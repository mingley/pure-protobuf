# Reproduce the frozen sources

The published starting HEAD was acc8aef9. The benchmark baseline is the
recorded 600-file source at runtime commit 6d1336e0; its core inputs match
acc8aef9. The previous capsule records the baseline binaries and host.

After checking the archive with check.py, extract it into a disposable
directory. Run `python3 source/reconstruct.py /path/to/repo /tmp/pbrs-source
VARIANT`, replacing VARIANT with a name in source/manifest.json. It exports
the baseline, materializes six in-tree symlinks, applies that variant's
overlays and verifies every input hash. Use the retained build plans and
`*-build.json` files for compiler settings, commands and exact harness inputs.
Absolute workspace paths in captured commands must be adjusted for the new
checkout. Preserve source and locks; rebuild fresh binaries before timing.

The old evidence capsule documents the reused baseline artifacts. Compiler,
protoc and GNU time installations, ELF files, build caches and duplicate
generated output are deliberately excluded. See the parent page for workload
scope, control limitations and all losses.
