"""Reconstruct and hash-check one frozen source from the Git baseline and archived overlays."""
import argparse,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser(description=__doc__);p.add_argument('repository',type=Path);p.add_argument('destination',type=Path);p.add_argument('variant');a=p.parse_args()
repo=a.repository.resolve(strict=True);out=a.destination.resolve();source=Path(__file__).resolve().parent;manifest=json.loads((source/'manifest.json').read_text());base=manifest['baseline_files'];v=manifest['variants'][a.variant];assert not out.exists();out.mkdir(parents=True)
paths=sorted(base)
process=subprocess.Popen(['git','-C',str(repo),'archive','--format=tar',manifest['baseline_commit'],*paths],stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout,mode='r|') as stream:stream.extractall(out,filter='data')
assert process.wait()==0
materialized=[]
for name,want in base.items():
 file=out/name
 if file.is_symlink():
  target=file.resolve(strict=True);assert target.is_relative_to(out);data=file.read_bytes();file.unlink();file.write_bytes(data);materialized.append(name)
 assert file.is_file() and hashlib.sha256(file.read_bytes()).hexdigest()==want,name
for path,meta in v['declared_changes'].items():
 overlay=(source/'overlays'/a.variant/path).resolve(strict=True);assert overlay.is_relative_to(source/'overlays'/a.variant)
 dest=out/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(overlay,dest)
actual={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()};assert actual==v['files'],(set(actual)^set(v['files']),[p for p in actual.keys()&v['files'].keys() if actual[p]!=v['files'][p]][:10])
print(json.dumps(dict(variant=a.variant,files=len(actual),materialized_symlinks=sorted(materialized),verified=True)))
