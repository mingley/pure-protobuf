# Correctness repairs and rejected optimization candidates

Publication draft for `docs/evidence/optimizations-20261028/`. This update
supersedes the candidate-status sections of `work/round-evidence-draft.md`.
The earlier draft retains allocator details and reproduction notes.

The published starting point is `acc8aef9`. Measurements use the frozen
`6d1336e0` runtime baseline, whose relevant inputs match that published tree
(`work/benchmark-followup/baseline-equivalence.json`). Candidate snapshots
identify the rejected results below. The selected correctness source is
`ce0a06e50ab2262cb3a38d39660858b30561fc88`. Ratios are paired
candidate/baseline medians; values above one mean a regression. These shared
x86_64 VM measurements do not establish a world ranking or comprehensive parity.

## Correctness changes

The byte-budget repair uses checked relaxed compare-exchange loops for
unlimited byte and permit-token accounting. The previous overflowing
`fetch_add`/rollback sequence could briefly publish a wrapped value and admit
an impossible overlapping acquisition. Deterministic counterfactual tests and
barrier-controlled public acquisitions cover both counters. Fourteen budget
tests, strict transport Clippy and Rust 1.85 native/Tower checks pass. Exact
source, commands and log hashes are in `work/review-budget-overflow.json`.

The separate framing repair checks stream header-plus-payload arithmetic and
rejects unrepresentable identity frames before reservation or codec execution.
Configured encoding-cap errors retain precedence over arithmetic errors.
Compressed plaintext may exceed `u32` on a capable host; its compressed wire
length is checked separately. Prior server messages still flush before the
error trailer. Client failures release permits and preserve existing reset
and closed-upload behavior. The existing rollback/unwind guard remains active.

Twenty-one wire units, three integration tests and strict transport/library
and fixture Clippy pass. `work/framing-overflow-results.json` binds the exact
four source/test hashes and logs. Integration coverage includes open/closed
uploads, connection recovery, prior replies and status trailers. Actual
32-bit execution and allocations above 4 GiB were not performed. Synthetic
lengths exercise the arithmetic without creating such payloads. The change
does not validate every dishonest codec's reported-versus-written length or
catch arbitrary user panics.

Neither repair is a speed claim. The tracker microbenchmark has no tonic
equivalent: valid acquire/drop paired CPU medians range from 0.844 to 1.170
across zero/64-byte permits and one/two/four threads, with wide contention
ranges. For four threads and 64 bytes, the ratio is 1.170 with a 0.634–1.291
pair range. Full RPC results on the selected combined source remain required.
The raw record is `work/benchmark-followup/results/budget-micro/`.

## Candidates rejected after measurement

| Candidate | Observation that prevents adoption |
| --- | --- |
| Lazy provenance enum, `6acebf0d…` | Nested depth-8/64 full reads use 1.066/1.075 times prior CPU; every pair regresses. Smaller measured boxes did not justify the CPU cost. |
| Initial map prefix/fold candidate, `8333fa59…` | Distinct 16/64/256 ordinary full loops use 5.473/7.547/7.390 times prior CPU; distinct collection and an owned mixed-read lifecycle also regress. |
| Narrow map candidate, `54b…` | The same distinct full loops use 5.802–8.226 times prior CPU. |
| Forced-inline map candidate, `a2871279…` | Distinct collection uses 1.306–1.449 times prior CPU; ordinary full loops use 2.568–3.364 times prior CPU. |
| First-survivor-only inline candidate, `a2dd829e…` | Removing the fold override still leaves distinct collection at 1.377–1.448 times prior CPU and full loops at 2.479–3.371 times prior CPU. |
| Generator move-and-shrink, `2c5e6119…` | Release small fresh generation has a 1.171 paired elapsed ratio; its pair range spans 0.825–1.266. There is no broad speed win. |
| Broad borrowed-wire prototype | Lazy depth-8/64 full reads improve to 0.905/0.906 times prior CPU, but owned scalar parse/read regress to 1.269/1.174. The lazy reads still use 2.602/2.121 times Prost CPU. |
| Narrow borrowed-wire prototype | Owned mixed parse/read regress to 1.102/1.101 times prior CPU; owned scalar parse/read to 1.216/1.186. Small fresh release generation regresses to 1.102 times prior elapsed time (pair range 1.012–1.272). |

Focused correctness checks passed for these candidates. That did not predict
their shipping performance. The map tests now also cover normal iteration,
partial reads, order, early exit, construction/read/drop and a surviving first
entry; benchmark controls labelled `prost` are standard `HashMap` for map-only
cells. They are not Prost parsing measurements. Assembly observations explain
which wrappers inline, but do not override the measured regressions.

Allocator improvements remain diagnostic. On the tested compiler and x86_64
target, the rejected lazy enum reduces fixture parse requests from 432 to 424
bytes and first-getter requests from 128 to 120, with unchanged allocation
counts. This relies on compiler layout choices. Generator move-and-shrink has
byte-identical output across five corpora and lowers instrumented requested-
live peaks. A 1,000-message release command's maximum RSS falls from 77.83 to
65.39 MB; this is direct-command maximum RSS, not a simultaneous process-tree
peak. The allocator counts a realloc's full new size and cannot observe old
and new allocations overlapping inside realloc. The earlier move-only variant
also increased retained capacity and was replaced before timing. Neither
resource observation establishes lower CPU.

## Upload designs left unchanged

Deferring closed-upload encoding can let an early peer success hide a later
local codec error. Sending each completed frame during synchronous encoding
can expose request DATA before a later local failure. These alternatives
change observable ordering; neither is adopted. The discarded deferred source
was not retained, so there is no exact-source reproduction or timed claim for
it. A shared compression slab is unmeasured and needs a bound on concurrent
active speculation. The current 16 MiB idle ledger and 4 MiB per-backing cap
do not bound every active allocation. No cap is raised. The complete source
analysis is `work/transport-closed-upload-analysis.md`.

## Results still pending

A narrower borrowed-wire candidate confines new generated helper use to
eligible prevalidated lazy messages. It preserves owned-mode generated output
and old helper/macro compatibility. Source manifests are
`work/borrowed-wire-narrow-20261028/source-manifest.json` and
`work/all-benchmarks/measurement/round-borrowed-narrow-source-source.json`.
It is also rejected: although lazy depth-8/64 reads improve to 0.906/0.908
times prior CPU, they remain 2.344/2.038 times Prost CPU and the lifecycle
regressions above remain. Its results are recorded separately from the broad
prototype; neither is selected.

**Complete combined benchmark results and final workspace/conformance/MSRV/
regeneration checks: pending.** Retain every row,
control movement and pair range before making adoption or speed claims.

The previous published ledger remains 124 timing rows with 48 losses and
seven ties, and 236 resource rows with 55 losses and 138 ties. Nine axes remain
missing. Deep lazy reads, small/duplicate maps, small release generation,
large generated output and downstream consumer build costs remain in scope.
Prior transport losses also remain: noisy upload-client requested bytes were
16.072 MB versus tonic's 12.151 MB; pipeline-client CPU increased by a paired
1.471 ratio, and the longer identity-client confirmation by 1.151. The rejected
earlier C identity reservation traded 25.4% fewer requested bytes for roughly
50% higher client and 56% higher server CPU. No all-benchmark win follows from
this round's focused observations.

## Reproduction and packaging inputs

Keep the baseline capsule linked at
`docs/evidence/decode-and-map-speed-20261027/README.md`. Exact candidate source
overlays/manifests, build records, raw captures and summaries are under:

- `work/all-benchmarks/measurement/round-{codec,map-actual,map-narrow,map-forced-inline,map-first-inline,borrowed}-*-comparison/`.
- `work/benchmark-followup/results/map-ordinary-loop{,-narrow,-forced,-first-inline}/`,
  `codegen-after-{debug,release}/`, `codegen-borrowed-{debug,release}/` and
  `budget-micro/`.
- `work/codec-provenance-results.json`, `work/round-validation/map*.log`,
  `work/map-next-variant/`, `work/map-first-only/` and `work/map-first-inline/`.
- `work/codegen-move-20261028/shrink-allocation-results/results.json`,
  `shrink-allocations.py`, allocator driver sources, manifests and lockfiles.
- `work/borrowed-wire-20261028/{results.json,source-manifest.json}`,
  `work/borrowed-wire-narrow-20261028/` and
  `work/borrowed-wire-legacy-compat-20261028/`.
- `work/review-budget-overflow.json`, `work/framing-overflow-results.json`
  and their referenced source-hash and validation logs.

The preparation, build and measurement commands are in
`work/benchmark-followup/`; `binary-audit.json` and per-harness records bind
executables to frozen source. Preserve rejected stale-artifact preflights as
diagnostics and use only accepted fresh-artifact captures for comparison.
The final archive inventory and integrity check are **pending**.
