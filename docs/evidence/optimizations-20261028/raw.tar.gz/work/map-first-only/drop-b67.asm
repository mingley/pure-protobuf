
work/all-benchmarks/measurement/round-loop-first-only/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002a390 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof>:
   2a390:	41 56                	push   %r14
   2a392:	53                   	push   %rbx
   2a393:	50                   	push   %rax
   2a394:	48 85 ff             	test   %rdi,%rdi
   2a397:	74 43                	je     2a3dc <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof+0x4c>
   2a399:	48 89 fb             	mov    %rdi,%rbx
   2a39c:	48 83 3f 00          	cmpq   $0x0,(%rdi)
   2a3a0:	74 0a                	je     2a3ac <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof+0x1c>
   2a3a2:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   2a3a6:	ff 15 ac 77 04 00    	call   *0x477ac(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a3ac:	8b 43 30             	mov    0x30(%rbx),%eax
   2a3af:	8d 48 fe             	lea    -0x2(%rax),%ecx
   2a3b2:	83 f9 02             	cmp    $0x2,%ecx
   2a3b5:	72 15                	jb     2a3cc <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof+0x3c>
   2a3b7:	85 c0                	test   %eax,%eax
   2a3b9:	75 29                	jne    2a3e4 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof+0x54>
   2a3bb:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   2a3c0:	74 0a                	je     2a3cc <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl3GVi33whjw_4pbrs3map3MapllEECsiIbCUDqdB5G_24pbrs_map_iteration_proof+0x3c>
   2a3c2:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   2a3c6:	ff 15 8c 77 04 00    	call   *0x4778c(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a3cc:	48 89 df             	mov    %rbx,%rdi
   2a3cf:	48 83 c4 08          	add    $0x8,%rsp
   2a3d3:	5b                   	pop    %rbx
   2a3d4:	41 5e                	pop    %r14
   2a3d6:	ff 25 7c 77 04 00    	jmp    *0x4777c(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a3dc:	48 83 c4 08          	add    $0x8,%rsp
   2a3e0:	5b                   	pop    %rbx
   2a3e1:	41 5e                	pop    %r14
   2a3e3:	c3                   	ret
   2a3e4:	48 8d 3d 8c f2 fd ff 	lea    -0x20d74(%rip),%rdi        # 9677 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3e0>
   2a3eb:	48 8d 15 ae 5f 04 00 	lea    0x45fae(%rip),%rdx        # 703a0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9b0>
   2a3f2:	be 79 00 00 00       	mov    $0x79,%esi
   2a3f7:	ff 15 ab 77 04 00    	call   *0x477ab(%rip)        # 71ba8 <_DYNAMIC+0x280>
   2a3fd:	0f 0b                	ud2
   2a3ff:	49 89 c6             	mov    %rax,%r14
   2a402:	48 89 df             	mov    %rbx,%rdi
   2a405:	ff 15 4d 77 04 00    	call   *0x4774d(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a40b:	4c 89 f7             	mov    %r14,%rdi
   2a40e:	e8 3d 3f 04 00       	call   6e350 <_Unwind_Resume@plt>
