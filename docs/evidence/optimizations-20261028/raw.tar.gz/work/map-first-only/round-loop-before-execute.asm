
/workspace/pure-protobuf/work/all-benchmarks/measurement/round-loop-before/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002d910 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_>:
   2d910:	55                   	push   %rbp
   2d911:	41 57                	push   %r15
   2d913:	41 56                	push   %r14
   2d915:	41 55                	push   %r13
   2d917:	41 54                	push   %r12
   2d919:	53                   	push   %rbx
   2d91a:	48 83 ec 78          	sub    $0x78,%rsp
   2d91e:	48 8b 07             	mov    (%rdi),%rax
   2d921:	48 8b 00             	mov    (%rax),%rax
   2d924:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2d929:	75 10                	jne    2d93b <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x2b>
   2d92b:	48 8b 40 08          	mov    0x8(%rax),%rax
   2d92f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2d935:	0f 84 4b 03 00 00    	je     2dc86 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2d93b:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2d93f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2d944:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2d949:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2d94d:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2d951:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2d955:	48 83 f9 04          	cmp    $0x4,%rcx
   2d959:	0f 87 60 0b 00 00    	ja     2e4bf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2d95f:	48 8b 40 08          	mov    0x8(%rax),%rax
   2d963:	48 8d 15 c6 b8 fd ff 	lea    -0x2473a(%rip),%rdx        # 9230 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2d96a:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2d96e:	48 01 d1             	add    %rdx,%rcx
   2d971:	ff e1                	jmp    *%rcx
   2d973:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2d97a:	61 6c 6c 
   2d97d:	48 39 08             	cmp    %rcx,(%rax)
   2d980:	0f 85 39 0b 00 00    	jne    2e4bf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2d986:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   2d98b:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2d98f:	48 85 c0             	test   %rax,%rax
   2d992:	0f 84 2a 03 00 00    	je     2dcc2 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2d998:	48 8b 09             	mov    (%rcx),%rcx
   2d99b:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2d99f:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2d9a3:	f7 d7                	not    %edi
   2d9a5:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2d9a9:	31 d2                	xor    %edx,%edx
   2d9ab:	eb 36                	jmp    2d9e3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2d9ad:	0f 1f 00             	nopl   (%rax)
   2d9b0:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2d9b4:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2d9b9:	41 21 f8             	and    %edi,%r8d
   2d9bc:	41 c1 e1 03          	shl    $0x3,%r9d
   2d9c0:	48 89 cf             	mov    %rcx,%rdi
   2d9c3:	4c 29 cf             	sub    %r9,%rdi
   2d9c6:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2d9ca:	49 89 d2             	mov    %rdx,%r10
   2d9cd:	4d 01 ca             	add    %r9,%r10
   2d9d0:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2d9d4:	4c 01 d2             	add    %r10,%rdx
   2d9d7:	44 89 c7             	mov    %r8d,%edi
   2d9da:	48 ff c8             	dec    %rax
   2d9dd:	0f 84 e1 02 00 00    	je     2dcc4 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2d9e3:	66 85 ff             	test   %di,%di
   2d9e6:	75 c8                	jne    2d9b0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2d9e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2d9ef:	00 
   2d9f0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2d9f4:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2d9f8:	48 83 c6 10          	add    $0x10,%rsi
   2d9fc:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2da00:	66 83 f7 ff          	xor    $0xffff,%di
   2da04:	74 ea                	je     2d9f0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2da06:	eb a8                	jmp    2d9b0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2da08:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2da0f:	66 69 72 
   2da12:	48 33 08             	xor    (%rax),%rcx
   2da15:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2da19:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2da1f:	48 09 c8             	or     %rcx,%rax
   2da22:	0f 85 97 0a 00 00    	jne    2e4bf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2da28:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2da2d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2da32:	0f 84 77 02 00 00    	je     2dcaf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2da38:	48 8b 00             	mov    (%rax),%rax
   2da3b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2da3f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2da43:	66 83 f1 ff          	xor    $0xffff,%cx
   2da47:	75 1d                	jne    2da66 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2da49:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2da4d:	0f 1f 00             	nopl   (%rax)
   2da50:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2da54:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2da58:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2da5c:	48 83 c2 10          	add    $0x10,%rdx
   2da60:	66 83 f1 ff          	xor    $0xffff,%cx
   2da64:	74 ea                	je     2da50 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2da66:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2da6a:	c1 e1 03             	shl    $0x3,%ecx
   2da6d:	48 29 c8             	sub    %rcx,%rax
   2da70:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2da74:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2da78:	e9 34 02 00 00       	jmp    2dcb1 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2da7d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2da84:	72 65 61 
   2da87:	48 33 08             	xor    (%rax),%rcx
   2da8a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2da8e:	48 83 f0 64          	xor    $0x64,%rax
   2da92:	48 09 c8             	or     %rcx,%rax
   2da95:	0f 85 24 0a 00 00    	jne    2e4bf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2da9b:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2daa2:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2daa7:	0f 85 2b 0a 00 00    	jne    2e4d8 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbc8>
   2daad:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2dab1:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2dab6:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2daba:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2dabe:	0f 10 05 8b 28 04 00 	movups 0x4288b(%rip),%xmm0        # 70350 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2dac5:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2dac9:	f3 0f 6f 05 8f 28 04 	movdqu 0x4288f(%rip),%xmm0        # 70360 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2dad0:	00 
   2dad1:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2dad7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2dadc:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2dae1:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2dae5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2daea:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2daef:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2daf4:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2daf8:	48 85 c9             	test   %rcx,%rcx
   2dafb:	0f 84 cf 01 00 00    	je     2dcd0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2db01:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2db05:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2db09:	48 89 e3             	mov    %rsp,%rbx
   2db0c:	0f 1f 40 00          	nopl   0x0(%rax)
   2db10:	41 8b 36             	mov    (%r14),%esi
   2db13:	41 8b 56 04          	mov    0x4(%r14),%edx
   2db17:	48 89 df             	mov    %rbx,%rdi
   2db1a:	e8 41 60 00 00       	call   33b60 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2db1f:	49 83 c6 08          	add    $0x8,%r14
   2db23:	4d 39 fe             	cmp    %r15,%r14
   2db26:	75 e8                	jne    2db10 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2db28:	48 8b 3c 24          	mov    (%rsp),%rdi
   2db2c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2db31:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2db36:	48 85 c9             	test   %rcx,%rcx
   2db39:	0f 84 86 03 00 00    	je     2dec5 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x5b5>
   2db3f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2db43:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2db48:	41 f7 d1             	not    %r9d
   2db4b:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2db4f:	31 d2                	xor    %edx,%edx
   2db51:	49 89 f8             	mov    %rdi,%r8
   2db54:	eb 3d                	jmp    2db93 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2db56:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2db5d:	00 00 00 
   2db60:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2db64:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2db69:	45 21 ca             	and    %r9d,%r10d
   2db6c:	41 c1 e3 03          	shl    $0x3,%r11d
   2db70:	4d 89 c1             	mov    %r8,%r9
   2db73:	4d 29 d9             	sub    %r11,%r9
   2db76:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2db7a:	48 89 d3             	mov    %rdx,%rbx
   2db7d:	4c 01 db             	add    %r11,%rbx
   2db80:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2db84:	48 01 da             	add    %rbx,%rdx
   2db87:	45 89 d1             	mov    %r10d,%r9d
   2db8a:	48 ff c9             	dec    %rcx
   2db8d:	0f 84 34 03 00 00    	je     2dec7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x5b7>
   2db93:	66 45 85 c9          	test   %r9w,%r9w
   2db97:	75 c7                	jne    2db60 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2db99:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2dba0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dba4:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2dba8:	48 83 c6 10          	add    $0x10,%rsi
   2dbac:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dbb1:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2dbb6:	74 e8                	je     2dba0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2dbb8:	eb a6                	jmp    2db60 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2dbba:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2dbc1:	63 6f 6c 
   2dbc4:	48 33 08             	xor    (%rax),%rcx
   2dbc7:	8b 40 08             	mov    0x8(%rax),%eax
   2dbca:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2dbd0:	48 09 c8             	or     %rcx,%rax
   2dbd3:	0f 85 e6 08 00 00    	jne    2e4bf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2dbd9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2dbde:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2dbe2:	48 85 c9             	test   %rcx,%rcx
   2dbe5:	0f 84 f8 00 00 00    	je     2dce3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2dbeb:	4c 8b 28             	mov    (%rax),%r13
   2dbee:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2dbf4:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dbf9:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2dbfd:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dc02:	75 25                	jne    2dc29 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2dc04:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2dc0b:	00 00 00 00 00 
   2dc10:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2dc15:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2dc19:	48 83 c5 10          	add    $0x10,%rbp
   2dc1d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dc22:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dc27:	74 e7                	je     2dc10 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2dc29:	48 83 f9 05          	cmp    $0x5,%rcx
   2dc2d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2dc32:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2dc38:	4c 0f 43 f9          	cmovae %rcx,%r15
   2dc3c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2dc43:	00 
   2dc44:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2dc4b:	ff ff 1f 
   2dc4e:	48 ff c0             	inc    %rax
   2dc51:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2dc56:	48 39 c1             	cmp    %rax,%rcx
   2dc59:	0f 97 c0             	seta   %al
   2dc5c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2dc63:	ff ff 7f 
   2dc66:	48 83 c1 0b          	add    $0xb,%rcx
   2dc6a:	49 39 ce             	cmp    %rcx,%r14
   2dc6d:	0f 97 c1             	seta   %cl
   2dc70:	08 c1                	or     %al,%cl
   2dc72:	0f 84 47 01 00 00    	je     2ddbf <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x4af>
   2dc78:	31 db                	xor    %ebx,%ebx
   2dc7a:	48 89 df             	mov    %rbx,%rdi
   2dc7d:	4c 89 f6             	mov    %r14,%rsi
   2dc80:	ff 15 ea 42 04 00    	call   *0x442ea(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   2dc86:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2dc8a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2dc8f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   2dc94:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2dc99:	4c 8b 38             	mov    (%rax),%r15
   2dc9c:	4d 85 ff             	test   %r15,%r15
   2dc9f:	74 4f                	je     2dcf0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2dca1:	4d 8b 77 08          	mov    0x8(%r15),%r14
   2dca5:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2dca9:	49 83 c7 18          	add    $0x18,%r15
   2dcad:	eb 47                	jmp    2dcf6 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x3e6>
   2dcaf:	31 c9                	xor    %ecx,%ecx
   2dcb1:	48 89 0c 24          	mov    %rcx,(%rsp)
   2dcb5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2dcba:	48 89 e0             	mov    %rsp,%rax
   2dcbd:	e9 da 09 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dcc2:	31 d2                	xor    %edx,%edx
   2dcc4:	48 89 14 24          	mov    %rdx,(%rsp)
   2dcc8:	48 89 e0             	mov    %rsp,%rax
   2dccb:	e9 cc 09 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dcd0:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2dcd7:	00 00 
   2dcd9:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2dcde:	e9 b9 09 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dce3:	b8 04 00 00 00       	mov    $0x4,%eax
   2dce8:	45 31 ff             	xor    %r15d,%r15d
   2dceb:	e9 61 04 00 00       	jmp    2e151 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2dcf0:	45 31 ff             	xor    %r15d,%r15d
   2dcf3:	45 31 f6             	xor    %r14d,%r14d
   2dcf6:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2dcfa:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dcfe:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2dd02:	48 83 f9 04          	cmp    $0x4,%rcx
   2dd06:	0f 87 e7 07 00 00    	ja     2e4f3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2dd0c:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dd10:	48 8d 15 2d b5 fd ff 	lea    -0x24ad3(%rip),%rdx        # 9244 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2dd17:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2dd1b:	48 01 d1             	add    %rdx,%rcx
   2dd1e:	ff e1                	jmp    *%rcx
   2dd20:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2dd27:	61 6c 6c 
   2dd2a:	48 39 08             	cmp    %rcx,(%rax)
   2dd2d:	0f 85 c0 07 00 00    	jne    2e4f3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2dd33:	4d 85 f6             	test   %r14,%r14
   2dd36:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2dd3c:	4d 0f 45 e6          	cmovne %r14,%r12
   2dd40:	31 c0                	xor    %eax,%eax
   2dd42:	48 85 db             	test   %rbx,%rbx
   2dd45:	0f 84 4a 09 00 00    	je     2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd4b:	4d 85 f6             	test   %r14,%r14
   2dd4e:	0f 84 41 09 00 00    	je     2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd54:	48 83 fb 10          	cmp    $0x10,%rbx
   2dd58:	0f 92 c0             	setb   %al
   2dd5b:	4d 85 ff             	test   %r15,%r15
   2dd5e:	0f 94 c1             	sete   %cl
   2dd61:	08 c1                	or     %al,%cl
   2dd63:	0f 84 74 04 00 00    	je     2e1dd <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8cd>
   2dd69:	49 8d 0c de          	lea    (%r14,%rbx,8),%rcx
   2dd6d:	31 c0                	xor    %eax,%eax
   2dd6f:	31 d2                	xor    %edx,%edx
   2dd71:	eb 18                	jmp    2dd8b <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x47b>
   2dd73:	49 63 34 f4          	movslq (%r12,%rsi,8),%rsi
   2dd77:	49 63 7c d4 fc       	movslq -0x4(%r12,%rdx,8),%rdi
   2dd7c:	48 01 f0             	add    %rsi,%rax
   2dd7f:	48 01 f8             	add    %rdi,%rax
   2dd82:	48 39 da             	cmp    %rbx,%rdx
   2dd85:	0f 83 0a 09 00 00    	jae    2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd8b:	48 89 d6             	mov    %rdx,%rsi
   2dd8e:	48 8d 56 01          	lea    0x1(%rsi),%rdx
   2dd92:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
   2dd96:	48 83 c7 08          	add    $0x8,%rdi
   2dd9a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2dda0:	48 39 cf             	cmp    %rcx,%rdi
   2dda3:	74 ce                	je     2dd73 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x463>
   2dda5:	44 8b 07             	mov    (%rdi),%r8d
   2dda8:	48 83 c7 08          	add    $0x8,%rdi
   2ddac:	45 3b 04 f4          	cmp    (%r12,%rsi,8),%r8d
   2ddb0:	75 ee                	jne    2dda0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x490>
   2ddb2:	48 89 d6             	mov    %rdx,%rsi
   2ddb5:	48 39 da             	cmp    %rbx,%rdx
   2ddb8:	75 d4                	jne    2dd8e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x47e>
   2ddba:	e9 d6 08 00 00       	jmp    2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2ddbf:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2ddc4:	c1 e0 03             	shl    $0x3,%eax
   2ddc7:	4c 89 e9             	mov    %r13,%rcx
   2ddca:	48 29 c1             	sub    %rax,%rcx
   2ddcd:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2ddd2:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   2ddd8:	4c 89 f7             	mov    %r14,%rdi
   2dddb:	ff 15 df 41 04 00    	call   *0x441df(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2dde1:	48 85 c0             	test   %rax,%rax
   2dde4:	0f 84 90 fe ff ff    	je     2dc7a <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2ddea:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2ddef:	48 89 cb             	mov    %rcx,%rbx
   2ddf2:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2ddf8:	66 0f d6 00          	movq   %xmm0,(%rax)
   2ddfc:	4c 89 3c 24          	mov    %r15,(%rsp)
   2de00:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2de05:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2de0c:	00 00 
   2de0e:	48 ff cb             	dec    %rbx
   2de11:	0f 84 3a 03 00 00    	je     2e151 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2de17:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2de1c:	45 21 e7             	and    %r12d,%r15d
   2de1f:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2de25:	49 89 e4             	mov    %rsp,%r12
   2de28:	eb 35                	jmp    2de5f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x54f>
   2de2a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2de30:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2de35:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2de39:	44 21 f9             	and    %r15d,%ecx
   2de3c:	48 ff cb             	dec    %rbx
   2de3f:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2de45:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2de4b:	49 ff c6             	inc    %r14
   2de4e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2de53:	41 89 cf             	mov    %ecx,%r15d
   2de56:	48 85 db             	test   %rbx,%rbx
   2de59:	0f 84 e4 02 00 00    	je     2e143 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x833>
   2de5f:	66 45 85 ff          	test   %r15w,%r15w
   2de63:	75 24                	jne    2de89 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x579>
   2de65:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2de6c:	00 00 00 00 
   2de70:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2de75:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2de79:	48 83 c5 10          	add    $0x10,%rbp
   2de7d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2de82:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2de87:	74 e7                	je     2de70 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x560>
   2de89:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2de8e:	c1 e1 03             	shl    $0x3,%ecx
   2de91:	4c 89 ea             	mov    %r13,%rdx
   2de94:	48 29 ca             	sub    %rcx,%rdx
   2de97:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2de9c:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2dea1:	4c 3b 34 24          	cmp    (%rsp),%r14
   2dea5:	75 8e                	jne    2de35 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x525>
   2dea7:	b9 04 00 00 00       	mov    $0x4,%ecx
   2deac:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2deb2:	4c 89 e7             	mov    %r12,%rdi
   2deb5:	4c 89 f6             	mov    %r14,%rsi
   2deb8:	48 89 da             	mov    %rbx,%rdx
   2debb:	e8 d0 ec ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2dec0:	e9 6b ff ff ff       	jmp    2de30 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x520>
   2dec5:	31 d2                	xor    %edx,%edx
   2dec7:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   2decc:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
   2ded1:	48 85 c0             	test   %rax,%rax
   2ded4:	0f 84 c2 07 00 00    	je     2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2deda:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2dee1:	00 
   2dee2:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2dee6:	48 01 c8             	add    %rcx,%rax
   2dee9:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2deed:	0f 84 a9 07 00 00    	je     2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2def3:	48 29 cf             	sub    %rcx,%rdi
   2def6:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2defa:	ff 15 a8 40 04 00    	call   *0x440a8(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   2df00:	e9 97 07 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2df05:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2df0c:	66 69 72 
   2df0f:	48 33 08             	xor    (%rax),%rcx
   2df12:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2df16:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2df1c:	48 09 c8             	or     %rcx,%rax
   2df1f:	0f 85 ce 05 00 00    	jne    2e4f3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2df25:	4d 85 f6             	test   %r14,%r14
   2df28:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2df2e:	4d 0f 45 e6          	cmovne %r14,%r12
   2df32:	31 ed                	xor    %ebp,%ebp
   2df34:	48 85 db             	test   %rbx,%rbx
   2df37:	0f 84 9e 02 00 00    	je     2e1db <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2df3d:	4d 85 f6             	test   %r14,%r14
   2df40:	0f 84 95 02 00 00    	je     2e1db <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2df46:	48 83 fb 10          	cmp    $0x10,%rbx
   2df4a:	0f 92 c0             	setb   %al
   2df4d:	4d 85 ff             	test   %r15,%r15
   2df50:	0f 94 c1             	sete   %cl
   2df53:	08 c1                	or     %al,%cl
   2df55:	0f 84 37 02 00 00    	je     2e192 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x882>
   2df5b:	49 8d 04 de          	lea    (%r14,%rbx,8),%rax
   2df5f:	31 c9                	xor    %ecx,%ecx
   2df61:	49 8d 14 cc          	lea    (%r12,%rcx,8),%rdx
   2df65:	49 8d 34 cc          	lea    (%r12,%rcx,8),%rsi
   2df69:	48 83 c6 08          	add    $0x8,%rsi
   2df6d:	48 ff c1             	inc    %rcx
   2df70:	48 39 c6             	cmp    %rax,%rsi
   2df73:	0f 84 90 02 00 00    	je     2e209 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8f9>
   2df79:	8b 3e                	mov    (%rsi),%edi
   2df7b:	48 83 c6 08          	add    $0x8,%rsi
   2df7f:	3b 3a                	cmp    (%rdx),%edi
   2df81:	75 ed                	jne    2df70 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x660>
   2df83:	31 ed                	xor    %ebp,%ebp
   2df85:	48 39 d9             	cmp    %rbx,%rcx
   2df88:	75 d7                	jne    2df61 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x651>
   2df8a:	e9 88 02 00 00       	jmp    2e217 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2df8f:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2df96:	72 65 61 
   2df99:	48 33 08             	xor    (%rax),%rcx
   2df9c:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2dfa0:	48 83 f0 64          	xor    $0x64,%rax
   2dfa4:	48 09 c8             	or     %rcx,%rax
   2dfa7:	0f 85 46 05 00 00    	jne    2e4f3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2dfad:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2dfb4:	00 00 
   2dfb6:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2dfba:	48 89 04 24          	mov    %rax,(%rsp)
   2dfbe:	48 89 e0             	mov    %rsp,%rax
   2dfc1:	48 8b 04 24          	mov    (%rsp),%rax
   2dfc5:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dfc9:	48 85 c9             	test   %rcx,%rcx
   2dfcc:	0f 84 ab 01 00 00    	je     2e17d <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2dfd2:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2dfd6:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2dfda:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2dfdf:	90                   	nop
   2dfe0:	41 8b 36             	mov    (%r14),%esi
   2dfe3:	41 8b 56 04          	mov    0x4(%r14),%edx
   2dfe7:	48 89 df             	mov    %rbx,%rdi
   2dfea:	e8 d1 70 00 00       	call   350c0 <_RNvMso_NtCse9VFdDP9LWm_4pbrs3mapINtB5_3MapllE10push_entryCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2dfef:	49 83 c6 08          	add    $0x8,%r14
   2dff3:	4d 39 fe             	cmp    %r15,%r14
   2dff6:	75 e8                	jne    2dfe0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x6d0>
   2dff8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2dffd:	48 85 ff             	test   %rdi,%rdi
   2e000:	0f 84 77 01 00 00    	je     2e17d <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2e006:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
   2e00a:	48 85 db             	test   %rbx,%rbx
   2e00d:	0f 84 6c 01 00 00    	je     2e17f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x86f>
   2e013:	4c 8b 77 08          	mov    0x8(%rdi),%r14
   2e017:	48 83 fb 10          	cmp    $0x10,%rbx
   2e01b:	0f 83 07 02 00 00    	jae    2e228 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x918>
   2e021:	49 8d 4e 08          	lea    0x8(%r14),%rcx
   2e025:	48 8d 14 dd f8 ff ff 	lea    -0x8(,%rbx,8),%rdx
   2e02c:	ff 
   2e02d:	31 c0                	xor    %eax,%eax
   2e02f:	31 f6                	xor    %esi,%esi
   2e031:	eb 1b                	jmp    2e04e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x73e>
   2e033:	4f 63 04 d6          	movslq (%r14,%r10,8),%r8
   2e037:	49 89 c1             	mov    %rax,%r9
   2e03a:	4d 01 c1             	add    %r8,%r9
   2e03d:	49 63 44 f6 fc       	movslq -0x4(%r14,%rsi,8),%rax
   2e042:	4c 01 c8             	add    %r9,%rax
   2e045:	48 39 de             	cmp    %rbx,%rsi
   2e048:	0f 83 33 01 00 00    	jae    2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e04e:	4c 8d 0c f5 00 00 00 	lea    0x0(,%rsi,8),%r9
   2e055:	00 
   2e056:	49 89 d0             	mov    %rdx,%r8
   2e059:	4d 29 c8             	sub    %r9,%r8
   2e05c:	4c 8d 0c f1          	lea    (%rcx,%rsi,8),%r9
   2e060:	49 89 f2             	mov    %rsi,%r10
   2e063:	48 ff c6             	inc    %rsi
   2e066:	48 39 de             	cmp    %rbx,%rsi
   2e069:	74 c8                	je     2e033 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e06b:	47 8b 1c d6          	mov    (%r14,%r10,8),%r11d
   2e06f:	45 31 ff             	xor    %r15d,%r15d
   2e072:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e079:	1f 84 00 00 00 00 00 
   2e080:	47 39 1c 39          	cmp    %r11d,(%r9,%r15,1)
   2e084:	74 0b                	je     2e091 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x781>
   2e086:	49 83 c7 08          	add    $0x8,%r15
   2e08a:	4d 39 f8             	cmp    %r15,%r8
   2e08d:	75 f1                	jne    2e080 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x770>
   2e08f:	eb a2                	jmp    2e033 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e091:	49 83 c1 08          	add    $0x8,%r9
   2e095:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e099:	49 89 f2             	mov    %rsi,%r10
   2e09c:	48 ff c6             	inc    %rsi
   2e09f:	48 39 de             	cmp    %rbx,%rsi
   2e0a2:	75 c7                	jne    2e06b <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x75b>
   2e0a4:	eb 8d                	jmp    2e033 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e0a6:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e0ad:	63 6f 6c 
   2e0b0:	48 33 08             	xor    (%rax),%rcx
   2e0b3:	8b 40 08             	mov    0x8(%rax),%eax
   2e0b6:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e0bc:	48 09 c8             	or     %rcx,%rax
   2e0bf:	0f 85 2e 04 00 00    	jne    2e4f3 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2e0c5:	4d 85 f6             	test   %r14,%r14
   2e0c8:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2e0ce:	4d 0f 45 e6          	cmovne %r14,%r12
   2e0d2:	49 0f 44 de          	cmove  %r14,%rbx
   2e0d6:	31 c0                	xor    %eax,%eax
   2e0d8:	48 85 db             	test   %rbx,%rbx
   2e0db:	74 1a                	je     2e0f7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0dd:	4d 85 ff             	test   %r15,%r15
   2e0e0:	74 15                	je     2e0f7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0e2:	48 83 fb 10          	cmp    $0x10,%rbx
   2e0e6:	72 0f                	jb     2e0f7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0e8:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e0ec:	85 c0                	test   %eax,%eax
   2e0ee:	0f 85 18 04 00 00    	jne    2e50c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xbfc>
   2e0f4:	4c 89 f8             	mov    %r15,%rax
   2e0f7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e0fe:	00 
   2e0ff:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   2e104:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e109:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e10e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e115:	00 00 
   2e117:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2e11c:	48 89 e6             	mov    %rsp,%rsi
   2e11f:	48 89 df             	mov    %rbx,%rdi
   2e122:	e8 39 74 00 00       	call   35560 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCse9VFdDP9LWm_4pbrs3map11MapViewIterllEE9from_iterCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e127:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   2e12d:	0f 84 69 05 00 00    	je     2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e133:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   2e138:	ff 15 6a 3e 04 00    	call   *0x43e6a(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   2e13e:	e9 59 05 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e143:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e147:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e14c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e151:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e155:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e15a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e15f:	48 89 e0             	mov    %rsp,%rax
   2e162:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e167:	0f 84 2f 05 00 00    	je     2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e16d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e172:	ff 15 30 3e 04 00    	call   *0x43e30(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   2e178:	e9 1f 05 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e17d:	31 ff                	xor    %edi,%edi
   2e17f:	31 c0                	xor    %eax,%eax
   2e181:	48 89 04 24          	mov    %rax,(%rsp)
   2e185:	48 89 e0             	mov    %rsp,%rax
   2e188:	e8 a3 bd ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e18d:	e9 0a 05 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e192:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e196:	85 c0                	test   %eax,%eax
   2e198:	0f 85 81 03 00 00    	jne    2e51f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc0f>
   2e19e:	49 8b 57 10          	mov    0x10(%r15),%rdx
   2e1a2:	48 39 da             	cmp    %rbx,%rdx
   2e1a5:	74 65                	je     2e20c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e1a7:	48 85 d2             	test   %rdx,%rdx
   2e1aa:	74 2f                	je     2e1db <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2e1ac:	49 8b 4f 08          	mov    0x8(%r15),%rcx
   2e1b0:	48 83 fa 01          	cmp    $0x1,%rdx
   2e1b4:	0f 85 a0 02 00 00    	jne    2e45a <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb4a>
   2e1ba:	8b 11                	mov    (%rcx),%edx
   2e1bc:	31 c0                	xor    %eax,%eax
   2e1be:	eb 0a                	jmp    2e1ca <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8ba>
   2e1c0:	48 ff c0             	inc    %rax
   2e1c3:	31 ed                	xor    %ebp,%ebp
   2e1c5:	48 39 c3             	cmp    %rax,%rbx
   2e1c8:	74 4d                	je     2e217 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e1ca:	41 3b 14 c4          	cmp    (%r12,%rax,8),%edx
   2e1ce:	75 f0                	jne    2e1c0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e1d0:	48 3b 41 08          	cmp    0x8(%rcx),%rax
   2e1d4:	75 ea                	jne    2e1c0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e1d6:	e9 db 02 00 00       	jmp    2e4b6 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xba6>
   2e1db:	eb 3a                	jmp    2e217 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e1dd:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e1e1:	85 c0                	test   %eax,%eax
   2e1e3:	0f 85 56 03 00 00    	jne    2e53f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc2f>
   2e1e9:	49 8b 4f 10          	mov    0x10(%r15),%rcx
   2e1ed:	48 39 d9             	cmp    %rbx,%rcx
   2e1f0:	0f 85 64 03 00 00    	jne    2e55a <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc4a>
   2e1f6:	48 83 fb 04          	cmp    $0x4,%rbx
   2e1fa:	0f 83 03 01 00 00    	jae    2e303 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x9f3>
   2e200:	31 c0                	xor    %eax,%eax
   2e202:	31 c9                	xor    %ecx,%ecx
   2e204:	e9 75 04 00 00       	jmp    2e67e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd6e>
   2e209:	49 89 d4             	mov    %rdx,%r12
   2e20c:	f3 41 0f 7e 04 24    	movq   (%r12),%xmm0
   2e212:	bd 01 00 00 00       	mov    $0x1,%ebp
   2e217:	89 2c 24             	mov    %ebp,(%rsp)
   2e21a:	66 0f d6 44 24 04    	movq   %xmm0,0x4(%rsp)
   2e220:	48 89 e0             	mov    %rsp,%rax
   2e223:	e9 74 04 00 00       	jmp    2e69c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e228:	49 89 ff             	mov    %rdi,%r15
   2e22b:	8b 47 30             	mov    0x30(%rdi),%eax
   2e22e:	85 c0                	test   %eax,%eax
   2e230:	0f 85 db 03 00 00    	jne    2e611 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd01>
   2e236:	4c 89 ff             	mov    %r15,%rdi
   2e239:	49 8b 4f 28          	mov    0x28(%r15),%rcx
   2e23d:	48 39 d9             	cmp    %rbx,%rcx
   2e240:	0f 85 57 01 00 00    	jne    2e39d <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xa8d>
   2e246:	48 89 d9             	mov    %rbx,%rcx
   2e249:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
   2e24d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e251:	31 c0                	xor    %eax,%eax
   2e253:	66 0f ef c9          	pxor   %xmm1,%xmm1
   2e257:	f3 41 0f 6f 14 c6    	movdqu (%r14,%rax,8),%xmm2
   2e25d:	f3 41 0f 6f 5c c6 10 	movdqu 0x10(%r14,%rax,8),%xmm3
   2e264:	66 0f 70 e2 e8       	pshufd $0xe8,%xmm2,%xmm4
   2e269:	66 0f 6f e8          	movdqa %xmm0,%xmm5
   2e26d:	66 0f 70 c2 ed       	pshufd $0xed,%xmm2,%xmm0
   2e272:	66 0f 70 d3 e8       	pshufd $0xe8,%xmm3,%xmm2
   2e277:	66 0f 6f f1          	movdqa %xmm1,%xmm6
   2e27b:	66 0f 70 cb ed       	pshufd $0xed,%xmm3,%xmm1
   2e280:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e284:	66 0f 66 dc          	pcmpgtd %xmm4,%xmm3
   2e288:	66 0f 62 e3          	punpckldq %xmm3,%xmm4
   2e28c:	66 0f d4 ec          	paddq  %xmm4,%xmm5
   2e290:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e294:	66 0f 66 da          	pcmpgtd %xmm2,%xmm3
   2e298:	66 0f 62 d3          	punpckldq %xmm3,%xmm2
   2e29c:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   2e2a0:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e2a4:	66 0f 66 d0          	pcmpgtd %xmm0,%xmm2
   2e2a8:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
   2e2ac:	66 0f d4 c5          	paddq  %xmm5,%xmm0
   2e2b0:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e2b4:	66 0f 66 d1          	pcmpgtd %xmm1,%xmm2
   2e2b8:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
   2e2bc:	66 0f d4 ce          	paddq  %xmm6,%xmm1
   2e2c0:	48 83 c0 04          	add    $0x4,%rax
   2e2c4:	48 39 c1             	cmp    %rax,%rcx
   2e2c7:	75 8e                	jne    2e257 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x947>
   2e2c9:	66 0f d4 c8          	paddq  %xmm0,%xmm1
   2e2cd:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   2e2d2:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   2e2d6:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2e2db:	48 39 cb             	cmp    %rcx,%rbx
   2e2de:	0f 84 9d fe ff ff    	je     2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e2e4:	49 63 14 ce          	movslq (%r14,%rcx,8),%rdx
   2e2e8:	48 89 c6             	mov    %rax,%rsi
   2e2eb:	49 63 44 ce 04       	movslq 0x4(%r14,%rcx,8),%rax
   2e2f0:	48 ff c1             	inc    %rcx
   2e2f3:	48 01 d6             	add    %rdx,%rsi
   2e2f6:	48 01 f0             	add    %rsi,%rax
   2e2f9:	48 39 cb             	cmp    %rcx,%rbx
   2e2fc:	75 e6                	jne    2e2e4 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x9d4>
   2e2fe:	e9 7e fe ff ff       	jmp    2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e303:	48 89 d9             	mov    %rbx,%rcx
   2e306:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
   2e30a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e30e:	31 c0                	xor    %eax,%eax
   2e310:	66 0f ef c9          	pxor   %xmm1,%xmm1
   2e314:	f3 41 0f 6f 14 c6    	movdqu (%r14,%rax,8),%xmm2
   2e31a:	f3 41 0f 6f 5c c6 10 	movdqu 0x10(%r14,%rax,8),%xmm3
   2e321:	66 0f 70 e2 e8       	pshufd $0xe8,%xmm2,%xmm4
   2e326:	66 0f 6f e8          	movdqa %xmm0,%xmm5
   2e32a:	66 0f 70 c2 ed       	pshufd $0xed,%xmm2,%xmm0
   2e32f:	66 0f 70 d3 e8       	pshufd $0xe8,%xmm3,%xmm2
   2e334:	66 0f 6f f1          	movdqa %xmm1,%xmm6
   2e338:	66 0f 70 cb ed       	pshufd $0xed,%xmm3,%xmm1
   2e33d:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e341:	66 0f 66 dc          	pcmpgtd %xmm4,%xmm3
   2e345:	66 0f 62 e3          	punpckldq %xmm3,%xmm4
   2e349:	66 0f d4 ec          	paddq  %xmm4,%xmm5
   2e34d:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e351:	66 0f 66 da          	pcmpgtd %xmm2,%xmm3
   2e355:	66 0f 62 d3          	punpckldq %xmm3,%xmm2
   2e359:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   2e35d:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e361:	66 0f 66 d0          	pcmpgtd %xmm0,%xmm2
   2e365:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
   2e369:	66 0f d4 c5          	paddq  %xmm5,%xmm0
   2e36d:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e371:	66 0f 66 d1          	pcmpgtd %xmm1,%xmm2
   2e375:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
   2e379:	66 0f d4 ce          	paddq  %xmm6,%xmm1
   2e37d:	48 83 c0 04          	add    $0x4,%rax
   2e381:	48 39 c1             	cmp    %rax,%rcx
   2e384:	75 8e                	jne    2e314 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xa04>
   2e386:	66 0f d4 c8          	paddq  %xmm0,%xmm1
   2e38a:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   2e38f:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   2e393:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2e398:	e9 f3 02 00 00       	jmp    2e690 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd80>
   2e39d:	48 85 c9             	test   %rcx,%rcx
   2e3a0:	0f 84 d9 fd ff ff    	je     2e17f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x86f>
   2e3a6:	48 8b 57 20          	mov    0x20(%rdi),%rdx
   2e3aa:	31 c0                	xor    %eax,%eax
   2e3ac:	31 f6                	xor    %esi,%esi
   2e3ae:	48 83 f9 01          	cmp    $0x1,%rcx
   2e3b2:	75 23                	jne    2e3d7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xac7>
   2e3b4:	44 8b 02             	mov    (%rdx),%r8d
   2e3b7:	eb 0c                	jmp    2e3c5 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xab5>
   2e3b9:	48 ff c6             	inc    %rsi
   2e3bc:	48 39 f3             	cmp    %rsi,%rbx
   2e3bf:	0f 84 bc fd ff ff    	je     2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e3c5:	45 3b 04 f6          	cmp    (%r14,%rsi,8),%r8d
   2e3c9:	75 ee                	jne    2e3b9 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e3cb:	48 3b 72 08          	cmp    0x8(%rdx),%rsi
   2e3cf:	75 e8                	jne    2e3b9 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e3d1:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
   2e3d5:	eb 64                	jmp    2e43b <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb2b>
   2e3d7:	49 89 f1             	mov    %rsi,%r9
   2e3da:	eb 09                	jmp    2e3e5 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xad5>
   2e3dc:	49 39 d9             	cmp    %rbx,%r9
   2e3df:	0f 84 9c fd ff ff    	je     2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e3e5:	4c 89 ce             	mov    %r9,%rsi
   2e3e8:	47 8b 04 ce          	mov    (%r14,%r9,8),%r8d
   2e3ec:	49 89 c9             	mov    %rcx,%r9
   2e3ef:	45 31 d2             	xor    %r10d,%r10d
   2e3f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e3f9:	1f 84 00 00 00 00 00 
   2e400:	4d 89 d3             	mov    %r10,%r11
   2e403:	4d 89 cf             	mov    %r9,%r15
   2e406:	49 d1 ef             	shr    $1,%r15
   2e409:	4d 01 fa             	add    %r15,%r10
   2e40c:	4d 89 d4             	mov    %r10,%r12
   2e40f:	49 c1 e4 04          	shl    $0x4,%r12
   2e413:	46 39 04 22          	cmp    %r8d,(%rdx,%r12,1)
   2e417:	4d 0f 4f d3          	cmovg  %r11,%r10
   2e41b:	4d 29 f9             	sub    %r15,%r9
   2e41e:	49 83 f9 01          	cmp    $0x1,%r9
   2e422:	77 dc                	ja     2e400 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xaf0>
   2e424:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
   2e428:	49 c1 e2 04          	shl    $0x4,%r10
   2e42c:	46 39 04 12          	cmp    %r8d,(%rdx,%r10,1)
   2e430:	75 aa                	jne    2e3dc <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xacc>
   2e432:	49 01 d2             	add    %rdx,%r10
   2e435:	49 39 72 08          	cmp    %rsi,0x8(%r10)
   2e439:	75 a1                	jne    2e3dc <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xacc>
   2e43b:	49 63 74 f6 04       	movslq 0x4(%r14,%rsi,8),%rsi
   2e440:	4d 63 c0             	movslq %r8d,%r8
   2e443:	4c 01 c0             	add    %r8,%rax
   2e446:	48 01 f0             	add    %rsi,%rax
   2e449:	4c 89 ce             	mov    %r9,%rsi
   2e44c:	49 39 d9             	cmp    %rbx,%r9
   2e44f:	0f 82 59 ff ff ff    	jb     2e3ae <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xa9e>
   2e455:	e9 27 fd ff ff       	jmp    2e181 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e45a:	31 c0                	xor    %eax,%eax
   2e45c:	eb 0e                	jmp    2e46c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb5c>
   2e45e:	48 ff c0             	inc    %rax
   2e461:	31 ed                	xor    %ebp,%ebp
   2e463:	48 39 d8             	cmp    %rbx,%rax
   2e466:	0f 84 ab fd ff ff    	je     2e217 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e46c:	41 8b 34 c4          	mov    (%r12,%rax,8),%esi
   2e470:	49 89 d0             	mov    %rdx,%r8
   2e473:	31 ff                	xor    %edi,%edi
   2e475:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e47c:	00 00 00 00 
   2e480:	49 89 f9             	mov    %rdi,%r9
   2e483:	4d 89 c2             	mov    %r8,%r10
   2e486:	49 d1 ea             	shr    $1,%r10
   2e489:	4c 01 d7             	add    %r10,%rdi
   2e48c:	49 89 fb             	mov    %rdi,%r11
   2e48f:	49 c1 e3 04          	shl    $0x4,%r11
   2e493:	42 39 34 19          	cmp    %esi,(%rcx,%r11,1)
   2e497:	49 0f 4f f9          	cmovg  %r9,%rdi
   2e49b:	4d 29 d0             	sub    %r10,%r8
   2e49e:	49 83 f8 01          	cmp    $0x1,%r8
   2e4a2:	77 dc                	ja     2e480 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb70>
   2e4a4:	48 c1 e7 04          	shl    $0x4,%rdi
   2e4a8:	39 34 39             	cmp    %esi,(%rcx,%rdi,1)
   2e4ab:	75 b1                	jne    2e45e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb4e>
   2e4ad:	48 01 cf             	add    %rcx,%rdi
   2e4b0:	48 39 47 08          	cmp    %rax,0x8(%rdi)
   2e4b4:	75 a8                	jne    2e45e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xb4e>
   2e4b6:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
   2e4ba:	e9 4d fd ff ff       	jmp    2e20c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e4bf:	48 8d 3d ce ad fd ff 	lea    -0x25232(%rip),%rdi        # 9294 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e4c6:	48 8d 15 4b 20 04 00 	lea    0x4204b(%rip),%rdx        # 70518 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6a8>
   2e4cd:	be 28 00 00 00       	mov    $0x28,%esi
   2e4d2:	ff 15 40 3c 04 00    	call   *0x43c40(%rip)        # 72118 <_DYNAMIC+0x3a0>
   2e4d8:	49 89 fe             	mov    %rdi,%r14
   2e4db:	ff 15 9f 3e 04 00    	call   *0x43e9f(%rip)        # 72380 <_DYNAMIC+0x608>
   2e4e1:	4c 89 f7             	mov    %r14,%rdi
   2e4e4:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e4e9:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e4ee:	e9 c3 f5 ff ff       	jmp    2dab6 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e4f3:	48 8d 3d 9a ad fd ff 	lea    -0x25266(%rip),%rdi        # 9294 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e4fa:	48 8d 15 2f 20 04 00 	lea    0x4202f(%rip),%rdx        # 70530 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6c0>
   2e501:	be 28 00 00 00       	mov    $0x28,%esi
   2e506:	ff 15 0c 3c 04 00    	call   *0x43c0c(%rip)        # 72118 <_DYNAMIC+0x3a0>
   2e50c:	4c 89 ff             	mov    %r15,%rdi
   2e50f:	4c 89 e6             	mov    %r12,%rsi
   2e512:	48 89 da             	mov    %rbx,%rdx
   2e515:	e8 a2 ab ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e51a:	e9 d5 fb ff ff       	jmp    2e0f4 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x7e4>
   2e51f:	4c 89 ff             	mov    %r15,%rdi
   2e522:	4c 89 f6             	mov    %r14,%rsi
   2e525:	48 89 da             	mov    %rbx,%rdx
   2e528:	e8 8f ab ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e52d:	49 8b 57 10          	mov    0x10(%r15),%rdx
   2e531:	48 39 da             	cmp    %rbx,%rdx
   2e534:	0f 85 6d fc ff ff    	jne    2e1a7 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x897>
   2e53a:	e9 cd fc ff ff       	jmp    2e20c <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e53f:	4c 89 ff             	mov    %r15,%rdi
   2e542:	4c 89 f6             	mov    %r14,%rsi
   2e545:	48 89 da             	mov    %rbx,%rdx
   2e548:	e8 6f ab ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e54d:	49 8b 4f 10          	mov    0x10(%r15),%rcx
   2e551:	48 39 d9             	cmp    %rbx,%rcx
   2e554:	0f 84 9c fc ff ff    	je     2e1f6 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x8e6>
   2e55a:	48 85 c9             	test   %rcx,%rcx
   2e55d:	0f 84 a7 00 00 00    	je     2e60a <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xcfa>
   2e563:	49 8b 57 08          	mov    0x8(%r15),%rdx
   2e567:	31 c0                	xor    %eax,%eax
   2e569:	31 f6                	xor    %esi,%esi
   2e56b:	48 83 f9 01          	cmp    $0x1,%rcx
   2e56f:	75 22                	jne    2e593 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc83>
   2e571:	8b 3a                	mov    (%rdx),%edi
   2e573:	eb 0c                	jmp    2e581 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc71>
   2e575:	48 ff c6             	inc    %rsi
   2e578:	48 39 f3             	cmp    %rsi,%rbx
   2e57b:	0f 84 14 01 00 00    	je     2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e581:	41 3b 3c f4          	cmp    (%r12,%rsi,8),%edi
   2e585:	75 ee                	jne    2e575 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc65>
   2e587:	48 3b 72 08          	cmp    0x8(%rdx),%rsi
   2e58b:	75 e8                	jne    2e575 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc65>
   2e58d:	4c 8d 46 01          	lea    0x1(%rsi),%r8
   2e591:	eb 58                	jmp    2e5eb <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xcdb>
   2e593:	49 89 f0             	mov    %rsi,%r8
   2e596:	eb 09                	jmp    2e5a1 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc91>
   2e598:	49 39 d8             	cmp    %rbx,%r8
   2e59b:	0f 84 f4 00 00 00    	je     2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e5a1:	4c 89 c6             	mov    %r8,%rsi
   2e5a4:	43 8b 3c c4          	mov    (%r12,%r8,8),%edi
   2e5a8:	49 89 c8             	mov    %rcx,%r8
   2e5ab:	45 31 c9             	xor    %r9d,%r9d
   2e5ae:	66 90                	xchg   %ax,%ax
   2e5b0:	4d 89 ca             	mov    %r9,%r10
   2e5b3:	4d 89 c3             	mov    %r8,%r11
   2e5b6:	49 d1 eb             	shr    $1,%r11
   2e5b9:	4d 01 d9             	add    %r11,%r9
   2e5bc:	4d 89 ce             	mov    %r9,%r14
   2e5bf:	49 c1 e6 04          	shl    $0x4,%r14
   2e5c3:	42 39 3c 32          	cmp    %edi,(%rdx,%r14,1)
   2e5c7:	4d 0f 4f ca          	cmovg  %r10,%r9
   2e5cb:	4d 29 d8             	sub    %r11,%r8
   2e5ce:	49 83 f8 01          	cmp    $0x1,%r8
   2e5d2:	77 dc                	ja     2e5b0 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xca0>
   2e5d4:	4c 8d 46 01          	lea    0x1(%rsi),%r8
   2e5d8:	49 c1 e1 04          	shl    $0x4,%r9
   2e5dc:	42 39 3c 0a          	cmp    %edi,(%rdx,%r9,1)
   2e5e0:	75 b6                	jne    2e598 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc88>
   2e5e2:	49 01 d1             	add    %rdx,%r9
   2e5e5:	49 39 71 08          	cmp    %rsi,0x8(%r9)
   2e5e9:	75 ad                	jne    2e598 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc88>
   2e5eb:	49 63 74 f4 04       	movslq 0x4(%r12,%rsi,8),%rsi
   2e5f0:	48 63 ff             	movslq %edi,%rdi
   2e5f3:	48 01 f8             	add    %rdi,%rax
   2e5f6:	48 01 f0             	add    %rsi,%rax
   2e5f9:	4c 89 c6             	mov    %r8,%rsi
   2e5fc:	49 39 d8             	cmp    %rbx,%r8
   2e5ff:	0f 82 66 ff ff ff    	jb     2e56b <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xc5b>
   2e605:	e9 8b 00 00 00       	jmp    2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e60a:	31 c0                	xor    %eax,%eax
   2e60c:	e9 84 00 00 00       	jmp    2e695 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e611:	49 8d 7f 18          	lea    0x18(%r15),%rdi
   2e615:	4c 89 f6             	mov    %r14,%rsi
   2e618:	48 89 da             	mov    %rbx,%rdx
   2e61b:	e8 9c aa ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e620:	e9 11 fc ff ff       	jmp    2e236 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0x926>
   2e625:	48 89 c3             	mov    %rax,%rbx
   2e628:	eb 25                	jmp    2e64f <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd3f>
   2e62a:	48 89 c3             	mov    %rax,%rbx
   2e62d:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e632:	74 23                	je     2e657 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd47>
   2e634:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e639:	ff 15 69 39 04 00    	call   *0x43969(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   2e63f:	48 89 df             	mov    %rbx,%rdi
   2e642:	e8 89 01 04 00       	call   6e7d0 <_Unwind_Resume@plt>
   2e647:	48 89 c3             	mov    %rax,%rbx
   2e64a:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   2e64f:	4c 89 ff             	mov    %r15,%rdi
   2e652:	e8 d9 b8 ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e657:	48 89 df             	mov    %rbx,%rdi
   2e65a:	e8 71 01 04 00       	call   6e7d0 <_Unwind_Resume@plt>
   2e65f:	ff 15 9b 39 04 00    	call   *0x4399b(%rip)        # 72000 <_DYNAMIC+0x288>
   2e665:	48 89 c3             	mov    %rax,%rbx
   2e668:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e66c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e671:	e8 ba ba ff ff       	call   2a130 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e676:	48 89 df             	mov    %rbx,%rdi
   2e679:	e8 52 01 04 00       	call   6e7d0 <_Unwind_Resume@plt>
   2e67e:	49 63 14 ce          	movslq (%r14,%rcx,8),%rdx
   2e682:	49 63 74 ce 04       	movslq 0x4(%r14,%rcx,8),%rsi
   2e687:	48 ff c1             	inc    %rcx
   2e68a:	48 01 d0             	add    %rdx,%rax
   2e68d:	48 01 f0             	add    %rsi,%rax
   2e690:	48 39 cb             	cmp    %rcx,%rbx
   2e693:	75 e9                	jne    2e67e <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_+0xd6e>
   2e695:	48 89 04 24          	mov    %rax,(%rsp)
   2e699:	48 89 e0             	mov    %rsp,%rax
   2e69c:	48 83 c4 78          	add    $0x78,%rsp
   2e6a0:	5b                   	pop    %rbx
   2e6a1:	41 5c                	pop    %r12
   2e6a3:	41 5d                	pop    %r13
   2e6a5:	41 5e                	pop    %r14
   2e6a7:	41 5f                	pop    %r15
   2e6a9:	5d                   	pop    %rbp
   2e6aa:	c3                   	ret
