
work/all-benchmarks/measurement/round-loop-narrow-fresh/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002a270 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof>:
   2a270:	41 56                	push   %r14
   2a272:	53                   	push   %rbx
   2a273:	50                   	push   %rax
   2a274:	48 85 ff             	test   %rdi,%rdi
   2a277:	74 43                	je     2a2bc <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof+0x4c>
   2a279:	48 89 fb             	mov    %rdi,%rbx
   2a27c:	48 83 3f 00          	cmpq   $0x0,(%rdi)
   2a280:	74 0a                	je     2a28c <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof+0x1c>
   2a282:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   2a286:	ff 15 cc 78 04 00    	call   *0x478cc(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a28c:	8b 43 30             	mov    0x30(%rbx),%eax
   2a28f:	8d 48 fe             	lea    -0x2(%rax),%ecx
   2a292:	83 f9 02             	cmp    $0x2,%ecx
   2a295:	72 15                	jb     2a2ac <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof+0x3c>
   2a297:	85 c0                	test   %eax,%eax
   2a299:	75 29                	jne    2a2c4 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof+0x54>
   2a29b:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   2a2a0:	74 0a                	je     2a2ac <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof+0x3c>
   2a2a2:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   2a2a6:	ff 15 ac 78 04 00    	call   *0x478ac(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a2ac:	48 89 df             	mov    %rbx,%rdi
   2a2af:	48 83 c4 08          	add    $0x8,%rsp
   2a2b3:	5b                   	pop    %rbx
   2a2b4:	41 5e                	pop    %r14
   2a2b6:	ff 25 9c 78 04 00    	jmp    *0x4789c(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a2bc:	48 83 c4 08          	add    $0x8,%rsp
   2a2c0:	5b                   	pop    %rbx
   2a2c1:	41 5e                	pop    %r14
   2a2c3:	c3                   	ret
   2a2c4:	48 8d 3d 9c f3 fd ff 	lea    -0x20c64(%rip),%rdi        # 9667 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3e0>
   2a2cb:	48 8d 15 ce 60 04 00 	lea    0x460ce(%rip),%rdx        # 703a0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9b0>
   2a2d2:	be 79 00 00 00       	mov    $0x79,%esi
   2a2d7:	ff 15 cb 78 04 00    	call   *0x478cb(%rip)        # 71ba8 <_DYNAMIC+0x280>
   2a2dd:	0f 0b                	ud2
   2a2df:	49 89 c6             	mov    %rax,%r14
   2a2e2:	48 89 df             	mov    %rbx,%rdi
   2a2e5:	ff 15 6d 78 04 00    	call   *0x4786d(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2a2eb:	4c 89 f7             	mov    %r14,%rdi
   2a2ee:	e8 5d 40 04 00       	call   6e350 <_Unwind_Resume@plt>
