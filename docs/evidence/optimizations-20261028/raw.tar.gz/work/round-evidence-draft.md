# Runtime, map, generator and budget follow-up

Draft for the current round. Focused correctness and allocator checks are
available. Combined and isolated performance results are pending; this page
does not establish a CPU improvement or a win on every benchmark.

## Source scope

The published starting point is `acc8aef92d65bd73fe4f082150770395d4475808`.
The benchmark baseline is the frozen runtime source
`6d1336e0f6490249c7339b6a8a6bb74c7d44d432`. The relevant runtime and generator
inputs match the published starting point; the check is recorded in
`work/benchmark-followup/baseline-equivalence.json`.

**Final source commit: [PENDING].**
**Final source manifests, artifact hashes and adoption decisions: [PENDING].**

Four candidate production files are frozen separately and together. Each
snapshot contains the same 600-file baseline with only its declared changes.
The manifests are under `work/all-benchmarks/measurement/`:

| Candidate | Production file | Source manifest |
| --- | --- | --- |
| Lazy validation provenance | `src/lazy.rs` | `round-codec-source-source.json` |
| Map iteration | `src/map.rs` | `round-map-actual-source-source.json` |
| Generated output ownership | `src/codegen/descriptors.rs` | `round-codegen-source-source.json` |
| Checked budget counters | `pbrs-grpc/src/limits.rs` | `round-budget-actual-source-source.json` |
| All four together | The four files above | `round-integrated-source-source.json` |

The manifests record full before/after file hashes. Map and generator test
changes are correctness checks; they do not change the benchmark workload.

## The four designs

The lazy-message candidate replaces the separate validation flag with a
private enum containing either unchecked or validated `Wire`. It keeps `Wire`
itself and the zero-valid outer `Option<Box<_>>` representation unchanged.
Both variants dispatch to the same checked or prevalidated merge methods used
before. Old and custom generated code retains the checked trait fallback.

The map candidate uses the existing last-occurrence index to skip a shadowed
wire prefix. When index cardinality proves that the remaining suffix contains
only surviving entries, `fold` traverses that suffix directly. Proven-unique
maps also use direct slice folding. It adds no index field or projection
buffer. Last-value-wins semantics, last-occurrence order and partially consumed
iterator behavior remain part of the contract. Ordinary `for`/`next` and cold
construction holdouts are included because a `fold` improvement alone would
not establish a faster map lifecycle.

The generator candidate moves the completed source string into the output
when there is only one output path. It calls `shrink_to_fit` first to avoid
retaining the emitter's spare capacity. A target needing both a package path
and a flat alias still gets independently owned strings. This changes output
ownership, not generated Rust bytes. Shrinking can move and copy the buffer;
an in-place shrink is allocator behavior, not a guarantee.

The budget correction replaces overflowing `fetch_add` followed by rollback
with checked relaxed compare-exchange loops. Neither the unlimited byte
counter nor the permit-token counter may publish a transient wrapped value.
The existing byte caps, token ownership, rollback after a later failure and
release behavior remain in force. This is a correctness repair. It adds
checked CAS work to valid acquisitions; its runtime cost must be measured.

## Focused checks and allocator observations

The lazy proof passes malformed-wire and UTF-8 rejection, merge/mutation,
clone isolation, concurrent getters, shared input lifetime, required fields,
oneofs and legacy fallback checks. Initial descendant validations remain 63;
the later getter chain performs zero. Sixteen lazy unit tests, a Rust 1.85
validated-lazy consumer check and strict core Clippy pass. The source-bound
record is `work/codec-provenance-results.json`; its logs and independent review
are `work/codec-provenance-final-proof.log`,
`work/codec-provenance-lazy-tests.log`,
`work/codec-provenance-msrv-independent.log`,
`work/codec-provenance-clippy-after-map-fix.log` and
`work/review-lazy-wire.json`.

On this x86_64 toolchain, that fixture requests 424 bytes for parsing instead
of 432, and 120 bytes for the first child instead of 128. Allocation counts
remain two and one respectively. Rust's enum niche/layout choices can differ
across compilers and targets; these are fixture measurements, not a stable
eight-byte layout promise. Deep full reads still construct boxed children.

Twelve map-view tests pass, including order and values after partial reads,
short-circuiting, empty/singleton maps, distinct and duplicate keys, and
mutation after indexing. Focused assertions require zero projection
allocations and bounded key comparisons for the indexed first survivor.
Strict all-feature core Clippy passes. **Final source-bound map test log and
complete benchmark allocation results: [PENDING].**

Twenty-five generator tests and the targeted deterministic multi-target test
pass (`work/codegen-move-20261028/codegen-tests.log` and
`alias-test-profile0.log`). The alias test also mutates one output and checks
that the other stays independent. The separate allocator capture records
identical input hashes and complete generated filename/size/SHA sets for five
synthetic corpora. Its warm, second-call observations are:

| Corpus | Requested allocation calls, before → candidate | Peak requested-live bytes, before → candidate | Retained bytes, before → candidate |
| --- | ---: | ---: | ---: |
| One file, full output | 50,951 → 50,950 | 6,327,858 → 4,117,177 | 2,214,403 → 2,214,408 |
| Twenty files, full | 502,132 → 502,112 | 47,338,438 → 45,217,096 | 42,304,114 → 42,304,214 |
| Twenty files, shared lean | 289,997 → 289,977 | 19,394,283 → 18,026,540 | 16,716,328 → 16,716,428 |
| Hundred files, shared full | 288,610 → 288,510 | 20,227,765 → 19,387,301 | 18,487,132 → 18,487,632 |
| Hundred files, full | 288,205 → 288,105 | 75,705,159 → 74,978,824 | 73,544,908 → 73,545,408 |

Requested-byte totals are nearly unchanged: 11 fewer bytes per target in
these fixtures. The allocator counts each successful `realloc` as a request
for its entire new size, including shrinking. Its live counter subtracts the
old size before adding the new size; it cannot observe any transient overlap
inside the system allocator. Peak values also depend on worker overlap.
These counters measure requested bytes, not allocator usable size, RSS or
system-wide peak memory. Instrumented wall and CPU samples are explicitly
unusable for speed claims.

Reproduction inputs, commands, output hashes and samples are in
`work/codegen-move-20261028/shrink-allocation-results/results.json`, with
`shrink-allocations.py`, `shrink-allocation/src/main.rs`, both driver manifests
and lockfiles, and the build logs in that directory. The earlier move-only
experiment is retained in `allocation-results/results.json`; it raised
retained bytes by 1.15–4.61 times and was replaced by the shrink variant.

Fourteen budget tests pass. Deterministic counterfactuals stage the old wrap
and overlapping public acquisition; barrier-controlled public acquisitions
also prove that exactly one increment fits at `usize::MAX - 1`. Strict
transport Clippy and Rust 1.85 native/Tower checks pass. Commands, exact source
hash and log hashes are in `work/review-budget-overflow.json`. These tests do
not measure CAS throughput or contention.

## Upload alternatives rejected in this round

No upload implementation change is accepted here. The closed-upload path
currently finishes all local encoding, size and admission checks before
queueing request DATA. Deferring later encoding until earlier sends progress
could let an early peer success hide a later custom-codec error. Synchronous
encode/send interleaving could expose a DATA prefix before a later local
failure; waiting for send capacity without handling the peer can also stall.
Checking only queued `Err` items does not establish future codec success.

The discarded deferred prototype has no retained exact source, benchmark or
independently reproduced failure. These are source/control-flow arguments;
the narrower synchronous alternative was not benchmarked either. A shared
compression slab is also unmeasured. It needs an explicit concurrent active
memory bound: the existing 16 MiB idle-cache ledger and 4 MiB per-backing cap
do not bound all active allocations. Predicting later outputs can waste
space on compressible or mixed-size messages and keep it alive through shared
prefixes. No cap is raised. The full analysis and call sites are in
`work/transport-closed-upload-analysis.md`.

## Losses carried forward

The previous source-pinned record remains
`docs/evidence/decode-and-map-speed-20261027/README.md`. Its ledger has 124
timing rows (69 wins, 48 losses, seven ties), 236 resource rows (43 wins, 55
losses, 138 ties) and nine missing axes. This round must not silently replace
those losses with focused candidate results.

Small and duplicate-heavy map rows mostly lose to standard `HashMap`: only
three of 42 warm-map rows won. The control named `prost` in that harness is
`HashMap`, not protobuf decoding. Lazy depth-64 full reads remained about
2.339 times Prost CPU; owned parsing retained one near-parity loss. Small
fresh and unchanged release generation lost, and the 1,000-message generated
output remained 36.31 MB versus Prost's 0.413 MB. Downstream consumer build
costs, service-stub generation and several other axes remain unmeasured.

Transport retained upload-client, download-server and large identity
allocation losses. For four noisy 1 MiB gzip upload messages, client requested
bytes were 16.072 MB versus tonic's 12.151 MB (ratio 1.323). The previous final
pipeline-client CPU ratio after/before was 1.471, and the longer identity
client confirmation was 1.151. Compressed allocation improvements did not
prove lower CPU. The older C identity reservation was rejected despite a
25.4% byte reduction because longer confirmation showed roughly 50% higher
client CPU and 56% higher server CPU. Identity growth stays unchanged here.

## Results and final checks to complete

**Isolated performance results and adoption decisions: [PENDING].** Include
every original row, paired ranges, ties, regressions and control drift.

**Combined performance results: [PENDING].** A component observation does not
prove the combined source wins. Retain CPU and allocation captures separately.

**Final workspace, conformance, regeneration, MSRV and lint results: [PENDING].**
Focused checks above are not a final-tree validation certificate.

The reproduction entry points are `work/benchmark-followup/freeze.py`,
`build-probes-actual.sh`, `build-extra.sh`, `build-integrated.sh` and
`measure.sh`. They use the existing matched harnesses under
`work/all-benchmarks/measurement/`; records include source manifests, build
profiles, lockfiles and binary hashes. New holdout source and helpers are
`map-loop-template/src/main.rs`, `map-loop-compare.py`,
`budget-template/src/main.rs`, `budget-compare.py` and
`prepare-rpc-plans.py`, all under `work/benchmark-followup/`.

Expected result locations, which are not completed-result claims:

- Existing matrices: `work/all-benchmarks/measurement/round-{map-actual,integrated}-{map-small,map-large,codec-lazy,codec-owned}-comparison/`
  and `round-{codec,integrated}-{codec-lazy,codec-owned,partial-lazy,partial-owned,encode-lazy,encode-owned}-comparison/`.
- Additional holdouts: `work/benchmark-followup/results/map-ordinary-loop/`
  (36 ordinary-loop/first-survivor/cold-construction rows) and `budget-micro/`
  (zero/64-byte permits with one/two/four threads; no tonic-equivalent control).
- Generator: `work/benchmark-followup/results/codegen-{after,integrated}-{debug,release}/`.
  Preserve corrected completion timing, fresh/unchanged cases and output hashes.
- Combined RPC: `work/benchmark-followup/results/rpc-{allocations,shipping,default,identity-confirmation}/`.
  Preserve the default pipeline and longer identity confirmation alongside
  compressed cells. Isolated tracker RPC plans and captures remain separately
  identified under `work/all-benchmarks/measurement/round-budget-*`.

**Final all-benchmark gate and missing-axis inventory: [PENDING].** No full
tonic/prost parity or world-leading ranking follows from these candidates.
