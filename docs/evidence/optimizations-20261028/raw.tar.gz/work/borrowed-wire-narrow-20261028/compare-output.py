"""Compare pre/post eligibility-refactor generated files, byte for byte."""
import hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/pure-protobuf');work=root/'work/borrowed-wire-narrow-20261028';src=work/'source';protoc=root/'target/conformance-build/protoc'
plugins={'before':work/'precompute-plugin','after':work/'target/debug/protoc-gen-pbrs'}
cases=[
 ('codec-owned',src/'proto',['codec_cases.proto'],'owned_message_fields=true'),
 ('codec-lazy',src/'proto',['codec_cases.proto'],''),
 ('collisions',src/'tests/proof/validated_lazy',['proof.proto','strict.proto'],''),
 ('options-and-imports',root/'tests/proof/codegen_parity/proto',['case.proto','external.proto','imported.proto','options_proto2.proto','unpackaged.proto'],'enable_type_names=true,retain_enum_prefix=true,shared_pool=true'),
 ('multi-target-100',root/'work/all-benchmarks/measurement/codegen-corrected-phase1-debug/corpora/100/consumer/proto',None,'shared_pool=true'),
]
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def outputs(p):return {str(f.relative_to(p)):dict(bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(p.rglob('*')) if f.is_file()}
report={'schema':'pbrs.borrowed-wire-eligibility-equivalence.v1','protoc':str(protoc),'protoc_sha256':sha(protoc),'plugins':{k:dict(path=str(v),sha256=sha(v)) for k,v in plugins.items()},'cases':[],'complete':False}
for name,include,files,options in cases:
 files=files or sorted(p.name for p in include.glob('*.proto'))
 assert files
 before=None
 for side,repeat in [('before',0),('after',0),('after',1),('after',2)]:
  output=work/'equivalence-outputs'/name/f'{side}-{repeat}';output.mkdir(parents=True,exist_ok=False)
  arg=(options+':' if options else '')+str(output)
  cmd=[str(protoc),f'--plugin=protoc-gen-pbrs={plugins[side]}',f'--pbrs_out={arg}',f'-I{include}',f'-I{root}/third_party/protobuf/src',*files]
  done=subprocess.run(cmd,cwd=include,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  value=outputs(output);assert done.returncode==0,(name,side,done.stderr)
  if before is None:before=value
  else:assert before==value,(name,side,repeat,'generated files differ')
  report['cases'].append(dict(case=name,side=side,repeat=repeat,command=cmd,exit_code=done.returncode,outputs=value))
 if name=='codec-owned':
  old=root/'work/bench-target/release/build/pbrs-codec-proof-7847111c722db867/out/pbrs/codec_cases.rs'
  generated=work/'equivalence-outputs'/name/'before-0/codec_cases.rs'
  report['owned_compared_to_previous_benchmark']=dict(baseline=str(old),same_bytes=old.read_bytes()==generated.read_bytes(),sha256=sha(generated),baseline_sha256=sha(old))
  report['owned_compared_to_previous_benchmark']['scope'] = 'Not an equivalent descriptor input: direct protoc includes source-info/comments; compare the Cargo-harness generated files separately.'
report['complete']=True;(work/'output-equivalence.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(complete=True,cases=len(cases),runs=len(report['cases']),direct_plugin_owned_matches_cargo=report['owned_compared_to_previous_benchmark']['same_bytes'])))
