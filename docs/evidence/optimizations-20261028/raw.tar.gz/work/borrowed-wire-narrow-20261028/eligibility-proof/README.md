# Reconstruct the eligibility-refactor check

The final narrow generator computes lazy/prevalidated eligibility once per
message. The pre-refactor narrow generator computed the same value in separate
emitters. Twenty direct-protoc runs over five input sets produced identical
files, including owned/lazy profiles, helper-name collision, options and
imports, and a five-target 100-message corpus. The pinned 13-file SDK drift
check also passes. `output-equivalence.json` records each command and output
hash; direct protoc supplies source-info, so it is a distinct input from the
Cargo harness. The separate owned-harness record verifies exact baseline bytes.

Reconstruct the final narrow export (600 source files, optionally with the eight proof files) from its 14-file overlay on the
published phase6 export. Run `python3 reconstruct.py FINAL_EXPORT PRE_OUTPUT`
from this directory to create the 608-file pre-refactor snapshot, including all
eight standalone proof files. The manifest validates every input and output
file and retains the two added schemas/inputs directories with their hashes.

Build `protoc-gen-pbrs` in the pre-refactor and final trees with the same Rust
and pinned protoc 35.1, then repeat the commands in `output-equivalence.json`
with the paths changed to those two plugin executables, the reconstructed
proof fixture and the retained `inputs/` directories. Compare every output file
against the recorded size and SHA-256. Rebuilt executable hashes can differ
with source paths and toolchains; this check compares generated output, not
executable bytes or timing. The original mismatch against a differently formed
Cargo descriptor and its failure log remain in the evidence.
