#!/usr/bin/env python3
"""Reconstruct the pre-refactor source from the exact final narrow export."""
import hashlib,json,shutil,sys
from pathlib import Path
base,out=Path(sys.argv[1]),Path(sys.argv[2]);here=Path(__file__).resolve().parent;m=json.loads((here/'manifest.json').read_text())
def check(p,r):return p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
expected=set(m['base_files']);extras=actual-expected
if expected-actual or not extras.issubset(set(m['proof_files'])):raise ValueError('final export inventory differs')
for rel in extras:
 if not check(base/rel,m['target_files'][rel]):raise ValueError('final proof fixture mismatch: '+rel)
for rel,r in m['base_files'].items():
 if not check(base/rel,r):raise ValueError('final export hash mismatch: '+rel)
out.mkdir(parents=True,exist_ok=False)
for rel in m['base_files']:
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/rel,target)
for rel,r in m['changed'].items():
 source=here/'precompute-overlay'/rel
 if not check(source,r):raise ValueError('overlay mismatch: '+rel)
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
actual={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.rglob('*') if p.is_file()}
if actual!=m['target_files']:raise ValueError('pre-refactor inventory/hash mismatch')
print(json.dumps(dict(files=len(actual),verified=True)))
