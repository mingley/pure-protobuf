# Old generated binding on the borrowed-wire runtime

This proof uses the unmodified phase6 `src/generated/struct.rs` (SHA-256
`dbe6f625312168409f12d5a52ab2781dfaa9df910dc941ec0c5fd63d2f9a293a`). Its
`PbValue` uses the old four-argument `impl_typed_message!` macro. The rest of
the runtime and generated bindings match the frozen narrow source.

Reconstruct the exact 608-file narrow benchmark export using its source
manifest and overlays, then run:

```sh
python3 reconstruct.py NARROW_EXPORT PROOF_OUTPUT
cargo run --locked --manifest-path PROOF_OUTPUT/tests/proof/validated_lazy/Cargo.toml
```

The overlay adds the old binding and one proof-only test. That test validates
nested wire, exercises the old generated prevalidated dispatch and ordinary
checked constructor, reads nested struct/map values, clones, merges another
field, and checks serialization and parsing again. `proof.log` is the captured
successful run. This mixed-generation binary is correctness evidence, not a
shipping timing result.
