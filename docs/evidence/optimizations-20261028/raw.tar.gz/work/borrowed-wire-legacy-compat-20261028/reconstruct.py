#!/usr/bin/env python3
"""Reconstruct the old-generated/new-runtime proof from the narrow export."""
import hashlib,json,shutil,sys
from pathlib import Path
base,out=Path(sys.argv[1]),Path(sys.argv[2]);here=Path(__file__).resolve().parent;m=json.loads((here/'manifest.json').read_text())
def check(p,r):
 return p.is_file() and not p.is_symlink() and p.stat().st_size==r['bytes'] and hashlib.sha256(p.read_bytes()).hexdigest()==r['sha256']
actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
if actual!=set(m['baseline_files']):raise ValueError('narrow export inventory differs')
for rel,r in m['baseline_files'].items():
 if not check(base/rel,r):raise ValueError('narrow export hash mismatch: '+rel)
out.mkdir(parents=True,exist_ok=False)
for rel in m['baseline_files']:
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/rel,target)
for rel,r in m['changed'].items():
 source=here/'overlay'/rel
 if not check(source,r):raise ValueError('overlay hash mismatch: '+rel)
 target=out/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
actual={str(p.relative_to(out)):dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest()) for p in out.rglob('*') if p.is_file()}
if actual!=m['proof_files']:raise ValueError('proof source inventory/hash mismatch')
print(json.dumps(dict(files=len(actual),verified=True)))
