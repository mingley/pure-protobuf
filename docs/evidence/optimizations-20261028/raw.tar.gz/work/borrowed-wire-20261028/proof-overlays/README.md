# Reconstruct the proof-only clone counters

These overlays apply to the exact `phase6` source snapshot from the earlier
published evidence capsule. The candidate was captured before regenerating
its ten SDK files; it is not the shipping measurement source. Both overlays
include the eight standalone validated-lazy fixture files and an instrumented
`Wire::clone`. The counter counts calls to `Wire::clone` on a private Arc-backed
64-node chain; it does not count all reference-count operations and its binaries
must not be used for CPU timing.

1. Reconstruct `phase6` using `reconstruct_variant.py` and `source-overlays`
   from `docs/evidence/decode-and-map-speed-20261027/raw.tar.gz`:
   `python3 reconstruct_variant.py REPOSITORY /tmp/pbrs-phase6 phase6`.
2. Run `python3 reconstruct.py /tmp/pbrs-phase6 /tmp/proof-before instrument-baseline`
   and `python3 reconstruct.py /tmp/pbrs-phase6 /tmp/proof-after instrument-candidate`.
3. From each reconstructed tree run `cargo run --locked --manifest-path
   tests/proof/validated_lazy/Cargo.toml` with protoc on PATH. The expected
   parent `Wire::clone` counts are 63 and 0. The original failed calibration
   and successful logs are retained in the accompanying evidence.

The complete hashes verify every reconstructed source and fixture file.
The final benchmark source has a separate manifest and regenerated SDK files.
