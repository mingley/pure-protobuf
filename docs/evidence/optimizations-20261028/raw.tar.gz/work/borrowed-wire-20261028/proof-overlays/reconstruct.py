#!/usr/bin/env python3
"""Rebuild a proof snapshot from the verified phase6 source and compact overlay."""
import hashlib,json,shutil,sys
from pathlib import Path
base,out,variant=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
here=Path(__file__).resolve().parent;manifest=json.loads((here/'manifest.json').read_text());selected=manifest['variants'][variant]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for name,record in manifest['baseline_files'].items():
 p=base/name
 if not p.is_file() or p.is_symlink() or p.stat().st_size!=record['bytes'] or digest(p)!=record['sha256']:raise ValueError('baseline mismatch: '+name)
actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
if actual!=set(manifest['baseline_files']):raise ValueError('baseline file inventory mismatch')
out.mkdir(parents=True,exist_ok=False)
for name in manifest['baseline_files']:
 p=out/name;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/name,p)
for name,record in selected['changed'].items():
 src=here/variant/name
 if not src.is_file() or src.is_symlink() or src.stat().st_size!=record['bytes'] or digest(src)!=record['sha256']:raise ValueError('overlay mismatch: '+name)
 dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
for name in selected['removed']:(out/name).unlink()
actual={str(p.relative_to(out)):dict(sha256=digest(p),bytes=p.stat().st_size) for p in out.rglob('*') if p.is_file()}
if actual!=selected['files']:raise ValueError('reconstructed file inventory/hash mismatch')
print(json.dumps(dict(variant=variant,files=len(actual),verified=True)))
