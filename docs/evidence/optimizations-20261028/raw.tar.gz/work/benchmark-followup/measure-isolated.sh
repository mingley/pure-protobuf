#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
mkdir -p "$out"
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
python3 - <<'PY'
import hashlib,json
from pathlib import Path
root=Path.cwd();b=root/'work/all-benchmarks/measurement'
for label,name in [('round-map-actual','src/map.rs'),('round-codec','src/lazy.rs'),('round-codegen','src/codegen/descriptors.rs'),('round-budget-actual','pbrs-grpc/src/limits.rs')]:
 d=json.loads((b/(label+'-source-source.json')).read_text());assert hashlib.sha256((root/name).read_bytes()).hexdigest()==d['declared_changes'][name]['after'],f'Working source changed: {name}'
print(json.dumps({'all_isolated_sources_match':True}),flush=True)
PY
for group in map-small map-large; do
python3 "$m/measure_phase2.py" "$group" --candidate round-map-actual > "$out/round-map-actual-$group.log" 2>&1
done
for label in round-map-actual round-codec; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate "$label" > "$out/$label-codec-$profile.log" 2>&1
done
done
for kind in partial encode; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" "$kind" --storage "$profile" --candidate round-codec > "$out/round-codec-$kind-$profile.log" 2>&1
done
done
python3 work/benchmark-followup/map-loop-compare.py --before-shipping "$m/round-loop-before/codec-shipping" --before-allocations "$m/round-loop-before/codec-allocations" --before-record "$m/round-loop-before/source.json" --after-shipping "$m/round-loop-after/codec-shipping" --after-allocations "$m/round-loop-after/codec-allocations" --after-record "$m/round-loop-after/source.json" --storage lazy --output "$out/map-ordinary-loop" > "$out/map-ordinary-loop.log" 2>&1
for profile in debug release; do
baseline="work/all-benchmarks/codegen/final-candidate-$profile/driver"
prost=work/all-benchmarks/codegen/prost-canonical-driver
if [ "$profile" = release ]; then prost=work/all-benchmarks/codegen/final-prost-release/driver; fi
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/codegen_compare_blocking.py" --baseline "$baseline" --candidate "work/benchmark-followup/codegen-after-$profile/driver" --prost "$prost" --profile "$profile" --output "$out/codegen-after-$profile" --capture-limit 12 "${resume[@]}" > "$out/codegen-after-$profile-$part.log" 2>&1
done
done
python3 work/benchmark-followup/budget-compare.py --before "$m/round-budget-before/codec-shipping" --before-record "$m/round-budget-before/source.json" --after "$m/round-budget-after/codec-shipping" --after-record "$m/round-budget-after/source.json" --output "$out/budget-micro" > "$out/budget-micro.log" 2>&1
printf '%s\n' 'All isolated comparisons completed.'
