"""Package this round only, preserving source scopes, controls and raw records.

Run after all selected measurements, final implementation commit and validation.
"""
from pathlib import Path
import argparse,csv,hashlib,io,json,os,shutil,statistics,subprocess,tarfile,tempfile
root=Path(__file__).resolve().parents[2];m=root/'work/all-benchmarks/measurement';w=root/'work/benchmark-followup'
p=argparse.ArgumentParser();p.add_argument('--selected',required=True,help='Frozen selected source label, e.g. round-selected');p.add_argument('--validation',type=Path,required=True);p.add_argument('--output',type=Path,default=root/'docs/evidence/optimizations-20261028');a=p.parse_args();a.validation=a.validation.resolve(strict=True);a.output=a.output.resolve()
sha=lambda x:hashlib.sha256(x).hexdigest()
def read(p):return json.loads(p.read_text())
def require(v,msg):
 if not v:raise ValueError(msg)
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip();validation=read(a.validation);require(validation.get('complete') is True,'Final validation incomplete');require(validation.get('source')==head,'Final validation is not bound to HEAD')
base=read(m/'phase6-source-source.json');selected=read(m/(a.selected+'-source-source.json'));require(selected['baseline_commit']=='6d1336e0f6490249c7339b6a8a6bb74c7d44d432','Wrong benchmark baseline')
# Verify every measured source file against the committed implementation; no unmeasured edits can hide in the final tree.
paths=sorted(selected['files']);require(len(paths)>=600,'Unexpected source file count')
import io as _io
archive_bytes=subprocess.check_output(['git','archive','--format=tar',head,*paths],cwd=root);with_git=tarfile.open(fileobj=_io.BytesIO(archive_bytes));members={x.name:x for x in with_git}
with tempfile.TemporaryDirectory(prefix='pbrs-final-source-') as d:
 with_git.extractall(d,filter='data');tree=Path(d)
 actual={name:sha((tree/name).read_bytes()) for name in paths}
 differences={name:dict(measured=selected['files'][name],committed=actual[name]) for name in paths if actual[name]!=selected['files'][name]}
 for name in differences:require(selected['declared_changes'].get(name,{}).get('scope')=='test-only','Final commit differs from measured shipping/build/documentation input: '+name)
files={}
# Include only selected sources' compact overlays, never the duplicated full snapshots or ELF executables.
labels=['round-map-actual','round-map-narrow','round-map-forced-inline','round-map-first-inline','round-codec','round-codegen','round-budget-actual','round-borrowed','round-borrowed-narrow']
if a.selected not in labels:labels.append(a.selected)
variants={}
for label in labels:
 path=m/(label+'-source-source.json')
 if not path.exists():continue
 d=read(path);variants[label]={'files':d['files'],'declared_changes':d['declared_changes']}
 for name,row in d['declared_changes'].items():
  data=(Path(d['source'])/name).read_bytes();require(sha(data)==row['after'],'Overlay hash mismatch: '+label+'/'+name);files['source/overlays/'+label+'/'+name]=data
source_manifest=dict(schema='pbrs.followup-sources.v1',baseline_commit='6d1336e0f6490249c7339b6a8a6bb74c7d44d432',published_head='acc8aef92d65bd73fe4f082150770395d4475808',baseline_files=base['files'],variants=variants,selected=a.selected,selected_commit=head,measured_source_commit=selected['published_head'],test_only_commit_differences=differences,note='Six repository symlinks are materialized to match the measured 600-file snapshots.')
files['source/manifest.json']=(json.dumps(source_manifest,indent=2)+'\n').encode();files['source/reconstruct.py']=(w/'reconstruct.py').read_bytes()
files['source/reproduce.md']=('''# Reproduce the frozen sources\n\nThe published starting HEAD was acc8aef9. The benchmark baseline is the\nrecorded 600-file source at runtime commit 6d1336e0; its core inputs match\nacc8aef9. The previous capsule records the baseline binaries and host.\n\nAfter checking the archive with check.py, extract it into a disposable\ndirectory. Run `python3 source/reconstruct.py /path/to/repo /tmp/pbrs-source\nVARIANT`, replacing VARIANT with a name in source/manifest.json. It exports\nthe baseline, materializes six in-tree symlinks, applies that variant's\noverlays and verifies every input hash. Use the retained build plans and\n`*-build.json` files for compiler settings, commands and exact harness inputs.\nAbsolute workspace paths in captured commands must be adjusted for the new\ncheckout. Preserve source and locks; rebuild fresh binaries before timing.\n\nThe old evidence capsule documents the reused baseline artifacts. Compiler,\nprotoc and GNU time installations, ELF files, build caches and duplicate\ngenerated output are deliberately excluded. See the parent page for workload\nscope, control limitations and all losses.\n''').encode()
# Explicitly enumerate this round. Historical data is referenced by its prior capsule.
allow_ext={'.json','.jsonl','.log','.stdout','.stderr','.rs','.proto','.toml','.lock','.py','.sh','.md','.asm','.patch','.diff'}
def add_tree(path):
 if not path.exists():return
 if path.is_file():paths=[path]
 else:paths=(f for f in path.rglob('*') if f.is_file())
 for f in paths:
  if f.is_symlink() or f.suffix not in allow_ext or any(x in ('target','.git','__pycache__','representative-generated','outputs') for x in f.parts):continue
  data=f.read_bytes()
  if not data.startswith(b'\x7fELF'):files[str(f.relative_to(root))]=data
for p in w.iterdir():
 if p.name in ('results','budget-template','map-loop-template') or p.is_file():add_tree(p)
for path in sorted(m.glob('round-*')):
 if path.is_dir() and path.name.endswith('-source'):continue
 add_tree(path)
for name in ['codec_compare.py','map_compare.py','partial_compare.py','encode_compare.py','measure_phase2.py','build_probe.py','build_rpc.py','build_rpc_probe.py','prepare_holdouts.py','codegen_compare_blocking.py','canonical_codegen_blocking.py','rpc_compressed_compare.py','rpc_compressed_helper.py','rpc_default_compare.py','phase6-source-source.json','artifact-audit.json','variant-artifact-audit.json']:
 add_tree(m/name)
for name in ['candidate-map','candidate-lazy','candidate-owned','candidate-partial-lazy','candidate-partial-owned','candidate-encode-lazy','candidate-encode-owned','phase6-rpc']:
 folder=m/name
 for f in [folder/'source.json',*folder.glob('*-build.json')]:add_tree(f)
for profile in ['debug','release']:
 for folder in [root/'work/all-benchmarks/codegen'/('final-candidate-'+profile),w/('codegen-after-'+profile),w/('codegen-borrowed-'+profile),w/('codegen-borrowed-narrow-'+profile),w/('codegen-selected-'+profile)]:
  for f in [folder/'source.json',folder/'Cargo.toml',folder/'Cargo.lock',folder/'src/main.rs']:add_tree(f)
add_tree(root/'work/map-first-only');add_tree(root/'work/borrowed-wire-narrow-20261028/eligibility-proof');[add_tree(p) for p in (root/'work/borrowed-wire-legacy-compat-20261028').iterdir() if p.name not in ('source','reconstructed')];add_tree(root/'work/round-evidence-update.md');[add_tree(p) for p in (root/'work/ce0a-validation').glob('*-clean.json')];add_tree(root/'work/ce0a-validation/results');add_tree(a.validation.parent);add_tree(root/'work/borrowed-wire-20261028/proof-overlays');add_tree(root/'work/encode_smoke.py');add_tree(root/'work/codegen_resolution/src/main.rs');add_tree(root/'work/round-evidence-draft.md');add_tree(a.validation)
# Proof and rejection records only; no prototype source trees or compiler caches.
for directory in [root/'work/borrowed-wire-20261028',root/'work/borrowed-wire-narrow-20261028',root/'work/map-next-variant',root/'work/codegen-move-20261028']:
 if directory.is_dir():
  for f in directory.iterdir():
   if f.is_file():add_tree(f)
for pattern in ('review-*.json','map-narrow-*.log','codec-provenance-*.log','transport-closed-upload-*.md','framing-overflow-*.log'):
 for f in (root/'work').glob(pattern):add_tree(f)

# Extract rows without discarding regressions or comparing diagnostics to an unrelated peer.
timing=[];resource=[];summaries={}
def classify(value):return 'invalid' if value is None else 'win' if value<1 else 'tie' if value==1 else 'loss'
def cv(v):return None if v is None else float(v)
def emit(dst,scope,suite,profile,case,op,endpoint,control,metric,before,after,ref,ab,ac,pairs,source):
 r=dict(scope=scope,suite=suite,profile=profile,case=case,operation=op,endpoint=endpoint,control=control,metric=metric,before=before,after=after,control_after=ref,paired_after_before=ab,paired_after_control=ac,pair_min=min(pairs) if pairs else None,pair_max=max(pairs) if pairs else None,comparison=classify(ac),source=source);dst.append(r)
def runname(scope,label,kind,profile=''):
 name=label+'-'+kind+('-'+profile if profile else '')+'-comparison';path=m/name/'summary.json'
 require(path.exists(),'Missing summary '+str(path));rows=read(path);summaries[name]=rows
 for r in rows:
  med=r['cpu_ns_medians'];q=r['ratios'];ratio=q['after_pbrs_over_prost'];base_ratio=q['after_over_before_pbrs'];control='std HashMap' if kind.startswith('map-') else 'Prost 0.14.4'
  emit(timing,scope,kind,profile,r['case'],r['operation'],'',control,'process_cpu_ns_per_operation',med['before']['pbrs'],med['after']['pbrs'],med['after']['prost'],base_ratio['median'],ratio['median'],ratio['pairs'],name)
  for metric in ('requested_bytes','allocation_calls'):
   v=r['allocations'];before=v['before-pbrs'][metric];after=v['after-pbrs'][metric];reference=v['after-prost'][metric];ab=after/before if before else None;ac=after/reference if reference else (1.0 if after==0 else None)
   emit(resource,scope,kind,profile,r['case'],r['operation'],'',control,metric+'_per_operation',before,after,reference,ab,ac,None,name)
   if reference==0:resource[-1]['comparison']='tie' if after==0 else 'loss'
scopes=[('round-map-actual','isolated-map-8333'),('round-codec','isolated-lazy-enum'),('round-map-narrow','isolated-map-54b'),('round-map-forced-inline','isolated-map-forced-inline'),('round-map-first-inline','isolated-map-first-inline')]
if (m/'round-borrowed-codec-lazy-comparison/summary.json').exists():scopes.append(('round-borrowed','isolated-borrowed-wire'))
if (m/'round-borrowed-narrow-codec-lazy-comparison/summary.json').exists():scopes.append(('round-borrowed-narrow','isolated-borrowed-wire-narrow'))
scopes.append((a.selected,'selected'))
for label,scope in scopes:
 if label in ('round-map-actual','round-map-narrow','round-map-forced-inline','round-map-first-inline',a.selected):
  for kind in ('map-small','map-large'):runname(scope,label,kind)
 for profile in ('lazy','owned'):runname(scope,label,'codec',profile)
 if label in ('round-codec','round-borrowed','round-borrowed-narrow',a.selected):
  for kind in ('partial','encode'):
   for profile in ('lazy','owned'):runname(scope,label,kind,profile)
# Additional ordinary-loop / cold-entry rows are source-scoped and stay separate.
for name,scope in [('map-ordinary-loop','isolated-map-8333'),('map-ordinary-loop-narrow','isolated-map-54b'),('map-ordinary-loop-forced','isolated-map-forced-inline'),('map-ordinary-loop-first-inline','isolated-map-first-inline'),('map-ordinary-loop-selected','selected')]:
 path=w/'results'/name/'summary.json'
 if not path.exists():
  require(scope!='selected','Missing selected ordinary map results: '+str(path));continue
 rows=read(path);summaries[name]=rows
 for r in rows:
  med=r['cpu_ns_medians'];q=r['ratios'];z=q['after_pbrs_over_prost'];v=q['after_over_before_pbrs']
  emit(timing,scope,'ordinary-map','',r['case'],r['operation'],'','std HashMap','process_cpu_ns_per_operation',med['before']['pbrs'],med['after']['pbrs'],med['after']['prost'],v['median'],z['median'],z['pairs'],name)
  for metric in ('requested_bytes','allocation_calls'):
   z=r['allocations'];before=z['before-pbrs'][metric];after=z['after-pbrs'][metric];reference=z['after-prost'][metric];ab=after/before if before else None;ac=after/reference if reference else (1.0 if after==0 else None)
   emit(resource,scope,'ordinary-map','',r['case'],r['operation'],'','std HashMap',metric+'_per_operation',before,after,reference,ab,ac,None,name)
   if reference==0:resource[-1]['comparison']='tie' if after==0 else 'loss'
codegen_scopes=[('after','isolated-codegen')]
if (w/'results/codegen-borrowed-debug/summary.json').exists():codegen_scopes.append(('borrowed','isolated-borrowed-wire'))
if (w/'results/codegen-borrowed-narrow-debug/summary.json').exists():codegen_scopes.append(('borrowed-narrow','isolated-borrowed-wire-narrow'))
codegen_scopes.append(('selected','selected'))
for label,scope in codegen_scopes:
 for profile in ('debug','release'):
  name='codegen-'+label+'-'+profile;path=w/'results'/name/'summary.json';require(path.exists(),'Missing '+str(path));rows=read(path);summaries[name]=rows
  for r in rows:
   med=r['elapsed_ns_medians'];q=r['ratios'];z=q['after_pbrs_over_prost'];v=q['after_over_before_pbrs'];emit(timing,scope,'codegen',profile,r['case'],r['operation'],'','Prost 0.14.4','elapsed_ns',med['before']['pbrs'],med['after']['pbrs'],med['after']['prost'],v['median'],z['median'],z['pairs'],name)
   sizes=r['generated_bytes'];before=sizes['baseline'];after=sizes['candidate'];ref=sizes['prost'];emit(resource,scope,'codegen',profile,r['case'],r['operation'],'','Prost 0.14.4','generated_rust_bytes',before,after,ref,after/before,after/ref,None,name)
   captures=read(path.with_name('manifest.json'))['captures'];cases=[c for c in captures if c['case']==r['case']]
   for field,metric in [('peak_rss_bytes','process_tree_sampled_rss_lower_bound_bytes'),('direct_command_peak_rss_bytes','gnu_time_command_child_max_rss_bytes')]:
    vals={(c['repeat'],c['source'],c['backend']):c['phases'][r['operation']].get(field) for c in cases}
    def series(side,backend):return [vals[i,side,backend] for i in range(5)]
    before_values=series('before','pbrs');after_values=series('after','pbrs');control_values=series('after','prost')
    if not all(isinstance(x,(int,float)) and x>0 for x in before_values+after_values+control_values):
     emit(resource,scope,'codegen',profile,r['case'],r['operation'],'','Prost 0.14.4',metric,None,None,None,None,None,None,name);continue
    before=statistics.median(before_values);after=statistics.median(after_values);ref=statistics.median(control_values);pairs=[after_values[i]/control_values[i] for i in range(5)];prior=[after_values[i]/before_values[i] for i in range(5)]
    emit(resource,scope,'codegen',profile,r['case'],r['operation'],'','Prost 0.14.4',metric,before,after,ref,statistics.median(prior),statistics.median(pairs),pairs,name)
for name in ('rpc-shipping','rpc-default','rpc-identity-confirmation','rpc-allocations'):
 path=w/'results'/name/'summary.json';require(path.exists(),'Missing '+str(path));rows=read(path);summaries[name]=rows
 for r in rows:
  med=r.get('medians',r.get('cpu_us_per_rpc_medians'));q=r.get('ratios');ac=q['after_native_over_tonic'] if q else None;ab=q['after_over_before_native'] if q else None;dst=resource if name=='rpc-allocations' else timing
  emit(dst,'selected',name,'',r['cell'],'',r['endpoint'],'Tonic 0.14.6 / same Prost codec',r.get('metric','cpu_us_per_rpc'),med['before']['native'],med['after']['native'],med['after']['tonic'],ab['median'] if ab else None,ac['median'] if ac else None,ac['pairs'] if ac else None,name)
for name in ['budget-micro']:
 path=w/'results'/name/'summary.json';require(path.exists(),'Missing '+str(path));rows=read(path);summaries[name]=rows
 for r in rows:
  for metric in ('cpu','wall'):
   v=r[metric];emit(timing,'diagnostic','byte-permit','',str(r['bytes'])+' bytes',str(r['threads'])+' threads','','previous tracker',metric+'_ns_per_operation',v['before_median_ns'],v['after_median_ns'],None,v['paired_after_before_median'],None,v['paired'],name);timing[-1]['comparison']='diagnostic'
fields=['scope','suite','profile','case','operation','endpoint','control','metric','before','after','control_after','paired_after_before','paired_after_control','pair_min','pair_max','comparison','source']
def csvbytes(rows):
 s=io.StringIO(newline='');writer=csv.DictWriter(s,fieldnames=fields);writer.writeheader();writer.writerows(rows);return s.getvalue().encode()
companions={'timing.csv':csvbytes(timing),'resources.csv':csvbytes(resource)}
selected_timing=[x for x in timing if x['scope']=='selected'];selected_resource=[x for x in resource if x['scope']=='selected'];prior=read(root/'docs/evidence/decode-and-map-speed-20261027/all-win-gate.json');missing=prior['missing_axes'];gate=dict(schema='pbrs.followup.all-win-gate.v1',qualified=False,world_ranking_established=False,selected_source_commit=head,timing_rows=len(selected_timing),timing_nonwins=sum(x['comparison']!='win' for x in selected_timing),resource_rows=len(selected_resource),resource_nonwins=sum(x['comparison']!='win' for x in selected_resource),missing_axes=missing,all_benchmarks_won=all(x['comparison']=='win' for x in selected_timing+selected_resource) and not missing,remaining_timing=[x for x in selected_timing if x['comparison']!='win'],remaining_resources=[x for x in selected_resource if x['comparison']!='win'])
companions['all-win-gate.json']=(json.dumps(gate,indent=2)+'\n').encode()
result=dict(schema='pbrs.followup.results.v1',baseline_published_head='acc8aef92d65bd73fe4f082150770395d4475808',baseline_runtime='6d1336e0f6490249c7339b6a8a6bb74c7d44d432',selected_commit=head,selected_source=a.selected,measured_source_commit=selected['published_head'],test_only_commit_differences=differences,full_tonic_prost_parity=False,world_ranking_established=False,all_benchmarks_won=gate['all_benchmarks_won'],gate=gate,validation=validation,source_manifest=source_manifest,summaries=summaries)
a.output.mkdir(parents=True,exist_ok=True)
for name,data in companions.items():(a.output/name).write_bytes(data)
with tarfile.open(a.output/'raw.tar.gz','w:gz',compresslevel=6) as tar:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
# Reconstruct all variants using only source members recovered from the finished archive.
with tempfile.TemporaryDirectory(prefix='pbrs-round-check-') as t:
 d=Path(t)
 with tarfile.open(a.output/'raw.tar.gz') as tar:
  for member in tar:
   if member.name.startswith('source/'):
    require(member.isfile() and '..' not in Path(member.name).parts,'Unsafe source member');tar.extract(member,d,filter='data')
 proof=[]
 for label in variants:
  out=d/('tree-'+label);r=subprocess.run(['python3',str(d/'source/reconstruct.py'),str(root),str(out),label],capture_output=True,text=True);require(r.returncode==0,'Archived reconstruction failed '+label+': '+r.stderr);proof.append(json.loads(r.stdout));shutil.rmtree(out)
 result['archive_reconstruction']=dict(complete=True,variants=proof)
(a.output/'results.json').write_text(json.dumps(result,indent=2)+'\n')
manifest=dict(schema='pbrs.evidence-manifest.v1',archive_sha256=sha((a.output/'raw.tar.gz').read_bytes()),results_sha256=sha((a.output/'results.json').read_bytes()),companion_files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in companions.items()},files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())})
(a.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');shutil.copyfile(root/'docs/evidence/decode-and-map-speed-20261027/check.py',a.output/'check.py')
print(json.dumps(dict(files=len(files),archive_bytes=(a.output/'raw.tar.gz').stat().st_size,timing_rows=len(timing),selected_timing=len(selected_timing),selected_timing_nonwins=gate['timing_nonwins'],resource_rows=len(resource),selected_resource=len(selected_resource),selected_resource_nonwins=gate['resource_nonwins'],all_benchmarks_won=gate['all_benchmarks_won'])))
