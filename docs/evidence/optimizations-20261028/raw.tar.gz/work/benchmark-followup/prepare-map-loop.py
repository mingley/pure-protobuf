"""Prepare equal ordinary-loop holdouts against baseline and a frozen candidate."""
from pathlib import Path
import argparse,shutil,hashlib,json
p=argparse.ArgumentParser();p.add_argument('--label',default='round-loop');p.add_argument('--candidate-source',default='round-map-actual-source');a=p.parse_args()
root=Path(__file__).resolve().parents[2];b=root/'work/all-benchmarks/measurement';template=root/'work/benchmark-followup/map-loop-template'
assert a.label in ('round-loop','round-loop-integrated');assert a.candidate_source in ('round-map-actual-source','round-integrated-source')
for side,source in [('before','phase6-source'),('after',a.candidate_source)]:
 out=b/(a.label+'-'+side+'-harness');assert not out.exists();shutil.copytree(template,out);shutil.copyfile(b/'map-candidate-harness/Cargo.lock',out/'Cargo.lock');p=out/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(b/source)))
assert (b/(a.label+'-before-harness/src/main.rs')).read_bytes()==(b/(a.label+'-after-harness/src/main.rs')).read_bytes()
assert (b/(a.label+'-before-harness/Cargo.lock')).read_bytes()==(b/(a.label+'-after-harness/Cargo.lock')).read_bytes()
print(json.dumps(dict(prepared=True,label=a.label,template_sha256=hashlib.sha256((template/'src/main.rs').read_bytes()).hexdigest(),baseline='phase6-source',candidate=a.candidate_source)))
