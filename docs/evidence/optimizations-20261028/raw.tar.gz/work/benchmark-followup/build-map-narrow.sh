#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; x=shutil.disk_usage("/workspace").free;print("free_bytes",x,flush=True);assert x>=750*1024*1024,"pause: insufficient free space"'; }
python3 - <<'PY'
from pathlib import Path
import shutil
b=Path('work/all-benchmarks/measurement').resolve();w=Path('work/benchmark-followup').resolve()
for name,src in [('round-map-narrow-harness',b/'map-template'),('round-loop-narrow-harness',w/'map-loop-template')]:
 out=b/name;assert not out.exists();shutil.copytree(src,out);shutil.copyfile(b/'map-candidate-harness/Cargo.lock',out/'Cargo.lock');p=out/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(b/'round-map-narrow-source')))
assert (b/'round-map-narrow-harness/src/main.rs').read_bytes()==(b/'map-candidate-harness/src/main.rs').read_bytes()
assert (b/'round-loop-narrow-harness/src/main.rs').read_bytes()==(b/'round-loop-before-harness/src/main.rs').read_bytes()
PY
for kind in map loop; do
for mode in shipping allocations; do
free_check
output="work/all-benchmarks/measurement/round-$kind-narrow"
if [ "$kind" = map ]; then output="work/all-benchmarks/measurement/round-map-narrow-map"; fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-map-narrow-source --manifest "work/all-benchmarks/measurement/round-$kind-narrow-harness/Cargo.toml" --binary-name pbrs-map-iteration-proof --mode "$mode" --output "$output" --record-key "codec-$mode"
done
done
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-map-narrow-source --manifest work/all-benchmarks/measurement/round-map-narrow-source/tests/proof/codec_benchmark/Cargo.toml --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/round-map-narrow-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
printf '%s\n' 'Narrow map benchmark binaries built; no timed work performed.'
python3 work/benchmark-followup/preflight-narrow.py
