"""Freeze an isolated candidate over the exact published transport baseline."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess
root=Path(__file__).resolve().parents[2];base=root/'work/all-benchmarks/measurement/phase6-source';outroot=root/'work/all-benchmarks/measurement'
p=argparse.ArgumentParser();p.add_argument('--overlay-root',type=Path,default=root);p.add_argument('--allow-new',action='store_true');p.add_argument('label');p.add_argument('files',nargs='+');a=p.parse_args()
overlay_root=a.overlay_root.resolve(strict=True)
assert a.label in ('round-map','round-map-final','round-map-actual','round-map-narrow','round-map-first-inline','round-budget','round-budget-actual','round-integrated','round-selected','round-borrowed','round-borrowed-narrow','round-codec','round-transport','round-codegen')
paths=[Path(x) for x in a.files]
assert all(not x.is_absolute() and '..' not in x.parts for x in paths)
assert len(set(paths))==len(paths)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((outroot/'phase6-source-source.json').read_text());assert len(manifest['files'])==600
source=outroot/(a.label+'-source');assert not source.exists();before={str(x):sha(overlay_root/x) for x in paths}
shutil.copytree(base,source)
for path in paths:
 assert (overlay_root/path).is_file() and ((base/path).is_file() or a.allow_new)
 (source/path).parent.mkdir(parents=True,exist_ok=True)
 shutil.copyfile(overlay_root/path,source/path)
assert before=={str(x):sha(overlay_root/x) for x in paths}
files={str(f.relative_to(source)):sha(f) for f in source.rglob('*') if f.is_file()}
new={str(x) for x in paths if str(x) not in manifest['files']}
assert set(files)==set(manifest['files'])|new
changed={k for k in files if files[k]!=manifest['files'].get(k)};assert changed==set(map(str,paths)),changed
record=dict(schema='pbrs.followup.source.v1',baseline_commit='6d1336e0f6490249c7339b6a8a6bb74c7d44d432',published_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),baseline_manifest_sha256=sha(outroot/'phase6-source-source.json'),overlay_root=str(overlay_root),source=str(source),files=files,declared_changes={x:dict(before=manifest['files'].get(x),after=files[x],scope=('standalone-proof-only' if x.startswith('tests/proof/validated_lazy/') else 'test-only' if x.startswith(('tests/','pbrs-grpc/tests/')) else 'shipping-source')) for x in sorted(changed)},snapshot_note='Standalone proof files can be absent from the phase6 export even when tracked in Git.')
(outroot/(source.name+'-source.json')).write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(dict(source=str(source),changes=record['declared_changes'],file_count=len(files))))
