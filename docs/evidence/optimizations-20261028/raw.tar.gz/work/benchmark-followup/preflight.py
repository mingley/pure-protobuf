"""Exercise all new holdout semantics without any timed iterations."""
from pathlib import Path
import hashlib,itertools,json,subprocess
root=Path(__file__).resolve().parents[2];base=root/'work/all-benchmarks/measurement';out=root/'work/benchmark-followup/preflight.json';assert not out.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];fingerprints={}
for side,mode,n,dist,op,backend in itertools.product(('before','after'),('shipping','allocations'),(4,16,64,256),('distinct','duplicate','firstsurvives'),('iter_all','iter_first','cold_read'),('pbrs','prost')):
 folder=base/('round-loop-'+side);binary=folder/('codec-'+mode);record=json.loads((folder/'source.json').read_text());assert record['binaries']['codec-'+mode]['sha256']==sha(binary)
 case=f'map_{n}_{dist}';cmd=[str(binary),case,backend,op,'0','1'];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(cmd,r.stderr);v=json.loads(r.stdout);assert v['semantic_prechecks'] and v['case']==case and v['backend']==backend and v['operation']==op and v['raw_entries']==n
 key=(case,);signature=(v['wire_bytes'],v['wire_fnv1a64'],v['checksum'],v['unique_entries']);assert fingerprints.setdefault(key,signature)==signature
 rows.append(dict(side=side,mode=mode,case=case,operation=op,backend=backend,passed=True))
for side,threads,size in itertools.product(('before','after'),(1,2,4),(0,64)):
 folder=base/('round-budget-'+side);binary=folder/'codec-shipping';record=json.loads((folder/'source.json').read_text());assert record['binaries']['codec-shipping']['sha256']==sha(binary)
 cmd=[str(binary),str(threads),str(size),'0','1'];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(cmd,r.stderr);v=json.loads(r.stdout);assert v==dict(preflight=True,threads=threads,bytes=size)
 rows.append(dict(side=side,threads=threads,bytes=size,operations_per_thread=1,timed_iterations=0,passed=True))
report=dict(schema='pbrs.followup-holdout-preflight.v1',complete=True,timed_iterations=0,captures=len(rows),fingerprints={k[0]:v for k,v in fingerprints.items()},cases=rows)
out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,captures=len(rows),timed_iterations=0)))
