"""Audit copied probe artifacts and reject shared-target stale executable collisions."""
import glob,hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[2];b=root/'work/all-benchmarks/measurement';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
groups=['round-map-actual-map','round-map-actual-lazy','round-map-actual-owned','round-codec-lazy','round-codec-owned','round-codec-partial-lazy','round-codec-partial-owned','round-codec-encode-lazy','round-codec-encode-owned','round-loop-before','round-loop-after','round-map-narrow-map','round-map-narrow-lazy','round-map-narrow-owned','round-loop-narrow-fresh','round-map-forced-inline-map','round-map-forced-inline-lazy','round-map-forced-inline-owned','round-loop-forced-inline','round-map-first-inline-map','round-map-first-inline-lazy','round-map-first-inline-owned','round-loop-first-inline','round-borrowed-lazy','round-borrowed-owned','round-borrowed-partial-lazy','round-borrowed-partial-owned','round-borrowed-encode-lazy','round-borrowed-encode-owned','round-borrowed-narrow-lazy','round-borrowed-narrow-owned','round-borrowed-narrow-partial-lazy','round-borrowed-narrow-partial-owned','round-borrowed-narrow-encode-lazy','round-borrowed-narrow-encode-owned']
rows=[]
for group in groups:
 folder=b/group;aggregate=json.loads((folder/'source.json').read_text())
 for mode in ('shipping','allocations'):
  key='codec-'+mode;info=aggregate['binaries'][key];record=json.loads((folder/info['build_record']).read_text());binary=folder/key;assert sha(binary)==info['sha256']==record['binary_sha256'];assert record['source_unchanged'] and record['harness_unchanged'] and record['exit_code']==0
  artifact_path=folder/(key+'.jsonl');matches=[]
  for line in artifact_path.read_text().splitlines():
   value=json.loads(line)
   if value.get('reason')=='compiler-artifact' and value.get('executable')==record['build_executable']:matches.append(value)
  assert len(matches)==1 and matches[0]['fresh'] is False,(group,mode,'not freshly compiled');assert matches[0]['profile']['opt_level']=='3';assert ('allocations' in record['features'])==(mode=='allocations')
  rows.append(dict(group=group,mode=mode,binary_sha256=sha(binary),source=record['source'],harness_main_sha256=record['harness_files'].get('src/main.rs'),fresh=False,features=record['features']))
for side in ('before','after'):
 folder=b/('round-budget-'+side);key='codec-shipping';agg=json.loads((folder/'source.json').read_text());d=json.loads((folder/agg['binaries'][key]['build_record']).read_text());binary=folder/key;assert d['binary_sha256']==agg['binaries'][key]['sha256']==sha(binary)
 a=[json.loads(x) for x in (folder/(key+'.jsonl')).read_text().splitlines()];a=[x for x in a if x.get('reason')=='compiler-artifact' and x.get('executable')==d['build_executable']];assert len(a)==1 and a[0]['fresh'] is False and a[0]['profile']['opt_level']=='3'
 rows.append(dict(group=folder.name,mode='shipping',binary_sha256=sha(binary),source=d['source'],harness_main_sha256=d['harness_files'].get('src/main.rs'),fresh=False,features=d['features']))
for candidate in ('after','borrowed','borrowed-narrow'):
 for profile in ('debug','release'):
  before=json.loads((root/'work/all-benchmarks/codegen'/('final-candidate-'+profile)/'source.json').read_text());after=json.loads((root/'work/benchmark-followup'/('codegen-'+candidate+'-'+profile)/'source.json').read_text());assert before['lock_sha256']==after['lock_sha256'] and before['driver_source_sha256']==after['driver_source_sha256'];assert before['cargo_artifact']['fresh'] is False and after['cargo_artifact']['fresh'] is False
  for side,d in [('before',before),(candidate,after)]:assert sha(Path(d['executable']))==d['executable_sha256'];rows.append(dict(group='codegen-'+profile+'-'+side,mode=profile,binary_sha256=d['executable_sha256'],source=d['source_path'],harness_main_sha256=d['driver_source_sha256'],fresh=False,features=d['cargo_artifact']['features']))
for group in ['candidate-map','candidate-lazy','candidate-owned','candidate-partial-lazy','candidate-partial-owned','candidate-encode-lazy','candidate-encode-owned']:
 folder=b/group;agg=json.loads((folder/'source.json').read_text())
 for mode in ('shipping','allocations'):
  key='codec-'+mode;assert sha(folder/key)==agg['binaries'][key]['sha256']
prior=json.loads((b/'artifact-audit.json').read_text());assert prior['complete']
byhash={}
for row in rows:byhash.setdefault(row['binary_sha256'],[]).append(row)
for digest,items in byhash.items():
 if len({x['harness_main_sha256'] for x in items})>1:raise ValueError('Different harnesses produced same executable '+digest)
stale=b/'round-loop-narrow';stale_agg=json.loads((stale/'source.json').read_text());warm=json.loads((b/'round-map-narrow-map/source.json').read_text());assert stale_agg['binaries']['codec-shipping']['sha256']==warm['binaries']['codec-shipping']['sha256']
report=dict(schema='pbrs.followup-binary-audit.v1',complete=True,accepted_fresh_artifacts=len(rows),prior_baseline_audit='work/all-benchmarks/measurement/artifact-audit.json',prior_baseline_sha256=sha(b/'artifact-audit.json'),rejected_stale='work/benchmark-followup/narrow-loop-stale-disposition.json',artifacts=rows)
(root/'work/benchmark-followup/binary-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,accepted_fresh=len(rows),rejected_stale=True)))
