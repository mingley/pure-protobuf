"""Randomized paired diagnostic for unlimited byte-permit acquire/drop."""
import argparse,hashlib,itertools,json,os,platform,random,statistics,subprocess
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--before',type=Path,required=True);p.add_argument('--after',type=Path,required=True);p.add_argument('--before-record',type=Path,required=True);p.add_argument('--after-record',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
binaries={k:getattr(a,k).resolve(strict=True) for k in ('before','after')};hashes={k:sha(v) for k,v in binaries.items()}
records={k:json.loads(getattr(a,k+'_record').read_text()) for k in binaries}
for key in binaries:
 assert records[key]['binaries']['codec-shipping']['sha256']==hashes[key],f'{key} binary differs from build record'
out=a.output.resolve();out.mkdir(exist_ok=False,parents=True)
# Fixed work is large enough to amortize setup; all sources use identical work.
iterations={1:1_000_000,2:300_000,4:200_000};cases=list(itertools.product((1,2,4),(0,64)))
rng=random.Random(271231);plan=[]
for repeat in range(5):
 cells=list(cases);rng.shuffle(cells)
 for threads,size in cells:
  order=['before','after'];rng.shuffle(order)
  for source in order:plan.append(dict(repeat=repeat,threads=threads,bytes=size,source=source))
meta=dict(schema='pbrs.byte-budget-microcomparison.v1',qualified=False,state='running',seed=271231,pairs=5,samples=3,iterations=iterations,binary_sha256=hashes,binaries={k:str(v) for k,v in binaries.items()},build_records=records,affinity=sorted(os.sched_getaffinity(0)),host=platform.uname()._asdict(),limits=['Same tracker semantics, fresh process and prewarmed peak counters; no tonic-equivalent control.','Process CPU and wall throughput are separate metrics; thread startup is outside the measured interval except barrier release and join.','One shared VM and unpinned multi-thread processes; contention, scheduling and topology affect results.','Zero-byte permit isolates token tracking but still retains the shared Arc; 64-byte permits exercise both counters.','Arithmetic-overflow rejection is established by correctness tests; these timed valid paths do not exercise overflow.'])
for name in ('cpu.max','cpu.stat'):
 try:meta['cgroup_before_'+name]=Path('/sys/fs/cgroup',name).read_text()
 except OSError:pass
(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n');rows=[]
try:
 with (out/'raw.jsonl').open('w') as raw:
  for index,entry in enumerate(plan):
   cmd=[str(binaries[entry['source']]),str(entry['threads']),str(entry['bytes']),str(iterations[entry['threads']]),'3']
   r=subprocess.run(cmd,capture_output=True,text=True);(out/f'{index:03}.stderr').write_text(r.stderr);(out/f'{index:03}.stdout').write_text(r.stdout)
   if r.returncode:raise ValueError(f'capture {index} failed: {r.returncode}')
   v=json.loads(r.stdout);assert v['semantic_prechecks'] and v['threads']==entry['threads'] and v['bytes']==entry['bytes'] and v['iterations_per_thread']==iterations[entry['threads']] and len(v['samples'])==3
   assert all(x['cpu_ns']>0 and x['wall_ns']>0 for x in v['samples'])
   row=dict(entry,command=cmd,result=v);rows.append(row);raw.write(json.dumps(row)+'\n');raw.flush()
   if (index+1)%10==0:print(f'{index+1}/{len(plan)} budget processes passed',flush=True)
 summary=[]
 for threads,size in cases:
  section=[r for r in rows if (r['threads'],r['bytes'])==(threads,size)];work=iterations[threads]*threads
  values={(r['repeat'],r['source']):{metric:statistics.mean(s[metric+'_ns']/work for s in r['result']['samples']) for metric in ('cpu','wall')} for r in section}
  item=dict(threads=threads,bytes=size,iterations_per_thread=iterations[threads],pairs=5)
  for metric in ('cpu','wall'):
   before=[values[i,'before'][metric] for i in range(5)];after=[values[i,'after'][metric] for i in range(5)];ratios=[after[i]/before[i] for i in range(5)]
   item[metric]=dict(before_median_ns=statistics.median(before),after_median_ns=statistics.median(after),paired_after_before_median=statistics.median(ratios),paired_range=[min(ratios),max(ratios)],paired=ratios)
  summary.append(item)
 assert all(sha(path)==hashes[key] for key,path in binaries.items())
 for name in ('cpu.max','cpu.stat'):
  try:meta['cgroup_after_'+name]=Path('/sys/fs/cgroup',name).read_text()
  except OSError:pass
 meta.update(state='complete',captures=len(rows));(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
except Exception as e:
 meta.update(state='failed',captures=len(rows),error=str(e));raise
finally:(out/'manifest.json').write_text(json.dumps(meta,indent=2)+'\n')
print(json.dumps(dict(state='complete',captures=len(rows))))
