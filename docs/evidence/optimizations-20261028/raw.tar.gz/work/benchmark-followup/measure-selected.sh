#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
mkdir -p "$out"
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
python3 - <<'PY'
import hashlib,json
from pathlib import Path
r=Path.cwd();d=json.loads((r/'work/all-benchmarks/measurement/round-selected-source-source.json').read_text());source=Path(d['source']);assert all(hashlib.sha256((source/name).read_bytes()).hexdigest()==v for name,v in d['files'].items());print(json.dumps({'selected_source_verified':True,'files':len(d['files'])}),flush=True)
PY
python3 work/benchmark-followup/preflight-selected.py > "$out/preflight-selected.log" 2>&1
python3 work/benchmark-followup/preflight-selected-loop.py > "$out/preflight-selected-loop.log" 2>&1
for label in round-selected; do
for group in map-small map-large; do
python3 "$m/measure_phase2.py" "$group" --candidate "$label" > "$out/$label-$group.log" 2>&1
done
done
for label in round-selected; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate "$label" > "$out/$label-codec-$profile.log" 2>&1
done
done
for label in round-selected; do
for kind in partial encode; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" "$kind" --storage "$profile" --candidate "$label" > "$out/$label-$kind-$profile.log" 2>&1
done
done
done
python3 work/benchmark-followup/map-loop-compare.py --before-shipping "$m/round-loop-before/codec-shipping" --before-allocations "$m/round-loop-before/codec-allocations" --before-record "$m/round-loop-before/source.json" --after-shipping "$m/round-loop-selected/codec-shipping" --after-allocations "$m/round-loop-selected/codec-allocations" --after-record "$m/round-loop-selected/source.json" --storage lazy --output "$out/map-ordinary-loop-selected" > "$out/map-ordinary-loop-selected.log" 2>&1
for candidate in selected; do
for profile in debug release; do
baseline="work/all-benchmarks/codegen/final-candidate-$profile/driver"
prost=work/all-benchmarks/codegen/prost-canonical-driver
if [ "$profile" = release ]; then prost=work/all-benchmarks/codegen/final-prost-release/driver; fi
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/codegen_compare_blocking.py" --baseline "$baseline" --candidate "work/benchmark-followup/codegen-$candidate-$profile/driver" --prost "$prost" --profile "$profile" --output "$out/codegen-$candidate-$profile" --capture-limit 12 "${resume[@]}" > "$out/codegen-$candidate-$profile-$part.log" 2>&1
done
done
done
for mode in allocations shipping; do
parts=12
if [ "$mode" = shipping ]; then parts=30; fi
for part in $(seq 1 "$parts"); do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/rpc_compressed_compare.py" --before-binary "$m/phase6-rpc/rpc-$mode" --before-record "$m/phase6-rpc/source.json" --before-checkout "$m/phase6-source" --after-binary "$m/round-selected-rpc/rpc-$mode" --after-record "$m/round-selected-rpc/source.json" --after-checkout "$m/round-selected-source" --mode "$mode" --plan "$m/round-selected-rpc-plan.json" --output "$out/rpc-$mode" --capture-limit 12 "${resume[@]}" > "$out/rpc-$mode-$part.log" 2>&1
done
done
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/rpc_default_compare.py" --before-binary "$m/phase6-rpc/rpc-shipping" --before-record "$m/phase6-rpc/source.json" --before-checkout "$m/phase6-source" --after-binary "$m/round-selected-rpc/rpc-shipping" --after-record "$m/round-selected-rpc/source.json" --after-checkout "$m/round-selected-source" --plan "$m/round-selected-rpc-default-plan.json" --output "$out/rpc-default" --capture-limit 24 "${resume[@]}" > "$out/rpc-default-$part.log" 2>&1
done
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/rpc_compressed_compare.py" --before-binary "$m/phase6-rpc/rpc-shipping" --before-record "$m/phase6-rpc/source.json" --before-checkout "$m/phase6-source" --after-binary "$m/round-selected-rpc/rpc-shipping" --after-record "$m/round-selected-rpc/source.json" --after-checkout "$m/round-selected-source" --mode shipping --plan "$m/round-selected-rpc-identity-plan.json" --output "$out/rpc-identity-confirmation" --capture-limit 12 "${resume[@]}" > "$out/rpc-identity-$part.log" 2>&1
done
printf '%s\n' 'All planned benchmark comparisons completed.'
