"""Audit selected compiled executable provenance before the quiet campaign."""
from pathlib import Path
import hashlib,json
r=Path.cwd();b=r/'work/all-benchmarks/measurement';d=json.loads((b/'round-selected-source-source.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
for group in ['round-selected-map','round-selected-lazy','round-selected-owned','round-selected-partial-lazy','round-selected-partial-owned','round-selected-encode-lazy','round-selected-encode-owned','round-loop-selected','round-selected-rpc']:
 folder=b/group;agg=json.loads((folder/'source.json').read_text());prefix='rpc' if group.endswith('-rpc') else 'codec'
 for mode in ('shipping','allocations'):
  key=prefix+'-'+mode;v=agg['binaries'][key];record=json.loads((folder/v['build_record']).read_text());binary=folder/key;assert sha(binary)==v['sha256']==record['binary_sha256'];assert record['source_unchanged'] and record['harness_unchanged'] and record['exit_code']==0
  assert all(record['source_files'].get(n)==h for n,h in d['files'].items()),(group,mode,'source mismatch')
  messages=[json.loads(l) for l in (folder/(key+'.jsonl')).read_text().splitlines()];a=[x for x in messages if x.get('reason')=='compiler-artifact' and x.get('executable')==record['build_executable']];assert len(a)==1 and a[0]['fresh'] is False and a[0]['profile']['opt_level']=='3',(group,mode,'stale');features=record['features'];assert (('allocation-counts' if prefix=='rpc' else 'allocations') in features)==(mode=='allocations');rows.append({'group':group,'mode':mode,'sha256':sha(binary),'fresh':False,'features':features,'harness_main':record['harness_files'].get('src/main.rs')})
byhash={}
for row in rows:byhash.setdefault(row['sha256'],set()).add(row['harness_main'])
assert all(len(v)==1 for v in byhash.values()),'Identical executable from different harnesses'
for profile in ('debug','release'):
 p=r/'work/benchmark-followup'/('codegen-selected-'+profile);a=json.loads((p/'source.json').read_text());before=json.loads((r/'work/all-benchmarks/codegen'/('final-candidate-'+profile)/'source.json').read_text());assert a['lock_sha256']==before['lock_sha256'] and a['driver_source_sha256']==before['driver_source_sha256'];assert a['cargo_artifact']['fresh'] is False and sha(p/'driver')==a['executable_sha256'];assert all(a['source_sha256'].get(n)==h for n,h in d['files'].items());rows.append({'group':'codegen-selected-'+profile,'sha256':a['executable_sha256'],'fresh':False})
report={'schema':'pbrs.selected-binary-audit.v1','complete':True,'source_commit':d['published_head'],'source_files':len(d['files']),'artifacts':rows};(r/'work/benchmark-followup/selected-binary-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'complete':True,'artifacts':len(rows)}))
