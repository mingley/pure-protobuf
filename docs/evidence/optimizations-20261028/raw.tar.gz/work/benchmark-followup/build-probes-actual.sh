#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; free=shutil.disk_usage("/workspace").free; print("free_bytes",free,flush=True); assert free>=750*1024*1024, "pause: less than 750 MiB free"'; }
python3 - <<'PY'
from pathlib import Path
import shutil,json,hashlib
b=Path('work/all-benchmarks/measurement').resolve();h=b/'round-map-actual-harness';assert not h.exists();shutil.copytree(b/'map-template',h);shutil.copyfile(b/'map-candidate-harness/Cargo.lock',h/'Cargo.lock');p=h/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(b/'round-map-actual-source')));assert (h/'src/main.rs').read_bytes()==(b/'map-candidate-harness/src/main.rs').read_bytes();print(json.dumps(dict(harness=str(h),main_sha256=hashlib.sha256((h/'src/main.rs').read_bytes()).hexdigest())))
PY
for mode in shipping allocations; do
free_check
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-map-actual-source --manifest work/all-benchmarks/measurement/round-map-actual-harness/Cargo.toml --binary-name pbrs-map-iteration-proof --mode "$mode" --output work/all-benchmarks/measurement/round-map-actual-map --record-key "codec-$mode"
done
for label in round-map-actual round-codec; do
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$label-source" --manifest "work/all-benchmarks/measurement/$label-source/tests/proof/codec_benchmark/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/$label-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
done
free_check
python3 work/all-benchmarks/measurement/prepare_holdouts.py work/all-benchmarks/measurement/round-codec-source round-codec
for kind in partial encode; do
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
binary=pbrs-encode-proof
if [ "$kind" = partial ]; then binary=pbrs-partial-getter-proof; fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-codec-source --manifest "work/all-benchmarks/measurement/round-codec-$kind-harness/Cargo.toml" --binary-name "$binary" --mode "$mode" --output "work/all-benchmarks/measurement/round-codec-$kind-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
done
printf '%s\n' 'All selected map/codec shipping and allocation binaries are frozen. No timing was performed.'
