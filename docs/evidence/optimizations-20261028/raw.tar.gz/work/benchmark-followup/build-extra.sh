#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; free=shutil.disk_usage("/workspace").free; print("free_bytes",free,flush=True); assert free>=750*1024*1024, "pause: less than 750 MiB free"'; }
for profile in debug release; do
free_check
python3 work/all-benchmarks/codegen/build_final_driver.py --source work/all-benchmarks/measurement/round-codegen-source --peer pbrs --profile "$profile" --output "work/benchmark-followup/codegen-after-$profile"
python3 - "$profile" <<'PY'
import sys,hashlib
from pathlib import Path
p=sys.argv[1];root=Path.cwd();before=root/'work/all-benchmarks/codegen'/('final-candidate-'+p)/'Cargo.lock';after=root/'work/benchmark-followup'/('codegen-after-'+p)/'Cargo.lock'
assert before.read_bytes()==after.read_bytes(),f'{p} codegen peer lockfile mismatch'
print('matched_codegen_lock',p,hashlib.sha256(after.read_bytes()).hexdigest())
PY
done
free_check
python3 work/all-benchmarks/measurement/build_rpc.py work/all-benchmarks/measurement/round-budget-actual-source round-budget
for side in before after; do
free_check
if [ "$side" = before ]; then source=phase6-source; else source=round-budget-actual-source; fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$source" --manifest "work/all-benchmarks/measurement/round-budget-$side-harness/Cargo.toml" --binary-name pbrs-budget-proof --mode shipping --output "work/all-benchmarks/measurement/round-budget-$side" --record-key codec-shipping
done
printf '%s\n' 'Codegen, RPC and budget probe binaries are frozen. No timing was performed.'
