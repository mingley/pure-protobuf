#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; free=shutil.disk_usage("/workspace").free; print("free_bytes",free,flush=True); assert free>=750*1024*1024, "pause: less than 750 MiB free"'; }
python3 - <<'PY'
from pathlib import Path
import shutil,json,hashlib
b=Path('work/all-benchmarks/measurement').resolve();h=b/'round-integrated-harness';assert not h.exists();shutil.copytree(b/'map-template',h);shutil.copyfile(b/'map-candidate-harness/Cargo.lock',h/'Cargo.lock');p=h/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(b/'round-integrated-source')));assert (h/'src/main.rs').read_bytes()==(b/'map-candidate-harness/src/main.rs').read_bytes();print(json.dumps(dict(harness=str(h),main_sha256=hashlib.sha256((h/'src/main.rs').read_bytes()).hexdigest())))
PY
for mode in shipping allocations; do
free_check
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-integrated-source --manifest work/all-benchmarks/measurement/round-integrated-harness/Cargo.toml --binary-name pbrs-map-iteration-proof --mode "$mode" --output work/all-benchmarks/measurement/round-integrated-map --record-key "codec-$mode"
done
for label in round-integrated; do
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$label-source" --manifest "work/all-benchmarks/measurement/$label-source/tests/proof/codec_benchmark/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/$label-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
done
free_check
python3 work/all-benchmarks/measurement/prepare_holdouts.py work/all-benchmarks/measurement/round-integrated-source round-integrated
for kind in partial encode; do
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
binary=pbrs-encode-proof
if [ "$kind" = partial ]; then binary=pbrs-partial-getter-proof; fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-integrated-source --manifest "work/all-benchmarks/measurement/round-integrated-$kind-harness/Cargo.toml" --binary-name "$binary" --mode "$mode" --output "work/all-benchmarks/measurement/round-integrated-$kind-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
done
free_check
python3 work/all-benchmarks/measurement/build_rpc.py work/all-benchmarks/measurement/round-integrated-source round-integrated
for profile in debug release; do
free_check
python3 work/all-benchmarks/codegen/build_final_driver.py --source work/all-benchmarks/measurement/round-integrated-source --peer pbrs --profile "$profile" --output "work/benchmark-followup/codegen-integrated-$profile"
python3 - "$profile" <<'INNER'
import sys,hashlib
from pathlib import Path
p=sys.argv[1];root=Path.cwd();before=root/'work/all-benchmarks/codegen'/('final-candidate-'+p)/'Cargo.lock';after=root/'work/benchmark-followup'/('codegen-integrated-'+p)/'Cargo.lock'
assert before.read_bytes()==after.read_bytes(),f'{p} integrated codegen lock mismatch'
print('matched_integrated_codegen_lock',p,hashlib.sha256(after.read_bytes()).hexdigest())
INNER
done
free_check
python3 work/benchmark-followup/prepare-map-loop.py
for side in before after; do
for mode in shipping allocations; do
free_check
if [ "$side" = before ]; then source=phase6-source; else source=round-integrated-source; fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$source" --manifest "work/all-benchmarks/measurement/round-loop-$side-harness/Cargo.toml" --binary-name pbrs-map-iteration-proof --mode "$mode" --output "work/all-benchmarks/measurement/round-loop-$side" --record-key "codec-$mode"
done
done
printf '%s\n' 'Integrated map/codec/holdout/RPC/generator binaries are frozen. No timing was performed.' 
