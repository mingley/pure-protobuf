#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
python3 - <<'PY'
import hashlib,json
from pathlib import Path
r=Path.cwd();m=r/'work/all-benchmarks/measurement/round-map-narrow-source-source.json';d=json.loads(m.read_text());f=r/'work/all-benchmarks/measurement/round-map-narrow-source/src/map.rs';assert hashlib.sha256(f.read_bytes()).hexdigest()==d['declared_changes']['src/map.rs']['after'];print(json.dumps({'narrow_frozen_source_matches':True,'workspace_map_sha256':hashlib.sha256((r/'src/map.rs').read_bytes()).hexdigest()}),flush=True)
PY
for group in map-small map-large; do
python3 "$m/measure_phase2.py" "$group" --candidate round-map-narrow > "$out/round-map-narrow-$group.log" 2>&1
done
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate round-map-narrow > "$out/round-map-narrow-codec-$profile.log" 2>&1
done
python3 work/benchmark-followup/map-loop-compare.py --before-shipping "$m/round-loop-before/codec-shipping" --before-allocations "$m/round-loop-before/codec-allocations" --before-record "$m/round-loop-before/source.json" --after-shipping "$m/round-loop-narrow-fresh/codec-shipping" --after-allocations "$m/round-loop-narrow-fresh/codec-allocations" --after-record "$m/round-loop-narrow-fresh/source.json" --storage lazy --output "$out/map-ordinary-loop-narrow" > "$out/map-ordinary-loop-narrow.log" 2>&1
printf '%s\n' 'Narrow map comparisons completed.'
