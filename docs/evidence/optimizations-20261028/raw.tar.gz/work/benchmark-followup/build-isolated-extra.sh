#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; free=shutil.disk_usage("/workspace").free; print("free_bytes",free,flush=True); assert free>=750*1024*1024, "pause: less than 750 MiB free"'; }
python3 work/benchmark-followup/prepare-map-loop.py --label round-loop --candidate-source round-map-actual-source
for side in before after; do
for mode in shipping allocations; do
free_check
if [ "$side" = before ]; then source=phase6-source; else source=round-map-actual-source; fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$source" --manifest "work/all-benchmarks/measurement/round-loop-$side-harness/Cargo.toml" --binary-name pbrs-map-iteration-proof --mode "$mode" --output "work/all-benchmarks/measurement/round-loop-$side" --record-key "codec-$mode"
done
done
for side in before after; do
free_check
if [ "$side" = before ]; then source=phase6-source; else source=round-budget-actual-source; fi
python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/$source" --manifest "work/all-benchmarks/measurement/round-budget-$side-harness/Cargo.toml" --binary-name pbrs-budget-proof --mode shipping --output "work/all-benchmarks/measurement/round-budget-$side" --record-key codec-shipping
done
printf '%s\n' 'Isolated holdout binaries built. Semantic preflight performs zero timing iterations.'
python3 work/benchmark-followup/preflight.py
