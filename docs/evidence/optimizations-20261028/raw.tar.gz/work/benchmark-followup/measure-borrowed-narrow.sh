#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
for label in round-borrowed-narrow; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate "$label" > "$out/$label-codec-$profile.log" 2>&1
done
done
for kind in partial encode; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" "$kind" --storage "$profile" --candidate round-borrowed-narrow > "$out/round-borrowed-narrow-$kind-$profile.log" 2>&1
done
done
for profile in debug release; do
baseline="work/all-benchmarks/codegen/final-candidate-$profile/driver"
prost=work/all-benchmarks/codegen/prost-canonical-driver
if [ "$profile" = release ]; then prost=work/all-benchmarks/codegen/final-prost-release/driver; fi
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/codegen_compare_blocking.py" --baseline "$baseline" --candidate "work/benchmark-followup/codegen-borrowed-narrow-$profile/driver" --prost "$prost" --profile "$profile" --output "$out/codegen-borrowed-narrow-$profile" --capture-limit 12 "${resume[@]}" > "$out/codegen-borrowed-narrow-$profile-$part.log" 2>&1
done
done
printf '%s\n' 'Narrow borrowed-wire comparisons completed.'
