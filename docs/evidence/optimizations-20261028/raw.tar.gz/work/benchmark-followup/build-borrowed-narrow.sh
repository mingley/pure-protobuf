#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
free_check() { python3 -c 'import shutil; x=shutil.disk_usage("/workspace").free;print("free_bytes",x,flush=True);assert x>=750*1024*1024,"pause: insufficient free space"'; }
# Retain content hashes while forcing Cargo to notice the newly copied runtime/gencode files.
python3 - <<'PY'
from pathlib import Path
import json
s=Path('work/all-benchmarks/measurement/round-borrowed-narrow-source');d=json.loads(Path('work/all-benchmarks/measurement/round-borrowed-narrow-source-source.json').read_text())
for name,meta in d['declared_changes'].items():
 if meta['scope']=='shipping-source':(s/name).touch()
(s/'tests/proof/codec_benchmark/src/main.rs').touch()
PY
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-borrowed-narrow-source --manifest work/all-benchmarks/measurement/round-borrowed-narrow-source/tests/proof/codec_benchmark/Cargo.toml --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/round-borrowed-narrow-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
free_check
python3 work/all-benchmarks/measurement/prepare_holdouts.py work/all-benchmarks/measurement/round-borrowed-narrow-source round-borrowed-narrow
for kind in partial encode; do
for profile in lazy owned; do
for mode in shipping allocations; do
free_check
extra=()
if [ "$profile" = owned ]; then extra=(--owned); fi
binary=pbrs-encode-proof
if [ "$kind" = partial ]; then binary=pbrs-partial-getter-proof; fi
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round-borrowed-narrow-source --manifest "work/all-benchmarks/measurement/round-borrowed-narrow-$kind-harness/Cargo.toml" --binary-name "$binary" --mode "$mode" --output "work/all-benchmarks/measurement/round-borrowed-narrow-$kind-$profile" --record-key "codec-$mode" "${extra[@]}"
done
done
done
for profile in debug release; do
free_check
python3 work/all-benchmarks/codegen/build_final_driver.py --source work/all-benchmarks/measurement/round-borrowed-narrow-source --peer pbrs --profile "$profile" --output "work/benchmark-followup/codegen-borrowed-narrow-$profile"
python3 - "$profile" <<'INNER'
import sys,hashlib
from pathlib import Path
p=sys.argv[1];root=Path.cwd();before=root/'work/all-benchmarks/codegen'/('final-candidate-'+p)/'Cargo.lock';after=root/'work/benchmark-followup'/('codegen-borrowed-narrow-'+p)/'Cargo.lock'
assert before.read_bytes()==after.read_bytes(),f'{p} borrowed codegen lock mismatch'
print('matched_borrowed_codegen_lock',p,hashlib.sha256(after.read_bytes()).hexdigest())
INNER
done
printf '%s\n' 'Narrow borrowed-wire binaries frozen; no performance timing was performed.'
