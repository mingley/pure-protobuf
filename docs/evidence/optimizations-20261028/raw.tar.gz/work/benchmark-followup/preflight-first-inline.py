"""Check every narrow-map holdout case without timed iterations."""
from pathlib import Path
import hashlib,itertools,json,subprocess
root=Path(__file__).resolve().parents[2];folder=root/'work/all-benchmarks/measurement/round-loop-first-inline';out=root/'work/benchmark-followup/preflight-first-inline.json';assert not out.exists()
baseline=json.loads((root/'work/benchmark-followup/preflight.json').read_text())['fingerprints'];record=json.loads((folder/'source.json').read_text());rows=[]
for mode,n,dist,op,backend in itertools.product(('shipping','allocations'),(4,16,64,256),('distinct','duplicate','firstsurvives'),('iter_all','iter_first','cold_read'),('pbrs','prost')):
 binary=folder/('codec-'+mode);assert record['binaries']['codec-'+mode]['sha256']==hashlib.sha256(binary.read_bytes()).hexdigest()
 case=f'map_{n}_{dist}';cmd=[str(binary),case,backend,op,'0','1'];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(cmd,r.stderr);v=json.loads(r.stdout);assert v['semantic_prechecks'] and v['case']==case and v['backend']==backend and v['operation']==op and v['raw_entries']==n
 assert [v['wire_bytes'],v['wire_fnv1a64'],v['checksum'],v['unique_entries']]==baseline[case],case
 rows.append(dict(mode=mode,case=case,operation=op,backend=backend,passed=True))
report=dict(schema='pbrs.first-inline-map-holdout-preflight.v1',complete=True,timed_iterations=0,captures=len(rows),cases=rows);out.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,captures=len(rows),timed_iterations=0)))
