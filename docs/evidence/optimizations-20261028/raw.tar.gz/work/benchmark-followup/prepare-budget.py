"""Prepare equal tracker harnesses using one locked dependency graph."""
from pathlib import Path
import json,os,shutil,subprocess
root=Path(__file__).resolve().parents[2];base=root/'work/all-benchmarks/measurement';template=root/'work/benchmark-followup/budget-template'
env=dict(os.environ);env.update(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_TARGET_DIR=str(root/'work/bench-target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0');env['PATH']=str(root/'work/cargo/bin')+':'+str(root/'work/toolchain/protoc/bin')+':'+env['PATH']
for label,source in [('round-budget-before','phase6-source'),('round-budget-after','round-budget-actual-source')]:
 out=base/(label+'-harness');assert not out.exists();shutil.copytree(template,out);p=out/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(base/source)))
 if label.endswith('before'):
  subprocess.run(['cargo','generate-lockfile','--offline','--manifest-path',str(p)],cwd=root,env=env,check=True)
 else:shutil.copyfile(base/'round-budget-before-harness/Cargo.lock',out/'Cargo.lock')
assert (base/'round-budget-before-harness/src/main.rs').read_bytes()==(base/'round-budget-after-harness/src/main.rs').read_bytes()
assert (base/'round-budget-before-harness/Cargo.lock').read_bytes()==(base/'round-budget-after-harness/Cargo.lock').read_bytes()
print(json.dumps({'prepared':True,'sources':['phase6-source','round-budget-actual-source']}))
