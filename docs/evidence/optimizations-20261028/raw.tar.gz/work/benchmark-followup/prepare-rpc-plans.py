"""Make unchanged-work plans for the isolated tracker correction."""
from pathlib import Path
import hashlib,json
b=Path('work/all-benchmarks/measurement')
for src,dest in [('phase6-rpc-plan.json','round-budget-rpc-plan.json'),('phase6-rpc-default-plan.json','round-budget-rpc-default-plan.json'),('phase6-rpc-identity-confirmation-plan.json','round-budget-rpc-identity-plan.json')]:
 old=json.loads((b/src).read_text());new=dict(old)
 new.update(baseline='6d1336e0f6490249c7339b6a8a6bb74c7d44d432',candidate='6d1336e0+isolated-checked-budget-f61b2baf',source_manifest='round-budget-actual-source-source.json',source_scope='Only pbrs-grpc/src/limits.rs differs from the phase6 source; benchmark work is unchanged')
 if 'production_changes' in new:new['production_changes']=['pbrs-grpc/src/limits.rs']
 if 'reason' in new:new['reason']='Retain the separate 500/1000-RPC confirmation to resolve the original 100Hz 10/20-RPC quantization.'
 if 'identity' in dest and 'limits' in new:new['limits']=[x for x in new['limits'] if 'Counts remain10/20' not in x]+['This confirmation retains 500/1000 counts; all other identity-cell settings remain unchanged.']
 ignored={'baseline','candidate','source_manifest','source_scope','production_changes','reason','limits'}
 assert {k:v for k,v in old.items() if k not in ignored}=={k:v for k,v in new.items() if k not in ignored}
 new['derived_from']=src;new['derived_from_sha256']=hashlib.sha256((b/src).read_bytes()).hexdigest()
 target=b/dest;assert not target.exists();target.write_text(json.dumps(new,indent=2)+'\n')
print('Three phase6-equivalent plans prepared; no measurements run.')
