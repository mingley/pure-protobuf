#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
bash work/benchmark-followup/measure-map-narrow.sh
for group in map-small map-large; do
python3 "$m/measure_phase2.py" "$group" --candidate round-map-forced-inline > "$out/round-map-forced-inline-$group.log" 2>&1
done
for label in round-map-forced-inline round-borrowed; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate "$label" > "$out/$label-codec-$profile.log" 2>&1
done
done
for kind in partial encode; do
for profile in lazy owned; do
python3 "$m/measure_phase2.py" "$kind" --storage "$profile" --candidate round-borrowed > "$out/round-borrowed-$kind-$profile.log" 2>&1
done
done
python3 work/benchmark-followup/map-loop-compare.py --before-shipping "$m/round-loop-before/codec-shipping" --before-allocations "$m/round-loop-before/codec-allocations" --before-record "$m/round-loop-before/source.json" --after-shipping "$m/round-loop-forced-inline/codec-shipping" --after-allocations "$m/round-loop-forced-inline/codec-allocations" --after-record "$m/round-loop-forced-inline/source.json" --storage lazy --output "$out/map-ordinary-loop-forced" > "$out/map-ordinary-loop-forced.log" 2>&1
for profile in debug release; do
baseline="work/all-benchmarks/codegen/final-candidate-$profile/driver"
prost=work/all-benchmarks/codegen/prost-canonical-driver
if [ "$profile" = release ]; then prost=work/all-benchmarks/codegen/final-prost-release/driver; fi
for part in 1 2 3 4 5; do
resume=()
if [ "$part" -gt 1 ]; then resume=(--resume); fi
python3 "$m/codegen_compare_blocking.py" --baseline "$baseline" --candidate "work/benchmark-followup/codegen-borrowed-$profile/driver" --prost "$prost" --profile "$profile" --output "$out/codegen-borrowed-$profile" --capture-limit 12 "${resume[@]}" > "$out/codegen-borrowed-$profile-$part.log" 2>&1
done
done
printf '%s\n' 'Narrow map, forced-inline map and borrowed-wire comparisons completed.'
