"""One-operation semantic and fixture checks. Run only in an approved quiet window; ignore clocks."""
import hashlib,itertools,json,subprocess
from pathlib import Path
root=Path.cwd();m=root/'work/all-benchmarks/measurement';out=root/'work/benchmark-followup/preflight-selected.json';assert not out.exists()
suites={'codec':({'empty','scalars','blob_4kib','packed_256','nested_8','nested_64','rpc_sparse','rpc_mixed'},('parse_owned','read_all')),'partial':({'nested_8','nested_64'},('read_first_child',)),'encode':({'nested_8','nested_64'},('parse_fresh_encode','fresh_encode','cached_encode','mutate_encode'))};rows=[]
for suite,(cases,ops) in suites.items():
 for profile,mode,case,op,backend in itertools.product(('lazy','owned'),('shipping','allocations'),sorted(cases),ops,('pbrs','prost')):
  stem='' if suite=='codec' else suite+'-';fingerprints={}
  for version in ('before','after'):
   folder=m/(('candidate-' if version=='before' else 'round-selected-')+stem+profile);binary=folder/('codec-'+mode);d=json.loads((folder/'source.json').read_text());assert hashlib.sha256(binary.read_bytes()).hexdigest()==d['binaries']['codec-'+mode]['sha256'];cmd=[str(binary),case,backend,op,'1','1'];r=subprocess.run(cmd,capture_output=True,text=True);assert r.returncode==0,(cmd,r.stderr);v=json.loads(r.stdout);assert v['semantic_prechecks'] and v['case']==case and v['operation']==op and v['backend']==backend and v['message_storage']==profile and v['allocation_instrumentation']==(mode=='allocations');fingerprints[version]=[v.get(k) for k in ('wire_bytes','wire_fnv1a64','checksum')]
  assert fingerprints['before']==fingerprints['after'],(suite,profile,case,op,backend,fingerprints);rows.append(dict(suite=suite,profile=profile,mode=mode,case=case,operation=op,backend=backend,fingerprint=fingerprints['after']))
out.write_text(json.dumps(dict(schema='pbrs.selected-semantic-preflight.v1',complete=True,captures=len(rows)*2,note='One operation per capture; internal clocks are deliberately discarded. Run in quiet; not performance evidence.',cases=rows),indent=2)+'\n');print(json.dumps({'complete':True,'captures':len(rows)*2,'purpose':'semantic preflight only'}))
