# Closed-upload allocation and error-order analysis

Scope: source review of `pbrs-grpc` at `acc8aef9`, plus the previous recorded
phase-6 measurements. No accepted transport source change results from this
analysis. The local deferred-encoding prototype was discarded; its exact source
was not retained, and no claim relies on a timed or independently reproduced
run of that prototype.

## Observed comparison

The [phase-6 evidence](../docs/evidence/decode-and-map-speed-20261027/README.md)
records two allocation pairs using the same Prost codec and a fresh tonic
control. For four incompressible, 1 MiB gzip messages, native upload-client
requested bytes are 16.072 MB per RPC versus 12.151 MB for tonic (paired ratio
1.323). This is requested allocator traffic, not RSS or endpoint CPU. The
measurements do not identify which calls account for the entire difference.

The earlier diagnostic tracer in `work/all-benchmarks/transport/allocdiag/`
classified large requests for a different bidi fixture and earlier source. It
uses an instrumented allocator, traces only selected allocation forms and sizes,
and did not isolate current upload-client cache misses. It is diagnostic, not
proof of the current upload allocation breakdown.

## Existing ordering and two rejected ideas

`pbrs-grpc/src/client/streaming.rs:505` drains a closed producer and encodes
all of its messages. Each message acquires its byte permit and joins a batch;
completed frame segments enter `queued`. Sending does not start until line 552,
after all messages were encoded. Therefore a later local encode, size-limit or
budget error is returned before any request DATA is queued by this fast path.
Already-open HEADERS are a separate event.

A deferred prototype encoded the first large compressed frame, then waited for
send progress before encoding the remaining messages. Its control flow can
select a complete peer response while the second message is still unencoded.
For an application-supplied `CodecMessage` whose second encoder returns an
error, an early peer success could therefore replace the earlier local error.
This counterexample follows from the select and callback ordering; it was not
independently reproduced with an exact retained copy of the discarded source.
Checking whether the remaining queue contains `Err` items does not establish
that future codec, length-limit or budget checks will succeed.

A narrower synchronous interleaving would try to queue each completed frame
while still encoding all messages. Even if it records send errors until every
local check is complete, the server can observe and act on a DATA prefix
before a later encoder fails. The existing path never queues that DATA on such
an error. A full send buffer also leaves an unsent suffix holding the original
backing. Waiting for capacity without observing an early peer response can
stall indefinitely. No implementation of this alternative was benchmarked.

## Sharing a bounded compression slab

`pbrs-grpc/src/wire/encode.rs:67` and `wire/out_batch.rs:97` already preserve
unused mutable tail space after a complete compressed frame is split away.
The retained backing is charged by its full capacity to the shared idle encode
cache: at most 4 MiB per backing and 16 MiB across idle entries. Immutable
prefixes remain owned by their frame handles; Rust/`BytesMut` sharing rules
prevent their mutation. The 16 MiB ledger does not limit every active buffer or
total process memory.

A slab fitting three approximate 1 MiB incompressible outputs can remain below
4 MiB, but four such gzip frames exceed that cap. Reserving room for later
outputs before encoding them moves allocation forward: with a 1 MiB first
message, a roughly 3 MiB backing can be active while only that first message's
byte permit has been acquired. Active compression and output allocations are
already outside the byte-permit ledger, so this is not by itself a violation of
the existing documented contract. It is a material increase in active memory
per call and is not bounded by the 16 MiB *idle* cache across concurrent calls.
If later messages compress to tiny outputs or are much smaller, the spare can
be wasted and held alive by immutable prefixes.

Preallocating from a claimed `encoded_len` before compression would also
penalize zero-filled data and custom codecs with inaccurate length reports.
The present `CompressedWriter` at `wire/encode.rs:456` waits for substantial
actual output before its size-based growth. A multi-frame hint after that
point could distinguish incompressible from zero-filled first messages and
would have a fixed per-backing cap, but still predicts later messages; its
allocation-call count, requested bytes, copy cost, peak live memory and CPU
are not measured here. The growth request already made before the observation
must also be included in any requested-byte comparison. Pre-acquiring permits
for all predicted bytes or revising permit transfers would alter admission and
failure ordering unless explicitly designed and tested.

A defensible follow-up needs an explicit bound for concurrent *active*
speculation and matched noise, zero and mixed-size measurements, in addition
to tests for custom codecs, local error precedence, cancellation, NO_ERROR
resets, shared immutable prefixes and budget saturation. No new cap or hint
is introduced by this note.
