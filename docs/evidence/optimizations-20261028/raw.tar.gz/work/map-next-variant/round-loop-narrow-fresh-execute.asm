
work/all-benchmarks/measurement/round-loop-narrow-fresh/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002dc70 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_>:
   2dc70:	55                   	push   %rbp
   2dc71:	41 57                	push   %r15
   2dc73:	41 56                	push   %r14
   2dc75:	41 55                	push   %r13
   2dc77:	41 54                	push   %r12
   2dc79:	53                   	push   %rbx
   2dc7a:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
   2dc81:	48 8b 07             	mov    (%rdi),%rax
   2dc84:	48 8b 00             	mov    (%rax),%rax
   2dc87:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2dc8c:	75 10                	jne    2dc9e <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x2e>
   2dc8e:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dc92:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2dc98:	0f 84 48 03 00 00    	je     2dfe6 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2dc9e:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2dca2:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2dca7:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2dcac:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2dcb0:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dcb4:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2dcb8:	48 83 f9 04          	cmp    $0x4,%rcx
   2dcbc:	0f 87 c5 08 00 00    	ja     2e587 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dcc2:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dcc6:	48 8d 15 f3 b5 fd ff 	lea    -0x24a0d(%rip),%rdx        # 92c0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2dccd:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2dcd1:	48 01 d1             	add    %rdx,%rcx
   2dcd4:	ff e1                	jmp    *%rcx
   2dcd6:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2dcdd:	61 6c 6c 
   2dce0:	48 39 08             	cmp    %rcx,(%rax)
   2dce3:	0f 85 9e 08 00 00    	jne    2e587 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dce9:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   2dcee:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2dcf2:	48 85 c0             	test   %rax,%rax
   2dcf5:	0f 84 27 03 00 00    	je     2e022 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2dcfb:	48 8b 09             	mov    (%rcx),%rcx
   2dcfe:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2dd02:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dd06:	f7 d7                	not    %edi
   2dd08:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2dd0c:	31 d2                	xor    %edx,%edx
   2dd0e:	eb 33                	jmp    2dd43 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2dd10:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2dd14:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2dd19:	41 21 f8             	and    %edi,%r8d
   2dd1c:	41 c1 e1 03          	shl    $0x3,%r9d
   2dd20:	48 89 cf             	mov    %rcx,%rdi
   2dd23:	4c 29 cf             	sub    %r9,%rdi
   2dd26:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2dd2a:	49 89 d2             	mov    %rdx,%r10
   2dd2d:	4d 01 ca             	add    %r9,%r10
   2dd30:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2dd34:	4c 01 d2             	add    %r10,%rdx
   2dd37:	44 89 c7             	mov    %r8d,%edi
   2dd3a:	48 ff c8             	dec    %rax
   2dd3d:	0f 84 e1 02 00 00    	je     2e024 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2dd43:	66 85 ff             	test   %di,%di
   2dd46:	75 c8                	jne    2dd10 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dd48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2dd4f:	00 
   2dd50:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dd54:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2dd58:	48 83 c6 10          	add    $0x10,%rsi
   2dd5c:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dd60:	66 83 f7 ff          	xor    $0xffff,%di
   2dd64:	74 ea                	je     2dd50 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2dd66:	eb a8                	jmp    2dd10 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dd68:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2dd6f:	66 69 72 
   2dd72:	48 33 08             	xor    (%rax),%rcx
   2dd75:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2dd79:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2dd7f:	48 09 c8             	or     %rcx,%rax
   2dd82:	0f 85 ff 07 00 00    	jne    2e587 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dd88:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2dd8d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2dd92:	0f 84 77 02 00 00    	je     2e00f <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2dd98:	48 8b 00             	mov    (%rax),%rax
   2dd9b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2dd9f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dda3:	66 83 f1 ff          	xor    $0xffff,%cx
   2dda7:	75 1d                	jne    2ddc6 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2dda9:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2ddad:	0f 1f 00             	nopl   (%rax)
   2ddb0:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2ddb4:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2ddb8:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2ddbc:	48 83 c2 10          	add    $0x10,%rdx
   2ddc0:	66 83 f1 ff          	xor    $0xffff,%cx
   2ddc4:	74 ea                	je     2ddb0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2ddc6:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2ddca:	c1 e1 03             	shl    $0x3,%ecx
   2ddcd:	48 29 c8             	sub    %rcx,%rax
   2ddd0:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2ddd4:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2ddd8:	e9 34 02 00 00       	jmp    2e011 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2dddd:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2dde4:	72 65 61 
   2dde7:	48 33 08             	xor    (%rax),%rcx
   2ddea:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2ddee:	48 83 f0 64          	xor    $0x64,%rax
   2ddf2:	48 09 c8             	or     %rcx,%rax
   2ddf5:	0f 85 8c 07 00 00    	jne    2e587 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2ddfb:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2de02:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2de07:	0f 85 93 07 00 00    	jne    2e5a0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x930>
   2de0d:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2de11:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2de16:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2de1a:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2de1e:	0f 10 05 db 20 04 00 	movups 0x420db(%rip),%xmm0        # 6ff00 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x510>
   2de25:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2de29:	f3 0f 6f 05 df 20 04 	movdqu 0x420df(%rip),%xmm0        # 6ff10 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x520>
   2de30:	00 
   2de31:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2de37:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2de3c:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2de41:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2de45:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2de4a:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2de4f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2de54:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2de58:	48 85 c9             	test   %rcx,%rcx
   2de5b:	0f 84 cf 01 00 00    	je     2e030 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2de61:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2de65:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2de69:	48 89 e3             	mov    %rsp,%rbx
   2de6c:	0f 1f 40 00          	nopl   0x0(%rax)
   2de70:	41 8b 36             	mov    (%r14),%esi
   2de73:	41 8b 56 04          	mov    0x4(%r14),%edx
   2de77:	48 89 df             	mov    %rbx,%rdi
   2de7a:	e8 71 5b 00 00       	call   339f0 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2de7f:	49 83 c6 08          	add    $0x8,%r14
   2de83:	4d 39 fe             	cmp    %r15,%r14
   2de86:	75 e8                	jne    2de70 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2de88:	48 8b 3c 24          	mov    (%rsp),%rdi
   2de8c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2de91:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2de96:	48 85 c9             	test   %rcx,%rcx
   2de99:	0f 84 86 03 00 00    	je     2e225 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x5b5>
   2de9f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2dea3:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dea8:	41 f7 d1             	not    %r9d
   2deab:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2deaf:	31 d2                	xor    %edx,%edx
   2deb1:	49 89 f8             	mov    %rdi,%r8
   2deb4:	eb 3d                	jmp    2def3 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2deb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2debd:	00 00 00 
   2dec0:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2dec4:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2dec9:	45 21 ca             	and    %r9d,%r10d
   2decc:	41 c1 e3 03          	shl    $0x3,%r11d
   2ded0:	4d 89 c1             	mov    %r8,%r9
   2ded3:	4d 29 d9             	sub    %r11,%r9
   2ded6:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2deda:	48 89 d3             	mov    %rdx,%rbx
   2dedd:	4c 01 db             	add    %r11,%rbx
   2dee0:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2dee4:	48 01 da             	add    %rbx,%rdx
   2dee7:	45 89 d1             	mov    %r10d,%r9d
   2deea:	48 ff c9             	dec    %rcx
   2deed:	0f 84 34 03 00 00    	je     2e227 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x5b7>
   2def3:	66 45 85 c9          	test   %r9w,%r9w
   2def7:	75 c7                	jne    2dec0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2def9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2df00:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2df04:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2df08:	48 83 c6 10          	add    $0x10,%rsi
   2df0c:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2df11:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2df16:	74 e8                	je     2df00 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2df18:	eb a6                	jmp    2dec0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2df1a:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2df21:	63 6f 6c 
   2df24:	48 33 08             	xor    (%rax),%rcx
   2df27:	8b 40 08             	mov    0x8(%rax),%eax
   2df2a:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2df30:	48 09 c8             	or     %rcx,%rax
   2df33:	0f 85 4e 06 00 00    	jne    2e587 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2df39:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2df3e:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2df42:	48 85 c9             	test   %rcx,%rcx
   2df45:	0f 84 f8 00 00 00    	je     2e043 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2df4b:	4c 8b 28             	mov    (%rax),%r13
   2df4e:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2df54:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2df59:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2df5d:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2df62:	75 25                	jne    2df89 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2df64:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2df6b:	00 00 00 00 00 
   2df70:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2df75:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2df79:	48 83 c5 10          	add    $0x10,%rbp
   2df7d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2df82:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2df87:	74 e7                	je     2df70 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2df89:	48 83 f9 05          	cmp    $0x5,%rcx
   2df8d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2df92:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2df98:	4c 0f 43 f9          	cmovae %rcx,%r15
   2df9c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2dfa3:	00 
   2dfa4:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2dfab:	ff ff 1f 
   2dfae:	48 ff c0             	inc    %rax
   2dfb1:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   2dfb6:	48 39 c1             	cmp    %rax,%rcx
   2dfb9:	0f 97 c0             	seta   %al
   2dfbc:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2dfc3:	ff ff 7f 
   2dfc6:	48 83 c1 0b          	add    $0xb,%rcx
   2dfca:	49 39 ce             	cmp    %rcx,%r14
   2dfcd:	0f 97 c1             	seta   %cl
   2dfd0:	08 c1                	or     %al,%cl
   2dfd2:	0f 84 40 01 00 00    	je     2e118 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x4a8>
   2dfd8:	31 db                	xor    %ebx,%ebx
   2dfda:	48 89 df             	mov    %rbx,%rdi
   2dfdd:	4c 89 f6             	mov    %r14,%rsi
   2dfe0:	ff 15 3a 3b 04 00    	call   *0x43b3a(%rip)        # 71b20 <_DYNAMIC+0x1f8>
   2dfe6:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2dfea:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2dfef:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
   2dff4:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2dff9:	4c 8b 30             	mov    (%rax),%r14
   2dffc:	4d 85 f6             	test   %r14,%r14
   2dfff:	74 4f                	je     2e050 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2e001:	49 8b 46 08          	mov    0x8(%r14),%rax
   2e005:	49 8b 5e 10          	mov    0x10(%r14),%rbx
   2e009:	49 83 c6 18          	add    $0x18,%r14
   2e00d:	eb 46                	jmp    2e055 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x3e5>
   2e00f:	31 c9                	xor    %ecx,%ecx
   2e011:	48 89 0c 24          	mov    %rcx,(%rsp)
   2e015:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e01a:	48 89 e0             	mov    %rsp,%rax
   2e01d:	e9 4b 05 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e022:	31 d2                	xor    %edx,%edx
   2e024:	48 89 14 24          	mov    %rdx,(%rsp)
   2e028:	48 89 e0             	mov    %rsp,%rax
   2e02b:	e9 3d 05 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e030:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2e037:	00 00 
   2e039:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2e03e:	e9 2a 05 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e043:	b8 04 00 00 00       	mov    $0x4,%eax
   2e048:	45 31 ff             	xor    %r15d,%r15d
   2e04b:	e9 65 04 00 00       	jmp    2e4b5 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x845>
   2e050:	45 31 f6             	xor    %r14d,%r14d
   2e053:	31 c0                	xor    %eax,%eax
   2e055:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2e059:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   2e05d:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   2e061:	48 83 fa 04          	cmp    $0x4,%rdx
   2e065:	0f 87 50 05 00 00    	ja     2e5bb <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e06b:	48 8b 49 08          	mov    0x8(%rcx),%rcx
   2e06f:	48 8d 35 5e b2 fd ff 	lea    -0x24da2(%rip),%rsi        # 92d4 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2e076:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2e07a:	48 01 f2             	add    %rsi,%rdx
   2e07d:	ff e2                	jmp    *%rdx
   2e07f:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2e086:	61 6c 6c 
   2e089:	48 39 11             	cmp    %rdx,(%rcx)
   2e08c:	0f 85 29 05 00 00    	jne    2e5bb <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e092:	48 85 c0             	test   %rax,%rax
   2e095:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e09b:	4c 0f 45 f8          	cmovne %rax,%r15
   2e09f:	48 0f 44 d8          	cmove  %rax,%rbx
   2e0a3:	31 c0                	xor    %eax,%eax
   2e0a5:	48 85 db             	test   %rbx,%rbx
   2e0a8:	74 1a                	je     2e0c4 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2e0aa:	4d 85 f6             	test   %r14,%r14
   2e0ad:	74 15                	je     2e0c4 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2e0af:	48 83 fb 10          	cmp    $0x10,%rbx
   2e0b3:	72 0f                	jb     2e0c4 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2e0b5:	41 8b 46 18          	mov    0x18(%r14),%eax
   2e0b9:	85 c0                	test   %eax,%eax
   2e0bb:	0f 85 26 05 00 00    	jne    2e5e7 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x977>
   2e0c1:	4c 89 f0             	mov    %r14,%rax
   2e0c4:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e0cb:	00 
   2e0cc:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e0d1:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e0d6:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e0db:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e0e2:	00 00 
   2e0e4:	45 31 ff             	xor    %r15d,%r15d
   2e0e7:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e0ec:	49 89 e6             	mov    %rsp,%r14
   2e0ef:	90                   	nop
   2e0f0:	48 89 df             	mov    %rbx,%rdi
   2e0f3:	4c 89 f6             	mov    %r14,%rsi
   2e0f6:	e8 95 89 00 00       	call   36a90 <_RNvXsN_NtCs5j8IpIVsCiS_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e0fb:	83 7c 24 30 01       	cmpl   $0x1,0x30(%rsp)
   2e100:	0f 85 dd 02 00 00    	jne    2e3e3 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x773>
   2e106:	48 63 44 24 34       	movslq 0x34(%rsp),%rax
   2e10b:	48 63 4c 24 38       	movslq 0x38(%rsp),%rcx
   2e110:	49 01 c7             	add    %rax,%r15
   2e113:	49 01 cf             	add    %rcx,%r15
   2e116:	eb d8                	jmp    2e0f0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x480>
   2e118:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2e11d:	c1 e0 03             	shl    $0x3,%eax
   2e120:	4c 89 e9             	mov    %r13,%rcx
   2e123:	48 29 c1             	sub    %rax,%rcx
   2e126:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2e12b:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   2e131:	4c 89 f7             	mov    %r14,%rdi
   2e134:	ff 15 36 3a 04 00    	call   *0x43a36(%rip)        # 71b70 <malloc@GLIBC_2.2.5>
   2e13a:	48 85 c0             	test   %rax,%rax
   2e13d:	0f 84 97 fe ff ff    	je     2dfda <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2e143:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2e148:	48 89 cb             	mov    %rcx,%rbx
   2e14b:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2e151:	66 0f d6 00          	movq   %xmm0,(%rax)
   2e155:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e159:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e15e:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2e165:	00 00 
   2e167:	48 ff cb             	dec    %rbx
   2e16a:	0f 84 45 03 00 00    	je     2e4b5 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x845>
   2e170:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2e175:	45 21 e7             	and    %r12d,%r15d
   2e178:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e17e:	49 89 e4             	mov    %rsp,%r12
   2e181:	eb 3c                	jmp    2e1bf <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x54f>
   2e183:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e18a:	84 00 00 00 00 00 
   2e190:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e195:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2e199:	44 21 f9             	and    %r15d,%ecx
   2e19c:	48 ff cb             	dec    %rbx
   2e19f:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2e1a5:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2e1ab:	49 ff c6             	inc    %r14
   2e1ae:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e1b3:	41 89 cf             	mov    %ecx,%r15d
   2e1b6:	48 85 db             	test   %rbx,%rbx
   2e1b9:	0f 84 e8 02 00 00    	je     2e4a7 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x837>
   2e1bf:	66 45 85 ff          	test   %r15w,%r15w
   2e1c3:	75 24                	jne    2e1e9 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x579>
   2e1c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e1cc:	00 00 00 00 
   2e1d0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e1d5:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e1d9:	48 83 c5 10          	add    $0x10,%rbp
   2e1dd:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2e1e2:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2e1e7:	74 e7                	je     2e1d0 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x560>
   2e1e9:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2e1ee:	c1 e1 03             	shl    $0x3,%ecx
   2e1f1:	4c 89 ea             	mov    %r13,%rdx
   2e1f4:	48 29 ca             	sub    %rcx,%rdx
   2e1f7:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2e1fc:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   2e201:	4c 3b 34 24          	cmp    (%rsp),%r14
   2e205:	75 8e                	jne    2e195 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x525>
   2e207:	b9 04 00 00 00       	mov    $0x4,%ecx
   2e20c:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2e212:	4c 89 e7             	mov    %r12,%rdi
   2e215:	4c 89 f6             	mov    %r14,%rsi
   2e218:	48 89 da             	mov    %rbx,%rdx
   2e21b:	e8 b0 ec ff ff       	call   2ced0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e220:	e9 6b ff ff ff       	jmp    2e190 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x520>
   2e225:	31 d2                	xor    %edx,%edx
   2e227:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   2e22c:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   2e231:	48 85 c0             	test   %rax,%rax
   2e234:	0f 84 33 03 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e23a:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e241:	00 
   2e242:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e246:	48 01 c8             	add    %rcx,%rax
   2e249:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e24d:	0f 84 1a 03 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e253:	48 29 cf             	sub    %rcx,%rdi
   2e256:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e25a:	ff 15 f8 38 04 00    	call   *0x438f8(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e260:	e9 08 03 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e265:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2e26c:	66 69 72 
   2e26f:	48 33 11             	xor    (%rcx),%rdx
   2e272:	0f b7 49 08          	movzwl 0x8(%rcx),%ecx
   2e276:	48 81 f1 73 74 00 00 	xor    $0x7473,%rcx
   2e27d:	48 09 d1             	or     %rdx,%rcx
   2e280:	0f 85 35 03 00 00    	jne    2e5bb <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e286:	48 85 c0             	test   %rax,%rax
   2e289:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e28f:	4c 0f 45 f8          	cmovne %rax,%r15
   2e293:	48 0f 44 d8          	cmove  %rax,%rbx
   2e297:	31 c0                	xor    %eax,%eax
   2e299:	48 85 db             	test   %rbx,%rbx
   2e29c:	74 1a                	je     2e2b8 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e29e:	4d 85 f6             	test   %r14,%r14
   2e2a1:	74 15                	je     2e2b8 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e2a3:	48 83 fb 10          	cmp    $0x10,%rbx
   2e2a7:	72 0f                	jb     2e2b8 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e2a9:	41 8b 46 18          	mov    0x18(%r14),%eax
   2e2ad:	85 c0                	test   %eax,%eax
   2e2af:	0f 85 1f 03 00 00    	jne    2e5d4 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x964>
   2e2b5:	4c 89 f0             	mov    %r14,%rax
   2e2b8:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e2bf:	00 
   2e2c0:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e2c5:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e2ca:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e2cf:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e2d6:	00 00 
   2e2d8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2e2dd:	48 89 e6             	mov    %rsp,%rsi
   2e2e0:	e8 ab 87 00 00       	call   36a90 <_RNvXsN_NtCs5j8IpIVsCiS_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e2e5:	8b 44 24 38          	mov    0x38(%rsp),%eax
   2e2e9:	89 44 24 58          	mov    %eax,0x58(%rsp)
   2e2ed:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2e2f2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   2e2f7:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
   2e2fc:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e301:	0f 84 66 02 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e307:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e30d:	0f 84 5a 02 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e313:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e318:	ff 15 3a 38 04 00    	call   *0x4383a(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e31e:	e9 4a 02 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e323:	48 b8 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rax
   2e32a:	72 65 61 
   2e32d:	48 33 01             	xor    (%rcx),%rax
   2e330:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
   2e334:	48 83 f1 64          	xor    $0x64,%rcx
   2e338:	48 09 c1             	or     %rax,%rcx
   2e33b:	0f 85 7a 02 00 00    	jne    2e5bb <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e341:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   2e348:	00 00 
   2e34a:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e34e:	48 89 04 24          	mov    %rax,(%rsp)
   2e352:	48 89 e0             	mov    %rsp,%rax
   2e355:	48 8b 04 24          	mov    (%rsp),%rax
   2e359:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e35d:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2e363:	48 85 c9             	test   %rcx,%rcx
   2e366:	0f 84 75 01 00 00    	je     2e4e1 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e36c:	4c 8b 78 08          	mov    0x8(%rax),%r15
   2e370:	4d 8d 24 cf          	lea    (%r15,%rcx,8),%r12
   2e374:	48 8d 5c 24 50       	lea    0x50(%rsp),%rbx
   2e379:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e380:	41 8b 37             	mov    (%r15),%esi
   2e383:	41 8b 57 04          	mov    0x4(%r15),%edx
   2e387:	48 89 df             	mov    %rbx,%rdi
   2e38a:	e8 c1 6b 00 00       	call   34f50 <_RNvMso_NtCs5j8IpIVsCiS_4pbrs3mapINtB5_3MapllE10push_entryCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e38f:	49 83 c7 08          	add    $0x8,%r15
   2e393:	4d 39 e7             	cmp    %r12,%r15
   2e396:	75 e8                	jne    2e380 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x710>
   2e398:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
   2e39d:	48 85 db             	test   %rbx,%rbx
   2e3a0:	0f 84 3b 01 00 00    	je     2e4e1 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e3a6:	4c 8b 73 08          	mov    0x8(%rbx),%r14
   2e3aa:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
   2e3ae:	4d 85 ff             	test   %r15,%r15
   2e3b1:	0f 84 c8 01 00 00    	je     2e57f <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x90f>
   2e3b7:	49 83 ff 10          	cmp    $0x10,%r15
   2e3bb:	0f 82 25 01 00 00    	jb     2e4e6 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x876>
   2e3c1:	4c 8d 63 18          	lea    0x18(%rbx),%r12
   2e3c5:	8b 43 30             	mov    0x30(%rbx),%eax
   2e3c8:	85 c0                	test   %eax,%eax
   2e3ca:	0f 84 19 01 00 00    	je     2e4e9 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x879>
   2e3d0:	4c 89 e7             	mov    %r12,%rdi
   2e3d3:	4c 89 f6             	mov    %r14,%rsi
   2e3d6:	4c 89 fa             	mov    %r15,%rdx
   2e3d9:	e8 1a b0 ff ff       	call   293f8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs5j8IpIVsCiS_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e3de:	e9 06 01 00 00       	jmp    2e4e9 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x879>
   2e3e3:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e3e8:	74 13                	je     2e3fd <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x78d>
   2e3ea:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e3f0:	74 0b                	je     2e3fd <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x78d>
   2e3f2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e3f7:	ff 15 5b 37 04 00    	call   *0x4375b(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e3fd:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e401:	48 89 e0             	mov    %rsp,%rax
   2e404:	e9 64 01 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e409:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2e410:	63 6f 6c 
   2e413:	48 33 11             	xor    (%rcx),%rdx
   2e416:	8b 49 08             	mov    0x8(%rcx),%ecx
   2e419:	48 81 f1 6c 65 63 74 	xor    $0x7463656c,%rcx
   2e420:	48 09 d1             	or     %rdx,%rcx
   2e423:	0f 85 92 01 00 00    	jne    2e5bb <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e429:	48 85 c0             	test   %rax,%rax
   2e42c:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e432:	4c 0f 45 f8          	cmovne %rax,%r15
   2e436:	48 0f 44 d8          	cmove  %rax,%rbx
   2e43a:	31 c0                	xor    %eax,%eax
   2e43c:	48 85 db             	test   %rbx,%rbx
   2e43f:	74 1a                	je     2e45b <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e441:	4d 85 f6             	test   %r14,%r14
   2e444:	74 15                	je     2e45b <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e446:	48 83 fb 10          	cmp    $0x10,%rbx
   2e44a:	72 0f                	jb     2e45b <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e44c:	41 8b 46 18          	mov    0x18(%r14),%eax
   2e450:	85 c0                	test   %eax,%eax
   2e452:	0f 85 a2 01 00 00    	jne    2e5fa <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x98a>
   2e458:	4c 89 f0             	mov    %r14,%rax
   2e45b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e462:	00 
   2e463:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e468:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e46d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e472:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e479:	00 00 
   2e47b:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e480:	48 89 e6             	mov    %rsp,%rsi
   2e483:	48 89 df             	mov    %rbx,%rdi
   2e486:	e8 65 6f 00 00       	call   353f0 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs5j8IpIVsCiS_4pbrs3map11MapViewIterllEE9from_iterCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e48b:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   2e491:	0f 84 d6 00 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e497:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2e49c:	ff 15 b6 36 04 00    	call   *0x436b6(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e4a2:	e9 c6 00 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e4a7:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e4ab:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e4b0:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2e4b5:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e4b9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e4be:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e4c3:	48 89 e0             	mov    %rsp,%rax
   2e4c6:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e4cb:	0f 84 9c 00 00 00    	je     2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e4d1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e4d6:	ff 15 7c 36 04 00    	call   *0x4367c(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e4dc:	e9 8c 00 00 00       	jmp    2e56d <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e4e1:	45 31 ff             	xor    %r15d,%r15d
   2e4e4:	31 db                	xor    %ebx,%ebx
   2e4e6:	45 31 e4             	xor    %r12d,%r12d
   2e4e9:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e4f0:	00 
   2e4f1:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   2e4f6:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   2e4fb:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   2e500:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e507:	00 00 
   2e509:	45 31 e4             	xor    %r12d,%r12d
   2e50c:	4c 8d 74 24 30       	lea    0x30(%rsp),%r14
   2e511:	49 89 e7             	mov    %rsp,%r15
   2e514:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e51b:	00 00 00 00 00 
   2e520:	4c 89 f7             	mov    %r14,%rdi
   2e523:	4c 89 fe             	mov    %r15,%rsi
   2e526:	e8 65 85 00 00       	call   36a90 <_RNvXsN_NtCs5j8IpIVsCiS_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e52b:	83 7c 24 30 01       	cmpl   $0x1,0x30(%rsp)
   2e530:	75 12                	jne    2e544 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8d4>
   2e532:	48 63 44 24 34       	movslq 0x34(%rsp),%rax
   2e537:	48 63 4c 24 38       	movslq 0x38(%rsp),%rcx
   2e53c:	49 01 c4             	add    %rax,%r12
   2e53f:	49 01 cc             	add    %rcx,%r12
   2e542:	eb dc                	jmp    2e520 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e544:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e549:	74 13                	je     2e55e <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8ee>
   2e54b:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e551:	74 0b                	je     2e55e <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x8ee>
   2e553:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e558:	ff 15 fa 35 04 00    	call   *0x435fa(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e55e:	4c 89 24 24          	mov    %r12,(%rsp)
   2e562:	48 89 e0             	mov    %rsp,%rax
   2e565:	48 89 df             	mov    %rbx,%rdi
   2e568:	e8 03 bd ff ff       	call   2a270 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e56d:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
   2e574:	5b                   	pop    %rbx
   2e575:	41 5c                	pop    %r12
   2e577:	41 5d                	pop    %r13
   2e579:	41 5e                	pop    %r14
   2e57b:	41 5f                	pop    %r15
   2e57d:	5d                   	pop    %rbp
   2e57e:	c3                   	ret
   2e57f:	45 31 ff             	xor    %r15d,%r15d
   2e582:	e9 5f ff ff ff       	jmp    2e4e6 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x876>
   2e587:	48 8d 3d 96 ad fd ff 	lea    -0x2526a(%rip),%rdi        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e58e:	48 8d 15 33 1b 04 00 	lea    0x41b33(%rip),%rdx        # 700c8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6d8>
   2e595:	be 28 00 00 00       	mov    $0x28,%esi
   2e59a:	ff 15 28 37 04 00    	call   *0x43728(%rip)        # 71cc8 <_DYNAMIC+0x3a0>
   2e5a0:	49 89 fe             	mov    %rdi,%r14
   2e5a3:	ff 15 8f 39 04 00    	call   *0x4398f(%rip)        # 71f38 <_DYNAMIC+0x610>
   2e5a9:	4c 89 f7             	mov    %r14,%rdi
   2e5ac:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e5b1:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e5b6:	e9 5b f8 ff ff       	jmp    2de16 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e5bb:	48 8d 3d 62 ad fd ff 	lea    -0x2529e(%rip),%rdi        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e5c2:	48 8d 15 17 1b 04 00 	lea    0x41b17(%rip),%rdx        # 700e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f0>
   2e5c9:	be 28 00 00 00       	mov    $0x28,%esi
   2e5ce:	ff 15 f4 36 04 00    	call   *0x436f4(%rip)        # 71cc8 <_DYNAMIC+0x3a0>
   2e5d4:	4c 89 f7             	mov    %r14,%rdi
   2e5d7:	4c 89 fe             	mov    %r15,%rsi
   2e5da:	48 89 da             	mov    %rbx,%rdx
   2e5dd:	e8 16 ae ff ff       	call   293f8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs5j8IpIVsCiS_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e5e2:	e9 ce fc ff ff       	jmp    2e2b5 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x645>
   2e5e7:	4c 89 f7             	mov    %r14,%rdi
   2e5ea:	4c 89 fe             	mov    %r15,%rsi
   2e5ed:	48 89 da             	mov    %rbx,%rdx
   2e5f0:	e8 03 ae ff ff       	call   293f8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs5j8IpIVsCiS_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e5f5:	e9 c7 fa ff ff       	jmp    2e0c1 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x451>
   2e5fa:	4c 89 f7             	mov    %r14,%rdi
   2e5fd:	4c 89 fe             	mov    %r15,%rsi
   2e600:	48 89 da             	mov    %rbx,%rdx
   2e603:	e8 f0 ad ff ff       	call   293f8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs5j8IpIVsCiS_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e608:	e9 4b fe ff ff       	jmp    2e458 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x7e8>
   2e60d:	49 89 c6             	mov    %rax,%r14
   2e610:	eb 3a                	jmp    2e64c <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e612:	eb 48                	jmp    2e65c <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x9ec>
   2e614:	49 89 c6             	mov    %rax,%r14
   2e617:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e61c:	74 5b                	je     2e679 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e61e:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e623:	eb 4e                	jmp    2e673 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa03>
   2e625:	49 89 c6             	mov    %rax,%r14
   2e628:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
   2e62d:	eb 1d                	jmp    2e64c <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e62f:	49 89 c6             	mov    %rax,%r14
   2e632:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e637:	74 13                	je     2e64c <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e639:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e63f:	74 0b                	je     2e64c <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e641:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e646:	ff 15 0c 35 04 00    	call   *0x4350c(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e64c:	48 89 df             	mov    %rbx,%rdi
   2e64f:	e8 1c bc ff ff       	call   2a270 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs5j8IpIVsCiS_4pbrs3map3MapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e654:	eb 23                	jmp    2e679 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e656:	ff 15 54 35 04 00    	call   *0x43554(%rip)        # 71bb0 <_DYNAMIC+0x288>
   2e65c:	49 89 c6             	mov    %rax,%r14
   2e65f:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e664:	74 13                	je     2e679 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e666:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e66c:	74 0b                	je     2e679 <_RNCNvCs6aMYlvfNe3f_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e66e:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e673:	ff 15 df 34 04 00    	call   *0x434df(%rip)        # 71b58 <free@GLIBC_2.2.5>
   2e679:	4c 89 f7             	mov    %r14,%rdi
   2e67c:	e8 cf fc 03 00       	call   6e350 <_Unwind_Resume@plt>
   2e681:	49 89 c6             	mov    %rax,%r14
   2e684:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e688:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e68d:	e8 de bd ff ff       	call   2a470 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECs6aMYlvfNe3f_24pbrs_map_iteration_proof>
   2e692:	4c 89 f7             	mov    %r14,%rdi
   2e695:	e8 b6 fc 03 00       	call   6e350 <_Unwind_Resume@plt>
