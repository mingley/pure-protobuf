
/workspace/pure-protobuf/work/all-benchmarks/measurement/round-loop-forced-inline/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002dc20 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_>:
   2dc20:	55                   	push   %rbp
   2dc21:	41 57                	push   %r15
   2dc23:	41 56                	push   %r14
   2dc25:	41 55                	push   %r13
   2dc27:	41 54                	push   %r12
   2dc29:	53                   	push   %rbx
   2dc2a:	48 83 ec 78          	sub    $0x78,%rsp
   2dc2e:	48 8b 07             	mov    (%rdi),%rax
   2dc31:	48 8b 00             	mov    (%rax),%rax
   2dc34:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2dc39:	75 10                	jne    2dc4b <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x2b>
   2dc3b:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dc3f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2dc45:	0f 84 4b 03 00 00    	je     2df96 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2dc4b:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2dc4f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2dc54:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2dc59:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2dc5d:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dc61:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2dc65:	48 83 f9 04          	cmp    $0x4,%rcx
   2dc69:	0f 87 e4 0c 00 00    	ja     2e953 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd33>
   2dc6f:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dc73:	48 8d 15 56 b6 fd ff 	lea    -0x249aa(%rip),%rdx        # 92d0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2dc7a:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2dc7e:	48 01 d1             	add    %rdx,%rcx
   2dc81:	ff e1                	jmp    *%rcx
   2dc83:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2dc8a:	61 6c 6c 
   2dc8d:	48 39 08             	cmp    %rcx,(%rax)
   2dc90:	0f 85 bd 0c 00 00    	jne    2e953 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd33>
   2dc96:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   2dc9b:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2dc9f:	48 85 c0             	test   %rax,%rax
   2dca2:	0f 84 2a 03 00 00    	je     2dfd2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2dca8:	48 8b 09             	mov    (%rcx),%rcx
   2dcab:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2dcaf:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dcb3:	f7 d7                	not    %edi
   2dcb5:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2dcb9:	31 d2                	xor    %edx,%edx
   2dcbb:	eb 36                	jmp    2dcf3 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2dcbd:	0f 1f 00             	nopl   (%rax)
   2dcc0:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2dcc4:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2dcc9:	41 21 f8             	and    %edi,%r8d
   2dccc:	41 c1 e1 03          	shl    $0x3,%r9d
   2dcd0:	48 89 cf             	mov    %rcx,%rdi
   2dcd3:	4c 29 cf             	sub    %r9,%rdi
   2dcd6:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2dcda:	49 89 d2             	mov    %rdx,%r10
   2dcdd:	4d 01 ca             	add    %r9,%r10
   2dce0:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2dce4:	4c 01 d2             	add    %r10,%rdx
   2dce7:	44 89 c7             	mov    %r8d,%edi
   2dcea:	48 ff c8             	dec    %rax
   2dced:	0f 84 e1 02 00 00    	je     2dfd4 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2dcf3:	66 85 ff             	test   %di,%di
   2dcf6:	75 c8                	jne    2dcc0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dcf8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2dcff:	00 
   2dd00:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dd04:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2dd08:	48 83 c6 10          	add    $0x10,%rsi
   2dd0c:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dd10:	66 83 f7 ff          	xor    $0xffff,%di
   2dd14:	74 ea                	je     2dd00 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2dd16:	eb a8                	jmp    2dcc0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dd18:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2dd1f:	66 69 72 
   2dd22:	48 33 08             	xor    (%rax),%rcx
   2dd25:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2dd29:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2dd2f:	48 09 c8             	or     %rcx,%rax
   2dd32:	0f 85 1b 0c 00 00    	jne    2e953 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd33>
   2dd38:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2dd3d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2dd42:	0f 84 77 02 00 00    	je     2dfbf <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2dd48:	48 8b 00             	mov    (%rax),%rax
   2dd4b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2dd4f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dd53:	66 83 f1 ff          	xor    $0xffff,%cx
   2dd57:	75 1d                	jne    2dd76 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2dd59:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2dd5d:	0f 1f 00             	nopl   (%rax)
   2dd60:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2dd64:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2dd68:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dd6c:	48 83 c2 10          	add    $0x10,%rdx
   2dd70:	66 83 f1 ff          	xor    $0xffff,%cx
   2dd74:	74 ea                	je     2dd60 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2dd76:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2dd7a:	c1 e1 03             	shl    $0x3,%ecx
   2dd7d:	48 29 c8             	sub    %rcx,%rax
   2dd80:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2dd84:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2dd88:	e9 34 02 00 00       	jmp    2dfc1 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2dd8d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2dd94:	72 65 61 
   2dd97:	48 33 08             	xor    (%rax),%rcx
   2dd9a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2dd9e:	48 83 f0 64          	xor    $0x64,%rax
   2dda2:	48 09 c8             	or     %rcx,%rax
   2dda5:	0f 85 a8 0b 00 00    	jne    2e953 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd33>
   2ddab:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2ddb2:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2ddb7:	0f 85 af 0b 00 00    	jne    2e96c <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd4c>
   2ddbd:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2ddc1:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2ddc6:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2ddca:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2ddce:	0f 10 05 0b 2a 04 00 	movups 0x42a0b(%rip),%xmm0        # 707e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x510>
   2ddd5:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2ddd9:	f3 0f 6f 05 0f 2a 04 	movdqu 0x42a0f(%rip),%xmm0        # 707f0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x520>
   2dde0:	00 
   2dde1:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2dde7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2ddec:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2ddf1:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2ddf5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2ddfa:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2ddff:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2de04:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2de08:	48 85 c9             	test   %rcx,%rcx
   2de0b:	0f 84 cf 01 00 00    	je     2dfe0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2de11:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2de15:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2de19:	48 89 e3             	mov    %rsp,%rbx
   2de1c:	0f 1f 40 00          	nopl   0x0(%rax)
   2de20:	41 8b 36             	mov    (%r14),%esi
   2de23:	41 8b 56 04          	mov    0x4(%r14),%edx
   2de27:	48 89 df             	mov    %rbx,%rdi
   2de2a:	e8 31 63 00 00       	call   34160 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2de2f:	49 83 c6 08          	add    $0x8,%r14
   2de33:	4d 39 fe             	cmp    %r15,%r14
   2de36:	75 e8                	jne    2de20 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2de38:	48 8b 3c 24          	mov    (%rsp),%rdi
   2de3c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2de41:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2de46:	48 85 c9             	test   %rcx,%rcx
   2de49:	0f 84 7d 05 00 00    	je     2e3cc <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x7ac>
   2de4f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2de53:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2de58:	41 f7 d1             	not    %r9d
   2de5b:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2de5f:	31 d2                	xor    %edx,%edx
   2de61:	49 89 f8             	mov    %rdi,%r8
   2de64:	eb 3d                	jmp    2dea3 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2de66:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2de6d:	00 00 00 
   2de70:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2de74:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2de79:	45 21 ca             	and    %r9d,%r10d
   2de7c:	41 c1 e3 03          	shl    $0x3,%r11d
   2de80:	4d 89 c1             	mov    %r8,%r9
   2de83:	4d 29 d9             	sub    %r11,%r9
   2de86:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2de8a:	48 89 d3             	mov    %rdx,%rbx
   2de8d:	4c 01 db             	add    %r11,%rbx
   2de90:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2de94:	48 01 da             	add    %rbx,%rdx
   2de97:	45 89 d1             	mov    %r10d,%r9d
   2de9a:	48 ff c9             	dec    %rcx
   2de9d:	0f 84 2b 05 00 00    	je     2e3ce <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x7ae>
   2dea3:	66 45 85 c9          	test   %r9w,%r9w
   2dea7:	75 c7                	jne    2de70 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2dea9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2deb0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2deb4:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2deb8:	48 83 c6 10          	add    $0x10,%rsi
   2debc:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dec1:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2dec6:	74 e8                	je     2deb0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2dec8:	eb a6                	jmp    2de70 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2deca:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2ded1:	63 6f 6c 
   2ded4:	48 33 08             	xor    (%rax),%rcx
   2ded7:	8b 40 08             	mov    0x8(%rax),%eax
   2deda:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2dee0:	48 09 c8             	or     %rcx,%rax
   2dee3:	0f 85 6a 0a 00 00    	jne    2e953 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd33>
   2dee9:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2deee:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2def2:	48 85 c9             	test   %rcx,%rcx
   2def5:	0f 84 f8 00 00 00    	je     2dff3 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2defb:	4c 8b 28             	mov    (%rax),%r13
   2defe:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2df04:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2df09:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2df0d:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2df12:	75 25                	jne    2df39 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2df14:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2df1b:	00 00 00 00 00 
   2df20:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2df25:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2df29:	48 83 c5 10          	add    $0x10,%rbp
   2df2d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2df32:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2df37:	74 e7                	je     2df20 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2df39:	48 83 f9 05          	cmp    $0x5,%rcx
   2df3d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2df42:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2df48:	4c 0f 43 f9          	cmovae %rcx,%r15
   2df4c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2df53:	00 
   2df54:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2df5b:	ff ff 1f 
   2df5e:	48 ff c0             	inc    %rax
   2df61:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2df66:	48 39 c1             	cmp    %rax,%rcx
   2df69:	0f 97 c0             	seta   %al
   2df6c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2df73:	ff ff 7f 
   2df76:	48 83 c1 0b          	add    $0xb,%rcx
   2df7a:	49 39 ce             	cmp    %rcx,%r14
   2df7d:	0f 97 c1             	seta   %cl
   2df80:	08 c1                	or     %al,%cl
   2df82:	0f 84 20 01 00 00    	je     2e0a8 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x488>
   2df88:	31 db                	xor    %ebx,%ebx
   2df8a:	48 89 df             	mov    %rbx,%rdi
   2df8d:	4c 89 f6             	mov    %r14,%rsi
   2df90:	ff 15 a2 44 04 00    	call   *0x444a2(%rip)        # 72438 <_DYNAMIC+0x230>
   2df96:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2df9a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2df9f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   2dfa4:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2dfa9:	48 8b 30             	mov    (%rax),%rsi
   2dfac:	48 85 f6             	test   %rsi,%rsi
   2dfaf:	74 4f                	je     2e000 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2dfb1:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   2dfb5:	4c 8b 76 10          	mov    0x10(%rsi),%r14
   2dfb9:	48 83 c6 18          	add    $0x18,%rsi
   2dfbd:	eb 45                	jmp    2e004 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x3e4>
   2dfbf:	31 c9                	xor    %ecx,%ecx
   2dfc1:	48 89 0c 24          	mov    %rcx,(%rsp)
   2dfc5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2dfca:	48 89 e0             	mov    %rsp,%rax
   2dfcd:	e9 6e 09 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2dfd2:	31 d2                	xor    %edx,%edx
   2dfd4:	48 89 14 24          	mov    %rdx,(%rsp)
   2dfd8:	48 89 e0             	mov    %rsp,%rax
   2dfdb:	e9 60 09 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2dfe0:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2dfe7:	00 00 
   2dfe9:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2dfee:	e9 4d 09 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2dff3:	b8 04 00 00 00       	mov    $0x4,%eax
   2dff8:	45 31 ff             	xor    %r15d,%r15d
   2dffb:	e9 13 06 00 00       	jmp    2e613 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9f3>
   2e000:	31 f6                	xor    %esi,%esi
   2e002:	31 d2                	xor    %edx,%edx
   2e004:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2e008:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e00c:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2e010:	48 83 f9 04          	cmp    $0x4,%rcx
   2e014:	0f 87 6d 09 00 00    	ja     2e987 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd67>
   2e01a:	48 8b 40 08          	mov    0x8(%rax),%rax
   2e01e:	4c 8d 05 bf b2 fd ff 	lea    -0x24d41(%rip),%r8        # 92e4 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2e025:	49 63 0c 88          	movslq (%r8,%rcx,4),%rcx
   2e029:	4c 01 c1             	add    %r8,%rcx
   2e02c:	ff e1                	jmp    *%rcx
   2e02e:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2e035:	61 6c 6c 
   2e038:	48 39 08             	cmp    %rcx,(%rax)
   2e03b:	0f 85 46 09 00 00    	jne    2e987 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd67>
   2e041:	48 85 d2             	test   %rdx,%rdx
   2e044:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e04a:	4c 0f 45 fa          	cmovne %rdx,%r15
   2e04e:	4c 0f 44 f2          	cmove  %rdx,%r14
   2e052:	31 c0                	xor    %eax,%eax
   2e054:	4d 85 f6             	test   %r14,%r14
   2e057:	74 19                	je     2e072 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e059:	48 85 f6             	test   %rsi,%rsi
   2e05c:	74 14                	je     2e072 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e05e:	49 83 fe 10          	cmp    $0x10,%r14
   2e062:	72 0e                	jb     2e072 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e064:	8b 46 18             	mov    0x18(%rsi),%eax
   2e067:	85 c0                	test   %eax,%eax
   2e069:	0f 85 31 09 00 00    	jne    2e9a0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd80>
   2e06f:	48 89 f0             	mov    %rsi,%rax
   2e072:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e079:	00 
   2e07a:	48 8d 5c 24 08       	lea    0x8(%rsp),%rbx
   2e07f:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e084:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e089:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e08e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e095:	00 00 
   2e097:	45 31 f6             	xor    %r14d,%r14d
   2e09a:	4c 8b 3d 57 47 04 00 	mov    0x44757(%rip),%r15        # 727f8 <_DYNAMIC+0x5f0>
   2e0a1:	31 c0                	xor    %eax,%eax
   2e0a3:	e9 28 01 00 00       	jmp    2e1d0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x5b0>
   2e0a8:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2e0ad:	c1 e0 03             	shl    $0x3,%eax
   2e0b0:	4c 89 e9             	mov    %r13,%rcx
   2e0b3:	48 29 c1             	sub    %rax,%rcx
   2e0b6:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2e0bb:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   2e0c1:	4c 89 f7             	mov    %r14,%rdi
   2e0c4:	ff 15 26 43 04 00    	call   *0x44326(%rip)        # 723f0 <malloc@GLIBC_2.2.5>
   2e0ca:	48 85 c0             	test   %rax,%rax
   2e0cd:	0f 84 b7 fe ff ff    	je     2df8a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2e0d3:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e0d8:	48 89 cb             	mov    %rcx,%rbx
   2e0db:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e0e1:	66 0f d6 00          	movq   %xmm0,(%rax)
   2e0e5:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e0e9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e0ee:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2e0f5:	00 00 
   2e0f7:	48 ff cb             	dec    %rbx
   2e0fa:	0f 84 13 05 00 00    	je     2e613 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9f3>
   2e100:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2e105:	45 21 e7             	and    %r12d,%r15d
   2e108:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e10e:	49 89 e4             	mov    %rsp,%r12
   2e111:	eb 3c                	jmp    2e14f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x52f>
   2e113:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e11a:	84 00 00 00 00 00 
   2e120:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e125:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2e129:	44 21 f9             	and    %r15d,%ecx
   2e12c:	48 ff cb             	dec    %rbx
   2e12f:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e135:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2e13b:	49 ff c6             	inc    %r14
   2e13e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e143:	41 89 cf             	mov    %ecx,%r15d
   2e146:	48 85 db             	test   %rbx,%rbx
   2e149:	0f 84 b6 04 00 00    	je     2e605 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9e5>
   2e14f:	66 45 85 ff          	test   %r15w,%r15w
   2e153:	75 24                	jne    2e179 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x559>
   2e155:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e15c:	00 00 00 00 
   2e160:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e165:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e169:	48 83 c5 10          	add    $0x10,%rbp
   2e16d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2e172:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2e177:	74 e7                	je     2e160 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x540>
   2e179:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2e17e:	c1 e1 03             	shl    $0x3,%ecx
   2e181:	4c 89 ea             	mov    %r13,%rdx
   2e184:	48 29 ca             	sub    %rcx,%rdx
   2e187:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2e18c:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2e191:	4c 3b 34 24          	cmp    (%rsp),%r14
   2e195:	75 8e                	jne    2e125 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x505>
   2e197:	b9 04 00 00 00       	mov    $0x4,%ecx
   2e19c:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2e1a2:	4c 89 e7             	mov    %r12,%rdi
   2e1a5:	4c 89 f6             	mov    %r14,%rsi
   2e1a8:	48 89 da             	mov    %rbx,%rdx
   2e1ab:	e8 d0 ec ff ff       	call   2ce80 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e1b0:	e9 6b ff ff ff       	jmp    2e120 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x500>
   2e1b5:	48 8d 50 04          	lea    0x4(%rax),%rdx
   2e1b9:	8b 30                	mov    (%rax),%esi
   2e1bb:	8b 0a                	mov    (%rdx),%ecx
   2e1bd:	48 8b 04 24          	mov    (%rsp),%rax
   2e1c1:	48 63 d6             	movslq %esi,%rdx
   2e1c4:	4c 89 f6             	mov    %r14,%rsi
   2e1c7:	48 01 d6             	add    %rdx,%rsi
   2e1ca:	4c 63 f1             	movslq %ecx,%r14
   2e1cd:	49 01 f6             	add    %rsi,%r14
   2e1d0:	48 83 f8 01          	cmp    $0x1,%rax
   2e1d4:	75 44                	jne    2e21a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x5fa>
   2e1d6:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e1db:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
   2e1e0:	0f 83 c0 01 00 00    	jae    2e3a6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x786>
   2e1e6:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   2e1eb:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   2e1ef:	44 8b 04 ba          	mov    (%rdx,%rdi,4),%r8d
   2e1f3:	8b 74 ba 04          	mov    0x4(%rdx,%rdi,4),%esi
   2e1f7:	8b 4c ba 08          	mov    0x8(%rdx,%rdi,4),%ecx
   2e1fb:	c7 04 ba 00 00 00 00 	movl   $0x0,(%rdx,%rdi,4)
   2e202:	48 ff c0             	inc    %rax
   2e205:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e20a:	b8 01 00 00 00       	mov    $0x1,%eax
   2e20f:	41 83 f8 01          	cmp    $0x1,%r8d
   2e213:	74 ac                	je     2e1c1 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x5a1>
   2e215:	e9 8c 01 00 00       	jmp    2e3a6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x786>
   2e21a:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e21f:	48 85 f6             	test   %rsi,%rsi
   2e222:	74 3e                	je     2e262 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x642>
   2e224:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   2e228:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e22d:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e232:	48 39 c2             	cmp    %rax,%rdx
   2e235:	0f 85 9f 00 00 00    	jne    2e2da <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6ba>
   2e23b:	48 39 d1             	cmp    %rdx,%rcx
   2e23e:	0f 83 62 01 00 00    	jae    2e3a6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x786>
   2e244:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e249:	48 8d 04 ca          	lea    (%rdx,%rcx,8),%rax
   2e24d:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
   2e251:	48 83 c2 04          	add    $0x4,%rdx
   2e255:	48 ff c1             	inc    %rcx
   2e258:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e25d:	e9 57 ff ff ff       	jmp    2e1b9 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x599>
   2e262:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   2e267:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   2e26c:	48 39 ca             	cmp    %rcx,%rdx
   2e26f:	0f 83 31 01 00 00    	jae    2e3a6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x786>
   2e275:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e27a:	48 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%rax
   2e281:	00 
   2e282:	48 8d 3c d6          	lea    (%rsi,%rdx,8),%rdi
   2e286:	48 83 c7 08          	add    $0x8,%rdi
   2e28a:	4c 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%r8
   2e291:	00 
   2e292:	49 29 c0             	sub    %rax,%r8
   2e295:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e299:	48 8d 04 d6          	lea    (%rsi,%rdx,8),%rax
   2e29d:	48 ff c2             	inc    %rdx
   2e2a0:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   2e2a5:	48 39 ca             	cmp    %rcx,%rdx
   2e2a8:	0f 84 07 ff ff ff    	je     2e1b5 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x595>
   2e2ae:	44 8b 08             	mov    (%rax),%r9d
   2e2b1:	45 31 d2             	xor    %r10d,%r10d
   2e2b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e2bb:	00 00 00 00 00 
   2e2c0:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e2c4:	74 0e                	je     2e2d4 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6b4>
   2e2c6:	49 83 c2 08          	add    $0x8,%r10
   2e2ca:	4d 39 d0             	cmp    %r10,%r8
   2e2cd:	75 f1                	jne    2e2c0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6a0>
   2e2cf:	e9 e1 fe ff ff       	jmp    2e1b5 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x595>
   2e2d4:	48 83 c7 08          	add    $0x8,%rdi
   2e2d8:	eb bb                	jmp    2e295 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x675>
   2e2da:	48 85 c9             	test   %rcx,%rcx
   2e2dd:	0f 84 b4 00 00 00    	je     2e397 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x777>
   2e2e3:	48 39 c1             	cmp    %rax,%rcx
   2e2e6:	0f 83 ba 00 00 00    	jae    2e3a6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x786>
   2e2ec:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e2f1:	eb 20                	jmp    2e313 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6f3>
   2e2f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e2fa:	84 00 00 00 00 00 
   2e300:	49 39 78 08          	cmp    %rdi,0x8(%r8)
   2e304:	0f 84 7c 00 00 00    	je     2e386 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x766>
   2e30a:	48 39 c1             	cmp    %rax,%rcx
   2e30d:	0f 84 ad 00 00 00    	je     2e3c0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x7a0>
   2e313:	48 89 cf             	mov    %rcx,%rdi
   2e316:	48 ff c1             	inc    %rcx
   2e319:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e31e:	4c 8b 4e 10          	mov    0x10(%rsi),%r9
   2e322:	4d 85 c9             	test   %r9,%r9
   2e325:	74 e3                	je     2e30a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6ea>
   2e327:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   2e32b:	44 8b 14 fa          	mov    (%rdx,%rdi,8),%r10d
   2e32f:	49 83 f9 01          	cmp    $0x1,%r9
   2e333:	75 0b                	jne    2e340 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x720>
   2e335:	45 39 10             	cmp    %r10d,(%r8)
   2e338:	74 c6                	je     2e300 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6e0>
   2e33a:	eb ce                	jmp    2e30a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6ea>
   2e33c:	0f 1f 40 00          	nopl   0x0(%rax)
   2e340:	45 31 db             	xor    %r11d,%r11d
   2e343:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e34a:	84 00 00 00 00 00 
   2e350:	4d 89 dc             	mov    %r11,%r12
   2e353:	4d 89 cd             	mov    %r9,%r13
   2e356:	49 d1 ed             	shr    $1,%r13
   2e359:	4d 01 eb             	add    %r13,%r11
   2e35c:	4c 89 dd             	mov    %r11,%rbp
   2e35f:	48 c1 e5 04          	shl    $0x4,%rbp
   2e363:	45 39 14 28          	cmp    %r10d,(%r8,%rbp,1)
   2e367:	4d 0f 4f dc          	cmovg  %r12,%r11
   2e36b:	4d 29 e9             	sub    %r13,%r9
   2e36e:	49 83 f9 01          	cmp    $0x1,%r9
   2e372:	77 dc                	ja     2e350 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x730>
   2e374:	49 c1 e3 04          	shl    $0x4,%r11
   2e378:	47 39 14 18          	cmp    %r10d,(%r8,%r11,1)
   2e37c:	75 8c                	jne    2e30a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6ea>
   2e37e:	4d 01 d8             	add    %r11,%r8
   2e381:	e9 7a ff ff ff       	jmp    2e300 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x6e0>
   2e386:	48 8d 04 fa          	lea    (%rdx,%rdi,8),%rax
   2e38a:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
   2e38e:	48 83 c2 04          	add    $0x4,%rdx
   2e392:	e9 22 fe ff ff       	jmp    2e1b9 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x599>
   2e397:	48 89 df             	mov    %rbx,%rdi
   2e39a:	41 ff d7             	call   *%r15
   2e39d:	48 85 c0             	test   %rax,%rax
   2e3a0:	0f 85 13 fe ff ff    	jne    2e1b9 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x599>
   2e3a6:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e3ab:	74 13                	je     2e3c0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x7a0>
   2e3ad:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e3b3:	74 0b                	je     2e3c0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x7a0>
   2e3b5:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e3ba:	ff 15 40 40 04 00    	call   *0x44040(%rip)        # 72400 <free@GLIBC_2.2.5>
   2e3c0:	4c 89 34 24          	mov    %r14,(%rsp)
   2e3c4:	48 89 e0             	mov    %rsp,%rax
   2e3c7:	e9 74 05 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e3cc:	31 d2                	xor    %edx,%edx
   2e3ce:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   2e3d3:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   2e3d8:	48 85 c0             	test   %rax,%rax
   2e3db:	0f 84 5f 05 00 00    	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e3e1:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e3e8:	00 
   2e3e9:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e3ed:	48 01 c8             	add    %rcx,%rax
   2e3f0:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e3f4:	0f 84 46 05 00 00    	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e3fa:	48 29 cf             	sub    %rcx,%rdi
   2e3fd:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e401:	e9 2e 02 00 00       	jmp    2e634 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa14>
   2e406:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2e40d:	66 69 72 
   2e410:	48 33 08             	xor    (%rax),%rcx
   2e413:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e417:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e41d:	48 09 c8             	or     %rcx,%rax
   2e420:	0f 85 61 05 00 00    	jne    2e987 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd67>
   2e426:	48 85 d2             	test   %rdx,%rdx
   2e429:	b8 04 00 00 00       	mov    $0x4,%eax
   2e42e:	48 0f 45 c2          	cmovne %rdx,%rax
   2e432:	4d 85 f6             	test   %r14,%r14
   2e435:	0f 84 4b 04 00 00    	je     2e886 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc66>
   2e43b:	48 85 d2             	test   %rdx,%rdx
   2e43e:	0f 84 42 04 00 00    	je     2e886 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc66>
   2e444:	49 83 fe 10          	cmp    $0x10,%r14
   2e448:	0f 92 c1             	setb   %cl
   2e44b:	48 85 f6             	test   %rsi,%rsi
   2e44e:	40 0f 94 c7          	sete   %dil
   2e452:	40 08 cf             	or     %cl,%dil
   2e455:	0f 84 4f 04 00 00    	je     2e8aa <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc8a>
   2e45b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e462:	00 
   2e463:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2e468:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e46d:	4a 8d 0c f2          	lea    (%rdx,%r14,8),%rcx
   2e471:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   2e478:	00 00 
   2e47a:	31 d2                	xor    %edx,%edx
   2e47c:	48 8d 34 d0          	lea    (%rax,%rdx,8),%rsi
   2e480:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
   2e484:	48 83 c7 08          	add    $0x8,%rdi
   2e488:	48 ff c2             	inc    %rdx
   2e48b:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   2e490:	48 39 cf             	cmp    %rcx,%rdi
   2e493:	0f 84 51 04 00 00    	je     2e8ea <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcca>
   2e499:	44 8b 07             	mov    (%rdi),%r8d
   2e49c:	48 83 c7 08          	add    $0x8,%rdi
   2e4a0:	44 3b 06             	cmp    (%rsi),%r8d
   2e4a3:	75 eb                	jne    2e490 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x870>
   2e4a5:	31 f6                	xor    %esi,%esi
   2e4a7:	4c 39 f2             	cmp    %r14,%rdx
   2e4aa:	75 d0                	jne    2e47c <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x85c>
   2e4ac:	e9 64 04 00 00       	jmp    2e915 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcf5>
   2e4b1:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e4b8:	72 65 61 
   2e4bb:	48 33 08             	xor    (%rax),%rcx
   2e4be:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e4c2:	48 83 f0 64          	xor    $0x64,%rax
   2e4c6:	48 09 c8             	or     %rcx,%rax
   2e4c9:	0f 85 b8 04 00 00    	jne    2e987 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd67>
   2e4cf:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2e4d6:	00 00 
   2e4d8:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e4dc:	48 89 04 24          	mov    %rax,(%rsp)
   2e4e0:	48 89 e0             	mov    %rsp,%rax
   2e4e3:	48 8b 04 24          	mov    (%rsp),%rax
   2e4e7:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e4eb:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e4f1:	48 85 c9             	test   %rcx,%rcx
   2e4f4:	0f 84 45 01 00 00    	je     2e63f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa1f>
   2e4fa:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e4fe:	4d 8d 24 ce          	lea    (%r14,%rcx,8),%r12
   2e502:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e507:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2e50e:	00 00 
   2e510:	41 8b 36             	mov    (%r14),%esi
   2e513:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e517:	48 89 df             	mov    %rbx,%rdi
   2e51a:	e8 a1 71 00 00       	call   356c0 <_RNvMso_NtCs29Zh0EKK4Pp_4pbrs3mapINtB5_3MapllE10push_entryCsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e51f:	49 83 c6 08          	add    $0x8,%r14
   2e523:	4d 39 e6             	cmp    %r12,%r14
   2e526:	75 e8                	jne    2e510 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x8f0>
   2e528:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
   2e52d:	48 85 db             	test   %rbx,%rbx
   2e530:	0f 84 09 01 00 00    	je     2e63f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa1f>
   2e536:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
   2e53a:	4c 8b 63 10          	mov    0x10(%rbx),%r12
   2e53e:	4d 85 e4             	test   %r12,%r12
   2e541:	0f 84 ac 03 00 00    	je     2e8f3 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcd3>
   2e547:	49 83 fc 10          	cmp    $0x10,%r12
   2e54b:	0f 82 f3 00 00 00    	jb     2e644 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa24>
   2e551:	4c 8d 6b 18          	lea    0x18(%rbx),%r13
   2e555:	8b 43 30             	mov    0x30(%rbx),%eax
   2e558:	85 c0                	test   %eax,%eax
   2e55a:	0f 84 e7 00 00 00    	je     2e647 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa27>
   2e560:	4c 89 ef             	mov    %r13,%rdi
   2e563:	4c 89 fe             	mov    %r15,%rsi
   2e566:	4c 89 e2             	mov    %r12,%rdx
   2e569:	e8 3a ae ff ff       	call   293a8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs29Zh0EKK4Pp_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e56e:	e9 d4 00 00 00       	jmp    2e647 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa27>
   2e573:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e57a:	63 6f 6c 
   2e57d:	48 33 08             	xor    (%rax),%rcx
   2e580:	8b 40 08             	mov    0x8(%rax),%eax
   2e583:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e589:	48 09 c8             	or     %rcx,%rax
   2e58c:	0f 85 f5 03 00 00    	jne    2e987 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd67>
   2e592:	48 85 d2             	test   %rdx,%rdx
   2e595:	bb 04 00 00 00       	mov    $0x4,%ebx
   2e59a:	48 0f 45 da          	cmovne %rdx,%rbx
   2e59e:	4c 0f 44 f2          	cmove  %rdx,%r14
   2e5a2:	31 c0                	xor    %eax,%eax
   2e5a4:	4d 85 f6             	test   %r14,%r14
   2e5a7:	74 19                	je     2e5c2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9a2>
   2e5a9:	48 85 f6             	test   %rsi,%rsi
   2e5ac:	74 14                	je     2e5c2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9a2>
   2e5ae:	49 83 fe 10          	cmp    $0x10,%r14
   2e5b2:	72 0e                	jb     2e5c2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9a2>
   2e5b4:	8b 46 18             	mov    0x18(%rsi),%eax
   2e5b7:	85 c0                	test   %eax,%eax
   2e5b9:	0f 85 fa 03 00 00    	jne    2e9b9 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd99>
   2e5bf:	48 89 f0             	mov    %rsi,%rax
   2e5c2:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e5c9:	00 
   2e5ca:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   2e5cf:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e5d4:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e5d9:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e5e0:	00 00 
   2e5e2:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e5e7:	48 89 e6             	mov    %rsp,%rsi
   2e5ea:	48 89 df             	mov    %rbx,%rdi
   2e5ed:	e8 6e 75 00 00       	call   35b60 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs29Zh0EKK4Pp_4pbrs3map11MapViewIterllEE9from_iterCsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e5f2:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   2e5f8:	0f 84 42 03 00 00    	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e5fe:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2e603:	eb 2f                	jmp    2e634 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa14>
   2e605:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e609:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e60e:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e613:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e617:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e61c:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e621:	48 89 e0             	mov    %rsp,%rax
   2e624:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e629:	0f 84 11 03 00 00    	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e62f:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e634:	ff 15 c6 3d 04 00    	call   *0x43dc6(%rip)        # 72400 <free@GLIBC_2.2.5>
   2e63a:	e9 01 03 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e63f:	45 31 e4             	xor    %r12d,%r12d
   2e642:	31 db                	xor    %ebx,%ebx
   2e644:	45 31 ed             	xor    %r13d,%r13d
   2e647:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e64e:	00 
   2e64f:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e654:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2e659:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   2e65e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e665:	00 00 
   2e667:	45 31 ff             	xor    %r15d,%r15d
   2e66a:	4c 8b 25 87 41 04 00 	mov    0x44187(%rip),%r12        # 727f8 <_DYNAMIC+0x5f0>
   2e671:	31 c0                	xor    %eax,%eax
   2e673:	eb 1b                	jmp    2e690 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa70>
   2e675:	48 8d 50 04          	lea    0x4(%rax),%rdx
   2e679:	8b 08                	mov    (%rax),%ecx
   2e67b:	8b 02                	mov    (%rdx),%eax
   2e67d:	48 63 c9             	movslq %ecx,%rcx
   2e680:	4c 89 fa             	mov    %r15,%rdx
   2e683:	48 01 ca             	add    %rcx,%rdx
   2e686:	4c 63 f8             	movslq %eax,%r15
   2e689:	49 01 d7             	add    %rdx,%r15
   2e68c:	48 8b 04 24          	mov    (%rsp),%rax
   2e690:	48 83 f8 01          	cmp    $0x1,%rax
   2e694:	75 3f                	jne    2e6d5 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xab5>
   2e696:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e69b:	48 3b 54 24 20       	cmp    0x20(%rsp),%rdx
   2e6a0:	0f 83 b2 01 00 00    	jae    2e858 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc38>
   2e6a6:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e6ab:	48 8d 3c 52          	lea    (%rdx,%rdx,2),%rdi
   2e6af:	44 8b 04 be          	mov    (%rsi,%rdi,4),%r8d
   2e6b3:	8b 4c be 04          	mov    0x4(%rsi,%rdi,4),%ecx
   2e6b7:	8b 44 be 08          	mov    0x8(%rsi,%rdi,4),%eax
   2e6bb:	c7 04 be 00 00 00 00 	movl   $0x0,(%rsi,%rdi,4)
   2e6c2:	48 ff c2             	inc    %rdx
   2e6c5:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2e6ca:	41 83 f8 01          	cmp    $0x1,%r8d
   2e6ce:	74 ad                	je     2e67d <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa5d>
   2e6d0:	e9 83 01 00 00       	jmp    2e858 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc38>
   2e6d5:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e6da:	48 85 f6             	test   %rsi,%rsi
   2e6dd:	74 3e                	je     2e71d <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xafd>
   2e6df:	48 8b 56 10          	mov    0x10(%rsi),%rdx
   2e6e3:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e6e8:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e6ed:	48 39 c2             	cmp    %rax,%rdx
   2e6f0:	0f 85 94 00 00 00    	jne    2e78a <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb6a>
   2e6f6:	48 39 d1             	cmp    %rdx,%rcx
   2e6f9:	0f 83 59 01 00 00    	jae    2e858 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc38>
   2e6ff:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e704:	48 8d 04 ca          	lea    (%rdx,%rcx,8),%rax
   2e708:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
   2e70c:	48 83 c2 04          	add    $0x4,%rdx
   2e710:	48 ff c1             	inc    %rcx
   2e713:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e718:	e9 5c ff ff ff       	jmp    2e679 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa59>
   2e71d:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   2e722:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   2e727:	48 39 ca             	cmp    %rcx,%rdx
   2e72a:	0f 83 28 01 00 00    	jae    2e858 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc38>
   2e730:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e735:	48 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%rax
   2e73c:	00 
   2e73d:	48 8d 3c d6          	lea    (%rsi,%rdx,8),%rdi
   2e741:	48 83 c7 08          	add    $0x8,%rdi
   2e745:	4c 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%r8
   2e74c:	00 
   2e74d:	49 29 c0             	sub    %rax,%r8
   2e750:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e754:	48 8d 04 d6          	lea    (%rsi,%rdx,8),%rax
   2e758:	48 ff c2             	inc    %rdx
   2e75b:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   2e760:	48 39 ca             	cmp    %rcx,%rdx
   2e763:	0f 84 0c ff ff ff    	je     2e675 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e769:	44 8b 08             	mov    (%rax),%r9d
   2e76c:	45 31 d2             	xor    %r10d,%r10d
   2e76f:	90                   	nop
   2e770:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e774:	74 0e                	je     2e784 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb64>
   2e776:	49 83 c2 08          	add    $0x8,%r10
   2e77a:	4d 39 d0             	cmp    %r10,%r8
   2e77d:	75 f1                	jne    2e770 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb50>
   2e77f:	e9 f1 fe ff ff       	jmp    2e675 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e784:	48 83 c7 08          	add    $0x8,%rdi
   2e788:	eb c6                	jmp    2e750 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb30>
   2e78a:	48 85 c9             	test   %rcx,%rcx
   2e78d:	0f 84 b4 00 00 00    	je     2e847 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc27>
   2e793:	48 39 c1             	cmp    %rax,%rcx
   2e796:	0f 83 bc 00 00 00    	jae    2e858 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc38>
   2e79c:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e7a1:	eb 20                	jmp    2e7c3 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xba3>
   2e7a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e7aa:	84 00 00 00 00 00 
   2e7b0:	49 39 78 08          	cmp    %rdi,0x8(%r8)
   2e7b4:	0f 84 7c 00 00 00    	je     2e836 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc16>
   2e7ba:	48 39 c1             	cmp    %rax,%rcx
   2e7bd:	0f 84 af 00 00 00    	je     2e872 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc52>
   2e7c3:	48 89 cf             	mov    %rcx,%rdi
   2e7c6:	48 ff c1             	inc    %rcx
   2e7c9:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e7ce:	4c 8b 4e 10          	mov    0x10(%rsi),%r9
   2e7d2:	4d 85 c9             	test   %r9,%r9
   2e7d5:	74 e3                	je     2e7ba <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb9a>
   2e7d7:	4c 8b 46 08          	mov    0x8(%rsi),%r8
   2e7db:	44 8b 14 fa          	mov    (%rdx,%rdi,8),%r10d
   2e7df:	49 83 f9 01          	cmp    $0x1,%r9
   2e7e3:	75 0b                	jne    2e7f0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xbd0>
   2e7e5:	45 39 10             	cmp    %r10d,(%r8)
   2e7e8:	74 c6                	je     2e7b0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb90>
   2e7ea:	eb ce                	jmp    2e7ba <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb9a>
   2e7ec:	0f 1f 40 00          	nopl   0x0(%rax)
   2e7f0:	45 31 ed             	xor    %r13d,%r13d
   2e7f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e7fa:	84 00 00 00 00 00 
   2e800:	4d 89 ee             	mov    %r13,%r14
   2e803:	4c 89 cd             	mov    %r9,%rbp
   2e806:	48 d1 ed             	shr    $1,%rbp
   2e809:	49 01 ed             	add    %rbp,%r13
   2e80c:	4d 89 eb             	mov    %r13,%r11
   2e80f:	49 c1 e3 04          	shl    $0x4,%r11
   2e813:	47 39 14 18          	cmp    %r10d,(%r8,%r11,1)
   2e817:	4d 0f 4f ee          	cmovg  %r14,%r13
   2e81b:	49 29 e9             	sub    %rbp,%r9
   2e81e:	49 83 f9 01          	cmp    $0x1,%r9
   2e822:	77 dc                	ja     2e800 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xbe0>
   2e824:	49 c1 e5 04          	shl    $0x4,%r13
   2e828:	47 39 14 28          	cmp    %r10d,(%r8,%r13,1)
   2e82c:	75 8c                	jne    2e7ba <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb9a>
   2e82e:	4d 01 e8             	add    %r13,%r8
   2e831:	e9 7a ff ff ff       	jmp    2e7b0 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xb90>
   2e836:	48 8d 04 fa          	lea    (%rdx,%rdi,8),%rax
   2e83a:	48 8d 14 fa          	lea    (%rdx,%rdi,8),%rdx
   2e83e:	48 83 c2 04          	add    $0x4,%rdx
   2e842:	e9 32 fe ff ff       	jmp    2e679 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa59>
   2e847:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   2e84c:	41 ff d4             	call   *%r12
   2e84f:	48 85 c0             	test   %rax,%rax
   2e852:	0f 85 21 fe ff ff    	jne    2e679 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa59>
   2e858:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e85d:	74 13                	je     2e872 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc52>
   2e85f:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e865:	74 0b                	je     2e872 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc52>
   2e867:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e86c:	ff 15 8e 3b 04 00    	call   *0x43b8e(%rip)        # 72400 <free@GLIBC_2.2.5>
   2e872:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e876:	48 89 e0             	mov    %rsp,%rax
   2e879:	48 89 df             	mov    %rbx,%rdi
   2e87c:	e8 9f b9 ff ff       	call   2a220 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs29Zh0EKK4Pp_4pbrs3map3MapllEECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e881:	e9 ba 00 00 00       	jmp    2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e886:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e88d:	00 
   2e88e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e893:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e897:	f3 0f 7f 44 24 10    	movdqu %xmm0,0x10(%rsp)
   2e89d:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e8a4:	00 00 
   2e8a6:	31 f6                	xor    %esi,%esi
   2e8a8:	eb 6b                	jmp    2e915 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcf5>
   2e8aa:	8b 4e 18             	mov    0x18(%rsi),%ecx
   2e8ad:	85 c9                	test   %ecx,%ecx
   2e8af:	0f 85 1d 01 00 00    	jne    2e9d2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xdb2>
   2e8b5:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e8bc:	00 
   2e8bd:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2e8c2:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e8c7:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   2e8cc:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e8d3:	00 00 
   2e8d5:	4c 39 76 10          	cmp    %r14,0x10(%rsi)
   2e8d9:	75 20                	jne    2e8fb <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcdb>
   2e8db:	48 83 c2 04          	add    $0x4,%rdx
   2e8df:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2e8e6:	00 00 
   2e8e8:	eb 21                	jmp    2e90b <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xceb>
   2e8ea:	48 8d 56 04          	lea    0x4(%rsi),%rdx
   2e8ee:	48 89 f0             	mov    %rsi,%rax
   2e8f1:	eb 18                	jmp    2e90b <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xceb>
   2e8f3:	45 31 e4             	xor    %r12d,%r12d
   2e8f6:	e9 49 fd ff ff       	jmp    2e644 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa24>
   2e8fb:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   2e900:	ff 15 f2 3e 04 00    	call   *0x43ef2(%rip)        # 727f8 <_DYNAMIC+0x5f0>
   2e906:	48 85 c0             	test   %rax,%rax
   2e909:	74 44                	je     2e94f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd2f>
   2e90b:	44 8b 00             	mov    (%rax),%r8d
   2e90e:	8b 3a                	mov    (%rdx),%edi
   2e910:	be 01 00 00 00       	mov    $0x1,%esi
   2e915:	89 74 24 30          	mov    %esi,0x30(%rsp)
   2e919:	44 89 44 24 34       	mov    %r8d,0x34(%rsp)
   2e91e:	89 7c 24 38          	mov    %edi,0x38(%rsp)
   2e922:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2e927:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e92c:	74 12                	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e92e:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e934:	74 0a                	je     2e940 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xd20>
   2e936:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e93b:	e9 f4 fc ff ff       	jmp    2e634 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xa14>
   2e940:	48 83 c4 78          	add    $0x78,%rsp
   2e944:	5b                   	pop    %rbx
   2e945:	41 5c                	pop    %r12
   2e947:	41 5d                	pop    %r13
   2e949:	41 5e                	pop    %r14
   2e94b:	41 5f                	pop    %r15
   2e94d:	5d                   	pop    %rbp
   2e94e:	c3                   	ret
   2e94f:	31 f6                	xor    %esi,%esi
   2e951:	eb c2                	jmp    2e915 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xcf5>
   2e953:	48 8d 3d da a9 fd ff 	lea    -0x25626(%rip),%rdi        # 9334 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e95a:	48 8d 15 47 20 04 00 	lea    0x42047(%rip),%rdx        # 709a8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6d8>
   2e961:	be 28 00 00 00       	mov    $0x28,%esi
   2e966:	ff 15 54 3c 04 00    	call   *0x43c54(%rip)        # 725c0 <_DYNAMIC+0x3b8>
   2e96c:	49 89 fe             	mov    %rdi,%r14
   2e96f:	ff 15 a3 3e 04 00    	call   *0x43ea3(%rip)        # 72818 <_DYNAMIC+0x610>
   2e975:	4c 89 f7             	mov    %r14,%rdi
   2e978:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e97d:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e982:	e9 3f f4 ff ff       	jmp    2ddc6 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e987:	48 8d 3d a6 a9 fd ff 	lea    -0x2565a(%rip),%rdi        # 9334 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e98e:	48 8d 15 2b 20 04 00 	lea    0x4202b(%rip),%rdx        # 709c0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f0>
   2e995:	be 28 00 00 00       	mov    $0x28,%esi
   2e99a:	ff 15 20 3c 04 00    	call   *0x43c20(%rip)        # 725c0 <_DYNAMIC+0x3b8>
   2e9a0:	48 89 f7             	mov    %rsi,%rdi
   2e9a3:	48 89 f3             	mov    %rsi,%rbx
   2e9a6:	4c 89 fe             	mov    %r15,%rsi
   2e9a9:	4c 89 f2             	mov    %r14,%rdx
   2e9ac:	e8 f7 a9 ff ff       	call   293a8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs29Zh0EKK4Pp_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e9b1:	48 89 d8             	mov    %rbx,%rax
   2e9b4:	e9 b9 f6 ff ff       	jmp    2e072 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e9b9:	48 89 f7             	mov    %rsi,%rdi
   2e9bc:	49 89 f7             	mov    %rsi,%r15
   2e9bf:	48 89 de             	mov    %rbx,%rsi
   2e9c2:	4c 89 f2             	mov    %r14,%rdx
   2e9c5:	e8 de a9 ff ff       	call   293a8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs29Zh0EKK4Pp_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e9ca:	4c 89 f8             	mov    %r15,%rax
   2e9cd:	e9 f0 fb ff ff       	jmp    2e5c2 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0x9a2>
   2e9d2:	48 89 f7             	mov    %rsi,%rdi
   2e9d5:	48 89 f3             	mov    %rsi,%rbx
   2e9d8:	48 89 d6             	mov    %rdx,%rsi
   2e9db:	49 89 d7             	mov    %rdx,%r15
   2e9de:	4c 89 f2             	mov    %r14,%rdx
   2e9e1:	49 89 c4             	mov    %rax,%r12
   2e9e4:	e8 bf a9 ff ff       	call   293a8 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs29Zh0EKK4Pp_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2e9e9:	4c 89 e0             	mov    %r12,%rax
   2e9ec:	4c 89 fa             	mov    %r15,%rdx
   2e9ef:	48 89 de             	mov    %rbx,%rsi
   2e9f2:	e9 be fe ff ff       	jmp    2e8b5 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xc95>
   2e9f7:	49 89 c6             	mov    %rax,%r14
   2e9fa:	eb 6b                	jmp    2ea67 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe47>
   2e9fc:	49 89 c6             	mov    %rax,%r14
   2e9ff:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2ea04:	74 61                	je     2ea67 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe47>
   2ea06:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2ea0c:	74 59                	je     2ea67 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe47>
   2ea0e:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2ea13:	ff 15 e7 39 04 00    	call   *0x439e7(%rip)        # 72400 <free@GLIBC_2.2.5>
   2ea19:	eb 4c                	jmp    2ea67 <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe47>
   2ea1b:	eb 00                	jmp    2ea1d <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xdfd>
   2ea1d:	49 89 c6             	mov    %rax,%r14
   2ea20:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2ea25:	74 48                	je     2ea6f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe4f>
   2ea27:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2ea2d:	74 40                	je     2ea6f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe4f>
   2ea2f:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2ea34:	ff 15 c6 39 04 00    	call   *0x439c6(%rip)        # 72400 <free@GLIBC_2.2.5>
   2ea3a:	4c 89 f7             	mov    %r14,%rdi
   2ea3d:	e8 ee 01 04 00       	call   6ec30 <_Unwind_Resume@plt>
   2ea42:	49 89 c6             	mov    %rax,%r14
   2ea45:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2ea4a:	74 23                	je     2ea6f <_RNCNvCsbcAr0yfpOS5_24pbrs_map_iteration_proof4mains1_0B3_+0xe4f>
   2ea4c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2ea51:	ff 15 a9 39 04 00    	call   *0x439a9(%rip)        # 72400 <free@GLIBC_2.2.5>
   2ea57:	4c 89 f7             	mov    %r14,%rdi
   2ea5a:	e8 d1 01 04 00       	call   6ec30 <_Unwind_Resume@plt>
   2ea5f:	49 89 c6             	mov    %rax,%r14
   2ea62:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
   2ea67:	48 89 df             	mov    %rbx,%rdi
   2ea6a:	e8 b1 b7 ff ff       	call   2a220 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs29Zh0EKK4Pp_4pbrs3map3MapllEECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2ea6f:	4c 89 f7             	mov    %r14,%rdi
   2ea72:	e8 b9 01 04 00       	call   6ec30 <_Unwind_Resume@plt>
   2ea77:	ff 15 2b 3a 04 00    	call   *0x43a2b(%rip)        # 724a8 <_DYNAMIC+0x2a0>
   2ea7d:	49 89 c6             	mov    %rax,%r14
   2ea80:	48 8b 3c 24          	mov    (%rsp),%rdi
   2ea84:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2ea89:	e8 92 b9 ff ff       	call   2a420 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECsbcAr0yfpOS5_24pbrs_map_iteration_proof>
   2ea8e:	4c 89 f7             	mov    %r14,%rdi
   2ea91:	e8 9a 01 04 00       	call   6ec30 <_Unwind_Resume@plt>
