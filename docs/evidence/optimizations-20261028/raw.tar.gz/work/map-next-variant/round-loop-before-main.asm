
work/all-benchmarks/measurement/round-loop-before/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002e6e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main>:
   2e6e0:	55                   	push   %rbp
   2e6e1:	41 57                	push   %r15
   2e6e3:	41 56                	push   %r14
   2e6e5:	41 55                	push   %r13
   2e6e7:	41 54                	push   %r12
   2e6e9:	53                   	push   %rbx
   2e6ea:	48 81 ec 98 02 00 00 	sub    $0x298,%rsp
   2e6f1:	48 89 e7             	mov    %rsp,%rdi
   2e6f4:	ff 15 8e 3c 04 00    	call   *0x43c8e(%rip)        # 72388 <_DYNAMIC+0x610>
   2e6fa:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   2e6ff:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   2e704:	4d 39 fd             	cmp    %r15,%r13
   2e707:	0f 84 1a 4b 00 00    	je     33227 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b47>
   2e70d:	49 8d 6d 18          	lea    0x18(%r13),%rbp
   2e711:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   2e716:	4d 8b 75 00          	mov    0x0(%r13),%r14
   2e71a:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   2e71e:	0f 84 00 4b 00 00    	je     33224 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b44>
   2e724:	49 8b 75 08          	mov    0x8(%r13),%rsi
   2e728:	49 8b 5d 10          	mov    0x10(%r13),%rbx
   2e72c:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2e733:	00 
   2e734:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
   2e739:	48 89 da             	mov    %rbx,%rdx
   2e73c:	ff 15 1e 39 04 00    	call   *0x4391e(%rip)        # 72060 <_DYNAMIC+0x2e8>
   2e742:	83 bc 24 30 01 00 00 	cmpl   $0x1,0x130(%rsp)
   2e749:	01 
   2e74a:	0f 84 5a 4b 00 00    	je     332aa <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4bca>
   2e750:	48 ba f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rdx
   2e757:	ff ff 7f 
   2e75a:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
   2e761:	00 
   2e762:	4c 89 f8             	mov    %r15,%rax
   2e765:	48 29 e8             	sub    %rbp,%rax
   2e768:	48 89 c1             	mov    %rax,%rcx
   2e76b:	48 c1 e9 03          	shr    $0x3,%rcx
   2e76f:	48 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rsi
   2e776:	aa aa aa 
   2e779:	48 0f af ce          	imul   %rsi,%rcx
   2e77d:	48 83 f9 04          	cmp    $0x4,%rcx
   2e781:	41 bf 03 00 00 00    	mov    $0x3,%r15d
   2e787:	4c 0f 43 f9          	cmovae %rcx,%r15
   2e78b:	48 8d 4a ef          	lea    -0x11(%rdx),%rcx
   2e78f:	48 39 c8             	cmp    %rcx,%rax
   2e792:	76 18                	jbe    2e7ac <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xcc>
   2e794:	31 ff                	xor    %edi,%edi
   2e796:	4c 89 e6             	mov    %r12,%rsi
   2e799:	4c 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%r15
   2e7a0:	00 
   2e7a1:	ff 15 c9 37 04 00    	call   *0x437c9(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   2e7a7:	e9 6d 4d 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   2e7ac:	4a 8d 04 fd 08 00 00 	lea    0x8(,%r15,8),%rax
   2e7b3:	00 
   2e7b4:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
   2e7b8:	4d 85 e4             	test   %r12,%r12
   2e7bb:	74 17                	je     2e7d4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf4>
   2e7bd:	4c 89 e7             	mov    %r12,%rdi
   2e7c0:	ff 15 fa 37 04 00    	call   *0x437fa(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2e7c6:	48 85 c0             	test   %rax,%rax
   2e7c9:	0f 84 9c 4b 00 00    	je     3336b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c8b>
   2e7cf:	49 ff c7             	inc    %r15
   2e7d2:	eb 08                	jmp    2e7dc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xfc>
   2e7d4:	b8 08 00 00 00       	mov    $0x8,%eax
   2e7d9:	45 31 ff             	xor    %r15d,%r15d
   2e7dc:	4c 89 30             	mov    %r14,(%rax)
   2e7df:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   2e7e4:	48 89 48 08          	mov    %rcx,0x8(%rax)
   2e7e8:	48 89 58 10          	mov    %rbx,0x10(%rax)
   2e7ec:	4c 89 7c 24 30       	mov    %r15,0x30(%rsp)
   2e7f1:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2e7f6:	48 c7 44 24 40 01 00 	movq   $0x1,0x40(%rsp)
   2e7fd:	00 00 
   2e7ff:	66 0f 10 04 24       	movupd (%rsp),%xmm0
   2e804:	f3 0f 6f 4c 24 10    	movdqu 0x10(%rsp),%xmm1
   2e80a:	66 0f 7f 8c 24 40 01 	movdqa %xmm1,0x140(%rsp)
   2e811:	00 00 
   2e813:	66 0f 29 84 24 30 01 	movapd %xmm0,0x130(%rsp)
   2e81a:	00 00 
   2e81c:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
   2e823:	00 
   2e824:	48 8b ac 24 38 01 00 	mov    0x138(%rsp),%rbp
   2e82b:	00 
   2e82c:	4c 39 e5             	cmp    %r12,%rbp
   2e82f:	0f 84 f1 00 00 00    	je     2e926 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x246>
   2e835:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   2e83c:	00 
   2e83d:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e843:	41 bd 28 00 00 00    	mov    $0x28,%r13d
   2e849:	eb 45                	jmp    2e890 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b0>
   2e84b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2e850:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2e857:	00 
   2e858:	4e 89 7c 28 f0       	mov    %r15,-0x10(%rax,%r13,1)
   2e85d:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   2e862:	4a 89 4c 28 f8       	mov    %rcx,-0x8(%rax,%r13,1)
   2e867:	4a 89 2c 28          	mov    %rbp,(%rax,%r13,1)
   2e86b:	49 ff c6             	inc    %r14
   2e86e:	4c 89 74 24 40       	mov    %r14,0x40(%rsp)
   2e873:	48 8b ac 24 38 01 00 	mov    0x138(%rsp),%rbp
   2e87a:	00 
   2e87b:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
   2e882:	00 
   2e883:	49 83 c5 18          	add    $0x18,%r13
   2e887:	4c 39 e5             	cmp    %r12,%rbp
   2e88a:	0f 84 a1 00 00 00    	je     2e931 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x251>
   2e890:	48 8d 5d 18          	lea    0x18(%rbp),%rbx
   2e894:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
   2e89b:	00 
   2e89c:	4c 8b 7d 00          	mov    0x0(%rbp),%r15
   2e8a0:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
   2e8a4:	0f 84 84 00 00 00    	je     2e92e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x24e>
   2e8aa:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   2e8ae:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
   2e8b2:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   2e8b9:	00 
   2e8ba:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
   2e8bf:	48 89 ea             	mov    %rbp,%rdx
   2e8c2:	ff 15 98 37 04 00    	call   *0x43798(%rip)        # 72060 <_DYNAMIC+0x2e8>
   2e8c8:	83 bc 24 b8 00 00 00 	cmpl   $0x1,0xb8(%rsp)
   2e8cf:	01 
   2e8d0:	0f 84 57 48 00 00    	je     3312d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a4d>
   2e8d6:	4c 3b 74 24 30       	cmp    0x30(%rsp),%r14
   2e8db:	0f 85 6f ff ff ff    	jne    2e850 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x170>
   2e8e1:	49 29 dc             	sub    %rbx,%r12
   2e8e4:	49 c1 ec 03          	shr    $0x3,%r12
   2e8e8:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   2e8ef:	aa aa aa 
   2e8f2:	4c 0f af e0          	imul   %rax,%r12
   2e8f6:	49 ff c4             	inc    %r12
   2e8f9:	b9 08 00 00 00       	mov    $0x8,%ecx
   2e8fe:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   2e904:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2e909:	4c 89 f6             	mov    %r14,%rsi
   2e90c:	4c 89 e2             	mov    %r12,%rdx
   2e90f:	e8 7c e2 ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2e914:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2e919:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   2e920:	00 
   2e921:	e9 2a ff ff ff       	jmp    2e850 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x170>
   2e926:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e92c:	eb 03                	jmp    2e931 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x251>
   2e92e:	48 89 dd             	mov    %rbx,%rbp
   2e931:	4c 89 e0             	mov    %r12,%rax
   2e934:	48 29 e8             	sub    %rbp,%rax
   2e937:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   2e93e:	aa aa aa 
   2e941:	48 f7 e1             	mul    %rcx
   2e944:	49 39 ec             	cmp    %rbp,%r12
   2e947:	4c 8d a4 24 30 01 00 	lea    0x130(%rsp),%r12
   2e94e:	00 
   2e94f:	74 38                	je     2e989 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2a9>
   2e951:	48 89 d3             	mov    %rdx,%rbx
   2e954:	48 c1 eb 04          	shr    $0x4,%rbx
   2e958:	48 83 c5 08          	add    $0x8,%rbp
   2e95c:	4c 8b 3d 45 36 04 00 	mov    0x43645(%rip),%r15        # 71fa8 <free@GLIBC_2.2.5>
   2e963:	eb 14                	jmp    2e979 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x299>
   2e965:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e96c:	00 00 00 00 
   2e970:	48 83 c5 18          	add    $0x18,%rbp
   2e974:	48 ff cb             	dec    %rbx
   2e977:	74 10                	je     2e989 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2a9>
   2e979:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   2e97e:	74 f0                	je     2e970 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x290>
   2e980:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   2e984:	41 ff d7             	call   *%r15
   2e987:	eb e7                	jmp    2e970 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x290>
   2e989:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
   2e990:	00 00 
   2e992:	74 0e                	je     2e9a2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2c2>
   2e994:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   2e99b:	00 
   2e99c:	ff 15 06 36 04 00    	call   *0x43606(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   2e9a2:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2e9a7:	48 89 84 24 18 02 00 	mov    %rax,0x218(%rsp)
   2e9ae:	00 
   2e9af:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2e9b4:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   2e9bb:	00 
   2e9bc:	49 83 fe 06          	cmp    $0x6,%r14
   2e9c0:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2e9c5:	0f 85 af 48 00 00    	jne    3327a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b9a>
   2e9cb:	48 8d 48 30          	lea    0x30(%rax),%rcx
   2e9cf:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   2e9d6:	00 
   2e9d7:	48 89 8c 24 40 02 00 	mov    %rcx,0x240(%rsp)
   2e9de:	00 
   2e9df:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2e9e3:	48 8b 70 70          	mov    0x70(%rax),%rsi
   2e9e7:	48 83 fe 01          	cmp    $0x1,%rsi
   2e9eb:	74 0e                	je     2e9fb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x31b>
   2e9ed:	48 85 f6             	test   %rsi,%rsi
   2e9f0:	0f 84 94 49 00 00    	je     3338a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4caa>
   2e9f6:	0f b6 11             	movzbl (%rcx),%edx
   2e9f9:	eb 17                	jmp    2ea12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x332>
   2e9fb:	0f b6 11             	movzbl (%rcx),%edx
   2e9fe:	b0 01                	mov    $0x1,%al
   2ea00:	83 fa 2b             	cmp    $0x2b,%edx
   2ea03:	0f 84 ae 43 00 00    	je     32db7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d7>
   2ea09:	83 fa 2d             	cmp    $0x2d,%edx
   2ea0c:	0f 84 a5 43 00 00    	je     32db7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d7>
   2ea12:	31 c0                	xor    %eax,%eax
   2ea14:	80 fa 2b             	cmp    $0x2b,%dl
   2ea17:	0f 94 c0             	sete   %al
   2ea1a:	48 89 f2             	mov    %rsi,%rdx
   2ea1d:	48 29 c2             	sub    %rax,%rdx
   2ea20:	48 01 c1             	add    %rax,%rcx
   2ea23:	48 f7 d8             	neg    %rax
   2ea26:	48 83 fa 11          	cmp    $0x11,%rdx
   2ea2a:	73 55                	jae    2ea81 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3a1>
   2ea2c:	48 85 d2             	test   %rdx,%rdx
   2ea2f:	0f 84 a9 00 00 00    	je     2eade <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3fe>
   2ea35:	48 01 c6             	add    %rax,%rsi
   2ea38:	48 f7 de             	neg    %rsi
   2ea3b:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2ea42:	00 00 
   2ea44:	31 c0                	xor    %eax,%eax
   2ea46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2ea4d:	00 00 00 
   2ea50:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2ea54:	83 c2 d0             	add    $0xffffffd0,%edx
   2ea57:	83 fa 09             	cmp    $0x9,%edx
   2ea5a:	0f 87 bf 46 00 00    	ja     3311f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a3f>
   2ea60:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   2ea65:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
   2ea69:	89 d2                	mov    %edx,%edx
   2ea6b:	48 8d 14 7a          	lea    (%rdx,%rdi,2),%rdx
   2ea6f:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   2ea74:	48 ff c0             	inc    %rax
   2ea77:	48 89 f2             	mov    %rsi,%rdx
   2ea7a:	48 01 c2             	add    %rax,%rdx
   2ea7d:	75 d1                	jne    2ea50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x370>
   2ea7f:	eb 66                	jmp    2eae7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x407>
   2ea81:	48 01 c6             	add    %rax,%rsi
   2ea84:	48 f7 de             	neg    %rsi
   2ea87:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2ea8e:	00 00 
   2ea90:	bf 0a 00 00 00       	mov    $0xa,%edi
   2ea95:	45 31 c0             	xor    %r8d,%r8d
   2ea98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ea9f:	00 
   2eaa0:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2eaa5:	48 f7 e7             	mul    %rdi
   2eaa8:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2eaad:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2eab2:	0f 80 f1 42 00 00    	jo     32da9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46c9>
   2eab8:	83 c2 d0             	add    $0xffffffd0,%edx
   2eabb:	83 fa 0a             	cmp    $0xa,%edx
   2eabe:	0f 83 5b 46 00 00    	jae    3311f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a3f>
   2eac4:	89 d0                	mov    %edx,%eax
   2eac6:	48 01 44 24 68       	add    %rax,0x68(%rsp)
   2eacb:	0f 82 e4 42 00 00    	jb     32db5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d5>
   2ead1:	49 ff c0             	inc    %r8
   2ead4:	48 89 f0             	mov    %rsi,%rax
   2ead7:	4c 01 c0             	add    %r8,%rax
   2eada:	75 c4                	jne    2eaa0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3c0>
   2eadc:	eb 09                	jmp    2eae7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x407>
   2eade:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2eae5:	00 00 
   2eae7:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2eaec:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
   2eaf3:	4c 8b 80 88 00 00 00 	mov    0x88(%rax),%r8
   2eafa:	49 83 f8 01          	cmp    $0x1,%r8
   2eafe:	74 0e                	je     2eb0e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x42e>
   2eb00:	4d 85 c0             	test   %r8,%r8
   2eb03:	0f 84 9b 48 00 00    	je     333a4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cc4>
   2eb09:	0f b6 0e             	movzbl (%rsi),%ecx
   2eb0c:	eb 17                	jmp    2eb25 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x445>
   2eb0e:	0f b6 0e             	movzbl (%rsi),%ecx
   2eb11:	b0 01                	mov    $0x1,%al
   2eb13:	83 f9 2b             	cmp    $0x2b,%ecx
   2eb16:	0f 84 b9 42 00 00    	je     32dd5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f5>
   2eb1c:	83 f9 2d             	cmp    $0x2d,%ecx
   2eb1f:	0f 84 b0 42 00 00    	je     32dd5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f5>
   2eb25:	31 c0                	xor    %eax,%eax
   2eb27:	80 f9 2b             	cmp    $0x2b,%cl
   2eb2a:	0f 94 c0             	sete   %al
   2eb2d:	4c 89 c2             	mov    %r8,%rdx
   2eb30:	48 29 c2             	sub    %rax,%rdx
   2eb33:	48 01 c6             	add    %rax,%rsi
   2eb36:	48 f7 d8             	neg    %rax
   2eb39:	48 8d 0d 68 1a 04 00 	lea    0x41a68(%rip),%rcx        # 705a8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x738>
   2eb40:	48 8d 3d 75 a7 fd ff 	lea    -0x2588b(%rip),%rdi        # 92bc <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xc5>
   2eb47:	48 83 fa 11          	cmp    $0x11,%rdx
   2eb4b:	73 4a                	jae    2eb97 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b7>
   2eb4d:	48 85 d2             	test   %rdx,%rdx
   2eb50:	0f 84 3b 48 00 00    	je     33391 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb1>
   2eb56:	49 01 c0             	add    %rax,%r8
   2eb59:	49 f7 d8             	neg    %r8
   2eb5c:	45 31 db             	xor    %r11d,%r11d
   2eb5f:	31 c0                	xor    %eax,%eax
   2eb61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2eb68:	0f 1f 84 00 00 00 00 
   2eb6f:	00 
   2eb70:	0f b6 14 06          	movzbl (%rsi,%rax,1),%edx
   2eb74:	83 c2 d0             	add    $0xffffffd0,%edx
   2eb77:	83 fa 09             	cmp    $0x9,%edx
   2eb7a:	0f 87 98 45 00 00    	ja     33118 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a38>
   2eb80:	4f 8d 0c 9b          	lea    (%r11,%r11,4),%r9
   2eb84:	89 d2                	mov    %edx,%edx
   2eb86:	4e 8d 1c 4a          	lea    (%rdx,%r9,2),%r11
   2eb8a:	48 ff c0             	inc    %rax
   2eb8d:	4c 89 c2             	mov    %r8,%rdx
   2eb90:	48 01 c2             	add    %rax,%rdx
   2eb93:	75 db                	jne    2eb70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x490>
   2eb95:	eb 4f                	jmp    2ebe6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x506>
   2eb97:	49 01 c0             	add    %rax,%r8
   2eb9a:	49 f7 d8             	neg    %r8
   2eb9d:	45 31 db             	xor    %r11d,%r11d
   2eba0:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
   2eba6:	45 31 d2             	xor    %r10d,%r10d
   2eba9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2ebb0:	4c 89 d8             	mov    %r11,%rax
   2ebb3:	49 f7 e1             	mul    %r9
   2ebb6:	42 0f b6 14 16       	movzbl (%rsi,%r10,1),%edx
   2ebbb:	0f 80 06 42 00 00    	jo     32dc7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46e7>
   2ebc1:	83 c2 d0             	add    $0xffffffd0,%edx
   2ebc4:	83 fa 0a             	cmp    $0xa,%edx
   2ebc7:	0f 83 4b 45 00 00    	jae    33118 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a38>
   2ebcd:	49 89 c3             	mov    %rax,%r11
   2ebd0:	89 d0                	mov    %edx,%eax
   2ebd2:	49 01 c3             	add    %rax,%r11
   2ebd5:	0f 82 f8 41 00 00    	jb     32dd3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f3>
   2ebdb:	49 ff c2             	inc    %r10
   2ebde:	4c 89 c0             	mov    %r8,%rax
   2ebe1:	4c 01 d0             	add    %r10,%rax
   2ebe4:	75 ca                	jne    2ebb0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d0>
   2ebe6:	4d 85 db             	test   %r11,%r11
   2ebe9:	0f 84 a2 47 00 00    	je     33391 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb1>
   2ebef:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   2ebf4:	49 8b 40 40          	mov    0x40(%r8),%rax
   2ebf8:	48 8d 0d c1 19 04 00 	lea    0x419c1(%rip),%rcx        # 705c0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   2ebff:	be 39 00 00 00       	mov    $0x39,%esi
   2ec04:	48 8d 3d ce a6 fd ff 	lea    -0x25932(%rip),%rdi        # 92d9 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xe2>
   2ec0b:	48 83 f8 05          	cmp    $0x5,%rax
   2ec0f:	75 1b                	jne    2ec2c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x54c>
   2ec11:	49 8b 40 38          	mov    0x38(%r8),%rax
   2ec15:	ba 70 72 6f 73       	mov    $0x736f7270,%edx
   2ec1a:	33 10                	xor    (%rax),%edx
   2ec1c:	0f b6 40 04          	movzbl 0x4(%rax),%eax
   2ec20:	83 f0 74             	xor    $0x74,%eax
   2ec23:	09 d0                	or     %edx,%eax
   2ec25:	74 24                	je     2ec4b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x56b>
   2ec27:	e9 6a 47 00 00       	jmp    33396 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb6>
   2ec2c:	48 83 f8 04          	cmp    $0x4,%rax
   2ec30:	0f 85 60 47 00 00    	jne    33396 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb6>
   2ec36:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   2ec3b:	49 8b 40 38          	mov    0x38(%r8),%rax
   2ec3f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2ec45:	0f 85 4b 47 00 00    	jne    33396 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb6>
   2ec4b:	49 8b 50 58          	mov    0x58(%r8),%rdx
   2ec4f:	48 8d 0d 82 19 04 00 	lea    0x41982(%rip),%rcx        # 705d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x768>
   2ec56:	be 5b 00 00 00       	mov    $0x5b,%esi
   2ec5b:	48 8d 3d b0 a6 fd ff 	lea    -0x25950(%rip),%rdi        # 9312 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x11b>
   2ec62:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   2ec66:	48 83 fa 04          	cmp    $0x4,%rdx
   2ec6a:	0f 87 26 47 00 00    	ja     33396 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb6>
   2ec70:	49 8b 40 50          	mov    0x50(%r8),%rax
   2ec74:	4c 8d 05 dd a5 fd ff 	lea    -0x25a23(%rip),%r8        # 9258 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x61>
   2ec7b:	49 63 14 90          	movslq (%r8,%rdx,4),%rdx
   2ec7f:	4c 01 c2             	add    %r8,%rdx
   2ec82:	ff e2                	jmp    *%rdx
   2ec84:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2ec8b:	61 6c 6c 
   2ec8e:	48 39 10             	cmp    %rdx,(%rax)
   2ec91:	eb 49                	jmp    2ecdc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5fc>
   2ec93:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2ec9a:	66 69 72 
   2ec9d:	48 33 10             	xor    (%rax),%rdx
   2eca0:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2eca4:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2ecaa:	eb 2d                	jmp    2ecd9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5f9>
   2ecac:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2ecb3:	63 6f 6c 
   2ecb6:	48 33 10             	xor    (%rax),%rdx
   2ecb9:	8b 40 08             	mov    0x8(%rax),%eax
   2ecbc:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2ecc2:	eb 15                	jmp    2ecd9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5f9>
   2ecc4:	48 ba 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rdx
   2eccb:	72 65 61 
   2ecce:	48 33 10             	xor    (%rax),%rdx
   2ecd1:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2ecd5:	48 83 f0 64          	xor    $0x64,%rax
   2ecd9:	48 09 d0             	or     %rdx,%rax
   2ecdc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2ece1:	0f 85 af 46 00 00    	jne    33396 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cb6>
   2ece7:	4c 89 9c 24 70 02 00 	mov    %r11,0x270(%rsp)
   2ecee:	00 
   2ecef:	48 8d 48 48          	lea    0x48(%rax),%rcx
   2ecf3:	48 89 8c 24 30 02 00 	mov    %rcx,0x230(%rsp)
   2ecfa:	00 
   2ecfb:	49 bd 80 80 80 80 80 	movabs $0x8080808080808080,%r13
   2ed02:	80 80 80 
   2ed05:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2ed0c:	5f 5f 5f 
   2ed0f:	49 bc 00 01 01 01 01 	movabs $0x101010101010100,%r12
   2ed16:	01 01 01 
   2ed19:	48 8b 50 20          	mov    0x20(%rax),%rdx
   2ed1d:	48 8b 70 28          	mov    0x28(%rax),%rsi
   2ed21:	48 8d 42 08          	lea    0x8(%rdx),%rax
   2ed25:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   2ed2c:	00 
   2ed2d:	31 ed                	xor    %ebp,%ebp
   2ed2f:	31 c0                	xor    %eax,%eax
   2ed31:	48 89 94 24 a0 00 00 	mov    %rdx,0xa0(%rsp)
   2ed38:	00 
   2ed39:	48 89 74 24 50       	mov    %rsi,0x50(%rsp)
   2ed3e:	eb 1e                	jmp    2ed5e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x67e>
   2ed40:	4c 89 f8             	mov    %r15,%rax
   2ed43:	49 39 f7             	cmp    %rsi,%r15
   2ed46:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2ed4d:	5f 5f 5f 
   2ed50:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   2ed57:	00 
   2ed58:	0f 87 ff 1f 00 00    	ja     30d5d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x267d>
   2ed5e:	48 89 f1             	mov    %rsi,%rcx
   2ed61:	48 29 c1             	sub    %rax,%rcx
   2ed64:	48 01 c2             	add    %rax,%rdx
   2ed67:	48 83 f9 0f          	cmp    $0xf,%rcx
   2ed6b:	77 33                	ja     2eda0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x6c0>
   2ed6d:	b3 01                	mov    $0x1,%bl
   2ed6f:	48 39 c6             	cmp    %rax,%rsi
   2ed72:	0f 84 3d 01 00 00    	je     2eeb5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7d5>
   2ed78:	45 31 f6             	xor    %r14d,%r14d
   2ed7b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2ed80:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2ed85:	0f 84 e5 00 00 00    	je     2ee70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x790>
   2ed8b:	49 ff c6             	inc    %r14
   2ed8e:	4c 39 f1             	cmp    %r14,%rcx
   2ed91:	75 ed                	jne    2ed80 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x6a0>
   2ed93:	e9 1d 01 00 00       	jmp    2eeb5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7d5>
   2ed98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ed9f:	00 
   2eda0:	48 8d 72 07          	lea    0x7(%rdx),%rsi
   2eda4:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   2eda8:	48 29 d6             	sub    %rdx,%rsi
   2edab:	75 53                	jne    2ee00 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x720>
   2edad:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2edb1:	31 f6                	xor    %esi,%esi
   2edb3:	4c 8b 84 24 90 00 00 	mov    0x90(%rsp),%r8
   2edba:	00 
   2edbb:	49 01 c0             	add    %rax,%r8
   2edbe:	66 90                	xchg   %ax,%ax
   2edc0:	4d 8b 4c 30 f8       	mov    -0x8(%r8,%rsi,1),%r9
   2edc5:	4d 89 ca             	mov    %r9,%r10
   2edc8:	49 31 da             	xor    %rbx,%r10
   2edcb:	4d 89 e3             	mov    %r12,%r11
   2edce:	4d 29 d3             	sub    %r10,%r11
   2edd1:	4d 09 cb             	or     %r9,%r11
   2edd4:	4d 8b 0c 30          	mov    (%r8,%rsi,1),%r9
   2edd8:	49 31 d9             	xor    %rbx,%r9
   2eddb:	4d 89 e2             	mov    %r12,%r10
   2edde:	4d 29 ca             	sub    %r9,%r10
   2ede1:	4d 09 ca             	or     %r9,%r10
   2ede4:	4d 21 eb             	and    %r13,%r11
   2ede7:	4d 21 d3             	and    %r10,%r11
   2edea:	4d 39 eb             	cmp    %r13,%r11
   2eded:	75 51                	jne    2ee40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x760>
   2edef:	48 83 c6 10          	add    $0x10,%rsi
   2edf3:	48 39 fe             	cmp    %rdi,%rsi
   2edf6:	76 c8                	jbe    2edc0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x6e0>
   2edf8:	eb 46                	jmp    2ee40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x760>
   2edfa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2ee00:	45 31 f6             	xor    %r14d,%r14d
   2ee03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ee0a:	84 00 00 00 00 00 
   2ee10:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2ee15:	74 59                	je     2ee70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x790>
   2ee17:	49 ff c6             	inc    %r14
   2ee1a:	4c 39 f6             	cmp    %r14,%rsi
   2ee1d:	75 f1                	jne    2ee10 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x730>
   2ee1f:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2ee23:	48 39 fe             	cmp    %rdi,%rsi
   2ee26:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2ee2d:	5f 5f 5f 
   2ee30:	76 81                	jbe    2edb3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x6d3>
   2ee32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ee39:	1f 84 00 00 00 00 00 
   2ee40:	b3 01                	mov    $0x1,%bl
   2ee42:	49 89 f6             	mov    %rsi,%r14
   2ee45:	48 39 f1             	cmp    %rsi,%rcx
   2ee48:	74 6b                	je     2eeb5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7d5>
   2ee4a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2ee50:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2ee55:	74 19                	je     2ee70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x790>
   2ee57:	49 ff c6             	inc    %r14
   2ee5a:	4c 39 f1             	cmp    %r14,%rcx
   2ee5d:	75 f1                	jne    2ee50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x770>
   2ee5f:	eb 54                	jmp    2eeb5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7d5>
   2ee61:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ee68:	0f 1f 84 00 00 00 00 
   2ee6f:	00 
   2ee70:	4d 8d 3c 06          	lea    (%r14,%rax,1),%r15
   2ee74:	49 ff c7             	inc    %r15
   2ee77:	49 01 c6             	add    %rax,%r14
   2ee7a:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   2ee7f:	49 39 f6             	cmp    %rsi,%r14
   2ee82:	0f 83 b8 fe ff ff    	jae    2ed40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x660>
   2ee88:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2ee8f:	00 
   2ee90:	42 80 3c 30 5f       	cmpb   $0x5f,(%rax,%r14,1)
   2ee95:	0f 85 a5 fe ff ff    	jne    2ed40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x660>
   2ee9b:	31 db                	xor    %ebx,%ebx
   2ee9d:	4c 89 fd             	mov    %r15,%rbp
   2eea0:	bf 40 00 00 00       	mov    $0x40,%edi
   2eea5:	ff 15 15 31 04 00    	call   *0x43115(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2eeab:	48 85 c0             	test   %rax,%rax
   2eeae:	75 21                	jne    2eed1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7f1>
   2eeb0:	e9 c1 1e 00 00       	jmp    30d76 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2696>
   2eeb5:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   2eeba:	4d 89 f7             	mov    %r14,%r15
   2eebd:	bf 40 00 00 00       	mov    $0x40,%edi
   2eec2:	ff 15 f8 30 04 00    	call   *0x430f8(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2eec8:	48 85 c0             	test   %rax,%rax
   2eecb:	0f 84 a5 1e 00 00    	je     30d76 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2696>
   2eed1:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   2eed8:	00 
   2eed9:	48 89 08             	mov    %rcx,(%rax)
   2eedc:	4c 89 70 08          	mov    %r14,0x8(%rax)
   2eee0:	48 c7 84 24 30 01 00 	movq   $0x4,0x130(%rsp)
   2eee7:	00 04 00 00 00 
   2eeec:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   2eef3:	00 
   2eef4:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   2eefb:	00 
   2eefc:	48 c7 84 24 40 01 00 	movq   $0x1,0x140(%rsp)
   2ef03:	00 01 00 00 00 
   2ef08:	84 db                	test   %bl,%bl
   2ef0a:	0f 85 1d 44 00 00    	jne    3332d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c4d>
   2ef10:	bb 01 00 00 00       	mov    $0x1,%ebx
   2ef15:	eb 58                	jmp    2ef6f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x88f>
   2ef17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2ef1e:	00 00 
   2ef20:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
   2ef27:	00 
   2ef28:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   2ef2f:	00 
   2ef30:	49 29 ee             	sub    %rbp,%r14
   2ef33:	48 03 ac 24 a0 00 00 	add    0xa0(%rsp),%rbp
   2ef3a:	00 
   2ef3b:	48 89 d8             	mov    %rbx,%rax
   2ef3e:	48 c1 e0 04          	shl    $0x4,%rax
   2ef42:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2ef49:	00 
   2ef4a:	48 89 2c 01          	mov    %rbp,(%rcx,%rax,1)
   2ef4e:	4c 89 74 01 08       	mov    %r14,0x8(%rcx,%rax,1)
   2ef53:	48 ff c3             	inc    %rbx
   2ef56:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
   2ef5d:	00 
   2ef5e:	4c 89 ed             	mov    %r13,%rbp
   2ef61:	80 bc 24 98 01 00 00 	cmpb   $0x0,0x198(%rsp)
   2ef68:	00 
   2ef69:	0f 85 f7 01 00 00    	jne    2f166 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa86>
   2ef6f:	b0 01                	mov    $0x1,%al
   2ef71:	89 84 24 98 01 00 00 	mov    %eax,0x198(%rsp)
   2ef78:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2ef7d:	4c 39 f9             	cmp    %r15,%rcx
   2ef80:	73 0e                	jae    2ef90 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x8b0>
   2ef82:	49 89 ed             	mov    %rbp,%r13
   2ef85:	49 89 ce             	mov    %rcx,%r14
   2ef88:	e9 9e 01 00 00       	jmp    2f12b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa4b>
   2ef8d:	0f 1f 00             	nopl   (%rax)
   2ef90:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2ef97:	5f 5f 5f 
   2ef9a:	eb 1a                	jmp    2efb6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x8d6>
   2ef9c:	0f 1f 40 00          	nopl   0x0(%rax)
   2efa0:	4d 89 ef             	mov    %r13,%r15
   2efa3:	49 39 cd             	cmp    %rcx,%r13
   2efa6:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2efad:	5f 5f 5f 
   2efb0:	0f 87 a8 01 00 00    	ja     2f15e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa7e>
   2efb6:	48 89 c8             	mov    %rcx,%rax
   2efb9:	4c 29 f8             	sub    %r15,%rax
   2efbc:	48 89 ca             	mov    %rcx,%rdx
   2efbf:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   2efc6:	00 
   2efc7:	4c 01 f9             	add    %r15,%rcx
   2efca:	48 83 f8 0f          	cmp    $0xf,%rax
   2efce:	77 30                	ja     2f000 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x920>
   2efd0:	4c 39 fa             	cmp    %r15,%rdx
   2efd3:	0f 84 47 01 00 00    	je     2f120 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa40>
   2efd9:	45 31 f6             	xor    %r14d,%r14d
   2efdc:	0f 1f 40 00          	nopl   0x0(%rax)
   2efe0:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2efe5:	0f 84 f5 00 00 00    	je     2f0e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa00>
   2efeb:	49 ff c6             	inc    %r14
   2efee:	4c 39 f0             	cmp    %r14,%rax
   2eff1:	75 ed                	jne    2efe0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x900>
   2eff3:	e9 28 01 00 00       	jmp    2f120 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa40>
   2eff8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2efff:	00 
   2f000:	48 8d 51 07          	lea    0x7(%rcx),%rdx
   2f004:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
   2f008:	48 29 ca             	sub    %rcx,%rdx
   2f00b:	49 bb 80 80 80 80 80 	movabs $0x8080808080808080,%r11
   2f012:	80 80 80 
   2f015:	75 59                	jne    2f070 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x990>
   2f017:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2f01b:	31 d2                	xor    %edx,%edx
   2f01d:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   2f024:	00 
   2f025:	4c 01 ff             	add    %r15,%rdi
   2f028:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f02f:	00 
   2f030:	4c 8b 44 17 f8       	mov    -0x8(%rdi,%rdx,1),%r8
   2f035:	4d 89 c1             	mov    %r8,%r9
   2f038:	4d 31 f1             	xor    %r14,%r9
   2f03b:	4d 89 e2             	mov    %r12,%r10
   2f03e:	4d 29 ca             	sub    %r9,%r10
   2f041:	4d 09 c2             	or     %r8,%r10
   2f044:	4c 8b 04 17          	mov    (%rdi,%rdx,1),%r8
   2f048:	4d 31 f0             	xor    %r14,%r8
   2f04b:	4d 89 e1             	mov    %r12,%r9
   2f04e:	4d 29 c1             	sub    %r8,%r9
   2f051:	4d 09 c1             	or     %r8,%r9
   2f054:	4d 21 da             	and    %r11,%r10
   2f057:	4d 21 ca             	and    %r9,%r10
   2f05a:	4d 39 da             	cmp    %r11,%r10
   2f05d:	75 51                	jne    2f0b0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x9d0>
   2f05f:	48 83 c2 10          	add    $0x10,%rdx
   2f063:	48 39 f2             	cmp    %rsi,%rdx
   2f066:	76 c8                	jbe    2f030 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x950>
   2f068:	eb 46                	jmp    2f0b0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x9d0>
   2f06a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f070:	45 31 f6             	xor    %r14d,%r14d
   2f073:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f07a:	84 00 00 00 00 00 
   2f080:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2f085:	74 59                	je     2f0e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa00>
   2f087:	49 ff c6             	inc    %r14
   2f08a:	4c 39 f2             	cmp    %r14,%rdx
   2f08d:	75 f1                	jne    2f080 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x9a0>
   2f08f:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2f093:	48 39 f2             	cmp    %rsi,%rdx
   2f096:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2f09d:	5f 5f 5f 
   2f0a0:	0f 86 77 ff ff ff    	jbe    2f01d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x93d>
   2f0a6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2f0ad:	00 00 00 
   2f0b0:	49 89 d6             	mov    %rdx,%r14
   2f0b3:	48 39 d0             	cmp    %rdx,%rax
   2f0b6:	74 68                	je     2f120 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa40>
   2f0b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f0bf:	00 
   2f0c0:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2f0c5:	74 19                	je     2f0e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa00>
   2f0c7:	49 ff c6             	inc    %r14
   2f0ca:	4c 39 f0             	cmp    %r14,%rax
   2f0cd:	75 f1                	jne    2f0c0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x9e0>
   2f0cf:	eb 4f                	jmp    2f120 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa40>
   2f0d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f0d8:	0f 1f 84 00 00 00 00 
   2f0df:	00 
   2f0e0:	4f 8d 2c 3e          	lea    (%r14,%r15,1),%r13
   2f0e4:	49 ff c5             	inc    %r13
   2f0e7:	4d 01 fe             	add    %r15,%r14
   2f0ea:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2f0ef:	49 39 ce             	cmp    %rcx,%r14
   2f0f2:	0f 83 a8 fe ff ff    	jae    2efa0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x8c0>
   2f0f8:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2f0ff:	00 
   2f100:	42 80 3c 30 5f       	cmpb   $0x5f,(%rax,%r14,1)
   2f105:	0f 85 95 fe ff ff    	jne    2efa0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x8c0>
   2f10b:	c7 84 24 98 01 00 00 	movl   $0x0,0x198(%rsp)
   2f112:	00 00 00 00 
   2f116:	4d 89 ef             	mov    %r13,%r15
   2f119:	eb 10                	jmp    2f12b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xa4b>
   2f11b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2f120:	4c 8b 74 24 50       	mov    0x50(%rsp),%r14
   2f125:	4d 89 f7             	mov    %r14,%r15
   2f128:	49 89 ed             	mov    %rbp,%r13
   2f12b:	48 3b 9c 24 30 01 00 	cmp    0x130(%rsp),%rbx
   2f132:	00 
   2f133:	0f 85 f7 fd ff ff    	jne    2ef30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x850>
   2f139:	ba 01 00 00 00       	mov    $0x1,%edx
   2f13e:	b9 08 00 00 00       	mov    $0x8,%ecx
   2f143:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   2f149:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2f150:	00 
   2f151:	48 89 de             	mov    %rbx,%rsi
   2f154:	e8 37 da ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2f159:	e9 c2 fd ff ff       	jmp    2ef20 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x840>
   2f15e:	4d 89 ef             	mov    %r13,%r15
   2f161:	e9 1c fe ff ff       	jmp    2ef82 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x8a2>
   2f166:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
   2f16d:	00 
   2f16e:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   2f175:	00 
   2f176:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   2f17d:	00 
   2f17e:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   2f185:	00 
   2f186:	48 83 fb 03          	cmp    $0x3,%rbx
   2f18a:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
   2f191:	00 
   2f192:	0f 85 ae 41 00 00    	jne    33346 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c66>
   2f198:	48 83 7f 08 03       	cmpq   $0x3,0x8(%rdi)
   2f19d:	0f 85 7c 3d 00 00    	jne    32f1f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x483f>
   2f1a3:	48 8b 07             	mov    (%rdi),%rax
   2f1a6:	0f b7 08             	movzwl (%rax),%ecx
   2f1a9:	81 f1 6d 61 00 00    	xor    $0x616d,%ecx
   2f1af:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   2f1b3:	83 f0 70             	xor    $0x70,%eax
   2f1b6:	66 09 c8             	or     %cx,%ax
   2f1b9:	0f 85 60 3d 00 00    	jne    32f1f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x483f>
   2f1bf:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2f1c3:	48 8b 77 18          	mov    0x18(%rdi),%rsi
   2f1c7:	48 83 fe 01          	cmp    $0x1,%rsi
   2f1cb:	74 0e                	je     2f1db <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xafb>
   2f1cd:	48 85 f6             	test   %rsi,%rsi
   2f1d0:	0f 84 d5 41 00 00    	je     333ab <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ccb>
   2f1d6:	0f b6 11             	movzbl (%rcx),%edx
   2f1d9:	eb 17                	jmp    2f1f2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xb12>
   2f1db:	0f b6 11             	movzbl (%rcx),%edx
   2f1de:	b0 01                	mov    $0x1,%al
   2f1e0:	83 fa 2b             	cmp    $0x2b,%edx
   2f1e3:	0f 84 29 3c 00 00    	je     32e12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4732>
   2f1e9:	83 fa 2d             	cmp    $0x2d,%edx
   2f1ec:	0f 84 20 3c 00 00    	je     32e12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4732>
   2f1f2:	31 c0                	xor    %eax,%eax
   2f1f4:	80 fa 2b             	cmp    $0x2b,%dl
   2f1f7:	0f 94 c0             	sete   %al
   2f1fa:	48 89 f2             	mov    %rsi,%rdx
   2f1fd:	48 29 c2             	sub    %rax,%rdx
   2f200:	48 01 c1             	add    %rax,%rcx
   2f203:	48 f7 d8             	neg    %rax
   2f206:	48 83 fa 11          	cmp    $0x11,%rdx
   2f20a:	73 3b                	jae    2f247 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xb67>
   2f20c:	48 85 d2             	test   %rdx,%rdx
   2f20f:	0f 84 ed 00 00 00    	je     2f302 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xc22>
   2f215:	48 01 c6             	add    %rax,%rsi
   2f218:	48 f7 de             	neg    %rsi
   2f21b:	45 31 e4             	xor    %r12d,%r12d
   2f21e:	31 c0                	xor    %eax,%eax
   2f220:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2f224:	83 c2 d0             	add    $0xffffffd0,%edx
   2f227:	83 fa 09             	cmp    $0x9,%edx
   2f22a:	0f 87 f6 3e 00 00    	ja     33126 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a46>
   2f230:	4b 8d 3c a4          	lea    (%r12,%r12,4),%rdi
   2f234:	89 d2                	mov    %edx,%edx
   2f236:	4c 8d 24 7a          	lea    (%rdx,%rdi,2),%r12
   2f23a:	48 ff c0             	inc    %rax
   2f23d:	48 89 f2             	mov    %rsi,%rdx
   2f240:	48 01 c2             	add    %rax,%rdx
   2f243:	75 db                	jne    2f220 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xb40>
   2f245:	eb 4f                	jmp    2f296 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xbb6>
   2f247:	48 01 c6             	add    %rax,%rsi
   2f24a:	48 f7 de             	neg    %rsi
   2f24d:	45 31 e4             	xor    %r12d,%r12d
   2f250:	bf 0a 00 00 00       	mov    $0xa,%edi
   2f255:	45 31 c0             	xor    %r8d,%r8d
   2f258:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f25f:	00 
   2f260:	4c 89 e0             	mov    %r12,%rax
   2f263:	48 f7 e7             	mul    %rdi
   2f266:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2f26b:	0f 80 93 3b 00 00    	jo     32e04 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4724>
   2f271:	83 c2 d0             	add    $0xffffffd0,%edx
   2f274:	83 fa 0a             	cmp    $0xa,%edx
   2f277:	0f 83 a9 3e 00 00    	jae    33126 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a46>
   2f27d:	49 89 c4             	mov    %rax,%r12
   2f280:	89 d0                	mov    %edx,%eax
   2f282:	49 01 c4             	add    %rax,%r12
   2f285:	0f 82 85 3b 00 00    	jb     32e10 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4730>
   2f28b:	49 ff c0             	inc    %r8
   2f28e:	48 89 f0             	mov    %rsi,%rax
   2f291:	4c 01 c0             	add    %r8,%rax
   2f294:	75 ca                	jne    2f260 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xb80>
   2f296:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f29d:	00 
   2f29e:	48 8b 40 28          	mov    0x28(%rax),%rax
   2f2a2:	48 83 f8 0d          	cmp    $0xd,%rax
   2f2a6:	74 6f                	je     2f317 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xc37>
   2f2a8:	48 83 f8 09          	cmp    $0x9,%rax
   2f2ac:	75 3d                	jne    2f2eb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xc0b>
   2f2ae:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2f2b5:	00 
   2f2b6:	48 8b 49 20          	mov    0x20(%rcx),%rcx
   2f2ba:	48 ba 64 75 70 6c 69 	movabs $0x746163696c707564,%rdx
   2f2c1:	63 61 74 
   2f2c4:	48 33 11             	xor    (%rcx),%rdx
   2f2c7:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
   2f2cb:	48 83 f1 65          	xor    $0x65,%rcx
   2f2cf:	48 09 d1             	or     %rdx,%rcx
   2f2d2:	40 0f 94 c5          	sete   %bpl
   2f2d6:	c7 84 24 9c 00 00 00 	movl   $0x0,0x9c(%rsp)
   2f2dd:	00 00 00 00 
   2f2e1:	40 84 ed             	test   %bpl,%bpl
   2f2e4:	74 6c                	je     2f352 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xc72>
   2f2e6:	e9 9a 00 00 00       	jmp    2f385 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xca5>
   2f2eb:	31 ed                	xor    %ebp,%ebp
   2f2ed:	c7 84 24 9c 00 00 00 	movl   $0x0,0x9c(%rsp)
   2f2f4:	00 00 00 00 
   2f2f8:	40 84 ed             	test   %bpl,%bpl
   2f2fb:	74 55                	je     2f352 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xc72>
   2f2fd:	e9 83 00 00 00       	jmp    2f385 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xca5>
   2f302:	45 31 e4             	xor    %r12d,%r12d
   2f305:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f30c:	00 
   2f30d:	48 8b 40 28          	mov    0x28(%rax),%rax
   2f311:	48 83 f8 0d          	cmp    $0xd,%rax
   2f315:	75 91                	jne    2f2a8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xbc8>
   2f317:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2f31e:	00 
   2f31f:	48 8b 49 20          	mov    0x20(%rcx),%rcx
   2f323:	48 ba 66 69 72 73 74 	movabs $0x7275737473726966,%rdx
   2f32a:	73 75 72 
   2f32d:	48 33 11             	xor    (%rcx),%rdx
   2f330:	48 be 73 75 72 76 69 	movabs $0x7365766976727573,%rsi
   2f337:	76 65 73 
   2f33a:	48 33 71 05          	xor    0x5(%rcx),%rsi
   2f33e:	48 09 d6             	or     %rdx,%rsi
   2f341:	0f 94 c1             	sete   %cl
   2f344:	89 8c 24 9c 00 00 00 	mov    %ecx,0x9c(%rsp)
   2f34b:	31 ed                	xor    %ebp,%ebp
   2f34d:	40 84 ed             	test   %bpl,%bpl
   2f350:	75 33                	jne    2f385 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xca5>
   2f352:	80 bc 24 9c 00 00 00 	cmpb   $0x0,0x9c(%rsp)
   2f359:	00 
   2f35a:	75 29                	jne    2f385 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xca5>
   2f35c:	48 83 f8 08          	cmp    $0x8,%rax
   2f360:	0f 85 f4 3b 00 00    	jne    32f5a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x487a>
   2f366:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f36d:	00 
   2f36e:	48 8b 40 20          	mov    0x20(%rax),%rax
   2f372:	48 b9 64 69 73 74 69 	movabs $0x74636e6974736964,%rcx
   2f379:	6e 63 74 
   2f37c:	48 39 08             	cmp    %rcx,(%rax)
   2f37f:	0f 85 d5 3b 00 00    	jne    32f5a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x487a>
   2f385:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
   2f38c:	00 00 00 00 00 
   2f391:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2f398:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2f39d:	0f 85 d5 3b 00 00    	jne    32f78 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4898>
   2f3a3:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2f3a7:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2f3ac:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2f3b0:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2f3b4:	0f 10 05 95 0f 04 00 	movups 0x40f95(%rip),%xmm0        # 70350 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2f3bb:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   2f3c2:	00 
   2f3c3:	66 0f 10 05 95 0f 04 	movupd 0x40f95(%rip),%xmm0        # 70360 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2f3ca:	00 
   2f3cb:	66 0f 29 84 24 40 01 	movapd %xmm0,0x140(%rsp)
   2f3d2:	00 00 
   2f3d4:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   2f3db:	00 
   2f3dc:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
   2f3e3:	00 
   2f3e4:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
   2f3eb:	00 00 00 00 00 
   2f3f0:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
   2f3f7:	00 00 00 00 00 
   2f3fc:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
   2f403:	00 00 00 00 00 
   2f408:	48 c7 84 24 88 01 00 	movq   $0x1,0x188(%rsp)
   2f40f:	00 01 00 00 00 
   2f414:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
   2f41b:	00 00 00 00 00 
   2f420:	48 c7 84 24 a0 01 00 	movq   $0x0,0x1a0(%rsp)
   2f427:	00 00 00 00 00 
   2f42c:	48 c7 84 24 a8 01 00 	movq   $0x4,0x1a8(%rsp)
   2f433:	00 04 00 00 00 
   2f438:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
   2f43f:	00 00 00 00 00 
   2f444:	40 84 ed             	test   %bpl,%bpl
   2f447:	74 0b                	je     2f454 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xd74>
   2f449:	49 8d 74 24 03       	lea    0x3(%r12),%rsi
   2f44e:	48 c1 ee 02          	shr    $0x2,%rsi
   2f452:	eb 20                	jmp    2f474 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xd94>
   2f454:	4c 89 e6             	mov    %r12,%rsi
   2f457:	80 bc 24 9c 00 00 00 	cmpb   $0x0,0x9c(%rsp)
   2f45e:	00 
   2f45f:	74 13                	je     2f474 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xd94>
   2f461:	49 8d 74 24 03       	lea    0x3(%r12),%rsi
   2f466:	48 c1 ee 02          	shr    $0x2,%rsi
   2f46a:	48 ff c6             	inc    %rsi
   2f46d:	49 39 f4             	cmp    %rsi,%r12
   2f470:	49 0f 42 f4          	cmovb  %r12,%rsi
   2f474:	4d 85 e4             	test   %r12,%r12
   2f477:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
   2f47e:	00 
   2f47f:	0f 84 31 0c 00 00    	je     300b6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x19d6>
   2f485:	89 ac 24 4c 02 00 00 	mov    %ebp,0x24c(%rsp)
   2f48c:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
   2f490:	48 89 84 24 60 02 00 	mov    %rax,0x260(%rsp)
   2f497:	00 
   2f498:	45 31 f6             	xor    %r14d,%r14d
   2f49b:	48 8d 05 96 12 04 00 	lea    0x41296(%rip),%rax        # 70738 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8c8>
   2f4a2:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   2f4a9:	00 
   2f4aa:	45 31 ed             	xor    %r13d,%r13d
   2f4ad:	45 31 ff             	xor    %r15d,%r15d
   2f4b0:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
   2f4b7:	00 00 00 00 00 
   2f4bc:	48 89 b4 24 78 02 00 	mov    %rsi,0x278(%rsp)
   2f4c3:	00 
   2f4c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f4cb:	00 00 00 00 00 
   2f4d0:	49 8d 46 01          	lea    0x1(%r14),%rax
   2f4d4:	48 39 f0             	cmp    %rsi,%rax
   2f4d7:	b9 00 00 00 00       	mov    $0x0,%ecx
   2f4dc:	48 0f 45 c8          	cmovne %rax,%rcx
   2f4e0:	80 bc 24 4c 02 00 00 	cmpb   $0x0,0x24c(%rsp)
   2f4e7:	00 
   2f4e8:	48 89 8c 24 98 01 00 	mov    %rcx,0x198(%rsp)
   2f4ef:	00 
   2f4f0:	74 2e                	je     2f520 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xe40>
   2f4f2:	48 85 f6             	test   %rsi,%rsi
   2f4f5:	0f 84 94 3c 00 00    	je     3318f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4aaf>
   2f4fb:	4c 89 e8             	mov    %r13,%rax
   2f4fe:	48 09 f0             	or     %rsi,%rax
   2f501:	48 c1 e8 20          	shr    $0x20,%rax
   2f505:	0f 85 95 00 00 00    	jne    2f5a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xec0>
   2f50b:	44 89 e8             	mov    %r13d,%eax
   2f50e:	31 d2                	xor    %edx,%edx
   2f510:	f7 f6                	div    %esi
   2f512:	41 89 d6             	mov    %edx,%r14d
   2f515:	e9 86 00 00 00       	jmp    2f5a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xec0>
   2f51a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f520:	80 bc 24 9c 00 00 00 	cmpb   $0x0,0x9c(%rsp)
   2f527:	00 
   2f528:	74 36                	je     2f560 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xe80>
   2f52a:	4d 85 ed             	test   %r13,%r13
   2f52d:	48 8b bc 24 60 02 00 	mov    0x260(%rsp),%rdi
   2f534:	00 
   2f535:	74 49                	je     2f580 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xea0>
   2f537:	48 85 ff             	test   %rdi,%rdi
   2f53a:	0f 84 5e 3c 00 00    	je     3319e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4abe>
   2f540:	49 8d 45 ff          	lea    -0x1(%r13),%rax
   2f544:	48 89 c1             	mov    %rax,%rcx
   2f547:	48 09 f9             	or     %rdi,%rcx
   2f54a:	48 c1 e9 20          	shr    $0x20,%rcx
   2f54e:	74 3f                	je     2f58f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xeaf>
   2f550:	31 d2                	xor    %edx,%edx
   2f552:	48 f7 f7             	div    %rdi
   2f555:	49 89 d6             	mov    %rdx,%r14
   2f558:	eb 3c                	jmp    2f596 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xeb6>
   2f55a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f560:	4c 89 e8             	mov    %r13,%rax
   2f563:	48 c1 e0 04          	shl    $0x4,%rax
   2f567:	4c 01 e8             	add    %r13,%rax
   2f56a:	48 89 c1             	mov    %rax,%rcx
   2f56d:	4c 09 e1             	or     %r12,%rcx
   2f570:	48 c1 e9 20          	shr    $0x20,%rcx
   2f574:	74 0f                	je     2f585 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xea5>
   2f576:	31 d2                	xor    %edx,%edx
   2f578:	49 f7 f4             	div    %r12
   2f57b:	49 89 d6             	mov    %rdx,%r14
   2f57e:	eb 20                	jmp    2f5a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xec0>
   2f580:	45 31 f6             	xor    %r14d,%r14d
   2f583:	eb 1b                	jmp    2f5a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xec0>
   2f585:	31 d2                	xor    %edx,%edx
   2f587:	41 f7 f4             	div    %r12d
   2f58a:	41 89 d6             	mov    %edx,%r14d
   2f58d:	eb 11                	jmp    2f5a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xec0>
   2f58f:	31 d2                	xor    %edx,%edx
   2f591:	f7 f7                	div    %edi
   2f593:	41 89 d6             	mov    %edx,%r14d
   2f596:	49 ff c6             	inc    %r14
   2f599:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2f5a0:	42 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%edx
   2f5a7:	00 
   2f5a8:	44 29 ea             	sub    %r13d,%edx
   2f5ab:	83 c2 03             	add    $0x3,%edx
   2f5ae:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   2f5b5:	00 
   2f5b6:	44 89 f6             	mov    %r14d,%esi
   2f5b9:	89 94 24 a0 00 00 00 	mov    %edx,0xa0(%rsp)
   2f5c0:	e8 fb 5a 00 00       	call   350c0 <_RNvMso_NtCse9VFdDP9LWm_4pbrs3mapINtB5_3MapllE10push_entryCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2f5c5:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2f5cc:	00 
   2f5cd:	44 89 f6             	mov    %r14d,%esi
   2f5d0:	8b 94 24 a0 00 00 00 	mov    0xa0(%rsp),%edx
   2f5d7:	e8 84 45 00 00       	call   33b60 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   2f5dc:	4c 89 6c 24 50       	mov    %r13,0x50(%rsp)
   2f5e1:	4d 85 ff             	test   %r15,%r15
   2f5e4:	0f 84 c6 00 00 00    	je     2f6b0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xfd0>
   2f5ea:	48 89 e8             	mov    %rbp,%rax
   2f5ed:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
   2f5f4:	00 
   2f5f5:	4c 89 fb             	mov    %r15,%rbx
   2f5f8:	44 0f b7 7b 62       	movzwl 0x62(%rbx),%r15d
   2f5fd:	4d 89 fd             	mov    %r15,%r13
   2f600:	45 85 ff             	test   %r15d,%r15d
   2f603:	74 42                	je     2f647 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf67>
   2f605:	44 89 f9             	mov    %r15d,%ecx
   2f608:	c1 e1 02             	shl    $0x2,%ecx
   2f60b:	45 31 ed             	xor    %r13d,%r13d
   2f60e:	66 90                	xchg   %ax,%ax
   2f610:	46 3b 74 ab 08       	cmp    0x8(%rbx,%r13,4),%r14d
   2f615:	40 0f 9c c6          	setl   %sil
   2f619:	0f 9f c2             	setg   %dl
   2f61c:	40 28 f2             	sub    %sil,%dl
   2f61f:	80 fa 01             	cmp    $0x1,%dl
   2f622:	75 1c                	jne    2f640 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf60>
   2f624:	49 ff c5             	inc    %r13
   2f627:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
   2f62b:	75 e3                	jne    2f610 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf30>
   2f62d:	4d 89 fd             	mov    %r15,%r13
   2f630:	eb 15                	jmp    2f647 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf67>
   2f632:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f639:	1f 84 00 00 00 00 00 
   2f640:	0f b6 ca             	movzbl %dl,%ecx
   2f643:	85 c9                	test   %ecx,%ecx
   2f645:	74 29                	je     2f670 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf90>
   2f647:	48 83 e8 01          	sub    $0x1,%rax
   2f64b:	0f 82 94 01 00 00    	jb     2f7e5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1105>
   2f651:	4a 8b 5c eb 68       	mov    0x68(%rbx,%r13,8),%rbx
   2f656:	44 0f b7 7b 62       	movzwl 0x62(%rbx),%r15d
   2f65b:	4d 89 fd             	mov    %r15,%r13
   2f65e:	45 85 ff             	test   %r15d,%r15d
   2f661:	75 a2                	jne    2f605 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf25>
   2f663:	eb e2                	jmp    2f647 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xf67>
   2f665:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f66c:	00 00 00 00 
   2f670:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
   2f677:	42 89 44 ab 34       	mov    %eax,0x34(%rbx,%r13,4)
   2f67c:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2f683:	00 
   2f684:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2f689:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   2f690:	00 
   2f691:	48 3b 9c 24 a0 01 00 	cmp    0x1a0(%rsp),%rbx
   2f698:	00 
   2f699:	0f 84 9a 00 00 00    	je     2f739 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1059>
   2f69f:	e9 a3 00 00 00       	jmp    2f747 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1067>
   2f6a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f6ab:	00 00 00 00 00 
   2f6b0:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2f6b6:	bf 68 00 00 00       	mov    $0x68,%edi
   2f6bb:	ff 15 ff 28 04 00    	call   *0x428ff(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2f6c1:	48 85 c0             	test   %rax,%rax
   2f6c4:	0f 84 af 37 00 00    	je     32e79 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4799>
   2f6ca:	49 89 c7             	mov    %rax,%r15
   2f6cd:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f6d4:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
   2f6db:	00 
   2f6dc:	48 c7 84 24 e0 01 00 	movq   $0x0,0x1e0(%rsp)
   2f6e3:	00 00 00 00 00 
   2f6e8:	66 c7 40 62 01 00    	movw   $0x1,0x62(%rax)
   2f6ee:	44 89 70 08          	mov    %r14d,0x8(%rax)
   2f6f2:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
   2f6f9:	41 89 47 34          	mov    %eax,0x34(%r15)
   2f6fd:	31 ed                	xor    %ebp,%ebp
   2f6ff:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   2f706:	00 
   2f707:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2f70c:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
   2f713:	00 
   2f714:	48 ff c1             	inc    %rcx
   2f717:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
   2f71e:	00 
   2f71f:	48 89 8c 24 e8 01 00 	mov    %rcx,0x1e8(%rsp)
   2f726:	00 
   2f727:	48 8b 9c 24 b0 01 00 	mov    0x1b0(%rsp),%rbx
   2f72e:	00 
   2f72f:	48 3b 9c 24 a0 01 00 	cmp    0x1a0(%rsp),%rbx
   2f736:	00 
   2f737:	75 0e                	jne    2f747 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1067>
   2f739:	48 8d bc 24 a0 01 00 	lea    0x1a0(%rsp),%rdi
   2f740:	00 
   2f741:	ff 15 19 2c 04 00    	call   *0x42c19(%rip)        # 72360 <_DYNAMIC+0x5e8>
   2f747:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
   2f74e:	00 
   2f74f:	44 89 34 d8          	mov    %r14d,(%rax,%rbx,8)
   2f753:	8b 8c 24 a0 00 00 00 	mov    0xa0(%rsp),%ecx
   2f75a:	89 4c d8 04          	mov    %ecx,0x4(%rax,%rbx,8)
   2f75e:	48 ff c3             	inc    %rbx
   2f761:	48 89 9c 24 b0 01 00 	mov    %rbx,0x1b0(%rsp)
   2f768:	00 
   2f769:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
   2f770:	00 
   2f771:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   2f778:	00 
   2f779:	48 89 c1             	mov    %rax,%rcx
   2f77c:	48 29 f1             	sub    %rsi,%rcx
   2f77f:	48 83 f9 03          	cmp    $0x3,%rcx
   2f783:	0f 86 c9 08 00 00    	jbe    30052 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1972>
   2f789:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   2f790:	00 
   2f791:	44 89 34 31          	mov    %r14d,(%rcx,%rsi,1)
   2f795:	48 83 c6 04          	add    $0x4,%rsi
   2f799:	48 89 b4 24 90 01 00 	mov    %rsi,0x190(%rsp)
   2f7a0:	00 
   2f7a1:	48 29 f0             	sub    %rsi,%rax
   2f7a4:	48 83 f8 03          	cmp    $0x3,%rax
   2f7a8:	0f 86 d6 08 00 00    	jbe    30084 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x19a4>
   2f7ae:	49 ff c5             	inc    %r13
   2f7b1:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
   2f7b8:	89 04 31             	mov    %eax,(%rcx,%rsi,1)
   2f7bb:	48 83 c6 04          	add    $0x4,%rsi
   2f7bf:	48 89 b4 24 90 01 00 	mov    %rsi,0x190(%rsp)
   2f7c6:	00 
   2f7c7:	4c 8b b4 24 98 01 00 	mov    0x198(%rsp),%r14
   2f7ce:	00 
   2f7cf:	4d 39 e5             	cmp    %r12,%r13
   2f7d2:	48 8b b4 24 78 02 00 	mov    0x278(%rsp),%rsi
   2f7d9:	00 
   2f7da:	0f 85 f0 fc ff ff    	jne    2f4d0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xdf0>
   2f7e0:	e9 e0 08 00 00       	jmp    300c5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x19e5>
   2f7e5:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f7e9:	66 41 83 ff 0b       	cmp    $0xb,%r15w
   2f7ee:	73 6b                	jae    2f85b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x117b>
   2f7f0:	4d 39 ef             	cmp    %r13,%r15
   2f7f3:	76 40                	jbe    2f835 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1155>
   2f7f5:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2f7f9:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2f7fd:	48 83 c7 04          	add    $0x4,%rdi
   2f801:	45 89 fc             	mov    %r15d,%r12d
   2f804:	45 29 ec             	sub    %r13d,%r12d
   2f807:	41 c1 e4 02          	shl    $0x2,%r12d
   2f80b:	4c 89 e2             	mov    %r12,%rdx
   2f80e:	ff 15 24 28 04 00    	call   *0x42824(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2f814:	4a 8d 34 ab          	lea    (%rbx,%r13,4),%rsi
   2f818:	48 83 c6 34          	add    $0x34,%rsi
   2f81c:	4a 8d 3c ab          	lea    (%rbx,%r13,4),%rdi
   2f820:	48 83 c7 38          	add    $0x38,%rdi
   2f824:	4c 89 e2             	mov    %r12,%rdx
   2f827:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   2f82e:	00 
   2f82f:	ff 15 03 28 04 00    	call   *0x42803(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2f835:	46 89 74 ab 08       	mov    %r14d,0x8(%rbx,%r13,4)
   2f83a:	41 8d 47 01          	lea    0x1(%r15),%eax
   2f83e:	8b 8c 24 a0 00 00 00 	mov    0xa0(%rsp),%ecx
   2f845:	42 89 4c ab 34       	mov    %ecx,0x34(%rbx,%r13,4)
   2f84a:	66 89 43 62          	mov    %ax,0x62(%rbx)
   2f84e:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2f855:	00 
   2f856:	e9 ac fe ff ff       	jmp    2f707 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1027>
   2f85b:	49 83 fd 05          	cmp    $0x5,%r13
   2f85f:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
   2f866:	00 
   2f867:	73 10                	jae    2f879 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1199>
   2f869:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2f86f:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
   2f876:	00 
   2f877:	eb 36                	jmp    2f8af <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x11cf>
   2f879:	74 17                	je     2f892 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x11b2>
   2f87b:	49 83 fd 06          	cmp    $0x6,%r13
   2f87f:	75 1e                	jne    2f89f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x11bf>
   2f881:	41 bf 05 00 00 00    	mov    $0x5,%r15d
   2f887:	b0 01                	mov    $0x1,%al
   2f889:	89 44 24 60          	mov    %eax,0x60(%rsp)
   2f88d:	45 31 ed             	xor    %r13d,%r13d
   2f890:	eb 1d                	jmp    2f8af <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x11cf>
   2f892:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
   2f899:	00 
   2f89a:	4d 89 ef             	mov    %r13,%r15
   2f89d:	eb 10                	jmp    2f8af <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x11cf>
   2f89f:	49 83 c5 f9          	add    $0xfffffffffffffff9,%r13
   2f8a3:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   2f8a9:	b0 01                	mov    $0x1,%al
   2f8ab:	89 44 24 60          	mov    %eax,0x60(%rsp)
   2f8af:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2f8b5:	bf 68 00 00 00       	mov    $0x68,%edi
   2f8ba:	ff 15 00 27 04 00    	call   *0x42700(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2f8c0:	48 85 c0             	test   %rax,%rax
   2f8c3:	0f 84 b0 35 00 00    	je     32e79 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4799>
   2f8c9:	48 89 c5             	mov    %rax,%rbp
   2f8cc:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f8d3:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f8d7:	4d 89 fc             	mov    %r15,%r12
   2f8da:	49 f7 d4             	not    %r12
   2f8dd:	49 01 c4             	add    %rax,%r12
   2f8e0:	66 44 89 65 62       	mov    %r12w,0x62(%rbp)
   2f8e5:	49 83 fc 0c          	cmp    $0xc,%r12
   2f8e9:	0f 83 3a 36 00 00    	jae    32f29 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4849>
   2f8ef:	42 8b 44 bb 08       	mov    0x8(%rbx,%r15,4),%eax
   2f8f4:	89 84 24 7c 01 00 00 	mov    %eax,0x17c(%rsp)
   2f8fb:	42 8b 44 bb 34       	mov    0x34(%rbx,%r15,4),%eax
   2f900:	89 84 24 78 01 00 00 	mov    %eax,0x178(%rsp)
   2f907:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f90b:	4a 8d 34 b8          	lea    (%rax,%r15,4),%rsi
   2f90f:	48 83 c6 04          	add    $0x4,%rsi
   2f913:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
   2f917:	49 c1 e4 02          	shl    $0x2,%r12
   2f91b:	4c 89 e2             	mov    %r12,%rdx
   2f91e:	ff 15 6c 26 04 00    	call   *0x4266c(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   2f924:	4a 8d 34 bb          	lea    (%rbx,%r15,4),%rsi
   2f928:	48 83 c6 38          	add    $0x38,%rsi
   2f92c:	48 8d 7d 34          	lea    0x34(%rbp),%rdi
   2f930:	4c 89 e2             	mov    %r12,%rdx
   2f933:	ff 15 57 26 04 00    	call   *0x42657(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   2f939:	66 44 89 7b 62       	mov    %r15w,0x62(%rbx)
   2f93e:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   2f943:	49 89 ef             	mov    %rbp,%r15
   2f946:	4c 0f 44 fb          	cmove  %rbx,%r15
   2f94a:	45 0f b7 67 62       	movzwl 0x62(%r15),%r12d
   2f94f:	4d 39 ec             	cmp    %r13,%r12
   2f952:	76 3f                	jbe    2f993 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x12b3>
   2f954:	49 8d 47 08          	lea    0x8(%r15),%rax
   2f958:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2f95c:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2f960:	48 83 c7 04          	add    $0x4,%rdi
   2f964:	44 89 e2             	mov    %r12d,%edx
   2f967:	44 29 ea             	sub    %r13d,%edx
   2f96a:	c1 e2 02             	shl    $0x2,%edx
   2f96d:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   2f972:	ff 15 c0 26 04 00    	call   *0x426c0(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2f978:	4b 8d 34 af          	lea    (%r15,%r13,4),%rsi
   2f97c:	48 83 c6 34          	add    $0x34,%rsi
   2f980:	4b 8d 3c af          	lea    (%r15,%r13,4),%rdi
   2f984:	48 83 c7 38          	add    $0x38,%rdi
   2f988:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   2f98d:	ff 15 a5 26 04 00    	call   *0x426a5(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2f993:	47 89 74 af 08       	mov    %r14d,0x8(%r15,%r13,4)
   2f998:	41 ff c4             	inc    %r12d
   2f99b:	8b 84 24 a0 00 00 00 	mov    0xa0(%rsp),%eax
   2f9a2:	43 89 44 af 34       	mov    %eax,0x34(%r15,%r13,4)
   2f9a7:	66 45 89 67 62       	mov    %r12w,0x62(%r15)
   2f9ac:	48 8b 03             	mov    (%rbx),%rax
   2f9af:	31 c9                	xor    %ecx,%ecx
   2f9b1:	48 85 c0             	test   %rax,%rax
   2f9b4:	0f 84 54 04 00 00    	je     2fe0e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x172e>
   2f9ba:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2f9c1:	00 
   2f9c2:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2f9c7:	eb 2b                	jmp    2f9f4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1314>
   2f9c9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2f9d0:	48 8b 8c 24 68 02 00 	mov    0x268(%rsp),%rcx
   2f9d7:	00 
   2f9d8:	48 ff c1             	inc    %rcx
   2f9db:	48 8b 03             	mov    (%rbx),%rax
   2f9de:	48 85 c0             	test   %rax,%rax
   2f9e1:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2f9e8:	00 
   2f9e9:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2f9ee:	0f 84 27 04 00 00    	je     2fe1b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x173b>
   2f9f4:	8b b4 24 78 01 00 00 	mov    0x178(%rsp),%esi
   2f9fb:	8b bc 24 7c 01 00 00 	mov    0x17c(%rsp),%edi
   2fa02:	44 0f b7 4b 60       	movzwl 0x60(%rbx),%r9d
   2fa07:	48 89 c3             	mov    %rax,%rbx
   2fa0a:	44 0f b7 50 62       	movzwl 0x62(%rax),%r10d
   2fa0f:	49 83 fa 0b          	cmp    $0xb,%r10
   2fa13:	48 89 ac 24 38 02 00 	mov    %rbp,0x238(%rsp)
   2fa1a:	00 
   2fa1b:	89 b4 24 74 01 00 00 	mov    %esi,0x174(%rsp)
   2fa22:	89 bc 24 70 01 00 00 	mov    %edi,0x170(%rsp)
   2fa29:	4c 89 94 24 28 02 00 	mov    %r10,0x228(%rsp)
   2fa30:	00 
   2fa31:	0f 82 88 04 00 00    	jb     2febf <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x17df>
   2fa37:	66 41 83 f9 05       	cmp    $0x5,%r9w
   2fa3c:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
   2fa43:	00 
   2fa44:	73 1a                	jae    2fa60 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1380>
   2fa46:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2fa4b:	b8 04 00 00 00       	mov    $0x4,%eax
   2fa50:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   2fa57:	00 
   2fa58:	45 31 ff             	xor    %r15d,%r15d
   2fa5b:	eb 63                	jmp    2fac0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x13e0>
   2fa5d:	0f 1f 00             	nopl   (%rax)
   2fa60:	49 83 f9 05          	cmp    $0x5,%r9
   2fa64:	74 21                	je     2fa87 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x13a7>
   2fa66:	41 83 f9 06          	cmp    $0x6,%r9d
   2fa6a:	75 2d                	jne    2fa99 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x13b9>
   2fa6c:	41 b7 01             	mov    $0x1,%r15b
   2fa6f:	b8 05 00 00 00       	mov    $0x5,%eax
   2fa74:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   2fa7b:	00 
   2fa7c:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
   2fa83:	00 00 
   2fa85:	eb 39                	jmp    2fac0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x13e0>
   2fa87:	45 31 ff             	xor    %r15d,%r15d
   2fa8a:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2fa8f:	4c 89 8c 24 60 01 00 	mov    %r9,0x160(%rsp)
   2fa96:	00 
   2fa97:	eb 27                	jmp    2fac0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x13e0>
   2fa99:	49 83 c1 f9          	add    $0xfffffffffffffff9,%r9
   2fa9d:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2faa2:	41 b7 01             	mov    $0x1,%r15b
   2faa5:	b8 06 00 00 00       	mov    $0x6,%eax
   2faaa:	48 89 84 24 60 01 00 	mov    %rax,0x160(%rsp)
   2fab1:	00 
   2fab2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fab9:	1f 84 00 00 00 00 00 
   2fac0:	41 bc c8 00 00 00    	mov    $0xc8,%r12d
   2fac6:	bf c8 00 00 00       	mov    $0xc8,%edi
   2facb:	ff 15 ef 24 04 00    	call   *0x424ef(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2fad1:	48 85 c0             	test   %rax,%rax
   2fad4:	0f 84 9f 33 00 00    	je     32e79 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4799>
   2fada:	49 89 c5             	mov    %rax,%r13
   2fadd:	48 89 c5             	mov    %rax,%rbp
   2fae0:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
   2fae7:	00 
   2fae8:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2faec:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
   2faf3:	00 
   2faf4:	49 89 cc             	mov    %rcx,%r12
   2faf7:	49 f7 d4             	not    %r12
   2fafa:	49 01 c4             	add    %rax,%r12
   2fafd:	66 45 89 65 62       	mov    %r12w,0x62(%r13)
   2fb02:	49 83 fc 0c          	cmp    $0xc,%r12
   2fb06:	0f 83 a5 33 00 00    	jae    32eb1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x47d1>
   2fb0c:	44 89 bc 24 20 02 00 	mov    %r15d,0x220(%rsp)
   2fb13:	00 
   2fb14:	44 8d 3c 8d 00 00 00 	lea    0x0(,%rcx,4),%r15d
   2fb1b:	00 
   2fb1c:	42 8b 44 3b 08       	mov    0x8(%rbx,%r15,1),%eax
   2fb21:	89 84 24 7c 01 00 00 	mov    %eax,0x17c(%rsp)
   2fb28:	42 8b 44 3b 34       	mov    0x34(%rbx,%r15,1),%eax
   2fb2d:	89 84 24 78 01 00 00 	mov    %eax,0x178(%rsp)
   2fb34:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
   2fb38:	48 83 c6 0c          	add    $0xc,%rsi
   2fb3c:	49 8d 7d 08          	lea    0x8(%r13),%rdi
   2fb40:	49 c1 e4 02          	shl    $0x2,%r12
   2fb44:	4c 89 e2             	mov    %r12,%rdx
   2fb47:	ff 15 43 24 04 00    	call   *0x42443(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   2fb4d:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
   2fb51:	48 83 c6 38          	add    $0x38,%rsi
   2fb55:	49 8d 7d 34          	lea    0x34(%r13),%rdi
   2fb59:	4c 89 e2             	mov    %r12,%rdx
   2fb5c:	ff 15 2e 24 04 00    	call   *0x4242e(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   2fb62:	48 8b 8c 24 60 01 00 	mov    0x160(%rsp),%rcx
   2fb69:	00 
   2fb6a:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2fb6e:	44 0f b7 7d 62       	movzwl 0x62(%rbp),%r15d
   2fb73:	4d 8d 67 01          	lea    0x1(%r15),%r12
   2fb77:	49 83 ff 0b          	cmp    $0xb,%r15
   2fb7b:	0f 87 4c 33 00 00    	ja     32ecd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x47ed>
   2fb81:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   2fb88:	00 
   2fb89:	29 c8                	sub    %ecx,%eax
   2fb8b:	44 39 e0             	cmp    %r12d,%eax
   2fb8e:	0f 85 6d 33 00 00    	jne    32f01 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4821>
   2fb94:	49 8d 7d 68          	lea    0x68(%r13),%rdi
   2fb98:	48 8d 34 cb          	lea    (%rbx,%rcx,8),%rsi
   2fb9c:	48 83 c6 70          	add    $0x70,%rsi
   2fba0:	42 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%edx
   2fba7:	00 
   2fba8:	ff 15 e2 23 04 00    	call   *0x423e2(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   2fbae:	44 89 e0             	mov    %r12d,%eax
   2fbb1:	83 e0 03             	and    $0x3,%eax
   2fbb4:	66 41 83 ff 03       	cmp    $0x3,%r15w
   2fbb9:	73 15                	jae    2fbd0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x14f0>
   2fbbb:	31 c9                	xor    %ecx,%ecx
   2fbbd:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2fbc2:	44 8b 8c 24 20 02 00 	mov    0x220(%rsp),%r9d
   2fbc9:	00 
   2fbca:	eb 74                	jmp    2fc40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1560>
   2fbcc:	0f 1f 40 00          	nopl   0x0(%rax)
   2fbd0:	41 83 e4 1c          	and    $0x1c,%r12d
   2fbd4:	31 c9                	xor    %ecx,%ecx
   2fbd6:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2fbdb:	44 8b 8c 24 20 02 00 	mov    0x220(%rsp),%r9d
   2fbe2:	00 
   2fbe3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fbea:	84 00 00 00 00 00 
   2fbf0:	48 8b 54 cd 68       	mov    0x68(%rbp,%rcx,8),%rdx
   2fbf5:	48 89 2a             	mov    %rbp,(%rdx)
   2fbf8:	89 ce                	mov    %ecx,%esi
   2fbfa:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2fbfe:	48 8b 54 cd 70       	mov    0x70(%rbp,%rcx,8),%rdx
   2fc03:	48 89 2a             	mov    %rbp,(%rdx)
   2fc06:	8d 7e 01             	lea    0x1(%rsi),%edi
   2fc09:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2fc0d:	48 8b 54 cd 78       	mov    0x78(%rbp,%rcx,8),%rdx
   2fc12:	48 89 2a             	mov    %rbp,(%rdx)
   2fc15:	8d 7e 02             	lea    0x2(%rsi),%edi
   2fc18:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2fc1c:	48 8b 94 cd 80 00 00 	mov    0x80(%rbp,%rcx,8),%rdx
   2fc23:	00 
   2fc24:	48 83 c1 04          	add    $0x4,%rcx
   2fc28:	48 89 2a             	mov    %rbp,(%rdx)
   2fc2b:	83 c6 03             	add    $0x3,%esi
   2fc2e:	66 89 72 60          	mov    %si,0x60(%rdx)
   2fc32:	4c 39 e1             	cmp    %r12,%rcx
   2fc35:	75 b9                	jne    2fbf0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1510>
   2fc37:	48 85 c0             	test   %rax,%rax
   2fc3a:	74 18                	je     2fc54 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1574>
   2fc3c:	0f 1f 40 00          	nopl   0x0(%rax)
   2fc40:	48 8b 54 cd 68       	mov    0x68(%rbp,%rcx,8),%rdx
   2fc45:	48 89 2a             	mov    %rbp,(%rdx)
   2fc48:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2fc4c:	48 ff c1             	inc    %rcx
   2fc4f:	48 ff c8             	dec    %rax
   2fc52:	75 ec                	jne    2fc40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1560>
   2fc54:	45 84 c9             	test   %r9b,%r9b
   2fc57:	4c 0f 44 eb          	cmove  %rbx,%r13
   2fc5b:	45 0f b7 65 62       	movzwl 0x62(%r13),%r12d
   2fc60:	4d 8d 78 01          	lea    0x1(%r8),%r15
   2fc64:	4d 89 e1             	mov    %r12,%r9
   2fc67:	4d 29 c1             	sub    %r8,%r9
   2fc6a:	0f 86 c0 00 00 00    	jbe    2fd30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1650>
   2fc70:	49 8d 45 08          	lea    0x8(%r13),%rax
   2fc74:	4a 8d 34 85 08 00 00 	lea    0x8(,%r8,4),%rsi
   2fc7b:	00 
   2fc7c:	4c 01 ee             	add    %r13,%rsi
   2fc7f:	4a 8d 3c b8          	lea    (%rax,%r15,4),%rdi
   2fc83:	44 89 e0             	mov    %r12d,%eax
   2fc86:	44 29 c0             	sub    %r8d,%eax
   2fc89:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
   2fc90:	00 
   2fc91:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
   2fc98:	48 89 94 24 20 02 00 	mov    %rdx,0x220(%rsp)
   2fc9f:	00 
   2fca0:	4c 89 8c 24 60 01 00 	mov    %r9,0x160(%rsp)
   2fca7:	00 
   2fca8:	ff 15 8a 23 04 00    	call   *0x4238a(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2fcae:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fcb3:	48 8d 34 85 34 00 00 	lea    0x34(,%rax,4),%rsi
   2fcba:	00 
   2fcbb:	4c 01 ee             	add    %r13,%rsi
   2fcbe:	4a 8d 3c bd 34 00 00 	lea    0x34(,%r15,4),%rdi
   2fcc5:	00 
   2fcc6:	4c 01 ef             	add    %r13,%rdi
   2fcc9:	48 8b 94 24 20 02 00 	mov    0x220(%rsp),%rdx
   2fcd0:	00 
   2fcd1:	ff 15 61 23 04 00    	call   *0x42361(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2fcd7:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fcdc:	8b 8c 24 70 01 00 00 	mov    0x170(%rsp),%ecx
   2fce3:	41 89 4c 85 08       	mov    %ecx,0x8(%r13,%rax,4)
   2fce8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fced:	8b 8c 24 74 01 00 00 	mov    0x174(%rsp),%ecx
   2fcf4:	41 89 4c 85 34       	mov    %ecx,0x34(%r13,%rax,4)
   2fcf9:	4b 8d 74 fd 68       	lea    0x68(%r13,%r15,8),%rsi
   2fcfe:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fd03:	48 8d 3c c5 78 00 00 	lea    0x78(,%rax,8),%rdi
   2fd0a:	00 
   2fd0b:	4c 01 ef             	add    %r13,%rdi
   2fd0e:	48 8b 94 24 28 02 00 	mov    0x228(%rsp),%rdx
   2fd15:	00 
   2fd16:	c1 e2 03             	shl    $0x3,%edx
   2fd19:	ff 15 19 23 04 00    	call   *0x42319(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2fd1f:	4c 8b 8c 24 60 01 00 	mov    0x160(%rsp),%r9
   2fd26:	00 
   2fd27:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2fd2c:	eb 1a                	jmp    2fd48 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1668>
   2fd2e:	66 90                	xchg   %ax,%ax
   2fd30:	8b 84 24 70 01 00 00 	mov    0x170(%rsp),%eax
   2fd37:	43 89 44 85 08       	mov    %eax,0x8(%r13,%r8,4)
   2fd3c:	8b 84 24 74 01 00 00 	mov    0x174(%rsp),%eax
   2fd43:	43 89 44 85 34       	mov    %eax,0x34(%r13,%r8,4)
   2fd48:	48 8b 94 24 38 02 00 	mov    0x238(%rsp),%rdx
   2fd4f:	00 
   2fd50:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
   2fd55:	49 8d 44 24 02       	lea    0x2(%r12),%rax
   2fd5a:	4b 89 54 c5 70       	mov    %rdx,0x70(%r13,%r8,8)
   2fd5f:	66 41 89 4d 62       	mov    %cx,0x62(%r13)
   2fd64:	41 39 c7             	cmp    %eax,%r15d
   2fd67:	0f 83 63 fc ff ff    	jae    2f9d0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x12f0>
   2fd6d:	45 29 c4             	sub    %r8d,%r12d
   2fd70:	41 ff c4             	inc    %r12d
   2fd73:	41 83 e4 03          	and    $0x3,%r12d
   2fd77:	74 31                	je     2fdaa <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x16ca>
   2fd79:	4a 8d 14 c5 70 00 00 	lea    0x70(,%r8,8),%rdx
   2fd80:	00 
   2fd81:	4c 01 ea             	add    %r13,%rdx
   2fd84:	31 c9                	xor    %ecx,%ecx
   2fd86:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2fd8d:	00 00 00 
   2fd90:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   2fd94:	4c 89 2e             	mov    %r13,(%rsi)
   2fd97:	41 8d 3c 0f          	lea    (%r15,%rcx,1),%edi
   2fd9b:	66 89 7e 60          	mov    %di,0x60(%rsi)
   2fd9f:	48 ff c1             	inc    %rcx
   2fda2:	49 39 cc             	cmp    %rcx,%r12
   2fda5:	75 e9                	jne    2fd90 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x16b0>
   2fda7:	49 01 cf             	add    %rcx,%r15
   2fdaa:	41 83 f9 03          	cmp    $0x3,%r9d
   2fdae:	0f 82 1c fc ff ff    	jb     2f9d0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x12f0>
   2fdb4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fdbb:	00 00 00 00 00 
   2fdc0:	4b 8b 4c fd 68       	mov    0x68(%r13,%r15,8),%rcx
   2fdc5:	4c 89 29             	mov    %r13,(%rcx)
   2fdc8:	66 44 89 79 60       	mov    %r15w,0x60(%rcx)
   2fdcd:	4b 8b 4c fd 70       	mov    0x70(%r13,%r15,8),%rcx
   2fdd2:	4c 89 29             	mov    %r13,(%rcx)
   2fdd5:	41 8d 57 01          	lea    0x1(%r15),%edx
   2fdd9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fddd:	4b 8b 4c fd 78       	mov    0x78(%r13,%r15,8),%rcx
   2fde2:	4c 89 29             	mov    %r13,(%rcx)
   2fde5:	41 8d 57 02          	lea    0x2(%r15),%edx
   2fde9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fded:	4b 8b 8c fd 80 00 00 	mov    0x80(%r13,%r15,8),%rcx
   2fdf4:	00 
   2fdf5:	4c 89 29             	mov    %r13,(%rcx)
   2fdf8:	41 8d 57 03          	lea    0x3(%r15),%edx
   2fdfc:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fe00:	49 83 c7 04          	add    $0x4,%r15
   2fe04:	49 39 c7             	cmp    %rax,%r15
   2fe07:	75 b7                	jne    2fdc0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x16e0>
   2fe09:	e9 c2 fb ff ff       	jmp    2f9d0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x12f0>
   2fe0e:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2fe15:	00 
   2fe16:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2fe1b:	48 89 cb             	mov    %rcx,%rbx
   2fe1e:	bf c8 00 00 00       	mov    $0xc8,%edi
   2fe23:	ff 15 97 21 04 00    	call   *0x42197(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   2fe29:	48 85 c0             	test   %rax,%rax
   2fe2c:	0f 84 be 31 00 00    	je     32ff0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4910>
   2fe32:	49 89 c4             	mov    %rax,%r12
   2fe35:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2fe3c:	66 c7 40 62 00 00    	movw   $0x0,0x62(%rax)
   2fe42:	4c 89 78 68          	mov    %r15,0x68(%rax)
   2fe46:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   2fe4d:	00 
   2fe4e:	48 89 c8             	mov    %rcx,%rax
   2fe51:	48 ff c0             	inc    %rax
   2fe54:	0f 84 ab 31 00 00    	je     33005 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4925>
   2fe5a:	4d 89 27             	mov    %r12,(%r15)
   2fe5d:	66 41 c7 47 60 00 00 	movw   $0x0,0x60(%r15)
   2fe64:	4c 89 a4 24 d8 01 00 	mov    %r12,0x1d8(%rsp)
   2fe6b:	00 
   2fe6c:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   2fe73:	00 
   2fe74:	48 39 cb             	cmp    %rcx,%rbx
   2fe77:	0f 85 9a 31 00 00    	jne    33017 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4937>
   2fe7d:	66 41 c7 44 24 62 01 	movw   $0x1,0x62(%r12)
   2fe84:	00 
   2fe85:	8b 8c 24 7c 01 00 00 	mov    0x17c(%rsp),%ecx
   2fe8c:	41 89 4c 24 08       	mov    %ecx,0x8(%r12)
   2fe91:	8b 8c 24 78 01 00 00 	mov    0x178(%rsp),%ecx
   2fe98:	41 89 4c 24 34       	mov    %ecx,0x34(%r12)
   2fe9d:	49 89 6c 24 70       	mov    %rbp,0x70(%r12)
   2fea2:	4c 89 65 00          	mov    %r12,0x0(%rbp)
   2fea6:	66 c7 45 60 01 00    	movw   $0x1,0x60(%rbp)
   2feac:	48 89 c5             	mov    %rax,%rbp
   2feaf:	4d 89 e7             	mov    %r12,%r15
   2feb2:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   2feb9:	00 
   2feba:	e9 4d f8 ff ff       	jmp    2f70c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x102c>
   2febf:	49 89 e8             	mov    %rbp,%r8
   2fec2:	49 8d 69 01          	lea    0x1(%r9),%rbp
   2fec6:	66 45 39 d1          	cmp    %r10w,%r9w
   2feca:	0f 83 bc 00 00 00    	jae    2ff8c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x18ac>
   2fed0:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   2fed4:	4a 8d 34 8b          	lea    (%rbx,%r9,4),%rsi
   2fed8:	48 83 c6 08          	add    $0x8,%rsi
   2fedc:	44 8d 3c ad 00 00 00 	lea    0x0(,%rbp,4),%r15d
   2fee3:	00 
   2fee4:	4c 01 ff             	add    %r15,%rdi
   2fee7:	4d 89 d4             	mov    %r10,%r12
   2feea:	4d 29 cc             	sub    %r9,%r12
   2feed:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
   2fef4:	00 
   2fef5:	48 8b 05 3c 21 04 00 	mov    0x4213c(%rip),%rax        # 72038 <memmove@GLIBC_2.2.5>
   2fefc:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2ff01:	ff d0                	call   *%rax
   2ff03:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ff08:	44 8d 2c 85 00 00 00 	lea    0x0(,%rax,4),%r13d
   2ff0f:	00 
   2ff10:	4a 8d 34 2b          	lea    (%rbx,%r13,1),%rsi
   2ff14:	48 83 c6 34          	add    $0x34,%rsi
   2ff18:	4a 8d 3c 3b          	lea    (%rbx,%r15,1),%rdi
   2ff1c:	48 83 c7 34          	add    $0x34,%rdi
   2ff20:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   2ff27:	00 
   2ff28:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
   2ff2f:	00 
   2ff30:	ff 15 02 21 04 00    	call   *0x42102(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2ff36:	8b 84 24 70 01 00 00 	mov    0x170(%rsp),%eax
   2ff3d:	42 89 44 2b 08       	mov    %eax,0x8(%rbx,%r13,1)
   2ff42:	8b 84 24 74 01 00 00 	mov    0x174(%rsp),%eax
   2ff49:	42 89 44 2b 34       	mov    %eax,0x34(%rbx,%r13,1)
   2ff4e:	4c 8b 6c 24 50       	mov    0x50(%rsp),%r13
   2ff53:	48 8d 34 eb          	lea    (%rbx,%rbp,8),%rsi
   2ff57:	48 83 c6 68          	add    $0x68,%rsi
   2ff5b:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2ff60:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
   2ff64:	48 83 c7 78          	add    $0x78,%rdi
   2ff68:	49 c1 e4 03          	shl    $0x3,%r12
   2ff6c:	4c 89 e2             	mov    %r12,%rdx
   2ff6f:	ff 15 c3 20 04 00    	call   *0x420c3(%rip)        # 72038 <memmove@GLIBC_2.2.5>
   2ff75:	4c 8b 94 24 28 02 00 	mov    0x228(%rsp),%r10
   2ff7c:	00 
   2ff7d:	4c 8b 84 24 38 02 00 	mov    0x238(%rsp),%r8
   2ff84:	00 
   2ff85:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
   2ff8a:	eb 0a                	jmp    2ff96 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x18b6>
   2ff8c:	42 89 7c 8b 08       	mov    %edi,0x8(%rbx,%r9,4)
   2ff91:	42 89 74 8b 34       	mov    %esi,0x34(%rbx,%r9,4)
   2ff96:	4c 8b a4 24 00 01 00 	mov    0x100(%rsp),%r12
   2ff9d:	00 
   2ff9e:	41 8d 4a 01          	lea    0x1(%r10),%ecx
   2ffa2:	49 8d 42 02          	lea    0x2(%r10),%rax
   2ffa6:	4e 89 44 cb 70       	mov    %r8,0x70(%rbx,%r9,8)
   2ffab:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2ffaf:	39 c5                	cmp    %eax,%ebp
   2ffb1:	0f 83 8e 00 00 00    	jae    30045 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1965>
   2ffb7:	44 89 d1             	mov    %r10d,%ecx
   2ffba:	44 29 c9             	sub    %r9d,%ecx
   2ffbd:	ff c1                	inc    %ecx
   2ffbf:	83 e1 03             	and    $0x3,%ecx
   2ffc2:	74 27                	je     2ffeb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x190b>
   2ffc4:	4a 8d 34 cb          	lea    (%rbx,%r9,8),%rsi
   2ffc8:	48 83 c6 70          	add    $0x70,%rsi
   2ffcc:	31 d2                	xor    %edx,%edx
   2ffce:	66 90                	xchg   %ax,%ax
   2ffd0:	48 8b 3c d6          	mov    (%rsi,%rdx,8),%rdi
   2ffd4:	48 89 1f             	mov    %rbx,(%rdi)
   2ffd7:	44 8d 04 2a          	lea    (%rdx,%rbp,1),%r8d
   2ffdb:	66 44 89 47 60       	mov    %r8w,0x60(%rdi)
   2ffe0:	48 ff c2             	inc    %rdx
   2ffe3:	48 39 d1             	cmp    %rdx,%rcx
   2ffe6:	75 e8                	jne    2ffd0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x18f0>
   2ffe8:	48 01 d5             	add    %rdx,%rbp
   2ffeb:	4d 29 ca             	sub    %r9,%r10
   2ffee:	41 83 fa 03          	cmp    $0x3,%r10d
   2fff2:	72 51                	jb     30045 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1965>
   2fff4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fffb:	00 00 00 00 00 
   30000:	48 8b 4c eb 68       	mov    0x68(%rbx,%rbp,8),%rcx
   30005:	48 89 19             	mov    %rbx,(%rcx)
   30008:	66 89 69 60          	mov    %bp,0x60(%rcx)
   3000c:	48 8b 4c eb 70       	mov    0x70(%rbx,%rbp,8),%rcx
   30011:	48 89 19             	mov    %rbx,(%rcx)
   30014:	8d 55 01             	lea    0x1(%rbp),%edx
   30017:	66 89 51 60          	mov    %dx,0x60(%rcx)
   3001b:	48 8b 4c eb 78       	mov    0x78(%rbx,%rbp,8),%rcx
   30020:	48 89 19             	mov    %rbx,(%rcx)
   30023:	8d 55 02             	lea    0x2(%rbp),%edx
   30026:	66 89 51 60          	mov    %dx,0x60(%rcx)
   3002a:	48 8b 8c eb 80 00 00 	mov    0x80(%rbx,%rbp,8),%rcx
   30031:	00 
   30032:	48 89 19             	mov    %rbx,(%rcx)
   30035:	8d 55 03             	lea    0x3(%rbp),%edx
   30038:	66 89 51 60          	mov    %dx,0x60(%rcx)
   3003c:	48 83 c5 04          	add    $0x4,%rbp
   30040:	48 39 c5             	cmp    %rax,%rbp
   30043:	75 bb                	jne    30000 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1920>
   30045:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   3004c:	00 
   3004d:	e9 ba f6 ff ff       	jmp    2f70c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x102c>
   30052:	ba 04 00 00 00       	mov    $0x4,%edx
   30057:	b9 01 00 00 00       	mov    $0x1,%ecx
   3005c:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   30062:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
   30069:	00 
   3006a:	e8 21 cb ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3006f:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
   30076:	00 
   30077:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   3007e:	00 
   3007f:	e9 05 f7 ff ff       	jmp    2f789 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x10a9>
   30084:	ba 04 00 00 00       	mov    $0x4,%edx
   30089:	b9 01 00 00 00       	mov    $0x1,%ecx
   3008e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   30094:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
   3009b:	00 
   3009c:	e8 ef ca ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   300a1:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   300a8:	00 
   300a9:	48 8b b4 24 90 01 00 	mov    0x190(%rsp),%rsi
   300b0:	00 
   300b1:	e9 f8 f6 ff ff       	jmp    2f7ae <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x10ce>
   300b6:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
   300bd:	00 00 00 00 00 
   300c2:	45 31 ff             	xor    %r15d,%r15d
   300c5:	4c 89 bc 24 90 00 00 	mov    %r15,0x90(%rsp)
   300cc:	00 
   300cd:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   300d4:	00 
   300d5:	4d 85 e4             	test   %r12,%r12
   300d8:	74 1a                	je     300f4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a14>
   300da:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   300df:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   300e4:	4d 85 ff             	test   %r15,%r15
   300e7:	74 11                	je     300fa <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a1a>
   300e9:	49 83 ff 10          	cmp    $0x10,%r15
   300ed:	73 13                	jae    30102 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a22>
   300ef:	45 31 e4             	xor    %r12d,%r12d
   300f2:	eb 1f                	jmp    30113 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a33>
   300f4:	41 be 04 00 00 00    	mov    $0x4,%r14d
   300fa:	45 31 ff             	xor    %r15d,%r15d
   300fd:	45 31 e4             	xor    %r12d,%r12d
   30100:	eb 11                	jmp    30113 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a33>
   30102:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   30107:	49 83 c4 18          	add    $0x18,%r12
   3010b:	85 c0                	test   %eax,%eax
   3010d:	0f 85 7c 2f 00 00    	jne    3308f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x49af>
   30113:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   3011a:	00 
   3011b:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   30120:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   30125:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   3012a:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   30131:	00 00 
   30133:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   3013a:	00 
   3013b:	48 89 e6             	mov    %rsp,%rsi
   3013e:	e8 bd d1 ff ff       	call   2d300 <_RINvXs1o_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB7_8BTreeMapllEINtNtNtNtCskADBYZwJmSU_4core4iter6traits7collect12FromIteratorTllEE9from_iterINtNtCse9VFdDP9LWm_4pbrs3map11MapViewIterllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30143:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   3014a:	00 
   3014b:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   30152:	00 
   30153:	e8 18 6c 00 00       	call   36d70 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30158:	84 c0                	test   %al,%al
   3015a:	0f 84 2d 2e 00 00    	je     32f8d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x48ad>
   30160:	48 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%rdx
   30167:	00 
   30168:	48 85 d2             	test   %rdx,%rdx
   3016b:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
   30172:	00 
   30173:	0f 84 7b 00 00 00    	je     301f4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b14>
   30179:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   30180:	00 
   30181:	48 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%rax
   30188:	00 
   30189:	48 8d 1c d1          	lea    (%rcx,%rdx,8),%rbx
   3018d:	48 8d 7a 01          	lea    0x1(%rdx),%rdi
   30191:	45 31 f6             	xor    %r14d,%r14d
   30194:	48 89 c6             	mov    %rax,%rsi
   30197:	49 39 d6             	cmp    %rdx,%r14
   3019a:	0f 84 a5 2d 00 00    	je     32f45 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4865>
   301a0:	4c 8d 69 08          	lea    0x8(%rcx),%r13
   301a4:	49 ff c6             	inc    %r14
   301a7:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
   301ae:	00 
   301af:	8b 29                	mov    (%rcx),%ebp
   301b1:	49 39 c0             	cmp    %rax,%r8
   301b4:	0f 84 7a 00 00 00    	je     30234 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b54>
   301ba:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   301c0:	42 39 2c 01          	cmp    %ebp,(%rcx,%r8,1)
   301c4:	74 1a                	je     301e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b00>
   301c6:	49 83 c0 08          	add    $0x8,%r8
   301ca:	4c 39 c6             	cmp    %r8,%rsi
   301cd:	75 f1                	jne    301c0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ae0>
   301cf:	eb 63                	jmp    30234 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b54>
   301d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   301d8:	0f 1f 84 00 00 00 00 
   301df:	00 
   301e0:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   301e4:	4c 89 e9             	mov    %r13,%rcx
   301e7:	49 39 dd             	cmp    %rbx,%r13
   301ea:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   301f1:	00 
   301f2:	75 a3                	jne    30197 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ab7>
   301f4:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
   301fb:	00 00 00 00 00 
   30200:	48 c7 84 24 f8 01 00 	movq   $0x4,0x1f8(%rsp)
   30207:	00 04 00 00 00 
   3020c:	48 c7 84 24 00 02 00 	movq   $0x0,0x200(%rsp)
   30213:	00 00 00 00 00 
   30218:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   3021f:	00 
   30220:	4d 85 e4             	test   %r12,%r12
   30223:	0f 85 79 01 00 00    	jne    303a2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cc2>
   30229:	41 be 04 00 00 00    	mov    $0x4,%r14d
   3022f:	e9 88 01 00 00       	jmp    303bc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cdc>
   30234:	44 8b 79 04          	mov    0x4(%rcx),%r15d
   30238:	bf 20 00 00 00       	mov    $0x20,%edi
   3023d:	ff 15 7d 1d 04 00    	call   *0x41d7d(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   30243:	48 85 c0             	test   %rax,%rax
   30246:	0f 84 29 31 00 00    	je     33375 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c95>
   3024c:	89 28                	mov    %ebp,(%rax)
   3024e:	44 89 78 04          	mov    %r15d,0x4(%rax)
   30252:	48 c7 04 24 04 00 00 	movq   $0x4,(%rsp)
   30259:	00 
   3025a:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   3025f:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   30266:	00 00 
   30268:	49 39 dd             	cmp    %rbx,%r13
   3026b:	0f 84 f2 00 00 00    	je     30363 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c83>
   30271:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30277:	eb 21                	jmp    3029a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1bba>
   30279:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30280:	42 89 2c f8          	mov    %ebp,(%rax,%r15,8)
   30284:	46 89 64 f8 04       	mov    %r12d,0x4(%rax,%r15,8)
   30289:	49 ff c7             	inc    %r15
   3028c:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   30291:	49 39 dd             	cmp    %rbx,%r13
   30294:	0f 84 c9 00 00 00    	je     30363 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c83>
   3029a:	48 8b 8c 24 a8 01 00 	mov    0x1a8(%rsp),%rcx
   302a1:	00 
   302a2:	48 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%rdx
   302a9:	00 
   302aa:	4a 8d 3c f5 00 00 00 	lea    0x0(,%r14,8),%rdi
   302b1:	00 
   302b2:	4a 8d 0c f1          	lea    (%rcx,%r14,8),%rcx
   302b6:	48 83 c1 08          	add    $0x8,%rcx
   302ba:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
   302c1:	00 
   302c2:	48 29 fe             	sub    %rdi,%rsi
   302c5:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   302c9:	4c 89 ef             	mov    %r13,%rdi
   302cc:	4c 8d 6f 08          	lea    0x8(%rdi),%r13
   302d0:	49 ff c6             	inc    %r14
   302d3:	49 39 d6             	cmp    %rdx,%r14
   302d6:	0f 87 0d 2c 00 00    	ja     32ee9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4809>
   302dc:	8b 2f                	mov    (%rdi),%ebp
   302de:	74 50                	je     30330 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c50>
   302e0:	45 31 c0             	xor    %r8d,%r8d
   302e3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   302ea:	84 00 00 00 00 00 
   302f0:	42 39 2c 01          	cmp    %ebp,(%rcx,%r8,1)
   302f4:	74 1a                	je     30310 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c30>
   302f6:	49 83 c0 08          	add    $0x8,%r8
   302fa:	4c 39 c6             	cmp    %r8,%rsi
   302fd:	75 f1                	jne    302f0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c10>
   302ff:	eb 2f                	jmp    30330 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c50>
   30301:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30308:	0f 1f 84 00 00 00 00 
   3030f:	00 
   30310:	48 83 c1 08          	add    $0x8,%rcx
   30314:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   30318:	4c 89 ef             	mov    %r13,%rdi
   3031b:	49 39 dd             	cmp    %rbx,%r13
   3031e:	75 ac                	jne    302cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1bec>
   30320:	eb 41                	jmp    30363 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1c83>
   30322:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30329:	1f 84 00 00 00 00 00 
   30330:	44 8b 67 04          	mov    0x4(%rdi),%r12d
   30334:	4c 3b 3c 24          	cmp    (%rsp),%r15
   30338:	0f 85 42 ff ff ff    	jne    30280 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ba0>
   3033e:	ba 01 00 00 00       	mov    $0x1,%edx
   30343:	b9 04 00 00 00       	mov    $0x4,%ecx
   30348:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   3034e:	48 89 e7             	mov    %rsp,%rdi
   30351:	4c 89 fe             	mov    %r15,%rsi
   30354:	e8 37 c8 ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30359:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   3035e:	e9 1d ff ff ff       	jmp    30280 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ba0>
   30363:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   30368:	48 89 84 24 00 02 00 	mov    %rax,0x200(%rsp)
   3036f:	00 
   30370:	48 8b 04 24          	mov    (%rsp),%rax
   30374:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
   3037b:	00 
   3037c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   30381:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
   30388:	00 
   30389:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   30390:	00 
   30391:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   30398:	00 
   30399:	4d 85 e4             	test   %r12,%r12
   3039c:	0f 84 87 fe ff ff    	je     30229 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1b49>
   303a2:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   303a7:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   303ac:	4d 85 ff             	test   %r15,%r15
   303af:	74 0b                	je     303bc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cdc>
   303b1:	49 83 ff 10          	cmp    $0x10,%r15
   303b5:	73 0d                	jae    303c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ce4>
   303b7:	45 31 e4             	xor    %r12d,%r12d
   303ba:	eb 19                	jmp    303d5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cf5>
   303bc:	45 31 ff             	xor    %r15d,%r15d
   303bf:	45 31 e4             	xor    %r12d,%r12d
   303c2:	eb 11                	jmp    303d5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cf5>
   303c4:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   303c9:	49 83 c4 18          	add    $0x18,%r12
   303cd:	85 c0                	test   %eax,%eax
   303cf:	0f 85 cd 2c 00 00    	jne    330a2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x49c2>
   303d5:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   303dc:	00 
   303dd:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   303e2:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   303e7:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   303ec:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   303f3:	00 00 
   303f5:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   303fc:	00 
   303fd:	48 89 e6             	mov    %rsp,%rsi
   30400:	e8 5b 51 00 00       	call   35560 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCse9VFdDP9LWm_4pbrs3map11MapViewIterllEE9from_iterCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30405:	48 8b 8c 24 c8 00 00 	mov    0xc8(%rsp),%rcx
   3040c:	00 
   3040d:	48 3b 8c 24 00 02 00 	cmp    0x200(%rsp),%rcx
   30414:	00 
   30415:	0f 85 56 29 00 00    	jne    32d71 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4691>
   3041b:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   30422:	00 
   30423:	48 85 c9             	test   %rcx,%rcx
   30426:	0f 84 98 00 00 00    	je     304c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1de4>
   3042c:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
   30433:	00 
   30434:	48 83 f9 01          	cmp    $0x1,%rcx
   30438:	75 04                	jne    3043e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1d5e>
   3043a:	31 d2                	xor    %edx,%edx
   3043c:	eb 66                	jmp    304a4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1dc4>
   3043e:	48 89 ce             	mov    %rcx,%rsi
   30441:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
   30445:	31 d2                	xor    %edx,%edx
   30447:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3044e:	00 00 
   30450:	f3 0f 7e 04 d7       	movq   (%rdi,%rdx,8),%xmm0
   30455:	f3 0f 7e 0c d0       	movq   (%rax,%rdx,8),%xmm1
   3045a:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   3045e:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   30463:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   30468:	41 83 f8 03          	cmp    $0x3,%r8d
   3046c:	0f 85 ff 28 00 00    	jne    32d71 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4691>
   30472:	f3 0f 7e 44 d7 08    	movq   0x8(%rdi,%rdx,8),%xmm0
   30478:	f3 0f 7e 4c d0 08    	movq   0x8(%rax,%rdx,8),%xmm1
   3047e:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   30482:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   30487:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   3048c:	41 83 f8 03          	cmp    $0x3,%r8d
   30490:	0f 85 db 28 00 00    	jne    32d71 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4691>
   30496:	48 83 c2 02          	add    $0x2,%rdx
   3049a:	48 39 d6             	cmp    %rdx,%rsi
   3049d:	75 b1                	jne    30450 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1d70>
   3049f:	f6 c1 01             	test   $0x1,%cl
   304a2:	74 20                	je     304c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1de4>
   304a4:	f3 0f 7e 04 d7       	movq   (%rdi,%rdx,8),%xmm0
   304a9:	f3 0f 7e 0c d0       	movq   (%rax,%rdx,8),%xmm1
   304ae:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   304b2:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   304b7:	66 0f 50 c0          	movmskpd %xmm0,%eax
   304bb:	83 f8 03             	cmp    $0x3,%eax
   304be:	0f 85 ad 28 00 00    	jne    32d71 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4691>
   304c4:	48 83 bc 24 b8 00 00 	cmpq   $0x0,0xb8(%rsp)
   304cb:	00 00 
   304cd:	74 06                	je     304d5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1df5>
   304cf:	ff 15 d3 1a 04 00    	call   *0x41ad3(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   304d5:	80 bc 24 9c 00 00 00 	cmpb   $0x0,0x9c(%rsp)
   304dc:	00 
   304dd:	0f 84 50 01 00 00    	je     30633 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f53>
   304e3:	48 8b 9c 24 10 01 00 	mov    0x110(%rsp),%rbx
   304ea:	00 
   304eb:	48 85 db             	test   %rbx,%rbx
   304ee:	0f 84 bd 2c 00 00    	je     331b1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad1>
   304f4:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
   304f8:	4d 85 ff             	test   %r15,%r15
   304fb:	0f 84 b0 2c 00 00    	je     331b1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad1>
   30501:	4c 8b 73 08          	mov    0x8(%rbx),%r14
   30505:	49 83 ff 10          	cmp    $0x10,%r15
   30509:	73 52                	jae    3055d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e7d>
   3050b:	49 8d 46 08          	lea    0x8(%r14),%rax
   3050f:	4a 8d 0c fd f8 ff ff 	lea    -0x8(,%r15,8),%rcx
   30516:	ff 
   30517:	31 d2                	xor    %edx,%edx
   30519:	49 8d 34 d6          	lea    (%r14,%rdx,8),%rsi
   3051d:	48 ff c2             	inc    %rdx
   30520:	4c 39 fa             	cmp    %r15,%rdx
   30523:	74 30                	je     30555 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e75>
   30525:	8b 3e                	mov    (%rsi),%edi
   30527:	45 31 c0             	xor    %r8d,%r8d
   3052a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   30530:	42 39 3c 00          	cmp    %edi,(%rax,%r8,1)
   30534:	74 0b                	je     30541 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e61>
   30536:	49 83 c0 08          	add    $0x8,%r8
   3053a:	4c 39 c1             	cmp    %r8,%rcx
   3053d:	75 f1                	jne    30530 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e50>
   3053f:	eb 14                	jmp    30555 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e75>
   30541:	48 83 c0 08          	add    $0x8,%rax
   30545:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   30549:	49 8d 34 d6          	lea    (%r14,%rdx,8),%rsi
   3054d:	48 ff c2             	inc    %rdx
   30550:	4c 39 fa             	cmp    %r15,%rdx
   30553:	75 d0                	jne    30525 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e45>
   30555:	49 89 f6             	mov    %rsi,%r14
   30558:	e9 af 00 00 00       	jmp    3060c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f2c>
   3055d:	8b 43 30             	mov    0x30(%rbx),%eax
   30560:	85 c0                	test   %eax,%eax
   30562:	0f 85 13 2b 00 00    	jne    3307b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x499b>
   30568:	48 8b 53 28          	mov    0x28(%rbx),%rdx
   3056c:	4c 39 fa             	cmp    %r15,%rdx
   3056f:	0f 84 97 00 00 00    	je     3060c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f2c>
   30575:	48 8b 43 20          	mov    0x20(%rbx),%rax
   30579:	48 83 fa 01          	cmp    $0x1,%rdx
   3057d:	74 69                	je     305e8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f08>
   3057f:	48 85 d2             	test   %rdx,%rdx
   30582:	0f 84 29 2c 00 00    	je     331b1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad1>
   30588:	31 c9                	xor    %ecx,%ecx
   3058a:	eb 10                	jmp    3059c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ebc>
   3058c:	0f 1f 40 00          	nopl   0x0(%rax)
   30590:	48 ff c1             	inc    %rcx
   30593:	4c 39 f9             	cmp    %r15,%rcx
   30596:	0f 84 15 2c 00 00    	je     331b1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad1>
   3059c:	41 8b 34 ce          	mov    (%r14,%rcx,8),%esi
   305a0:	49 89 d0             	mov    %rdx,%r8
   305a3:	31 ff                	xor    %edi,%edi
   305a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   305ac:	00 00 00 00 
   305b0:	49 89 f9             	mov    %rdi,%r9
   305b3:	4d 89 c2             	mov    %r8,%r10
   305b6:	49 d1 ea             	shr    $1,%r10
   305b9:	4c 01 d7             	add    %r10,%rdi
   305bc:	49 89 fb             	mov    %rdi,%r11
   305bf:	49 c1 e3 04          	shl    $0x4,%r11
   305c3:	42 39 34 18          	cmp    %esi,(%rax,%r11,1)
   305c7:	49 0f 4f f9          	cmovg  %r9,%rdi
   305cb:	4d 29 d0             	sub    %r10,%r8
   305ce:	49 83 f8 01          	cmp    $0x1,%r8
   305d2:	77 dc                	ja     305b0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1ed0>
   305d4:	48 c1 e7 04          	shl    $0x4,%rdi
   305d8:	39 34 38             	cmp    %esi,(%rax,%rdi,1)
   305db:	75 b3                	jne    30590 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1eb0>
   305dd:	48 01 c7             	add    %rax,%rdi
   305e0:	48 39 4f 08          	cmp    %rcx,0x8(%rdi)
   305e4:	75 aa                	jne    30590 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1eb0>
   305e6:	eb 20                	jmp    30608 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f28>
   305e8:	8b 10                	mov    (%rax),%edx
   305ea:	31 c9                	xor    %ecx,%ecx
   305ec:	eb 0e                	jmp    305fc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f1c>
   305ee:	66 90                	xchg   %ax,%ax
   305f0:	48 ff c1             	inc    %rcx
   305f3:	49 39 cf             	cmp    %rcx,%r15
   305f6:	0f 84 b5 2b 00 00    	je     331b1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad1>
   305fc:	41 3b 14 ce          	cmp    (%r14,%rcx,8),%edx
   30600:	75 ee                	jne    305f0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f10>
   30602:	48 3b 48 08          	cmp    0x8(%rax),%rcx
   30606:	75 e8                	jne    305f0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f10>
   30608:	4d 8d 34 ce          	lea    (%r14,%rcx,8),%r14
   3060c:	41 8b 0e             	mov    (%r14),%ecx
   3060f:	41 8b 46 04          	mov    0x4(%r14),%eax
   30613:	89 4c 24 04          	mov    %ecx,0x4(%rsp)
   30617:	89 44 24 08          	mov    %eax,0x8(%rsp)
   3061b:	c7 04 24 01 00 00 00 	movl   $0x1,(%rsp)
   30622:	85 c9                	test   %ecx,%ecx
   30624:	0f 85 8e 2b 00 00    	jne    331b8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad8>
   3062a:	83 f8 03             	cmp    $0x3,%eax
   3062d:	0f 85 85 2b 00 00    	jne    331b8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ad8>
   30633:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
   3063a:	00 00 00 00 00 
   3063f:	48 8b 84 24 b0 01 00 	mov    0x1b0(%rsp),%rax
   30646:	00 
   30647:	48 85 c0             	test   %rax,%rax
   3064a:	74 69                	je     306b5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fd5>
   3064c:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
   30653:	00 
   30654:	4c 8d 3c c3          	lea    (%rbx,%rax,8),%r15
   30658:	4c 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%r14
   3065f:	00 
   30660:	8b 33                	mov    (%rbx),%esi
   30662:	8b 53 04             	mov    0x4(%rbx),%edx
   30665:	4c 89 f7             	mov    %r14,%rdi
   30668:	e8 53 4a 00 00       	call   350c0 <_RNvMso_NtCse9VFdDP9LWm_4pbrs3mapINtB5_3MapllE10push_entryCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3066d:	48 83 c3 08          	add    $0x8,%rbx
   30671:	4c 39 fb             	cmp    %r15,%rbx
   30674:	75 ea                	jne    30660 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1f80>
   30676:	4c 8b a4 24 b8 01 00 	mov    0x1b8(%rsp),%r12
   3067d:	00 
   3067e:	4d 85 e4             	test   %r12,%r12
   30681:	74 32                	je     306b5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fd5>
   30683:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   30688:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   3068d:	4d 85 ff             	test   %r15,%r15
   30690:	74 29                	je     306bb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fdb>
   30692:	49 83 ff 10          	cmp    $0x10,%r15
   30696:	72 26                	jb     306be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fde>
   30698:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   3069d:	49 83 c4 18          	add    $0x18,%r12
   306a1:	85 c0                	test   %eax,%eax
   306a3:	74 1c                	je     306c1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fe1>
   306a5:	4c 89 e7             	mov    %r12,%rdi
   306a8:	4c 89 f6             	mov    %r14,%rsi
   306ab:	4c 89 fa             	mov    %r15,%rdx
   306ae:	e8 09 8a ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   306b3:	eb 0c                	jmp    306c1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1fe1>
   306b5:	41 be 04 00 00 00    	mov    $0x4,%r14d
   306bb:	45 31 ff             	xor    %r15d,%r15d
   306be:	45 31 e4             	xor    %r12d,%r12d
   306c1:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   306c8:	00 
   306c9:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   306ce:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   306d3:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   306d8:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   306df:	00 00 
   306e1:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   306e8:	00 
   306e9:	48 89 e6             	mov    %rsp,%rsi
   306ec:	e8 0f cc ff ff       	call   2d300 <_RINvXs1o_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB7_8BTreeMapllEINtNtNtNtCskADBYZwJmSU_4core4iter6traits7collect12FromIteratorTllEE9from_iterINtNtCse9VFdDP9LWm_4pbrs3map11MapViewIterllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   306f1:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   306f8:	00 
   306f9:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   30700:	00 
   30701:	e8 6a 66 00 00       	call   36d70 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30706:	84 c0                	test   %al,%al
   30708:	0f 84 a0 28 00 00    	je     32fae <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x48ce>
   3070e:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   30715:	00 
   30716:	e8 45 9a ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3071b:	48 8b 8c 24 48 01 00 	mov    0x148(%rsp),%rcx
   30722:	00 
   30723:	48 85 c9             	test   %rcx,%rcx
   30726:	0f 84 a1 00 00 00    	je     307cd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x20ed>
   3072c:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   30733:	ff ff 1f 
   30736:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
   3073d:	00 
   3073e:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   30742:	66 44 0f d7 e8       	pmovmskb %xmm0,%r13d
   30747:	48 8d 6b 10          	lea    0x10(%rbx),%rbp
   3074b:	66 41 83 f5 ff       	xor    $0xffff,%r13w
   30750:	75 27                	jne    30779 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2099>
   30752:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30759:	1f 84 00 00 00 00 00 
   30760:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   30765:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   30769:	48 83 c5 10          	add    $0x10,%rbp
   3076d:	66 44 0f d7 e8       	pmovmskb %xmm0,%r13d
   30772:	66 41 83 f5 ff       	xor    $0xffff,%r13w
   30777:	74 e7                	je     30760 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2080>
   30779:	48 83 f9 05          	cmp    $0x5,%rcx
   3077d:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   30783:	41 be 04 00 00 00    	mov    $0x4,%r14d
   30789:	4c 0f 43 f1          	cmovae %rcx,%r14
   3078d:	4e 8d 24 f5 00 00 00 	lea    0x0(,%r14,8),%r12
   30794:	00 
   30795:	48 ff c0             	inc    %rax
   30798:	48 39 c1             	cmp    %rax,%rcx
   3079b:	0f 97 c0             	seta   %al
   3079e:	48 89 ca             	mov    %rcx,%rdx
   307a1:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   307a8:	ff ff 7f 
   307ab:	48 83 c1 0b          	add    $0xb,%rcx
   307af:	49 39 cc             	cmp    %rcx,%r12
   307b2:	0f 97 c1             	seta   %cl
   307b5:	08 c1                	or     %al,%cl
   307b7:	74 31                	je     307ea <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x210a>
   307b9:	45 31 ff             	xor    %r15d,%r15d
   307bc:	4c 89 ff             	mov    %r15,%rdi
   307bf:	4c 89 e6             	mov    %r12,%rsi
   307c2:	ff 15 a8 17 04 00    	call   *0x417a8(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   307c8:	e9 4c 2d 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   307cd:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
   307d4:	00 00 00 00 00 
   307d9:	48 c7 84 24 c8 00 00 	movq   $0x0,0xc8(%rsp)
   307e0:	00 00 00 00 00 
   307e5:	e9 ce 01 00 00       	jmp    309b8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x22d8>
   307ea:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   307ef:	f3 41 0f bc c5       	tzcnt  %r13d,%eax
   307f4:	c1 e0 03             	shl    $0x3,%eax
   307f7:	48 89 d9             	mov    %rbx,%rcx
   307fa:	48 29 c1             	sub    %rax,%rcx
   307fd:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   30802:	66 0f 7f 84 24 a0 00 	movdqa %xmm0,0xa0(%rsp)
   30809:	00 00 
   3080b:	4c 89 e7             	mov    %r12,%rdi
   3080e:	ff 15 ac 17 04 00    	call   *0x417ac(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   30814:	48 85 c0             	test   %rax,%rax
   30817:	74 a3                	je     307bc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x20dc>
   30819:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   3081e:	49 89 cf             	mov    %rcx,%r15
   30821:	66 0f 6f 84 24 a0 00 	movdqa 0xa0(%rsp),%xmm0
   30828:	00 00 
   3082a:	66 0f d6 00          	movq   %xmm0,(%rax)
   3082e:	4c 89 34 24          	mov    %r14,(%rsp)
   30832:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   30837:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   3083e:	00 00 
   30840:	49 ff cf             	dec    %r15
   30843:	0f 84 49 01 00 00    	je     30992 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x22b2>
   30849:	45 8d 75 ff          	lea    -0x1(%r13),%r14d
   3084d:	45 21 ee             	and    %r13d,%r14d
   30850:	b9 01 00 00 00       	mov    $0x1,%ecx
   30855:	49 89 e4             	mov    %rsp,%r12
   30858:	eb 30                	jmp    3088a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x21aa>
   3085a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   30860:	41 8d 56 ff          	lea    -0x1(%r14),%edx
   30864:	44 21 f2             	and    %r14d,%edx
   30867:	49 ff cf             	dec    %r15
   3086a:	66 0f 6f 84 24 a0 00 	movdqa 0xa0(%rsp),%xmm0
   30871:	00 00 
   30873:	66 42 0f d6 04 e8    	movq   %xmm0,(%rax,%r13,8)
   30879:	49 8d 4d 01          	lea    0x1(%r13),%rcx
   3087d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   30882:	41 89 d6             	mov    %edx,%r14d
   30885:	4d 85 ff             	test   %r15,%r15
   30888:	74 73                	je     308fd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x221d>
   3088a:	49 89 cd             	mov    %rcx,%r13
   3088d:	66 45 85 f6          	test   %r14w,%r14w
   30891:	75 26                	jne    308b9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x21d9>
   30893:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3089a:	84 00 00 00 00 00 
   308a0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   308a5:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   308a9:	48 83 c5 10          	add    $0x10,%rbp
   308ad:	66 44 0f d7 f0       	pmovmskb %xmm0,%r14d
   308b2:	66 41 83 f6 ff       	xor    $0xffff,%r14w
   308b7:	74 e7                	je     308a0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x21c0>
   308b9:	f3 41 0f bc ce       	tzcnt  %r14d,%ecx
   308be:	c1 e1 03             	shl    $0x3,%ecx
   308c1:	48 89 da             	mov    %rbx,%rdx
   308c4:	48 29 ca             	sub    %rcx,%rdx
   308c7:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   308cc:	0f 29 84 24 a0 00 00 	movaps %xmm0,0xa0(%rsp)
   308d3:	00 
   308d4:	4c 3b 2c 24          	cmp    (%rsp),%r13
   308d8:	75 86                	jne    30860 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2180>
   308da:	b9 04 00 00 00       	mov    $0x4,%ecx
   308df:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   308e5:	4c 89 e7             	mov    %r12,%rdi
   308e8:	4c 89 ee             	mov    %r13,%rsi
   308eb:	4c 89 fa             	mov    %r15,%rdx
   308ee:	e8 9d c2 ff ff       	call   2cb90 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   308f3:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   308f8:	e9 63 ff ff ff       	jmp    30860 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2180>
   308fd:	4c 8b 34 24          	mov    (%rsp),%r14
   30901:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   30906:	49 83 fd 14          	cmp    $0x14,%r13
   3090a:	0f 83 a5 27 00 00    	jae    330b5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x49d5>
   30910:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   30915:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
   30919:	48 8d 78 08          	lea    0x8(%rax),%rdi
   3091d:	31 d2                	xor    %edx,%edx
   3091f:	49 89 c2             	mov    %rax,%r10
   30922:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   30929:	00 
   3092a:	eb 20                	jmp    3094c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x226c>
   3092c:	49 01 c1             	add    %rax,%r9
   3092f:	4d 89 cb             	mov    %r9,%r11
   30932:	49 c1 e0 20          	shl    $0x20,%r8
   30936:	49 09 f8             	or     %rdi,%r8
   30939:	4d 89 03             	mov    %r8,(%r11)
   3093c:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
   30940:	48 83 c2 08          	add    $0x8,%rdx
   30944:	49 89 f2             	mov    %rsi,%r10
   30947:	48 39 cf             	cmp    %rcx,%rdi
   3094a:	74 3f                	je     3098b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x22ab>
   3094c:	48 89 fe             	mov    %rdi,%rsi
   3094f:	41 8b 7a 08          	mov    0x8(%r10),%edi
   30953:	41 3b 3a             	cmp    (%r10),%edi
   30956:	7d e4                	jge    3093c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x225c>
   30958:	45 8b 42 0c          	mov    0xc(%r10),%r8d
   3095c:	4d 8b 0a             	mov    (%r10),%r9
   3095f:	4d 89 4a 08          	mov    %r9,0x8(%r10)
   30963:	49 89 d1             	mov    %rdx,%r9
   30966:	49 89 c3             	mov    %rax,%r11
   30969:	49 39 c2             	cmp    %rax,%r10
   3096c:	74 c4                	je     30932 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2252>
   3096e:	66 90                	xchg   %ax,%ax
   30970:	42 3b 7c 08 f8       	cmp    -0x8(%rax,%r9,1),%edi
   30975:	7d b5                	jge    3092c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x224c>
   30977:	4e 8b 54 08 f8       	mov    -0x8(%rax,%r9,1),%r10
   3097c:	4e 89 14 08          	mov    %r10,(%rax,%r9,1)
   30980:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   30984:	75 ea                	jne    30970 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2290>
   30986:	49 89 c3             	mov    %rax,%r11
   30989:	eb a7                	jmp    30932 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2252>
   3098b:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   30990:	eb 08                	jmp    3099a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x22ba>
   30992:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   30999:	00 
   3099a:	4c 89 34 24          	mov    %r14,(%rsp)
   3099e:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   309a3:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   309a8:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   309af:	00 
   309b0:	48 89 e6             	mov    %rsp,%rsi
   309b3:	e8 b8 8e ff ff       	call   29870 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   309b8:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   309bf:	00 
   309c0:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   309c7:	00 
   309c8:	e8 a3 63 00 00       	call   36d70 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   309cd:	84 c0                	test   %al,%al
   309cf:	0f 84 fa 25 00 00    	je     32fcf <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x48ef>
   309d5:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   309dc:	00 
   309dd:	e8 7e 97 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   309e2:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   309e9:	00 
   309ea:	4d 85 e4             	test   %r12,%r12
   309ed:	74 1a                	je     30a09 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2329>
   309ef:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   309f4:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   309f9:	4d 85 ff             	test   %r15,%r15
   309fc:	74 11                	je     30a0f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x232f>
   309fe:	49 83 ff 10          	cmp    $0x10,%r15
   30a02:	73 13                	jae    30a17 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2337>
   30a04:	45 31 e4             	xor    %r12d,%r12d
   30a07:	eb 1f                	jmp    30a28 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2348>
   30a09:	41 be 04 00 00 00    	mov    $0x4,%r14d
   30a0f:	45 31 ff             	xor    %r15d,%r15d
   30a12:	45 31 e4             	xor    %r12d,%r12d
   30a15:	eb 11                	jmp    30a28 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2348>
   30a17:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   30a1c:	49 83 c4 18          	add    $0x18,%r12
   30a20:	85 c0                	test   %eax,%eax
   30a22:	0f 85 ca 26 00 00    	jne    330f2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a12>
   30a28:	4c 8b 9c 24 68 01 00 	mov    0x168(%rsp),%r11
   30a2f:	00 
   30a30:	4d 85 db             	test   %r11,%r11
   30a33:	0f 84 e7 01 00 00    	je     30c20 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2540>
   30a39:	4d 8d 56 08          	lea    0x8(%r14),%r10
   30a3d:	4a 8d 3c fd f8 ff ff 	lea    -0x8(,%r15,8),%rdi
   30a44:	ff 
   30a45:	31 c0                	xor    %eax,%eax
   30a47:	eb 13                	jmp    30a5c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x237c>
   30a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30a50:	4c 89 e8             	mov    %r13,%rax
   30a53:	49 ff cb             	dec    %r11
   30a56:	0f 84 c6 01 00 00    	je     30c22 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2542>
   30a5c:	4c 89 fe             	mov    %r15,%rsi
   30a5f:	48 29 c6             	sub    %rax,%rsi
   30a62:	b9 00 00 00 00       	mov    $0x0,%ecx
   30a67:	48 0f 43 ce          	cmovae %rsi,%rcx
   30a6b:	49 83 ff 02          	cmp    $0x2,%r15
   30a6f:	73 1f                	jae    30a90 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x23b0>
   30a71:	4c 39 d9             	cmp    %r11,%rcx
   30a74:	0f 85 11 23 00 00    	jne    32d8b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46ab>
   30a7a:	4d 85 e4             	test   %r12,%r12
   30a7d:	74 3b                	je     30aba <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x23da>
   30a7f:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
   30a84:	e9 a9 00 00 00       	jmp    30b32 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2452>
   30a89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30a90:	4d 85 e4             	test   %r12,%r12
   30a93:	74 1c                	je     30ab1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x23d1>
   30a95:	49 8b 5c 24 10       	mov    0x10(%r12),%rbx
   30a9a:	4c 39 fb             	cmp    %r15,%rbx
   30a9d:	0f 85 86 00 00 00    	jne    30b29 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2449>
   30aa3:	4c 39 d9             	cmp    %r11,%rcx
   30aa6:	0f 84 8b 00 00 00    	je     30b37 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2457>
   30aac:	e9 da 22 00 00       	jmp    32d8b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46ab>
   30ab1:	4c 39 d9             	cmp    %r11,%rcx
   30ab4:	0f 82 d1 22 00 00    	jb     32d8b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46ab>
   30aba:	4c 39 f8             	cmp    %r15,%rax
   30abd:	0f 83 b4 26 00 00    	jae    33177 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a97>
   30ac3:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   30aca:	00 
   30acb:	48 89 fe             	mov    %rdi,%rsi
   30ace:	48 29 ce             	sub    %rcx,%rsi
   30ad1:	49 8d 1c c2          	lea    (%r10,%rax,8),%rbx
   30ad5:	4c 8d 68 01          	lea    0x1(%rax),%r13
   30ad9:	4d 39 fd             	cmp    %r15,%r13
   30adc:	0f 84 6e ff ff ff    	je     30a50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2370>
   30ae2:	41 8b 04 c6          	mov    (%r14,%rax,8),%eax
   30ae6:	31 c9                	xor    %ecx,%ecx
   30ae8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   30aef:	00 
   30af0:	39 04 0b             	cmp    %eax,(%rbx,%rcx,1)
   30af3:	74 1b                	je     30b10 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2430>
   30af5:	48 83 c1 08          	add    $0x8,%rcx
   30af9:	48 39 ce             	cmp    %rcx,%rsi
   30afc:	75 f2                	jne    30af0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2410>
   30afe:	e9 4d ff ff ff       	jmp    30a50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2370>
   30b03:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30b0a:	84 00 00 00 00 00 
   30b10:	48 83 c3 08          	add    $0x8,%rbx
   30b14:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   30b18:	4c 89 e8             	mov    %r13,%rax
   30b1b:	4c 8d 68 01          	lea    0x1(%rax),%r13
   30b1f:	4d 39 fd             	cmp    %r15,%r13
   30b22:	75 be                	jne    30ae2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2402>
   30b24:	e9 27 ff ff ff       	jmp    30a50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2370>
   30b29:	4c 39 d9             	cmp    %r11,%rcx
   30b2c:	0f 82 59 22 00 00    	jb     32d8b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46ab>
   30b32:	4c 39 fb             	cmp    %r15,%rbx
   30b35:	75 19                	jne    30b50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2470>
   30b37:	4c 39 f8             	cmp    %r15,%rax
   30b3a:	0f 82 d8 00 00 00    	jb     30c18 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2538>
   30b40:	e9 32 26 00 00       	jmp    33177 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a97>
   30b45:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   30b4c:	00 00 00 00 
   30b50:	be 28 00 00 00       	mov    $0x28,%esi
   30b55:	4c 39 f8             	cmp    %r15,%rax
   30b58:	0f 83 1e 26 00 00    	jae    3317c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a9c>
   30b5e:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
   30b63:	48 83 fb 01          	cmp    $0x1,%rbx
   30b67:	0f 84 80 00 00 00    	je     30bed <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x250d>
   30b6d:	48 89 fe             	mov    %rdi,%rsi
   30b70:	48 85 db             	test   %rbx,%rbx
   30b73:	75 14                	jne    30b89 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x24a9>
   30b75:	e9 60 25 00 00       	jmp    330da <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x49fa>
   30b7a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   30b80:	4c 39 f8             	cmp    %r15,%rax
   30b83:	0f 84 51 25 00 00    	je     330da <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x49fa>
   30b89:	48 89 c5             	mov    %rax,%rbp
   30b8c:	41 8b 0c c6          	mov    (%r14,%rax,8),%ecx
   30b90:	48 89 d8             	mov    %rbx,%rax
   30b93:	45 31 c9             	xor    %r9d,%r9d
   30b96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   30b9d:	00 00 00 
   30ba0:	4c 89 ca             	mov    %r9,%rdx
   30ba3:	48 89 c7             	mov    %rax,%rdi
   30ba6:	48 d1 ef             	shr    $1,%rdi
   30ba9:	49 01 f9             	add    %rdi,%r9
   30bac:	4d 89 c8             	mov    %r9,%r8
   30baf:	49 c1 e0 04          	shl    $0x4,%r8
   30bb3:	43 39 4c 05 00       	cmp    %ecx,0x0(%r13,%r8,1)
   30bb8:	4c 0f 4f ca          	cmovg  %rdx,%r9
   30bbc:	48 29 f8             	sub    %rdi,%rax
   30bbf:	48 83 f8 01          	cmp    $0x1,%rax
   30bc3:	77 db                	ja     30ba0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x24c0>
   30bc5:	48 8d 45 01          	lea    0x1(%rbp),%rax
   30bc9:	49 c1 e1 04          	shl    $0x4,%r9
   30bcd:	43 39 4c 0d 00       	cmp    %ecx,0x0(%r13,%r9,1)
   30bd2:	75 ac                	jne    30b80 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x24a0>
   30bd4:	4d 01 e9             	add    %r13,%r9
   30bd7:	49 39 69 08          	cmp    %rbp,0x8(%r9)
   30bdb:	75 a3                	jne    30b80 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x24a0>
   30bdd:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   30be4:	00 
   30be5:	48 89 f7             	mov    %rsi,%rdi
   30be8:	e9 66 fe ff ff       	jmp    30a53 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2373>
   30bed:	41 8b 4d 00          	mov    0x0(%r13),%ecx
   30bf1:	eb 19                	jmp    30c0c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x252c>
   30bf3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30bfa:	84 00 00 00 00 00 
   30c00:	48 ff c0             	inc    %rax
   30c03:	49 39 c7             	cmp    %rax,%r15
   30c06:	0f 84 70 25 00 00    	je     3317c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a9c>
   30c0c:	41 3b 0c c6          	cmp    (%r14,%rax,8),%ecx
   30c10:	75 ee                	jne    30c00 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2520>
   30c12:	49 3b 45 08          	cmp    0x8(%r13),%rax
   30c16:	75 e8                	jne    30c00 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2520>
   30c18:	48 ff c0             	inc    %rax
   30c1b:	e9 33 fe ff ff       	jmp    30a53 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2373>
   30c20:	31 c0                	xor    %eax,%eax
   30c22:	31 c9                	xor    %ecx,%ecx
   30c24:	4c 89 fa             	mov    %r15,%rdx
   30c27:	48 29 c2             	sub    %rax,%rdx
   30c2a:	48 0f 43 ca          	cmovae %rdx,%rcx
   30c2e:	49 83 ff 02          	cmp    $0x2,%r15
   30c32:	72 14                	jb     30c48 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2568>
   30c34:	4d 85 e4             	test   %r12,%r12
   30c37:	0f 84 9a 00 00 00    	je     30cd7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x25f7>
   30c3d:	4d 39 7c 24 10       	cmp    %r15,0x10(%r12)
   30c42:	0f 85 8f 00 00 00    	jne    30cd7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x25f7>
   30c48:	48 89 0c 24          	mov    %rcx,(%rsp)
   30c4c:	48 c7 44 24 08 01 00 	movq   $0x1,0x8(%rsp)
   30c53:	00 00 
   30c55:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   30c5a:	49 39 c7             	cmp    %rax,%r15
   30c5d:	0f 87 93 00 00 00    	ja     30cf6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2616>
   30c63:	4d 85 e4             	test   %r12,%r12
   30c66:	74 2f                	je     30c97 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x25b7>
   30c68:	49 8b 74 24 10       	mov    0x10(%r12),%rsi
   30c6d:	4c 39 fe             	cmp    %r15,%rsi
   30c70:	0f 85 8d 00 00 00    	jne    30d03 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2623>
   30c76:	4c 39 f8             	cmp    %r15,%rax
   30c79:	0f 83 7d 01 00 00    	jae    30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30c7f:	48 8d 15 52 fa 03 00 	lea    0x3fa52(%rip),%rdx        # 706d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x868>
   30c86:	be 28 00 00 00       	mov    $0x28,%esi
   30c8b:	48 8d 3d 4e 87 fd ff 	lea    -0x278b2(%rip),%rdi        # 93e0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1e9>
   30c92:	e9 07 21 00 00       	jmp    32d9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46be>
   30c97:	4c 39 f8             	cmp    %r15,%rax
   30c9a:	0f 83 5c 01 00 00    	jae    30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30ca0:	48 8d 14 c5 00 00 00 	lea    0x0(,%rax,8),%rdx
   30ca7:	00 
   30ca8:	49 8d 0c c6          	lea    (%r14,%rax,8),%rcx
   30cac:	48 83 c1 08          	add    $0x8,%rcx
   30cb0:	4e 8d 04 fd 00 00 00 	lea    0x0(,%r15,8),%r8
   30cb7:	00 
   30cb8:	49 29 d0             	sub    %rdx,%r8
   30cbb:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   30cbf:	48 8d 15 12 fa 03 00 	lea    0x3fa12(%rip),%rdx        # 706d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x868>
   30cc6:	48 8d 3d 13 87 fd ff 	lea    -0x278ed(%rip),%rdi        # 93e0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1e9>
   30ccd:	be 28 00 00 00       	mov    $0x28,%esi
   30cd2:	e9 7a 21 00 00       	jmp    32e51 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4771>
   30cd7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   30cde:	00 
   30cdf:	48 c7 44 24 08 01 00 	movq   $0x1,0x8(%rsp)
   30ce6:	00 00 
   30ce8:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   30ced:	49 39 c7             	cmp    %rax,%r15
   30cf0:	0f 86 6d ff ff ff    	jbe    30c63 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2583>
   30cf6:	48 89 e7             	mov    %rsp,%rdi
   30cf9:	e8 27 9a ff ff       	call   2a725 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedTjINtNtB4_6option6OptionjEEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   30cfe:	e9 16 28 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   30d03:	4c 39 f8             	cmp    %r15,%rax
   30d06:	0f 83 f0 00 00 00    	jae    30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30d0c:	48 85 f6             	test   %rsi,%rsi
   30d0f:	0f 84 e7 00 00 00    	je     30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30d15:	49 8b 4c 24 08       	mov    0x8(%r12),%rcx
   30d1a:	48 83 fe 01          	cmp    $0x1,%rsi
   30d1e:	75 6b                	jne    30d8b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x26ab>
   30d20:	8b 31                	mov    (%rcx),%esi
   30d22:	48 8d 15 af f9 03 00 	lea    0x3f9af(%rip),%rdx        # 706d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x868>
   30d29:	48 8d 3d b0 86 fd ff 	lea    -0x27950(%rip),%rdi        # 93e0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1e9>
   30d30:	eb 1a                	jmp    30d4c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x266c>
   30d32:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30d39:	1f 84 00 00 00 00 00 
   30d40:	48 ff c0             	inc    %rax
   30d43:	49 39 c7             	cmp    %rax,%r15
   30d46:	0f 84 b0 00 00 00    	je     30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30d4c:	41 3b 34 c6          	cmp    (%r14,%rax,8),%esi
   30d50:	75 ee                	jne    30d40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2660>
   30d52:	48 3b 41 08          	cmp    0x8(%rcx),%rax
   30d56:	75 e8                	jne    30d40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2660>
   30d58:	e9 8b 23 00 00       	jmp    330e8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a08>
   30d5d:	b3 01                	mov    $0x1,%bl
   30d5f:	49 89 f6             	mov    %rsi,%r14
   30d62:	bf 40 00 00 00       	mov    $0x40,%edi
   30d67:	ff 15 53 12 04 00    	call   *0x41253(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   30d6d:	48 85 c0             	test   %rax,%rax
   30d70:	0f 85 5b e1 ff ff    	jne    2eed1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x7f1>
   30d76:	bf 08 00 00 00       	mov    $0x8,%edi
   30d7b:	be 40 00 00 00       	mov    $0x40,%esi
   30d80:	ff 15 ea 11 04 00    	call   *0x411ea(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   30d86:	e9 8e 27 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   30d8b:	48 8d 15 46 f9 03 00 	lea    0x3f946(%rip),%rdx        # 706d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x868>
   30d92:	48 8d 3d 47 86 fd ff 	lea    -0x279b9(%rip),%rdi        # 93e0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1e9>
   30d99:	eb 0d                	jmp    30da8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x26c8>
   30d9b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30da0:	48 ff c0             	inc    %rax
   30da3:	4c 39 f8             	cmp    %r15,%rax
   30da6:	74 54                	je     30dfc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x271c>
   30da8:	45 8b 04 c6          	mov    (%r14,%rax,8),%r8d
   30dac:	49 89 f2             	mov    %rsi,%r10
   30daf:	45 31 c9             	xor    %r9d,%r9d
   30db2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30db9:	1f 84 00 00 00 00 00 
   30dc0:	4d 89 cb             	mov    %r9,%r11
   30dc3:	4c 89 d3             	mov    %r10,%rbx
   30dc6:	48 d1 eb             	shr    $1,%rbx
   30dc9:	49 01 d9             	add    %rbx,%r9
   30dcc:	4d 89 cc             	mov    %r9,%r12
   30dcf:	49 c1 e4 04          	shl    $0x4,%r12
   30dd3:	46 39 04 21          	cmp    %r8d,(%rcx,%r12,1)
   30dd7:	4d 0f 4f cb          	cmovg  %r11,%r9
   30ddb:	49 29 da             	sub    %rbx,%r10
   30dde:	49 83 fa 01          	cmp    $0x1,%r10
   30de2:	77 dc                	ja     30dc0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x26e0>
   30de4:	49 c1 e1 04          	shl    $0x4,%r9
   30de8:	46 39 04 09          	cmp    %r8d,(%rcx,%r9,1)
   30dec:	75 b2                	jne    30da0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x26c0>
   30dee:	49 01 c9             	add    %rcx,%r9
   30df1:	49 39 41 08          	cmp    %rax,0x8(%r9)
   30df5:	75 a9                	jne    30da0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x26c0>
   30df7:	e9 ec 22 00 00       	jmp    330e8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a08>
   30dfc:	45 31 d2             	xor    %r10d,%r10d
   30dff:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
   30e06:	00 
   30e07:	48 85 c0             	test   %rax,%rax
   30e0a:	0f 84 9b 01 00 00    	je     30fab <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28cb>
   30e10:	4c 8b 8c 24 90 00 00 	mov    0x90(%rsp),%r9
   30e17:	00 
   30e18:	4d 85 c9             	test   %r9,%r9
   30e1b:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
   30e22:	00 
   30e23:	0f 84 8a 01 00 00    	je     30fb3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28d3>
   30e29:	31 c9                	xor    %ecx,%ecx
   30e2b:	45 31 d2             	xor    %r10d,%r10d
   30e2e:	eb 2c                	jmp    30e5c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x277c>
   30e30:	48 8d 75 01          	lea    0x1(%rbp),%rsi
   30e34:	48 89 d1             	mov    %rdx,%rcx
   30e37:	48 ff c8             	dec    %rax
   30e3a:	48 63 7c aa 08       	movslq 0x8(%rdx,%rbp,4),%rdi
   30e3f:	49 01 fa             	add    %rdi,%r10
   30e42:	48 63 54 aa 34       	movslq 0x34(%rdx,%rbp,4),%rdx
   30e47:	49 01 d2             	add    %rdx,%r10
   30e4a:	41 b9 00 00 00 00    	mov    $0x0,%r9d
   30e50:	48 89 f5             	mov    %rsi,%rbp
   30e53:	48 85 c0             	test   %rax,%rax
   30e56:	0f 84 57 01 00 00    	je     30fb3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28d3>
   30e5c:	48 85 c9             	test   %rcx,%rcx
   30e5f:	74 1f                	je     30e80 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27a0>
   30e61:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   30e65:	48 39 d5             	cmp    %rdx,%rbp
   30e68:	0f 83 a2 00 00 00    	jae    30f10 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2830>
   30e6e:	48 89 ca             	mov    %rcx,%rdx
   30e71:	e9 b6 00 00 00       	jmp    30f2c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x284c>
   30e76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   30e7d:	00 00 00 
   30e80:	48 85 ed             	test   %rbp,%rbp
   30e83:	74 35                	je     30eba <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27da>
   30e85:	48 89 ea             	mov    %rbp,%rdx
   30e88:	4c 89 c9             	mov    %r9,%rcx
   30e8b:	48 83 e2 07          	and    $0x7,%rdx
   30e8f:	74 2e                	je     30ebf <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27df>
   30e91:	31 f6                	xor    %esi,%esi
   30e93:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30e9a:	84 00 00 00 00 00 
   30ea0:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ea4:	48 ff c6             	inc    %rsi
   30ea7:	48 39 f2             	cmp    %rsi,%rdx
   30eaa:	75 f4                	jne    30ea0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27c0>
   30eac:	48 89 ea             	mov    %rbp,%rdx
   30eaf:	48 29 f2             	sub    %rsi,%rdx
   30eb2:	48 83 fd 08          	cmp    $0x8,%rbp
   30eb6:	73 18                	jae    30ed0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27f0>
   30eb8:	eb 3c                	jmp    30ef6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2816>
   30eba:	4c 89 c9             	mov    %r9,%rcx
   30ebd:	eb 37                	jmp    30ef6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2816>
   30ebf:	48 89 ea             	mov    %rbp,%rdx
   30ec2:	48 83 fd 08          	cmp    $0x8,%rbp
   30ec6:	72 2e                	jb     30ef6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2816>
   30ec8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   30ecf:	00 
   30ed0:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ed4:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ed8:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30edc:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ee0:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ee4:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ee8:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30eec:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30ef0:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   30ef4:	75 da                	jne    30ed0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x27f0>
   30ef6:	31 ed                	xor    %ebp,%ebp
   30ef8:	45 31 c9             	xor    %r9d,%r9d
   30efb:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   30eff:	48 39 d5             	cmp    %rdx,%rbp
   30f02:	0f 82 66 ff ff ff    	jb     30e6e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x278e>
   30f08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   30f0f:	00 
   30f10:	48 8b 11             	mov    (%rcx),%rdx
   30f13:	48 85 d2             	test   %rdx,%rdx
   30f16:	0f 84 4d 21 00 00    	je     33069 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4989>
   30f1c:	49 ff c1             	inc    %r9
   30f1f:	0f b7 69 60          	movzwl 0x60(%rcx),%ebp
   30f23:	48 89 d1             	mov    %rdx,%rcx
   30f26:	66 3b 6a 62          	cmp    0x62(%rdx),%bp
   30f2a:	73 e4                	jae    30f10 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2830>
   30f2c:	4d 85 c9             	test   %r9,%r9
   30f2f:	0f 84 fb fe ff ff    	je     30e30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2750>
   30f35:	48 8d 34 ea          	lea    (%rdx,%rbp,8),%rsi
   30f39:	48 83 c6 70          	add    $0x70,%rsi
   30f3d:	4c 89 cf             	mov    %r9,%rdi
   30f40:	48 83 e7 07          	and    $0x7,%rdi
   30f44:	74 5a                	je     30fa0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28c0>
   30f46:	45 31 c0             	xor    %r8d,%r8d
   30f49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30f50:	48 8b 0e             	mov    (%rsi),%rcx
   30f53:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30f57:	49 ff c0             	inc    %r8
   30f5a:	4c 39 c7             	cmp    %r8,%rdi
   30f5d:	75 f1                	jne    30f50 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2870>
   30f5f:	4c 89 cf             	mov    %r9,%rdi
   30f62:	4c 29 c7             	sub    %r8,%rdi
   30f65:	49 83 f9 08          	cmp    $0x8,%r9
   30f69:	72 2e                	jb     30f99 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28b9>
   30f6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30f70:	48 8b 0e             	mov    (%rsi),%rcx
   30f73:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f77:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f7b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f7f:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f83:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f87:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f8b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30f8f:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30f93:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
   30f97:	75 d7                	jne    30f70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2890>
   30f99:	31 f6                	xor    %esi,%esi
   30f9b:	e9 97 fe ff ff       	jmp    30e37 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2757>
   30fa0:	4c 89 cf             	mov    %r9,%rdi
   30fa3:	49 83 f9 08          	cmp    $0x8,%r9
   30fa7:	73 c7                	jae    30f70 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2890>
   30fa9:	eb ee                	jmp    30f99 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x28b9>
   30fab:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
   30fb2:	00 
   30fb3:	48 83 7c 24 68 00    	cmpq   $0x0,0x68(%rsp)
   30fb9:	0f 84 6f 07 00 00    	je     3172e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x304e>
   30fbf:	4c 89 94 24 90 00 00 	mov    %r10,0x90(%rsp)
   30fc6:	00 
   30fc7:	48 8d 84 24 40 02 00 	lea    0x240(%rsp),%rax
   30fce:	00 
   30fcf:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   30fd6:	00 
   30fd7:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
   30fde:	00 
   30fdf:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   30fe6:	00 
   30fe7:	48 8b 84 24 30 02 00 	mov    0x230(%rsp),%rax
   30fee:	00 
   30fef:	48 89 84 24 c8 00 00 	mov    %rax,0xc8(%rsp)
   30ff6:	00 
   30ff7:	48 8d 84 24 a0 01 00 	lea    0x1a0(%rsp),%rax
   30ffe:	00 
   30fff:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   31006:	00 
   31007:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   3100e:	00 
   3100f:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   31016:	00 
   31017:	bd 64 00 00 00       	mov    $0x64,%ebp
   3101c:	48 8d 9c 24 b8 00 00 	lea    0xb8(%rsp),%rbx
   31023:	00 
   31024:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   3102b:	00 00 00 00 00 
   31030:	48 89 df             	mov    %rbx,%rdi
   31033:	e8 d8 c8 ff ff       	call   2d910 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_>
   31038:	ff cd                	dec    %ebp
   3103a:	75 f4                	jne    31030 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2950>
   3103c:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
   31043:	00 00 00 00 00 
   31048:	48 c7 84 24 c8 01 00 	movq   $0x8,0x1c8(%rsp)
   3104f:	00 08 00 00 00 
   31054:	48 c7 84 24 d0 01 00 	movq   $0x0,0x1d0(%rsp)
   3105b:	00 00 00 00 00 
   31060:	48 89 e5             	mov    %rsp,%rbp
   31063:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   31068:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
   3106f:	00 00 00 00 00 
   31074:	eb 4c                	jmp    310c2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x29e2>
   31076:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   3107d:	00 00 00 
   31080:	48 8b 84 24 c8 01 00 	mov    0x1c8(%rsp),%rax
   31087:	00 
   31088:	48 89 d9             	mov    %rbx,%rcx
   3108b:	48 c1 e1 05          	shl    $0x5,%rcx
   3108f:	66 0f 10 44 24 70    	movupd 0x70(%rsp),%xmm0
   31095:	f3 0f 6f 8c 24 80 00 	movdqu 0x80(%rsp),%xmm1
   3109c:	00 00 
   3109e:	f3 0f 7f 4c 08 10    	movdqu %xmm1,0x10(%rax,%rcx,1)
   310a4:	66 0f 11 04 08       	movupd %xmm0,(%rax,%rcx,1)
   310a9:	48 ff c3             	inc    %rbx
   310ac:	48 89 9c 24 d0 01 00 	mov    %rbx,0x1d0(%rsp)
   310b3:	00 
   310b4:	4c 39 b4 24 a0 00 00 	cmp    %r14,0xa0(%rsp)
   310bb:	00 
   310bc:	0f 84 21 05 00 00    	je     315e3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2f03>
   310c2:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   310c6:	66 0f 29 04 24       	movapd %xmm0,(%rsp)
   310cb:	bf 02 00 00 00       	mov    $0x2,%edi
   310d0:	48 89 ee             	mov    %rbp,%rsi
   310d3:	ff 15 b7 12 04 00    	call   *0x412b7(%rip)        # 72390 <clock_gettime@GLIBC_2.17>
   310d9:	89 44 24 30          	mov    %eax,0x30(%rsp)
   310dd:	85 c0                	test   %eax,%eax
   310df:	0f 85 ac 1d 00 00    	jne    32e91 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x47b1>
   310e5:	4c 8b 2c 24          	mov    (%rsp),%r13
   310e9:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   310ee:	bf 01 00 00 00       	mov    $0x1,%edi
   310f3:	e8 48 40 02 00       	call   55140 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   310f8:	48 89 c3             	mov    %rax,%rbx
   310fb:	89 d5                	mov    %edx,%ebp
   310fd:	48 ff 84 24 a0 00 00 	incq   0xa0(%rsp)
   31104:	00 
   31105:	45 31 f6             	xor    %r14d,%r14d
   31108:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3110f:	00 
   31110:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   31117:	00 
   31118:	e8 f3 c7 ff ff       	call   2d910 <_RNCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains1_0B3_>
   3111d:	49 ff c6             	inc    %r14
   31120:	4c 39 74 24 68       	cmp    %r14,0x68(%rsp)
   31125:	75 e9                	jne    31110 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2a30>
   31127:	bf 01 00 00 00       	mov    $0x1,%edi
   3112c:	e8 0f 40 02 00       	call   55140 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   31131:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   31136:	89 54 24 78          	mov    %edx,0x78(%rsp)
   3113a:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   3113f:	89 6c 24 38          	mov    %ebp,0x38(%rsp)
   31143:	48 89 e7             	mov    %rsp,%rdi
   31146:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   3114b:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   31150:	e8 2b 3f 02 00       	call   55080 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.4795996092214488023>
   31155:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
   31159:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
   3115e:	48 f7 64 24 08       	mulq   0x8(%rsp)
   31163:	48 89 d3             	mov    %rdx,%rbx
   31166:	49 89 c6             	mov    %rax,%r14
   31169:	49 01 ce             	add    %rcx,%r14
   3116c:	48 83 d3 00          	adc    $0x0,%rbx
   31170:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   31174:	b8 00 00 00 00       	mov    $0x0,%eax
   31179:	4c 0f 45 f0          	cmovne %rax,%r14
   3117d:	48 0f 45 d8          	cmovne %rax,%rbx
   31181:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   31185:	66 0f 29 04 24       	movapd %xmm0,(%rsp)
   3118a:	bf 02 00 00 00       	mov    $0x2,%edi
   3118f:	48 89 e5             	mov    %rsp,%rbp
   31192:	48 89 ee             	mov    %rbp,%rsi
   31195:	ff 15 f5 11 04 00    	call   *0x411f5(%rip)        # 72390 <clock_gettime@GLIBC_2.17>
   3119b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   3119f:	85 c0                	test   %eax,%eax
   311a1:	0f 85 e5 1c 00 00    	jne    32e8c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x47ac>
   311a7:	4c 89 b4 24 98 01 00 	mov    %r14,0x198(%rsp)
   311ae:	00 
   311af:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   311b4:	4c 89 f9             	mov    %r15,%rcx
   311b7:	48 c1 f9 3f          	sar    $0x3f,%rcx
   311bb:	4c 89 ea             	mov    %r13,%rdx
   311be:	48 c1 fa 3f          	sar    $0x3f,%rdx
   311c2:	48 8b 04 24          	mov    (%rsp),%rax
   311c6:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   311cb:	48 89 c6             	mov    %rax,%rsi
   311ce:	48 c1 fe 3f          	sar    $0x3f,%rsi
   311d2:	4d 89 f4             	mov    %r14,%r12
   311d5:	49 c1 fc 3f          	sar    $0x3f,%r12
   311d9:	4c 29 e8             	sub    %r13,%rax
   311dc:	48 19 d6             	sbb    %rdx,%rsi
   311df:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
   311e4:	48 f7 e2             	mul    %rdx
   311e7:	48 69 f6 00 ca 9a 3b 	imul   $0x3b9aca00,%rsi,%rsi
   311ee:	48 01 d6             	add    %rdx,%rsi
   311f1:	4d 29 fe             	sub    %r15,%r14
   311f4:	49 19 cc             	sbb    %rcx,%r12
   311f7:	49 01 c6             	add    %rax,%r14
   311fa:	49 11 f4             	adc    %rsi,%r12
   311fd:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
   31204:	00 00 00 00 00 
   31209:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   31210:	00 00 00 00 00 
   31215:	41 bf 0a 00 00 00    	mov    $0xa,%r15d
   3121b:	bf 0a 00 00 00       	mov    $0xa,%edi
   31220:	ff 15 9a 0d 04 00    	call   *0x40d9a(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31226:	48 85 c0             	test   %rax,%rax
   31229:	0f 84 d6 1e 00 00    	je     33105 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a25>
   3122f:	48 89 c3             	mov    %rax,%rbx
   31232:	48 b8 69 74 65 72 61 	movabs $0x6f69746172657469,%rax
   31239:	74 69 6f 
   3123c:	48 89 03             	mov    %rax,(%rbx)
   3123f:	66 c7 43 08 6e 73    	movw   $0x736e,0x8(%rbx)
   31245:	48 c7 84 24 e0 00 00 	movq   $0xa,0xe0(%rsp)
   3124c:	00 0a 00 00 00 
   31251:	48 89 9c 24 e8 00 00 	mov    %rbx,0xe8(%rsp)
   31258:	00 
   31259:	48 c7 84 24 f0 00 00 	movq   $0xa,0xf0(%rsp)
   31260:	00 0a 00 00 00 
   31265:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   3126a:	48 89 ee             	mov    %rbp,%rsi
   3126d:	ff 15 65 10 04 00    	call   *0x41065(%rip)        # 722d8 <_DYNAMIC+0x560>
   31273:	49 89 c5             	mov    %rax,%r13
   31276:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   3127a:	49 f7 df             	neg    %r15
   3127d:	bd 01 00 00 00       	mov    $0x1,%ebp
   31282:	48 83 f8 14          	cmp    $0x14,%rax
   31286:	74 25                	je     312ad <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2bcd>
   31288:	4c 89 ff             	mov    %r15,%rdi
   3128b:	ff 15 2f 0d 04 00    	call   *0x40d2f(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31291:	48 85 c0             	test   %rax,%rax
   31294:	0f 84 3e 1f 00 00    	je     331d8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4af8>
   3129a:	48 89 c5             	mov    %rax,%rbp
   3129d:	4a 8d 34 2c          	lea    (%rsp,%r13,1),%rsi
   312a1:	48 89 c7             	mov    %rax,%rdi
   312a4:	4c 89 fa             	mov    %r15,%rdx
   312a7:	ff 15 e3 0c 04 00    	call   *0x40ce3(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   312ad:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   312b2:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   312b7:	c6 04 24 02          	movb   $0x2,(%rsp)
   312bb:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   312c0:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   312c5:	4c 89 ef             	mov    %r13,%rdi
   312c8:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   312cf:	00 
   312d0:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   312d7:	00 
   312d8:	48 89 e5             	mov    %rsp,%rbp
   312db:	48 89 e9             	mov    %rbp,%rcx
   312de:	e8 4d 2c 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   312e3:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   312e8:	74 08                	je     312f2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2c12>
   312ea:	4c 89 ef             	mov    %r13,%rdi
   312ed:	e8 de 91 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   312f2:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   312f8:	bf 06 00 00 00       	mov    $0x6,%edi
   312fd:	ff 15 bd 0c 04 00    	call   *0x40cbd(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31303:	48 85 c0             	test   %rax,%rax
   31306:	0f 84 f9 1d 00 00    	je     33105 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a25>
   3130c:	48 89 c3             	mov    %rax,%rbx
   3130f:	66 c7 40 04 6e 73    	movw   $0x736e,0x4(%rax)
   31315:	c7 00 63 70 75 5f    	movl   $0x5f757063,(%rax)
   3131b:	48 c7 84 24 e0 00 00 	movq   $0x6,0xe0(%rsp)
   31322:	00 06 00 00 00 
   31327:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   3132e:	00 
   3132f:	48 c7 84 24 f0 00 00 	movq   $0x6,0xf0(%rsp)
   31336:	00 06 00 00 00 
   3133b:	4c 89 f7             	mov    %r14,%rdi
   3133e:	4c 89 e6             	mov    %r12,%rsi
   31341:	48 89 ea             	mov    %rbp,%rdx
   31344:	ff 15 7e 0f 04 00    	call   *0x40f7e(%rip)        # 722c8 <_DYNAMIC+0x550>
   3134a:	49 89 c4             	mov    %rax,%r12
   3134d:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   31351:	49 f7 de             	neg    %r14
   31354:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   3135a:	48 83 f8 27          	cmp    $0x27,%rax
   3135e:	74 25                	je     31385 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2ca5>
   31360:	4c 89 f7             	mov    %r14,%rdi
   31363:	ff 15 57 0c 04 00    	call   *0x40c57(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31369:	48 85 c0             	test   %rax,%rax
   3136c:	0f 84 53 1e 00 00    	je     331c5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ae5>
   31372:	49 89 c7             	mov    %rax,%r15
   31375:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31379:	48 89 c7             	mov    %rax,%rdi
   3137c:	4c 89 f2             	mov    %r14,%rdx
   3137f:	ff 15 0b 0c 04 00    	call   *0x40c0b(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31385:	c6 04 24 02          	movb   $0x2,(%rsp)
   31389:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   3138e:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   31393:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   31398:	4c 89 ef             	mov    %r13,%rdi
   3139b:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   313a2:	00 
   313a3:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   313aa:	00 
   313ab:	48 89 e9             	mov    %rbp,%rcx
   313ae:	e8 7d 2b 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   313b3:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   313b8:	74 08                	je     313c2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2ce2>
   313ba:	4c 89 ef             	mov    %r13,%rdi
   313bd:	e8 0e 91 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   313c2:	41 bf 07 00 00 00    	mov    $0x7,%r15d
   313c8:	bf 07 00 00 00       	mov    $0x7,%edi
   313cd:	ff 15 ed 0b 04 00    	call   *0x40bed(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   313d3:	48 85 c0             	test   %rax,%rax
   313d6:	0f 84 29 1d 00 00    	je     33105 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a25>
   313dc:	48 89 c3             	mov    %rax,%rbx
   313df:	c7 40 03 6c 5f 6e 73 	movl   $0x736e5f6c,0x3(%rax)
   313e6:	c7 00 77 61 6c 6c    	movl   $0x6c6c6177,(%rax)
   313ec:	48 c7 84 24 e0 00 00 	movq   $0x7,0xe0(%rsp)
   313f3:	00 07 00 00 00 
   313f8:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   313ff:	00 
   31400:	48 c7 84 24 f0 00 00 	movq   $0x7,0xf0(%rsp)
   31407:	00 07 00 00 00 
   3140c:	48 8b bc 24 98 01 00 	mov    0x198(%rsp),%rdi
   31413:	00 
   31414:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   31419:	48 89 ea             	mov    %rbp,%rdx
   3141c:	ff 15 a6 0e 04 00    	call   *0x40ea6(%rip)        # 722c8 <_DYNAMIC+0x550>
   31422:	49 89 c4             	mov    %rax,%r12
   31425:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   31429:	49 f7 de             	neg    %r14
   3142c:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31432:	48 83 f8 27          	cmp    $0x27,%rax
   31436:	74 25                	je     3145d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2d7d>
   31438:	4c 89 f7             	mov    %r14,%rdi
   3143b:	ff 15 7f 0b 04 00    	call   *0x40b7f(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31441:	48 85 c0             	test   %rax,%rax
   31444:	0f 84 a1 1d 00 00    	je     331eb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b0b>
   3144a:	49 89 c7             	mov    %rax,%r15
   3144d:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31451:	48 89 c7             	mov    %rax,%rdi
   31454:	4c 89 f2             	mov    %r14,%rdx
   31457:	ff 15 33 0b 04 00    	call   *0x40b33(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   3145d:	c6 04 24 02          	movb   $0x2,(%rsp)
   31461:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   31466:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   3146b:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   31470:	4c 89 ef             	mov    %r13,%rdi
   31473:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3147a:	00 
   3147b:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   31482:	00 
   31483:	48 89 e9             	mov    %rbp,%rcx
   31486:	e8 a5 2a 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3148b:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31490:	74 08                	je     3149a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2dba>
   31492:	4c 89 ef             	mov    %r13,%rdi
   31495:	e8 36 90 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3149a:	41 bf 10 00 00 00    	mov    $0x10,%r15d
   314a0:	bf 10 00 00 00       	mov    $0x10,%edi
   314a5:	ff 15 15 0b 04 00    	call   *0x40b15(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   314ab:	48 85 c0             	test   %rax,%rax
   314ae:	0f 84 51 1c 00 00    	je     33105 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a25>
   314b4:	66 0f 10 05 54 60 fd 	movupd -0x29fac(%rip),%xmm0        # 7510 <anon.0f363c1c2085502831f1e7e323c26323.407.llvm.704920437039905144+0x170>
   314bb:	ff 
   314bc:	66 0f 11 00          	movupd %xmm0,(%rax)
   314c0:	48 c7 84 24 e0 00 00 	movq   $0x10,0xe0(%rsp)
   314c7:	00 10 00 00 00 
   314cc:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   314d3:	00 
   314d4:	48 c7 84 24 f0 00 00 	movq   $0x10,0xf0(%rsp)
   314db:	00 10 00 00 00 
   314e0:	c6 04 24 00          	movb   $0x0,(%rsp)
   314e4:	4c 89 ef             	mov    %r13,%rdi
   314e7:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   314ee:	00 
   314ef:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   314f6:	00 
   314f7:	48 89 e9             	mov    %rbp,%rcx
   314fa:	e8 31 2a 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   314ff:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31504:	74 08                	je     3150e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2e2e>
   31506:	4c 89 ef             	mov    %r13,%rdi
   31509:	e8 c2 8f ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3150e:	41 bf 0f 00 00 00    	mov    $0xf,%r15d
   31514:	bf 0f 00 00 00       	mov    $0xf,%edi
   31519:	ff 15 a1 0a 04 00    	call   *0x40aa1(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3151f:	48 85 c0             	test   %rax,%rax
   31522:	0f 84 dd 1b 00 00    	je     33105 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4a25>
   31528:	48 b9 65 64 5f 62 79 	movabs $0x73657479625f6465,%rcx
   3152f:	74 65 73 
   31532:	48 89 48 07          	mov    %rcx,0x7(%rax)
   31536:	48 b9 72 65 71 75 65 	movabs $0x6574736575716572,%rcx
   3153d:	73 74 65 
   31540:	48 89 08             	mov    %rcx,(%rax)
   31543:	48 c7 84 24 e0 00 00 	movq   $0xf,0xe0(%rsp)
   3154a:	00 0f 00 00 00 
   3154f:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   31556:	00 
   31557:	48 c7 84 24 f0 00 00 	movq   $0xf,0xf0(%rsp)
   3155e:	00 0f 00 00 00 
   31563:	c6 04 24 00          	movb   $0x0,(%rsp)
   31567:	4c 89 ef             	mov    %r13,%rdi
   3156a:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31571:	00 
   31572:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   31579:	00 
   3157a:	48 89 e9             	mov    %rbp,%rcx
   3157d:	e8 ae 29 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31582:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31587:	74 08                	je     31591 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2eb1>
   31589:	4c 89 ef             	mov    %r13,%rdi
   3158c:	e8 3f 8f ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31591:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   31598:	00 
   31599:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
   3159e:	48 89 41 10          	mov    %rax,0x10(%rcx)
   315a2:	0f 10 84 24 18 01 00 	movups 0x118(%rsp),%xmm0
   315a9:	00 
   315aa:	0f 11 01             	movups %xmm0,(%rcx)
   315ad:	c6 44 24 70 05       	movb   $0x5,0x70(%rsp)
   315b2:	48 8b 9c 24 d0 01 00 	mov    0x1d0(%rsp),%rbx
   315b9:	00 
   315ba:	48 3b 9c 24 c0 01 00 	cmp    0x1c0(%rsp),%rbx
   315c1:	00 
   315c2:	4c 8b b4 24 70 02 00 	mov    0x270(%rsp),%r14
   315c9:	00 
   315ca:	0f 85 b0 fa ff ff    	jne    31080 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x29a0>
   315d0:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   315d7:	00 
   315d8:	ff 15 9a 0d 04 00    	call   *0x40d9a(%rip)        # 72378 <_DYNAMIC+0x600>
   315de:	e9 9d fa ff ff       	jmp    31080 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x29a0>
   315e3:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
   315ea:	00 00 00 00 00 
   315ef:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   315f6:	00 00 00 00 00 
   315fb:	41 bd 06 00 00 00    	mov    $0x6,%r13d
   31601:	bf 06 00 00 00       	mov    $0x6,%edi
   31606:	ff 15 b4 09 04 00    	call   *0x409b4(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3160c:	48 85 c0             	test   %rax,%rax
   3160f:	0f 84 e9 1b 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31615:	48 89 c3             	mov    %rax,%rbx
   31618:	66 c7 40 04 6d 61    	movw   $0x616d,0x4(%rax)
   3161e:	c7 00 73 63 68 65    	movl   $0x65686373,(%rax)
   31624:	48 c7 44 24 70 06 00 	movq   $0x6,0x70(%rsp)
   3162b:	00 00 
   3162d:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   31632:	48 c7 84 24 80 00 00 	movq   $0x6,0x80(%rsp)
   31639:	00 06 00 00 00 
   3163e:	bf 15 00 00 00       	mov    $0x15,%edi
   31643:	ff 15 77 09 04 00    	call   *0x40977(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31649:	48 85 c0             	test   %rax,%rax
   3164c:	0f 84 60 1d 00 00    	je     333b2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cd2>
   31652:	66 0f 10 05 c0 7d fd 	movupd -0x28240(%rip),%xmm0        # 941a <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x223>
   31659:	ff 
   3165a:	66 0f 11 00          	movupd %xmm0,(%rax)
   3165e:	48 b9 2d 70 72 6f 6f 	movabs $0x312f666f6f72702d,%rcx
   31665:	66 2f 31 
   31668:	48 89 48 0d          	mov    %rcx,0xd(%rax)
   3166c:	c6 04 24 03          	movb   $0x3,(%rsp)
   31670:	48 c7 44 24 08 15 00 	movq   $0x15,0x8(%rsp)
   31677:	00 00 
   31679:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   3167e:	48 c7 44 24 18 15 00 	movq   $0x15,0x18(%rsp)
   31685:	00 00 
   31687:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3168c:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31693:	00 
   31694:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31699:	48 89 e1             	mov    %rsp,%rcx
   3169c:	e8 8f 28 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   316a1:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   316a6:	74 0a                	je     316b2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2fd2>
   316a8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   316ad:	e8 1e 8e ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   316b2:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   316b8:	bf 04 00 00 00       	mov    $0x4,%edi
   316bd:	ff 15 fd 08 04 00    	call   *0x408fd(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   316c3:	48 85 c0             	test   %rax,%rax
   316c6:	0f 84 32 1b 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   316cc:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   316d2:	48 c7 44 24 70 04 00 	movq   $0x4,0x70(%rsp)
   316d9:	00 00 
   316db:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   316e0:	48 c7 84 24 80 00 00 	movq   $0x4,0x80(%rsp)
   316e7:	00 04 00 00 00 
   316ec:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   316f1:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   316f5:	48 85 db             	test   %rbx,%rbx
   316f8:	0f 84 cc 00 00 00    	je     317ca <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x30ea>
   316fe:	49 89 c6             	mov    %rax,%r14
   31701:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   31705:	48 89 df             	mov    %rbx,%rdi
   31708:	ff 15 b2 08 04 00    	call   *0x408b2(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3170e:	48 85 c0             	test   %rax,%rax
   31711:	0f 84 ef 1c 00 00    	je     33406 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d26>
   31717:	49 89 c7             	mov    %rax,%r15
   3171a:	48 89 c7             	mov    %rax,%rdi
   3171d:	4c 89 e6             	mov    %r12,%rsi
   31720:	48 89 da             	mov    %rbx,%rdx
   31723:	ff 15 67 08 04 00    	call   *0x40867(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31729:	e9 a2 00 00 00       	jmp    317d0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x30f0>
   3172e:	4c 89 d5             	mov    %r10,%rbp
   31731:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
   31738:	00 00 00 00 00 
   3173d:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
   31744:	00 00 00 00 00 
   31749:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   3174f:	bf 04 00 00 00       	mov    $0x4,%edi
   31754:	ff 15 66 08 04 00    	call   *0x40866(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3175a:	48 85 c0             	test   %rax,%rax
   3175d:	0f 84 ae 1a 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   31763:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   31769:	48 c7 44 24 30 04 00 	movq   $0x4,0x30(%rsp)
   31770:	00 00 
   31772:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   31777:	48 c7 44 24 40 04 00 	movq   $0x4,0x40(%rsp)
   3177e:	00 00 
   31780:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   31785:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   31789:	48 85 db             	test   %rbx,%rbx
   3178c:	0f 84 7d 0c 00 00    	je     3240f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3d2f>
   31792:	49 89 c6             	mov    %rax,%r14
   31795:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   31799:	48 89 df             	mov    %rbx,%rdi
   3179c:	ff 15 1e 08 04 00    	call   *0x4081e(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   317a2:	48 85 c0             	test   %rax,%rax
   317a5:	0f 84 f0 1c 00 00    	je     3349b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4dbb>
   317ab:	49 89 c7             	mov    %rax,%r15
   317ae:	48 89 c7             	mov    %rax,%rdi
   317b1:	4c 89 e6             	mov    %r12,%rsi
   317b4:	48 89 da             	mov    %rbx,%rdx
   317b7:	ff 15 d3 07 04 00    	call   *0x407d3(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   317bd:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
   317c4:	00 
   317c5:	e9 4b 0c 00 00       	jmp    32415 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3d35>
   317ca:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   317d0:	c6 04 24 03          	movb   $0x3,(%rsp)
   317d4:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   317d9:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   317de:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   317e3:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   317e8:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   317ef:	00 
   317f0:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   317f5:	48 89 e1             	mov    %rsp,%rcx
   317f8:	e8 33 27 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   317fd:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31802:	74 0a                	je     3180e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x312e>
   31804:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31809:	e8 c2 8c ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3180e:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   31814:	bf 07 00 00 00       	mov    $0x7,%edi
   31819:	ff 15 a1 07 04 00    	call   *0x407a1(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3181f:	48 85 c0             	test   %rax,%rax
   31822:	0f 84 d6 19 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31828:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   3182f:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   31835:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   3183c:	00 00 
   3183e:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   31843:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   3184a:	00 07 00 00 00 
   3184f:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   31856:	00 
   31857:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   3185b:	48 85 db             	test   %rbx,%rbx
   3185e:	74 2d                	je     3188d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x31ad>
   31860:	49 89 c6             	mov    %rax,%r14
   31863:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   31867:	48 89 df             	mov    %rbx,%rdi
   3186a:	ff 15 50 07 04 00    	call   *0x40750(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31870:	48 85 c0             	test   %rax,%rax
   31873:	0f 84 a0 1b 00 00    	je     33419 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d39>
   31879:	49 89 c7             	mov    %rax,%r15
   3187c:	48 89 c7             	mov    %rax,%rdi
   3187f:	4c 89 e6             	mov    %r12,%rsi
   31882:	48 89 da             	mov    %rbx,%rdx
   31885:	ff 15 05 07 04 00    	call   *0x40705(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   3188b:	eb 06                	jmp    31893 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x31b3>
   3188d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31893:	c6 04 24 03          	movb   $0x3,(%rsp)
   31897:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   3189c:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   318a1:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   318a6:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   318ab:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   318b2:	00 
   318b3:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   318b8:	48 89 e1             	mov    %rsp,%rcx
   318bb:	e8 70 26 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   318c0:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   318c5:	74 0a                	je     318d1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x31f1>
   318c7:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   318cc:	e8 ff 8b ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   318d1:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   318d7:	bf 09 00 00 00       	mov    $0x9,%edi
   318dc:	ff 15 de 06 04 00    	call   *0x406de(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   318e2:	48 85 c0             	test   %rax,%rax
   318e5:	0f 84 13 19 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   318eb:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   318f2:	74 69 6f 
   318f5:	48 89 08             	mov    %rcx,(%rax)
   318f8:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   318fc:	48 c7 44 24 70 09 00 	movq   $0x9,0x70(%rsp)
   31903:	00 00 
   31905:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   3190a:	48 c7 84 24 80 00 00 	movq   $0x9,0x80(%rsp)
   31911:	00 09 00 00 00 
   31916:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   3191b:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   3191f:	48 85 db             	test   %rbx,%rbx
   31922:	74 2d                	je     31951 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3271>
   31924:	49 89 c6             	mov    %rax,%r14
   31927:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   3192b:	48 89 df             	mov    %rbx,%rdi
   3192e:	ff 15 8c 06 04 00    	call   *0x4068c(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31934:	48 85 c0             	test   %rax,%rax
   31937:	0f 84 ef 1a 00 00    	je     3342c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d4c>
   3193d:	49 89 c7             	mov    %rax,%r15
   31940:	48 89 c7             	mov    %rax,%rdi
   31943:	4c 89 e6             	mov    %r12,%rsi
   31946:	48 89 da             	mov    %rbx,%rdx
   31949:	ff 15 41 06 04 00    	call   *0x40641(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   3194f:	eb 06                	jmp    31957 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3277>
   31951:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31957:	c6 04 24 03          	movb   $0x3,(%rsp)
   3195b:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   31960:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   31965:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   3196a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3196f:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31976:	00 
   31977:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   3197c:	48 89 e1             	mov    %rsp,%rcx
   3197f:	e8 ac 25 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31984:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31989:	74 0a                	je     31995 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x32b5>
   3198b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31990:	e8 3b 8b ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31995:	41 bd 05 00 00 00    	mov    $0x5,%r13d
   3199b:	bf 05 00 00 00       	mov    $0x5,%edi
   319a0:	ff 15 1a 06 04 00    	call   *0x4061a(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   319a6:	48 85 c0             	test   %rax,%rax
   319a9:	0f 84 4f 18 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   319af:	48 89 c3             	mov    %rax,%rbx
   319b2:	c6 40 04 74          	movb   $0x74,0x4(%rax)
   319b6:	c7 00 69 6e 70 75    	movl   $0x75706e69,(%rax)
   319bc:	48 c7 44 24 70 05 00 	movq   $0x5,0x70(%rsp)
   319c3:	00 00 
   319c5:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   319ca:	48 c7 84 24 80 00 00 	movq   $0x5,0x80(%rsp)
   319d1:	00 05 00 00 00 
   319d6:	bf 79 00 00 00       	mov    $0x79,%edi
   319db:	ff 15 df 05 04 00    	call   *0x405df(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   319e1:	48 85 c0             	test   %rax,%rax
   319e4:	0f 84 dd 19 00 00    	je     333c7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ce7>
   319ea:	0f 10 05 a7 7a fd ff 	movups -0x28559(%rip),%xmm0        # 9498 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2a1>
   319f1:	0f 11 40 69          	movups %xmm0,0x69(%rax)
   319f5:	0f 10 05 93 7a fd ff 	movups -0x2856d(%rip),%xmm0        # 948f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x298>
   319fc:	0f 11 40 60          	movups %xmm0,0x60(%rax)
   31a00:	0f 10 05 78 7a fd ff 	movups -0x28588(%rip),%xmm0        # 947f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x288>
   31a07:	0f 11 40 50          	movups %xmm0,0x50(%rax)
   31a0b:	0f 10 05 5d 7a fd ff 	movups -0x285a3(%rip),%xmm0        # 946f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x278>
   31a12:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   31a16:	0f 10 05 42 7a fd ff 	movups -0x285be(%rip),%xmm0        # 945f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x268>
   31a1d:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   31a21:	0f 10 05 27 7a fd ff 	movups -0x285d9(%rip),%xmm0        # 944f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x258>
   31a28:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   31a2c:	0f 10 05 0c 7a fd ff 	movups -0x285f4(%rip),%xmm0        # 943f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x248>
   31a33:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   31a37:	66 0f 10 05 f0 79 fd 	movupd -0x28610(%rip),%xmm0        # 942f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x238>
   31a3e:	ff 
   31a3f:	66 0f 11 00          	movupd %xmm0,(%rax)
   31a43:	c6 04 24 03          	movb   $0x3,(%rsp)
   31a47:	48 c7 44 24 08 79 00 	movq   $0x79,0x8(%rsp)
   31a4e:	00 00 
   31a50:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   31a55:	48 c7 44 24 18 79 00 	movq   $0x79,0x18(%rsp)
   31a5c:	00 00 
   31a5e:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31a63:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31a6a:	00 
   31a6b:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31a70:	48 89 e1             	mov    %rsp,%rcx
   31a73:	e8 b8 24 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31a78:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31a7d:	74 0a                	je     31a89 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x33a9>
   31a7f:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31a84:	e8 47 8a ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31a89:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   31a8f:	bf 07 00 00 00       	mov    $0x7,%edi
   31a94:	ff 15 26 05 04 00    	call   *0x40526(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31a9a:	48 85 c0             	test   %rax,%rax
   31a9d:	0f 84 5b 17 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31aa3:	48 89 c3             	mov    %rax,%rbx
   31aa6:	c7 40 03 74 72 6f 6c 	movl   $0x6c6f7274,0x3(%rax)
   31aad:	c7 00 63 6f 6e 74    	movl   $0x746e6f63,(%rax)
   31ab3:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   31aba:	00 00 
   31abc:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   31ac1:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   31ac8:	00 07 00 00 00 
   31acd:	bf 53 00 00 00       	mov    $0x53,%edi
   31ad2:	ff 15 e8 04 04 00    	call   *0x404e8(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31ad8:	48 85 c0             	test   %rax,%rax
   31adb:	0f 84 fb 18 00 00    	je     333dc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4cfc>
   31ae1:	0f 10 05 00 7a fd ff 	movups -0x28600(%rip),%xmm0        # 94e8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2f1>
   31ae8:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   31aec:	0f 10 05 e5 79 fd ff 	movups -0x2861b(%rip),%xmm0        # 94d8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2e1>
   31af3:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   31af7:	0f 10 05 ca 79 fd ff 	movups -0x28636(%rip),%xmm0        # 94c8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2d1>
   31afe:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   31b02:	0f 10 05 af 79 fd ff 	movups -0x28651(%rip),%xmm0        # 94b8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2c1>
   31b09:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   31b0d:	66 0f 10 05 93 79 fd 	movupd -0x2866d(%rip),%xmm0        # 94a8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2b1>
   31b14:	ff 
   31b15:	66 0f 11 00          	movupd %xmm0,(%rax)
   31b19:	c7 40 4f 63 6f 64 65 	movl   $0x65646f63,0x4f(%rax)
   31b20:	c6 04 24 03          	movb   $0x3,(%rsp)
   31b24:	48 c7 44 24 08 53 00 	movq   $0x53,0x8(%rsp)
   31b2b:	00 00 
   31b2d:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   31b32:	48 c7 44 24 18 53 00 	movq   $0x53,0x18(%rsp)
   31b39:	00 00 
   31b3b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31b40:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31b47:	00 
   31b48:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31b4d:	48 89 e1             	mov    %rsp,%rcx
   31b50:	e8 db 23 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31b55:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31b5a:	74 0a                	je     31b66 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3486>
   31b5c:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31b61:	e8 6a 89 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31b66:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   31b6c:	bf 0a 00 00 00       	mov    $0xa,%edi
   31b71:	ff 15 49 04 04 00    	call   *0x40449(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31b77:	48 85 c0             	test   %rax,%rax
   31b7a:	0f 84 7e 16 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31b80:	48 89 c3             	mov    %rax,%rbx
   31b83:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   31b8a:	62 79 74 
   31b8d:	48 89 03             	mov    %rax,(%rbx)
   31b90:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   31b96:	48 c7 44 24 70 0a 00 	movq   $0xa,0x70(%rsp)
   31b9d:	00 00 
   31b9f:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
   31ba4:	48 c7 84 24 80 00 00 	movq   $0xa,0x80(%rsp)
   31bab:	00 0a 00 00 00 
   31bb0:	4c 8b bc 24 90 01 00 	mov    0x190(%rsp),%r15
   31bb7:	00 
   31bb8:	48 89 e6             	mov    %rsp,%rsi
   31bbb:	4c 89 ff             	mov    %r15,%rdi
   31bbe:	ff 15 14 07 04 00    	call   *0x40714(%rip)        # 722d8 <_DYNAMIC+0x560>
   31bc4:	49 89 c4             	mov    %rax,%r12
   31bc7:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   31bcb:	49 f7 de             	neg    %r14
   31bce:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31bd4:	48 83 f8 14          	cmp    $0x14,%rax
   31bd8:	74 25                	je     31bff <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x351f>
   31bda:	4c 89 f7             	mov    %r14,%rdi
   31bdd:	ff 15 dd 03 04 00    	call   *0x403dd(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31be3:	48 85 c0             	test   %rax,%rax
   31be6:	0f 84 66 18 00 00    	je     33452 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d72>
   31bec:	49 89 c5             	mov    %rax,%r13
   31bef:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31bf3:	48 89 c7             	mov    %rax,%rdi
   31bf6:	4c 89 f2             	mov    %r14,%rdx
   31bf9:	ff 15 91 03 04 00    	call   *0x40391(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31bff:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31c04:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   31c09:	c6 04 24 02          	movb   $0x2,(%rsp)
   31c0d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   31c12:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
   31c17:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31c1e:	00 
   31c1f:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31c24:	48 89 e1             	mov    %rsp,%rcx
   31c27:	4c 89 e7             	mov    %r12,%rdi
   31c2a:	e8 01 23 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31c2f:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31c34:	74 0a                	je     31c40 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3560>
   31c36:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31c3b:	e8 90 88 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31c40:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   31c46:	bf 0c 00 00 00       	mov    $0xc,%edi
   31c4b:	ff 15 6f 03 04 00    	call   *0x4036f(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31c51:	48 85 c0             	test   %rax,%rax
   31c54:	0f 84 a4 15 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31c5a:	49 89 c6             	mov    %rax,%r14
   31c5d:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   31c64:	9c f2 cb 
   31c67:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   31c6e:	66 6e 76 
   31c71:	49 89 0e             	mov    %rcx,(%r14)
   31c74:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   31c7b:	34 
   31c7c:	48 c7 84 24 e0 00 00 	movq   $0xc,0xe0(%rsp)
   31c83:	00 0c 00 00 00 
   31c88:	4c 89 b4 24 e8 00 00 	mov    %r14,0xe8(%rsp)
   31c8f:	00 
   31c90:	48 c7 84 24 f0 00 00 	movq   $0xc,0xf0(%rsp)
   31c97:	00 0c 00 00 00 
   31c9c:	48 8b 9c 24 88 01 00 	mov    0x188(%rsp),%rbx
   31ca3:	00 
   31ca4:	4d 85 ff             	test   %r15,%r15
   31ca7:	0f 84 97 00 00 00    	je     31d44 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3664>
   31cad:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   31cb4:	01 00 00 
   31cb7:	44 89 fa             	mov    %r15d,%edx
   31cba:	83 e2 03             	and    $0x3,%edx
   31cbd:	49 83 ff 04          	cmp    $0x4,%r15
   31cc1:	73 04                	jae    31cc7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x35e7>
   31cc3:	31 f6                	xor    %esi,%esi
   31cc5:	eb 57                	jmp    31d1e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x363e>
   31cc7:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   31cce:	ff ff 7f 
   31cd1:	48 83 c6 0b          	add    $0xb,%rsi
   31cd5:	49 21 f7             	and    %rsi,%r15
   31cd8:	31 f6                	xor    %esi,%esi
   31cda:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   31ce0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   31ce4:	48 31 f8             	xor    %rdi,%rax
   31ce7:	48 0f af c1          	imul   %rcx,%rax
   31ceb:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   31cf0:	48 31 c7             	xor    %rax,%rdi
   31cf3:	48 0f af f9          	imul   %rcx,%rdi
   31cf7:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   31cfd:	49 31 f8             	xor    %rdi,%r8
   31d00:	4c 0f af c1          	imul   %rcx,%r8
   31d04:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   31d09:	4c 31 c0             	xor    %r8,%rax
   31d0c:	48 0f af c1          	imul   %rcx,%rax
   31d10:	48 83 c6 04          	add    $0x4,%rsi
   31d14:	49 39 f7             	cmp    %rsi,%r15
   31d17:	75 c7                	jne    31ce0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3600>
   31d19:	48 85 d2             	test   %rdx,%rdx
   31d1c:	74 26                	je     31d44 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3664>
   31d1e:	48 01 de             	add    %rbx,%rsi
   31d21:	31 ff                	xor    %edi,%edi
   31d23:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   31d2a:	84 00 00 00 00 00 
   31d30:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   31d35:	4c 31 c0             	xor    %r8,%rax
   31d38:	48 0f af c1          	imul   %rcx,%rax
   31d3c:	48 ff c7             	inc    %rdi
   31d3f:	48 39 fa             	cmp    %rdi,%rdx
   31d42:	75 ec                	jne    31d30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3650>
   31d44:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   31d49:	4c 89 24 24          	mov    %r12,(%rsp)
   31d4d:	48 8b 05 94 04 04 00 	mov    0x40494(%rip),%rax        # 721e8 <_DYNAMIC+0x470>
   31d54:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   31d59:	48 8d 35 e0 65 fd ff 	lea    -0x29a20(%rip),%rsi        # 8340 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   31d60:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   31d65:	48 89 e2             	mov    %rsp,%rdx
   31d68:	ff 15 9a 02 04 00    	call   *0x4029a(%rip)        # 72008 <_DYNAMIC+0x290>
   31d6e:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
   31d73:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   31d7a:	00 
   31d7b:	4d 85 e4             	test   %r12,%r12
   31d7e:	74 26                	je     31da6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x36c6>
   31d80:	4c 89 e7             	mov    %r12,%rdi
   31d83:	ff 15 37 02 04 00    	call   *0x40237(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31d89:	48 85 c0             	test   %rax,%rax
   31d8c:	0f 84 ad 16 00 00    	je     3343f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d5f>
   31d92:	49 89 c5             	mov    %rax,%r13
   31d95:	48 89 c7             	mov    %rax,%rdi
   31d98:	4c 89 fe             	mov    %r15,%rsi
   31d9b:	4c 89 e2             	mov    %r12,%rdx
   31d9e:	ff 15 ec 01 04 00    	call   *0x401ec(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31da4:	eb 06                	jmp    31dac <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x36cc>
   31da6:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31dac:	c6 04 24 03          	movb   $0x3,(%rsp)
   31db0:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   31db5:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31dba:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   31dbf:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31dc4:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31dcb:	00 
   31dcc:	48 8d 94 24 e0 00 00 	lea    0xe0(%rsp),%rdx
   31dd3:	00 
   31dd4:	48 89 e1             	mov    %rsp,%rcx
   31dd7:	e8 54 21 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31ddc:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31de1:	74 0a                	je     31ded <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x370d>
   31de3:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31de8:	e8 e3 86 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31ded:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   31df3:	74 09                	je     31dfe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x371e>
   31df5:	4c 89 ff             	mov    %r15,%rdi
   31df8:	ff 15 aa 01 04 00    	call   *0x401aa(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   31dfe:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   31e04:	bf 08 00 00 00       	mov    $0x8,%edi
   31e09:	ff 15 b1 01 04 00    	call   *0x401b1(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31e0f:	48 85 c0             	test   %rax,%rax
   31e12:	0f 84 e6 13 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31e18:	49 89 c6             	mov    %rax,%r14
   31e1b:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   31e22:	73 75 6d 
   31e25:	49 89 06             	mov    %rax,(%r14)
   31e28:	48 c7 44 24 70 08 00 	movq   $0x8,0x70(%rsp)
   31e2f:	00 00 
   31e31:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   31e36:	48 c7 84 24 80 00 00 	movq   $0x8,0x80(%rsp)
   31e3d:	00 08 00 00 00 
   31e42:	48 89 e6             	mov    %rsp,%rsi
   31e45:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   31e4c:	00 
   31e4d:	ff 15 85 04 04 00    	call   *0x40485(%rip)        # 722d8 <_DYNAMIC+0x560>
   31e53:	49 89 c4             	mov    %rax,%r12
   31e56:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31e5a:	49 f7 df             	neg    %r15
   31e5d:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31e63:	48 83 f8 14          	cmp    $0x14,%rax
   31e67:	74 25                	je     31e8e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x37ae>
   31e69:	4c 89 ff             	mov    %r15,%rdi
   31e6c:	ff 15 4e 01 04 00    	call   *0x4014e(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31e72:	48 85 c0             	test   %rax,%rax
   31e75:	0f 84 ea 15 00 00    	je     33465 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d85>
   31e7b:	49 89 c5             	mov    %rax,%r13
   31e7e:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31e82:	48 89 c7             	mov    %rax,%rdi
   31e85:	4c 89 fa             	mov    %r15,%rdx
   31e88:	ff 15 02 01 04 00    	call   *0x40102(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31e8e:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31e93:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   31e98:	c6 04 24 02          	movb   $0x2,(%rsp)
   31e9c:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   31ea1:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31ea6:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31ead:	00 
   31eae:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31eb3:	48 89 e1             	mov    %rsp,%rcx
   31eb6:	e8 75 20 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31ebb:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31ec0:	74 0a                	je     31ecc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x37ec>
   31ec2:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31ec7:	e8 04 86 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31ecc:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   31ed2:	bf 0b 00 00 00       	mov    $0xb,%edi
   31ed7:	ff 15 e3 00 04 00    	call   *0x400e3(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31edd:	48 85 c0             	test   %rax,%rax
   31ee0:	0f 84 18 13 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31ee6:	49 89 c6             	mov    %rax,%r14
   31ee9:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   31ef0:	6e 74 72 
   31ef3:	49 89 06             	mov    %rax,(%r14)
   31ef6:	41 c7 46 07 72 69 65 	movl   $0x73656972,0x7(%r14)
   31efd:	73 
   31efe:	48 c7 44 24 70 0b 00 	movq   $0xb,0x70(%rsp)
   31f05:	00 00 
   31f07:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   31f0c:	48 c7 84 24 80 00 00 	movq   $0xb,0x80(%rsp)
   31f13:	00 0b 00 00 00 
   31f18:	48 89 e6             	mov    %rsp,%rsi
   31f1b:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
   31f22:	00 
   31f23:	ff 15 af 03 04 00    	call   *0x403af(%rip)        # 722d8 <_DYNAMIC+0x560>
   31f29:	49 89 c4             	mov    %rax,%r12
   31f2c:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31f30:	49 f7 df             	neg    %r15
   31f33:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31f39:	48 83 f8 14          	cmp    $0x14,%rax
   31f3d:	74 25                	je     31f64 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3884>
   31f3f:	4c 89 ff             	mov    %r15,%rdi
   31f42:	ff 15 78 00 04 00    	call   *0x40078(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31f48:	48 85 c0             	test   %rax,%rax
   31f4b:	0f 84 27 15 00 00    	je     33478 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d98>
   31f51:	49 89 c5             	mov    %rax,%r13
   31f54:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31f58:	48 89 c7             	mov    %rax,%rdi
   31f5b:	4c 89 fa             	mov    %r15,%rdx
   31f5e:	ff 15 2c 00 04 00    	call   *0x4002c(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   31f64:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31f69:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   31f6e:	c6 04 24 02          	movb   $0x2,(%rsp)
   31f72:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   31f77:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31f7c:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31f83:	00 
   31f84:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31f89:	48 89 e1             	mov    %rsp,%rcx
   31f8c:	e8 9f 1f 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31f91:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31f96:	74 0a                	je     31fa2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x38c2>
   31f98:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31f9d:	e8 2e 85 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   31fa2:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   31fa8:	bf 0e 00 00 00       	mov    $0xe,%edi
   31fad:	ff 15 0d 00 04 00    	call   *0x4000d(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   31fb3:	48 85 c0             	test   %rax,%rax
   31fb6:	0f 84 42 12 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   31fbc:	49 89 c6             	mov    %rax,%r14
   31fbf:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   31fc6:	69 65 73 
   31fc9:	49 89 46 06          	mov    %rax,0x6(%r14)
   31fcd:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   31fd4:	65 5f 65 
   31fd7:	49 89 06             	mov    %rax,(%r14)
   31fda:	48 c7 44 24 70 0e 00 	movq   $0xe,0x70(%rsp)
   31fe1:	00 00 
   31fe3:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   31fe8:	48 c7 84 24 80 00 00 	movq   $0xe,0x80(%rsp)
   31fef:	00 0e 00 00 00 
   31ff4:	48 89 e6             	mov    %rsp,%rsi
   31ff7:	48 8b bc 24 68 01 00 	mov    0x168(%rsp),%rdi
   31ffe:	00 
   31fff:	ff 15 d3 02 04 00    	call   *0x402d3(%rip)        # 722d8 <_DYNAMIC+0x560>
   32005:	49 89 c4             	mov    %rax,%r12
   32008:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   3200c:	49 f7 df             	neg    %r15
   3200f:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   32015:	48 83 f8 14          	cmp    $0x14,%rax
   32019:	74 25                	je     32040 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3960>
   3201b:	4c 89 ff             	mov    %r15,%rdi
   3201e:	ff 15 9c ff 03 00    	call   *0x3ff9c(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32024:	48 85 c0             	test   %rax,%rax
   32027:	0f 84 5e 14 00 00    	je     3348b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4dab>
   3202d:	49 89 c5             	mov    %rax,%r13
   32030:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   32034:	48 89 c7             	mov    %rax,%rdi
   32037:	4c 89 fa             	mov    %r15,%rdx
   3203a:	ff 15 50 ff 03 00    	call   *0x3ff50(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   32040:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   32045:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   3204a:	c6 04 24 02          	movb   $0x2,(%rsp)
   3204e:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   32053:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   32058:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3205f:	00 
   32060:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   32065:	48 89 e1             	mov    %rsp,%rcx
   32068:	e8 c3 1e 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3206d:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   32072:	74 0a                	je     3207e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x399e>
   32074:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   32079:	e8 52 84 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3207e:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   32084:	bf 12 00 00 00       	mov    $0x12,%edi
   32089:	ff 15 31 ff 03 00    	call   *0x3ff31(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3208f:	48 85 c0             	test   %rax,%rax
   32092:	0f 84 66 11 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   32098:	66 0f 10 05 68 73 fd 	movupd -0x28c98(%rip),%xmm0        # 9408 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x211>
   3209f:	ff 
   320a0:	66 0f 11 00          	movupd %xmm0,(%rax)
   320a4:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   320aa:	48 c7 44 24 70 12 00 	movq   $0x12,0x70(%rsp)
   320b1:	00 00 
   320b3:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   320b8:	48 c7 84 24 80 00 00 	movq   $0x12,0x80(%rsp)
   320bf:	00 12 00 00 00 
   320c4:	66 c7 04 24 01 01    	movw   $0x101,(%rsp)
   320ca:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   320cf:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   320d6:	00 
   320d7:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   320dc:	48 89 e1             	mov    %rsp,%rcx
   320df:	e8 4c 1e 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   320e4:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   320e9:	74 0a                	je     320f5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3a15>
   320eb:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   320f0:	e8 db 83 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   320f5:	41 bd 0f 00 00 00    	mov    $0xf,%r13d
   320fb:	bf 0f 00 00 00       	mov    $0xf,%edi
   32100:	ff 15 ba fe 03 00    	call   *0x3feba(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32106:	48 85 c0             	test   %rax,%rax
   32109:	0f 84 ef 10 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   3210f:	49 89 c6             	mov    %rax,%r14
   32112:	48 b8 5f 73 74 6f 72 	movabs $0x656761726f74735f,%rax
   32119:	61 67 65 
   3211c:	49 89 46 07          	mov    %rax,0x7(%r14)
   32120:	48 b8 6d 65 73 73 61 	movabs $0x5f6567617373656d,%rax
   32127:	67 65 5f 
   3212a:	49 89 06             	mov    %rax,(%r14)
   3212d:	48 c7 44 24 70 0f 00 	movq   $0xf,0x70(%rsp)
   32134:	00 00 
   32136:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   3213b:	48 c7 84 24 80 00 00 	movq   $0xf,0x80(%rsp)
   32142:	00 0f 00 00 00 
   32147:	bf 04 00 00 00       	mov    $0x4,%edi
   3214c:	ff 15 6e fe 03 00    	call   *0x3fe6e(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32152:	48 85 c0             	test   %rax,%rax
   32155:	0f 84 96 12 00 00    	je     333f1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4d11>
   3215b:	c7 00 6c 61 7a 79    	movl   $0x797a616c,(%rax)
   32161:	c6 04 24 03          	movb   $0x3,(%rsp)
   32165:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   3216c:	00 00 
   3216e:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   32173:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   3217a:	00 00 
   3217c:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   32181:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   32188:	00 
   32189:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   3218e:	48 89 e1             	mov    %rsp,%rcx
   32191:	e8 9a 1d 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32196:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   3219b:	74 0a                	je     321a7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3ac7>
   3219d:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   321a2:	e8 29 83 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   321a7:	41 bd 1a 00 00 00    	mov    $0x1a,%r13d
   321ad:	bf 1a 00 00 00       	mov    $0x1a,%edi
   321b2:	ff 15 08 fe 03 00    	call   *0x3fe08(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   321b8:	48 85 c0             	test   %rax,%rax
   321bb:	0f 84 3d 10 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   321c1:	0f 10 05 3d 73 fd ff 	movups -0x28cc3(%rip),%xmm0        # 9505 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x30e>
   321c8:	0f 11 40 0a          	movups %xmm0,0xa(%rax)
   321cc:	66 0f 10 05 27 73 fd 	movupd -0x28cd9(%rip),%xmm0        # 94fb <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x304>
   321d3:	ff 
   321d4:	66 0f 11 00          	movupd %xmm0,(%rax)
   321d8:	48 c7 44 24 70 1a 00 	movq   $0x1a,0x70(%rsp)
   321df:	00 00 
   321e1:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   321e6:	48 c7 84 24 80 00 00 	movq   $0x1a,0x80(%rsp)
   321ed:	00 1a 00 00 00 
   321f2:	66 c7 04 24 01 00    	movw   $0x1,(%rsp)
   321f8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   321fd:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   32204:	00 
   32205:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   3220a:	48 89 e1             	mov    %rsp,%rcx
   3220d:	e8 1e 1d 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32212:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   32217:	74 0a                	je     32223 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3b43>
   32219:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3221e:	e8 ad 82 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32223:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   32229:	bf 07 00 00 00       	mov    $0x7,%edi
   3222e:	ff 15 8c fd 03 00    	call   *0x3fd8c(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32234:	48 85 c0             	test   %rax,%rax
   32237:	0f 84 c1 0f 00 00    	je     331fe <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b1e>
   3223d:	49 89 c6             	mov    %rax,%r14
   32240:	c7 40 03 70 6c 65 73 	movl   $0x73656c70,0x3(%rax)
   32247:	c7 00 73 61 6d 70    	movl   $0x706d6173,(%rax)
   3224d:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   32254:	00 00 
   32256:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   3225b:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   32262:	00 07 00 00 00 
   32267:	48 89 e7             	mov    %rsp,%rdi
   3226a:	48 8d b4 24 c0 01 00 	lea    0x1c0(%rsp),%rsi
   32271:	00 
   32272:	e8 29 b1 ff ff       	call   2d3a0 <_RINvYNtNtNtCseZmxtRzJJaS_10serde_json5value3ser10SerializerNtNtCsgX5KCuC7WXX_10serde_core3ser10Serializer11collect_seqRINtNtCsgFX3jaOk65H_5alloc3vec3VecNtB7_5ValueEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32277:	80 3c 24 ff          	cmpb   $0xff,(%rsp)
   3227b:	0f 84 b4 0d 00 00    	je     33035 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4955>
   32281:	66 0f 10 04 24       	movupd (%rsp),%xmm0
   32286:	f3 0f 6f 4c 24 10    	movdqu 0x10(%rsp),%xmm1
   3228c:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   32292:	66 0f 29 44 24 30    	movapd %xmm0,0x30(%rsp)
   32298:	49 89 e6             	mov    %rsp,%r14
   3229b:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   322a2:	00 
   322a3:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   322a8:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   322ad:	4c 89 f7             	mov    %r14,%rdi
   322b0:	e8 7b 1c 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   322b5:	80 3c 24 ff          	cmpb   $0xff,(%rsp)
   322b9:	74 08                	je     322c3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3be3>
   322bb:	48 89 e7             	mov    %rsp,%rdi
   322be:	e8 0d 82 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   322c3:	66 0f 10 84 24 18 01 	movupd 0x118(%rsp),%xmm0
   322ca:	00 00 
   322cc:	66 0f 11 44 24 08    	movupd %xmm0,0x8(%rsp)
   322d2:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   322d9:	00 
   322da:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   322df:	c6 04 24 05          	movb   $0x5,(%rsp)
   322e3:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   322e8:	48 8b 05 a9 00 04 00 	mov    0x400a9(%rip),%rax        # 72398 <_DYNAMIC+0x620>
   322ef:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   322f4:	48 8d 3d ed 37 fd ff 	lea    -0x2c813(%rip),%rdi        # 5ae8 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   322fb:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   32300:	ff 15 9a 00 04 00    	call   *0x4009a(%rip)        # 723a0 <_DYNAMIC+0x628>
   32306:	48 89 e7             	mov    %rsp,%rdi
   32309:	e8 c2 81 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3230e:	4c 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%r14
   32315:	00 
   32316:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   3231d:	00 
   3231e:	48 85 c0             	test   %rax,%rax
   32321:	74 22                	je     32345 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3c65>
   32323:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   32329:	49 29 c5             	sub    %rax,%r13
   3232c:	4d 89 f7             	mov    %r14,%r15
   3232f:	90                   	nop
   32330:	4c 89 ff             	mov    %r15,%rdi
   32333:	e8 98 81 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32338:	49 83 c7 20          	add    $0x20,%r15
   3233c:	49 ff c5             	inc    %r13
   3233f:	49 83 fd 01          	cmp    $0x1,%r13
   32343:	75 eb                	jne    32330 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3c50>
   32345:	48 83 bc 24 c0 01 00 	cmpq   $0x0,0x1c0(%rsp)
   3234c:	00 00 
   3234e:	74 09                	je     32359 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3c79>
   32350:	4c 89 f7             	mov    %r14,%rdi
   32353:	ff 15 4f fc 03 00    	call   *0x3fc4f(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32359:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
   32360:	00 
   32361:	e8 ca 7b ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32366:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   3236d:	00 00 
   3236f:	74 0e                	je     3237f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3c9f>
   32371:	48 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%rdi
   32378:	00 
   32379:	ff 15 29 fc 03 00    	call   *0x3fc29(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   3237f:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   32386:	00 
   32387:	e8 d4 7d ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3238c:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   32393:	00 00 
   32395:	74 0e                	je     323a5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3cc5>
   32397:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   3239e:	00 
   3239f:	ff 15 03 fc 03 00    	call   *0x3fc03(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   323a5:	48 83 bc 24 80 01 00 	cmpq   $0x0,0x180(%rsp)
   323ac:	00 00 
   323ae:	74 09                	je     323b9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3cd9>
   323b0:	48 89 df             	mov    %rbx,%rdi
   323b3:	ff 15 ef fb 03 00    	call   *0x3fbef(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   323b9:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
   323c0:	00 
   323c1:	e8 9a 7d ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   323c6:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   323cd:	00 
   323ce:	48 85 c9             	test   %rcx,%rcx
   323d1:	74 2a                	je     323fd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3d1d>
   323d3:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   323da:	00 
   323db:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   323df:	48 01 c1             	add    %rax,%rcx
   323e2:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   323e6:	74 15                	je     323fd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3d1d>
   323e8:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   323ef:	00 
   323f0:	48 29 c7             	sub    %rax,%rdi
   323f3:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   323f7:	ff 15 ab fb 03 00    	call   *0x3fbab(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   323fd:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   32404:	00 
   32405:	e8 26 7b ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3240a:	e9 9c 08 00 00       	jmp    32cab <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x45cb>
   3240f:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   32415:	c6 04 24 03          	movb   $0x3,(%rsp)
   32419:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   3241e:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   32423:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   32428:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   3242f:	00 
   32430:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32437:	00 
   32438:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   3243d:	48 89 e1             	mov    %rsp,%rcx
   32440:	e8 eb 1a 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32445:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   3244c:	ff 
   3244d:	74 0d                	je     3245c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3d7c>
   3244f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32456:	00 
   32457:	e8 74 80 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3245c:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   32462:	bf 07 00 00 00       	mov    $0x7,%edi
   32467:	ff 15 53 fb 03 00    	call   *0x3fb53(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3246d:	48 85 c0             	test   %rax,%rax
   32470:	0f 84 9b 0d 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32476:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   3247d:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   32483:	48 c7 44 24 30 07 00 	movq   $0x7,0x30(%rsp)
   3248a:	00 00 
   3248c:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   32491:	48 c7 44 24 40 07 00 	movq   $0x7,0x40(%rsp)
   32498:	00 00 
   3249a:	48 8b 8c 24 40 02 00 	mov    0x240(%rsp),%rcx
   324a1:	00 
   324a2:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   324a6:	48 85 db             	test   %rbx,%rbx
   324a9:	74 35                	je     324e0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3e00>
   324ab:	49 89 c6             	mov    %rax,%r14
   324ae:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   324b2:	48 89 df             	mov    %rbx,%rdi
   324b5:	ff 15 05 fb 03 00    	call   *0x3fb05(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   324bb:	48 85 c0             	test   %rax,%rax
   324be:	0f 84 e7 0f 00 00    	je     334ab <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4dcb>
   324c4:	49 89 c7             	mov    %rax,%r15
   324c7:	48 89 c7             	mov    %rax,%rdi
   324ca:	4c 89 e6             	mov    %r12,%rsi
   324cd:	48 89 da             	mov    %rbx,%rdx
   324d0:	ff 15 ba fa 03 00    	call   *0x3faba(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   324d6:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
   324dd:	00 
   324de:	eb 06                	jmp    324e6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3e06>
   324e0:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   324e6:	c6 04 24 03          	movb   $0x3,(%rsp)
   324ea:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   324ef:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   324f4:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   324f9:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32500:	00 
   32501:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32508:	00 
   32509:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   3250e:	48 89 e1             	mov    %rsp,%rcx
   32511:	e8 1a 1a 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32516:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   3251d:	ff 
   3251e:	74 0d                	je     3252d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3e4d>
   32520:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32527:	00 
   32528:	e8 a3 7f ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3252d:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   32533:	bf 09 00 00 00       	mov    $0x9,%edi
   32538:	ff 15 82 fa 03 00    	call   *0x3fa82(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3253e:	48 85 c0             	test   %rax,%rax
   32541:	0f 84 ca 0c 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32547:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   3254e:	74 69 6f 
   32551:	48 89 08             	mov    %rcx,(%rax)
   32554:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   32558:	48 c7 44 24 30 09 00 	movq   $0x9,0x30(%rsp)
   3255f:	00 00 
   32561:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   32566:	48 c7 44 24 40 09 00 	movq   $0x9,0x40(%rsp)
   3256d:	00 00 
   3256f:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   32574:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   32578:	48 85 db             	test   %rbx,%rbx
   3257b:	74 35                	je     325b2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3ed2>
   3257d:	49 89 c6             	mov    %rax,%r14
   32580:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   32584:	48 89 df             	mov    %rbx,%rdi
   32587:	ff 15 33 fa 03 00    	call   *0x3fa33(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3258d:	48 85 c0             	test   %rax,%rax
   32590:	0f 84 25 0f 00 00    	je     334bb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ddb>
   32596:	49 89 c7             	mov    %rax,%r15
   32599:	48 89 c7             	mov    %rax,%rdi
   3259c:	4c 89 e6             	mov    %r12,%rsi
   3259f:	48 89 da             	mov    %rbx,%rdx
   325a2:	ff 15 e8 f9 03 00    	call   *0x3f9e8(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   325a8:	4c 8b b4 24 00 01 00 	mov    0x100(%rsp),%r14
   325af:	00 
   325b0:	eb 06                	jmp    325b8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3ed8>
   325b2:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   325b8:	c6 04 24 03          	movb   $0x3,(%rsp)
   325bc:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   325c1:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   325c6:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   325cb:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   325d2:	00 
   325d3:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   325da:	00 
   325db:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   325e0:	48 89 e1             	mov    %rsp,%rcx
   325e3:	e8 48 19 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   325e8:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   325ef:	ff 
   325f0:	74 0d                	je     325ff <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3f1f>
   325f2:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   325f9:	00 
   325fa:	e8 d1 7e ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   325ff:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   32605:	bf 12 00 00 00       	mov    $0x12,%edi
   3260a:	ff 15 b0 f9 03 00    	call   *0x3f9b0(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32610:	48 85 c0             	test   %rax,%rax
   32613:	0f 84 f8 0b 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32619:	66 0f 10 05 e7 6d fd 	movupd -0x29219(%rip),%xmm0        # 9408 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x211>
   32620:	ff 
   32621:	66 0f 11 00          	movupd %xmm0,(%rax)
   32625:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   3262b:	48 c7 44 24 30 12 00 	movq   $0x12,0x30(%rsp)
   32632:	00 00 
   32634:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   32639:	48 c7 44 24 40 12 00 	movq   $0x12,0x40(%rsp)
   32640:	00 00 
   32642:	66 c7 04 24 01 01    	movw   $0x101,(%rsp)
   32648:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   3264f:	00 
   32650:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32657:	00 
   32658:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   3265d:	48 89 e1             	mov    %rsp,%rcx
   32660:	e8 cb 18 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32665:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   3266c:	ff 
   3266d:	74 0d                	je     3267c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x3f9c>
   3266f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32676:	00 
   32677:	e8 54 7e ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3267c:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   32682:	bf 0b 00 00 00       	mov    $0xb,%edi
   32687:	ff 15 33 f9 03 00    	call   *0x3f933(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3268d:	48 85 c0             	test   %rax,%rax
   32690:	0f 84 7b 0b 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32696:	48 89 c3             	mov    %rax,%rbx
   32699:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   326a0:	6e 74 72 
   326a3:	48 89 03             	mov    %rax,(%rbx)
   326a6:	c7 43 07 72 69 65 73 	movl   $0x73656972,0x7(%rbx)
   326ad:	48 c7 44 24 30 0b 00 	movq   $0xb,0x30(%rsp)
   326b4:	00 00 
   326b6:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   326bb:	48 c7 44 24 40 0b 00 	movq   $0xb,0x40(%rsp)
   326c2:	00 00 
   326c4:	48 89 e6             	mov    %rsp,%rsi
   326c7:	4c 89 f7             	mov    %r14,%rdi
   326ca:	ff 15 08 fc 03 00    	call   *0x3fc08(%rip)        # 722d8 <_DYNAMIC+0x560>
   326d0:	49 89 c7             	mov    %rax,%r15
   326d3:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   326d7:	49 f7 de             	neg    %r14
   326da:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   326e0:	48 83 f8 14          	cmp    $0x14,%rax
   326e4:	74 25                	je     3270b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x402b>
   326e6:	4c 89 f7             	mov    %r14,%rdi
   326e9:	ff 15 d1 f8 03 00    	call   *0x3f8d1(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   326ef:	48 85 c0             	test   %rax,%rax
   326f2:	0f 84 e3 0d 00 00    	je     334db <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4dfb>
   326f8:	49 89 c4             	mov    %rax,%r12
   326fb:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   326ff:	48 89 c7             	mov    %rax,%rdi
   32702:	4c 89 f2             	mov    %r14,%rdx
   32705:	ff 15 85 f8 03 00    	call   *0x3f885(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   3270b:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   32710:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   32715:	c6 04 24 02          	movb   $0x2,(%rsp)
   32719:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   3271e:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32725:	00 
   32726:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   3272d:	00 
   3272e:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32733:	48 89 e1             	mov    %rsp,%rcx
   32736:	e8 f5 17 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3273b:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   32742:	ff 
   32743:	4c 8b b4 24 68 01 00 	mov    0x168(%rsp),%r14
   3274a:	00 
   3274b:	74 0d                	je     3275a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x407a>
   3274d:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32754:	00 
   32755:	e8 76 7d ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3275a:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   32760:	bf 0e 00 00 00       	mov    $0xe,%edi
   32765:	ff 15 55 f8 03 00    	call   *0x3f855(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   3276b:	48 85 c0             	test   %rax,%rax
   3276e:	0f 84 9d 0a 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32774:	48 89 c3             	mov    %rax,%rbx
   32777:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   3277e:	69 65 73 
   32781:	48 89 43 06          	mov    %rax,0x6(%rbx)
   32785:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   3278c:	65 5f 65 
   3278f:	48 89 03             	mov    %rax,(%rbx)
   32792:	48 c7 44 24 30 0e 00 	movq   $0xe,0x30(%rsp)
   32799:	00 00 
   3279b:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   327a0:	48 c7 44 24 40 0e 00 	movq   $0xe,0x40(%rsp)
   327a7:	00 00 
   327a9:	48 89 e6             	mov    %rsp,%rsi
   327ac:	4c 89 f7             	mov    %r14,%rdi
   327af:	ff 15 23 fb 03 00    	call   *0x3fb23(%rip)        # 722d8 <_DYNAMIC+0x560>
   327b5:	49 89 c7             	mov    %rax,%r15
   327b8:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   327bc:	49 f7 de             	neg    %r14
   327bf:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   327c5:	48 83 f8 14          	cmp    $0x14,%rax
   327c9:	74 25                	je     327f0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4110>
   327cb:	4c 89 f7             	mov    %r14,%rdi
   327ce:	ff 15 ec f7 03 00    	call   *0x3f7ec(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   327d4:	48 85 c0             	test   %rax,%rax
   327d7:	0f 84 0e 0d 00 00    	je     334eb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e0b>
   327dd:	49 89 c4             	mov    %rax,%r12
   327e0:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   327e4:	48 89 c7             	mov    %rax,%rdi
   327e7:	4c 89 f2             	mov    %r14,%rdx
   327ea:	ff 15 a0 f7 03 00    	call   *0x3f7a0(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   327f0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   327f5:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   327fa:	c6 04 24 02          	movb   $0x2,(%rsp)
   327fe:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   32803:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   3280a:	00 
   3280b:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32812:	00 
   32813:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32818:	48 89 e1             	mov    %rsp,%rcx
   3281b:	e8 10 17 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32820:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   32827:	ff 
   32828:	74 0d                	je     32837 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4157>
   3282a:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32831:	00 
   32832:	e8 99 7c ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32837:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   3283d:	bf 0a 00 00 00       	mov    $0xa,%edi
   32842:	ff 15 78 f7 03 00    	call   *0x3f778(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32848:	48 85 c0             	test   %rax,%rax
   3284b:	0f 84 c0 09 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32851:	48 89 c3             	mov    %rax,%rbx
   32854:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   3285b:	62 79 74 
   3285e:	48 89 03             	mov    %rax,(%rbx)
   32861:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   32867:	48 c7 44 24 30 0a 00 	movq   $0xa,0x30(%rsp)
   3286e:	00 00 
   32870:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   32875:	48 c7 44 24 40 0a 00 	movq   $0xa,0x40(%rsp)
   3287c:	00 00 
   3287e:	4c 8b bc 24 90 01 00 	mov    0x190(%rsp),%r15
   32885:	00 
   32886:	48 89 e6             	mov    %rsp,%rsi
   32889:	4c 89 ff             	mov    %r15,%rdi
   3288c:	ff 15 46 fa 03 00    	call   *0x3fa46(%rip)        # 722d8 <_DYNAMIC+0x560>
   32892:	49 89 c4             	mov    %rax,%r12
   32895:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   32899:	49 f7 de             	neg    %r14
   3289c:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   328a2:	48 83 f8 14          	cmp    $0x14,%rax
   328a6:	74 25                	je     328cd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x41ed>
   328a8:	4c 89 f7             	mov    %r14,%rdi
   328ab:	ff 15 0f f7 03 00    	call   *0x3f70f(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   328b1:	48 85 c0             	test   %rax,%rax
   328b4:	0f 84 41 0c 00 00    	je     334fb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e1b>
   328ba:	49 89 c5             	mov    %rax,%r13
   328bd:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   328c1:	48 89 c7             	mov    %rax,%rdi
   328c4:	4c 89 f2             	mov    %r14,%rdx
   328c7:	ff 15 c3 f6 03 00    	call   *0x3f6c3(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   328cd:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   328d2:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   328d7:	c6 04 24 02          	movb   $0x2,(%rsp)
   328db:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   328e0:	4c 8d a4 24 b8 00 00 	lea    0xb8(%rsp),%r12
   328e7:	00 
   328e8:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   328ef:	00 
   328f0:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   328f5:	48 89 e1             	mov    %rsp,%rcx
   328f8:	4c 89 e7             	mov    %r12,%rdi
   328fb:	e8 30 16 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32900:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   32907:	ff 
   32908:	74 0d                	je     32917 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4237>
   3290a:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32911:	00 
   32912:	e8 b9 7b ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32917:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   3291d:	bf 0c 00 00 00       	mov    $0xc,%edi
   32922:	ff 15 98 f6 03 00    	call   *0x3f698(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32928:	48 85 c0             	test   %rax,%rax
   3292b:	0f 84 e0 08 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32931:	49 89 c6             	mov    %rax,%r14
   32934:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   3293b:	9c f2 cb 
   3293e:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   32945:	66 6e 76 
   32948:	49 89 0e             	mov    %rcx,(%r14)
   3294b:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   32952:	34 
   32953:	48 c7 44 24 70 0c 00 	movq   $0xc,0x70(%rsp)
   3295a:	00 00 
   3295c:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   32961:	48 c7 84 24 80 00 00 	movq   $0xc,0x80(%rsp)
   32968:	00 0c 00 00 00 
   3296d:	48 8b 9c 24 88 01 00 	mov    0x188(%rsp),%rbx
   32974:	00 
   32975:	4d 85 ff             	test   %r15,%r15
   32978:	0f 84 96 00 00 00    	je     32a14 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4334>
   3297e:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   32985:	01 00 00 
   32988:	44 89 fa             	mov    %r15d,%edx
   3298b:	83 e2 03             	and    $0x3,%edx
   3298e:	49 83 ff 04          	cmp    $0x4,%r15
   32992:	73 04                	jae    32998 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x42b8>
   32994:	31 f6                	xor    %esi,%esi
   32996:	eb 56                	jmp    329ee <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x430e>
   32998:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   3299f:	ff ff 7f 
   329a2:	48 83 c6 0b          	add    $0xb,%rsi
   329a6:	49 21 f7             	and    %rsi,%r15
   329a9:	31 f6                	xor    %esi,%esi
   329ab:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   329b0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   329b4:	48 31 f8             	xor    %rdi,%rax
   329b7:	48 0f af c1          	imul   %rcx,%rax
   329bb:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   329c0:	48 31 c7             	xor    %rax,%rdi
   329c3:	48 0f af f9          	imul   %rcx,%rdi
   329c7:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   329cd:	49 31 f8             	xor    %rdi,%r8
   329d0:	4c 0f af c1          	imul   %rcx,%r8
   329d4:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   329d9:	4c 31 c0             	xor    %r8,%rax
   329dc:	48 0f af c1          	imul   %rcx,%rax
   329e0:	48 83 c6 04          	add    $0x4,%rsi
   329e4:	49 39 f7             	cmp    %rsi,%r15
   329e7:	75 c7                	jne    329b0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x42d0>
   329e9:	48 85 d2             	test   %rdx,%rdx
   329ec:	74 26                	je     32a14 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4334>
   329ee:	48 01 de             	add    %rbx,%rsi
   329f1:	31 ff                	xor    %edi,%edi
   329f3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   329fa:	84 00 00 00 00 00 
   32a00:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   32a05:	4c 31 c0             	xor    %r8,%rax
   32a08:	48 0f af c1          	imul   %rcx,%rax
   32a0c:	48 ff c7             	inc    %rdi
   32a0f:	48 39 fa             	cmp    %rdi,%rdx
   32a12:	75 ec                	jne    32a00 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4320>
   32a14:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   32a1b:	00 
   32a1c:	4c 89 24 24          	mov    %r12,(%rsp)
   32a20:	48 8b 05 c1 f7 03 00 	mov    0x3f7c1(%rip),%rax        # 721e8 <_DYNAMIC+0x470>
   32a27:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   32a2c:	48 8d 35 0d 59 fd ff 	lea    -0x2a6f3(%rip),%rsi        # 8340 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   32a33:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   32a38:	48 89 e2             	mov    %rsp,%rdx
   32a3b:	ff 15 c7 f5 03 00    	call   *0x3f5c7(%rip)        # 72008 <_DYNAMIC+0x290>
   32a41:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   32a46:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
   32a4b:	4d 85 e4             	test   %r12,%r12
   32a4e:	74 26                	je     32a76 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4396>
   32a50:	4c 89 e7             	mov    %r12,%rdi
   32a53:	ff 15 67 f5 03 00    	call   *0x3f567(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32a59:	48 85 c0             	test   %rax,%rax
   32a5c:	0f 84 69 0a 00 00    	je     334cb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4deb>
   32a62:	49 89 c5             	mov    %rax,%r13
   32a65:	48 89 c7             	mov    %rax,%rdi
   32a68:	4c 89 fe             	mov    %r15,%rsi
   32a6b:	4c 89 e2             	mov    %r12,%rdx
   32a6e:	ff 15 1c f5 03 00    	call   *0x3f51c(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   32a74:	eb 06                	jmp    32a7c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x439c>
   32a76:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   32a7c:	c6 04 24 03          	movb   $0x3,(%rsp)
   32a80:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   32a85:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   32a8a:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   32a8f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32a96:	00 
   32a97:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32a9e:	00 
   32a9f:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   32aa4:	48 89 e1             	mov    %rsp,%rcx
   32aa7:	e8 84 14 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32aac:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   32ab3:	ff 
   32ab4:	74 0d                	je     32ac3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x43e3>
   32ab6:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32abd:	00 
   32abe:	e8 0d 7a ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32ac3:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   32ac9:	74 09                	je     32ad4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x43f4>
   32acb:	4c 89 ff             	mov    %r15,%rdi
   32ace:	ff 15 d4 f4 03 00    	call   *0x3f4d4(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32ad4:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   32ada:	bf 08 00 00 00       	mov    $0x8,%edi
   32adf:	ff 15 db f4 03 00    	call   *0x3f4db(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32ae5:	48 85 c0             	test   %rax,%rax
   32ae8:	0f 84 23 07 00 00    	je     33211 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b31>
   32aee:	49 89 c6             	mov    %rax,%r14
   32af1:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   32af8:	73 75 6d 
   32afb:	49 89 06             	mov    %rax,(%r14)
   32afe:	48 c7 44 24 30 08 00 	movq   $0x8,0x30(%rsp)
   32b05:	00 00 
   32b07:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
   32b0c:	48 c7 44 24 40 08 00 	movq   $0x8,0x40(%rsp)
   32b13:	00 00 
   32b15:	48 89 e6             	mov    %rsp,%rsi
   32b18:	48 89 ef             	mov    %rbp,%rdi
   32b1b:	ff 15 b7 f7 03 00    	call   *0x3f7b7(%rip)        # 722d8 <_DYNAMIC+0x560>
   32b21:	49 89 c4             	mov    %rax,%r12
   32b24:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   32b28:	49 f7 df             	neg    %r15
   32b2b:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   32b31:	48 83 f8 14          	cmp    $0x14,%rax
   32b35:	74 25                	je     32b5c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x447c>
   32b37:	4c 89 ff             	mov    %r15,%rdi
   32b3a:	ff 15 80 f4 03 00    	call   *0x3f480(%rip)        # 71fc0 <malloc@GLIBC_2.2.5>
   32b40:	48 85 c0             	test   %rax,%rax
   32b43:	0f 84 c2 09 00 00    	je     3350b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e2b>
   32b49:	49 89 c5             	mov    %rax,%r13
   32b4c:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   32b50:	48 89 c7             	mov    %rax,%rdi
   32b53:	4c 89 fa             	mov    %r15,%rdx
   32b56:	ff 15 34 f4 03 00    	call   *0x3f434(%rip)        # 71f90 <memcpy@GLIBC_2.14>
   32b5c:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   32b61:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   32b66:	c6 04 24 02          	movb   $0x2,(%rsp)
   32b6a:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   32b6f:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32b76:	00 
   32b77:	48 8d b4 24 e0 00 00 	lea    0xe0(%rsp),%rsi
   32b7e:	00 
   32b7f:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32b84:	49 89 e6             	mov    %rsp,%r14
   32b87:	4c 89 f1             	mov    %r14,%rcx
   32b8a:	e8 a1 13 00 00       	call   33f30 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32b8f:	80 bc 24 b8 00 00 00 	cmpb   $0xff,0xb8(%rsp)
   32b96:	ff 
   32b97:	74 0d                	je     32ba6 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x44c6>
   32b99:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32ba0:	00 
   32ba1:	e8 2a 79 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32ba6:	66 0f 10 84 24 e0 00 	movupd 0xe0(%rsp),%xmm0
   32bad:	00 00 
   32baf:	66 0f 11 44 24 08    	movupd %xmm0,0x8(%rsp)
   32bb5:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
   32bbc:	00 
   32bbd:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   32bc2:	c6 04 24 05          	movb   $0x5,(%rsp)
   32bc6:	4c 89 b4 24 b8 00 00 	mov    %r14,0xb8(%rsp)
   32bcd:	00 
   32bce:	48 8b 05 c3 f7 03 00 	mov    0x3f7c3(%rip),%rax        # 72398 <_DYNAMIC+0x620>
   32bd5:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   32bdc:	00 
   32bdd:	48 8d 3d 04 2f fd ff 	lea    -0x2d0fc(%rip),%rdi        # 5ae8 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   32be4:	48 8d b4 24 b8 00 00 	lea    0xb8(%rsp),%rsi
   32beb:	00 
   32bec:	ff 15 ae f7 03 00    	call   *0x3f7ae(%rip)        # 723a0 <_DYNAMIC+0x628>
   32bf2:	48 89 e7             	mov    %rsp,%rdi
   32bf5:	e8 d6 78 ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32bfa:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
   32c01:	00 
   32c02:	e8 29 73 ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32c07:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   32c0e:	00 00 
   32c10:	74 0e                	je     32c20 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4540>
   32c12:	48 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%rdi
   32c19:	00 
   32c1a:	ff 15 88 f3 03 00    	call   *0x3f388(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32c20:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   32c27:	00 
   32c28:	e8 33 75 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32c2d:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   32c34:	00 00 
   32c36:	74 0e                	je     32c46 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4566>
   32c38:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   32c3f:	00 
   32c40:	ff 15 62 f3 03 00    	call   *0x3f362(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32c46:	48 83 bc 24 80 01 00 	cmpq   $0x0,0x180(%rsp)
   32c4d:	00 00 
   32c4f:	74 09                	je     32c5a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x457a>
   32c51:	48 89 df             	mov    %rbx,%rdi
   32c54:	ff 15 4e f3 03 00    	call   *0x3f34e(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32c5a:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
   32c61:	00 
   32c62:	e8 f9 74 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32c67:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   32c6e:	00 
   32c6f:	48 85 c9             	test   %rcx,%rcx
   32c72:	74 2a                	je     32c9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x45be>
   32c74:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   32c7b:	00 
   32c7c:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   32c80:	48 01 c1             	add    %rax,%rcx
   32c83:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   32c87:	74 15                	je     32c9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x45be>
   32c89:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   32c90:	00 
   32c91:	48 29 c7             	sub    %rax,%rdi
   32c94:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   32c98:	ff 15 0a f3 03 00    	call   *0x3f30a(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32c9e:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   32ca5:	00 
   32ca6:	e8 85 72 ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32cab:	48 83 bc 24 10 02 00 	cmpq   $0x0,0x210(%rsp)
   32cb2:	00 00 
   32cb4:	74 0e                	je     32cc4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x45e4>
   32cb6:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
   32cbd:	00 
   32cbe:	ff 15 e4 f2 03 00    	call   *0x3f2e4(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32cc4:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   32cc9:	48 83 3b 00          	cmpq   $0x0,(%rbx)
   32ccd:	74 0a                	je     32cd9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x45f9>
   32ccf:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   32cd3:	ff 15 cf f2 03 00    	call   *0x3f2cf(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32cd9:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   32cde:	74 0a                	je     32cea <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x460a>
   32ce0:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   32ce4:	ff 15 be f2 03 00    	call   *0x3f2be(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32cea:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
   32cf1:	00 
   32cf2:	48 83 38 00          	cmpq   $0x0,(%rax)
   32cf6:	74 0f                	je     32d07 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4627>
   32cf8:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   32cfd:	48 8b 78 38          	mov    0x38(%rax),%rdi
   32d01:	ff 15 a1 f2 03 00    	call   *0x3f2a1(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32d07:	48 8b 84 24 30 02 00 	mov    0x230(%rsp),%rax
   32d0e:	00 
   32d0f:	48 83 38 00          	cmpq   $0x0,(%rax)
   32d13:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   32d18:	74 0a                	je     32d24 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4644>
   32d1a:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   32d1e:	ff 15 84 f2 03 00    	call   *0x3f284(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32d24:	48 83 7b 60 00       	cmpq   $0x0,0x60(%rbx)
   32d29:	74 0a                	je     32d35 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4655>
   32d2b:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
   32d2f:	ff 15 73 f2 03 00    	call   *0x3f273(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32d35:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   32d3a:	74 0d                	je     32d49 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4669>
   32d3c:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
   32d43:	ff 15 5f f2 03 00    	call   *0x3f25f(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32d49:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   32d50:	00 00 
   32d52:	74 0b                	je     32d5f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x467f>
   32d54:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   32d59:	ff 15 49 f2 03 00    	call   *0x3f249(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   32d5f:	48 81 c4 98 02 00 00 	add    $0x298,%rsp
   32d66:	5b                   	pop    %rbx
   32d67:	41 5c                	pop    %r12
   32d69:	41 5d                	pop    %r13
   32d6b:	41 5e                	pop    %r14
   32d6d:	41 5f                	pop    %r15
   32d6f:	5d                   	pop    %rbp
   32d70:	c3                   	ret
   32d71:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32d78:	00 
   32d79:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   32d80:	00 
   32d81:	e8 fa 78 ff ff       	call   2a680 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtCsgFX3jaOk65H_5alloc3vec3VecTllEEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32d86:	e9 8e 07 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32d8b:	be 44 00 00 00       	mov    $0x44,%esi
   32d90:	48 8d 3d 7e 67 fd ff 	lea    -0x29882(%rip),%rdi        # 9515 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x31e>
   32d97:	48 8d 15 6a d9 03 00 	lea    0x3d96a(%rip),%rdx        # 70708 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x898>
   32d9e:	ff 15 74 f3 03 00    	call   *0x3f374(%rip)        # 72118 <_DYNAMIC+0x3a0>
   32da4:	e9 70 07 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32da9:	80 c2 d0             	add    $0xd0,%dl
   32dac:	31 c0                	xor    %eax,%eax
   32dae:	80 fa 0a             	cmp    $0xa,%dl
   32db1:	14 01                	adc    $0x1,%al
   32db3:	eb 02                	jmp    32db7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d7>
   32db5:	b0 02                	mov    $0x2,%al
   32db7:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32dbe:	4c 8d 05 b3 d7 03 00 	lea    0x3d7b3(%rip),%r8        # 70578 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x708>
   32dc5:	eb 1c                	jmp    32de3 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4703>
   32dc7:	80 c2 d0             	add    $0xd0,%dl
   32dca:	31 c0                	xor    %eax,%eax
   32dcc:	80 fa 0a             	cmp    $0xa,%dl
   32dcf:	14 01                	adc    $0x1,%al
   32dd1:	eb 02                	jmp    32dd5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f5>
   32dd3:	b0 02                	mov    $0x2,%al
   32dd5:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32ddc:	4c 8d 05 ad d7 03 00 	lea    0x3d7ad(%rip),%r8        # 70590 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x720>
   32de3:	48 8d 3d c2 67 fd ff 	lea    -0x2983e(%rip),%rdi        # 95ac <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   32dea:	48 8d 0d df d9 03 00 	lea    0x3d9df(%rip),%rcx        # 707d0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x960>
   32df1:	be 2b 00 00 00       	mov    $0x2b,%esi
   32df6:	4c 89 e2             	mov    %r12,%rdx
   32df9:	ff 15 19 f2 03 00    	call   *0x3f219(%rip)        # 72018 <_DYNAMIC+0x2a0>
   32dff:	e9 15 07 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32e04:	80 c2 d0             	add    $0xd0,%dl
   32e07:	31 c0                	xor    %eax,%eax
   32e09:	80 fa 0a             	cmp    $0xa,%dl
   32e0c:	14 01                	adc    $0x1,%al
   32e0e:	eb 02                	jmp    32e12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4732>
   32e10:	b0 02                	mov    $0x2,%al
   32e12:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32e19:	48 8d 3d 8c 67 fd ff 	lea    -0x29874(%rip),%rdi        # 95ac <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   32e20:	48 8d 0d a9 d9 03 00 	lea    0x3d9a9(%rip),%rcx        # 707d0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x960>
   32e27:	4c 8d 05 ea d7 03 00 	lea    0x3d7ea(%rip),%r8        # 70618 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7a8>
   32e2e:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
   32e35:	00 
   32e36:	be 2b 00 00 00       	mov    $0x2b,%esi
   32e3b:	ff 15 d7 f1 03 00    	call   *0x3f1d7(%rip)        # 72018 <_DYNAMIC+0x2a0>
   32e41:	e9 d3 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32e46:	48 83 c1 08          	add    $0x8,%rcx
   32e4a:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   32e4e:	4c 89 c8             	mov    %r9,%rax
   32e51:	4c 8d 48 01          	lea    0x1(%rax),%r9
   32e55:	4d 39 f9             	cmp    %r15,%r9
   32e58:	0f 84 40 ff ff ff    	je     32d9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46be>
   32e5e:	41 8b 04 c6          	mov    (%r14,%rax,8),%eax
   32e62:	45 31 d2             	xor    %r10d,%r10d
   32e65:	42 39 04 11          	cmp    %eax,(%rcx,%r10,1)
   32e69:	74 db                	je     32e46 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4766>
   32e6b:	49 83 c2 08          	add    $0x8,%r10
   32e6f:	4d 39 d0             	cmp    %r10,%r8
   32e72:	75 f1                	jne    32e65 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4785>
   32e74:	e9 25 ff ff ff       	jmp    32d9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46be>
   32e79:	bf 08 00 00 00       	mov    $0x8,%edi
   32e7e:	4c 89 e6             	mov    %r12,%rsi
   32e81:	ff 15 59 f1 03 00    	call   *0x3f159(%rip)        # 71fe0 <_DYNAMIC+0x268>
   32e87:	e9 8d 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32e8c:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   32e91:	48 8d 15 6c 5a fd ff 	lea    -0x2a594(%rip),%rdx        # 8904 <_RNvNtNtNtCskADBYZwJmSU_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x84>
   32e98:	4c 8d 0d f9 d8 03 00 	lea    0x3d8f9(%rip),%r9        # 70798 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x928>
   32e9f:	31 ff                	xor    %edi,%edi
   32ea1:	4c 89 ee             	mov    %r13,%rsi
   32ea4:	31 c9                	xor    %ecx,%ecx
   32ea6:	ff 15 fc f4 03 00    	call   *0x3f4fc(%rip)        # 723a8 <_DYNAMIC+0x630>
   32eac:	e9 68 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32eb1:	48 8d 0d 80 d9 03 00 	lea    0x3d980(%rip),%rcx        # 70838 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9c8>
   32eb8:	ba 0b 00 00 00       	mov    $0xb,%edx
   32ebd:	31 ff                	xor    %edi,%edi
   32ebf:	4c 89 e6             	mov    %r12,%rsi
   32ec2:	ff 15 00 f1 03 00    	call   *0x3f100(%rip)        # 71fc8 <_DYNAMIC+0x250>
   32ec8:	e9 4c 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32ecd:	48 8d 0d 64 d4 03 00 	lea    0x3d464(%rip),%rcx        # 70338 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4c8>
   32ed4:	ba 0c 00 00 00       	mov    $0xc,%edx
   32ed9:	31 ff                	xor    %edi,%edi
   32edb:	4c 89 e6             	mov    %r12,%rsi
   32ede:	ff 15 e4 f0 03 00    	call   *0x3f0e4(%rip)        # 71fc8 <_DYNAMIC+0x250>
   32ee4:	e9 30 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32ee9:	48 8d 0d 10 d6 03 00 	lea    0x3d610(%rip),%rcx        # 70500 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x690>
   32ef0:	4c 89 f7             	mov    %r14,%rdi
   32ef3:	48 89 d6             	mov    %rdx,%rsi
   32ef6:	ff 15 cc f0 03 00    	call   *0x3f0cc(%rip)        # 71fc8 <_DYNAMIC+0x250>
   32efc:	e9 18 06 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f01:	48 8d 3d 64 63 fd ff 	lea    -0x29c9c(%rip),%rdi        # 926c <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x75>
   32f08:	48 8d 15 49 d5 03 00 	lea    0x3d549(%rip),%rdx        # 70458 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x5e8>
   32f0f:	be 28 00 00 00       	mov    $0x28,%esi
   32f14:	ff 15 fe f1 03 00    	call   *0x3f1fe(%rip)        # 72118 <_DYNAMIC+0x3a0>
   32f1a:	e9 fa 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f1f:	e8 c5 77 ff ff       	call   2a6e9 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedReBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32f24:	e9 f0 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f29:	48 8d 0d 08 d9 03 00 	lea    0x3d908(%rip),%rcx        # 70838 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9c8>
   32f30:	ba 0b 00 00 00       	mov    $0xb,%edx
   32f35:	31 ff                	xor    %edi,%edi
   32f37:	4c 89 e6             	mov    %r12,%rsi
   32f3a:	ff 15 88 f0 03 00    	call   *0x3f088(%rip)        # 71fc8 <_DYNAMIC+0x250>
   32f40:	e9 d4 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f45:	48 8d 0d b4 d5 03 00 	lea    0x3d5b4(%rip),%rcx        # 70500 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x690>
   32f4c:	48 89 d6             	mov    %rdx,%rsi
   32f4f:	ff 15 73 f0 03 00    	call   *0x3f073(%rip)        # 71fc8 <_DYNAMIC+0x250>
   32f55:	e9 bf 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f5a:	48 8d 3d 0f 64 fd ff 	lea    -0x29bf1(%rip),%rdi        # 9370 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x179>
   32f61:	48 8d 15 c8 d6 03 00 	lea    0x3d6c8(%rip),%rdx        # 70630 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c0>
   32f68:	be 47 00 00 00       	mov    $0x47,%esi
   32f6d:	ff 15 a5 f1 03 00    	call   *0x3f1a5(%rip)        # 72118 <_DYNAMIC+0x3a0>
   32f73:	e9 a1 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32f78:	ff 15 02 f4 03 00    	call   *0x3f402(%rip)        # 72380 <_DYNAMIC+0x608>
   32f7e:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   32f83:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   32f88:	e9 1f c4 ff ff       	jmp    2f3ac <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xccc>
   32f8d:	48 8d 15 b4 d6 03 00 	lea    0x3d6b4(%rip),%rdx        # 70648 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7d8>
   32f94:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   32f9b:	00 
   32f9c:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   32fa3:	00 
   32fa4:	e8 0f 77 ff ff       	call   2a6b8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32fa9:	e9 6b 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32fae:	48 8d 15 db d6 03 00 	lea    0x3d6db(%rip),%rdx        # 70690 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x820>
   32fb5:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32fbc:	00 
   32fbd:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   32fc4:	00 
   32fc5:	e8 ee 76 ff ff       	call   2a6b8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32fca:	e9 4a 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32fcf:	48 8d 15 d2 d6 03 00 	lea    0x3d6d2(%rip),%rdx        # 706a8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x838>
   32fd6:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   32fdd:	00 
   32fde:	48 8d b4 24 d8 01 00 	lea    0x1d8(%rsp),%rsi
   32fe5:	00 
   32fe6:	e8 cd 76 ff ff       	call   2a6b8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   32feb:	e9 29 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   32ff0:	bf 08 00 00 00       	mov    $0x8,%edi
   32ff5:	be c8 00 00 00       	mov    $0xc8,%esi
   32ffa:	ff 15 e0 ef 03 00    	call   *0x3efe0(%rip)        # 71fe0 <_DYNAMIC+0x268>
   33000:	e9 14 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33005:	48 8d 3d 14 d3 03 00 	lea    0x3d314(%rip),%rdi        # 70320 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4b0>
   3300c:	ff 15 de f0 03 00    	call   *0x3f0de(%rip)        # 720f0 <_DYNAMIC+0x378>
   33012:	e9 02 05 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33017:	48 8d 3d 35 66 fd ff 	lea    -0x299cb(%rip),%rdi        # 9653 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x45c>
   3301e:	48 8d 15 2b d8 03 00 	lea    0x3d82b(%rip),%rdx        # 70850 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9e0>
   33025:	be 30 00 00 00       	mov    $0x30,%esi
   3302a:	ff 15 e8 f0 03 00    	call   *0x3f0e8(%rip)        # 72118 <_DYNAMIC+0x3a0>
   33030:	e9 e4 04 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33035:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   3303a:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   3303f:	48 8d 3d 66 65 fd ff 	lea    -0x29a9a(%rip),%rdi        # 95ac <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   33046:	48 8d 0d 63 d7 03 00 	lea    0x3d763(%rip),%rcx        # 707b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x940>
   3304d:	4c 8d 05 9c d6 03 00 	lea    0x3d69c(%rip),%r8        # 706f0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x880>
   33054:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   33059:	be 2b 00 00 00       	mov    $0x2b,%esi
   3305e:	ff 15 b4 ef 03 00    	call   *0x3efb4(%rip)        # 72018 <_DYNAMIC+0x2a0>
   33064:	e9 b0 04 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33069:	48 8d 3d f0 d4 03 00 	lea    0x3d4f0(%rip),%rdi        # 70560 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f0>
   33070:	ff 15 7a f0 03 00    	call   *0x3f07a(%rip)        # 720f0 <_DYNAMIC+0x378>
   33076:	e9 9e 04 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3307b:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
   3307f:	4c 89 f6             	mov    %r14,%rsi
   33082:	4c 89 fa             	mov    %r15,%rdx
   33085:	e8 32 60 ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3308a:	e9 d9 d4 ff ff       	jmp    30568 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1e88>
   3308f:	4c 89 e7             	mov    %r12,%rdi
   33092:	4c 89 f6             	mov    %r14,%rsi
   33095:	4c 89 fa             	mov    %r15,%rdx
   33098:	e8 1f 60 ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3309d:	e9 71 d0 ff ff       	jmp    30113 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1a33>
   330a2:	4c 89 e7             	mov    %r12,%rdi
   330a5:	4c 89 f6             	mov    %r14,%rsi
   330a8:	4c 89 fa             	mov    %r15,%rdx
   330ab:	e8 0c 60 ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   330b0:	e9 20 d3 ff ff       	jmp    303d5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x1cf5>
   330b5:	49 89 c7             	mov    %rax,%r15
   330b8:	48 89 c7             	mov    %rax,%rdi
   330bb:	48 8b 74 24 50       	mov    0x50(%rsp),%rsi
   330c0:	e8 bb 77 ff ff       	call   2a880 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB2U_8adapters3map3MapINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map4IterllENCNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4mains2_0EE0E0INtNtB1b_3vec3VecBZ_EEB5c_>
   330c5:	4c 89 f8             	mov    %r15,%rax
   330c8:	48 8b ac 24 f8 00 00 	mov    0xf8(%rsp),%rbp
   330cf:	00 
   330d0:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   330d5:	e9 c0 d8 ff ff       	jmp    3099a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x22ba>
   330da:	48 8d 3d 78 64 fd ff 	lea    -0x29b88(%rip),%rdi        # 9559 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x362>
   330e1:	48 8d 15 38 d6 03 00 	lea    0x3d638(%rip),%rdx        # 70720 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8b0>
   330e8:	be 28 00 00 00       	mov    $0x28,%esi
   330ed:	e9 ac fc ff ff       	jmp    32d9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46be>
   330f2:	4c 89 e7             	mov    %r12,%rdi
   330f5:	4c 89 f6             	mov    %r14,%rsi
   330f8:	4c 89 fa             	mov    %r15,%rdx
   330fb:	e8 bc 5f ff ff       	call   290bc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCse9VFdDP9LWm_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33100:	e9 23 d9 ff ff       	jmp    30a28 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x2348>
   33105:	bf 01 00 00 00       	mov    $0x1,%edi
   3310a:	4c 89 fe             	mov    %r15,%rsi
   3310d:	ff 15 5d ee 03 00    	call   *0x3ee5d(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33113:	e9 01 04 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33118:	b0 01                	mov    $0x1,%al
   3311a:	e9 b6 fc ff ff       	jmp    32dd5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f5>
   3311f:	b0 01                	mov    $0x1,%al
   33121:	e9 91 fc ff ff       	jmp    32db7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d7>
   33126:	b0 01                	mov    $0x1,%al
   33128:	e9 e5 fc ff ff       	jmp    32e12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4732>
   3312d:	4c 89 bc 24 b8 00 00 	mov    %r15,0xb8(%rsp)
   33134:	00 
   33135:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   3313a:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   33141:	00 
   33142:	48 89 ac 24 c8 00 00 	mov    %rbp,0xc8(%rsp)
   33149:	00 
   3314a:	48 8d 3d a7 8d fd ff 	lea    -0x27259(%rip),%rdi        # bef8 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   33151:	48 8d 0d a8 e3 03 00 	lea    0x3e3a8(%rip),%rcx        # 71500 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   33158:	4c 8d 05 51 e3 03 00 	lea    0x3e351(%rip),%r8        # 714b0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   3315f:	48 8d 94 24 b8 00 00 	lea    0xb8(%rsp),%rdx
   33166:	00 
   33167:	be 2b 00 00 00       	mov    $0x2b,%esi
   3316c:	ff 15 a6 ee 03 00    	call   *0x3eea6(%rip)        # 72018 <_DYNAMIC+0x2a0>
   33172:	e9 a2 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33177:	be 28 00 00 00       	mov    $0x28,%esi
   3317c:	48 8d 3d d6 63 fd ff 	lea    -0x29c2a(%rip),%rdi        # 9559 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x362>
   33183:	48 8d 15 96 d5 03 00 	lea    0x3d596(%rip),%rdx        # 70720 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8b0>
   3318a:	e9 0f fc ff ff       	jmp    32d9e <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46be>
   3318f:	48 8d 05 ba d5 03 00 	lea    0x3d5ba(%rip),%rax        # 70750 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8e0>
   33196:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   3319d:	00 
   3319e:	48 8b bc 24 50 02 00 	mov    0x250(%rsp),%rdi
   331a5:	00 
   331a6:	ff 15 bc ef 03 00    	call   *0x3efbc(%rip)        # 72168 <_DYNAMIC+0x3f0>
   331ac:	e9 68 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   331b1:	c7 04 24 00 00 00 00 	movl   $0x0,(%rsp)
   331b8:	48 89 e7             	mov    %rsp,%rdi
   331bb:	e8 84 74 ff ff       	call   2a644 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtB4_6option6OptionTllEEBM_ECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   331c0:	e9 54 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   331c5:	bf 01 00 00 00       	mov    $0x1,%edi
   331ca:	4c 89 f6             	mov    %r14,%rsi
   331cd:	ff 15 9d ed 03 00    	call   *0x3ed9d(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   331d3:	e9 41 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   331d8:	bf 01 00 00 00       	mov    $0x1,%edi
   331dd:	4c 89 fe             	mov    %r15,%rsi
   331e0:	ff 15 8a ed 03 00    	call   *0x3ed8a(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   331e6:	e9 2e 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   331eb:	bf 01 00 00 00       	mov    $0x1,%edi
   331f0:	4c 89 f6             	mov    %r14,%rsi
   331f3:	ff 15 77 ed 03 00    	call   *0x3ed77(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   331f9:	e9 1b 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   331fe:	bf 01 00 00 00       	mov    $0x1,%edi
   33203:	4c 89 ee             	mov    %r13,%rsi
   33206:	ff 15 64 ed 03 00    	call   *0x3ed64(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   3320c:	e9 08 03 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33211:	bf 01 00 00 00       	mov    $0x1,%edi
   33216:	4c 89 ee             	mov    %r13,%rsi
   33219:	ff 15 51 ed 03 00    	call   *0x3ed51(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   3321f:	e9 f5 02 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33224:	49 89 ed             	mov    %rbp,%r13
   33227:	4c 89 f8             	mov    %r15,%rax
   3322a:	4c 29 e8             	sub    %r13,%rax
   3322d:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   33234:	aa aa aa 
   33237:	48 f7 e1             	mul    %rcx
   3323a:	4d 39 ef             	cmp    %r13,%r15
   3323d:	0f 85 b1 00 00 00    	jne    332f4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c14>
   33243:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   33249:	74 0a                	je     33255 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b75>
   3324b:	48 8b 3c 24          	mov    (%rsp),%rdi
   3324f:	ff 15 53 ed 03 00    	call   *0x3ed53(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33255:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
   3325c:	00 00 00 00 00 
   33261:	b8 08 00 00 00       	mov    $0x8,%eax
   33266:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   3326b:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
   33272:	00 00 00 00 00 
   33277:	45 31 f6             	xor    %r14d,%r14d
   3327a:	48 8d 15 cf 50 fd ff 	lea    -0x2af31(%rip),%rdx        # 8350 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x20d>
   33281:	48 8d 0d f9 62 fd ff 	lea    -0x29d07(%rip),%rcx        # 9581 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x38a>
   33288:	4c 8d 0d f1 d4 03 00 	lea    0x3d4f1(%rip),%r9        # 70780 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x910>
   3328f:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   33296:	00 
   33297:	41 b8 45 00 00 00    	mov    $0x45,%r8d
   3329d:	31 ff                	xor    %edi,%edi
   3329f:	ff 15 a3 ed 03 00    	call   *0x3eda3(%rip)        # 72048 <_DYNAMIC+0x2d0>
   332a5:	e9 6f 02 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   332aa:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   332b1:	00 
   332b2:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   332b7:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   332be:	00 
   332bf:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
   332c6:	00 
   332c7:	48 8d 3d 2a 8c fd ff 	lea    -0x273d6(%rip),%rdi        # bef8 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   332ce:	48 8d 0d 2b e2 03 00 	lea    0x3e22b(%rip),%rcx        # 71500 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   332d5:	4c 8d 05 d4 e1 03 00 	lea    0x3e1d4(%rip),%r8        # 714b0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   332dc:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
   332e3:	00 
   332e4:	be 2b 00 00 00       	mov    $0x2b,%esi
   332e9:	ff 15 29 ed 03 00    	call   *0x3ed29(%rip)        # 72018 <_DYNAMIC+0x2a0>
   332ef:	e9 25 02 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   332f4:	48 89 d3             	mov    %rdx,%rbx
   332f7:	48 c1 eb 04          	shr    $0x4,%rbx
   332fb:	49 83 c5 08          	add    $0x8,%r13
   332ff:	4c 8b 35 a2 ec 03 00 	mov    0x3eca2(%rip),%r14        # 71fa8 <free@GLIBC_2.2.5>
   33306:	eb 15                	jmp    3331d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c3d>
   33308:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3330f:	00 
   33310:	49 83 c5 18          	add    $0x18,%r13
   33314:	48 ff cb             	dec    %rbx
   33317:	0f 84 26 ff ff ff    	je     33243 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4b63>
   3331d:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   33322:	74 ec                	je     33310 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c30>
   33324:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   33328:	41 ff d6             	call   *%r14
   3332b:	eb e3                	jmp    33310 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4c30>
   3332d:	48 c7 84 24 30 01 00 	movq   $0x1,0x130(%rsp)
   33334:	00 01 00 00 00 
   33339:	b8 04 00 00 00       	mov    $0x4,%eax
   3333e:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   33345:	00 
   33346:	48 8d 15 33 50 fd ff 	lea    -0x2afcd(%rip),%rdx        # 8380 <anon.574165b9a1e3cebd535338bb0d7973a0.751.llvm.2316785571840406366+0x20>
   3334d:	4c 8d 0d 14 d4 03 00 	lea    0x3d414(%rip),%r9        # 70768 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8f8>
   33354:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   3335b:	00 
   3335c:	31 ff                	xor    %edi,%edi
   3335e:	31 c9                	xor    %ecx,%ecx
   33360:	ff 15 e2 ec 03 00    	call   *0x3ece2(%rip)        # 72048 <_DYNAMIC+0x2d0>
   33366:	e9 ae 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3336b:	bf 08 00 00 00       	mov    $0x8,%edi
   33370:	e9 21 b4 ff ff       	jmp    2e796 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0xb6>
   33375:	bf 04 00 00 00       	mov    $0x4,%edi
   3337a:	be 20 00 00 00       	mov    $0x20,%esi
   3337f:	ff 15 eb eb 03 00    	call   *0x3ebeb(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33385:	e9 8f 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3338a:	31 c0                	xor    %eax,%eax
   3338c:	e9 26 fa ff ff       	jmp    32db7 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46d7>
   33391:	be 1d 00 00 00       	mov    $0x1d,%esi
   33396:	48 89 ca             	mov    %rcx,%rdx
   33399:	ff 15 79 ed 03 00    	call   *0x3ed79(%rip)        # 72118 <_DYNAMIC+0x3a0>
   3339f:	e9 75 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   333a4:	31 c0                	xor    %eax,%eax
   333a6:	e9 2a fa ff ff       	jmp    32dd5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x46f5>
   333ab:	31 c0                	xor    %eax,%eax
   333ad:	e9 60 fa ff ff       	jmp    32e12 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4732>
   333b2:	bf 01 00 00 00       	mov    $0x1,%edi
   333b7:	be 15 00 00 00       	mov    $0x15,%esi
   333bc:	ff 15 ae eb 03 00    	call   *0x3ebae(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   333c2:	e9 52 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   333c7:	bf 01 00 00 00       	mov    $0x1,%edi
   333cc:	be 79 00 00 00       	mov    $0x79,%esi
   333d1:	ff 15 99 eb 03 00    	call   *0x3eb99(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   333d7:	e9 3d 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   333dc:	bf 01 00 00 00       	mov    $0x1,%edi
   333e1:	be 53 00 00 00       	mov    $0x53,%esi
   333e6:	ff 15 84 eb 03 00    	call   *0x3eb84(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   333ec:	e9 28 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   333f1:	bf 01 00 00 00       	mov    $0x1,%edi
   333f6:	be 04 00 00 00       	mov    $0x4,%esi
   333fb:	ff 15 6f eb 03 00    	call   *0x3eb6f(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33401:	e9 13 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33406:	bf 01 00 00 00       	mov    $0x1,%edi
   3340b:	48 89 de             	mov    %rbx,%rsi
   3340e:	ff 15 5c eb 03 00    	call   *0x3eb5c(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33414:	e9 00 01 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33419:	bf 01 00 00 00       	mov    $0x1,%edi
   3341e:	48 89 de             	mov    %rbx,%rsi
   33421:	ff 15 49 eb 03 00    	call   *0x3eb49(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33427:	e9 ed 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3342c:	bf 01 00 00 00       	mov    $0x1,%edi
   33431:	48 89 de             	mov    %rbx,%rsi
   33434:	ff 15 36 eb 03 00    	call   *0x3eb36(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   3343a:	e9 da 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3343f:	bf 01 00 00 00       	mov    $0x1,%edi
   33444:	4c 89 e6             	mov    %r12,%rsi
   33447:	ff 15 23 eb 03 00    	call   *0x3eb23(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   3344d:	e9 c7 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33452:	bf 01 00 00 00       	mov    $0x1,%edi
   33457:	4c 89 f6             	mov    %r14,%rsi
   3345a:	ff 15 10 eb 03 00    	call   *0x3eb10(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33460:	e9 b4 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33465:	bf 01 00 00 00       	mov    $0x1,%edi
   3346a:	4c 89 fe             	mov    %r15,%rsi
   3346d:	ff 15 fd ea 03 00    	call   *0x3eafd(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33473:	e9 a1 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   33478:	bf 01 00 00 00       	mov    $0x1,%edi
   3347d:	4c 89 fe             	mov    %r15,%rsi
   33480:	ff 15 ea ea 03 00    	call   *0x3eaea(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33486:	e9 8e 00 00 00       	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3348b:	bf 01 00 00 00       	mov    $0x1,%edi
   33490:	4c 89 fe             	mov    %r15,%rsi
   33493:	ff 15 d7 ea 03 00    	call   *0x3ead7(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33499:	eb 7e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3349b:	bf 01 00 00 00       	mov    $0x1,%edi
   334a0:	48 89 de             	mov    %rbx,%rsi
   334a3:	ff 15 c7 ea 03 00    	call   *0x3eac7(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334a9:	eb 6e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334ab:	bf 01 00 00 00       	mov    $0x1,%edi
   334b0:	48 89 de             	mov    %rbx,%rsi
   334b3:	ff 15 b7 ea 03 00    	call   *0x3eab7(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334b9:	eb 5e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334bb:	bf 01 00 00 00       	mov    $0x1,%edi
   334c0:	48 89 de             	mov    %rbx,%rsi
   334c3:	ff 15 a7 ea 03 00    	call   *0x3eaa7(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334c9:	eb 4e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334cb:	bf 01 00 00 00       	mov    $0x1,%edi
   334d0:	4c 89 e6             	mov    %r12,%rsi
   334d3:	ff 15 97 ea 03 00    	call   *0x3ea97(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334d9:	eb 3e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334db:	bf 01 00 00 00       	mov    $0x1,%edi
   334e0:	4c 89 f6             	mov    %r14,%rsi
   334e3:	ff 15 87 ea 03 00    	call   *0x3ea87(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334e9:	eb 2e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334eb:	bf 01 00 00 00       	mov    $0x1,%edi
   334f0:	4c 89 f6             	mov    %r14,%rsi
   334f3:	ff 15 77 ea 03 00    	call   *0x3ea77(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   334f9:	eb 1e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   334fb:	bf 01 00 00 00       	mov    $0x1,%edi
   33500:	4c 89 f6             	mov    %r14,%rsi
   33503:	ff 15 67 ea 03 00    	call   *0x3ea67(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33509:	eb 0e                	jmp    33519 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e39>
   3350b:	bf 01 00 00 00       	mov    $0x1,%edi
   33510:	4c 89 fe             	mov    %r15,%rsi
   33513:	ff 15 57 ea 03 00    	call   *0x3ea57(%rip)        # 71f70 <_DYNAMIC+0x1f8>
   33519:	0f 0b                	ud2
   3351b:	49 89 c4             	mov    %rax,%r12
   3351e:	4d 85 f6             	test   %r14,%r14
   33521:	0f 84 97 04 00 00    	je     339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   33527:	4c 89 ff             	mov    %r15,%rdi
   3352a:	ff 15 78 ea 03 00    	call   *0x3ea78(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33530:	e9 89 04 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   33535:	49 89 c4             	mov    %rax,%r12
   33538:	e9 2a 05 00 00       	jmp    33a67 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5387>
   3353d:	49 89 c4             	mov    %rax,%r12
   33540:	4c 89 f7             	mov    %r14,%rdi
   33543:	ff 15 5f ea 03 00    	call   *0x3ea5f(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33549:	eb 20                	jmp    3356b <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e8b>
   3354b:	eb 77                	jmp    335c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ee4>
   3354d:	eb 75                	jmp    335c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ee4>
   3354f:	eb 73                	jmp    335c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ee4>
   33551:	eb 15                	jmp    33568 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4e88>
   33553:	49 89 c4             	mov    %rax,%r12
   33556:	48 89 e7             	mov    %rsp,%rdi
   33559:	e8 72 6f ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3355e:	e9 5b 04 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   33563:	e9 61 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   33568:	49 89 c4             	mov    %rax,%r12
   3356b:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   33571:	0f 84 55 01 00 00    	je     336cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fec>
   33577:	4c 89 ff             	mov    %r15,%rdi
   3357a:	ff 15 28 ea 03 00    	call   *0x3ea28(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33580:	e9 47 01 00 00       	jmp    336cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fec>
   33585:	eb 3d                	jmp    335c4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ee4>
   33587:	e9 3d 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   3358c:	e9 38 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   33591:	e9 33 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   33596:	e9 2e 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   3359b:	e9 29 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   335a0:	e9 24 01 00 00       	jmp    336c9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fe9>
   335a5:	49 89 c4             	mov    %rax,%r12
   335a8:	4c 89 f7             	mov    %r14,%rdi
   335ab:	ff 15 f7 e9 03 00    	call   *0x3e9f7(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   335b1:	eb 72                	jmp    33625 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f45>
   335b3:	e9 aa 00 00 00       	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   335b8:	e9 a5 00 00 00       	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   335bd:	e9 a0 00 00 00       	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   335c2:	eb 5e                	jmp    33622 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f42>
   335c4:	49 89 c4             	mov    %rax,%r12
   335c7:	4c 89 f7             	mov    %r14,%rdi
   335ca:	ff 15 d8 e9 03 00    	call   *0x3e9d8(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   335d0:	e9 f7 00 00 00       	jmp    336cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fec>
   335d5:	eb 02                	jmp    335d9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ef9>
   335d7:	eb 00                	jmp    335d9 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4ef9>
   335d9:	49 89 c4             	mov    %rax,%r12
   335dc:	48 89 df             	mov    %rbx,%rdi
   335df:	ff 15 c3 e9 03 00    	call   *0x3e9c3(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   335e5:	e9 e2 00 00 00       	jmp    336cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4fec>
   335ea:	49 89 c4             	mov    %rax,%r12
   335ed:	48 89 e7             	mov    %rsp,%rdi
   335f0:	e8 db 6e ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   335f5:	e9 0e 03 00 00       	jmp    33908 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5228>
   335fa:	e9 6d 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   335ff:	eb 61                	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   33601:	e9 66 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33606:	e9 61 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   3360b:	eb 55                	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   3360d:	eb 5b                	jmp    3366a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f8a>
   3360f:	eb 59                	jmp    3366a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f8a>
   33611:	eb 57                	jmp    3366a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f8a>
   33613:	e9 54 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33618:	e9 4f 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   3361d:	e9 4a 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33622:	49 89 c4             	mov    %rax,%r12
   33625:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   3362b:	0f 84 11 02 00 00    	je     33842 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5162>
   33631:	4c 89 ff             	mov    %r15,%rdi
   33634:	e9 03 02 00 00       	jmp    3383c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x515c>
   33639:	eb 27                	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   3363b:	e9 2c 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33640:	e9 27 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33645:	e9 22 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   3364a:	e9 1d 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   3364f:	e9 18 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33654:	e9 13 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   33659:	e9 0e 01 00 00       	jmp    3376c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x508c>
   3365e:	eb 02                	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   33660:	eb 00                	jmp    33662 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x4f82>
   33662:	49 89 c4             	mov    %rax,%r12
   33665:	e9 cf 01 00 00       	jmp    33839 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5159>
   3366a:	49 89 c4             	mov    %rax,%r12
   3366d:	48 89 df             	mov    %rbx,%rdi
   33670:	e9 c7 01 00 00       	jmp    3383c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x515c>
   33675:	49 89 c4             	mov    %rax,%r12
   33678:	e9 b3 03 00 00       	jmp    33a30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5350>
   3367d:	e9 14 02 00 00       	jmp    33896 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x51b6>
   33682:	49 89 c4             	mov    %rax,%r12
   33685:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
   3368c:	00 00 
   3368e:	0f 84 51 04 00 00    	je     33ae5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5405>
   33694:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   3369b:	00 
   3369c:	e9 3e 04 00 00       	jmp    33adf <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53ff>
   336a1:	e9 2c 04 00 00       	jmp    33ad2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53f2>
   336a6:	e9 fd 01 00 00       	jmp    338a8 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x51c8>
   336ab:	49 89 c4             	mov    %rax,%r12
   336ae:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   336b3:	0f 84 05 03 00 00    	je     339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   336b9:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   336be:	ff 15 e4 e8 03 00    	call   *0x3e8e4(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   336c4:	e9 f5 02 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   336c9:	49 89 c4             	mov    %rax,%r12
   336cc:	48 8d bc 24 e0 00 00 	lea    0xe0(%rsp),%rdi
   336d3:	00 
   336d4:	e8 77 26 00 00       	call   35d50 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   336d9:	e9 e0 02 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   336de:	49 89 c4             	mov    %rax,%r12
   336e1:	4d 85 f6             	test   %r14,%r14
   336e4:	0f 85 a9 03 00 00    	jne    33a93 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53b3>
   336ea:	48 83 bc 24 18 02 00 	cmpq   $0x0,0x218(%rsp)
   336f1:	00 00 
   336f3:	0f 84 0c 04 00 00    	je     33b05 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5425>
   336f9:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   336fe:	ff 15 a4 e8 03 00    	call   *0x3e8a4(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33704:	4c 89 e7             	mov    %r12,%rdi
   33707:	e8 c4 b0 03 00       	call   6e7d0 <_Unwind_Resume@plt>
   3370c:	eb 7e                	jmp    3378c <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ac>
   3370e:	e9 b9 00 00 00       	jmp    337cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ec>
   33713:	e9 b4 00 00 00       	jmp    337cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ec>
   33718:	49 89 c4             	mov    %rax,%r12
   3371b:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   33720:	e8 ab 6d ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33725:	e9 de 01 00 00       	jmp    33908 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5228>
   3372a:	ff 15 d0 e8 03 00    	call   *0x3e8d0(%rip)        # 72000 <_DYNAMIC+0x288>
   33730:	e9 97 00 00 00       	jmp    337cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ec>
   33735:	49 89 c4             	mov    %rax,%r12
   33738:	4d 85 ed             	test   %r13,%r13
   3373b:	0f 84 04 02 00 00    	je     33945 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5265>
   33741:	49 83 c7 20          	add    $0x20,%r15
   33745:	49 f7 dd             	neg    %r13
   33748:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3374f:	00 
   33750:	4c 89 ff             	mov    %r15,%rdi
   33753:	e8 78 6d ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33758:	49 83 c7 20          	add    $0x20,%r15
   3375c:	49 ff cd             	dec    %r13
   3375f:	75 ef                	jne    33750 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5070>
   33761:	e9 df 01 00 00       	jmp    33945 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5265>
   33766:	ff 15 94 e8 03 00    	call   *0x3e894(%rip)        # 72000 <_DYNAMIC+0x288>
   3376c:	49 89 c4             	mov    %rax,%r12
   3376f:	e9 ce 00 00 00       	jmp    33842 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5162>
   33774:	49 89 c4             	mov    %rax,%r12
   33777:	48 83 bc 24 b8 00 00 	cmpq   $0x0,0xb8(%rsp)
   3377e:	00 00 
   33780:	74 1d                	je     3379f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50bf>
   33782:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   33789:	00 
   3378a:	eb 0d                	jmp    33799 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50b9>
   3378c:	49 89 c4             	mov    %rax,%r12
   3378f:	4d 85 ff             	test   %r15,%r15
   33792:	74 0b                	je     3379f <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50bf>
   33794:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   33799:	ff 15 09 e8 03 00    	call   *0x3e809(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   3379f:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   337a6:	00 
   337a7:	e8 34 6c ff ff       	call   2a3e0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCs8ZKwes1zzDd_3std3env4ArgsECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   337ac:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   337b1:	e8 5a 68 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsgFX3jaOk65H_5alloc3vec3VecNtNtBG_6string6StringEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   337b6:	4c 89 e7             	mov    %r12,%rdi
   337b9:	e8 12 b0 03 00       	call   6e7d0 <_Unwind_Resume@plt>
   337be:	eb 55                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   337c0:	eb 53                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   337c2:	eb 51                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   337c4:	eb 06                	jmp    337cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ec>
   337c6:	eb 4d                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   337c8:	eb 02                	jmp    337cc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x50ec>
   337ca:	eb 49                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   337cc:	49 89 c4             	mov    %rax,%r12
   337cf:	48 89 df             	mov    %rbx,%rdi
   337d2:	ff 15 d0 e7 03 00    	call   *0x3e7d0(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   337d8:	eb 3e                	jmp    33818 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5138>
   337da:	e9 dc 01 00 00       	jmp    339bb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52db>
   337df:	49 89 c4             	mov    %rax,%r12
   337e2:	41 be 06 00 00 00    	mov    $0x6,%r14d
   337e8:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
   337ef:	00 00 
   337f1:	0f 84 9c 02 00 00    	je     33a93 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53b3>
   337f7:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   337fe:	00 
   337ff:	e9 89 02 00 00       	jmp    33a8d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53ad>
   33804:	e9 b2 01 00 00       	jmp    339bb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52db>
   33809:	e9 f7 00 00 00       	jmp    33905 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5225>
   3380e:	eb 05                	jmp    33815 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5135>
   33810:	e9 ad 00 00 00       	jmp    338c2 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x51e2>
   33815:	49 89 c4             	mov    %rax,%r12
   33818:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   3381f:	00 
   33820:	e8 2b 25 00 00       	call   35d50 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33825:	e9 de 00 00 00       	jmp    33908 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5228>
   3382a:	0f 0b                	ud2
   3382c:	49 89 c4             	mov    %rax,%r12
   3382f:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   33834:	e8 27 6c ff ff       	call   2a460 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5error5ErrorECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33839:	4c 89 f7             	mov    %r14,%rdi
   3383c:	ff 15 66 e7 03 00    	call   *0x3e766(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33842:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   33849:	00 
   3384a:	e8 01 25 00 00       	call   35d50 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   3384f:	e9 b4 00 00 00       	jmp    33908 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5228>
   33854:	ff 15 a6 e7 03 00    	call   *0x3e7a6(%rip)        # 72000 <_DYNAMIC+0x288>
   3385a:	4c 89 e7             	mov    %r12,%rdi
   3385d:	ff 15 45 e7 03 00    	call   *0x3e745(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33863:	0f 0b                	ud2
   33865:	0f 0b                	ud2
   33867:	49 89 c4             	mov    %rax,%r12
   3386a:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   33871:	00 
   33872:	e8 e9 68 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33877:	e9 42 01 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   3387c:	e9 84 00 00 00       	jmp    33905 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5225>
   33881:	49 89 c4             	mov    %rax,%r12
   33884:	48 8d bc 24 b8 00 00 	lea    0xb8(%rsp),%rdi
   3388b:	00 
   3388c:	e8 cf 68 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33891:	e9 28 01 00 00       	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   33896:	49 89 c4             	mov    %rax,%r12
   33899:	e9 2d 01 00 00       	jmp    339cb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52eb>
   3389e:	eb 2a                	jmp    338ca <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x51ea>
   338a0:	49 89 c4             	mov    %rax,%r12
   338a3:	e9 3c 01 00 00       	jmp    339e4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5304>
   338a8:	49 89 c4             	mov    %rax,%r12
   338ab:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   338b0:	0f 84 2e 01 00 00    	je     339e4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5304>
   338b6:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   338bb:	e9 1e 01 00 00       	jmp    339de <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52fe>
   338c0:	eb 08                	jmp    338ca <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x51ea>
   338c2:	49 89 c4             	mov    %rax,%r12
   338c5:	e9 27 01 00 00       	jmp    339f1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5311>
   338ca:	49 89 c4             	mov    %rax,%r12
   338cd:	48 89 ef             	mov    %rbp,%rdi
   338d0:	ff 15 d2 e6 03 00    	call   *0x3e6d2(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   338d6:	e9 16 01 00 00       	jmp    339f1 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5311>
   338db:	49 89 c4             	mov    %rax,%r12
   338de:	48 83 bc 24 b8 00 00 	cmpq   $0x0,0xb8(%rsp)
   338e5:	00 00 
   338e7:	0f 84 de 00 00 00    	je     339cb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52eb>
   338ed:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   338f4:	00 
   338f5:	ff 15 ad e6 03 00    	call   *0x3e6ad(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   338fb:	e9 cb 00 00 00       	jmp    339cb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52eb>
   33900:	e9 b6 00 00 00       	jmp    339bb <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52db>
   33905:	49 89 c4             	mov    %rax,%r12
   33908:	4c 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%r14
   3390f:	00 
   33910:	48 8b 84 24 d0 01 00 	mov    0x1d0(%rsp),%rax
   33917:	00 
   33918:	48 85 c0             	test   %rax,%rax
   3391b:	74 28                	je     33945 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5265>
   3391d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   33923:	49 29 c7             	sub    %rax,%r15
   33926:	4c 89 f3             	mov    %r14,%rbx
   33929:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   33930:	48 89 df             	mov    %rbx,%rdi
   33933:	e8 98 6b ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33938:	48 83 c3 20          	add    $0x20,%rbx
   3393c:	49 ff c7             	inc    %r15
   3393f:	49 83 ff 01          	cmp    $0x1,%r15
   33943:	75 eb                	jne    33930 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5250>
   33945:	48 83 bc 24 c0 01 00 	cmpq   $0x0,0x1c0(%rsp)
   3394c:	00 00 
   3394e:	74 6e                	je     339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   33950:	4c 89 f7             	mov    %r14,%rdi
   33953:	ff 15 4f e6 03 00    	call   *0x3e64f(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33959:	eb 63                	jmp    339be <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52de>
   3395b:	4d 85 ff             	test   %r15,%r15
   3395e:	74 21                	je     33981 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x52a1>
   33960:	48 83 c3 20          	add    $0x20,%rbx
   33964:	49 f7 df             	neg    %r15
   33967:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3396e:	00 00 
   33970:	48 89 df             	mov    %rbx,%rdi
   33973:	e8 58 6b ff ff       	call   2a4d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33978:	48 83 c3 20          	add    $0x20,%rbx
   3397c:	49 ff cf             	dec    %r15
   3397f:	75 ef                	jne    33970 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5290>
   33981:	48 83 bc 24 c0 01 00 	cmpq   $0x0,0x1c0(%rsp)
   33988:	00 00 
   3398a:	0f 84 3c 01 00 00    	je     33acc <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53ec>
   33990:	4c 89 f7             	mov    %r14,%rdi
   33993:	ff 15 0f e6 03 00    	call   *0x3e60f(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33999:	ff 15 61 e6 03 00    	call   *0x3e661(%rip)        # 72000 <_DYNAMIC+0x288>
   3399f:	ff 15 5b e6 03 00    	call   *0x3e65b(%rip)        # 72000 <_DYNAMIC+0x288>
   339a5:	49 89 c4             	mov    %rax,%r12
   339a8:	e9 c7 00 00 00       	jmp    33a74 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5394>
   339ad:	49 89 c4             	mov    %rax,%r12
   339b0:	41 be 06 00 00 00    	mov    $0x6,%r14d
   339b6:	e9 d8 00 00 00       	jmp    33a93 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53b3>
   339bb:	49 89 c4             	mov    %rax,%r12
   339be:	48 8b bc 24 b8 01 00 	mov    0x1b8(%rsp),%rdi
   339c5:	00 
   339c6:	e8 65 65 ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   339cb:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   339d2:	00 00 
   339d4:	74 0e                	je     339e4 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5304>
   339d6:	48 8b bc 24 f8 01 00 	mov    0x1f8(%rsp),%rdi
   339dd:	00 
   339de:	ff 15 c4 e5 03 00    	call   *0x3e5c4(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   339e4:	48 8d bc 24 80 02 00 	lea    0x280(%rsp),%rdi
   339eb:	00 
   339ec:	e8 6f 67 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   339f1:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   339f8:	00 00 
   339fa:	74 0e                	je     33a0a <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x532a>
   339fc:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   33a03:	00 
   33a04:	ff 15 9e e5 03 00    	call   *0x3e59e(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33a0a:	48 83 bc 24 80 01 00 	cmpq   $0x0,0x180(%rsp)
   33a11:	00 00 
   33a13:	74 0e                	je     33a23 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5343>
   33a15:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
   33a1c:	00 
   33a1d:	ff 15 85 e5 03 00    	call   *0x3e585(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33a23:	48 8d bc 24 d8 01 00 	lea    0x1d8(%rsp),%rdi
   33a2a:	00 
   33a2b:	e8 30 67 ff ff       	call   2a160 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33a30:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   33a37:	00 
   33a38:	48 85 c9             	test   %rcx,%rcx
   33a3b:	74 2a                	je     33a67 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5387>
   33a3d:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   33a44:	00 
   33a45:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   33a49:	48 01 c1             	add    %rax,%rcx
   33a4c:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   33a50:	74 15                	je     33a67 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5387>
   33a52:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   33a59:	00 
   33a5a:	48 29 c7             	sub    %rax,%rdi
   33a5d:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   33a61:	ff 15 41 e5 03 00    	call   *0x3e541(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33a67:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   33a6e:	00 
   33a6f:	e8 bc 64 ff ff       	call   29f30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCse9VFdDP9LWm_4pbrs3map3MapllEECs9ZOqQLcSayJ_24pbrs_map_iteration_proof>
   33a74:	41 be 06 00 00 00    	mov    $0x6,%r14d
   33a7a:	48 83 bc 24 10 02 00 	cmpq   $0x0,0x210(%rsp)
   33a81:	00 00 
   33a83:	74 0e                	je     33a93 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53b3>
   33a85:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
   33a8c:	00 
   33a8d:	ff 15 15 e5 03 00    	call   *0x3e515(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33a93:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   33a98:	48 8d 58 08          	lea    0x8(%rax),%rbx
   33a9c:	4c 8b 3d 05 e5 03 00 	mov    0x3e505(%rip),%r15        # 71fa8 <free@GLIBC_2.2.5>
   33aa3:	eb 18                	jmp    33abd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53dd>
   33aa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   33aac:	00 00 00 00 
   33ab0:	48 83 c3 18          	add    $0x18,%rbx
   33ab4:	49 ff ce             	dec    %r14
   33ab7:	0f 84 2d fc ff ff    	je     336ea <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x500a>
   33abd:	48 83 7b f8 00       	cmpq   $0x0,-0x8(%rbx)
   33ac2:	74 ec                	je     33ab0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53d0>
   33ac4:	48 8b 3b             	mov    (%rbx),%rdi
   33ac7:	41 ff d7             	call   *%r15
   33aca:	eb e4                	jmp    33ab0 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x53d0>
   33acc:	ff 15 2e e5 03 00    	call   *0x3e52e(%rip)        # 72000 <_DYNAMIC+0x288>
   33ad2:	49 89 c4             	mov    %rax,%r12
   33ad5:	4d 85 f6             	test   %r14,%r14
   33ad8:	74 0b                	je     33ae5 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5405>
   33ada:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   33adf:	ff 15 c3 e4 03 00    	call   *0x3e4c3(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33ae5:	4c 89 f8             	mov    %r15,%rax
   33ae8:	48 29 e8             	sub    %rbp,%rax
   33aeb:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   33af2:	aa aa aa 
   33af5:	48 f7 e1             	mul    %rcx
   33af8:	49 39 ef             	cmp    %rbp,%r15
   33afb:	75 10                	jne    33b0d <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x542d>
   33afd:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   33b03:	75 44                	jne    33b49 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5469>
   33b05:	4c 89 e7             	mov    %r12,%rdi
   33b08:	e8 c3 ac 03 00       	call   6e7d0 <_Unwind_Resume@plt>
   33b0d:	48 89 d3             	mov    %rdx,%rbx
   33b10:	48 c1 eb 04          	shr    $0x4,%rbx
   33b14:	49 83 c5 20          	add    $0x20,%r13
   33b18:	4c 8b 35 89 e4 03 00 	mov    0x3e489(%rip),%r14        # 71fa8 <free@GLIBC_2.2.5>
   33b1f:	eb 18                	jmp    33b39 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5459>
   33b21:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   33b28:	0f 1f 84 00 00 00 00 
   33b2f:	00 
   33b30:	49 83 c5 18          	add    $0x18,%r13
   33b34:	48 ff cb             	dec    %rbx
   33b37:	74 c4                	je     33afd <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x541d>
   33b39:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   33b3e:	74 f0                	je     33b30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5450>
   33b40:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   33b44:	41 ff d6             	call   *%r14
   33b47:	eb e7                	jmp    33b30 <_RNvCs9ZOqQLcSayJ_24pbrs_map_iteration_proof4main+0x5450>
   33b49:	48 8b 3c 24          	mov    (%rsp),%rdi
   33b4d:	ff 15 55 e4 03 00    	call   *0x3e455(%rip)        # 71fa8 <free@GLIBC_2.2.5>
   33b53:	4c 89 e7             	mov    %r12,%rdi
   33b56:	e8 75 ac 03 00       	call   6e7d0 <_Unwind_Resume@plt>
