
work/all-benchmarks/measurement/round-map-actual-map/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002dd70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main>:
   2dd70:	55                   	push   %rbp
   2dd71:	41 57                	push   %r15
   2dd73:	41 56                	push   %r14
   2dd75:	41 55                	push   %r13
   2dd77:	41 54                	push   %r12
   2dd79:	53                   	push   %rbx
   2dd7a:	48 81 ec 88 02 00 00 	sub    $0x288,%rsp
   2dd81:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   2dd88:	00 
   2dd89:	ff 15 21 22 04 00    	call   *0x42221(%rip)        # 6ffb0 <_DYNAMIC+0x608>
   2dd8f:	4c 8b ac 24 c8 01 00 	mov    0x1c8(%rsp),%r13
   2dd96:	00 
   2dd97:	4c 8b bc 24 d8 01 00 	mov    0x1d8(%rsp),%r15
   2dd9e:	00 
   2dd9f:	4d 39 fd             	cmp    %r15,%r13
   2dda2:	0f 84 de 3c 00 00    	je     31a86 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d16>
   2dda8:	49 8d 6d 18          	lea    0x18(%r13),%rbp
   2ddac:	48 89 ac 24 c8 01 00 	mov    %rbp,0x1c8(%rsp)
   2ddb3:	00 
   2ddb4:	4d 8b 75 00          	mov    0x0(%r13),%r14
   2ddb8:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   2ddbc:	0f 84 c1 3c 00 00    	je     31a83 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d13>
   2ddc2:	49 8b 75 08          	mov    0x8(%r13),%rsi
   2ddc6:	49 8b 5d 10          	mov    0x10(%r13),%rbx
   2ddca:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2ddcf:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
   2ddd4:	48 89 da             	mov    %rbx,%rdx
   2ddd7:	ff 15 cb 1e 04 00    	call   *0x41ecb(%rip)        # 6fca8 <_DYNAMIC+0x300>
   2dddd:	83 7c 24 10 01       	cmpl   $0x1,0x10(%rsp)
   2dde2:	0f 84 25 3d 00 00    	je     31b0d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d9d>
   2dde8:	48 ba f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rdx
   2ddef:	ff ff 7f 
   2ddf2:	4c 89 bc 24 b0 00 00 	mov    %r15,0xb0(%rsp)
   2ddf9:	00 
   2ddfa:	4c 89 f8             	mov    %r15,%rax
   2ddfd:	48 29 e8             	sub    %rbp,%rax
   2de00:	48 89 c1             	mov    %rax,%rcx
   2de03:	48 c1 e9 03          	shr    $0x3,%rcx
   2de07:	48 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rsi
   2de0e:	aa aa aa 
   2de11:	48 0f af ce          	imul   %rsi,%rcx
   2de15:	48 83 f9 04          	cmp    $0x4,%rcx
   2de19:	41 bf 03 00 00 00    	mov    $0x3,%r15d
   2de1f:	4c 0f 43 f9          	cmovae %rcx,%r15
   2de23:	48 8d 4a ef          	lea    -0x11(%rdx),%rcx
   2de27:	48 39 c8             	cmp    %rcx,%rax
   2de2a:	76 18                	jbe    2de44 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd4>
   2de2c:	31 ff                	xor    %edi,%edi
   2de2e:	4c 89 e6             	mov    %r12,%rsi
   2de31:	4c 8b bc 24 b0 00 00 	mov    0xb0(%rsp),%r15
   2de38:	00 
   2de39:	ff 15 99 1d 04 00    	call   *0x41d99(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   2de3f:	e9 8d 3e 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   2de44:	4a 8d 04 fd 08 00 00 	lea    0x8(,%r15,8),%rax
   2de4b:	00 
   2de4c:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
   2de50:	4d 85 e4             	test   %r12,%r12
   2de53:	74 17                	je     2de6c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xfc>
   2de55:	4c 89 e7             	mov    %r12,%rdi
   2de58:	ff 15 32 1d 04 00    	call   *0x41d32(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2de5e:	48 85 c0             	test   %rax,%rax
   2de61:	0f 84 4e 3d 00 00    	je     31bb5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e45>
   2de67:	49 ff c7             	inc    %r15
   2de6a:	eb 08                	jmp    2de74 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x104>
   2de6c:	b8 08 00 00 00       	mov    $0x8,%eax
   2de71:	45 31 ff             	xor    %r15d,%r15d
   2de74:	4c 89 30             	mov    %r14,(%rax)
   2de77:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   2de7c:	48 89 48 08          	mov    %rcx,0x8(%rax)
   2de80:	48 89 58 10          	mov    %rbx,0x10(%rax)
   2de84:	4c 89 7c 24 60       	mov    %r15,0x60(%rsp)
   2de89:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2de8e:	48 c7 44 24 70 01 00 	movq   $0x1,0x70(%rsp)
   2de95:	00 00 
   2de97:	f3 0f 6f 84 24 c0 01 	movdqu 0x1c0(%rsp),%xmm0
   2de9e:	00 00 
   2dea0:	66 0f 10 8c 24 d0 01 	movupd 0x1d0(%rsp),%xmm1
   2dea7:	00 00 
   2dea9:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   2deaf:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2deb5:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   2deba:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   2debf:	4c 39 e5             	cmp    %r12,%rbp
   2dec2:	0f 84 e5 00 00 00    	je     2dfad <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23d>
   2dec8:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   2decf:	00 
   2ded0:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2ded6:	41 bd 28 00 00 00    	mov    $0x28,%r13d
   2dedc:	eb 3c                	jmp    2df1a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1aa>
   2dede:	66 90                	xchg   %ax,%ax
   2dee0:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   2dee7:	00 
   2dee8:	4e 89 7c 28 f0       	mov    %r15,-0x10(%rax,%r13,1)
   2deed:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   2def2:	4a 89 4c 28 f8       	mov    %rcx,-0x8(%rax,%r13,1)
   2def7:	4a 89 2c 28          	mov    %rbp,(%rax,%r13,1)
   2defb:	49 ff c6             	inc    %r14
   2defe:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
   2df03:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   2df08:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   2df0d:	49 83 c5 18          	add    $0x18,%r13
   2df11:	4c 39 e5             	cmp    %r12,%rbp
   2df14:	0f 84 9e 00 00 00    	je     2dfb8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x248>
   2df1a:	48 8d 5d 18          	lea    0x18(%rbp),%rbx
   2df1e:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   2df23:	4c 8b 7d 00          	mov    0x0(%rbp),%r15
   2df27:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
   2df2b:	0f 84 84 00 00 00    	je     2dfb5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x245>
   2df31:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   2df35:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
   2df39:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   2df40:	00 
   2df41:	48 89 74 24 58       	mov    %rsi,0x58(%rsp)
   2df46:	48 89 ea             	mov    %rbp,%rdx
   2df49:	ff 15 59 1d 04 00    	call   *0x41d59(%rip)        # 6fca8 <_DYNAMIC+0x300>
   2df4f:	83 bc 24 e8 00 00 00 	cmpl   $0x1,0xe8(%rsp)
   2df56:	01 
   2df57:	0f 84 66 3a 00 00    	je     319c3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c53>
   2df5d:	4c 3b 74 24 60       	cmp    0x60(%rsp),%r14
   2df62:	0f 85 78 ff ff ff    	jne    2dee0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x170>
   2df68:	49 29 dc             	sub    %rbx,%r12
   2df6b:	49 c1 ec 03          	shr    $0x3,%r12
   2df6f:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   2df76:	aa aa aa 
   2df79:	4c 0f af e0          	imul   %rax,%r12
   2df7d:	49 ff c4             	inc    %r12
   2df80:	b9 08 00 00 00       	mov    $0x8,%ecx
   2df85:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   2df8b:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   2df90:	4c 89 f6             	mov    %r14,%rsi
   2df93:	4c 89 e2             	mov    %r12,%rdx
   2df96:	e8 c5 e6 ff ff       	call   2c660 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2df9b:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2dfa0:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   2dfa7:	00 
   2dfa8:	e9 33 ff ff ff       	jmp    2dee0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x170>
   2dfad:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2dfb3:	eb 03                	jmp    2dfb8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x248>
   2dfb5:	48 89 dd             	mov    %rbx,%rbp
   2dfb8:	4c 89 e0             	mov    %r12,%rax
   2dfbb:	48 29 e8             	sub    %rbp,%rax
   2dfbe:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   2dfc5:	aa aa aa 
   2dfc8:	48 f7 e1             	mul    %rcx
   2dfcb:	49 39 ec             	cmp    %rbp,%r12
   2dfce:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
   2dfd3:	74 34                	je     2e009 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x299>
   2dfd5:	48 89 d3             	mov    %rdx,%rbx
   2dfd8:	48 c1 eb 04          	shr    $0x4,%rbx
   2dfdc:	48 83 c5 08          	add    $0x8,%rbp
   2dfe0:	4c 8b 3d b9 1b 04 00 	mov    0x41bb9(%rip),%r15        # 6fba0 <free@GLIBC_2.2.5>
   2dfe7:	eb 10                	jmp    2dff9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x289>
   2dfe9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2dff0:	48 83 c5 18          	add    $0x18,%rbp
   2dff4:	48 ff cb             	dec    %rbx
   2dff7:	74 10                	je     2e009 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x299>
   2dff9:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   2dffe:	74 f0                	je     2dff0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x280>
   2e000:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   2e004:	41 ff d7             	call   *%r15
   2e007:	eb e7                	jmp    2dff0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x280>
   2e009:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
   2e00f:	74 0b                	je     2e01c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ac>
   2e011:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2e016:	ff 15 84 1b 04 00    	call   *0x41b84(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   2e01c:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2e021:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   2e028:	00 
   2e029:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2e02e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e033:	49 83 fe 06          	cmp    $0x6,%r14
   2e037:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   2e03e:	00 
   2e03f:	0f 85 9b 3a 00 00    	jne    31ae0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d70>
   2e045:	48 8d 48 30          	lea    0x30(%rax),%rcx
   2e049:	48 89 8c 24 48 02 00 	mov    %rcx,0x248(%rsp)
   2e050:	00 
   2e051:	48 89 8c 24 28 02 00 	mov    %rcx,0x228(%rsp)
   2e058:	00 
   2e059:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2e05d:	48 8b 70 70          	mov    0x70(%rax),%rsi
   2e061:	48 83 fe 01          	cmp    $0x1,%rsi
   2e065:	74 0e                	je     2e075 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x305>
   2e067:	48 85 f6             	test   %rsi,%rsi
   2e06a:	0f 84 a3 3b 00 00    	je     31c13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ea3>
   2e070:	0f b6 11             	movzbl (%rcx),%edx
   2e073:	eb 17                	jmp    2e08c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x31c>
   2e075:	0f b6 11             	movzbl (%rcx),%edx
   2e078:	b0 01                	mov    $0x1,%al
   2e07a:	83 fa 2b             	cmp    $0x2b,%edx
   2e07d:	0f 84 6e 36 00 00    	je     316f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3981>
   2e083:	83 fa 2d             	cmp    $0x2d,%edx
   2e086:	0f 84 65 36 00 00    	je     316f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3981>
   2e08c:	31 c0                	xor    %eax,%eax
   2e08e:	80 fa 2b             	cmp    $0x2b,%dl
   2e091:	0f 94 c0             	sete   %al
   2e094:	48 89 f2             	mov    %rsi,%rdx
   2e097:	48 29 c2             	sub    %rax,%rdx
   2e09a:	48 01 c1             	add    %rax,%rcx
   2e09d:	48 f7 d8             	neg    %rax
   2e0a0:	48 83 fa 11          	cmp    $0x11,%rdx
   2e0a4:	73 4b                	jae    2e0f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x381>
   2e0a6:	48 85 d2             	test   %rdx,%rdx
   2e0a9:	0f 84 9f 00 00 00    	je     2e14e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3de>
   2e0af:	48 01 c6             	add    %rax,%rsi
   2e0b2:	48 f7 de             	neg    %rsi
   2e0b5:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   2e0bc:	00 00 
   2e0be:	31 c0                	xor    %eax,%eax
   2e0c0:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2e0c4:	83 c2 d0             	add    $0xffffffd0,%edx
   2e0c7:	83 fa 09             	cmp    $0x9,%edx
   2e0ca:	0f 87 e5 38 00 00    	ja     319b5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c45>
   2e0d0:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   2e0d5:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
   2e0d9:	89 d2                	mov    %edx,%edx
   2e0db:	48 8d 14 7a          	lea    (%rdx,%rdi,2),%rdx
   2e0df:	48 89 54 24 58       	mov    %rdx,0x58(%rsp)
   2e0e4:	48 ff c0             	inc    %rax
   2e0e7:	48 89 f2             	mov    %rsi,%rdx
   2e0ea:	48 01 c2             	add    %rax,%rdx
   2e0ed:	75 d1                	jne    2e0c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x350>
   2e0ef:	eb 66                	jmp    2e157 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e7>
   2e0f1:	48 01 c6             	add    %rax,%rsi
   2e0f4:	48 f7 de             	neg    %rsi
   2e0f7:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   2e0fe:	00 00 
   2e100:	bf 0a 00 00 00       	mov    $0xa,%edi
   2e105:	45 31 c0             	xor    %r8d,%r8d
   2e108:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e10f:	00 
   2e110:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2e115:	48 f7 e7             	mul    %rdi
   2e118:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2e11d:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2e122:	0f 80 bb 35 00 00    	jo     316e3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3973>
   2e128:	83 c2 d0             	add    $0xffffffd0,%edx
   2e12b:	83 fa 0a             	cmp    $0xa,%edx
   2e12e:	0f 83 81 38 00 00    	jae    319b5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c45>
   2e134:	89 d0                	mov    %edx,%eax
   2e136:	48 01 44 24 58       	add    %rax,0x58(%rsp)
   2e13b:	0f 82 ae 35 00 00    	jb     316ef <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x397f>
   2e141:	49 ff c0             	inc    %r8
   2e144:	48 89 f0             	mov    %rsi,%rax
   2e147:	4c 01 c0             	add    %r8,%rax
   2e14a:	75 c4                	jne    2e110 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a0>
   2e14c:	eb 09                	jmp    2e157 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e7>
   2e14e:	48 c7 44 24 58 00 00 	movq   $0x0,0x58(%rsp)
   2e155:	00 00 
   2e157:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   2e15e:	00 
   2e15f:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
   2e166:	4c 8b 80 88 00 00 00 	mov    0x88(%rax),%r8
   2e16d:	49 83 f8 01          	cmp    $0x1,%r8
   2e171:	74 0e                	je     2e181 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x411>
   2e173:	4d 85 c0             	test   %r8,%r8
   2e176:	0f 84 9e 3a 00 00    	je     31c1a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eaa>
   2e17c:	0f b6 0e             	movzbl (%rsi),%ecx
   2e17f:	eb 17                	jmp    2e198 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x428>
   2e181:	0f b6 0e             	movzbl (%rsi),%ecx
   2e184:	b0 01                	mov    $0x1,%al
   2e186:	83 f9 2b             	cmp    $0x2b,%ecx
   2e189:	0f 84 7d 35 00 00    	je     3170c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399c>
   2e18f:	83 f9 2d             	cmp    $0x2d,%ecx
   2e192:	0f 84 74 35 00 00    	je     3170c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399c>
   2e198:	31 c0                	xor    %eax,%eax
   2e19a:	80 f9 2b             	cmp    $0x2b,%cl
   2e19d:	0f 94 c0             	sete   %al
   2e1a0:	4c 89 c2             	mov    %r8,%rdx
   2e1a3:	48 29 c2             	sub    %rax,%rdx
   2e1a6:	48 01 c6             	add    %rax,%rsi
   2e1a9:	48 f7 d8             	neg    %rax
   2e1ac:	48 8d 0d 55 00 04 00 	lea    0x40055(%rip),%rcx        # 6e208 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f8>
   2e1b3:	48 8d 3d 96 b0 fd ff 	lea    -0x24f6a(%rip),%rdi        # 9250 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x89>
   2e1ba:	48 83 fa 11          	cmp    $0x11,%rdx
   2e1be:	73 47                	jae    2e207 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x497>
   2e1c0:	48 85 d2             	test   %rdx,%rdx
   2e1c3:	0f 84 58 3a 00 00    	je     31c21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb1>
   2e1c9:	49 01 c0             	add    %rax,%r8
   2e1cc:	49 f7 d8             	neg    %r8
   2e1cf:	45 31 db             	xor    %r11d,%r11d
   2e1d2:	31 c0                	xor    %eax,%eax
   2e1d4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e1db:	00 00 00 00 00 
   2e1e0:	0f b6 14 06          	movzbl (%rsi,%rax,1),%edx
   2e1e4:	83 c2 d0             	add    $0xffffffd0,%edx
   2e1e7:	83 fa 09             	cmp    $0x9,%edx
   2e1ea:	0f 87 be 37 00 00    	ja     319ae <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c3e>
   2e1f0:	4f 8d 0c 9b          	lea    (%r11,%r11,4),%r9
   2e1f4:	89 d2                	mov    %edx,%edx
   2e1f6:	4e 8d 1c 4a          	lea    (%rdx,%r9,2),%r11
   2e1fa:	48 ff c0             	inc    %rax
   2e1fd:	4c 89 c2             	mov    %r8,%rdx
   2e200:	48 01 c2             	add    %rax,%rdx
   2e203:	75 db                	jne    2e1e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x470>
   2e205:	eb 4f                	jmp    2e256 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e6>
   2e207:	49 01 c0             	add    %rax,%r8
   2e20a:	49 f7 d8             	neg    %r8
   2e20d:	45 31 db             	xor    %r11d,%r11d
   2e210:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
   2e216:	45 31 d2             	xor    %r10d,%r10d
   2e219:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e220:	4c 89 d8             	mov    %r11,%rax
   2e223:	49 f7 e1             	mul    %r9
   2e226:	42 0f b6 14 16       	movzbl (%rsi,%r10,1),%edx
   2e22b:	0f 80 cd 34 00 00    	jo     316fe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x398e>
   2e231:	83 c2 d0             	add    $0xffffffd0,%edx
   2e234:	83 fa 0a             	cmp    $0xa,%edx
   2e237:	0f 83 71 37 00 00    	jae    319ae <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c3e>
   2e23d:	49 89 c3             	mov    %rax,%r11
   2e240:	89 d0                	mov    %edx,%eax
   2e242:	49 01 c3             	add    %rax,%r11
   2e245:	0f 82 bf 34 00 00    	jb     3170a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399a>
   2e24b:	49 ff c2             	inc    %r10
   2e24e:	4c 89 c0             	mov    %r8,%rax
   2e251:	4c 01 d0             	add    %r10,%rax
   2e254:	75 ca                	jne    2e220 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b0>
   2e256:	be 2f 00 00 00       	mov    $0x2f,%esi
   2e25b:	48 83 7c 24 58 00    	cmpq   $0x0,0x58(%rsp)
   2e261:	0f 84 bf 39 00 00    	je     31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e267:	4d 85 db             	test   %r11,%r11
   2e26a:	0f 84 b6 39 00 00    	je     31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e270:	48 8b 94 24 a8 00 00 	mov    0xa8(%rsp),%rdx
   2e277:	00 
   2e278:	48 8b 42 40          	mov    0x40(%rdx),%rax
   2e27c:	48 8d 0d 9d ff 03 00 	lea    0x3ff9d(%rip),%rcx        # 6e220 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x710>
   2e283:	be 39 00 00 00       	mov    $0x39,%esi
   2e288:	48 8d 3d f0 af fd ff 	lea    -0x25010(%rip),%rdi        # 927f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xb8>
   2e28f:	48 83 f8 05          	cmp    $0x5,%rax
   2e293:	75 1b                	jne    2e2b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x540>
   2e295:	48 8b 42 38          	mov    0x38(%rdx),%rax
   2e299:	ba 70 72 6f 73       	mov    $0x736f7270,%edx
   2e29e:	33 10                	xor    (%rax),%edx
   2e2a0:	0f b6 40 04          	movzbl 0x4(%rax),%eax
   2e2a4:	83 f0 74             	xor    $0x74,%eax
   2e2a7:	09 d0                	or     %edx,%eax
   2e2a9:	74 27                	je     2e2d2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x562>
   2e2ab:	e9 76 39 00 00       	jmp    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e2b0:	48 83 f8 04          	cmp    $0x4,%rax
   2e2b4:	0f 85 6c 39 00 00    	jne    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e2ba:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   2e2c1:	00 
   2e2c2:	48 8b 40 38          	mov    0x38(%rax),%rax
   2e2c6:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2e2cc:	0f 85 54 39 00 00    	jne    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e2d2:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   2e2d9:	00 
   2e2da:	48 8b 41 50          	mov    0x50(%rcx),%rax
   2e2de:	48 8b 51 58          	mov    0x58(%rcx),%rdx
   2e2e2:	48 8d 0d 4f ff 03 00 	lea    0x3ff4f(%rip),%rcx        # 6e238 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x728>
   2e2e9:	be 4f 00 00 00       	mov    $0x4f,%esi
   2e2ee:	48 8d 3d c3 af fd ff 	lea    -0x2503d(%rip),%rdi        # 92b8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xf1>
   2e2f5:	48 83 fa 08          	cmp    $0x8,%rdx
   2e2f9:	74 1f                	je     2e31a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5aa>
   2e2fb:	48 83 fa 0a          	cmp    $0xa,%rdx
   2e2ff:	75 2d                	jne    2e32e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5be>
   2e301:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2e308:	66 69 72 
   2e30b:	48 33 10             	xor    (%rax),%rdx
   2e30e:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e312:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e318:	eb 34                	jmp    2e34e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5de>
   2e31a:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2e321:	61 6c 6c 
   2e324:	48 39 10             	cmp    %rdx,(%rax)
   2e327:	74 2e                	je     2e357 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5e7>
   2e329:	e9 f8 38 00 00       	jmp    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e32e:	48 83 fa 0c          	cmp    $0xc,%rdx
   2e332:	0f 85 ee 38 00 00    	jne    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e338:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2e33f:	63 6f 6c 
   2e342:	48 33 10             	xor    (%rax),%rdx
   2e345:	8b 40 08             	mov    0x8(%rax),%eax
   2e348:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e34e:	48 09 d0             	or     %rdx,%rax
   2e351:	0f 85 cf 38 00 00    	jne    31c26 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   2e357:	4c 89 9c 24 58 02 00 	mov    %r11,0x258(%rsp)
   2e35e:	00 
   2e35f:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   2e366:	00 
   2e367:	48 8d 48 48          	lea    0x48(%rax),%rcx
   2e36b:	48 89 8c 24 20 02 00 	mov    %rcx,0x220(%rsp)
   2e372:	00 
   2e373:	48 bd 80 80 80 80 80 	movabs $0x8080808080808080,%rbp
   2e37a:	80 80 80 
   2e37d:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e384:	5f 5f 5f 
   2e387:	49 bd 00 01 01 01 01 	movabs $0x101010101010100,%r13
   2e38e:	01 01 01 
   2e391:	48 8b 50 20          	mov    0x20(%rax),%rdx
   2e395:	48 8b 70 28          	mov    0x28(%rax),%rsi
   2e399:	48 8d 42 08          	lea    0x8(%rdx),%rax
   2e39d:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   2e3a4:	00 
   2e3a5:	45 31 f6             	xor    %r14d,%r14d
   2e3a8:	31 c0                	xor    %eax,%eax
   2e3aa:	48 89 94 24 b0 00 00 	mov    %rdx,0xb0(%rsp)
   2e3b1:	00 
   2e3b2:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   2e3b7:	eb 25                	jmp    2e3de <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x66e>
   2e3b9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e3c0:	4c 89 e0             	mov    %r12,%rax
   2e3c3:	49 39 f4             	cmp    %rsi,%r12
   2e3c6:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e3cd:	5f 5f 5f 
   2e3d0:	48 8b 94 24 b0 00 00 	mov    0xb0(%rsp),%rdx
   2e3d7:	00 
   2e3d8:	0f 87 b2 32 00 00    	ja     31690 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3920>
   2e3de:	48 89 f1             	mov    %rsi,%rcx
   2e3e1:	48 29 c1             	sub    %rax,%rcx
   2e3e4:	48 01 c2             	add    %rax,%rdx
   2e3e7:	48 83 f9 0f          	cmp    $0xf,%rcx
   2e3eb:	77 33                	ja     2e420 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6b0>
   2e3ed:	b3 01                	mov    $0x1,%bl
   2e3ef:	48 39 c6             	cmp    %rax,%rsi
   2e3f2:	0f 84 3d 01 00 00    	je     2e535 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7c5>
   2e3f8:	45 31 ff             	xor    %r15d,%r15d
   2e3fb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2e400:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e405:	0f 84 e5 00 00 00    	je     2e4f0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x780>
   2e40b:	49 ff c7             	inc    %r15
   2e40e:	4c 39 f9             	cmp    %r15,%rcx
   2e411:	75 ed                	jne    2e400 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x690>
   2e413:	e9 1d 01 00 00       	jmp    2e535 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7c5>
   2e418:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e41f:	00 
   2e420:	48 8d 72 07          	lea    0x7(%rdx),%rsi
   2e424:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   2e428:	48 29 d6             	sub    %rdx,%rsi
   2e42b:	75 53                	jne    2e480 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x710>
   2e42d:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2e431:	31 f6                	xor    %esi,%esi
   2e433:	4c 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%r8
   2e43a:	00 
   2e43b:	49 01 c0             	add    %rax,%r8
   2e43e:	66 90                	xchg   %ax,%ax
   2e440:	4d 8b 4c 30 f8       	mov    -0x8(%r8,%rsi,1),%r9
   2e445:	4d 89 ca             	mov    %r9,%r10
   2e448:	49 31 da             	xor    %rbx,%r10
   2e44b:	4d 89 eb             	mov    %r13,%r11
   2e44e:	4d 29 d3             	sub    %r10,%r11
   2e451:	4d 09 cb             	or     %r9,%r11
   2e454:	4d 8b 0c 30          	mov    (%r8,%rsi,1),%r9
   2e458:	49 31 d9             	xor    %rbx,%r9
   2e45b:	4d 89 ea             	mov    %r13,%r10
   2e45e:	4d 29 ca             	sub    %r9,%r10
   2e461:	4d 09 ca             	or     %r9,%r10
   2e464:	49 21 eb             	and    %rbp,%r11
   2e467:	4d 21 d3             	and    %r10,%r11
   2e46a:	49 39 eb             	cmp    %rbp,%r11
   2e46d:	75 51                	jne    2e4c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x750>
   2e46f:	48 83 c6 10          	add    $0x10,%rsi
   2e473:	48 39 fe             	cmp    %rdi,%rsi
   2e476:	76 c8                	jbe    2e440 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6d0>
   2e478:	eb 46                	jmp    2e4c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x750>
   2e47a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e480:	45 31 ff             	xor    %r15d,%r15d
   2e483:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e48a:	84 00 00 00 00 00 
   2e490:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e495:	74 59                	je     2e4f0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x780>
   2e497:	49 ff c7             	inc    %r15
   2e49a:	4c 39 fe             	cmp    %r15,%rsi
   2e49d:	75 f1                	jne    2e490 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x720>
   2e49f:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2e4a3:	48 39 fe             	cmp    %rdi,%rsi
   2e4a6:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e4ad:	5f 5f 5f 
   2e4b0:	76 81                	jbe    2e433 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6c3>
   2e4b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e4b9:	1f 84 00 00 00 00 00 
   2e4c0:	b3 01                	mov    $0x1,%bl
   2e4c2:	49 89 f7             	mov    %rsi,%r15
   2e4c5:	48 39 f1             	cmp    %rsi,%rcx
   2e4c8:	74 6b                	je     2e535 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7c5>
   2e4ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e4d0:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e4d5:	74 19                	je     2e4f0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x780>
   2e4d7:	49 ff c7             	inc    %r15
   2e4da:	4c 39 f9             	cmp    %r15,%rcx
   2e4dd:	75 f1                	jne    2e4d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x760>
   2e4df:	eb 54                	jmp    2e535 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7c5>
   2e4e1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e4e8:	0f 1f 84 00 00 00 00 
   2e4ef:	00 
   2e4f0:	4d 8d 24 07          	lea    (%r15,%rax,1),%r12
   2e4f4:	49 ff c4             	inc    %r12
   2e4f7:	49 01 c7             	add    %rax,%r15
   2e4fa:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e4ff:	49 39 f7             	cmp    %rsi,%r15
   2e502:	0f 83 b8 fe ff ff    	jae    2e3c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x650>
   2e508:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   2e50f:	00 
   2e510:	42 80 3c 38 5f       	cmpb   $0x5f,(%rax,%r15,1)
   2e515:	0f 85 a5 fe ff ff    	jne    2e3c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x650>
   2e51b:	31 db                	xor    %ebx,%ebx
   2e51d:	4d 89 e6             	mov    %r12,%r14
   2e520:	bf 40 00 00 00       	mov    $0x40,%edi
   2e525:	ff 15 65 16 04 00    	call   *0x41665(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2e52b:	48 85 c0             	test   %rax,%rax
   2e52e:	75 21                	jne    2e551 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7e1>
   2e530:	e9 74 31 00 00       	jmp    316a9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3939>
   2e535:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2e53a:	4d 89 fc             	mov    %r15,%r12
   2e53d:	bf 40 00 00 00       	mov    $0x40,%edi
   2e542:	ff 15 48 16 04 00    	call   *0x41648(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2e548:	48 85 c0             	test   %rax,%rax
   2e54b:	0f 84 58 31 00 00    	je     316a9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3939>
   2e551:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   2e558:	00 
   2e559:	48 89 08             	mov    %rcx,(%rax)
   2e55c:	4c 89 78 08          	mov    %r15,0x8(%rax)
   2e560:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   2e567:	00 00 
   2e569:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   2e570:	00 
   2e571:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e576:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2e57d:	00 00 
   2e57f:	84 db                	test   %bl,%bl
   2e581:	0f 85 f6 35 00 00    	jne    31b7d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e0d>
   2e587:	bb 01 00 00 00       	mov    $0x1,%ebx
   2e58c:	eb 3e                	jmp    2e5cc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x85c>
   2e58e:	66 90                	xchg   %ax,%ax
   2e590:	4d 29 f7             	sub    %r14,%r15
   2e593:	4c 03 b4 24 b0 00 00 	add    0xb0(%rsp),%r14
   2e59a:	00 
   2e59b:	48 89 d8             	mov    %rbx,%rax
   2e59e:	48 c1 e0 04          	shl    $0x4,%rax
   2e5a2:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   2e5a9:	00 
   2e5aa:	4c 89 34 01          	mov    %r14,(%rcx,%rax,1)
   2e5ae:	4c 89 7c 01 08       	mov    %r15,0x8(%rcx,%rax,1)
   2e5b3:	48 ff c3             	inc    %rbx
   2e5b6:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   2e5bb:	49 89 ee             	mov    %rbp,%r14
   2e5be:	80 bc 24 50 01 00 00 	cmpb   $0x0,0x150(%rsp)
   2e5c5:	00 
   2e5c6:	0f 85 01 02 00 00    	jne    2e7cd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa5d>
   2e5cc:	b0 01                	mov    $0x1,%al
   2e5ce:	89 84 24 50 01 00 00 	mov    %eax,0x150(%rsp)
   2e5d5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2e5da:	4c 39 e1             	cmp    %r12,%rcx
   2e5dd:	73 11                	jae    2e5f0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x880>
   2e5df:	4c 89 f5             	mov    %r14,%rbp
   2e5e2:	49 89 cf             	mov    %rcx,%r15
   2e5e5:	e9 a1 01 00 00       	jmp    2e78b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa1b>
   2e5ea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e5f0:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e5f7:	5f 5f 5f 
   2e5fa:	eb 1a                	jmp    2e616 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8a6>
   2e5fc:	0f 1f 40 00          	nopl   0x0(%rax)
   2e600:	49 89 ec             	mov    %rbp,%r12
   2e603:	48 39 cd             	cmp    %rcx,%rbp
   2e606:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e60d:	5f 5f 5f 
   2e610:	0f 87 af 01 00 00    	ja     2e7c5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa55>
   2e616:	48 89 c8             	mov    %rcx,%rax
   2e619:	4c 29 e0             	sub    %r12,%rax
   2e61c:	48 89 ca             	mov    %rcx,%rdx
   2e61f:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   2e626:	00 
   2e627:	4c 01 e1             	add    %r12,%rcx
   2e62a:	48 83 f8 0f          	cmp    $0xf,%rax
   2e62e:	77 30                	ja     2e660 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8f0>
   2e630:	4c 39 e2             	cmp    %r12,%rdx
   2e633:	0f 84 47 01 00 00    	je     2e780 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa10>
   2e639:	45 31 ff             	xor    %r15d,%r15d
   2e63c:	0f 1f 40 00          	nopl   0x0(%rax)
   2e640:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e645:	0f 84 f5 00 00 00    	je     2e740 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9d0>
   2e64b:	49 ff c7             	inc    %r15
   2e64e:	4c 39 f8             	cmp    %r15,%rax
   2e651:	75 ed                	jne    2e640 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8d0>
   2e653:	e9 28 01 00 00       	jmp    2e780 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa10>
   2e658:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e65f:	00 
   2e660:	48 8d 51 07          	lea    0x7(%rcx),%rdx
   2e664:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
   2e668:	48 29 ca             	sub    %rcx,%rdx
   2e66b:	49 bb 80 80 80 80 80 	movabs $0x8080808080808080,%r11
   2e672:	80 80 80 
   2e675:	75 59                	jne    2e6d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x960>
   2e677:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2e67b:	31 d2                	xor    %edx,%edx
   2e67d:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   2e684:	00 
   2e685:	4c 01 e7             	add    %r12,%rdi
   2e688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e68f:	00 
   2e690:	4c 8b 44 17 f8       	mov    -0x8(%rdi,%rdx,1),%r8
   2e695:	4d 89 c1             	mov    %r8,%r9
   2e698:	4d 31 f9             	xor    %r15,%r9
   2e69b:	4d 89 ea             	mov    %r13,%r10
   2e69e:	4d 29 ca             	sub    %r9,%r10
   2e6a1:	4d 09 c2             	or     %r8,%r10
   2e6a4:	4c 8b 04 17          	mov    (%rdi,%rdx,1),%r8
   2e6a8:	4d 31 f8             	xor    %r15,%r8
   2e6ab:	4d 89 e9             	mov    %r13,%r9
   2e6ae:	4d 29 c1             	sub    %r8,%r9
   2e6b1:	4d 09 c1             	or     %r8,%r9
   2e6b4:	4d 21 da             	and    %r11,%r10
   2e6b7:	4d 21 ca             	and    %r9,%r10
   2e6ba:	4d 39 da             	cmp    %r11,%r10
   2e6bd:	75 51                	jne    2e710 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9a0>
   2e6bf:	48 83 c2 10          	add    $0x10,%rdx
   2e6c3:	48 39 f2             	cmp    %rsi,%rdx
   2e6c6:	76 c8                	jbe    2e690 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x920>
   2e6c8:	eb 46                	jmp    2e710 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9a0>
   2e6ca:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e6d0:	45 31 ff             	xor    %r15d,%r15d
   2e6d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e6da:	84 00 00 00 00 00 
   2e6e0:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e6e5:	74 59                	je     2e740 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9d0>
   2e6e7:	49 ff c7             	inc    %r15
   2e6ea:	4c 39 fa             	cmp    %r15,%rdx
   2e6ed:	75 f1                	jne    2e6e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x970>
   2e6ef:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2e6f3:	48 39 f2             	cmp    %rsi,%rdx
   2e6f6:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e6fd:	5f 5f 5f 
   2e700:	0f 86 77 ff ff ff    	jbe    2e67d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x90d>
   2e706:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2e70d:	00 00 00 
   2e710:	49 89 d7             	mov    %rdx,%r15
   2e713:	48 39 d0             	cmp    %rdx,%rax
   2e716:	74 68                	je     2e780 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa10>
   2e718:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e71f:	00 
   2e720:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e725:	74 19                	je     2e740 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9d0>
   2e727:	49 ff c7             	inc    %r15
   2e72a:	4c 39 f8             	cmp    %r15,%rax
   2e72d:	75 f1                	jne    2e720 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9b0>
   2e72f:	eb 4f                	jmp    2e780 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa10>
   2e731:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e738:	0f 1f 84 00 00 00 00 
   2e73f:	00 
   2e740:	4b 8d 2c 27          	lea    (%r15,%r12,1),%rbp
   2e744:	48 ff c5             	inc    %rbp
   2e747:	4d 01 e7             	add    %r12,%r15
   2e74a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2e74f:	49 39 cf             	cmp    %rcx,%r15
   2e752:	0f 83 a8 fe ff ff    	jae    2e600 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x890>
   2e758:	48 8b 84 24 b0 00 00 	mov    0xb0(%rsp),%rax
   2e75f:	00 
   2e760:	42 80 3c 38 5f       	cmpb   $0x5f,(%rax,%r15,1)
   2e765:	0f 85 95 fe ff ff    	jne    2e600 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x890>
   2e76b:	c7 84 24 50 01 00 00 	movl   $0x0,0x150(%rsp)
   2e772:	00 00 00 00 
   2e776:	49 89 ec             	mov    %rbp,%r12
   2e779:	eb 10                	jmp    2e78b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa1b>
   2e77b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2e780:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2e785:	4d 89 fc             	mov    %r15,%r12
   2e788:	4c 89 f5             	mov    %r14,%rbp
   2e78b:	48 3b 5c 24 10       	cmp    0x10(%rsp),%rbx
   2e790:	0f 85 fa fd ff ff    	jne    2e590 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x820>
   2e796:	ba 01 00 00 00       	mov    $0x1,%edx
   2e79b:	b9 08 00 00 00       	mov    $0x8,%ecx
   2e7a0:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   2e7a6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2e7ab:	48 89 de             	mov    %rbx,%rsi
   2e7ae:	e8 ad de ff ff       	call   2c660 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e7b3:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e7b8:	48 89 84 24 18 01 00 	mov    %rax,0x118(%rsp)
   2e7bf:	00 
   2e7c0:	e9 cb fd ff ff       	jmp    2e590 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x820>
   2e7c5:	49 89 ec             	mov    %rbp,%r12
   2e7c8:	e9 12 fe ff ff       	jmp    2e5df <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x86f>
   2e7cd:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e7d2:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
   2e7d9:	00 
   2e7da:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e7df:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e7e4:	48 83 fb 03          	cmp    $0x3,%rbx
   2e7e8:	48 89 bc 24 18 01 00 	mov    %rdi,0x118(%rsp)
   2e7ef:	00 
   2e7f0:	0f 85 9d 33 00 00    	jne    31b93 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e23>
   2e7f6:	48 83 7f 08 03       	cmpq   $0x3,0x8(%rdi)
   2e7fb:	0f 85 0f 30 00 00    	jne    31810 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3aa0>
   2e801:	48 8b 07             	mov    (%rdi),%rax
   2e804:	0f b7 08             	movzwl (%rax),%ecx
   2e807:	81 f1 6d 61 00 00    	xor    $0x616d,%ecx
   2e80d:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   2e811:	83 f0 70             	xor    $0x70,%eax
   2e814:	66 09 c8             	or     %cx,%ax
   2e817:	0f 85 f3 2f 00 00    	jne    31810 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3aa0>
   2e81d:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2e821:	48 8b 77 18          	mov    0x18(%rdi),%rsi
   2e825:	48 83 fe 01          	cmp    $0x1,%rsi
   2e829:	74 0e                	je     2e839 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xac9>
   2e82b:	48 85 f6             	test   %rsi,%rsi
   2e82e:	0f 84 00 34 00 00    	je     31c34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ec4>
   2e834:	0f b6 11             	movzbl (%rcx),%edx
   2e837:	eb 17                	jmp    2e850 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xae0>
   2e839:	0f b6 11             	movzbl (%rcx),%edx
   2e83c:	b0 01                	mov    $0x1,%al
   2e83e:	83 fa 2b             	cmp    $0x2b,%edx
   2e841:	0f 84 ff 2e 00 00    	je     31746 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d6>
   2e847:	83 fa 2d             	cmp    $0x2d,%edx
   2e84a:	0f 84 f6 2e 00 00    	je     31746 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d6>
   2e850:	31 c0                	xor    %eax,%eax
   2e852:	80 fa 2b             	cmp    $0x2b,%dl
   2e855:	0f 94 c0             	sete   %al
   2e858:	48 89 f2             	mov    %rsi,%rdx
   2e85b:	48 29 c2             	sub    %rax,%rdx
   2e85e:	48 01 c1             	add    %rax,%rcx
   2e861:	48 f7 d8             	neg    %rax
   2e864:	48 83 fa 11          	cmp    $0x11,%rdx
   2e868:	73 3d                	jae    2e8a7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb37>
   2e86a:	48 85 d2             	test   %rdx,%rdx
   2e86d:	0f 84 c1 00 00 00    	je     2e934 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xbc4>
   2e873:	48 01 c6             	add    %rax,%rsi
   2e876:	48 f7 de             	neg    %rsi
   2e879:	45 31 e4             	xor    %r12d,%r12d
   2e87c:	31 c0                	xor    %eax,%eax
   2e87e:	66 90                	xchg   %ax,%ax
   2e880:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2e884:	83 c2 d0             	add    $0xffffffd0,%edx
   2e887:	83 fa 09             	cmp    $0x9,%edx
   2e88a:	0f 87 2c 31 00 00    	ja     319bc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c4c>
   2e890:	4b 8d 3c a4          	lea    (%r12,%r12,4),%rdi
   2e894:	89 d2                	mov    %edx,%edx
   2e896:	4c 8d 24 7a          	lea    (%rdx,%rdi,2),%r12
   2e89a:	48 ff c0             	inc    %rax
   2e89d:	48 89 f2             	mov    %rsi,%rdx
   2e8a0:	48 01 c2             	add    %rax,%rdx
   2e8a3:	75 db                	jne    2e880 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb10>
   2e8a5:	eb 4f                	jmp    2e8f6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb86>
   2e8a7:	48 01 c6             	add    %rax,%rsi
   2e8aa:	48 f7 de             	neg    %rsi
   2e8ad:	45 31 e4             	xor    %r12d,%r12d
   2e8b0:	bf 0a 00 00 00       	mov    $0xa,%edi
   2e8b5:	45 31 c0             	xor    %r8d,%r8d
   2e8b8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e8bf:	00 
   2e8c0:	4c 89 e0             	mov    %r12,%rax
   2e8c3:	48 f7 e7             	mul    %rdi
   2e8c6:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2e8cb:	0f 80 67 2e 00 00    	jo     31738 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39c8>
   2e8d1:	83 c2 d0             	add    $0xffffffd0,%edx
   2e8d4:	83 fa 0a             	cmp    $0xa,%edx
   2e8d7:	0f 83 df 30 00 00    	jae    319bc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c4c>
   2e8dd:	49 89 c4             	mov    %rax,%r12
   2e8e0:	89 d0                	mov    %edx,%eax
   2e8e2:	49 01 c4             	add    %rax,%r12
   2e8e5:	0f 82 59 2e 00 00    	jb     31744 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d4>
   2e8eb:	49 ff c0             	inc    %r8
   2e8ee:	48 89 f0             	mov    %rsi,%rax
   2e8f1:	4c 01 c0             	add    %r8,%rax
   2e8f4:	75 ca                	jne    2e8c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb50>
   2e8f6:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   2e8fd:	00 
   2e8fe:	48 8b 41 28          	mov    0x28(%rcx),%rax
   2e902:	48 83 f8 09          	cmp    $0x9,%rax
   2e906:	75 41                	jne    2e949 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xbd9>
   2e908:	48 8b 41 20          	mov    0x20(%rcx),%rax
   2e90c:	48 b9 64 75 70 6c 69 	movabs $0x746163696c707564,%rcx
   2e913:	63 61 74 
   2e916:	48 33 08             	xor    (%rax),%rcx
   2e919:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e91d:	48 83 f0 65          	xor    $0x65,%rax
   2e921:	48 09 c8             	or     %rcx,%rax
   2e924:	b0 01                	mov    $0x1,%al
   2e926:	89 84 24 94 01 00 00 	mov    %eax,0x194(%rsp)
   2e92d:	74 4e                	je     2e97d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc0d>
   2e92f:	e9 02 2f 00 00       	jmp    31836 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ac6>
   2e934:	45 31 e4             	xor    %r12d,%r12d
   2e937:	48 8b 8c 24 18 01 00 	mov    0x118(%rsp),%rcx
   2e93e:	00 
   2e93f:	48 8b 41 28          	mov    0x28(%rcx),%rax
   2e943:	48 83 f8 09          	cmp    $0x9,%rax
   2e947:	74 bf                	je     2e908 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb98>
   2e949:	48 83 f8 08          	cmp    $0x8,%rax
   2e94d:	0f 85 e3 2e 00 00    	jne    31836 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ac6>
   2e953:	48 8b 84 24 18 01 00 	mov    0x118(%rsp),%rax
   2e95a:	00 
   2e95b:	48 8b 40 20          	mov    0x20(%rax),%rax
   2e95f:	48 b9 64 69 73 74 69 	movabs $0x74636e6974736964,%rcx
   2e966:	6e 63 74 
   2e969:	48 39 08             	cmp    %rcx,(%rax)
   2e96c:	0f 85 c4 2e 00 00    	jne    31836 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ac6>
   2e972:	c7 84 24 94 01 00 00 	movl   $0x0,0x194(%rsp)
   2e979:	00 00 00 00 
   2e97d:	48 c7 84 24 20 01 00 	movq   $0x0,0x120(%rsp)
   2e984:	00 00 00 00 00 
   2e989:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2e990:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2e995:	0f 85 b9 2e 00 00    	jne    31854 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ae4>
   2e99b:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2e99f:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2e9a4:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2e9a8:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2e9ac:	0f 10 05 3d f6 03 00 	movups 0x3f63d(%rip),%xmm0        # 6dff0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2e9b3:	0f 29 84 24 c0 01 00 	movaps %xmm0,0x1c0(%rsp)
   2e9ba:	00 
   2e9bb:	f3 0f 6f 05 3d f6 03 	movdqu 0x3f63d(%rip),%xmm0        # 6e000 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2e9c2:	00 
   2e9c3:	66 0f 7f 84 24 d0 01 	movdqa %xmm0,0x1d0(%rsp)
   2e9ca:	00 00 
   2e9cc:	48 89 84 24 e0 01 00 	mov    %rax,0x1e0(%rsp)
   2e9d3:	00 
   2e9d4:	48 89 94 24 e8 01 00 	mov    %rdx,0x1e8(%rsp)
   2e9db:	00 
   2e9dc:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
   2e9e3:	00 00 00 00 00 
   2e9e8:	48 c7 84 24 00 02 00 	movq   $0x0,0x200(%rsp)
   2e9ef:	00 00 00 00 00 
   2e9f4:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
   2e9fb:	00 00 00 00 00 
   2ea00:	48 c7 84 24 78 01 00 	movq   $0x1,0x178(%rsp)
   2ea07:	00 01 00 00 00 
   2ea0c:	48 c7 84 24 80 01 00 	movq   $0x0,0x180(%rsp)
   2ea13:	00 00 00 00 00 
   2ea18:	4d 85 e4             	test   %r12,%r12
   2ea1b:	4c 89 a4 24 88 01 00 	mov    %r12,0x188(%rsp)
   2ea22:	00 
   2ea23:	0f 84 1f 0f 00 00    	je     2f948 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1bd8>
   2ea29:	49 8d 5c 24 03       	lea    0x3(%r12),%rbx
   2ea2e:	48 c1 eb 02          	shr    $0x2,%rbx
   2ea32:	31 d2                	xor    %edx,%edx
   2ea34:	45 31 f6             	xor    %r14d,%r14d
   2ea37:	45 31 ed             	xor    %r13d,%r13d
   2ea3a:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
   2ea41:	00 00 00 00 00 
   2ea46:	48 89 9c 24 c8 00 00 	mov    %rbx,0xc8(%rsp)
   2ea4d:	00 
   2ea4e:	66 90                	xchg   %ax,%ax
   2ea50:	48 8d 42 01          	lea    0x1(%rdx),%rax
   2ea54:	48 39 d8             	cmp    %rbx,%rax
   2ea57:	b9 00 00 00 00       	mov    $0x0,%ecx
   2ea5c:	48 0f 45 c8          	cmovne %rax,%rcx
   2ea60:	48 89 8c 24 60 02 00 	mov    %rcx,0x260(%rsp)
   2ea67:	00 
   2ea68:	80 bc 24 94 01 00 00 	cmpb   $0x0,0x194(%rsp)
   2ea6f:	00 
   2ea70:	74 3e                	je     2eab0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd40>
   2ea72:	48 85 db             	test   %rbx,%rbx
   2ea75:	0f 84 cb 2f 00 00    	je     31a46 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3cd6>
   2ea7b:	4c 89 f0             	mov    %r14,%rax
   2ea7e:	48 09 d8             	or     %rbx,%rax
   2ea81:	48 c1 e8 20          	shr    $0x20,%rax
   2ea85:	74 71                	je     2eaf8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd88>
   2ea87:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2ea8c:	4c 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15
   2ea93:	00 
   2ea94:	4d 85 ff             	test   %r15,%r15
   2ea97:	0f 84 83 00 00 00    	je     2eb20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xdb0>
   2ea9d:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2eaa1:	49 3b 1f             	cmp    (%r15),%rbx
   2eaa4:	0f 85 f6 00 00 00    	jne    2eba0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe30>
   2eaaa:	e9 e8 00 00 00       	jmp    2eb97 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe27>
   2eaaf:	90                   	nop
   2eab0:	4c 89 f0             	mov    %r14,%rax
   2eab3:	48 c1 e0 04          	shl    $0x4,%rax
   2eab7:	4c 01 f0             	add    %r14,%rax
   2eaba:	48 89 c1             	mov    %rax,%rcx
   2eabd:	4c 09 e1             	or     %r12,%rcx
   2eac0:	48 c1 e9 20          	shr    $0x20,%rcx
   2eac4:	74 19                	je     2eadf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd6f>
   2eac6:	31 d2                	xor    %edx,%edx
   2eac8:	49 f7 f4             	div    %r12
   2eacb:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2ead0:	4c 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15
   2ead7:	00 
   2ead8:	4d 85 ff             	test   %r15,%r15
   2eadb:	75 c0                	jne    2ea9d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd2d>
   2eadd:	eb 41                	jmp    2eb20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xdb0>
   2eadf:	31 d2                	xor    %edx,%edx
   2eae1:	41 f7 f4             	div    %r12d
   2eae4:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2eae9:	4c 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15
   2eaf0:	00 
   2eaf1:	4d 85 ff             	test   %r15,%r15
   2eaf4:	75 a7                	jne    2ea9d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd2d>
   2eaf6:	eb 28                	jmp    2eb20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xdb0>
   2eaf8:	44 89 f0             	mov    %r14d,%eax
   2eafb:	31 d2                	xor    %edx,%edx
   2eafd:	f7 f3                	div    %ebx
   2eaff:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2eb04:	4c 8b bc 24 20 01 00 	mov    0x120(%rsp),%r15
   2eb0b:	00 
   2eb0c:	4d 85 ff             	test   %r15,%r15
   2eb0f:	75 8c                	jne    2ea9d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd2d>
   2eb11:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2eb18:	0f 1f 84 00 00 00 00 
   2eb1f:	00 
   2eb20:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2eb27:	00 00 
   2eb29:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   2eb30:	00 00 
   2eb32:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2eb39:	00 00 
   2eb3b:	c7 44 24 40 03 00 00 	movl   $0x3,0x40(%rsp)
   2eb42:	00 
   2eb43:	bf 38 00 00 00       	mov    $0x38,%edi
   2eb48:	ff 15 42 10 04 00    	call   *0x41042(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2eb4e:	48 85 c0             	test   %rax,%rax
   2eb51:	0f 84 68 2c 00 00    	je     317bf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a4f>
   2eb57:	49 89 c7             	mov    %rax,%r15
   2eb5a:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   2eb5f:	49 89 47 30          	mov    %rax,0x30(%r15)
   2eb63:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   2eb69:	66 0f 10 4c 24 20    	movupd 0x20(%rsp),%xmm1
   2eb6f:	f3 0f 6f 54 24 30    	movdqu 0x30(%rsp),%xmm2
   2eb75:	f3 41 0f 7f 57 20    	movdqu %xmm2,0x20(%r15)
   2eb7b:	66 41 0f 11 4f 10    	movupd %xmm1,0x10(%r15)
   2eb81:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   2eb86:	4c 89 bc 24 20 01 00 	mov    %r15,0x120(%rsp)
   2eb8d:	00 
   2eb8e:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2eb92:	49 3b 1f             	cmp    (%r15),%rbx
   2eb95:	75 09                	jne    2eba0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe30>
   2eb97:	4c 89 ff             	mov    %r15,%rdi
   2eb9a:	ff 15 f0 13 04 00    	call   *0x413f0(%rip)        # 6ff90 <_DYNAMIC+0x5e8>
   2eba0:	42 8d 14 f5 00 00 00 	lea    0x0(,%r14,8),%edx
   2eba7:	00 
   2eba8:	44 29 f2             	sub    %r14d,%edx
   2ebab:	83 c2 03             	add    $0x3,%edx
   2ebae:	49 8b 47 08          	mov    0x8(%r15),%rax
   2ebb2:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2ebb7:	89 0c d8             	mov    %ecx,(%rax,%rbx,8)
   2ebba:	89 94 24 b0 00 00 00 	mov    %edx,0xb0(%rsp)
   2ebc1:	89 54 d8 04          	mov    %edx,0x4(%rax,%rbx,8)
   2ebc5:	48 ff c3             	inc    %rbx
   2ebc8:	49 89 5f 10          	mov    %rbx,0x10(%r15)
   2ebcc:	41 8b 47 30          	mov    0x30(%r15),%eax
   2ebd0:	8d 48 fe             	lea    -0x2(%rax),%ecx
   2ebd3:	83 f9 02             	cmp    $0x2,%ecx
   2ebd6:	72 19                	jb     2ebf1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe81>
   2ebd8:	85 c0                	test   %eax,%eax
   2ebda:	0f 85 f4 2b 00 00    	jne    317d4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a64>
   2ebe0:	49 83 7f 18 00       	cmpq   $0x0,0x18(%r15)
   2ebe5:	74 0a                	je     2ebf1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe81>
   2ebe7:	49 8b 7f 20          	mov    0x20(%r15),%rdi
   2ebeb:	ff 15 af 0f 04 00    	call   *0x40faf(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   2ebf1:	41 c7 47 30 03 00 00 	movl   $0x3,0x30(%r15)
   2ebf8:	00 
   2ebf9:	4c 8b bc 24 e0 01 00 	mov    0x1e0(%rsp),%r15
   2ec00:	00 
   2ec01:	48 8b ac 24 e8 01 00 	mov    0x1e8(%rsp),%rbp
   2ec08:	00 
   2ec09:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   2ec10:	00 00 
   2ec12:	0f 84 8a 0c 00 00    	je     2f8a2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b32>
   2ec18:	49 ff c6             	inc    %r14
   2ec1b:	4c 89 f9             	mov    %r15,%rcx
   2ec1e:	48 b8 75 65 73 70 65 	movabs $0x736f6d6570736575,%rax
   2ec25:	6d 6f 73 
   2ec28:	48 31 c1             	xor    %rax,%rcx
   2ec2b:	48 b8 61 72 65 6e 65 	movabs $0x6c7967656e657261,%rax
   2ec32:	67 79 6c 
   2ec35:	49 31 c7             	xor    %rax,%r15
   2ec38:	4c 8b 44 24 08       	mov    0x8(%rsp),%r8
   2ec3d:	44 89 c0             	mov    %r8d,%eax
   2ec40:	48 ba 00 00 00 00 00 	movabs $0x400000000000000,%rdx
   2ec47:	00 00 04 
   2ec4a:	48 01 c2             	add    %rax,%rdx
   2ec4d:	48 be 73 65 74 79 62 	movabs $0x7065646279746573,%rsi
   2ec54:	64 65 70 
   2ec57:	48 31 f0             	xor    %rsi,%rax
   2ec5a:	48 31 e8             	xor    %rbp,%rax
   2ec5d:	48 be 6d 6f 64 6e 61 	movabs $0x646f72616e646f6d,%rsi
   2ec64:	72 6f 64 
   2ec67:	48 31 f5             	xor    %rsi,%rbp
   2ec6a:	48 01 e9             	add    %rbp,%rcx
   2ec6d:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ec71:	49 01 c7             	add    %rax,%r15
   2ec74:	48 31 cd             	xor    %rcx,%rbp
   2ec77:	48 c1 c0 10          	rol    $0x10,%rax
   2ec7b:	4c 31 f8             	xor    %r15,%rax
   2ec7e:	48 c1 c1 20          	rol    $0x20,%rcx
   2ec82:	49 01 ef             	add    %rbp,%r15
   2ec85:	48 01 c1             	add    %rax,%rcx
   2ec88:	48 c1 c5 11          	rol    $0x11,%rbp
   2ec8c:	4c 31 fd             	xor    %r15,%rbp
   2ec8f:	48 c1 c0 15          	rol    $0x15,%rax
   2ec93:	49 c1 c7 20          	rol    $0x20,%r15
   2ec97:	48 31 c8             	xor    %rcx,%rax
   2ec9a:	48 31 d1             	xor    %rdx,%rcx
   2ec9d:	49 81 f7 ff 00 00 00 	xor    $0xff,%r15
   2eca4:	48 01 e9             	add    %rbp,%rcx
   2eca7:	49 01 c7             	add    %rax,%r15
   2ecaa:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ecae:	48 31 cd             	xor    %rcx,%rbp
   2ecb1:	48 c1 c0 10          	rol    $0x10,%rax
   2ecb5:	48 c1 c1 20          	rol    $0x20,%rcx
   2ecb9:	4c 31 f8             	xor    %r15,%rax
   2ecbc:	49 01 ef             	add    %rbp,%r15
   2ecbf:	48 c1 c5 11          	rol    $0x11,%rbp
   2ecc3:	48 01 c1             	add    %rax,%rcx
   2ecc6:	4c 31 fd             	xor    %r15,%rbp
   2ecc9:	48 c1 c0 15          	rol    $0x15,%rax
   2eccd:	48 31 c8             	xor    %rcx,%rax
   2ecd0:	49 c1 c7 20          	rol    $0x20,%r15
   2ecd4:	48 01 e9             	add    %rbp,%rcx
   2ecd7:	49 01 c7             	add    %rax,%r15
   2ecda:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ecde:	48 31 cd             	xor    %rcx,%rbp
   2ece1:	48 c1 c0 10          	rol    $0x10,%rax
   2ece5:	48 c1 c1 20          	rol    $0x20,%rcx
   2ece9:	4c 31 f8             	xor    %r15,%rax
   2ecec:	49 01 ef             	add    %rbp,%r15
   2ecef:	48 c1 c5 11          	rol    $0x11,%rbp
   2ecf3:	48 01 c1             	add    %rax,%rcx
   2ecf6:	4c 31 fd             	xor    %r15,%rbp
   2ecf9:	48 c1 c0 15          	rol    $0x15,%rax
   2ecfd:	48 31 c8             	xor    %rcx,%rax
   2ed00:	49 c1 c7 20          	rol    $0x20,%r15
   2ed04:	48 01 e9             	add    %rbp,%rcx
   2ed07:	49 01 c7             	add    %rax,%r15
   2ed0a:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ed0e:	48 31 cd             	xor    %rcx,%rbp
   2ed11:	48 c1 c0 10          	rol    $0x10,%rax
   2ed15:	4c 31 f8             	xor    %r15,%rax
   2ed18:	49 01 ef             	add    %rbp,%r15
   2ed1b:	48 c1 c5 11          	rol    $0x11,%rbp
   2ed1f:	48 c1 c0 15          	rol    $0x15,%rax
   2ed23:	48 31 e8             	xor    %rbp,%rax
   2ed26:	4c 89 ff             	mov    %r15,%rdi
   2ed29:	48 c1 c7 20          	rol    $0x20,%rdi
   2ed2d:	48 31 c7             	xor    %rax,%rdi
   2ed30:	4c 31 ff             	xor    %r15,%rdi
   2ed33:	4d 89 c7             	mov    %r8,%r15
   2ed36:	48 8b 84 24 c0 01 00 	mov    0x1c0(%rsp),%rax
   2ed3d:	00 
   2ed3e:	48 8b 94 24 c8 01 00 	mov    0x1c8(%rsp),%rdx
   2ed45:	00 
   2ed46:	48 89 f9             	mov    %rdi,%rcx
   2ed49:	48 c1 e9 39          	shr    $0x39,%rcx
   2ed4d:	66 0f 6e c1          	movd   %ecx,%xmm0
   2ed51:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
   2ed55:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
   2ed5a:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
   2ed5f:	45 31 c9             	xor    %r9d,%r9d
   2ed62:	45 31 c0             	xor    %r8d,%r8d
   2ed65:	4c 89 b4 24 50 01 00 	mov    %r14,0x150(%rsp)
   2ed6c:	00 
   2ed6d:	48 21 d7             	and    %rdx,%rdi
   2ed70:	f3 0f 6f 0c 38       	movdqu (%rax,%rdi,1),%xmm1
   2ed75:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   2ed79:	66 0f 74 d0          	pcmpeqb %xmm0,%xmm2
   2ed7d:	66 44 0f d7 d2       	pmovmskb %xmm2,%r10d
   2ed82:	45 85 d2             	test   %r10d,%r10d
   2ed85:	74 39                	je     2edc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1050>
   2ed87:	f3 45 0f bc da       	tzcnt  %r10d,%r11d
   2ed8c:	49 01 fb             	add    %rdi,%r11
   2ed8f:	49 21 d3             	and    %rdx,%r11
   2ed92:	4a 8d 1c dd 00 00 00 	lea    0x0(,%r11,8),%rbx
   2ed99:	00 
   2ed9a:	49 89 c6             	mov    %rax,%r14
   2ed9d:	49 29 de             	sub    %rbx,%r14
   2eda0:	45 39 7e f8          	cmp    %r15d,-0x8(%r14)
   2eda4:	74 6a                	je     2ee10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x10a0>
   2eda6:	45 8d 5a ff          	lea    -0x1(%r10),%r11d
   2edaa:	66 45 21 d3          	and    %r10w,%r11w
   2edae:	45 89 da             	mov    %r11d,%r10d
   2edb1:	75 d4                	jne    2ed87 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1017>
   2edb3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2edba:	84 00 00 00 00 00 
   2edc0:	49 83 f9 01          	cmp    $0x1,%r9
   2edc4:	74 12                	je     2edd8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1068>
   2edc6:	66 0f d7 f1          	pmovmskb %xmm1,%esi
   2edca:	85 f6                	test   %esi,%esi
   2edcc:	74 28                	je     2edf6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1086>
   2edce:	f3 0f bc f6          	tzcnt  %esi,%esi
   2edd2:	48 01 fe             	add    %rdi,%rsi
   2edd5:	48 21 d6             	and    %rdx,%rsi
   2edd8:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   2eddc:	66 0f 74 ca          	pcmpeqb %xmm2,%xmm1
   2ede0:	66 44 0f d7 c9       	pmovmskb %xmm1,%r9d
   2ede5:	45 85 c9             	test   %r9d,%r9d
   2ede8:	0f 85 e2 00 00 00    	jne    2eed0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1160>
   2edee:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   2edf4:	eb 03                	jmp    2edf9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1089>
   2edf6:	45 31 c9             	xor    %r9d,%r9d
   2edf9:	4c 01 c7             	add    %r8,%rdi
   2edfc:	48 83 c7 10          	add    $0x10,%rdi
   2ee00:	49 83 c0 10          	add    $0x10,%r8
   2ee04:	e9 64 ff ff ff       	jmp    2ed6d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xffd>
   2ee09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2ee10:	49 f7 db             	neg    %r11
   2ee13:	8b 8c 24 b0 00 00 00 	mov    0xb0(%rsp),%ecx
   2ee1a:	42 89 4c d8 fc       	mov    %ecx,-0x4(%rax,%r11,8)
   2ee1f:	4d 85 ed             	test   %r13,%r13
   2ee22:	0f 84 16 01 00 00    	je     2ef3e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11ce>
   2ee28:	48 8b 84 24 c0 00 00 	mov    0xc0(%rsp),%rax
   2ee2f:	00 
   2ee30:	4c 89 eb             	mov    %r13,%rbx
   2ee33:	44 0f b7 73 62       	movzwl 0x62(%rbx),%r14d
   2ee38:	4c 89 f5             	mov    %r14,%rbp
   2ee3b:	45 85 f6             	test   %r14d,%r14d
   2ee3e:	74 47                	je     2ee87 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1117>
   2ee40:	44 89 f1             	mov    %r14d,%ecx
   2ee43:	c1 e1 02             	shl    $0x2,%ecx
   2ee46:	31 ed                	xor    %ebp,%ebp
   2ee48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ee4f:	00 
   2ee50:	44 3b 7c ab 08       	cmp    0x8(%rbx,%rbp,4),%r15d
   2ee55:	40 0f 9c c6          	setl   %sil
   2ee59:	0f 9f c2             	setg   %dl
   2ee5c:	40 28 f2             	sub    %sil,%dl
   2ee5f:	80 fa 01             	cmp    $0x1,%dl
   2ee62:	75 1c                	jne    2ee80 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1110>
   2ee64:	48 ff c5             	inc    %rbp
   2ee67:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
   2ee6b:	75 e3                	jne    2ee50 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x10e0>
   2ee6d:	4c 89 f5             	mov    %r14,%rbp
   2ee70:	eb 15                	jmp    2ee87 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1117>
   2ee72:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ee79:	1f 84 00 00 00 00 00 
   2ee80:	0f b6 ca             	movzbl %dl,%ecx
   2ee83:	85 c9                	test   %ecx,%ecx
   2ee85:	74 29                	je     2eeb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1140>
   2ee87:	48 83 e8 01          	sub    $0x1,%rax
   2ee8b:	0f 82 af 01 00 00    	jb     2f040 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x12d0>
   2ee91:	48 8b 5c eb 68       	mov    0x68(%rbx,%rbp,8),%rbx
   2ee96:	44 0f b7 73 62       	movzwl 0x62(%rbx),%r14d
   2ee9b:	4c 89 f5             	mov    %r14,%rbp
   2ee9e:	45 85 f6             	test   %r14d,%r14d
   2eea1:	75 9d                	jne    2ee40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x10d0>
   2eea3:	eb e2                	jmp    2ee87 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1117>
   2eea5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2eeac:	00 00 00 00 
   2eeb0:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
   2eeb7:	89 44 ab 34          	mov    %eax,0x34(%rbx,%rbp,4)
   2eebb:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2eec2:	00 
   2eec3:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2eeca:	00 
   2eecb:	e9 ff 00 00 00       	jmp    2efcf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x125f>
   2eed0:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
   2eed4:	40 84 ff             	test   %dil,%dil
   2eed7:	0f 89 56 0a 00 00    	jns    2f933 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1bc3>
   2eedd:	40 80 e7 01          	and    $0x1,%dil
   2eee1:	4c 8d 46 f0          	lea    -0x10(%rsi),%r8
   2eee5:	49 21 d0             	and    %rdx,%r8
   2eee8:	88 0c 30             	mov    %cl,(%rax,%rsi,1)
   2eeeb:	42 88 4c 00 10       	mov    %cl,0x10(%rax,%r8,1)
   2eef0:	66 0f 6f 84 24 d0 01 	movdqa 0x1d0(%rsp),%xmm0
   2eef7:	00 00 
   2eef9:	40 0f b6 cf          	movzbl %dil,%ecx
   2eefd:	66 0f 6e c9          	movd   %ecx,%xmm1
   2ef01:	66 0f c6 0d 46 84 fd 	shufpd $0x2,-0x27bba(%rip),%xmm1        # 7350 <anon.d74135bdccc798679365a46b1d65ca28.138.llvm.4795996092214488023+0xdd>
   2ef08:	ff 02 
   2ef0a:	66 0f fb c1          	psubq  %xmm1,%xmm0
   2ef0e:	66 0f 7f 84 24 d0 01 	movdqa %xmm0,0x1d0(%rsp)
   2ef15:	00 00 
   2ef17:	49 89 f3             	mov    %rsi,%r11
   2ef1a:	49 f7 db             	neg    %r11
   2ef1d:	48 c1 e6 03          	shl    $0x3,%rsi
   2ef21:	48 f7 de             	neg    %rsi
   2ef24:	44 89 7c 30 f8       	mov    %r15d,-0x8(%rax,%rsi,1)
   2ef29:	8b 8c 24 b0 00 00 00 	mov    0xb0(%rsp),%ecx
   2ef30:	42 89 4c d8 fc       	mov    %ecx,-0x4(%rax,%r11,8)
   2ef35:	4d 85 ed             	test   %r13,%r13
   2ef38:	0f 85 ea fe ff ff    	jne    2ee28 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x10b8>
   2ef3e:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2ef44:	bf 68 00 00 00       	mov    $0x68,%edi
   2ef49:	ff 15 41 0c 04 00    	call   *0x40c41(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2ef4f:	48 85 c0             	test   %rax,%rax
   2ef52:	0f 84 1c 28 00 00    	je     31774 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a04>
   2ef58:	49 89 c5             	mov    %rax,%r13
   2ef5b:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2ef62:	48 89 84 24 f0 01 00 	mov    %rax,0x1f0(%rsp)
   2ef69:	00 
   2ef6a:	48 c7 84 24 f8 01 00 	movq   $0x0,0x1f8(%rsp)
   2ef71:	00 00 00 00 00 
   2ef76:	66 c7 40 62 01 00    	movw   $0x1,0x62(%rax)
   2ef7c:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2ef81:	44 89 78 08          	mov    %r15d,0x8(%rax)
   2ef85:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
   2ef8c:	41 89 45 34          	mov    %eax,0x34(%r13)
   2ef90:	48 c7 84 24 c0 00 00 	movq   $0x0,0xc0(%rsp)
   2ef97:	00 00 00 00 00 
   2ef9c:	4c 8b a4 24 88 01 00 	mov    0x188(%rsp),%r12
   2efa3:	00 
   2efa4:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2efab:	00 
   2efac:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2efb3:	00 
   2efb4:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
   2efbb:	00 
   2efbc:	48 ff c1             	inc    %rcx
   2efbf:	48 89 8c 24 68 01 00 	mov    %rcx,0x168(%rsp)
   2efc6:	00 
   2efc7:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
   2efce:	00 
   2efcf:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
   2efd6:	00 
   2efd7:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   2efde:	00 
   2efdf:	48 89 c1             	mov    %rax,%rcx
   2efe2:	48 29 f1             	sub    %rsi,%rcx
   2efe5:	48 83 f9 03          	cmp    $0x3,%rcx
   2efe9:	0f 86 cb 08 00 00    	jbe    2f8ba <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b4a>
   2efef:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
   2eff6:	00 
   2eff7:	44 89 3c 31          	mov    %r15d,(%rcx,%rsi,1)
   2effb:	48 83 c6 04          	add    $0x4,%rsi
   2efff:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
   2f006:	00 
   2f007:	48 29 f0             	sub    %rsi,%rax
   2f00a:	48 83 f8 03          	cmp    $0x3,%rax
   2f00e:	0f 86 e5 08 00 00    	jbe    2f8f9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b89>
   2f014:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
   2f01b:	89 04 31             	mov    %eax,(%rcx,%rsi,1)
   2f01e:	48 83 c6 04          	add    $0x4,%rsi
   2f022:	48 89 b4 24 80 01 00 	mov    %rsi,0x180(%rsp)
   2f029:	00 
   2f02a:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
   2f031:	00 
   2f032:	4d 39 e6             	cmp    %r12,%r14
   2f035:	0f 85 15 fa ff ff    	jne    2ea50 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xce0>
   2f03b:	e9 17 09 00 00       	jmp    2f957 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1be7>
   2f040:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f044:	66 41 83 fe 0b       	cmp    $0xb,%r14w
   2f049:	73 5f                	jae    2f0aa <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x133a>
   2f04b:	49 39 ee             	cmp    %rbp,%r14
   2f04e:	76 3d                	jbe    2f08d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x131d>
   2f050:	48 8d 34 a8          	lea    (%rax,%rbp,4),%rsi
   2f054:	48 8d 3c a8          	lea    (%rax,%rbp,4),%rdi
   2f058:	48 83 c7 04          	add    $0x4,%rdi
   2f05c:	45 89 f7             	mov    %r14d,%r15d
   2f05f:	41 29 ef             	sub    %ebp,%r15d
   2f062:	41 c1 e7 02          	shl    $0x2,%r15d
   2f066:	4c 89 fa             	mov    %r15,%rdx
   2f069:	ff 15 11 0c 04 00    	call   *0x40c11(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f06f:	48 8d 34 ab          	lea    (%rbx,%rbp,4),%rsi
   2f073:	48 83 c6 34          	add    $0x34,%rsi
   2f077:	48 8d 3c ab          	lea    (%rbx,%rbp,4),%rdi
   2f07b:	48 83 c7 38          	add    $0x38,%rdi
   2f07f:	4c 89 fa             	mov    %r15,%rdx
   2f082:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2f087:	ff 15 f3 0b 04 00    	call   *0x40bf3(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f08d:	44 89 7c ab 08       	mov    %r15d,0x8(%rbx,%rbp,4)
   2f092:	41 8d 46 01          	lea    0x1(%r14),%eax
   2f096:	8b 8c 24 b0 00 00 00 	mov    0xb0(%rsp),%ecx
   2f09d:	89 4c ab 34          	mov    %ecx,0x34(%rbx,%rbp,4)
   2f0a1:	66 89 43 62          	mov    %ax,0x62(%rbx)
   2f0a5:	e9 fa fe ff ff       	jmp    2efa4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1234>
   2f0aa:	48 83 fd 05          	cmp    $0x5,%rbp
   2f0ae:	73 10                	jae    2f0c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1350>
   2f0b0:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2f0b6:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   2f0bd:	00 
   2f0be:	eb 35                	jmp    2f0f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1385>
   2f0c0:	74 16                	je     2f0d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1368>
   2f0c2:	48 83 fd 06          	cmp    $0x6,%rbp
   2f0c6:	75 1d                	jne    2f0e5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1375>
   2f0c8:	41 be 05 00 00 00    	mov    $0x5,%r14d
   2f0ce:	b0 01                	mov    $0x1,%al
   2f0d0:	89 44 24 50          	mov    %eax,0x50(%rsp)
   2f0d4:	31 ed                	xor    %ebp,%ebp
   2f0d6:	eb 1d                	jmp    2f0f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1385>
   2f0d8:	c7 44 24 50 00 00 00 	movl   $0x0,0x50(%rsp)
   2f0df:	00 
   2f0e0:	49 89 ee             	mov    %rbp,%r14
   2f0e3:	eb 10                	jmp    2f0f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1385>
   2f0e5:	48 83 c5 f9          	add    $0xfffffffffffffff9,%rbp
   2f0e9:	41 be 06 00 00 00    	mov    $0x6,%r14d
   2f0ef:	b0 01                	mov    $0x1,%al
   2f0f1:	89 44 24 50          	mov    %eax,0x50(%rsp)
   2f0f5:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2f0fb:	bf 68 00 00 00       	mov    $0x68,%edi
   2f100:	ff 15 8a 0a 04 00    	call   *0x40a8a(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2f106:	48 85 c0             	test   %rax,%rax
   2f109:	0f 84 65 26 00 00    	je     31774 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a04>
   2f10f:	49 89 c7             	mov    %rax,%r15
   2f112:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f119:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f11d:	4d 89 f4             	mov    %r14,%r12
   2f120:	49 f7 d4             	not    %r12
   2f123:	49 01 c4             	add    %rax,%r12
   2f126:	66 45 89 67 62       	mov    %r12w,0x62(%r15)
   2f12b:	49 83 fc 0c          	cmp    $0xc,%r12
   2f12f:	0f 83 e5 26 00 00    	jae    3181a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3aaa>
   2f135:	42 8b 44 b3 08       	mov    0x8(%rbx,%r14,4),%eax
   2f13a:	89 84 24 4c 01 00 00 	mov    %eax,0x14c(%rsp)
   2f141:	42 8b 44 b3 34       	mov    0x34(%rbx,%r14,4),%eax
   2f146:	89 84 24 48 01 00 00 	mov    %eax,0x148(%rsp)
   2f14d:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f151:	4a 8d 34 b0          	lea    (%rax,%r14,4),%rsi
   2f155:	48 83 c6 04          	add    $0x4,%rsi
   2f159:	49 8d 7f 08          	lea    0x8(%r15),%rdi
   2f15d:	49 c1 e4 02          	shl    $0x2,%r12
   2f161:	4c 89 e2             	mov    %r12,%rdx
   2f164:	ff 15 46 0a 04 00    	call   *0x40a46(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   2f16a:	4a 8d 34 b3          	lea    (%rbx,%r14,4),%rsi
   2f16e:	48 83 c6 38          	add    $0x38,%rsi
   2f172:	49 8d 7f 34          	lea    0x34(%r15),%rdi
   2f176:	4c 89 e2             	mov    %r12,%rdx
   2f179:	ff 15 31 0a 04 00    	call   *0x40a31(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   2f17f:	66 44 89 73 62       	mov    %r14w,0x62(%rbx)
   2f184:	80 7c 24 50 00       	cmpb   $0x0,0x50(%rsp)
   2f189:	4d 89 fe             	mov    %r15,%r14
   2f18c:	4c 0f 44 f3          	cmove  %rbx,%r14
   2f190:	45 0f b7 66 62       	movzwl 0x62(%r14),%r12d
   2f195:	49 39 ec             	cmp    %rbp,%r12
   2f198:	76 3e                	jbe    2f1d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1468>
   2f19a:	49 8d 46 08          	lea    0x8(%r14),%rax
   2f19e:	48 8d 34 a8          	lea    (%rax,%rbp,4),%rsi
   2f1a2:	48 8d 3c a8          	lea    (%rax,%rbp,4),%rdi
   2f1a6:	48 83 c7 04          	add    $0x4,%rdi
   2f1aa:	44 89 e2             	mov    %r12d,%edx
   2f1ad:	29 ea                	sub    %ebp,%edx
   2f1af:	c1 e2 02             	shl    $0x2,%edx
   2f1b2:	48 89 54 24 50       	mov    %rdx,0x50(%rsp)
   2f1b7:	ff 15 c3 0a 04 00    	call   *0x40ac3(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f1bd:	49 8d 34 ae          	lea    (%r14,%rbp,4),%rsi
   2f1c1:	48 83 c6 34          	add    $0x34,%rsi
   2f1c5:	49 8d 3c ae          	lea    (%r14,%rbp,4),%rdi
   2f1c9:	48 83 c7 38          	add    $0x38,%rdi
   2f1cd:	48 8b 54 24 50       	mov    0x50(%rsp),%rdx
   2f1d2:	ff 15 a8 0a 04 00    	call   *0x40aa8(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f1d8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2f1dd:	41 89 44 ae 08       	mov    %eax,0x8(%r14,%rbp,4)
   2f1e2:	41 ff c4             	inc    %r12d
   2f1e5:	8b 84 24 b0 00 00 00 	mov    0xb0(%rsp),%eax
   2f1ec:	41 89 44 ae 34       	mov    %eax,0x34(%r14,%rbp,4)
   2f1f1:	66 45 89 66 62       	mov    %r12w,0x62(%r14)
   2f1f6:	48 8b 03             	mov    (%rbx),%rax
   2f1f9:	31 ed                	xor    %ebp,%ebp
   2f1fb:	48 85 c0             	test   %rax,%rax
   2f1fe:	0f 84 4a 04 00 00    	je     2f64e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x18de>
   2f204:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2f20b:	00 
   2f20c:	eb 21                	jmp    2f22f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x14bf>
   2f20e:	66 90                	xchg   %ax,%ax
   2f210:	48 8b ac 24 50 02 00 	mov    0x250(%rsp),%rbp
   2f217:	00 
   2f218:	48 ff c5             	inc    %rbp
   2f21b:	48 8b 03             	mov    (%rbx),%rax
   2f21e:	48 85 c0             	test   %rax,%rax
   2f221:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2f228:	00 
   2f229:	0f 84 27 04 00 00    	je     2f656 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x18e6>
   2f22f:	8b 8c 24 48 01 00 00 	mov    0x148(%rsp),%ecx
   2f236:	8b b4 24 4c 01 00 00 	mov    0x14c(%rsp),%esi
   2f23d:	44 0f b7 4b 60       	movzwl 0x60(%rbx),%r9d
   2f242:	48 89 c3             	mov    %rax,%rbx
   2f245:	44 0f b7 50 62       	movzwl 0x62(%rax),%r10d
   2f24a:	49 83 fa 0b          	cmp    $0xb,%r10
   2f24e:	4c 89 bc 24 18 02 00 	mov    %r15,0x218(%rsp)
   2f255:	00 
   2f256:	89 8c 24 44 01 00 00 	mov    %ecx,0x144(%rsp)
   2f25d:	89 b4 24 40 01 00 00 	mov    %esi,0x140(%rsp)
   2f264:	4c 89 94 24 b8 01 00 	mov    %r10,0x1b8(%rsp)
   2f26b:	00 
   2f26c:	0f 82 98 04 00 00    	jb     2f70a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x199a>
   2f272:	66 41 83 f9 05       	cmp    $0x5,%r9w
   2f277:	48 89 ac 24 50 02 00 	mov    %rbp,0x250(%rsp)
   2f27e:	00 
   2f27f:	73 1f                	jae    2f2a0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1530>
   2f281:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   2f286:	b8 04 00 00 00       	mov    $0x4,%eax
   2f28b:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   2f292:	00 
   2f293:	45 31 f6             	xor    %r14d,%r14d
   2f296:	eb 68                	jmp    2f300 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1590>
   2f298:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f29f:	00 
   2f2a0:	49 83 f9 05          	cmp    $0x5,%r9
   2f2a4:	74 21                	je     2f2c7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1557>
   2f2a6:	41 83 f9 06          	cmp    $0x6,%r9d
   2f2aa:	75 2d                	jne    2f2d9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1569>
   2f2ac:	41 b6 01             	mov    $0x1,%r14b
   2f2af:	b8 05 00 00 00       	mov    $0x5,%eax
   2f2b4:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   2f2bb:	00 
   2f2bc:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   2f2c3:	00 00 
   2f2c5:	eb 39                	jmp    2f300 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1590>
   2f2c7:	45 31 f6             	xor    %r14d,%r14d
   2f2ca:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   2f2cf:	4c 89 8c 24 10 01 00 	mov    %r9,0x110(%rsp)
   2f2d6:	00 
   2f2d7:	eb 27                	jmp    2f300 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1590>
   2f2d9:	49 83 c1 f9          	add    $0xfffffffffffffff9,%r9
   2f2dd:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   2f2e2:	41 b6 01             	mov    $0x1,%r14b
   2f2e5:	b8 06 00 00 00       	mov    $0x6,%eax
   2f2ea:	48 89 84 24 10 01 00 	mov    %rax,0x110(%rsp)
   2f2f1:	00 
   2f2f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f2f9:	1f 84 00 00 00 00 00 
   2f300:	41 bc c8 00 00 00    	mov    $0xc8,%r12d
   2f306:	bf c8 00 00 00       	mov    $0xc8,%edi
   2f30b:	ff 15 7f 08 04 00    	call   *0x4087f(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2f311:	48 85 c0             	test   %rax,%rax
   2f314:	0f 84 5a 24 00 00    	je     31774 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a04>
   2f31a:	48 89 c5             	mov    %rax,%rbp
   2f31d:	49 89 c7             	mov    %rax,%r15
   2f320:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
   2f327:	00 
   2f328:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f32c:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
   2f333:	00 
   2f334:	49 89 cc             	mov    %rcx,%r12
   2f337:	49 f7 d4             	not    %r12
   2f33a:	49 01 c4             	add    %rax,%r12
   2f33d:	66 44 89 65 62       	mov    %r12w,0x62(%rbp)
   2f342:	49 83 fc 0c          	cmp    $0xc,%r12
   2f346:	0f 83 3b 24 00 00    	jae    31787 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a17>
   2f34c:	44 89 b4 24 b0 01 00 	mov    %r14d,0x1b0(%rsp)
   2f353:	00 
   2f354:	44 8d 34 8d 00 00 00 	lea    0x0(,%rcx,4),%r14d
   2f35b:	00 
   2f35c:	42 8b 44 33 08       	mov    0x8(%rbx,%r14,1),%eax
   2f361:	89 84 24 4c 01 00 00 	mov    %eax,0x14c(%rsp)
   2f368:	42 8b 44 33 34       	mov    0x34(%rbx,%r14,1),%eax
   2f36d:	89 84 24 48 01 00 00 	mov    %eax,0x148(%rsp)
   2f374:	4a 8d 34 33          	lea    (%rbx,%r14,1),%rsi
   2f378:	48 83 c6 0c          	add    $0xc,%rsi
   2f37c:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
   2f380:	49 c1 e4 02          	shl    $0x2,%r12
   2f384:	4c 89 e2             	mov    %r12,%rdx
   2f387:	ff 15 23 08 04 00    	call   *0x40823(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   2f38d:	4a 8d 34 33          	lea    (%rbx,%r14,1),%rsi
   2f391:	48 83 c6 38          	add    $0x38,%rsi
   2f395:	48 8d 7d 34          	lea    0x34(%rbp),%rdi
   2f399:	4c 89 e2             	mov    %r12,%rdx
   2f39c:	ff 15 0e 08 04 00    	call   *0x4080e(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   2f3a2:	48 8b 8c 24 10 01 00 	mov    0x110(%rsp),%rcx
   2f3a9:	00 
   2f3aa:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2f3ae:	45 0f b7 77 62       	movzwl 0x62(%r15),%r14d
   2f3b3:	4d 8d 66 01          	lea    0x1(%r14),%r12
   2f3b7:	49 83 fe 0b          	cmp    $0xb,%r14
   2f3bb:	0f 87 e2 23 00 00    	ja     317a3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a33>
   2f3c1:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
   2f3c8:	00 
   2f3c9:	29 c8                	sub    %ecx,%eax
   2f3cb:	44 39 e0             	cmp    %r12d,%eax
   2f3ce:	0f 85 1e 24 00 00    	jne    317f2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a82>
   2f3d4:	48 8d 7d 68          	lea    0x68(%rbp),%rdi
   2f3d8:	48 8d 34 cb          	lea    (%rbx,%rcx,8),%rsi
   2f3dc:	48 83 c6 70          	add    $0x70,%rsi
   2f3e0:	42 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%edx
   2f3e7:	00 
   2f3e8:	ff 15 c2 07 04 00    	call   *0x407c2(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   2f3ee:	44 89 e0             	mov    %r12d,%eax
   2f3f1:	83 e0 03             	and    $0x3,%eax
   2f3f4:	66 41 83 fe 03       	cmp    $0x3,%r14w
   2f3f9:	73 15                	jae    2f410 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x16a0>
   2f3fb:	31 c9                	xor    %ecx,%ecx
   2f3fd:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
   2f402:	44 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9d
   2f409:	00 
   2f40a:	eb 74                	jmp    2f480 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1710>
   2f40c:	0f 1f 40 00          	nopl   0x0(%rax)
   2f410:	41 83 e4 1c          	and    $0x1c,%r12d
   2f414:	31 c9                	xor    %ecx,%ecx
   2f416:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
   2f41b:	44 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%r9d
   2f422:	00 
   2f423:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f42a:	84 00 00 00 00 00 
   2f430:	49 8b 54 cf 68       	mov    0x68(%r15,%rcx,8),%rdx
   2f435:	4c 89 3a             	mov    %r15,(%rdx)
   2f438:	89 ce                	mov    %ecx,%esi
   2f43a:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2f43e:	49 8b 54 cf 70       	mov    0x70(%r15,%rcx,8),%rdx
   2f443:	4c 89 3a             	mov    %r15,(%rdx)
   2f446:	8d 7e 01             	lea    0x1(%rsi),%edi
   2f449:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2f44d:	49 8b 54 cf 78       	mov    0x78(%r15,%rcx,8),%rdx
   2f452:	4c 89 3a             	mov    %r15,(%rdx)
   2f455:	8d 7e 02             	lea    0x2(%rsi),%edi
   2f458:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2f45c:	49 8b 94 cf 80 00 00 	mov    0x80(%r15,%rcx,8),%rdx
   2f463:	00 
   2f464:	48 83 c1 04          	add    $0x4,%rcx
   2f468:	4c 89 3a             	mov    %r15,(%rdx)
   2f46b:	83 c6 03             	add    $0x3,%esi
   2f46e:	66 89 72 60          	mov    %si,0x60(%rdx)
   2f472:	4c 39 e1             	cmp    %r12,%rcx
   2f475:	75 b9                	jne    2f430 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x16c0>
   2f477:	48 85 c0             	test   %rax,%rax
   2f47a:	74 18                	je     2f494 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1724>
   2f47c:	0f 1f 40 00          	nopl   0x0(%rax)
   2f480:	49 8b 54 cf 68       	mov    0x68(%r15,%rcx,8),%rdx
   2f485:	4c 89 3a             	mov    %r15,(%rdx)
   2f488:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2f48c:	48 ff c1             	inc    %rcx
   2f48f:	48 ff c8             	dec    %rax
   2f492:	75 ec                	jne    2f480 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1710>
   2f494:	45 84 c9             	test   %r9b,%r9b
   2f497:	48 0f 44 eb          	cmove  %rbx,%rbp
   2f49b:	44 0f b7 65 62       	movzwl 0x62(%rbp),%r12d
   2f4a0:	4d 8d 70 01          	lea    0x1(%r8),%r14
   2f4a4:	4d 89 e1             	mov    %r12,%r9
   2f4a7:	4d 29 c1             	sub    %r8,%r9
   2f4aa:	0f 86 c0 00 00 00    	jbe    2f570 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1800>
   2f4b0:	48 8d 45 08          	lea    0x8(%rbp),%rax
   2f4b4:	4a 8d 34 85 08 00 00 	lea    0x8(,%r8,4),%rsi
   2f4bb:	00 
   2f4bc:	48 01 ee             	add    %rbp,%rsi
   2f4bf:	4a 8d 3c b0          	lea    (%rax,%r14,4),%rdi
   2f4c3:	44 89 e0             	mov    %r12d,%eax
   2f4c6:	44 29 c0             	sub    %r8d,%eax
   2f4c9:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   2f4d0:	00 
   2f4d1:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
   2f4d8:	48 89 94 24 b0 01 00 	mov    %rdx,0x1b0(%rsp)
   2f4df:	00 
   2f4e0:	4c 89 8c 24 10 01 00 	mov    %r9,0x110(%rsp)
   2f4e7:	00 
   2f4e8:	ff 15 92 07 04 00    	call   *0x40792(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f4ee:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f4f3:	48 8d 34 85 34 00 00 	lea    0x34(,%rax,4),%rsi
   2f4fa:	00 
   2f4fb:	48 01 ee             	add    %rbp,%rsi
   2f4fe:	4a 8d 3c b5 34 00 00 	lea    0x34(,%r14,4),%rdi
   2f505:	00 
   2f506:	48 01 ef             	add    %rbp,%rdi
   2f509:	48 8b 94 24 b0 01 00 	mov    0x1b0(%rsp),%rdx
   2f510:	00 
   2f511:	ff 15 69 07 04 00    	call   *0x40769(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f517:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f51c:	8b 8c 24 40 01 00 00 	mov    0x140(%rsp),%ecx
   2f523:	89 4c 85 08          	mov    %ecx,0x8(%rbp,%rax,4)
   2f527:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f52c:	8b 8c 24 44 01 00 00 	mov    0x144(%rsp),%ecx
   2f533:	89 4c 85 34          	mov    %ecx,0x34(%rbp,%rax,4)
   2f537:	4a 8d 74 f5 68       	lea    0x68(%rbp,%r14,8),%rsi
   2f53c:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f541:	48 8d 3c c5 78 00 00 	lea    0x78(,%rax,8),%rdi
   2f548:	00 
   2f549:	48 01 ef             	add    %rbp,%rdi
   2f54c:	48 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%rdx
   2f553:	00 
   2f554:	c1 e2 03             	shl    $0x3,%edx
   2f557:	ff 15 23 07 04 00    	call   *0x40723(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f55d:	4c 8b 8c 24 10 01 00 	mov    0x110(%rsp),%r9
   2f564:	00 
   2f565:	4c 8b 44 24 50       	mov    0x50(%rsp),%r8
   2f56a:	eb 1c                	jmp    2f588 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1818>
   2f56c:	0f 1f 40 00          	nopl   0x0(%rax)
   2f570:	8b 84 24 40 01 00 00 	mov    0x140(%rsp),%eax
   2f577:	42 89 44 85 08       	mov    %eax,0x8(%rbp,%r8,4)
   2f57c:	8b 84 24 44 01 00 00 	mov    0x144(%rsp),%eax
   2f583:	42 89 44 85 34       	mov    %eax,0x34(%rbp,%r8,4)
   2f588:	48 8b 94 24 18 02 00 	mov    0x218(%rsp),%rdx
   2f58f:	00 
   2f590:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
   2f595:	49 8d 44 24 02       	lea    0x2(%r12),%rax
   2f59a:	4a 89 54 c5 70       	mov    %rdx,0x70(%rbp,%r8,8)
   2f59f:	66 89 4d 62          	mov    %cx,0x62(%rbp)
   2f5a3:	41 39 c6             	cmp    %eax,%r14d
   2f5a6:	0f 83 64 fc ff ff    	jae    2f210 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x14a0>
   2f5ac:	45 29 c4             	sub    %r8d,%r12d
   2f5af:	41 ff c4             	inc    %r12d
   2f5b2:	41 83 e4 03          	and    $0x3,%r12d
   2f5b6:	74 32                	je     2f5ea <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x187a>
   2f5b8:	4a 8d 14 c5 70 00 00 	lea    0x70(,%r8,8),%rdx
   2f5bf:	00 
   2f5c0:	48 01 ea             	add    %rbp,%rdx
   2f5c3:	31 c9                	xor    %ecx,%ecx
   2f5c5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f5cc:	00 00 00 00 
   2f5d0:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   2f5d4:	48 89 2e             	mov    %rbp,(%rsi)
   2f5d7:	41 8d 3c 0e          	lea    (%r14,%rcx,1),%edi
   2f5db:	66 89 7e 60          	mov    %di,0x60(%rsi)
   2f5df:	48 ff c1             	inc    %rcx
   2f5e2:	49 39 cc             	cmp    %rcx,%r12
   2f5e5:	75 e9                	jne    2f5d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1860>
   2f5e7:	49 01 ce             	add    %rcx,%r14
   2f5ea:	41 83 f9 03          	cmp    $0x3,%r9d
   2f5ee:	0f 82 1c fc ff ff    	jb     2f210 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x14a0>
   2f5f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f5fb:	00 00 00 00 00 
   2f600:	4a 8b 4c f5 68       	mov    0x68(%rbp,%r14,8),%rcx
   2f605:	48 89 29             	mov    %rbp,(%rcx)
   2f608:	66 44 89 71 60       	mov    %r14w,0x60(%rcx)
   2f60d:	4a 8b 4c f5 70       	mov    0x70(%rbp,%r14,8),%rcx
   2f612:	48 89 29             	mov    %rbp,(%rcx)
   2f615:	41 8d 56 01          	lea    0x1(%r14),%edx
   2f619:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f61d:	4a 8b 4c f5 78       	mov    0x78(%rbp,%r14,8),%rcx
   2f622:	48 89 29             	mov    %rbp,(%rcx)
   2f625:	41 8d 56 02          	lea    0x2(%r14),%edx
   2f629:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f62d:	4a 8b 8c f5 80 00 00 	mov    0x80(%rbp,%r14,8),%rcx
   2f634:	00 
   2f635:	48 89 29             	mov    %rbp,(%rcx)
   2f638:	41 8d 56 03          	lea    0x3(%r14),%edx
   2f63c:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f640:	49 83 c6 04          	add    $0x4,%r14
   2f644:	49 39 c6             	cmp    %rax,%r14
   2f647:	75 b7                	jne    2f600 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1890>
   2f649:	e9 c2 fb ff ff       	jmp    2f210 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x14a0>
   2f64e:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2f655:	00 
   2f656:	bf c8 00 00 00       	mov    $0xc8,%edi
   2f65b:	ff 15 2f 05 04 00    	call   *0x4052f(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2f661:	48 85 c0             	test   %rax,%rax
   2f664:	0f 84 91 22 00 00    	je     318fb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b8b>
   2f66a:	49 89 c4             	mov    %rax,%r12
   2f66d:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f674:	66 c7 40 62 00 00    	movw   $0x0,0x62(%rax)
   2f67a:	4c 89 68 68          	mov    %r13,0x68(%rax)
   2f67e:	48 8b 8c 24 c0 00 00 	mov    0xc0(%rsp),%rcx
   2f685:	00 
   2f686:	48 89 c8             	mov    %rcx,%rax
   2f689:	48 ff c0             	inc    %rax
   2f68c:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2f693:	00 
   2f694:	0f 84 76 22 00 00    	je     31910 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ba0>
   2f69a:	4d 89 65 00          	mov    %r12,0x0(%r13)
   2f69e:	66 41 c7 45 60 00 00 	movw   $0x0,0x60(%r13)
   2f6a5:	4c 89 a4 24 f0 01 00 	mov    %r12,0x1f0(%rsp)
   2f6ac:	00 
   2f6ad:	48 89 84 24 f8 01 00 	mov    %rax,0x1f8(%rsp)
   2f6b4:	00 
   2f6b5:	48 39 cd             	cmp    %rcx,%rbp
   2f6b8:	0f 85 64 22 00 00    	jne    31922 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3bb2>
   2f6be:	66 41 c7 44 24 62 01 	movw   $0x1,0x62(%r12)
   2f6c5:	00 
   2f6c6:	8b 8c 24 4c 01 00 00 	mov    0x14c(%rsp),%ecx
   2f6cd:	41 89 4c 24 08       	mov    %ecx,0x8(%r12)
   2f6d2:	8b 8c 24 48 01 00 00 	mov    0x148(%rsp),%ecx
   2f6d9:	41 89 4c 24 34       	mov    %ecx,0x34(%r12)
   2f6de:	4d 89 7c 24 70       	mov    %r15,0x70(%r12)
   2f6e3:	4d 89 27             	mov    %r12,(%r15)
   2f6e6:	66 41 c7 47 60 01 00 	movw   $0x1,0x60(%r15)
   2f6ed:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   2f6f4:	00 
   2f6f5:	4d 89 e5             	mov    %r12,%r13
   2f6f8:	4c 8b a4 24 88 01 00 	mov    0x188(%rsp),%r12
   2f6ff:	00 
   2f700:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2f705:	e9 aa f8 ff ff       	jmp    2efb4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1244>
   2f70a:	49 8d 69 01          	lea    0x1(%r9),%rbp
   2f70e:	66 45 39 d1          	cmp    %r10w,%r9w
   2f712:	0f 83 b7 00 00 00    	jae    2f7cf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a5f>
   2f718:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   2f71c:	4a 8d 34 8b          	lea    (%rbx,%r9,4),%rsi
   2f720:	48 83 c6 08          	add    $0x8,%rsi
   2f724:	44 8d 34 ad 00 00 00 	lea    0x0(,%rbp,4),%r14d
   2f72b:	00 
   2f72c:	4c 01 f7             	add    %r14,%rdi
   2f72f:	4d 89 d7             	mov    %r10,%r15
   2f732:	4d 29 cf             	sub    %r9,%r15
   2f735:	4a 8d 14 bd 00 00 00 	lea    0x0(,%r15,4),%rdx
   2f73c:	00 
   2f73d:	48 8b 05 3c 05 04 00 	mov    0x4053c(%rip),%rax        # 6fc80 <memmove@GLIBC_2.2.5>
   2f744:	4c 89 4c 24 50       	mov    %r9,0x50(%rsp)
   2f749:	ff d0                	call   *%rax
   2f74b:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f750:	44 8d 24 85 00 00 00 	lea    0x0(,%rax,4),%r12d
   2f757:	00 
   2f758:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
   2f75c:	48 83 c6 34          	add    $0x34,%rsi
   2f760:	4a 8d 3c 33          	lea    (%rbx,%r14,1),%rdi
   2f764:	48 83 c7 34          	add    $0x34,%rdi
   2f768:	4c 8b b4 24 50 01 00 	mov    0x150(%rsp),%r14
   2f76f:	00 
   2f770:	4a 8d 14 bd 00 00 00 	lea    0x0(,%r15,4),%rdx
   2f777:	00 
   2f778:	ff 15 02 05 04 00    	call   *0x40502(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f77e:	8b 84 24 40 01 00 00 	mov    0x140(%rsp),%eax
   2f785:	42 89 44 23 08       	mov    %eax,0x8(%rbx,%r12,1)
   2f78a:	8b 84 24 44 01 00 00 	mov    0x144(%rsp),%eax
   2f791:	42 89 44 23 34       	mov    %eax,0x34(%rbx,%r12,1)
   2f796:	48 8d 34 eb          	lea    (%rbx,%rbp,8),%rsi
   2f79a:	48 83 c6 68          	add    $0x68,%rsi
   2f79e:	48 8b 44 24 50       	mov    0x50(%rsp),%rax
   2f7a3:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
   2f7a7:	48 83 c7 78          	add    $0x78,%rdi
   2f7ab:	49 c1 e7 03          	shl    $0x3,%r15
   2f7af:	4c 89 fa             	mov    %r15,%rdx
   2f7b2:	ff 15 c8 04 04 00    	call   *0x404c8(%rip)        # 6fc80 <memmove@GLIBC_2.2.5>
   2f7b8:	4c 8b 94 24 b8 01 00 	mov    0x1b8(%rsp),%r10
   2f7bf:	00 
   2f7c0:	4c 8b 84 24 18 02 00 	mov    0x218(%rsp),%r8
   2f7c7:	00 
   2f7c8:	4c 8b 4c 24 50       	mov    0x50(%rsp),%r9
   2f7cd:	eb 0d                	jmp    2f7dc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a6c>
   2f7cf:	4d 89 f8             	mov    %r15,%r8
   2f7d2:	42 89 74 8b 08       	mov    %esi,0x8(%rbx,%r9,4)
   2f7d7:	42 89 4c 8b 34       	mov    %ecx,0x34(%rbx,%r9,4)
   2f7dc:	4c 8b a4 24 88 01 00 	mov    0x188(%rsp),%r12
   2f7e3:	00 
   2f7e4:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2f7e9:	41 8d 4a 01          	lea    0x1(%r10),%ecx
   2f7ed:	49 8d 42 02          	lea    0x2(%r10),%rax
   2f7f1:	4e 89 44 cb 70       	mov    %r8,0x70(%rbx,%r9,8)
   2f7f6:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2f7fa:	39 c5                	cmp    %eax,%ebp
   2f7fc:	0f 83 93 00 00 00    	jae    2f895 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b25>
   2f802:	44 89 d1             	mov    %r10d,%ecx
   2f805:	44 29 c9             	sub    %r9d,%ecx
   2f808:	ff c1                	inc    %ecx
   2f80a:	83 e1 03             	and    $0x3,%ecx
   2f80d:	74 2c                	je     2f83b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1acb>
   2f80f:	4a 8d 34 cb          	lea    (%rbx,%r9,8),%rsi
   2f813:	48 83 c6 70          	add    $0x70,%rsi
   2f817:	31 d2                	xor    %edx,%edx
   2f819:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2f820:	48 8b 3c d6          	mov    (%rsi,%rdx,8),%rdi
   2f824:	48 89 1f             	mov    %rbx,(%rdi)
   2f827:	44 8d 04 2a          	lea    (%rdx,%rbp,1),%r8d
   2f82b:	66 44 89 47 60       	mov    %r8w,0x60(%rdi)
   2f830:	48 ff c2             	inc    %rdx
   2f833:	48 39 d1             	cmp    %rdx,%rcx
   2f836:	75 e8                	jne    2f820 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ab0>
   2f838:	48 01 d5             	add    %rdx,%rbp
   2f83b:	4d 29 ca             	sub    %r9,%r10
   2f83e:	41 83 fa 03          	cmp    $0x3,%r10d
   2f842:	72 51                	jb     2f895 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b25>
   2f844:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f84b:	00 00 00 00 00 
   2f850:	48 8b 4c eb 68       	mov    0x68(%rbx,%rbp,8),%rcx
   2f855:	48 89 19             	mov    %rbx,(%rcx)
   2f858:	66 89 69 60          	mov    %bp,0x60(%rcx)
   2f85c:	48 8b 4c eb 70       	mov    0x70(%rbx,%rbp,8),%rcx
   2f861:	48 89 19             	mov    %rbx,(%rcx)
   2f864:	8d 55 01             	lea    0x1(%rbp),%edx
   2f867:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f86b:	48 8b 4c eb 78       	mov    0x78(%rbx,%rbp,8),%rcx
   2f870:	48 89 19             	mov    %rbx,(%rcx)
   2f873:	8d 55 02             	lea    0x2(%rbp),%edx
   2f876:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f87a:	48 8b 8c eb 80 00 00 	mov    0x80(%rbx,%rbp,8),%rcx
   2f881:	00 
   2f882:	48 89 19             	mov    %rbx,(%rcx)
   2f885:	8d 55 03             	lea    0x3(%rbp),%edx
   2f888:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f88c:	48 83 c5 04          	add    $0x4,%rbp
   2f890:	48 39 c5             	cmp    %rax,%rbp
   2f893:	75 bb                	jne    2f850 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ae0>
   2f895:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2f89c:	00 
   2f89d:	e9 12 f7 ff ff       	jmp    2efb4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1244>
   2f8a2:	48 8d bc 24 c0 01 00 	lea    0x1c0(%rsp),%rdi
   2f8a9:	00 
   2f8aa:	4c 89 fe             	mov    %r15,%rsi
   2f8ad:	48 89 ea             	mov    %rbp,%rdx
   2f8b0:	e8 cb 93 ff ff       	call   28c80 <_RINvMs6_NtCs3BTM885nGDo_9hashbrown3rawINtB6_8RawTableTllEE14reserve_rehashNCINvNtB8_3map11make_hasherllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE0ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f8b5:	e9 5e f3 ff ff       	jmp    2ec18 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xea8>
   2f8ba:	ba 04 00 00 00       	mov    $0x4,%edx
   2f8bf:	b9 01 00 00 00       	mov    $0x1,%ecx
   2f8c4:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2f8ca:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   2f8d1:	00 
   2f8d2:	e8 89 cd ff ff       	call   2c660 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f8d7:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
   2f8de:	00 
   2f8df:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   2f8e6:	00 
   2f8e7:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2f8ee:	00 
   2f8ef:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2f8f4:	e9 f6 f6 ff ff       	jmp    2efef <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x127f>
   2f8f9:	ba 04 00 00 00       	mov    $0x4,%edx
   2f8fe:	b9 01 00 00 00       	mov    $0x1,%ecx
   2f903:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2f909:	48 8d bc 24 70 01 00 	lea    0x170(%rsp),%rdi
   2f910:	00 
   2f911:	e8 4a cd ff ff       	call   2c660 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f916:	48 8b 8c 24 78 01 00 	mov    0x178(%rsp),%rcx
   2f91d:	00 
   2f91e:	48 8b b4 24 80 01 00 	mov    0x180(%rsp),%rsi
   2f925:	00 
   2f926:	48 8b 9c 24 c8 00 00 	mov    0xc8(%rsp),%rbx
   2f92d:	00 
   2f92e:	e9 e1 f6 ff ff       	jmp    2f014 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x12a4>
   2f933:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2f937:	66 0f d7 f0          	pmovmskb %xmm0,%esi
   2f93b:	f3 0f bc f6          	tzcnt  %esi,%esi
   2f93f:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
   2f943:	e9 95 f5 ff ff       	jmp    2eedd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x116d>
   2f948:	48 c7 84 24 68 01 00 	movq   $0x0,0x168(%rsp)
   2f94f:	00 00 00 00 00 
   2f954:	45 31 ed             	xor    %r13d,%r13d
   2f957:	4c 8b a4 24 20 01 00 	mov    0x120(%rsp),%r12
   2f95e:	00 
   2f95f:	4d 85 e4             	test   %r12,%r12
   2f962:	74 1a                	je     2f97e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c0e>
   2f964:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   2f969:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   2f96e:	4d 85 ff             	test   %r15,%r15
   2f971:	74 11                	je     2f984 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c14>
   2f973:	49 83 ff 10          	cmp    $0x10,%r15
   2f977:	73 13                	jae    2f98c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c1c>
   2f979:	45 31 e4             	xor    %r12d,%r12d
   2f97c:	eb 1f                	jmp    2f99d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c2d>
   2f97e:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2f984:	45 31 ff             	xor    %r15d,%r15d
   2f987:	45 31 e4             	xor    %r12d,%r12d
   2f98a:	eb 11                	jmp    2f99d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c2d>
   2f98c:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   2f991:	49 83 c4 18          	add    $0x18,%r12
   2f995:	85 c0                	test   %eax,%eax
   2f997:	0f 85 c8 1f 00 00    	jne    31965 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3bf5>
   2f99d:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2f9a4:	00 00 
   2f9a6:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   2f9ab:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   2f9b0:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   2f9b5:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2f9bc:	00 00 
   2f9be:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   2f9c5:	00 
   2f9c6:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   2f9cb:	e8 90 3e 00 00       	call   33860 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEE9from_iterCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f9d0:	48 8b b4 24 f8 00 00 	mov    0xf8(%rsp),%rsi
   2f9d7:	00 
   2f9d8:	48 85 f6             	test   %rsi,%rsi
   2f9db:	74 21                	je     2f9fe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c8e>
   2f9dd:	48 83 fe 01          	cmp    $0x1,%rsi
   2f9e1:	0f 85 f8 1e 00 00    	jne    318df <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b6f>
   2f9e7:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
   2f9ee:	00 
   2f9ef:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   2f9f6:	00 
   2f9f7:	e8 e4 99 ff ff       	call   293e0 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f9fc:	eb 31                	jmp    2fa2f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1cbf>
   2f9fe:	48 c7 84 24 30 02 00 	movq   $0x0,0x230(%rsp)
   2fa05:	00 00 00 00 00 
   2fa0a:	48 c7 84 24 40 02 00 	movq   $0x0,0x240(%rsp)
   2fa11:	00 00 00 00 00 
   2fa16:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
   2fa1d:	00 00 
   2fa1f:	74 0e                	je     2fa2f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1cbf>
   2fa21:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   2fa28:	00 
   2fa29:	ff 15 71 01 04 00    	call   *0x40171(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   2fa2f:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
   2fa36:	00 
   2fa37:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   2fa3e:	00 
   2fa3f:	e8 8c 4c 00 00       	call   346d0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fa44:	84 c0                	test   %al,%al
   2fa46:	0f 84 1d 1e 00 00    	je     31869 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3af9>
   2fa4c:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   2fa53:	00 
   2fa54:	48 85 c9             	test   %rcx,%rcx
   2fa57:	0f 84 9d 00 00 00    	je     2fafa <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d8a>
   2fa5d:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2fa64:	ff ff 1f 
   2fa67:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
   2fa6e:	00 
   2fa6f:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   2fa73:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   2fa77:	4c 8d 73 10          	lea    0x10(%rbx),%r14
   2fa7b:	66 83 f5 ff          	xor    $0xffff,%bp
   2fa7f:	75 26                	jne    2faa7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d37>
   2fa81:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fa88:	0f 1f 84 00 00 00 00 
   2fa8f:	00 
   2fa90:	66 41 0f 6f 06       	movdqa (%r14),%xmm0
   2fa95:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   2fa99:	49 83 c6 10          	add    $0x10,%r14
   2fa9d:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   2faa1:	66 83 f5 ff          	xor    $0xffff,%bp
   2faa5:	74 e9                	je     2fa90 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d20>
   2faa7:	48 83 f9 05          	cmp    $0x5,%rcx
   2faab:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2fab1:	be 04 00 00 00       	mov    $0x4,%esi
   2fab6:	48 0f 43 f1          	cmovae %rcx,%rsi
   2faba:	4c 8d 24 f5 00 00 00 	lea    0x0(,%rsi,8),%r12
   2fac1:	00 
   2fac2:	48 ff c0             	inc    %rax
   2fac5:	48 39 c1             	cmp    %rax,%rcx
   2fac8:	0f 97 c0             	seta   %al
   2facb:	48 89 ca             	mov    %rcx,%rdx
   2face:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2fad5:	ff ff 7f 
   2fad8:	48 83 c1 0b          	add    $0xb,%rcx
   2fadc:	49 39 cc             	cmp    %rcx,%r12
   2fadf:	0f 97 c1             	seta   %cl
   2fae2:	08 c1                	or     %al,%cl
   2fae4:	74 31                	je     2fb17 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1da7>
   2fae6:	45 31 ff             	xor    %r15d,%r15d
   2fae9:	4c 89 ff             	mov    %r15,%rdi
   2faec:	4c 89 e6             	mov    %r12,%rsi
   2faef:	ff 15 e3 00 04 00    	call   *0x400e3(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   2faf5:	e9 d7 21 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   2fafa:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
   2fb01:	00 00 00 00 00 
   2fb06:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
   2fb0d:	00 00 00 00 00 
   2fb12:	e9 da 01 00 00       	jmp    2fcf1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f81>
   2fb17:	48 89 b4 24 b0 00 00 	mov    %rsi,0xb0(%rsp)
   2fb1e:	00 
   2fb1f:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2fb24:	f3 0f bc c5          	tzcnt  %ebp,%eax
   2fb28:	c1 e0 03             	shl    $0x3,%eax
   2fb2b:	48 89 d9             	mov    %rbx,%rcx
   2fb2e:	48 29 c1             	sub    %rax,%rcx
   2fb31:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2fb36:	66 0f 7f 84 24 50 01 	movdqa %xmm0,0x150(%rsp)
   2fb3d:	00 00 
   2fb3f:	4c 89 e7             	mov    %r12,%rdi
   2fb42:	ff 15 48 00 04 00    	call   *0x40048(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   2fb48:	48 85 c0             	test   %rax,%rax
   2fb4b:	74 9c                	je     2fae9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d79>
   2fb4d:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2fb52:	49 89 cf             	mov    %rcx,%r15
   2fb55:	66 0f 6f 84 24 50 01 	movdqa 0x150(%rsp),%xmm0
   2fb5c:	00 00 
   2fb5e:	66 0f d6 00          	movq   %xmm0,(%rax)
   2fb62:	4c 8b a4 24 b0 00 00 	mov    0xb0(%rsp),%r12
   2fb69:	00 
   2fb6a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2fb6f:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2fb74:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2fb7b:	00 00 
   2fb7d:	49 ff cf             	dec    %r15
   2fb80:	0f 84 4a 01 00 00    	je     2fcd0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f60>
   2fb86:	44 8d 65 ff          	lea    -0x1(%rbp),%r12d
   2fb8a:	41 21 ec             	and    %ebp,%r12d
   2fb8d:	b9 01 00 00 00       	mov    $0x1,%ecx
   2fb92:	eb 3b                	jmp    2fbcf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e5f>
   2fb94:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fb9b:	00 00 00 00 00 
   2fba0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2fba5:	41 8d 54 24 ff       	lea    -0x1(%r12),%edx
   2fbaa:	44 21 e2             	and    %r12d,%edx
   2fbad:	49 ff cf             	dec    %r15
   2fbb0:	66 0f 6f 84 24 b0 00 	movdqa 0xb0(%rsp),%xmm0
   2fbb7:	00 00 
   2fbb9:	66 0f d6 04 e8       	movq   %xmm0,(%rax,%rbp,8)
   2fbbe:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   2fbc2:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2fbc7:	41 89 d4             	mov    %edx,%r12d
   2fbca:	4d 85 ff             	test   %r15,%r15
   2fbcd:	74 6c                	je     2fc3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ecb>
   2fbcf:	48 89 cd             	mov    %rcx,%rbp
   2fbd2:	66 45 85 e4          	test   %r12w,%r12w
   2fbd6:	75 21                	jne    2fbf9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e89>
   2fbd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2fbdf:	00 
   2fbe0:	66 41 0f 6f 06       	movdqa (%r14),%xmm0
   2fbe5:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   2fbe9:	49 83 c6 10          	add    $0x10,%r14
   2fbed:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2fbf2:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2fbf7:	74 e7                	je     2fbe0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e70>
   2fbf9:	f3 41 0f bc cc       	tzcnt  %r12d,%ecx
   2fbfe:	c1 e1 03             	shl    $0x3,%ecx
   2fc01:	48 89 da             	mov    %rbx,%rdx
   2fc04:	48 29 ca             	sub    %rcx,%rdx
   2fc07:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2fc0c:	0f 29 84 24 b0 00 00 	movaps %xmm0,0xb0(%rsp)
   2fc13:	00 
   2fc14:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
   2fc19:	75 8a                	jne    2fba5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e35>
   2fc1b:	b9 04 00 00 00       	mov    $0x4,%ecx
   2fc20:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2fc26:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2fc2b:	48 89 ee             	mov    %rbp,%rsi
   2fc2e:	4c 89 fa             	mov    %r15,%rdx
   2fc31:	e8 2a ca ff ff       	call   2c660 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fc36:	e9 65 ff ff ff       	jmp    2fba0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e30>
   2fc3b:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   2fc40:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2fc45:	48 83 fd 14          	cmp    $0x14,%rbp
   2fc49:	0f 83 29 1d 00 00    	jae    31978 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c08>
   2fc4f:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2fc54:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
   2fc58:	48 8d 78 08          	lea    0x8(%rax),%rdi
   2fc5c:	31 d2                	xor    %edx,%edx
   2fc5e:	49 89 c2             	mov    %rax,%r10
   2fc61:	eb 20                	jmp    2fc83 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f13>
   2fc63:	49 01 c1             	add    %rax,%r9
   2fc66:	4d 89 cb             	mov    %r9,%r11
   2fc69:	49 c1 e0 20          	shl    $0x20,%r8
   2fc6d:	49 09 f8             	or     %rdi,%r8
   2fc70:	4d 89 03             	mov    %r8,(%r11)
   2fc73:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
   2fc77:	48 83 c2 08          	add    $0x8,%rdx
   2fc7b:	49 89 f2             	mov    %rsi,%r10
   2fc7e:	48 39 cf             	cmp    %rcx,%rdi
   2fc81:	74 48                	je     2fccb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f5b>
   2fc83:	48 89 fe             	mov    %rdi,%rsi
   2fc86:	41 8b 7a 08          	mov    0x8(%r10),%edi
   2fc8a:	41 3b 3a             	cmp    (%r10),%edi
   2fc8d:	7d e4                	jge    2fc73 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f03>
   2fc8f:	45 8b 42 0c          	mov    0xc(%r10),%r8d
   2fc93:	4d 8b 0a             	mov    (%r10),%r9
   2fc96:	4d 89 4a 08          	mov    %r9,0x8(%r10)
   2fc9a:	49 89 d1             	mov    %rdx,%r9
   2fc9d:	49 89 c3             	mov    %rax,%r11
   2fca0:	49 39 c2             	cmp    %rax,%r10
   2fca3:	74 c4                	je     2fc69 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ef9>
   2fca5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2fcac:	00 00 00 00 
   2fcb0:	42 3b 7c 08 f8       	cmp    -0x8(%rax,%r9,1),%edi
   2fcb5:	7d ac                	jge    2fc63 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ef3>
   2fcb7:	4e 8b 54 08 f8       	mov    -0x8(%rax,%r9,1),%r10
   2fcbc:	4e 89 14 08          	mov    %r10,(%rax,%r9,1)
   2fcc0:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   2fcc4:	75 ea                	jne    2fcb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f40>
   2fcc6:	49 89 c3             	mov    %rax,%r11
   2fcc9:	eb 9e                	jmp    2fc69 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ef9>
   2fccb:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2fcd0:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2fcd5:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2fcda:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2fcdf:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   2fce6:	00 
   2fce7:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   2fcec:	e8 ef 96 ff ff       	call   293e0 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fcf1:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   2fcf8:	00 
   2fcf9:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   2fd00:	00 
   2fd01:	e8 ca 49 00 00       	call   346d0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fd06:	84 c0                	test   %al,%al
   2fd08:	0f 84 7c 1b 00 00    	je     3188a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b1a>
   2fd0e:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   2fd15:	00 
   2fd16:	e8 85 9f ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fd1b:	48 8b ac 24 20 01 00 	mov    0x120(%rsp),%rbp
   2fd22:	00 
   2fd23:	48 85 ed             	test   %rbp,%rbp
   2fd26:	74 17                	je     2fd3f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fcf>
   2fd28:	4c 8b 65 08          	mov    0x8(%rbp),%r12
   2fd2c:	4c 8b 7d 10          	mov    0x10(%rbp),%r15
   2fd30:	4d 85 ff             	test   %r15,%r15
   2fd33:	74 10                	je     2fd45 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fd5>
   2fd35:	49 83 ff 10          	cmp    $0x10,%r15
   2fd39:	73 11                	jae    2fd4c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fdc>
   2fd3b:	31 ed                	xor    %ebp,%ebp
   2fd3d:	eb 1c                	jmp    2fd5b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1feb>
   2fd3f:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2fd45:	45 31 ff             	xor    %r15d,%r15d
   2fd48:	31 ed                	xor    %ebp,%ebp
   2fd4a:	eb 0f                	jmp    2fd5b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1feb>
   2fd4c:	8b 45 30             	mov    0x30(%rbp),%eax
   2fd4f:	48 83 c5 18          	add    $0x18,%rbp
   2fd53:	85 c0                	test   %eax,%eax
   2fd55:	0f 85 40 1c 00 00    	jne    3199b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c2b>
   2fd5b:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
   2fd62:	00 00 00 00 00 
   2fd67:	4c 8d b4 24 f0 00 00 	lea    0xf0(%rsp),%r14
   2fd6e:	00 
   2fd6f:	4c 89 a4 24 f0 00 00 	mov    %r12,0xf0(%rsp)
   2fd76:	00 
   2fd77:	4c 89 bc 24 f8 00 00 	mov    %r15,0xf8(%rsp)
   2fd7e:	00 
   2fd7f:	48 89 ac 24 00 01 00 	mov    %rbp,0x100(%rsp)
   2fd86:	00 
   2fd87:	48 c7 84 24 08 01 00 	movq   $0x0,0x108(%rsp)
   2fd8e:	00 00 00 00 00 
   2fd93:	48 8b 9c 24 68 01 00 	mov    0x168(%rsp),%rbx
   2fd9a:	00 
   2fd9b:	48 85 db             	test   %rbx,%rbx
   2fd9e:	0f 84 4d 01 00 00    	je     2fef1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2181>
   2fda4:	31 ed                	xor    %ebp,%ebp
   2fda6:	4c 8d 25 73 e5 03 00 	lea    0x3e573(%rip),%r12        # 6e320 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x810>
   2fdad:	4c 8d 3d cb 96 fd ff 	lea    -0x26935(%rip),%r15        # 947f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2b8>
   2fdb4:	eb 13                	jmp    2fdc9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2059>
   2fdb6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2fdbd:	00 00 00 
   2fdc0:	48 ff cb             	dec    %rbx
   2fdc3:	0f 84 ee 00 00 00    	je     2feb7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2147>
   2fdc9:	80 bc 24 e8 00 00 00 	cmpb   $0x0,0xe8(%rsp)
   2fdd0:	00 
   2fdd1:	74 5d                	je     2fe30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x20c0>
   2fdd3:	48 8b 84 24 f0 00 00 	mov    0xf0(%rsp),%rax
   2fdda:	00 
   2fddb:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2fde2:	00 
   2fde3:	48 89 ca             	mov    %rcx,%rdx
   2fde6:	48 29 c2             	sub    %rax,%rdx
   2fde9:	48 0f 42 d5          	cmovb  %rbp,%rdx
   2fded:	48 39 d3             	cmp    %rdx,%rbx
   2fdf0:	0f 85 ab 00 00 00    	jne    2fea1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2131>
   2fdf6:	be 28 00 00 00       	mov    $0x28,%esi
   2fdfb:	48 39 c8             	cmp    %rcx,%rax
   2fdfe:	0f 83 6c 1c 00 00    	jae    31a70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d00>
   2fe04:	48 8b 8c 24 00 01 00 	mov    0x100(%rsp),%rcx
   2fe0b:	00 
   2fe0c:	48 8d 14 40          	lea    (%rax,%rax,2),%rdx
   2fe10:	48 ff c0             	inc    %rax
   2fe13:	83 3c 91 00          	cmpl   $0x0,(%rcx,%rdx,4)
   2fe17:	c7 04 91 00 00 00 00 	movl   $0x0,(%rcx,%rdx,4)
   2fe1e:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   2fe25:	00 
   2fe26:	75 98                	jne    2fdc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2050>
   2fe28:	e9 43 1c 00 00       	jmp    31a70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d00>
   2fe2d:	0f 1f 00             	nopl   (%rax)
   2fe30:	48 8b 8c 24 f8 00 00 	mov    0xf8(%rsp),%rcx
   2fe37:	00 
   2fe38:	48 89 ca             	mov    %rcx,%rdx
   2fe3b:	48 2b 94 24 08 01 00 	sub    0x108(%rsp),%rdx
   2fe42:	00 
   2fe43:	b8 00 00 00 00       	mov    $0x0,%eax
   2fe48:	48 0f 43 c2          	cmovae %rdx,%rax
   2fe4c:	48 83 f9 02          	cmp    $0x2,%rcx
   2fe50:	72 13                	jb     2fe65 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x20f5>
   2fe52:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
   2fe59:	00 
   2fe5a:	48 85 d2             	test   %rdx,%rdx
   2fe5d:	74 30                	je     2fe8f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x211f>
   2fe5f:	48 39 4a 10          	cmp    %rcx,0x10(%rdx)
   2fe63:	75 2a                	jne    2fe8f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x211f>
   2fe65:	48 39 d8             	cmp    %rbx,%rax
   2fe68:	0f 97 c1             	seta   %cl
   2fe6b:	48 39 d8             	cmp    %rbx,%rax
   2fe6e:	0f 92 c0             	setb   %al
   2fe71:	84 c9                	test   %cl,%cl
   2fe73:	75 26                	jne    2fe9b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x212b>
   2fe75:	84 c0                	test   %al,%al
   2fe77:	75 28                	jne    2fea1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2131>
   2fe79:	4c 89 f7             	mov    %r14,%rdi
   2fe7c:	e8 cf 4c 00 00       	call   34b50 <_RNvXsq_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_7MapIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fe81:	48 85 c0             	test   %rax,%rax
   2fe84:	0f 85 36 ff ff ff    	jne    2fdc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2050>
   2fe8a:	e9 dc 1b 00 00       	jmp    31a6b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3cfb>
   2fe8f:	31 c9                	xor    %ecx,%ecx
   2fe91:	48 39 d8             	cmp    %rbx,%rax
   2fe94:	0f 92 c0             	setb   %al
   2fe97:	84 c9                	test   %cl,%cl
   2fe99:	74 da                	je     2fe75 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2105>
   2fe9b:	b0 01                	mov    $0x1,%al
   2fe9d:	84 c0                	test   %al,%al
   2fe9f:	74 d8                	je     2fe79 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2109>
   2fea1:	be 44 00 00 00       	mov    $0x44,%esi
   2fea6:	4c 89 ff             	mov    %r15,%rdi
   2fea9:	4c 89 e2             	mov    %r12,%rdx
   2feac:	ff 15 ae fe 03 00    	call   *0x3feae(%rip)        # 6fd60 <_DYNAMIC+0x3b8>
   2feb2:	e9 1a 1e 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   2feb7:	80 bc 24 e8 00 00 00 	cmpb   $0x0,0xe8(%rsp)
   2febe:	00 
   2febf:	74 34                	je     2fef5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2185>
   2fec1:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2fec8:	00 
   2fec9:	31 c9                	xor    %ecx,%ecx
   2fecb:	48 2b 84 24 f0 00 00 	sub    0xf0(%rsp),%rax
   2fed2:	00 
   2fed3:	48 0f 43 c8          	cmovae %rax,%rcx
   2fed7:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2fedc:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
   2fee3:	00 00 
   2fee5:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2feea:	76 73                	jbe    2ff5f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x21ef>
   2feec:	e9 90 17 00 00       	jmp    31681 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3911>
   2fef1:	31 c0                	xor    %eax,%eax
   2fef3:	eb 10                	jmp    2ff05 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2195>
   2fef5:	4c 8b bc 24 f8 00 00 	mov    0xf8(%rsp),%r15
   2fefc:	00 
   2fefd:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2ff04:	00 
   2ff05:	31 c9                	xor    %ecx,%ecx
   2ff07:	4c 89 fa             	mov    %r15,%rdx
   2ff0a:	48 29 c2             	sub    %rax,%rdx
   2ff0d:	48 0f 43 ca          	cmovae %rdx,%rcx
   2ff11:	49 83 ff 02          	cmp    $0x2,%r15
   2ff15:	72 1b                	jb     2ff32 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x21c2>
   2ff17:	48 8b 94 24 00 01 00 	mov    0x100(%rsp),%rdx
   2ff1e:	00 
   2ff1f:	48 85 d2             	test   %rdx,%rdx
   2ff22:	0f 84 39 17 00 00    	je     31661 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38f1>
   2ff28:	4c 39 7a 10          	cmp    %r15,0x10(%rdx)
   2ff2c:	0f 85 2f 17 00 00    	jne    31661 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38f1>
   2ff32:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2ff37:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
   2ff3e:	00 00 
   2ff40:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2ff45:	49 39 c7             	cmp    %rax,%r15
   2ff48:	0f 87 33 17 00 00    	ja     31681 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3911>
   2ff4e:	4c 89 f7             	mov    %r14,%rdi
   2ff51:	e8 fa 4b 00 00       	call   34b50 <_RNvXsq_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_7MapIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2ff56:	48 85 c0             	test   %rax,%rax
   2ff59:	0f 85 dc 1c 00 00    	jne    31c3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ecb>
   2ff5f:	45 31 f6             	xor    %r14d,%r14d
   2ff62:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
   2ff69:	00 
   2ff6a:	48 85 c0             	test   %rax,%rax
   2ff6d:	0f 84 a8 01 00 00    	je     3011b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23ab>
   2ff73:	4d 85 ed             	test   %r13,%r13
   2ff76:	0f 84 9f 01 00 00    	je     3011b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23ab>
   2ff7c:	31 c9                	xor    %ecx,%ecx
   2ff7e:	45 31 f6             	xor    %r14d,%r14d
   2ff81:	eb 3e                	jmp    2ffc1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2251>
   2ff83:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ff8a:	84 00 00 00 00 00 
   2ff90:	49 8d 71 01          	lea    0x1(%r9),%rsi
   2ff94:	48 89 d1             	mov    %rdx,%rcx
   2ff97:	48 ff c8             	dec    %rax
   2ff9a:	4a 63 7c 8a 08       	movslq 0x8(%rdx,%r9,4),%rdi
   2ff9f:	49 01 fe             	add    %rdi,%r14
   2ffa2:	4a 63 54 8a 34       	movslq 0x34(%rdx,%r9,4),%rdx
   2ffa7:	49 01 d6             	add    %rdx,%r14
   2ffaa:	41 bd 00 00 00 00    	mov    $0x0,%r13d
   2ffb0:	48 89 b4 24 c0 00 00 	mov    %rsi,0xc0(%rsp)
   2ffb7:	00 
   2ffb8:	48 85 c0             	test   %rax,%rax
   2ffbb:	0f 84 5a 01 00 00    	je     3011b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23ab>
   2ffc1:	48 85 c9             	test   %rcx,%rcx
   2ffc4:	74 2a                	je     2fff0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2280>
   2ffc6:	48 8b b4 24 c0 00 00 	mov    0xc0(%rsp),%rsi
   2ffcd:	00 
   2ffce:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   2ffd2:	48 39 d6             	cmp    %rdx,%rsi
   2ffd5:	0f 83 a5 00 00 00    	jae    30080 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2310>
   2ffdb:	49 89 f1             	mov    %rsi,%r9
   2ffde:	48 89 ca             	mov    %rcx,%rdx
   2ffe1:	e9 b8 00 00 00       	jmp    3009e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x232e>
   2ffe6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2ffed:	00 00 00 
   2fff0:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   2fff7:	00 
   2fff8:	48 85 ff             	test   %rdi,%rdi
   2fffb:	74 35                	je     30032 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22c2>
   2fffd:	48 89 fa             	mov    %rdi,%rdx
   30000:	4c 89 e9             	mov    %r13,%rcx
   30003:	48 83 e2 07          	and    $0x7,%rdx
   30007:	74 2e                	je     30037 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22c7>
   30009:	31 f6                	xor    %esi,%esi
   3000b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30010:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30014:	48 ff c6             	inc    %rsi
   30017:	48 39 f2             	cmp    %rsi,%rdx
   3001a:	75 f4                	jne    30010 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22a0>
   3001c:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   30023:	00 
   30024:	48 89 fa             	mov    %rdi,%rdx
   30027:	48 29 f2             	sub    %rsi,%rdx
   3002a:	48 83 ff 08          	cmp    $0x8,%rdi
   3002e:	73 10                	jae    30040 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22d0>
   30030:	eb 34                	jmp    30066 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22f6>
   30032:	4c 89 e9             	mov    %r13,%rcx
   30035:	eb 2f                	jmp    30066 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22f6>
   30037:	48 89 fa             	mov    %rdi,%rdx
   3003a:	48 83 ff 08          	cmp    $0x8,%rdi
   3003e:	72 26                	jb     30066 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22f6>
   30040:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30044:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30048:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3004c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30050:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30054:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30058:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3005c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30060:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   30064:	75 da                	jne    30040 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22d0>
   30066:	31 f6                	xor    %esi,%esi
   30068:	45 31 ed             	xor    %r13d,%r13d
   3006b:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   3006f:	48 39 d6             	cmp    %rdx,%rsi
   30072:	0f 82 63 ff ff ff    	jb     2ffdb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x226b>
   30078:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3007f:	00 
   30080:	48 8b 11             	mov    (%rcx),%rdx
   30083:	48 85 d2             	test   %rdx,%rdx
   30086:	0f 84 b4 18 00 00    	je     31940 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3bd0>
   3008c:	49 ff c5             	inc    %r13
   3008f:	44 0f b7 49 60       	movzwl 0x60(%rcx),%r9d
   30094:	48 89 d1             	mov    %rdx,%rcx
   30097:	66 44 3b 4a 62       	cmp    0x62(%rdx),%r9w
   3009c:	73 e2                	jae    30080 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2310>
   3009e:	4d 85 ed             	test   %r13,%r13
   300a1:	0f 84 e9 fe ff ff    	je     2ff90 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2220>
   300a7:	4a 8d 34 ca          	lea    (%rdx,%r9,8),%rsi
   300ab:	48 83 c6 70          	add    $0x70,%rsi
   300af:	4c 89 ef             	mov    %r13,%rdi
   300b2:	48 83 e7 07          	and    $0x7,%rdi
   300b6:	74 58                	je     30110 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23a0>
   300b8:	45 31 c0             	xor    %r8d,%r8d
   300bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   300c0:	48 8b 0e             	mov    (%rsi),%rcx
   300c3:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   300c7:	49 ff c0             	inc    %r8
   300ca:	4c 39 c7             	cmp    %r8,%rdi
   300cd:	75 f1                	jne    300c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2350>
   300cf:	4c 89 ef             	mov    %r13,%rdi
   300d2:	4c 29 c7             	sub    %r8,%rdi
   300d5:	49 83 fd 08          	cmp    $0x8,%r13
   300d9:	72 2e                	jb     30109 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2399>
   300db:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   300e0:	48 8b 0e             	mov    (%rsi),%rcx
   300e3:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300e7:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300eb:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300ef:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300f3:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300f7:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300fb:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   300ff:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30103:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
   30107:	75 d7                	jne    300e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2370>
   30109:	31 f6                	xor    %esi,%esi
   3010b:	e9 87 fe ff ff       	jmp    2ff97 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2227>
   30110:	4c 89 ef             	mov    %r13,%rdi
   30113:	49 83 fd 08          	cmp    $0x8,%r13
   30117:	73 c7                	jae    300e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2370>
   30119:	eb ee                	jmp    30109 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2399>
   3011b:	48 8d 84 24 28 02 00 	lea    0x228(%rsp),%rax
   30122:	00 
   30123:	48 89 84 24 68 02 00 	mov    %rax,0x268(%rsp)
   3012a:	00 
   3012b:	48 8d 84 24 20 01 00 	lea    0x120(%rsp),%rax
   30132:	00 
   30133:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
   3013a:	00 
   3013b:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   30142:	00 
   30143:	48 89 84 24 78 02 00 	mov    %rax,0x278(%rsp)
   3014a:	00 
   3014b:	48 8d 84 24 c0 01 00 	lea    0x1c0(%rsp),%rax
   30152:	00 
   30153:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
   3015a:	00 
   3015b:	bd 64 00 00 00       	mov    $0x64,%ebp
   30160:	48 8d 9c 24 68 02 00 	lea    0x268(%rsp),%rbx
   30167:	00 
   30168:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3016f:	00 
   30170:	48 89 df             	mov    %rbx,%rdi
   30173:	e8 c8 d1 ff ff       	call   2d340 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains_0B3_>
   30178:	ff cd                	dec    %ebp
   3017a:	75 f4                	jne    30170 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2400>
   3017c:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
   30183:	00 
   30184:	48 c7 84 24 98 01 00 	movq   $0x0,0x198(%rsp)
   3018b:	00 00 00 00 00 
   30190:	48 c7 84 24 a0 01 00 	movq   $0x8,0x1a0(%rsp)
   30197:	00 08 00 00 00 
   3019c:	48 c7 84 24 a8 01 00 	movq   $0x0,0x1a8(%rsp)
   301a3:	00 00 00 00 00 
   301a8:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
   301ad:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
   301b4:	00 00 00 00 00 
   301b9:	eb 4a                	jmp    30205 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2495>
   301bb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   301c0:	48 8b 84 24 a0 01 00 	mov    0x1a0(%rsp),%rax
   301c7:	00 
   301c8:	48 89 d9             	mov    %rbx,%rcx
   301cb:	48 c1 e1 05          	shl    $0x5,%rcx
   301cf:	f3 0f 6f 84 24 88 00 	movdqu 0x88(%rsp),%xmm0
   301d6:	00 00 
   301d8:	66 0f 10 8c 24 98 00 	movupd 0x98(%rsp),%xmm1
   301df:	00 00 
   301e1:	66 0f 11 4c 08 10    	movupd %xmm1,0x10(%rax,%rcx,1)
   301e7:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
   301ec:	48 ff c3             	inc    %rbx
   301ef:	48 89 9c 24 a8 01 00 	mov    %rbx,0x1a8(%rsp)
   301f6:	00 
   301f7:	4c 39 ac 24 b0 00 00 	cmp    %r13,0xb0(%rsp)
   301fe:	00 
   301ff:	0f 84 50 05 00 00    	je     30755 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x29e5>
   30205:	66 0f ef c0          	pxor   %xmm0,%xmm0
   30209:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   3020f:	bf 02 00 00 00       	mov    $0x2,%edi
   30214:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30219:	ff 15 99 fd 03 00    	call   *0x3fd99(%rip)        # 6ffb8 <clock_gettime@GLIBC_2.17>
   3021f:	89 44 24 60          	mov    %eax,0x60(%rsp)
   30223:	85 c0                	test   %eax,%eax
   30225:	0f 85 98 14 00 00    	jne    316c3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3953>
   3022b:	4c 8b 6c 24 10       	mov    0x10(%rsp),%r13
   30230:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   30235:	bf 01 00 00 00       	mov    $0x1,%edi
   3023a:	e8 a1 2b 02 00       	call   52de0 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   3023f:	48 89 c3             	mov    %rax,%rbx
   30242:	89 d5                	mov    %edx,%ebp
   30244:	48 ff 84 24 b0 00 00 	incq   0xb0(%rsp)
   3024b:	00 
   3024c:	45 31 f6             	xor    %r14d,%r14d
   3024f:	90                   	nop
   30250:	48 8d bc 24 68 02 00 	lea    0x268(%rsp),%rdi
   30257:	00 
   30258:	e8 e3 d0 ff ff       	call   2d340 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains_0B3_>
   3025d:	49 ff c6             	inc    %r14
   30260:	4c 39 74 24 58       	cmp    %r14,0x58(%rsp)
   30265:	75 e9                	jne    30250 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x24e0>
   30267:	bf 01 00 00 00       	mov    $0x1,%edi
   3026c:	e8 6f 2b 02 00       	call   52de0 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   30271:	48 89 84 24 88 00 00 	mov    %rax,0x88(%rsp)
   30278:	00 
   30279:	89 94 24 90 00 00 00 	mov    %edx,0x90(%rsp)
   30280:	48 89 5c 24 60       	mov    %rbx,0x60(%rsp)
   30285:	89 6c 24 68          	mov    %ebp,0x68(%rsp)
   30289:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   3028e:	48 8d b4 24 88 00 00 	lea    0x88(%rsp),%rsi
   30295:	00 
   30296:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   3029b:	e8 80 2a 02 00       	call   52d20 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.4795996092214488023>
   302a0:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
   302a4:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
   302a9:	48 f7 64 24 18       	mulq   0x18(%rsp)
   302ae:	48 89 d3             	mov    %rdx,%rbx
   302b1:	49 89 c6             	mov    %rax,%r14
   302b4:	49 01 ce             	add    %rcx,%r14
   302b7:	48 83 d3 00          	adc    $0x0,%rbx
   302bb:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   302c0:	b8 00 00 00 00       	mov    $0x0,%eax
   302c5:	4c 0f 45 f0          	cmovne %rax,%r14
   302c9:	48 0f 45 d8          	cmovne %rax,%rbx
   302cd:	66 0f ef c0          	pxor   %xmm0,%xmm0
   302d1:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   302d7:	bf 02 00 00 00       	mov    $0x2,%edi
   302dc:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   302e1:	ff 15 d1 fc 03 00    	call   *0x3fcd1(%rip)        # 6ffb8 <clock_gettime@GLIBC_2.17>
   302e7:	89 44 24 60          	mov    %eax,0x60(%rsp)
   302eb:	85 c0                	test   %eax,%eax
   302ed:	0f 85 cb 13 00 00    	jne    316be <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x394e>
   302f3:	4c 89 b4 24 50 01 00 	mov    %r14,0x150(%rsp)
   302fa:	00 
   302fb:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   30300:	4c 89 f9             	mov    %r15,%rcx
   30303:	48 c1 f9 3f          	sar    $0x3f,%rcx
   30307:	4c 89 ea             	mov    %r13,%rdx
   3030a:	48 c1 fa 3f          	sar    $0x3f,%rdx
   3030e:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   30313:	4c 8b 64 24 18       	mov    0x18(%rsp),%r12
   30318:	48 89 c6             	mov    %rax,%rsi
   3031b:	48 c1 fe 3f          	sar    $0x3f,%rsi
   3031f:	4d 89 e6             	mov    %r12,%r14
   30322:	49 c1 fe 3f          	sar    $0x3f,%r14
   30326:	4c 29 e8             	sub    %r13,%rax
   30329:	48 19 d6             	sbb    %rdx,%rsi
   3032c:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
   30331:	48 f7 e2             	mul    %rdx
   30334:	48 69 f6 00 ca 9a 3b 	imul   $0x3b9aca00,%rsi,%rsi
   3033b:	48 01 d6             	add    %rdx,%rsi
   3033e:	4d 29 fc             	sub    %r15,%r12
   30341:	49 19 ce             	sbb    %rcx,%r14
   30344:	49 01 c4             	add    %rax,%r12
   30347:	49 11 f6             	adc    %rsi,%r14
   3034a:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
   30351:	00 00 00 00 00 
   30356:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
   3035d:	00 00 00 00 00 
   30362:	41 bf 0a 00 00 00    	mov    $0xa,%r15d
   30368:	bf 0a 00 00 00       	mov    $0xa,%edi
   3036d:	ff 15 1d f8 03 00    	call   *0x3f81d(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30373:	48 85 c0             	test   %rax,%rax
   30376:	0f 84 d6 15 00 00    	je     31952 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3be2>
   3037c:	48 89 c3             	mov    %rax,%rbx
   3037f:	48 b8 69 74 65 72 61 	movabs $0x6f69746172657469,%rax
   30386:	74 69 6f 
   30389:	48 89 03             	mov    %rax,(%rbx)
   3038c:	66 c7 43 08 6e 73    	movw   $0x736e,0x8(%rbx)
   30392:	48 c7 84 24 28 01 00 	movq   $0xa,0x128(%rsp)
   30399:	00 0a 00 00 00 
   3039e:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   303a5:	00 
   303a6:	48 c7 84 24 38 01 00 	movq   $0xa,0x138(%rsp)
   303ad:	00 0a 00 00 00 
   303b2:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   303b7:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   303bc:	ff 15 46 fb 03 00    	call   *0x3fb46(%rip)        # 6ff08 <_DYNAMIC+0x560>
   303c2:	48 89 c5             	mov    %rax,%rbp
   303c5:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   303c9:	49 f7 df             	neg    %r15
   303cc:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   303d2:	48 83 f8 14          	cmp    $0x14,%rax
   303d6:	74 29                	je     30401 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2691>
   303d8:	4c 89 ff             	mov    %r15,%rdi
   303db:	ff 15 af f7 03 00    	call   *0x3f7af(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   303e1:	48 85 c0             	test   %rax,%rax
   303e4:	0f 84 36 16 00 00    	je     31a20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3cb0>
   303ea:	49 89 c5             	mov    %rax,%r13
   303ed:	48 8d 34 2c          	lea    (%rsp,%rbp,1),%rsi
   303f1:	48 83 c6 10          	add    $0x10,%rsi
   303f5:	48 89 c7             	mov    %rax,%rdi
   303f8:	4c 89 fa             	mov    %r15,%rdx
   303fb:	ff 15 af f7 03 00    	call   *0x3f7af(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   30401:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30406:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   3040b:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30410:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   30415:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
   3041a:	48 89 ef             	mov    %rbp,%rdi
   3041d:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30424:	00 
   30425:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   3042c:	00 
   3042d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30432:	e8 39 1f 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30437:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   3043c:	4c 8b ac 24 58 02 00 	mov    0x258(%rsp),%r13
   30443:	00 
   30444:	74 08                	je     3044e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26de>
   30446:	48 89 ef             	mov    %rbp,%rdi
   30449:	e8 c2 9b ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3044e:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   30454:	bf 06 00 00 00       	mov    $0x6,%edi
   30459:	ff 15 31 f7 03 00    	call   *0x3f731(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   3045f:	48 85 c0             	test   %rax,%rax
   30462:	0f 84 ea 14 00 00    	je     31952 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3be2>
   30468:	48 89 c3             	mov    %rax,%rbx
   3046b:	66 c7 40 04 6e 73    	movw   $0x736e,0x4(%rax)
   30471:	c7 00 63 70 75 5f    	movl   $0x5f757063,(%rax)
   30477:	48 c7 84 24 28 01 00 	movq   $0x6,0x128(%rsp)
   3047e:	00 06 00 00 00 
   30483:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   3048a:	00 
   3048b:	48 c7 84 24 38 01 00 	movq   $0x6,0x138(%rsp)
   30492:	00 06 00 00 00 
   30497:	4c 89 e7             	mov    %r12,%rdi
   3049a:	4c 89 f6             	mov    %r14,%rsi
   3049d:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   304a2:	ff 15 50 fa 03 00    	call   *0x3fa50(%rip)        # 6fef8 <_DYNAMIC+0x550>
   304a8:	49 89 c4             	mov    %rax,%r12
   304ab:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   304af:	49 f7 de             	neg    %r14
   304b2:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   304b8:	48 83 f8 27          	cmp    $0x27,%rax
   304bc:	74 29                	je     304e7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2777>
   304be:	4c 89 f7             	mov    %r14,%rdi
   304c1:	ff 15 c9 f6 03 00    	call   *0x3f6c9(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   304c7:	48 85 c0             	test   %rax,%rax
   304ca:	0f 84 3d 15 00 00    	je     31a0d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c9d>
   304d0:	49 89 c7             	mov    %rax,%r15
   304d3:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   304d7:	48 83 c6 10          	add    $0x10,%rsi
   304db:	48 89 c7             	mov    %rax,%rdi
   304de:	4c 89 f2             	mov    %r14,%rdx
   304e1:	ff 15 c9 f6 03 00    	call   *0x3f6c9(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   304e7:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   304ec:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   304f1:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   304f6:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   304fb:	48 89 ef             	mov    %rbp,%rdi
   304fe:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30505:	00 
   30506:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   3050d:	00 
   3050e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30513:	e8 58 1e 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30518:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   3051d:	74 08                	je     30527 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x27b7>
   3051f:	48 89 ef             	mov    %rbp,%rdi
   30522:	e8 e9 9a ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30527:	41 bf 07 00 00 00    	mov    $0x7,%r15d
   3052d:	bf 07 00 00 00       	mov    $0x7,%edi
   30532:	ff 15 58 f6 03 00    	call   *0x3f658(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30538:	48 85 c0             	test   %rax,%rax
   3053b:	0f 84 11 14 00 00    	je     31952 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3be2>
   30541:	48 89 c3             	mov    %rax,%rbx
   30544:	c7 40 03 6c 5f 6e 73 	movl   $0x736e5f6c,0x3(%rax)
   3054b:	c7 00 77 61 6c 6c    	movl   $0x6c6c6177,(%rax)
   30551:	48 c7 84 24 28 01 00 	movq   $0x7,0x128(%rsp)
   30558:	00 07 00 00 00 
   3055d:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   30564:	00 
   30565:	48 c7 84 24 38 01 00 	movq   $0x7,0x138(%rsp)
   3056c:	00 07 00 00 00 
   30571:	48 8b bc 24 50 01 00 	mov    0x150(%rsp),%rdi
   30578:	00 
   30579:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   3057e:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   30583:	ff 15 6f f9 03 00    	call   *0x3f96f(%rip)        # 6fef8 <_DYNAMIC+0x550>
   30589:	49 89 c4             	mov    %rax,%r12
   3058c:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   30590:	49 f7 de             	neg    %r14
   30593:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30599:	48 83 f8 27          	cmp    $0x27,%rax
   3059d:	74 29                	je     305c8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2858>
   3059f:	4c 89 f7             	mov    %r14,%rdi
   305a2:	ff 15 e8 f5 03 00    	call   *0x3f5e8(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   305a8:	48 85 c0             	test   %rax,%rax
   305ab:	0f 84 82 14 00 00    	je     31a33 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3cc3>
   305b1:	49 89 c7             	mov    %rax,%r15
   305b4:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   305b8:	48 83 c6 10          	add    $0x10,%rsi
   305bc:	48 89 c7             	mov    %rax,%rdi
   305bf:	4c 89 f2             	mov    %r14,%rdx
   305c2:	ff 15 e8 f5 03 00    	call   *0x3f5e8(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   305c8:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   305cd:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   305d2:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   305d7:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   305dc:	48 89 ef             	mov    %rbp,%rdi
   305df:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   305e6:	00 
   305e7:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   305ee:	00 
   305ef:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   305f4:	e8 77 1d 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   305f9:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   305fe:	74 08                	je     30608 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2898>
   30600:	48 89 ef             	mov    %rbp,%rdi
   30603:	e8 08 9a ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30608:	41 bf 10 00 00 00    	mov    $0x10,%r15d
   3060e:	bf 10 00 00 00       	mov    $0x10,%edi
   30613:	ff 15 77 f5 03 00    	call   *0x3f577(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30619:	48 85 c0             	test   %rax,%rax
   3061c:	0f 84 30 13 00 00    	je     31952 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3be2>
   30622:	f3 0f 6f 05 b6 6e fd 	movdqu -0x2914a(%rip),%xmm0        # 74e0 <anon.0f363c1c2085502831f1e7e323c26323.407.llvm.704920437039905144+0x170>
   30629:	ff 
   3062a:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   3062e:	48 c7 84 24 28 01 00 	movq   $0x10,0x128(%rsp)
   30635:	00 10 00 00 00 
   3063a:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   30641:	00 
   30642:	48 c7 84 24 38 01 00 	movq   $0x10,0x138(%rsp)
   30649:	00 10 00 00 00 
   3064e:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
   30653:	48 89 ef             	mov    %rbp,%rdi
   30656:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   3065d:	00 
   3065e:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   30665:	00 
   30666:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   3066b:	e8 00 1d 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30670:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30675:	74 08                	je     3067f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x290f>
   30677:	48 89 ef             	mov    %rbp,%rdi
   3067a:	e8 91 99 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3067f:	41 bf 0f 00 00 00    	mov    $0xf,%r15d
   30685:	bf 0f 00 00 00       	mov    $0xf,%edi
   3068a:	ff 15 00 f5 03 00    	call   *0x3f500(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30690:	48 85 c0             	test   %rax,%rax
   30693:	0f 84 b9 12 00 00    	je     31952 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3be2>
   30699:	48 b9 65 64 5f 62 79 	movabs $0x73657479625f6465,%rcx
   306a0:	74 65 73 
   306a3:	48 89 48 07          	mov    %rcx,0x7(%rax)
   306a7:	48 b9 72 65 71 75 65 	movabs $0x6574736575716572,%rcx
   306ae:	73 74 65 
   306b1:	48 89 08             	mov    %rcx,(%rax)
   306b4:	48 c7 84 24 28 01 00 	movq   $0xf,0x128(%rsp)
   306bb:	00 0f 00 00 00 
   306c0:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   306c7:	00 
   306c8:	48 c7 84 24 38 01 00 	movq   $0xf,0x138(%rsp)
   306cf:	00 0f 00 00 00 
   306d4:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
   306d9:	48 89 ef             	mov    %rbp,%rdi
   306dc:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   306e3:	00 
   306e4:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   306eb:	00 
   306ec:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   306f1:	e8 7a 1c 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   306f6:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   306fb:	74 08                	je     30705 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2995>
   306fd:	48 89 ef             	mov    %rbp,%rdi
   30700:	e8 0b 99 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30705:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   3070c:	00 
   3070d:	48 8d 8c 24 90 00 00 	lea    0x90(%rsp),%rcx
   30714:	00 
   30715:	48 89 41 10          	mov    %rax,0x10(%rcx)
   30719:	0f 10 84 24 d0 00 00 	movups 0xd0(%rsp),%xmm0
   30720:	00 
   30721:	0f 11 01             	movups %xmm0,(%rcx)
   30724:	c6 84 24 88 00 00 00 	movb   $0x5,0x88(%rsp)
   3072b:	05 
   3072c:	48 8b 9c 24 a8 01 00 	mov    0x1a8(%rsp),%rbx
   30733:	00 
   30734:	48 3b 9c 24 98 01 00 	cmp    0x198(%rsp),%rbx
   3073b:	00 
   3073c:	0f 85 7e fa ff ff    	jne    301c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2450>
   30742:	48 8d bc 24 98 01 00 	lea    0x198(%rsp),%rdi
   30749:	00 
   3074a:	ff 15 58 f8 03 00    	call   *0x3f858(%rip)        # 6ffa8 <_DYNAMIC+0x600>
   30750:	e9 6b fa ff ff       	jmp    301c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2450>
   30755:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
   3075c:	00 00 00 00 00 
   30761:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
   30768:	00 00 00 00 00 
   3076d:	41 bd 06 00 00 00    	mov    $0x6,%r13d
   30773:	bf 06 00 00 00       	mov    $0x6,%edi
   30778:	ff 15 12 f4 03 00    	call   *0x3f412(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   3077e:	48 85 c0             	test   %rax,%rax
   30781:	0f 84 d1 12 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30787:	48 89 c3             	mov    %rax,%rbx
   3078a:	66 c7 40 04 6d 61    	movw   $0x616d,0x4(%rax)
   30790:	c7 00 73 63 68 65    	movl   $0x65686373,(%rax)
   30796:	48 c7 84 24 88 00 00 	movq   $0x6,0x88(%rsp)
   3079d:	00 06 00 00 00 
   307a2:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   307a9:	00 
   307aa:	48 c7 84 24 98 00 00 	movq   $0x6,0x98(%rsp)
   307b1:	00 06 00 00 00 
   307b6:	bf 15 00 00 00       	mov    $0x15,%edi
   307bb:	ff 15 cf f3 03 00    	call   *0x3f3cf(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   307c1:	48 85 c0             	test   %rax,%rax
   307c4:	0f 84 f5 13 00 00    	je     31bbf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e4f>
   307ca:	f3 0f 6f 05 ae 8b fd 	movdqu -0x27452(%rip),%xmm0        # 9380 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1b9>
   307d1:	ff 
   307d2:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   307d6:	48 b9 2d 70 72 6f 6f 	movabs $0x312f666f6f72702d,%rcx
   307dd:	66 2f 31 
   307e0:	48 89 48 0d          	mov    %rcx,0xd(%rax)
   307e4:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   307e9:	48 c7 44 24 18 15 00 	movq   $0x15,0x18(%rsp)
   307f0:	00 00 
   307f2:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   307f7:	48 c7 44 24 28 15 00 	movq   $0x15,0x28(%rsp)
   307fe:	00 00 
   30800:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30805:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   3080c:	00 
   3080d:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30814:	00 
   30815:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   3081a:	e8 51 1b 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3081f:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30824:	74 0a                	je     30830 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ac0>
   30826:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3082b:	e8 e0 97 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30830:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   30836:	bf 04 00 00 00       	mov    $0x4,%edi
   3083b:	ff 15 4f f3 03 00    	call   *0x3f34f(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30841:	48 85 c0             	test   %rax,%rax
   30844:	0f 84 0e 12 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   3084a:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   30850:	48 c7 84 24 88 00 00 	movq   $0x4,0x88(%rsp)
   30857:	00 04 00 00 00 
   3085c:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   30863:	00 
   30864:	48 c7 84 24 98 00 00 	movq   $0x4,0x98(%rsp)
   3086b:	00 04 00 00 00 
   30870:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   30877:	00 
   30878:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   3087c:	48 85 db             	test   %rbx,%rbx
   3087f:	74 2d                	je     308ae <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b3e>
   30881:	49 89 c6             	mov    %rax,%r14
   30884:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   30888:	48 89 df             	mov    %rbx,%rdi
   3088b:	ff 15 ff f2 03 00    	call   *0x3f2ff(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30891:	48 85 c0             	test   %rax,%rax
   30894:	0f 84 b9 13 00 00    	je     31c53 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ee3>
   3089a:	49 89 c7             	mov    %rax,%r15
   3089d:	48 89 c7             	mov    %rax,%rdi
   308a0:	4c 89 e6             	mov    %r12,%rsi
   308a3:	48 89 da             	mov    %rbx,%rdx
   308a6:	ff 15 04 f3 03 00    	call   *0x3f304(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   308ac:	eb 06                	jmp    308b4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b44>
   308ae:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   308b4:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   308b9:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   308be:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   308c3:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   308c8:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   308cd:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   308d4:	00 
   308d5:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   308dc:	00 
   308dd:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   308e2:	e8 89 1a 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   308e7:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   308ec:	74 0a                	je     308f8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b88>
   308ee:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   308f3:	e8 18 97 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   308f8:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   308fe:	bf 07 00 00 00       	mov    $0x7,%edi
   30903:	ff 15 87 f2 03 00    	call   *0x3f287(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30909:	48 85 c0             	test   %rax,%rax
   3090c:	0f 84 46 11 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30912:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   30919:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   3091f:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   30926:	00 07 00 00 00 
   3092b:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   30932:	00 
   30933:	48 c7 84 24 98 00 00 	movq   $0x7,0x98(%rsp)
   3093a:	00 07 00 00 00 
   3093f:	48 8b 8c 24 28 02 00 	mov    0x228(%rsp),%rcx
   30946:	00 
   30947:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   3094b:	48 85 db             	test   %rbx,%rbx
   3094e:	74 2d                	je     3097d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c0d>
   30950:	49 89 c6             	mov    %rax,%r14
   30953:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   30957:	48 89 df             	mov    %rbx,%rdi
   3095a:	ff 15 30 f2 03 00    	call   *0x3f230(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30960:	48 85 c0             	test   %rax,%rax
   30963:	0f 84 fa 12 00 00    	je     31c63 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ef3>
   30969:	49 89 c7             	mov    %rax,%r15
   3096c:	48 89 c7             	mov    %rax,%rdi
   3096f:	4c 89 e6             	mov    %r12,%rsi
   30972:	48 89 da             	mov    %rbx,%rdx
   30975:	ff 15 35 f2 03 00    	call   *0x3f235(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   3097b:	eb 06                	jmp    30983 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c13>
   3097d:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30983:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30988:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   3098d:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   30992:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   30997:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3099c:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   309a3:	00 
   309a4:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   309ab:	00 
   309ac:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   309b1:	e8 ba 19 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   309b6:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   309bb:	74 0a                	je     309c7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c57>
   309bd:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   309c2:	e8 49 96 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   309c7:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   309cd:	bf 09 00 00 00       	mov    $0x9,%edi
   309d2:	ff 15 b8 f1 03 00    	call   *0x3f1b8(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   309d8:	48 85 c0             	test   %rax,%rax
   309db:	0f 84 77 10 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   309e1:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   309e8:	74 69 6f 
   309eb:	48 89 08             	mov    %rcx,(%rax)
   309ee:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   309f2:	48 c7 84 24 88 00 00 	movq   $0x9,0x88(%rsp)
   309f9:	00 09 00 00 00 
   309fe:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   30a05:	00 
   30a06:	48 c7 84 24 98 00 00 	movq   $0x9,0x98(%rsp)
   30a0d:	00 09 00 00 00 
   30a12:	48 8b 8c 24 a8 00 00 	mov    0xa8(%rsp),%rcx
   30a19:	00 
   30a1a:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   30a1e:	48 85 db             	test   %rbx,%rbx
   30a21:	74 2d                	je     30a50 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ce0>
   30a23:	49 89 c6             	mov    %rax,%r14
   30a26:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   30a2a:	48 89 df             	mov    %rbx,%rdi
   30a2d:	ff 15 5d f1 03 00    	call   *0x3f15d(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30a33:	48 85 c0             	test   %rax,%rax
   30a36:	0f 84 37 12 00 00    	je     31c73 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f03>
   30a3c:	49 89 c7             	mov    %rax,%r15
   30a3f:	48 89 c7             	mov    %rax,%rdi
   30a42:	4c 89 e6             	mov    %r12,%rsi
   30a45:	48 89 da             	mov    %rbx,%rdx
   30a48:	ff 15 62 f1 03 00    	call   *0x3f162(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   30a4e:	eb 06                	jmp    30a56 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ce6>
   30a50:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30a56:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30a5b:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   30a60:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   30a65:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   30a6a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30a6f:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30a76:	00 
   30a77:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30a7e:	00 
   30a7f:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30a84:	e8 e7 18 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30a89:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30a8e:	74 0a                	je     30a9a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2d2a>
   30a90:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30a95:	e8 76 95 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30a9a:	41 bd 05 00 00 00    	mov    $0x5,%r13d
   30aa0:	bf 05 00 00 00       	mov    $0x5,%edi
   30aa5:	ff 15 e5 f0 03 00    	call   *0x3f0e5(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30aab:	48 85 c0             	test   %rax,%rax
   30aae:	0f 84 a4 0f 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30ab4:	48 89 c3             	mov    %rax,%rbx
   30ab7:	c6 40 04 74          	movb   $0x74,0x4(%rax)
   30abb:	c7 00 69 6e 70 75    	movl   $0x75706e69,(%rax)
   30ac1:	48 c7 84 24 88 00 00 	movq   $0x5,0x88(%rsp)
   30ac8:	00 05 00 00 00 
   30acd:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   30ad4:	00 
   30ad5:	48 c7 84 24 98 00 00 	movq   $0x5,0x98(%rsp)
   30adc:	00 05 00 00 00 
   30ae1:	bf 6b 00 00 00       	mov    $0x6b,%edi
   30ae6:	ff 15 a4 f0 03 00    	call   *0x3f0a4(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30aec:	48 85 c0             	test   %rax,%rax
   30aef:	0f 84 df 10 00 00    	je     31bd4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e64>
   30af5:	0f 10 05 f4 88 fd ff 	movups -0x2770c(%rip),%xmm0        # 93f0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x229>
   30afc:	0f 11 40 5b          	movups %xmm0,0x5b(%rax)
   30b00:	0f 10 05 de 88 fd ff 	movups -0x27722(%rip),%xmm0        # 93e5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x21e>
   30b07:	0f 11 40 50          	movups %xmm0,0x50(%rax)
   30b0b:	0f 10 05 c3 88 fd ff 	movups -0x2773d(%rip),%xmm0        # 93d5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x20e>
   30b12:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   30b16:	0f 10 05 a8 88 fd ff 	movups -0x27758(%rip),%xmm0        # 93c5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1fe>
   30b1d:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   30b21:	0f 10 05 8d 88 fd ff 	movups -0x27773(%rip),%xmm0        # 93b5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1ee>
   30b28:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   30b2c:	0f 10 05 72 88 fd ff 	movups -0x2778e(%rip),%xmm0        # 93a5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1de>
   30b33:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   30b37:	f3 0f 6f 05 56 88 fd 	movdqu -0x277aa(%rip),%xmm0        # 9395 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1ce>
   30b3e:	ff 
   30b3f:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30b43:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30b48:	48 c7 44 24 18 6b 00 	movq   $0x6b,0x18(%rsp)
   30b4f:	00 00 
   30b51:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   30b56:	48 c7 44 24 28 6b 00 	movq   $0x6b,0x28(%rsp)
   30b5d:	00 00 
   30b5f:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30b64:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30b6b:	00 
   30b6c:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30b73:	00 
   30b74:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30b79:	e8 f2 17 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30b7e:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30b83:	74 0a                	je     30b8f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2e1f>
   30b85:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30b8a:	e8 81 94 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30b8f:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   30b95:	bf 07 00 00 00       	mov    $0x7,%edi
   30b9a:	ff 15 f0 ef 03 00    	call   *0x3eff0(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30ba0:	48 85 c0             	test   %rax,%rax
   30ba3:	0f 84 af 0e 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30ba9:	48 89 c3             	mov    %rax,%rbx
   30bac:	c7 40 03 74 72 6f 6c 	movl   $0x6c6f7274,0x3(%rax)
   30bb3:	c7 00 63 6f 6e 74    	movl   $0x746e6f63,(%rax)
   30bb9:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   30bc0:	00 07 00 00 00 
   30bc5:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   30bcc:	00 
   30bcd:	48 c7 84 24 98 00 00 	movq   $0x7,0x98(%rsp)
   30bd4:	00 07 00 00 00 
   30bd9:	bf 53 00 00 00       	mov    $0x53,%edi
   30bde:	ff 15 ac ef 03 00    	call   *0x3efac(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30be4:	48 85 c0             	test   %rax,%rax
   30be7:	0f 84 fc 0f 00 00    	je     31be9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e79>
   30bed:	0f 10 05 4c 88 fd ff 	movups -0x277b4(%rip),%xmm0        # 9440 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x279>
   30bf4:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   30bf8:	0f 10 05 31 88 fd ff 	movups -0x277cf(%rip),%xmm0        # 9430 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x269>
   30bff:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   30c03:	0f 10 05 16 88 fd ff 	movups -0x277ea(%rip),%xmm0        # 9420 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x259>
   30c0a:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   30c0e:	0f 10 05 fb 87 fd ff 	movups -0x27805(%rip),%xmm0        # 9410 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x249>
   30c15:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   30c19:	f3 0f 6f 05 df 87 fd 	movdqu -0x27821(%rip),%xmm0        # 9400 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x239>
   30c20:	ff 
   30c21:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30c25:	c7 40 4f 63 6f 64 65 	movl   $0x65646f63,0x4f(%rax)
   30c2c:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30c31:	48 c7 44 24 18 53 00 	movq   $0x53,0x18(%rsp)
   30c38:	00 00 
   30c3a:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   30c3f:	48 c7 44 24 28 53 00 	movq   $0x53,0x28(%rsp)
   30c46:	00 00 
   30c48:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30c4d:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30c54:	00 
   30c55:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30c5c:	00 
   30c5d:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30c62:	e8 09 17 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30c67:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30c6c:	74 0a                	je     30c78 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2f08>
   30c6e:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30c73:	e8 98 93 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30c78:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   30c7e:	bf 0a 00 00 00       	mov    $0xa,%edi
   30c83:	ff 15 07 ef 03 00    	call   *0x3ef07(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30c89:	48 85 c0             	test   %rax,%rax
   30c8c:	0f 84 c6 0d 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30c92:	48 89 c3             	mov    %rax,%rbx
   30c95:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   30c9c:	62 79 74 
   30c9f:	48 89 03             	mov    %rax,(%rbx)
   30ca2:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   30ca8:	48 c7 84 24 88 00 00 	movq   $0xa,0x88(%rsp)
   30caf:	00 0a 00 00 00 
   30cb4:	48 89 9c 24 90 00 00 	mov    %rbx,0x90(%rsp)
   30cbb:	00 
   30cbc:	48 c7 84 24 98 00 00 	movq   $0xa,0x98(%rsp)
   30cc3:	00 0a 00 00 00 
   30cc8:	4c 8b bc 24 80 01 00 	mov    0x180(%rsp),%r15
   30ccf:	00 
   30cd0:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30cd5:	4c 89 ff             	mov    %r15,%rdi
   30cd8:	ff 15 2a f2 03 00    	call   *0x3f22a(%rip)        # 6ff08 <_DYNAMIC+0x560>
   30cde:	49 89 c4             	mov    %rax,%r12
   30ce1:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   30ce5:	49 f7 de             	neg    %r14
   30ce8:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30cee:	48 83 f8 14          	cmp    $0x14,%rax
   30cf2:	74 29                	je     30d1d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2fad>
   30cf4:	4c 89 f7             	mov    %r14,%rdi
   30cf7:	ff 15 93 ee 03 00    	call   *0x3ee93(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30cfd:	48 85 c0             	test   %rax,%rax
   30d00:	0f 84 8d 0f 00 00    	je     31c93 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f23>
   30d06:	49 89 c5             	mov    %rax,%r13
   30d09:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30d0d:	48 83 c6 10          	add    $0x10,%rsi
   30d11:	48 89 c7             	mov    %rax,%rdi
   30d14:	4c 89 f2             	mov    %r14,%rdx
   30d17:	ff 15 93 ee 03 00    	call   *0x3ee93(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   30d1d:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30d22:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   30d27:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30d2c:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   30d31:	4c 8d 64 24 60       	lea    0x60(%rsp),%r12
   30d36:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30d3d:	00 
   30d3e:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30d45:	00 
   30d46:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30d4b:	4c 89 e7             	mov    %r12,%rdi
   30d4e:	e8 1d 16 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30d53:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30d58:	74 0a                	je     30d64 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ff4>
   30d5a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30d5f:	e8 ac 92 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30d64:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   30d6a:	bf 0c 00 00 00       	mov    $0xc,%edi
   30d6f:	ff 15 1b ee 03 00    	call   *0x3ee1b(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30d75:	48 85 c0             	test   %rax,%rax
   30d78:	0f 84 da 0c 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30d7e:	49 89 c6             	mov    %rax,%r14
   30d81:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   30d88:	9c f2 cb 
   30d8b:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   30d92:	66 6e 76 
   30d95:	49 89 0e             	mov    %rcx,(%r14)
   30d98:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   30d9f:	34 
   30da0:	48 c7 84 24 28 01 00 	movq   $0xc,0x128(%rsp)
   30da7:	00 0c 00 00 00 
   30dac:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   30db3:	00 
   30db4:	48 c7 84 24 38 01 00 	movq   $0xc,0x138(%rsp)
   30dbb:	00 0c 00 00 00 
   30dc0:	48 8b 9c 24 78 01 00 	mov    0x178(%rsp),%rbx
   30dc7:	00 
   30dc8:	4d 85 ff             	test   %r15,%r15
   30dcb:	0f 84 93 00 00 00    	je     30e64 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x30f4>
   30dd1:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   30dd8:	01 00 00 
   30ddb:	44 89 fa             	mov    %r15d,%edx
   30dde:	83 e2 03             	and    $0x3,%edx
   30de1:	49 83 ff 04          	cmp    $0x4,%r15
   30de5:	73 04                	jae    30deb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x307b>
   30de7:	31 f6                	xor    %esi,%esi
   30de9:	eb 53                	jmp    30e3e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x30ce>
   30deb:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   30df2:	ff ff 7f 
   30df5:	48 83 c6 0b          	add    $0xb,%rsi
   30df9:	49 21 f7             	and    %rsi,%r15
   30dfc:	31 f6                	xor    %esi,%esi
   30dfe:	66 90                	xchg   %ax,%ax
   30e00:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   30e04:	48 31 f8             	xor    %rdi,%rax
   30e07:	48 0f af c1          	imul   %rcx,%rax
   30e0b:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   30e10:	48 31 c7             	xor    %rax,%rdi
   30e13:	48 0f af f9          	imul   %rcx,%rdi
   30e17:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   30e1d:	49 31 f8             	xor    %rdi,%r8
   30e20:	4c 0f af c1          	imul   %rcx,%r8
   30e24:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   30e29:	4c 31 c0             	xor    %r8,%rax
   30e2c:	48 0f af c1          	imul   %rcx,%rax
   30e30:	48 83 c6 04          	add    $0x4,%rsi
   30e34:	49 39 f7             	cmp    %rsi,%r15
   30e37:	75 c7                	jne    30e00 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3090>
   30e39:	48 85 d2             	test   %rdx,%rdx
   30e3c:	74 26                	je     30e64 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x30f4>
   30e3e:	48 01 de             	add    %rbx,%rsi
   30e41:	31 ff                	xor    %edi,%edi
   30e43:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30e4a:	84 00 00 00 00 00 
   30e50:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   30e55:	4c 31 c0             	xor    %r8,%rax
   30e58:	48 0f af c1          	imul   %rcx,%rax
   30e5c:	48 ff c7             	inc    %rdi
   30e5f:	48 39 fa             	cmp    %rdi,%rdx
   30e62:	75 ec                	jne    30e50 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x30e0>
   30e64:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   30e69:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   30e6e:	48 8b 05 bb ef 03 00 	mov    0x3efbb(%rip),%rax        # 6fe30 <_DYNAMIC+0x488>
   30e75:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   30e7a:	48 8d 35 8f 74 fd ff 	lea    -0x28b71(%rip),%rsi        # 8310 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   30e81:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
   30e88:	00 
   30e89:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   30e8e:	ff 15 bc ed 03 00    	call   *0x3edbc(%rip)        # 6fc50 <_DYNAMIC+0x2a8>
   30e94:	4c 8b bc 24 90 00 00 	mov    0x90(%rsp),%r15
   30e9b:	00 
   30e9c:	4c 8b a4 24 98 00 00 	mov    0x98(%rsp),%r12
   30ea3:	00 
   30ea4:	4d 85 e4             	test   %r12,%r12
   30ea7:	74 26                	je     30ecf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x315f>
   30ea9:	4c 89 e7             	mov    %r12,%rdi
   30eac:	ff 15 de ec 03 00    	call   *0x3ecde(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30eb2:	48 85 c0             	test   %rax,%rax
   30eb5:	0f 84 c8 0d 00 00    	je     31c83 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f13>
   30ebb:	49 89 c5             	mov    %rax,%r13
   30ebe:	48 89 c7             	mov    %rax,%rdi
   30ec1:	4c 89 fe             	mov    %r15,%rsi
   30ec4:	4c 89 e2             	mov    %r12,%rdx
   30ec7:	ff 15 e3 ec 03 00    	call   *0x3ece3(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   30ecd:	eb 06                	jmp    30ed5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3165>
   30ecf:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30ed5:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30eda:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   30edf:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30ee4:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   30ee9:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30eee:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30ef5:	00 
   30ef6:	48 8d 94 24 28 01 00 	lea    0x128(%rsp),%rdx
   30efd:	00 
   30efe:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30f03:	e8 68 14 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30f08:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   30f0d:	74 0a                	je     30f19 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x31a9>
   30f0f:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30f14:	e8 f7 90 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30f19:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
   30f20:	00 00 
   30f22:	74 09                	je     30f2d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x31bd>
   30f24:	4c 89 ff             	mov    %r15,%rdi
   30f27:	ff 15 73 ec 03 00    	call   *0x3ec73(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   30f2d:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   30f33:	bf 08 00 00 00       	mov    $0x8,%edi
   30f38:	ff 15 52 ec 03 00    	call   *0x3ec52(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30f3e:	48 85 c0             	test   %rax,%rax
   30f41:	0f 84 11 0b 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   30f47:	49 89 c6             	mov    %rax,%r14
   30f4a:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   30f51:	73 75 6d 
   30f54:	49 89 06             	mov    %rax,(%r14)
   30f57:	48 c7 84 24 88 00 00 	movq   $0x8,0x88(%rsp)
   30f5e:	00 08 00 00 00 
   30f63:	4c 89 b4 24 90 00 00 	mov    %r14,0x90(%rsp)
   30f6a:	00 
   30f6b:	48 c7 84 24 98 00 00 	movq   $0x8,0x98(%rsp)
   30f72:	00 08 00 00 00 
   30f77:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30f7c:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   30f83:	00 
   30f84:	ff 15 7e ef 03 00    	call   *0x3ef7e(%rip)        # 6ff08 <_DYNAMIC+0x560>
   30f8a:	49 89 c4             	mov    %rax,%r12
   30f8d:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   30f91:	49 f7 df             	neg    %r15
   30f94:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30f9a:	48 83 f8 14          	cmp    $0x14,%rax
   30f9e:	74 29                	je     30fc9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3259>
   30fa0:	4c 89 ff             	mov    %r15,%rdi
   30fa3:	ff 15 e7 eb 03 00    	call   *0x3ebe7(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   30fa9:	48 85 c0             	test   %rax,%rax
   30fac:	0f 84 f1 0c 00 00    	je     31ca3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f33>
   30fb2:	49 89 c5             	mov    %rax,%r13
   30fb5:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30fb9:	48 83 c6 10          	add    $0x10,%rsi
   30fbd:	48 89 c7             	mov    %rax,%rdi
   30fc0:	4c 89 fa             	mov    %r15,%rdx
   30fc3:	ff 15 e7 eb 03 00    	call   *0x3ebe7(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   30fc9:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30fce:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   30fd3:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30fd8:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   30fdd:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   30fe2:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   30fe9:	00 
   30fea:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   30ff1:	00 
   30ff2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30ff7:	e8 74 13 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30ffc:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   31001:	74 0a                	je     3100d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x329d>
   31003:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   31008:	e8 03 90 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3100d:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   31013:	bf 0b 00 00 00       	mov    $0xb,%edi
   31018:	ff 15 72 eb 03 00    	call   *0x3eb72(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   3101e:	48 85 c0             	test   %rax,%rax
   31021:	0f 84 31 0a 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   31027:	49 89 c6             	mov    %rax,%r14
   3102a:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   31031:	6e 74 72 
   31034:	49 89 06             	mov    %rax,(%r14)
   31037:	41 c7 46 07 72 69 65 	movl   $0x73656972,0x7(%r14)
   3103e:	73 
   3103f:	48 c7 84 24 88 00 00 	movq   $0xb,0x88(%rsp)
   31046:	00 0b 00 00 00 
   3104b:	4c 89 b4 24 90 00 00 	mov    %r14,0x90(%rsp)
   31052:	00 
   31053:	48 c7 84 24 98 00 00 	movq   $0xb,0x98(%rsp)
   3105a:	00 0b 00 00 00 
   3105f:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31064:	48 8b bc 24 88 01 00 	mov    0x188(%rsp),%rdi
   3106b:	00 
   3106c:	ff 15 96 ee 03 00    	call   *0x3ee96(%rip)        # 6ff08 <_DYNAMIC+0x560>
   31072:	49 89 c4             	mov    %rax,%r12
   31075:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31079:	49 f7 df             	neg    %r15
   3107c:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31082:	48 83 f8 14          	cmp    $0x14,%rax
   31086:	74 29                	je     310b1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3341>
   31088:	4c 89 ff             	mov    %r15,%rdi
   3108b:	ff 15 ff ea 03 00    	call   *0x3eaff(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   31091:	48 85 c0             	test   %rax,%rax
   31094:	0f 84 19 0c 00 00    	je     31cb3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f43>
   3109a:	49 89 c5             	mov    %rax,%r13
   3109d:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   310a1:	48 83 c6 10          	add    $0x10,%rsi
   310a5:	48 89 c7             	mov    %rax,%rdi
   310a8:	4c 89 fa             	mov    %r15,%rdx
   310ab:	ff 15 ff ea 03 00    	call   *0x3eaff(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   310b1:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   310b6:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   310bb:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   310c0:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   310c5:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   310ca:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   310d1:	00 
   310d2:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   310d9:	00 
   310da:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   310df:	e8 8c 12 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   310e4:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   310e9:	74 0a                	je     310f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3385>
   310eb:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   310f0:	e8 1b 8f ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   310f5:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   310fb:	bf 0e 00 00 00       	mov    $0xe,%edi
   31100:	ff 15 8a ea 03 00    	call   *0x3ea8a(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   31106:	48 85 c0             	test   %rax,%rax
   31109:	0f 84 49 09 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   3110f:	49 89 c6             	mov    %rax,%r14
   31112:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   31119:	69 65 73 
   3111c:	49 89 46 06          	mov    %rax,0x6(%r14)
   31120:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   31127:	65 5f 65 
   3112a:	49 89 06             	mov    %rax,(%r14)
   3112d:	48 c7 84 24 88 00 00 	movq   $0xe,0x88(%rsp)
   31134:	00 0e 00 00 00 
   31139:	4c 89 b4 24 90 00 00 	mov    %r14,0x90(%rsp)
   31140:	00 
   31141:	48 c7 84 24 98 00 00 	movq   $0xe,0x98(%rsp)
   31148:	00 0e 00 00 00 
   3114d:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31152:	48 8b bc 24 68 01 00 	mov    0x168(%rsp),%rdi
   31159:	00 
   3115a:	ff 15 a8 ed 03 00    	call   *0x3eda8(%rip)        # 6ff08 <_DYNAMIC+0x560>
   31160:	49 89 c4             	mov    %rax,%r12
   31163:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31167:	49 f7 df             	neg    %r15
   3116a:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31170:	48 83 f8 14          	cmp    $0x14,%rax
   31174:	74 29                	je     3119f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x342f>
   31176:	4c 89 ff             	mov    %r15,%rdi
   31179:	ff 15 11 ea 03 00    	call   *0x3ea11(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   3117f:	48 85 c0             	test   %rax,%rax
   31182:	0f 84 3b 0b 00 00    	je     31cc3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f53>
   31188:	49 89 c5             	mov    %rax,%r13
   3118b:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   3118f:	48 83 c6 10          	add    $0x10,%rsi
   31193:	48 89 c7             	mov    %rax,%rdi
   31196:	4c 89 fa             	mov    %r15,%rdx
   31199:	ff 15 11 ea 03 00    	call   *0x3ea11(%rip)        # 6fbb0 <memcpy@GLIBC_2.14>
   3119f:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   311a4:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   311a9:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   311ae:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   311b3:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   311b8:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   311bf:	00 
   311c0:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   311c7:	00 
   311c8:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   311cd:	e8 9e 11 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   311d2:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   311d7:	74 0a                	je     311e3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3473>
   311d9:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   311de:	e8 2d 8e ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   311e3:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   311e9:	bf 12 00 00 00       	mov    $0x12,%edi
   311ee:	ff 15 9c e9 03 00    	call   *0x3e99c(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   311f4:	48 85 c0             	test   %rax,%rax
   311f7:	0f 84 5b 08 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   311fd:	f3 0f 6f 05 4e 82 fd 	movdqu -0x27db2(%rip),%xmm0        # 9453 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x28c>
   31204:	ff 
   31205:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   31209:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   3120f:	48 c7 84 24 88 00 00 	movq   $0x12,0x88(%rsp)
   31216:	00 12 00 00 00 
   3121b:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   31222:	00 
   31223:	48 c7 84 24 98 00 00 	movq   $0x12,0x98(%rsp)
   3122a:	00 12 00 00 00 
   3122f:	66 c7 44 24 10 01 01 	movw   $0x101,0x10(%rsp)
   31236:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3123b:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   31242:	00 
   31243:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   3124a:	00 
   3124b:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   31250:	e8 1b 11 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31255:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   3125a:	74 0a                	je     31266 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x34f6>
   3125c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   31261:	e8 aa 8d ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31266:	41 bd 0f 00 00 00    	mov    $0xf,%r13d
   3126c:	bf 0f 00 00 00       	mov    $0xf,%edi
   31271:	ff 15 19 e9 03 00    	call   *0x3e919(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   31277:	48 85 c0             	test   %rax,%rax
   3127a:	0f 84 d8 07 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   31280:	49 89 c6             	mov    %rax,%r14
   31283:	48 b8 5f 73 74 6f 72 	movabs $0x656761726f74735f,%rax
   3128a:	61 67 65 
   3128d:	49 89 46 07          	mov    %rax,0x7(%r14)
   31291:	48 b8 6d 65 73 73 61 	movabs $0x5f6567617373656d,%rax
   31298:	67 65 5f 
   3129b:	49 89 06             	mov    %rax,(%r14)
   3129e:	48 c7 84 24 88 00 00 	movq   $0xf,0x88(%rsp)
   312a5:	00 0f 00 00 00 
   312aa:	4c 89 b4 24 90 00 00 	mov    %r14,0x90(%rsp)
   312b1:	00 
   312b2:	48 c7 84 24 98 00 00 	movq   $0xf,0x98(%rsp)
   312b9:	00 0f 00 00 00 
   312be:	bf 04 00 00 00       	mov    $0x4,%edi
   312c3:	ff 15 c7 e8 03 00    	call   *0x3e8c7(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   312c9:	48 85 c0             	test   %rax,%rax
   312cc:	0f 84 2c 09 00 00    	je     31bfe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e8e>
   312d2:	c7 00 6c 61 7a 79    	movl   $0x797a616c,(%rax)
   312d8:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   312dd:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   312e4:	00 00 
   312e6:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   312eb:	48 c7 44 24 28 04 00 	movq   $0x4,0x28(%rsp)
   312f2:	00 00 
   312f4:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   312f9:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   31300:	00 
   31301:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   31308:	00 
   31309:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   3130e:	e8 5d 10 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31313:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   31318:	74 0a                	je     31324 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x35b4>
   3131a:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   3131f:	e8 ec 8c ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31324:	41 bd 1a 00 00 00    	mov    $0x1a,%r13d
   3132a:	bf 1a 00 00 00       	mov    $0x1a,%edi
   3132f:	ff 15 5b e8 03 00    	call   *0x3e85b(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   31335:	48 85 c0             	test   %rax,%rax
   31338:	0f 84 1a 07 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   3133e:	0f 10 05 2a 81 fd ff 	movups -0x27ed6(%rip),%xmm0        # 946f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2a8>
   31345:	0f 11 40 0a          	movups %xmm0,0xa(%rax)
   31349:	f3 0f 6f 05 14 81 fd 	movdqu -0x27eec(%rip),%xmm0        # 9465 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x29e>
   31350:	ff 
   31351:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   31355:	48 c7 84 24 88 00 00 	movq   $0x1a,0x88(%rsp)
   3135c:	00 1a 00 00 00 
   31361:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   31368:	00 
   31369:	48 c7 84 24 98 00 00 	movq   $0x1a,0x98(%rsp)
   31370:	00 1a 00 00 00 
   31375:	66 c7 44 24 10 01 00 	movw   $0x1,0x10(%rsp)
   3137c:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   31381:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   31388:	00 
   31389:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   31390:	00 
   31391:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   31396:	e8 d5 0f 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3139b:	80 7c 24 60 ff       	cmpb   $0xff,0x60(%rsp)
   313a0:	74 0a                	je     313ac <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x363c>
   313a2:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   313a7:	e8 64 8c ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   313ac:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   313b2:	bf 07 00 00 00       	mov    $0x7,%edi
   313b7:	ff 15 d3 e7 03 00    	call   *0x3e7d3(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   313bd:	48 85 c0             	test   %rax,%rax
   313c0:	0f 84 92 06 00 00    	je     31a58 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ce8>
   313c6:	49 89 c6             	mov    %rax,%r14
   313c9:	c7 40 03 70 6c 65 73 	movl   $0x73656c70,0x3(%rax)
   313d0:	c7 00 73 61 6d 70    	movl   $0x706d6173,(%rax)
   313d6:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   313dd:	00 07 00 00 00 
   313e2:	48 89 84 24 90 00 00 	mov    %rax,0x90(%rsp)
   313e9:	00 
   313ea:	48 c7 84 24 98 00 00 	movq   $0x7,0x98(%rsp)
   313f1:	00 07 00 00 00 
   313f6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   313fb:	48 8d b4 24 98 01 00 	lea    0x198(%rsp),%rsi
   31402:	00 
   31403:	e8 c8 b9 ff ff       	call   2cdd0 <_RINvYNtNtNtCseZmxtRzJJaS_10serde_json5value3ser10SerializerNtNtCsgX5KCuC7WXX_10serde_core3ser10Serializer11collect_seqRINtNtCsgFX3jaOk65H_5alloc3vec3VecNtB7_5ValueEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31408:	80 7c 24 10 ff       	cmpb   $0xff,0x10(%rsp)
   3140d:	0f 84 98 04 00 00    	je     318ab <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b3b>
   31413:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   31419:	66 0f 10 4c 24 20    	movupd 0x20(%rsp),%xmm1
   3141f:	66 0f 29 4c 24 70    	movapd %xmm1,0x70(%rsp)
   31425:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   3142b:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
   31430:	48 8d b4 24 d0 00 00 	lea    0xd0(%rsp),%rsi
   31437:	00 
   31438:	48 8d 94 24 88 00 00 	lea    0x88(%rsp),%rdx
   3143f:	00 
   31440:	48 8d 4c 24 60       	lea    0x60(%rsp),%rcx
   31445:	4c 89 f7             	mov    %r14,%rdi
   31448:	e8 23 0f 00 00       	call   32370 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3144d:	80 7c 24 10 ff       	cmpb   $0xff,0x10(%rsp)
   31452:	74 0a                	je     3145e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x36ee>
   31454:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31459:	e8 b2 8b ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3145e:	f3 0f 6f 84 24 d0 00 	movdqu 0xd0(%rsp),%xmm0
   31465:	00 00 
   31467:	f3 0f 7f 44 24 18    	movdqu %xmm0,0x18(%rsp)
   3146d:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   31474:	00 
   31475:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   3147a:	c6 44 24 10 05       	movb   $0x5,0x10(%rsp)
   3147f:	4c 89 74 24 60       	mov    %r14,0x60(%rsp)
   31484:	48 8b 05 35 eb 03 00 	mov    0x3eb35(%rip),%rax        # 6ffc0 <_DYNAMIC+0x618>
   3148b:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   31490:	48 8d 3d d1 45 fd ff 	lea    -0x2ba2f(%rip),%rdi        # 5a68 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   31497:	48 8d 74 24 60       	lea    0x60(%rsp),%rsi
   3149c:	ff 15 26 eb 03 00    	call   *0x3eb26(%rip)        # 6ffc8 <_DYNAMIC+0x620>
   314a2:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   314a7:	e8 64 8b ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   314ac:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
   314b3:	00 
   314b4:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
   314bb:	00 
   314bc:	48 85 c0             	test   %rax,%rax
   314bf:	74 24                	je     314e5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3775>
   314c1:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   314c7:	49 29 c5             	sub    %rax,%r13
   314ca:	4d 89 f7             	mov    %r14,%r15
   314cd:	0f 1f 00             	nopl   (%rax)
   314d0:	4c 89 ff             	mov    %r15,%rdi
   314d3:	e8 38 8b ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   314d8:	49 83 c7 20          	add    $0x20,%r15
   314dc:	49 ff c5             	inc    %r13
   314df:	49 83 fd 01          	cmp    $0x1,%r13
   314e3:	75 eb                	jne    314d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3760>
   314e5:	48 83 bc 24 98 01 00 	cmpq   $0x0,0x198(%rsp)
   314ec:	00 00 
   314ee:	74 09                	je     314f9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3789>
   314f0:	4c 89 f7             	mov    %r14,%rdi
   314f3:	ff 15 a7 e6 03 00    	call   *0x3e6a7(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   314f9:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
   31500:	00 00 
   31502:	74 19                	je     3151d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x37ad>
   31504:	48 83 bc 24 f8 00 00 	cmpq   $0x0,0xf8(%rsp)
   3150b:	00 00 
   3150d:	74 0e                	je     3151d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x37ad>
   3150f:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
   31516:	00 
   31517:	ff 15 83 e6 03 00    	call   *0x3e683(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   3151d:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
   31524:	00 
   31525:	e8 76 87 ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3152a:	48 83 bc 24 70 01 00 	cmpq   $0x0,0x170(%rsp)
   31531:	00 00 
   31533:	74 09                	je     3153e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x37ce>
   31535:	48 89 df             	mov    %rbx,%rdi
   31538:	ff 15 62 e6 03 00    	call   *0x3e662(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   3153e:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
   31545:	00 
   31546:	e8 55 87 ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3154b:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   31552:	00 
   31553:	48 85 c9             	test   %rcx,%rcx
   31556:	74 2a                	je     31582 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3812>
   31558:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   3155f:	00 
   31560:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   31564:	48 01 c1             	add    %rax,%rcx
   31567:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   3156b:	74 15                	je     31582 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3812>
   3156d:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
   31574:	00 
   31575:	48 29 c7             	sub    %rax,%rdi
   31578:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   3157c:	ff 15 1e e6 03 00    	call   *0x3e61e(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31582:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
   31589:	00 
   3158a:	e8 11 85 ff ff       	call   29aa0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3158f:	48 83 bc 24 08 02 00 	cmpq   $0x0,0x208(%rsp)
   31596:	00 00 
   31598:	74 0e                	je     315a8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3838>
   3159a:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
   315a1:	00 
   315a2:	ff 15 f8 e5 03 00    	call   *0x3e5f8(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   315a8:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
   315af:	00 
   315b0:	48 83 3b 00          	cmpq   $0x0,(%rbx)
   315b4:	74 0a                	je     315c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3850>
   315b6:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   315ba:	ff 15 e0 e5 03 00    	call   *0x3e5e0(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   315c0:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   315c5:	74 0a                	je     315d1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3861>
   315c7:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   315cb:	ff 15 cf e5 03 00    	call   *0x3e5cf(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   315d1:	48 8b 84 24 48 02 00 	mov    0x248(%rsp),%rax
   315d8:	00 
   315d9:	48 83 38 00          	cmpq   $0x0,(%rax)
   315dd:	74 12                	je     315f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3881>
   315df:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   315e6:	00 
   315e7:	48 8b 78 38          	mov    0x38(%rax),%rdi
   315eb:	ff 15 af e5 03 00    	call   *0x3e5af(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   315f1:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   315f8:	00 
   315f9:	48 83 38 00          	cmpq   $0x0,(%rax)
   315fd:	48 8b 9c 24 a8 00 00 	mov    0xa8(%rsp),%rbx
   31604:	00 
   31605:	74 0a                	je     31611 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38a1>
   31607:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   3160b:	ff 15 8f e5 03 00    	call   *0x3e58f(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31611:	48 83 7b 60 00       	cmpq   $0x0,0x60(%rbx)
   31616:	74 0a                	je     31622 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38b2>
   31618:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
   3161c:	ff 15 7e e5 03 00    	call   *0x3e57e(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31622:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   31627:	74 0d                	je     31636 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38c6>
   31629:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
   31630:	ff 15 6a e5 03 00    	call   *0x3e56a(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31636:	48 83 bc 24 10 02 00 	cmpq   $0x0,0x210(%rsp)
   3163d:	00 00 
   3163f:	74 0e                	je     3164f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38df>
   31641:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   31648:	00 
   31649:	ff 15 51 e5 03 00    	call   *0x3e551(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   3164f:	48 81 c4 88 02 00 00 	add    $0x288,%rsp
   31656:	5b                   	pop    %rbx
   31657:	41 5c                	pop    %r12
   31659:	41 5d                	pop    %r13
   3165b:	41 5e                	pop    %r14
   3165d:	41 5f                	pop    %r15
   3165f:	5d                   	pop    %rbp
   31660:	c3                   	ret
   31661:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   31668:	00 00 
   3166a:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
   31671:	00 00 
   31673:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   31678:	49 39 c7             	cmp    %rax,%r15
   3167b:	0f 86 cd e8 ff ff    	jbe    2ff4e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x21de>
   31681:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31686:	e8 66 8b ff ff       	call   2a1f1 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedTjINtNtB4_6option6OptionjEEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3168b:	e9 41 06 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31690:	b3 01                	mov    $0x1,%bl
   31692:	49 89 f7             	mov    %rsi,%r15
   31695:	bf 40 00 00 00       	mov    $0x40,%edi
   3169a:	ff 15 f0 e4 03 00    	call   *0x3e4f0(%rip)        # 6fb90 <malloc@GLIBC_2.2.5>
   316a0:	48 85 c0             	test   %rax,%rax
   316a3:	0f 85 a8 ce ff ff    	jne    2e551 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7e1>
   316a9:	bf 08 00 00 00       	mov    $0x8,%edi
   316ae:	be 40 00 00 00       	mov    $0x40,%esi
   316b3:	ff 15 1f e5 03 00    	call   *0x3e51f(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   316b9:	e9 13 06 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   316be:	48 8d 6c 24 60       	lea    0x60(%rsp),%rbp
   316c3:	48 8d 15 0a 72 fd ff 	lea    -0x28df6(%rip),%rdx        # 88d4 <_RNvNtNtNtCskADBYZwJmSU_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x84>
   316ca:	4c 8d 0d c7 cc 03 00 	lea    0x3ccc7(%rip),%r9        # 6e398 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x888>
   316d1:	31 ff                	xor    %edi,%edi
   316d3:	48 89 ee             	mov    %rbp,%rsi
   316d6:	31 c9                	xor    %ecx,%ecx
   316d8:	ff 15 f2 e8 03 00    	call   *0x3e8f2(%rip)        # 6ffd0 <_DYNAMIC+0x628>
   316de:	e9 ee 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   316e3:	80 c2 d0             	add    $0xd0,%dl
   316e6:	31 c0                	xor    %eax,%eax
   316e8:	80 fa 0a             	cmp    $0xa,%dl
   316eb:	14 01                	adc    $0x1,%al
   316ed:	eb 02                	jmp    316f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3981>
   316ef:	b0 02                	mov    $0x2,%al
   316f1:	88 44 24 10          	mov    %al,0x10(%rsp)
   316f5:	4c 8d 05 dc ca 03 00 	lea    0x3cadc(%rip),%r8        # 6e1d8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6c8>
   316fc:	eb 19                	jmp    31717 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39a7>
   316fe:	80 c2 d0             	add    $0xd0,%dl
   31701:	31 c0                	xor    %eax,%eax
   31703:	80 fa 0a             	cmp    $0xa,%dl
   31706:	14 01                	adc    $0x1,%al
   31708:	eb 02                	jmp    3170c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399c>
   3170a:	b0 02                	mov    $0x2,%al
   3170c:	88 44 24 10          	mov    %al,0x10(%rsp)
   31710:	4c 8d 05 d9 ca 03 00 	lea    0x3cad9(%rip),%r8        # 6e1f0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6e0>
   31717:	48 8d 3d f8 7d fd ff 	lea    -0x28208(%rip),%rdi        # 9516 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   3171e:	48 8d 0d ab cc 03 00 	lea    0x3ccab(%rip),%rcx        # 6e3d0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8c0>
   31725:	be 2b 00 00 00       	mov    $0x2b,%esi
   3172a:	4c 89 e2             	mov    %r12,%rdx
   3172d:	ff 15 2d e5 03 00    	call   *0x3e52d(%rip)        # 6fc60 <_DYNAMIC+0x2b8>
   31733:	e9 99 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31738:	80 c2 d0             	add    $0xd0,%dl
   3173b:	31 c0                	xor    %eax,%eax
   3173d:	80 fa 0a             	cmp    $0xa,%dl
   31740:	14 01                	adc    $0x1,%al
   31742:	eb 02                	jmp    31746 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d6>
   31744:	b0 02                	mov    $0x2,%al
   31746:	88 44 24 10          	mov    %al,0x10(%rsp)
   3174a:	48 8d 3d c5 7d fd ff 	lea    -0x2823b(%rip),%rdi        # 9516 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   31751:	48 8d 0d 78 cc 03 00 	lea    0x3cc78(%rip),%rcx        # 6e3d0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8c0>
   31758:	4c 8d 05 19 cb 03 00 	lea    0x3cb19(%rip),%r8        # 6e278 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x768>
   3175f:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   31764:	be 2b 00 00 00       	mov    $0x2b,%esi
   31769:	ff 15 f1 e4 03 00    	call   *0x3e4f1(%rip)        # 6fc60 <_DYNAMIC+0x2b8>
   3176f:	e9 5d 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31774:	bf 08 00 00 00       	mov    $0x8,%edi
   31779:	4c 89 e6             	mov    %r12,%rsi
   3177c:	ff 15 a6 e4 03 00    	call   *0x3e4a6(%rip)        # 6fc28 <_DYNAMIC+0x280>
   31782:	e9 4a 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31787:	48 8d 0d aa cc 03 00 	lea    0x3ccaa(%rip),%rcx        # 6e438 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x928>
   3178e:	ba 0b 00 00 00       	mov    $0xb,%edx
   31793:	31 ff                	xor    %edi,%edi
   31795:	4c 89 e6             	mov    %r12,%rsi
   31798:	ff 15 7a e4 03 00    	call   *0x3e47a(%rip)        # 6fc18 <_DYNAMIC+0x270>
   3179e:	e9 2e 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   317a3:	48 8d 0d 2e c8 03 00 	lea    0x3c82e(%rip),%rcx        # 6dfd8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4c8>
   317aa:	ba 0c 00 00 00       	mov    $0xc,%edx
   317af:	31 ff                	xor    %edi,%edi
   317b1:	4c 89 e6             	mov    %r12,%rsi
   317b4:	ff 15 5e e4 03 00    	call   *0x3e45e(%rip)        # 6fc18 <_DYNAMIC+0x270>
   317ba:	e9 12 05 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   317bf:	bf 08 00 00 00       	mov    $0x8,%edi
   317c4:	be 38 00 00 00       	mov    $0x38,%esi
   317c9:	ff 15 59 e4 03 00    	call   *0x3e459(%rip)        # 6fc28 <_DYNAMIC+0x280>
   317cf:	e9 fd 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   317d4:	48 8d 3d 66 7d fd ff 	lea    -0x2829a(%rip),%rdi        # 9541 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x37a>
   317db:	48 8d 15 0e cc 03 00 	lea    0x3cc0e(%rip),%rdx        # 6e3f0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8e0>
   317e2:	be 79 00 00 00       	mov    $0x79,%esi
   317e7:	ff 15 53 e4 03 00    	call   *0x3e453(%rip)        # 6fc40 <_DYNAMIC+0x298>
   317ed:	e9 df 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   317f2:	48 8d 3d 07 7a fd ff 	lea    -0x285f9(%rip),%rdi        # 9200 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   317f9:	48 8d 15 b8 c8 03 00 	lea    0x3c8b8(%rip),%rdx        # 6e0b8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x5a8>
   31800:	be 28 00 00 00       	mov    $0x28,%esi
   31805:	ff 15 55 e5 03 00    	call   *0x3e555(%rip)        # 6fd60 <_DYNAMIC+0x3b8>
   3180b:	e9 c1 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31810:	e8 a0 89 ff ff       	call   2a1b5 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedReBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31815:	e9 b7 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   3181a:	48 8d 0d 17 cc 03 00 	lea    0x3cc17(%rip),%rcx        # 6e438 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x928>
   31821:	ba 0b 00 00 00       	mov    $0xb,%edx
   31826:	31 ff                	xor    %edi,%edi
   31828:	4c 89 e6             	mov    %r12,%rsi
   3182b:	ff 15 e7 e3 03 00    	call   *0x3e3e7(%rip)        # 6fc18 <_DYNAMIC+0x270>
   31831:	e9 9b 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31836:	48 8d 3d cd 7a fd ff 	lea    -0x28533(%rip),%rdi        # 930a <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x143>
   3183d:	48 8d 15 4c ca 03 00 	lea    0x3ca4c(%rip),%rdx        # 6e290 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x780>
   31844:	be 35 00 00 00       	mov    $0x35,%esi
   31849:	ff 15 11 e5 03 00    	call   *0x3e511(%rip)        # 6fd60 <_DYNAMIC+0x3b8>
   3184f:	e9 7d 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31854:	ff 15 7e e7 03 00    	call   *0x3e77e(%rip)        # 6ffd8 <_DYNAMIC+0x630>
   3185a:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   3185f:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   31864:	e9 3b d1 ff ff       	jmp    2e9a4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc34>
   31869:	48 8d 15 38 ca 03 00 	lea    0x3ca38(%rip),%rdx        # 6e2a8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x798>
   31870:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
   31877:	00 
   31878:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   3187f:	00 
   31880:	e8 ff 88 ff ff       	call   2a184 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31885:	e9 47 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   3188a:	48 8d 15 2f ca 03 00 	lea    0x3ca2f(%rip),%rdx        # 6e2c0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7b0>
   31891:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   31898:	00 
   31899:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   318a0:	00 
   318a1:	e8 de 88 ff ff       	call   2a184 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   318a6:	e9 26 04 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   318ab:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   318b0:	48 89 44 24 60       	mov    %rax,0x60(%rsp)
   318b5:	48 8d 3d 5a 7c fd ff 	lea    -0x283a6(%rip),%rdi        # 9516 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   318bc:	48 8d 0d ed ca 03 00 	lea    0x3caed(%rip),%rcx        # 6e3b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8a0>
   318c3:	4c 8d 05 3e ca 03 00 	lea    0x3ca3e(%rip),%r8        # 6e308 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7f8>
   318ca:	48 8d 54 24 60       	lea    0x60(%rsp),%rdx
   318cf:	be 2b 00 00 00       	mov    $0x2b,%esi
   318d4:	ff 15 86 e3 03 00    	call   *0x3e386(%rip)        # 6fc60 <_DYNAMIC+0x2b8>
   318da:	e9 f2 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   318df:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   318e6:	00 
   318e7:	48 83 fe 15          	cmp    $0x15,%rsi
   318eb:	0f 83 e2 03 00 00    	jae    31cd3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f63>
   318f1:	e8 ca 8e ff ff       	call   2a7c0 <_RINvNtNtNtNtCskADBYZwJmSU_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB1y_11collections5btree3mapINtB2l_8BTreeMapllEINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEE0E0ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   318f6:	e9 ec e0 ff ff       	jmp    2f9e7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c77>
   318fb:	bf 08 00 00 00       	mov    $0x8,%edi
   31900:	be c8 00 00 00       	mov    $0xc8,%esi
   31905:	ff 15 1d e3 03 00    	call   *0x3e31d(%rip)        # 6fc28 <_DYNAMIC+0x280>
   3190b:	e9 c1 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31910:	48 8d 3d a9 c6 03 00 	lea    0x3c6a9(%rip),%rdi        # 6dfc0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4b0>
   31917:	ff 15 1b e4 03 00    	call   *0x3e41b(%rip)        # 6fd38 <_DYNAMIC+0x390>
   3191d:	e9 af 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31922:	48 8d 3d 94 7c fd ff 	lea    -0x2836c(%rip),%rdi        # 95bd <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3f6>
   31929:	48 8d 15 20 cb 03 00 	lea    0x3cb20(%rip),%rdx        # 6e450 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x940>
   31930:	be 30 00 00 00       	mov    $0x30,%esi
   31935:	ff 15 25 e4 03 00    	call   *0x3e425(%rip)        # 6fd60 <_DYNAMIC+0x3b8>
   3193b:	e9 91 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31940:	48 8d 3d 79 c8 03 00 	lea    0x3c879(%rip),%rdi        # 6e1c0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6b0>
   31947:	ff 15 eb e3 03 00    	call   *0x3e3eb(%rip)        # 6fd38 <_DYNAMIC+0x390>
   3194d:	e9 7f 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31952:	bf 01 00 00 00       	mov    $0x1,%edi
   31957:	4c 89 fe             	mov    %r15,%rsi
   3195a:	ff 15 78 e2 03 00    	call   *0x3e278(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31960:	e9 6c 03 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31965:	4c 89 e7             	mov    %r12,%rdi
   31968:	4c 89 f6             	mov    %r14,%rsi
   3196b:	4c 89 fa             	mov    %r15,%rdx
   3196e:	e8 b9 72 ff ff       	call   28c2c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31973:	e9 25 e0 ff ff       	jmp    2f99d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c2d>
   31978:	4c 89 e3             	mov    %r12,%rbx
   3197b:	49 89 c7             	mov    %rax,%r15
   3197e:	48 89 c7             	mov    %rax,%rdi
   31981:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   31986:	e8 c5 89 ff ff       	call   2a350 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB2U_8adapters3map3MapINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map4IterllENCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains0_0EE0E0INtNtB1b_3vec3VecBZ_EEB5c_>
   3198b:	4c 89 f8             	mov    %r15,%rax
   3198e:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   31993:	49 89 dc             	mov    %rbx,%r12
   31996:	e9 35 e3 ff ff       	jmp    2fcd0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f60>
   3199b:	48 89 ef             	mov    %rbp,%rdi
   3199e:	4c 89 e6             	mov    %r12,%rsi
   319a1:	4c 89 fa             	mov    %r15,%rdx
   319a4:	e8 83 72 ff ff       	call   28c2c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   319a9:	e9 ad e3 ff ff       	jmp    2fd5b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1feb>
   319ae:	b0 01                	mov    $0x1,%al
   319b0:	e9 57 fd ff ff       	jmp    3170c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399c>
   319b5:	b0 01                	mov    $0x1,%al
   319b7:	e9 35 fd ff ff       	jmp    316f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3981>
   319bc:	b0 01                	mov    $0x1,%al
   319be:	e9 83 fd ff ff       	jmp    31746 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d6>
   319c3:	4c 89 bc 24 e8 00 00 	mov    %r15,0xe8(%rsp)
   319ca:	00 
   319cb:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   319d0:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   319d7:	00 
   319d8:	48 89 ac 24 f8 00 00 	mov    %rbp,0xf8(%rsp)
   319df:	00 
   319e0:	48 8d 3d 79 a4 fd ff 	lea    -0x25b87(%rip),%rdi        # be60 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   319e7:	48 8d 0d 42 d7 03 00 	lea    0x3d742(%rip),%rcx        # 6f130 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   319ee:	4c 8d 05 eb d6 03 00 	lea    0x3d6eb(%rip),%r8        # 6f0e0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   319f5:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   319fc:	00 
   319fd:	be 2b 00 00 00       	mov    $0x2b,%esi
   31a02:	ff 15 58 e2 03 00    	call   *0x3e258(%rip)        # 6fc60 <_DYNAMIC+0x2b8>
   31a08:	e9 c4 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a0d:	bf 01 00 00 00       	mov    $0x1,%edi
   31a12:	4c 89 f6             	mov    %r14,%rsi
   31a15:	ff 15 bd e1 03 00    	call   *0x3e1bd(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31a1b:	e9 b1 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a20:	bf 01 00 00 00       	mov    $0x1,%edi
   31a25:	4c 89 fe             	mov    %r15,%rsi
   31a28:	ff 15 aa e1 03 00    	call   *0x3e1aa(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31a2e:	e9 9e 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a33:	bf 01 00 00 00       	mov    $0x1,%edi
   31a38:	4c 89 f6             	mov    %r14,%rsi
   31a3b:	ff 15 97 e1 03 00    	call   *0x3e197(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31a41:	e9 8b 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a46:	48 8d 3d 03 c9 03 00 	lea    0x3c903(%rip),%rdi        # 6e350 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x840>
   31a4d:	ff 15 5d e3 03 00    	call   *0x3e35d(%rip)        # 6fdb0 <_DYNAMIC+0x408>
   31a53:	e9 79 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a58:	bf 01 00 00 00       	mov    $0x1,%edi
   31a5d:	4c 89 ee             	mov    %r13,%rsi
   31a60:	ff 15 72 e1 03 00    	call   *0x3e172(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31a66:	e9 66 02 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31a6b:	be 28 00 00 00       	mov    $0x28,%esi
   31a70:	4c 8d 3d 4c 7a fd ff 	lea    -0x285b4(%rip),%r15        # 94c3 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2fc>
   31a77:	4c 8d 25 ba c8 03 00 	lea    0x3c8ba(%rip),%r12        # 6e338 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x828>
   31a7e:	e9 23 e4 ff ff       	jmp    2fea6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2136>
   31a83:	49 89 ed             	mov    %rbp,%r13
   31a86:	4c 89 f8             	mov    %r15,%rax
   31a89:	4c 29 e8             	sub    %r13,%rax
   31a8c:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   31a93:	aa aa aa 
   31a96:	48 f7 e1             	mul    %rcx
   31a99:	4d 39 ef             	cmp    %r13,%r15
   31a9c:	0f 85 a9 00 00 00    	jne    31b4b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3ddb>
   31aa2:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   31aa9:	00 00 
   31aab:	74 0e                	je     31abb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d4b>
   31aad:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
   31ab4:	00 
   31ab5:	ff 15 e5 e0 03 00    	call   *0x3e0e5(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31abb:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   31ac2:	00 00 
   31ac4:	b8 08 00 00 00       	mov    $0x8,%eax
   31ac9:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   31ad0:	00 
   31ad1:	48 c7 84 24 10 02 00 	movq   $0x0,0x210(%rsp)
   31ad8:	00 00 00 00 00 
   31add:	45 31 f6             	xor    %r14d,%r14d
   31ae0:	48 8d 15 39 68 fd ff 	lea    -0x297c7(%rip),%rdx        # 8320 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x20d>
   31ae7:	48 8d 0d fd 79 fd ff 	lea    -0x28603(%rip),%rcx        # 94eb <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x324>
   31aee:	4c 8d 0d 8b c8 03 00 	lea    0x3c88b(%rip),%r9        # 6e380 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x870>
   31af5:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31afa:	41 b8 45 00 00 00    	mov    $0x45,%r8d
   31b00:	31 ff                	xor    %edi,%edi
   31b02:	ff 15 88 e1 03 00    	call   *0x3e188(%rip)        # 6fc90 <_DYNAMIC+0x2e8>
   31b08:	e9 c4 01 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31b0d:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   31b12:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   31b17:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   31b1c:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   31b21:	48 8d 3d 38 a3 fd ff 	lea    -0x25cc8(%rip),%rdi        # be60 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   31b28:	48 8d 0d 01 d6 03 00 	lea    0x3d601(%rip),%rcx        # 6f130 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   31b2f:	4c 8d 05 aa d5 03 00 	lea    0x3d5aa(%rip),%r8        # 6f0e0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   31b36:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   31b3b:	be 2b 00 00 00       	mov    $0x2b,%esi
   31b40:	ff 15 1a e1 03 00    	call   *0x3e11a(%rip)        # 6fc60 <_DYNAMIC+0x2b8>
   31b46:	e9 86 01 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31b4b:	48 89 d3             	mov    %rdx,%rbx
   31b4e:	48 c1 eb 04          	shr    $0x4,%rbx
   31b52:	49 83 c5 08          	add    $0x8,%r13
   31b56:	4c 8b 35 43 e0 03 00 	mov    0x3e043(%rip),%r14        # 6fba0 <free@GLIBC_2.2.5>
   31b5d:	eb 0e                	jmp    31b6d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3dfd>
   31b5f:	90                   	nop
   31b60:	49 83 c5 18          	add    $0x18,%r13
   31b64:	48 ff cb             	dec    %rbx
   31b67:	0f 84 35 ff ff ff    	je     31aa2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d32>
   31b6d:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   31b72:	74 ec                	je     31b60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3df0>
   31b74:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   31b78:	41 ff d6             	call   *%r14
   31b7b:	eb e3                	jmp    31b60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3df0>
   31b7d:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   31b84:	00 00 
   31b86:	b8 04 00 00 00       	mov    $0x4,%eax
   31b8b:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
   31b92:	00 
   31b93:	48 8d 15 b6 67 fd ff 	lea    -0x2984a(%rip),%rdx        # 8350 <anon.574165b9a1e3cebd535338bb0d7973a0.751.llvm.2316785571840406366+0x20>
   31b9a:	4c 8d 0d c7 c7 03 00 	lea    0x3c7c7(%rip),%r9        # 6e368 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x858>
   31ba1:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31ba6:	31 ff                	xor    %edi,%edi
   31ba8:	31 c9                	xor    %ecx,%ecx
   31baa:	ff 15 e0 e0 03 00    	call   *0x3e0e0(%rip)        # 6fc90 <_DYNAMIC+0x2e8>
   31bb0:	e9 1c 01 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31bb5:	bf 08 00 00 00       	mov    $0x8,%edi
   31bba:	e9 6f c2 ff ff       	jmp    2de2e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xbe>
   31bbf:	bf 01 00 00 00       	mov    $0x1,%edi
   31bc4:	be 15 00 00 00       	mov    $0x15,%esi
   31bc9:	ff 15 09 e0 03 00    	call   *0x3e009(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31bcf:	e9 fd 00 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31bd4:	bf 01 00 00 00       	mov    $0x1,%edi
   31bd9:	be 6b 00 00 00       	mov    $0x6b,%esi
   31bde:	ff 15 f4 df 03 00    	call   *0x3dff4(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31be4:	e9 e8 00 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31be9:	bf 01 00 00 00       	mov    $0x1,%edi
   31bee:	be 53 00 00 00       	mov    $0x53,%esi
   31bf3:	ff 15 df df 03 00    	call   *0x3dfdf(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31bf9:	e9 d3 00 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31bfe:	bf 01 00 00 00       	mov    $0x1,%edi
   31c03:	be 04 00 00 00       	mov    $0x4,%esi
   31c08:	ff 15 ca df 03 00    	call   *0x3dfca(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31c0e:	e9 be 00 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c13:	31 c0                	xor    %eax,%eax
   31c15:	e9 d7 fa ff ff       	jmp    316f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3981>
   31c1a:	31 c0                	xor    %eax,%eax
   31c1c:	e9 eb fa ff ff       	jmp    3170c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x399c>
   31c21:	be 2f 00 00 00       	mov    $0x2f,%esi
   31c26:	48 89 ca             	mov    %rcx,%rdx
   31c29:	ff 15 31 e1 03 00    	call   *0x3e131(%rip)        # 6fd60 <_DYNAMIC+0x3b8>
   31c2f:	e9 9d 00 00 00       	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c34:	31 c0                	xor    %eax,%eax
   31c36:	e9 0b fb ff ff       	jmp    31746 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x39d6>
   31c3b:	4c 8d 25 ae c6 03 00 	lea    0x3c6ae(%rip),%r12        # 6e2f0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7e0>
   31c42:	be 28 00 00 00       	mov    $0x28,%esi
   31c47:	4c 8d 3d 0a 77 fd ff 	lea    -0x288f6(%rip),%r15        # 9358 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x191>
   31c4e:	e9 53 e2 ff ff       	jmp    2fea6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2136>
   31c53:	bf 01 00 00 00       	mov    $0x1,%edi
   31c58:	48 89 de             	mov    %rbx,%rsi
   31c5b:	ff 15 77 df 03 00    	call   *0x3df77(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31c61:	eb 6e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c63:	bf 01 00 00 00       	mov    $0x1,%edi
   31c68:	48 89 de             	mov    %rbx,%rsi
   31c6b:	ff 15 67 df 03 00    	call   *0x3df67(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31c71:	eb 5e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c73:	bf 01 00 00 00       	mov    $0x1,%edi
   31c78:	48 89 de             	mov    %rbx,%rsi
   31c7b:	ff 15 57 df 03 00    	call   *0x3df57(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31c81:	eb 4e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c83:	bf 01 00 00 00       	mov    $0x1,%edi
   31c88:	4c 89 e6             	mov    %r12,%rsi
   31c8b:	ff 15 47 df 03 00    	call   *0x3df47(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31c91:	eb 3e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31c93:	bf 01 00 00 00       	mov    $0x1,%edi
   31c98:	4c 89 f6             	mov    %r14,%rsi
   31c9b:	ff 15 37 df 03 00    	call   *0x3df37(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31ca1:	eb 2e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31ca3:	bf 01 00 00 00       	mov    $0x1,%edi
   31ca8:	4c 89 fe             	mov    %r15,%rsi
   31cab:	ff 15 27 df 03 00    	call   *0x3df27(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31cb1:	eb 1e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31cb3:	bf 01 00 00 00       	mov    $0x1,%edi
   31cb8:	4c 89 fe             	mov    %r15,%rsi
   31cbb:	ff 15 17 df 03 00    	call   *0x3df17(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31cc1:	eb 0e                	jmp    31cd1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f61>
   31cc3:	bf 01 00 00 00       	mov    $0x1,%edi
   31cc8:	4c 89 fe             	mov    %r15,%rsi
   31ccb:	ff 15 07 df 03 00    	call   *0x3df07(%rip)        # 6fbd8 <_DYNAMIC+0x230>
   31cd1:	0f 0b                	ud2
   31cd3:	49 89 fe             	mov    %rdi,%r14
   31cd6:	e8 65 85 ff ff       	call   2a240 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEE0E0INtNtB1b_3vec3VecBZ_EECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31cdb:	e9 07 dd ff ff       	jmp    2f9e7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c77>
   31ce0:	49 89 c4             	mov    %rax,%r12
   31ce3:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
   31cea:	00 00 
   31cec:	0f 84 e1 03 00 00    	je     320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31cf2:	4c 89 f7             	mov    %r14,%rdi
   31cf5:	ff 15 a5 de 03 00    	call   *0x3dea5(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31cfb:	e9 d3 03 00 00       	jmp    320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31d00:	49 89 c4             	mov    %rax,%r12
   31d03:	48 85 db             	test   %rbx,%rbx
   31d06:	0f 84 ba 03 00 00    	je     320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   31d0c:	4c 89 ff             	mov    %r15,%rdi
   31d0f:	e9 53 03 00 00       	jmp    32067 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42f7>
   31d14:	49 89 c4             	mov    %rax,%r12
   31d17:	e9 14 04 00 00       	jmp    32130 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43c0>
   31d1c:	49 89 c4             	mov    %rax,%r12
   31d1f:	4c 89 f7             	mov    %r14,%rdi
   31d22:	ff 15 78 de 03 00    	call   *0x3de78(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31d28:	eb 54                	jmp    31d7e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x400e>
   31d2a:	e9 91 00 00 00       	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d2f:	e9 8c 00 00 00       	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d34:	e9 87 00 00 00       	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d39:	eb 40                	jmp    31d7b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x400b>
   31d3b:	49 89 c4             	mov    %rax,%r12
   31d3e:	e9 b6 03 00 00       	jmp    320f9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4389>
   31d43:	49 89 c4             	mov    %rax,%r12
   31d46:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31d4b:	e8 c0 82 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31d50:	e9 a1 02 00 00       	jmp    31ff6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4286>
   31d55:	e9 92 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d5a:	eb 64                	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d5c:	eb 6a                	jmp    31dc8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4058>
   31d5e:	eb 68                	jmp    31dc8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4058>
   31d60:	eb 5e                	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d62:	e9 85 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d67:	e9 80 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d6c:	e9 7b 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d71:	e9 76 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d76:	e9 71 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d7b:	49 89 c4             	mov    %rax,%r12
   31d7e:	48 83 bc 24 88 00 00 	cmpq   $0x0,0x88(%rsp)
   31d85:	00 00 
   31d87:	0f 84 e8 01 00 00    	je     31f75 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4205>
   31d8d:	4c 89 ff             	mov    %r15,%rdi
   31d90:	e9 da 01 00 00       	jmp    31f6f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41ff>
   31d95:	eb 29                	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31d97:	e9 50 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31d9c:	e9 4b 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31da1:	e9 46 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31da6:	e9 41 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31dab:	eb 1b                	jmp    31dc8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4058>
   31dad:	e9 3a 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31db2:	e9 35 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31db7:	e9 30 01 00 00       	jmp    31eec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x417c>
   31dbc:	eb 02                	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31dbe:	eb 00                	jmp    31dc0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4050>
   31dc0:	49 89 c4             	mov    %rax,%r12
   31dc3:	e9 a4 01 00 00       	jmp    31f6c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41fc>
   31dc8:	49 89 c4             	mov    %rax,%r12
   31dcb:	48 89 df             	mov    %rbx,%rdi
   31dce:	e9 9c 01 00 00       	jmp    31f6f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41ff>
   31dd3:	49 89 c4             	mov    %rax,%r12
   31dd6:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31ddc:	0f 84 d3 03 00 00    	je     321b5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4445>
   31de2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31de7:	e9 c3 03 00 00       	jmp    321af <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x443f>
   31dec:	e9 b1 03 00 00       	jmp    321a2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4432>
   31df1:	49 89 c4             	mov    %rax,%r12
   31df4:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31dfa:	0f 84 c6 02 00 00    	je     320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   31e00:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31e05:	e9 5d 02 00 00       	jmp    32067 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42f7>
   31e0a:	49 89 c4             	mov    %rax,%r12
   31e0d:	4d 85 f6             	test   %r14,%r14
   31e10:	0f 85 46 03 00 00    	jne    3215c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43ec>
   31e16:	48 83 bc 24 10 02 00 	cmpq   $0x0,0x210(%rsp)
   31e1d:	00 00 
   31e1f:	0f 84 b3 03 00 00    	je     321d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4468>
   31e25:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   31e2c:	00 
   31e2d:	ff 15 6d dd 03 00    	call   *0x3dd6d(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31e33:	4c 89 e7             	mov    %r12,%rdi
   31e36:	e8 35 a6 03 00       	call   6c470 <_Unwind_Resume@plt>
   31e3b:	eb 4c                	jmp    31e89 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4119>
   31e3d:	e9 a4 01 00 00       	jmp    31fe6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4276>
   31e42:	e9 86 01 00 00       	jmp    31fcd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x425d>
   31e47:	e9 d5 00 00 00       	jmp    31f21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41b1>
   31e4c:	e9 d0 00 00 00       	jmp    31f21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41b1>
   31e51:	49 89 c4             	mov    %rax,%r12
   31e54:	48 8d bc 24 88 00 00 	lea    0x88(%rsp),%rdi
   31e5b:	00 
   31e5c:	e8 af 81 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31e61:	e9 90 01 00 00       	jmp    31ff6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4286>
   31e66:	ff 15 dc dd 03 00    	call   *0x3dddc(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   31e6c:	e9 b0 00 00 00       	jmp    31f21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41b1>
   31e71:	49 89 c4             	mov    %rax,%r12
   31e74:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
   31e7b:	00 00 
   31e7d:	74 1d                	je     31e9c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x412c>
   31e7f:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   31e86:	00 
   31e87:	eb 0d                	jmp    31e96 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4126>
   31e89:	49 89 c4             	mov    %rax,%r12
   31e8c:	4d 85 ff             	test   %r15,%r15
   31e8f:	74 0b                	je     31e9c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x412c>
   31e91:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   31e96:	ff 15 04 dd 03 00    	call   *0x3dd04(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31e9c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31ea1:	e8 7a 80 ff ff       	call   29f20 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCs8ZKwes1zzDd_3std3env4ArgsECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31ea6:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   31eab:	e8 d0 7c ff ff       	call   29b80 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsgFX3jaOk65H_5alloc3vec3VecNtNtBG_6string6StringEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31eb0:	4c 89 e7             	mov    %r12,%rdi
   31eb3:	e8 b8 a5 03 00       	call   6c470 <_Unwind_Resume@plt>
   31eb8:	49 89 c4             	mov    %rax,%r12
   31ebb:	4d 85 ed             	test   %r13,%r13
   31ebe:	0f 84 71 01 00 00    	je     32035 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42c5>
   31ec4:	49 83 c7 20          	add    $0x20,%r15
   31ec8:	49 f7 dd             	neg    %r13
   31ecb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   31ed0:	4c 89 ff             	mov    %r15,%rdi
   31ed3:	e8 38 81 ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31ed8:	49 83 c7 20          	add    $0x20,%r15
   31edc:	49 ff cd             	dec    %r13
   31edf:	75 ef                	jne    31ed0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4160>
   31ee1:	e9 4f 01 00 00       	jmp    32035 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42c5>
   31ee6:	ff 15 5c dd 03 00    	call   *0x3dd5c(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   31eec:	49 89 c4             	mov    %rax,%r12
   31eef:	e9 81 00 00 00       	jmp    31f75 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4205>
   31ef4:	49 89 c4             	mov    %rax,%r12
   31ef7:	41 be 06 00 00 00    	mov    $0x6,%r14d
   31efd:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31f03:	0f 84 53 02 00 00    	je     3215c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43ec>
   31f09:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31f0e:	e9 43 02 00 00       	jmp    32156 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43e6>
   31f13:	eb 26                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f15:	eb 24                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f17:	eb 22                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f19:	eb 06                	jmp    31f21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41b1>
   31f1b:	eb 1e                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f1d:	eb 02                	jmp    31f21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41b1>
   31f1f:	eb 1a                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f21:	49 89 c4             	mov    %rax,%r12
   31f24:	48 89 df             	mov    %rbx,%rdi
   31f27:	ff 15 73 dc 03 00    	call   *0x3dc73(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31f2d:	eb 0f                	jmp    31f3e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41ce>
   31f2f:	e9 b2 00 00 00       	jmp    31fe6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4276>
   31f34:	e9 ba 00 00 00       	jmp    31ff3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4283>
   31f39:	eb 00                	jmp    31f3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41cb>
   31f3b:	49 89 c4             	mov    %rax,%r12
   31f3e:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
   31f45:	00 
   31f46:	e8 a5 1c 00 00       	call   33bf0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f4b:	e9 a6 00 00 00       	jmp    31ff6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4286>
   31f50:	0f 0b                	ud2
   31f52:	4c 89 e7             	mov    %r12,%rdi
   31f55:	ff 15 45 dc 03 00    	call   *0x3dc45(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31f5b:	0f 0b                	ud2
   31f5d:	0f 0b                	ud2
   31f5f:	49 89 c4             	mov    %rax,%r12
   31f62:	48 8d 7c 24 60       	lea    0x60(%rsp),%rdi
   31f67:	e8 34 80 ff ff       	call   29fa0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5error5ErrorECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f6c:	4c 89 f7             	mov    %r14,%rdi
   31f6f:	ff 15 2b dc 03 00    	call   *0x3dc2b(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31f75:	48 8d bc 24 d0 00 00 	lea    0xd0(%rsp),%rdi
   31f7c:	00 
   31f7d:	e8 6e 1c 00 00       	call   33bf0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f82:	eb 72                	jmp    31ff6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4286>
   31f84:	ff 15 be dc 03 00    	call   *0x3dcbe(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   31f8a:	49 89 c4             	mov    %rax,%r12
   31f8d:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   31f94:	00 
   31f95:	e8 06 7d ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f9a:	e9 27 01 00 00       	jmp    320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   31f9f:	eb 52                	jmp    31ff3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4283>
   31fa1:	eb 32                	jmp    31fd5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4265>
   31fa3:	49 89 c4             	mov    %rax,%r12
   31fa6:	41 c7 47 30 03 00 00 	movl   $0x3,0x30(%r15)
   31fad:	00 
   31fae:	e9 20 01 00 00       	jmp    320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31fb3:	49 89 c4             	mov    %rax,%r12
   31fb6:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31fbb:	e8 70 7b ff ff       	call   29b30 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map8MapInnerllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31fc0:	e9 0e 01 00 00       	jmp    320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31fc5:	ff 15 7d dc 03 00    	call   *0x3dc7d(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   31fcb:	eb 08                	jmp    31fd5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4265>
   31fcd:	49 89 c4             	mov    %rax,%r12
   31fd0:	e9 fe 00 00 00       	jmp    320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31fd5:	49 89 c4             	mov    %rax,%r12
   31fd8:	4c 89 ff             	mov    %r15,%rdi
   31fdb:	ff 15 bf db 03 00    	call   *0x3dbbf(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   31fe1:	e9 ed 00 00 00       	jmp    320d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4363>
   31fe6:	49 89 c4             	mov    %rax,%r12
   31fe9:	eb 5e                	jmp    32049 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42d9>
   31feb:	49 89 c4             	mov    %rax,%r12
   31fee:	e9 4a 01 00 00       	jmp    3213d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43cd>
   31ff3:	49 89 c4             	mov    %rax,%r12
   31ff6:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
   31ffd:	00 
   31ffe:	48 8b 84 24 a8 01 00 	mov    0x1a8(%rsp),%rax
   32005:	00 
   32006:	48 85 c0             	test   %rax,%rax
   32009:	74 2a                	je     32035 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42c5>
   3200b:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   32011:	49 29 c7             	sub    %rax,%r15
   32014:	4c 89 f3             	mov    %r14,%rbx
   32017:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3201e:	00 00 
   32020:	48 89 df             	mov    %rbx,%rdi
   32023:	e8 e8 7f ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32028:	48 83 c3 20          	add    $0x20,%rbx
   3202c:	49 ff c7             	inc    %r15
   3202f:	49 83 ff 01          	cmp    $0x1,%r15
   32033:	75 eb                	jne    32020 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42b0>
   32035:	48 83 bc 24 98 01 00 	cmpq   $0x0,0x198(%rsp)
   3203c:	00 00 
   3203e:	74 09                	je     32049 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42d9>
   32040:	4c 89 f7             	mov    %r14,%rdi
   32043:	ff 15 57 db 03 00    	call   *0x3db57(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   32049:	48 83 bc 24 e8 00 00 	cmpq   $0x0,0xe8(%rsp)
   32050:	00 00 
   32052:	74 72                	je     320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   32054:	48 83 bc 24 f8 00 00 	cmpq   $0x0,0xf8(%rsp)
   3205b:	00 00 
   3205d:	74 67                	je     320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   3205f:	48 8b bc 24 00 01 00 	mov    0x100(%rsp),%rdi
   32066:	00 
   32067:	ff 15 33 db 03 00    	call   *0x3db33(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   3206d:	eb 57                	jmp    320c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4356>
   3206f:	4d 85 ff             	test   %r15,%r15
   32072:	74 1d                	je     32091 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4321>
   32074:	48 83 c3 20          	add    $0x20,%rbx
   32078:	49 f7 df             	neg    %r15
   3207b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   32080:	48 89 df             	mov    %rbx,%rdi
   32083:	e8 88 7f ff ff       	call   2a010 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32088:	48 83 c3 20          	add    $0x20,%rbx
   3208c:	49 ff cf             	dec    %r15
   3208f:	75 ef                	jne    32080 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4310>
   32091:	48 83 bc 24 98 01 00 	cmpq   $0x0,0x198(%rsp)
   32098:	00 00 
   3209a:	0f 84 fc 00 00 00    	je     3219c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x442c>
   320a0:	4c 89 f7             	mov    %r14,%rdi
   320a3:	ff 15 f7 da 03 00    	call   *0x3daf7(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   320a9:	ff 15 99 db 03 00    	call   *0x3db99(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   320af:	ff 15 93 db 03 00    	call   *0x3db93(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   320b5:	49 89 c4             	mov    %rax,%r12
   320b8:	41 be 06 00 00 00    	mov    $0x6,%r14d
   320be:	e9 99 00 00 00       	jmp    3215c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43ec>
   320c3:	49 89 c4             	mov    %rax,%r12
   320c6:	48 8d bc 24 30 02 00 	lea    0x230(%rsp),%rdi
   320cd:	00 
   320ce:	e8 cd 7b ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   320d3:	48 83 bc 24 70 01 00 	cmpq   $0x0,0x170(%rsp)
   320da:	00 00 
   320dc:	74 0e                	je     320ec <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x437c>
   320de:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
   320e5:	00 
   320e6:	ff 15 b4 da 03 00    	call   *0x3dab4(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   320ec:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
   320f3:	00 
   320f4:	e8 a7 7b ff ff       	call   29ca0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   320f9:	48 8b 8c 24 c8 01 00 	mov    0x1c8(%rsp),%rcx
   32100:	00 
   32101:	48 85 c9             	test   %rcx,%rcx
   32104:	74 2a                	je     32130 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43c0>
   32106:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   3210d:	00 
   3210e:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   32112:	48 01 c1             	add    %rax,%rcx
   32115:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   32119:	74 15                	je     32130 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43c0>
   3211b:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
   32122:	00 
   32123:	48 29 c7             	sub    %rax,%rdi
   32126:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   3212a:	ff 15 70 da 03 00    	call   *0x3da70(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   32130:	48 8b bc 24 20 01 00 	mov    0x120(%rsp),%rdi
   32137:	00 
   32138:	e8 63 79 ff ff       	call   29aa0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3213d:	41 be 06 00 00 00    	mov    $0x6,%r14d
   32143:	48 83 bc 24 08 02 00 	cmpq   $0x0,0x208(%rsp)
   3214a:	00 00 
   3214c:	74 0e                	je     3215c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43ec>
   3214e:	48 8b bc 24 18 01 00 	mov    0x118(%rsp),%rdi
   32155:	00 
   32156:	ff 15 44 da 03 00    	call   *0x3da44(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   3215c:	48 8b 84 24 a8 00 00 	mov    0xa8(%rsp),%rax
   32163:	00 
   32164:	48 8d 58 08          	lea    0x8(%rax),%rbx
   32168:	4c 8b 3d 31 da 03 00 	mov    0x3da31(%rip),%r15        # 6fba0 <free@GLIBC_2.2.5>
   3216f:	eb 1c                	jmp    3218d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x441d>
   32171:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   32178:	0f 1f 84 00 00 00 00 
   3217f:	00 
   32180:	48 83 c3 18          	add    $0x18,%rbx
   32184:	49 ff ce             	dec    %r14
   32187:	0f 84 89 fc ff ff    	je     31e16 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x40a6>
   3218d:	48 83 7b f8 00       	cmpq   $0x0,-0x8(%rbx)
   32192:	74 ec                	je     32180 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4410>
   32194:	48 8b 3b             	mov    (%rbx),%rdi
   32197:	41 ff d7             	call   *%r15
   3219a:	eb e4                	jmp    32180 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4410>
   3219c:	ff 15 a6 da 03 00    	call   *0x3daa6(%rip)        # 6fc48 <_DYNAMIC+0x2a0>
   321a2:	49 89 c4             	mov    %rax,%r12
   321a5:	4d 85 f6             	test   %r14,%r14
   321a8:	74 0b                	je     321b5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4445>
   321aa:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   321af:	ff 15 eb d9 03 00    	call   *0x3d9eb(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   321b5:	4c 89 f8             	mov    %r15,%rax
   321b8:	48 29 e8             	sub    %rbp,%rax
   321bb:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   321c2:	aa aa aa 
   321c5:	48 f7 e1             	mul    %rcx
   321c8:	49 39 ef             	cmp    %rbp,%r15
   321cb:	75 13                	jne    321e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4470>
   321cd:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   321d4:	00 00 
   321d6:	75 41                	jne    32219 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44a9>
   321d8:	4c 89 e7             	mov    %r12,%rdi
   321db:	e8 90 a2 03 00       	call   6c470 <_Unwind_Resume@plt>
   321e0:	48 89 d3             	mov    %rdx,%rbx
   321e3:	48 c1 eb 04          	shr    $0x4,%rbx
   321e7:	49 83 c5 20          	add    $0x20,%r13
   321eb:	4c 8b 35 ae d9 03 00 	mov    0x3d9ae(%rip),%r14        # 6fba0 <free@GLIBC_2.2.5>
   321f2:	eb 15                	jmp    32209 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4499>
   321f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   321fb:	00 00 00 00 00 
   32200:	49 83 c5 18          	add    $0x18,%r13
   32204:	48 ff cb             	dec    %rbx
   32207:	74 c4                	je     321cd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x445d>
   32209:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   3220e:	74 f0                	je     32200 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4490>
   32210:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   32214:	41 ff d6             	call   *%r14
   32217:	eb e7                	jmp    32200 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4490>
   32219:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
   32220:	00 
   32221:	ff 15 79 d9 03 00    	call   *0x3d979(%rip)        # 6fba0 <free@GLIBC_2.2.5>
   32227:	4c 89 e7             	mov    %r12,%rdi
   3222a:	e8 41 a2 03 00       	call   6c470 <_Unwind_Resume@plt>
