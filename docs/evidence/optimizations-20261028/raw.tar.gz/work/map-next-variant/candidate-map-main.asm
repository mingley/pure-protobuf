
work/all-benchmarks/measurement/candidate-map/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002db70 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main>:
   2db70:	55                   	push   %rbp
   2db71:	41 57                	push   %r15
   2db73:	41 56                	push   %r14
   2db75:	41 55                	push   %r13
   2db77:	41 54                	push   %r12
   2db79:	53                   	push   %rbx
   2db7a:	48 81 ec 58 02 00 00 	sub    $0x258,%rsp
   2db81:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
   2db88:	00 
   2db89:	ff 15 99 23 04 00    	call   *0x42399(%rip)        # 6ff28 <_DYNAMIC+0x608>
   2db8f:	48 8b ac 24 88 01 00 	mov    0x188(%rsp),%rbp
   2db96:	00 
   2db97:	4c 8b bc 24 98 01 00 	mov    0x198(%rsp),%r15
   2db9e:	00 
   2db9f:	4c 39 fd             	cmp    %r15,%rbp
   2dba2:	0f 84 96 3d 00 00    	je     3193e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3dce>
   2dba8:	4c 8d 6d 18          	lea    0x18(%rbp),%r13
   2dbac:	4c 89 ac 24 88 01 00 	mov    %r13,0x188(%rsp)
   2dbb3:	00 
   2dbb4:	4c 8b 75 00          	mov    0x0(%rbp),%r14
   2dbb8:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   2dbbc:	0f 84 79 3d 00 00    	je     3193b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3dcb>
   2dbc2:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   2dbc6:	48 8b 5d 10          	mov    0x10(%rbp),%rbx
   2dbca:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2dbcf:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
   2dbd6:	00 
   2dbd7:	48 89 da             	mov    %rbx,%rdx
   2dbda:	ff 15 40 20 04 00    	call   *0x42040(%rip)        # 6fc20 <_DYNAMIC+0x300>
   2dbe0:	83 7c 24 10 01       	cmpl   $0x1,0x10(%rsp)
   2dbe5:	0f 84 da 3d 00 00    	je     319c5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3e55>
   2dbeb:	48 ba f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rdx
   2dbf2:	ff ff 7f 
   2dbf5:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2dbfa:	4c 89 f8             	mov    %r15,%rax
   2dbfd:	4c 29 e8             	sub    %r13,%rax
   2dc00:	48 89 c1             	mov    %rax,%rcx
   2dc03:	48 c1 e9 03          	shr    $0x3,%rcx
   2dc07:	48 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rsi
   2dc0e:	aa aa aa 
   2dc11:	48 0f af ce          	imul   %rsi,%rcx
   2dc15:	48 83 f9 04          	cmp    $0x4,%rcx
   2dc19:	41 bf 03 00 00 00    	mov    $0x3,%r15d
   2dc1f:	4c 0f 43 f9          	cmovae %rcx,%r15
   2dc23:	48 8d 4a ef          	lea    -0x11(%rdx),%rcx
   2dc27:	48 39 c8             	cmp    %rcx,%rax
   2dc2a:	76 15                	jbe    2dc41 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xd1>
   2dc2c:	31 ff                	xor    %edi,%edi
   2dc2e:	4c 89 e6             	mov    %r12,%rsi
   2dc31:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2dc36:	ff 15 dc 1e 04 00    	call   *0x41edc(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   2dc3c:	e9 38 3f 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   2dc41:	4a 8d 04 fd 08 00 00 	lea    0x8(,%r15,8),%rax
   2dc48:	00 
   2dc49:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
   2dc4d:	4d 85 e4             	test   %r12,%r12
   2dc50:	74 17                	je     2dc69 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xf9>
   2dc52:	4c 89 e7             	mov    %r12,%rdi
   2dc55:	ff 15 0d 1f 04 00    	call   *0x41f0d(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2dc5b:	48 85 c0             	test   %rax,%rax
   2dc5e:	0f 84 11 3e 00 00    	je     31a75 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f05>
   2dc64:	49 ff c7             	inc    %r15
   2dc67:	eb 08                	jmp    2dc71 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x101>
   2dc69:	b8 08 00 00 00       	mov    $0x8,%eax
   2dc6e:	45 31 ff             	xor    %r15d,%r15d
   2dc71:	4c 89 30             	mov    %r14,(%rax)
   2dc74:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   2dc7b:	00 
   2dc7c:	48 89 48 08          	mov    %rcx,0x8(%rax)
   2dc80:	48 89 58 10          	mov    %rbx,0x10(%rax)
   2dc84:	4c 89 7c 24 70       	mov    %r15,0x70(%rsp)
   2dc89:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   2dc8e:	48 c7 84 24 80 00 00 	movq   $0x1,0x80(%rsp)
   2dc95:	00 01 00 00 00 
   2dc9a:	f3 0f 6f 84 24 80 01 	movdqu 0x180(%rsp),%xmm0
   2dca1:	00 00 
   2dca3:	66 0f 10 8c 24 90 01 	movupd 0x190(%rsp),%xmm1
   2dcaa:	00 00 
   2dcac:	66 0f 29 4c 24 20    	movapd %xmm1,0x20(%rsp)
   2dcb2:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2dcb8:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   2dcbd:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   2dcc2:	4c 39 e5             	cmp    %r12,%rbp
   2dcc5:	0f 84 d7 00 00 00    	je     2dda2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x232>
   2dccb:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2dcd0:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2dcd6:	41 bd 28 00 00 00    	mov    $0x28,%r13d
   2dcdc:	eb 3f                	jmp    2dd1d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ad>
   2dcde:	66 90                	xchg   %ax,%ax
   2dce0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2dce5:	4e 89 7c 28 f0       	mov    %r15,-0x10(%rax,%r13,1)
   2dcea:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   2dcf1:	00 
   2dcf2:	4a 89 4c 28 f8       	mov    %rcx,-0x8(%rax,%r13,1)
   2dcf7:	4a 89 2c 28          	mov    %rbp,(%rax,%r13,1)
   2dcfb:	49 ff c6             	inc    %r14
   2dcfe:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   2dd05:	00 
   2dd06:	48 8b 6c 24 18       	mov    0x18(%rsp),%rbp
   2dd0b:	4c 8b 64 24 28       	mov    0x28(%rsp),%r12
   2dd10:	49 83 c5 18          	add    $0x18,%r13
   2dd14:	4c 39 e5             	cmp    %r12,%rbp
   2dd17:	0f 84 90 00 00 00    	je     2ddad <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23d>
   2dd1d:	48 8d 5d 18          	lea    0x18(%rbp),%rbx
   2dd21:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   2dd26:	4c 8b 7d 00          	mov    0x0(%rbp),%r15
   2dd2a:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
   2dd2e:	74 7a                	je     2ddaa <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23a>
   2dd30:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   2dd34:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
   2dd38:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   2dd3d:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
   2dd44:	00 
   2dd45:	48 89 ea             	mov    %rbp,%rdx
   2dd48:	ff 15 d2 1e 04 00    	call   *0x41ed2(%rip)        # 6fc20 <_DYNAMIC+0x300>
   2dd4e:	83 7c 24 50 01       	cmpl   $0x1,0x50(%rsp)
   2dd53:	0f 84 2b 3b 00 00    	je     31884 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d14>
   2dd59:	4c 3b 74 24 70       	cmp    0x70(%rsp),%r14
   2dd5e:	75 80                	jne    2dce0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x170>
   2dd60:	49 29 dc             	sub    %rbx,%r12
   2dd63:	49 c1 ec 03          	shr    $0x3,%r12
   2dd67:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   2dd6e:	aa aa aa 
   2dd71:	4c 0f af e0          	imul   %rax,%r12
   2dd75:	49 ff c4             	inc    %r12
   2dd78:	b9 08 00 00 00       	mov    $0x8,%ecx
   2dd7d:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   2dd83:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   2dd88:	4c 89 f6             	mov    %r14,%rsi
   2dd8b:	4c 89 e2             	mov    %r12,%rdx
   2dd8e:	e8 fd e7 ff ff       	call   2c590 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2dd93:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   2dd98:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2dd9d:	e9 3e ff ff ff       	jmp    2dce0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x170>
   2dda2:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2dda8:	eb 03                	jmp    2ddad <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23d>
   2ddaa:	48 89 dd             	mov    %rbx,%rbp
   2ddad:	4c 89 e0             	mov    %r12,%rax
   2ddb0:	48 29 e8             	sub    %rbp,%rax
   2ddb3:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   2ddba:	aa aa aa 
   2ddbd:	48 f7 e1             	mul    %rcx
   2ddc0:	49 39 ec             	cmp    %rbp,%r12
   2ddc3:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
   2ddc8:	74 2f                	je     2ddf9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x289>
   2ddca:	48 89 d3             	mov    %rdx,%rbx
   2ddcd:	48 c1 eb 04          	shr    $0x4,%rbx
   2ddd1:	48 83 c5 08          	add    $0x8,%rbp
   2ddd5:	4c 8b 3d 74 1d 04 00 	mov    0x41d74(%rip),%r15        # 6fb50 <free@GLIBC_2.2.5>
   2dddc:	eb 0b                	jmp    2dde9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x279>
   2ddde:	66 90                	xchg   %ax,%ax
   2dde0:	48 83 c5 18          	add    $0x18,%rbp
   2dde4:	48 ff cb             	dec    %rbx
   2dde7:	74 10                	je     2ddf9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x289>
   2dde9:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   2ddee:	74 f0                	je     2dde0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x270>
   2ddf0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   2ddf4:	41 ff d7             	call   *%r15
   2ddf7:	eb e7                	jmp    2dde0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x270>
   2ddf9:	48 83 7c 24 20 00    	cmpq   $0x0,0x20(%rsp)
   2ddff:	74 0b                	je     2de0c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x29c>
   2de01:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2de06:	ff 15 44 1d 04 00    	call   *0x41d44(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   2de0c:	48 8b 44 24 70       	mov    0x70(%rsp),%rax
   2de11:	48 89 84 24 d8 01 00 	mov    %rax,0x1d8(%rsp)
   2de18:	00 
   2de19:	48 8b 44 24 78       	mov    0x78(%rsp),%rax
   2de1e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2de23:	49 83 fe 06          	cmp    $0x6,%r14
   2de27:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   2de2e:	00 
   2de2f:	0f 85 63 3b 00 00    	jne    31998 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3e28>
   2de35:	48 8d 48 30          	lea    0x30(%rax),%rcx
   2de39:	48 89 8c 24 20 02 00 	mov    %rcx,0x220(%rsp)
   2de40:	00 
   2de41:	48 89 8c 24 00 02 00 	mov    %rcx,0x200(%rsp)
   2de48:	00 
   2de49:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2de4d:	48 8b 70 70          	mov    0x70(%rax),%rsi
   2de51:	48 83 fe 01          	cmp    $0x1,%rsi
   2de55:	74 0e                	je     2de65 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2f5>
   2de57:	48 85 f6             	test   %rsi,%rsi
   2de5a:	0f 84 73 3c 00 00    	je     31ad3 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f63>
   2de60:	0f b6 11             	movzbl (%rcx),%edx
   2de63:	eb 17                	jmp    2de7c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x30c>
   2de65:	0f b6 11             	movzbl (%rcx),%edx
   2de68:	b0 01                	mov    $0x1,%al
   2de6a:	83 fa 2b             	cmp    $0x2b,%edx
   2de6d:	0f 84 f8 36 00 00    	je     3156b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39fb>
   2de73:	83 fa 2d             	cmp    $0x2d,%edx
   2de76:	0f 84 ef 36 00 00    	je     3156b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39fb>
   2de7c:	31 c0                	xor    %eax,%eax
   2de7e:	80 fa 2b             	cmp    $0x2b,%dl
   2de81:	0f 94 c0             	sete   %al
   2de84:	48 89 f2             	mov    %rsi,%rdx
   2de87:	48 29 c2             	sub    %rax,%rdx
   2de8a:	48 01 c1             	add    %rax,%rcx
   2de8d:	48 f7 d8             	neg    %rax
   2de90:	48 83 fa 11          	cmp    $0x11,%rdx
   2de94:	73 41                	jae    2ded7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x367>
   2de96:	48 85 d2             	test   %rdx,%rdx
   2de99:	0f 84 89 00 00 00    	je     2df28 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b8>
   2de9f:	48 01 c6             	add    %rax,%rsi
   2dea2:	48 f7 de             	neg    %rsi
   2dea5:	45 31 db             	xor    %r11d,%r11d
   2dea8:	31 c0                	xor    %eax,%eax
   2deaa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2deb0:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2deb4:	83 c2 d0             	add    $0xffffffd0,%edx
   2deb7:	83 fa 09             	cmp    $0x9,%edx
   2deba:	0f 87 b6 39 00 00    	ja     31876 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d06>
   2dec0:	4b 8d 3c 9b          	lea    (%r11,%r11,4),%rdi
   2dec4:	89 d2                	mov    %edx,%edx
   2dec6:	4c 8d 1c 7a          	lea    (%rdx,%rdi,2),%r11
   2deca:	48 ff c0             	inc    %rax
   2decd:	48 89 f2             	mov    %rsi,%rdx
   2ded0:	48 01 c2             	add    %rax,%rdx
   2ded3:	75 db                	jne    2deb0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x340>
   2ded5:	eb 54                	jmp    2df2b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3bb>
   2ded7:	48 01 c6             	add    %rax,%rsi
   2deda:	48 f7 de             	neg    %rsi
   2dedd:	45 31 db             	xor    %r11d,%r11d
   2dee0:	bf 0a 00 00 00       	mov    $0xa,%edi
   2dee5:	45 31 c0             	xor    %r8d,%r8d
   2dee8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2deef:	00 
   2def0:	4c 89 d8             	mov    %r11,%rax
   2def3:	48 f7 e7             	mul    %rdi
   2def6:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2defb:	0f 80 5c 36 00 00    	jo     3155d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39ed>
   2df01:	83 c2 d0             	add    $0xffffffd0,%edx
   2df04:	83 fa 0a             	cmp    $0xa,%edx
   2df07:	0f 83 69 39 00 00    	jae    31876 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d06>
   2df0d:	49 89 c3             	mov    %rax,%r11
   2df10:	89 d0                	mov    %edx,%eax
   2df12:	49 01 c3             	add    %rax,%r11
   2df15:	0f 82 4e 36 00 00    	jb     31569 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39f9>
   2df1b:	49 ff c0             	inc    %r8
   2df1e:	48 89 f0             	mov    %rsi,%rax
   2df21:	4c 01 c0             	add    %r8,%rax
   2df24:	75 ca                	jne    2def0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x380>
   2df26:	eb 03                	jmp    2df2b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3bb>
   2df28:	45 31 db             	xor    %r11d,%r11d
   2df2b:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2df32:	00 
   2df33:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
   2df3a:	4c 8b 80 88 00 00 00 	mov    0x88(%rax),%r8
   2df41:	49 83 f8 01          	cmp    $0x1,%r8
   2df45:	74 0e                	je     2df55 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3e5>
   2df47:	4d 85 c0             	test   %r8,%r8
   2df4a:	0f 84 8a 3b 00 00    	je     31ada <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f6a>
   2df50:	0f b6 0e             	movzbl (%rsi),%ecx
   2df53:	eb 17                	jmp    2df6c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3fc>
   2df55:	0f b6 0e             	movzbl (%rsi),%ecx
   2df58:	b0 01                	mov    $0x1,%al
   2df5a:	83 f9 2b             	cmp    $0x2b,%ecx
   2df5d:	0f 84 23 36 00 00    	je     31586 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a16>
   2df63:	83 f9 2d             	cmp    $0x2d,%ecx
   2df66:	0f 84 1a 36 00 00    	je     31586 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a16>
   2df6c:	31 c0                	xor    %eax,%eax
   2df6e:	80 f9 2b             	cmp    $0x2b,%cl
   2df71:	0f 94 c0             	sete   %al
   2df74:	4c 89 c2             	mov    %r8,%rdx
   2df77:	48 29 c2             	sub    %rax,%rdx
   2df7a:	48 01 c6             	add    %rax,%rsi
   2df7d:	48 f7 d8             	neg    %rax
   2df80:	48 8d 0d 29 02 04 00 	lea    0x40229(%rip),%rcx        # 6e1b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6e0>
   2df87:	48 8d 3d 32 b2 fd ff 	lea    -0x24dce(%rip),%rdi        # 91c0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x89>
   2df8e:	48 83 fa 11          	cmp    $0x11,%rdx
   2df92:	73 43                	jae    2dfd7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x467>
   2df94:	48 85 d2             	test   %rdx,%rdx
   2df97:	0f 84 44 3b 00 00    	je     31ae1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f71>
   2df9d:	49 01 c0             	add    %rax,%r8
   2dfa0:	49 f7 d8             	neg    %r8
   2dfa3:	31 db                	xor    %ebx,%ebx
   2dfa5:	31 c0                	xor    %eax,%eax
   2dfa7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2dfae:	00 00 
   2dfb0:	0f b6 14 06          	movzbl (%rsi,%rax,1),%edx
   2dfb4:	83 c2 d0             	add    $0xffffffd0,%edx
   2dfb7:	83 fa 09             	cmp    $0x9,%edx
   2dfba:	0f 87 af 38 00 00    	ja     3186f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cff>
   2dfc0:	4c 8d 0c 9b          	lea    (%rbx,%rbx,4),%r9
   2dfc4:	89 d2                	mov    %edx,%edx
   2dfc6:	4a 8d 1c 4a          	lea    (%rdx,%r9,2),%rbx
   2dfca:	48 ff c0             	inc    %rax
   2dfcd:	4c 89 c2             	mov    %r8,%rdx
   2dfd0:	48 01 c2             	add    %rax,%rdx
   2dfd3:	75 db                	jne    2dfb0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x440>
   2dfd5:	eb 4f                	jmp    2e026 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4b6>
   2dfd7:	49 01 c0             	add    %rax,%r8
   2dfda:	49 f7 d8             	neg    %r8
   2dfdd:	31 db                	xor    %ebx,%ebx
   2dfdf:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
   2dfe5:	45 31 d2             	xor    %r10d,%r10d
   2dfe8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2dfef:	00 
   2dff0:	48 89 d8             	mov    %rbx,%rax
   2dff3:	49 f7 e1             	mul    %r9
   2dff6:	42 0f b6 14 16       	movzbl (%rsi,%r10,1),%edx
   2dffb:	0f 80 77 35 00 00    	jo     31578 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a08>
   2e001:	83 c2 d0             	add    $0xffffffd0,%edx
   2e004:	83 fa 0a             	cmp    $0xa,%edx
   2e007:	0f 83 62 38 00 00    	jae    3186f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cff>
   2e00d:	48 89 c3             	mov    %rax,%rbx
   2e010:	89 d0                	mov    %edx,%eax
   2e012:	48 01 c3             	add    %rax,%rbx
   2e015:	0f 82 69 35 00 00    	jb     31584 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a14>
   2e01b:	49 ff c2             	inc    %r10
   2e01e:	4c 89 c0             	mov    %r8,%rax
   2e021:	4c 01 d0             	add    %r10,%rax
   2e024:	75 ca                	jne    2dff0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x480>
   2e026:	be 2f 00 00 00       	mov    $0x2f,%esi
   2e02b:	4d 85 db             	test   %r11,%r11
   2e02e:	0f 84 b2 3a 00 00    	je     31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e034:	48 85 db             	test   %rbx,%rbx
   2e037:	0f 84 a9 3a 00 00    	je     31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e03d:	48 8b 94 24 a0 00 00 	mov    0xa0(%rsp),%rdx
   2e044:	00 
   2e045:	48 8b 42 40          	mov    0x40(%rdx),%rax
   2e049:	48 8d 0d 78 01 04 00 	lea    0x40178(%rip),%rcx        # 6e1c8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f8>
   2e050:	be 39 00 00 00       	mov    $0x39,%esi
   2e055:	48 8d 3d 93 b1 fd ff 	lea    -0x24e6d(%rip),%rdi        # 91ef <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xb8>
   2e05c:	48 83 f8 05          	cmp    $0x5,%rax
   2e060:	75 1b                	jne    2e07d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x50d>
   2e062:	48 8b 42 38          	mov    0x38(%rdx),%rax
   2e066:	ba 70 72 6f 73       	mov    $0x736f7270,%edx
   2e06b:	33 10                	xor    (%rax),%edx
   2e06d:	0f b6 40 04          	movzbl 0x4(%rax),%eax
   2e071:	83 f0 74             	xor    $0x74,%eax
   2e074:	09 d0                	or     %edx,%eax
   2e076:	74 27                	je     2e09f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x52f>
   2e078:	e9 69 3a 00 00       	jmp    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e07d:	48 83 f8 04          	cmp    $0x4,%rax
   2e081:	0f 85 5f 3a 00 00    	jne    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e087:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2e08e:	00 
   2e08f:	48 8b 40 38          	mov    0x38(%rax),%rax
   2e093:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2e099:	0f 85 47 3a 00 00    	jne    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e09f:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   2e0a6:	00 
   2e0a7:	48 8b 41 50          	mov    0x50(%rcx),%rax
   2e0ab:	48 8b 51 58          	mov    0x58(%rcx),%rdx
   2e0af:	48 8d 0d 2a 01 04 00 	lea    0x4012a(%rip),%rcx        # 6e1e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x710>
   2e0b6:	be 4f 00 00 00       	mov    $0x4f,%esi
   2e0bb:	48 8d 3d 66 b1 fd ff 	lea    -0x24e9a(%rip),%rdi        # 9228 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xf1>
   2e0c2:	48 83 fa 08          	cmp    $0x8,%rdx
   2e0c6:	74 1f                	je     2e0e7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x577>
   2e0c8:	48 83 fa 0a          	cmp    $0xa,%rdx
   2e0cc:	75 2d                	jne    2e0fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x58b>
   2e0ce:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2e0d5:	66 69 72 
   2e0d8:	48 33 10             	xor    (%rax),%rdx
   2e0db:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e0df:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e0e5:	eb 34                	jmp    2e11b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x5ab>
   2e0e7:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2e0ee:	61 6c 6c 
   2e0f1:	48 39 10             	cmp    %rdx,(%rax)
   2e0f4:	74 2e                	je     2e124 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x5b4>
   2e0f6:	e9 eb 39 00 00       	jmp    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e0fb:	48 83 fa 0c          	cmp    $0xc,%rdx
   2e0ff:	0f 85 e1 39 00 00    	jne    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e105:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2e10c:	63 6f 6c 
   2e10f:	48 33 10             	xor    (%rax),%rdx
   2e112:	8b 40 08             	mov    0x8(%rax),%eax
   2e115:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e11b:	48 09 d0             	or     %rdx,%rax
   2e11e:	0f 85 c2 39 00 00    	jne    31ae6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f76>
   2e124:	48 89 9c 24 30 02 00 	mov    %rbx,0x230(%rsp)
   2e12b:	00 
   2e12c:	4c 89 9c 24 f0 01 00 	mov    %r11,0x1f0(%rsp)
   2e133:	00 
   2e134:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   2e13b:	00 
   2e13c:	48 8d 48 48          	lea    0x48(%rax),%rcx
   2e140:	48 89 8c 24 f8 01 00 	mov    %rcx,0x1f8(%rsp)
   2e147:	00 
   2e148:	48 bd 80 80 80 80 80 	movabs $0x8080808080808080,%rbp
   2e14f:	80 80 80 
   2e152:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e159:	5f 5f 5f 
   2e15c:	49 bd 00 01 01 01 01 	movabs $0x101010101010100,%r13
   2e163:	01 01 01 
   2e166:	48 8b 50 20          	mov    0x20(%rax),%rdx
   2e16a:	48 8b 70 28          	mov    0x28(%rax),%rsi
   2e16e:	48 8d 42 08          	lea    0x8(%rdx),%rax
   2e172:	48 89 84 24 30 01 00 	mov    %rax,0x130(%rsp)
   2e179:	00 
   2e17a:	45 31 f6             	xor    %r14d,%r14d
   2e17d:	31 c0                	xor    %eax,%eax
   2e17f:	48 89 94 24 90 00 00 	mov    %rdx,0x90(%rsp)
   2e186:	00 
   2e187:	48 89 74 24 08       	mov    %rsi,0x8(%rsp)
   2e18c:	eb 20                	jmp    2e1ae <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x63e>
   2e18e:	66 90                	xchg   %ax,%ax
   2e190:	4c 89 e0             	mov    %r12,%rax
   2e193:	49 39 f4             	cmp    %rsi,%r12
   2e196:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e19d:	5f 5f 5f 
   2e1a0:	48 8b 94 24 90 00 00 	mov    0x90(%rsp),%rdx
   2e1a7:	00 
   2e1a8:	0f 87 6f 1c 00 00    	ja     2fe1d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22ad>
   2e1ae:	48 89 f1             	mov    %rsi,%rcx
   2e1b1:	48 29 c1             	sub    %rax,%rcx
   2e1b4:	48 01 c2             	add    %rax,%rdx
   2e1b7:	48 83 f9 0f          	cmp    $0xf,%rcx
   2e1bb:	77 33                	ja     2e1f0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x680>
   2e1bd:	b3 01                	mov    $0x1,%bl
   2e1bf:	48 39 c6             	cmp    %rax,%rsi
   2e1c2:	0f 84 3d 01 00 00    	je     2e305 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x795>
   2e1c8:	45 31 ff             	xor    %r15d,%r15d
   2e1cb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2e1d0:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e1d5:	0f 84 e5 00 00 00    	je     2e2c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x750>
   2e1db:	49 ff c7             	inc    %r15
   2e1de:	4c 39 f9             	cmp    %r15,%rcx
   2e1e1:	75 ed                	jne    2e1d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x660>
   2e1e3:	e9 1d 01 00 00       	jmp    2e305 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x795>
   2e1e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e1ef:	00 
   2e1f0:	48 8d 72 07          	lea    0x7(%rdx),%rsi
   2e1f4:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   2e1f8:	48 29 d6             	sub    %rdx,%rsi
   2e1fb:	75 53                	jne    2e250 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x6e0>
   2e1fd:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2e201:	31 f6                	xor    %esi,%esi
   2e203:	4c 8b 84 24 30 01 00 	mov    0x130(%rsp),%r8
   2e20a:	00 
   2e20b:	49 01 c0             	add    %rax,%r8
   2e20e:	66 90                	xchg   %ax,%ax
   2e210:	4d 8b 4c 30 f8       	mov    -0x8(%r8,%rsi,1),%r9
   2e215:	4d 89 ca             	mov    %r9,%r10
   2e218:	49 31 da             	xor    %rbx,%r10
   2e21b:	4d 89 eb             	mov    %r13,%r11
   2e21e:	4d 29 d3             	sub    %r10,%r11
   2e221:	4d 09 cb             	or     %r9,%r11
   2e224:	4d 8b 0c 30          	mov    (%r8,%rsi,1),%r9
   2e228:	49 31 d9             	xor    %rbx,%r9
   2e22b:	4d 89 ea             	mov    %r13,%r10
   2e22e:	4d 29 ca             	sub    %r9,%r10
   2e231:	4d 09 ca             	or     %r9,%r10
   2e234:	49 21 eb             	and    %rbp,%r11
   2e237:	4d 21 d3             	and    %r10,%r11
   2e23a:	49 39 eb             	cmp    %rbp,%r11
   2e23d:	75 51                	jne    2e290 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x720>
   2e23f:	48 83 c6 10          	add    $0x10,%rsi
   2e243:	48 39 fe             	cmp    %rdi,%rsi
   2e246:	76 c8                	jbe    2e210 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x6a0>
   2e248:	eb 46                	jmp    2e290 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x720>
   2e24a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e250:	45 31 ff             	xor    %r15d,%r15d
   2e253:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e25a:	84 00 00 00 00 00 
   2e260:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e265:	74 59                	je     2e2c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x750>
   2e267:	49 ff c7             	inc    %r15
   2e26a:	4c 39 fe             	cmp    %r15,%rsi
   2e26d:	75 f1                	jne    2e260 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x6f0>
   2e26f:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2e273:	48 39 fe             	cmp    %rdi,%rsi
   2e276:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2e27d:	5f 5f 5f 
   2e280:	76 81                	jbe    2e203 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x693>
   2e282:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e289:	1f 84 00 00 00 00 00 
   2e290:	b3 01                	mov    $0x1,%bl
   2e292:	49 89 f7             	mov    %rsi,%r15
   2e295:	48 39 f1             	cmp    %rsi,%rcx
   2e298:	74 6b                	je     2e305 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x795>
   2e29a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e2a0:	42 80 3c 3a 5f       	cmpb   $0x5f,(%rdx,%r15,1)
   2e2a5:	74 19                	je     2e2c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x750>
   2e2a7:	49 ff c7             	inc    %r15
   2e2aa:	4c 39 f9             	cmp    %r15,%rcx
   2e2ad:	75 f1                	jne    2e2a0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x730>
   2e2af:	eb 54                	jmp    2e305 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x795>
   2e2b1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e2b8:	0f 1f 84 00 00 00 00 
   2e2bf:	00 
   2e2c0:	4d 8d 24 07          	lea    (%r15,%rax,1),%r12
   2e2c4:	49 ff c4             	inc    %r12
   2e2c7:	49 01 c7             	add    %rax,%r15
   2e2ca:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e2cf:	49 39 f7             	cmp    %rsi,%r15
   2e2d2:	0f 83 b8 fe ff ff    	jae    2e190 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x620>
   2e2d8:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   2e2df:	00 
   2e2e0:	42 80 3c 38 5f       	cmpb   $0x5f,(%rax,%r15,1)
   2e2e5:	0f 85 a5 fe ff ff    	jne    2e190 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x620>
   2e2eb:	31 db                	xor    %ebx,%ebx
   2e2ed:	4d 89 e6             	mov    %r12,%r14
   2e2f0:	bf 40 00 00 00       	mov    $0x40,%edi
   2e2f5:	ff 15 6d 18 04 00    	call   *0x4186d(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2e2fb:	48 85 c0             	test   %rax,%rax
   2e2fe:	75 21                	jne    2e321 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x7b1>
   2e300:	e9 31 1b 00 00       	jmp    2fe36 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22c6>
   2e305:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2e30a:	4d 89 fc             	mov    %r15,%r12
   2e30d:	bf 40 00 00 00       	mov    $0x40,%edi
   2e312:	ff 15 50 18 04 00    	call   *0x41850(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2e318:	48 85 c0             	test   %rax,%rax
   2e31b:	0f 84 15 1b 00 00    	je     2fe36 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22c6>
   2e321:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   2e328:	00 
   2e329:	48 89 08             	mov    %rcx,(%rax)
   2e32c:	4c 89 78 08          	mov    %r15,0x8(%rax)
   2e330:	48 c7 44 24 10 04 00 	movq   $0x4,0x10(%rsp)
   2e337:	00 00 
   2e339:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   2e340:	00 
   2e341:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e346:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2e34d:	00 00 
   2e34f:	84 db                	test   %bl,%bl
   2e351:	0f 85 e6 36 00 00    	jne    31a3d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ecd>
   2e357:	bb 01 00 00 00       	mov    $0x1,%ebx
   2e35c:	eb 3e                	jmp    2e39c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x82c>
   2e35e:	66 90                	xchg   %ax,%ax
   2e360:	4d 29 f7             	sub    %r14,%r15
   2e363:	4c 03 b4 24 90 00 00 	add    0x90(%rsp),%r14
   2e36a:	00 
   2e36b:	48 89 d8             	mov    %rbx,%rax
   2e36e:	48 c1 e0 04          	shl    $0x4,%rax
   2e372:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
   2e379:	00 
   2e37a:	4c 89 34 01          	mov    %r14,(%rcx,%rax,1)
   2e37e:	4c 89 7c 01 08       	mov    %r15,0x8(%rcx,%rax,1)
   2e383:	48 ff c3             	inc    %rbx
   2e386:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   2e38b:	49 89 ee             	mov    %rbp,%r14
   2e38e:	80 bc 24 c0 00 00 00 	cmpb   $0x0,0xc0(%rsp)
   2e395:	00 
   2e396:	0f 85 01 02 00 00    	jne    2e59d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xa2d>
   2e39c:	b0 01                	mov    $0x1,%al
   2e39e:	89 84 24 c0 00 00 00 	mov    %eax,0xc0(%rsp)
   2e3a5:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2e3aa:	4c 39 e1             	cmp    %r12,%rcx
   2e3ad:	73 11                	jae    2e3c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x850>
   2e3af:	4c 89 f5             	mov    %r14,%rbp
   2e3b2:	49 89 cf             	mov    %rcx,%r15
   2e3b5:	e9 a1 01 00 00       	jmp    2e55b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9eb>
   2e3ba:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e3c0:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e3c7:	5f 5f 5f 
   2e3ca:	eb 1a                	jmp    2e3e6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x876>
   2e3cc:	0f 1f 40 00          	nopl   0x0(%rax)
   2e3d0:	49 89 ec             	mov    %rbp,%r12
   2e3d3:	48 39 cd             	cmp    %rcx,%rbp
   2e3d6:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e3dd:	5f 5f 5f 
   2e3e0:	0f 87 af 01 00 00    	ja     2e595 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xa25>
   2e3e6:	48 89 c8             	mov    %rcx,%rax
   2e3e9:	4c 29 e0             	sub    %r12,%rax
   2e3ec:	48 89 ca             	mov    %rcx,%rdx
   2e3ef:	48 8b 8c 24 90 00 00 	mov    0x90(%rsp),%rcx
   2e3f6:	00 
   2e3f7:	4c 01 e1             	add    %r12,%rcx
   2e3fa:	48 83 f8 0f          	cmp    $0xf,%rax
   2e3fe:	77 30                	ja     2e430 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x8c0>
   2e400:	4c 39 e2             	cmp    %r12,%rdx
   2e403:	0f 84 47 01 00 00    	je     2e550 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9e0>
   2e409:	45 31 ff             	xor    %r15d,%r15d
   2e40c:	0f 1f 40 00          	nopl   0x0(%rax)
   2e410:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e415:	0f 84 f5 00 00 00    	je     2e510 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9a0>
   2e41b:	49 ff c7             	inc    %r15
   2e41e:	4c 39 f8             	cmp    %r15,%rax
   2e421:	75 ed                	jne    2e410 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x8a0>
   2e423:	e9 28 01 00 00       	jmp    2e550 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9e0>
   2e428:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e42f:	00 
   2e430:	48 8d 51 07          	lea    0x7(%rcx),%rdx
   2e434:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
   2e438:	48 29 ca             	sub    %rcx,%rdx
   2e43b:	49 bb 80 80 80 80 80 	movabs $0x8080808080808080,%r11
   2e442:	80 80 80 
   2e445:	75 59                	jne    2e4a0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x930>
   2e447:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2e44b:	31 d2                	xor    %edx,%edx
   2e44d:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   2e454:	00 
   2e455:	4c 01 e7             	add    %r12,%rdi
   2e458:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e45f:	00 
   2e460:	4c 8b 44 17 f8       	mov    -0x8(%rdi,%rdx,1),%r8
   2e465:	4d 89 c1             	mov    %r8,%r9
   2e468:	4d 31 f9             	xor    %r15,%r9
   2e46b:	4d 89 ea             	mov    %r13,%r10
   2e46e:	4d 29 ca             	sub    %r9,%r10
   2e471:	4d 09 c2             	or     %r8,%r10
   2e474:	4c 8b 04 17          	mov    (%rdi,%rdx,1),%r8
   2e478:	4d 31 f8             	xor    %r15,%r8
   2e47b:	4d 89 e9             	mov    %r13,%r9
   2e47e:	4d 29 c1             	sub    %r8,%r9
   2e481:	4d 09 c1             	or     %r8,%r9
   2e484:	4d 21 da             	and    %r11,%r10
   2e487:	4d 21 ca             	and    %r9,%r10
   2e48a:	4d 39 da             	cmp    %r11,%r10
   2e48d:	75 51                	jne    2e4e0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x970>
   2e48f:	48 83 c2 10          	add    $0x10,%rdx
   2e493:	48 39 f2             	cmp    %rsi,%rdx
   2e496:	76 c8                	jbe    2e460 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x8f0>
   2e498:	eb 46                	jmp    2e4e0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x970>
   2e49a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e4a0:	45 31 ff             	xor    %r15d,%r15d
   2e4a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e4aa:	84 00 00 00 00 00 
   2e4b0:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e4b5:	74 59                	je     2e510 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9a0>
   2e4b7:	49 ff c7             	inc    %r15
   2e4ba:	4c 39 fa             	cmp    %r15,%rdx
   2e4bd:	75 f1                	jne    2e4b0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x940>
   2e4bf:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2e4c3:	48 39 f2             	cmp    %rsi,%rdx
   2e4c6:	49 bf 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r15
   2e4cd:	5f 5f 5f 
   2e4d0:	0f 86 77 ff ff ff    	jbe    2e44d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x8dd>
   2e4d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2e4dd:	00 00 00 
   2e4e0:	49 89 d7             	mov    %rdx,%r15
   2e4e3:	48 39 d0             	cmp    %rdx,%rax
   2e4e6:	74 68                	je     2e550 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9e0>
   2e4e8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e4ef:	00 
   2e4f0:	42 80 3c 39 5f       	cmpb   $0x5f,(%rcx,%r15,1)
   2e4f5:	74 19                	je     2e510 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9a0>
   2e4f7:	49 ff c7             	inc    %r15
   2e4fa:	4c 39 f8             	cmp    %r15,%rax
   2e4fd:	75 f1                	jne    2e4f0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x980>
   2e4ff:	eb 4f                	jmp    2e550 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9e0>
   2e501:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e508:	0f 1f 84 00 00 00 00 
   2e50f:	00 
   2e510:	4b 8d 2c 27          	lea    (%r15,%r12,1),%rbp
   2e514:	48 ff c5             	inc    %rbp
   2e517:	4d 01 e7             	add    %r12,%r15
   2e51a:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2e51f:	49 39 cf             	cmp    %rcx,%r15
   2e522:	0f 83 a8 fe ff ff    	jae    2e3d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x860>
   2e528:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   2e52f:	00 
   2e530:	42 80 3c 38 5f       	cmpb   $0x5f,(%rax,%r15,1)
   2e535:	0f 85 95 fe ff ff    	jne    2e3d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x860>
   2e53b:	c7 84 24 c0 00 00 00 	movl   $0x0,0xc0(%rsp)
   2e542:	00 00 00 00 
   2e546:	49 89 ec             	mov    %rbp,%r12
   2e549:	eb 10                	jmp    2e55b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x9eb>
   2e54b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2e550:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   2e555:	4d 89 fc             	mov    %r15,%r12
   2e558:	4c 89 f5             	mov    %r14,%rbp
   2e55b:	48 3b 5c 24 10       	cmp    0x10(%rsp),%rbx
   2e560:	0f 85 fa fd ff ff    	jne    2e360 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x7f0>
   2e566:	ba 01 00 00 00       	mov    $0x1,%edx
   2e56b:	b9 08 00 00 00       	mov    $0x8,%ecx
   2e570:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   2e576:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2e57b:	48 89 de             	mov    %rbx,%rsi
   2e57e:	e8 0d e0 ff ff       	call   2c590 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2e583:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e588:	48 89 84 24 e8 00 00 	mov    %rax,0xe8(%rsp)
   2e58f:	00 
   2e590:	e9 cb fd ff ff       	jmp    2e360 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x7f0>
   2e595:	49 89 ec             	mov    %rbp,%r12
   2e598:	e9 12 fe ff ff       	jmp    2e3af <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x83f>
   2e59d:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e5a2:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   2e5a9:	00 
   2e5aa:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e5af:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e5b4:	48 83 fb 03          	cmp    $0x3,%rbx
   2e5b8:	48 89 bc 24 e8 00 00 	mov    %rdi,0xe8(%rsp)
   2e5bf:	00 
   2e5c0:	0f 85 8d 34 00 00    	jne    31a53 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ee3>
   2e5c6:	48 83 7f 08 03       	cmpq   $0x3,0x8(%rdi)
   2e5cb:	0f 85 ee 30 00 00    	jne    316bf <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b4f>
   2e5d1:	48 8b 07             	mov    (%rdi),%rax
   2e5d4:	0f b7 08             	movzwl (%rax),%ecx
   2e5d7:	81 f1 6d 61 00 00    	xor    $0x616d,%ecx
   2e5dd:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   2e5e1:	83 f0 70             	xor    $0x70,%eax
   2e5e4:	66 09 c8             	or     %cx,%ax
   2e5e7:	0f 85 d2 30 00 00    	jne    316bf <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b4f>
   2e5ed:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2e5f1:	48 8b 77 18          	mov    0x18(%rdi),%rsi
   2e5f5:	48 83 fe 01          	cmp    $0x1,%rsi
   2e5f9:	74 0e                	je     2e609 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xa99>
   2e5fb:	48 85 f6             	test   %rsi,%rsi
   2e5fe:	0f 84 f0 34 00 00    	je     31af4 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f84>
   2e604:	0f b6 11             	movzbl (%rcx),%edx
   2e607:	eb 17                	jmp    2e620 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xab0>
   2e609:	0f b6 11             	movzbl (%rcx),%edx
   2e60c:	b0 01                	mov    $0x1,%al
   2e60e:	83 fa 2b             	cmp    $0x2b,%edx
   2e611:	0f 84 a9 2f 00 00    	je     315c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a50>
   2e617:	83 fa 2d             	cmp    $0x2d,%edx
   2e61a:	0f 84 a0 2f 00 00    	je     315c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a50>
   2e620:	31 c0                	xor    %eax,%eax
   2e622:	80 fa 2b             	cmp    $0x2b,%dl
   2e625:	0f 94 c0             	sete   %al
   2e628:	48 89 f2             	mov    %rsi,%rdx
   2e62b:	48 29 c2             	sub    %rax,%rdx
   2e62e:	48 01 c1             	add    %rax,%rcx
   2e631:	48 f7 d8             	neg    %rax
   2e634:	48 83 fa 11          	cmp    $0x11,%rdx
   2e638:	73 3d                	jae    2e677 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xb07>
   2e63a:	48 85 d2             	test   %rdx,%rdx
   2e63d:	0f 84 c1 00 00 00    	je     2e704 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xb94>
   2e643:	48 01 c6             	add    %rax,%rsi
   2e646:	48 f7 de             	neg    %rsi
   2e649:	45 31 ff             	xor    %r15d,%r15d
   2e64c:	31 c0                	xor    %eax,%eax
   2e64e:	66 90                	xchg   %ax,%ax
   2e650:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2e654:	83 c2 d0             	add    $0xffffffd0,%edx
   2e657:	83 fa 09             	cmp    $0x9,%edx
   2e65a:	0f 87 1d 32 00 00    	ja     3187d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d0d>
   2e660:	4b 8d 3c bf          	lea    (%r15,%r15,4),%rdi
   2e664:	89 d2                	mov    %edx,%edx
   2e666:	4c 8d 3c 7a          	lea    (%rdx,%rdi,2),%r15
   2e66a:	48 ff c0             	inc    %rax
   2e66d:	48 89 f2             	mov    %rsi,%rdx
   2e670:	48 01 c2             	add    %rax,%rdx
   2e673:	75 db                	jne    2e650 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xae0>
   2e675:	eb 4f                	jmp    2e6c6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xb56>
   2e677:	48 01 c6             	add    %rax,%rsi
   2e67a:	48 f7 de             	neg    %rsi
   2e67d:	45 31 ff             	xor    %r15d,%r15d
   2e680:	bf 0a 00 00 00       	mov    $0xa,%edi
   2e685:	45 31 c0             	xor    %r8d,%r8d
   2e688:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e68f:	00 
   2e690:	4c 89 f8             	mov    %r15,%rax
   2e693:	48 f7 e7             	mul    %rdi
   2e696:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2e69b:	0f 80 11 2f 00 00    	jo     315b2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a42>
   2e6a1:	83 c2 d0             	add    $0xffffffd0,%edx
   2e6a4:	83 fa 0a             	cmp    $0xa,%edx
   2e6a7:	0f 83 d0 31 00 00    	jae    3187d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d0d>
   2e6ad:	49 89 c7             	mov    %rax,%r15
   2e6b0:	89 d0                	mov    %edx,%eax
   2e6b2:	49 01 c7             	add    %rax,%r15
   2e6b5:	0f 82 03 2f 00 00    	jb     315be <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a4e>
   2e6bb:	49 ff c0             	inc    %r8
   2e6be:	48 89 f0             	mov    %rsi,%rax
   2e6c1:	4c 01 c0             	add    %r8,%rax
   2e6c4:	75 ca                	jne    2e690 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xb20>
   2e6c6:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
   2e6cd:	00 
   2e6ce:	48 8b 41 28          	mov    0x28(%rcx),%rax
   2e6d2:	48 83 f8 09          	cmp    $0x9,%rax
   2e6d6:	75 41                	jne    2e719 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xba9>
   2e6d8:	48 8b 41 20          	mov    0x20(%rcx),%rax
   2e6dc:	48 b9 64 75 70 6c 69 	movabs $0x746163696c707564,%rcx
   2e6e3:	63 61 74 
   2e6e6:	48 33 08             	xor    (%rax),%rcx
   2e6e9:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e6ed:	48 83 f0 65          	xor    $0x65,%rax
   2e6f1:	48 09 c8             	or     %rcx,%rax
   2e6f4:	b0 01                	mov    $0x1,%al
   2e6f6:	89 84 24 5c 01 00 00 	mov    %eax,0x15c(%rsp)
   2e6fd:	74 4e                	je     2e74d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xbdd>
   2e6ff:	e9 e1 2f 00 00       	jmp    316e5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b75>
   2e704:	45 31 ff             	xor    %r15d,%r15d
   2e707:	48 8b 8c 24 e8 00 00 	mov    0xe8(%rsp),%rcx
   2e70e:	00 
   2e70f:	48 8b 41 28          	mov    0x28(%rcx),%rax
   2e713:	48 83 f8 09          	cmp    $0x9,%rax
   2e717:	74 bf                	je     2e6d8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xb68>
   2e719:	48 83 f8 08          	cmp    $0x8,%rax
   2e71d:	0f 85 c2 2f 00 00    	jne    316e5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b75>
   2e723:	48 8b 84 24 e8 00 00 	mov    0xe8(%rsp),%rax
   2e72a:	00 
   2e72b:	48 8b 40 20          	mov    0x20(%rax),%rax
   2e72f:	48 b9 64 69 73 74 69 	movabs $0x74636e6974736964,%rcx
   2e736:	6e 63 74 
   2e739:	48 39 08             	cmp    %rcx,(%rax)
   2e73c:	0f 85 a3 2f 00 00    	jne    316e5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b75>
   2e742:	c7 84 24 5c 01 00 00 	movl   $0x0,0x15c(%rsp)
   2e749:	00 00 00 00 
   2e74d:	48 c7 84 24 f0 00 00 	movq   $0x0,0xf0(%rsp)
   2e754:	00 00 00 00 00 
   2e759:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2e760:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2e765:	0f 85 98 2f 00 00    	jne    31703 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b93>
   2e76b:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2e76f:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2e774:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2e778:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2e77c:	0f 10 05 2d f8 03 00 	movups 0x3f82d(%rip),%xmm0        # 6dfb0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2e783:	0f 29 84 24 80 01 00 	movaps %xmm0,0x180(%rsp)
   2e78a:	00 
   2e78b:	f3 0f 6f 05 2d f8 03 	movdqu 0x3f82d(%rip),%xmm0        # 6dfc0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2e792:	00 
   2e793:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
   2e79a:	00 00 
   2e79c:	48 89 84 24 a0 01 00 	mov    %rax,0x1a0(%rsp)
   2e7a3:	00 
   2e7a4:	48 89 94 24 a8 01 00 	mov    %rdx,0x1a8(%rsp)
   2e7ab:	00 
   2e7ac:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
   2e7b3:	00 00 00 00 00 
   2e7b8:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
   2e7bf:	00 00 00 00 00 
   2e7c4:	48 c7 84 24 38 01 00 	movq   $0x0,0x138(%rsp)
   2e7cb:	00 00 00 00 00 
   2e7d0:	48 c7 84 24 40 01 00 	movq   $0x1,0x140(%rsp)
   2e7d7:	00 01 00 00 00 
   2e7dc:	48 c7 84 24 48 01 00 	movq   $0x0,0x148(%rsp)
   2e7e3:	00 00 00 00 00 
   2e7e8:	4d 85 ff             	test   %r15,%r15
   2e7eb:	4c 89 bc 24 e0 00 00 	mov    %r15,0xe0(%rsp)
   2e7f2:	00 
   2e7f3:	0f 84 0b 0f 00 00    	je     2f704 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1b94>
   2e7f9:	4d 8d 67 03          	lea    0x3(%r15),%r12
   2e7fd:	49 c1 ec 02          	shr    $0x2,%r12
   2e801:	31 db                	xor    %ebx,%ebx
   2e803:	45 31 ed             	xor    %r13d,%r13d
   2e806:	45 31 f6             	xor    %r14d,%r14d
   2e809:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   2e810:	00 00 00 00 00 
   2e815:	4c 89 a4 24 20 01 00 	mov    %r12,0x120(%rsp)
   2e81c:	00 
   2e81d:	0f 1f 00             	nopl   (%rax)
   2e820:	48 8d 43 01          	lea    0x1(%rbx),%rax
   2e824:	4c 39 e0             	cmp    %r12,%rax
   2e827:	b9 00 00 00 00       	mov    $0x0,%ecx
   2e82c:	48 0f 45 c8          	cmovne %rax,%rcx
   2e830:	48 89 8c 24 30 01 00 	mov    %rcx,0x130(%rsp)
   2e837:	00 
   2e838:	80 bc 24 5c 01 00 00 	cmpb   $0x0,0x15c(%rsp)
   2e83f:	00 
   2e840:	74 3e                	je     2e880 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xd10>
   2e842:	4d 85 e4             	test   %r12,%r12
   2e845:	0f 84 cb 30 00 00    	je     31916 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3da6>
   2e84b:	4c 89 e8             	mov    %r13,%rax
   2e84e:	4c 09 e0             	or     %r12,%rax
   2e851:	48 c1 e8 20          	shr    $0x20,%rax
   2e855:	0f 84 92 05 00 00    	je     2eded <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x127d>
   2e85b:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
   2e862:	00 
   2e863:	4d 85 ff             	test   %r15,%r15
   2e866:	74 47                	je     2e8af <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xd3f>
   2e868:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   2e86d:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2e871:	49 3b 1f             	cmp    (%r15),%rbx
   2e874:	0f 84 b1 00 00 00    	je     2e92b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xdbb>
   2e87a:	e9 b5 00 00 00       	jmp    2e934 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xdc4>
   2e87f:	90                   	nop
   2e880:	4c 89 e8             	mov    %r13,%rax
   2e883:	48 c1 e0 04          	shl    $0x4,%rax
   2e887:	4c 01 e8             	add    %r13,%rax
   2e88a:	48 89 c1             	mov    %rax,%rcx
   2e88d:	4c 09 f9             	or     %r15,%rcx
   2e890:	48 c1 e9 20          	shr    $0x20,%rcx
   2e894:	0f 84 36 05 00 00    	je     2edd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1260>
   2e89a:	31 d2                	xor    %edx,%edx
   2e89c:	49 f7 f7             	div    %r15
   2e89f:	48 89 d3             	mov    %rdx,%rbx
   2e8a2:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
   2e8a9:	00 
   2e8aa:	4d 85 ff             	test   %r15,%r15
   2e8ad:	75 b9                	jne    2e868 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xcf8>
   2e8af:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2e8b6:	00 00 
   2e8b8:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   2e8bf:	00 00 
   2e8c1:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e8c8:	00 00 
   2e8ca:	c7 44 24 40 03 00 00 	movl   $0x3,0x40(%rsp)
   2e8d1:	00 
   2e8d2:	bf 38 00 00 00       	mov    $0x38,%edi
   2e8d7:	ff 15 8b 12 04 00    	call   *0x4128b(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2e8dd:	48 85 c0             	test   %rax,%rax
   2e8e0:	0f 84 88 2d 00 00    	je     3166e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3afe>
   2e8e6:	49 89 c7             	mov    %rax,%r15
   2e8e9:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   2e8ee:	49 89 47 30          	mov    %rax,0x30(%r15)
   2e8f2:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   2e8f8:	66 0f 10 4c 24 20    	movupd 0x20(%rsp),%xmm1
   2e8fe:	f3 0f 6f 54 24 30    	movdqu 0x30(%rsp),%xmm2
   2e904:	f3 41 0f 7f 57 20    	movdqu %xmm2,0x20(%r15)
   2e90a:	66 41 0f 11 4f 10    	movupd %xmm1,0x10(%r15)
   2e910:	f3 41 0f 7f 07       	movdqu %xmm0,(%r15)
   2e915:	4c 89 bc 24 f0 00 00 	mov    %r15,0xf0(%rsp)
   2e91c:	00 
   2e91d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   2e922:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2e926:	49 3b 1f             	cmp    (%r15),%rbx
   2e929:	75 09                	jne    2e934 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xdc4>
   2e92b:	4c 89 ff             	mov    %r15,%rdi
   2e92e:	ff 15 d4 15 04 00    	call   *0x415d4(%rip)        # 6ff08 <_DYNAMIC+0x5e8>
   2e934:	42 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%edx
   2e93b:	00 
   2e93c:	44 29 ea             	sub    %r13d,%edx
   2e93f:	83 c2 03             	add    $0x3,%edx
   2e942:	49 8b 47 08          	mov    0x8(%r15),%rax
   2e946:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2e94b:	89 0c d8             	mov    %ecx,(%rax,%rbx,8)
   2e94e:	89 94 24 90 00 00 00 	mov    %edx,0x90(%rsp)
   2e955:	89 54 d8 04          	mov    %edx,0x4(%rax,%rbx,8)
   2e959:	48 ff c3             	inc    %rbx
   2e95c:	49 89 5f 10          	mov    %rbx,0x10(%r15)
   2e960:	41 8b 47 30          	mov    0x30(%r15),%eax
   2e964:	8d 48 fe             	lea    -0x2(%rax),%ecx
   2e967:	83 f9 02             	cmp    $0x2,%ecx
   2e96a:	72 19                	jb     2e985 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xe15>
   2e96c:	85 c0                	test   %eax,%eax
   2e96e:	0f 85 0f 2d 00 00    	jne    31683 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b13>
   2e974:	49 83 7f 18 00       	cmpq   $0x0,0x18(%r15)
   2e979:	74 0a                	je     2e985 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xe15>
   2e97b:	49 8b 7f 20          	mov    0x20(%r15),%rdi
   2e97f:	ff 15 cb 11 04 00    	call   *0x411cb(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   2e985:	41 c7 47 30 03 00 00 	movl   $0x3,0x30(%r15)
   2e98c:	00 
   2e98d:	4c 8b bc 24 a0 01 00 	mov    0x1a0(%rsp),%r15
   2e994:	00 
   2e995:	48 8b ac 24 a8 01 00 	mov    0x1a8(%rsp),%rbp
   2e99c:	00 
   2e99d:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   2e9a4:	00 00 
   2e9a6:	0f 84 c2 0c 00 00    	je     2f66e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1afe>
   2e9ac:	49 ff c5             	inc    %r13
   2e9af:	4c 89 f9             	mov    %r15,%rcx
   2e9b2:	48 b8 75 65 73 70 65 	movabs $0x736f6d6570736575,%rax
   2e9b9:	6d 6f 73 
   2e9bc:	48 31 c1             	xor    %rax,%rcx
   2e9bf:	48 b8 61 72 65 6e 65 	movabs $0x6c7967656e657261,%rax
   2e9c6:	67 79 6c 
   2e9c9:	49 31 c7             	xor    %rax,%r15
   2e9cc:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e9d1:	89 f8                	mov    %edi,%eax
   2e9d3:	48 ba 00 00 00 00 00 	movabs $0x400000000000000,%rdx
   2e9da:	00 00 04 
   2e9dd:	48 01 c2             	add    %rax,%rdx
   2e9e0:	48 be 73 65 74 79 62 	movabs $0x7065646279746573,%rsi
   2e9e7:	64 65 70 
   2e9ea:	48 31 f0             	xor    %rsi,%rax
   2e9ed:	48 31 e8             	xor    %rbp,%rax
   2e9f0:	48 be 6d 6f 64 6e 61 	movabs $0x646f72616e646f6d,%rsi
   2e9f7:	72 6f 64 
   2e9fa:	48 31 f5             	xor    %rsi,%rbp
   2e9fd:	48 01 e9             	add    %rbp,%rcx
   2ea00:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ea04:	49 01 c7             	add    %rax,%r15
   2ea07:	48 31 cd             	xor    %rcx,%rbp
   2ea0a:	48 c1 c0 10          	rol    $0x10,%rax
   2ea0e:	4c 31 f8             	xor    %r15,%rax
   2ea11:	48 c1 c1 20          	rol    $0x20,%rcx
   2ea15:	49 01 ef             	add    %rbp,%r15
   2ea18:	48 01 c1             	add    %rax,%rcx
   2ea1b:	48 c1 c5 11          	rol    $0x11,%rbp
   2ea1f:	4c 31 fd             	xor    %r15,%rbp
   2ea22:	48 c1 c0 15          	rol    $0x15,%rax
   2ea26:	49 c1 c7 20          	rol    $0x20,%r15
   2ea2a:	48 31 c8             	xor    %rcx,%rax
   2ea2d:	48 31 d1             	xor    %rdx,%rcx
   2ea30:	49 81 f7 ff 00 00 00 	xor    $0xff,%r15
   2ea37:	48 01 e9             	add    %rbp,%rcx
   2ea3a:	49 01 c7             	add    %rax,%r15
   2ea3d:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ea41:	48 31 cd             	xor    %rcx,%rbp
   2ea44:	48 c1 c0 10          	rol    $0x10,%rax
   2ea48:	48 c1 c1 20          	rol    $0x20,%rcx
   2ea4c:	4c 31 f8             	xor    %r15,%rax
   2ea4f:	49 01 ef             	add    %rbp,%r15
   2ea52:	48 c1 c5 11          	rol    $0x11,%rbp
   2ea56:	48 01 c1             	add    %rax,%rcx
   2ea59:	4c 31 fd             	xor    %r15,%rbp
   2ea5c:	48 c1 c0 15          	rol    $0x15,%rax
   2ea60:	48 31 c8             	xor    %rcx,%rax
   2ea63:	49 c1 c7 20          	rol    $0x20,%r15
   2ea67:	48 01 e9             	add    %rbp,%rcx
   2ea6a:	49 01 c7             	add    %rax,%r15
   2ea6d:	48 c1 c5 0d          	rol    $0xd,%rbp
   2ea71:	48 31 cd             	xor    %rcx,%rbp
   2ea74:	48 c1 c0 10          	rol    $0x10,%rax
   2ea78:	48 c1 c1 20          	rol    $0x20,%rcx
   2ea7c:	4c 31 f8             	xor    %r15,%rax
   2ea7f:	49 01 ef             	add    %rbp,%r15
   2ea82:	48 c1 c5 11          	rol    $0x11,%rbp
   2ea86:	48 01 c1             	add    %rax,%rcx
   2ea89:	4c 31 fd             	xor    %r15,%rbp
   2ea8c:	48 c1 c0 15          	rol    $0x15,%rax
   2ea90:	48 31 c8             	xor    %rcx,%rax
   2ea93:	49 c1 c7 20          	rol    $0x20,%r15
   2ea97:	48 01 e9             	add    %rbp,%rcx
   2ea9a:	49 01 c7             	add    %rax,%r15
   2ea9d:	48 c1 c5 0d          	rol    $0xd,%rbp
   2eaa1:	48 31 cd             	xor    %rcx,%rbp
   2eaa4:	48 c1 c0 10          	rol    $0x10,%rax
   2eaa8:	4c 31 f8             	xor    %r15,%rax
   2eaab:	49 01 ef             	add    %rbp,%r15
   2eaae:	48 c1 c5 11          	rol    $0x11,%rbp
   2eab2:	48 c1 c0 15          	rol    $0x15,%rax
   2eab6:	48 31 e8             	xor    %rbp,%rax
   2eab9:	48 89 fd             	mov    %rdi,%rbp
   2eabc:	4c 89 ff             	mov    %r15,%rdi
   2eabf:	48 c1 c7 20          	rol    $0x20,%rdi
   2eac3:	48 31 c7             	xor    %rax,%rdi
   2eac6:	4c 31 ff             	xor    %r15,%rdi
   2eac9:	48 8b 84 24 80 01 00 	mov    0x180(%rsp),%rax
   2ead0:	00 
   2ead1:	48 8b 94 24 88 01 00 	mov    0x188(%rsp),%rdx
   2ead8:	00 
   2ead9:	48 89 f9             	mov    %rdi,%rcx
   2eadc:	48 c1 e9 39          	shr    $0x39,%rcx
   2eae0:	66 0f 6e c1          	movd   %ecx,%xmm0
   2eae4:	66 0f 60 c0          	punpcklbw %xmm0,%xmm0
   2eae8:	f2 0f 70 c0 00       	pshuflw $0x0,%xmm0,%xmm0
   2eaed:	66 0f 70 c0 44       	pshufd $0x44,%xmm0,%xmm0
   2eaf2:	45 31 c9             	xor    %r9d,%r9d
   2eaf5:	45 31 c0             	xor    %r8d,%r8d
   2eaf8:	48 21 d7             	and    %rdx,%rdi
   2eafb:	f3 0f 6f 0c 38       	movdqu (%rax,%rdi,1),%xmm1
   2eb00:	66 0f 6f d1          	movdqa %xmm1,%xmm2
   2eb04:	66 0f 74 d0          	pcmpeqb %xmm0,%xmm2
   2eb08:	66 44 0f d7 d2       	pmovmskb %xmm2,%r10d
   2eb0d:	45 85 d2             	test   %r10d,%r10d
   2eb10:	74 2e                	je     2eb40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xfd0>
   2eb12:	f3 45 0f bc da       	tzcnt  %r10d,%r11d
   2eb17:	49 01 fb             	add    %rdi,%r11
   2eb1a:	49 21 d3             	and    %rdx,%r11
   2eb1d:	4a 8d 1c dd 00 00 00 	lea    0x0(,%r11,8),%rbx
   2eb24:	00 
   2eb25:	49 89 c7             	mov    %rax,%r15
   2eb28:	49 29 df             	sub    %rbx,%r15
   2eb2b:	41 39 6f f8          	cmp    %ebp,-0x8(%r15)
   2eb2f:	74 5f                	je     2eb90 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1020>
   2eb31:	45 8d 5a ff          	lea    -0x1(%r10),%r11d
   2eb35:	66 45 21 d3          	and    %r10w,%r11w
   2eb39:	45 89 da             	mov    %r11d,%r10d
   2eb3c:	75 d4                	jne    2eb12 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xfa2>
   2eb3e:	66 90                	xchg   %ax,%ax
   2eb40:	49 83 f9 01          	cmp    $0x1,%r9
   2eb44:	74 12                	je     2eb58 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xfe8>
   2eb46:	66 0f d7 f1          	pmovmskb %xmm1,%esi
   2eb4a:	85 f6                	test   %esi,%esi
   2eb4c:	74 24                	je     2eb72 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1002>
   2eb4e:	f3 0f bc f6          	tzcnt  %esi,%esi
   2eb52:	48 01 fe             	add    %rdi,%rsi
   2eb55:	48 21 d6             	and    %rdx,%rsi
   2eb58:	66 0f 76 d2          	pcmpeqd %xmm2,%xmm2
   2eb5c:	66 0f 74 ca          	pcmpeqb %xmm2,%xmm1
   2eb60:	66 44 0f d7 c9       	pmovmskb %xmm1,%r9d
   2eb65:	45 85 c9             	test   %r9d,%r9d
   2eb68:	75 36                	jne    2eba0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1030>
   2eb6a:	41 b9 01 00 00 00    	mov    $0x1,%r9d
   2eb70:	eb 03                	jmp    2eb75 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1005>
   2eb72:	45 31 c9             	xor    %r9d,%r9d
   2eb75:	4c 01 c7             	add    %r8,%rdi
   2eb78:	48 83 c7 10          	add    $0x10,%rdi
   2eb7c:	49 83 c0 10          	add    $0x10,%r8
   2eb80:	e9 73 ff ff ff       	jmp    2eaf8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xf88>
   2eb85:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2eb8c:	00 00 00 00 
   2eb90:	49 f7 db             	neg    %r11
   2eb93:	4c 8b 8c 24 50 01 00 	mov    0x150(%rsp),%r9
   2eb9a:	00 
   2eb9b:	eb 63                	jmp    2ec00 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1090>
   2eb9d:	0f 1f 00             	nopl   (%rax)
   2eba0:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
   2eba4:	40 84 ff             	test   %dil,%dil
   2eba7:	4c 8b 8c 24 50 01 00 	mov    0x150(%rsp),%r9
   2ebae:	00 
   2ebaf:	0f 89 3a 0b 00 00    	jns    2f6ef <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1b7f>
   2ebb5:	40 80 e7 01          	and    $0x1,%dil
   2ebb9:	4c 8d 46 f0          	lea    -0x10(%rsi),%r8
   2ebbd:	49 21 d0             	and    %rdx,%r8
   2ebc0:	88 0c 30             	mov    %cl,(%rax,%rsi,1)
   2ebc3:	42 88 4c 00 10       	mov    %cl,0x10(%rax,%r8,1)
   2ebc8:	66 0f 6f 84 24 90 01 	movdqa 0x190(%rsp),%xmm0
   2ebcf:	00 00 
   2ebd1:	40 0f b6 cf          	movzbl %dil,%ecx
   2ebd5:	66 0f 6e c9          	movd   %ecx,%xmm1
   2ebd9:	66 0f c6 0d de 86 fd 	shufpd $0x2,-0x27922(%rip),%xmm1        # 72c0 <anon.d74135bdccc798679365a46b1d65ca28.138.llvm.4795996092214488023+0xe9>
   2ebe0:	ff 02 
   2ebe2:	66 0f fb c1          	psubq  %xmm1,%xmm0
   2ebe6:	66 0f 7f 84 24 90 01 	movdqa %xmm0,0x190(%rsp)
   2ebed:	00 00 
   2ebef:	49 89 f3             	mov    %rsi,%r11
   2ebf2:	49 f7 db             	neg    %r11
   2ebf5:	48 c1 e6 03          	shl    $0x3,%rsi
   2ebf9:	48 f7 de             	neg    %rsi
   2ebfc:	89 6c 30 f8          	mov    %ebp,-0x8(%rax,%rsi,1)
   2ec00:	4c 89 ac 24 c0 00 00 	mov    %r13,0xc0(%rsp)
   2ec07:	00 
   2ec08:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
   2ec0f:	42 89 4c d8 fc       	mov    %ecx,-0x4(%rax,%r11,8)
   2ec14:	4d 85 f6             	test   %r14,%r14
   2ec17:	0f 84 b3 00 00 00    	je     2ecd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1160>
   2ec1d:	4c 89 c8             	mov    %r9,%rax
   2ec20:	4c 89 f3             	mov    %r14,%rbx
   2ec23:	44 0f b7 63 62       	movzwl 0x62(%rbx),%r12d
   2ec28:	4d 89 e5             	mov    %r12,%r13
   2ec2b:	45 85 e4             	test   %r12d,%r12d
   2ec2e:	74 47                	je     2ec77 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1107>
   2ec30:	44 89 e1             	mov    %r12d,%ecx
   2ec33:	c1 e1 02             	shl    $0x2,%ecx
   2ec36:	45 31 ed             	xor    %r13d,%r13d
   2ec39:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2ec40:	42 3b 6c ab 08       	cmp    0x8(%rbx,%r13,4),%ebp
   2ec45:	40 0f 9c c6          	setl   %sil
   2ec49:	0f 9f c2             	setg   %dl
   2ec4c:	40 28 f2             	sub    %sil,%dl
   2ec4f:	80 fa 01             	cmp    $0x1,%dl
   2ec52:	75 1c                	jne    2ec70 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1100>
   2ec54:	49 ff c5             	inc    %r13
   2ec57:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
   2ec5b:	75 e3                	jne    2ec40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x10d0>
   2ec5d:	4d 89 e5             	mov    %r12,%r13
   2ec60:	eb 15                	jmp    2ec77 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1107>
   2ec62:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ec69:	1f 84 00 00 00 00 00 
   2ec70:	0f b6 ca             	movzbl %dl,%ecx
   2ec73:	85 c9                	test   %ecx,%ecx
   2ec75:	74 29                	je     2eca0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1130>
   2ec77:	48 83 e8 01          	sub    $0x1,%rax
   2ec7b:	0f 82 8c 01 00 00    	jb     2ee0d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x129d>
   2ec81:	4a 8b 5c eb 68       	mov    0x68(%rbx,%r13,8),%rbx
   2ec86:	44 0f b7 63 62       	movzwl 0x62(%rbx),%r12d
   2ec8b:	4d 89 e5             	mov    %r12,%r13
   2ec8e:	45 85 e4             	test   %r12d,%r12d
   2ec91:	75 9d                	jne    2ec30 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x10c0>
   2ec93:	eb e2                	jmp    2ec77 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1107>
   2ec95:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2ec9c:	00 00 00 00 
   2eca0:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   2eca7:	42 89 44 ab 34       	mov    %eax,0x34(%rbx,%r13,4)
   2ecac:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
   2ecb3:	00 
   2ecb4:	4c 8b a4 24 20 01 00 	mov    0x120(%rsp),%r12
   2ecbb:	00 
   2ecbc:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   2ecc3:	00 
   2ecc4:	e9 97 00 00 00       	jmp    2ed60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11f0>
   2ecc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2ecd0:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2ecd6:	bf 68 00 00 00       	mov    $0x68,%edi
   2ecdb:	ff 15 87 0e 04 00    	call   *0x40e87(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2ece1:	48 85 c0             	test   %rax,%rax
   2ece4:	0f 84 39 29 00 00    	je     31623 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ab3>
   2ecea:	49 89 c6             	mov    %rax,%r14
   2eced:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2ecf4:	48 89 84 24 b8 01 00 	mov    %rax,0x1b8(%rsp)
   2ecfb:	00 
   2ecfc:	48 c7 84 24 c0 01 00 	movq   $0x0,0x1c0(%rsp)
   2ed03:	00 00 00 00 00 
   2ed08:	66 c7 40 62 01 00    	movw   $0x1,0x62(%rax)
   2ed0e:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2ed13:	89 68 08             	mov    %ebp,0x8(%rax)
   2ed16:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   2ed1d:	41 89 46 34          	mov    %eax,0x34(%r14)
   2ed21:	48 c7 84 24 50 01 00 	movq   $0x0,0x150(%rsp)
   2ed28:	00 00 00 00 00 
   2ed2d:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
   2ed34:	00 
   2ed35:	4c 8b a4 24 20 01 00 	mov    0x120(%rsp),%r12
   2ed3c:	00 
   2ed3d:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   2ed44:	00 
   2ed45:	48 8b 8c 24 28 01 00 	mov    0x128(%rsp),%rcx
   2ed4c:	00 
   2ed4d:	48 ff c1             	inc    %rcx
   2ed50:	48 89 8c 24 28 01 00 	mov    %rcx,0x128(%rsp)
   2ed57:	00 
   2ed58:	48 89 8c 24 c8 01 00 	mov    %rcx,0x1c8(%rsp)
   2ed5f:	00 
   2ed60:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
   2ed67:	00 
   2ed68:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   2ed6f:	00 
   2ed70:	48 89 c1             	mov    %rax,%rcx
   2ed73:	48 29 f1             	sub    %rsi,%rcx
   2ed76:	48 83 f9 03          	cmp    $0x3,%rcx
   2ed7a:	0f 86 06 09 00 00    	jbe    2f686 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1b16>
   2ed80:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
   2ed87:	00 
   2ed88:	89 2c 31             	mov    %ebp,(%rcx,%rsi,1)
   2ed8b:	48 83 c6 04          	add    $0x4,%rsi
   2ed8f:	48 89 b4 24 48 01 00 	mov    %rsi,0x148(%rsp)
   2ed96:	00 
   2ed97:	48 29 f0             	sub    %rsi,%rax
   2ed9a:	48 83 f8 03          	cmp    $0x3,%rax
   2ed9e:	0f 86 19 09 00 00    	jbe    2f6bd <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1b4d>
   2eda4:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   2edab:	89 04 31             	mov    %eax,(%rcx,%rsi,1)
   2edae:	48 83 c6 04          	add    $0x4,%rsi
   2edb2:	48 89 b4 24 48 01 00 	mov    %rsi,0x148(%rsp)
   2edb9:	00 
   2edba:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
   2edc1:	00 
   2edc2:	4d 39 fd             	cmp    %r15,%r13
   2edc5:	0f 85 55 fa ff ff    	jne    2e820 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xcb0>
   2edcb:	e9 43 09 00 00       	jmp    2f713 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ba3>
   2edd0:	31 d2                	xor    %edx,%edx
   2edd2:	41 f7 f7             	div    %r15d
   2edd5:	89 d3                	mov    %edx,%ebx
   2edd7:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
   2edde:	00 
   2eddf:	4d 85 ff             	test   %r15,%r15
   2ede2:	0f 85 80 fa ff ff    	jne    2e868 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xcf8>
   2ede8:	e9 c2 fa ff ff       	jmp    2e8af <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xd3f>
   2eded:	44 89 e8             	mov    %r13d,%eax
   2edf0:	31 d2                	xor    %edx,%edx
   2edf2:	41 f7 f4             	div    %r12d
   2edf5:	89 d3                	mov    %edx,%ebx
   2edf7:	4c 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%r15
   2edfe:	00 
   2edff:	4d 85 ff             	test   %r15,%r15
   2ee02:	0f 85 60 fa ff ff    	jne    2e868 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xcf8>
   2ee08:	e9 a2 fa ff ff       	jmp    2e8af <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xd3f>
   2ee0d:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2ee11:	66 41 83 fc 0b       	cmp    $0xb,%r12w
   2ee16:	73 60                	jae    2ee78 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1308>
   2ee18:	4d 39 ec             	cmp    %r13,%r12
   2ee1b:	76 3c                	jbe    2ee59 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x12e9>
   2ee1d:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2ee21:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2ee25:	48 83 c7 04          	add    $0x4,%rdi
   2ee29:	45 89 e7             	mov    %r12d,%r15d
   2ee2c:	45 29 ef             	sub    %r13d,%r15d
   2ee2f:	41 c1 e7 02          	shl    $0x2,%r15d
   2ee33:	4c 89 fa             	mov    %r15,%rdx
   2ee36:	48 8b 2d a3 0d 04 00 	mov    0x40da3(%rip),%rbp        # 6fbe0 <memmove@GLIBC_2.2.5>
   2ee3d:	ff d5                	call   *%rbp
   2ee3f:	4a 8d 34 ab          	lea    (%rbx,%r13,4),%rsi
   2ee43:	48 83 c6 34          	add    $0x34,%rsi
   2ee47:	4a 8d 3c ab          	lea    (%rbx,%r13,4),%rdi
   2ee4b:	48 83 c7 38          	add    $0x38,%rdi
   2ee4f:	4c 89 fa             	mov    %r15,%rdx
   2ee52:	ff d5                	call   *%rbp
   2ee54:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2ee59:	42 89 6c ab 08       	mov    %ebp,0x8(%rbx,%r13,4)
   2ee5e:	41 8d 44 24 01       	lea    0x1(%r12),%eax
   2ee63:	8b 8c 24 90 00 00 00 	mov    0x90(%rsp),%ecx
   2ee6a:	42 89 4c ab 34       	mov    %ecx,0x34(%rbx,%r13,4)
   2ee6f:	66 89 43 62          	mov    %ax,0x62(%rbx)
   2ee73:	e9 b5 fe ff ff       	jmp    2ed2d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11bd>
   2ee78:	49 83 fd 05          	cmp    $0x5,%r13
   2ee7c:	73 0f                	jae    2ee8d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x131d>
   2ee7e:	bd 04 00 00 00       	mov    $0x4,%ebp
   2ee83:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   2ee8a:	00 
   2ee8b:	eb 34                	jmp    2eec1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1351>
   2ee8d:	74 16                	je     2eea5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1335>
   2ee8f:	49 83 fd 06          	cmp    $0x6,%r13
   2ee93:	75 1d                	jne    2eeb2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1342>
   2ee95:	bd 05 00 00 00       	mov    $0x5,%ebp
   2ee9a:	b0 01                	mov    $0x1,%al
   2ee9c:	89 44 24 48          	mov    %eax,0x48(%rsp)
   2eea0:	45 31 ed             	xor    %r13d,%r13d
   2eea3:	eb 1c                	jmp    2eec1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1351>
   2eea5:	c7 44 24 48 00 00 00 	movl   $0x0,0x48(%rsp)
   2eeac:	00 
   2eead:	4c 89 ed             	mov    %r13,%rbp
   2eeb0:	eb 0f                	jmp    2eec1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1351>
   2eeb2:	49 83 c5 f9          	add    $0xfffffffffffffff9,%r13
   2eeb6:	bd 06 00 00 00       	mov    $0x6,%ebp
   2eebb:	b0 01                	mov    $0x1,%al
   2eebd:	89 44 24 48          	mov    %eax,0x48(%rsp)
   2eec1:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2eec7:	bf 68 00 00 00       	mov    $0x68,%edi
   2eecc:	ff 15 96 0c 04 00    	call   *0x40c96(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2eed2:	48 85 c0             	test   %rax,%rax
   2eed5:	0f 84 48 27 00 00    	je     31623 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ab3>
   2eedb:	49 89 c7             	mov    %rax,%r15
   2eede:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2eee5:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2eee9:	49 89 ec             	mov    %rbp,%r12
   2eeec:	49 f7 d4             	not    %r12
   2eeef:	49 01 c4             	add    %rax,%r12
   2eef2:	66 45 89 67 62       	mov    %r12w,0x62(%r15)
   2eef7:	49 83 fc 0c          	cmp    $0xc,%r12
   2eefb:	0f 83 c8 27 00 00    	jae    316c9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b59>
   2ef01:	8b 44 ab 08          	mov    0x8(%rbx,%rbp,4),%eax
   2ef05:	89 84 24 1c 01 00 00 	mov    %eax,0x11c(%rsp)
   2ef0c:	8b 44 ab 34          	mov    0x34(%rbx,%rbp,4),%eax
   2ef10:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
   2ef17:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2ef1b:	48 8d 34 a8          	lea    (%rax,%rbp,4),%rsi
   2ef1f:	48 83 c6 04          	add    $0x4,%rsi
   2ef23:	49 8d 7f 08          	lea    0x8(%r15),%rdi
   2ef27:	49 c1 e4 02          	shl    $0x2,%r12
   2ef2b:	4c 89 e2             	mov    %r12,%rdx
   2ef2e:	ff 15 04 0c 04 00    	call   *0x40c04(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   2ef34:	48 8d 34 ab          	lea    (%rbx,%rbp,4),%rsi
   2ef38:	48 83 c6 38          	add    $0x38,%rsi
   2ef3c:	49 8d 7f 34          	lea    0x34(%r15),%rdi
   2ef40:	4c 89 e2             	mov    %r12,%rdx
   2ef43:	ff 15 ef 0b 04 00    	call   *0x40bef(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   2ef49:	66 89 6b 62          	mov    %bp,0x62(%rbx)
   2ef4d:	80 7c 24 48 00       	cmpb   $0x0,0x48(%rsp)
   2ef52:	4c 89 fd             	mov    %r15,%rbp
   2ef55:	48 0f 44 eb          	cmove  %rbx,%rbp
   2ef59:	44 0f b7 65 62       	movzwl 0x62(%rbp),%r12d
   2ef5e:	4d 39 ec             	cmp    %r13,%r12
   2ef61:	76 45                	jbe    2efa8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1438>
   2ef63:	48 8d 45 08          	lea    0x8(%rbp),%rax
   2ef67:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2ef6b:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2ef6f:	48 83 c7 04          	add    $0x4,%rdi
   2ef73:	44 89 e2             	mov    %r12d,%edx
   2ef76:	44 29 ea             	sub    %r13d,%edx
   2ef79:	c1 e2 02             	shl    $0x2,%edx
   2ef7c:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   2ef81:	ff 15 59 0c 04 00    	call   *0x40c59(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2ef87:	4a 8d 34 ad 34 00 00 	lea    0x34(,%r13,4),%rsi
   2ef8e:	00 
   2ef8f:	48 01 ee             	add    %rbp,%rsi
   2ef92:	4a 8d 3c ad 38 00 00 	lea    0x38(,%r13,4),%rdi
   2ef99:	00 
   2ef9a:	48 01 ef             	add    %rbp,%rdi
   2ef9d:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   2efa2:	ff 15 38 0c 04 00    	call   *0x40c38(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2efa8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2efad:	42 89 44 ad 08       	mov    %eax,0x8(%rbp,%r13,4)
   2efb2:	41 ff c4             	inc    %r12d
   2efb5:	8b 84 24 90 00 00 00 	mov    0x90(%rsp),%eax
   2efbc:	42 89 44 ad 34       	mov    %eax,0x34(%rbp,%r13,4)
   2efc1:	66 44 89 65 62       	mov    %r12w,0x62(%rbp)
   2efc6:	48 8b 03             	mov    (%rbx),%rax
   2efc9:	31 c9                	xor    %ecx,%ecx
   2efcb:	48 85 c0             	test   %rax,%rax
   2efce:	0f 84 4a 04 00 00    	je     2f41e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x18ae>
   2efd4:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2efd9:	eb 29                	jmp    2f004 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1494>
   2efdb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2efe0:	48 8b 8c 24 28 02 00 	mov    0x228(%rsp),%rcx
   2efe7:	00 
   2efe8:	48 ff c1             	inc    %rcx
   2efeb:	48 8b 03             	mov    (%rbx),%rax
   2efee:	48 85 c0             	test   %rax,%rax
   2eff1:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   2eff8:	00 
   2eff9:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2effe:	0f 84 27 04 00 00    	je     2f42b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x18bb>
   2f004:	8b b4 24 18 01 00 00 	mov    0x118(%rsp),%esi
   2f00b:	8b bc 24 1c 01 00 00 	mov    0x11c(%rsp),%edi
   2f012:	44 0f b7 4b 60       	movzwl 0x60(%rbx),%r9d
   2f017:	48 89 c3             	mov    %rax,%rbx
   2f01a:	44 0f b7 50 62       	movzwl 0x62(%rax),%r10d
   2f01f:	49 83 fa 0b          	cmp    $0xb,%r10
   2f023:	4c 89 bc 24 e8 01 00 	mov    %r15,0x1e8(%rsp)
   2f02a:	00 
   2f02b:	89 b4 24 14 01 00 00 	mov    %esi,0x114(%rsp)
   2f032:	89 bc 24 10 01 00 00 	mov    %edi,0x110(%rsp)
   2f039:	4c 89 94 24 78 01 00 	mov    %r10,0x178(%rsp)
   2f040:	00 
   2f041:	0f 82 95 04 00 00    	jb     2f4dc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x196c>
   2f047:	66 41 83 f9 05       	cmp    $0x5,%r9w
   2f04c:	48 89 8c 24 28 02 00 	mov    %rcx,0x228(%rsp)
   2f053:	00 
   2f054:	73 1a                	jae    2f070 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1500>
   2f056:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
   2f05b:	b8 04 00 00 00       	mov    $0x4,%eax
   2f060:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   2f067:	00 
   2f068:	45 31 ed             	xor    %r13d,%r13d
   2f06b:	eb 63                	jmp    2f0d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1560>
   2f06d:	0f 1f 00             	nopl   (%rax)
   2f070:	49 83 f9 05          	cmp    $0x5,%r9
   2f074:	74 21                	je     2f097 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1527>
   2f076:	41 83 f9 06          	cmp    $0x6,%r9d
   2f07a:	75 2d                	jne    2f0a9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1539>
   2f07c:	41 b5 01             	mov    $0x1,%r13b
   2f07f:	b8 05 00 00 00       	mov    $0x5,%eax
   2f084:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   2f08b:	00 
   2f08c:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   2f093:	00 00 
   2f095:	eb 39                	jmp    2f0d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1560>
   2f097:	45 31 ed             	xor    %r13d,%r13d
   2f09a:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
   2f09f:	4c 89 8c 24 d8 00 00 	mov    %r9,0xd8(%rsp)
   2f0a6:	00 
   2f0a7:	eb 27                	jmp    2f0d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1560>
   2f0a9:	49 83 c1 f9          	add    $0xfffffffffffffff9,%r9
   2f0ad:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
   2f0b2:	41 b5 01             	mov    $0x1,%r13b
   2f0b5:	b8 06 00 00 00       	mov    $0x6,%eax
   2f0ba:	48 89 84 24 d8 00 00 	mov    %rax,0xd8(%rsp)
   2f0c1:	00 
   2f0c2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f0c9:	1f 84 00 00 00 00 00 
   2f0d0:	41 bc c8 00 00 00    	mov    $0xc8,%r12d
   2f0d6:	bf c8 00 00 00       	mov    $0xc8,%edi
   2f0db:	ff 15 87 0a 04 00    	call   *0x40a87(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2f0e1:	48 85 c0             	test   %rax,%rax
   2f0e4:	0f 84 39 25 00 00    	je     31623 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ab3>
   2f0ea:	48 89 c5             	mov    %rax,%rbp
   2f0ed:	49 89 c7             	mov    %rax,%r15
   2f0f0:	48 c7 45 00 00 00 00 	movq   $0x0,0x0(%rbp)
   2f0f7:	00 
   2f0f8:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f0fc:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   2f103:	00 
   2f104:	49 89 cc             	mov    %rcx,%r12
   2f107:	49 f7 d4             	not    %r12
   2f10a:	49 01 c4             	add    %rax,%r12
   2f10d:	66 44 89 65 62       	mov    %r12w,0x62(%rbp)
   2f112:	49 83 fc 0c          	cmp    $0xc,%r12
   2f116:	0f 83 1a 25 00 00    	jae    31636 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ac6>
   2f11c:	44 89 ac 24 e0 01 00 	mov    %r13d,0x1e0(%rsp)
   2f123:	00 
   2f124:	44 8d 2c 8d 00 00 00 	lea    0x0(,%rcx,4),%r13d
   2f12b:	00 
   2f12c:	42 8b 44 2b 08       	mov    0x8(%rbx,%r13,1),%eax
   2f131:	89 84 24 1c 01 00 00 	mov    %eax,0x11c(%rsp)
   2f138:	42 8b 44 2b 34       	mov    0x34(%rbx,%r13,1),%eax
   2f13d:	89 84 24 18 01 00 00 	mov    %eax,0x118(%rsp)
   2f144:	4a 8d 34 2b          	lea    (%rbx,%r13,1),%rsi
   2f148:	48 83 c6 0c          	add    $0xc,%rsi
   2f14c:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
   2f150:	49 c1 e4 02          	shl    $0x2,%r12
   2f154:	4c 89 e2             	mov    %r12,%rdx
   2f157:	ff 15 db 09 04 00    	call   *0x409db(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   2f15d:	4a 8d 34 2b          	lea    (%rbx,%r13,1),%rsi
   2f161:	48 83 c6 38          	add    $0x38,%rsi
   2f165:	48 8d 7d 34          	lea    0x34(%rbp),%rdi
   2f169:	4c 89 e2             	mov    %r12,%rdx
   2f16c:	ff 15 c6 09 04 00    	call   *0x409c6(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   2f172:	48 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%rcx
   2f179:	00 
   2f17a:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2f17e:	45 0f b7 67 62       	movzwl 0x62(%r15),%r12d
   2f183:	4d 8d 6c 24 01       	lea    0x1(%r12),%r13
   2f188:	49 83 fc 0b          	cmp    $0xb,%r12
   2f18c:	0f 87 c0 24 00 00    	ja     31652 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ae2>
   2f192:	48 8b 84 24 78 01 00 	mov    0x178(%rsp),%rax
   2f199:	00 
   2f19a:	29 c8                	sub    %ecx,%eax
   2f19c:	44 39 e8             	cmp    %r13d,%eax
   2f19f:	0f 85 fc 24 00 00    	jne    316a1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3b31>
   2f1a5:	48 8d 7d 68          	lea    0x68(%rbp),%rdi
   2f1a9:	48 8d 34 cb          	lea    (%rbx,%rcx,8),%rsi
   2f1ad:	48 83 c6 70          	add    $0x70,%rsi
   2f1b1:	42 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%edx
   2f1b8:	00 
   2f1b9:	ff 15 79 09 04 00    	call   *0x40979(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   2f1bf:	44 89 e8             	mov    %r13d,%eax
   2f1c2:	83 e0 03             	and    $0x3,%eax
   2f1c5:	66 41 83 fc 03       	cmp    $0x3,%r12w
   2f1ca:	73 14                	jae    2f1e0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1670>
   2f1cc:	31 c9                	xor    %ecx,%ecx
   2f1ce:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
   2f1d3:	eb 6b                	jmp    2f240 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x16d0>
   2f1d5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f1dc:	00 00 00 00 
   2f1e0:	41 83 e5 1c          	and    $0x1c,%r13d
   2f1e4:	31 c9                	xor    %ecx,%ecx
   2f1e6:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
   2f1eb:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2f1f0:	49 8b 54 cf 68       	mov    0x68(%r15,%rcx,8),%rdx
   2f1f5:	4c 89 3a             	mov    %r15,(%rdx)
   2f1f8:	89 ce                	mov    %ecx,%esi
   2f1fa:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2f1fe:	49 8b 54 cf 70       	mov    0x70(%r15,%rcx,8),%rdx
   2f203:	4c 89 3a             	mov    %r15,(%rdx)
   2f206:	8d 7e 01             	lea    0x1(%rsi),%edi
   2f209:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2f20d:	49 8b 54 cf 78       	mov    0x78(%r15,%rcx,8),%rdx
   2f212:	4c 89 3a             	mov    %r15,(%rdx)
   2f215:	8d 7e 02             	lea    0x2(%rsi),%edi
   2f218:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2f21c:	49 8b 94 cf 80 00 00 	mov    0x80(%r15,%rcx,8),%rdx
   2f223:	00 
   2f224:	48 83 c1 04          	add    $0x4,%rcx
   2f228:	4c 89 3a             	mov    %r15,(%rdx)
   2f22b:	83 c6 03             	add    $0x3,%esi
   2f22e:	66 89 72 60          	mov    %si,0x60(%rdx)
   2f232:	4c 39 e9             	cmp    %r13,%rcx
   2f235:	75 b9                	jne    2f1f0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1680>
   2f237:	48 85 c0             	test   %rax,%rax
   2f23a:	74 18                	je     2f254 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x16e4>
   2f23c:	0f 1f 40 00          	nopl   0x0(%rax)
   2f240:	49 8b 54 cf 68       	mov    0x68(%r15,%rcx,8),%rdx
   2f245:	4c 89 3a             	mov    %r15,(%rdx)
   2f248:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2f24c:	48 ff c1             	inc    %rcx
   2f24f:	48 ff c8             	dec    %rax
   2f252:	75 ec                	jne    2f240 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x16d0>
   2f254:	80 bc 24 e0 01 00 00 	cmpb   $0x0,0x1e0(%rsp)
   2f25b:	00 
   2f25c:	48 0f 44 eb          	cmove  %rbx,%rbp
   2f260:	44 0f b7 65 62       	movzwl 0x62(%rbp),%r12d
   2f265:	4d 8d 68 01          	lea    0x1(%r8),%r13
   2f269:	4d 89 e1             	mov    %r12,%r9
   2f26c:	4d 29 c1             	sub    %r8,%r9
   2f26f:	0f 86 cb 00 00 00    	jbe    2f340 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x17d0>
   2f275:	48 8d 45 08          	lea    0x8(%rbp),%rax
   2f279:	4a 8d 34 85 08 00 00 	lea    0x8(,%r8,4),%rsi
   2f280:	00 
   2f281:	48 01 ee             	add    %rbp,%rsi
   2f284:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2f288:	44 89 e0             	mov    %r12d,%eax
   2f28b:	44 29 c0             	sub    %r8d,%eax
   2f28e:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
   2f295:	00 
   2f296:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
   2f29d:	48 89 94 24 e0 01 00 	mov    %rdx,0x1e0(%rsp)
   2f2a4:	00 
   2f2a5:	4c 89 8c 24 d8 00 00 	mov    %r9,0xd8(%rsp)
   2f2ac:	00 
   2f2ad:	ff 15 2d 09 04 00    	call   *0x4092d(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f2b3:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f2b8:	48 8d 34 85 34 00 00 	lea    0x34(,%rax,4),%rsi
   2f2bf:	00 
   2f2c0:	48 01 ee             	add    %rbp,%rsi
   2f2c3:	4a 8d 3c ad 34 00 00 	lea    0x34(,%r13,4),%rdi
   2f2ca:	00 
   2f2cb:	48 01 ef             	add    %rbp,%rdi
   2f2ce:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   2f2d5:	00 
   2f2d6:	ff 15 04 09 04 00    	call   *0x40904(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f2dc:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f2e1:	8b 8c 24 10 01 00 00 	mov    0x110(%rsp),%ecx
   2f2e8:	89 4c 85 08          	mov    %ecx,0x8(%rbp,%rax,4)
   2f2ec:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f2f1:	8b 8c 24 14 01 00 00 	mov    0x114(%rsp),%ecx
   2f2f8:	89 4c 85 34          	mov    %ecx,0x34(%rbp,%rax,4)
   2f2fc:	4a 8d 74 ed 68       	lea    0x68(%rbp,%r13,8),%rsi
   2f301:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f306:	48 8d 3c c5 78 00 00 	lea    0x78(,%rax,8),%rdi
   2f30d:	00 
   2f30e:	48 01 ef             	add    %rbp,%rdi
   2f311:	48 8b 94 24 78 01 00 	mov    0x178(%rsp),%rdx
   2f318:	00 
   2f319:	c1 e2 03             	shl    $0x3,%edx
   2f31c:	ff 15 be 08 04 00    	call   *0x408be(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f322:	4c 8b 8c 24 d8 00 00 	mov    0xd8(%rsp),%r9
   2f329:	00 
   2f32a:	4c 8b 44 24 48       	mov    0x48(%rsp),%r8
   2f32f:	eb 27                	jmp    2f358 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x17e8>
   2f331:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f338:	0f 1f 84 00 00 00 00 
   2f33f:	00 
   2f340:	8b 84 24 10 01 00 00 	mov    0x110(%rsp),%eax
   2f347:	42 89 44 85 08       	mov    %eax,0x8(%rbp,%r8,4)
   2f34c:	8b 84 24 14 01 00 00 	mov    0x114(%rsp),%eax
   2f353:	42 89 44 85 34       	mov    %eax,0x34(%rbp,%r8,4)
   2f358:	48 8b 94 24 e8 01 00 	mov    0x1e8(%rsp),%rdx
   2f35f:	00 
   2f360:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
   2f365:	49 8d 44 24 02       	lea    0x2(%r12),%rax
   2f36a:	4a 89 54 c5 70       	mov    %rdx,0x70(%rbp,%r8,8)
   2f36f:	66 89 4d 62          	mov    %cx,0x62(%rbp)
   2f373:	41 39 c5             	cmp    %eax,%r13d
   2f376:	0f 83 64 fc ff ff    	jae    2efe0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1470>
   2f37c:	45 29 c4             	sub    %r8d,%r12d
   2f37f:	41 ff c4             	inc    %r12d
   2f382:	41 83 e4 03          	and    $0x3,%r12d
   2f386:	74 32                	je     2f3ba <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x184a>
   2f388:	4a 8d 14 c5 70 00 00 	lea    0x70(,%r8,8),%rdx
   2f38f:	00 
   2f390:	48 01 ea             	add    %rbp,%rdx
   2f393:	31 c9                	xor    %ecx,%ecx
   2f395:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f39c:	00 00 00 00 
   2f3a0:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   2f3a4:	48 89 2e             	mov    %rbp,(%rsi)
   2f3a7:	42 8d 3c 29          	lea    (%rcx,%r13,1),%edi
   2f3ab:	66 89 7e 60          	mov    %di,0x60(%rsi)
   2f3af:	48 ff c1             	inc    %rcx
   2f3b2:	49 39 cc             	cmp    %rcx,%r12
   2f3b5:	75 e9                	jne    2f3a0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1830>
   2f3b7:	49 01 cd             	add    %rcx,%r13
   2f3ba:	41 83 f9 03          	cmp    $0x3,%r9d
   2f3be:	0f 82 1c fc ff ff    	jb     2efe0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1470>
   2f3c4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f3cb:	00 00 00 00 00 
   2f3d0:	4a 8b 4c ed 68       	mov    0x68(%rbp,%r13,8),%rcx
   2f3d5:	48 89 29             	mov    %rbp,(%rcx)
   2f3d8:	66 44 89 69 60       	mov    %r13w,0x60(%rcx)
   2f3dd:	4a 8b 4c ed 70       	mov    0x70(%rbp,%r13,8),%rcx
   2f3e2:	48 89 29             	mov    %rbp,(%rcx)
   2f3e5:	41 8d 55 01          	lea    0x1(%r13),%edx
   2f3e9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f3ed:	4a 8b 4c ed 78       	mov    0x78(%rbp,%r13,8),%rcx
   2f3f2:	48 89 29             	mov    %rbp,(%rcx)
   2f3f5:	41 8d 55 02          	lea    0x2(%r13),%edx
   2f3f9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f3fd:	4a 8b 8c ed 80 00 00 	mov    0x80(%rbp,%r13,8),%rcx
   2f404:	00 
   2f405:	48 89 29             	mov    %rbp,(%rcx)
   2f408:	41 8d 55 03          	lea    0x3(%r13),%edx
   2f40c:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f410:	49 83 c5 04          	add    $0x4,%r13
   2f414:	49 39 c5             	cmp    %rax,%r13
   2f417:	75 b7                	jne    2f3d0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1860>
   2f419:	e9 c2 fb ff ff       	jmp    2efe0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1470>
   2f41e:	4c 8b ac 24 c0 00 00 	mov    0xc0(%rsp),%r13
   2f425:	00 
   2f426:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2f42b:	48 89 cb             	mov    %rcx,%rbx
   2f42e:	bf c8 00 00 00       	mov    $0xc8,%edi
   2f433:	ff 15 2f 07 04 00    	call   *0x4072f(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2f439:	48 85 c0             	test   %rax,%rax
   2f43c:	0f 84 62 23 00 00    	je     317a4 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c34>
   2f442:	49 89 c4             	mov    %rax,%r12
   2f445:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f44c:	66 c7 40 62 00 00    	movw   $0x0,0x62(%rax)
   2f452:	4c 89 70 68          	mov    %r14,0x68(%rax)
   2f456:	48 8b 8c 24 50 01 00 	mov    0x150(%rsp),%rcx
   2f45d:	00 
   2f45e:	48 89 c8             	mov    %rcx,%rax
   2f461:	48 ff c0             	inc    %rax
   2f464:	0f 84 4f 23 00 00    	je     317b9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c49>
   2f46a:	4d 89 26             	mov    %r12,(%r14)
   2f46d:	66 41 c7 46 60 00 00 	movw   $0x0,0x60(%r14)
   2f474:	4c 89 a4 24 b8 01 00 	mov    %r12,0x1b8(%rsp)
   2f47b:	00 
   2f47c:	48 89 84 24 c0 01 00 	mov    %rax,0x1c0(%rsp)
   2f483:	00 
   2f484:	48 39 cb             	cmp    %rcx,%rbx
   2f487:	0f 85 3e 23 00 00    	jne    317cb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c5b>
   2f48d:	66 41 c7 44 24 62 01 	movw   $0x1,0x62(%r12)
   2f494:	00 
   2f495:	8b 8c 24 1c 01 00 00 	mov    0x11c(%rsp),%ecx
   2f49c:	41 89 4c 24 08       	mov    %ecx,0x8(%r12)
   2f4a1:	8b 8c 24 18 01 00 00 	mov    0x118(%rsp),%ecx
   2f4a8:	41 89 4c 24 34       	mov    %ecx,0x34(%r12)
   2f4ad:	4d 89 7c 24 70       	mov    %r15,0x70(%r12)
   2f4b2:	4d 89 27             	mov    %r12,(%r15)
   2f4b5:	66 41 c7 47 60 01 00 	movw   $0x1,0x60(%r15)
   2f4bc:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   2f4c3:	00 
   2f4c4:	4d 89 e6             	mov    %r12,%r14
   2f4c7:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
   2f4ce:	00 
   2f4cf:	4c 8b a4 24 20 01 00 	mov    0x120(%rsp),%r12
   2f4d6:	00 
   2f4d7:	e9 69 f8 ff ff       	jmp    2ed45 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11d5>
   2f4dc:	4d 8d 69 01          	lea    0x1(%r9),%r13
   2f4e0:	66 45 39 d1          	cmp    %r10w,%r9w
   2f4e4:	0f 83 b4 00 00 00    	jae    2f59e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1a2e>
   2f4ea:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   2f4ee:	4a 8d 34 8b          	lea    (%rbx,%r9,4),%rsi
   2f4f2:	48 83 c6 08          	add    $0x8,%rsi
   2f4f6:	42 8d 2c ad 00 00 00 	lea    0x0(,%r13,4),%ebp
   2f4fd:	00 
   2f4fe:	48 01 ef             	add    %rbp,%rdi
   2f501:	4d 89 d7             	mov    %r10,%r15
   2f504:	4d 29 cf             	sub    %r9,%r15
   2f507:	4a 8d 14 bd 00 00 00 	lea    0x0(,%r15,4),%rdx
   2f50e:	00 
   2f50f:	48 8b 05 ca 06 04 00 	mov    0x406ca(%rip),%rax        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f516:	4c 89 4c 24 48       	mov    %r9,0x48(%rsp)
   2f51b:	ff d0                	call   *%rax
   2f51d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f522:	44 8d 24 85 00 00 00 	lea    0x0(,%rax,4),%r12d
   2f529:	00 
   2f52a:	4a 8d 34 23          	lea    (%rbx,%r12,1),%rsi
   2f52e:	48 83 c6 34          	add    $0x34,%rsi
   2f532:	48 8d 3c 2b          	lea    (%rbx,%rbp,1),%rdi
   2f536:	48 83 c7 34          	add    $0x34,%rdi
   2f53a:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2f53f:	4a 8d 14 bd 00 00 00 	lea    0x0(,%r15,4),%rdx
   2f546:	00 
   2f547:	ff 15 93 06 04 00    	call   *0x40693(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f54d:	8b 84 24 10 01 00 00 	mov    0x110(%rsp),%eax
   2f554:	42 89 44 23 08       	mov    %eax,0x8(%rbx,%r12,1)
   2f559:	8b 84 24 14 01 00 00 	mov    0x114(%rsp),%eax
   2f560:	42 89 44 23 34       	mov    %eax,0x34(%rbx,%r12,1)
   2f565:	4a 8d 34 eb          	lea    (%rbx,%r13,8),%rsi
   2f569:	48 83 c6 68          	add    $0x68,%rsi
   2f56d:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2f572:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
   2f576:	48 83 c7 78          	add    $0x78,%rdi
   2f57a:	49 c1 e7 03          	shl    $0x3,%r15
   2f57e:	4c 89 fa             	mov    %r15,%rdx
   2f581:	ff 15 59 06 04 00    	call   *0x40659(%rip)        # 6fbe0 <memmove@GLIBC_2.2.5>
   2f587:	4c 8b 94 24 78 01 00 	mov    0x178(%rsp),%r10
   2f58e:	00 
   2f58f:	4c 8b 84 24 e8 01 00 	mov    0x1e8(%rsp),%r8
   2f596:	00 
   2f597:	4c 8b 4c 24 48       	mov    0x48(%rsp),%r9
   2f59c:	eb 0d                	jmp    2f5ab <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1a3b>
   2f59e:	4d 89 f8             	mov    %r15,%r8
   2f5a1:	42 89 7c 8b 08       	mov    %edi,0x8(%rbx,%r9,4)
   2f5a6:	42 89 74 8b 34       	mov    %esi,0x34(%rbx,%r9,4)
   2f5ab:	4c 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%r15
   2f5b2:	00 
   2f5b3:	4c 8b a4 24 20 01 00 	mov    0x120(%rsp),%r12
   2f5ba:	00 
   2f5bb:	41 8d 4a 01          	lea    0x1(%r10),%ecx
   2f5bf:	49 8d 42 02          	lea    0x2(%r10),%rax
   2f5c3:	4e 89 44 cb 70       	mov    %r8,0x70(%rbx,%r9,8)
   2f5c8:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2f5cc:	41 39 c5             	cmp    %eax,%r13d
   2f5cf:	0f 83 68 f7 ff ff    	jae    2ed3d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11cd>
   2f5d5:	44 89 d1             	mov    %r10d,%ecx
   2f5d8:	44 29 c9             	sub    %r9d,%ecx
   2f5db:	ff c1                	inc    %ecx
   2f5dd:	83 e1 03             	and    $0x3,%ecx
   2f5e0:	74 29                	je     2f60b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1a9b>
   2f5e2:	4a 8d 34 cb          	lea    (%rbx,%r9,8),%rsi
   2f5e6:	48 83 c6 70          	add    $0x70,%rsi
   2f5ea:	31 d2                	xor    %edx,%edx
   2f5ec:	0f 1f 40 00          	nopl   0x0(%rax)
   2f5f0:	48 8b 3c d6          	mov    (%rsi,%rdx,8),%rdi
   2f5f4:	48 89 1f             	mov    %rbx,(%rdi)
   2f5f7:	46 8d 04 2a          	lea    (%rdx,%r13,1),%r8d
   2f5fb:	66 44 89 47 60       	mov    %r8w,0x60(%rdi)
   2f600:	48 ff c2             	inc    %rdx
   2f603:	48 39 d1             	cmp    %rdx,%rcx
   2f606:	75 e8                	jne    2f5f0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1a80>
   2f608:	49 01 d5             	add    %rdx,%r13
   2f60b:	4d 29 ca             	sub    %r9,%r10
   2f60e:	41 83 fa 03          	cmp    $0x3,%r10d
   2f612:	0f 82 25 f7 ff ff    	jb     2ed3d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11cd>
   2f618:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f61f:	00 
   2f620:	4a 8b 4c eb 68       	mov    0x68(%rbx,%r13,8),%rcx
   2f625:	48 89 19             	mov    %rbx,(%rcx)
   2f628:	66 44 89 69 60       	mov    %r13w,0x60(%rcx)
   2f62d:	4a 8b 4c eb 70       	mov    0x70(%rbx,%r13,8),%rcx
   2f632:	48 89 19             	mov    %rbx,(%rcx)
   2f635:	41 8d 55 01          	lea    0x1(%r13),%edx
   2f639:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f63d:	4a 8b 4c eb 78       	mov    0x78(%rbx,%r13,8),%rcx
   2f642:	48 89 19             	mov    %rbx,(%rcx)
   2f645:	41 8d 55 02          	lea    0x2(%r13),%edx
   2f649:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f64d:	4a 8b 8c eb 80 00 00 	mov    0x80(%rbx,%r13,8),%rcx
   2f654:	00 
   2f655:	48 89 19             	mov    %rbx,(%rcx)
   2f658:	41 8d 55 03          	lea    0x3(%r13),%edx
   2f65c:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2f660:	49 83 c5 04          	add    $0x4,%r13
   2f664:	49 39 c5             	cmp    %rax,%r13
   2f667:	75 b7                	jne    2f620 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ab0>
   2f669:	e9 cf f6 ff ff       	jmp    2ed3d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x11cd>
   2f66e:	48 8d bc 24 80 01 00 	lea    0x180(%rsp),%rdi
   2f675:	00 
   2f676:	4c 89 fe             	mov    %r15,%rsi
   2f679:	48 89 ea             	mov    %rbp,%rdx
   2f67c:	e8 2f 95 ff ff       	call   28bb0 <_RINvMs6_NtCs3BTM885nGDo_9hashbrown3rawINtB6_8RawTableTllEE14reserve_rehashNCINvNtB8_3map11make_hasherllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE0ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f681:	e9 26 f3 ff ff       	jmp    2e9ac <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xe3c>
   2f686:	ba 04 00 00 00       	mov    $0x4,%edx
   2f68b:	b9 01 00 00 00       	mov    $0x1,%ecx
   2f690:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2f696:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
   2f69d:	00 
   2f69e:	e8 ed ce ff ff       	call   2c590 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f6a3:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
   2f6aa:	00 
   2f6ab:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   2f6b2:	00 
   2f6b3:	48 8b 6c 24 08       	mov    0x8(%rsp),%rbp
   2f6b8:	e9 c3 f6 ff ff       	jmp    2ed80 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1210>
   2f6bd:	ba 04 00 00 00       	mov    $0x4,%edx
   2f6c2:	b9 01 00 00 00       	mov    $0x1,%ecx
   2f6c7:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2f6cd:	48 8d bc 24 38 01 00 	lea    0x138(%rsp),%rdi
   2f6d4:	00 
   2f6d5:	e8 b6 ce ff ff       	call   2c590 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f6da:	48 8b 8c 24 40 01 00 	mov    0x140(%rsp),%rcx
   2f6e1:	00 
   2f6e2:	48 8b b4 24 48 01 00 	mov    0x148(%rsp),%rsi
   2f6e9:	00 
   2f6ea:	e9 b5 f6 ff ff       	jmp    2eda4 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1234>
   2f6ef:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2f6f3:	66 0f d7 f0          	pmovmskb %xmm0,%esi
   2f6f7:	f3 0f bc f6          	tzcnt  %esi,%esi
   2f6fb:	0f b6 3c 30          	movzbl (%rax,%rsi,1),%edi
   2f6ff:	e9 b1 f4 ff ff       	jmp    2ebb5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1045>
   2f704:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   2f70b:	00 00 00 00 00 
   2f710:	45 31 f6             	xor    %r14d,%r14d
   2f713:	4c 8b a4 24 f0 00 00 	mov    0xf0(%rsp),%r12
   2f71a:	00 
   2f71b:	4d 85 e4             	test   %r12,%r12
   2f71e:	74 1a                	je     2f73a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1bca>
   2f720:	49 8b 5c 24 08       	mov    0x8(%r12),%rbx
   2f725:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   2f72a:	4d 85 ff             	test   %r15,%r15
   2f72d:	74 10                	je     2f73f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1bcf>
   2f72f:	49 83 ff 10          	cmp    $0x10,%r15
   2f733:	73 12                	jae    2f747 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1bd7>
   2f735:	45 31 e4             	xor    %r12d,%r12d
   2f738:	eb 1e                	jmp    2f758 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1be8>
   2f73a:	bb 04 00 00 00       	mov    $0x4,%ebx
   2f73f:	45 31 ff             	xor    %r15d,%r15d
   2f742:	45 31 e4             	xor    %r12d,%r12d
   2f745:	eb 11                	jmp    2f758 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1be8>
   2f747:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   2f74c:	49 83 c4 18          	add    $0x18,%r12
   2f750:	85 c0                	test   %eax,%eax
   2f752:	0f 85 b6 20 00 00    	jne    3180e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c9e>
   2f758:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2f75f:	00 00 
   2f761:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   2f766:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   2f76b:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   2f770:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2f777:	00 00 
   2f779:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   2f77e:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   2f783:	e8 78 3f 00 00       	call   33700 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCsiicy3ks7M05_4pbrs3map11MapViewIterllEE9from_iterCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f788:	48 8b 74 24 60       	mov    0x60(%rsp),%rsi
   2f78d:	48 85 f6             	test   %rsi,%rsi
   2f790:	74 1e                	je     2f7b0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1c40>
   2f792:	48 83 fe 01          	cmp    $0x1,%rsi
   2f796:	0f 85 ef 1f 00 00    	jne    3178b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c1b>
   2f79c:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   2f7a3:	00 
   2f7a4:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   2f7a9:	e8 62 9b ff ff       	call   29310 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f7ae:	eb 2b                	jmp    2f7db <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1c6b>
   2f7b0:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
   2f7b7:	00 00 00 00 00 
   2f7bc:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
   2f7c3:	00 00 00 00 00 
   2f7c8:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
   2f7ce:	74 0b                	je     2f7db <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1c6b>
   2f7d0:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   2f7d5:	ff 15 75 03 04 00    	call   *0x40375(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   2f7db:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   2f7e2:	00 
   2f7e3:	48 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%rsi
   2f7ea:	00 
   2f7eb:	e8 e0 51 00 00       	call   349d0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f7f0:	84 c0                	test   %al,%al
   2f7f2:	0f 84 20 1f 00 00    	je     31718 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ba8>
   2f7f8:	48 8b 8c 24 98 01 00 	mov    0x198(%rsp),%rcx
   2f7ff:	00 
   2f800:	48 85 c9             	test   %rcx,%rcx
   2f803:	0f 84 90 00 00 00    	je     2f899 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1d29>
   2f809:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2f810:	ff ff 1f 
   2f813:	4c 8b ac 24 80 01 00 	mov    0x180(%rsp),%r13
   2f81a:	00 
   2f81b:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2f821:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   2f825:	49 8d 5d 10          	lea    0x10(%r13),%rbx
   2f829:	66 83 f5 ff          	xor    $0xffff,%bp
   2f82d:	75 17                	jne    2f846 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1cd6>
   2f82f:	90                   	nop
   2f830:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   2f834:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2f838:	48 83 c3 10          	add    $0x10,%rbx
   2f83c:	66 0f d7 e8          	pmovmskb %xmm0,%ebp
   2f840:	66 83 f5 ff          	xor    $0xffff,%bp
   2f844:	74 ea                	je     2f830 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1cc0>
   2f846:	48 83 f9 05          	cmp    $0x5,%rcx
   2f84a:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2f850:	be 04 00 00 00       	mov    $0x4,%esi
   2f855:	48 0f 43 f1          	cmovae %rcx,%rsi
   2f859:	4c 8d 24 f5 00 00 00 	lea    0x0(,%rsi,8),%r12
   2f860:	00 
   2f861:	48 ff c0             	inc    %rax
   2f864:	48 39 c1             	cmp    %rax,%rcx
   2f867:	0f 97 c0             	seta   %al
   2f86a:	48 89 ca             	mov    %rcx,%rdx
   2f86d:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2f874:	ff ff 7f 
   2f877:	48 83 c1 0b          	add    $0xb,%rcx
   2f87b:	49 39 cc             	cmp    %rcx,%r12
   2f87e:	0f 97 c1             	seta   %cl
   2f881:	08 c1                	or     %al,%cl
   2f883:	74 2b                	je     2f8b0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1d40>
   2f885:	45 31 ff             	xor    %r15d,%r15d
   2f888:	4c 89 ff             	mov    %r15,%rdi
   2f88b:	4c 89 e6             	mov    %r12,%rsi
   2f88e:	ff 15 84 02 04 00    	call   *0x40284(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   2f894:	e9 e0 22 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   2f899:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   2f8a0:	00 00 
   2f8a2:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
   2f8a9:	00 00 
   2f8ab:	e9 ce 01 00 00       	jmp    2fa7e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f0e>
   2f8b0:	48 89 b4 24 90 00 00 	mov    %rsi,0x90(%rsp)
   2f8b7:	00 
   2f8b8:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2f8bd:	f3 0f bc c5          	tzcnt  %ebp,%eax
   2f8c1:	c1 e0 03             	shl    $0x3,%eax
   2f8c4:	4c 89 e9             	mov    %r13,%rcx
   2f8c7:	48 29 c1             	sub    %rax,%rcx
   2f8ca:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2f8cf:	66 0f 7f 84 24 c0 00 	movdqa %xmm0,0xc0(%rsp)
   2f8d6:	00 00 
   2f8d8:	4c 89 e7             	mov    %r12,%rdi
   2f8db:	ff 15 87 02 04 00    	call   *0x40287(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2f8e1:	48 85 c0             	test   %rax,%rax
   2f8e4:	74 a2                	je     2f888 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1d18>
   2f8e6:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2f8eb:	49 89 cf             	mov    %rcx,%r15
   2f8ee:	66 0f 6f 84 24 c0 00 	movdqa 0xc0(%rsp),%xmm0
   2f8f5:	00 00 
   2f8f7:	66 0f d6 00          	movq   %xmm0,(%rax)
   2f8fb:	4c 8b a4 24 90 00 00 	mov    0x90(%rsp),%r12
   2f902:	00 
   2f903:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2f908:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2f90d:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2f914:	00 00 
   2f916:	49 ff cf             	dec    %r15
   2f919:	0f 84 41 01 00 00    	je     2fa60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ef0>
   2f91f:	44 8d 65 ff          	lea    -0x1(%rbp),%r12d
   2f923:	41 21 ec             	and    %ebp,%r12d
   2f926:	b9 01 00 00 00       	mov    $0x1,%ecx
   2f92b:	eb 32                	jmp    2f95f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1def>
   2f92d:	0f 1f 00             	nopl   (%rax)
   2f930:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2f935:	41 8d 54 24 ff       	lea    -0x1(%r12),%edx
   2f93a:	44 21 e2             	and    %r12d,%edx
   2f93d:	49 ff cf             	dec    %r15
   2f940:	66 0f 6f 84 24 90 00 	movdqa 0x90(%rsp),%xmm0
   2f947:	00 00 
   2f949:	66 0f d6 04 e8       	movq   %xmm0,(%rax,%rbp,8)
   2f94e:	48 8d 4d 01          	lea    0x1(%rbp),%rcx
   2f952:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2f957:	41 89 d4             	mov    %edx,%r12d
   2f95a:	4d 85 ff             	test   %r15,%r15
   2f95d:	74 6b                	je     2f9ca <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e5a>
   2f95f:	48 89 cd             	mov    %rcx,%rbp
   2f962:	66 45 85 e4          	test   %r12w,%r12w
   2f966:	75 20                	jne    2f988 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e18>
   2f968:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f96f:	00 
   2f970:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   2f974:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2f978:	48 83 c3 10          	add    $0x10,%rbx
   2f97c:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2f981:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2f986:	74 e8                	je     2f970 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e00>
   2f988:	f3 41 0f bc cc       	tzcnt  %r12d,%ecx
   2f98d:	c1 e1 03             	shl    $0x3,%ecx
   2f990:	4c 89 ea             	mov    %r13,%rdx
   2f993:	48 29 ca             	sub    %rcx,%rdx
   2f996:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2f99b:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   2f9a2:	00 
   2f9a3:	48 3b 6c 24 10       	cmp    0x10(%rsp),%rbp
   2f9a8:	75 8b                	jne    2f935 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1dc5>
   2f9aa:	b9 04 00 00 00       	mov    $0x4,%ecx
   2f9af:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2f9b5:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2f9ba:	48 89 ee             	mov    %rbp,%rsi
   2f9bd:	4c 89 fa             	mov    %r15,%rdx
   2f9c0:	e8 cb cb ff ff       	call   2c590 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2f9c5:	e9 66 ff ff ff       	jmp    2f930 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1dc0>
   2f9ca:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   2f9cf:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2f9d4:	48 83 fd 14          	cmp    $0x14,%rbp
   2f9d8:	0f 83 43 1e 00 00    	jae    31821 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cb1>
   2f9de:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2f9e3:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
   2f9e7:	48 8d 78 08          	lea    0x8(%rax),%rdi
   2f9eb:	31 d2                	xor    %edx,%edx
   2f9ed:	49 89 c2             	mov    %rax,%r10
   2f9f0:	eb 20                	jmp    2fa12 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ea2>
   2f9f2:	49 01 c1             	add    %rax,%r9
   2f9f5:	4d 89 cb             	mov    %r9,%r11
   2f9f8:	49 c1 e0 20          	shl    $0x20,%r8
   2f9fc:	49 09 f8             	or     %rdi,%r8
   2f9ff:	4d 89 03             	mov    %r8,(%r11)
   2fa02:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
   2fa06:	48 83 c2 08          	add    $0x8,%rdx
   2fa0a:	49 89 f2             	mov    %rsi,%r10
   2fa0d:	48 39 cf             	cmp    %rcx,%rdi
   2fa10:	74 49                	je     2fa5b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1eeb>
   2fa12:	48 89 fe             	mov    %rdi,%rsi
   2fa15:	41 8b 7a 08          	mov    0x8(%r10),%edi
   2fa19:	41 3b 3a             	cmp    (%r10),%edi
   2fa1c:	7d e4                	jge    2fa02 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e92>
   2fa1e:	45 8b 42 0c          	mov    0xc(%r10),%r8d
   2fa22:	4d 8b 0a             	mov    (%r10),%r9
   2fa25:	4d 89 4a 08          	mov    %r9,0x8(%r10)
   2fa29:	49 89 d1             	mov    %rdx,%r9
   2fa2c:	49 89 c3             	mov    %rax,%r11
   2fa2f:	49 39 c2             	cmp    %rax,%r10
   2fa32:	74 c4                	je     2f9f8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e88>
   2fa34:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fa3b:	00 00 00 00 00 
   2fa40:	42 3b 7c 08 f8       	cmp    -0x8(%rax,%r9,1),%edi
   2fa45:	7d ab                	jge    2f9f2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e82>
   2fa47:	4e 8b 54 08 f8       	mov    -0x8(%rax,%r9,1),%r10
   2fa4c:	4e 89 14 08          	mov    %r10,(%rax,%r9,1)
   2fa50:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   2fa54:	75 ea                	jne    2fa40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ed0>
   2fa56:	49 89 c3             	mov    %rax,%r11
   2fa59:	eb 9d                	jmp    2f9f8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1e88>
   2fa5b:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   2fa60:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2fa65:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2fa6a:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2fa6f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   2fa74:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   2fa79:	e8 92 98 ff ff       	call   29310 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2fa7e:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   2fa83:	48 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%rsi
   2fa8a:	00 
   2fa8b:	e8 40 4f 00 00       	call   349d0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2fa90:	84 c0                	test   %al,%al
   2fa92:	0f 84 a1 1c 00 00    	je     31739 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3bc9>
   2fa98:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   2fa9d:	48 89 7c 24 48       	mov    %rdi,0x48(%rsp)
   2faa2:	e8 29 a1 ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2faa7:	48 8b ac 24 f0 00 00 	mov    0xf0(%rsp),%rbp
   2faae:	00 
   2faaf:	48 85 ed             	test   %rbp,%rbp
   2fab2:	74 17                	je     2facb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f5b>
   2fab4:	4c 8b 7d 08          	mov    0x8(%rbp),%r15
   2fab8:	4c 8b 6d 10          	mov    0x10(%rbp),%r13
   2fabc:	4d 85 ed             	test   %r13,%r13
   2fabf:	74 10                	je     2fad1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f61>
   2fac1:	49 83 fd 10          	cmp    $0x10,%r13
   2fac5:	73 11                	jae    2fad8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f68>
   2fac7:	31 ed                	xor    %ebp,%ebp
   2fac9:	eb 1c                	jmp    2fae7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f77>
   2facb:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2fad1:	45 31 ed             	xor    %r13d,%r13d
   2fad4:	31 ed                	xor    %ebp,%ebp
   2fad6:	eb 0f                	jmp    2fae7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f77>
   2fad8:	8b 45 30             	mov    0x30(%rbp),%eax
   2fadb:	48 83 c5 18          	add    $0x18,%rbp
   2fadf:	85 c0                	test   %eax,%eax
   2fae1:	0f 85 75 1d 00 00    	jne    3185c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cec>
   2fae7:	4c 8b 9c 24 28 01 00 	mov    0x128(%rsp),%r11
   2faee:	00 
   2faef:	4d 85 db             	test   %r11,%r11
   2faf2:	0f 84 e9 01 00 00    	je     2fce1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2171>
   2faf8:	49 8d 57 08          	lea    0x8(%r15),%rdx
   2fafc:	4a 8d 3c ed f8 ff ff 	lea    -0x8(,%r13,8),%rdi
   2fb03:	ff 
   2fb04:	45 31 c0             	xor    %r8d,%r8d
   2fb07:	eb 13                	jmp    2fb1c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fac>
   2fb09:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2fb10:	49 89 c0             	mov    %rax,%r8
   2fb13:	49 ff cb             	dec    %r11
   2fb16:	0f 84 c8 01 00 00    	je     2fce4 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2174>
   2fb1c:	4c 89 e9             	mov    %r13,%rcx
   2fb1f:	4c 29 c1             	sub    %r8,%rcx
   2fb22:	b8 00 00 00 00       	mov    $0x0,%eax
   2fb27:	48 0f 43 c1          	cmovae %rcx,%rax
   2fb2b:	49 83 fd 02          	cmp    $0x2,%r13
   2fb2f:	73 1f                	jae    2fb50 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fe0>
   2fb31:	4c 39 d8             	cmp    %r11,%rax
   2fb34:	0f 85 05 1a 00 00    	jne    3153f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39cf>
   2fb3a:	48 85 ed             	test   %rbp,%rbp
   2fb3d:	74 3a                	je     2fb79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2009>
   2fb3f:	48 8b 5d 10          	mov    0x10(%rbp),%rbx
   2fb43:	e9 aa 00 00 00       	jmp    2fbf2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2082>
   2fb48:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2fb4f:	00 
   2fb50:	48 85 ed             	test   %rbp,%rbp
   2fb53:	74 1b                	je     2fb70 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2000>
   2fb55:	48 8b 5d 10          	mov    0x10(%rbp),%rbx
   2fb59:	4c 39 eb             	cmp    %r13,%rbx
   2fb5c:	0f 85 87 00 00 00    	jne    2fbe9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2079>
   2fb62:	4c 39 d8             	cmp    %r11,%rax
   2fb65:	0f 84 8c 00 00 00    	je     2fbf7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2087>
   2fb6b:	e9 cf 19 00 00       	jmp    3153f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39cf>
   2fb70:	4c 39 d8             	cmp    %r11,%rax
   2fb73:	0f 82 c6 19 00 00    	jb     3153f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39cf>
   2fb79:	4d 39 e8             	cmp    %r13,%r8
   2fb7c:	0f 83 7c 1d 00 00    	jae    318fe <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d8e>
   2fb82:	4a 8d 04 c5 00 00 00 	lea    0x0(,%r8,8),%rax
   2fb89:	00 
   2fb8a:	48 89 fe             	mov    %rdi,%rsi
   2fb8d:	48 29 c6             	sub    %rax,%rsi
   2fb90:	4a 8d 1c c2          	lea    (%rdx,%r8,8),%rbx
   2fb94:	49 8d 40 01          	lea    0x1(%r8),%rax
   2fb98:	4c 39 e8             	cmp    %r13,%rax
   2fb9b:	0f 84 6f ff ff ff    	je     2fb10 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fa0>
   2fba1:	43 8b 0c c7          	mov    (%r15,%r8,8),%ecx
   2fba5:	45 31 c0             	xor    %r8d,%r8d
   2fba8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2fbaf:	00 
   2fbb0:	42 39 0c 03          	cmp    %ecx,(%rbx,%r8,1)
   2fbb4:	74 1a                	je     2fbd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2060>
   2fbb6:	49 83 c0 08          	add    $0x8,%r8
   2fbba:	4c 39 c6             	cmp    %r8,%rsi
   2fbbd:	75 f1                	jne    2fbb0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2040>
   2fbbf:	e9 4c ff ff ff       	jmp    2fb10 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fa0>
   2fbc4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fbcb:	00 00 00 00 00 
   2fbd0:	48 83 c3 08          	add    $0x8,%rbx
   2fbd4:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   2fbd8:	49 89 c0             	mov    %rax,%r8
   2fbdb:	49 8d 40 01          	lea    0x1(%r8),%rax
   2fbdf:	4c 39 e8             	cmp    %r13,%rax
   2fbe2:	75 bd                	jne    2fba1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2031>
   2fbe4:	e9 27 ff ff ff       	jmp    2fb10 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fa0>
   2fbe9:	4c 39 d8             	cmp    %r11,%rax
   2fbec:	0f 82 4d 19 00 00    	jb     3153f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39cf>
   2fbf2:	4c 39 eb             	cmp    %r13,%rbx
   2fbf5:	75 19                	jne    2fc10 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x20a0>
   2fbf7:	4d 39 e8             	cmp    %r13,%r8
   2fbfa:	0f 82 d9 00 00 00    	jb     2fcd9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2169>
   2fc00:	e9 f9 1c 00 00       	jmp    318fe <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d8e>
   2fc05:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2fc0c:	00 00 00 00 
   2fc10:	be 28 00 00 00       	mov    $0x28,%esi
   2fc15:	4d 39 e8             	cmp    %r13,%r8
   2fc18:	0f 83 e5 1c 00 00    	jae    31903 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d93>
   2fc1e:	4c 8b 65 08          	mov    0x8(%rbp),%r12
   2fc22:	48 83 fb 01          	cmp    $0x1,%rbx
   2fc26:	0f 84 82 00 00 00    	je     2fcae <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x213e>
   2fc2c:	48 89 ee             	mov    %rbp,%rsi
   2fc2f:	48 89 d5             	mov    %rdx,%rbp
   2fc32:	48 85 db             	test   %rbx,%rbx
   2fc35:	75 12                	jne    2fc49 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x20d9>
   2fc37:	e9 08 1c 00 00       	jmp    31844 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cd4>
   2fc3c:	0f 1f 40 00          	nopl   0x0(%rax)
   2fc40:	4d 39 e8             	cmp    %r13,%r8
   2fc43:	0f 84 fb 1b 00 00    	je     31844 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3cd4>
   2fc49:	4c 89 c0             	mov    %r8,%rax
   2fc4c:	43 8b 0c c7          	mov    (%r15,%r8,8),%ecx
   2fc50:	49 89 d8             	mov    %rbx,%r8
   2fc53:	31 ff                	xor    %edi,%edi
   2fc55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2fc5c:	00 00 00 00 
   2fc60:	49 89 fa             	mov    %rdi,%r10
   2fc63:	4c 89 c2             	mov    %r8,%rdx
   2fc66:	48 d1 ea             	shr    $1,%rdx
   2fc69:	48 01 d7             	add    %rdx,%rdi
   2fc6c:	49 89 f9             	mov    %rdi,%r9
   2fc6f:	49 c1 e1 04          	shl    $0x4,%r9
   2fc73:	43 39 0c 0c          	cmp    %ecx,(%r12,%r9,1)
   2fc77:	49 0f 4f fa          	cmovg  %r10,%rdi
   2fc7b:	49 29 d0             	sub    %rdx,%r8
   2fc7e:	49 83 f8 01          	cmp    $0x1,%r8
   2fc82:	77 dc                	ja     2fc60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x20f0>
   2fc84:	4c 8d 40 01          	lea    0x1(%rax),%r8
   2fc88:	48 c1 e7 04          	shl    $0x4,%rdi
   2fc8c:	41 39 0c 3c          	cmp    %ecx,(%r12,%rdi,1)
   2fc90:	75 ae                	jne    2fc40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x20d0>
   2fc92:	4c 01 e7             	add    %r12,%rdi
   2fc95:	48 39 47 08          	cmp    %rax,0x8(%rdi)
   2fc99:	75 a5                	jne    2fc40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x20d0>
   2fc9b:	48 89 ea             	mov    %rbp,%rdx
   2fc9e:	48 89 f5             	mov    %rsi,%rbp
   2fca1:	4a 8d 3c ed f8 ff ff 	lea    -0x8(,%r13,8),%rdi
   2fca8:	ff 
   2fca9:	e9 65 fe ff ff       	jmp    2fb13 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fa3>
   2fcae:	41 8b 04 24          	mov    (%r12),%eax
   2fcb2:	eb 18                	jmp    2fccc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x215c>
   2fcb4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fcbb:	00 00 00 00 00 
   2fcc0:	49 ff c0             	inc    %r8
   2fcc3:	4d 39 c5             	cmp    %r8,%r13
   2fcc6:	0f 84 37 1c 00 00    	je     31903 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d93>
   2fccc:	43 3b 04 c7          	cmp    (%r15,%r8,8),%eax
   2fcd0:	75 ee                	jne    2fcc0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2150>
   2fcd2:	4d 3b 44 24 08       	cmp    0x8(%r12),%r8
   2fcd7:	75 e7                	jne    2fcc0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2150>
   2fcd9:	49 ff c0             	inc    %r8
   2fcdc:	e9 32 fe ff ff       	jmp    2fb13 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1fa3>
   2fce1:	45 31 c0             	xor    %r8d,%r8d
   2fce4:	31 c0                	xor    %eax,%eax
   2fce6:	4c 89 e9             	mov    %r13,%rcx
   2fce9:	4c 29 c1             	sub    %r8,%rcx
   2fcec:	48 0f 43 c1          	cmovae %rcx,%rax
   2fcf0:	49 83 fd 02          	cmp    $0x2,%r13
   2fcf4:	72 13                	jb     2fd09 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2199>
   2fcf6:	48 85 ed             	test   %rbp,%rbp
   2fcf9:	0f 84 99 00 00 00    	je     2fd98 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2228>
   2fcff:	4c 39 6d 10          	cmp    %r13,0x10(%rbp)
   2fd03:	0f 85 8f 00 00 00    	jne    2fd98 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2228>
   2fd09:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   2fd0e:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
   2fd15:	00 00 
   2fd17:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2fd1c:	4d 39 c5             	cmp    %r8,%r13
   2fd1f:	0f 87 93 00 00 00    	ja     2fdb8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2248>
   2fd25:	48 85 ed             	test   %rbp,%rbp
   2fd28:	74 2e                	je     2fd58 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x21e8>
   2fd2a:	48 8b 75 10          	mov    0x10(%rbp),%rsi
   2fd2e:	4c 39 ee             	cmp    %r13,%rsi
   2fd31:	0f 85 90 00 00 00    	jne    2fdc7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2257>
   2fd37:	4d 39 e8             	cmp    %r13,%r8
   2fd3a:	0f 83 7c 01 00 00    	jae    2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fd40:	48 8d 15 51 e5 03 00 	lea    0x3e551(%rip),%rdx        # 6e298 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c8>
   2fd47:	be 28 00 00 00       	mov    $0x28,%esi
   2fd4c:	48 8d 3d 75 95 fd ff 	lea    -0x26a8b(%rip),%rdi        # 92c8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x191>
   2fd53:	e9 fa 17 00 00       	jmp    31552 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39e2>
   2fd58:	4d 39 e8             	cmp    %r13,%r8
   2fd5b:	0f 83 5b 01 00 00    	jae    2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fd61:	4a 8d 14 c5 00 00 00 	lea    0x0(,%r8,8),%rdx
   2fd68:	00 
   2fd69:	4b 8d 0c c7          	lea    (%r15,%r8,8),%rcx
   2fd6d:	48 83 c1 08          	add    $0x8,%rcx
   2fd71:	4a 8d 04 ed 00 00 00 	lea    0x0(,%r13,8),%rax
   2fd78:	00 
   2fd79:	48 29 d0             	sub    %rdx,%rax
   2fd7c:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
   2fd80:	4c 8d 15 11 e5 03 00 	lea    0x3e511(%rip),%r10        # 6e298 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c8>
   2fd87:	48 8d 15 3a 95 fd ff 	lea    -0x26ac6(%rip),%rdx        # 92c8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x191>
   2fd8e:	be 28 00 00 00       	mov    $0x28,%esi
   2fd93:	e9 61 18 00 00       	jmp    315f9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a89>
   2fd98:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2fd9f:	00 00 
   2fda1:	48 c7 44 24 18 01 00 	movq   $0x1,0x18(%rsp)
   2fda8:	00 00 
   2fdaa:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2fdaf:	4d 39 c5             	cmp    %r8,%r13
   2fdb2:	0f 86 6d ff ff ff    	jbe    2fd25 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x21b5>
   2fdb8:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2fdbd:	e8 5f a3 ff ff       	call   2a121 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedTjINtNtB4_6option6OptionjEEBM_ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   2fdc2:	e9 b2 1d 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   2fdc7:	4d 39 e8             	cmp    %r13,%r8
   2fdca:	0f 83 ec 00 00 00    	jae    2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fdd0:	48 85 f6             	test   %rsi,%rsi
   2fdd3:	0f 84 e3 00 00 00    	je     2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fdd9:	48 8b 4d 08          	mov    0x8(%rbp),%rcx
   2fddd:	48 83 fe 01          	cmp    $0x1,%rsi
   2fde1:	75 68                	jne    2fe4b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22db>
   2fde3:	8b 01                	mov    (%rcx),%eax
   2fde5:	48 8d 15 ac e4 03 00 	lea    0x3e4ac(%rip),%rdx        # 6e298 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c8>
   2fdec:	48 8d 3d d5 94 fd ff 	lea    -0x26b2b(%rip),%rdi        # 92c8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x191>
   2fdf3:	eb 17                	jmp    2fe0c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x229c>
   2fdf5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2fdfc:	00 00 00 00 
   2fe00:	49 ff c0             	inc    %r8
   2fe03:	4d 39 c5             	cmp    %r8,%r13
   2fe06:	0f 84 b0 00 00 00    	je     2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fe0c:	43 3b 04 c7          	cmp    (%r15,%r8,8),%eax
   2fe10:	75 ee                	jne    2fe00 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2290>
   2fe12:	4c 3b 41 08          	cmp    0x8(%rcx),%r8
   2fe16:	75 e8                	jne    2fe00 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2290>
   2fe18:	e9 35 1a 00 00       	jmp    31852 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ce2>
   2fe1d:	b3 01                	mov    $0x1,%bl
   2fe1f:	49 89 f7             	mov    %rsi,%r15
   2fe22:	bf 40 00 00 00       	mov    $0x40,%edi
   2fe27:	ff 15 3b fd 03 00    	call   *0x3fd3b(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   2fe2d:	48 85 c0             	test   %rax,%rax
   2fe30:	0f 85 eb e4 ff ff    	jne    2e321 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x7b1>
   2fe36:	bf 08 00 00 00       	mov    $0x8,%edi
   2fe3b:	be 40 00 00 00       	mov    $0x40,%esi
   2fe40:	ff 15 d2 fc 03 00    	call   *0x3fcd2(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   2fe46:	e9 2e 1d 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   2fe4b:	48 8d 15 46 e4 03 00 	lea    0x3e446(%rip),%rdx        # 6e298 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c8>
   2fe52:	48 8d 3d 6f 94 fd ff 	lea    -0x26b91(%rip),%rdi        # 92c8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x191>
   2fe59:	eb 0d                	jmp    2fe68 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22f8>
   2fe5b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2fe60:	49 ff c0             	inc    %r8
   2fe63:	4d 39 e8             	cmp    %r13,%r8
   2fe66:	74 54                	je     2febc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x234c>
   2fe68:	43 8b 04 c7          	mov    (%r15,%r8,8),%eax
   2fe6c:	49 89 f1             	mov    %rsi,%r9
   2fe6f:	45 31 e4             	xor    %r12d,%r12d
   2fe72:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fe79:	1f 84 00 00 00 00 00 
   2fe80:	4d 89 e2             	mov    %r12,%r10
   2fe83:	4d 89 cb             	mov    %r9,%r11
   2fe86:	49 d1 eb             	shr    $1,%r11
   2fe89:	4d 01 dc             	add    %r11,%r12
   2fe8c:	4c 89 e3             	mov    %r12,%rbx
   2fe8f:	48 c1 e3 04          	shl    $0x4,%rbx
   2fe93:	39 04 19             	cmp    %eax,(%rcx,%rbx,1)
   2fe96:	4d 0f 4f e2          	cmovg  %r10,%r12
   2fe9a:	4d 29 d9             	sub    %r11,%r9
   2fe9d:	49 83 f9 01          	cmp    $0x1,%r9
   2fea1:	77 dd                	ja     2fe80 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2310>
   2fea3:	49 c1 e4 04          	shl    $0x4,%r12
   2fea7:	42 39 04 21          	cmp    %eax,(%rcx,%r12,1)
   2feab:	75 b3                	jne    2fe60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22f0>
   2fead:	49 01 cc             	add    %rcx,%r12
   2feb0:	4d 39 44 24 08       	cmp    %r8,0x8(%r12)
   2feb5:	75 a9                	jne    2fe60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x22f0>
   2feb7:	e9 96 19 00 00       	jmp    31852 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ce2>
   2febc:	45 31 ff             	xor    %r15d,%r15d
   2febf:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   2fec6:	00 
   2fec7:	48 85 c0             	test   %rax,%rax
   2feca:	0f 84 9b 01 00 00    	je     3006b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24fb>
   2fed0:	4d 85 f6             	test   %r14,%r14
   2fed3:	4c 8b ac 24 f0 01 00 	mov    0x1f0(%rsp),%r13
   2feda:	00 
   2fedb:	4c 8b 8c 24 50 01 00 	mov    0x150(%rsp),%r9
   2fee2:	00 
   2fee3:	0f 84 8a 01 00 00    	je     30073 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2503>
   2fee9:	31 c9                	xor    %ecx,%ecx
   2feeb:	45 31 ff             	xor    %r15d,%r15d
   2feee:	eb 2c                	jmp    2ff1c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23ac>
   2fef0:	49 8d 71 01          	lea    0x1(%r9),%rsi
   2fef4:	48 89 d1             	mov    %rdx,%rcx
   2fef7:	48 ff c8             	dec    %rax
   2fefa:	4a 63 7c 8a 08       	movslq 0x8(%rdx,%r9,4),%rdi
   2feff:	49 01 ff             	add    %rdi,%r15
   2ff02:	4a 63 54 8a 34       	movslq 0x34(%rdx,%r9,4),%rdx
   2ff07:	49 01 d7             	add    %rdx,%r15
   2ff0a:	41 be 00 00 00 00    	mov    $0x0,%r14d
   2ff10:	49 89 f1             	mov    %rsi,%r9
   2ff13:	48 85 c0             	test   %rax,%rax
   2ff16:	0f 84 57 01 00 00    	je     30073 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2503>
   2ff1c:	48 85 c9             	test   %rcx,%rcx
   2ff1f:	74 1f                	je     2ff40 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23d0>
   2ff21:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   2ff25:	49 39 d1             	cmp    %rdx,%r9
   2ff28:	0f 83 a2 00 00 00    	jae    2ffd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2460>
   2ff2e:	48 89 ca             	mov    %rcx,%rdx
   2ff31:	e9 b8 00 00 00       	jmp    2ffee <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x247e>
   2ff36:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2ff3d:	00 00 00 
   2ff40:	4d 85 c9             	test   %r9,%r9
   2ff43:	74 35                	je     2ff7a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x240a>
   2ff45:	4c 89 ca             	mov    %r9,%rdx
   2ff48:	4c 89 f1             	mov    %r14,%rcx
   2ff4b:	48 83 e2 07          	and    $0x7,%rdx
   2ff4f:	74 2e                	je     2ff7f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x240f>
   2ff51:	31 f6                	xor    %esi,%esi
   2ff53:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ff5a:	84 00 00 00 00 00 
   2ff60:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ff64:	48 ff c6             	inc    %rsi
   2ff67:	48 39 f2             	cmp    %rsi,%rdx
   2ff6a:	75 f4                	jne    2ff60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23f0>
   2ff6c:	4c 89 ca             	mov    %r9,%rdx
   2ff6f:	48 29 f2             	sub    %rsi,%rdx
   2ff72:	49 83 f9 08          	cmp    $0x8,%r9
   2ff76:	73 18                	jae    2ff90 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2420>
   2ff78:	eb 3c                	jmp    2ffb6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2446>
   2ff7a:	4c 89 f1             	mov    %r14,%rcx
   2ff7d:	eb 37                	jmp    2ffb6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2446>
   2ff7f:	4c 89 ca             	mov    %r9,%rdx
   2ff82:	49 83 f9 08          	cmp    $0x8,%r9
   2ff86:	72 2e                	jb     2ffb6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2446>
   2ff88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ff8f:	00 
   2ff90:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ff94:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ff98:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ff9c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ffa0:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ffa4:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ffa8:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ffac:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   2ffb0:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   2ffb4:	75 da                	jne    2ff90 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2420>
   2ffb6:	45 31 c9             	xor    %r9d,%r9d
   2ffb9:	45 31 f6             	xor    %r14d,%r14d
   2ffbc:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   2ffc0:	49 39 d1             	cmp    %rdx,%r9
   2ffc3:	0f 82 65 ff ff ff    	jb     2ff2e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x23be>
   2ffc9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2ffd0:	48 8b 11             	mov    (%rcx),%rdx
   2ffd3:	48 85 d2             	test   %rdx,%rdx
   2ffd6:	0f 84 0d 18 00 00    	je     317e9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c79>
   2ffdc:	49 ff c6             	inc    %r14
   2ffdf:	44 0f b7 49 60       	movzwl 0x60(%rcx),%r9d
   2ffe4:	48 89 d1             	mov    %rdx,%rcx
   2ffe7:	66 44 3b 4a 62       	cmp    0x62(%rdx),%r9w
   2ffec:	73 e2                	jae    2ffd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2460>
   2ffee:	4d 85 f6             	test   %r14,%r14
   2fff1:	0f 84 f9 fe ff ff    	je     2fef0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2380>
   2fff7:	4a 8d 34 ca          	lea    (%rdx,%r9,8),%rsi
   2fffb:	48 83 c6 70          	add    $0x70,%rsi
   2ffff:	4c 89 f7             	mov    %r14,%rdi
   30002:	48 83 e7 07          	and    $0x7,%rdi
   30006:	74 58                	je     30060 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24f0>
   30008:	45 31 c0             	xor    %r8d,%r8d
   3000b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30010:	48 8b 0e             	mov    (%rsi),%rcx
   30013:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30017:	49 ff c0             	inc    %r8
   3001a:	4c 39 c7             	cmp    %r8,%rdi
   3001d:	75 f1                	jne    30010 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24a0>
   3001f:	4c 89 f7             	mov    %r14,%rdi
   30022:	4c 29 c7             	sub    %r8,%rdi
   30025:	49 83 fe 08          	cmp    $0x8,%r14
   30029:	72 2e                	jb     30059 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24e9>
   3002b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30030:	48 8b 0e             	mov    (%rsi),%rcx
   30033:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30037:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3003b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3003f:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30043:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30047:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3004b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   3004f:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30053:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
   30057:	75 d7                	jne    30030 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24c0>
   30059:	31 f6                	xor    %esi,%esi
   3005b:	e9 97 fe ff ff       	jmp    2fef7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2387>
   30060:	4c 89 f7             	mov    %r14,%rdi
   30063:	49 83 fe 08          	cmp    $0x8,%r14
   30067:	73 c7                	jae    30030 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24c0>
   30069:	eb ee                	jmp    30059 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x24e9>
   3006b:	4c 8b ac 24 f0 01 00 	mov    0x1f0(%rsp),%r13
   30072:	00 
   30073:	48 8d 84 24 00 02 00 	lea    0x200(%rsp),%rax
   3007a:	00 
   3007b:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
   30082:	00 
   30083:	48 8d 84 24 f0 00 00 	lea    0xf0(%rsp),%rax
   3008a:	00 
   3008b:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   30092:	00 
   30093:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
   3009a:	00 
   3009b:	48 89 84 24 48 02 00 	mov    %rax,0x248(%rsp)
   300a2:	00 
   300a3:	48 8d 84 24 80 01 00 	lea    0x180(%rsp),%rax
   300aa:	00 
   300ab:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   300b2:	00 
   300b3:	bd 64 00 00 00       	mov    $0x64,%ebp
   300b8:	48 8d 9c 24 38 02 00 	lea    0x238(%rsp),%rbx
   300bf:	00 
   300c0:	48 89 df             	mov    %rbx,%rdi
   300c3:	e8 a8 d1 ff ff       	call   2d270 <_RNCNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4mains_0B3_>
   300c8:	ff cd                	dec    %ebp
   300ca:	75 f4                	jne    300c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2550>
   300cc:	4c 89 bc 24 30 01 00 	mov    %r15,0x130(%rsp)
   300d3:	00 
   300d4:	48 c7 84 24 60 01 00 	movq   $0x0,0x160(%rsp)
   300db:	00 00 00 00 00 
   300e0:	48 c7 84 24 68 01 00 	movq   $0x8,0x168(%rsp)
   300e7:	00 08 00 00 00 
   300ec:	48 c7 84 24 70 01 00 	movq   $0x0,0x170(%rsp)
   300f3:	00 00 00 00 00 
   300f8:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
   300fd:	48 c7 84 24 90 00 00 	movq   $0x0,0x90(%rsp)
   30104:	00 00 00 00 00 
   30109:	eb 4f                	jmp    3015a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x25ea>
   3010b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30110:	48 8b 84 24 68 01 00 	mov    0x168(%rsp),%rax
   30117:	00 
   30118:	48 89 d9             	mov    %rbx,%rcx
   3011b:	48 c1 e1 05          	shl    $0x5,%rcx
   3011f:	f3 0f 6f 44 24 70    	movdqu 0x70(%rsp),%xmm0
   30125:	66 0f 10 8c 24 80 00 	movupd 0x80(%rsp),%xmm1
   3012c:	00 00 
   3012e:	66 0f 11 4c 08 10    	movupd %xmm1,0x10(%rax,%rcx,1)
   30134:	f3 0f 7f 04 08       	movdqu %xmm0,(%rax,%rcx,1)
   30139:	48 ff c3             	inc    %rbx
   3013c:	48 89 9c 24 70 01 00 	mov    %rbx,0x170(%rsp)
   30143:	00 
   30144:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   3014b:	00 
   3014c:	48 3b 84 24 30 02 00 	cmp    0x230(%rsp),%rax
   30153:	00 
   30154:	0f 84 52 05 00 00    	je     306ac <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2b3c>
   3015a:	66 0f ef c0          	pxor   %xmm0,%xmm0
   3015e:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   30164:	bf 02 00 00 00       	mov    $0x2,%edi
   30169:	48 89 ee             	mov    %rbp,%rsi
   3016c:	ff 15 be fd 03 00    	call   *0x3fdbe(%rip)        # 6ff30 <clock_gettime@GLIBC_2.17>
   30172:	89 44 24 50          	mov    %eax,0x50(%rsp)
   30176:	85 c0                	test   %eax,%eax
   30178:	0f 85 9f 13 00 00    	jne    3151d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39ad>
   3017e:	4c 8b 64 24 10       	mov    0x10(%rsp),%r12
   30183:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   30188:	bf 01 00 00 00       	mov    $0x1,%edi
   3018d:	e8 0e 2c 02 00       	call   52da0 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   30192:	48 89 c3             	mov    %rax,%rbx
   30195:	89 d5                	mov    %edx,%ebp
   30197:	48 ff 84 24 90 00 00 	incq   0x90(%rsp)
   3019e:	00 
   3019f:	45 31 f6             	xor    %r14d,%r14d
   301a2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   301a9:	1f 84 00 00 00 00 00 
   301b0:	48 8d bc 24 38 02 00 	lea    0x238(%rsp),%rdi
   301b7:	00 
   301b8:	e8 b3 d0 ff ff       	call   2d270 <_RNCNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4mains_0B3_>
   301bd:	49 ff c6             	inc    %r14
   301c0:	4d 39 f5             	cmp    %r14,%r13
   301c3:	75 eb                	jne    301b0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2640>
   301c5:	bf 01 00 00 00       	mov    $0x1,%edi
   301ca:	e8 d1 2b 02 00       	call   52da0 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   301cf:	48 89 44 24 70       	mov    %rax,0x70(%rsp)
   301d4:	89 54 24 78          	mov    %edx,0x78(%rsp)
   301d8:	48 89 5c 24 50       	mov    %rbx,0x50(%rsp)
   301dd:	89 6c 24 58          	mov    %ebp,0x58(%rsp)
   301e1:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   301e6:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   301eb:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
   301f0:	e8 eb 2a 02 00       	call   52ce0 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.4795996092214488023>
   301f5:	8b 4c 24 20          	mov    0x20(%rsp),%ecx
   301f9:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
   301fe:	48 f7 64 24 18       	mulq   0x18(%rsp)
   30203:	48 89 d3             	mov    %rdx,%rbx
   30206:	49 89 c6             	mov    %rax,%r14
   30209:	49 01 ce             	add    %rcx,%r14
   3020c:	48 83 d3 00          	adc    $0x0,%rbx
   30210:	80 7c 24 10 00       	cmpb   $0x0,0x10(%rsp)
   30215:	b8 00 00 00 00       	mov    $0x0,%eax
   3021a:	4c 0f 45 f0          	cmovne %rax,%r14
   3021e:	48 0f 45 d8          	cmovne %rax,%rbx
   30222:	66 0f ef c0          	pxor   %xmm0,%xmm0
   30226:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   3022c:	bf 02 00 00 00       	mov    $0x2,%edi
   30231:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
   30236:	48 89 ee             	mov    %rbp,%rsi
   30239:	ff 15 f1 fc 03 00    	call   *0x3fcf1(%rip)        # 6ff30 <clock_gettime@GLIBC_2.17>
   3023f:	89 44 24 50          	mov    %eax,0x50(%rsp)
   30243:	85 c0                	test   %eax,%eax
   30245:	0f 85 d2 12 00 00    	jne    3151d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39ad>
   3024b:	4c 89 b4 24 c0 00 00 	mov    %r14,0xc0(%rsp)
   30252:	00 
   30253:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   30258:	4c 89 f9             	mov    %r15,%rcx
   3025b:	48 c1 f9 3f          	sar    $0x3f,%rcx
   3025f:	4c 89 e2             	mov    %r12,%rdx
   30262:	48 c1 fa 3f          	sar    $0x3f,%rdx
   30266:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   3026b:	48 8b 5c 24 18       	mov    0x18(%rsp),%rbx
   30270:	48 89 c6             	mov    %rax,%rsi
   30273:	48 c1 fe 3f          	sar    $0x3f,%rsi
   30277:	49 89 de             	mov    %rbx,%r14
   3027a:	49 c1 fe 3f          	sar    $0x3f,%r14
   3027e:	4c 29 e0             	sub    %r12,%rax
   30281:	48 19 d6             	sbb    %rdx,%rsi
   30284:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
   30289:	48 f7 e2             	mul    %rdx
   3028c:	48 69 f6 00 ca 9a 3b 	imul   $0x3b9aca00,%rsi,%rsi
   30293:	48 01 d6             	add    %rdx,%rsi
   30296:	4c 29 fb             	sub    %r15,%rbx
   30299:	49 19 ce             	sbb    %rcx,%r14
   3029c:	48 01 c3             	add    %rax,%rbx
   3029f:	49 11 f6             	adc    %rsi,%r14
   302a2:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
   302a9:	00 00 00 00 00 
   302ae:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
   302b5:	00 00 00 00 00 
   302ba:	41 bf 0a 00 00 00    	mov    $0xa,%r15d
   302c0:	bf 0a 00 00 00       	mov    $0xa,%edi
   302c5:	ff 15 9d f8 03 00    	call   *0x3f89d(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   302cb:	48 85 c0             	test   %rax,%rax
   302ce:	0f 84 27 15 00 00    	je     317fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c8b>
   302d4:	49 89 c4             	mov    %rax,%r12
   302d7:	48 b8 69 74 65 72 61 	movabs $0x6f69746172657469,%rax
   302de:	74 69 6f 
   302e1:	49 89 04 24          	mov    %rax,(%r12)
   302e5:	66 41 c7 44 24 08 6e 	movw   $0x736e,0x8(%r12)
   302ec:	73 
   302ed:	48 c7 84 24 f8 00 00 	movq   $0xa,0xf8(%rsp)
   302f4:	00 0a 00 00 00 
   302f9:	4c 89 a4 24 00 01 00 	mov    %r12,0x100(%rsp)
   30300:	00 
   30301:	48 c7 84 24 08 01 00 	movq   $0xa,0x108(%rsp)
   30308:	00 0a 00 00 00 
   3030d:	4c 89 ef             	mov    %r13,%rdi
   30310:	48 89 ee             	mov    %rbp,%rsi
   30313:	ff 15 67 fb 03 00    	call   *0x3fb67(%rip)        # 6fe80 <_DYNAMIC+0x560>
   30319:	48 89 c5             	mov    %rax,%rbp
   3031c:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   30320:	49 f7 df             	neg    %r15
   30323:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30329:	48 83 f8 14          	cmp    $0x14,%rax
   3032d:	74 29                	je     30358 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x27e8>
   3032f:	4c 89 ff             	mov    %r15,%rdi
   30332:	ff 15 30 f8 03 00    	call   *0x3f830(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30338:	48 85 c0             	test   %rax,%rax
   3033b:	0f 84 97 15 00 00    	je     318d8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d68>
   30341:	49 89 c5             	mov    %rax,%r13
   30344:	48 8d 34 2c          	lea    (%rsp,%rbp,1),%rsi
   30348:	48 83 c6 10          	add    $0x10,%rsi
   3034c:	48 89 c7             	mov    %rax,%rdi
   3034f:	4c 89 fa             	mov    %r15,%rdx
   30352:	ff 15 e0 f7 03 00    	call   *0x3f7e0(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30358:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   3035d:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   30362:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30367:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   3036c:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30371:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30378:	00 
   30379:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   30380:	00 
   30381:	48 8d 6c 24 10       	lea    0x10(%rsp),%rbp
   30386:	48 89 e9             	mov    %rbp,%rcx
   30389:	e8 82 1e 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3038e:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30393:	4c 8b ac 24 f0 01 00 	mov    0x1f0(%rsp),%r13
   3039a:	00 
   3039b:	74 0a                	je     303a7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2837>
   3039d:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   303a2:	e8 99 9b ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   303a7:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   303ad:	bf 06 00 00 00       	mov    $0x6,%edi
   303b2:	ff 15 b0 f7 03 00    	call   *0x3f7b0(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   303b8:	48 85 c0             	test   %rax,%rax
   303bb:	0f 84 3a 14 00 00    	je     317fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c8b>
   303c1:	49 89 c4             	mov    %rax,%r12
   303c4:	66 c7 40 04 6e 73    	movw   $0x736e,0x4(%rax)
   303ca:	c7 00 63 70 75 5f    	movl   $0x5f757063,(%rax)
   303d0:	48 c7 84 24 f8 00 00 	movq   $0x6,0xf8(%rsp)
   303d7:	00 06 00 00 00 
   303dc:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   303e3:	00 
   303e4:	48 c7 84 24 08 01 00 	movq   $0x6,0x108(%rsp)
   303eb:	00 06 00 00 00 
   303f0:	48 89 df             	mov    %rbx,%rdi
   303f3:	4c 89 f6             	mov    %r14,%rsi
   303f6:	48 89 ea             	mov    %rbp,%rdx
   303f9:	ff 15 71 fa 03 00    	call   *0x3fa71(%rip)        # 6fe70 <_DYNAMIC+0x550>
   303ff:	49 89 c7             	mov    %rax,%r15
   30402:	48 8d 58 d9          	lea    -0x27(%rax),%rbx
   30406:	48 f7 db             	neg    %rbx
   30409:	41 be 01 00 00 00    	mov    $0x1,%r14d
   3040f:	48 83 f8 27          	cmp    $0x27,%rax
   30413:	74 29                	je     3043e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x28ce>
   30415:	48 89 df             	mov    %rbx,%rdi
   30418:	ff 15 4a f7 03 00    	call   *0x3f74a(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3041e:	48 85 c0             	test   %rax,%rax
   30421:	0f 84 9e 14 00 00    	je     318c5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d55>
   30427:	49 89 c6             	mov    %rax,%r14
   3042a:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   3042e:	48 83 c6 10          	add    $0x10,%rsi
   30432:	48 89 c7             	mov    %rax,%rdi
   30435:	48 89 da             	mov    %rbx,%rdx
   30438:	ff 15 fa f6 03 00    	call   *0x3f6fa(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   3043e:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30443:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   30448:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
   3044d:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   30452:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30457:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   3045e:	00 
   3045f:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   30466:	00 
   30467:	48 89 e9             	mov    %rbp,%rcx
   3046a:	e8 a1 1d 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3046f:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30474:	74 0a                	je     30480 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2910>
   30476:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   3047b:	e8 c0 9a ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30480:	41 bf 07 00 00 00    	mov    $0x7,%r15d
   30486:	bf 07 00 00 00       	mov    $0x7,%edi
   3048b:	ff 15 d7 f6 03 00    	call   *0x3f6d7(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30491:	48 85 c0             	test   %rax,%rax
   30494:	0f 84 61 13 00 00    	je     317fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c8b>
   3049a:	48 89 c3             	mov    %rax,%rbx
   3049d:	c7 40 03 6c 5f 6e 73 	movl   $0x736e5f6c,0x3(%rax)
   304a4:	c7 00 77 61 6c 6c    	movl   $0x6c6c6177,(%rax)
   304aa:	48 c7 84 24 f8 00 00 	movq   $0x7,0xf8(%rsp)
   304b1:	00 07 00 00 00 
   304b6:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   304bd:	00 
   304be:	48 c7 84 24 08 01 00 	movq   $0x7,0x108(%rsp)
   304c5:	00 07 00 00 00 
   304ca:	48 8b bc 24 c0 00 00 	mov    0xc0(%rsp),%rdi
   304d1:	00 
   304d2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   304d7:	48 89 ea             	mov    %rbp,%rdx
   304da:	ff 15 90 f9 03 00    	call   *0x3f990(%rip)        # 6fe70 <_DYNAMIC+0x550>
   304e0:	49 89 c4             	mov    %rax,%r12
   304e3:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   304e7:	49 f7 de             	neg    %r14
   304ea:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   304f0:	48 83 f8 27          	cmp    $0x27,%rax
   304f4:	74 29                	je     3051f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x29af>
   304f6:	4c 89 f7             	mov    %r14,%rdi
   304f9:	ff 15 69 f6 03 00    	call   *0x3f669(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   304ff:	48 85 c0             	test   %rax,%rax
   30502:	0f 84 e3 13 00 00    	je     318eb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3d7b>
   30508:	49 89 c7             	mov    %rax,%r15
   3050b:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   3050f:	48 83 c6 10          	add    $0x10,%rsi
   30513:	48 89 c7             	mov    %rax,%rdi
   30516:	4c 89 f2             	mov    %r14,%rdx
   30519:	ff 15 19 f6 03 00    	call   *0x3f619(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   3051f:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30524:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   30529:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   3052e:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   30533:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30538:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   3053f:	00 
   30540:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   30547:	00 
   30548:	48 89 e9             	mov    %rbp,%rcx
   3054b:	e8 c0 1c 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30550:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30555:	74 0a                	je     30561 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x29f1>
   30557:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   3055c:	e8 df 99 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30561:	41 bf 10 00 00 00    	mov    $0x10,%r15d
   30567:	bf 10 00 00 00       	mov    $0x10,%edi
   3056c:	ff 15 f6 f5 03 00    	call   *0x3f5f6(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30572:	48 85 c0             	test   %rax,%rax
   30575:	0f 84 80 12 00 00    	je     317fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c8b>
   3057b:	f3 0f 6f 05 cd 6e fd 	movdqu -0x29133(%rip),%xmm0        # 7450 <anon.0f363c1c2085502831f1e7e323c26323.407.llvm.704920437039905144+0x170>
   30582:	ff 
   30583:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30587:	48 c7 84 24 f8 00 00 	movq   $0x10,0xf8(%rsp)
   3058e:	00 10 00 00 00 
   30593:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   3059a:	00 
   3059b:	48 c7 84 24 08 01 00 	movq   $0x10,0x108(%rsp)
   305a2:	00 10 00 00 00 
   305a7:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
   305ac:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   305b1:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   305b8:	00 
   305b9:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   305c0:	00 
   305c1:	48 89 e9             	mov    %rbp,%rcx
   305c4:	e8 47 1c 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   305c9:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   305ce:	74 0a                	je     305da <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2a6a>
   305d0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   305d5:	e8 66 99 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   305da:	41 bf 0f 00 00 00    	mov    $0xf,%r15d
   305e0:	bf 0f 00 00 00       	mov    $0xf,%edi
   305e5:	ff 15 7d f5 03 00    	call   *0x3f57d(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   305eb:	48 85 c0             	test   %rax,%rax
   305ee:	0f 84 07 12 00 00    	je     317fb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3c8b>
   305f4:	48 b9 65 64 5f 62 79 	movabs $0x73657479625f6465,%rcx
   305fb:	74 65 73 
   305fe:	48 89 48 07          	mov    %rcx,0x7(%rax)
   30602:	48 b9 72 65 71 75 65 	movabs $0x6574736575716572,%rcx
   30609:	73 74 65 
   3060c:	48 89 08             	mov    %rcx,(%rax)
   3060f:	48 c7 84 24 f8 00 00 	movq   $0xf,0xf8(%rsp)
   30616:	00 0f 00 00 00 
   3061b:	48 89 84 24 00 01 00 	mov    %rax,0x100(%rsp)
   30622:	00 
   30623:	48 c7 84 24 08 01 00 	movq   $0xf,0x108(%rsp)
   3062a:	00 0f 00 00 00 
   3062f:	c6 44 24 10 00       	movb   $0x0,0x10(%rsp)
   30634:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30639:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30640:	00 
   30641:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   30648:	00 
   30649:	48 89 e9             	mov    %rbp,%rcx
   3064c:	e8 bf 1b 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30651:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30656:	74 0a                	je     30662 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2af2>
   30658:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   3065d:	e8 de 98 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30662:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   30669:	00 
   3066a:	48 8d 4c 24 78       	lea    0x78(%rsp),%rcx
   3066f:	48 89 41 10          	mov    %rax,0x10(%rcx)
   30673:	0f 10 84 24 a8 00 00 	movups 0xa8(%rsp),%xmm0
   3067a:	00 
   3067b:	0f 11 01             	movups %xmm0,(%rcx)
   3067e:	c6 44 24 70 05       	movb   $0x5,0x70(%rsp)
   30683:	48 8b 9c 24 70 01 00 	mov    0x170(%rsp),%rbx
   3068a:	00 
   3068b:	48 3b 9c 24 60 01 00 	cmp    0x160(%rsp),%rbx
   30692:	00 
   30693:	0f 85 77 fa ff ff    	jne    30110 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x25a0>
   30699:	48 8d bc 24 60 01 00 	lea    0x160(%rsp),%rdi
   306a0:	00 
   306a1:	ff 15 79 f8 03 00    	call   *0x3f879(%rip)        # 6ff20 <_DYNAMIC+0x600>
   306a7:	e9 64 fa ff ff       	jmp    30110 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x25a0>
   306ac:	48 c7 84 24 a8 00 00 	movq   $0x0,0xa8(%rsp)
   306b3:	00 00 00 00 00 
   306b8:	48 c7 84 24 b8 00 00 	movq   $0x0,0xb8(%rsp)
   306bf:	00 00 00 00 00 
   306c4:	41 bd 06 00 00 00    	mov    $0x6,%r13d
   306ca:	bf 06 00 00 00       	mov    $0x6,%edi
   306cf:	ff 15 93 f4 03 00    	call   *0x3f493(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   306d5:	48 85 c0             	test   %rax,%rax
   306d8:	0f 84 4a 12 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   306de:	48 89 c3             	mov    %rax,%rbx
   306e1:	66 c7 40 04 6d 61    	movw   $0x616d,0x4(%rax)
   306e7:	c7 00 73 63 68 65    	movl   $0x65686373,(%rax)
   306ed:	48 c7 44 24 70 06 00 	movq   $0x6,0x70(%rsp)
   306f4:	00 00 
   306f6:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   306fb:	48 c7 84 24 80 00 00 	movq   $0x6,0x80(%rsp)
   30702:	00 06 00 00 00 
   30707:	bf 15 00 00 00       	mov    $0x15,%edi
   3070c:	ff 15 56 f4 03 00    	call   *0x3f456(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30712:	48 85 c0             	test   %rax,%rax
   30715:	0f 84 64 13 00 00    	je     31a7f <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f0f>
   3071b:	f3 0f 6f 05 cd 8b fd 	movdqu -0x27433(%rip),%xmm0        # 92f0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1b9>
   30722:	ff 
   30723:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30727:	48 b9 2d 70 72 6f 6f 	movabs $0x312f666f6f72702d,%rcx
   3072e:	66 2f 31 
   30731:	48 89 48 0d          	mov    %rcx,0xd(%rax)
   30735:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   3073a:	48 c7 44 24 18 15 00 	movq   $0x15,0x18(%rsp)
   30741:	00 00 
   30743:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   30748:	48 c7 44 24 28 15 00 	movq   $0x15,0x28(%rsp)
   3074f:	00 00 
   30751:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30756:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   3075d:	00 
   3075e:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30763:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30768:	e8 a3 1a 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3076d:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30772:	74 0a                	je     3077e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2c0e>
   30774:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30779:	e8 c2 97 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3077e:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   30784:	bf 04 00 00 00       	mov    $0x4,%edi
   30789:	ff 15 d9 f3 03 00    	call   *0x3f3d9(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3078f:	48 85 c0             	test   %rax,%rax
   30792:	0f 84 90 11 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30798:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   3079e:	48 c7 44 24 70 04 00 	movq   $0x4,0x70(%rsp)
   307a5:	00 00 
   307a7:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   307ac:	48 c7 84 24 80 00 00 	movq   $0x4,0x80(%rsp)
   307b3:	00 04 00 00 00 
   307b8:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   307bf:	00 
   307c0:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   307c4:	48 85 db             	test   %rbx,%rbx
   307c7:	74 2d                	je     307f6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2c86>
   307c9:	49 89 c6             	mov    %rax,%r14
   307cc:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   307d0:	48 89 df             	mov    %rbx,%rdi
   307d3:	ff 15 8f f3 03 00    	call   *0x3f38f(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   307d9:	48 85 c0             	test   %rax,%rax
   307dc:	0f 84 19 13 00 00    	je     31afb <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f8b>
   307e2:	49 89 c7             	mov    %rax,%r15
   307e5:	48 89 c7             	mov    %rax,%rdi
   307e8:	4c 89 e6             	mov    %r12,%rsi
   307eb:	48 89 da             	mov    %rbx,%rdx
   307ee:	ff 15 44 f3 03 00    	call   *0x3f344(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   307f4:	eb 06                	jmp    307fc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2c8c>
   307f6:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   307fc:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30801:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   30806:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   3080b:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   30810:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30815:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   3081c:	00 
   3081d:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30822:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30827:	e8 e4 19 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3082c:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30831:	74 0a                	je     3083d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2ccd>
   30833:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30838:	e8 03 97 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3083d:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   30843:	bf 07 00 00 00       	mov    $0x7,%edi
   30848:	ff 15 1a f3 03 00    	call   *0x3f31a(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3084e:	48 85 c0             	test   %rax,%rax
   30851:	0f 84 d1 10 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30857:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   3085e:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   30864:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   3086b:	00 00 
   3086d:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   30872:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   30879:	00 07 00 00 00 
   3087e:	48 8b 8c 24 00 02 00 	mov    0x200(%rsp),%rcx
   30885:	00 
   30886:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   3088a:	48 85 db             	test   %rbx,%rbx
   3088d:	74 2d                	je     308bc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2d4c>
   3088f:	49 89 c6             	mov    %rax,%r14
   30892:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   30896:	48 89 df             	mov    %rbx,%rdi
   30899:	ff 15 c9 f2 03 00    	call   *0x3f2c9(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3089f:	48 85 c0             	test   %rax,%rax
   308a2:	0f 84 63 12 00 00    	je     31b0b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f9b>
   308a8:	49 89 c7             	mov    %rax,%r15
   308ab:	48 89 c7             	mov    %rax,%rdi
   308ae:	4c 89 e6             	mov    %r12,%rsi
   308b1:	48 89 da             	mov    %rbx,%rdx
   308b4:	ff 15 7e f2 03 00    	call   *0x3f27e(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   308ba:	eb 06                	jmp    308c2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2d52>
   308bc:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   308c2:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   308c7:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   308cc:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   308d1:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   308d6:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   308db:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   308e2:	00 
   308e3:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   308e8:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   308ed:	e8 1e 19 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   308f2:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   308f7:	74 0a                	je     30903 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2d93>
   308f9:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   308fe:	e8 3d 96 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30903:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   30909:	bf 09 00 00 00       	mov    $0x9,%edi
   3090e:	ff 15 54 f2 03 00    	call   *0x3f254(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30914:	48 85 c0             	test   %rax,%rax
   30917:	0f 84 0b 10 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   3091d:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   30924:	74 69 6f 
   30927:	48 89 08             	mov    %rcx,(%rax)
   3092a:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   3092e:	48 c7 44 24 70 09 00 	movq   $0x9,0x70(%rsp)
   30935:	00 00 
   30937:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   3093c:	48 c7 84 24 80 00 00 	movq   $0x9,0x80(%rsp)
   30943:	00 09 00 00 00 
   30948:	48 8b 8c 24 a0 00 00 	mov    0xa0(%rsp),%rcx
   3094f:	00 
   30950:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   30954:	48 85 db             	test   %rbx,%rbx
   30957:	74 2d                	je     30986 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2e16>
   30959:	49 89 c6             	mov    %rax,%r14
   3095c:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   30960:	48 89 df             	mov    %rbx,%rdi
   30963:	ff 15 ff f1 03 00    	call   *0x3f1ff(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30969:	48 85 c0             	test   %rax,%rax
   3096c:	0f 84 a9 11 00 00    	je     31b1b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3fab>
   30972:	49 89 c7             	mov    %rax,%r15
   30975:	48 89 c7             	mov    %rax,%rdi
   30978:	4c 89 e6             	mov    %r12,%rsi
   3097b:	48 89 da             	mov    %rbx,%rdx
   3097e:	ff 15 b4 f1 03 00    	call   *0x3f1b4(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30984:	eb 06                	jmp    3098c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2e1c>
   30986:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   3098c:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30991:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   30996:	4c 89 7c 24 20       	mov    %r15,0x20(%rsp)
   3099b:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   309a0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   309a5:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   309ac:	00 
   309ad:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   309b2:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   309b7:	e8 54 18 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   309bc:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   309c1:	74 0a                	je     309cd <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2e5d>
   309c3:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   309c8:	e8 73 95 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   309cd:	41 bd 05 00 00 00    	mov    $0x5,%r13d
   309d3:	bf 05 00 00 00       	mov    $0x5,%edi
   309d8:	ff 15 8a f1 03 00    	call   *0x3f18a(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   309de:	48 85 c0             	test   %rax,%rax
   309e1:	0f 84 41 0f 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   309e7:	48 89 c3             	mov    %rax,%rbx
   309ea:	c6 40 04 74          	movb   $0x74,0x4(%rax)
   309ee:	c7 00 69 6e 70 75    	movl   $0x75706e69,(%rax)
   309f4:	48 c7 44 24 70 05 00 	movq   $0x5,0x70(%rsp)
   309fb:	00 00 
   309fd:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   30a02:	48 c7 84 24 80 00 00 	movq   $0x5,0x80(%rsp)
   30a09:	00 05 00 00 00 
   30a0e:	bf 6b 00 00 00       	mov    $0x6b,%edi
   30a13:	ff 15 4f f1 03 00    	call   *0x3f14f(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30a19:	48 85 c0             	test   %rax,%rax
   30a1c:	0f 84 72 10 00 00    	je     31a94 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f24>
   30a22:	0f 10 05 37 89 fd ff 	movups -0x276c9(%rip),%xmm0        # 9360 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x229>
   30a29:	0f 11 40 5b          	movups %xmm0,0x5b(%rax)
   30a2d:	0f 10 05 21 89 fd ff 	movups -0x276df(%rip),%xmm0        # 9355 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x21e>
   30a34:	0f 11 40 50          	movups %xmm0,0x50(%rax)
   30a38:	0f 10 05 06 89 fd ff 	movups -0x276fa(%rip),%xmm0        # 9345 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x20e>
   30a3f:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   30a43:	0f 10 05 eb 88 fd ff 	movups -0x27715(%rip),%xmm0        # 9335 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1fe>
   30a4a:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   30a4e:	0f 10 05 d0 88 fd ff 	movups -0x27730(%rip),%xmm0        # 9325 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1ee>
   30a55:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   30a59:	0f 10 05 b5 88 fd ff 	movups -0x2774b(%rip),%xmm0        # 9315 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1de>
   30a60:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   30a64:	f3 0f 6f 05 99 88 fd 	movdqu -0x27767(%rip),%xmm0        # 9305 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1ce>
   30a6b:	ff 
   30a6c:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30a70:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30a75:	48 c7 44 24 18 6b 00 	movq   $0x6b,0x18(%rsp)
   30a7c:	00 00 
   30a7e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   30a83:	48 c7 44 24 28 6b 00 	movq   $0x6b,0x28(%rsp)
   30a8a:	00 00 
   30a8c:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30a91:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30a98:	00 
   30a99:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30a9e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30aa3:	e8 68 17 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30aa8:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30aad:	74 0a                	je     30ab9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x2f49>
   30aaf:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30ab4:	e8 87 94 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30ab9:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   30abf:	bf 07 00 00 00       	mov    $0x7,%edi
   30ac4:	ff 15 9e f0 03 00    	call   *0x3f09e(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30aca:	48 85 c0             	test   %rax,%rax
   30acd:	0f 84 55 0e 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30ad3:	48 89 c3             	mov    %rax,%rbx
   30ad6:	c7 40 03 74 72 6f 6c 	movl   $0x6c6f7274,0x3(%rax)
   30add:	c7 00 63 6f 6e 74    	movl   $0x746e6f63,(%rax)
   30ae3:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   30aea:	00 00 
   30aec:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   30af1:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   30af8:	00 07 00 00 00 
   30afd:	bf 53 00 00 00       	mov    $0x53,%edi
   30b02:	ff 15 60 f0 03 00    	call   *0x3f060(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30b08:	48 85 c0             	test   %rax,%rax
   30b0b:	0f 84 98 0f 00 00    	je     31aa9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f39>
   30b11:	0f 10 05 98 88 fd ff 	movups -0x27768(%rip),%xmm0        # 93b0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x279>
   30b18:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   30b1c:	0f 10 05 7d 88 fd ff 	movups -0x27783(%rip),%xmm0        # 93a0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x269>
   30b23:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   30b27:	0f 10 05 62 88 fd ff 	movups -0x2779e(%rip),%xmm0        # 9390 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x259>
   30b2e:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   30b32:	0f 10 05 47 88 fd ff 	movups -0x277b9(%rip),%xmm0        # 9380 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x249>
   30b39:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   30b3d:	f3 0f 6f 05 2b 88 fd 	movdqu -0x277d5(%rip),%xmm0        # 9370 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x239>
   30b44:	ff 
   30b45:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   30b49:	c7 40 4f 63 6f 64 65 	movl   $0x65646f63,0x4f(%rax)
   30b50:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30b55:	48 c7 44 24 18 53 00 	movq   $0x53,0x18(%rsp)
   30b5c:	00 00 
   30b5e:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   30b63:	48 c7 44 24 28 53 00 	movq   $0x53,0x28(%rsp)
   30b6a:	00 00 
   30b6c:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30b71:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30b78:	00 
   30b79:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30b7e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30b83:	e8 88 16 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30b88:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30b8d:	74 0a                	je     30b99 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3029>
   30b8f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30b94:	e8 a7 93 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30b99:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   30b9f:	bf 0a 00 00 00       	mov    $0xa,%edi
   30ba4:	ff 15 be ef 03 00    	call   *0x3efbe(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30baa:	48 85 c0             	test   %rax,%rax
   30bad:	0f 84 75 0d 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30bb3:	48 89 c3             	mov    %rax,%rbx
   30bb6:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   30bbd:	62 79 74 
   30bc0:	48 89 03             	mov    %rax,(%rbx)
   30bc3:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   30bc9:	48 c7 44 24 70 0a 00 	movq   $0xa,0x70(%rsp)
   30bd0:	00 00 
   30bd2:	48 89 5c 24 78       	mov    %rbx,0x78(%rsp)
   30bd7:	48 c7 84 24 80 00 00 	movq   $0xa,0x80(%rsp)
   30bde:	00 0a 00 00 00 
   30be3:	4c 8b bc 24 48 01 00 	mov    0x148(%rsp),%r15
   30bea:	00 
   30beb:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30bf0:	4c 89 ff             	mov    %r15,%rdi
   30bf3:	ff 15 87 f2 03 00    	call   *0x3f287(%rip)        # 6fe80 <_DYNAMIC+0x560>
   30bf9:	49 89 c4             	mov    %rax,%r12
   30bfc:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   30c00:	49 f7 de             	neg    %r14
   30c03:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30c09:	48 83 f8 14          	cmp    $0x14,%rax
   30c0d:	74 29                	je     30c38 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x30c8>
   30c0f:	4c 89 f7             	mov    %r14,%rdi
   30c12:	ff 15 50 ef 03 00    	call   *0x3ef50(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30c18:	48 85 c0             	test   %rax,%rax
   30c1b:	0f 84 1a 0f 00 00    	je     31b3b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3fcb>
   30c21:	49 89 c5             	mov    %rax,%r13
   30c24:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30c28:	48 83 c6 10          	add    $0x10,%rsi
   30c2c:	48 89 c7             	mov    %rax,%rdi
   30c2f:	4c 89 f2             	mov    %r14,%rdx
   30c32:	ff 15 00 ef 03 00    	call   *0x3ef00(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30c38:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30c3d:	4c 89 74 24 28       	mov    %r14,0x28(%rsp)
   30c42:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30c47:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   30c4c:	4c 8d 64 24 50       	lea    0x50(%rsp),%r12
   30c51:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30c58:	00 
   30c59:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30c5e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30c63:	4c 89 e7             	mov    %r12,%rdi
   30c66:	e8 a5 15 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30c6b:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30c70:	74 0a                	je     30c7c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x310c>
   30c72:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30c77:	e8 c4 92 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30c7c:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   30c82:	bf 0c 00 00 00       	mov    $0xc,%edi
   30c87:	ff 15 db ee 03 00    	call   *0x3eedb(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30c8d:	48 85 c0             	test   %rax,%rax
   30c90:	0f 84 92 0c 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30c96:	49 89 c6             	mov    %rax,%r14
   30c99:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   30ca0:	9c f2 cb 
   30ca3:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   30caa:	66 6e 76 
   30cad:	49 89 0e             	mov    %rcx,(%r14)
   30cb0:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   30cb7:	34 
   30cb8:	48 c7 84 24 f8 00 00 	movq   $0xc,0xf8(%rsp)
   30cbf:	00 0c 00 00 00 
   30cc4:	4c 89 b4 24 00 01 00 	mov    %r14,0x100(%rsp)
   30ccb:	00 
   30ccc:	48 c7 84 24 08 01 00 	movq   $0xc,0x108(%rsp)
   30cd3:	00 0c 00 00 00 
   30cd8:	48 8b 9c 24 40 01 00 	mov    0x140(%rsp),%rbx
   30cdf:	00 
   30ce0:	4d 85 ff             	test   %r15,%r15
   30ce3:	0f 84 9b 00 00 00    	je     30d84 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3214>
   30ce9:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   30cf0:	01 00 00 
   30cf3:	44 89 fa             	mov    %r15d,%edx
   30cf6:	83 e2 03             	and    $0x3,%edx
   30cf9:	49 83 ff 04          	cmp    $0x4,%r15
   30cfd:	73 04                	jae    30d03 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3193>
   30cff:	31 f6                	xor    %esi,%esi
   30d01:	eb 5b                	jmp    30d5e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x31ee>
   30d03:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   30d0a:	ff ff 7f 
   30d0d:	48 83 c6 0b          	add    $0xb,%rsi
   30d11:	49 21 f7             	and    %rsi,%r15
   30d14:	31 f6                	xor    %esi,%esi
   30d16:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   30d1d:	00 00 00 
   30d20:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   30d24:	48 31 f8             	xor    %rdi,%rax
   30d27:	48 0f af c1          	imul   %rcx,%rax
   30d2b:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   30d30:	48 31 c7             	xor    %rax,%rdi
   30d33:	48 0f af f9          	imul   %rcx,%rdi
   30d37:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   30d3d:	49 31 f8             	xor    %rdi,%r8
   30d40:	4c 0f af c1          	imul   %rcx,%r8
   30d44:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   30d49:	4c 31 c0             	xor    %r8,%rax
   30d4c:	48 0f af c1          	imul   %rcx,%rax
   30d50:	48 83 c6 04          	add    $0x4,%rsi
   30d54:	49 39 f7             	cmp    %rsi,%r15
   30d57:	75 c7                	jne    30d20 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x31b0>
   30d59:	48 85 d2             	test   %rdx,%rdx
   30d5c:	74 26                	je     30d84 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3214>
   30d5e:	48 01 de             	add    %rbx,%rsi
   30d61:	31 ff                	xor    %edi,%edi
   30d63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30d6a:	84 00 00 00 00 00 
   30d70:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   30d75:	4c 31 c0             	xor    %r8,%rax
   30d78:	48 0f af c1          	imul   %rcx,%rax
   30d7c:	48 ff c7             	inc    %rdi
   30d7f:	48 39 fa             	cmp    %rdi,%rdx
   30d82:	75 ec                	jne    30d70 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3200>
   30d84:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   30d89:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   30d8e:	48 8b 05 13 f0 03 00 	mov    0x3f013(%rip),%rax        # 6fda8 <_DYNAMIC+0x488>
   30d95:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   30d9a:	48 8d 35 df 74 fd ff 	lea    -0x28b21(%rip),%rsi        # 8280 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   30da1:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   30da6:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   30dab:	ff 15 ff ed 03 00    	call   *0x3edff(%rip)        # 6fbb0 <_DYNAMIC+0x290>
   30db1:	4c 8b 7c 24 78       	mov    0x78(%rsp),%r15
   30db6:	4c 8b a4 24 80 00 00 	mov    0x80(%rsp),%r12
   30dbd:	00 
   30dbe:	4d 85 e4             	test   %r12,%r12
   30dc1:	74 26                	je     30de9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3279>
   30dc3:	4c 89 e7             	mov    %r12,%rdi
   30dc6:	ff 15 9c ed 03 00    	call   *0x3ed9c(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30dcc:	48 85 c0             	test   %rax,%rax
   30dcf:	0f 84 56 0d 00 00    	je     31b2b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3fbb>
   30dd5:	49 89 c5             	mov    %rax,%r13
   30dd8:	48 89 c7             	mov    %rax,%rdi
   30ddb:	4c 89 fe             	mov    %r15,%rsi
   30dde:	4c 89 e2             	mov    %r12,%rdx
   30de1:	ff 15 51 ed 03 00    	call   *0x3ed51(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30de7:	eb 06                	jmp    30def <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x327f>
   30de9:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30def:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   30df4:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   30df9:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30dfe:	4c 89 64 24 28       	mov    %r12,0x28(%rsp)
   30e03:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30e08:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30e0f:	00 
   30e10:	48 8d 94 24 f8 00 00 	lea    0xf8(%rsp),%rdx
   30e17:	00 
   30e18:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30e1d:	e8 ee 13 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30e22:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30e27:	74 0a                	je     30e33 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x32c3>
   30e29:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30e2e:	e8 0d 91 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30e33:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   30e39:	74 09                	je     30e44 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x32d4>
   30e3b:	4c 89 ff             	mov    %r15,%rdi
   30e3e:	ff 15 0c ed 03 00    	call   *0x3ed0c(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   30e44:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   30e4a:	bf 08 00 00 00       	mov    $0x8,%edi
   30e4f:	ff 15 13 ed 03 00    	call   *0x3ed13(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30e55:	48 85 c0             	test   %rax,%rax
   30e58:	0f 84 ca 0a 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30e5e:	49 89 c6             	mov    %rax,%r14
   30e61:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   30e68:	73 75 6d 
   30e6b:	49 89 06             	mov    %rax,(%r14)
   30e6e:	48 c7 44 24 70 08 00 	movq   $0x8,0x70(%rsp)
   30e75:	00 00 
   30e77:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   30e7c:	48 c7 84 24 80 00 00 	movq   $0x8,0x80(%rsp)
   30e83:	00 08 00 00 00 
   30e88:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30e8d:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   30e94:	00 
   30e95:	ff 15 e5 ef 03 00    	call   *0x3efe5(%rip)        # 6fe80 <_DYNAMIC+0x560>
   30e9b:	49 89 c4             	mov    %rax,%r12
   30e9e:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   30ea2:	49 f7 df             	neg    %r15
   30ea5:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30eab:	48 83 f8 14          	cmp    $0x14,%rax
   30eaf:	74 29                	je     30eda <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x336a>
   30eb1:	4c 89 ff             	mov    %r15,%rdi
   30eb4:	ff 15 ae ec 03 00    	call   *0x3ecae(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30eba:	48 85 c0             	test   %rax,%rax
   30ebd:	0f 84 88 0c 00 00    	je     31b4b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3fdb>
   30ec3:	49 89 c5             	mov    %rax,%r13
   30ec6:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30eca:	48 83 c6 10          	add    $0x10,%rsi
   30ece:	48 89 c7             	mov    %rax,%rdi
   30ed1:	4c 89 fa             	mov    %r15,%rdx
   30ed4:	ff 15 5e ec 03 00    	call   *0x3ec5e(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30eda:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30edf:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   30ee4:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30ee9:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   30eee:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30ef3:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30efa:	00 
   30efb:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30f00:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30f05:	e8 06 13 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30f0a:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30f0f:	74 0a                	je     30f1b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x33ab>
   30f11:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30f16:	e8 25 90 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30f1b:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   30f21:	bf 0b 00 00 00       	mov    $0xb,%edi
   30f26:	ff 15 3c ec 03 00    	call   *0x3ec3c(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30f2c:	48 85 c0             	test   %rax,%rax
   30f2f:	0f 84 f3 09 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   30f35:	49 89 c6             	mov    %rax,%r14
   30f38:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   30f3f:	6e 74 72 
   30f42:	49 89 06             	mov    %rax,(%r14)
   30f45:	41 c7 46 07 72 69 65 	movl   $0x73656972,0x7(%r14)
   30f4c:	73 
   30f4d:	48 c7 44 24 70 0b 00 	movq   $0xb,0x70(%rsp)
   30f54:	00 00 
   30f56:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   30f5b:	48 c7 84 24 80 00 00 	movq   $0xb,0x80(%rsp)
   30f62:	00 0b 00 00 00 
   30f67:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   30f6c:	48 8b bc 24 e0 00 00 	mov    0xe0(%rsp),%rdi
   30f73:	00 
   30f74:	ff 15 06 ef 03 00    	call   *0x3ef06(%rip)        # 6fe80 <_DYNAMIC+0x560>
   30f7a:	49 89 c4             	mov    %rax,%r12
   30f7d:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   30f81:	49 f7 df             	neg    %r15
   30f84:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   30f8a:	48 83 f8 14          	cmp    $0x14,%rax
   30f8e:	74 29                	je     30fb9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3449>
   30f90:	4c 89 ff             	mov    %r15,%rdi
   30f93:	ff 15 cf eb 03 00    	call   *0x3ebcf(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   30f99:	48 85 c0             	test   %rax,%rax
   30f9c:	0f 84 b9 0b 00 00    	je     31b5b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3feb>
   30fa2:	49 89 c5             	mov    %rax,%r13
   30fa5:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30fa9:	48 83 c6 10          	add    $0x10,%rsi
   30fad:	48 89 c7             	mov    %rax,%rdi
   30fb0:	4c 89 fa             	mov    %r15,%rdx
   30fb3:	ff 15 7f eb 03 00    	call   *0x3eb7f(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   30fb9:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   30fbe:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   30fc3:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   30fc8:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   30fcd:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30fd2:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   30fd9:	00 
   30fda:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   30fdf:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   30fe4:	e8 27 12 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30fe9:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   30fee:	74 0a                	je     30ffa <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x348a>
   30ff0:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   30ff5:	e8 46 8f ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   30ffa:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   31000:	bf 0e 00 00 00       	mov    $0xe,%edi
   31005:	ff 15 5d eb 03 00    	call   *0x3eb5d(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3100b:	48 85 c0             	test   %rax,%rax
   3100e:	0f 84 14 09 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   31014:	49 89 c6             	mov    %rax,%r14
   31017:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   3101e:	69 65 73 
   31021:	49 89 46 06          	mov    %rax,0x6(%r14)
   31025:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   3102c:	65 5f 65 
   3102f:	49 89 06             	mov    %rax,(%r14)
   31032:	48 c7 44 24 70 0e 00 	movq   $0xe,0x70(%rsp)
   31039:	00 00 
   3103b:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   31040:	48 c7 84 24 80 00 00 	movq   $0xe,0x80(%rsp)
   31047:	00 0e 00 00 00 
   3104c:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31051:	48 8b bc 24 28 01 00 	mov    0x128(%rsp),%rdi
   31058:	00 
   31059:	ff 15 21 ee 03 00    	call   *0x3ee21(%rip)        # 6fe80 <_DYNAMIC+0x560>
   3105f:	49 89 c4             	mov    %rax,%r12
   31062:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31066:	49 f7 df             	neg    %r15
   31069:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   3106f:	48 83 f8 14          	cmp    $0x14,%rax
   31073:	74 29                	je     3109e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x352e>
   31075:	4c 89 ff             	mov    %r15,%rdi
   31078:	ff 15 ea ea 03 00    	call   *0x3eaea(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3107e:	48 85 c0             	test   %rax,%rax
   31081:	0f 84 e4 0a 00 00    	je     31b6b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ffb>
   31087:	49 89 c5             	mov    %rax,%r13
   3108a:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   3108e:	48 83 c6 10          	add    $0x10,%rsi
   31092:	48 89 c7             	mov    %rax,%rdi
   31095:	4c 89 fa             	mov    %r15,%rdx
   31098:	ff 15 9a ea 03 00    	call   *0x3ea9a(%rip)        # 6fb38 <memcpy@GLIBC_2.14>
   3109e:	4c 89 6c 24 20       	mov    %r13,0x20(%rsp)
   310a3:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   310a8:	c6 44 24 10 02       	movb   $0x2,0x10(%rsp)
   310ad:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   310b2:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   310b7:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   310be:	00 
   310bf:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   310c4:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   310c9:	e8 42 11 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   310ce:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   310d3:	74 0a                	je     310df <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x356f>
   310d5:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   310da:	e8 61 8e ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   310df:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   310e5:	bf 12 00 00 00       	mov    $0x12,%edi
   310ea:	ff 15 78 ea 03 00    	call   *0x3ea78(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   310f0:	48 85 c0             	test   %rax,%rax
   310f3:	0f 84 2f 08 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   310f9:	f3 0f 6f 05 c2 82 fd 	movdqu -0x27d3e(%rip),%xmm0        # 93c3 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x28c>
   31100:	ff 
   31101:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   31105:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   3110b:	48 c7 44 24 70 12 00 	movq   $0x12,0x70(%rsp)
   31112:	00 00 
   31114:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   31119:	48 c7 84 24 80 00 00 	movq   $0x12,0x80(%rsp)
   31120:	00 12 00 00 00 
   31125:	66 c7 44 24 10 01 01 	movw   $0x101,0x10(%rsp)
   3112c:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31131:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   31138:	00 
   31139:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   3113e:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   31143:	e8 c8 10 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31148:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   3114d:	74 0a                	je     31159 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x35e9>
   3114f:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31154:	e8 e7 8d ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31159:	41 bd 0f 00 00 00    	mov    $0xf,%r13d
   3115f:	bf 0f 00 00 00       	mov    $0xf,%edi
   31164:	ff 15 fe e9 03 00    	call   *0x3e9fe(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3116a:	48 85 c0             	test   %rax,%rax
   3116d:	0f 84 b5 07 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   31173:	49 89 c6             	mov    %rax,%r14
   31176:	48 b8 5f 73 74 6f 72 	movabs $0x656761726f74735f,%rax
   3117d:	61 67 65 
   31180:	49 89 46 07          	mov    %rax,0x7(%r14)
   31184:	48 b8 6d 65 73 73 61 	movabs $0x5f6567617373656d,%rax
   3118b:	67 65 5f 
   3118e:	49 89 06             	mov    %rax,(%r14)
   31191:	48 c7 44 24 70 0f 00 	movq   $0xf,0x70(%rsp)
   31198:	00 00 
   3119a:	4c 89 74 24 78       	mov    %r14,0x78(%rsp)
   3119f:	48 c7 84 24 80 00 00 	movq   $0xf,0x80(%rsp)
   311a6:	00 0f 00 00 00 
   311ab:	bf 04 00 00 00       	mov    $0x4,%edi
   311b0:	ff 15 b2 e9 03 00    	call   *0x3e9b2(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   311b6:	48 85 c0             	test   %rax,%rax
   311b9:	0f 84 ff 08 00 00    	je     31abe <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3f4e>
   311bf:	c7 00 6c 61 7a 79    	movl   $0x797a616c,(%rax)
   311c5:	c6 44 24 10 03       	movb   $0x3,0x10(%rsp)
   311ca:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   311d1:	00 00 
   311d3:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   311d8:	48 c7 44 24 28 04 00 	movq   $0x4,0x28(%rsp)
   311df:	00 00 
   311e1:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   311e6:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   311ed:	00 
   311ee:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   311f3:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   311f8:	e8 13 10 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   311fd:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   31202:	74 0a                	je     3120e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x369e>
   31204:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31209:	e8 32 8d ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3120e:	41 bd 1a 00 00 00    	mov    $0x1a,%r13d
   31214:	bf 1a 00 00 00       	mov    $0x1a,%edi
   31219:	ff 15 49 e9 03 00    	call   *0x3e949(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3121f:	48 85 c0             	test   %rax,%rax
   31222:	0f 84 00 07 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   31228:	0f 10 05 b0 81 fd ff 	movups -0x27e50(%rip),%xmm0        # 93df <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2a8>
   3122f:	0f 11 40 0a          	movups %xmm0,0xa(%rax)
   31233:	f3 0f 6f 05 9a 81 fd 	movdqu -0x27e66(%rip),%xmm0        # 93d5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x29e>
   3123a:	ff 
   3123b:	f3 0f 7f 00          	movdqu %xmm0,(%rax)
   3123f:	48 c7 44 24 70 1a 00 	movq   $0x1a,0x70(%rsp)
   31246:	00 00 
   31248:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   3124d:	48 c7 84 24 80 00 00 	movq   $0x1a,0x80(%rsp)
   31254:	00 1a 00 00 00 
   31259:	66 c7 44 24 10 01 00 	movw   $0x1,0x10(%rsp)
   31260:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31265:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   3126c:	00 
   3126d:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31272:	48 8d 4c 24 10       	lea    0x10(%rsp),%rcx
   31277:	e8 94 0f 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3127c:	80 7c 24 50 ff       	cmpb   $0xff,0x50(%rsp)
   31281:	74 0a                	je     3128d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x371d>
   31283:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31288:	e8 b3 8c ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3128d:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   31293:	bf 07 00 00 00       	mov    $0x7,%edi
   31298:	ff 15 ca e8 03 00    	call   *0x3e8ca(%rip)        # 6fb68 <malloc@GLIBC_2.2.5>
   3129e:	48 85 c0             	test   %rax,%rax
   312a1:	0f 84 81 06 00 00    	je     31928 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3db8>
   312a7:	49 89 c6             	mov    %rax,%r14
   312aa:	c7 40 03 70 6c 65 73 	movl   $0x73656c70,0x3(%rax)
   312b1:	c7 00 73 61 6d 70    	movl   $0x706d6173,(%rax)
   312b7:	48 c7 44 24 70 07 00 	movq   $0x7,0x70(%rsp)
   312be:	00 00 
   312c0:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   312c5:	48 c7 84 24 80 00 00 	movq   $0x7,0x80(%rsp)
   312cc:	00 07 00 00 00 
   312d1:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   312d6:	48 8d b4 24 60 01 00 	lea    0x160(%rsp),%rsi
   312dd:	00 
   312de:	e8 1d ba ff ff       	call   2cd00 <_RINvYNtNtNtCseZmxtRzJJaS_10serde_json5value3ser10SerializerNtNtCsgX5KCuC7WXX_10serde_core3ser10Serializer11collect_seqRINtNtCsgFX3jaOk65H_5alloc3vec3VecNtB7_5ValueEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   312e3:	80 7c 24 10 ff       	cmpb   $0xff,0x10(%rsp)
   312e8:	0f 84 69 04 00 00    	je     31757 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3be7>
   312ee:	f3 0f 6f 44 24 10    	movdqu 0x10(%rsp),%xmm0
   312f4:	66 0f 10 4c 24 20    	movupd 0x20(%rsp),%xmm1
   312fa:	66 0f 29 4c 24 60    	movapd %xmm1,0x60(%rsp)
   31300:	66 0f 7f 44 24 50    	movdqa %xmm0,0x50(%rsp)
   31306:	4c 8d 74 24 10       	lea    0x10(%rsp),%r14
   3130b:	48 8d b4 24 a8 00 00 	lea    0xa8(%rsp),%rsi
   31312:	00 
   31313:	48 8d 54 24 70       	lea    0x70(%rsp),%rdx
   31318:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
   3131d:	4c 89 f7             	mov    %r14,%rdi
   31320:	e8 eb 0e 00 00       	call   32210 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31325:	80 7c 24 10 ff       	cmpb   $0xff,0x10(%rsp)
   3132a:	74 0a                	je     31336 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x37c6>
   3132c:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31331:	e8 0a 8c ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31336:	f3 0f 6f 84 24 a8 00 	movdqu 0xa8(%rsp),%xmm0
   3133d:	00 00 
   3133f:	f3 0f 7f 44 24 18    	movdqu %xmm0,0x18(%rsp)
   31345:	48 8b 84 24 b8 00 00 	mov    0xb8(%rsp),%rax
   3134c:	00 
   3134d:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   31352:	c6 44 24 10 05       	movb   $0x5,0x10(%rsp)
   31357:	4c 89 74 24 50       	mov    %r14,0x50(%rsp)
   3135c:	48 8b 05 d5 eb 03 00 	mov    0x3ebd5(%rip),%rax        # 6ff38 <_DYNAMIC+0x618>
   31363:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   31368:	48 8d 3d b9 46 fd ff 	lea    -0x2b947(%rip),%rdi        # 5a28 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   3136f:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   31374:	ff 15 c6 eb 03 00    	call   *0x3ebc6(%rip)        # 6ff40 <_DYNAMIC+0x620>
   3137a:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   3137f:	e8 bc 8b ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31384:	4c 8b b4 24 68 01 00 	mov    0x168(%rsp),%r14
   3138b:	00 
   3138c:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
   31393:	00 
   31394:	48 85 c0             	test   %rax,%rax
   31397:	74 2c                	je     313c5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3855>
   31399:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   3139f:	49 29 c4             	sub    %rax,%r12
   313a2:	4d 89 f7             	mov    %r14,%r15
   313a5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   313ac:	00 00 00 00 
   313b0:	4c 89 ff             	mov    %r15,%rdi
   313b3:	e8 88 8b ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   313b8:	49 83 c7 20          	add    $0x20,%r15
   313bc:	49 ff c4             	inc    %r12
   313bf:	49 83 fc 01          	cmp    $0x1,%r12
   313c3:	75 eb                	jne    313b0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3840>
   313c5:	48 83 bc 24 60 01 00 	cmpq   $0x0,0x160(%rsp)
   313cc:	00 00 
   313ce:	74 09                	je     313d9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3869>
   313d0:	4c 89 f7             	mov    %r14,%rdi
   313d3:	ff 15 77 e7 03 00    	call   *0x3e777(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   313d9:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   313e0:	00 
   313e1:	e8 ea 87 ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   313e6:	48 83 bc 24 38 01 00 	cmpq   $0x0,0x138(%rsp)
   313ed:	00 00 
   313ef:	74 09                	je     313fa <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x388a>
   313f1:	48 89 df             	mov    %rbx,%rdi
   313f4:	ff 15 56 e7 03 00    	call   *0x3e756(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   313fa:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
   31401:	00 
   31402:	e8 c9 87 ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31407:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   3140e:	00 
   3140f:	48 85 c9             	test   %rcx,%rcx
   31412:	74 2a                	je     3143e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x38ce>
   31414:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   3141b:	00 
   3141c:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   31420:	48 01 c1             	add    %rax,%rcx
   31423:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   31427:	74 15                	je     3143e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x38ce>
   31429:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
   31430:	00 
   31431:	48 29 c7             	sub    %rax,%rdi
   31434:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   31438:	ff 15 12 e7 03 00    	call   *0x3e712(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   3143e:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   31445:	00 
   31446:	e8 a5 86 ff ff       	call   29af0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsiicy3ks7M05_4pbrs3map3MapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3144b:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   31452:	00 00 
   31454:	74 0e                	je     31464 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x38f4>
   31456:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
   3145d:	00 
   3145e:	ff 15 ec e6 03 00    	call   *0x3e6ec(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31464:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   3146b:	00 
   3146c:	48 83 3b 00          	cmpq   $0x0,(%rbx)
   31470:	74 0a                	je     3147c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x390c>
   31472:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   31476:	ff 15 d4 e6 03 00    	call   *0x3e6d4(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   3147c:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   31481:	74 0a                	je     3148d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x391d>
   31483:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   31487:	ff 15 c3 e6 03 00    	call   *0x3e6c3(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   3148d:	48 8b 84 24 20 02 00 	mov    0x220(%rsp),%rax
   31494:	00 
   31495:	48 83 38 00          	cmpq   $0x0,(%rax)
   31499:	74 12                	je     314ad <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x393d>
   3149b:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   314a2:	00 
   314a3:	48 8b 78 38          	mov    0x38(%rax),%rdi
   314a7:	ff 15 a3 e6 03 00    	call   *0x3e6a3(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   314ad:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
   314b4:	00 
   314b5:	48 83 38 00          	cmpq   $0x0,(%rax)
   314b9:	48 8b 9c 24 a0 00 00 	mov    0xa0(%rsp),%rbx
   314c0:	00 
   314c1:	74 0a                	je     314cd <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x395d>
   314c3:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   314c7:	ff 15 83 e6 03 00    	call   *0x3e683(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   314cd:	48 83 7b 60 00       	cmpq   $0x0,0x60(%rbx)
   314d2:	74 0a                	je     314de <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x396e>
   314d4:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
   314d8:	ff 15 72 e6 03 00    	call   *0x3e672(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   314de:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   314e3:	74 0d                	je     314f2 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3982>
   314e5:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
   314ec:	ff 15 5e e6 03 00    	call   *0x3e65e(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   314f2:	48 83 bc 24 d8 01 00 	cmpq   $0x0,0x1d8(%rsp)
   314f9:	00 00 
   314fb:	74 0e                	je     3150b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x399b>
   314fd:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
   31504:	00 
   31505:	ff 15 45 e6 03 00    	call   *0x3e645(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   3150b:	48 81 c4 58 02 00 00 	add    $0x258,%rsp
   31512:	5b                   	pop    %rbx
   31513:	41 5c                	pop    %r12
   31515:	41 5d                	pop    %r13
   31517:	41 5e                	pop    %r14
   31519:	41 5f                	pop    %r15
   3151b:	5d                   	pop    %rbp
   3151c:	c3                   	ret
   3151d:	48 8d 15 20 73 fd ff 	lea    -0x28ce0(%rip),%rdx        # 8844 <_RNvNtNtNtCskADBYZwJmSU_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x84>
   31524:	4c 8d 0d 15 ce 03 00 	lea    0x3ce15(%rip),%r9        # 6e340 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x870>
   3152b:	31 ff                	xor    %edi,%edi
   3152d:	48 8b 74 24 48       	mov    0x48(%rsp),%rsi
   31532:	31 c9                	xor    %ecx,%ecx
   31534:	ff 15 0e ea 03 00    	call   *0x3ea0e(%rip)        # 6ff48 <_DYNAMIC+0x628>
   3153a:	e9 3a 06 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3153f:	be 44 00 00 00       	mov    $0x44,%esi
   31544:	48 8d 3d a4 7e fd ff 	lea    -0x2815c(%rip),%rdi        # 93ef <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2b8>
   3154b:	48 8d 15 76 cd 03 00 	lea    0x3cd76(%rip),%rdx        # 6e2c8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7f8>
   31552:	ff 15 80 e7 03 00    	call   *0x3e780(%rip)        # 6fcd8 <_DYNAMIC+0x3b8>
   31558:	e9 1c 06 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3155d:	80 c2 d0             	add    $0xd0,%dl
   31560:	31 c0                	xor    %eax,%eax
   31562:	80 fa 0a             	cmp    $0xa,%dl
   31565:	14 01                	adc    $0x1,%al
   31567:	eb 02                	jmp    3156b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39fb>
   31569:	b0 02                	mov    $0x2,%al
   3156b:	88 44 24 10          	mov    %al,0x10(%rsp)
   3156f:	4c 8d 05 0a cc 03 00 	lea    0x3cc0a(%rip),%r8        # 6e180 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6b0>
   31576:	eb 19                	jmp    31591 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a21>
   31578:	80 c2 d0             	add    $0xd0,%dl
   3157b:	31 c0                	xor    %eax,%eax
   3157d:	80 fa 0a             	cmp    $0xa,%dl
   31580:	14 01                	adc    $0x1,%al
   31582:	eb 02                	jmp    31586 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a16>
   31584:	b0 02                	mov    $0x2,%al
   31586:	88 44 24 10          	mov    %al,0x10(%rsp)
   3158a:	4c 8d 05 07 cc 03 00 	lea    0x3cc07(%rip),%r8        # 6e198 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6c8>
   31591:	48 8d 3d ee 7e fd ff 	lea    -0x28112(%rip),%rdi        # 9486 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   31598:	48 8d 0d d9 cd 03 00 	lea    0x3cdd9(%rip),%rcx        # 6e378 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8a8>
   3159f:	be 2b 00 00 00       	mov    $0x2b,%esi
   315a4:	4c 89 e2             	mov    %r12,%rdx
   315a7:	ff 15 13 e6 03 00    	call   *0x3e613(%rip)        # 6fbc0 <_DYNAMIC+0x2a0>
   315ad:	e9 c7 05 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   315b2:	80 c2 d0             	add    $0xd0,%dl
   315b5:	31 c0                	xor    %eax,%eax
   315b7:	80 fa 0a             	cmp    $0xa,%dl
   315ba:	14 01                	adc    $0x1,%al
   315bc:	eb 02                	jmp    315c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a50>
   315be:	b0 02                	mov    $0x2,%al
   315c0:	88 44 24 10          	mov    %al,0x10(%rsp)
   315c4:	48 8d 3d bb 7e fd ff 	lea    -0x28145(%rip),%rdi        # 9486 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   315cb:	48 8d 0d a6 cd 03 00 	lea    0x3cda6(%rip),%rcx        # 6e378 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8a8>
   315d2:	4c 8d 05 47 cc 03 00 	lea    0x3cc47(%rip),%r8        # 6e220 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   315d9:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   315de:	be 2b 00 00 00       	mov    $0x2b,%esi
   315e3:	ff 15 d7 e5 03 00    	call   *0x3e5d7(%rip)        # 6fbc0 <_DYNAMIC+0x2a0>
   315e9:	e9 8b 05 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   315ee:	48 83 c1 08          	add    $0x8,%rcx
   315f2:	48 83 c0 f8          	add    $0xfffffffffffffff8,%rax
   315f6:	4d 89 c8             	mov    %r9,%r8
   315f9:	4d 8d 48 01          	lea    0x1(%r8),%r9
   315fd:	4d 39 e9             	cmp    %r13,%r9
   31600:	74 16                	je     31618 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3aa8>
   31602:	43 8b 3c c7          	mov    (%r15,%r8,8),%edi
   31606:	45 31 c0             	xor    %r8d,%r8d
   31609:	42 39 3c 01          	cmp    %edi,(%rcx,%r8,1)
   3160d:	74 df                	je     315ee <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a7e>
   3160f:	49 83 c0 08          	add    $0x8,%r8
   31613:	4c 39 c0             	cmp    %r8,%rax
   31616:	75 f1                	jne    31609 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a99>
   31618:	48 89 d7             	mov    %rdx,%rdi
   3161b:	4c 89 d2             	mov    %r10,%rdx
   3161e:	e9 2f ff ff ff       	jmp    31552 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39e2>
   31623:	bf 08 00 00 00       	mov    $0x8,%edi
   31628:	4c 89 e6             	mov    %r12,%rsi
   3162b:	ff 15 57 e5 03 00    	call   *0x3e557(%rip)        # 6fb88 <_DYNAMIC+0x268>
   31631:	e9 43 05 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31636:	48 8d 0d a3 cd 03 00 	lea    0x3cda3(%rip),%rcx        # 6e3e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x910>
   3163d:	ba 0b 00 00 00       	mov    $0xb,%edx
   31642:	31 ff                	xor    %edi,%edi
   31644:	4c 89 e6             	mov    %r12,%rsi
   31647:	ff 15 23 e5 03 00    	call   *0x3e523(%rip)        # 6fb70 <_DYNAMIC+0x250>
   3164d:	e9 27 05 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31652:	48 8d 0d 3f c9 03 00 	lea    0x3c93f(%rip),%rcx        # 6df98 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4c8>
   31659:	ba 0c 00 00 00       	mov    $0xc,%edx
   3165e:	31 ff                	xor    %edi,%edi
   31660:	4c 89 ee             	mov    %r13,%rsi
   31663:	ff 15 07 e5 03 00    	call   *0x3e507(%rip)        # 6fb70 <_DYNAMIC+0x250>
   31669:	e9 0b 05 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3166e:	bf 08 00 00 00       	mov    $0x8,%edi
   31673:	be 38 00 00 00       	mov    $0x38,%esi
   31678:	ff 15 0a e5 03 00    	call   *0x3e50a(%rip)        # 6fb88 <_DYNAMIC+0x268>
   3167e:	e9 f6 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31683:	48 8d 3d 27 7e fd ff 	lea    -0x281d9(%rip),%rdi        # 94b1 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x37a>
   3168a:	48 8d 15 07 cd 03 00 	lea    0x3cd07(%rip),%rdx        # 6e398 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8c8>
   31691:	be 79 00 00 00       	mov    $0x79,%esi
   31696:	ff 15 04 e5 03 00    	call   *0x3e504(%rip)        # 6fba0 <_DYNAMIC+0x280>
   3169c:	e9 d8 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   316a1:	48 8d 3d c8 7a fd ff 	lea    -0x28538(%rip),%rdi        # 9170 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   316a8:	48 8d 15 c9 c9 03 00 	lea    0x3c9c9(%rip),%rdx        # 6e078 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x5a8>
   316af:	be 28 00 00 00       	mov    $0x28,%esi
   316b4:	ff 15 1e e6 03 00    	call   *0x3e61e(%rip)        # 6fcd8 <_DYNAMIC+0x3b8>
   316ba:	e9 ba 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   316bf:	e8 21 8a ff ff       	call   2a0e5 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedReBM_ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   316c4:	e9 b0 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   316c9:	48 8d 0d 10 cd 03 00 	lea    0x3cd10(%rip),%rcx        # 6e3e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x910>
   316d0:	ba 0b 00 00 00       	mov    $0xb,%edx
   316d5:	31 ff                	xor    %edi,%edi
   316d7:	4c 89 e6             	mov    %r12,%rsi
   316da:	ff 15 90 e4 03 00    	call   *0x3e490(%rip)        # 6fb70 <_DYNAMIC+0x250>
   316e0:	e9 94 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   316e5:	48 8d 3d 8e 7b fd ff 	lea    -0x28472(%rip),%rdi        # 927a <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x143>
   316ec:	48 8d 15 45 cb 03 00 	lea    0x3cb45(%rip),%rdx        # 6e238 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x768>
   316f3:	be 35 00 00 00       	mov    $0x35,%esi
   316f8:	ff 15 da e5 03 00    	call   *0x3e5da(%rip)        # 6fcd8 <_DYNAMIC+0x3b8>
   316fe:	e9 76 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31703:	ff 15 47 e8 03 00    	call   *0x3e847(%rip)        # 6ff50 <_DYNAMIC+0x630>
   31709:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   3170e:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   31713:	e9 5c d0 ff ff       	jmp    2e774 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xc04>
   31718:	48 8d 15 31 cb 03 00 	lea    0x3cb31(%rip),%rdx        # 6e250 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x780>
   3171f:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   31726:	00 
   31727:	48 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%rsi
   3172e:	00 
   3172f:	e8 80 89 ff ff       	call   2a0b4 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31734:	e9 40 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31739:	48 8d 15 28 cb 03 00 	lea    0x3cb28(%rip),%rdx        # 6e268 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x798>
   31740:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31745:	48 8d b4 24 b8 01 00 	lea    0x1b8(%rsp),%rsi
   3174c:	00 
   3174d:	e8 62 89 ff ff       	call   2a0b4 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31752:	e9 22 04 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31757:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   3175c:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   31761:	48 8d 3d 1e 7d fd ff 	lea    -0x282e2(%rip),%rdi        # 9486 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x34f>
   31768:	48 8d 0d e9 cb 03 00 	lea    0x3cbe9(%rip),%rcx        # 6e358 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x888>
   3176f:	4c 8d 05 3a cb 03 00 	lea    0x3cb3a(%rip),%r8        # 6e2b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7e0>
   31776:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
   3177b:	be 2b 00 00 00       	mov    $0x2b,%esi
   31780:	ff 15 3a e4 03 00    	call   *0x3e43a(%rip)        # 6fbc0 <_DYNAMIC+0x2a0>
   31786:	e9 ee 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3178b:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   31790:	48 83 fe 15          	cmp    $0x15,%rsi
   31794:	0f 83 e1 03 00 00    	jae    31b7b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x400b>
   3179a:	e8 51 8f ff ff       	call   2a6f0 <_RINvNtNtNtNtCskADBYZwJmSU_4core5slice4sort6shared9smallsort25insertion_sort_shift_leftTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSB1m_7sort_byNCINvXs1o_NtNtNtB1y_11collections5btree3mapINtB2l_8BTreeMapllEINtNtNtNtBa_4iter6traits7collect12FromIteratorB1m_E9from_iterINtNtCsiicy3ks7M05_4pbrs3map11MapViewIterllEE0E0ECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3179f:	e9 f8 df ff ff       	jmp    2f79c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1c2c>
   317a4:	bf 08 00 00 00       	mov    $0x8,%edi
   317a9:	be c8 00 00 00       	mov    $0xc8,%esi
   317ae:	ff 15 d4 e3 03 00    	call   *0x3e3d4(%rip)        # 6fb88 <_DYNAMIC+0x268>
   317b4:	e9 c0 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   317b9:	48 8d 3d c0 c7 03 00 	lea    0x3c7c0(%rip),%rdi        # 6df80 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4b0>
   317c0:	ff 15 ea e4 03 00    	call   *0x3e4ea(%rip)        # 6fcb0 <_DYNAMIC+0x390>
   317c6:	e9 ae 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   317cb:	48 8d 3d 5b 7d fd ff 	lea    -0x282a5(%rip),%rdi        # 952d <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3f6>
   317d2:	48 8d 15 1f cc 03 00 	lea    0x3cc1f(%rip),%rdx        # 6e3f8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x928>
   317d9:	be 30 00 00 00       	mov    $0x30,%esi
   317de:	ff 15 f4 e4 03 00    	call   *0x3e4f4(%rip)        # 6fcd8 <_DYNAMIC+0x3b8>
   317e4:	e9 90 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   317e9:	48 8d 3d 78 c9 03 00 	lea    0x3c978(%rip),%rdi        # 6e168 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x698>
   317f0:	ff 15 ba e4 03 00    	call   *0x3e4ba(%rip)        # 6fcb0 <_DYNAMIC+0x390>
   317f6:	e9 7e 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   317fb:	bf 01 00 00 00       	mov    $0x1,%edi
   31800:	4c 89 fe             	mov    %r15,%rsi
   31803:	ff 15 0f e3 03 00    	call   *0x3e30f(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31809:	e9 6b 03 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3180e:	4c 89 e7             	mov    %r12,%rdi
   31811:	48 89 de             	mov    %rbx,%rsi
   31814:	4c 89 fa             	mov    %r15,%rdx
   31817:	e8 40 73 ff ff       	call   28b5c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsiicy3ks7M05_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3181c:	e9 37 df ff ff       	jmp    2f758 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1be8>
   31821:	4c 89 e3             	mov    %r12,%rbx
   31824:	49 89 c7             	mov    %rax,%r15
   31827:	48 89 c7             	mov    %rax,%rdi
   3182a:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   3182f:	e8 4c 8a ff ff       	call   2a280 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB2U_8adapters3map3MapINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map4IterllENCNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4mains0_0EE0E0INtNtB1b_3vec3VecBZ_EEB5c_>
   31834:	4c 89 f8             	mov    %r15,%rax
   31837:	48 8b 4c 24 08       	mov    0x8(%rsp),%rcx
   3183c:	49 89 dc             	mov    %rbx,%r12
   3183f:	e9 1c e2 ff ff       	jmp    2fa60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1ef0>
   31844:	48 8d 3d e8 7b fd ff 	lea    -0x28418(%rip),%rdi        # 9433 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2fc>
   3184b:	48 8d 15 8e ca 03 00 	lea    0x3ca8e(%rip),%rdx        # 6e2e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x810>
   31852:	be 28 00 00 00       	mov    $0x28,%esi
   31857:	e9 f6 fc ff ff       	jmp    31552 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39e2>
   3185c:	48 89 ef             	mov    %rbp,%rdi
   3185f:	4c 89 fe             	mov    %r15,%rsi
   31862:	4c 89 ea             	mov    %r13,%rdx
   31865:	e8 f2 72 ff ff       	call   28b5c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsiicy3ks7M05_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   3186a:	e9 78 e2 ff ff       	jmp    2fae7 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1f77>
   3186f:	b0 01                	mov    $0x1,%al
   31871:	e9 10 fd ff ff       	jmp    31586 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a16>
   31876:	b0 01                	mov    $0x1,%al
   31878:	e9 ee fc ff ff       	jmp    3156b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39fb>
   3187d:	b0 01                	mov    $0x1,%al
   3187f:	e9 3c fd ff ff       	jmp    315c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a50>
   31884:	4c 89 7c 24 50       	mov    %r15,0x50(%rsp)
   31889:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   31890:	00 
   31891:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   31896:	48 89 6c 24 60       	mov    %rbp,0x60(%rsp)
   3189b:	48 8d 3d 2e a5 fd ff 	lea    -0x25ad2(%rip),%rdi        # bdd0 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   318a2:	48 8d 0d ff d7 03 00 	lea    0x3d7ff(%rip),%rcx        # 6f0a8 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   318a9:	4c 8d 05 a8 d7 03 00 	lea    0x3d7a8(%rip),%r8        # 6f058 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   318b0:	48 8d 54 24 50       	lea    0x50(%rsp),%rdx
   318b5:	be 2b 00 00 00       	mov    $0x2b,%esi
   318ba:	ff 15 00 e3 03 00    	call   *0x3e300(%rip)        # 6fbc0 <_DYNAMIC+0x2a0>
   318c0:	e9 b4 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   318c5:	bf 01 00 00 00       	mov    $0x1,%edi
   318ca:	48 89 de             	mov    %rbx,%rsi
   318cd:	ff 15 45 e2 03 00    	call   *0x3e245(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   318d3:	e9 a1 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   318d8:	bf 01 00 00 00       	mov    $0x1,%edi
   318dd:	4c 89 fe             	mov    %r15,%rsi
   318e0:	ff 15 32 e2 03 00    	call   *0x3e232(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   318e6:	e9 8e 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   318eb:	bf 01 00 00 00       	mov    $0x1,%edi
   318f0:	4c 89 f6             	mov    %r14,%rsi
   318f3:	ff 15 1f e2 03 00    	call   *0x3e21f(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   318f9:	e9 7b 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   318fe:	be 28 00 00 00       	mov    $0x28,%esi
   31903:	48 8d 3d 29 7b fd ff 	lea    -0x284d7(%rip),%rdi        # 9433 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2fc>
   3190a:	48 8d 15 cf c9 03 00 	lea    0x3c9cf(%rip),%rdx        # 6e2e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x810>
   31911:	e9 3c fc ff ff       	jmp    31552 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39e2>
   31916:	48 8d 3d db c9 03 00 	lea    0x3c9db(%rip),%rdi        # 6e2f8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x828>
   3191d:	ff 15 05 e4 03 00    	call   *0x3e405(%rip)        # 6fd28 <_DYNAMIC+0x408>
   31923:	e9 51 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31928:	bf 01 00 00 00       	mov    $0x1,%edi
   3192d:	4c 89 ee             	mov    %r13,%rsi
   31930:	ff 15 e2 e1 03 00    	call   *0x3e1e2(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31936:	e9 3e 02 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   3193b:	4c 89 ed             	mov    %r13,%rbp
   3193e:	4c 89 f8             	mov    %r15,%rax
   31941:	48 29 e8             	sub    %rbp,%rax
   31944:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   3194b:	aa aa aa 
   3194e:	48 f7 e1             	mul    %rcx
   31951:	49 39 ef             	cmp    %rbp,%r15
   31954:	0f 85 ac 00 00 00    	jne    31a06 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3e96>
   3195a:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   31961:	00 00 
   31963:	74 0e                	je     31973 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3e03>
   31965:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
   3196c:	00 
   3196d:	ff 15 dd e1 03 00    	call   *0x3e1dd(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31973:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   3197a:	00 00 
   3197c:	b8 08 00 00 00       	mov    $0x8,%eax
   31981:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   31988:	00 
   31989:	48 c7 84 24 d8 01 00 	movq   $0x0,0x1d8(%rsp)
   31990:	00 00 00 00 00 
   31995:	45 31 f6             	xor    %r14d,%r14d
   31998:	48 8d 15 f1 68 fd ff 	lea    -0x2970f(%rip),%rdx        # 8290 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x20d>
   3199f:	48 8d 0d b5 7a fd ff 	lea    -0x2854b(%rip),%rcx        # 945b <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x324>
   319a6:	4c 8d 0d 7b c9 03 00 	lea    0x3c97b(%rip),%r9        # 6e328 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x858>
   319ad:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   319b2:	41 b8 45 00 00 00    	mov    $0x45,%r8d
   319b8:	31 ff                	xor    %edi,%edi
   319ba:	ff 15 48 e2 03 00    	call   *0x3e248(%rip)        # 6fc08 <_DYNAMIC+0x2e8>
   319c0:	e9 b4 01 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   319c5:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   319ca:	48 8b 84 24 90 00 00 	mov    0x90(%rsp),%rax
   319d1:	00 
   319d2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   319d7:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   319dc:	48 8d 3d ed a3 fd ff 	lea    -0x25c13(%rip),%rdi        # bdd0 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   319e3:	48 8d 0d be d6 03 00 	lea    0x3d6be(%rip),%rcx        # 6f0a8 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   319ea:	4c 8d 05 67 d6 03 00 	lea    0x3d667(%rip),%r8        # 6f058 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   319f1:	48 8d 54 24 10       	lea    0x10(%rsp),%rdx
   319f6:	be 2b 00 00 00       	mov    $0x2b,%esi
   319fb:	ff 15 bf e1 03 00    	call   *0x3e1bf(%rip)        # 6fbc0 <_DYNAMIC+0x2a0>
   31a01:	e9 73 01 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31a06:	48 89 d3             	mov    %rdx,%rbx
   31a09:	48 c1 eb 04          	shr    $0x4,%rbx
   31a0d:	48 83 c5 08          	add    $0x8,%rbp
   31a11:	4c 8b 35 38 e1 03 00 	mov    0x3e138(%rip),%r14        # 6fb50 <free@GLIBC_2.2.5>
   31a18:	eb 13                	jmp    31a2d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3ebd>
   31a1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   31a20:	48 83 c5 18          	add    $0x18,%rbp
   31a24:	48 ff cb             	dec    %rbx
   31a27:	0f 84 2d ff ff ff    	je     3195a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3dea>
   31a2d:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   31a32:	74 ec                	je     31a20 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3eb0>
   31a34:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   31a38:	41 ff d6             	call   *%r14
   31a3b:	eb e3                	jmp    31a20 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3eb0>
   31a3d:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   31a44:	00 00 
   31a46:	b8 04 00 00 00       	mov    $0x4,%eax
   31a4b:	48 89 84 24 d0 01 00 	mov    %rax,0x1d0(%rsp)
   31a52:	00 
   31a53:	48 8d 15 66 68 fd ff 	lea    -0x2979a(%rip),%rdx        # 82c0 <anon.574165b9a1e3cebd535338bb0d7973a0.751.llvm.2316785571840406366+0x20>
   31a5a:	4c 8d 0d af c8 03 00 	lea    0x3c8af(%rip),%r9        # 6e310 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x840>
   31a61:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   31a66:	31 ff                	xor    %edi,%edi
   31a68:	31 c9                	xor    %ecx,%ecx
   31a6a:	ff 15 98 e1 03 00    	call   *0x3e198(%rip)        # 6fc08 <_DYNAMIC+0x2e8>
   31a70:	e9 04 01 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31a75:	bf 08 00 00 00       	mov    $0x8,%edi
   31a7a:	e9 af c1 ff ff       	jmp    2dc2e <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0xbe>
   31a7f:	bf 01 00 00 00       	mov    $0x1,%edi
   31a84:	be 15 00 00 00       	mov    $0x15,%esi
   31a89:	ff 15 89 e0 03 00    	call   *0x3e089(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31a8f:	e9 e5 00 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31a94:	bf 01 00 00 00       	mov    $0x1,%edi
   31a99:	be 6b 00 00 00       	mov    $0x6b,%esi
   31a9e:	ff 15 74 e0 03 00    	call   *0x3e074(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31aa4:	e9 d0 00 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31aa9:	bf 01 00 00 00       	mov    $0x1,%edi
   31aae:	be 53 00 00 00       	mov    $0x53,%esi
   31ab3:	ff 15 5f e0 03 00    	call   *0x3e05f(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31ab9:	e9 bb 00 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31abe:	bf 01 00 00 00       	mov    $0x1,%edi
   31ac3:	be 04 00 00 00       	mov    $0x4,%esi
   31ac8:	ff 15 4a e0 03 00    	call   *0x3e04a(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31ace:	e9 a6 00 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31ad3:	31 c0                	xor    %eax,%eax
   31ad5:	e9 91 fa ff ff       	jmp    3156b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x39fb>
   31ada:	31 c0                	xor    %eax,%eax
   31adc:	e9 a5 fa ff ff       	jmp    31586 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a16>
   31ae1:	be 2f 00 00 00       	mov    $0x2f,%esi
   31ae6:	48 89 ca             	mov    %rcx,%rdx
   31ae9:	ff 15 e9 e1 03 00    	call   *0x3e1e9(%rip)        # 6fcd8 <_DYNAMIC+0x3b8>
   31aef:	e9 85 00 00 00       	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31af4:	31 c0                	xor    %eax,%eax
   31af6:	e9 c5 fa ff ff       	jmp    315c0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x3a50>
   31afb:	bf 01 00 00 00       	mov    $0x1,%edi
   31b00:	48 89 de             	mov    %rbx,%rsi
   31b03:	ff 15 0f e0 03 00    	call   *0x3e00f(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b09:	eb 6e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b0b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b10:	48 89 de             	mov    %rbx,%rsi
   31b13:	ff 15 ff df 03 00    	call   *0x3dfff(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b19:	eb 5e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b1b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b20:	48 89 de             	mov    %rbx,%rsi
   31b23:	ff 15 ef df 03 00    	call   *0x3dfef(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b29:	eb 4e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b2b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b30:	4c 89 e6             	mov    %r12,%rsi
   31b33:	ff 15 df df 03 00    	call   *0x3dfdf(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b39:	eb 3e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b3b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b40:	4c 89 f6             	mov    %r14,%rsi
   31b43:	ff 15 cf df 03 00    	call   *0x3dfcf(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b49:	eb 2e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b4b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b50:	4c 89 fe             	mov    %r15,%rsi
   31b53:	ff 15 bf df 03 00    	call   *0x3dfbf(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b59:	eb 1e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b5b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b60:	4c 89 fe             	mov    %r15,%rsi
   31b63:	ff 15 af df 03 00    	call   *0x3dfaf(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b69:	eb 0e                	jmp    31b79 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4009>
   31b6b:	bf 01 00 00 00       	mov    $0x1,%edi
   31b70:	4c 89 fe             	mov    %r15,%rsi
   31b73:	ff 15 9f df 03 00    	call   *0x3df9f(%rip)        # 6fb18 <_DYNAMIC+0x1f8>
   31b79:	0f 0b                	ud2
   31b7b:	48 89 fb             	mov    %rdi,%rbx
   31b7e:	e8 ed 85 ff ff       	call   2a170 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtCsiicy3ks7M05_4pbrs3map11MapViewIterllEE0E0INtNtB1b_3vec3VecBZ_EECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31b83:	e9 14 dc ff ff       	jmp    2f79c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x1c2c>
   31b88:	49 89 c4             	mov    %rax,%r12
   31b8b:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
   31b91:	0f 84 dc 03 00 00    	je     31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31b97:	48 89 df             	mov    %rbx,%rdi
   31b9a:	ff 15 b0 df 03 00    	call   *0x3dfb0(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31ba0:	e9 ce 03 00 00       	jmp    31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31ba5:	49 89 c4             	mov    %rax,%r12
   31ba8:	48 85 db             	test   %rbx,%rbx
   31bab:	0f 84 b5 03 00 00    	je     31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31bb1:	4c 89 ff             	mov    %r15,%rdi
   31bb4:	e9 4a 03 00 00       	jmp    31f03 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4393>
   31bb9:	49 89 c4             	mov    %rax,%r12
   31bbc:	e9 0f 04 00 00       	jmp    31fd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4460>
   31bc1:	49 89 c4             	mov    %rax,%r12
   31bc4:	4c 89 f7             	mov    %r14,%rdi
   31bc7:	ff 15 83 df 03 00    	call   *0x3df83(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31bcd:	eb 54                	jmp    31c23 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40b3>
   31bcf:	eb 4f                	jmp    31c20 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40b0>
   31bd1:	e9 8c 00 00 00       	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31bd6:	e9 87 00 00 00       	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31bdb:	e9 82 00 00 00       	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31be0:	49 89 c4             	mov    %rax,%r12
   31be3:	e9 b1 03 00 00       	jmp    31f99 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4429>
   31be8:	49 89 c4             	mov    %rax,%r12
   31beb:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31bf0:	e8 4b 83 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31bf5:	e9 b7 02 00 00       	jmp    31eb1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4341>
   31bfa:	e9 9c 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31bff:	eb 61                	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31c01:	eb 67                	jmp    31c6a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40fa>
   31c03:	eb 65                	jmp    31c6a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40fa>
   31c05:	eb 5b                	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31c07:	e9 8f 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c0c:	e9 8a 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c11:	e9 85 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c16:	e9 80 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c1b:	e9 7b 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c20:	49 89 c4             	mov    %rax,%r12
   31c23:	48 83 7c 24 70 00    	cmpq   $0x0,0x70(%rsp)
   31c29:	0f 84 04 02 00 00    	je     31e33 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x42c3>
   31c2f:	4c 89 ff             	mov    %r15,%rdi
   31c32:	e9 f6 01 00 00       	jmp    31e2d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x42bd>
   31c37:	eb 29                	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31c39:	e9 5d 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c3e:	e9 58 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c43:	e9 53 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c48:	e9 4e 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c4d:	e9 49 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c52:	e9 44 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c57:	eb 11                	jmp    31c6a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40fa>
   31c59:	e9 3d 01 00 00       	jmp    31d9b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x422b>
   31c5e:	eb 02                	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31c60:	eb 00                	jmp    31c62 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x40f2>
   31c62:	49 89 c4             	mov    %rax,%r12
   31c65:	e9 c0 01 00 00       	jmp    31e2a <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x42ba>
   31c6a:	49 89 c4             	mov    %rax,%r12
   31c6d:	48 89 df             	mov    %rbx,%rdi
   31c70:	e9 b8 01 00 00       	jmp    31e2d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x42bd>
   31c75:	49 89 c4             	mov    %rax,%r12
   31c78:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31c7e:	0f 84 d4 03 00 00    	je     32058 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44e8>
   31c84:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31c89:	e9 c4 03 00 00       	jmp    32052 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44e2>
   31c8e:	e9 af 03 00 00       	jmp    32042 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44d2>
   31c93:	49 89 c4             	mov    %rax,%r12
   31c96:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31c9c:	0f 84 c4 02 00 00    	je     31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31ca2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31ca7:	e9 57 02 00 00       	jmp    31f03 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4393>
   31cac:	49 89 c4             	mov    %rax,%r12
   31caf:	4d 85 f6             	test   %r14,%r14
   31cb2:	0f 85 44 03 00 00    	jne    31ffc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x448c>
   31cb8:	48 83 bc 24 d8 01 00 	cmpq   $0x0,0x1d8(%rsp)
   31cbf:	00 00 
   31cc1:	0f 84 b4 03 00 00    	je     3207b <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x450b>
   31cc7:	48 8b bc 24 a0 00 00 	mov    0xa0(%rsp),%rdi
   31cce:	00 
   31ccf:	ff 15 7b de 03 00    	call   *0x3de7b(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31cd5:	4c 89 e7             	mov    %r12,%rdi
   31cd8:	e8 53 a7 03 00       	call   6c430 <_Unwind_Resume@plt>
   31cdd:	eb 3e                	jmp    31d1d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x41ad>
   31cdf:	e9 a4 01 00 00       	jmp    31e88 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4318>
   31ce4:	e9 df 00 00 00       	jmp    31dc8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4258>
   31ce9:	e9 ee 00 00 00       	jmp    31ddc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x426c>
   31cee:	49 89 c4             	mov    %rax,%r12
   31cf1:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   31cf6:	e8 45 82 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31cfb:	e9 b1 01 00 00       	jmp    31eb1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4341>
   31d00:	ff 15 a2 de 03 00    	call   *0x3dea2(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31d06:	e9 d1 00 00 00       	jmp    31ddc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x426c>
   31d0b:	49 89 c4             	mov    %rax,%r12
   31d0e:	48 83 7c 24 50 00    	cmpq   $0x0,0x50(%rsp)
   31d14:	74 1d                	je     31d33 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x41c3>
   31d16:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   31d1b:	eb 10                	jmp    31d2d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x41bd>
   31d1d:	49 89 c4             	mov    %rax,%r12
   31d20:	4d 85 ff             	test   %r15,%r15
   31d23:	74 0e                	je     31d33 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x41c3>
   31d25:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   31d2c:	00 
   31d2d:	ff 15 1d de 03 00    	call   *0x3de1d(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31d33:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31d38:	e8 13 81 ff ff       	call   29e50 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCs8ZKwes1zzDd_3std3env4ArgsECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31d3d:	48 8d 7c 24 70       	lea    0x70(%rsp),%rdi
   31d42:	e8 89 7c ff ff       	call   299d0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsgFX3jaOk65H_5alloc3vec3VecNtNtBG_6string6StringEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31d47:	4c 89 e7             	mov    %r12,%rdi
   31d4a:	e8 e1 a6 03 00       	call   6c430 <_Unwind_Resume@plt>
   31d4f:	48 89 c3             	mov    %rax,%rbx
   31d52:	4d 85 e4             	test   %r12,%r12
   31d55:	74 1a                	je     31d71 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4201>
   31d57:	49 83 c7 20          	add    $0x20,%r15
   31d5b:	49 f7 dc             	neg    %r12
   31d5e:	66 90                	xchg   %ax,%ax
   31d60:	4c 89 ff             	mov    %r15,%rdi
   31d63:	e8 d8 81 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31d68:	49 83 c7 20          	add    $0x20,%r15
   31d6c:	49 ff cc             	dec    %r12
   31d6f:	75 ef                	jne    31d60 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x41f0>
   31d71:	48 83 bc 24 60 01 00 	cmpq   $0x0,0x160(%rsp)
   31d78:	00 00 
   31d7a:	75 08                	jne    31d84 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4214>
   31d7c:	49 89 dc             	mov    %rbx,%r12
   31d7f:	e9 e2 01 00 00       	jmp    31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31d84:	4c 89 f7             	mov    %r14,%rdi
   31d87:	ff 15 c3 dd 03 00    	call   *0x3ddc3(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31d8d:	49 89 dc             	mov    %rbx,%r12
   31d90:	e9 d1 01 00 00       	jmp    31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31d95:	ff 15 0d de 03 00    	call   *0x3de0d(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31d9b:	49 89 c4             	mov    %rax,%r12
   31d9e:	e9 90 00 00 00       	jmp    31e33 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x42c3>
   31da3:	49 89 c4             	mov    %rax,%r12
   31da6:	41 be 06 00 00 00    	mov    $0x6,%r14d
   31dac:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   31db2:	0f 84 44 02 00 00    	je     31ffc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x448c>
   31db8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   31dbd:	e9 34 02 00 00       	jmp    31ff6 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4486>
   31dc2:	eb 35                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31dc4:	eb 33                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31dc6:	eb 31                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31dc8:	49 89 c4             	mov    %rax,%r12
   31dcb:	48 89 df             	mov    %rbx,%rdi
   31dce:	ff 15 7c dd 03 00    	call   *0x3dd7c(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31dd4:	eb 26                	jmp    31dfc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x428c>
   31dd6:	eb 21                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31dd8:	eb 02                	jmp    31ddc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x426c>
   31dda:	eb 1d                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31ddc:	48 89 c3             	mov    %rax,%rbx
   31ddf:	4c 89 e7             	mov    %r12,%rdi
   31de2:	ff 15 68 dd 03 00    	call   *0x3dd68(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31de8:	49 89 dc             	mov    %rbx,%r12
   31deb:	eb 0f                	jmp    31dfc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x428c>
   31ded:	e9 71 01 00 00       	jmp    31f63 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f3>
   31df2:	e9 b7 00 00 00       	jmp    31eae <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x433e>
   31df7:	eb 00                	jmp    31df9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4289>
   31df9:	49 89 c4             	mov    %rax,%r12
   31dfc:	48 8d bc 24 a8 00 00 	lea    0xa8(%rsp),%rdi
   31e03:	00 
   31e04:	e8 e7 20 00 00       	call   33ef0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31e09:	e9 a3 00 00 00       	jmp    31eb1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4341>
   31e0e:	0f 0b                	ud2
   31e10:	4c 89 e7             	mov    %r12,%rdi
   31e13:	ff 15 37 dd 03 00    	call   *0x3dd37(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31e19:	0f 0b                	ud2
   31e1b:	0f 0b                	ud2
   31e1d:	49 89 c4             	mov    %rax,%r12
   31e20:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31e25:	e8 a6 80 ff ff       	call   29ed0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5error5ErrorECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31e2a:	4c 89 f7             	mov    %r14,%rdi
   31e2d:	ff 15 1d dd 03 00    	call   *0x3dd1d(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31e33:	48 8d bc 24 a8 00 00 	lea    0xa8(%rsp),%rdi
   31e3a:	00 
   31e3b:	e8 b0 20 00 00       	call   33ef0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31e40:	eb 6f                	jmp    31eb1 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4341>
   31e42:	ff 15 60 dd 03 00    	call   *0x3dd60(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31e48:	49 89 c4             	mov    %rax,%r12
   31e4b:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   31e50:	e8 7b 7d ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31e55:	e9 0c 01 00 00       	jmp    31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31e5a:	eb 52                	jmp    31eae <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x433e>
   31e5c:	eb 32                	jmp    31e90 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4320>
   31e5e:	49 89 c4             	mov    %rax,%r12
   31e61:	41 c7 47 30 03 00 00 	movl   $0x3,0x30(%r15)
   31e68:	00 
   31e69:	e9 05 01 00 00       	jmp    31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31e6e:	49 89 c4             	mov    %rax,%r12
   31e71:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   31e76:	e8 05 7d ff ff       	call   29b80 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsiicy3ks7M05_4pbrs3map8MapInnerllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31e7b:	e9 f3 00 00 00       	jmp    31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31e80:	ff 15 22 dd 03 00    	call   *0x3dd22(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31e86:	eb 08                	jmp    31e90 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4320>
   31e88:	49 89 c4             	mov    %rax,%r12
   31e8b:	e9 e3 00 00 00       	jmp    31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31e90:	49 89 c4             	mov    %rax,%r12
   31e93:	4c 89 ff             	mov    %r15,%rdi
   31e96:	ff 15 b4 dc 03 00    	call   *0x3dcb4(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31e9c:	e9 d2 00 00 00       	jmp    31f73 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4403>
   31ea1:	e9 bd 00 00 00       	jmp    31f63 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f3>
   31ea6:	49 89 c4             	mov    %rax,%r12
   31ea9:	e9 2f 01 00 00       	jmp    31fdd <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x446d>
   31eae:	49 89 c4             	mov    %rax,%r12
   31eb1:	4c 8b b4 24 68 01 00 	mov    0x168(%rsp),%r14
   31eb8:	00 
   31eb9:	48 8b 84 24 70 01 00 	mov    0x170(%rsp),%rax
   31ec0:	00 
   31ec1:	48 85 c0             	test   %rax,%rax
   31ec4:	74 2f                	je     31ef5 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4385>
   31ec6:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31ecc:	49 29 c7             	sub    %rax,%r15
   31ecf:	4c 89 f3             	mov    %r14,%rbx
   31ed2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   31ed9:	1f 84 00 00 00 00 00 
   31ee0:	48 89 df             	mov    %rbx,%rdi
   31ee3:	e8 58 80 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31ee8:	48 83 c3 20          	add    $0x20,%rbx
   31eec:	49 ff c7             	inc    %r15
   31eef:	49 83 ff 01          	cmp    $0x1,%r15
   31ef3:	75 eb                	jne    31ee0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4370>
   31ef5:	48 83 bc 24 60 01 00 	cmpq   $0x0,0x160(%rsp)
   31efc:	00 00 
   31efe:	74 66                	je     31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31f00:	4c 89 f7             	mov    %r14,%rdi
   31f03:	ff 15 47 dc 03 00    	call   *0x3dc47(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31f09:	eb 5b                	jmp    31f66 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43f6>
   31f0b:	4d 85 ff             	test   %r15,%r15
   31f0e:	74 21                	je     31f31 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43c1>
   31f10:	48 83 c3 20          	add    $0x20,%rbx
   31f14:	49 f7 df             	neg    %r15
   31f17:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   31f1e:	00 00 
   31f20:	48 89 df             	mov    %rbx,%rdi
   31f23:	e8 18 80 ff ff       	call   29f40 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31f28:	48 83 c3 20          	add    $0x20,%rbx
   31f2c:	49 ff cf             	dec    %r15
   31f2f:	75 ef                	jne    31f20 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x43b0>
   31f31:	48 83 bc 24 60 01 00 	cmpq   $0x0,0x160(%rsp)
   31f38:	00 00 
   31f3a:	0f 84 fc 00 00 00    	je     3203c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44cc>
   31f40:	4c 89 f7             	mov    %r14,%rdi
   31f43:	ff 15 07 dc 03 00    	call   *0x3dc07(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31f49:	ff 15 59 dc 03 00    	call   *0x3dc59(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31f4f:	ff 15 53 dc 03 00    	call   *0x3dc53(%rip)        # 6fba8 <_DYNAMIC+0x288>
   31f55:	49 89 c4             	mov    %rax,%r12
   31f58:	41 be 06 00 00 00    	mov    $0x6,%r14d
   31f5e:	e9 99 00 00 00       	jmp    31ffc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x448c>
   31f63:	49 89 c4             	mov    %rax,%r12
   31f66:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   31f6d:	00 
   31f6e:	e8 5d 7c ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31f73:	48 83 bc 24 38 01 00 	cmpq   $0x0,0x138(%rsp)
   31f7a:	00 00 
   31f7c:	74 0e                	je     31f8c <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x441c>
   31f7e:	48 8b bc 24 40 01 00 	mov    0x140(%rsp),%rdi
   31f85:	00 
   31f86:	ff 15 c4 db 03 00    	call   *0x3dbc4(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31f8c:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
   31f93:	00 
   31f94:	e8 37 7c ff ff       	call   29bd0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31f99:	48 8b 8c 24 88 01 00 	mov    0x188(%rsp),%rcx
   31fa0:	00 
   31fa1:	48 85 c9             	test   %rcx,%rcx
   31fa4:	74 2a                	je     31fd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4460>
   31fa6:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   31fad:	00 
   31fae:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   31fb2:	48 01 c1             	add    %rax,%rcx
   31fb5:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   31fb9:	74 15                	je     31fd0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4460>
   31fbb:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
   31fc2:	00 
   31fc3:	48 29 c7             	sub    %rax,%rdi
   31fc6:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   31fca:	ff 15 80 db 03 00    	call   *0x3db80(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31fd0:	48 8b bc 24 f0 00 00 	mov    0xf0(%rsp),%rdi
   31fd7:	00 
   31fd8:	e8 13 7b ff ff       	call   29af0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsiicy3ks7M05_4pbrs3map3MapllEECsapjKrC6Ky8i_24pbrs_map_iteration_proof>
   31fdd:	41 be 06 00 00 00    	mov    $0x6,%r14d
   31fe3:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   31fea:	00 00 
   31fec:	74 0e                	je     31ffc <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x448c>
   31fee:	48 8b bc 24 e8 00 00 	mov    0xe8(%rsp),%rdi
   31ff5:	00 
   31ff6:	ff 15 54 db 03 00    	call   *0x3db54(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   31ffc:	48 8b 84 24 a0 00 00 	mov    0xa0(%rsp),%rax
   32003:	00 
   32004:	48 8d 58 08          	lea    0x8(%rax),%rbx
   32008:	4c 8b 3d 41 db 03 00 	mov    0x3db41(%rip),%r15        # 6fb50 <free@GLIBC_2.2.5>
   3200f:	eb 1c                	jmp    3202d <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44bd>
   32011:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   32018:	0f 1f 84 00 00 00 00 
   3201f:	00 
   32020:	48 83 c3 18          	add    $0x18,%rbx
   32024:	49 ff ce             	dec    %r14
   32027:	0f 84 8b fc ff ff    	je     31cb8 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4148>
   3202d:	48 83 7b f8 00       	cmpq   $0x0,-0x8(%rbx)
   32032:	74 ec                	je     32020 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44b0>
   32034:	48 8b 3b             	mov    (%rbx),%rdi
   32037:	41 ff d7             	call   *%r15
   3203a:	eb e4                	jmp    32020 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44b0>
   3203c:	ff 15 66 db 03 00    	call   *0x3db66(%rip)        # 6fba8 <_DYNAMIC+0x288>
   32042:	49 89 c4             	mov    %rax,%r12
   32045:	4d 85 f6             	test   %r14,%r14
   32048:	74 0e                	je     32058 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x44e8>
   3204a:	48 8b bc 24 90 00 00 	mov    0x90(%rsp),%rdi
   32051:	00 
   32052:	ff 15 f8 da 03 00    	call   *0x3daf8(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   32058:	4c 89 f8             	mov    %r15,%rax
   3205b:	4c 29 e8             	sub    %r13,%rax
   3205e:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   32065:	aa aa aa 
   32068:	48 f7 e1             	mul    %rcx
   3206b:	4d 39 ef             	cmp    %r13,%r15
   3206e:	75 13                	jne    32083 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4513>
   32070:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   32077:	00 00 
   32079:	75 3e                	jne    320b9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4549>
   3207b:	4c 89 e7             	mov    %r12,%rdi
   3207e:	e8 ad a3 03 00       	call   6c430 <_Unwind_Resume@plt>
   32083:	48 89 d3             	mov    %rdx,%rbx
   32086:	48 c1 eb 04          	shr    $0x4,%rbx
   3208a:	48 83 c5 20          	add    $0x20,%rbp
   3208e:	4c 8b 35 bb da 03 00 	mov    0x3dabb(%rip),%r14        # 6fb50 <free@GLIBC_2.2.5>
   32095:	eb 12                	jmp    320a9 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4539>
   32097:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3209e:	00 00 
   320a0:	48 83 c5 18          	add    $0x18,%rbp
   320a4:	48 ff cb             	dec    %rbx
   320a7:	74 c7                	je     32070 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4500>
   320a9:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   320ae:	74 f0                	je     320a0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4530>
   320b0:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   320b4:	41 ff d6             	call   *%r14
   320b7:	eb e7                	jmp    320a0 <_RNvCsapjKrC6Ky8i_24pbrs_map_iteration_proof4main+0x4530>
   320b9:	48 8b bc 24 80 01 00 	mov    0x180(%rsp),%rdi
   320c0:	00 
   320c1:	ff 15 89 da 03 00    	call   *0x3da89(%rip)        # 6fb50 <free@GLIBC_2.2.5>
   320c7:	4c 89 e7             	mov    %r12,%rdi
   320ca:	e8 61 a3 03 00       	call   6c430 <_Unwind_Resume@plt>
