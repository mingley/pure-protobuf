
work/all-benchmarks/measurement/round-loop-after/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002da50 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_>:
   2da50:	55                   	push   %rbp
   2da51:	41 57                	push   %r15
   2da53:	41 56                	push   %r14
   2da55:	41 55                	push   %r13
   2da57:	41 54                	push   %r12
   2da59:	53                   	push   %rbx
   2da5a:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
   2da61:	48 8b 07             	mov    (%rdi),%rax
   2da64:	48 8b 00             	mov    (%rax),%rax
   2da67:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2da6c:	75 10                	jne    2da7e <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x2e>
   2da6e:	48 8b 40 08          	mov    0x8(%rax),%rax
   2da72:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2da78:	0f 84 48 03 00 00    	je     2ddc6 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2da7e:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2da82:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2da87:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2da8c:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2da90:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2da94:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2da98:	48 83 f9 04          	cmp    $0x4,%rcx
   2da9c:	0f 87 c5 08 00 00    	ja     2e367 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2daa2:	48 8b 40 08          	mov    0x8(%rax),%rax
   2daa6:	48 8d 15 13 b8 fd ff 	lea    -0x247ed(%rip),%rdx        # 92c0 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2daad:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2dab1:	48 01 d1             	add    %rdx,%rcx
   2dab4:	ff e1                	jmp    *%rcx
   2dab6:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2dabd:	61 6c 6c 
   2dac0:	48 39 08             	cmp    %rcx,(%rax)
   2dac3:	0f 85 9e 08 00 00    	jne    2e367 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dac9:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   2dace:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2dad2:	48 85 c0             	test   %rax,%rax
   2dad5:	0f 84 27 03 00 00    	je     2de02 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2dadb:	48 8b 09             	mov    (%rcx),%rcx
   2dade:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2dae2:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dae6:	f7 d7                	not    %edi
   2dae8:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2daec:	31 d2                	xor    %edx,%edx
   2daee:	eb 33                	jmp    2db23 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2daf0:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2daf4:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2daf9:	41 21 f8             	and    %edi,%r8d
   2dafc:	41 c1 e1 03          	shl    $0x3,%r9d
   2db00:	48 89 cf             	mov    %rcx,%rdi
   2db03:	4c 29 cf             	sub    %r9,%rdi
   2db06:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2db0a:	49 89 d2             	mov    %rdx,%r10
   2db0d:	4d 01 ca             	add    %r9,%r10
   2db10:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2db14:	4c 01 d2             	add    %r10,%rdx
   2db17:	44 89 c7             	mov    %r8d,%edi
   2db1a:	48 ff c8             	dec    %rax
   2db1d:	0f 84 e1 02 00 00    	je     2de04 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2db23:	66 85 ff             	test   %di,%di
   2db26:	75 c8                	jne    2daf0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2db28:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2db2f:	00 
   2db30:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2db34:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2db38:	48 83 c6 10          	add    $0x10,%rsi
   2db3c:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2db40:	66 83 f7 ff          	xor    $0xffff,%di
   2db44:	74 ea                	je     2db30 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2db46:	eb a8                	jmp    2daf0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2db48:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2db4f:	66 69 72 
   2db52:	48 33 08             	xor    (%rax),%rcx
   2db55:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2db59:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2db5f:	48 09 c8             	or     %rcx,%rax
   2db62:	0f 85 ff 07 00 00    	jne    2e367 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2db68:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2db6d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2db72:	0f 84 77 02 00 00    	je     2ddef <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2db78:	48 8b 00             	mov    (%rax),%rax
   2db7b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2db7f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2db83:	66 83 f1 ff          	xor    $0xffff,%cx
   2db87:	75 1d                	jne    2dba6 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2db89:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2db8d:	0f 1f 00             	nopl   (%rax)
   2db90:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2db94:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2db98:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2db9c:	48 83 c2 10          	add    $0x10,%rdx
   2dba0:	66 83 f1 ff          	xor    $0xffff,%cx
   2dba4:	74 ea                	je     2db90 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2dba6:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2dbaa:	c1 e1 03             	shl    $0x3,%ecx
   2dbad:	48 29 c8             	sub    %rcx,%rax
   2dbb0:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2dbb4:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2dbb8:	e9 34 02 00 00       	jmp    2ddf1 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2dbbd:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2dbc4:	72 65 61 
   2dbc7:	48 33 08             	xor    (%rax),%rcx
   2dbca:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2dbce:	48 83 f0 64          	xor    $0x64,%rax
   2dbd2:	48 09 c8             	or     %rcx,%rax
   2dbd5:	0f 85 8c 07 00 00    	jne    2e367 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dbdb:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2dbe2:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2dbe7:	0f 85 93 07 00 00    	jne    2e380 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x930>
   2dbed:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2dbf1:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2dbf6:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2dbfa:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2dbfe:	0f 10 05 2b 22 04 00 	movups 0x4222b(%rip),%xmm0        # 6fe30 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2dc05:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2dc09:	f3 0f 6f 05 2f 22 04 	movdqu 0x4222f(%rip),%xmm0        # 6fe40 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2dc10:	00 
   2dc11:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2dc17:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2dc1c:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2dc21:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2dc25:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2dc2a:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2dc2f:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2dc34:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dc38:	48 85 c9             	test   %rcx,%rcx
   2dc3b:	0f 84 cf 01 00 00    	je     2de10 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2dc41:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2dc45:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2dc49:	48 89 e3             	mov    %rsp,%rbx
   2dc4c:	0f 1f 40 00          	nopl   0x0(%rax)
   2dc50:	41 8b 36             	mov    (%r14),%esi
   2dc53:	41 8b 56 04          	mov    0x4(%r14),%edx
   2dc57:	48 89 df             	mov    %rbx,%rdi
   2dc5a:	e8 71 5b 00 00       	call   337d0 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2dc5f:	49 83 c6 08          	add    $0x8,%r14
   2dc63:	4d 39 fe             	cmp    %r15,%r14
   2dc66:	75 e8                	jne    2dc50 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2dc68:	48 8b 3c 24          	mov    (%rsp),%rdi
   2dc6c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2dc71:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2dc76:	48 85 c9             	test   %rcx,%rcx
   2dc79:	0f 84 86 03 00 00    	je     2e005 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x5b5>
   2dc7f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2dc83:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dc88:	41 f7 d1             	not    %r9d
   2dc8b:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2dc8f:	31 d2                	xor    %edx,%edx
   2dc91:	49 89 f8             	mov    %rdi,%r8
   2dc94:	eb 3d                	jmp    2dcd3 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2dc96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2dc9d:	00 00 00 
   2dca0:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2dca4:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2dca9:	45 21 ca             	and    %r9d,%r10d
   2dcac:	41 c1 e3 03          	shl    $0x3,%r11d
   2dcb0:	4d 89 c1             	mov    %r8,%r9
   2dcb3:	4d 29 d9             	sub    %r11,%r9
   2dcb6:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2dcba:	48 89 d3             	mov    %rdx,%rbx
   2dcbd:	4c 01 db             	add    %r11,%rbx
   2dcc0:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2dcc4:	48 01 da             	add    %rbx,%rdx
   2dcc7:	45 89 d1             	mov    %r10d,%r9d
   2dcca:	48 ff c9             	dec    %rcx
   2dccd:	0f 84 34 03 00 00    	je     2e007 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x5b7>
   2dcd3:	66 45 85 c9          	test   %r9w,%r9w
   2dcd7:	75 c7                	jne    2dca0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2dcd9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2dce0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dce4:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2dce8:	48 83 c6 10          	add    $0x10,%rsi
   2dcec:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dcf1:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2dcf6:	74 e8                	je     2dce0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2dcf8:	eb a6                	jmp    2dca0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2dcfa:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2dd01:	63 6f 6c 
   2dd04:	48 33 08             	xor    (%rax),%rcx
   2dd07:	8b 40 08             	mov    0x8(%rax),%eax
   2dd0a:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2dd10:	48 09 c8             	or     %rcx,%rax
   2dd13:	0f 85 4e 06 00 00    	jne    2e367 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x917>
   2dd19:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2dd1e:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2dd22:	48 85 c9             	test   %rcx,%rcx
   2dd25:	0f 84 f8 00 00 00    	je     2de23 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2dd2b:	4c 8b 28             	mov    (%rax),%r13
   2dd2e:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2dd34:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dd39:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2dd3d:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dd42:	75 25                	jne    2dd69 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2dd44:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2dd4b:	00 00 00 00 00 
   2dd50:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2dd55:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2dd59:	48 83 c5 10          	add    $0x10,%rbp
   2dd5d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dd62:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dd67:	74 e7                	je     2dd50 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2dd69:	48 83 f9 05          	cmp    $0x5,%rcx
   2dd6d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2dd72:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2dd78:	4c 0f 43 f9          	cmovae %rcx,%r15
   2dd7c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2dd83:	00 
   2dd84:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2dd8b:	ff ff 1f 
   2dd8e:	48 ff c0             	inc    %rax
   2dd91:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   2dd96:	48 39 c1             	cmp    %rax,%rcx
   2dd99:	0f 97 c0             	seta   %al
   2dd9c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2dda3:	ff ff 7f 
   2dda6:	48 83 c1 0b          	add    $0xb,%rcx
   2ddaa:	49 39 ce             	cmp    %rcx,%r14
   2ddad:	0f 97 c1             	seta   %cl
   2ddb0:	08 c1                	or     %al,%cl
   2ddb2:	0f 84 40 01 00 00    	je     2def8 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x4a8>
   2ddb8:	31 db                	xor    %ebx,%ebx
   2ddba:	48 89 df             	mov    %rbx,%rdi
   2ddbd:	4c 89 f6             	mov    %r14,%rsi
   2ddc0:	ff 15 f2 3c 04 00    	call   *0x43cf2(%rip)        # 71ab8 <_DYNAMIC+0x230>
   2ddc6:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2ddca:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2ddcf:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
   2ddd4:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2ddd9:	4c 8b 30             	mov    (%rax),%r14
   2dddc:	4d 85 f6             	test   %r14,%r14
   2dddf:	74 4f                	je     2de30 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2dde1:	49 8b 46 08          	mov    0x8(%r14),%rax
   2dde5:	49 8b 5e 10          	mov    0x10(%r14),%rbx
   2dde9:	49 83 c6 18          	add    $0x18,%r14
   2dded:	eb 46                	jmp    2de35 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x3e5>
   2ddef:	31 c9                	xor    %ecx,%ecx
   2ddf1:	48 89 0c 24          	mov    %rcx,(%rsp)
   2ddf5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2ddfa:	48 89 e0             	mov    %rsp,%rax
   2ddfd:	e9 4b 05 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2de02:	31 d2                	xor    %edx,%edx
   2de04:	48 89 14 24          	mov    %rdx,(%rsp)
   2de08:	48 89 e0             	mov    %rsp,%rax
   2de0b:	e9 3d 05 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2de10:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2de17:	00 00 
   2de19:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2de1e:	e9 2a 05 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2de23:	b8 04 00 00 00       	mov    $0x4,%eax
   2de28:	45 31 ff             	xor    %r15d,%r15d
   2de2b:	e9 65 04 00 00       	jmp    2e295 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x845>
   2de30:	45 31 f6             	xor    %r14d,%r14d
   2de33:	31 c0                	xor    %eax,%eax
   2de35:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2de39:	48 8b 51 10          	mov    0x10(%rcx),%rdx
   2de3d:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   2de41:	48 83 fa 04          	cmp    $0x4,%rdx
   2de45:	0f 87 50 05 00 00    	ja     2e39b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2de4b:	48 8b 49 08          	mov    0x8(%rcx),%rcx
   2de4f:	48 8d 35 7e b4 fd ff 	lea    -0x24b82(%rip),%rsi        # 92d4 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2de56:	48 63 14 96          	movslq (%rsi,%rdx,4),%rdx
   2de5a:	48 01 f2             	add    %rsi,%rdx
   2de5d:	ff e2                	jmp    *%rdx
   2de5f:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2de66:	61 6c 6c 
   2de69:	48 39 11             	cmp    %rdx,(%rcx)
   2de6c:	0f 85 29 05 00 00    	jne    2e39b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2de72:	48 85 c0             	test   %rax,%rax
   2de75:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2de7b:	4c 0f 45 f8          	cmovne %rax,%r15
   2de7f:	48 0f 44 d8          	cmove  %rax,%rbx
   2de83:	31 c0                	xor    %eax,%eax
   2de85:	48 85 db             	test   %rbx,%rbx
   2de88:	74 1a                	je     2dea4 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2de8a:	4d 85 f6             	test   %r14,%r14
   2de8d:	74 15                	je     2dea4 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2de8f:	48 83 fb 10          	cmp    $0x10,%rbx
   2de93:	72 0f                	jb     2dea4 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x454>
   2de95:	41 8b 46 18          	mov    0x18(%r14),%eax
   2de99:	85 c0                	test   %eax,%eax
   2de9b:	0f 85 26 05 00 00    	jne    2e3c7 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x977>
   2dea1:	4c 89 f0             	mov    %r14,%rax
   2dea4:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2deab:	00 
   2deac:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2deb1:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2deb6:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2debb:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2dec2:	00 00 
   2dec4:	45 31 ff             	xor    %r15d,%r15d
   2dec7:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2decc:	49 89 e6             	mov    %rsp,%r14
   2decf:	90                   	nop
   2ded0:	48 89 df             	mov    %rbx,%rdi
   2ded3:	4c 89 f6             	mov    %r14,%rsi
   2ded6:	e8 a5 89 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2dedb:	83 7c 24 30 01       	cmpl   $0x1,0x30(%rsp)
   2dee0:	0f 85 dd 02 00 00    	jne    2e1c3 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x773>
   2dee6:	48 63 44 24 34       	movslq 0x34(%rsp),%rax
   2deeb:	48 63 4c 24 38       	movslq 0x38(%rsp),%rcx
   2def0:	49 01 c7             	add    %rax,%r15
   2def3:	49 01 cf             	add    %rcx,%r15
   2def6:	eb d8                	jmp    2ded0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x480>
   2def8:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2defd:	c1 e0 03             	shl    $0x3,%eax
   2df00:	4c 89 e9             	mov    %r13,%rcx
   2df03:	48 29 c1             	sub    %rax,%rcx
   2df06:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2df0b:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   2df11:	4c 89 f7             	mov    %r14,%rdi
   2df14:	ff 15 56 3b 04 00    	call   *0x43b56(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2df1a:	48 85 c0             	test   %rax,%rax
   2df1d:	0f 84 97 fe ff ff    	je     2ddba <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2df23:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2df28:	48 89 cb             	mov    %rcx,%rbx
   2df2b:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2df31:	66 0f d6 00          	movq   %xmm0,(%rax)
   2df35:	4c 89 3c 24          	mov    %r15,(%rsp)
   2df39:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2df3e:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2df45:	00 00 
   2df47:	48 ff cb             	dec    %rbx
   2df4a:	0f 84 45 03 00 00    	je     2e295 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x845>
   2df50:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2df55:	45 21 e7             	and    %r12d,%r15d
   2df58:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2df5e:	49 89 e4             	mov    %rsp,%r12
   2df61:	eb 3c                	jmp    2df9f <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x54f>
   2df63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2df6a:	84 00 00 00 00 00 
   2df70:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2df75:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2df79:	44 21 f9             	and    %r15d,%ecx
   2df7c:	48 ff cb             	dec    %rbx
   2df7f:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2df85:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2df8b:	49 ff c6             	inc    %r14
   2df8e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2df93:	41 89 cf             	mov    %ecx,%r15d
   2df96:	48 85 db             	test   %rbx,%rbx
   2df99:	0f 84 e8 02 00 00    	je     2e287 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x837>
   2df9f:	66 45 85 ff          	test   %r15w,%r15w
   2dfa3:	75 24                	jne    2dfc9 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x579>
   2dfa5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2dfac:	00 00 00 00 
   2dfb0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2dfb5:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2dfb9:	48 83 c5 10          	add    $0x10,%rbp
   2dfbd:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2dfc2:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2dfc7:	74 e7                	je     2dfb0 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x560>
   2dfc9:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2dfce:	c1 e1 03             	shl    $0x3,%ecx
   2dfd1:	4c 89 ea             	mov    %r13,%rdx
   2dfd4:	48 29 ca             	sub    %rcx,%rdx
   2dfd7:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2dfdc:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   2dfe1:	4c 3b 34 24          	cmp    (%rsp),%r14
   2dfe5:	75 8e                	jne    2df75 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x525>
   2dfe7:	b9 04 00 00 00       	mov    $0x4,%ecx
   2dfec:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2dff2:	4c 89 e7             	mov    %r12,%rdi
   2dff5:	4c 89 f6             	mov    %r14,%rsi
   2dff8:	48 89 da             	mov    %rbx,%rdx
   2dffb:	e8 b0 ec ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e000:	e9 6b ff ff ff       	jmp    2df70 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x520>
   2e005:	31 d2                	xor    %edx,%edx
   2e007:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   2e00c:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   2e011:	48 85 c0             	test   %rax,%rax
   2e014:	0f 84 33 03 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e01a:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e021:	00 
   2e022:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e026:	48 01 c8             	add    %rcx,%rax
   2e029:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e02d:	0f 84 1a 03 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e033:	48 29 cf             	sub    %rcx,%rdi
   2e036:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e03a:	ff 15 40 3a 04 00    	call   *0x43a40(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e040:	e9 08 03 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e045:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2e04c:	66 69 72 
   2e04f:	48 33 11             	xor    (%rcx),%rdx
   2e052:	0f b7 49 08          	movzwl 0x8(%rcx),%ecx
   2e056:	48 81 f1 73 74 00 00 	xor    $0x7473,%rcx
   2e05d:	48 09 d1             	or     %rdx,%rcx
   2e060:	0f 85 35 03 00 00    	jne    2e39b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e066:	48 85 c0             	test   %rax,%rax
   2e069:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e06f:	4c 0f 45 f8          	cmovne %rax,%r15
   2e073:	48 0f 44 d8          	cmove  %rax,%rbx
   2e077:	31 c0                	xor    %eax,%eax
   2e079:	48 85 db             	test   %rbx,%rbx
   2e07c:	74 1a                	je     2e098 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e07e:	4d 85 f6             	test   %r14,%r14
   2e081:	74 15                	je     2e098 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e083:	48 83 fb 10          	cmp    $0x10,%rbx
   2e087:	72 0f                	jb     2e098 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x648>
   2e089:	41 8b 46 18          	mov    0x18(%r14),%eax
   2e08d:	85 c0                	test   %eax,%eax
   2e08f:	0f 85 1f 03 00 00    	jne    2e3b4 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x964>
   2e095:	4c 89 f0             	mov    %r14,%rax
   2e098:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e09f:	00 
   2e0a0:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e0a5:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e0aa:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e0af:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e0b6:	00 00 
   2e0b8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   2e0bd:	48 89 e6             	mov    %rsp,%rsi
   2e0c0:	e8 bb 87 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e0c5:	8b 44 24 38          	mov    0x38(%rsp),%eax
   2e0c9:	89 44 24 58          	mov    %eax,0x58(%rsp)
   2e0cd:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2e0d2:	48 89 44 24 50       	mov    %rax,0x50(%rsp)
   2e0d7:	48 8d 44 24 50       	lea    0x50(%rsp),%rax
   2e0dc:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e0e1:	0f 84 66 02 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e0e7:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e0ed:	0f 84 5a 02 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e0f3:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e0f8:	ff 15 82 39 04 00    	call   *0x43982(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e0fe:	e9 4a 02 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e103:	48 b8 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rax
   2e10a:	72 65 61 
   2e10d:	48 33 01             	xor    (%rcx),%rax
   2e110:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
   2e114:	48 83 f1 64          	xor    $0x64,%rcx
   2e118:	48 09 c1             	or     %rax,%rcx
   2e11b:	0f 85 7a 02 00 00    	jne    2e39b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e121:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   2e128:	00 00 
   2e12a:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e12e:	48 89 04 24          	mov    %rax,(%rsp)
   2e132:	48 89 e0             	mov    %rsp,%rax
   2e135:	48 8b 04 24          	mov    (%rsp),%rax
   2e139:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e13d:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2e143:	48 85 c9             	test   %rcx,%rcx
   2e146:	0f 84 75 01 00 00    	je     2e2c1 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e14c:	4c 8b 78 08          	mov    0x8(%rax),%r15
   2e150:	4d 8d 24 cf          	lea    (%r15,%rcx,8),%r12
   2e154:	48 8d 5c 24 50       	lea    0x50(%rsp),%rbx
   2e159:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e160:	41 8b 37             	mov    (%r15),%esi
   2e163:	41 8b 57 04          	mov    0x4(%r15),%edx
   2e167:	48 89 df             	mov    %rbx,%rdi
   2e16a:	e8 c1 6b 00 00       	call   34d30 <_RNvMso_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_3MapllE10push_entryCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e16f:	49 83 c7 08          	add    $0x8,%r15
   2e173:	4d 39 e7             	cmp    %r12,%r15
   2e176:	75 e8                	jne    2e160 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x710>
   2e178:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
   2e17d:	48 85 db             	test   %rbx,%rbx
   2e180:	0f 84 3b 01 00 00    	je     2e2c1 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e186:	4c 8b 73 08          	mov    0x8(%rbx),%r14
   2e18a:	4c 8b 7b 10          	mov    0x10(%rbx),%r15
   2e18e:	4d 85 ff             	test   %r15,%r15
   2e191:	0f 84 c8 01 00 00    	je     2e35f <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x90f>
   2e197:	49 83 ff 10          	cmp    $0x10,%r15
   2e19b:	0f 82 25 01 00 00    	jb     2e2c6 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x876>
   2e1a1:	4c 8d 63 18          	lea    0x18(%rbx),%r12
   2e1a5:	8b 43 30             	mov    0x30(%rbx),%eax
   2e1a8:	85 c0                	test   %eax,%eax
   2e1aa:	0f 84 19 01 00 00    	je     2e2c9 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x879>
   2e1b0:	4c 89 e7             	mov    %r12,%rdi
   2e1b3:	4c 89 f6             	mov    %r14,%rsi
   2e1b6:	4c 89 fa             	mov    %r15,%rdx
   2e1b9:	e8 1e b0 ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e1be:	e9 06 01 00 00       	jmp    2e2c9 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x879>
   2e1c3:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e1c8:	74 13                	je     2e1dd <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x78d>
   2e1ca:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e1d0:	74 0b                	je     2e1dd <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x78d>
   2e1d2:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e1d7:	ff 15 a3 38 04 00    	call   *0x438a3(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e1dd:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e1e1:	48 89 e0             	mov    %rsp,%rax
   2e1e4:	e9 64 01 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e1e9:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2e1f0:	63 6f 6c 
   2e1f3:	48 33 11             	xor    (%rcx),%rdx
   2e1f6:	8b 49 08             	mov    0x8(%rcx),%ecx
   2e1f9:	48 81 f1 6c 65 63 74 	xor    $0x7463656c,%rcx
   2e200:	48 09 d1             	or     %rdx,%rcx
   2e203:	0f 85 92 01 00 00    	jne    2e39b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x94b>
   2e209:	48 85 c0             	test   %rax,%rax
   2e20c:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e212:	4c 0f 45 f8          	cmovne %rax,%r15
   2e216:	48 0f 44 d8          	cmove  %rax,%rbx
   2e21a:	31 c0                	xor    %eax,%eax
   2e21c:	48 85 db             	test   %rbx,%rbx
   2e21f:	74 1a                	je     2e23b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e221:	4d 85 f6             	test   %r14,%r14
   2e224:	74 15                	je     2e23b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e226:	48 83 fb 10          	cmp    $0x10,%rbx
   2e22a:	72 0f                	jb     2e23b <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x7eb>
   2e22c:	41 8b 46 18          	mov    0x18(%r14),%eax
   2e230:	85 c0                	test   %eax,%eax
   2e232:	0f 85 a2 01 00 00    	jne    2e3da <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x98a>
   2e238:	4c 89 f0             	mov    %r14,%rax
   2e23b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e242:	00 
   2e243:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e248:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e24d:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e252:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e259:	00 00 
   2e25b:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e260:	48 89 e6             	mov    %rsp,%rsi
   2e263:	48 89 df             	mov    %rbx,%rdi
   2e266:	e8 65 6f 00 00       	call   351d0 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEE9from_iterCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e26b:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   2e271:	0f 84 d6 00 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e277:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2e27c:	ff 15 fe 37 04 00    	call   *0x437fe(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e282:	e9 c6 00 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e287:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e28b:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e290:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2e295:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e299:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e29e:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e2a3:	48 89 e0             	mov    %rsp,%rax
   2e2a6:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e2ab:	0f 84 9c 00 00 00    	je     2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e2b1:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e2b6:	ff 15 c4 37 04 00    	call   *0x437c4(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e2bc:	e9 8c 00 00 00       	jmp    2e34d <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8fd>
   2e2c1:	45 31 ff             	xor    %r15d,%r15d
   2e2c4:	31 db                	xor    %ebx,%ebx
   2e2c6:	45 31 e4             	xor    %r12d,%r12d
   2e2c9:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e2d0:	00 
   2e2d1:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   2e2d6:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   2e2db:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   2e2e0:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e2e7:	00 00 
   2e2e9:	45 31 e4             	xor    %r12d,%r12d
   2e2ec:	4c 8d 74 24 30       	lea    0x30(%rsp),%r14
   2e2f1:	49 89 e7             	mov    %rsp,%r15
   2e2f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e2fb:	00 00 00 00 00 
   2e300:	4c 89 f7             	mov    %r14,%rdi
   2e303:	4c 89 fe             	mov    %r15,%rsi
   2e306:	e8 75 85 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e30b:	83 7c 24 30 01       	cmpl   $0x1,0x30(%rsp)
   2e310:	75 12                	jne    2e324 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8d4>
   2e312:	48 63 44 24 34       	movslq 0x34(%rsp),%rax
   2e317:	48 63 4c 24 38       	movslq 0x38(%rsp),%rcx
   2e31c:	49 01 c4             	add    %rax,%r12
   2e31f:	49 01 cc             	add    %rcx,%r12
   2e322:	eb dc                	jmp    2e300 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e324:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e329:	74 13                	je     2e33e <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8ee>
   2e32b:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e331:	74 0b                	je     2e33e <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x8ee>
   2e333:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e338:	ff 15 42 37 04 00    	call   *0x43742(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e33e:	4c 89 24 24          	mov    %r12,(%rsp)
   2e342:	48 89 e0             	mov    %rsp,%rax
   2e345:	48 89 df             	mov    %rbx,%rdi
   2e348:	e8 03 bd ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e34d:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
   2e354:	5b                   	pop    %rbx
   2e355:	41 5c                	pop    %r12
   2e357:	41 5d                	pop    %r13
   2e359:	41 5e                	pop    %r14
   2e35b:	41 5f                	pop    %r15
   2e35d:	5d                   	pop    %rbp
   2e35e:	c3                   	ret
   2e35f:	45 31 ff             	xor    %r15d,%r15d
   2e362:	e9 5f ff ff ff       	jmp    2e2c6 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x876>
   2e367:	48 8d 3d b6 af fd ff 	lea    -0x2504a(%rip),%rdi        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e36e:	48 8d 15 83 1c 04 00 	lea    0x41c83(%rip),%rdx        # 6fff8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6a8>
   2e375:	be 28 00 00 00       	mov    $0x28,%esi
   2e37a:	ff 15 c0 38 04 00    	call   *0x438c0(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   2e380:	49 89 fe             	mov    %rdi,%r14
   2e383:	ff 15 07 3b 04 00    	call   *0x43b07(%rip)        # 71e90 <_DYNAMIC+0x608>
   2e389:	4c 89 f7             	mov    %r14,%rdi
   2e38c:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e391:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e396:	e9 5b f8 ff ff       	jmp    2dbf6 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e39b:	48 8d 3d 82 af fd ff 	lea    -0x2507e(%rip),%rdi        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e3a2:	48 8d 15 67 1c 04 00 	lea    0x41c67(%rip),%rdx        # 70010 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6c0>
   2e3a9:	be 28 00 00 00       	mov    $0x28,%esi
   2e3ae:	ff 15 8c 38 04 00    	call   *0x4388c(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   2e3b4:	4c 89 f7             	mov    %r14,%rdi
   2e3b7:	4c 89 fe             	mov    %r15,%rsi
   2e3ba:	48 89 da             	mov    %rbx,%rdx
   2e3bd:	e8 1a ae ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e3c2:	e9 ce fc ff ff       	jmp    2e095 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x645>
   2e3c7:	4c 89 f7             	mov    %r14,%rdi
   2e3ca:	4c 89 fe             	mov    %r15,%rsi
   2e3cd:	48 89 da             	mov    %rbx,%rdx
   2e3d0:	e8 07 ae ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e3d5:	e9 c7 fa ff ff       	jmp    2dea1 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x451>
   2e3da:	4c 89 f7             	mov    %r14,%rdi
   2e3dd:	4c 89 fe             	mov    %r15,%rsi
   2e3e0:	48 89 da             	mov    %rbx,%rdx
   2e3e3:	e8 f4 ad ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e3e8:	e9 4b fe ff ff       	jmp    2e238 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x7e8>
   2e3ed:	49 89 c6             	mov    %rax,%r14
   2e3f0:	eb 3a                	jmp    2e42c <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e3f2:	eb 48                	jmp    2e43c <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x9ec>
   2e3f4:	49 89 c6             	mov    %rax,%r14
   2e3f7:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e3fc:	74 5b                	je     2e459 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e3fe:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e403:	eb 4e                	jmp    2e453 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa03>
   2e405:	49 89 c6             	mov    %rax,%r14
   2e408:	48 8b 5c 24 50       	mov    0x50(%rsp),%rbx
   2e40d:	eb 1d                	jmp    2e42c <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e40f:	49 89 c6             	mov    %rax,%r14
   2e412:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e417:	74 13                	je     2e42c <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e419:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e41f:	74 0b                	je     2e42c <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0x9dc>
   2e421:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e426:	ff 15 54 36 04 00    	call   *0x43654(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e42c:	48 89 df             	mov    %rbx,%rdi
   2e42f:	e8 1c bc ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e434:	eb 23                	jmp    2e459 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e436:	ff 15 ec 36 04 00    	call   *0x436ec(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   2e43c:	49 89 c6             	mov    %rax,%r14
   2e43f:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e444:	74 13                	je     2e459 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e446:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e44c:	74 0b                	je     2e459 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_+0xa09>
   2e44e:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e453:	ff 15 27 36 04 00    	call   *0x43627(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e459:	4c 89 f7             	mov    %r14,%rdi
   2e45c:	e8 4f fe 03 00       	call   6e2b0 <_Unwind_Resume@plt>
   2e461:	49 89 c6             	mov    %rax,%r14
   2e464:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e468:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e46d:	e8 de bd ff ff       	call   2a250 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e472:	4c 89 f7             	mov    %r14,%rdi
   2e475:	e8 36 fe 03 00       	call   6e2b0 <_Unwind_Resume@plt>
