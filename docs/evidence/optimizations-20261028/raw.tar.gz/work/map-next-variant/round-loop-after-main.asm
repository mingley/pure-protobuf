
work/all-benchmarks/measurement/round-loop-after/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002e4b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main>:
   2e4b0:	55                   	push   %rbp
   2e4b1:	41 57                	push   %r15
   2e4b3:	41 56                	push   %r14
   2e4b5:	41 55                	push   %r13
   2e4b7:	41 54                	push   %r12
   2e4b9:	53                   	push   %rbx
   2e4ba:	48 81 ec b8 02 00 00 	sub    $0x2b8,%rsp
   2e4c1:	48 89 e7             	mov    %rsp,%rdi
   2e4c4:	ff 15 ce 39 04 00    	call   *0x439ce(%rip)        # 71e98 <_DYNAMIC+0x610>
   2e4ca:	4c 8b 6c 24 08       	mov    0x8(%rsp),%r13
   2e4cf:	4c 8b 7c 24 18       	mov    0x18(%rsp),%r15
   2e4d4:	4d 39 fd             	cmp    %r15,%r13
   2e4d7:	0f 84 80 49 00 00    	je     32e5d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x49ad>
   2e4dd:	49 8d 6d 18          	lea    0x18(%r13),%rbp
   2e4e1:	48 89 6c 24 08       	mov    %rbp,0x8(%rsp)
   2e4e6:	4d 8b 75 00          	mov    0x0(%r13),%r14
   2e4ea:	49 83 fe ff          	cmp    $0xffffffffffffffff,%r14
   2e4ee:	0f 84 66 49 00 00    	je     32e5a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x49aa>
   2e4f4:	49 8b 75 08          	mov    0x8(%r13),%rsi
   2e4f8:	49 8b 5d 10          	mov    0x10(%r13),%rbx
   2e4fc:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2e503:	00 
   2e504:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
   2e509:	48 89 da             	mov    %rbx,%rdx
   2e50c:	ff 15 76 36 04 00    	call   *0x43676(%rip)        # 71b88 <_DYNAMIC+0x300>
   2e512:	83 bc 24 30 01 00 00 	cmpl   $0x1,0x130(%rsp)
   2e519:	01 
   2e51a:	0f 84 c0 49 00 00    	je     32ee0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a30>
   2e520:	48 ba f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rdx
   2e527:	ff ff 7f 
   2e52a:	4c 89 bc 24 d0 00 00 	mov    %r15,0xd0(%rsp)
   2e531:	00 
   2e532:	4c 89 f8             	mov    %r15,%rax
   2e535:	48 29 e8             	sub    %rbp,%rax
   2e538:	48 89 c1             	mov    %rax,%rcx
   2e53b:	48 c1 e9 03          	shr    $0x3,%rcx
   2e53f:	48 be ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rsi
   2e546:	aa aa aa 
   2e549:	48 0f af ce          	imul   %rsi,%rcx
   2e54d:	48 83 f9 04          	cmp    $0x4,%rcx
   2e551:	41 bf 03 00 00 00    	mov    $0x3,%r15d
   2e557:	4c 0f 43 f9          	cmovae %rcx,%r15
   2e55b:	48 8d 4a ef          	lea    -0x11(%rdx),%rcx
   2e55f:	48 39 c8             	cmp    %rcx,%rax
   2e562:	76 18                	jbe    2e57c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xcc>
   2e564:	31 ff                	xor    %edi,%edi
   2e566:	4c 89 e6             	mov    %r12,%rsi
   2e569:	4c 8b bc 24 d0 00 00 	mov    0xd0(%rsp),%r15
   2e570:	00 
   2e571:	ff 15 41 35 04 00    	call   *0x43541(%rip)        # 71ab8 <_DYNAMIC+0x230>
   2e577:	e9 cd 4b 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   2e57c:	4a 8d 04 fd 08 00 00 	lea    0x8(,%r15,8),%rax
   2e583:	00 
   2e584:	4c 8d 24 40          	lea    (%rax,%rax,2),%r12
   2e588:	4d 85 e4             	test   %r12,%r12
   2e58b:	74 17                	je     2e5a4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf4>
   2e58d:	4c 89 e7             	mov    %r12,%rdi
   2e590:	ff 15 da 34 04 00    	call   *0x434da(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2e596:	48 85 c0             	test   %rax,%rax
   2e599:	0f 84 fc 49 00 00    	je     32f9b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4aeb>
   2e59f:	49 ff c7             	inc    %r15
   2e5a2:	eb 08                	jmp    2e5ac <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xfc>
   2e5a4:	b8 08 00 00 00       	mov    $0x8,%eax
   2e5a9:	45 31 ff             	xor    %r15d,%r15d
   2e5ac:	4c 89 30             	mov    %r14,(%rax)
   2e5af:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   2e5b4:	48 89 48 08          	mov    %rcx,0x8(%rax)
   2e5b8:	48 89 58 10          	mov    %rbx,0x10(%rax)
   2e5bc:	4c 89 bc 24 90 01 00 	mov    %r15,0x190(%rsp)
   2e5c3:	00 
   2e5c4:	48 89 84 24 98 01 00 	mov    %rax,0x198(%rsp)
   2e5cb:	00 
   2e5cc:	48 c7 84 24 a0 01 00 	movq   $0x1,0x1a0(%rsp)
   2e5d3:	00 01 00 00 00 
   2e5d8:	66 0f 10 04 24       	movupd (%rsp),%xmm0
   2e5dd:	f3 0f 6f 4c 24 10    	movdqu 0x10(%rsp),%xmm1
   2e5e3:	66 0f 7f 8c 24 40 01 	movdqa %xmm1,0x140(%rsp)
   2e5ea:	00 00 
   2e5ec:	66 0f 29 84 24 30 01 	movapd %xmm0,0x130(%rsp)
   2e5f3:	00 00 
   2e5f5:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
   2e5fc:	00 
   2e5fd:	48 8b ac 24 38 01 00 	mov    0x138(%rsp),%rbp
   2e604:	00 
   2e605:	4c 39 e5             	cmp    %r12,%rbp
   2e608:	0f 84 04 01 00 00    	je     2e712 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x262>
   2e60e:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   2e615:	00 
   2e616:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e61c:	41 bd 28 00 00 00    	mov    $0x28,%r13d
   2e622:	eb 4f                	jmp    2e673 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c3>
   2e624:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e62b:	00 00 00 00 00 
   2e630:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   2e637:	00 
   2e638:	4e 89 7c 28 f0       	mov    %r15,-0x10(%rax,%r13,1)
   2e63d:	48 8b 4c 24 68       	mov    0x68(%rsp),%rcx
   2e642:	4a 89 4c 28 f8       	mov    %rcx,-0x8(%rax,%r13,1)
   2e647:	4a 89 2c 28          	mov    %rbp,(%rax,%r13,1)
   2e64b:	49 ff c6             	inc    %r14
   2e64e:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
   2e655:	00 
   2e656:	48 8b ac 24 38 01 00 	mov    0x138(%rsp),%rbp
   2e65d:	00 
   2e65e:	4c 8b a4 24 48 01 00 	mov    0x148(%rsp),%r12
   2e665:	00 
   2e666:	49 83 c5 18          	add    $0x18,%r13
   2e66a:	4c 39 e5             	cmp    %r12,%rbp
   2e66d:	0f 84 aa 00 00 00    	je     2e71d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26d>
   2e673:	48 8d 5d 18          	lea    0x18(%rbp),%rbx
   2e677:	48 89 9c 24 38 01 00 	mov    %rbx,0x138(%rsp)
   2e67e:	00 
   2e67f:	4c 8b 7d 00          	mov    0x0(%rbp),%r15
   2e683:	49 83 ff ff          	cmp    $0xffffffffffffffff,%r15
   2e687:	0f 84 8d 00 00 00    	je     2e71a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26a>
   2e68d:	48 8b 75 08          	mov    0x8(%rbp),%rsi
   2e691:	48 8b 6d 10          	mov    0x10(%rbp),%rbp
   2e695:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   2e69c:	00 
   2e69d:	48 89 74 24 68       	mov    %rsi,0x68(%rsp)
   2e6a2:	48 89 ea             	mov    %rbp,%rdx
   2e6a5:	ff 15 dd 34 04 00    	call   *0x434dd(%rip)        # 71b88 <_DYNAMIC+0x300>
   2e6ab:	83 bc 24 a0 00 00 00 	cmpl   $0x1,0xa0(%rsp)
   2e6b2:	01 
   2e6b3:	0f 84 d6 46 00 00    	je     32d8f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48df>
   2e6b9:	4c 3b b4 24 90 01 00 	cmp    0x190(%rsp),%r14
   2e6c0:	00 
   2e6c1:	0f 85 69 ff ff ff    	jne    2e630 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x180>
   2e6c7:	49 29 dc             	sub    %rbx,%r12
   2e6ca:	49 c1 ec 03          	shr    $0x3,%r12
   2e6ce:	48 b8 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rax
   2e6d5:	aa aa aa 
   2e6d8:	4c 0f af e0          	imul   %rax,%r12
   2e6dc:	49 ff c4             	inc    %r12
   2e6df:	b9 08 00 00 00       	mov    $0x8,%ecx
   2e6e4:	41 b8 18 00 00 00    	mov    $0x18,%r8d
   2e6ea:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
   2e6f1:	00 
   2e6f2:	4c 89 f6             	mov    %r14,%rsi
   2e6f5:	4c 89 e2             	mov    %r12,%rdx
   2e6f8:	e8 b3 e5 ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2e6fd:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   2e704:	00 
   2e705:	48 89 84 24 d0 00 00 	mov    %rax,0xd0(%rsp)
   2e70c:	00 
   2e70d:	e9 1e ff ff ff       	jmp    2e630 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x180>
   2e712:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e718:	eb 03                	jmp    2e71d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26d>
   2e71a:	48 89 dd             	mov    %rbx,%rbp
   2e71d:	4c 89 e0             	mov    %r12,%rax
   2e720:	48 29 e8             	sub    %rbp,%rax
   2e723:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   2e72a:	aa aa aa 
   2e72d:	48 f7 e1             	mul    %rcx
   2e730:	49 39 ec             	cmp    %rbp,%r12
   2e733:	4c 8d a4 24 30 01 00 	lea    0x130(%rsp),%r12
   2e73a:	00 
   2e73b:	74 3c                	je     2e779 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c9>
   2e73d:	48 89 d3             	mov    %rdx,%rbx
   2e740:	48 c1 eb 04          	shr    $0x4,%rbx
   2e744:	48 83 c5 08          	add    $0x8,%rbp
   2e748:	4c 8b 3d 31 33 04 00 	mov    0x43331(%rip),%r15        # 71a80 <free@GLIBC_2.2.5>
   2e74f:	eb 18                	jmp    2e769 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b9>
   2e751:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e758:	0f 1f 84 00 00 00 00 
   2e75f:	00 
   2e760:	48 83 c5 18          	add    $0x18,%rbp
   2e764:	48 ff cb             	dec    %rbx
   2e767:	74 10                	je     2e779 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c9>
   2e769:	48 83 7d f8 00       	cmpq   $0x0,-0x8(%rbp)
   2e76e:	74 f0                	je     2e760 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b0>
   2e770:	48 8b 7d 00          	mov    0x0(%rbp),%rdi
   2e774:	41 ff d7             	call   *%r15
   2e777:	eb e7                	jmp    2e760 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b0>
   2e779:	48 83 bc 24 40 01 00 	cmpq   $0x0,0x140(%rsp)
   2e780:	00 00 
   2e782:	74 0e                	je     2e792 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2e2>
   2e784:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   2e78b:	00 
   2e78c:	ff 15 ee 32 04 00    	call   *0x432ee(%rip)        # 71a80 <free@GLIBC_2.2.5>
   2e792:	48 8b 84 24 90 01 00 	mov    0x190(%rsp),%rax
   2e799:	00 
   2e79a:	48 89 84 24 40 02 00 	mov    %rax,0x240(%rsp)
   2e7a1:	00 
   2e7a2:	48 8b 84 24 98 01 00 	mov    0x198(%rsp),%rax
   2e7a9:	00 
   2e7aa:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   2e7b1:	00 
   2e7b2:	49 83 fe 06          	cmp    $0x6,%r14
   2e7b6:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2e7bb:	0f 85 ef 46 00 00    	jne    32eb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a00>
   2e7c1:	48 8d 48 30          	lea    0x30(%rax),%rcx
   2e7c5:	48 89 8c 24 78 02 00 	mov    %rcx,0x278(%rsp)
   2e7cc:	00 
   2e7cd:	48 89 8c 24 68 02 00 	mov    %rcx,0x268(%rsp)
   2e7d4:	00 
   2e7d5:	48 8b 48 68          	mov    0x68(%rax),%rcx
   2e7d9:	48 8b 70 70          	mov    0x70(%rax),%rsi
   2e7dd:	48 83 fe 01          	cmp    $0x1,%rsi
   2e7e1:	74 0e                	je     2e7f1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x341>
   2e7e3:	48 85 f6             	test   %rsi,%rsi
   2e7e6:	0f 84 ce 47 00 00    	je     32fba <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b0a>
   2e7ec:	0f b6 11             	movzbl (%rcx),%edx
   2e7ef:	eb 17                	jmp    2e808 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x358>
   2e7f1:	0f b6 11             	movzbl (%rcx),%edx
   2e7f4:	b0 01                	mov    $0x1,%al
   2e7f6:	83 fa 2b             	cmp    $0x2b,%edx
   2e7f9:	0f 84 14 42 00 00    	je     32a13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4563>
   2e7ff:	83 fa 2d             	cmp    $0x2d,%edx
   2e802:	0f 84 0b 42 00 00    	je     32a13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4563>
   2e808:	31 c0                	xor    %eax,%eax
   2e80a:	80 fa 2b             	cmp    $0x2b,%dl
   2e80d:	0f 94 c0             	sete   %al
   2e810:	48 89 f2             	mov    %rsi,%rdx
   2e813:	48 29 c2             	sub    %rax,%rdx
   2e816:	48 01 c1             	add    %rax,%rcx
   2e819:	48 f7 d8             	neg    %rax
   2e81c:	48 83 fa 11          	cmp    $0x11,%rdx
   2e820:	73 4f                	jae    2e871 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c1>
   2e822:	48 85 d2             	test   %rdx,%rdx
   2e825:	0f 84 a3 00 00 00    	je     2e8ce <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41e>
   2e82b:	48 01 c6             	add    %rax,%rsi
   2e82e:	48 f7 de             	neg    %rsi
   2e831:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2e838:	00 00 
   2e83a:	31 c0                	xor    %eax,%eax
   2e83c:	0f 1f 40 00          	nopl   0x0(%rax)
   2e840:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2e844:	83 c2 d0             	add    $0xffffffd0,%edx
   2e847:	83 fa 09             	cmp    $0x9,%edx
   2e84a:	0f 87 31 45 00 00    	ja     32d81 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48d1>
   2e850:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   2e855:	48 8d 3c bf          	lea    (%rdi,%rdi,4),%rdi
   2e859:	89 d2                	mov    %edx,%edx
   2e85b:	48 8d 14 7a          	lea    (%rdx,%rdi,2),%rdx
   2e85f:	48 89 54 24 68       	mov    %rdx,0x68(%rsp)
   2e864:	48 ff c0             	inc    %rax
   2e867:	48 89 f2             	mov    %rsi,%rdx
   2e86a:	48 01 c2             	add    %rax,%rdx
   2e86d:	75 d1                	jne    2e840 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x390>
   2e86f:	eb 66                	jmp    2e8d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x427>
   2e871:	48 01 c6             	add    %rax,%rsi
   2e874:	48 f7 de             	neg    %rsi
   2e877:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2e87e:	00 00 
   2e880:	bf 0a 00 00 00       	mov    $0xa,%edi
   2e885:	45 31 c0             	xor    %r8d,%r8d
   2e888:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2e88f:	00 
   2e890:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2e895:	48 f7 e7             	mul    %rdi
   2e898:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2e89d:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2e8a2:	0f 80 5d 41 00 00    	jo     32a05 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4555>
   2e8a8:	83 c2 d0             	add    $0xffffffd0,%edx
   2e8ab:	83 fa 0a             	cmp    $0xa,%edx
   2e8ae:	0f 83 cd 44 00 00    	jae    32d81 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48d1>
   2e8b4:	89 d0                	mov    %edx,%eax
   2e8b6:	48 01 44 24 68       	add    %rax,0x68(%rsp)
   2e8bb:	0f 82 50 41 00 00    	jb     32a11 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4561>
   2e8c1:	49 ff c0             	inc    %r8
   2e8c4:	48 89 f0             	mov    %rsi,%rax
   2e8c7:	4c 01 c0             	add    %r8,%rax
   2e8ca:	75 c4                	jne    2e890 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e0>
   2e8cc:	eb 09                	jmp    2e8d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x427>
   2e8ce:	48 c7 44 24 68 00 00 	movq   $0x0,0x68(%rsp)
   2e8d5:	00 00 
   2e8d7:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2e8dc:	48 8b b0 80 00 00 00 	mov    0x80(%rax),%rsi
   2e8e3:	4c 8b 80 88 00 00 00 	mov    0x88(%rax),%r8
   2e8ea:	49 83 f8 01          	cmp    $0x1,%r8
   2e8ee:	74 0e                	je     2e8fe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44e>
   2e8f0:	4d 85 c0             	test   %r8,%r8
   2e8f3:	0f 84 db 46 00 00    	je     32fd4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b24>
   2e8f9:	0f b6 0e             	movzbl (%rsi),%ecx
   2e8fc:	eb 17                	jmp    2e915 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x465>
   2e8fe:	0f b6 0e             	movzbl (%rsi),%ecx
   2e901:	b0 01                	mov    $0x1,%al
   2e903:	83 f9 2b             	cmp    $0x2b,%ecx
   2e906:	0f 84 25 41 00 00    	je     32a31 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4581>
   2e90c:	83 f9 2d             	cmp    $0x2d,%ecx
   2e90f:	0f 84 1c 41 00 00    	je     32a31 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4581>
   2e915:	31 c0                	xor    %eax,%eax
   2e917:	80 f9 2b             	cmp    $0x2b,%cl
   2e91a:	0f 94 c0             	sete   %al
   2e91d:	4c 89 c2             	mov    %r8,%rdx
   2e920:	48 29 c2             	sub    %rax,%rdx
   2e923:	48 01 c6             	add    %rax,%rsi
   2e926:	48 f7 d8             	neg    %rax
   2e929:	48 8d 0d 58 17 04 00 	lea    0x41758(%rip),%rcx        # 70088 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x738>
   2e930:	48 8d 3d 15 aa fd ff 	lea    -0x255eb(%rip),%rdi        # 934c <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xc5>
   2e937:	48 83 fa 11          	cmp    $0x11,%rdx
   2e93b:	73 4a                	jae    2e987 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d7>
   2e93d:	48 85 d2             	test   %rdx,%rdx
   2e940:	0f 84 7b 46 00 00    	je     32fc1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b11>
   2e946:	49 01 c0             	add    %rax,%r8
   2e949:	49 f7 d8             	neg    %r8
   2e94c:	45 31 db             	xor    %r11d,%r11d
   2e94f:	31 c0                	xor    %eax,%eax
   2e951:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e958:	0f 1f 84 00 00 00 00 
   2e95f:	00 
   2e960:	0f b6 14 06          	movzbl (%rsi,%rax,1),%edx
   2e964:	83 c2 d0             	add    $0xffffffd0,%edx
   2e967:	83 fa 09             	cmp    $0x9,%edx
   2e96a:	0f 87 0a 44 00 00    	ja     32d7a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48ca>
   2e970:	4f 8d 0c 9b          	lea    (%r11,%r11,4),%r9
   2e974:	89 d2                	mov    %edx,%edx
   2e976:	4e 8d 1c 4a          	lea    (%rdx,%r9,2),%r11
   2e97a:	48 ff c0             	inc    %rax
   2e97d:	4c 89 c2             	mov    %r8,%rdx
   2e980:	48 01 c2             	add    %rax,%rdx
   2e983:	75 db                	jne    2e960 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b0>
   2e985:	eb 4f                	jmp    2e9d6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x526>
   2e987:	49 01 c0             	add    %rax,%r8
   2e98a:	49 f7 d8             	neg    %r8
   2e98d:	45 31 db             	xor    %r11d,%r11d
   2e990:	41 b9 0a 00 00 00    	mov    $0xa,%r9d
   2e996:	45 31 d2             	xor    %r10d,%r10d
   2e999:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e9a0:	4c 89 d8             	mov    %r11,%rax
   2e9a3:	49 f7 e1             	mul    %r9
   2e9a6:	42 0f b6 14 16       	movzbl (%rsi,%r10,1),%edx
   2e9ab:	0f 80 72 40 00 00    	jo     32a23 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4573>
   2e9b1:	83 c2 d0             	add    $0xffffffd0,%edx
   2e9b4:	83 fa 0a             	cmp    $0xa,%edx
   2e9b7:	0f 83 bd 43 00 00    	jae    32d7a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48ca>
   2e9bd:	49 89 c3             	mov    %rax,%r11
   2e9c0:	89 d0                	mov    %edx,%eax
   2e9c2:	49 01 c3             	add    %rax,%r11
   2e9c5:	0f 82 64 40 00 00    	jb     32a2f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x457f>
   2e9cb:	49 ff c2             	inc    %r10
   2e9ce:	4c 89 c0             	mov    %r8,%rax
   2e9d1:	4c 01 d0             	add    %r10,%rax
   2e9d4:	75 ca                	jne    2e9a0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f0>
   2e9d6:	4d 85 db             	test   %r11,%r11
   2e9d9:	0f 84 e2 45 00 00    	je     32fc1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b11>
   2e9df:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   2e9e4:	49 8b 40 40          	mov    0x40(%r8),%rax
   2e9e8:	48 8d 0d b1 16 04 00 	lea    0x416b1(%rip),%rcx        # 700a0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   2e9ef:	be 39 00 00 00       	mov    $0x39,%esi
   2e9f4:	48 8d 3d 6e a9 fd ff 	lea    -0x25692(%rip),%rdi        # 9369 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0xe2>
   2e9fb:	48 83 f8 05          	cmp    $0x5,%rax
   2e9ff:	75 1b                	jne    2ea1c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x56c>
   2ea01:	49 8b 40 38          	mov    0x38(%r8),%rax
   2ea05:	ba 70 72 6f 73       	mov    $0x736f7270,%edx
   2ea0a:	33 10                	xor    (%rax),%edx
   2ea0c:	0f b6 40 04          	movzbl 0x4(%rax),%eax
   2ea10:	83 f0 74             	xor    $0x74,%eax
   2ea13:	09 d0                	or     %edx,%eax
   2ea15:	74 24                	je     2ea3b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x58b>
   2ea17:	e9 aa 45 00 00       	jmp    32fc6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b16>
   2ea1c:	48 83 f8 04          	cmp    $0x4,%rax
   2ea20:	0f 85 a0 45 00 00    	jne    32fc6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b16>
   2ea26:	4c 8b 44 24 58       	mov    0x58(%rsp),%r8
   2ea2b:	49 8b 40 38          	mov    0x38(%r8),%rax
   2ea2f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2ea35:	0f 85 8b 45 00 00    	jne    32fc6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b16>
   2ea3b:	49 8b 50 58          	mov    0x58(%r8),%rdx
   2ea3f:	48 8d 0d 72 16 04 00 	lea    0x41672(%rip),%rcx        # 700b8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x768>
   2ea46:	be 5b 00 00 00       	mov    $0x5b,%esi
   2ea4b:	48 8d 3d 50 a9 fd ff 	lea    -0x256b0(%rip),%rdi        # 93a2 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x11b>
   2ea52:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   2ea56:	48 83 fa 04          	cmp    $0x4,%rdx
   2ea5a:	0f 87 66 45 00 00    	ja     32fc6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b16>
   2ea60:	49 8b 40 50          	mov    0x50(%r8),%rax
   2ea64:	4c 8d 05 7d a8 fd ff 	lea    -0x25783(%rip),%r8        # 92e8 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x61>
   2ea6b:	49 63 14 90          	movslq (%r8,%rdx,4),%rdx
   2ea6f:	4c 01 c2             	add    %r8,%rdx
   2ea72:	ff e2                	jmp    *%rdx
   2ea74:	48 ba 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rdx
   2ea7b:	61 6c 6c 
   2ea7e:	48 39 10             	cmp    %rdx,(%rax)
   2ea81:	eb 49                	jmp    2eacc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x61c>
   2ea83:	48 ba 69 74 65 72 5f 	movabs $0x7269665f72657469,%rdx
   2ea8a:	66 69 72 
   2ea8d:	48 33 10             	xor    (%rax),%rdx
   2ea90:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2ea94:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2ea9a:	eb 2d                	jmp    2eac9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x619>
   2ea9c:	48 ba 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rdx
   2eaa3:	63 6f 6c 
   2eaa6:	48 33 10             	xor    (%rax),%rdx
   2eaa9:	8b 40 08             	mov    0x8(%rax),%eax
   2eaac:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2eab2:	eb 15                	jmp    2eac9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x619>
   2eab4:	48 ba 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rdx
   2eabb:	72 65 61 
   2eabe:	48 33 10             	xor    (%rax),%rdx
   2eac1:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2eac5:	48 83 f0 64          	xor    $0x64,%rax
   2eac9:	48 09 d0             	or     %rdx,%rax
   2eacc:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2ead1:	0f 85 ef 44 00 00    	jne    32fc6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b16>
   2ead7:	4c 89 9c 24 90 02 00 	mov    %r11,0x290(%rsp)
   2eade:	00 
   2eadf:	48 8d 48 48          	lea    0x48(%rax),%rcx
   2eae3:	48 89 8c 24 58 02 00 	mov    %rcx,0x258(%rsp)
   2eaea:	00 
   2eaeb:	49 bd 80 80 80 80 80 	movabs $0x8080808080808080,%r13
   2eaf2:	80 80 80 
   2eaf5:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2eafc:	5f 5f 5f 
   2eaff:	49 bc 00 01 01 01 01 	movabs $0x101010101010100,%r12
   2eb06:	01 01 01 
   2eb09:	48 8b 50 20          	mov    0x20(%rax),%rdx
   2eb0d:	48 8b 70 28          	mov    0x28(%rax),%rsi
   2eb11:	48 8d 42 08          	lea    0x8(%rdx),%rax
   2eb15:	48 89 84 24 78 01 00 	mov    %rax,0x178(%rsp)
   2eb1c:	00 
   2eb1d:	31 ed                	xor    %ebp,%ebp
   2eb1f:	31 c0                	xor    %eax,%eax
   2eb21:	48 89 94 24 d0 00 00 	mov    %rdx,0xd0(%rsp)
   2eb28:	00 
   2eb29:	48 89 74 24 28       	mov    %rsi,0x28(%rsp)
   2eb2e:	eb 1e                	jmp    2eb4e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x69e>
   2eb30:	4c 89 f8             	mov    %r15,%rax
   2eb33:	49 39 f7             	cmp    %rsi,%r15
   2eb36:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2eb3d:	5f 5f 5f 
   2eb40:	48 8b 94 24 d0 00 00 	mov    0xd0(%rsp),%rdx
   2eb47:	00 
   2eb48:	0f 87 5c 3e 00 00    	ja     329aa <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44fa>
   2eb4e:	48 89 f1             	mov    %rsi,%rcx
   2eb51:	48 29 c1             	sub    %rax,%rcx
   2eb54:	48 01 c2             	add    %rax,%rdx
   2eb57:	48 83 f9 0f          	cmp    $0xf,%rcx
   2eb5b:	77 33                	ja     2eb90 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6e0>
   2eb5d:	b3 01                	mov    $0x1,%bl
   2eb5f:	48 39 c6             	cmp    %rax,%rsi
   2eb62:	0f 84 3d 01 00 00    	je     2eca5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7f5>
   2eb68:	45 31 f6             	xor    %r14d,%r14d
   2eb6b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   2eb70:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2eb75:	0f 84 e5 00 00 00    	je     2ec60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7b0>
   2eb7b:	49 ff c6             	inc    %r14
   2eb7e:	4c 39 f1             	cmp    %r14,%rcx
   2eb81:	75 ed                	jne    2eb70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6c0>
   2eb83:	e9 1d 01 00 00       	jmp    2eca5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7f5>
   2eb88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2eb8f:	00 
   2eb90:	48 8d 72 07          	lea    0x7(%rdx),%rsi
   2eb94:	48 83 e6 f8          	and    $0xfffffffffffffff8,%rsi
   2eb98:	48 29 d6             	sub    %rdx,%rsi
   2eb9b:	75 53                	jne    2ebf0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x740>
   2eb9d:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2eba1:	31 f6                	xor    %esi,%esi
   2eba3:	4c 8b 84 24 78 01 00 	mov    0x178(%rsp),%r8
   2ebaa:	00 
   2ebab:	49 01 c0             	add    %rax,%r8
   2ebae:	66 90                	xchg   %ax,%ax
   2ebb0:	4d 8b 4c 30 f8       	mov    -0x8(%r8,%rsi,1),%r9
   2ebb5:	4d 89 ca             	mov    %r9,%r10
   2ebb8:	49 31 da             	xor    %rbx,%r10
   2ebbb:	4d 89 e3             	mov    %r12,%r11
   2ebbe:	4d 29 d3             	sub    %r10,%r11
   2ebc1:	4d 09 cb             	or     %r9,%r11
   2ebc4:	4d 8b 0c 30          	mov    (%r8,%rsi,1),%r9
   2ebc8:	49 31 d9             	xor    %rbx,%r9
   2ebcb:	4d 89 e2             	mov    %r12,%r10
   2ebce:	4d 29 ca             	sub    %r9,%r10
   2ebd1:	4d 09 ca             	or     %r9,%r10
   2ebd4:	4d 21 eb             	and    %r13,%r11
   2ebd7:	4d 21 d3             	and    %r10,%r11
   2ebda:	4d 39 eb             	cmp    %r13,%r11
   2ebdd:	75 51                	jne    2ec30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x780>
   2ebdf:	48 83 c6 10          	add    $0x10,%rsi
   2ebe3:	48 39 fe             	cmp    %rdi,%rsi
   2ebe6:	76 c8                	jbe    2ebb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x700>
   2ebe8:	eb 46                	jmp    2ec30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x780>
   2ebea:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2ebf0:	45 31 f6             	xor    %r14d,%r14d
   2ebf3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ebfa:	84 00 00 00 00 00 
   2ec00:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2ec05:	74 59                	je     2ec60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7b0>
   2ec07:	49 ff c6             	inc    %r14
   2ec0a:	4c 39 f6             	cmp    %r14,%rsi
   2ec0d:	75 f1                	jne    2ec00 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x750>
   2ec0f:	48 8d 79 f0          	lea    -0x10(%rcx),%rdi
   2ec13:	48 39 fe             	cmp    %rdi,%rsi
   2ec16:	48 bb 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%rbx
   2ec1d:	5f 5f 5f 
   2ec20:	76 81                	jbe    2eba3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x6f3>
   2ec22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ec29:	1f 84 00 00 00 00 00 
   2ec30:	b3 01                	mov    $0x1,%bl
   2ec32:	49 89 f6             	mov    %rsi,%r14
   2ec35:	48 39 f1             	cmp    %rsi,%rcx
   2ec38:	74 6b                	je     2eca5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7f5>
   2ec3a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2ec40:	42 80 3c 32 5f       	cmpb   $0x5f,(%rdx,%r14,1)
   2ec45:	74 19                	je     2ec60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7b0>
   2ec47:	49 ff c6             	inc    %r14
   2ec4a:	4c 39 f1             	cmp    %r14,%rcx
   2ec4d:	75 f1                	jne    2ec40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x790>
   2ec4f:	eb 54                	jmp    2eca5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x7f5>
   2ec51:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ec58:	0f 1f 84 00 00 00 00 
   2ec5f:	00 
   2ec60:	4d 8d 3c 06          	lea    (%r14,%rax,1),%r15
   2ec64:	49 ff c7             	inc    %r15
   2ec67:	49 01 c6             	add    %rax,%r14
   2ec6a:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   2ec6f:	49 39 f6             	cmp    %rsi,%r14
   2ec72:	0f 83 b8 fe ff ff    	jae    2eb30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x680>
   2ec78:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   2ec7f:	00 
   2ec80:	42 80 3c 30 5f       	cmpb   $0x5f,(%rax,%r14,1)
   2ec85:	0f 85 a5 fe ff ff    	jne    2eb30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x680>
   2ec8b:	31 db                	xor    %ebx,%ebx
   2ec8d:	4c 89 fd             	mov    %r15,%rbp
   2ec90:	bf 40 00 00 00       	mov    $0x40,%edi
   2ec95:	ff 15 d5 2d 04 00    	call   *0x42dd5(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2ec9b:	48 85 c0             	test   %rax,%rax
   2ec9e:	75 21                	jne    2ecc1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x811>
   2eca0:	e9 1e 3d 00 00       	jmp    329c3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4513>
   2eca5:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   2ecaa:	4d 89 f7             	mov    %r14,%r15
   2ecad:	bf 40 00 00 00       	mov    $0x40,%edi
   2ecb2:	ff 15 b8 2d 04 00    	call   *0x42db8(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2ecb8:	48 85 c0             	test   %rax,%rax
   2ecbb:	0f 84 02 3d 00 00    	je     329c3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4513>
   2ecc1:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
   2ecc8:	00 
   2ecc9:	48 89 08             	mov    %rcx,(%rax)
   2eccc:	4c 89 70 08          	mov    %r14,0x8(%rax)
   2ecd0:	48 c7 84 24 30 01 00 	movq   $0x4,0x130(%rsp)
   2ecd7:	00 04 00 00 00 
   2ecdc:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   2ece3:	00 
   2ece4:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   2eceb:	00 
   2ecec:	48 c7 84 24 40 01 00 	movq   $0x1,0x140(%rsp)
   2ecf3:	00 01 00 00 00 
   2ecf8:	84 db                	test   %bl,%bl
   2ecfa:	0f 85 5d 42 00 00    	jne    32f5d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4aad>
   2ed00:	bb 01 00 00 00       	mov    $0x1,%ebx
   2ed05:	eb 55                	jmp    2ed5c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8ac>
   2ed07:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2ed0e:	00 00 
   2ed10:	48 8b 84 24 38 01 00 	mov    0x138(%rsp),%rax
   2ed17:	00 
   2ed18:	48 89 84 24 08 01 00 	mov    %rax,0x108(%rsp)
   2ed1f:	00 
   2ed20:	49 29 ee             	sub    %rbp,%r14
   2ed23:	48 03 ac 24 d0 00 00 	add    0xd0(%rsp),%rbp
   2ed2a:	00 
   2ed2b:	48 89 d8             	mov    %rbx,%rax
   2ed2e:	48 c1 e0 04          	shl    $0x4,%rax
   2ed32:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2ed39:	00 
   2ed3a:	48 89 2c 01          	mov    %rbp,(%rcx,%rax,1)
   2ed3e:	4c 89 74 01 08       	mov    %r14,0x8(%rcx,%rax,1)
   2ed43:	48 ff c3             	inc    %rbx
   2ed46:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
   2ed4d:	00 
   2ed4e:	4c 89 ed             	mov    %r13,%rbp
   2ed51:	80 7c 24 70 00       	cmpb   $0x0,0x70(%rsp)
   2ed56:	0f 85 fa 01 00 00    	jne    2ef56 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xaa6>
   2ed5c:	b0 01                	mov    $0x1,%al
   2ed5e:	89 44 24 70          	mov    %eax,0x70(%rsp)
   2ed62:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   2ed67:	4c 39 f9             	cmp    %r15,%rcx
   2ed6a:	73 14                	jae    2ed80 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8d0>
   2ed6c:	49 89 ed             	mov    %rbp,%r13
   2ed6f:	49 89 ce             	mov    %rcx,%r14
   2ed72:	e9 a4 01 00 00       	jmp    2ef1b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa6b>
   2ed77:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2ed7e:	00 00 
   2ed80:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2ed87:	5f 5f 5f 
   2ed8a:	eb 1a                	jmp    2eda6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8f6>
   2ed8c:	0f 1f 40 00          	nopl   0x0(%rax)
   2ed90:	4d 89 ef             	mov    %r13,%r15
   2ed93:	49 39 cd             	cmp    %rcx,%r13
   2ed96:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2ed9d:	5f 5f 5f 
   2eda0:	0f 87 a8 01 00 00    	ja     2ef4e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa9e>
   2eda6:	48 89 c8             	mov    %rcx,%rax
   2eda9:	4c 29 f8             	sub    %r15,%rax
   2edac:	48 89 ca             	mov    %rcx,%rdx
   2edaf:	48 8b 8c 24 d0 00 00 	mov    0xd0(%rsp),%rcx
   2edb6:	00 
   2edb7:	4c 01 f9             	add    %r15,%rcx
   2edba:	48 83 f8 0f          	cmp    $0xf,%rax
   2edbe:	77 30                	ja     2edf0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x940>
   2edc0:	4c 39 fa             	cmp    %r15,%rdx
   2edc3:	0f 84 47 01 00 00    	je     2ef10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa60>
   2edc9:	45 31 f6             	xor    %r14d,%r14d
   2edcc:	0f 1f 40 00          	nopl   0x0(%rax)
   2edd0:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2edd5:	0f 84 f5 00 00 00    	je     2eed0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa20>
   2eddb:	49 ff c6             	inc    %r14
   2edde:	4c 39 f0             	cmp    %r14,%rax
   2ede1:	75 ed                	jne    2edd0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x920>
   2ede3:	e9 28 01 00 00       	jmp    2ef10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa60>
   2ede8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2edef:	00 
   2edf0:	48 8d 51 07          	lea    0x7(%rcx),%rdx
   2edf4:	48 83 e2 f8          	and    $0xfffffffffffffff8,%rdx
   2edf8:	48 29 ca             	sub    %rcx,%rdx
   2edfb:	49 bb 80 80 80 80 80 	movabs $0x8080808080808080,%r11
   2ee02:	80 80 80 
   2ee05:	75 59                	jne    2ee60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9b0>
   2ee07:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2ee0b:	31 d2                	xor    %edx,%edx
   2ee0d:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
   2ee14:	00 
   2ee15:	4c 01 ff             	add    %r15,%rdi
   2ee18:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ee1f:	00 
   2ee20:	4c 8b 44 17 f8       	mov    -0x8(%rdi,%rdx,1),%r8
   2ee25:	4d 89 c1             	mov    %r8,%r9
   2ee28:	4d 31 f1             	xor    %r14,%r9
   2ee2b:	4d 89 e2             	mov    %r12,%r10
   2ee2e:	4d 29 ca             	sub    %r9,%r10
   2ee31:	4d 09 c2             	or     %r8,%r10
   2ee34:	4c 8b 04 17          	mov    (%rdi,%rdx,1),%r8
   2ee38:	4d 31 f0             	xor    %r14,%r8
   2ee3b:	4d 89 e1             	mov    %r12,%r9
   2ee3e:	4d 29 c1             	sub    %r8,%r9
   2ee41:	4d 09 c1             	or     %r8,%r9
   2ee44:	4d 21 da             	and    %r11,%r10
   2ee47:	4d 21 ca             	and    %r9,%r10
   2ee4a:	4d 39 da             	cmp    %r11,%r10
   2ee4d:	75 51                	jne    2eea0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9f0>
   2ee4f:	48 83 c2 10          	add    $0x10,%rdx
   2ee53:	48 39 f2             	cmp    %rsi,%rdx
   2ee56:	76 c8                	jbe    2ee20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x970>
   2ee58:	eb 46                	jmp    2eea0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9f0>
   2ee5a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2ee60:	45 31 f6             	xor    %r14d,%r14d
   2ee63:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2ee6a:	84 00 00 00 00 00 
   2ee70:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2ee75:	74 59                	je     2eed0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa20>
   2ee77:	49 ff c6             	inc    %r14
   2ee7a:	4c 39 f2             	cmp    %r14,%rdx
   2ee7d:	75 f1                	jne    2ee70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x9c0>
   2ee7f:	48 8d 70 f0          	lea    -0x10(%rax),%rsi
   2ee83:	48 39 f2             	cmp    %rsi,%rdx
   2ee86:	49 be 5f 5f 5f 5f 5f 	movabs $0x5f5f5f5f5f5f5f5f,%r14
   2ee8d:	5f 5f 5f 
   2ee90:	0f 86 77 ff ff ff    	jbe    2ee0d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x95d>
   2ee96:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2ee9d:	00 00 00 
   2eea0:	49 89 d6             	mov    %rdx,%r14
   2eea3:	48 39 d0             	cmp    %rdx,%rax
   2eea6:	74 68                	je     2ef10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa60>
   2eea8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2eeaf:	00 
   2eeb0:	42 80 3c 31 5f       	cmpb   $0x5f,(%rcx,%r14,1)
   2eeb5:	74 19                	je     2eed0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa20>
   2eeb7:	49 ff c6             	inc    %r14
   2eeba:	4c 39 f0             	cmp    %r14,%rax
   2eebd:	75 f1                	jne    2eeb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa00>
   2eebf:	eb 4f                	jmp    2ef10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa60>
   2eec1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2eec8:	0f 1f 84 00 00 00 00 
   2eecf:	00 
   2eed0:	4f 8d 2c 3e          	lea    (%r14,%r15,1),%r13
   2eed4:	49 ff c5             	inc    %r13
   2eed7:	4d 01 fe             	add    %r15,%r14
   2eeda:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   2eedf:	49 39 ce             	cmp    %rcx,%r14
   2eee2:	0f 83 a8 fe ff ff    	jae    2ed90 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8e0>
   2eee8:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   2eeef:	00 
   2eef0:	42 80 3c 30 5f       	cmpb   $0x5f,(%rax,%r14,1)
   2eef5:	0f 85 95 fe ff ff    	jne    2ed90 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8e0>
   2eefb:	c7 44 24 70 00 00 00 	movl   $0x0,0x70(%rsp)
   2ef02:	00 
   2ef03:	4d 89 ef             	mov    %r13,%r15
   2ef06:	eb 13                	jmp    2ef1b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xa6b>
   2ef08:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2ef0f:	00 
   2ef10:	4c 8b 74 24 28       	mov    0x28(%rsp),%r14
   2ef15:	4d 89 f7             	mov    %r14,%r15
   2ef18:	49 89 ed             	mov    %rbp,%r13
   2ef1b:	48 3b 9c 24 30 01 00 	cmp    0x130(%rsp),%rbx
   2ef22:	00 
   2ef23:	0f 85 f7 fd ff ff    	jne    2ed20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x870>
   2ef29:	ba 01 00 00 00       	mov    $0x1,%edx
   2ef2e:	b9 08 00 00 00       	mov    $0x8,%ecx
   2ef33:	41 b8 10 00 00 00    	mov    $0x10,%r8d
   2ef39:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2ef40:	00 
   2ef41:	48 89 de             	mov    %rbx,%rsi
   2ef44:	e8 67 dd ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2ef49:	e9 c2 fd ff ff       	jmp    2ed10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x860>
   2ef4e:	4d 89 ef             	mov    %r13,%r15
   2ef51:	e9 16 fe ff ff       	jmp    2ed6c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x8bc>
   2ef56:	48 8b 84 24 30 01 00 	mov    0x130(%rsp),%rax
   2ef5d:	00 
   2ef5e:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
   2ef65:	00 
   2ef66:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   2ef6d:	00 
   2ef6e:	48 89 9c 24 30 01 00 	mov    %rbx,0x130(%rsp)
   2ef75:	00 
   2ef76:	48 83 fb 03          	cmp    $0x3,%rbx
   2ef7a:	48 89 bc 24 08 01 00 	mov    %rdi,0x108(%rsp)
   2ef81:	00 
   2ef82:	0f 85 ee 3f 00 00    	jne    32f76 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4ac6>
   2ef88:	48 83 7f 08 03       	cmpq   $0x3,0x8(%rdi)
   2ef8d:	0f 85 cb 3b 00 00    	jne    32b5e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46ae>
   2ef93:	48 8b 07             	mov    (%rdi),%rax
   2ef96:	0f b7 08             	movzwl (%rax),%ecx
   2ef99:	81 f1 6d 61 00 00    	xor    $0x616d,%ecx
   2ef9f:	0f b6 40 02          	movzbl 0x2(%rax),%eax
   2efa3:	83 f0 70             	xor    $0x70,%eax
   2efa6:	66 09 c8             	or     %cx,%ax
   2efa9:	0f 85 af 3b 00 00    	jne    32b5e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46ae>
   2efaf:	48 8b 4f 10          	mov    0x10(%rdi),%rcx
   2efb3:	48 8b 77 18          	mov    0x18(%rdi),%rsi
   2efb7:	48 83 fe 01          	cmp    $0x1,%rsi
   2efbb:	74 0e                	je     2efcb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb1b>
   2efbd:	48 85 f6             	test   %rsi,%rsi
   2efc0:	0f 84 15 40 00 00    	je     32fdb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b2b>
   2efc6:	0f b6 11             	movzbl (%rcx),%edx
   2efc9:	eb 17                	jmp    2efe2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb32>
   2efcb:	0f b6 11             	movzbl (%rcx),%edx
   2efce:	b0 01                	mov    $0x1,%al
   2efd0:	83 fa 2b             	cmp    $0x2b,%edx
   2efd3:	0f 84 95 3a 00 00    	je     32a6e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45be>
   2efd9:	83 fa 2d             	cmp    $0x2d,%edx
   2efdc:	0f 84 8c 3a 00 00    	je     32a6e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45be>
   2efe2:	31 c0                	xor    %eax,%eax
   2efe4:	80 fa 2b             	cmp    $0x2b,%dl
   2efe7:	0f 94 c0             	sete   %al
   2efea:	48 89 f2             	mov    %rsi,%rdx
   2efed:	48 29 c2             	sub    %rax,%rdx
   2eff0:	48 01 c1             	add    %rax,%rcx
   2eff3:	48 f7 d8             	neg    %rax
   2eff6:	48 83 fa 11          	cmp    $0x11,%rdx
   2effa:	73 42                	jae    2f03e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb8e>
   2effc:	48 85 d2             	test   %rdx,%rdx
   2efff:	0f 84 ee 00 00 00    	je     2f0f3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc43>
   2f005:	48 01 c6             	add    %rax,%rsi
   2f008:	48 f7 de             	neg    %rsi
   2f00b:	31 ed                	xor    %ebp,%ebp
   2f00d:	31 c0                	xor    %eax,%eax
   2f00f:	90                   	nop
   2f010:	0f b6 14 01          	movzbl (%rcx,%rax,1),%edx
   2f014:	83 c2 d0             	add    $0xffffffd0,%edx
   2f017:	83 fa 09             	cmp    $0x9,%edx
   2f01a:	0f 87 68 3d 00 00    	ja     32d88 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48d8>
   2f020:	48 8d 3c ad 00 00 00 	lea    0x0(,%rbp,4),%rdi
   2f027:	00 
   2f028:	48 01 ef             	add    %rbp,%rdi
   2f02b:	89 d2                	mov    %edx,%edx
   2f02d:	48 8d 2c 7a          	lea    (%rdx,%rdi,2),%rbp
   2f031:	48 ff c0             	inc    %rax
   2f034:	48 89 f2             	mov    %rsi,%rdx
   2f037:	48 01 c2             	add    %rax,%rdx
   2f03a:	75 d4                	jne    2f010 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb60>
   2f03c:	eb 48                	jmp    2f086 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xbd6>
   2f03e:	48 01 c6             	add    %rax,%rsi
   2f041:	48 f7 de             	neg    %rsi
   2f044:	31 ed                	xor    %ebp,%ebp
   2f046:	bf 0a 00 00 00       	mov    $0xa,%edi
   2f04b:	45 31 c0             	xor    %r8d,%r8d
   2f04e:	66 90                	xchg   %ax,%ax
   2f050:	48 89 e8             	mov    %rbp,%rax
   2f053:	48 f7 e7             	mul    %rdi
   2f056:	42 0f b6 14 01       	movzbl (%rcx,%r8,1),%edx
   2f05b:	0f 80 ff 39 00 00    	jo     32a60 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45b0>
   2f061:	83 c2 d0             	add    $0xffffffd0,%edx
   2f064:	83 fa 0a             	cmp    $0xa,%edx
   2f067:	0f 83 1b 3d 00 00    	jae    32d88 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48d8>
   2f06d:	48 89 c5             	mov    %rax,%rbp
   2f070:	89 d0                	mov    %edx,%eax
   2f072:	48 01 c5             	add    %rax,%rbp
   2f075:	0f 82 f1 39 00 00    	jb     32a6c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45bc>
   2f07b:	49 ff c0             	inc    %r8
   2f07e:	48 89 f0             	mov    %rsi,%rax
   2f081:	4c 01 c0             	add    %r8,%rax
   2f084:	75 ca                	jne    2f050 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xba0>
   2f086:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f08d:	00 
   2f08e:	48 8b 40 28          	mov    0x28(%rax),%rax
   2f092:	48 83 f8 0d          	cmp    $0xd,%rax
   2f096:	74 6f                	je     2f107 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc57>
   2f098:	48 83 f8 09          	cmp    $0x9,%rax
   2f09c:	75 3d                	jne    2f0db <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc2b>
   2f09e:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2f0a5:	00 
   2f0a6:	48 8b 49 20          	mov    0x20(%rcx),%rcx
   2f0aa:	48 ba 64 75 70 6c 69 	movabs $0x746163696c707564,%rdx
   2f0b1:	63 61 74 
   2f0b4:	48 33 11             	xor    (%rcx),%rdx
   2f0b7:	0f b6 49 08          	movzbl 0x8(%rcx),%ecx
   2f0bb:	48 83 f1 65          	xor    $0x65,%rcx
   2f0bf:	48 09 d1             	or     %rdx,%rcx
   2f0c2:	41 0f 94 c4          	sete   %r12b
   2f0c6:	c7 84 24 cc 00 00 00 	movl   $0x0,0xcc(%rsp)
   2f0cd:	00 00 00 00 
   2f0d1:	45 84 e4             	test   %r12b,%r12b
   2f0d4:	74 6d                	je     2f143 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc93>
   2f0d6:	e9 9b 00 00 00       	jmp    2f176 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xcc6>
   2f0db:	45 31 e4             	xor    %r12d,%r12d
   2f0de:	c7 84 24 cc 00 00 00 	movl   $0x0,0xcc(%rsp)
   2f0e5:	00 00 00 00 
   2f0e9:	45 84 e4             	test   %r12b,%r12b
   2f0ec:	74 55                	je     2f143 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xc93>
   2f0ee:	e9 83 00 00 00       	jmp    2f176 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xcc6>
   2f0f3:	31 ed                	xor    %ebp,%ebp
   2f0f5:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f0fc:	00 
   2f0fd:	48 8b 40 28          	mov    0x28(%rax),%rax
   2f101:	48 83 f8 0d          	cmp    $0xd,%rax
   2f105:	75 91                	jne    2f098 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xbe8>
   2f107:	48 8b 8c 24 08 01 00 	mov    0x108(%rsp),%rcx
   2f10e:	00 
   2f10f:	48 8b 49 20          	mov    0x20(%rcx),%rcx
   2f113:	48 ba 66 69 72 73 74 	movabs $0x7275737473726966,%rdx
   2f11a:	73 75 72 
   2f11d:	48 33 11             	xor    (%rcx),%rdx
   2f120:	48 be 73 75 72 76 69 	movabs $0x7365766976727573,%rsi
   2f127:	76 65 73 
   2f12a:	48 33 71 05          	xor    0x5(%rcx),%rsi
   2f12e:	48 09 d6             	or     %rdx,%rsi
   2f131:	0f 94 c1             	sete   %cl
   2f134:	89 8c 24 cc 00 00 00 	mov    %ecx,0xcc(%rsp)
   2f13b:	45 31 e4             	xor    %r12d,%r12d
   2f13e:	45 84 e4             	test   %r12b,%r12b
   2f141:	75 33                	jne    2f176 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xcc6>
   2f143:	80 bc 24 cc 00 00 00 	cmpb   $0x0,0xcc(%rsp)
   2f14a:	00 
   2f14b:	75 29                	jne    2f176 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xcc6>
   2f14d:	48 83 f8 08          	cmp    $0x8,%rax
   2f151:	0f 85 42 3a 00 00    	jne    32b99 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46e9>
   2f157:	48 8b 84 24 08 01 00 	mov    0x108(%rsp),%rax
   2f15e:	00 
   2f15f:	48 8b 40 20          	mov    0x20(%rax),%rax
   2f163:	48 b9 64 69 73 74 69 	movabs $0x74636e6974736964,%rcx
   2f16a:	6e 63 74 
   2f16d:	48 39 08             	cmp    %rcx,(%rax)
   2f170:	0f 85 23 3a 00 00    	jne    32b99 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46e9>
   2f176:	48 c7 84 24 10 01 00 	movq   $0x0,0x110(%rsp)
   2f17d:	00 00 00 00 00 
   2f182:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2f189:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2f18e:	0f 85 23 3a 00 00    	jne    32bb7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4707>
   2f194:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2f198:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2f19d:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2f1a1:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2f1a5:	0f 10 05 84 0c 04 00 	movups 0x40c84(%rip),%xmm0        # 6fe30 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2f1ac:	0f 29 84 24 30 01 00 	movaps %xmm0,0x130(%rsp)
   2f1b3:	00 
   2f1b4:	66 0f 10 05 84 0c 04 	movupd 0x40c84(%rip),%xmm0        # 6fe40 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2f1bb:	00 
   2f1bc:	66 0f 29 84 24 40 01 	movapd %xmm0,0x140(%rsp)
   2f1c3:	00 00 
   2f1c5:	48 89 84 24 50 01 00 	mov    %rax,0x150(%rsp)
   2f1cc:	00 
   2f1cd:	48 89 94 24 58 01 00 	mov    %rdx,0x158(%rsp)
   2f1d4:	00 
   2f1d5:	48 c7 84 24 08 02 00 	movq   $0x0,0x208(%rsp)
   2f1dc:	00 00 00 00 00 
   2f1e1:	48 c7 84 24 18 02 00 	movq   $0x0,0x218(%rsp)
   2f1e8:	00 00 00 00 00 
   2f1ed:	48 c7 84 24 b8 01 00 	movq   $0x0,0x1b8(%rsp)
   2f1f4:	00 00 00 00 00 
   2f1f9:	48 c7 84 24 c0 01 00 	movq   $0x1,0x1c0(%rsp)
   2f200:	00 01 00 00 00 
   2f205:	48 c7 84 24 c8 01 00 	movq   $0x0,0x1c8(%rsp)
   2f20c:	00 00 00 00 00 
   2f211:	48 c7 84 24 d0 01 00 	movq   $0x0,0x1d0(%rsp)
   2f218:	00 00 00 00 00 
   2f21d:	48 c7 84 24 d8 01 00 	movq   $0x4,0x1d8(%rsp)
   2f224:	00 04 00 00 00 
   2f229:	48 c7 84 24 e0 01 00 	movq   $0x0,0x1e0(%rsp)
   2f230:	00 00 00 00 00 
   2f235:	45 84 e4             	test   %r12b,%r12b
   2f238:	74 0a                	je     2f244 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xd94>
   2f23a:	48 8d 75 03          	lea    0x3(%rbp),%rsi
   2f23e:	48 c1 ee 02          	shr    $0x2,%rsi
   2f242:	eb 1f                	jmp    2f263 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xdb3>
   2f244:	48 89 ee             	mov    %rbp,%rsi
   2f247:	80 bc 24 cc 00 00 00 	cmpb   $0x0,0xcc(%rsp)
   2f24e:	00 
   2f24f:	74 12                	je     2f263 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xdb3>
   2f251:	48 8d 75 03          	lea    0x3(%rbp),%rsi
   2f255:	48 c1 ee 02          	shr    $0x2,%rsi
   2f259:	48 ff c6             	inc    %rsi
   2f25c:	48 39 f5             	cmp    %rsi,%rbp
   2f25f:	48 0f 42 f5          	cmovb  %rbp,%rsi
   2f263:	48 85 ed             	test   %rbp,%rbp
   2f266:	48 89 ac 24 70 01 00 	mov    %rbp,0x170(%rsp)
   2f26d:	00 
   2f26e:	0f 84 42 0c 00 00    	je     2feb6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a06>
   2f274:	48 8d 46 ff          	lea    -0x1(%rsi),%rax
   2f278:	48 89 84 24 80 02 00 	mov    %rax,0x280(%rsp)
   2f27f:	00 
   2f280:	45 31 f6             	xor    %r14d,%r14d
   2f283:	48 8d 05 8e 0f 04 00 	lea    0x40f8e(%rip),%rax        # 70218 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8c8>
   2f28a:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
   2f291:	00 
   2f292:	45 31 ed             	xor    %r13d,%r13d
   2f295:	45 31 ff             	xor    %r15d,%r15d
   2f298:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
   2f29f:	00 00 00 00 00 
   2f2a4:	44 89 a4 24 04 01 00 	mov    %r12d,0x104(%rsp)
   2f2ab:	00 
   2f2ac:	48 89 b4 24 98 02 00 	mov    %rsi,0x298(%rsp)
   2f2b3:	00 
   2f2b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f2bb:	00 00 00 00 00 
   2f2c0:	49 8d 46 01          	lea    0x1(%r14),%rax
   2f2c4:	48 39 f0             	cmp    %rsi,%rax
   2f2c7:	b9 00 00 00 00       	mov    $0x0,%ecx
   2f2cc:	48 0f 45 c8          	cmovne %rax,%rcx
   2f2d0:	45 84 e4             	test   %r12b,%r12b
   2f2d3:	48 89 8c 24 78 01 00 	mov    %rcx,0x178(%rsp)
   2f2da:	00 
   2f2db:	74 33                	je     2f310 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe60>
   2f2dd:	48 85 f6             	test   %rsi,%rsi
   2f2e0:	0f 84 f3 3a 00 00    	je     32dd9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4929>
   2f2e6:	4c 89 e8             	mov    %r13,%rax
   2f2e9:	48 09 f0             	or     %rsi,%rax
   2f2ec:	48 c1 e8 20          	shr    $0x20,%rax
   2f2f0:	0f 85 9a 00 00 00    	jne    2f390 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xee0>
   2f2f6:	44 89 e8             	mov    %r13d,%eax
   2f2f9:	31 d2                	xor    %edx,%edx
   2f2fb:	f7 f6                	div    %esi
   2f2fd:	41 89 d6             	mov    %edx,%r14d
   2f300:	e9 8b 00 00 00       	jmp    2f390 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xee0>
   2f305:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f30c:	00 00 00 00 
   2f310:	80 bc 24 cc 00 00 00 	cmpb   $0x0,0xcc(%rsp)
   2f317:	00 
   2f318:	74 36                	je     2f350 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xea0>
   2f31a:	4d 85 ed             	test   %r13,%r13
   2f31d:	48 8b bc 24 80 02 00 	mov    0x280(%rsp),%rdi
   2f324:	00 
   2f325:	74 49                	je     2f370 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xec0>
   2f327:	48 85 ff             	test   %rdi,%rdi
   2f32a:	0f 84 b8 3a 00 00    	je     32de8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4938>
   2f330:	49 8d 45 ff          	lea    -0x1(%r13),%rax
   2f334:	48 89 c1             	mov    %rax,%rcx
   2f337:	48 09 f9             	or     %rdi,%rcx
   2f33a:	48 c1 e9 20          	shr    $0x20,%rcx
   2f33e:	74 3e                	je     2f37e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xece>
   2f340:	31 d2                	xor    %edx,%edx
   2f342:	48 f7 f7             	div    %rdi
   2f345:	49 89 d6             	mov    %rdx,%r14
   2f348:	eb 3b                	jmp    2f385 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xed5>
   2f34a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f350:	4c 89 e8             	mov    %r13,%rax
   2f353:	48 c1 e0 04          	shl    $0x4,%rax
   2f357:	4c 01 e8             	add    %r13,%rax
   2f35a:	48 89 c1             	mov    %rax,%rcx
   2f35d:	48 09 e9             	or     %rbp,%rcx
   2f360:	48 c1 e9 20          	shr    $0x20,%rcx
   2f364:	74 0f                	je     2f375 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xec5>
   2f366:	31 d2                	xor    %edx,%edx
   2f368:	48 f7 f5             	div    %rbp
   2f36b:	49 89 d6             	mov    %rdx,%r14
   2f36e:	eb 20                	jmp    2f390 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xee0>
   2f370:	45 31 f6             	xor    %r14d,%r14d
   2f373:	eb 1b                	jmp    2f390 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xee0>
   2f375:	31 d2                	xor    %edx,%edx
   2f377:	f7 f5                	div    %ebp
   2f379:	41 89 d6             	mov    %edx,%r14d
   2f37c:	eb 12                	jmp    2f390 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xee0>
   2f37e:	31 d2                	xor    %edx,%edx
   2f380:	f7 f7                	div    %edi
   2f382:	41 89 d6             	mov    %edx,%r14d
   2f385:	49 ff c6             	inc    %r14
   2f388:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2f38f:	00 
   2f390:	42 8d 14 ed 00 00 00 	lea    0x0(,%r13,8),%edx
   2f397:	00 
   2f398:	44 29 ea             	sub    %r13d,%edx
   2f39b:	83 c2 03             	add    $0x3,%edx
   2f39e:	48 8d bc 24 10 01 00 	lea    0x110(%rsp),%rdi
   2f3a5:	00 
   2f3a6:	44 89 f6             	mov    %r14d,%esi
   2f3a9:	89 94 24 d0 00 00 00 	mov    %edx,0xd0(%rsp)
   2f3b0:	e8 7b 59 00 00       	call   34d30 <_RNvMso_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_3MapllE10push_entryCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f3b5:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   2f3bc:	00 
   2f3bd:	44 89 f6             	mov    %r14d,%esi
   2f3c0:	8b 94 24 d0 00 00 00 	mov    0xd0(%rsp),%edx
   2f3c7:	e8 04 44 00 00       	call   337d0 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2f3cc:	4c 89 6c 24 70       	mov    %r13,0x70(%rsp)
   2f3d1:	4d 85 ff             	test   %r15,%r15
   2f3d4:	0f 84 c6 00 00 00    	je     2f4a0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xff0>
   2f3da:	48 8b 84 24 e0 00 00 	mov    0xe0(%rsp),%rax
   2f3e1:	00 
   2f3e2:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   2f3e7:	4c 89 fb             	mov    %r15,%rbx
   2f3ea:	44 0f b7 7b 62       	movzwl 0x62(%rbx),%r15d
   2f3ef:	4d 89 fd             	mov    %r15,%r13
   2f3f2:	45 85 ff             	test   %r15d,%r15d
   2f3f5:	74 40                	je     2f437 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf87>
   2f3f7:	44 89 f9             	mov    %r15d,%ecx
   2f3fa:	c1 e1 02             	shl    $0x2,%ecx
   2f3fd:	45 31 ed             	xor    %r13d,%r13d
   2f400:	46 3b 74 ab 08       	cmp    0x8(%rbx,%r13,4),%r14d
   2f405:	40 0f 9c c6          	setl   %sil
   2f409:	0f 9f c2             	setg   %dl
   2f40c:	40 28 f2             	sub    %sil,%dl
   2f40f:	80 fa 01             	cmp    $0x1,%dl
   2f412:	75 1c                	jne    2f430 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf80>
   2f414:	49 ff c5             	inc    %r13
   2f417:	48 83 c1 fc          	add    $0xfffffffffffffffc,%rcx
   2f41b:	75 e3                	jne    2f400 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf50>
   2f41d:	4d 89 fd             	mov    %r15,%r13
   2f420:	eb 15                	jmp    2f437 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf87>
   2f422:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f429:	1f 84 00 00 00 00 00 
   2f430:	0f b6 ca             	movzbl %dl,%ecx
   2f433:	85 c9                	test   %ecx,%ecx
   2f435:	74 29                	je     2f460 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xfb0>
   2f437:	48 83 e8 01          	sub    $0x1,%rax
   2f43b:	0f 82 a6 01 00 00    	jb     2f5e7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1137>
   2f441:	4a 8b 5c eb 68       	mov    0x68(%rbx,%r13,8),%rbx
   2f446:	44 0f b7 7b 62       	movzwl 0x62(%rbx),%r15d
   2f44b:	4d 89 fd             	mov    %r15,%r13
   2f44e:	45 85 ff             	test   %r15d,%r15d
   2f451:	75 a4                	jne    2f3f7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf47>
   2f453:	eb e2                	jmp    2f437 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xf87>
   2f455:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2f45c:	00 00 00 00 
   2f460:	8b 84 24 d0 00 00 00 	mov    0xd0(%rsp),%eax
   2f467:	42 89 44 ab 34       	mov    %eax,0x34(%rbx,%r13,4)
   2f46c:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2f471:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2f476:	48 8b 9c 24 e0 01 00 	mov    0x1e0(%rsp),%rbx
   2f47d:	00 
   2f47e:	48 3b 9c 24 d0 01 00 	cmp    0x1d0(%rsp),%rbx
   2f485:	00 
   2f486:	0f 84 af 00 00 00    	je     2f53b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x108b>
   2f48c:	e9 b8 00 00 00       	jmp    2f549 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1099>
   2f491:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f498:	0f 1f 84 00 00 00 00 
   2f49f:	00 
   2f4a0:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2f4a6:	bf 68 00 00 00       	mov    $0x68,%edi
   2f4ab:	ff 15 bf 25 04 00    	call   *0x425bf(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2f4b1:	48 85 c0             	test   %rax,%rax
   2f4b4:	0f 84 e8 35 00 00    	je     32aa2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45f2>
   2f4ba:	49 89 c7             	mov    %rax,%r15
   2f4bd:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f4c4:	48 89 84 24 08 02 00 	mov    %rax,0x208(%rsp)
   2f4cb:	00 
   2f4cc:	48 c7 84 24 10 02 00 	movq   $0x0,0x210(%rsp)
   2f4d3:	00 00 00 00 00 
   2f4d8:	66 c7 40 62 01 00    	movw   $0x1,0x62(%rax)
   2f4de:	44 89 70 08          	mov    %r14d,0x8(%rax)
   2f4e2:	8b 84 24 d0 00 00 00 	mov    0xd0(%rsp),%eax
   2f4e9:	41 89 47 34          	mov    %eax,0x34(%r15)
   2f4ed:	48 c7 84 24 e0 00 00 	movq   $0x0,0xe0(%rsp)
   2f4f4:	00 00 00 00 00 
   2f4f9:	48 8b ac 24 70 01 00 	mov    0x170(%rsp),%rbp
   2f500:	00 
   2f501:	44 8b a4 24 04 01 00 	mov    0x104(%rsp),%r12d
   2f508:	00 
   2f509:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2f50e:	48 8b 8c 24 98 00 00 	mov    0x98(%rsp),%rcx
   2f515:	00 
   2f516:	48 ff c1             	inc    %rcx
   2f519:	48 89 8c 24 98 00 00 	mov    %rcx,0x98(%rsp)
   2f520:	00 
   2f521:	48 89 8c 24 18 02 00 	mov    %rcx,0x218(%rsp)
   2f528:	00 
   2f529:	48 8b 9c 24 e0 01 00 	mov    0x1e0(%rsp),%rbx
   2f530:	00 
   2f531:	48 3b 9c 24 d0 01 00 	cmp    0x1d0(%rsp),%rbx
   2f538:	00 
   2f539:	75 0e                	jne    2f549 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1099>
   2f53b:	48 8d bc 24 d0 01 00 	lea    0x1d0(%rsp),%rdi
   2f542:	00 
   2f543:	ff 15 27 29 04 00    	call   *0x42927(%rip)        # 71e70 <_DYNAMIC+0x5e8>
   2f549:	48 8b 84 24 d8 01 00 	mov    0x1d8(%rsp),%rax
   2f550:	00 
   2f551:	44 89 34 d8          	mov    %r14d,(%rax,%rbx,8)
   2f555:	8b 8c 24 d0 00 00 00 	mov    0xd0(%rsp),%ecx
   2f55c:	89 4c d8 04          	mov    %ecx,0x4(%rax,%rbx,8)
   2f560:	48 ff c3             	inc    %rbx
   2f563:	48 89 9c 24 e0 01 00 	mov    %rbx,0x1e0(%rsp)
   2f56a:	00 
   2f56b:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
   2f572:	00 
   2f573:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
   2f57a:	00 
   2f57b:	48 89 c1             	mov    %rax,%rcx
   2f57e:	48 29 f1             	sub    %rsi,%rcx
   2f581:	48 83 f9 03          	cmp    $0x3,%rcx
   2f585:	0f 86 c7 08 00 00    	jbe    2fe52 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x19a2>
   2f58b:	48 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%rcx
   2f592:	00 
   2f593:	44 89 34 31          	mov    %r14d,(%rcx,%rsi,1)
   2f597:	48 83 c6 04          	add    $0x4,%rsi
   2f59b:	48 89 b4 24 c8 01 00 	mov    %rsi,0x1c8(%rsp)
   2f5a2:	00 
   2f5a3:	48 29 f0             	sub    %rsi,%rax
   2f5a6:	48 83 f8 03          	cmp    $0x3,%rax
   2f5aa:	0f 86 d4 08 00 00    	jbe    2fe84 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x19d4>
   2f5b0:	49 ff c5             	inc    %r13
   2f5b3:	8b 84 24 d0 00 00 00 	mov    0xd0(%rsp),%eax
   2f5ba:	89 04 31             	mov    %eax,(%rcx,%rsi,1)
   2f5bd:	48 83 c6 04          	add    $0x4,%rsi
   2f5c1:	48 89 b4 24 c8 01 00 	mov    %rsi,0x1c8(%rsp)
   2f5c8:	00 
   2f5c9:	4c 8b b4 24 78 01 00 	mov    0x178(%rsp),%r14
   2f5d0:	00 
   2f5d1:	49 39 ed             	cmp    %rbp,%r13
   2f5d4:	48 8b b4 24 98 02 00 	mov    0x298(%rsp),%rsi
   2f5db:	00 
   2f5dc:	0f 85 de fc ff ff    	jne    2f2c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xe10>
   2f5e2:	e9 de 08 00 00       	jmp    2fec5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a15>
   2f5e7:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f5eb:	66 41 83 ff 0b       	cmp    $0xb,%r15w
   2f5f0:	73 68                	jae    2f65a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11aa>
   2f5f2:	4d 39 ef             	cmp    %r13,%r15
   2f5f5:	76 40                	jbe    2f637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1187>
   2f5f7:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2f5fb:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2f5ff:	48 83 c7 04          	add    $0x4,%rdi
   2f603:	45 89 fc             	mov    %r15d,%r12d
   2f606:	45 29 ec             	sub    %r13d,%r12d
   2f609:	41 c1 e4 02          	shl    $0x2,%r12d
   2f60d:	4c 89 e2             	mov    %r12,%rdx
   2f610:	ff 15 4a 25 04 00    	call   *0x4254a(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2f616:	4a 8d 34 ab          	lea    (%rbx,%r13,4),%rsi
   2f61a:	48 83 c6 34          	add    $0x34,%rsi
   2f61e:	4a 8d 3c ab          	lea    (%rbx,%r13,4),%rdi
   2f622:	48 83 c7 38          	add    $0x38,%rdi
   2f626:	4c 89 e2             	mov    %r12,%rdx
   2f629:	44 8b a4 24 04 01 00 	mov    0x104(%rsp),%r12d
   2f630:	00 
   2f631:	ff 15 29 25 04 00    	call   *0x42529(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2f637:	46 89 74 ab 08       	mov    %r14d,0x8(%rbx,%r13,4)
   2f63c:	41 8d 47 01          	lea    0x1(%r15),%eax
   2f640:	8b 8c 24 d0 00 00 00 	mov    0xd0(%rsp),%ecx
   2f647:	42 89 4c ab 34       	mov    %ecx,0x34(%rbx,%r13,4)
   2f64c:	66 89 43 62          	mov    %ax,0x62(%rbx)
   2f650:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2f655:	e9 af fe ff ff       	jmp    2f509 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1059>
   2f65a:	49 83 fd 05          	cmp    $0x5,%r13
   2f65e:	73 10                	jae    2f670 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11c0>
   2f660:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2f666:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
   2f66d:	00 
   2f66e:	eb 36                	jmp    2f6a6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11f6>
   2f670:	74 17                	je     2f689 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11d9>
   2f672:	49 83 fd 06          	cmp    $0x6,%r13
   2f676:	75 1e                	jne    2f696 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11e6>
   2f678:	41 bf 05 00 00 00    	mov    $0x5,%r15d
   2f67e:	b0 01                	mov    $0x1,%al
   2f680:	89 44 24 60          	mov    %eax,0x60(%rsp)
   2f684:	45 31 ed             	xor    %r13d,%r13d
   2f687:	eb 1d                	jmp    2f6a6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11f6>
   2f689:	c7 44 24 60 00 00 00 	movl   $0x0,0x60(%rsp)
   2f690:	00 
   2f691:	4d 89 ef             	mov    %r13,%r15
   2f694:	eb 10                	jmp    2f6a6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x11f6>
   2f696:	49 83 c5 f9          	add    $0xfffffffffffffff9,%r13
   2f69a:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   2f6a0:	b0 01                	mov    $0x1,%al
   2f6a2:	89 44 24 60          	mov    %eax,0x60(%rsp)
   2f6a6:	41 bc 68 00 00 00    	mov    $0x68,%r12d
   2f6ac:	bf 68 00 00 00       	mov    $0x68,%edi
   2f6b1:	ff 15 b9 23 04 00    	call   *0x423b9(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2f6b7:	48 85 c0             	test   %rax,%rax
   2f6ba:	0f 84 e2 33 00 00    	je     32aa2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45f2>
   2f6c0:	48 89 c5             	mov    %rax,%rbp
   2f6c3:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2f6ca:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f6ce:	4d 89 fc             	mov    %r15,%r12
   2f6d1:	49 f7 d4             	not    %r12
   2f6d4:	49 01 c4             	add    %rax,%r12
   2f6d7:	66 44 89 65 62       	mov    %r12w,0x62(%rbp)
   2f6dc:	49 83 fc 0c          	cmp    $0xc,%r12
   2f6e0:	0f 83 82 34 00 00    	jae    32b68 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46b8>
   2f6e6:	42 8b 44 bb 08       	mov    0x8(%rbx,%r15,4),%eax
   2f6eb:	89 84 24 8c 01 00 00 	mov    %eax,0x18c(%rsp)
   2f6f2:	42 8b 44 bb 34       	mov    0x34(%rbx,%r15,4),%eax
   2f6f7:	89 84 24 88 01 00 00 	mov    %eax,0x188(%rsp)
   2f6fe:	48 8d 43 08          	lea    0x8(%rbx),%rax
   2f702:	4a 8d 34 b8          	lea    (%rax,%r15,4),%rsi
   2f706:	48 83 c6 04          	add    $0x4,%rsi
   2f70a:	48 8d 7d 08          	lea    0x8(%rbp),%rdi
   2f70e:	49 c1 e4 02          	shl    $0x2,%r12
   2f712:	4c 89 e2             	mov    %r12,%rdx
   2f715:	ff 15 75 23 04 00    	call   *0x42375(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   2f71b:	4a 8d 34 bb          	lea    (%rbx,%r15,4),%rsi
   2f71f:	48 83 c6 38          	add    $0x38,%rsi
   2f723:	48 8d 7d 34          	lea    0x34(%rbp),%rdi
   2f727:	4c 89 e2             	mov    %r12,%rdx
   2f72a:	ff 15 60 23 04 00    	call   *0x42360(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   2f730:	66 44 89 7b 62       	mov    %r15w,0x62(%rbx)
   2f735:	80 7c 24 60 00       	cmpb   $0x0,0x60(%rsp)
   2f73a:	49 89 ef             	mov    %rbp,%r15
   2f73d:	4c 0f 44 fb          	cmove  %rbx,%r15
   2f741:	45 0f b7 67 62       	movzwl 0x62(%r15),%r12d
   2f746:	4d 39 ec             	cmp    %r13,%r12
   2f749:	76 3f                	jbe    2f78a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x12da>
   2f74b:	49 8d 47 08          	lea    0x8(%r15),%rax
   2f74f:	4a 8d 34 a8          	lea    (%rax,%r13,4),%rsi
   2f753:	4a 8d 3c a8          	lea    (%rax,%r13,4),%rdi
   2f757:	48 83 c7 04          	add    $0x4,%rdi
   2f75b:	44 89 e2             	mov    %r12d,%edx
   2f75e:	44 29 ea             	sub    %r13d,%edx
   2f761:	c1 e2 02             	shl    $0x2,%edx
   2f764:	48 89 54 24 60       	mov    %rdx,0x60(%rsp)
   2f769:	ff 15 f1 23 04 00    	call   *0x423f1(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2f76f:	4b 8d 34 af          	lea    (%r15,%r13,4),%rsi
   2f773:	48 83 c6 34          	add    $0x34,%rsi
   2f777:	4b 8d 3c af          	lea    (%r15,%r13,4),%rdi
   2f77b:	48 83 c7 38          	add    $0x38,%rdi
   2f77f:	48 8b 54 24 60       	mov    0x60(%rsp),%rdx
   2f784:	ff 15 d6 23 04 00    	call   *0x423d6(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2f78a:	47 89 74 af 08       	mov    %r14d,0x8(%r15,%r13,4)
   2f78f:	41 ff c4             	inc    %r12d
   2f792:	8b 84 24 d0 00 00 00 	mov    0xd0(%rsp),%eax
   2f799:	43 89 44 af 34       	mov    %eax,0x34(%r15,%r13,4)
   2f79e:	66 45 89 67 62       	mov    %r12w,0x62(%r15)
   2f7a3:	48 8b 03             	mov    (%rbx),%rax
   2f7a6:	31 c9                	xor    %ecx,%ecx
   2f7a8:	48 85 c0             	test   %rax,%rax
   2f7ab:	0f 84 4d 04 00 00    	je     2fbfe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x174e>
   2f7b1:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2f7b6:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2f7bb:	eb 24                	jmp    2f7e1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1331>
   2f7bd:	0f 1f 00             	nopl   (%rax)
   2f7c0:	48 8b 8c 24 88 02 00 	mov    0x288(%rsp),%rcx
   2f7c7:	00 
   2f7c8:	48 ff c1             	inc    %rcx
   2f7cb:	48 8b 03             	mov    (%rbx),%rax
   2f7ce:	48 85 c0             	test   %rax,%rax
   2f7d1:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2f7d6:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2f7db:	0f 84 27 04 00 00    	je     2fc08 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1758>
   2f7e1:	8b b4 24 88 01 00 00 	mov    0x188(%rsp),%esi
   2f7e8:	8b bc 24 8c 01 00 00 	mov    0x18c(%rsp),%edi
   2f7ef:	44 0f b7 4b 60       	movzwl 0x60(%rbx),%r9d
   2f7f4:	48 89 c3             	mov    %rax,%rbx
   2f7f7:	44 0f b7 50 62       	movzwl 0x62(%rax),%r10d
   2f7fc:	49 83 fa 0b          	cmp    $0xb,%r10
   2f800:	48 89 ac 24 60 02 00 	mov    %rbp,0x260(%rsp)
   2f807:	00 
   2f808:	89 b4 24 84 01 00 00 	mov    %esi,0x184(%rsp)
   2f80f:	89 bc 24 80 01 00 00 	mov    %edi,0x180(%rsp)
   2f816:	4c 89 94 24 50 02 00 	mov    %r10,0x250(%rsp)
   2f81d:	00 
   2f81e:	0f 82 95 04 00 00    	jb     2fcb9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1809>
   2f824:	66 41 83 f9 05       	cmp    $0x5,%r9w
   2f829:	48 89 8c 24 88 02 00 	mov    %rcx,0x288(%rsp)
   2f830:	00 
   2f831:	73 1d                	jae    2f850 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x13a0>
   2f833:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2f838:	b8 04 00 00 00       	mov    $0x4,%eax
   2f83d:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
   2f844:	00 
   2f845:	45 31 ff             	xor    %r15d,%r15d
   2f848:	eb 66                	jmp    2f8b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1400>
   2f84a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2f850:	49 83 f9 05          	cmp    $0x5,%r9
   2f854:	74 21                	je     2f877 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x13c7>
   2f856:	41 83 f9 06          	cmp    $0x6,%r9d
   2f85a:	75 2d                	jne    2f889 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x13d9>
   2f85c:	41 b7 01             	mov    $0x1,%r15b
   2f85f:	b8 05 00 00 00       	mov    $0x5,%eax
   2f864:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
   2f86b:	00 
   2f86c:	48 c7 44 24 60 00 00 	movq   $0x0,0x60(%rsp)
   2f873:	00 00 
   2f875:	eb 39                	jmp    2f8b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1400>
   2f877:	45 31 ff             	xor    %r15d,%r15d
   2f87a:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2f87f:	4c 89 8c 24 68 01 00 	mov    %r9,0x168(%rsp)
   2f886:	00 
   2f887:	eb 27                	jmp    2f8b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1400>
   2f889:	49 83 c1 f9          	add    $0xfffffffffffffff9,%r9
   2f88d:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2f892:	41 b7 01             	mov    $0x1,%r15b
   2f895:	b8 06 00 00 00       	mov    $0x6,%eax
   2f89a:	48 89 84 24 68 01 00 	mov    %rax,0x168(%rsp)
   2f8a1:	00 
   2f8a2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f8a9:	1f 84 00 00 00 00 00 
   2f8b0:	41 bc c8 00 00 00    	mov    $0xc8,%r12d
   2f8b6:	bf c8 00 00 00       	mov    $0xc8,%edi
   2f8bb:	ff 15 af 21 04 00    	call   *0x421af(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2f8c1:	48 85 c0             	test   %rax,%rax
   2f8c4:	0f 84 d8 31 00 00    	je     32aa2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45f2>
   2f8ca:	49 89 c5             	mov    %rax,%r13
   2f8cd:	48 89 c5             	mov    %rax,%rbp
   2f8d0:	49 c7 45 00 00 00 00 	movq   $0x0,0x0(%r13)
   2f8d7:	00 
   2f8d8:	0f b7 43 62          	movzwl 0x62(%rbx),%eax
   2f8dc:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
   2f8e3:	00 
   2f8e4:	49 89 cc             	mov    %rcx,%r12
   2f8e7:	49 f7 d4             	not    %r12
   2f8ea:	49 01 c4             	add    %rax,%r12
   2f8ed:	66 45 89 65 62       	mov    %r12w,0x62(%r13)
   2f8f2:	49 83 fc 0c          	cmp    $0xc,%r12
   2f8f6:	0f 83 f4 31 00 00    	jae    32af0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4640>
   2f8fc:	44 89 bc 24 48 02 00 	mov    %r15d,0x248(%rsp)
   2f903:	00 
   2f904:	44 8d 3c 8d 00 00 00 	lea    0x0(,%rcx,4),%r15d
   2f90b:	00 
   2f90c:	42 8b 44 3b 08       	mov    0x8(%rbx,%r15,1),%eax
   2f911:	89 84 24 8c 01 00 00 	mov    %eax,0x18c(%rsp)
   2f918:	42 8b 44 3b 34       	mov    0x34(%rbx,%r15,1),%eax
   2f91d:	89 84 24 88 01 00 00 	mov    %eax,0x188(%rsp)
   2f924:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
   2f928:	48 83 c6 0c          	add    $0xc,%rsi
   2f92c:	49 8d 7d 08          	lea    0x8(%r13),%rdi
   2f930:	49 c1 e4 02          	shl    $0x2,%r12
   2f934:	4c 89 e2             	mov    %r12,%rdx
   2f937:	ff 15 53 21 04 00    	call   *0x42153(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   2f93d:	4a 8d 34 3b          	lea    (%rbx,%r15,1),%rsi
   2f941:	48 83 c6 38          	add    $0x38,%rsi
   2f945:	49 8d 7d 34          	lea    0x34(%r13),%rdi
   2f949:	4c 89 e2             	mov    %r12,%rdx
   2f94c:	ff 15 3e 21 04 00    	call   *0x4213e(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   2f952:	48 8b 8c 24 68 01 00 	mov    0x168(%rsp),%rcx
   2f959:	00 
   2f95a:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2f95e:	44 0f b7 7d 62       	movzwl 0x62(%rbp),%r15d
   2f963:	4d 8d 67 01          	lea    0x1(%r15),%r12
   2f967:	49 83 ff 0b          	cmp    $0xb,%r15
   2f96b:	0f 87 9b 31 00 00    	ja     32b0c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x465c>
   2f971:	48 8b 84 24 50 02 00 	mov    0x250(%rsp),%rax
   2f978:	00 
   2f979:	29 c8                	sub    %ecx,%eax
   2f97b:	44 39 e0             	cmp    %r12d,%eax
   2f97e:	0f 85 bc 31 00 00    	jne    32b40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4690>
   2f984:	49 8d 7d 68          	lea    0x68(%r13),%rdi
   2f988:	48 8d 34 cb          	lea    (%rbx,%rcx,8),%rsi
   2f98c:	48 83 c6 70          	add    $0x70,%rsi
   2f990:	42 8d 14 e5 00 00 00 	lea    0x0(,%r12,8),%edx
   2f997:	00 
   2f998:	ff 15 f2 20 04 00    	call   *0x420f2(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   2f99e:	44 89 e0             	mov    %r12d,%eax
   2f9a1:	83 e0 03             	and    $0x3,%eax
   2f9a4:	66 41 83 ff 03       	cmp    $0x3,%r15w
   2f9a9:	73 15                	jae    2f9c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1510>
   2f9ab:	31 c9                	xor    %ecx,%ecx
   2f9ad:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2f9b2:	44 8b 8c 24 48 02 00 	mov    0x248(%rsp),%r9d
   2f9b9:	00 
   2f9ba:	eb 74                	jmp    2fa30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1580>
   2f9bc:	0f 1f 40 00          	nopl   0x0(%rax)
   2f9c0:	41 83 e4 1c          	and    $0x1c,%r12d
   2f9c4:	31 c9                	xor    %ecx,%ecx
   2f9c6:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2f9cb:	44 8b 8c 24 48 02 00 	mov    0x248(%rsp),%r9d
   2f9d2:	00 
   2f9d3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2f9da:	84 00 00 00 00 00 
   2f9e0:	48 8b 54 cd 68       	mov    0x68(%rbp,%rcx,8),%rdx
   2f9e5:	48 89 2a             	mov    %rbp,(%rdx)
   2f9e8:	89 ce                	mov    %ecx,%esi
   2f9ea:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2f9ee:	48 8b 54 cd 70       	mov    0x70(%rbp,%rcx,8),%rdx
   2f9f3:	48 89 2a             	mov    %rbp,(%rdx)
   2f9f6:	8d 7e 01             	lea    0x1(%rsi),%edi
   2f9f9:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2f9fd:	48 8b 54 cd 78       	mov    0x78(%rbp,%rcx,8),%rdx
   2fa02:	48 89 2a             	mov    %rbp,(%rdx)
   2fa05:	8d 7e 02             	lea    0x2(%rsi),%edi
   2fa08:	66 89 7a 60          	mov    %di,0x60(%rdx)
   2fa0c:	48 8b 94 cd 80 00 00 	mov    0x80(%rbp,%rcx,8),%rdx
   2fa13:	00 
   2fa14:	48 83 c1 04          	add    $0x4,%rcx
   2fa18:	48 89 2a             	mov    %rbp,(%rdx)
   2fa1b:	83 c6 03             	add    $0x3,%esi
   2fa1e:	66 89 72 60          	mov    %si,0x60(%rdx)
   2fa22:	4c 39 e1             	cmp    %r12,%rcx
   2fa25:	75 b9                	jne    2f9e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1530>
   2fa27:	48 85 c0             	test   %rax,%rax
   2fa2a:	74 18                	je     2fa44 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1594>
   2fa2c:	0f 1f 40 00          	nopl   0x0(%rax)
   2fa30:	48 8b 54 cd 68       	mov    0x68(%rbp,%rcx,8),%rdx
   2fa35:	48 89 2a             	mov    %rbp,(%rdx)
   2fa38:	66 89 4a 60          	mov    %cx,0x60(%rdx)
   2fa3c:	48 ff c1             	inc    %rcx
   2fa3f:	48 ff c8             	dec    %rax
   2fa42:	75 ec                	jne    2fa30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1580>
   2fa44:	45 84 c9             	test   %r9b,%r9b
   2fa47:	4c 0f 44 eb          	cmove  %rbx,%r13
   2fa4b:	45 0f b7 65 62       	movzwl 0x62(%r13),%r12d
   2fa50:	4d 8d 78 01          	lea    0x1(%r8),%r15
   2fa54:	4d 89 e1             	mov    %r12,%r9
   2fa57:	4d 29 c1             	sub    %r8,%r9
   2fa5a:	0f 86 c0 00 00 00    	jbe    2fb20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1670>
   2fa60:	49 8d 45 08          	lea    0x8(%r13),%rax
   2fa64:	4a 8d 34 85 08 00 00 	lea    0x8(,%r8,4),%rsi
   2fa6b:	00 
   2fa6c:	4c 01 ee             	add    %r13,%rsi
   2fa6f:	4a 8d 3c b8          	lea    (%rax,%r15,4),%rdi
   2fa73:	44 89 e0             	mov    %r12d,%eax
   2fa76:	44 29 c0             	sub    %r8d,%eax
   2fa79:	48 89 84 24 50 02 00 	mov    %rax,0x250(%rsp)
   2fa80:	00 
   2fa81:	8d 14 85 00 00 00 00 	lea    0x0(,%rax,4),%edx
   2fa88:	48 89 94 24 48 02 00 	mov    %rdx,0x248(%rsp)
   2fa8f:	00 
   2fa90:	4c 89 8c 24 68 01 00 	mov    %r9,0x168(%rsp)
   2fa97:	00 
   2fa98:	ff 15 c2 20 04 00    	call   *0x420c2(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2fa9e:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2faa3:	48 8d 34 85 34 00 00 	lea    0x34(,%rax,4),%rsi
   2faaa:	00 
   2faab:	4c 01 ee             	add    %r13,%rsi
   2faae:	4a 8d 3c bd 34 00 00 	lea    0x34(,%r15,4),%rdi
   2fab5:	00 
   2fab6:	4c 01 ef             	add    %r13,%rdi
   2fab9:	48 8b 94 24 48 02 00 	mov    0x248(%rsp),%rdx
   2fac0:	00 
   2fac1:	ff 15 99 20 04 00    	call   *0x42099(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2fac7:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2facc:	8b 8c 24 80 01 00 00 	mov    0x180(%rsp),%ecx
   2fad3:	41 89 4c 85 08       	mov    %ecx,0x8(%r13,%rax,4)
   2fad8:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fadd:	8b 8c 24 84 01 00 00 	mov    0x184(%rsp),%ecx
   2fae4:	41 89 4c 85 34       	mov    %ecx,0x34(%r13,%rax,4)
   2fae9:	4b 8d 74 fd 68       	lea    0x68(%r13,%r15,8),%rsi
   2faee:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2faf3:	48 8d 3c c5 78 00 00 	lea    0x78(,%rax,8),%rdi
   2fafa:	00 
   2fafb:	4c 01 ef             	add    %r13,%rdi
   2fafe:	48 8b 94 24 50 02 00 	mov    0x250(%rsp),%rdx
   2fb05:	00 
   2fb06:	c1 e2 03             	shl    $0x3,%edx
   2fb09:	ff 15 51 20 04 00    	call   *0x42051(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2fb0f:	4c 8b 8c 24 68 01 00 	mov    0x168(%rsp),%r9
   2fb16:	00 
   2fb17:	4c 8b 44 24 60       	mov    0x60(%rsp),%r8
   2fb1c:	eb 1a                	jmp    2fb38 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1688>
   2fb1e:	66 90                	xchg   %ax,%ax
   2fb20:	8b 84 24 80 01 00 00 	mov    0x180(%rsp),%eax
   2fb27:	43 89 44 85 08       	mov    %eax,0x8(%r13,%r8,4)
   2fb2c:	8b 84 24 84 01 00 00 	mov    0x184(%rsp),%eax
   2fb33:	43 89 44 85 34       	mov    %eax,0x34(%r13,%r8,4)
   2fb38:	48 8b 94 24 60 02 00 	mov    0x260(%rsp),%rdx
   2fb3f:	00 
   2fb40:	41 8d 4c 24 01       	lea    0x1(%r12),%ecx
   2fb45:	49 8d 44 24 02       	lea    0x2(%r12),%rax
   2fb4a:	4b 89 54 c5 70       	mov    %rdx,0x70(%r13,%r8,8)
   2fb4f:	66 41 89 4d 62       	mov    %cx,0x62(%r13)
   2fb54:	41 39 c7             	cmp    %eax,%r15d
   2fb57:	0f 83 63 fc ff ff    	jae    2f7c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1310>
   2fb5d:	45 29 c4             	sub    %r8d,%r12d
   2fb60:	41 ff c4             	inc    %r12d
   2fb63:	41 83 e4 03          	and    $0x3,%r12d
   2fb67:	74 31                	je     2fb9a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x16ea>
   2fb69:	4a 8d 14 c5 70 00 00 	lea    0x70(,%r8,8),%rdx
   2fb70:	00 
   2fb71:	4c 01 ea             	add    %r13,%rdx
   2fb74:	31 c9                	xor    %ecx,%ecx
   2fb76:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2fb7d:	00 00 00 
   2fb80:	48 8b 34 ca          	mov    (%rdx,%rcx,8),%rsi
   2fb84:	4c 89 2e             	mov    %r13,(%rsi)
   2fb87:	41 8d 3c 0f          	lea    (%r15,%rcx,1),%edi
   2fb8b:	66 89 7e 60          	mov    %di,0x60(%rsi)
   2fb8f:	48 ff c1             	inc    %rcx
   2fb92:	49 39 cc             	cmp    %rcx,%r12
   2fb95:	75 e9                	jne    2fb80 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x16d0>
   2fb97:	49 01 cf             	add    %rcx,%r15
   2fb9a:	41 83 f9 03          	cmp    $0x3,%r9d
   2fb9e:	0f 82 1c fc ff ff    	jb     2f7c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1310>
   2fba4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fbab:	00 00 00 00 00 
   2fbb0:	4b 8b 4c fd 68       	mov    0x68(%r13,%r15,8),%rcx
   2fbb5:	4c 89 29             	mov    %r13,(%rcx)
   2fbb8:	66 44 89 79 60       	mov    %r15w,0x60(%rcx)
   2fbbd:	4b 8b 4c fd 70       	mov    0x70(%r13,%r15,8),%rcx
   2fbc2:	4c 89 29             	mov    %r13,(%rcx)
   2fbc5:	41 8d 57 01          	lea    0x1(%r15),%edx
   2fbc9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fbcd:	4b 8b 4c fd 78       	mov    0x78(%r13,%r15,8),%rcx
   2fbd2:	4c 89 29             	mov    %r13,(%rcx)
   2fbd5:	41 8d 57 02          	lea    0x2(%r15),%edx
   2fbd9:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fbdd:	4b 8b 8c fd 80 00 00 	mov    0x80(%r13,%r15,8),%rcx
   2fbe4:	00 
   2fbe5:	4c 89 29             	mov    %r13,(%rcx)
   2fbe8:	41 8d 57 03          	lea    0x3(%r15),%edx
   2fbec:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fbf0:	49 83 c7 04          	add    $0x4,%r15
   2fbf4:	49 39 c7             	cmp    %rax,%r15
   2fbf7:	75 b7                	jne    2fbb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1700>
   2fbf9:	e9 c2 fb ff ff       	jmp    2f7c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1310>
   2fbfe:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2fc03:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2fc08:	48 89 cb             	mov    %rcx,%rbx
   2fc0b:	bf c8 00 00 00       	mov    $0xc8,%edi
   2fc10:	ff 15 5a 1e 04 00    	call   *0x41e5a(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   2fc16:	48 85 c0             	test   %rax,%rax
   2fc19:	0f 84 44 30 00 00    	je     32c63 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x47b3>
   2fc1f:	49 89 c4             	mov    %rax,%r12
   2fc22:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   2fc29:	66 c7 40 62 00 00    	movw   $0x0,0x62(%rax)
   2fc2f:	4c 89 78 68          	mov    %r15,0x68(%rax)
   2fc33:	48 8b 8c 24 e0 00 00 	mov    0xe0(%rsp),%rcx
   2fc3a:	00 
   2fc3b:	48 89 c8             	mov    %rcx,%rax
   2fc3e:	48 ff c0             	inc    %rax
   2fc41:	0f 84 31 30 00 00    	je     32c78 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x47c8>
   2fc47:	4d 89 27             	mov    %r12,(%r15)
   2fc4a:	66 41 c7 47 60 00 00 	movw   $0x0,0x60(%r15)
   2fc51:	4c 89 a4 24 08 02 00 	mov    %r12,0x208(%rsp)
   2fc58:	00 
   2fc59:	48 89 84 24 10 02 00 	mov    %rax,0x210(%rsp)
   2fc60:	00 
   2fc61:	48 39 cb             	cmp    %rcx,%rbx
   2fc64:	0f 85 20 30 00 00    	jne    32c8a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x47da>
   2fc6a:	66 41 c7 44 24 62 01 	movw   $0x1,0x62(%r12)
   2fc71:	00 
   2fc72:	8b 8c 24 8c 01 00 00 	mov    0x18c(%rsp),%ecx
   2fc79:	41 89 4c 24 08       	mov    %ecx,0x8(%r12)
   2fc7e:	8b 8c 24 88 01 00 00 	mov    0x188(%rsp),%ecx
   2fc85:	41 89 4c 24 34       	mov    %ecx,0x34(%r12)
   2fc8a:	49 89 6c 24 70       	mov    %rbp,0x70(%r12)
   2fc8f:	4c 89 65 00          	mov    %r12,0x0(%rbp)
   2fc93:	66 c7 45 60 01 00    	movw   $0x1,0x60(%rbp)
   2fc99:	48 89 84 24 e0 00 00 	mov    %rax,0xe0(%rsp)
   2fca0:	00 
   2fca1:	4d 89 e7             	mov    %r12,%r15
   2fca4:	48 8b ac 24 70 01 00 	mov    0x170(%rsp),%rbp
   2fcab:	00 
   2fcac:	44 8b a4 24 04 01 00 	mov    0x104(%rsp),%r12d
   2fcb3:	00 
   2fcb4:	e9 55 f8 ff ff       	jmp    2f50e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x105e>
   2fcb9:	49 89 e8             	mov    %rbp,%r8
   2fcbc:	49 8d 69 01          	lea    0x1(%r9),%rbp
   2fcc0:	66 45 39 d1          	cmp    %r10w,%r9w
   2fcc4:	0f 83 b9 00 00 00    	jae    2fd83 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x18d3>
   2fcca:	48 8d 7b 08          	lea    0x8(%rbx),%rdi
   2fcce:	4a 8d 34 8b          	lea    (%rbx,%r9,4),%rsi
   2fcd2:	48 83 c6 08          	add    $0x8,%rsi
   2fcd6:	44 8d 3c ad 00 00 00 	lea    0x0(,%rbp,4),%r15d
   2fcdd:	00 
   2fcde:	4c 01 ff             	add    %r15,%rdi
   2fce1:	4d 89 d4             	mov    %r10,%r12
   2fce4:	4d 29 cc             	sub    %r9,%r12
   2fce7:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
   2fcee:	00 
   2fcef:	48 8b 05 6a 1e 04 00 	mov    0x41e6a(%rip),%rax        # 71b60 <memmove@GLIBC_2.2.5>
   2fcf6:	4c 89 4c 24 60       	mov    %r9,0x60(%rsp)
   2fcfb:	ff d0                	call   *%rax
   2fcfd:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fd02:	44 8d 2c 85 00 00 00 	lea    0x0(,%rax,4),%r13d
   2fd09:	00 
   2fd0a:	4a 8d 34 2b          	lea    (%rbx,%r13,1),%rsi
   2fd0e:	48 83 c6 34          	add    $0x34,%rsi
   2fd12:	4a 8d 3c 3b          	lea    (%rbx,%r15,1),%rdi
   2fd16:	48 83 c7 34          	add    $0x34,%rdi
   2fd1a:	4a 8d 14 a5 00 00 00 	lea    0x0(,%r12,4),%rdx
   2fd21:	00 
   2fd22:	ff 15 38 1e 04 00    	call   *0x41e38(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2fd28:	8b 84 24 80 01 00 00 	mov    0x180(%rsp),%eax
   2fd2f:	42 89 44 2b 08       	mov    %eax,0x8(%rbx,%r13,1)
   2fd34:	8b 84 24 84 01 00 00 	mov    0x184(%rsp),%eax
   2fd3b:	42 89 44 2b 34       	mov    %eax,0x34(%rbx,%r13,1)
   2fd40:	4c 8b 6c 24 70       	mov    0x70(%rsp),%r13
   2fd45:	4c 8b 7c 24 28       	mov    0x28(%rsp),%r15
   2fd4a:	48 8d 34 eb          	lea    (%rbx,%rbp,8),%rsi
   2fd4e:	48 83 c6 68          	add    $0x68,%rsi
   2fd52:	48 8b 44 24 60       	mov    0x60(%rsp),%rax
   2fd57:	48 8d 3c c3          	lea    (%rbx,%rax,8),%rdi
   2fd5b:	48 83 c7 78          	add    $0x78,%rdi
   2fd5f:	49 c1 e4 03          	shl    $0x3,%r12
   2fd63:	4c 89 e2             	mov    %r12,%rdx
   2fd66:	ff 15 f4 1d 04 00    	call   *0x41df4(%rip)        # 71b60 <memmove@GLIBC_2.2.5>
   2fd6c:	4c 8b 94 24 50 02 00 	mov    0x250(%rsp),%r10
   2fd73:	00 
   2fd74:	4c 8b 84 24 60 02 00 	mov    0x260(%rsp),%r8
   2fd7b:	00 
   2fd7c:	4c 8b 4c 24 60       	mov    0x60(%rsp),%r9
   2fd81:	eb 0a                	jmp    2fd8d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x18dd>
   2fd83:	42 89 7c 8b 08       	mov    %edi,0x8(%rbx,%r9,4)
   2fd88:	42 89 74 8b 34       	mov    %esi,0x34(%rbx,%r9,4)
   2fd8d:	44 8b a4 24 04 01 00 	mov    0x104(%rsp),%r12d
   2fd94:	00 
   2fd95:	41 8d 4a 01          	lea    0x1(%r10),%ecx
   2fd99:	49 8d 42 02          	lea    0x2(%r10),%rax
   2fd9d:	4e 89 44 cb 70       	mov    %r8,0x70(%rbx,%r9,8)
   2fda2:	66 89 4b 62          	mov    %cx,0x62(%rbx)
   2fda6:	39 c5                	cmp    %eax,%ebp
   2fda8:	0f 83 97 00 00 00    	jae    2fe45 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1995>
   2fdae:	44 89 d1             	mov    %r10d,%ecx
   2fdb1:	44 29 c9             	sub    %r9d,%ecx
   2fdb4:	ff c1                	inc    %ecx
   2fdb6:	83 e1 03             	and    $0x3,%ecx
   2fdb9:	74 30                	je     2fdeb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x193b>
   2fdbb:	4a 8d 34 cb          	lea    (%rbx,%r9,8),%rsi
   2fdbf:	48 83 c6 70          	add    $0x70,%rsi
   2fdc3:	31 d2                	xor    %edx,%edx
   2fdc5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2fdcc:	00 00 00 00 
   2fdd0:	48 8b 3c d6          	mov    (%rsi,%rdx,8),%rdi
   2fdd4:	48 89 1f             	mov    %rbx,(%rdi)
   2fdd7:	44 8d 04 2a          	lea    (%rdx,%rbp,1),%r8d
   2fddb:	66 44 89 47 60       	mov    %r8w,0x60(%rdi)
   2fde0:	48 ff c2             	inc    %rdx
   2fde3:	48 39 d1             	cmp    %rdx,%rcx
   2fde6:	75 e8                	jne    2fdd0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1920>
   2fde8:	48 01 d5             	add    %rdx,%rbp
   2fdeb:	4d 29 ca             	sub    %r9,%r10
   2fdee:	41 83 fa 03          	cmp    $0x3,%r10d
   2fdf2:	72 51                	jb     2fe45 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1995>
   2fdf4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fdfb:	00 00 00 00 00 
   2fe00:	48 8b 4c eb 68       	mov    0x68(%rbx,%rbp,8),%rcx
   2fe05:	48 89 19             	mov    %rbx,(%rcx)
   2fe08:	66 89 69 60          	mov    %bp,0x60(%rcx)
   2fe0c:	48 8b 4c eb 70       	mov    0x70(%rbx,%rbp,8),%rcx
   2fe11:	48 89 19             	mov    %rbx,(%rcx)
   2fe14:	8d 55 01             	lea    0x1(%rbp),%edx
   2fe17:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fe1b:	48 8b 4c eb 78       	mov    0x78(%rbx,%rbp,8),%rcx
   2fe20:	48 89 19             	mov    %rbx,(%rcx)
   2fe23:	8d 55 02             	lea    0x2(%rbp),%edx
   2fe26:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fe2a:	48 8b 8c eb 80 00 00 	mov    0x80(%rbx,%rbp,8),%rcx
   2fe31:	00 
   2fe32:	48 89 19             	mov    %rbx,(%rcx)
   2fe35:	8d 55 03             	lea    0x3(%rbp),%edx
   2fe38:	66 89 51 60          	mov    %dx,0x60(%rcx)
   2fe3c:	48 83 c5 04          	add    $0x4,%rbp
   2fe40:	48 39 c5             	cmp    %rax,%rbp
   2fe43:	75 bb                	jne    2fe00 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1950>
   2fe45:	48 8b ac 24 70 01 00 	mov    0x170(%rsp),%rbp
   2fe4c:	00 
   2fe4d:	e9 bc f6 ff ff       	jmp    2f50e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x105e>
   2fe52:	ba 04 00 00 00       	mov    $0x4,%edx
   2fe57:	b9 01 00 00 00       	mov    $0x1,%ecx
   2fe5c:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2fe62:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
   2fe69:	00 
   2fe6a:	e8 41 ce ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fe6f:	48 8b 84 24 b8 01 00 	mov    0x1b8(%rsp),%rax
   2fe76:	00 
   2fe77:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
   2fe7e:	00 
   2fe7f:	e9 07 f7 ff ff       	jmp    2f58b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x10db>
   2fe84:	ba 04 00 00 00       	mov    $0x4,%edx
   2fe89:	b9 01 00 00 00       	mov    $0x1,%ecx
   2fe8e:	41 b8 01 00 00 00    	mov    $0x1,%r8d
   2fe94:	48 8d bc 24 b8 01 00 	lea    0x1b8(%rsp),%rdi
   2fe9b:	00 
   2fe9c:	e8 0f ce ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2fea1:	48 8b 8c 24 c0 01 00 	mov    0x1c0(%rsp),%rcx
   2fea8:	00 
   2fea9:	48 8b b4 24 c8 01 00 	mov    0x1c8(%rsp),%rsi
   2feb0:	00 
   2feb1:	e9 fa f6 ff ff       	jmp    2f5b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1100>
   2feb6:	48 c7 84 24 98 00 00 	movq   $0x0,0x98(%rsp)
   2febd:	00 00 00 00 00 
   2fec2:	45 31 ff             	xor    %r15d,%r15d
   2fec5:	4c 89 7c 24 28       	mov    %r15,0x28(%rsp)
   2feca:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   2fed1:	00 
   2fed2:	4d 85 e4             	test   %r12,%r12
   2fed5:	74 2a                	je     2ff01 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a51>
   2fed7:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   2fedc:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   2fee1:	4d 85 ff             	test   %r15,%r15
   2fee4:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   2feeb:	00 
   2feec:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   2fef3:	00 
   2fef4:	74 29                	je     2ff1f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a6f>
   2fef6:	49 83 ff 10          	cmp    $0x10,%r15
   2fefa:	73 2b                	jae    2ff27 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a77>
   2fefc:	45 31 e4             	xor    %r12d,%r12d
   2feff:	eb 37                	jmp    2ff38 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a88>
   2ff01:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2ff07:	45 31 ff             	xor    %r15d,%r15d
   2ff0a:	45 31 e4             	xor    %r12d,%r12d
   2ff0d:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   2ff14:	00 
   2ff15:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   2ff1c:	00 
   2ff1d:	eb 19                	jmp    2ff38 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a88>
   2ff1f:	45 31 ff             	xor    %r15d,%r15d
   2ff22:	45 31 e4             	xor    %r12d,%r12d
   2ff25:	eb 11                	jmp    2ff38 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a88>
   2ff27:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   2ff2c:	49 83 c4 18          	add    $0x18,%r12
   2ff30:	85 c0                	test   %eax,%eax
   2ff32:	0f 85 b6 2d 00 00    	jne    32cee <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x483e>
   2ff38:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2ff3f:	00 
   2ff40:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   2ff45:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   2ff4a:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   2ff4f:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2ff56:	00 00 
   2ff58:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   2ff5f:	00 
   2ff60:	48 89 e6             	mov    %rsp,%rsi
   2ff63:	e8 b8 d4 ff ff       	call   2d420 <_RINvXs1o_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB7_8BTreeMapllEINtNtNtNtCskADBYZwJmSU_4core4iter6traits7collect12FromIteratorTllEE9from_iterINtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2ff68:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   2ff6f:	00 
   2ff70:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   2ff77:	00 
   2ff78:	e8 43 65 00 00       	call   364c0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   2ff7d:	84 c0                	test   %al,%al
   2ff7f:	0f 84 47 2c 00 00    	je     32bcc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x471c>
   2ff85:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   2ff8c:	00 
   2ff8d:	48 85 d2             	test   %rdx,%rdx
   2ff90:	0f 84 86 00 00 00    	je     3001c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b6c>
   2ff96:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   2ff9d:	00 
   2ff9e:	48 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%rax
   2ffa5:	00 
   2ffa6:	48 8d 1c d1          	lea    (%rcx,%rdx,8),%rbx
   2ffaa:	48 8d 7a 01          	lea    0x1(%rdx),%rdi
   2ffae:	45 31 f6             	xor    %r14d,%r14d
   2ffb1:	48 89 c6             	mov    %rax,%rsi
   2ffb4:	49 39 d6             	cmp    %rdx,%r14
   2ffb7:	0f 84 c7 2b 00 00    	je     32b84 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x46d4>
   2ffbd:	4c 8d 69 08          	lea    0x8(%rcx),%r13
   2ffc1:	49 ff c6             	inc    %r14
   2ffc4:	4e 8d 04 f5 00 00 00 	lea    0x0(,%r14,8),%r8
   2ffcb:	00 
   2ffcc:	8b 29                	mov    (%rcx),%ebp
   2ffce:	49 39 c0             	cmp    %rax,%r8
   2ffd1:	0f 84 85 00 00 00    	je     3005c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1bac>
   2ffd7:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2ffdd:	0f 1f 00             	nopl   (%rax)
   2ffe0:	42 39 2c 01          	cmp    %ebp,(%rcx,%r8,1)
   2ffe4:	74 1a                	je     30000 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b50>
   2ffe6:	49 83 c0 08          	add    $0x8,%r8
   2ffea:	4c 39 c6             	cmp    %r8,%rsi
   2ffed:	75 f1                	jne    2ffe0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b30>
   2ffef:	eb 6b                	jmp    3005c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1bac>
   2fff1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2fff8:	0f 1f 84 00 00 00 00 
   2ffff:	00 
   30000:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   30004:	4c 89 e9             	mov    %r13,%rcx
   30007:	49 39 dd             	cmp    %rbx,%r13
   3000a:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   30011:	00 
   30012:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   30019:	00 
   3001a:	75 98                	jne    2ffb4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1b04>
   3001c:	48 c7 84 24 20 02 00 	movq   $0x0,0x220(%rsp)
   30023:	00 00 00 00 00 
   30028:	48 c7 84 24 28 02 00 	movq   $0x4,0x228(%rsp)
   3002f:	00 04 00 00 00 
   30034:	48 c7 84 24 30 02 00 	movq   $0x0,0x230(%rsp)
   3003b:	00 00 00 00 00 
   30040:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   30047:	00 
   30048:	4d 85 e4             	test   %r12,%r12
   3004b:	0f 85 89 01 00 00    	jne    301da <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d2a>
   30051:	41 be 04 00 00 00    	mov    $0x4,%r14d
   30057:	e9 98 01 00 00       	jmp    301f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d44>
   3005c:	44 8b 79 04          	mov    0x4(%rcx),%r15d
   30060:	bf 20 00 00 00       	mov    $0x20,%edi
   30065:	ff 15 05 1a 04 00    	call   *0x41a05(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3006b:	48 85 c0             	test   %rax,%rax
   3006e:	0f 84 31 2f 00 00    	je     32fa5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4af5>
   30074:	89 28                	mov    %ebp,(%rax)
   30076:	44 89 78 04          	mov    %r15d,0x4(%rax)
   3007a:	48 c7 04 24 04 00 00 	movq   $0x4,(%rsp)
   30081:	00 
   30082:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   30087:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   3008e:	00 00 
   30090:	49 39 dd             	cmp    %rbx,%r13
   30093:	0f 84 fa 00 00 00    	je     30193 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ce3>
   30099:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   3009f:	eb 29                	jmp    300ca <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c1a>
   300a1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   300a8:	0f 1f 84 00 00 00 00 
   300af:	00 
   300b0:	42 89 2c f8          	mov    %ebp,(%rax,%r15,8)
   300b4:	46 89 64 f8 04       	mov    %r12d,0x4(%rax,%r15,8)
   300b9:	49 ff c7             	inc    %r15
   300bc:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   300c1:	49 39 dd             	cmp    %rbx,%r13
   300c4:	0f 84 c9 00 00 00    	je     30193 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ce3>
   300ca:	48 8b 8c 24 d8 01 00 	mov    0x1d8(%rsp),%rcx
   300d1:	00 
   300d2:	48 8b 94 24 e0 01 00 	mov    0x1e0(%rsp),%rdx
   300d9:	00 
   300da:	4a 8d 3c f5 00 00 00 	lea    0x0(,%r14,8),%rdi
   300e1:	00 
   300e2:	4a 8d 0c f1          	lea    (%rcx,%r14,8),%rcx
   300e6:	48 83 c1 08          	add    $0x8,%rcx
   300ea:	48 8d 34 d5 00 00 00 	lea    0x0(,%rdx,8),%rsi
   300f1:	00 
   300f2:	48 29 fe             	sub    %rdi,%rsi
   300f5:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   300f9:	4c 89 ef             	mov    %r13,%rdi
   300fc:	4c 8d 6f 08          	lea    0x8(%rdi),%r13
   30100:	49 ff c6             	inc    %r14
   30103:	49 39 d6             	cmp    %rdx,%r14
   30106:	0f 87 1c 2a 00 00    	ja     32b28 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4678>
   3010c:	8b 2f                	mov    (%rdi),%ebp
   3010e:	74 50                	je     30160 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1cb0>
   30110:	45 31 c0             	xor    %r8d,%r8d
   30113:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3011a:	84 00 00 00 00 00 
   30120:	42 39 2c 01          	cmp    %ebp,(%rcx,%r8,1)
   30124:	74 1a                	je     30140 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c90>
   30126:	49 83 c0 08          	add    $0x8,%r8
   3012a:	4c 39 c6             	cmp    %r8,%rsi
   3012d:	75 f1                	jne    30120 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c70>
   3012f:	eb 2f                	jmp    30160 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1cb0>
   30131:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30138:	0f 1f 84 00 00 00 00 
   3013f:	00 
   30140:	48 83 c1 08          	add    $0x8,%rcx
   30144:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   30148:	4c 89 ef             	mov    %r13,%rdi
   3014b:	49 39 dd             	cmp    %rbx,%r13
   3014e:	75 ac                	jne    300fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c4c>
   30150:	eb 41                	jmp    30193 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ce3>
   30152:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30159:	1f 84 00 00 00 00 00 
   30160:	44 8b 67 04          	mov    0x4(%rdi),%r12d
   30164:	4c 3b 3c 24          	cmp    (%rsp),%r15
   30168:	0f 85 42 ff ff ff    	jne    300b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c00>
   3016e:	ba 01 00 00 00       	mov    $0x1,%edx
   30173:	b9 04 00 00 00       	mov    $0x4,%ecx
   30178:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   3017e:	48 89 e7             	mov    %rsp,%rdi
   30181:	4c 89 fe             	mov    %r15,%rsi
   30184:	e8 27 cb ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30189:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   3018e:	e9 1d ff ff ff       	jmp    300b0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1c00>
   30193:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   30198:	48 89 84 24 30 02 00 	mov    %rax,0x230(%rsp)
   3019f:	00 
   301a0:	48 8b 04 24          	mov    (%rsp),%rax
   301a4:	48 89 84 24 20 02 00 	mov    %rax,0x220(%rsp)
   301ab:	00 
   301ac:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   301b1:	48 89 84 24 28 02 00 	mov    %rax,0x228(%rsp)
   301b8:	00 
   301b9:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   301c0:	00 
   301c1:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   301c8:	00 
   301c9:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   301d0:	00 
   301d1:	4d 85 e4             	test   %r12,%r12
   301d4:	0f 84 77 fe ff ff    	je     30051 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ba1>
   301da:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   301df:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   301e4:	4d 85 ff             	test   %r15,%r15
   301e7:	74 0b                	je     301f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d44>
   301e9:	49 83 ff 10          	cmp    $0x10,%r15
   301ed:	73 0d                	jae    301fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d4c>
   301ef:	45 31 e4             	xor    %r12d,%r12d
   301f2:	eb 19                	jmp    3020d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d5d>
   301f4:	45 31 ff             	xor    %r15d,%r15d
   301f7:	45 31 e4             	xor    %r12d,%r12d
   301fa:	eb 11                	jmp    3020d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d5d>
   301fc:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   30201:	49 83 c4 18          	add    $0x18,%r12
   30205:	85 c0                	test   %eax,%eax
   30207:	0f 85 f4 2a 00 00    	jne    32d01 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4851>
   3020d:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   30214:	00 
   30215:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   3021a:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   3021f:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   30224:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   3022b:	00 00 
   3022d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30234:	00 
   30235:	48 89 e6             	mov    %rsp,%rsi
   30238:	e8 93 4f 00 00       	call   351d0 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEE9from_iterCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3023d:	48 8b 8c 24 b0 00 00 	mov    0xb0(%rsp),%rcx
   30244:	00 
   30245:	48 3b 8c 24 30 02 00 	cmp    0x230(%rsp),%rcx
   3024c:	00 
   3024d:	0f 85 85 27 00 00    	jne    329d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4528>
   30253:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   3025a:	00 
   3025b:	48 85 c9             	test   %rcx,%rcx
   3025e:	0f 84 90 00 00 00    	je     302f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e44>
   30264:	48 8b 84 24 28 02 00 	mov    0x228(%rsp),%rax
   3026b:	00 
   3026c:	48 83 f9 01          	cmp    $0x1,%rcx
   30270:	75 04                	jne    30276 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1dc6>
   30272:	31 d2                	xor    %edx,%edx
   30274:	eb 5e                	jmp    302d4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e24>
   30276:	48 89 ce             	mov    %rcx,%rsi
   30279:	48 83 e6 fe          	and    $0xfffffffffffffffe,%rsi
   3027d:	31 d2                	xor    %edx,%edx
   3027f:	90                   	nop
   30280:	f3 0f 7e 04 d7       	movq   (%rdi,%rdx,8),%xmm0
   30285:	f3 0f 7e 0c d0       	movq   (%rax,%rdx,8),%xmm1
   3028a:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   3028e:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   30293:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   30298:	41 83 f8 03          	cmp    $0x3,%r8d
   3029c:	0f 85 36 27 00 00    	jne    329d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4528>
   302a2:	f3 0f 7e 44 d7 08    	movq   0x8(%rdi,%rdx,8),%xmm0
   302a8:	f3 0f 7e 4c d0 08    	movq   0x8(%rax,%rdx,8),%xmm1
   302ae:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   302b2:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   302b7:	66 44 0f 50 c0       	movmskpd %xmm0,%r8d
   302bc:	41 83 f8 03          	cmp    $0x3,%r8d
   302c0:	0f 85 12 27 00 00    	jne    329d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4528>
   302c6:	48 83 c2 02          	add    $0x2,%rdx
   302ca:	48 39 d6             	cmp    %rdx,%rsi
   302cd:	75 b1                	jne    30280 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1dd0>
   302cf:	f6 c1 01             	test   $0x1,%cl
   302d2:	74 20                	je     302f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e44>
   302d4:	f3 0f 7e 04 d7       	movq   (%rdi,%rdx,8),%xmm0
   302d9:	f3 0f 7e 0c d0       	movq   (%rax,%rdx,8),%xmm1
   302de:	66 0f 76 c8          	pcmpeqd %xmm0,%xmm1
   302e2:	66 0f 70 c1 50       	pshufd $0x50,%xmm1,%xmm0
   302e7:	66 0f 50 c0          	movmskpd %xmm0,%eax
   302eb:	83 f8 03             	cmp    $0x3,%eax
   302ee:	0f 85 e4 26 00 00    	jne    329d8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4528>
   302f4:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
   302fb:	00 00 
   302fd:	74 06                	je     30305 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e55>
   302ff:	ff 15 7b 17 04 00    	call   *0x4177b(%rip)        # 71a80 <free@GLIBC_2.2.5>
   30305:	80 bc 24 cc 00 00 00 	cmpb   $0x0,0xcc(%rsp)
   3030c:	00 
   3030d:	0f 84 bf 00 00 00    	je     303d2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f22>
   30313:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   3031a:	00 
   3031b:	4d 85 e4             	test   %r12,%r12
   3031e:	74 1a                	je     3033a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e8a>
   30320:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   30325:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   3032a:	4d 85 ff             	test   %r15,%r15
   3032d:	74 11                	je     30340 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e90>
   3032f:	49 83 ff 10          	cmp    $0x10,%r15
   30333:	73 13                	jae    30348 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1e98>
   30335:	45 31 e4             	xor    %r12d,%r12d
   30338:	eb 1f                	jmp    30359 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ea9>
   3033a:	41 be 04 00 00 00    	mov    $0x4,%r14d
   30340:	45 31 ff             	xor    %r15d,%r15d
   30343:	45 31 e4             	xor    %r12d,%r12d
   30346:	eb 11                	jmp    30359 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ea9>
   30348:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   3034d:	49 83 c4 18          	add    $0x18,%r12
   30351:	85 c0                	test   %eax,%eax
   30353:	0f 85 0e 2a 00 00    	jne    32d67 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48b7>
   30359:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   30360:	00 
   30361:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   30366:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   3036b:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   30370:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   30377:	00 00 
   30379:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30380:	00 
   30381:	48 89 e6             	mov    %rsp,%rsi
   30384:	e8 f7 64 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30389:	83 bc 24 a0 00 00 00 	cmpl   $0x1,0xa0(%rsp)
   30390:	01 
   30391:	0f 85 60 28 00 00    	jne    32bf7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4747>
   30397:	83 bc 24 a8 00 00 00 	cmpl   $0x3,0xa8(%rsp)
   3039e:	03 
   3039f:	0f 94 c0             	sete   %al
   303a2:	83 bc 24 a4 00 00 00 	cmpl   $0x0,0xa4(%rsp)
   303a9:	00 
   303aa:	0f 85 3d 28 00 00    	jne    32bed <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x473d>
   303b0:	84 c0                	test   %al,%al
   303b2:	0f 84 3f 28 00 00    	je     32bf7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4747>
   303b8:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   303bd:	74 13                	je     303d2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f22>
   303bf:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   303c5:	74 0b                	je     303d2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f22>
   303c7:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   303cc:	ff 15 ae 16 04 00    	call   *0x416ae(%rip)        # 71a80 <free@GLIBC_2.2.5>
   303d2:	48 c7 84 24 e8 01 00 	movq   $0x0,0x1e8(%rsp)
   303d9:	00 00 00 00 00 
   303de:	48 8b 84 24 e0 01 00 	mov    0x1e0(%rsp),%rax
   303e5:	00 
   303e6:	48 85 c0             	test   %rax,%rax
   303e9:	74 6a                	je     30455 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fa5>
   303eb:	48 8b 9c 24 d8 01 00 	mov    0x1d8(%rsp),%rbx
   303f2:	00 
   303f3:	4c 8d 3c c3          	lea    (%rbx,%rax,8),%r15
   303f7:	4c 8d b4 24 e8 01 00 	lea    0x1e8(%rsp),%r14
   303fe:	00 
   303ff:	90                   	nop
   30400:	8b 33                	mov    (%rbx),%esi
   30402:	8b 53 04             	mov    0x4(%rbx),%edx
   30405:	4c 89 f7             	mov    %r14,%rdi
   30408:	e8 23 49 00 00       	call   34d30 <_RNvMso_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_3MapllE10push_entryCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3040d:	48 83 c3 08          	add    $0x8,%rbx
   30411:	4c 39 fb             	cmp    %r15,%rbx
   30414:	75 ea                	jne    30400 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f50>
   30416:	4c 8b a4 24 e8 01 00 	mov    0x1e8(%rsp),%r12
   3041d:	00 
   3041e:	4d 85 e4             	test   %r12,%r12
   30421:	74 32                	je     30455 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fa5>
   30423:	4d 8b 74 24 08       	mov    0x8(%r12),%r14
   30428:	4d 8b 7c 24 10       	mov    0x10(%r12),%r15
   3042d:	4d 85 ff             	test   %r15,%r15
   30430:	74 29                	je     3045b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fab>
   30432:	49 83 ff 10          	cmp    $0x10,%r15
   30436:	72 26                	jb     3045e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fae>
   30438:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   3043d:	49 83 c4 18          	add    $0x18,%r12
   30441:	85 c0                	test   %eax,%eax
   30443:	74 1c                	je     30461 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fb1>
   30445:	4c 89 e7             	mov    %r12,%rdi
   30448:	4c 89 f6             	mov    %r14,%rsi
   3044b:	4c 89 fa             	mov    %r15,%rdx
   3044e:	e8 89 8d ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30453:	eb 0c                	jmp    30461 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1fb1>
   30455:	41 be 04 00 00 00    	mov    $0x4,%r14d
   3045b:	45 31 ff             	xor    %r15d,%r15d
   3045e:	45 31 e4             	xor    %r12d,%r12d
   30461:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   30468:	00 
   30469:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   3046e:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   30473:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   30478:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   3047f:	00 00 
   30481:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30488:	00 
   30489:	48 89 e6             	mov    %rsp,%rsi
   3048c:	e8 8f cf ff ff       	call   2d420 <_RINvXs1o_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB7_8BTreeMapllEINtNtNtNtCskADBYZwJmSU_4core4iter6traits7collect12FromIteratorTllEE9from_iterINtNtCs8kuuWm0O9xc_4pbrs3map11MapViewIterllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30491:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30498:	00 
   30499:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   304a0:	00 
   304a1:	e8 1a 60 00 00       	call   364c0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   304a6:	84 c0                	test   %al,%al
   304a8:	0f 84 5b 27 00 00    	je     32c09 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4759>
   304ae:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   304b5:	00 
   304b6:	e8 c5 9d ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   304bb:	48 8b 8c 24 48 01 00 	mov    0x148(%rsp),%rcx
   304c2:	00 
   304c3:	48 85 c9             	test   %rcx,%rcx
   304c6:	0f 84 a1 00 00 00    	je     3056d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x20bd>
   304cc:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   304d3:	ff ff 1f 
   304d6:	48 8b 9c 24 30 01 00 	mov    0x130(%rsp),%rbx
   304dd:	00 
   304de:	66 0f 6f 03          	movdqa (%rbx),%xmm0
   304e2:	66 44 0f d7 e8       	pmovmskb %xmm0,%r13d
   304e7:	48 8d 6b 10          	lea    0x10(%rbx),%rbp
   304eb:	66 41 83 f5 ff       	xor    $0xffff,%r13w
   304f0:	75 27                	jne    30519 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2069>
   304f2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   304f9:	1f 84 00 00 00 00 00 
   30500:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   30505:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   30509:	48 83 c5 10          	add    $0x10,%rbp
   3050d:	66 44 0f d7 e8       	pmovmskb %xmm0,%r13d
   30512:	66 41 83 f5 ff       	xor    $0xffff,%r13w
   30517:	74 e7                	je     30500 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2050>
   30519:	48 83 f9 05          	cmp    $0x5,%rcx
   3051d:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   30523:	41 be 04 00 00 00    	mov    $0x4,%r14d
   30529:	4c 0f 43 f1          	cmovae %rcx,%r14
   3052d:	4e 8d 24 f5 00 00 00 	lea    0x0(,%r14,8),%r12
   30534:	00 
   30535:	48 ff c0             	inc    %rax
   30538:	48 39 c1             	cmp    %rax,%rcx
   3053b:	0f 97 c0             	seta   %al
   3053e:	48 89 ca             	mov    %rcx,%rdx
   30541:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   30548:	ff ff 7f 
   3054b:	48 83 c1 0b          	add    $0xb,%rcx
   3054f:	49 39 cc             	cmp    %rcx,%r12
   30552:	0f 97 c1             	seta   %cl
   30555:	08 c1                	or     %al,%cl
   30557:	74 31                	je     3058a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x20da>
   30559:	45 31 ff             	xor    %r15d,%r15d
   3055c:	4c 89 ff             	mov    %r15,%rdi
   3055f:	4c 89 e6             	mov    %r12,%rsi
   30562:	ff 15 50 15 04 00    	call   *0x41550(%rip)        # 71ab8 <_DYNAMIC+0x230>
   30568:	e9 dc 2b 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3056d:	48 c7 84 24 a0 00 00 	movq   $0x0,0xa0(%rsp)
   30574:	00 00 00 00 00 
   30579:	48 c7 84 24 b0 00 00 	movq   $0x0,0xb0(%rsp)
   30580:	00 00 00 00 00 
   30585:	e9 e6 01 00 00       	jmp    30770 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22c0>
   3058a:	48 89 54 24 70       	mov    %rdx,0x70(%rsp)
   3058f:	f3 41 0f bc c5       	tzcnt  %r13d,%eax
   30594:	c1 e0 03             	shl    $0x3,%eax
   30597:	48 89 d9             	mov    %rbx,%rcx
   3059a:	48 29 c1             	sub    %rax,%rcx
   3059d:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   305a2:	66 0f 7f 84 24 d0 00 	movdqa %xmm0,0xd0(%rsp)
   305a9:	00 00 
   305ab:	4c 89 e7             	mov    %r12,%rdi
   305ae:	ff 15 bc 14 04 00    	call   *0x414bc(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   305b4:	48 85 c0             	test   %rax,%rax
   305b7:	74 a3                	je     3055c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x20ac>
   305b9:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   305be:	49 89 cf             	mov    %rcx,%r15
   305c1:	66 0f 6f 84 24 d0 00 	movdqa 0xd0(%rsp),%xmm0
   305c8:	00 00 
   305ca:	66 0f d6 00          	movq   %xmm0,(%rax)
   305ce:	4c 89 34 24          	mov    %r14,(%rsp)
   305d2:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   305d7:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   305de:	00 00 
   305e0:	49 ff cf             	dec    %r15
   305e3:	0f 84 59 01 00 00    	je     30742 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2292>
   305e9:	45 8d 75 ff          	lea    -0x1(%r13),%r14d
   305ed:	45 21 ee             	and    %r13d,%r14d
   305f0:	b9 01 00 00 00       	mov    $0x1,%ecx
   305f5:	49 89 e4             	mov    %rsp,%r12
   305f8:	eb 35                	jmp    3062f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x217f>
   305fa:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   30600:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   30605:	41 8d 56 ff          	lea    -0x1(%r14),%edx
   30609:	44 21 f2             	and    %r14d,%edx
   3060c:	49 ff cf             	dec    %r15
   3060f:	66 0f 6f 84 24 d0 00 	movdqa 0xd0(%rsp),%xmm0
   30616:	00 00 
   30618:	66 42 0f d6 04 e8    	movq   %xmm0,(%rax,%r13,8)
   3061e:	49 8d 4d 01          	lea    0x1(%r13),%rcx
   30622:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   30627:	41 89 d6             	mov    %edx,%r14d
   3062a:	4d 85 ff             	test   %r15,%r15
   3062d:	74 69                	je     30698 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x21e8>
   3062f:	49 89 cd             	mov    %rcx,%r13
   30632:	66 45 85 f6          	test   %r14w,%r14w
   30636:	75 21                	jne    30659 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x21a9>
   30638:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   3063f:	00 
   30640:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   30645:	48 83 c3 80          	add    $0xffffffffffffff80,%rbx
   30649:	48 83 c5 10          	add    $0x10,%rbp
   3064d:	66 44 0f d7 f0       	pmovmskb %xmm0,%r14d
   30652:	66 41 83 f6 ff       	xor    $0xffff,%r14w
   30657:	74 e7                	je     30640 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2190>
   30659:	f3 41 0f bc ce       	tzcnt  %r14d,%ecx
   3065e:	c1 e1 03             	shl    $0x3,%ecx
   30661:	48 89 da             	mov    %rbx,%rdx
   30664:	48 29 ca             	sub    %rcx,%rdx
   30667:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   3066c:	0f 29 84 24 d0 00 00 	movaps %xmm0,0xd0(%rsp)
   30673:	00 
   30674:	4c 3b 2c 24          	cmp    (%rsp),%r13
   30678:	75 8b                	jne    30605 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2155>
   3067a:	b9 04 00 00 00       	mov    $0x4,%ecx
   3067f:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   30685:	4c 89 e7             	mov    %r12,%rdi
   30688:	4c 89 ee             	mov    %r13,%rsi
   3068b:	4c 89 fa             	mov    %r15,%rdx
   3068e:	e8 1d c6 ff ff       	call   2ccb0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30693:	e9 68 ff ff ff       	jmp    30600 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2150>
   30698:	4c 8b 34 24          	mov    (%rsp),%r14
   3069c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   306a1:	49 83 fd 14          	cmp    $0x14,%r13
   306a5:	0f 83 69 26 00 00    	jae    32d14 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4864>
   306ab:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   306b0:	48 8d 0c c8          	lea    (%rax,%rcx,8),%rcx
   306b4:	48 8d 78 08          	lea    0x8(%rax),%rdi
   306b8:	31 d2                	xor    %edx,%edx
   306ba:	49 89 c2             	mov    %rax,%r10
   306bd:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   306c4:	00 
   306c5:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   306cc:	00 
   306cd:	eb 20                	jmp    306ef <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x223f>
   306cf:	49 01 c1             	add    %rax,%r9
   306d2:	4d 89 cb             	mov    %r9,%r11
   306d5:	49 c1 e0 20          	shl    $0x20,%r8
   306d9:	49 09 f8             	or     %rdi,%r8
   306dc:	4d 89 03             	mov    %r8,(%r11)
   306df:	48 8d 7e 08          	lea    0x8(%rsi),%rdi
   306e3:	48 83 c2 08          	add    $0x8,%rdx
   306e7:	49 89 f2             	mov    %rsi,%r10
   306ea:	48 39 cf             	cmp    %rcx,%rdi
   306ed:	74 4c                	je     3073b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x228b>
   306ef:	48 89 fe             	mov    %rdi,%rsi
   306f2:	41 8b 7a 08          	mov    0x8(%r10),%edi
   306f6:	41 3b 3a             	cmp    (%r10),%edi
   306f9:	7d e4                	jge    306df <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x222f>
   306fb:	45 8b 42 0c          	mov    0xc(%r10),%r8d
   306ff:	4d 8b 0a             	mov    (%r10),%r9
   30702:	4d 89 4a 08          	mov    %r9,0x8(%r10)
   30706:	49 89 d1             	mov    %rdx,%r9
   30709:	49 89 c3             	mov    %rax,%r11
   3070c:	49 39 c2             	cmp    %rax,%r10
   3070f:	74 c4                	je     306d5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2225>
   30711:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30718:	0f 1f 84 00 00 00 00 
   3071f:	00 
   30720:	42 3b 7c 08 f8       	cmp    -0x8(%rax,%r9,1),%edi
   30725:	7d a8                	jge    306cf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x221f>
   30727:	4e 8b 54 08 f8       	mov    -0x8(%rax,%r9,1),%r10
   3072c:	4e 89 14 08          	mov    %r10,(%rax,%r9,1)
   30730:	49 83 c1 f8          	add    $0xfffffffffffffff8,%r9
   30734:	75 ea                	jne    30720 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2270>
   30736:	49 89 c3             	mov    %rax,%r11
   30739:	eb 9a                	jmp    306d5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2225>
   3073b:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   30740:	eb 10                	jmp    30752 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22a2>
   30742:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   30749:	00 
   3074a:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   30751:	00 
   30752:	4c 89 34 24          	mov    %r14,(%rsp)
   30756:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   3075b:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   30760:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30767:	00 
   30768:	48 89 e6             	mov    %rsp,%rsi
   3076b:	e8 20 92 ff ff       	call   29990 <_RINvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllE27bulk_build_from_sorted_iterINtNtBc_3vec3VecTllEEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30770:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30777:	00 
   30778:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   3077f:	00 
   30780:	e8 3b 5d 00 00       	call   364c0 <_RNvXs1t_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB6_8BTreeMapllENtNtCskADBYZwJmSU_4core3cmp9PartialEq2eqCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30785:	84 c0                	test   %al,%al
   30787:	0f 84 9d 24 00 00    	je     32c2a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x477a>
   3078d:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30794:	00 
   30795:	e8 e6 9a ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3079a:	4c 8b a4 24 10 01 00 	mov    0x110(%rsp),%r12
   307a1:	00 
   307a2:	4d 85 e4             	test   %r12,%r12
   307a5:	74 1a                	je     307c1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2311>
   307a7:	4d 8b 7c 24 08       	mov    0x8(%r12),%r15
   307ac:	4d 8b 74 24 10       	mov    0x10(%r12),%r14
   307b1:	4d 85 f6             	test   %r14,%r14
   307b4:	74 11                	je     307c7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2317>
   307b6:	49 83 fe 10          	cmp    $0x10,%r14
   307ba:	73 13                	jae    307cf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x231f>
   307bc:	45 31 e4             	xor    %r12d,%r12d
   307bf:	eb 1f                	jmp    307e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2330>
   307c1:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   307c7:	45 31 f6             	xor    %r14d,%r14d
   307ca:	45 31 e4             	xor    %r12d,%r12d
   307cd:	eb 11                	jmp    307e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2330>
   307cf:	41 8b 44 24 30       	mov    0x30(%r12),%eax
   307d4:	49 83 c4 18          	add    $0x18,%r12
   307d8:	85 c0                	test   %eax,%eax
   307da:	0f 85 61 25 00 00    	jne    32d41 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4891>
   307e0:	48 c7 84 24 90 01 00 	movq   $0x0,0x190(%rsp)
   307e7:	00 00 00 00 00 
   307ec:	4c 89 bc 24 98 01 00 	mov    %r15,0x198(%rsp)
   307f3:	00 
   307f4:	4c 89 b4 24 a0 01 00 	mov    %r14,0x1a0(%rsp)
   307fb:	00 
   307fc:	4c 89 a4 24 a8 01 00 	mov    %r12,0x1a8(%rsp)
   30803:	00 
   30804:	48 c7 84 24 b0 01 00 	movq   $0x0,0x1b0(%rsp)
   3080b:	00 00 00 00 00 
   30810:	4d 85 ed             	test   %r13,%r13
   30813:	0f 84 10 01 00 00    	je     30929 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2479>
   30819:	4c 89 eb             	mov    %r13,%rbx
   3081c:	31 ed                	xor    %ebp,%ebp
   3081e:	49 89 e4             	mov    %rsp,%r12
   30821:	4c 8d ac 24 90 01 00 	lea    0x190(%rsp),%r13
   30828:	00 
   30829:	4c 8d 35 d0 f9 03 00 	lea    0x3f9d0(%rip),%r14        # 70200 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8b0>
   30830:	4c 8d 3d b2 8d fd ff 	lea    -0x2724e(%rip),%r15        # 95e9 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x362>
   30837:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   3083e:	00 00 
   30840:	83 bc 24 90 01 00 00 	cmpl   $0x1,0x190(%rsp)
   30847:	01 
   30848:	75 26                	jne    30870 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23c0>
   3084a:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
   30851:	00 
   30852:	48 2b 8c 24 98 01 00 	sub    0x198(%rsp),%rcx
   30859:	00 
   3085a:	48 0f 42 cd          	cmovb  %rbp,%rcx
   3085e:	48 89 c8             	mov    %rcx,%rax
   30861:	be 44 00 00 00       	mov    $0x44,%esi
   30866:	48 39 d9             	cmp    %rbx,%rcx
   30869:	76 65                	jbe    308d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2420>
   3086b:	e9 82 21 00 00       	jmp    329f2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4542>
   30870:	48 8b 8c 24 a0 01 00 	mov    0x1a0(%rsp),%rcx
   30877:	00 
   30878:	48 89 ca             	mov    %rcx,%rdx
   3087b:	48 2b 94 24 b0 01 00 	sub    0x1b0(%rsp),%rdx
   30882:	00 
   30883:	b8 00 00 00 00       	mov    $0x0,%eax
   30888:	48 0f 43 c2          	cmovae %rdx,%rax
   3088c:	48 83 f9 02          	cmp    $0x2,%rcx
   30890:	72 13                	jb     308a5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x23f5>
   30892:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   30899:	00 
   3089a:	48 85 d2             	test   %rdx,%rdx
   3089d:	74 18                	je     308b7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2407>
   3089f:	48 39 4a 10          	cmp    %rcx,0x10(%rdx)
   308a3:	75 12                	jne    308b7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2407>
   308a5:	48 89 c1             	mov    %rax,%rcx
   308a8:	be 44 00 00 00       	mov    $0x44,%esi
   308ad:	48 39 d9             	cmp    %rbx,%rcx
   308b0:	76 1e                	jbe    308d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2420>
   308b2:	e9 3b 21 00 00       	jmp    329f2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4542>
   308b7:	31 c9                	xor    %ecx,%ecx
   308b9:	be 44 00 00 00       	mov    $0x44,%esi
   308be:	48 39 d9             	cmp    %rbx,%rcx
   308c1:	0f 87 2b 21 00 00    	ja     329f2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4542>
   308c7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   308ce:	00 00 
   308d0:	48 39 d8             	cmp    %rbx,%rax
   308d3:	0f 82 19 21 00 00    	jb     329f2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4542>
   308d9:	4c 89 e7             	mov    %r12,%rdi
   308dc:	4c 89 ee             	mov    %r13,%rsi
   308df:	e8 9c 5f 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   308e4:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   308e8:	0f 84 c7 21 00 00    	je     32ab5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4605>
   308ee:	48 ff cb             	dec    %rbx
   308f1:	0f 85 49 ff ff ff    	jne    30840 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2390>
   308f7:	80 bc 24 90 01 00 00 	cmpb   $0x0,0x190(%rsp)
   308fe:	00 
   308ff:	74 2c                	je     3092d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x247d>
   30901:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
   30908:	00 
   30909:	31 c0                	xor    %eax,%eax
   3090b:	48 2b 8c 24 98 01 00 	sub    0x198(%rsp),%rcx
   30912:	00 
   30913:	48 0f 43 c1          	cmovae %rcx,%rax
   30917:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   3091e:	00 
   3091f:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   30926:	00 
   30927:	eb 51                	jmp    3097a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x24ca>
   30929:	31 c9                	xor    %ecx,%ecx
   3092b:	eb 20                	jmp    3094d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x249d>
   3092d:	4c 8b b4 24 a0 01 00 	mov    0x1a0(%rsp),%r14
   30934:	00 
   30935:	48 8b 8c 24 b0 01 00 	mov    0x1b0(%rsp),%rcx
   3093c:	00 
   3093d:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   30944:	00 
   30945:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   3094c:	00 
   3094d:	31 c0                	xor    %eax,%eax
   3094f:	4c 89 f2             	mov    %r14,%rdx
   30952:	48 29 ca             	sub    %rcx,%rdx
   30955:	48 0f 43 c2          	cmovae %rdx,%rax
   30959:	49 83 fe 02          	cmp    $0x2,%r14
   3095d:	72 1b                	jb     3097a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x24ca>
   3095f:	48 8b 94 24 a8 01 00 	mov    0x1a8(%rsp),%rdx
   30966:	00 
   30967:	48 85 d2             	test   %rdx,%rdx
   3096a:	0f 84 f7 09 00 00    	je     31367 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2eb7>
   30970:	4c 39 72 10          	cmp    %r14,0x10(%rdx)
   30974:	0f 85 ed 09 00 00    	jne    31367 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2eb7>
   3097a:	48 89 04 24          	mov    %rax,(%rsp)
   3097e:	48 c7 44 24 08 01 00 	movq   $0x1,0x8(%rsp)
   30985:	00 00 
   30987:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   3098c:	48 85 c0             	test   %rax,%rax
   3098f:	0f 85 f1 09 00 00    	jne    31386 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ed6>
   30995:	48 89 e7             	mov    %rsp,%rdi
   30998:	48 8d b4 24 90 01 00 	lea    0x190(%rsp),%rsi
   3099f:	00 
   309a0:	e8 db 5e 00 00       	call   36880 <_RNvXsM_NtCs8kuuWm0O9xc_4pbrs3mapINtB5_11MapViewIterllENtNtNtNtCskADBYZwJmSU_4core4iter6traits8iterator8Iterator4nextCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   309a5:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   309a9:	0f 85 9c 22 00 00    	jne    32c4b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x479b>
   309af:	45 31 d2             	xor    %r10d,%r10d
   309b2:	4d 85 ed             	test   %r13,%r13
   309b5:	0f 84 a2 01 00 00    	je     30b5d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26ad>
   309bb:	48 83 7c 24 28 00    	cmpq   $0x0,0x28(%rsp)
   309c1:	0f 84 96 01 00 00    	je     30b5d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26ad>
   309c7:	31 c9                	xor    %ecx,%ecx
   309c9:	45 31 d2             	xor    %r10d,%r10d
   309cc:	4c 89 e8             	mov    %r13,%rax
   309cf:	eb 3f                	jmp    30a10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2560>
   309d1:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   309d8:	0f 1f 84 00 00 00 00 
   309df:	00 
   309e0:	48 8d 75 01          	lea    0x1(%rbp),%rsi
   309e4:	48 89 d1             	mov    %rdx,%rcx
   309e7:	48 ff c8             	dec    %rax
   309ea:	48 63 7c aa 08       	movslq 0x8(%rdx,%rbp,4),%rdi
   309ef:	49 01 fa             	add    %rdi,%r10
   309f2:	48 63 54 aa 34       	movslq 0x34(%rdx,%rbp,4),%rdx
   309f7:	49 01 d2             	add    %rdx,%r10
   309fa:	ba 00 00 00 00       	mov    $0x0,%edx
   309ff:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   30a04:	48 89 f5             	mov    %rsi,%rbp
   30a07:	48 85 c0             	test   %rax,%rax
   30a0a:	0f 84 4d 01 00 00    	je     30b5d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x26ad>
   30a10:	48 85 c9             	test   %rcx,%rcx
   30a13:	74 1b                	je     30a30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2580>
   30a15:	4c 8b 4c 24 28       	mov    0x28(%rsp),%r9
   30a1a:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   30a1e:	48 39 d5             	cmp    %rdx,%rbp
   30a21:	0f 83 89 00 00 00    	jae    30ab0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2600>
   30a27:	48 89 ca             	mov    %rcx,%rdx
   30a2a:	e9 9d 00 00 00       	jmp    30acc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x261c>
   30a2f:	90                   	nop
   30a30:	48 85 ed             	test   %rbp,%rbp
   30a33:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   30a38:	74 5c                	je     30a96 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25e6>
   30a3a:	48 89 ea             	mov    %rbp,%rdx
   30a3d:	48 83 e2 07          	and    $0x7,%rdx
   30a41:	0f 84 04 01 00 00    	je     30b4b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x269b>
   30a47:	31 f6                	xor    %esi,%esi
   30a49:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30a50:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a54:	48 ff c6             	inc    %rsi
   30a57:	48 39 f2             	cmp    %rsi,%rdx
   30a5a:	75 f4                	jne    30a50 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25a0>
   30a5c:	48 89 ea             	mov    %rbp,%rdx
   30a5f:	48 29 f2             	sub    %rsi,%rdx
   30a62:	48 83 fd 08          	cmp    $0x8,%rbp
   30a66:	72 2e                	jb     30a96 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25e6>
   30a68:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   30a6f:	00 
   30a70:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a74:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a78:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a7c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a80:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a84:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a88:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a8c:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30a90:	48 83 c2 f8          	add    $0xfffffffffffffff8,%rdx
   30a94:	75 da                	jne    30a70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25c0>
   30a96:	31 ed                	xor    %ebp,%ebp
   30a98:	45 31 c9             	xor    %r9d,%r9d
   30a9b:	0f b7 51 62          	movzwl 0x62(%rcx),%edx
   30a9f:	48 39 d5             	cmp    %rdx,%rbp
   30aa2:	72 83                	jb     30a27 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2577>
   30aa4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   30aab:	00 00 00 00 00 
   30ab0:	48 8b 11             	mov    (%rcx),%rdx
   30ab3:	48 85 d2             	test   %rdx,%rdx
   30ab6:	0f 84 20 22 00 00    	je     32cdc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x482c>
   30abc:	49 ff c1             	inc    %r9
   30abf:	0f b7 69 60          	movzwl 0x60(%rcx),%ebp
   30ac3:	48 89 d1             	mov    %rdx,%rcx
   30ac6:	66 3b 6a 62          	cmp    0x62(%rdx),%bp
   30aca:	73 e4                	jae    30ab0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2600>
   30acc:	4d 85 c9             	test   %r9,%r9
   30acf:	0f 84 0b ff ff ff    	je     309e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2530>
   30ad5:	48 8d 34 ea          	lea    (%rdx,%rbp,8),%rsi
   30ad9:	48 83 c6 70          	add    $0x70,%rsi
   30add:	4c 89 cf             	mov    %r9,%rdi
   30ae0:	48 83 e7 07          	and    $0x7,%rdi
   30ae4:	74 5a                	je     30b40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2690>
   30ae6:	45 31 c0             	xor    %r8d,%r8d
   30ae9:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   30af0:	48 8b 0e             	mov    (%rsi),%rcx
   30af3:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30af7:	49 ff c0             	inc    %r8
   30afa:	4c 39 c7             	cmp    %r8,%rdi
   30afd:	75 f1                	jne    30af0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2640>
   30aff:	4c 89 cf             	mov    %r9,%rdi
   30b02:	4c 29 c7             	sub    %r8,%rdi
   30b05:	49 83 f9 08          	cmp    $0x8,%r9
   30b09:	72 2e                	jb     30b39 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2689>
   30b0b:	0f 1f 44 00 00       	nopl   0x0(%rax,%rax,1)
   30b10:	48 8b 0e             	mov    (%rsi),%rcx
   30b13:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b17:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b1b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b1f:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b23:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b27:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b2b:	48 8b 49 68          	mov    0x68(%rcx),%rcx
   30b2f:	48 8d 71 68          	lea    0x68(%rcx),%rsi
   30b33:	48 83 c7 f8          	add    $0xfffffffffffffff8,%rdi
   30b37:	75 d7                	jne    30b10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2660>
   30b39:	31 f6                	xor    %esi,%esi
   30b3b:	e9 a7 fe ff ff       	jmp    309e7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2537>
   30b40:	4c 89 cf             	mov    %r9,%rdi
   30b43:	49 83 f9 08          	cmp    $0x8,%r9
   30b47:	73 c7                	jae    30b10 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2660>
   30b49:	eb ee                	jmp    30b39 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2689>
   30b4b:	48 89 ea             	mov    %rbp,%rdx
   30b4e:	48 83 fd 08          	cmp    $0x8,%rbp
   30b52:	0f 83 18 ff ff ff    	jae    30a70 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25c0>
   30b58:	e9 39 ff ff ff       	jmp    30a96 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x25e6>
   30b5d:	4c 89 94 24 78 01 00 	mov    %r10,0x178(%rsp)
   30b64:	00 
   30b65:	48 83 7c 24 68 00    	cmpq   $0x0,0x68(%rsp)
   30b6b:	0f 84 5d 07 00 00    	je     312ce <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2e1e>
   30b71:	48 8d 84 24 68 02 00 	lea    0x268(%rsp),%rax
   30b78:	00 
   30b79:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   30b80:	00 
   30b81:	48 8d 84 24 10 01 00 	lea    0x110(%rsp),%rax
   30b88:	00 
   30b89:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   30b90:	00 
   30b91:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
   30b98:	00 
   30b99:	48 89 84 24 b0 00 00 	mov    %rax,0xb0(%rsp)
   30ba0:	00 
   30ba1:	48 8d 84 24 d0 01 00 	lea    0x1d0(%rsp),%rax
   30ba8:	00 
   30ba9:	48 89 84 24 b8 00 00 	mov    %rax,0xb8(%rsp)
   30bb0:	00 
   30bb1:	48 8d 84 24 30 01 00 	lea    0x130(%rsp),%rax
   30bb8:	00 
   30bb9:	48 89 84 24 c0 00 00 	mov    %rax,0xc0(%rsp)
   30bc0:	00 
   30bc1:	bd 64 00 00 00       	mov    $0x64,%ebp
   30bc6:	48 8d 9c 24 a0 00 00 	lea    0xa0(%rsp),%rbx
   30bcd:	00 
   30bce:	66 90                	xchg   %ax,%ax
   30bd0:	48 89 df             	mov    %rbx,%rdi
   30bd3:	e8 78 ce ff ff       	call   2da50 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_>
   30bd8:	ff cd                	dec    %ebp
   30bda:	75 f4                	jne    30bd0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2720>
   30bdc:	48 c7 84 24 f0 01 00 	movq   $0x0,0x1f0(%rsp)
   30be3:	00 00 00 00 00 
   30be8:	48 c7 84 24 f8 01 00 	movq   $0x8,0x1f8(%rsp)
   30bef:	00 08 00 00 00 
   30bf4:	48 c7 84 24 00 02 00 	movq   $0x0,0x200(%rsp)
   30bfb:	00 00 00 00 00 
   30c00:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   30c05:	48 c7 84 24 d0 00 00 	movq   $0x0,0xd0(%rsp)
   30c0c:	00 00 00 00 00 
   30c11:	eb 57                	jmp    30c6a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x27ba>
   30c13:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   30c1a:	84 00 00 00 00 00 
   30c20:	48 8b 84 24 f8 01 00 	mov    0x1f8(%rsp),%rax
   30c27:	00 
   30c28:	48 89 d9             	mov    %rbx,%rcx
   30c2b:	48 c1 e1 05          	shl    $0x5,%rcx
   30c2f:	66 0f 10 44 24 78    	movupd 0x78(%rsp),%xmm0
   30c35:	f3 0f 6f 8c 24 88 00 	movdqu 0x88(%rsp),%xmm1
   30c3c:	00 00 
   30c3e:	f3 0f 7f 4c 08 10    	movdqu %xmm1,0x10(%rax,%rcx,1)
   30c44:	66 0f 11 04 08       	movupd %xmm0,(%rax,%rcx,1)
   30c49:	48 ff c3             	inc    %rbx
   30c4c:	48 89 9c 24 00 02 00 	mov    %rbx,0x200(%rsp)
   30c53:	00 
   30c54:	48 8b 84 24 d0 00 00 	mov    0xd0(%rsp),%rax
   30c5b:	00 
   30c5c:	48 3b 84 24 90 02 00 	cmp    0x290(%rsp),%rax
   30c63:	00 
   30c64:	0f 84 13 05 00 00    	je     3117d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ccd>
   30c6a:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   30c6e:	66 0f 29 04 24       	movapd %xmm0,(%rsp)
   30c73:	bf 02 00 00 00       	mov    $0x2,%edi
   30c78:	48 89 e6             	mov    %rsp,%rsi
   30c7b:	ff 15 1f 12 04 00    	call   *0x4121f(%rip)        # 71ea0 <clock_gettime@GLIBC_2.17>
   30c81:	89 44 24 30          	mov    %eax,0x30(%rsp)
   30c85:	85 c0                	test   %eax,%eax
   30c87:	0f 85 43 1e 00 00    	jne    32ad0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4620>
   30c8d:	4c 8b 2c 24          	mov    (%rsp),%r13
   30c91:	4c 8b 7c 24 08       	mov    0x8(%rsp),%r15
   30c96:	bf 01 00 00 00       	mov    $0x1,%edi
   30c9b:	e8 80 3f 02 00       	call   54c20 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   30ca0:	48 89 c3             	mov    %rax,%rbx
   30ca3:	89 d5                	mov    %edx,%ebp
   30ca5:	48 ff 84 24 d0 00 00 	incq   0xd0(%rsp)
   30cac:	00 
   30cad:	45 31 f6             	xor    %r14d,%r14d
   30cb0:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   30cb7:	00 
   30cb8:	e8 93 cd ff ff       	call   2da50 <_RNCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains1_0B3_>
   30cbd:	49 ff c6             	inc    %r14
   30cc0:	4c 39 74 24 68       	cmp    %r14,0x68(%rsp)
   30cc5:	75 e9                	jne    30cb0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2800>
   30cc7:	bf 01 00 00 00       	mov    $0x1,%edi
   30ccc:	e8 4f 3f 02 00       	call   54c20 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec3now.llvm.4795996092214488023>
   30cd1:	48 89 44 24 78       	mov    %rax,0x78(%rsp)
   30cd6:	89 94 24 80 00 00 00 	mov    %edx,0x80(%rsp)
   30cdd:	48 89 5c 24 30       	mov    %rbx,0x30(%rsp)
   30ce2:	89 6c 24 38          	mov    %ebp,0x38(%rsp)
   30ce6:	48 89 e7             	mov    %rsp,%rdi
   30ce9:	48 8d 74 24 78       	lea    0x78(%rsp),%rsi
   30cee:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   30cf3:	e8 68 3e 02 00       	call   54b60 <_RNvMNtNtNtNtCs8ZKwes1zzDd_3std3sys3pal4unix4timeNtB2_8Timespec12sub_timespec.llvm.4795996092214488023>
   30cf8:	8b 4c 24 10          	mov    0x10(%rsp),%ecx
   30cfc:	b8 00 ca 9a 3b       	mov    $0x3b9aca00,%eax
   30d01:	48 f7 64 24 08       	mulq   0x8(%rsp)
   30d06:	48 89 d3             	mov    %rdx,%rbx
   30d09:	49 89 c6             	mov    %rax,%r14
   30d0c:	49 01 ce             	add    %rcx,%r14
   30d0f:	48 83 d3 00          	adc    $0x0,%rbx
   30d13:	80 3c 24 00          	cmpb   $0x0,(%rsp)
   30d17:	b8 00 00 00 00       	mov    $0x0,%eax
   30d1c:	4c 0f 45 f0          	cmovne %rax,%r14
   30d20:	48 0f 45 d8          	cmovne %rax,%rbx
   30d24:	66 0f 57 c0          	xorpd  %xmm0,%xmm0
   30d28:	66 0f 29 04 24       	movapd %xmm0,(%rsp)
   30d2d:	bf 02 00 00 00       	mov    $0x2,%edi
   30d32:	48 89 e6             	mov    %rsp,%rsi
   30d35:	ff 15 65 11 04 00    	call   *0x41165(%rip)        # 71ea0 <clock_gettime@GLIBC_2.17>
   30d3b:	89 44 24 30          	mov    %eax,0x30(%rsp)
   30d3f:	85 c0                	test   %eax,%eax
   30d41:	0f 85 84 1d 00 00    	jne    32acb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x461b>
   30d47:	4c 89 74 24 70       	mov    %r14,0x70(%rsp)
   30d4c:	48 89 5c 24 28       	mov    %rbx,0x28(%rsp)
   30d51:	4c 89 f9             	mov    %r15,%rcx
   30d54:	48 c1 f9 3f          	sar    $0x3f,%rcx
   30d58:	4c 89 ea             	mov    %r13,%rdx
   30d5b:	48 c1 fa 3f          	sar    $0x3f,%rdx
   30d5f:	48 8b 04 24          	mov    (%rsp),%rax
   30d63:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   30d68:	48 89 c6             	mov    %rax,%rsi
   30d6b:	48 c1 fe 3f          	sar    $0x3f,%rsi
   30d6f:	4d 89 f4             	mov    %r14,%r12
   30d72:	49 c1 fc 3f          	sar    $0x3f,%r12
   30d76:	4c 29 e8             	sub    %r13,%rax
   30d79:	48 19 d6             	sbb    %rdx,%rsi
   30d7c:	ba 00 ca 9a 3b       	mov    $0x3b9aca00,%edx
   30d81:	48 f7 e2             	mul    %rdx
   30d84:	48 69 f6 00 ca 9a 3b 	imul   $0x3b9aca00,%rsi,%rsi
   30d8b:	48 01 d6             	add    %rdx,%rsi
   30d8e:	4d 29 fe             	sub    %r15,%r14
   30d91:	49 19 cc             	sbb    %rcx,%r12
   30d94:	49 01 c6             	add    %rax,%r14
   30d97:	49 11 f4             	adc    %rsi,%r12
   30d9a:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
   30da1:	00 00 00 00 00 
   30da6:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   30dad:	00 00 00 00 00 
   30db2:	41 bf 0a 00 00 00    	mov    $0xa,%r15d
   30db8:	bf 0a 00 00 00       	mov    $0xa,%edi
   30dbd:	ff 15 ad 0c 04 00    	call   *0x40cad(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30dc3:	48 85 c0             	test   %rax,%rax
   30dc6:	0f 84 88 1f 00 00    	je     32d54 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48a4>
   30dcc:	48 89 c3             	mov    %rax,%rbx
   30dcf:	48 b8 69 74 65 72 61 	movabs $0x6f69746172657469,%rax
   30dd6:	74 69 6f 
   30dd9:	48 89 03             	mov    %rax,(%rbx)
   30ddc:	66 c7 43 08 6e 73    	movw   $0x736e,0x8(%rbx)
   30de2:	48 c7 84 24 e8 00 00 	movq   $0xa,0xe8(%rsp)
   30de9:	00 0a 00 00 00 
   30dee:	48 89 9c 24 f0 00 00 	mov    %rbx,0xf0(%rsp)
   30df5:	00 
   30df6:	48 c7 84 24 f8 00 00 	movq   $0xa,0xf8(%rsp)
   30dfd:	00 0a 00 00 00 
   30e02:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   30e07:	48 89 e6             	mov    %rsp,%rsi
   30e0a:	ff 15 d8 0f 04 00    	call   *0x40fd8(%rip)        # 71de8 <_DYNAMIC+0x560>
   30e10:	49 89 c5             	mov    %rax,%r13
   30e13:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   30e17:	49 f7 df             	neg    %r15
   30e1a:	bd 01 00 00 00       	mov    $0x1,%ebp
   30e1f:	48 83 f8 14          	cmp    $0x14,%rax
   30e23:	74 25                	je     30e4a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x299a>
   30e25:	4c 89 ff             	mov    %r15,%rdi
   30e28:	ff 15 42 0c 04 00    	call   *0x40c42(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30e2e:	48 85 c0             	test   %rax,%rax
   30e31:	0f 84 d7 1f 00 00    	je     32e0e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x495e>
   30e37:	48 89 c5             	mov    %rax,%rbp
   30e3a:	4a 8d 34 2c          	lea    (%rsp,%r13,1),%rsi
   30e3e:	48 89 c7             	mov    %rax,%rdi
   30e41:	4c 89 fa             	mov    %r15,%rdx
   30e44:	ff 15 46 0c 04 00    	call   *0x40c46(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   30e4a:	48 89 6c 24 10       	mov    %rbp,0x10(%rsp)
   30e4f:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   30e54:	c6 04 24 02          	movb   $0x2,(%rsp)
   30e58:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   30e5d:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   30e62:	4c 89 ef             	mov    %r13,%rdi
   30e65:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   30e6c:	00 
   30e6d:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   30e74:	00 
   30e75:	48 89 e1             	mov    %rsp,%rcx
   30e78:	e8 23 2d 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30e7d:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   30e82:	48 8b ac 24 70 01 00 	mov    0x170(%rsp),%rbp
   30e89:	00 
   30e8a:	74 08                	je     30e94 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x29e4>
   30e8c:	4c 89 ef             	mov    %r13,%rdi
   30e8f:	e8 5c 97 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30e94:	41 bf 06 00 00 00    	mov    $0x6,%r15d
   30e9a:	bf 06 00 00 00       	mov    $0x6,%edi
   30e9f:	ff 15 cb 0b 04 00    	call   *0x40bcb(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30ea5:	48 85 c0             	test   %rax,%rax
   30ea8:	0f 84 a6 1e 00 00    	je     32d54 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48a4>
   30eae:	48 89 c3             	mov    %rax,%rbx
   30eb1:	66 c7 40 04 6e 73    	movw   $0x736e,0x4(%rax)
   30eb7:	c7 00 63 70 75 5f    	movl   $0x5f757063,(%rax)
   30ebd:	48 c7 84 24 e8 00 00 	movq   $0x6,0xe8(%rsp)
   30ec4:	00 06 00 00 00 
   30ec9:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   30ed0:	00 
   30ed1:	48 c7 84 24 f8 00 00 	movq   $0x6,0xf8(%rsp)
   30ed8:	00 06 00 00 00 
   30edd:	4c 89 f7             	mov    %r14,%rdi
   30ee0:	4c 89 e6             	mov    %r12,%rsi
   30ee3:	48 89 e2             	mov    %rsp,%rdx
   30ee6:	ff 15 ec 0e 04 00    	call   *0x40eec(%rip)        # 71dd8 <_DYNAMIC+0x550>
   30eec:	49 89 c4             	mov    %rax,%r12
   30eef:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   30ef3:	49 f7 de             	neg    %r14
   30ef6:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30efc:	48 83 f8 27          	cmp    $0x27,%rax
   30f00:	74 25                	je     30f27 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2a77>
   30f02:	4c 89 f7             	mov    %r14,%rdi
   30f05:	ff 15 65 0b 04 00    	call   *0x40b65(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30f0b:	48 85 c0             	test   %rax,%rax
   30f0e:	0f 84 e7 1e 00 00    	je     32dfb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x494b>
   30f14:	49 89 c7             	mov    %rax,%r15
   30f17:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30f1b:	48 89 c7             	mov    %rax,%rdi
   30f1e:	4c 89 f2             	mov    %r14,%rdx
   30f21:	ff 15 69 0b 04 00    	call   *0x40b69(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   30f27:	c6 04 24 02          	movb   $0x2,(%rsp)
   30f2b:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   30f30:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   30f35:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   30f3a:	4c 89 ef             	mov    %r13,%rdi
   30f3d:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   30f44:	00 
   30f45:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   30f4c:	00 
   30f4d:	48 89 e1             	mov    %rsp,%rcx
   30f50:	e8 4b 2c 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30f55:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   30f5a:	74 08                	je     30f64 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ab4>
   30f5c:	4c 89 ef             	mov    %r13,%rdi
   30f5f:	e8 8c 96 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   30f64:	41 bf 07 00 00 00    	mov    $0x7,%r15d
   30f6a:	bf 07 00 00 00       	mov    $0x7,%edi
   30f6f:	ff 15 fb 0a 04 00    	call   *0x40afb(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30f75:	48 85 c0             	test   %rax,%rax
   30f78:	0f 84 d6 1d 00 00    	je     32d54 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48a4>
   30f7e:	48 89 c3             	mov    %rax,%rbx
   30f81:	c7 40 03 6c 5f 6e 73 	movl   $0x736e5f6c,0x3(%rax)
   30f88:	c7 00 77 61 6c 6c    	movl   $0x6c6c6177,(%rax)
   30f8e:	48 c7 84 24 e8 00 00 	movq   $0x7,0xe8(%rsp)
   30f95:	00 07 00 00 00 
   30f9a:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   30fa1:	00 
   30fa2:	48 c7 84 24 f8 00 00 	movq   $0x7,0xf8(%rsp)
   30fa9:	00 07 00 00 00 
   30fae:	48 8b 7c 24 70       	mov    0x70(%rsp),%rdi
   30fb3:	48 8b 74 24 28       	mov    0x28(%rsp),%rsi
   30fb8:	48 89 e2             	mov    %rsp,%rdx
   30fbb:	ff 15 17 0e 04 00    	call   *0x40e17(%rip)        # 71dd8 <_DYNAMIC+0x550>
   30fc1:	49 89 c4             	mov    %rax,%r12
   30fc4:	4c 8d 70 d9          	lea    -0x27(%rax),%r14
   30fc8:	49 f7 de             	neg    %r14
   30fcb:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   30fd1:	48 83 f8 27          	cmp    $0x27,%rax
   30fd5:	74 25                	je     30ffc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b4c>
   30fd7:	4c 89 f7             	mov    %r14,%rdi
   30fda:	ff 15 90 0a 04 00    	call   *0x40a90(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   30fe0:	48 85 c0             	test   %rax,%rax
   30fe3:	0f 84 38 1e 00 00    	je     32e21 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4971>
   30fe9:	49 89 c7             	mov    %rax,%r15
   30fec:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   30ff0:	48 89 c7             	mov    %rax,%rdi
   30ff3:	4c 89 f2             	mov    %r14,%rdx
   30ff6:	ff 15 94 0a 04 00    	call   *0x40a94(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   30ffc:	c6 04 24 02          	movb   $0x2,(%rsp)
   31000:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   31005:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   3100a:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   3100f:	4c 89 ef             	mov    %r13,%rdi
   31012:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31019:	00 
   3101a:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   31021:	00 
   31022:	48 89 e1             	mov    %rsp,%rcx
   31025:	e8 76 2b 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3102a:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   3102f:	74 08                	je     31039 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2b89>
   31031:	4c 89 ef             	mov    %r13,%rdi
   31034:	e8 b7 95 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31039:	41 bf 10 00 00 00    	mov    $0x10,%r15d
   3103f:	bf 10 00 00 00       	mov    $0x10,%edi
   31044:	ff 15 26 0a 04 00    	call   *0x40a26(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3104a:	48 85 c0             	test   %rax,%rax
   3104d:	0f 84 01 1d 00 00    	je     32d54 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48a4>
   31053:	66 0f 10 05 45 65 fd 	movupd -0x29abb(%rip),%xmm0        # 75a0 <anon.0f363c1c2085502831f1e7e323c26323.407.llvm.704920437039905144+0x170>
   3105a:	ff 
   3105b:	66 0f 11 00          	movupd %xmm0,(%rax)
   3105f:	48 c7 84 24 e8 00 00 	movq   $0x10,0xe8(%rsp)
   31066:	00 10 00 00 00 
   3106b:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   31072:	00 
   31073:	48 c7 84 24 f8 00 00 	movq   $0x10,0xf8(%rsp)
   3107a:	00 10 00 00 00 
   3107f:	c6 04 24 00          	movb   $0x0,(%rsp)
   31083:	4c 89 ef             	mov    %r13,%rdi
   31086:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3108d:	00 
   3108e:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   31095:	00 
   31096:	48 89 e1             	mov    %rsp,%rcx
   31099:	e8 02 2b 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3109e:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   310a3:	74 08                	je     310ad <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2bfd>
   310a5:	4c 89 ef             	mov    %r13,%rdi
   310a8:	e8 43 95 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   310ad:	41 bf 0f 00 00 00    	mov    $0xf,%r15d
   310b3:	bf 0f 00 00 00       	mov    $0xf,%edi
   310b8:	ff 15 b2 09 04 00    	call   *0x409b2(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   310be:	48 85 c0             	test   %rax,%rax
   310c1:	0f 84 8d 1c 00 00    	je     32d54 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x48a4>
   310c7:	48 b9 65 64 5f 62 79 	movabs $0x73657479625f6465,%rcx
   310ce:	74 65 73 
   310d1:	48 89 48 07          	mov    %rcx,0x7(%rax)
   310d5:	48 b9 72 65 71 75 65 	movabs $0x6574736575716572,%rcx
   310dc:	73 74 65 
   310df:	48 89 08             	mov    %rcx,(%rax)
   310e2:	48 c7 84 24 e8 00 00 	movq   $0xf,0xe8(%rsp)
   310e9:	00 0f 00 00 00 
   310ee:	48 89 84 24 f0 00 00 	mov    %rax,0xf0(%rsp)
   310f5:	00 
   310f6:	48 c7 84 24 f8 00 00 	movq   $0xf,0xf8(%rsp)
   310fd:	00 0f 00 00 00 
   31102:	c6 04 24 00          	movb   $0x0,(%rsp)
   31106:	4c 89 ef             	mov    %r13,%rdi
   31109:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31110:	00 
   31111:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   31118:	00 
   31119:	48 89 e1             	mov    %rsp,%rcx
   3111c:	e8 7f 2a 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31121:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31126:	74 08                	je     31130 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2c80>
   31128:	4c 89 ef             	mov    %r13,%rdi
   3112b:	e8 c0 94 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31130:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   31137:	00 
   31138:	48 8d 8c 24 80 00 00 	lea    0x80(%rsp),%rcx
   3113f:	00 
   31140:	48 89 41 10          	mov    %rax,0x10(%rcx)
   31144:	0f 10 84 24 18 01 00 	movups 0x118(%rsp),%xmm0
   3114b:	00 
   3114c:	0f 11 01             	movups %xmm0,(%rcx)
   3114f:	c6 44 24 78 05       	movb   $0x5,0x78(%rsp)
   31154:	48 8b 9c 24 00 02 00 	mov    0x200(%rsp),%rbx
   3115b:	00 
   3115c:	48 3b 9c 24 f0 01 00 	cmp    0x1f0(%rsp),%rbx
   31163:	00 
   31164:	0f 85 b6 fa ff ff    	jne    30c20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2770>
   3116a:	48 8d bc 24 f0 01 00 	lea    0x1f0(%rsp),%rdi
   31171:	00 
   31172:	ff 15 10 0d 04 00    	call   *0x40d10(%rip)        # 71e88 <_DYNAMIC+0x600>
   31178:	e9 a3 fa ff ff       	jmp    30c20 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2770>
   3117d:	48 c7 84 24 18 01 00 	movq   $0x0,0x118(%rsp)
   31184:	00 00 00 00 00 
   31189:	48 c7 84 24 28 01 00 	movq   $0x0,0x128(%rsp)
   31190:	00 00 00 00 00 
   31195:	41 bd 06 00 00 00    	mov    $0x6,%r13d
   3119b:	bf 06 00 00 00       	mov    $0x6,%edi
   311a0:	ff 15 ca 08 04 00    	call   *0x408ca(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   311a6:	48 85 c0             	test   %rax,%rax
   311a9:	0f 84 85 1c 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   311af:	48 89 c3             	mov    %rax,%rbx
   311b2:	66 c7 40 04 6d 61    	movw   $0x616d,0x4(%rax)
   311b8:	c7 00 73 63 68 65    	movl   $0x65686373,(%rax)
   311be:	48 c7 44 24 78 06 00 	movq   $0x6,0x78(%rsp)
   311c5:	00 00 
   311c7:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   311ce:	00 
   311cf:	48 c7 84 24 88 00 00 	movq   $0x6,0x88(%rsp)
   311d6:	00 06 00 00 00 
   311db:	bf 15 00 00 00       	mov    $0x15,%edi
   311e0:	ff 15 8a 08 04 00    	call   *0x4088a(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   311e6:	48 85 c0             	test   %rax,%rax
   311e9:	0f 84 f3 1d 00 00    	je     32fe2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b32>
   311ef:	66 0f 10 05 b3 82 fd 	movupd -0x27d4d(%rip),%xmm0        # 94aa <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x223>
   311f6:	ff 
   311f7:	66 0f 11 00          	movupd %xmm0,(%rax)
   311fb:	48 b9 2d 70 72 6f 6f 	movabs $0x312f666f6f72702d,%rcx
   31202:	66 2f 31 
   31205:	48 89 48 0d          	mov    %rcx,0xd(%rax)
   31209:	c6 04 24 03          	movb   $0x3,(%rsp)
   3120d:	48 c7 44 24 08 15 00 	movq   $0x15,0x8(%rsp)
   31214:	00 00 
   31216:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   3121b:	48 c7 44 24 18 15 00 	movq   $0x15,0x18(%rsp)
   31222:	00 00 
   31224:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31229:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31230:	00 
   31231:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31236:	48 89 e1             	mov    %rsp,%rcx
   31239:	e8 62 29 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3123e:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31243:	74 0a                	je     3124f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2d9f>
   31245:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3124a:	e8 a1 93 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3124f:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   31255:	bf 04 00 00 00       	mov    $0x4,%edi
   3125a:	ff 15 10 08 04 00    	call   *0x40810(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31260:	48 85 c0             	test   %rax,%rax
   31263:	0f 84 cb 1b 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31269:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   3126f:	48 c7 44 24 78 04 00 	movq   $0x4,0x78(%rsp)
   31276:	00 00 
   31278:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   3127f:	00 
   31280:	48 c7 84 24 88 00 00 	movq   $0x4,0x88(%rsp)
   31287:	00 04 00 00 00 
   3128c:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   31291:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   31295:	48 85 db             	test   %rbx,%rbx
   31298:	0f 84 f5 00 00 00    	je     31393 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ee3>
   3129e:	49 89 c6             	mov    %rax,%r14
   312a1:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   312a5:	48 89 df             	mov    %rbx,%rdi
   312a8:	ff 15 c2 07 04 00    	call   *0x407c2(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   312ae:	48 85 c0             	test   %rax,%rax
   312b1:	0f 84 7f 1d 00 00    	je     33036 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b86>
   312b7:	49 89 c7             	mov    %rax,%r15
   312ba:	48 89 c7             	mov    %rax,%rdi
   312bd:	4c 89 e6             	mov    %r12,%rsi
   312c0:	48 89 da             	mov    %rbx,%rdx
   312c3:	ff 15 c7 07 04 00    	call   *0x407c7(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   312c9:	e9 cb 00 00 00       	jmp    31399 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2ee9>
   312ce:	48 c7 84 24 e8 00 00 	movq   $0x0,0xe8(%rsp)
   312d5:	00 00 00 00 00 
   312da:	48 c7 84 24 f8 00 00 	movq   $0x0,0xf8(%rsp)
   312e1:	00 00 00 00 00 
   312e6:	41 bd 04 00 00 00    	mov    $0x4,%r13d
   312ec:	bf 04 00 00 00       	mov    $0x4,%edi
   312f1:	ff 15 79 07 04 00    	call   *0x40779(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   312f7:	48 85 c0             	test   %rax,%rax
   312fa:	48 8b ac 24 70 01 00 	mov    0x170(%rsp),%rbp
   31301:	00 
   31302:	0f 84 3f 1b 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   31308:	c7 00 63 61 73 65    	movl   $0x65736163,(%rax)
   3130e:	48 c7 44 24 30 04 00 	movq   $0x4,0x30(%rsp)
   31315:	00 00 
   31317:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   3131c:	48 c7 44 24 40 04 00 	movq   $0x4,0x40(%rsp)
   31323:	00 00 
   31325:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   3132a:	48 8b 59 28          	mov    0x28(%rcx),%rbx
   3132e:	48 85 db             	test   %rbx,%rbx
   31331:	0f 84 fc 0c 00 00    	je     32033 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b83>
   31337:	49 89 c6             	mov    %rax,%r14
   3133a:	4c 8b 61 20          	mov    0x20(%rcx),%r12
   3133e:	48 89 df             	mov    %rbx,%rdi
   31341:	ff 15 29 07 04 00    	call   *0x40729(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31347:	48 85 c0             	test   %rax,%rax
   3134a:	0f 84 7b 1d 00 00    	je     330cb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c1b>
   31350:	49 89 c7             	mov    %rax,%r15
   31353:	48 89 c7             	mov    %rax,%rdi
   31356:	4c 89 e6             	mov    %r12,%rsi
   31359:	48 89 da             	mov    %rbx,%rdx
   3135c:	ff 15 2e 07 04 00    	call   *0x4072e(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31362:	e9 d2 0c 00 00       	jmp    32039 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b89>
   31367:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   3136e:	00 
   3136f:	48 c7 44 24 08 01 00 	movq   $0x1,0x8(%rsp)
   31376:	00 00 
   31378:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   3137d:	49 39 ce             	cmp    %rcx,%r14
   31380:	0f 86 0f f6 ff ff    	jbe    30995 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x24e5>
   31386:	48 89 e7             	mov    %rsp,%rdi
   31389:	e8 b7 94 ff ff       	call   2a845 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedTjINtNtB4_6option6OptionjEEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3138e:	e9 b6 1d 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   31393:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31399:	c6 04 24 03          	movb   $0x3,(%rsp)
   3139d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   313a2:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   313a7:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   313ac:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   313b1:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   313b8:	00 
   313b9:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   313be:	48 89 e1             	mov    %rsp,%rcx
   313c1:	e8 da 27 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   313c6:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   313cb:	74 0a                	je     313d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2f27>
   313cd:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   313d2:	e8 19 92 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   313d7:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   313dd:	bf 07 00 00 00       	mov    $0x7,%edi
   313e2:	ff 15 88 06 04 00    	call   *0x40688(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   313e8:	48 85 c0             	test   %rax,%rax
   313eb:	0f 84 43 1a 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   313f1:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   313f8:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   313fe:	48 c7 44 24 78 07 00 	movq   $0x7,0x78(%rsp)
   31405:	00 00 
   31407:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   3140e:	00 
   3140f:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   31416:	00 07 00 00 00 
   3141b:	48 8b 8c 24 68 02 00 	mov    0x268(%rsp),%rcx
   31422:	00 
   31423:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   31427:	48 85 db             	test   %rbx,%rbx
   3142a:	74 2d                	je     31459 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2fa9>
   3142c:	49 89 c6             	mov    %rax,%r14
   3142f:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   31433:	48 89 df             	mov    %rbx,%rdi
   31436:	ff 15 34 06 04 00    	call   *0x40634(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3143c:	48 85 c0             	test   %rax,%rax
   3143f:	0f 84 04 1c 00 00    	je     33049 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b99>
   31445:	49 89 c7             	mov    %rax,%r15
   31448:	48 89 c7             	mov    %rax,%rdi
   3144b:	4c 89 e6             	mov    %r12,%rsi
   3144e:	48 89 da             	mov    %rbx,%rdx
   31451:	ff 15 39 06 04 00    	call   *0x40639(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31457:	eb 06                	jmp    3145f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2faf>
   31459:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   3145f:	c6 04 24 03          	movb   $0x3,(%rsp)
   31463:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   31468:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   3146d:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   31472:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31477:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3147e:	00 
   3147f:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31484:	48 89 e1             	mov    %rsp,%rcx
   31487:	e8 14 27 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3148c:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31491:	74 0a                	je     3149d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2fed>
   31493:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31498:	e8 53 91 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3149d:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   314a3:	bf 09 00 00 00       	mov    $0x9,%edi
   314a8:	ff 15 c2 05 04 00    	call   *0x405c2(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   314ae:	48 85 c0             	test   %rax,%rax
   314b1:	0f 84 7d 19 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   314b7:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   314be:	74 69 6f 
   314c1:	48 89 08             	mov    %rcx,(%rax)
   314c4:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   314c8:	48 c7 44 24 78 09 00 	movq   $0x9,0x78(%rsp)
   314cf:	00 00 
   314d1:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   314d8:	00 
   314d9:	48 c7 84 24 88 00 00 	movq   $0x9,0x88(%rsp)
   314e0:	00 09 00 00 00 
   314e5:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   314ea:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   314ee:	48 85 db             	test   %rbx,%rbx
   314f1:	74 2d                	je     31520 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3070>
   314f3:	49 89 c6             	mov    %rax,%r14
   314f6:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   314fa:	48 89 df             	mov    %rbx,%rdi
   314fd:	ff 15 6d 05 04 00    	call   *0x4056d(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31503:	48 85 c0             	test   %rax,%rax
   31506:	0f 84 50 1b 00 00    	je     3305c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4bac>
   3150c:	49 89 c7             	mov    %rax,%r15
   3150f:	48 89 c7             	mov    %rax,%rdi
   31512:	4c 89 e6             	mov    %r12,%rsi
   31515:	48 89 da             	mov    %rbx,%rdx
   31518:	ff 15 72 05 04 00    	call   *0x40572(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   3151e:	eb 06                	jmp    31526 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3076>
   31520:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   31526:	c6 04 24 03          	movb   $0x3,(%rsp)
   3152a:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   3152f:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   31534:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   31539:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3153e:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31545:	00 
   31546:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   3154b:	48 89 e1             	mov    %rsp,%rcx
   3154e:	e8 4d 26 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31553:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31558:	74 0a                	je     31564 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x30b4>
   3155a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3155f:	e8 8c 90 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31564:	41 bd 05 00 00 00    	mov    $0x5,%r13d
   3156a:	bf 05 00 00 00       	mov    $0x5,%edi
   3156f:	ff 15 fb 04 04 00    	call   *0x404fb(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31575:	48 85 c0             	test   %rax,%rax
   31578:	0f 84 b6 18 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   3157e:	48 89 c3             	mov    %rax,%rbx
   31581:	c6 40 04 74          	movb   $0x74,0x4(%rax)
   31585:	c7 00 69 6e 70 75    	movl   $0x75706e69,(%rax)
   3158b:	48 c7 44 24 78 05 00 	movq   $0x5,0x78(%rsp)
   31592:	00 00 
   31594:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   3159b:	00 
   3159c:	48 c7 84 24 88 00 00 	movq   $0x5,0x88(%rsp)
   315a3:	00 05 00 00 00 
   315a8:	bf 79 00 00 00       	mov    $0x79,%edi
   315ad:	ff 15 bd 04 04 00    	call   *0x404bd(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   315b3:	48 85 c0             	test   %rax,%rax
   315b6:	0f 84 3b 1a 00 00    	je     32ff7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b47>
   315bc:	0f 10 05 65 7f fd ff 	movups -0x2809b(%rip),%xmm0        # 9528 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2a1>
   315c3:	0f 11 40 69          	movups %xmm0,0x69(%rax)
   315c7:	0f 10 05 51 7f fd ff 	movups -0x280af(%rip),%xmm0        # 951f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x298>
   315ce:	0f 11 40 60          	movups %xmm0,0x60(%rax)
   315d2:	0f 10 05 36 7f fd ff 	movups -0x280ca(%rip),%xmm0        # 950f <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x288>
   315d9:	0f 11 40 50          	movups %xmm0,0x50(%rax)
   315dd:	0f 10 05 1b 7f fd ff 	movups -0x280e5(%rip),%xmm0        # 94ff <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x278>
   315e4:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   315e8:	0f 10 05 00 7f fd ff 	movups -0x28100(%rip),%xmm0        # 94ef <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x268>
   315ef:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   315f3:	0f 10 05 e5 7e fd ff 	movups -0x2811b(%rip),%xmm0        # 94df <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x258>
   315fa:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   315fe:	0f 10 05 ca 7e fd ff 	movups -0x28136(%rip),%xmm0        # 94cf <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x248>
   31605:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   31609:	66 0f 10 05 ae 7e fd 	movupd -0x28152(%rip),%xmm0        # 94bf <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x238>
   31610:	ff 
   31611:	66 0f 11 00          	movupd %xmm0,(%rax)
   31615:	c6 04 24 03          	movb   $0x3,(%rsp)
   31619:	48 c7 44 24 08 79 00 	movq   $0x79,0x8(%rsp)
   31620:	00 00 
   31622:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   31627:	48 c7 44 24 18 79 00 	movq   $0x79,0x18(%rsp)
   3162e:	00 00 
   31630:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31635:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3163c:	00 
   3163d:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31642:	48 89 e1             	mov    %rsp,%rcx
   31645:	e8 56 25 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3164a:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   3164f:	74 0a                	je     3165b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x31ab>
   31651:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31656:	e8 95 8f ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3165b:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   31661:	bf 07 00 00 00       	mov    $0x7,%edi
   31666:	ff 15 04 04 04 00    	call   *0x40404(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3166c:	48 85 c0             	test   %rax,%rax
   3166f:	0f 84 bf 17 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31675:	48 89 c3             	mov    %rax,%rbx
   31678:	c7 40 03 74 72 6f 6c 	movl   $0x6c6f7274,0x3(%rax)
   3167f:	c7 00 63 6f 6e 74    	movl   $0x746e6f63,(%rax)
   31685:	48 c7 44 24 78 07 00 	movq   $0x7,0x78(%rsp)
   3168c:	00 00 
   3168e:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   31695:	00 
   31696:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   3169d:	00 07 00 00 00 
   316a2:	bf 53 00 00 00       	mov    $0x53,%edi
   316a7:	ff 15 c3 03 04 00    	call   *0x403c3(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   316ad:	48 85 c0             	test   %rax,%rax
   316b0:	0f 84 56 19 00 00    	je     3300c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b5c>
   316b6:	0f 10 05 bb 7e fd ff 	movups -0x28145(%rip),%xmm0        # 9578 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2f1>
   316bd:	0f 11 40 40          	movups %xmm0,0x40(%rax)
   316c1:	0f 10 05 a0 7e fd ff 	movups -0x28160(%rip),%xmm0        # 9568 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2e1>
   316c8:	0f 11 40 30          	movups %xmm0,0x30(%rax)
   316cc:	0f 10 05 85 7e fd ff 	movups -0x2817b(%rip),%xmm0        # 9558 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2d1>
   316d3:	0f 11 40 20          	movups %xmm0,0x20(%rax)
   316d7:	0f 10 05 6a 7e fd ff 	movups -0x28196(%rip),%xmm0        # 9548 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2c1>
   316de:	0f 11 40 10          	movups %xmm0,0x10(%rax)
   316e2:	66 0f 10 05 4e 7e fd 	movupd -0x281b2(%rip),%xmm0        # 9538 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x2b1>
   316e9:	ff 
   316ea:	66 0f 11 00          	movupd %xmm0,(%rax)
   316ee:	c7 40 4f 63 6f 64 65 	movl   $0x65646f63,0x4f(%rax)
   316f5:	c6 04 24 03          	movb   $0x3,(%rsp)
   316f9:	48 c7 44 24 08 53 00 	movq   $0x53,0x8(%rsp)
   31700:	00 00 
   31702:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   31707:	48 c7 44 24 18 53 00 	movq   $0x53,0x18(%rsp)
   3170e:	00 00 
   31710:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31715:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   3171c:	00 
   3171d:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31722:	48 89 e1             	mov    %rsp,%rcx
   31725:	e8 76 24 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3172a:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   3172f:	74 0a                	je     3173b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x328b>
   31731:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31736:	e8 b5 8e ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3173b:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   31741:	bf 0a 00 00 00       	mov    $0xa,%edi
   31746:	ff 15 24 03 04 00    	call   *0x40324(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3174c:	48 85 c0             	test   %rax,%rax
   3174f:	0f 84 df 16 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31755:	48 89 c3             	mov    %rax,%rbx
   31758:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   3175f:	62 79 74 
   31762:	48 89 03             	mov    %rax,(%rbx)
   31765:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   3176b:	48 c7 44 24 78 0a 00 	movq   $0xa,0x78(%rsp)
   31772:	00 00 
   31774:	48 89 9c 24 80 00 00 	mov    %rbx,0x80(%rsp)
   3177b:	00 
   3177c:	48 c7 84 24 88 00 00 	movq   $0xa,0x88(%rsp)
   31783:	00 0a 00 00 00 
   31788:	4c 8b bc 24 c8 01 00 	mov    0x1c8(%rsp),%r15
   3178f:	00 
   31790:	48 89 e6             	mov    %rsp,%rsi
   31793:	4c 89 ff             	mov    %r15,%rdi
   31796:	ff 15 4c 06 04 00    	call   *0x4064c(%rip)        # 71de8 <_DYNAMIC+0x560>
   3179c:	49 89 c4             	mov    %rax,%r12
   3179f:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   317a3:	49 f7 de             	neg    %r14
   317a6:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   317ac:	48 83 f8 14          	cmp    $0x14,%rax
   317b0:	74 25                	je     317d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3327>
   317b2:	4c 89 f7             	mov    %r14,%rdi
   317b5:	ff 15 b5 02 04 00    	call   *0x402b5(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   317bb:	48 85 c0             	test   %rax,%rax
   317be:	0f 84 be 18 00 00    	je     33082 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4bd2>
   317c4:	49 89 c5             	mov    %rax,%r13
   317c7:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   317cb:	48 89 c7             	mov    %rax,%rdi
   317ce:	4c 89 f2             	mov    %r14,%rdx
   317d1:	ff 15 b9 02 04 00    	call   *0x402b9(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   317d7:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   317dc:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   317e1:	c6 04 24 02          	movb   $0x2,(%rsp)
   317e5:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   317ea:	4c 8d 64 24 30       	lea    0x30(%rsp),%r12
   317ef:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   317f6:	00 
   317f7:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   317fc:	48 89 e1             	mov    %rsp,%rcx
   317ff:	4c 89 e7             	mov    %r12,%rdi
   31802:	e8 99 23 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31807:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   3180c:	74 0a                	je     31818 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3368>
   3180e:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31813:	e8 d8 8d ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31818:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   3181e:	bf 0c 00 00 00       	mov    $0xc,%edi
   31823:	ff 15 47 02 04 00    	call   *0x40247(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31829:	48 85 c0             	test   %rax,%rax
   3182c:	0f 84 02 16 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31832:	49 89 c6             	mov    %rax,%r14
   31835:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   3183c:	9c f2 cb 
   3183f:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   31846:	66 6e 76 
   31849:	49 89 0e             	mov    %rcx,(%r14)
   3184c:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   31853:	34 
   31854:	48 c7 84 24 e8 00 00 	movq   $0xc,0xe8(%rsp)
   3185b:	00 0c 00 00 00 
   31860:	4c 89 b4 24 f0 00 00 	mov    %r14,0xf0(%rsp)
   31867:	00 
   31868:	48 c7 84 24 f8 00 00 	movq   $0xc,0xf8(%rsp)
   3186f:	00 0c 00 00 00 
   31874:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
   3187b:	00 
   3187c:	4d 85 ff             	test   %r15,%r15
   3187f:	0f 84 9f 00 00 00    	je     31924 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3474>
   31885:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   3188c:	01 00 00 
   3188f:	44 89 fa             	mov    %r15d,%edx
   31892:	83 e2 03             	and    $0x3,%edx
   31895:	49 83 ff 04          	cmp    $0x4,%r15
   31899:	73 04                	jae    3189f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x33ef>
   3189b:	31 f6                	xor    %esi,%esi
   3189d:	eb 5f                	jmp    318fe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x344e>
   3189f:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   318a6:	ff ff 7f 
   318a9:	48 83 c6 0b          	add    $0xb,%rsi
   318ad:	49 21 f7             	and    %rsi,%r15
   318b0:	31 f6                	xor    %esi,%esi
   318b2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   318b9:	1f 84 00 00 00 00 00 
   318c0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   318c4:	48 31 f8             	xor    %rdi,%rax
   318c7:	48 0f af c1          	imul   %rcx,%rax
   318cb:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   318d0:	48 31 c7             	xor    %rax,%rdi
   318d3:	48 0f af f9          	imul   %rcx,%rdi
   318d7:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   318dd:	49 31 f8             	xor    %rdi,%r8
   318e0:	4c 0f af c1          	imul   %rcx,%r8
   318e4:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   318e9:	4c 31 c0             	xor    %r8,%rax
   318ec:	48 0f af c1          	imul   %rcx,%rax
   318f0:	48 83 c6 04          	add    $0x4,%rsi
   318f4:	49 39 f7             	cmp    %rsi,%r15
   318f7:	75 c7                	jne    318c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3410>
   318f9:	48 85 d2             	test   %rdx,%rdx
   318fc:	74 26                	je     31924 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3474>
   318fe:	48 01 de             	add    %rbx,%rsi
   31901:	31 ff                	xor    %edi,%edi
   31903:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3190a:	84 00 00 00 00 00 
   31910:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   31915:	4c 31 c0             	xor    %r8,%rax
   31918:	48 0f af c1          	imul   %rcx,%rax
   3191c:	48 ff c7             	inc    %rdi
   3191f:	48 39 fa             	cmp    %rdi,%rdx
   31922:	75 ec                	jne    31910 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3460>
   31924:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   31929:	4c 89 24 24          	mov    %r12,(%rsp)
   3192d:	48 8b 05 dc 03 04 00 	mov    0x403dc(%rip),%rax        # 71d10 <_DYNAMIC+0x488>
   31934:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   31939:	48 8d 35 90 6a fd ff 	lea    -0x29570(%rip),%rsi        # 83d0 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   31940:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
   31945:	48 89 e2             	mov    %rsp,%rdx
   31948:	ff 15 e2 01 04 00    	call   *0x401e2(%rip)        # 71b30 <_DYNAMIC+0x2a8>
   3194e:	4c 8b bc 24 80 00 00 	mov    0x80(%rsp),%r15
   31955:	00 
   31956:	4c 8b a4 24 88 00 00 	mov    0x88(%rsp),%r12
   3195d:	00 
   3195e:	4d 85 e4             	test   %r12,%r12
   31961:	74 26                	je     31989 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x34d9>
   31963:	4c 89 e7             	mov    %r12,%rdi
   31966:	ff 15 04 01 04 00    	call   *0x40104(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3196c:	48 85 c0             	test   %rax,%rax
   3196f:	0f 84 fa 16 00 00    	je     3306f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4bbf>
   31975:	49 89 c5             	mov    %rax,%r13
   31978:	48 89 c7             	mov    %rax,%rdi
   3197b:	4c 89 fe             	mov    %r15,%rsi
   3197e:	4c 89 e2             	mov    %r12,%rdx
   31981:	ff 15 09 01 04 00    	call   *0x40109(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31987:	eb 06                	jmp    3198f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x34df>
   31989:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   3198f:	c6 04 24 03          	movb   $0x3,(%rsp)
   31993:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   31998:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   3199d:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   319a2:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   319a7:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   319ae:	00 
   319af:	48 8d 94 24 e8 00 00 	lea    0xe8(%rsp),%rdx
   319b6:	00 
   319b7:	48 89 e1             	mov    %rsp,%rcx
   319ba:	e8 e1 21 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   319bf:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   319c4:	74 0a                	je     319d0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3520>
   319c6:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   319cb:	e8 20 8c ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   319d0:	48 83 7c 24 78 00    	cmpq   $0x0,0x78(%rsp)
   319d6:	74 09                	je     319e1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3531>
   319d8:	4c 89 ff             	mov    %r15,%rdi
   319db:	ff 15 9f 00 04 00    	call   *0x4009f(%rip)        # 71a80 <free@GLIBC_2.2.5>
   319e1:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   319e7:	bf 08 00 00 00       	mov    $0x8,%edi
   319ec:	ff 15 7e 00 04 00    	call   *0x4007e(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   319f2:	48 85 c0             	test   %rax,%rax
   319f5:	0f 84 39 14 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   319fb:	49 89 c6             	mov    %rax,%r14
   319fe:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   31a05:	73 75 6d 
   31a08:	49 89 06             	mov    %rax,(%r14)
   31a0b:	48 c7 44 24 78 08 00 	movq   $0x8,0x78(%rsp)
   31a12:	00 00 
   31a14:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   31a1b:	00 
   31a1c:	48 c7 84 24 88 00 00 	movq   $0x8,0x88(%rsp)
   31a23:	00 08 00 00 00 
   31a28:	48 89 e6             	mov    %rsp,%rsi
   31a2b:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
   31a32:	00 
   31a33:	ff 15 af 03 04 00    	call   *0x403af(%rip)        # 71de8 <_DYNAMIC+0x560>
   31a39:	49 89 c4             	mov    %rax,%r12
   31a3c:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31a40:	49 f7 df             	neg    %r15
   31a43:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31a49:	48 83 f8 14          	cmp    $0x14,%rax
   31a4d:	74 25                	je     31a74 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x35c4>
   31a4f:	4c 89 ff             	mov    %r15,%rdi
   31a52:	ff 15 18 00 04 00    	call   *0x40018(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31a58:	48 85 c0             	test   %rax,%rax
   31a5b:	0f 84 34 16 00 00    	je     33095 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4be5>
   31a61:	49 89 c5             	mov    %rax,%r13
   31a64:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31a68:	48 89 c7             	mov    %rax,%rdi
   31a6b:	4c 89 fa             	mov    %r15,%rdx
   31a6e:	ff 15 1c 00 04 00    	call   *0x4001c(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31a74:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31a79:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   31a7e:	c6 04 24 02          	movb   $0x2,(%rsp)
   31a82:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   31a87:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31a8c:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31a93:	00 
   31a94:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31a99:	48 89 e1             	mov    %rsp,%rcx
   31a9c:	e8 ff 20 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31aa1:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31aa6:	74 0a                	je     31ab2 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3602>
   31aa8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31aad:	e8 3e 8b ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31ab2:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   31ab8:	bf 0b 00 00 00       	mov    $0xb,%edi
   31abd:	ff 15 ad ff 03 00    	call   *0x3ffad(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31ac3:	48 85 c0             	test   %rax,%rax
   31ac6:	0f 84 68 13 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31acc:	49 89 c6             	mov    %rax,%r14
   31acf:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   31ad6:	6e 74 72 
   31ad9:	49 89 06             	mov    %rax,(%r14)
   31adc:	41 c7 46 07 72 69 65 	movl   $0x73656972,0x7(%r14)
   31ae3:	73 
   31ae4:	48 c7 44 24 78 0b 00 	movq   $0xb,0x78(%rsp)
   31aeb:	00 00 
   31aed:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   31af4:	00 
   31af5:	48 c7 84 24 88 00 00 	movq   $0xb,0x88(%rsp)
   31afc:	00 0b 00 00 00 
   31b01:	48 89 e6             	mov    %rsp,%rsi
   31b04:	48 89 ef             	mov    %rbp,%rdi
   31b07:	ff 15 db 02 04 00    	call   *0x402db(%rip)        # 71de8 <_DYNAMIC+0x560>
   31b0d:	49 89 c4             	mov    %rax,%r12
   31b10:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31b14:	49 f7 df             	neg    %r15
   31b17:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31b1d:	48 83 f8 14          	cmp    $0x14,%rax
   31b21:	74 25                	je     31b48 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3698>
   31b23:	4c 89 ff             	mov    %r15,%rdi
   31b26:	ff 15 44 ff 03 00    	call   *0x3ff44(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31b2c:	48 85 c0             	test   %rax,%rax
   31b2f:	0f 84 73 15 00 00    	je     330a8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4bf8>
   31b35:	49 89 c5             	mov    %rax,%r13
   31b38:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31b3c:	48 89 c7             	mov    %rax,%rdi
   31b3f:	4c 89 fa             	mov    %r15,%rdx
   31b42:	ff 15 48 ff 03 00    	call   *0x3ff48(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31b48:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31b4d:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   31b52:	c6 04 24 02          	movb   $0x2,(%rsp)
   31b56:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   31b5b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31b60:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31b67:	00 
   31b68:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31b6d:	48 89 e1             	mov    %rsp,%rcx
   31b70:	e8 2b 20 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31b75:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31b7a:	74 0a                	je     31b86 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x36d6>
   31b7c:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31b81:	e8 6a 8a ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31b86:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   31b8c:	bf 0e 00 00 00       	mov    $0xe,%edi
   31b91:	ff 15 d9 fe 03 00    	call   *0x3fed9(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31b97:	48 85 c0             	test   %rax,%rax
   31b9a:	0f 84 94 12 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31ba0:	49 89 c6             	mov    %rax,%r14
   31ba3:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   31baa:	69 65 73 
   31bad:	49 89 46 06          	mov    %rax,0x6(%r14)
   31bb1:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   31bb8:	65 5f 65 
   31bbb:	49 89 06             	mov    %rax,(%r14)
   31bbe:	48 c7 44 24 78 0e 00 	movq   $0xe,0x78(%rsp)
   31bc5:	00 00 
   31bc7:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   31bce:	00 
   31bcf:	48 c7 84 24 88 00 00 	movq   $0xe,0x88(%rsp)
   31bd6:	00 0e 00 00 00 
   31bdb:	48 89 e6             	mov    %rsp,%rsi
   31bde:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
   31be5:	00 
   31be6:	ff 15 fc 01 04 00    	call   *0x401fc(%rip)        # 71de8 <_DYNAMIC+0x560>
   31bec:	49 89 c4             	mov    %rax,%r12
   31bef:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   31bf3:	49 f7 df             	neg    %r15
   31bf6:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31bfc:	48 83 f8 14          	cmp    $0x14,%rax
   31c00:	74 25                	je     31c27 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3777>
   31c02:	4c 89 ff             	mov    %r15,%rdi
   31c05:	ff 15 65 fe 03 00    	call   *0x3fe65(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31c0b:	48 85 c0             	test   %rax,%rax
   31c0e:	0f 84 a7 14 00 00    	je     330bb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c0b>
   31c14:	49 89 c5             	mov    %rax,%r13
   31c17:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   31c1b:	48 89 c7             	mov    %rax,%rdi
   31c1e:	4c 89 fa             	mov    %r15,%rdx
   31c21:	ff 15 69 fe 03 00    	call   *0x3fe69(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   31c27:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   31c2c:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   31c31:	c6 04 24 02          	movb   $0x2,(%rsp)
   31c35:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   31c3a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31c3f:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31c46:	00 
   31c47:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31c4c:	48 89 e1             	mov    %rsp,%rcx
   31c4f:	e8 4c 1f 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31c54:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31c59:	74 0a                	je     31c65 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x37b5>
   31c5b:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31c60:	e8 8b 89 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31c65:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   31c6b:	bf 12 00 00 00       	mov    $0x12,%edi
   31c70:	ff 15 fa fd 03 00    	call   *0x3fdfa(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31c76:	48 85 c0             	test   %rax,%rax
   31c79:	0f 84 b5 11 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31c7f:	66 0f 10 05 11 78 fd 	movupd -0x287ef(%rip),%xmm0        # 9498 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x211>
   31c86:	ff 
   31c87:	66 0f 11 00          	movupd %xmm0,(%rax)
   31c8b:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   31c91:	48 c7 44 24 78 12 00 	movq   $0x12,0x78(%rsp)
   31c98:	00 00 
   31c9a:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   31ca1:	00 
   31ca2:	48 c7 84 24 88 00 00 	movq   $0x12,0x88(%rsp)
   31ca9:	00 12 00 00 00 
   31cae:	66 c7 04 24 01 01    	movw   $0x101,(%rsp)
   31cb4:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31cb9:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31cc0:	00 
   31cc1:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31cc6:	48 89 e1             	mov    %rsp,%rcx
   31cc9:	e8 d2 1e 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31cce:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31cd3:	74 0a                	je     31cdf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x382f>
   31cd5:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31cda:	e8 11 89 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31cdf:	41 bd 0f 00 00 00    	mov    $0xf,%r13d
   31ce5:	bf 0f 00 00 00       	mov    $0xf,%edi
   31cea:	ff 15 80 fd 03 00    	call   *0x3fd80(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31cf0:	48 85 c0             	test   %rax,%rax
   31cf3:	0f 84 3b 11 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31cf9:	49 89 c6             	mov    %rax,%r14
   31cfc:	48 b8 5f 73 74 6f 72 	movabs $0x656761726f74735f,%rax
   31d03:	61 67 65 
   31d06:	49 89 46 07          	mov    %rax,0x7(%r14)
   31d0a:	48 b8 6d 65 73 73 61 	movabs $0x5f6567617373656d,%rax
   31d11:	67 65 5f 
   31d14:	49 89 06             	mov    %rax,(%r14)
   31d17:	48 c7 44 24 78 0f 00 	movq   $0xf,0x78(%rsp)
   31d1e:	00 00 
   31d20:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   31d27:	00 
   31d28:	48 c7 84 24 88 00 00 	movq   $0xf,0x88(%rsp)
   31d2f:	00 0f 00 00 00 
   31d34:	bf 04 00 00 00       	mov    $0x4,%edi
   31d39:	ff 15 31 fd 03 00    	call   *0x3fd31(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31d3f:	48 85 c0             	test   %rax,%rax
   31d42:	0f 84 d9 12 00 00    	je     33021 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4b71>
   31d48:	c7 00 6c 61 7a 79    	movl   $0x797a616c,(%rax)
   31d4e:	c6 04 24 03          	movb   $0x3,(%rsp)
   31d52:	48 c7 44 24 08 04 00 	movq   $0x4,0x8(%rsp)
   31d59:	00 00 
   31d5b:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   31d60:	48 c7 44 24 18 04 00 	movq   $0x4,0x18(%rsp)
   31d67:	00 00 
   31d69:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31d6e:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31d75:	00 
   31d76:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31d7b:	48 89 e1             	mov    %rsp,%rcx
   31d7e:	e8 1d 1e 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31d83:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31d88:	74 0a                	je     31d94 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x38e4>
   31d8a:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31d8f:	e8 5c 88 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31d94:	41 bd 1a 00 00 00    	mov    $0x1a,%r13d
   31d9a:	bf 1a 00 00 00       	mov    $0x1a,%edi
   31d9f:	ff 15 cb fc 03 00    	call   *0x3fccb(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31da5:	48 85 c0             	test   %rax,%rax
   31da8:	0f 84 86 10 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31dae:	0f 10 05 e0 77 fd ff 	movups -0x28820(%rip),%xmm0        # 9595 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x30e>
   31db5:	0f 11 40 0a          	movups %xmm0,0xa(%rax)
   31db9:	66 0f 10 05 ca 77 fd 	movupd -0x28836(%rip),%xmm0        # 958b <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x304>
   31dc0:	ff 
   31dc1:	66 0f 11 00          	movupd %xmm0,(%rax)
   31dc5:	48 c7 44 24 78 1a 00 	movq   $0x1a,0x78(%rsp)
   31dcc:	00 00 
   31dce:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   31dd5:	00 
   31dd6:	48 c7 84 24 88 00 00 	movq   $0x1a,0x88(%rsp)
   31ddd:	00 1a 00 00 00 
   31de2:	66 c7 04 24 01 00    	movw   $0x1,(%rsp)
   31de8:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31ded:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31df4:	00 
   31df5:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31dfa:	48 89 e1             	mov    %rsp,%rcx
   31dfd:	e8 9e 1d 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31e02:	80 7c 24 30 ff       	cmpb   $0xff,0x30(%rsp)
   31e07:	74 0a                	je     31e13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3963>
   31e09:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   31e0e:	e8 dd 87 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31e13:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   31e19:	bf 07 00 00 00       	mov    $0x7,%edi
   31e1e:	ff 15 4c fc 03 00    	call   *0x3fc4c(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   31e24:	48 85 c0             	test   %rax,%rax
   31e27:	0f 84 07 10 00 00    	je     32e34 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4984>
   31e2d:	49 89 c6             	mov    %rax,%r14
   31e30:	c7 40 03 70 6c 65 73 	movl   $0x73656c70,0x3(%rax)
   31e37:	c7 00 73 61 6d 70    	movl   $0x706d6173,(%rax)
   31e3d:	48 c7 44 24 78 07 00 	movq   $0x7,0x78(%rsp)
   31e44:	00 00 
   31e46:	48 89 84 24 80 00 00 	mov    %rax,0x80(%rsp)
   31e4d:	00 
   31e4e:	48 c7 84 24 88 00 00 	movq   $0x7,0x88(%rsp)
   31e55:	00 07 00 00 00 
   31e5a:	48 89 e7             	mov    %rsp,%rdi
   31e5d:	48 8d b4 24 f0 01 00 	lea    0x1f0(%rsp),%rsi
   31e64:	00 
   31e65:	e8 76 b6 ff ff       	call   2d4e0 <_RINvYNtNtNtCseZmxtRzJJaS_10serde_json5value3ser10SerializerNtNtCsgX5KCuC7WXX_10serde_core3ser10Serializer11collect_seqRINtNtCsgFX3jaOk65H_5alloc3vec3VecNtB7_5ValueEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31e6a:	80 3c 24 ff          	cmpb   $0xff,(%rsp)
   31e6e:	0f 84 34 0e 00 00    	je     32ca8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x47f8>
   31e74:	66 0f 10 04 24       	movupd (%rsp),%xmm0
   31e79:	f3 0f 6f 4c 24 10    	movdqu 0x10(%rsp),%xmm1
   31e7f:	66 0f 7f 4c 24 40    	movdqa %xmm1,0x40(%rsp)
   31e85:	66 0f 29 44 24 30    	movapd %xmm0,0x30(%rsp)
   31e8b:	49 89 e6             	mov    %rsp,%r14
   31e8e:	48 8d b4 24 18 01 00 	lea    0x118(%rsp),%rsi
   31e95:	00 
   31e96:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   31e9b:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   31ea0:	4c 89 f7             	mov    %r14,%rdi
   31ea3:	e8 f8 1c 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31ea8:	80 3c 24 ff          	cmpb   $0xff,(%rsp)
   31eac:	74 08                	je     31eb6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a06>
   31eae:	48 89 e7             	mov    %rsp,%rdi
   31eb1:	e8 3a 87 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31eb6:	66 0f 10 84 24 18 01 	movupd 0x118(%rsp),%xmm0
   31ebd:	00 00 
   31ebf:	66 0f 11 44 24 08    	movupd %xmm0,0x8(%rsp)
   31ec5:	48 8b 84 24 28 01 00 	mov    0x128(%rsp),%rax
   31ecc:	00 
   31ecd:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   31ed2:	c6 04 24 05          	movb   $0x5,(%rsp)
   31ed6:	4c 89 74 24 30       	mov    %r14,0x30(%rsp)
   31edb:	48 8b 05 c6 ff 03 00 	mov    0x3ffc6(%rip),%rax        # 71ea8 <_DYNAMIC+0x620>
   31ee2:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   31ee7:	48 8d 3d 3a 3c fd ff 	lea    -0x2c3c6(%rip),%rdi        # 5b28 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   31eee:	48 8d 74 24 30       	lea    0x30(%rsp),%rsi
   31ef3:	ff 15 b7 ff 03 00    	call   *0x3ffb7(%rip)        # 71eb0 <_DYNAMIC+0x628>
   31ef9:	48 89 e7             	mov    %rsp,%rdi
   31efc:	e8 ef 86 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f01:	4c 8b b4 24 f8 01 00 	mov    0x1f8(%rsp),%r14
   31f08:	00 
   31f09:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
   31f10:	00 
   31f11:	48 85 c0             	test   %rax,%rax
   31f14:	74 2f                	je     31f45 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a95>
   31f16:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   31f1c:	49 29 c5             	sub    %rax,%r13
   31f1f:	4d 89 f7             	mov    %r14,%r15
   31f22:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   31f29:	1f 84 00 00 00 00 00 
   31f30:	4c 89 ff             	mov    %r15,%rdi
   31f33:	e8 b8 86 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f38:	49 83 c7 20          	add    $0x20,%r15
   31f3c:	49 ff c5             	inc    %r13
   31f3f:	49 83 fd 01          	cmp    $0x1,%r13
   31f43:	75 eb                	jne    31f30 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3a80>
   31f45:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   31f4c:	00 00 
   31f4e:	74 09                	je     31f59 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3aa9>
   31f50:	4c 89 f7             	mov    %r14,%rdi
   31f53:	ff 15 27 fb 03 00    	call   *0x3fb27(%rip)        # 71a80 <free@GLIBC_2.2.5>
   31f59:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   31f60:	00 00 
   31f62:	74 19                	je     31f7d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3acd>
   31f64:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   31f6b:	00 00 
   31f6d:	74 0e                	je     31f7d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3acd>
   31f6f:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   31f76:	00 
   31f77:	ff 15 03 fb 03 00    	call   *0x3fb03(%rip)        # 71a80 <free@GLIBC_2.2.5>
   31f7d:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
   31f84:	00 
   31f85:	e8 c6 80 ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31f8a:	48 83 bc 24 20 02 00 	cmpq   $0x0,0x220(%rsp)
   31f91:	00 00 
   31f93:	74 0e                	je     31fa3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3af3>
   31f95:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
   31f9c:	00 
   31f9d:	ff 15 dd fa 03 00    	call   *0x3fadd(%rip)        # 71a80 <free@GLIBC_2.2.5>
   31fa3:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   31faa:	00 
   31fab:	e8 d0 82 ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31fb0:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   31fb7:	00 00 
   31fb9:	74 0e                	je     31fc9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b19>
   31fbb:	48 8b bc 24 d8 01 00 	mov    0x1d8(%rsp),%rdi
   31fc2:	00 
   31fc3:	ff 15 b7 fa 03 00    	call   *0x3fab7(%rip)        # 71a80 <free@GLIBC_2.2.5>
   31fc9:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   31fd0:	00 00 
   31fd2:	74 09                	je     31fdd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b2d>
   31fd4:	48 89 df             	mov    %rbx,%rdi
   31fd7:	ff 15 a3 fa 03 00    	call   *0x3faa3(%rip)        # 71a80 <free@GLIBC_2.2.5>
   31fdd:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   31fe4:	00 
   31fe5:	e8 96 82 ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   31fea:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   31ff1:	00 
   31ff2:	48 85 c9             	test   %rcx,%rcx
   31ff5:	74 2a                	je     32021 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b71>
   31ff7:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   31ffe:	00 
   31fff:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   32003:	48 01 c1             	add    %rax,%rcx
   32006:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   3200a:	74 15                	je     32021 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3b71>
   3200c:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   32013:	00 
   32014:	48 29 c7             	sub    %rax,%rdi
   32017:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   3201b:	ff 15 5f fa 03 00    	call   *0x3fa5f(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32021:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   32028:	00 
   32029:	e8 22 80 ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3202e:	e9 b1 08 00 00       	jmp    328e4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4434>
   32033:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   32039:	c6 04 24 03          	movb   $0x3,(%rsp)
   3203d:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   32042:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   32047:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   3204c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32053:	00 
   32054:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   3205b:	00 
   3205c:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32061:	48 89 e1             	mov    %rsp,%rcx
   32064:	e8 37 1b 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32069:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32070:	ff 
   32071:	74 0d                	je     32080 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3bd0>
   32073:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3207a:	00 
   3207b:	e8 70 85 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32080:	41 bd 07 00 00 00    	mov    $0x7,%r13d
   32086:	bf 07 00 00 00       	mov    $0x7,%edi
   3208b:	ff 15 df f9 03 00    	call   *0x3f9df(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32091:	48 85 c0             	test   %rax,%rax
   32094:	0f 84 ad 0d 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   3209a:	c7 40 03 6b 65 6e 64 	movl   $0x646e656b,0x3(%rax)
   320a1:	c7 00 62 61 63 6b    	movl   $0x6b636162,(%rax)
   320a7:	48 c7 44 24 30 07 00 	movq   $0x7,0x30(%rsp)
   320ae:	00 00 
   320b0:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   320b5:	48 c7 44 24 40 07 00 	movq   $0x7,0x40(%rsp)
   320bc:	00 00 
   320be:	48 8b 8c 24 68 02 00 	mov    0x268(%rsp),%rcx
   320c5:	00 
   320c6:	48 8b 59 10          	mov    0x10(%rcx),%rbx
   320ca:	48 85 db             	test   %rbx,%rbx
   320cd:	74 2d                	je     320fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c4c>
   320cf:	49 89 c6             	mov    %rax,%r14
   320d2:	4c 8b 61 08          	mov    0x8(%rcx),%r12
   320d6:	48 89 df             	mov    %rbx,%rdi
   320d9:	ff 15 91 f9 03 00    	call   *0x3f991(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   320df:	48 85 c0             	test   %rax,%rax
   320e2:	0f 84 f3 0f 00 00    	je     330db <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c2b>
   320e8:	49 89 c7             	mov    %rax,%r15
   320eb:	48 89 c7             	mov    %rax,%rdi
   320ee:	4c 89 e6             	mov    %r12,%rsi
   320f1:	48 89 da             	mov    %rbx,%rdx
   320f4:	ff 15 96 f9 03 00    	call   *0x3f996(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   320fa:	eb 06                	jmp    32102 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c52>
   320fc:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   32102:	c6 04 24 03          	movb   $0x3,(%rsp)
   32106:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   3210b:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   32110:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   32115:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3211c:	00 
   3211d:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   32124:	00 
   32125:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   3212a:	48 89 e1             	mov    %rsp,%rcx
   3212d:	e8 6e 1a 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32132:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32139:	ff 
   3213a:	74 0d                	je     32149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3c99>
   3213c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32143:	00 
   32144:	e8 a7 84 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32149:	41 bd 09 00 00 00    	mov    $0x9,%r13d
   3214f:	bf 09 00 00 00       	mov    $0x9,%edi
   32154:	ff 15 16 f9 03 00    	call   *0x3f916(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   3215a:	48 85 c0             	test   %rax,%rax
   3215d:	0f 84 e4 0c 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   32163:	48 b9 6f 70 65 72 61 	movabs $0x6f6974617265706f,%rcx
   3216a:	74 69 6f 
   3216d:	48 89 08             	mov    %rcx,(%rax)
   32170:	c6 40 08 6e          	movb   $0x6e,0x8(%rax)
   32174:	48 c7 44 24 30 09 00 	movq   $0x9,0x30(%rsp)
   3217b:	00 00 
   3217d:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   32182:	48 c7 44 24 40 09 00 	movq   $0x9,0x40(%rsp)
   32189:	00 00 
   3218b:	48 8b 4c 24 58       	mov    0x58(%rsp),%rcx
   32190:	48 8b 59 58          	mov    0x58(%rcx),%rbx
   32194:	48 85 db             	test   %rbx,%rbx
   32197:	74 2d                	je     321c6 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d16>
   32199:	49 89 c6             	mov    %rax,%r14
   3219c:	4c 8b 61 50          	mov    0x50(%rcx),%r12
   321a0:	48 89 df             	mov    %rbx,%rdi
   321a3:	ff 15 c7 f8 03 00    	call   *0x3f8c7(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   321a9:	48 85 c0             	test   %rax,%rax
   321ac:	0f 84 39 0f 00 00    	je     330eb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c3b>
   321b2:	49 89 c7             	mov    %rax,%r15
   321b5:	48 89 c7             	mov    %rax,%rdi
   321b8:	4c 89 e6             	mov    %r12,%rsi
   321bb:	48 89 da             	mov    %rbx,%rdx
   321be:	ff 15 cc f8 03 00    	call   *0x3f8cc(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   321c4:	eb 06                	jmp    321cc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d1c>
   321c6:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   321cc:	c6 04 24 03          	movb   $0x3,(%rsp)
   321d0:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   321d5:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   321da:	48 89 5c 24 18       	mov    %rbx,0x18(%rsp)
   321df:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   321e6:	00 
   321e7:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   321ee:	00 
   321ef:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   321f4:	48 89 e1             	mov    %rsp,%rcx
   321f7:	e8 a4 19 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   321fc:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32203:	ff 
   32204:	74 0d                	je     32213 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3d63>
   32206:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3220d:	00 
   3220e:	e8 dd 83 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32213:	41 bd 12 00 00 00    	mov    $0x12,%r13d
   32219:	bf 12 00 00 00       	mov    $0x12,%edi
   3221e:	ff 15 4c f8 03 00    	call   *0x3f84c(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32224:	48 85 c0             	test   %rax,%rax
   32227:	0f 84 1a 0c 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   3222d:	66 0f 10 05 63 72 fd 	movupd -0x28d9d(%rip),%xmm0        # 9498 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x211>
   32234:	ff 
   32235:	66 0f 11 00          	movupd %xmm0,(%rax)
   32239:	66 c7 40 10 6b 73    	movw   $0x736b,0x10(%rax)
   3223f:	48 c7 44 24 30 12 00 	movq   $0x12,0x30(%rsp)
   32246:	00 00 
   32248:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   3224d:	48 c7 44 24 40 12 00 	movq   $0x12,0x40(%rsp)
   32254:	00 00 
   32256:	66 c7 04 24 01 01    	movw   $0x101,(%rsp)
   3225c:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32263:	00 
   32264:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   3226b:	00 
   3226c:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32271:	48 89 e1             	mov    %rsp,%rcx
   32274:	e8 27 19 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32279:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32280:	ff 
   32281:	74 0d                	je     32290 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3de0>
   32283:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3228a:	00 
   3228b:	e8 60 83 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32290:	41 bd 0b 00 00 00    	mov    $0xb,%r13d
   32296:	bf 0b 00 00 00       	mov    $0xb,%edi
   3229b:	ff 15 cf f7 03 00    	call   *0x3f7cf(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   322a1:	48 85 c0             	test   %rax,%rax
   322a4:	0f 84 9d 0b 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   322aa:	48 89 c3             	mov    %rax,%rbx
   322ad:	48 b8 72 61 77 5f 65 	movabs $0x72746e655f776172,%rax
   322b4:	6e 74 72 
   322b7:	48 89 03             	mov    %rax,(%rbx)
   322ba:	c7 43 07 72 69 65 73 	movl   $0x73656972,0x7(%rbx)
   322c1:	48 c7 44 24 30 0b 00 	movq   $0xb,0x30(%rsp)
   322c8:	00 00 
   322ca:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   322cf:	48 c7 44 24 40 0b 00 	movq   $0xb,0x40(%rsp)
   322d6:	00 00 
   322d8:	48 89 e6             	mov    %rsp,%rsi
   322db:	48 89 ef             	mov    %rbp,%rdi
   322de:	ff 15 04 fb 03 00    	call   *0x3fb04(%rip)        # 71de8 <_DYNAMIC+0x560>
   322e4:	49 89 c7             	mov    %rax,%r15
   322e7:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   322eb:	49 f7 de             	neg    %r14
   322ee:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   322f4:	48 83 f8 14          	cmp    $0x14,%rax
   322f8:	74 25                	je     3231f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3e6f>
   322fa:	4c 89 f7             	mov    %r14,%rdi
   322fd:	ff 15 6d f7 03 00    	call   *0x3f76d(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32303:	48 85 c0             	test   %rax,%rax
   32306:	0f 84 ff 0d 00 00    	je     3310b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c5b>
   3230c:	49 89 c4             	mov    %rax,%r12
   3230f:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   32313:	48 89 c7             	mov    %rax,%rdi
   32316:	4c 89 f2             	mov    %r14,%rdx
   32319:	ff 15 71 f7 03 00    	call   *0x3f771(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   3231f:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   32324:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   32329:	c6 04 24 02          	movb   $0x2,(%rsp)
   3232d:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   32332:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32339:	00 
   3233a:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   32341:	00 
   32342:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32347:	48 89 e1             	mov    %rsp,%rcx
   3234a:	e8 51 18 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3234f:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32356:	ff 
   32357:	74 0d                	je     32366 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3eb6>
   32359:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32360:	00 
   32361:	e8 8a 82 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32366:	41 bd 0e 00 00 00    	mov    $0xe,%r13d
   3236c:	bf 0e 00 00 00       	mov    $0xe,%edi
   32371:	ff 15 f9 f6 03 00    	call   *0x3f6f9(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32377:	48 85 c0             	test   %rax,%rax
   3237a:	0f 84 c7 0a 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   32380:	48 89 c3             	mov    %rax,%rbx
   32383:	48 b8 5f 65 6e 74 72 	movabs $0x73656972746e655f,%rax
   3238a:	69 65 73 
   3238d:	48 89 43 06          	mov    %rax,0x6(%rbx)
   32391:	48 b8 75 6e 69 71 75 	movabs $0x655f657571696e75,%rax
   32398:	65 5f 65 
   3239b:	48 89 03             	mov    %rax,(%rbx)
   3239e:	48 c7 44 24 30 0e 00 	movq   $0xe,0x30(%rsp)
   323a5:	00 00 
   323a7:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   323ac:	48 c7 44 24 40 0e 00 	movq   $0xe,0x40(%rsp)
   323b3:	00 00 
   323b5:	48 89 e6             	mov    %rsp,%rsi
   323b8:	48 8b bc 24 98 00 00 	mov    0x98(%rsp),%rdi
   323bf:	00 
   323c0:	ff 15 22 fa 03 00    	call   *0x3fa22(%rip)        # 71de8 <_DYNAMIC+0x560>
   323c6:	49 89 c7             	mov    %rax,%r15
   323c9:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   323cd:	49 f7 de             	neg    %r14
   323d0:	41 bc 01 00 00 00    	mov    $0x1,%r12d
   323d6:	48 83 f8 14          	cmp    $0x14,%rax
   323da:	74 25                	je     32401 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f51>
   323dc:	4c 89 f7             	mov    %r14,%rdi
   323df:	ff 15 8b f6 03 00    	call   *0x3f68b(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   323e5:	48 85 c0             	test   %rax,%rax
   323e8:	0f 84 2d 0d 00 00    	je     3311b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c6b>
   323ee:	49 89 c4             	mov    %rax,%r12
   323f1:	4a 8d 34 3c          	lea    (%rsp,%r15,1),%rsi
   323f5:	48 89 c7             	mov    %rax,%rdi
   323f8:	4c 89 f2             	mov    %r14,%rdx
   323fb:	ff 15 8f f6 03 00    	call   *0x3f68f(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   32401:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   32406:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   3240b:	c6 04 24 02          	movb   $0x2,(%rsp)
   3240f:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   32414:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3241b:	00 
   3241c:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   32423:	00 
   32424:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32429:	48 89 e1             	mov    %rsp,%rcx
   3242c:	e8 6f 17 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32431:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32438:	ff 
   32439:	74 0d                	je     32448 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x3f98>
   3243b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32442:	00 
   32443:	e8 a8 81 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32448:	41 bd 0a 00 00 00    	mov    $0xa,%r13d
   3244e:	bf 0a 00 00 00       	mov    $0xa,%edi
   32453:	ff 15 17 f6 03 00    	call   *0x3f617(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32459:	48 85 c0             	test   %rax,%rax
   3245c:	0f 84 e5 09 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   32462:	48 89 c3             	mov    %rax,%rbx
   32465:	48 b8 77 69 72 65 5f 	movabs $0x7479625f65726977,%rax
   3246c:	62 79 74 
   3246f:	48 89 03             	mov    %rax,(%rbx)
   32472:	66 c7 43 08 65 73    	movw   $0x7365,0x8(%rbx)
   32478:	48 c7 44 24 30 0a 00 	movq   $0xa,0x30(%rsp)
   3247f:	00 00 
   32481:	48 89 5c 24 38       	mov    %rbx,0x38(%rsp)
   32486:	48 c7 44 24 40 0a 00 	movq   $0xa,0x40(%rsp)
   3248d:	00 00 
   3248f:	4c 8b bc 24 c8 01 00 	mov    0x1c8(%rsp),%r15
   32496:	00 
   32497:	48 89 e6             	mov    %rsp,%rsi
   3249a:	4c 89 ff             	mov    %r15,%rdi
   3249d:	ff 15 45 f9 03 00    	call   *0x3f945(%rip)        # 71de8 <_DYNAMIC+0x560>
   324a3:	49 89 c4             	mov    %rax,%r12
   324a6:	4c 8d 70 ec          	lea    -0x14(%rax),%r14
   324aa:	49 f7 de             	neg    %r14
   324ad:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   324b3:	48 83 f8 14          	cmp    $0x14,%rax
   324b7:	74 25                	je     324de <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x402e>
   324b9:	4c 89 f7             	mov    %r14,%rdi
   324bc:	ff 15 ae f5 03 00    	call   *0x3f5ae(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   324c2:	48 85 c0             	test   %rax,%rax
   324c5:	0f 84 60 0c 00 00    	je     3312b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c7b>
   324cb:	49 89 c5             	mov    %rax,%r13
   324ce:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   324d2:	48 89 c7             	mov    %rax,%rdi
   324d5:	4c 89 f2             	mov    %r14,%rdx
   324d8:	ff 15 b2 f5 03 00    	call   *0x3f5b2(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   324de:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   324e3:	4c 89 74 24 18       	mov    %r14,0x18(%rsp)
   324e8:	c6 04 24 02          	movb   $0x2,(%rsp)
   324ec:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   324f1:	4c 8d a4 24 a0 00 00 	lea    0xa0(%rsp),%r12
   324f8:	00 
   324f9:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   32500:	00 
   32501:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32506:	48 89 e1             	mov    %rsp,%rcx
   32509:	4c 89 e7             	mov    %r12,%rdi
   3250c:	e8 8f 16 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32511:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   32518:	ff 
   32519:	74 0d                	je     32528 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4078>
   3251b:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32522:	00 
   32523:	e8 c8 80 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32528:	41 bd 0c 00 00 00    	mov    $0xc,%r13d
   3252e:	bf 0c 00 00 00       	mov    $0xc,%edi
   32533:	ff 15 37 f5 03 00    	call   *0x3f537(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32539:	48 85 c0             	test   %rax,%rax
   3253c:	0f 84 05 09 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   32542:	49 89 c6             	mov    %rax,%r14
   32545:	48 b8 25 23 22 84 e4 	movabs $0xcbf29ce484222325,%rax
   3254c:	9c f2 cb 
   3254f:	48 b9 77 69 72 65 5f 	movabs $0x766e665f65726977,%rcx
   32556:	66 6e 76 
   32559:	49 89 0e             	mov    %rcx,(%r14)
   3255c:	41 c7 46 08 31 61 36 	movl   $0x34366131,0x8(%r14)
   32563:	34 
   32564:	48 c7 44 24 78 0c 00 	movq   $0xc,0x78(%rsp)
   3256b:	00 00 
   3256d:	4c 89 b4 24 80 00 00 	mov    %r14,0x80(%rsp)
   32574:	00 
   32575:	48 c7 84 24 88 00 00 	movq   $0xc,0x88(%rsp)
   3257c:	00 0c 00 00 00 
   32581:	48 8b 9c 24 c0 01 00 	mov    0x1c0(%rsp),%rbx
   32588:	00 
   32589:	4d 85 ff             	test   %r15,%r15
   3258c:	0f 84 92 00 00 00    	je     32624 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4174>
   32592:	48 b9 b3 01 00 00 00 	movabs $0x100000001b3,%rcx
   32599:	01 00 00 
   3259c:	44 89 fa             	mov    %r15d,%edx
   3259f:	83 e2 03             	and    $0x3,%edx
   325a2:	49 83 ff 04          	cmp    $0x4,%r15
   325a6:	73 04                	jae    325ac <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x40fc>
   325a8:	31 f6                	xor    %esi,%esi
   325aa:	eb 52                	jmp    325fe <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x414e>
   325ac:	48 be f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rsi
   325b3:	ff ff 7f 
   325b6:	48 83 c6 0b          	add    $0xb,%rsi
   325ba:	49 21 f7             	and    %rsi,%r15
   325bd:	31 f6                	xor    %esi,%esi
   325bf:	90                   	nop
   325c0:	0f b6 3c 33          	movzbl (%rbx,%rsi,1),%edi
   325c4:	48 31 f8             	xor    %rdi,%rax
   325c7:	48 0f af c1          	imul   %rcx,%rax
   325cb:	0f b6 7c 33 01       	movzbl 0x1(%rbx,%rsi,1),%edi
   325d0:	48 31 c7             	xor    %rax,%rdi
   325d3:	48 0f af f9          	imul   %rcx,%rdi
   325d7:	44 0f b6 44 33 02    	movzbl 0x2(%rbx,%rsi,1),%r8d
   325dd:	49 31 f8             	xor    %rdi,%r8
   325e0:	4c 0f af c1          	imul   %rcx,%r8
   325e4:	0f b6 44 33 03       	movzbl 0x3(%rbx,%rsi,1),%eax
   325e9:	4c 31 c0             	xor    %r8,%rax
   325ec:	48 0f af c1          	imul   %rcx,%rax
   325f0:	48 83 c6 04          	add    $0x4,%rsi
   325f4:	49 39 f7             	cmp    %rsi,%r15
   325f7:	75 c7                	jne    325c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4110>
   325f9:	48 85 d2             	test   %rdx,%rdx
   325fc:	74 26                	je     32624 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4174>
   325fe:	48 01 de             	add    %rbx,%rsi
   32601:	31 ff                	xor    %edi,%edi
   32603:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   3260a:	84 00 00 00 00 00 
   32610:	44 0f b6 04 3e       	movzbl (%rsi,%rdi,1),%r8d
   32615:	4c 31 c0             	xor    %r8,%rax
   32618:	48 0f af c1          	imul   %rcx,%rax
   3261c:	48 ff c7             	inc    %rdi
   3261f:	48 39 fa             	cmp    %rdi,%rdx
   32622:	75 ec                	jne    32610 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4160>
   32624:	48 89 84 24 a0 00 00 	mov    %rax,0xa0(%rsp)
   3262b:	00 
   3262c:	4c 89 24 24          	mov    %r12,(%rsp)
   32630:	48 8b 05 d9 f6 03 00 	mov    0x3f6d9(%rip),%rax        # 71d10 <_DYNAMIC+0x488>
   32637:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   3263c:	48 8d 35 8d 5d fd ff 	lea    -0x2a273(%rip),%rsi        # 83d0 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x1fd>
   32643:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   32648:	48 89 e2             	mov    %rsp,%rdx
   3264b:	ff 15 df f4 03 00    	call   *0x3f4df(%rip)        # 71b30 <_DYNAMIC+0x2a8>
   32651:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   32656:	4c 8b 64 24 40       	mov    0x40(%rsp),%r12
   3265b:	4d 85 e4             	test   %r12,%r12
   3265e:	74 26                	je     32686 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41d6>
   32660:	4c 89 e7             	mov    %r12,%rdi
   32663:	ff 15 07 f4 03 00    	call   *0x3f407(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32669:	48 85 c0             	test   %rax,%rax
   3266c:	0f 84 89 0a 00 00    	je     330fb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c4b>
   32672:	49 89 c5             	mov    %rax,%r13
   32675:	48 89 c7             	mov    %rax,%rdi
   32678:	4c 89 fe             	mov    %r15,%rsi
   3267b:	4c 89 e2             	mov    %r12,%rdx
   3267e:	ff 15 0c f4 03 00    	call   *0x3f40c(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   32684:	eb 06                	jmp    3268c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x41dc>
   32686:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   3268c:	c6 04 24 03          	movb   $0x3,(%rsp)
   32690:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   32695:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   3269a:	4c 89 64 24 18       	mov    %r12,0x18(%rsp)
   3269f:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   326a6:	00 
   326a7:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   326ae:	00 
   326af:	48 8d 54 24 78       	lea    0x78(%rsp),%rdx
   326b4:	48 89 e1             	mov    %rsp,%rcx
   326b7:	e8 e4 14 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   326bc:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   326c3:	ff 
   326c4:	74 0d                	je     326d3 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4223>
   326c6:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   326cd:	00 
   326ce:	e8 1d 7f ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   326d3:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   326d9:	74 09                	je     326e4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4234>
   326db:	4c 89 ff             	mov    %r15,%rdi
   326de:	ff 15 9c f3 03 00    	call   *0x3f39c(%rip)        # 71a80 <free@GLIBC_2.2.5>
   326e4:	41 bd 08 00 00 00    	mov    $0x8,%r13d
   326ea:	bf 08 00 00 00       	mov    $0x8,%edi
   326ef:	ff 15 7b f3 03 00    	call   *0x3f37b(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   326f5:	48 85 c0             	test   %rax,%rax
   326f8:	0f 84 49 07 00 00    	je     32e47 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4997>
   326fe:	49 89 c6             	mov    %rax,%r14
   32701:	48 b8 63 68 65 63 6b 	movabs $0x6d75736b63656863,%rax
   32708:	73 75 6d 
   3270b:	49 89 06             	mov    %rax,(%r14)
   3270e:	48 c7 44 24 30 08 00 	movq   $0x8,0x30(%rsp)
   32715:	00 00 
   32717:	4c 89 74 24 38       	mov    %r14,0x38(%rsp)
   3271c:	48 c7 44 24 40 08 00 	movq   $0x8,0x40(%rsp)
   32723:	00 00 
   32725:	48 89 e6             	mov    %rsp,%rsi
   32728:	48 8b bc 24 78 01 00 	mov    0x178(%rsp),%rdi
   3272f:	00 
   32730:	ff 15 b2 f6 03 00    	call   *0x3f6b2(%rip)        # 71de8 <_DYNAMIC+0x560>
   32736:	49 89 c4             	mov    %rax,%r12
   32739:	4c 8d 78 ec          	lea    -0x14(%rax),%r15
   3273d:	49 f7 df             	neg    %r15
   32740:	41 bd 01 00 00 00    	mov    $0x1,%r13d
   32746:	48 83 f8 14          	cmp    $0x14,%rax
   3274a:	74 25                	je     32771 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x42c1>
   3274c:	4c 89 ff             	mov    %r15,%rdi
   3274f:	ff 15 1b f3 03 00    	call   *0x3f31b(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   32755:	48 85 c0             	test   %rax,%rax
   32758:	0f 84 dd 09 00 00    	je     3313b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c8b>
   3275e:	49 89 c5             	mov    %rax,%r13
   32761:	4a 8d 34 24          	lea    (%rsp,%r12,1),%rsi
   32765:	48 89 c7             	mov    %rax,%rdi
   32768:	4c 89 fa             	mov    %r15,%rdx
   3276b:	ff 15 1f f3 03 00    	call   *0x3f31f(%rip)        # 71a90 <memcpy@GLIBC_2.14>
   32771:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   32776:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   3277b:	c6 04 24 02          	movb   $0x2,(%rsp)
   3277f:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   32784:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   3278b:	00 
   3278c:	48 8d b4 24 e8 00 00 	lea    0xe8(%rsp),%rsi
   32793:	00 
   32794:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32799:	49 89 e6             	mov    %rsp,%r14
   3279c:	4c 89 f1             	mov    %r14,%rcx
   3279f:	e8 fc 13 00 00       	call   33ba0 <_RNvMsi_NtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB5_8BTreeMapNtNtBb_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueE6insertCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   327a4:	80 bc 24 a0 00 00 00 	cmpb   $0xff,0xa0(%rsp)
   327ab:	ff 
   327ac:	74 0d                	je     327bb <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x430b>
   327ae:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   327b5:	00 
   327b6:	e8 35 7e ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   327bb:	66 0f 10 84 24 e8 00 	movupd 0xe8(%rsp),%xmm0
   327c2:	00 00 
   327c4:	66 0f 11 44 24 08    	movupd %xmm0,0x8(%rsp)
   327ca:	48 8b 84 24 f8 00 00 	mov    0xf8(%rsp),%rax
   327d1:	00 
   327d2:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   327d7:	c6 04 24 05          	movb   $0x5,(%rsp)
   327db:	4c 89 b4 24 a0 00 00 	mov    %r14,0xa0(%rsp)
   327e2:	00 
   327e3:	48 8b 05 be f6 03 00 	mov    0x3f6be(%rip),%rax        # 71ea8 <_DYNAMIC+0x620>
   327ea:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   327f1:	00 
   327f2:	48 8d 3d 2f 33 fd ff 	lea    -0x2ccd1(%rip),%rdi        # 5b28 <anon.0f363c1c2085502831f1e7e323c26323.206.llvm.704920437039905144+0x102>
   327f9:	48 8d b4 24 a0 00 00 	lea    0xa0(%rsp),%rsi
   32800:	00 
   32801:	ff 15 a9 f6 03 00    	call   *0x3f6a9(%rip)        # 71eb0 <_DYNAMIC+0x628>
   32807:	48 89 e7             	mov    %rsp,%rdi
   3280a:	e8 e1 7d ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3280f:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   32816:	00 00 
   32818:	74 19                	je     32833 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4383>
   3281a:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   32821:	00 00 
   32823:	74 0e                	je     32833 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4383>
   32825:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   3282c:	00 
   3282d:	ff 15 4d f2 03 00    	call   *0x3f24d(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32833:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
   3283a:	00 
   3283b:	e8 10 78 ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32840:	48 83 bc 24 20 02 00 	cmpq   $0x0,0x220(%rsp)
   32847:	00 00 
   32849:	74 0e                	je     32859 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43a9>
   3284b:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
   32852:	00 
   32853:	ff 15 27 f2 03 00    	call   *0x3f227(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32859:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   32860:	00 
   32861:	e8 1a 7a ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32866:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   3286d:	00 00 
   3286f:	74 0e                	je     3287f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43cf>
   32871:	48 8b bc 24 d8 01 00 	mov    0x1d8(%rsp),%rdi
   32878:	00 
   32879:	ff 15 01 f2 03 00    	call   *0x3f201(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3287f:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   32886:	00 00 
   32888:	74 09                	je     32893 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x43e3>
   3288a:	48 89 df             	mov    %rbx,%rdi
   3288d:	ff 15 ed f1 03 00    	call   *0x3f1ed(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32893:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   3289a:	00 
   3289b:	e8 e0 79 ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   328a0:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   328a7:	00 
   328a8:	48 85 c9             	test   %rcx,%rcx
   328ab:	74 2a                	je     328d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4427>
   328ad:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   328b4:	00 
   328b5:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   328b9:	48 01 c1             	add    %rax,%rcx
   328bc:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   328c0:	74 15                	je     328d7 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4427>
   328c2:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   328c9:	00 
   328ca:	48 29 c7             	sub    %rax,%rdi
   328cd:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   328d1:	ff 15 a9 f1 03 00    	call   *0x3f1a9(%rip)        # 71a80 <free@GLIBC_2.2.5>
   328d7:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   328de:	00 
   328df:	e8 6c 77 ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   328e4:	48 83 bc 24 38 02 00 	cmpq   $0x0,0x238(%rsp)
   328eb:	00 00 
   328ed:	74 0e                	je     328fd <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x444d>
   328ef:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
   328f6:	00 
   328f7:	ff 15 83 f1 03 00    	call   *0x3f183(%rip)        # 71a80 <free@GLIBC_2.2.5>
   328fd:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   32902:	48 83 3b 00          	cmpq   $0x0,(%rbx)
   32906:	74 0a                	je     32912 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4462>
   32908:	48 8b 7b 08          	mov    0x8(%rbx),%rdi
   3290c:	ff 15 6e f1 03 00    	call   *0x3f16e(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32912:	48 83 7b 18 00       	cmpq   $0x0,0x18(%rbx)
   32917:	74 0a                	je     32923 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4473>
   32919:	48 8b 7b 20          	mov    0x20(%rbx),%rdi
   3291d:	ff 15 5d f1 03 00    	call   *0x3f15d(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32923:	48 8b 84 24 78 02 00 	mov    0x278(%rsp),%rax
   3292a:	00 
   3292b:	48 83 38 00          	cmpq   $0x0,(%rax)
   3292f:	74 0f                	je     32940 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4490>
   32931:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   32936:	48 8b 78 38          	mov    0x38(%rax),%rdi
   3293a:	ff 15 40 f1 03 00    	call   *0x3f140(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32940:	48 8b 84 24 58 02 00 	mov    0x258(%rsp),%rax
   32947:	00 
   32948:	48 83 38 00          	cmpq   $0x0,(%rax)
   3294c:	48 8b 5c 24 58       	mov    0x58(%rsp),%rbx
   32951:	74 0a                	je     3295d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44ad>
   32953:	48 8b 7b 50          	mov    0x50(%rbx),%rdi
   32957:	ff 15 23 f1 03 00    	call   *0x3f123(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3295d:	48 83 7b 60 00       	cmpq   $0x0,0x60(%rbx)
   32962:	74 0a                	je     3296e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44be>
   32964:	48 8b 7b 68          	mov    0x68(%rbx),%rdi
   32968:	ff 15 12 f1 03 00    	call   *0x3f112(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3296e:	48 83 7b 78 00       	cmpq   $0x0,0x78(%rbx)
   32973:	74 0d                	je     32982 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44d2>
   32975:	48 8b bb 80 00 00 00 	mov    0x80(%rbx),%rdi
   3297c:	ff 15 fe f0 03 00    	call   *0x3f0fe(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32982:	48 83 bc 24 40 02 00 	cmpq   $0x0,0x240(%rsp)
   32989:	00 00 
   3298b:	74 0b                	je     32998 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x44e8>
   3298d:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   32992:	ff 15 e8 f0 03 00    	call   *0x3f0e8(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32998:	48 81 c4 b8 02 00 00 	add    $0x2b8,%rsp
   3299f:	5b                   	pop    %rbx
   329a0:	41 5c                	pop    %r12
   329a2:	41 5d                	pop    %r13
   329a4:	41 5e                	pop    %r14
   329a6:	41 5f                	pop    %r15
   329a8:	5d                   	pop    %rbp
   329a9:	c3                   	ret
   329aa:	b3 01                	mov    $0x1,%bl
   329ac:	49 89 f6             	mov    %rsi,%r14
   329af:	bf 40 00 00 00       	mov    $0x40,%edi
   329b4:	ff 15 b6 f0 03 00    	call   *0x3f0b6(%rip)        # 71a70 <malloc@GLIBC_2.2.5>
   329ba:	48 85 c0             	test   %rax,%rax
   329bd:	0f 85 fe c2 ff ff    	jne    2ecc1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x811>
   329c3:	bf 08 00 00 00       	mov    $0x8,%edi
   329c8:	be 40 00 00 00       	mov    $0x40,%esi
   329cd:	ff 15 e5 f0 03 00    	call   *0x3f0e5(%rip)        # 71ab8 <_DYNAMIC+0x230>
   329d3:	e9 71 07 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   329d8:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   329df:	00 
   329e0:	48 8d b4 24 20 02 00 	lea    0x220(%rsp),%rsi
   329e7:	00 
   329e8:	e8 b3 7d ff ff       	call   2a7a0 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtCsgFX3jaOk65H_5alloc3vec3VecTllEEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   329ed:	e9 57 07 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   329f2:	4c 8d 3d ac 6b fd ff 	lea    -0x29454(%rip),%r15        # 95a5 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x31e>
   329f9:	4c 8d 35 e8 d7 03 00 	lea    0x3d7e8(%rip),%r14        # 701e8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x898>
   32a00:	e9 b5 00 00 00       	jmp    32aba <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x460a>
   32a05:	80 c2 d0             	add    $0xd0,%dl
   32a08:	31 c0                	xor    %eax,%eax
   32a0a:	80 fa 0a             	cmp    $0xa,%dl
   32a0d:	14 01                	adc    $0x1,%al
   32a0f:	eb 02                	jmp    32a13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4563>
   32a11:	b0 02                	mov    $0x2,%al
   32a13:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32a1a:	4c 8d 05 37 d6 03 00 	lea    0x3d637(%rip),%r8        # 70058 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x708>
   32a21:	eb 1c                	jmp    32a3f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x458f>
   32a23:	80 c2 d0             	add    $0xd0,%dl
   32a26:	31 c0                	xor    %eax,%eax
   32a28:	80 fa 0a             	cmp    $0xa,%dl
   32a2b:	14 01                	adc    $0x1,%al
   32a2d:	eb 02                	jmp    32a31 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4581>
   32a2f:	b0 02                	mov    $0x2,%al
   32a31:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32a38:	4c 8d 05 31 d6 03 00 	lea    0x3d631(%rip),%r8        # 70070 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x720>
   32a3f:	48 8d 3d f6 6b fd ff 	lea    -0x2940a(%rip),%rdi        # 963c <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   32a46:	48 8d 0d 63 d8 03 00 	lea    0x3d863(%rip),%rcx        # 702b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x960>
   32a4d:	be 2b 00 00 00       	mov    $0x2b,%esi
   32a52:	4c 89 e2             	mov    %r12,%rdx
   32a55:	ff 15 e5 f0 03 00    	call   *0x3f0e5(%rip)        # 71b40 <_DYNAMIC+0x2b8>
   32a5b:	e9 e9 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32a60:	80 c2 d0             	add    $0xd0,%dl
   32a63:	31 c0                	xor    %eax,%eax
   32a65:	80 fa 0a             	cmp    $0xa,%dl
   32a68:	14 01                	adc    $0x1,%al
   32a6a:	eb 02                	jmp    32a6e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45be>
   32a6c:	b0 02                	mov    $0x2,%al
   32a6e:	88 84 24 30 01 00 00 	mov    %al,0x130(%rsp)
   32a75:	48 8d 3d c0 6b fd ff 	lea    -0x29440(%rip),%rdi        # 963c <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   32a7c:	48 8d 0d 2d d8 03 00 	lea    0x3d82d(%rip),%rcx        # 702b0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x960>
   32a83:	4c 8d 05 6e d6 03 00 	lea    0x3d66e(%rip),%r8        # 700f8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7a8>
   32a8a:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
   32a91:	00 
   32a92:	be 2b 00 00 00       	mov    $0x2b,%esi
   32a97:	ff 15 a3 f0 03 00    	call   *0x3f0a3(%rip)        # 71b40 <_DYNAMIC+0x2b8>
   32a9d:	e9 a7 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32aa2:	bf 08 00 00 00       	mov    $0x8,%edi
   32aa7:	4c 89 e6             	mov    %r12,%rsi
   32aaa:	ff 15 58 f0 03 00    	call   *0x3f058(%rip)        # 71b08 <_DYNAMIC+0x280>
   32ab0:	e9 94 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32ab5:	be 28 00 00 00       	mov    $0x28,%esi
   32aba:	4c 89 ff             	mov    %r15,%rdi
   32abd:	4c 89 f2             	mov    %r14,%rdx
   32ac0:	ff 15 7a f1 03 00    	call   *0x3f17a(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   32ac6:	e9 7e 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32acb:	4c 8d 6c 24 30       	lea    0x30(%rsp),%r13
   32ad0:	48 8d 15 bd 5e fd ff 	lea    -0x2a143(%rip),%rdx        # 8994 <_RNvNtNtNtCskADBYZwJmSU_4core7unicode12unicode_data2cf17SHORT_OFFSET_RUNS+0x84>
   32ad7:	4c 8d 0d 9a d7 03 00 	lea    0x3d79a(%rip),%r9        # 70278 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x928>
   32ade:	31 ff                	xor    %edi,%edi
   32ae0:	4c 89 ee             	mov    %r13,%rsi
   32ae3:	31 c9                	xor    %ecx,%ecx
   32ae5:	ff 15 cd f3 03 00    	call   *0x3f3cd(%rip)        # 71eb8 <_DYNAMIC+0x630>
   32aeb:	e9 59 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32af0:	48 8d 0d 21 d8 03 00 	lea    0x3d821(%rip),%rcx        # 70318 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9c8>
   32af7:	ba 0b 00 00 00       	mov    $0xb,%edx
   32afc:	31 ff                	xor    %edi,%edi
   32afe:	4c 89 e6             	mov    %r12,%rsi
   32b01:	ff 15 f1 ef 03 00    	call   *0x3eff1(%rip)        # 71af8 <_DYNAMIC+0x270>
   32b07:	e9 3d 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b0c:	48 8d 0d 05 d3 03 00 	lea    0x3d305(%rip),%rcx        # 6fe18 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4c8>
   32b13:	ba 0c 00 00 00       	mov    $0xc,%edx
   32b18:	31 ff                	xor    %edi,%edi
   32b1a:	4c 89 e6             	mov    %r12,%rsi
   32b1d:	ff 15 d5 ef 03 00    	call   *0x3efd5(%rip)        # 71af8 <_DYNAMIC+0x270>
   32b23:	e9 21 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b28:	48 8d 0d b1 d4 03 00 	lea    0x3d4b1(%rip),%rcx        # 6ffe0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x690>
   32b2f:	4c 89 f7             	mov    %r14,%rdi
   32b32:	48 89 d6             	mov    %rdx,%rsi
   32b35:	ff 15 bd ef 03 00    	call   *0x3efbd(%rip)        # 71af8 <_DYNAMIC+0x270>
   32b3b:	e9 09 06 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b40:	48 8d 3d b5 67 fd ff 	lea    -0x2984b(%rip),%rdi        # 92fc <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x75>
   32b47:	48 8d 15 ea d3 03 00 	lea    0x3d3ea(%rip),%rdx        # 6ff38 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x5e8>
   32b4e:	be 28 00 00 00       	mov    $0x28,%esi
   32b53:	ff 15 e7 f0 03 00    	call   *0x3f0e7(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   32b59:	e9 eb 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b5e:	e8 a6 7c ff ff       	call   2a809 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedReBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32b63:	e9 e1 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b68:	48 8d 0d a9 d7 03 00 	lea    0x3d7a9(%rip),%rcx        # 70318 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9c8>
   32b6f:	ba 0b 00 00 00       	mov    $0xb,%edx
   32b74:	31 ff                	xor    %edi,%edi
   32b76:	4c 89 e6             	mov    %r12,%rsi
   32b79:	ff 15 79 ef 03 00    	call   *0x3ef79(%rip)        # 71af8 <_DYNAMIC+0x270>
   32b7f:	e9 c5 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b84:	48 8d 0d 55 d4 03 00 	lea    0x3d455(%rip),%rcx        # 6ffe0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x690>
   32b8b:	48 89 d6             	mov    %rdx,%rsi
   32b8e:	ff 15 64 ef 03 00    	call   *0x3ef64(%rip)        # 71af8 <_DYNAMIC+0x270>
   32b94:	e9 b0 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32b99:	48 8d 3d 60 68 fd ff 	lea    -0x297a0(%rip),%rdi        # 9400 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x179>
   32ba0:	48 8d 15 69 d5 03 00 	lea    0x3d569(%rip),%rdx        # 70110 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7c0>
   32ba7:	be 47 00 00 00       	mov    $0x47,%esi
   32bac:	ff 15 8e f0 03 00    	call   *0x3f08e(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   32bb2:	e9 92 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32bb7:	ff 15 d3 f2 03 00    	call   *0x3f2d3(%rip)        # 71e90 <_DYNAMIC+0x608>
   32bbd:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   32bc2:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   32bc7:	e9 d1 c5 ff ff       	jmp    2f19d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xced>
   32bcc:	48 8d 15 55 d5 03 00 	lea    0x3d555(%rip),%rdx        # 70128 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x7d8>
   32bd3:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   32bda:	00 
   32bdb:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   32be2:	00 
   32be3:	e8 f0 7b ff ff       	call   2a7d8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32be8:	e9 5c 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32bed:	31 c0                	xor    %eax,%eax
   32bef:	84 c0                	test   %al,%al
   32bf1:	0f 85 c1 d7 ff ff    	jne    303b8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1f08>
   32bf7:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32bfe:	00 
   32bff:	e8 60 7b ff ff       	call   2a764 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtB4_6option6OptionTllEEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32c04:	e9 40 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32c09:	48 8d 15 60 d5 03 00 	lea    0x3d560(%rip),%rdx        # 70170 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x820>
   32c10:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32c17:	00 
   32c18:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   32c1f:	00 
   32c20:	e8 b3 7b ff ff       	call   2a7d8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32c25:	e9 1f 05 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32c2a:	48 8d 15 57 d5 03 00 	lea    0x3d557(%rip),%rdx        # 70188 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x838>
   32c31:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   32c38:	00 
   32c39:	48 8d b4 24 08 02 00 	lea    0x208(%rsp),%rsi
   32c40:	00 
   32c41:	e8 92 7b ff ff       	call   2a7d8 <_RINvNtCskADBYZwJmSU_4core9panicking13assert_failedINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEBM_ECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32c46:	e9 fe 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32c4b:	4c 8d 35 66 d5 03 00 	lea    0x3d566(%rip),%r14        # 701b8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x868>
   32c52:	be 28 00 00 00       	mov    $0x28,%esi
   32c57:	4c 8d 3d 12 68 fd ff 	lea    -0x297ee(%rip),%r15        # 9470 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x1e9>
   32c5e:	e9 57 fe ff ff       	jmp    32aba <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x460a>
   32c63:	bf 08 00 00 00       	mov    $0x8,%edi
   32c68:	be c8 00 00 00       	mov    $0xc8,%esi
   32c6d:	ff 15 95 ee 03 00    	call   *0x3ee95(%rip)        # 71b08 <_DYNAMIC+0x280>
   32c73:	e9 d1 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32c78:	48 8d 3d 81 d1 03 00 	lea    0x3d181(%rip),%rdi        # 6fe00 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4b0>
   32c7f:	ff 15 93 ef 03 00    	call   *0x3ef93(%rip)        # 71c18 <_DYNAMIC+0x390>
   32c85:	e9 bf 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32c8a:	48 8d 3d 52 6a fd ff 	lea    -0x295ae(%rip),%rdi        # 96e3 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x45c>
   32c91:	48 8d 15 98 d6 03 00 	lea    0x3d698(%rip),%rdx        # 70330 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x9e0>
   32c98:	be 30 00 00 00       	mov    $0x30,%esi
   32c9d:	ff 15 9d ef 03 00    	call   *0x3ef9d(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   32ca3:	e9 a1 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32ca8:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   32cad:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   32cb2:	48 8d 3d 83 69 fd ff 	lea    -0x2967d(%rip),%rdi        # 963c <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x3b5>
   32cb9:	48 8d 0d d0 d5 03 00 	lea    0x3d5d0(%rip),%rcx        # 70290 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x940>
   32cc0:	4c 8d 05 09 d5 03 00 	lea    0x3d509(%rip),%r8        # 701d0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x880>
   32cc7:	48 8d 54 24 30       	lea    0x30(%rsp),%rdx
   32ccc:	be 2b 00 00 00       	mov    $0x2b,%esi
   32cd1:	ff 15 69 ee 03 00    	call   *0x3ee69(%rip)        # 71b40 <_DYNAMIC+0x2b8>
   32cd7:	e9 6d 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32cdc:	48 8d 3d 5d d3 03 00 	lea    0x3d35d(%rip),%rdi        # 70040 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6f0>
   32ce3:	ff 15 2f ef 03 00    	call   *0x3ef2f(%rip)        # 71c18 <_DYNAMIC+0x390>
   32ce9:	e9 5b 04 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32cee:	4c 89 e7             	mov    %r12,%rdi
   32cf1:	4c 89 f6             	mov    %r14,%rsi
   32cf4:	4c 89 fa             	mov    %r15,%rdx
   32cf7:	e8 e0 64 ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32cfc:	e9 37 d2 ff ff       	jmp    2ff38 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1a88>
   32d01:	4c 89 e7             	mov    %r12,%rdi
   32d04:	4c 89 f6             	mov    %r14,%rsi
   32d07:	4c 89 fa             	mov    %r15,%rdx
   32d0a:	e8 cd 64 ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32d0f:	e9 f9 d4 ff ff       	jmp    3020d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1d5d>
   32d14:	49 89 c7             	mov    %rax,%r15
   32d17:	48 89 c7             	mov    %rax,%rdi
   32d1a:	48 8b 74 24 70       	mov    0x70(%rsp),%rsi
   32d1f:	e8 7c 7c ff ff       	call   2a9a0 <_RINvNtNtNtCskADBYZwJmSU_4core5slice4sort6stable14driftsort_mainTllENCINvMNtCsgFX3jaOk65H_5alloc5sliceSBZ_7sort_byNCINvXs1o_NtNtNtB1b_11collections5btree3mapINtB1X_8BTreeMapllEINtNtNtNtB8_4iter6traits7collect12FromIteratorBZ_E9from_iterINtNtNtB2U_8adapters3map3MapINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map4IterllENCNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4mains2_0EE0E0INtNtB1b_3vec3VecBZ_EEB5c_>
   32d24:	4c 89 f8             	mov    %r15,%rax
   32d27:	4c 8b ac 24 98 00 00 	mov    0x98(%rsp),%r13
   32d2e:	00 
   32d2f:	48 8b ac 24 e0 00 00 	mov    0xe0(%rsp),%rbp
   32d36:	00 
   32d37:	48 8b 4c 24 70       	mov    0x70(%rsp),%rcx
   32d3c:	e9 11 da ff ff       	jmp    30752 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x22a2>
   32d41:	4c 89 e7             	mov    %r12,%rdi
   32d44:	4c 89 fe             	mov    %r15,%rsi
   32d47:	4c 89 f2             	mov    %r14,%rdx
   32d4a:	e8 8d 64 ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32d4f:	e9 8c da ff ff       	jmp    307e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x2330>
   32d54:	bf 01 00 00 00       	mov    $0x1,%edi
   32d59:	4c 89 fe             	mov    %r15,%rsi
   32d5c:	ff 15 56 ed 03 00    	call   *0x3ed56(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32d62:	e9 e2 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32d67:	4c 89 e7             	mov    %r12,%rdi
   32d6a:	4c 89 f6             	mov    %r14,%rsi
   32d6d:	4c 89 fa             	mov    %r15,%rdx
   32d70:	e8 67 64 ff ff       	call   291dc <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs8kuuWm0O9xc_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   32d75:	e9 df d5 ff ff       	jmp    30359 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x1ea9>
   32d7a:	b0 01                	mov    $0x1,%al
   32d7c:	e9 b0 fc ff ff       	jmp    32a31 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4581>
   32d81:	b0 01                	mov    $0x1,%al
   32d83:	e9 8b fc ff ff       	jmp    32a13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4563>
   32d88:	b0 01                	mov    $0x1,%al
   32d8a:	e9 df fc ff ff       	jmp    32a6e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45be>
   32d8f:	4c 89 bc 24 a0 00 00 	mov    %r15,0xa0(%rsp)
   32d96:	00 
   32d97:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   32d9c:	48 89 84 24 a8 00 00 	mov    %rax,0xa8(%rsp)
   32da3:	00 
   32da4:	48 89 ac 24 b0 00 00 	mov    %rbp,0xb0(%rsp)
   32dab:	00 
   32dac:	48 8d 3d d5 91 fd ff 	lea    -0x26e2b(%rip),%rdi        # bf88 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   32db3:	48 8d 0d 56 e2 03 00 	lea    0x3e256(%rip),%rcx        # 71010 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   32dba:	4c 8d 05 ff e1 03 00 	lea    0x3e1ff(%rip),%r8        # 70fc0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   32dc1:	48 8d 94 24 a0 00 00 	lea    0xa0(%rsp),%rdx
   32dc8:	00 
   32dc9:	be 2b 00 00 00       	mov    $0x2b,%esi
   32dce:	ff 15 6c ed 03 00    	call   *0x3ed6c(%rip)        # 71b40 <_DYNAMIC+0x2b8>
   32dd4:	e9 70 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32dd9:	48 8d 05 50 d4 03 00 	lea    0x3d450(%rip),%rax        # 70230 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8e0>
   32de0:	48 89 84 24 70 02 00 	mov    %rax,0x270(%rsp)
   32de7:	00 
   32de8:	48 8b bc 24 70 02 00 	mov    0x270(%rsp),%rdi
   32def:	00 
   32df0:	ff 15 9a ee 03 00    	call   *0x3ee9a(%rip)        # 71c90 <_DYNAMIC+0x408>
   32df6:	e9 4e 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32dfb:	bf 01 00 00 00       	mov    $0x1,%edi
   32e00:	4c 89 f6             	mov    %r14,%rsi
   32e03:	ff 15 af ec 03 00    	call   *0x3ecaf(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32e09:	e9 3b 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32e0e:	bf 01 00 00 00       	mov    $0x1,%edi
   32e13:	4c 89 fe             	mov    %r15,%rsi
   32e16:	ff 15 9c ec 03 00    	call   *0x3ec9c(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32e1c:	e9 28 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32e21:	bf 01 00 00 00       	mov    $0x1,%edi
   32e26:	4c 89 f6             	mov    %r14,%rsi
   32e29:	ff 15 89 ec 03 00    	call   *0x3ec89(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32e2f:	e9 15 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32e34:	bf 01 00 00 00       	mov    $0x1,%edi
   32e39:	4c 89 ee             	mov    %r13,%rsi
   32e3c:	ff 15 76 ec 03 00    	call   *0x3ec76(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32e42:	e9 02 03 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32e47:	bf 01 00 00 00       	mov    $0x1,%edi
   32e4c:	4c 89 ee             	mov    %r13,%rsi
   32e4f:	ff 15 63 ec 03 00    	call   *0x3ec63(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32e55:	e9 ef 02 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32e5a:	49 89 ed             	mov    %rbp,%r13
   32e5d:	4c 89 f8             	mov    %r15,%rax
   32e60:	4c 29 e8             	sub    %r13,%rax
   32e63:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   32e6a:	aa aa aa 
   32e6d:	48 f7 e1             	mul    %rcx
   32e70:	4d 39 ef             	cmp    %r13,%r15
   32e73:	0f 85 b1 00 00 00    	jne    32f2a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a7a>
   32e79:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   32e7f:	74 0a                	je     32e8b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x49db>
   32e81:	48 8b 3c 24          	mov    (%rsp),%rdi
   32e85:	ff 15 f5 eb 03 00    	call   *0x3ebf5(%rip)        # 71a80 <free@GLIBC_2.2.5>
   32e8b:	48 c7 84 24 30 01 00 	movq   $0x0,0x130(%rsp)
   32e92:	00 00 00 00 00 
   32e97:	b8 08 00 00 00       	mov    $0x8,%eax
   32e9c:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   32ea1:	48 c7 84 24 40 02 00 	movq   $0x0,0x240(%rsp)
   32ea8:	00 00 00 00 00 
   32ead:	45 31 f6             	xor    %r14d,%r14d
   32eb0:	48 8d 15 29 55 fd ff 	lea    -0x2aad7(%rip),%rdx        # 83e0 <anon.0f363c1c2085502831f1e7e323c26323.91.llvm.704920437039905144+0x20d>
   32eb7:	48 8d 0d 53 67 fd ff 	lea    -0x298ad(%rip),%rcx        # 9611 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x38a>
   32ebe:	4c 8d 0d 9b d3 03 00 	lea    0x3d39b(%rip),%r9        # 70260 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x910>
   32ec5:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   32ecc:	00 
   32ecd:	41 b8 45 00 00 00    	mov    $0x45,%r8d
   32ed3:	31 ff                	xor    %edi,%edi
   32ed5:	ff 15 95 ec 03 00    	call   *0x3ec95(%rip)        # 71b70 <_DYNAMIC+0x2e8>
   32edb:	e9 69 02 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32ee0:	4c 89 b4 24 30 01 00 	mov    %r14,0x130(%rsp)
   32ee7:	00 
   32ee8:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   32eed:	48 89 84 24 38 01 00 	mov    %rax,0x138(%rsp)
   32ef4:	00 
   32ef5:	48 89 9c 24 40 01 00 	mov    %rbx,0x140(%rsp)
   32efc:	00 
   32efd:	48 8d 3d 84 90 fd ff 	lea    -0x26f7c(%rip),%rdi        # bf88 <anon.d74135bdccc798679365a46b1d65ca28.153.llvm.4795996092214488023>
   32f04:	48 8d 0d 05 e1 03 00 	lea    0x3e105(%rip),%rcx        # 71010 <anon.d74135bdccc798679365a46b1d65ca28.157.llvm.4795996092214488023>
   32f0b:	4c 8d 05 ae e0 03 00 	lea    0x3e0ae(%rip),%r8        # 70fc0 <anon.d74135bdccc798679365a46b1d65ca28.141.llvm.4795996092214488023>
   32f12:	48 8d 94 24 30 01 00 	lea    0x130(%rsp),%rdx
   32f19:	00 
   32f1a:	be 2b 00 00 00       	mov    $0x2b,%esi
   32f1f:	ff 15 1b ec 03 00    	call   *0x3ec1b(%rip)        # 71b40 <_DYNAMIC+0x2b8>
   32f25:	e9 1f 02 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32f2a:	48 89 d3             	mov    %rdx,%rbx
   32f2d:	48 c1 eb 04          	shr    $0x4,%rbx
   32f31:	49 83 c5 08          	add    $0x8,%r13
   32f35:	4c 8b 35 44 eb 03 00 	mov    0x3eb44(%rip),%r14        # 71a80 <free@GLIBC_2.2.5>
   32f3c:	eb 0f                	jmp    32f4d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a9d>
   32f3e:	66 90                	xchg   %ax,%ax
   32f40:	49 83 c5 18          	add    $0x18,%r13
   32f44:	48 ff cb             	dec    %rbx
   32f47:	0f 84 2c ff ff ff    	je     32e79 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x49c9>
   32f4d:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   32f52:	74 ec                	je     32f40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a90>
   32f54:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   32f58:	41 ff d6             	call   *%r14
   32f5b:	eb e3                	jmp    32f40 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4a90>
   32f5d:	48 c7 84 24 30 01 00 	movq   $0x1,0x130(%rsp)
   32f64:	00 01 00 00 00 
   32f69:	b8 04 00 00 00       	mov    $0x4,%eax
   32f6e:	48 89 84 24 38 02 00 	mov    %rax,0x238(%rsp)
   32f75:	00 
   32f76:	48 8d 15 93 54 fd ff 	lea    -0x2ab6d(%rip),%rdx        # 8410 <anon.574165b9a1e3cebd535338bb0d7973a0.751.llvm.2316785571840406366+0x20>
   32f7d:	4c 8d 0d c4 d2 03 00 	lea    0x3d2c4(%rip),%r9        # 70248 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x8f8>
   32f84:	48 8d b4 24 30 01 00 	lea    0x130(%rsp),%rsi
   32f8b:	00 
   32f8c:	31 ff                	xor    %edi,%edi
   32f8e:	31 c9                	xor    %ecx,%ecx
   32f90:	ff 15 da eb 03 00    	call   *0x3ebda(%rip)        # 71b70 <_DYNAMIC+0x2e8>
   32f96:	e9 ae 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32f9b:	bf 08 00 00 00       	mov    $0x8,%edi
   32fa0:	e9 c1 b5 ff ff       	jmp    2e566 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0xb6>
   32fa5:	bf 04 00 00 00       	mov    $0x4,%edi
   32faa:	be 20 00 00 00       	mov    $0x20,%esi
   32faf:	ff 15 03 eb 03 00    	call   *0x3eb03(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32fb5:	e9 8f 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32fba:	31 c0                	xor    %eax,%eax
   32fbc:	e9 52 fa ff ff       	jmp    32a13 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4563>
   32fc1:	be 1d 00 00 00       	mov    $0x1d,%esi
   32fc6:	48 89 ca             	mov    %rcx,%rdx
   32fc9:	ff 15 71 ec 03 00    	call   *0x3ec71(%rip)        # 71c40 <_DYNAMIC+0x3b8>
   32fcf:	e9 75 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32fd4:	31 c0                	xor    %eax,%eax
   32fd6:	e9 56 fa ff ff       	jmp    32a31 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4581>
   32fdb:	31 c0                	xor    %eax,%eax
   32fdd:	e9 8c fa ff ff       	jmp    32a6e <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x45be>
   32fe2:	bf 01 00 00 00       	mov    $0x1,%edi
   32fe7:	be 15 00 00 00       	mov    $0x15,%esi
   32fec:	ff 15 c6 ea 03 00    	call   *0x3eac6(%rip)        # 71ab8 <_DYNAMIC+0x230>
   32ff2:	e9 52 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   32ff7:	bf 01 00 00 00       	mov    $0x1,%edi
   32ffc:	be 79 00 00 00       	mov    $0x79,%esi
   33001:	ff 15 b1 ea 03 00    	call   *0x3eab1(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33007:	e9 3d 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3300c:	bf 01 00 00 00       	mov    $0x1,%edi
   33011:	be 53 00 00 00       	mov    $0x53,%esi
   33016:	ff 15 9c ea 03 00    	call   *0x3ea9c(%rip)        # 71ab8 <_DYNAMIC+0x230>
   3301c:	e9 28 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   33021:	bf 01 00 00 00       	mov    $0x1,%edi
   33026:	be 04 00 00 00       	mov    $0x4,%esi
   3302b:	ff 15 87 ea 03 00    	call   *0x3ea87(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33031:	e9 13 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   33036:	bf 01 00 00 00       	mov    $0x1,%edi
   3303b:	48 89 de             	mov    %rbx,%rsi
   3303e:	ff 15 74 ea 03 00    	call   *0x3ea74(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33044:	e9 00 01 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   33049:	bf 01 00 00 00       	mov    $0x1,%edi
   3304e:	48 89 de             	mov    %rbx,%rsi
   33051:	ff 15 61 ea 03 00    	call   *0x3ea61(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33057:	e9 ed 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3305c:	bf 01 00 00 00       	mov    $0x1,%edi
   33061:	48 89 de             	mov    %rbx,%rsi
   33064:	ff 15 4e ea 03 00    	call   *0x3ea4e(%rip)        # 71ab8 <_DYNAMIC+0x230>
   3306a:	e9 da 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3306f:	bf 01 00 00 00       	mov    $0x1,%edi
   33074:	4c 89 e6             	mov    %r12,%rsi
   33077:	ff 15 3b ea 03 00    	call   *0x3ea3b(%rip)        # 71ab8 <_DYNAMIC+0x230>
   3307d:	e9 c7 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   33082:	bf 01 00 00 00       	mov    $0x1,%edi
   33087:	4c 89 f6             	mov    %r14,%rsi
   3308a:	ff 15 28 ea 03 00    	call   *0x3ea28(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33090:	e9 b4 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   33095:	bf 01 00 00 00       	mov    $0x1,%edi
   3309a:	4c 89 fe             	mov    %r15,%rsi
   3309d:	ff 15 15 ea 03 00    	call   *0x3ea15(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330a3:	e9 a1 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330a8:	bf 01 00 00 00       	mov    $0x1,%edi
   330ad:	4c 89 fe             	mov    %r15,%rsi
   330b0:	ff 15 02 ea 03 00    	call   *0x3ea02(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330b6:	e9 8e 00 00 00       	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330bb:	bf 01 00 00 00       	mov    $0x1,%edi
   330c0:	4c 89 fe             	mov    %r15,%rsi
   330c3:	ff 15 ef e9 03 00    	call   *0x3e9ef(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330c9:	eb 7e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330cb:	bf 01 00 00 00       	mov    $0x1,%edi
   330d0:	48 89 de             	mov    %rbx,%rsi
   330d3:	ff 15 df e9 03 00    	call   *0x3e9df(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330d9:	eb 6e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330db:	bf 01 00 00 00       	mov    $0x1,%edi
   330e0:	48 89 de             	mov    %rbx,%rsi
   330e3:	ff 15 cf e9 03 00    	call   *0x3e9cf(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330e9:	eb 5e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330eb:	bf 01 00 00 00       	mov    $0x1,%edi
   330f0:	48 89 de             	mov    %rbx,%rsi
   330f3:	ff 15 bf e9 03 00    	call   *0x3e9bf(%rip)        # 71ab8 <_DYNAMIC+0x230>
   330f9:	eb 4e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   330fb:	bf 01 00 00 00       	mov    $0x1,%edi
   33100:	4c 89 e6             	mov    %r12,%rsi
   33103:	ff 15 af e9 03 00    	call   *0x3e9af(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33109:	eb 3e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3310b:	bf 01 00 00 00       	mov    $0x1,%edi
   33110:	4c 89 f6             	mov    %r14,%rsi
   33113:	ff 15 9f e9 03 00    	call   *0x3e99f(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33119:	eb 2e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3311b:	bf 01 00 00 00       	mov    $0x1,%edi
   33120:	4c 89 f6             	mov    %r14,%rsi
   33123:	ff 15 8f e9 03 00    	call   *0x3e98f(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33129:	eb 1e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3312b:	bf 01 00 00 00       	mov    $0x1,%edi
   33130:	4c 89 f6             	mov    %r14,%rsi
   33133:	ff 15 7f e9 03 00    	call   *0x3e97f(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33139:	eb 0e                	jmp    33149 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4c99>
   3313b:	bf 01 00 00 00       	mov    $0x1,%edi
   33140:	4c 89 fe             	mov    %r15,%rsi
   33143:	ff 15 6f e9 03 00    	call   *0x3e96f(%rip)        # 71ab8 <_DYNAMIC+0x230>
   33149:	0f 0b                	ud2
   3314b:	49 89 c4             	mov    %rax,%r12
   3314e:	4d 85 f6             	test   %r14,%r14
   33151:	0f 84 e0 04 00 00    	je     33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   33157:	4c 89 ff             	mov    %r15,%rdi
   3315a:	ff 15 20 e9 03 00    	call   *0x3e920(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33160:	e9 d2 04 00 00       	jmp    33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   33165:	49 89 c4             	mov    %rax,%r12
   33168:	e9 73 05 00 00       	jmp    336e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5230>
   3316d:	49 89 c4             	mov    %rax,%r12
   33170:	4c 89 f7             	mov    %r14,%rdi
   33173:	ff 15 07 e9 03 00    	call   *0x3e907(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33179:	eb 20                	jmp    3319b <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4ceb>
   3317b:	eb 1b                	jmp    33198 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4ce8>
   3317d:	eb 75                	jmp    331f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d44>
   3317f:	eb 73                	jmp    331f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d44>
   33181:	eb 71                	jmp    331f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d44>
   33183:	49 89 c4             	mov    %rax,%r12
   33186:	48 89 e7             	mov    %rsp,%rdi
   33189:	e8 62 74 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3318e:	e9 65 04 00 00       	jmp    335f8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5148>
   33193:	e9 64 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   33198:	49 89 c4             	mov    %rax,%r12
   3319b:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   331a1:	0f 84 58 01 00 00    	je     332ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4f>
   331a7:	4c 89 ff             	mov    %r15,%rdi
   331aa:	ff 15 d0 e8 03 00    	call   *0x3e8d0(%rip)        # 71a80 <free@GLIBC_2.2.5>
   331b0:	e9 4a 01 00 00       	jmp    332ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4f>
   331b5:	eb 3d                	jmp    331f4 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d44>
   331b7:	e9 40 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331bc:	e9 3b 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331c1:	e9 36 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331c6:	e9 31 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331cb:	e9 2c 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331d0:	e9 27 01 00 00       	jmp    332fc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4c>
   331d5:	49 89 c4             	mov    %rax,%r12
   331d8:	4c 89 f7             	mov    %r14,%rdi
   331db:	ff 15 9f e8 03 00    	call   *0x3e89f(%rip)        # 71a80 <free@GLIBC_2.2.5>
   331e1:	eb 72                	jmp    33255 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4da5>
   331e3:	e9 aa 00 00 00       	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   331e8:	e9 a5 00 00 00       	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   331ed:	e9 a0 00 00 00       	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   331f2:	eb 5e                	jmp    33252 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4da2>
   331f4:	49 89 c4             	mov    %rax,%r12
   331f7:	4c 89 f7             	mov    %r14,%rdi
   331fa:	ff 15 80 e8 03 00    	call   *0x3e880(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33200:	e9 fa 00 00 00       	jmp    332ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4f>
   33205:	eb 02                	jmp    33209 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d59>
   33207:	eb 00                	jmp    33209 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4d59>
   33209:	49 89 c4             	mov    %rax,%r12
   3320c:	48 89 df             	mov    %rbx,%rdi
   3320f:	ff 15 6b e8 03 00    	call   *0x3e86b(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33215:	e9 e5 00 00 00       	jmp    332ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e4f>
   3321a:	49 89 c4             	mov    %rax,%r12
   3321d:	48 89 e7             	mov    %rsp,%rdi
   33220:	e8 cb 73 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33225:	e9 33 03 00 00       	jmp    3355d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50ad>
   3322a:	e9 6d 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3322f:	eb 61                	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   33231:	eb 67                	jmp    3329a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4dea>
   33233:	eb 65                	jmp    3329a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4dea>
   33235:	eb 63                	jmp    3329a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4dea>
   33237:	eb 59                	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   33239:	e9 5e 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3323e:	e9 59 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33243:	e9 54 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33248:	e9 4f 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3324d:	e9 4a 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33252:	49 89 c4             	mov    %rax,%r12
   33255:	48 83 7c 24 78 00    	cmpq   $0x0,0x78(%rsp)
   3325b:	0f 84 19 02 00 00    	je     3347a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fca>
   33261:	4c 89 ff             	mov    %r15,%rdi
   33264:	e9 0b 02 00 00       	jmp    33474 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fc4>
   33269:	eb 27                	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   3326b:	e9 2c 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33270:	e9 27 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33275:	e9 22 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3327a:	e9 1d 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3327f:	e9 18 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33284:	e9 13 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   33289:	e9 0e 01 00 00       	jmp    3339c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4eec>
   3328e:	eb 02                	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   33290:	eb 00                	jmp    33292 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4de2>
   33292:	49 89 c4             	mov    %rax,%r12
   33295:	e9 d7 01 00 00       	jmp    33471 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fc1>
   3329a:	49 89 c4             	mov    %rax,%r12
   3329d:	48 89 df             	mov    %rbx,%rdi
   332a0:	e9 cf 01 00 00       	jmp    33474 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fc4>
   332a5:	49 89 c4             	mov    %rax,%r12
   332a8:	e9 fc 03 00 00       	jmp    336a9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51f9>
   332ad:	49 89 c4             	mov    %rax,%r12
   332b0:	e9 8f 03 00 00       	jmp    33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   332b5:	49 89 c4             	mov    %rax,%r12
   332b8:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
   332bf:	00 00 
   332c1:	0f 84 8e 04 00 00    	je     33755 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52a5>
   332c7:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   332ce:	00 
   332cf:	e9 7b 04 00 00       	jmp    3374f <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x529f>
   332d4:	e9 69 04 00 00       	jmp    33742 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5292>
   332d9:	e9 24 02 00 00       	jmp    33502 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5052>
   332de:	49 89 c4             	mov    %rax,%r12
   332e1:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   332e6:	0f 84 4b 03 00 00    	je     33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   332ec:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   332f1:	ff 15 89 e7 03 00    	call   *0x3e789(%rip)        # 71a80 <free@GLIBC_2.2.5>
   332f7:	e9 3b 03 00 00       	jmp    33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   332fc:	49 89 c4             	mov    %rax,%r12
   332ff:	48 8d bc 24 e8 00 00 	lea    0xe8(%rsp),%rdi
   33306:	00 
   33307:	e8 94 21 00 00       	call   354a0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3330c:	e9 e7 02 00 00       	jmp    335f8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5148>
   33311:	49 89 c4             	mov    %rax,%r12
   33314:	4d 85 f6             	test   %r14,%r14
   33317:	0f 85 ef 03 00 00    	jne    3370c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x525c>
   3331d:	48 83 bc 24 40 02 00 	cmpq   $0x0,0x240(%rsp)
   33324:	00 00 
   33326:	0f 84 49 04 00 00    	je     33775 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52c5>
   3332c:	48 8b 7c 24 58       	mov    0x58(%rsp),%rdi
   33331:	ff 15 49 e7 03 00    	call   *0x3e749(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33337:	4c 89 e7             	mov    %r12,%rdi
   3333a:	e8 71 af 03 00       	call   6e2b0 <_Unwind_Resume@plt>
   3333f:	e9 78 00 00 00       	jmp    333bc <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f0c>
   33344:	e9 b6 00 00 00       	jmp    333ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f4f>
   33349:	e9 b1 00 00 00       	jmp    333ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f4f>
   3334e:	e9 ac 00 00 00       	jmp    333ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f4f>
   33353:	49 89 c4             	mov    %rax,%r12
   33356:	48 8d 7c 24 78       	lea    0x78(%rsp),%rdi
   3335b:	e8 90 72 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33360:	e9 f8 01 00 00       	jmp    3355d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50ad>
   33365:	ff 15 bd e7 03 00    	call   *0x3e7bd(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   3336b:	49 89 c4             	mov    %rax,%r12
   3336e:	4d 85 ed             	test   %r13,%r13
   33371:	0f 84 1e 02 00 00    	je     33595 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50e5>
   33377:	49 83 c7 20          	add    $0x20,%r15
   3337b:	49 f7 dd             	neg    %r13
   3337e:	66 90                	xchg   %ax,%ax
   33380:	4c 89 ff             	mov    %r15,%rdi
   33383:	e8 68 72 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33388:	49 83 c7 20          	add    $0x20,%r15
   3338c:	49 ff cd             	dec    %r13
   3338f:	75 ef                	jne    33380 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4ed0>
   33391:	e9 ff 01 00 00       	jmp    33595 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50e5>
   33396:	ff 15 8c e7 03 00    	call   *0x3e78c(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   3339c:	49 89 c4             	mov    %rax,%r12
   3339f:	e9 d6 00 00 00       	jmp    3347a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fca>
   333a4:	49 89 c4             	mov    %rax,%r12
   333a7:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
   333ae:	00 00 
   333b0:	74 1d                	je     333cf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f1f>
   333b2:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   333b9:	00 
   333ba:	eb 0d                	jmp    333c9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f19>
   333bc:	49 89 c4             	mov    %rax,%r12
   333bf:	4d 85 ff             	test   %r15,%r15
   333c2:	74 0b                	je     333cf <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f1f>
   333c4:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   333c9:	ff 15 b1 e6 03 00    	call   *0x3e6b1(%rip)        # 71a80 <free@GLIBC_2.2.5>
   333cf:	48 8d bc 24 30 01 00 	lea    0x130(%rsp),%rdi
   333d6:	00 
   333d7:	e8 24 71 ff ff       	call   2a500 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCs8ZKwes1zzDd_3std3env4ArgsECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   333dc:	48 8d bc 24 90 01 00 	lea    0x190(%rsp),%rdi
   333e3:	00 
   333e4:	e8 47 6d ff ff       	call   2a130 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsgFX3jaOk65H_5alloc3vec3VecNtNtBG_6string6StringEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   333e9:	4c 89 e7             	mov    %r12,%rdi
   333ec:	e8 bf ae 03 00       	call   6e2b0 <_Unwind_Resume@plt>
   333f1:	eb 5a                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   333f3:	eb 58                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   333f5:	eb 56                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   333f7:	eb 06                	jmp    333ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f4f>
   333f9:	eb 52                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   333fb:	eb 02                	jmp    333ff <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f4f>
   333fd:	eb 4e                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   333ff:	49 89 c4             	mov    %rax,%r12
   33402:	48 89 df             	mov    %rbx,%rdi
   33405:	ff 15 75 e6 03 00    	call   *0x3e675(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3340b:	eb 43                	jmp    33450 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4fa0>
   3340d:	e9 e3 01 00 00       	jmp    335f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5145>
   33412:	e9 de 01 00 00       	jmp    335f5 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5145>
   33417:	49 89 c4             	mov    %rax,%r12
   3341a:	41 be 06 00 00 00    	mov    $0x6,%r14d
   33420:	48 83 bc 24 30 01 00 	cmpq   $0x0,0x130(%rsp)
   33427:	00 00 
   33429:	0f 84 dd 02 00 00    	je     3370c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x525c>
   3342f:	48 8b bc 24 38 01 00 	mov    0x138(%rsp),%rdi
   33436:	00 
   33437:	e9 ca 02 00 00       	jmp    33706 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5256>
   3343c:	e9 f3 01 00 00       	jmp    33634 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5184>
   33441:	e9 14 01 00 00       	jmp    3355a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50aa>
   33446:	eb 05                	jmp    3344d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4f9d>
   33448:	e9 cf 00 00 00       	jmp    3351c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x506c>
   3344d:	49 89 c4             	mov    %rax,%r12
   33450:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   33457:	00 
   33458:	e8 43 20 00 00       	call   354a0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3345d:	e9 fb 00 00 00       	jmp    3355d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50ad>
   33462:	0f 0b                	ud2
   33464:	49 89 c4             	mov    %rax,%r12
   33467:	48 8d 7c 24 30       	lea    0x30(%rsp),%rdi
   3346c:	e8 0f 71 ff ff       	call   2a580 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5error5ErrorECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33471:	4c 89 f7             	mov    %r14,%rdi
   33474:	ff 15 06 e6 03 00    	call   *0x3e606(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3347a:	48 8d bc 24 18 01 00 	lea    0x118(%rsp),%rdi
   33481:	00 
   33482:	e8 19 20 00 00       	call   354a0 <_RNvXNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3mapINtB2_8BTreeMapNtNtB8_6string6StringNtNtCseZmxtRzJJaS_10serde_json5value5ValueENtNtNtCskADBYZwJmSU_4core3ops4drop4Drop4dropCs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33487:	e9 d1 00 00 00       	jmp    3355d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50ad>
   3348c:	ff 15 96 e6 03 00    	call   *0x3e696(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   33492:	4c 89 e7             	mov    %r12,%rdi
   33495:	ff 15 e5 e5 03 00    	call   *0x3e5e5(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3349b:	0f 0b                	ud2
   3349d:	0f 0b                	ud2
   3349f:	49 89 c4             	mov    %rax,%r12
   334a2:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   334a9:	00 
   334aa:	e8 d1 6d ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   334af:	e9 83 01 00 00       	jmp    33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   334b4:	e9 a1 00 00 00       	jmp    3355a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50aa>
   334b9:	49 89 c4             	mov    %rax,%r12
   334bc:	48 8d bc 24 a0 00 00 	lea    0xa0(%rsp),%rdi
   334c3:	00 
   334c4:	e8 b7 6d ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   334c9:	e9 69 01 00 00       	jmp    33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   334ce:	eb 54                	jmp    33524 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5074>
   334d0:	49 89 c4             	mov    %rax,%r12
   334d3:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   334d8:	0f 84 66 01 00 00    	je     33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   334de:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   334e4:	0f 84 5a 01 00 00    	je     33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   334ea:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   334ef:	ff 15 8b e5 03 00    	call   *0x3e58b(%rip)        # 71a80 <free@GLIBC_2.2.5>
   334f5:	e9 4a 01 00 00       	jmp    33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   334fa:	49 89 c4             	mov    %rax,%r12
   334fd:	e9 5b 01 00 00       	jmp    3365d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ad>
   33502:	49 89 c4             	mov    %rax,%r12
   33505:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   3350a:	0f 84 4d 01 00 00    	je     3365d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ad>
   33510:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   33515:	e9 3d 01 00 00       	jmp    33657 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51a7>
   3351a:	eb 08                	jmp    33524 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5074>
   3351c:	49 89 c4             	mov    %rax,%r12
   3351f:	e9 46 01 00 00       	jmp    3366a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ba>
   33524:	49 89 c4             	mov    %rax,%r12
   33527:	48 89 ef             	mov    %rbp,%rdi
   3352a:	ff 15 50 e5 03 00    	call   *0x3e550(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33530:	e9 35 01 00 00       	jmp    3366a <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ba>
   33535:	49 89 c4             	mov    %rax,%r12
   33538:	48 83 bc 24 a0 00 00 	cmpq   $0x0,0xa0(%rsp)
   3353f:	00 00 
   33541:	0f 84 fd 00 00 00    	je     33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   33547:	48 8b bc 24 a8 00 00 	mov    0xa8(%rsp),%rdi
   3354e:	00 
   3354f:	ff 15 2b e5 03 00    	call   *0x3e52b(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33555:	e9 ea 00 00 00       	jmp    33644 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5194>
   3355a:	49 89 c4             	mov    %rax,%r12
   3355d:	4c 8b b4 24 f8 01 00 	mov    0x1f8(%rsp),%r14
   33564:	00 
   33565:	48 8b 84 24 00 02 00 	mov    0x200(%rsp),%rax
   3356c:	00 
   3356d:	48 85 c0             	test   %rax,%rax
   33570:	74 23                	je     33595 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50e5>
   33572:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   33578:	49 29 c7             	sub    %rax,%r15
   3357b:	4c 89 f3             	mov    %r14,%rbx
   3357e:	66 90                	xchg   %ax,%ax
   33580:	48 89 df             	mov    %rbx,%rdi
   33583:	e8 68 70 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33588:	48 83 c3 20          	add    $0x20,%rbx
   3358c:	49 ff c7             	inc    %r15
   3358f:	49 83 ff 01          	cmp    $0x1,%r15
   33593:	75 eb                	jne    33580 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x50d0>
   33595:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   3359c:	00 00 
   3359e:	74 58                	je     335f8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5148>
   335a0:	4c 89 f7             	mov    %r14,%rdi
   335a3:	ff 15 d7 e4 03 00    	call   *0x3e4d7(%rip)        # 71a80 <free@GLIBC_2.2.5>
   335a9:	eb 4d                	jmp    335f8 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5148>
   335ab:	4d 85 ff             	test   %r15,%r15
   335ae:	74 21                	je     335d1 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5121>
   335b0:	48 83 c3 20          	add    $0x20,%rbx
   335b4:	49 f7 df             	neg    %r15
   335b7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   335be:	00 00 
   335c0:	48 89 df             	mov    %rbx,%rdi
   335c3:	e8 28 70 ff ff       	call   2a5f0 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueNtNtCseZmxtRzJJaS_10serde_json5value5ValueECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   335c8:	48 83 c3 20          	add    $0x20,%rbx
   335cc:	49 ff cf             	dec    %r15
   335cf:	75 ef                	jne    335c0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5110>
   335d1:	48 83 bc 24 f0 01 00 	cmpq   $0x0,0x1f0(%rsp)
   335d8:	00 00 
   335da:	0f 84 5c 01 00 00    	je     3373c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x528c>
   335e0:	4c 89 f7             	mov    %r14,%rdi
   335e3:	ff 15 97 e4 03 00    	call   *0x3e497(%rip)        # 71a80 <free@GLIBC_2.2.5>
   335e9:	ff 15 39 e5 03 00    	call   *0x3e539(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   335ef:	ff 15 33 e5 03 00    	call   *0x3e533(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   335f5:	49 89 c4             	mov    %rax,%r12
   335f8:	48 83 bc 24 90 01 00 	cmpq   $0x0,0x190(%rsp)
   335ff:	00 00 
   33601:	74 34                	je     33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   33603:	48 83 bc 24 a0 01 00 	cmpq   $0x0,0x1a0(%rsp)
   3360a:	00 00 
   3360c:	74 29                	je     33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   3360e:	48 8b bc 24 a8 01 00 	mov    0x1a8(%rsp),%rdi
   33615:	00 
   33616:	ff 15 64 e4 03 00    	call   *0x3e464(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3361c:	eb 19                	jmp    33637 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5187>
   3361e:	49 89 c4             	mov    %rax,%r12
   33621:	e9 c7 00 00 00       	jmp    336ed <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x523d>
   33626:	49 89 c4             	mov    %rax,%r12
   33629:	41 be 06 00 00 00    	mov    $0x6,%r14d
   3362f:	e9 d8 00 00 00       	jmp    3370c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x525c>
   33634:	49 89 c4             	mov    %rax,%r12
   33637:	48 8b bc 24 e8 01 00 	mov    0x1e8(%rsp),%rdi
   3363e:	00 
   3363f:	e8 0c 6a ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   33644:	48 83 bc 24 20 02 00 	cmpq   $0x0,0x220(%rsp)
   3364b:	00 00 
   3364d:	74 0e                	je     3365d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ad>
   3364f:	48 8b bc 24 28 02 00 	mov    0x228(%rsp),%rdi
   33656:	00 
   33657:	ff 15 23 e4 03 00    	call   *0x3e423(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3365d:	48 8d bc 24 a0 02 00 	lea    0x2a0(%rsp),%rdi
   33664:	00 
   33665:	e8 16 6c ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   3366a:	48 83 bc 24 d0 01 00 	cmpq   $0x0,0x1d0(%rsp)
   33671:	00 00 
   33673:	74 0e                	je     33683 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51d3>
   33675:	48 8b bc 24 d8 01 00 	mov    0x1d8(%rsp),%rdi
   3367c:	00 
   3367d:	ff 15 fd e3 03 00    	call   *0x3e3fd(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33683:	48 83 bc 24 b8 01 00 	cmpq   $0x0,0x1b8(%rsp)
   3368a:	00 00 
   3368c:	74 0e                	je     3369c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x51ec>
   3368e:	48 8b bc 24 c0 01 00 	mov    0x1c0(%rsp),%rdi
   33695:	00 
   33696:	ff 15 e4 e3 03 00    	call   *0x3e3e4(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3369c:	48 8d bc 24 08 02 00 	lea    0x208(%rsp),%rdi
   336a3:	00 
   336a4:	e8 d7 6b ff ff       	call   2a280 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCsgFX3jaOk65H_5alloc11collections5btree3map8BTreeMapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   336a9:	48 8b 8c 24 38 01 00 	mov    0x138(%rsp),%rcx
   336b0:	00 
   336b1:	48 85 c9             	test   %rcx,%rcx
   336b4:	74 2a                	je     336e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5230>
   336b6:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   336bd:	00 
   336be:	48 83 e0 f0          	and    $0xfffffffffffffff0,%rax
   336c2:	48 01 c1             	add    %rax,%rcx
   336c5:	48 83 f9 df          	cmp    $0xffffffffffffffdf,%rcx
   336c9:	74 15                	je     336e0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5230>
   336cb:	48 8b bc 24 30 01 00 	mov    0x130(%rsp),%rdi
   336d2:	00 
   336d3:	48 29 c7             	sub    %rax,%rdi
   336d6:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   336da:	ff 15 a0 e3 03 00    	call   *0x3e3a0(%rip)        # 71a80 <free@GLIBC_2.2.5>
   336e0:	48 8b bc 24 10 01 00 	mov    0x110(%rsp),%rdi
   336e7:	00 
   336e8:	e8 63 69 ff ff       	call   2a050 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs8kuuWm0O9xc_4pbrs3map3MapllEECs1BH2C1Ao1SA_24pbrs_map_iteration_proof>
   336ed:	41 be 06 00 00 00    	mov    $0x6,%r14d
   336f3:	48 83 bc 24 38 02 00 	cmpq   $0x0,0x238(%rsp)
   336fa:	00 00 
   336fc:	74 0e                	je     3370c <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x525c>
   336fe:	48 8b bc 24 08 01 00 	mov    0x108(%rsp),%rdi
   33705:	00 
   33706:	ff 15 74 e3 03 00    	call   *0x3e374(%rip)        # 71a80 <free@GLIBC_2.2.5>
   3370c:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   33711:	48 8d 58 08          	lea    0x8(%rax),%rbx
   33715:	4c 8b 3d 64 e3 03 00 	mov    0x3e364(%rip),%r15        # 71a80 <free@GLIBC_2.2.5>
   3371c:	eb 0f                	jmp    3372d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x527d>
   3371e:	66 90                	xchg   %ax,%ax
   33720:	48 83 c3 18          	add    $0x18,%rbx
   33724:	49 ff ce             	dec    %r14
   33727:	0f 84 f0 fb ff ff    	je     3331d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x4e6d>
   3372d:	48 83 7b f8 00       	cmpq   $0x0,-0x8(%rbx)
   33732:	74 ec                	je     33720 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5270>
   33734:	48 8b 3b             	mov    (%rbx),%rdi
   33737:	41 ff d7             	call   *%r15
   3373a:	eb e4                	jmp    33720 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5270>
   3373c:	ff 15 e6 e3 03 00    	call   *0x3e3e6(%rip)        # 71b28 <_DYNAMIC+0x2a0>
   33742:	49 89 c4             	mov    %rax,%r12
   33745:	4d 85 f6             	test   %r14,%r14
   33748:	74 0b                	je     33755 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52a5>
   3374a:	48 8b 7c 24 68       	mov    0x68(%rsp),%rdi
   3374f:	ff 15 2b e3 03 00    	call   *0x3e32b(%rip)        # 71a80 <free@GLIBC_2.2.5>
   33755:	4c 89 f8             	mov    %r15,%rax
   33758:	48 29 e8             	sub    %rbp,%rax
   3375b:	48 b9 ab aa aa aa aa 	movabs $0xaaaaaaaaaaaaaaab,%rcx
   33762:	aa aa aa 
   33765:	48 f7 e1             	mul    %rcx
   33768:	49 39 ef             	cmp    %rbp,%r15
   3376b:	75 10                	jne    3377d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52cd>
   3376d:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   33773:	75 44                	jne    337b9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x5309>
   33775:	4c 89 e7             	mov    %r12,%rdi
   33778:	e8 33 ab 03 00       	call   6e2b0 <_Unwind_Resume@plt>
   3377d:	48 89 d3             	mov    %rdx,%rbx
   33780:	48 c1 eb 04          	shr    $0x4,%rbx
   33784:	49 83 c5 20          	add    $0x20,%r13
   33788:	4c 8b 35 f1 e2 03 00 	mov    0x3e2f1(%rip),%r14        # 71a80 <free@GLIBC_2.2.5>
   3378f:	eb 18                	jmp    337a9 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52f9>
   33791:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   33798:	0f 1f 84 00 00 00 00 
   3379f:	00 
   337a0:	49 83 c5 18          	add    $0x18,%r13
   337a4:	48 ff cb             	dec    %rbx
   337a7:	74 c4                	je     3376d <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52bd>
   337a9:	49 83 7d f8 00       	cmpq   $0x0,-0x8(%r13)
   337ae:	74 f0                	je     337a0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52f0>
   337b0:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   337b4:	41 ff d6             	call   *%r14
   337b7:	eb e7                	jmp    337a0 <_RNvCs1BH2C1Ao1SA_24pbrs_map_iteration_proof4main+0x52f0>
   337b9:	48 8b 3c 24          	mov    (%rsp),%rdi
   337bd:	ff 15 bd e2 03 00    	call   *0x3e2bd(%rip)        # 71a80 <free@GLIBC_2.2.5>
   337c3:	4c 89 e7             	mov    %r12,%rdi
   337c6:	e8 e5 aa 03 00       	call   6e2b0 <_Unwind_Resume@plt>
