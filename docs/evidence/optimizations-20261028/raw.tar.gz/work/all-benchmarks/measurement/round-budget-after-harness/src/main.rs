use pbrs_grpc::ByteBudgetTracker;
use std::hint::black_box;
use std::sync::{Arc, Barrier};
use std::time::Instant;

fn cpu_ns() -> u64 {
    let mut ts = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    let ok = unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) };
    assert_eq!(ok, 0);
    u64::try_from(ts.tv_sec).unwrap() * 1_000_000_000 + u64::try_from(ts.tv_nsec).unwrap()
}

fn run(threads: usize, bytes: usize, iterations: usize) -> (u64, u128) {
    let tracker = Arc::new(ByteBudgetTracker::unlimited());
    let warm: Vec<_> = (0..threads).map(|_| tracker.try_acquire(bytes).unwrap()).collect();
    drop(warm);
    let start = Arc::new(Barrier::new(threads + 1));
    let (cpu, wall) = std::thread::scope(|scope| {
        let handles: Vec<_> = (0..threads).map(|_| {
            let tracker = Arc::clone(&tracker);
            let start = Arc::clone(&start);
            scope.spawn(move || {
                start.wait();
                for _ in 0..iterations {
                    let permit = tracker.try_acquire(black_box(bytes)).unwrap();
                    black_box(permit.bytes());
                    drop(permit);
                }
            })
        }).collect();
        let c0 = cpu_ns();
        let t0 = Instant::now();
        start.wait();
        for handle in handles { handle.join().unwrap(); }
        (cpu_ns() - c0, t0.elapsed().as_nanos())
    });
    assert_eq!(tracker.allocated(), 0);
    assert_eq!(tracker.active_byte_permit_tokens(), 0);
    assert_eq!(tracker.peak_allocated(), threads * bytes);
    assert_eq!(tracker.peak_active_byte_permit_tokens(), threads);
    assert!(cpu > 0 && wall > 0);
    (cpu, wall)
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(), 5);
    let threads: usize = args[1].parse().unwrap();
    let bytes: usize = args[2].parse().unwrap();
    let iterations: usize = args[3].parse().unwrap();
    let samples: usize = args[4].parse().unwrap();
    assert!([1, 2, 4].contains(&threads) && [0, 64].contains(&bytes));
    assert!(samples > 0);
    if iterations == 0 {
        let tracker = Arc::new(ByteBudgetTracker::unlimited());
        std::thread::scope(|scope| {
            for _ in 0..threads {
                let tracker = Arc::clone(&tracker);
                scope.spawn(move || { drop(tracker.try_acquire(bytes).unwrap()); });
            }
        });
        assert_eq!(tracker.allocated(), 0);
        assert_eq!(tracker.active_byte_permit_tokens(), 0);
        println!("{{\"preflight\":true,\"threads\":{threads},\"bytes\":{bytes}}}");
        return;
    }
    assert!(iterations >= 100_000);
    let values: Vec<_> = (0..samples).map(|_| run(threads, bytes, iterations)).collect();
    print!("{{\"threads\":{threads},\"bytes\":{bytes},\"iterations_per_thread\":{iterations},\"semantic_prechecks\":true,\"samples\":[");
    for (i, (cpu, wall)) in values.iter().enumerate() {
        if i != 0 { print!(","); }
        print!("{{\"cpu_ns\":{cpu},\"wall_ns\":{wall}}}");
    }
    println!("]}}");
}
