import hashlib,json,subprocess,shutil
from pathlib import Path
base=Path(__file__).resolve().parent;out=base/'shrink-allocation-results';out.mkdir(exist_ok=False)
cases=[('single_full',1,100,8,False,False),('twenty_full',20,50,8,False,False),('twenty_shared_lean',20,50,8,True,True),('hundred_shared_full',100,10,4,True,False),('hundred_full',100,10,4,False,False)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
summary=[]
for name,files,messages,fields,shared,lean in cases:
 pair={}
 for side in ('baseline','candidate'):
  dest=out/name/side;dest.mkdir(parents=True)
  cmd=[str(base/(('shrink' if side == 'candidate' else side)+'-allocation-driver')),str(files),str(messages),str(fields),str(shared).lower(),str(lean).lower(),str(dest),'2','true']
  p=subprocess.run(cmd,text=True,capture_output=True,timeout=240);(dest/'stdout.jsonl').write_text(p.stdout);(dest/'stderr.log').write_text(p.stderr)
  assert p.returncode==0,p.stderr
  samples=[json.loads(line) for line in p.stdout.splitlines()];assert len(samples)==2
  outputs={str(p.relative_to(dest)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in dest.rglob('*.rs')}
  pair[side]=dict(samples=samples,generated=outputs,input_sha256=sha(dest/'request.bin'),command=cmd)
  for f in dest.rglob('*.rs'):f.unlink()
 a,b=pair['baseline'],pair['candidate'];assert a['generated']==b['generated'] and a['input_sha256']==b['input_sha256']
 metrics={k:dict(before=a['samples'][1][k],after=b['samples'][1][k],ratio=b['samples'][1][k]/a['samples'][1][k] if a['samples'][1][k] else None) for k in ('allocations','requested_bytes','peak_live_delta','retained_delta','generated_bytes')}
 row=dict(case=name,metrics=metrics,pair=pair,byte_identical=True,performance_timing_usable=False);summary.append(row)
 print(json.dumps(dict(case=name,metrics=metrics)),flush=True)
(out/'results.json').write_text(json.dumps(dict(complete=True,rows=summary),indent=2)+'\n')
