#!/usr/bin/env python3
import hashlib, json, pathlib, re, subprocess

ROOT=pathlib.Path('/workspace/pure-protobuf')
OUT=ROOT/'work/native-origin-perf-20261105'
BASE='dc2261c8efe6fa99bf6c3583fa642f09ee7249cf'
OVERLAYS=[
 'pbrs-grpc/src/client/channel.rs','pbrs-grpc/src/client/pool.rs',
 'pbrs-grpc/src/client/call.rs','pbrs-grpc/src/client/unary.rs',
 'pbrs-grpc/src/client/streaming.rs','pbrs-grpc/src/client/retry.rs',
 'pbrs-grpc/src/wire.rs','pbrs-grpc/src/wire/headers.rs',
 'pbrs-grpc/src/tower_client.rs','pbrs-grpc/src/request.rs',
]
def sha(data): return hashlib.sha256(data).hexdigest()
paths=subprocess.check_output(['git','ls-tree','-r','--name-only','-z',BASE,'--',
 'Cargo.toml','Cargo.lock','build.rs','clippy.toml','rustfmt.toml','src',
 'vendor/google/conformance_fds.bin','pbrs-grpc'],cwd=ROOT).decode().split('\0')
paths=sorted(x for x in paths if x)
manifest={'baseline_commit':BASE,'input_scope':'selected Git source trees, not a filesystem-read trace',
          'baseline_git_inputs':{},'candidate_overlays':{},'variants':{}}
original={}
for path in paths:
    data=subprocess.check_output(['git','show',f'{BASE}:{path}'],cwd=ROOT)
    original[path]=data
    manifest['baseline_git_inputs'][path]=sha(data)
for path in OVERLAYS: manifest['candidate_overlays'][path]=sha((ROOT/path).read_bytes())
for variant in ['baseline','candidate']:
    target=OUT/variant
    assert not target.exists(), target
    for path,data in original.items():
        if variant=='candidate' and path in OVERLAYS: data=(ROOT/path).read_bytes()
        dest=target/path
        dest.parent.mkdir(parents=True,exist_ok=True)
        dest.write_bytes(data)
    cargo=target/'Cargo.toml'
    text=cargo.read_text()
    text,count=re.subn(r'(\[workspace\]\s*members\s*=\s*)\[[\s\S]*?\]',r'\1[".", "pbrs-grpc"]',text,count=1)
    assert count==1
    cargo.write_text(text)
    # Identical observer functions in both isolated exports; no shipping API.
    local=target/'pbrs-grpc/src/client.rs'
    local.write_text(local.read_text()+'''\n// Measurement-only layout observer, absent from production source.\npub(crate) fn __origin_layout_probe() -> (usize, usize) {\n    (std::mem::size_of::<channel::ChannelLocal>(), std::mem::size_of::<channel::Channel>())\n}\n''')
    lib=target/'pbrs-grpc/src/lib.rs'
    lib.write_text(lib.read_text()+'''\n/// Measurement-only layout observer, absent from production source.\n#[doc(hidden)]\npub fn __origin_layout_probe() -> (usize, usize) { client::__origin_layout_probe() }\n''')
    driver=OUT/f'driver-{variant}'
    driver.mkdir()
    (driver/'src').mkdir()
    (driver/'src/main.rs').write_bytes((OUT/'main.rs').read_bytes())
    (driver/'Cargo.lock').write_bytes(original['Cargo.lock'])
    (driver/'Cargo.toml').write_text(f'''[package]\nname="origin-default-diagnostic"\nversion="0.0.0"\nedition="2024"\npublish=false\n[workspace]\n[features]\ndefault=[]\ncandidate=[]\nallocations=[]\n[dependencies]\npbrs-grpc={{path="../{variant}/pbrs-grpc"}}\ntokio={{version="1",features=["rt","macros","io-util","sync","time"]}}\nlibc="0.2"\nserde_json="1"\n[profile.release]\nlto="thin"\ncodegen-units=1\ndebug=0\n''')
    manifest['variants'][variant]={
      'source_files':{str(p.relative_to(target)):sha(p.read_bytes()) for p in sorted(target.rglob('*')) if p.is_file()},
      'driver_files':{str(p.relative_to(driver)):sha(p.read_bytes()) for p in sorted(driver.rglob('*')) if p.is_file()},
      'instrumentation':'common measurement-only layout exports; counting allocator only separate allocations feature',
    }
(OUT/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'git_inputs':len(paths),'overlays':len(OVERLAYS),'baseline':BASE},indent=2))
