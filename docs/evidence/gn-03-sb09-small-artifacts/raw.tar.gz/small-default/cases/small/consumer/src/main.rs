include!(concat!(env!("CARGO_MANIFEST_DIR"), "/generated/mod.rs"));

fn roundtrip<T: pbrs::Parse + pbrs::Serialize>(msg: T) -> usize {
    let wire = msg.serialize().expect("serialize generated message");
    let parsed = T::parse(std::hint::black_box(&wire)).expect("parse generated message");
    std::hint::black_box(parsed.serialize().expect("serialize parsed message")).len()
}

fn main() {
    let mut total = 0usize;
    total += roundtrip(bench::cg19::Message0000::new());
    total += roundtrip(bench::cg19::Message0001::new());
    total += roundtrip(bench::cg19::Message0002::new());
    total += roundtrip(bench::cg19::Message0003::new());
    total += roundtrip(bench::cg19::Message0004::new());
    total += roundtrip(bench::cg19::Message0005::new());
    println!("{}", std::hint::black_box(total + 1));
}
