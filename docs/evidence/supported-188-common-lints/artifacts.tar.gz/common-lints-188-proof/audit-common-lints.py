#!/usr/bin/env python3
"""Audit common-source correctness evidence without Cargo."""
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
CAP = 2 * 1024**3


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def gate(name, code):
    base = ROOT / name
    record = json.loads(base.with_suffix(".json").read_text())
    assert record["exit"] == int(base.with_suffix(".exit").read_text()) == code
    assert record["raw_sha256"] == sha(base.with_suffix(".log"))
    assert record["source_before"] == record["source_after"]
    assert record["tools_before"] == record["tools_after"]
    assert record["source_before"]["tracked_status"]["output"] == ""
    assert record["env"]["CARGO_BUILD_JOBS"] == "1" and record["budget_stop"] is None
    assert record["env"]["CARGO_TARGET_DIR"] == str(Path(record["cwd"]) / "target/gates")
    assert record["runner_sha256"] in {sha(ROOT / "run_gate.py"), sha(ROOT / "run_gate-v3.py")}
    for observation in [*record["resource_samples"], record["resources_after"]]:
        assert observation["cache_allocated_bytes"] <= CAP and observation["global_free_bytes"] >= CAP
    return record, base.with_suffix(".log").read_text()


pins = json.loads((ROOT / "common-source-pins.json").read_text())
equivalence = json.loads((ROOT / "core-input-equivalence.json").read_text())
assert pins["shipping_main"] == equivalence["shipping_main"] == "f37b68ce0f426bccf025858ac3339481eb46376d"
equivalent_sources = set()
for record in equivalence["core_input_equivalence_by_source"]:
    assert record["exit"] == 0 and not record["stdout"] and not record["stderr"]
    equivalent_sources.add(record["source"])
for relative, record in pins["snapshots"].items():
    path = ROOT / relative
    assert path.stat().st_size == record["bytes"] and sha(path) == record["sha256"]
passed = set()
for name in ["core-text-codegen-188-after-common-fix", "core-error-display-188-pinned-plugin",
             "core-clippy-188-common-only", "core-source-msrv-185-common-only"]:
    record, raw = gate(name, 0)
    assert record["source_before"]["head"] in equivalent_sources
    assert record["argv"][record["argv"].index("-p") + 1] == "pbrs"
    for relative, digest in pins["core_compiler_source_sha256"].items():
        assert record["source_before"]["source_sha256"][relative] == digest
    results = re.findall(r"^test (\S+) \.\.\. (ok|FAILED|ignored)$", raw, re.MULTILINE)
    assert all(result == "ok" for _, result in results)
    passed.update(test for test, _ in results)
assert len(passed) == 7
fmt, _ = gate("final-format-common-and-hook", 0)
strict, raw = gate("strict-clippy-188-after-compression-fix", 0)
assert "--keep-going" in strict["argv"] and "-D" in strict["argv"] and "warnings" in strict["argv"]
assert strict["source_before"]["head"] == "ed9027b76474fc84b642c6d0d8b6ccd164bf55da"
assert "Finished `dev` profile" in raw
_, retry = gate("strict-clippy-188-after-common-fix", 101)
_, compression = gate("strict-clippy-188-after-retry-fix", 101)
assert "retry_safety.rs:1254" in retry and "retry_safety.rs:1260" in retry
assert "compression/mod.rs:278" in compression
setup, raw = gate("core-error-display-188-after-common-fix", 101)
assert "1 passed; 1 failed;" in raw and "No such file or directory" in raw
fixed, _ = gate("core-error-display-188-pinned-plugin", 0)
assert fixed["env"]["CARGO_BIN_EXE_protoc-gen-pbrs"].endswith("target/gates/debug/protoc-gen-pbrs")
assert "CARGO_BIN_EXE_protoc-gen-pbrs" in fixed["tools_before"]["binaries"]
for name in ["strict-clippy-188", "strict-grpc-clippy-188"]:
    base = ROOT / "prior-strict" / name
    record = json.loads(base.with_suffix(".json").read_text())
    assert record["exit"] == int(base.with_suffix(".exit").read_text()) == 101
    assert record["raw_sha256"] == sha(base.with_suffix(".log"))
print(json.dumps({"shipping_common_source": pins["shipping_main"], "independent_core_tests_passed": len(passed),
                  "independent_core_clippy_188": "pass", "independent_core_source_msrv_185": "pass",
                  "broad_grpc_strict_clippy_188": "pass on separately isolated hook source ed9027b7",
                  "retained_prior_strict_reds": 4, "retained_plugin_setup_red": True,
                  "release_performance_adoption": "not qualified or adopted"}, indent=2))
