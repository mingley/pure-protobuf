#!/usr/bin/env python3
"""Record isolated correctness gates and enforce their agreed disk budget."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import signal
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[2]
LOGS = Path(__file__).resolve().parent
CACHE = ROOT / "target/gates"
LIMIT = 2 * 1024**3
ENV_KEYS = (
    "RUSTUP_HOME", "CARGO_HOME", "PATH", "VALGRIND_LIB", "CARGO_TARGET_DIR",
    "CARGO_BUILD_JOBS", "CARGO_PROFILE_DEV_DEBUG", "CARGO_PROFILE_TEST_DEBUG",
    "CARGO_INCREMENTAL", "CARGO_NET_OFFLINE", "RUSTFLAGS", "RUSTDOCFLAGS",
    "RUSTUP_TOOLCHAIN", "PROTOC", "LD_LIBRARY_PATH",
    "CARGO_BIN_EXE_protoc-gen-pbrs",
)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def command(argv):
    proc = subprocess.run(argv, cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    return {"argv": argv, "exit": proc.returncode, "output": proc.stdout.decode(errors="replace")}


def source():
    listed = subprocess.check_output(["git", "ls-files", "-z"], cwd=ROOT).split(b"\0")
    selected = [p.decode() for p in listed if p and (
        p.endswith((b".rs", b".toml")) or p in (b"Cargo.lock", b"clippy.toml", b"rustfmt.toml")
    )]
    diff = subprocess.check_output(["git", "diff", "--binary", "HEAD"], cwd=ROOT)
    protobuf = ROOT / "third_party/protobuf"
    return {
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
        "tree": subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=ROOT).decode().strip(),
        "tracked_status": command(["git", "status", "--short", "--untracked-files=no"]),
        "dirty_patch_sha256": hashlib.sha256(diff).hexdigest(),
        "source_sha256": {p: digest(ROOT / p) for p in selected},
        "protobuf_link": os.readlink(protobuf) if protobuf.is_symlink() else None,
        "protobuf_resolved": str(protobuf.resolve()),
        "protobuf_pin": command(["git", "-C", str(protobuf), "rev-parse", "HEAD"]),
    }


def resources():
    allocated = apparent = 0
    for directory, _, files in os.walk(CACHE):
        for filename in files:
            try:
                st = os.lstat(Path(directory) / filename)
            except FileNotFoundError:
                continue
            allocated += st.st_blocks * 512
            apparent += st.st_size
    free = os.statvfs(ROOT).f_bavail * os.statvfs(ROOT).f_frsize
    return {"utc": now(), "cache": str(CACHE), "cache_exists": CACHE.exists(),
            "cache_allocated_bytes": allocated, "cache_apparent_bytes": apparent,
            "global_free_bytes": free, "cache_cap_bytes": LIMIT, "global_free_floor_bytes": LIMIT}


def tools(toolchain, argv):
    versions = [command(["rustup", "run", toolchain, "rustc", "-vV"]),
                command(["rustup", "run", toolchain, "cargo", "--version"]),
                command(["protoc", "--version"])]
    programs = ["rustc", "cargo"]
    if argv[0] == "rustfmt":
        programs.append("rustfmt")
        versions.append(command(["rustup", "run", toolchain, "rustfmt", "--version"]))
    if "clippy" in argv and argv[0] == "cargo":
        programs.extend(["cargo-clippy", "clippy-driver"])
        versions.append(command(["rustup", "run", toolchain, "cargo", "clippy", "--version"]))
    binaries = {}
    invoked = shutil.which(argv[0])
    if invoked:
        binaries["invoked_command"] = {"path": invoked, "sha256": digest(invoked)}
    for program in programs:
        resolved = subprocess.run(["rustup", "which", "--toolchain", toolchain, program],
                                  cwd=ROOT, capture_output=True)
        if resolved.returncode == 0:
            path = resolved.stdout.decode().strip()
            binaries[program] = {"path": path, "sha256": digest(path)}
    for program in ("rustup", "protoc"):
        path = shutil.which(program)
        binaries[program] = {"path": path, "sha256": digest(path)}
    for key, path in os.environ.items():
        if key.startswith("CARGO_BIN_EXE_"):
            binaries[key] = {"path": path, "sha256": digest(path)}
    return {"versions": versions, "binaries": binaries}


def main():
    name, *argv = sys.argv[1:]
    if argv and argv[0] == "--":
        argv.pop(0)
    if not argv or not name.replace("-", "").replace("_", "").isalnum():
        raise SystemExit("usage: run_gate.py TAG -- COMMAND [ARGS...]")
    prefix = LOGS / name
    if prefix.with_suffix(".json").exists():
        raise SystemExit("refusing to overwrite an earlier gate")
    if os.environ.get("CARGO_BUILD_JOBS") != "1" or os.environ.get("CARGO_TARGET_DIR") != str(CACHE):
        raise SystemExit("expected jobs=1 and the exclusive target/gates path")
    started = now()
    toolchain = next((arg[1:] for arg in argv if arg.startswith("+")),
                     os.environ.get("RUSTUP_TOOLCHAIN", "stable"))
    if "--toolchain" in argv:
        toolchain = argv[argv.index("--toolchain") + 1]
    before = resources()
    record = {"kind": "ordinary_correctness_only", "argv": argv, "cwd": str(ROOT),
              "started_utc": started, "env": {k: os.environ.get(k) for k in ENV_KEYS},
              "source_before": source(), "resources_before": before,
              "runner_sha256": digest(__file__), "toolchain": toolchain,
              "tools_before": tools(toolchain, argv), "resource_samples": [before]}
    prefix.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    if before["cache_allocated_bytes"] > LIMIT or before["global_free_bytes"] < LIMIT:
        raise SystemExit("preflight disk budget exceeded; no gate launched")
    blocked = None
    with prefix.with_suffix(".log").open("wb") as output:
        child = subprocess.Popen(argv, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT, start_new_session=True)
        record["pid"] = child.pid
        next_sample = time.monotonic() + 10
        while child.poll() is None:
            time.sleep(0.5)
            if time.monotonic() >= next_sample:
                sample = resources()
                record["resource_samples"].append(sample)
                if sample["cache_allocated_bytes"] > LIMIT or sample["global_free_bytes"] < LIMIT:
                    blocked = "disk budget exceeded"
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                    break
                next_sample = time.monotonic() + 10
        result = child.wait()
    record.update({"exit": result, "ended_utc": now(), "source_after": source(),
                   "tools_after": tools(toolchain, argv),
                   "resources_after": resources(), "budget_stop": blocked,
                   "raw_output": str(prefix.with_suffix(".log")),
                   "raw_sha256": digest(prefix.with_suffix(".log"))})
    prefix.with_suffix(".exit").write_text(str(result) + "\n")
    prefix.with_suffix(".json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"gate": name, "exit": result, "budget_stop": blocked,
                      "raw_log": record["raw_output"], "resources_after": record["resources_after"]}))
    raise SystemExit(result if result >= 0 else 128 - result)


if __name__ == "__main__":
    main()
