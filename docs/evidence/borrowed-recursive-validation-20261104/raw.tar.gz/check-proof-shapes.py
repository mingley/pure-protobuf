#!/usr/bin/env python3
"""Verify that focused fixtures exercise the intended generator path."""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
rows = [json.loads(line) for line in (ROOT / 'validated-lazy-final-build.jsonl').read_text().splitlines()]
outdirs = [Path(row['out_dir']) for row in rows
           if row.get('reason') == 'build-script-executed'
           and 'pbrs-validated-lazy-proof' in row.get('package_id', '')]
assert len(outdirs) == 1
directory = outdirs[0] / 'pbrs'
expectations = {
    'proof.rs': {'Node': True, 'Mixed': False, 'WithRequired': False,
                 'FreeChoice': False, 'RequiredCollections': False},
    'strict.rs': {'StrictNode': True, 'CompactNode': True, 'RecursiveChoice': True,
                  'RecursiveSequence': True, 'Blob': False, 'BlobRoot': False},
}
found = {}
for file, messages in expectations.items():
    source = (directory / file).read_text()
    for name, expected in messages.items():
        start = source.index(f'impl {name} {{')
        end = source.index(f'pbrs::impl_typed_message!({name},', start)
        part = source[start:end]
        marker = '\n        fn __pbrs_validate_self('
        selected = marker in part
        assert selected is expected, (name, expected, selected)
        if selected:
            helper = part[part.index(marker):]
            assert 'crate::GENERATED_VALIDATIONS.fetch_add' in helper[:400]
        found[name] = selected
report = {'status': 'passed', 'out_dir': str(directory), 'selected': found,
          'scope': 'generated positive/negative fixture selection and proof-only counter location'}
(ROOT / 'proof-shapes.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
