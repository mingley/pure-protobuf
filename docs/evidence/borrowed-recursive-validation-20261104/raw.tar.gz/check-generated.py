#!/usr/bin/env python3
"""Check the experimental fixture changed only Node's validator body."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent
before = (ROOT / 'snapshot-baseline-pbrs/codec_cases.rs').read_text()
after = (ROOT / 'candidate-safe-pbrs/codec_cases.rs').read_text()
baseline_prost = (ROOT / 'snapshot-baseline-prost/cases.rs').read_bytes()
candidate_prost = (ROOT / 'candidate-safe-prost/cases.rs').read_bytes()

def region(source):
    impl_start = source.index('impl Node {')
    start = source.index('    pub fn validate_until(', impl_start)
    end = source.index('    pub fn compute_size(', start)
    assert end < source.index('pbrs::impl_typed_message!(Node', impl_start)
    return start, end

old_start, old_end = region(before)
new_start, new_end = region(after)
old, new = before[old_start:old_end], after[new_start:new_end]
assert 'fn __pbrs_validate_self(' not in old
assert new.count('fn __pbrs_validate_self(') == 1
assert '__pbrs_validate_self(&data[s..e], &mut ip, depth + 1, None)?' in new
assert before[:old_start] == after[:new_start]
assert before[old_end:] == after[new_end:]
assert baseline_prost == candidate_prost
sha = lambda data: hashlib.sha256(data).hexdigest()
report = {'status': 'passed', 'scope': 'single codec fixture generated source; selected Node validator only',
          'before_sha256': sha(before.encode()), 'after_sha256': sha(after.encode()),
          'old_validator_sha256': sha(old.encode()), 'new_validator_sha256': sha(new.encode()),
          'prost_sha256': sha(baseline_prost)}
(ROOT / 'generated-fixture-check.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
