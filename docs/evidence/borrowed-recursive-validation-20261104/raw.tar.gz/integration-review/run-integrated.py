#!/usr/bin/env python3
"""Run bounded focused checks, retaining output and source hashes."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/pure-protobuf')
OUT = Path(__file__).resolve().parent
FLOOR = 1024 * 1024 * 1024
FILES = ['src/codegen/parse.rs', 'src/codegen/config.rs', 'src/codegen/messages.rs',
         'tests/proof/validated_lazy/build.rs', 'tests/proof/validated_lazy/strict.proto',
         'tests/proof/validated_lazy/proof.proto', 'tests/proof/validated_lazy/src/main.rs',
         'tests/proof/validated_lazy/Cargo.toml', 'tests/proof/validated_lazy/Cargo.lock', 'Cargo.lock']
COMMANDS = [
    ('selector', ['cargo', 'test', '--locked', '--offline', '-p', 'pbrs', '--lib',
                  'self_validation_selects_only_safe_recursive_descriptors']),
    ('consumer', ['cargo', 'run', '--locked', '--offline', '--manifest-path',
                  'tests/proof/validated_lazy/Cargo.toml']),
    ('consumer-clippy', ['cargo', 'clippy', '--locked', '--offline', '--manifest-path',
                         'tests/proof/validated_lazy/Cargo.toml', '--', '-D', 'warnings']),
]

def snap():
    return {name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest() for name in FILES}

def now():
    return datetime.now(timezone.utc).isoformat()

env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + str(ROOT / 'work/toolchain/protoc/bin') + ':' + env['PATH']
before = snap()
for label, command in COMMANDS:
    path = OUT / (label + '.log')
    report_path = OUT / (label + '.json')
    if path.exists() or report_path.exists():
        raise SystemExit('preserve existing check records: ' + label)
    if shutil.disk_usage(ROOT).free < FLOOR:
        raise SystemExit('free space below 1 GiB before ' + label)
    report = {'label': label, 'command': command, 'head': subprocess.check_output(
        ['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(), 'source_sha256': before,
        'started_utc': now(), 'disk_floor': FLOOR, 'free_before': shutil.disk_usage(ROOT).free,
        'rustc': subprocess.check_output(['rustc', '-Vv'], env=env, text=True), 'disk_guard': False}
    started = time.monotonic()
    with path.open('wb') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                   start_new_session=True)
        while process.poll() is None:
            if shutil.disk_usage(ROOT).free < FLOOR:
                report['disk_guard'] = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=10)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            time.sleep(1)
    report.update(exit_code=99 if report['disk_guard'] else process.returncode,
                  finished_utc=now(), elapsed_seconds=time.monotonic() - started,
                  free_after=shutil.disk_usage(ROOT).free, source_unchanged=snap() == before,
                  log_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'source_sha256'}), flush=True)
    if report['exit_code'] or not report['source_unchanged']:
        raise SystemExit(report['exit_code'] or 2)
