#!/usr/bin/env python3
"""Interleave matched frozen codec binaries; diagnostic only, no global ranking."""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import random
import statistics
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BEFORE = ROOT / 'snapshot-baseline'
AFTER = ROOT / 'candidate-safe'
CASES = {'empty': 1_000_000, 'scalars': 200_000, 'blob_4kib': 30_000,
         'packed_256': 50_000, 'nested_8': 50_000, 'nested_64': 10_000,
         'rpc_sparse': 200_000, 'rpc_mixed': 30_000}
OPS = ('parse_owned', 'read_all')
PAIRS = 5
SAMPLES = 3
SEED = 20261103


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def interval(values):
    return {'median': statistics.median(values), 'range': [min(values), max(values)], 'pairs': values}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--partial', action='store_true')
    parser.add_argument('--confirmation', action='store_true')
    parser.add_argument('--focused', action='store_true')
    args = parser.parse_args()
    if args.focused and (args.partial or args.confirmation):
        parser.error('--focused is a separate confirmation')
    cases = {'nested_8': 100_000, 'nested_64': 20_000} if args.partial else CASES
    operations = ('read_first_child',) if args.partial else OPS
    if args.confirmation:
        cases = {name: count * 5 for name, count in cases.items()}
    if args.focused:
        cases = {name: CASES[name] * 10 for name in ('empty', 'blob_4kib', 'rpc_mixed', 'nested_8', 'nested_64')}
    pairs = 9 if args.focused else (7 if args.confirmation else PAIRS)
    samples = 5 if args.confirmation or args.focused else SAMPLES
    seed = 20261108 if args.focused else (20261107 if args.confirmation else SEED)
    paths = {'before': ROOT / 'partial-baseline', 'after': ROOT / 'partial-candidate'} if args.partial else {'before': BEFORE, 'after': AFTER}
    stem = 'partial' if args.partial else 'safe'
    suffix = 'focused-confirmation-results' if args.focused else ('confirmation-results' if args.confirmation else 'screen-results')
    out = ROOT / f'{stem}-{suffix}'
    out.mkdir(exist_ok=False)
    binaries = {name: path.resolve(strict=True) for name, path in paths.items()}
    digests = {name: sha(path) for name, path in binaries.items()}
    source_paths = ['src/lazy.rs', 'src/codegen/parse.rs', 'Cargo.toml',
                    'tests/proof/codec_benchmark/Cargo.toml',
                    'tests/proof/codec_benchmark/Cargo.lock',
                    'tests/proof/codec_benchmark/src/main.rs', 'proto/codec_cases.proto']
    source_sha = {path: sha(ROOT / 'source' / path) for path in source_paths}
    if args.partial:
        source_sha.update({'partial/' + name: sha(ROOT / 'partial' / name) for name in
                           ('Cargo.toml', 'Cargo.lock', 'src/main.rs', 'build.rs', 'partial-getter.proto')})
    affinity = sorted(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {affinity[0]})
    rng = random.Random(seed)
    plan = []
    for pair in range(pairs):
        cells = list(itertools.product(cases, operations))
        rng.shuffle(cells)
        for case, op in cells:
            versions = list(itertools.product(('before', 'after'), ('pbrs', 'prost')))
            rng.shuffle(versions)
            plan.extend({'pair': pair, 'case': case, 'operation': op, 'source': source, 'backend': backend}
                        for source, backend in versions)
    manifest = {'schema': 'pbrs.borrowed-self-validator-screen.v1', 'state': 'running', 'qualified': False,
                'before_git_commit': '41612b32e6e3466406ff63138a1e2d65c0d5d22e',
                'snapshot_note': 'Git source snapshot; workspace membership reduced to core only in both builds',
                'candidate_source_sha256': source_sha, 'binary_sha256': digests,
                'plan': plan, 'pairs': pairs, 'samples': samples, 'seed': seed, 'iterations': cases,
                'affinity_before': affinity, 'cpu': affinity[0], 'host': platform.uname()._asdict(),
                'cgroup_cpu_max': Path('/sys/fs/cgroup/cpu.max').read_text().strip(),
                'cgroup_cpu_stat_before': Path('/sys/fs/cgroup/cpu.stat').read_text(),
                'cpu_scope': 'CLOCK_PROCESS_CPUTIME_ID, owned result parsed and dropped per iteration',
                'limitations': ['shared host; diagnostic only', 'no allocation, retained memory or RSS counts',
                                'read_all traverses all populated fields; parse_owned can defer nested materialization',
                                'read_first_child visits root and immediate child before dropping the result']}
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    started = time.monotonic()
    rows, fixtures = [], {}
    with (out / 'raw.jsonl').open('w') as raw:
        for index, entry in enumerate(plan):
            command = [str(binaries[entry['source']]), entry['case'], entry['backend'], entry['operation'],
                       str(cases[entry['case']]), str(samples)]
            proc = subprocess.run(command, capture_output=True, text=True)
            record = dict(entry, command=command, returncode=proc.returncode, stderr=proc.stderr, stdout=proc.stdout)
            raw.write(json.dumps(record) + '\n')
            raw.flush()
            assert proc.returncode == 0, record
            value = json.loads(proc.stdout)
            assert all(value[k] == entry[k] for k in ('case', 'backend', 'operation'))
            assert value['semantic_prechecks'] is True and value['allocation_instrumentation'] is False
            assert value.get('message_storage', 'lazy') == 'lazy' and len(value['samples']) == samples
            assert all(v['iterations'] == cases[entry['case']] and v['cpu_ns'] > 0 for v in value['samples'])
            signature = (value['wire_bytes'], value['wire_fnv1a64'], value['checksum'], value.get('full_fixture_checksum'))
            assert fixtures.setdefault(entry['case'], signature) == signature
            rows.append(dict(entry, result=value))
            if (index + 1) % 16 == 0:
                print(f'{index + 1}/{len(plan)} validated processes', flush=True)
    summary = []
    for case, op in itertools.product(cases, operations):
        values = {}
        for row in rows:
            if (row['case'], row['operation']) == (case, op):
                values[(row['pair'], row['source'], row['backend'])] = statistics.mean(
                    sample['cpu_ns'] / sample['iterations'] for sample in row['result']['samples'])
        def ratios(source1, back1, source2, back2):
            return interval([values[p, source1, back1] / values[p, source2, back2] for p in range(pairs)])
        summary.append({'case': case, 'operation': op,
                        'candidate_over_baseline_pbrs': ratios('after', 'pbrs', 'before', 'pbrs'),
                        'candidate_pbrs_over_prost': ratios('after', 'pbrs', 'after', 'prost'),
                        'baseline_pbrs_over_prost': ratios('before', 'pbrs', 'before', 'prost'),
                        'candidate_over_baseline_prost': ratios('after', 'prost', 'before', 'prost'),
                        'fixture': fixtures[case]})
    for name, path in binaries.items():
        assert sha(path) == digests[name], name
    for path, digest in source_sha.items():
        actual = ROOT / path if path.startswith('partial/') else ROOT / 'source' / path
        assert sha(actual) == digest, path
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    manifest.update(state='complete', passed=True, processes=len(rows), elapsed_seconds=time.monotonic() - started,
                    cgroup_cpu_stat_after=Path('/sys/fs/cgroup/cpu.stat').read_text())
    (out / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'processes': len(rows), 'elapsed_seconds': manifest['elapsed_seconds'],
                      'summary': str(out / 'summary.json')}))


if __name__ == '__main__':
    main()
