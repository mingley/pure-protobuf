//! Differential control for the isolated self-recursive validator experiment.
use pbrs::{Parse, Serialize};

#[allow(dead_code, unused, nonstandard_style)]
mod before {
    include!("../../snapshot-baseline-pbrs/codec_cases.rs");
}

#[allow(dead_code, unused, nonstandard_style)]
mod after {
    include!("../../candidate-safe-pbrs/codec_cases.rs");
}

fn varint(mut value: u64) -> Vec<u8> {
    let mut out = Vec::new();
    while value >= 128 {
        out.push(value as u8 | 0x80);
        value >>= 7;
    }
    out.push(value as u8);
    out
}

fn length_field(number: u8, value: &[u8]) -> Vec<u8> {
    let mut out = vec![(number << 3) | 2];
    out.extend(varint(value.len() as u64));
    out.extend(value);
    out
}

fn recursive(depth: usize) -> Vec<u8> {
    let mut out = vec![8, 1];
    for n in 0..depth {
        let mut parent = vec![8];
        parent.extend(varint((n as u64) + 2));
        parent.extend(length_field(2, &out));
        out = parent;
    }
    out
}

fn next(state: &mut u64) -> u64 {
    *state ^= *state << 13;
    *state ^= *state >> 7;
    *state ^= *state << 17;
    *state
}

fn parse_owned<T: Parse + Serialize>(wire: &[u8]) -> Result<Vec<u8>, String> {
    T::parse(wire)
        .map_err(|err| err.to_string())?
        .serialize()
        .map_err(|err| err.to_string())
}

fn parse_shared<T: Parse + Serialize>(wire: &[u8]) -> Result<Vec<u8>, String> {
    let value = pbrs::rt::Bytes::copy_from_slice(wire);
    T::parse_bytes(value)
        .map_err(|err| err.to_string())?
        .serialize()
        .map_err(|err| err.to_string())
}

fn check(wire: &[u8]) {
    assert_eq!(
        parse_owned::<before::Node>(wire),
        parse_owned::<after::Node>(wire),
        "owned input differs: {wire:?}"
    );
    assert_eq!(
        parse_shared::<before::Node>(wire),
        parse_shared::<after::Node>(wire),
        "shared input differs: {wire:?}"
    );
    for until in [None, Some(7)] {
        let mut old_pos = 0;
        let mut new_pos = 0;
        let source = pbrs::rt::Wire::from_slice(wire);
        let old = before::Node::validate_until(&source, &mut old_pos, 0, until)
            .map_err(|e| e.to_string());
        let new =
            after::Node::validate_until(&source, &mut new_pos, 0, until).map_err(|e| e.to_string());
        assert_eq!(
            (old, old_pos),
            (new, new_pos),
            "validator differs, until {until:?}: {wire:?}"
        );
    }
}

fn main() {
    let mut checked = 0;
    let short = std::env::var_os("PBRS_DIFF_SHORT").is_some();
    let depths: Vec<usize> = if short {
        vec![0, 1, 2, 8, 32, 98, 99, 100, 101, 105]
    } else {
        (0..=105).collect()
    };
    for depth in depths {
        let wire = recursive(depth);
        check(&wire);
        checked += 1;
        for offset in [0, wire.len() / 2, wire.len() - 1] {
            check(&wire[..offset]);
            checked += 1;
        }
    }
    for wire in [
        vec![],
        vec![0],
        vec![0x80],
        vec![0x12, 0xff, 0xff, 0xff, 0x0f],
        vec![0x3b, 0x40, 0x01, 0x3c],
        vec![0x3b, 0x40, 0x01, 0x44],
        vec![0x3b, 0x40, 0x01],
        vec![0x3c],
        [
            length_field(2, &[8, 1]),
            length_field(2, &length_field(2, &[8, 2])),
        ]
        .concat(),
    ] {
        check(&wire);
        checked += 1;
    }
    let mut state = 0x6525_8319_42ac_d317u64;
    for _ in 0..if short { 64 } else { 8_000 } {
        let length = (next(&mut state) as usize) % 80;
        let mut wire = Vec::with_capacity(length);
        for _ in 0..length {
            wire.push(next(&mut state) as u8);
        }
        check(&wire);
        checked += 1;
    }
    for _ in 0..if short { 64 } else { 4_000 } {
        let depth = (next(&mut state) as usize) % 20;
        let mut wire = recursive(depth);
        let at = (next(&mut state) as usize) % wire.len();
        wire[at] ^= 1 << (next(&mut state) % 8);
        check(&wire);
        checked += 1;
    }
    println!(
        "passed {checked} differential inputs in borrowed/shared parse and two validator modes; short={short}"
    );
}
