#!/usr/bin/env python3
import hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
source=HERE/'outlined';assert not source.exists();shutil.copytree(HERE/'sorted',source)
path=source/'src/map.rs';text=path.read_text()
start=text.index('impl<K: MapKey, V: MapValue + PartialEq> PartialEq for Map<K, V> {')
end=text.index('impl<K: MapKey, V: MapValue + Eq> Eq for Map<K, V> {}',start)
body='''// Keep the indexed comparison out of the small-map scan's generated code.
// Both indexes already exist after equality compares the unique lengths.
#[inline(never)]
fn indexed_entries_eq<K: MapKey, V: MapValue + PartialEq>(
    left: &MapInner<K, V>,
    right: &MapInner<K, V>,
    left_index: &LastWinsIndex<K>,
    right_index: &LastWinsIndex<K>,
) -> bool {
    left_index.pos.iter().zip(&right_index.pos).all(
        |((left_key, left_pos), (right_key, right_pos))| {
            if left_key != right_key {
                return false;
            }
            let Some((_, left_value)) = left.entries.get(*left_pos) else {
                return false;
            };
            let Some((_, right_value)) = right.entries.get(*right_pos) else {
                return false;
            };
            // Keep the original value comparison direction.
            right_value == left_value
        },
    )
}

impl<K: MapKey, V: MapValue + PartialEq> PartialEq for Map<K, V> {
    fn eq(&self, other: &Self) -> bool {
        if self.len() != other.len() {
            return false;
        }
        if let (Some(left), Some(right)) = (self.0.as_deref(), other.0.as_deref()) {
            if left.entries.len() >= INDEX_THRESHOLD && right.entries.len() >= INDEX_THRESHOLD {
                if let (Some(left_index), Some(right_index)) = (left.index.get(), right.index.get()) {
                    // Unique sorted positions pair corresponding last-wins
                    // values without a binary search for every wire entry.
                    return indexed_entries_eq(left, right, left_index, right_index);
                }
            }
        }
        // Iteration yields each last-wins key once. Equal unique lengths and
        // matching every left entry also prove that the right has no extras.
        self.iter().all(|(k, v)| other.get(k) == Some(v))
    }
}
'''
path.write_text(text[:start]+body+text[end:])
harness=HERE/'outlined-harness';assert not harness.exists();shutil.copytree(HERE/'sorted-harness',harness)
manifest=harness/'Cargo.toml';manifest.write_text(manifest.read_text().replace('../sorted','../outlined'));(harness/'Cargo.lock').unlink()
report={'source_scope':'same70selectedbaselineinputs, Eq-onlyoutlined-indexoverlay+existingtests src/map.rs','source_sha256':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()},'base':'1c6ec8cacd547cce8c3a8e335320b49d34de40b4'}
(HERE/'outlined-source-plan.json').write_text(json.dumps(report,indent=2)+'\n')
build=(HERE/'build-indexed.py').read_text()
for old,new in [('sorted-harness','outlined-harness'),('sorted-lock','outlined-lock'),
                ('sorted-build','outlined-build'),('sorted-bin','outlined-bin'),
                ("HERE/'sorted'","HERE/'outlined'"),("'variant':'sorted'","'variant':'outlined'")]:
    build=build.replace(old,new)
(HERE/'build-outlined.py').write_text(build)
