#!/usr/bin/env python3
import shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
prefix=r'''// Allocation instrumentation is built separately from CPU executables.
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    static ACTIVE:AtomicBool=AtomicBool::new(false);
    static CALLS:AtomicU64=AtomicU64::new(0);
    static BYTES:AtomicU64=AtomicU64::new(0);
    pub struct Counted;
    unsafe impl GlobalAlloc for Counted {
        unsafe fn alloc(&self,l:Layout)->*mut u8 {
            let p=unsafe {System.alloc(l)};
            if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}
            p
        }
        unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {
            let p=unsafe {System.alloc_zeroed(l)};
            if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}
            p
        }
        unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {
            let out=unsafe {System.realloc(p,l,n)};
            if !out.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n as u64,Ordering::Relaxed);}
            out
        }
        unsafe fn dealloc(&self,p:*mut u8,l:Layout) {unsafe {System.dealloc(p,l)}}
    }
    pub fn start(){CALLS.store(0,Ordering::SeqCst);BYTES.store(0,Ordering::SeqCst);ACTIVE.store(true,Ordering::SeqCst);}
    pub fn stop(){ACTIVE.store(false,Ordering::SeqCst);}
    pub fn last()->(u64,u64){(CALLS.load(Ordering::SeqCst),BYTES.load(Ordering::SeqCst))}
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC:count::Counted=count::Counted;
#[cfg(not(feature = "allocations"))]
mod count {pub fn start(){}pub fn stop(){}pub fn last()->(u64,u64){(0,0)}}
'''
template='''    let pairs = if phase == "cold" {
        (0..iterations).map(|_| (a.clone(),b.clone())).collect::<Vec<_>>()
    } else {
        assert_eq!(phase,"warm");
        assert_eq!(a==b,expected);
        for _ in 0..100 {black_box(black_box(a)==black_box(b));}
        Vec::new()
    };
    count::start();
    let started=cpu_ns();
    let mut count=0;
    if phase == "cold" {
        for (left,right) in &pairs {count += u64::from(black_box(left)==black_box(right));}
    } else {
        for _ in 0..iterations {count += u64::from(black_box(a)==black_box(b));}
    }
    let elapsed=cpu_ns()-started;
    count::stop();
    assert_eq!(count,if expected {iterations}else{0});
    (elapsed,count)
'''
text=(HERE/'bench.rs').read_text()
start=text.index('    assert_eq!(a==b,expected);',text.index('fn measure_map'))
end=text.index('\n}',start)
text=text[:start]+template+text[end:]
start=text.index('    assert_eq!(a==b,expected);',text.index('fn measure_hash'))
end=text.index('\n}',start)
text=text[:start]+template+text[end:]
text=text.replace('iterations:u64,expected:bool) ->','iterations:u64,expected:bool,phase:&str) ->')
text=text.replace('fn measure_hash<K: Eq+Hash, V:PartialEq>','fn measure_hash<K: Eq+Hash+Clone, V:PartialEq+Clone>')
text=text.replace('assert_eq!(args.len(),8,"peer key_kind wire_entries distribution relationship iterations order");','assert_eq!(args.len(),9,"peer key_kind wire_entries distribution relationship iterations order phase");\n    let phase=args[8].as_str();')
text=text.replace('iterations,expected),','iterations,expected,phase),')
start=text.index('    println!(')
text=text[:start]+'''    let (allocation_calls,allocation_bytes)=count::last();
    let allocation_instrumented=cfg!(feature="allocations");
    println!("{{\\\"peer\\\":\\\"{peer}\\\",\\\"kind\\\":\\\"{kind}\\\",\\\"n\\\":{n},\\\"cardinality\\\":{cardinality},\\\"dist\\\":\\\"{dist}\\\",\\\"relationship\\\":\\\"{rel}\\\",\\\"iterations\\\":{iterations},\\\"order\\\":\\\"{order}\\\",\\\"phase\\\":\\\"{phase}\\\",\\\"expected\\\":{expected},\\\"matches\\\":{count},\\\"cpu_ns\\\":{elapsed},\\\"cpu_ns_per_eq\\\":{},\\\"allocation_instrumented\\\":{allocation_instrumented},\\\"allocation_calls\\\":{allocation_calls},\\\"allocation_bytes\\\":{allocation_bytes}}}",elapsed as f64/iterations as f64);
}
'''
text=prefix+text
(HERE/'cold-bench.rs').write_text(text)
for variant in ['baseline','candidate','sorted','outlined']:
    harness=HERE/f'{variant}-cold-harness';assert not harness.exists()
    shutil.copytree(HERE/f'{variant}-harness',harness)
    manifest=harness/'Cargo.toml'
    manifest.write_text(manifest.read_text().replace('name = "pbrs-map-equality-screen"','name = "pbrs-map-equality-cold"')+'\n[features]\nallocations = []\n')
    (harness/'src/main.rs').write_text(text)
    (harness/'Cargo.lock').unlink()
