#!/usr/bin/env python3
import argparse,datetime,hashlib,itertools,json,os,random,statistics,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);parser.add_argument('--mode',choices=['warm','holdout','cold','allocations'],required=True);parser.add_argument('--pairs',type=int,default=5);args=parser.parse_args()
raw=HERE/f'{args.label}-raw.jsonl';summary=HERE/f'{args.label}-summary.json';assert not raw.exists() and not summary.exists()
cpu=min(os.sched_getaffinity(0));seed=0x5ee01239+['warm','holdout','cold','allocations'].index(args.mode);rng=random.Random(seed)
variants=['baseline','candidate','sorted','outlined','hash']
if args.mode=='holdout':variants=['baseline','outlined']
if args.mode in ['warm','holdout']:
    bins={v:HERE/f'{v}-bin' for v in variants if v!='hash'}
    cells=set()
    for k,n,d,r in itertools.product(['int','proto','lazy'],[8,64,256],['distinct','duplicate'],['equal','value','key','size']):cells.add((k,n,d,r,'reverse','warm'))
    for k,n,d,o in itertools.product(['int','proto','lazy'],[1,15,16,17],['distinct','duplicate'],['forward','reverse']):cells.add((k,n,d,'equal',o,'warm'))
else:
    mode='allocations' if args.mode=='allocations' else 'cpu'
    bins={v:HERE/f'{v}-cold-{mode}-bin' for v in variants if v!='hash'}
    cells=set((k,n,d,r,'reverse',phase) for k,n,d,r,phase in itertools.product(['int','proto','lazy'],[8,16,256],['distinct','duplicate'],['equal','key'],['warm','cold'] if args.mode=='allocations' else ['cold']))
calibration={}
if args.mode=='holdout':
    previous=json.loads((HERE/'outlined-screen-summary.json').read_text())
    calibration={tuple(r['cell']):r['ns_medians']['baseline'] for r in previous['cells']}
    cells=[tuple(r['cell']) for r in previous['cells'] if r['median_outlined_baseline']>1.02 or (r['cell'][3]=='equal' and r['cell'][1] in [8,16,256] and r['cell'][4]=='reverse')]
cells=sorted(cells);schedule=[(cell,pair) for cell in cells for pair in range(args.pairs)];rng.shuffle(schedule)
def host():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip(),'process_cpu':subprocess.check_output(['ps','-eo','pid,ppid,comm,pcpu'],text=True),'affinity':sorted(os.sched_getaffinity(0)),'uname':list(os.uname())}
before=host();started=time.monotonic();rows={c:[] for c in cells}
with raw.open('w') as f:
    for index,(cell,pair) in enumerate(schedule):
        k,n,d,r,o,phase=cell
        iterations=max(8_000,1_000_000//max(n,1))
        if args.mode=='holdout':iterations=max(10_000,int(100_000_000/calibration[cell]))
        if args.mode=='cold':iterations=512
        if args.mode=='allocations':iterations=32
        order=variants.copy();rng.shuffle(order);captures=[];values={}
        for variant in order:
            exe=bins['baseline'] if variant=='hash' else bins[variant]
            peer='hash' if variant=='hash' else 'map'
            command=['taskset','-c',str(cpu),str(exe),peer,k,str(n),d,r,str(iterations),o]
            if args.mode in ['cold','allocations']:command.append(phase)
            result=subprocess.run(command,capture_output=True,text=True,check=True)
            sample=json.loads(result.stdout)
            assert sample['iterations']==iterations and sample['matches']==(iterations if sample['expected'] else 0)
            if args.mode=='allocations':assert sample['allocation_instrumented']
            elif args.mode=='cold':assert not sample['allocation_instrumented']
            values[variant]=sample['cpu_ns_per_eq']
            captures.append({'variant':variant,'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':sample})
        row={'cell':list(cell),'pair':pair,'captures':captures,'outlined_baseline_ratio':values['outlined']/values['baseline']}
        if 'hash' in values:row['outlined_hash_ratio']=values['outlined']/values['hash']
        if args.mode=='allocations':
            # All map variants build the same original indexes and do no new
            # allocation in the comparison. Verify that instead of assuming it.
            counts={(s['sample']['allocation_calls'],s['sample']['allocation_bytes']) for s in captures if s['variant']!='hash'}
            assert len(counts)==1,counts
            if phase=='warm':assert counts=={(0,0)},counts
        f.write(json.dumps(row)+'\n');f.flush();rows[cell].append(row)
        if (index+1)%50==0:print(json.dumps({'complete':index+1,'total':len(schedule),'elapsed':time.monotonic()-started}),flush=True)
out={'schema':'pbrs.map-equality-final.v1','mode':args.mode,'scope':'standalone map equality; shared host pinnedCPU0, other repo build jobs paused; map construction/cloning/drop excluded; warm index construction excluded; cold index construction included on precloned independent maps; separate CPU and allocation builds; HashMap storage reference is not Prost decoding','seed':seed,'pairs':args.pairs,'variants':variants,'host_before':before,'host_after':host(),'elapsed':time.monotonic()-started,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'binary_sha256':{v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()},'cells':[]}
for cell,records in rows.items():
    ratios=[r['outlined_baseline_ratio'] for r in records]
    row={'cell':list(cell),'median_outlined_baseline':statistics.median(ratios),'range_outlined_baseline':[min(ratios),max(ratios)],'ns_medians':{v:statistics.median(next(s['sample']['cpu_ns_per_eq'] for s in r['captures'] if s['variant']==v) for r in records) for v in variants}}
    if 'hash' in variants:row['median_outlined_hash']=statistics.median(r['outlined_hash_ratio'] for r in records)
    if args.mode=='allocations':row['allocation_per_eq']={v:{'calls':next(s['sample']['allocation_calls']/s['sample']['iterations'] for s in records[0]['captures'] if s['variant']==v),'bytes':next(s['sample']['allocation_bytes']/s['sample']['iterations'] for s in records[0]['captures'] if s['variant']==v)} for v in variants}
    out['cells'].append(row)
summary.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'mode':args.mode,'elapsed':out['elapsed'],'cells':len(cells),'regressions':[r for r in out['cells'] if r['median_outlined_baseline']>1.02]},indent=2),flush=True)
