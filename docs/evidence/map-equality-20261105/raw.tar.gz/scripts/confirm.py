#!/usr/bin/env python3
"""Longer paired follow-up; select every >2% screen regression and equal controls."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import time
HERE=Path(__file__).resolve().parent
screen=json.loads((HERE/'screen-summary.json').read_text())
selected=[r for r in screen['cells'] if r['median_new_old']>1.02 or (r['cell'][3]=='equal' and r['cell'][1] in [8,256])]
raw=HERE/'confirm-raw.jsonl';summary=HERE/'confirm-summary.json'
assert not raw.exists() and not summary.exists()
cpu=min(os.sched_getaffinity(0));rng=random.Random(0x5ee01236)
bins={v:HERE/f'{v}-bin' for v in ['baseline','candidate']}
schedule=[(r,pair) for r in selected for pair in range(9)];rng.shuffle(schedule)
def host():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip(),'process_cpu':subprocess.check_output(['ps','-eo','pid,ppid,comm,pcpu'],text=True),'affinity':sorted(os.sched_getaffinity(0))}
before=host();started=time.monotonic();rows={tuple(r['cell']):[] for r in selected}
with raw.open('w') as f:
    for index,(r,pair) in enumerate(schedule):
        cell=r['cell'];kind,n,dist,rel,order=cell
        iterations=max(10_000,int(100_000_000/r['ns_medians']['baseline']))
        variants=['baseline','candidate'];rng.shuffle(variants)
        captures=[];values={}
        for variant in variants:
            command=['taskset','-c',str(cpu),str(bins[variant]),'map',kind,str(n),dist,rel,str(iterations),order]
            result=subprocess.run(command,capture_output=True,text=True,check=True)
            sample=json.loads(result.stdout)
            assert sample['iterations']==iterations and sample['matches']==(iterations if sample['expected'] else 0)
            values[variant]=sample['cpu_ns_per_eq']
            captures.append({'variant':variant,'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':sample})
        row={'cell':cell,'pair':pair,'iterations':iterations,'captures':captures,'candidate_baseline_ratio':values['candidate']/values['baseline']}
        f.write(json.dumps(row)+'\n');f.flush();rows[tuple(cell)].append(row)
        if (index+1)%20==0:print(json.dumps({'complete':index+1,'total':len(schedule),'elapsed':time.monotonic()-started}),flush=True)
out={'schema':'pbrs.map-equality-confirm.v1','scope':'same warm fixtures, selected every >2% five-pair screen regression and equal controls at8/256;9new randomized process pairs, ~100ms baseline CPU target per process; no HashMap repeat','seed':0x5ee01236,'source_screen_sha256':hashlib.sha256((HERE/'screen-summary.json').read_bytes()).hexdigest(),'host_before':before,'host_after':host(),'elapsed':time.monotonic()-started,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'binary_sha256':{v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()},'cells':[]}
for cell,records in rows.items():
    ratios=[r['candidate_baseline_ratio'] for r in records]
    out['cells'].append({'cell':list(cell),'median_new_old':statistics.median(ratios),'range_new_old':[min(ratios),max(ratios)],'ns_medians':{v:statistics.median(next(s['sample']['cpu_ns_per_eq'] for s in r['captures'] if s['variant']==v) for r in records) for v in bins}})
summary.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['cells'],indent=2),flush=True)
