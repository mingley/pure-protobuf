#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time
ROOT=Path('/workspace/pure-protobuf'); HERE=Path(__file__).resolve().parent
FLOOR=1024**3
env=os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target/map-equality-20261105'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
for var in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS']:
    env.pop(var,None)
def run(cmd,path):
    assert not path.exists(),path
    assert shutil.disk_usage(ROOT).free>FLOOR
    started=time.monotonic()
    with path.open('w') as f:
        proc=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        guard=False
        while proc.poll() is None:
            if shutil.disk_usage(ROOT).free<FLOOR:
                guard=True;os.killpg(proc.pid,signal.SIGTERM);break
            time.sleep(.2)
        code=proc.wait()
    print(json.dumps({'command':cmd,'status':code,'disk_guard':guard,'elapsed':time.monotonic()-started,'log':str(path)}),flush=True)
    assert code==0 and not guard,path
for variant in ['baseline','candidate']:
    manifest=HERE/f'{variant}-harness/Cargo.toml'
    run(['cargo','generate-lockfile','--offline','--manifest-path',str(manifest)],HERE/f'{variant}-lock.log')
    log=HERE/f'{variant}-build.jsonl'
    cmd=['cargo','build','--release','--locked','--offline','--manifest-path',str(manifest),'--message-format=json']
    before={str(p.relative_to(HERE/variant)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/variant).rglob('*')) if p.is_file()}
    run(cmd,log)
    messages=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
    executable=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='pbrs-map-equality-screen']
    assert len(executable)==1,executable
    retained=HERE/f'{variant}-bin';assert not retained.exists()
    shutil.copy2(executable[0],retained)
    after={str(p.relative_to(HERE/variant)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/variant).rglob('*')) if p.is_file()}
    assert before==after
    (HERE/f'{variant}-build.json').write_text(json.dumps({'variant':variant,'command':cmd,'source_sha256':before,'binary_sha256':hashlib.sha256(retained.read_bytes()).hexdigest(),'harness_sha256':hashlib.sha256((manifest.parent/'src/main.rs').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'lock_sha256':hashlib.sha256((manifest.parent/'Cargo.lock').read_bytes()).hexdigest(),'build_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True)},indent=2)+'\n')
assert (HERE/'baseline-harness/Cargo.lock').read_bytes()==(HERE/'candidate-harness/Cargo.lock').read_bytes()
