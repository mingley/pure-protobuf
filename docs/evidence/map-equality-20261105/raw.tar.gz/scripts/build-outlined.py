#!/usr/bin/env python3
import hashlib,json,os,shutil,signal,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');HERE=Path(__file__).resolve().parent
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target/map-equality-20261105'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
for var in ['RUSTFLAGS','RUSTDOCFLAGS','CARGO_ENCODED_RUSTFLAGS']:env.pop(var,None)
def run(cmd,path):
    assert not path.exists();assert shutil.disk_usage(ROOT).free>1024**3
    started=time.monotonic()
    with path.open('w') as f:
        p=subprocess.Popen(cmd,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        guard=False
        while p.poll() is None:
            if shutil.disk_usage(ROOT).free<1024**3:guard=True;os.killpg(p.pid,signal.SIGTERM);break
            time.sleep(.2)
        code=p.wait()
    print(json.dumps({'command':cmd,'exit_code':code,'disk_guard':guard,'elapsed':time.monotonic()-started}),flush=True)
    assert code==0 and not guard,path
manifest=HERE/'outlined-harness/Cargo.toml'
run(['cargo','generate-lockfile','--offline','--manifest-path',str(manifest)],HERE/'outlined-lock.log')
assert (HERE/'baseline-harness/Cargo.lock').read_bytes()==(HERE/'outlined-harness/Cargo.lock').read_bytes()
source=HERE/'outlined';before={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()}
cmd=['cargo','build','--release','--locked','--offline','--manifest-path',str(manifest),'--message-format=json']
log=HERE/'outlined-build.jsonl';run(cmd,log)
after={str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()};assert before==after
messages=[json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
executables=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='pbrs-map-equality-screen'];assert len(executables)==1
retained=HERE/'outlined-bin';assert not retained.exists();shutil.copy2(executables[0],retained)
(HERE/'outlined-build.json').write_text(json.dumps({'variant':'outlined','command':cmd,'source_sha256':before,'binary_sha256':hashlib.sha256(retained.read_bytes()).hexdigest(),'harness_sha256':hashlib.sha256((manifest.parent/'src/main.rs').read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(manifest.read_bytes()).hexdigest(),'lock_sha256':hashlib.sha256((manifest.parent/'Cargo.lock').read_bytes()).hexdigest(),'build_log_sha256':hashlib.sha256(log.read_bytes()).hexdigest(),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True)},indent=2)+'\n')
