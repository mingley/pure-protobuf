#!/usr/bin/env python3
import hashlib,json,shutil
from pathlib import Path
HERE=Path(__file__).resolve().parent
source=HERE/'sorted';assert not source.exists()
shutil.copytree(HERE/'candidate',source)
path=source/'src/map.rs'
old='''        self.len() == other.len() && self.iter().all(|(k, v)| other.get(k) == Some(v))
'''
new='''        if self.len() != other.len() {
            return false;
        }
        if let (Some(left), Some(right)) = (self.0.as_deref(), other.0.as_deref()) {
            if let (Some(left_index), Some(right_index)) = (left.index.get(), right.index.get()) {
                // The indexes are unique and sorted by key. Matching positions
                // can be compared directly, avoiding one binary search per key
                // and repeated examination of shadowed wire entries.
                return left_index.pos.iter().zip(&right_index.pos).all(
                    |((left_key, left_pos), (right_key, right_pos))| {
                        if left_key != right_key {
                            return false;
                        }
                        let Some((_, left_value)) = left.entries.get(*left_pos) else {
                            return false;
                        };
                        let Some((_, right_value)) = right.entries.get(*right_pos) else {
                            return false;
                        };
                        // Keep the original value comparison direction.
                        right_value == left_value
                    },
                );
            }
        }
        self.iter().all(|(k, v)| other.get(k) == Some(v))
'''
text=path.read_text();assert text.count(old)==1
path.write_text(text.replace(old,new))
harness=HERE/'sorted-harness';assert not harness.exists()
shutil.copytree(HERE/'candidate-harness',harness)
manifest=harness/'Cargo.toml';manifest.write_text(manifest.read_text().replace('../candidate','../sorted'))
lock=harness/'Cargo.lock';lock.unlink()
report={'source_scope':'same70selected baseline inputs, with Eq-only sorted-index overlay in src/map.rs plus existing tests','source_sha256':{str(p.relative_to(source)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(source.rglob('*')) if p.is_file()},'base':'1c6ec8cacd547cce8c3a8e335320b49d34de40b4'}
(HERE/'sorted-source-plan.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'files':len(report['source_sha256']),'map_sha256':report['source_sha256']['src/map.rs']}))
