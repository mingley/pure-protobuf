#!/usr/bin/env python3
"""Fixed-executable drift controls for every screen regression."""
import datetime,hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
screen=json.loads((HERE/'screen-summary.json').read_text())
selected=[r for r in screen['cells'] if r['median_new_old']>1.02]
raw=HERE/'same-source-raw.jsonl';summary=HERE/'same-source-summary.json'
assert not raw.exists() and not summary.exists()
cpu=min(os.sched_getaffinity(0));rng=random.Random(0x5ee01237)
binary=HERE/'baseline-bin'
schedule=[(r,pair) for r in selected for pair in range(9)];rng.shuffle(schedule)
def host():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip(),'process_cpu':subprocess.check_output(['ps','-eo','pid,ppid,comm,pcpu'],text=True),'affinity':sorted(os.sched_getaffinity(0))}
before=host();started=time.monotonic();rows={tuple(r['cell']):[] for r in selected}
with raw.open('w') as f:
    for index,(r,pair) in enumerate(schedule):
        cell=r['cell'];kind,n,dist,rel,order=cell
        iterations=max(10_000,int(100_000_000/r['ns_medians']['baseline']))
        variants=['first','second'];rng.shuffle(variants)
        captures=[];values={}
        for variant in variants:
            command=['taskset','-c',str(cpu),str(binary),'map',kind,str(n),dist,rel,str(iterations),order]
            result=subprocess.run(command,capture_output=True,text=True,check=True)
            sample=json.loads(result.stdout)
            assert sample['iterations']==iterations and sample['matches']==(iterations if sample['expected'] else 0)
            values[variant]=sample['cpu_ns_per_eq']
            captures.append({'variant':variant,'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':sample})
        row={'cell':cell,'pair':pair,'iterations':iterations,'captures':captures,'second_first_ratio':values['second']/values['first']}
        f.write(json.dumps(row)+'\n');f.flush();rows[tuple(cell)].append(row)
out={'schema':'pbrs.map-equality-same-source.v1','scope':'same baseline executable in both randomized positions; every >2% five-pair screen regression;9new pairs, ~100ms baseline CPU target per process','seed':0x5ee01237,'source_screen_sha256':hashlib.sha256((HERE/'screen-summary.json').read_bytes()).hexdigest(),'host_before':before,'host_after':host(),'elapsed':time.monotonic()-started,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'cells':[]}
for cell,records in rows.items():
    ratios=[r['second_first_ratio'] for r in records]
    out['cells'].append({'cell':list(cell),'median_second_first':statistics.median(ratios),'range_second_first':[min(ratios),max(ratios)]})
summary.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out['cells'],indent=2),flush=True)
