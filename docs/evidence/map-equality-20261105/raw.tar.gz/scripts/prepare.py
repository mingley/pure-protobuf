#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
BASE = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert BASE == '1c6ec8cacd547cce8c3a8e335320b49d34de40b4', BASE
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE,
    '--', 'src', 'Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml',
    'rustfmt.toml', 'vendor/google/conformance_fds.bin'], cwd=ROOT, text=True).splitlines()
source = {}
for name in paths:
    source[name] = subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT)
manifest = source['Cargo.toml'].decode()
manifest = '[workspace]\nresolver = "2"\n\n' + manifest[manifest.index('[package]'):]
source['Cargo.toml'] = manifest.encode()
for variant in ['baseline', 'candidate']:
    folder = HERE / variant
    assert not folder.exists(), folder
    for name, data in source.items():
        path = folder / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    if variant == 'candidate':
        (folder / 'src/map.rs').write_bytes((ROOT / 'src/map.rs').read_bytes())
    harness = HERE / f'{variant}-harness'
    (harness / 'src').mkdir(parents=True)
    (harness / 'Cargo.toml').write_text(f'''[workspace]
[package]
name = "pbrs-map-equality-screen"
version = "0.0.0"
edition = "2024"
[dependencies]
pbrs = {{ path = "../{variant}", default-features = false }}
libc = "0.2"
[profile.release]
debug = 0
codegen-units = 1
lto = "thin"
''')
    (harness / 'src/main.rs').write_bytes((HERE / 'bench.rs').read_bytes())
report = {'source_commit': BASE, 'source_files': paths,
    'manifest_transformation': 'workspace contains only root crate; package/features/dependencies/lints unchanged',
    'git_source_sha256': {name: hashlib.sha256(subprocess.check_output(['git','show', f'{BASE}:{name}'], cwd=ROOT)).hexdigest() for name in paths},
    'overlays': {variant: {str(p.relative_to(HERE/variant)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((HERE/variant).rglob('*')) if p.is_file()} for variant in ['baseline','candidate']}}
(HERE / 'source-plan.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'source_commit': BASE, 'files': len(paths), 'changed_files': [n for n in paths if (HERE/'baseline'/n).read_bytes() != (HERE/'candidate'/n).read_bytes()]}))
