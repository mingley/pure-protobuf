#!/usr/bin/env python3
import argparse
import datetime
import hashlib
import itertools
import json
import os
from pathlib import Path
import random
import statistics
import subprocess
import time

HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser()
parser.add_argument('--label',required=True)
parser.add_argument('--pairs',type=int,default=5)
parser.add_argument('--mode',choices=['screen','full','holdout'],default='screen')
args=parser.parse_args()
raw=HERE/f'{args.label}-raw.jsonl';summary=HERE/f'{args.label}-summary.json'
assert not raw.exists() and not summary.exists()
cpu=min(os.sched_getaffinity(0))
bins={v:HERE/f'{v}-bin' for v in ['baseline','candidate']}
for p in bins.values():assert p.is_file(),p
rng=random.Random(0x5ee01235)
cells=[]
if args.mode=='screen':
    for kind,n,dist,rel in itertools.product(['int','proto','lazy'],[8,64,256],['distinct','duplicate'],['equal','value','key','size']):
        cells.append((kind,n,dist,rel,'reverse'))
elif args.mode=='full':
    for kind,n,dist,rel,order in itertools.product(['int','proto','lazy'],[0,1,8,15,16,17,64,256],['distinct','duplicate'],['equal','value','key','size'],['forward','reverse']):
        if n==0 and dist=='duplicate':continue
        cells.append((kind,n,dist,rel,order))
else:
    for kind,n,dist,rel,order in itertools.product(['int','proto','lazy'],[1,8,16,256],['distinct','duplicate'],['equal'],['forward','reverse']):
        cells.append((kind,n,dist,rel,order))
schedule=[(cell,pair) for cell in cells for pair in range(args.pairs)]
rng.shuffle(schedule)
rows={cell:[] for cell in cells}
started=time.monotonic()
def host_observation():
    return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'uname':list(os.uname()),'affinity':sorted(os.sched_getaffinity(0)),
        'loadavg':Path('/proc/loadavg').read_text().strip(),
        'process_cpu':subprocess.check_output(['ps','-eo','pid,ppid,comm,pcpu'],text=True),
        'cpuinfo':Path('/proc/cpuinfo').read_text(),
        'taskset':subprocess.check_output(['taskset','--version'],text=True).strip()}
before=host_observation()
max_load=0.0
with raw.open('w') as f:
    for index,(cell,pair) in enumerate(schedule):
        kind,n,dist,rel,order=cell
        iterations=max(8_000,1_000_000//max(1,n))
        variants=['baseline','candidate'];rng.shuffle(variants)
        values={}
        captures=[]
        for variant in variants:
            command=['taskset','-c',str(cpu),str(bins[variant]),'map',kind,str(n),dist,rel,str(iterations),order]
            result=subprocess.run(command,capture_output=True,text=True,check=True)
            sample=json.loads(result.stdout)
            assert sample['iterations']==iterations and sample['matches']==(iterations if sample['expected'] else 0)
            values[variant]=sample['cpu_ns_per_eq']
            captures.append({'variant':variant,'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':sample})
        command=['taskset','-c',str(cpu),str(bins['baseline']),'hash',kind,str(n),dist,rel,str(iterations),order]
        result=subprocess.run(command,capture_output=True,text=True,check=True)
        reference=json.loads(result.stdout)
        record={'cell':list(cell),'pair':pair,'captures':captures,'hash_reference':{'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':reference},'candidate_baseline_ratio':values['candidate']/values['baseline'],'candidate_hash_ratio':values['candidate']/reference['cpu_ns_per_eq']}
        f.write(json.dumps(record)+'\n');f.flush()
        max_load=max(max_load,float(Path('/proc/loadavg').read_text().split()[0]))
        rows[cell].append(record)
        if (index+1)%50==0:print(json.dumps({'complete':index+1,'total':len(schedule),'elapsed':time.monotonic()-started}),flush=True)
result={'scope':'warm map equality; map/index construction, parsing and destruction excluded; shared host pinned one CPU; HashMap reference is storage only, not a Prost decoder benchmark',
    'schema':'pbrs.map-equality-screen.v1','mode':args.mode,'pairs':args.pairs,'cpu':cpu,'seed':0x5ee01235,'elapsed':time.monotonic()-started,
    'host_before':before,'host_after':host_observation(),'max_observed_1min_loadavg':max_load,
    'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'binary_sha256':{v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()},
    'cells':[{'cell':list(cell),'median_new_old':statistics.median([r['candidate_baseline_ratio'] for r in records]),'range_new_old':[min(r['candidate_baseline_ratio'] for r in records),max(r['candidate_baseline_ratio'] for r in records)],'median_new_hash':statistics.median(r['candidate_hash_ratio'] for r in records),'ns_medians':{v:statistics.median(next(s['sample']['cpu_ns_per_eq'] for s in r['captures'] if s['variant']==v) for r in records) for v in ['baseline','candidate']}} for cell,records in rows.items()]}
summary.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'cells':len(cells),'pairs':len(schedule),'elapsed':result['elapsed'],'regressions':[r for r in result['cells'] if r['median_new_old']>1.02]},indent=2),flush=True)
