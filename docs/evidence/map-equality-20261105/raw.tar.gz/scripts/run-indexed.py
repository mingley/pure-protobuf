#!/usr/bin/env python3
import argparse,datetime,hashlib,itertools,json,os,random,statistics,subprocess,time
from pathlib import Path
HERE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);parser.add_argument('--pairs',type=int,default=5);parser.add_argument('--long',action='store_true');args=parser.parse_args()
raw=HERE/f'{args.label}-raw.jsonl';summary=HERE/f'{args.label}-summary.json';assert not raw.exists() and not summary.exists()
cpu=min(os.sched_getaffinity(0));rng=random.Random(0x5ee01238)
bins={v:HERE/f'{v}-bin' for v in ['baseline','candidate','sorted']}
cells=set()
for k,n,d,r in itertools.product(['int','proto','lazy'],[8,64,256],['distinct','duplicate'],['equal','value','key','size']):cells.add((k,n,d,r,'reverse'))
for k,n,d,o in itertools.product(['int','proto','lazy'],[1,15,16,17],['distinct','duplicate'],['forward','reverse']):cells.add((k,n,d,'equal',o))
cells=sorted(cells)
source_screen=json.loads((HERE/'screen-summary.json').read_text())
by_cell={tuple(r['cell']):r for r in source_screen['cells']}
if args.long:
    # Confirm every regression seen against original baseline in indexed screen,
    # plus equal indexed/small controls. Selection is explicit and retained.
    prev=json.loads((HERE/'indexed-screen-summary.json').read_text())
    cells=[tuple(r['cell']) for r in prev['cells'] if r['median_sorted_baseline']>1.02 or (r['cell'][3]=='equal' and r['cell'][1] in [8,16,256])]
    by_cell={tuple(r['cell']):r for r in prev['cells']}
schedule=[(cell,pair) for cell in cells for pair in range(args.pairs)];rng.shuffle(schedule)
def host():return {'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'loadavg':Path('/proc/loadavg').read_text().strip(),'process_cpu':subprocess.check_output(['ps','-eo','pid,ppid,comm,pcpu'],text=True),'affinity':sorted(os.sched_getaffinity(0)),'uname':list(os.uname())}
before=host();started=time.monotonic();rows={tuple(c):[] for c in cells}
with raw.open('w') as f:
    for index,(cell,pair) in enumerate(schedule):
        k,n,d,r,o=cell
        iterations=max(8_000,1_000_000//max(n,1))
        if args.long:iterations=max(10_000,int(100_000_000/by_cell[cell]['ns_medians']['baseline']))
        variants=['baseline','candidate','sorted','hash'];rng.shuffle(variants)
        captures=[];values={}
        for variant in variants:
            exe=bins['baseline'] if variant=='hash' else bins[variant]
            peer='hash' if variant=='hash' else 'map'
            command=['taskset','-c',str(cpu),str(exe),peer,k,str(n),d,r,str(iterations),o]
            result=subprocess.run(command,capture_output=True,text=True,check=True)
            sample=json.loads(result.stdout)
            assert sample['iterations']==iterations and sample['matches']==(iterations if sample['expected'] else 0)
            values[variant]=sample['cpu_ns_per_eq']
            captures.append({'variant':variant,'command':command,'returncode':result.returncode,'stderr':result.stderr,'sample':sample})
        row={'cell':list(cell),'pair':pair,'captures':captures,'sorted_baseline_ratio':values['sorted']/values['baseline'],'sorted_candidate_ratio':values['sorted']/values['candidate'],'sorted_hash_ratio':values['sorted']/values['hash']}
        f.write(json.dumps(row)+'\n');f.flush();rows[cell].append(row)
        if (index+1)%50==0:print(json.dumps({'complete':index+1,'total':len(schedule),'elapsed':time.monotonic()-started}),flush=True)
out={'schema':'pbrs.map-equality-indexed.v1','scope':'warm equality; same original harness; baseline/simple/sorted candidates + separate-process HashMap storage reference; all4 peers process-order randomized; construction/indexbuild/drop excluded; shared host pinnedCPU0','seed':0x5ee01238,'pairs':args.pairs,'long':args.long,'host_before':before,'host_after':host(),'elapsed':time.monotonic()-started,'raw_sha256':hashlib.sha256(raw.read_bytes()).hexdigest(),'binary_sha256':{v:hashlib.sha256(p.read_bytes()).hexdigest() for v,p in bins.items()},'cells':[]}
for cell,records in rows.items():
    ratios=[r['sorted_baseline_ratio'] for r in records]
    out['cells'].append({'cell':list(cell),'median_sorted_baseline':statistics.median(ratios),'range_sorted_baseline':[min(ratios),max(ratios)],'median_sorted_candidate':statistics.median(r['sorted_candidate_ratio'] for r in records),'median_sorted_hash':statistics.median(r['sorted_hash_ratio'] for r in records),'ns_medians':{v:statistics.median(next(s['sample']['cpu_ns_per_eq'] for s in r['captures'] if s['variant']==v) for r in records) for v in ['baseline','candidate','sorted','hash']}})
summary.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'elapsed':out['elapsed'],'cells':len(cells),'regressions':[r for r in out['cells'] if r['median_sorted_baseline']>1.02]},indent=2),flush=True)
