// Allocation instrumentation is built separately from CPU executables.
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    static ACTIVE:AtomicBool=AtomicBool::new(false);
    static CALLS:AtomicU64=AtomicU64::new(0);
    static BYTES:AtomicU64=AtomicU64::new(0);
    pub struct Counted;
    unsafe impl GlobalAlloc for Counted {
        unsafe fn alloc(&self,l:Layout)->*mut u8 {
            let p=unsafe {System.alloc(l)};
            if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}
            p
        }
        unsafe fn alloc_zeroed(&self,l:Layout)->*mut u8 {
            let p=unsafe {System.alloc_zeroed(l)};
            if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);}
            p
        }
        unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {
            let out=unsafe {System.realloc(p,l,n)};
            if !out.is_null() && ACTIVE.load(Ordering::Relaxed) {CALLS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n as u64,Ordering::Relaxed);}
            out
        }
        unsafe fn dealloc(&self,p:*mut u8,l:Layout) {unsafe {System.dealloc(p,l)}}
    }
    pub fn start(){CALLS.store(0,Ordering::SeqCst);BYTES.store(0,Ordering::SeqCst);ACTIVE.store(true,Ordering::SeqCst);}
    pub fn stop(){ACTIVE.store(false,Ordering::SeqCst);}
    pub fn last()->(u64,u64){(CALLS.load(Ordering::SeqCst),BYTES.load(Ordering::SeqCst))}
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC:count::Counted=count::Counted;
#[cfg(not(feature = "allocations"))]
mod count {pub fn start(){}pub fn stop(){}pub fn last()->(u64,u64){(0,0)}}
use pbrs::{Map, MapKey, MapValue, ProtoString};
use pbrs::rt::LazyStr;
use std::collections::HashMap;
use std::hash::Hash;
use std::hint::black_box;

fn cpu_ns() -> u128 {
    let mut t = libc::timespec {tv_sec: 0, tv_nsec: 0};
    assert_eq!(unsafe {libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut t)}, 0);
    (t.tv_sec as u128) * 1_000_000_000 + t.tv_nsec as u128
}

fn map<K: MapKey, V: MapValue>(wire: impl IntoIterator<Item=(K,V)>) -> Map<K,V> {
    let mut out = Map::new();
    for (k,v) in wire {out.push_entry(k,v);}
    out
}

#[inline(never)]
fn measure_map<K:MapKey, V:MapValue+PartialEq>(a:&Map<K,V>,b:&Map<K,V>,iterations:u64,expected:bool,phase:&str) -> (u128,u64) {
    let pairs = if phase == "cold" {
        (0..iterations).map(|_| (a.clone(),b.clone())).collect::<Vec<_>>()
    } else {
        assert_eq!(phase,"warm");
        assert_eq!(a==b,expected);
        for _ in 0..100 {black_box(black_box(a)==black_box(b));}
        Vec::new()
    };
    count::start();
    let started=cpu_ns();
    let mut count=0;
    if phase == "cold" {
        for (left,right) in &pairs {count += u64::from(black_box(left)==black_box(right));}
    } else {
        for _ in 0..iterations {count += u64::from(black_box(a)==black_box(b));}
    }
    let elapsed=cpu_ns()-started;
    count::stop();
    assert_eq!(count,if expected {iterations}else{0});
    (elapsed,count)

}

#[inline(never)]
fn measure_hash<K: Eq+Hash+Clone, V:PartialEq+Clone>(a:&HashMap<K,V>,b:&HashMap<K,V>,iterations:u64,expected:bool,phase:&str) -> (u128,u64) {
    let pairs = if phase == "cold" {
        (0..iterations).map(|_| (a.clone(),b.clone())).collect::<Vec<_>>()
    } else {
        assert_eq!(phase,"warm");
        assert_eq!(a==b,expected);
        for _ in 0..100 {black_box(black_box(a)==black_box(b));}
        Vec::new()
    };
    count::start();
    let started=cpu_ns();
    let mut count=0;
    if phase == "cold" {
        for (left,right) in &pairs {count += u64::from(black_box(left)==black_box(right));}
    } else {
        for _ in 0..iterations {count += u64::from(black_box(a)==black_box(b));}
    }
    let elapsed=cpu_ns()-started;
    count::stop();
    assert_eq!(count,if expected {iterations}else{0});
    (elapsed,count)

}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(),9,"peer key_kind wire_entries distribution relationship iterations order phase");
    let phase=args[8].as_str();
    let peer=&args[1]; let kind=&args[2]; let n:usize=args[3].parse().unwrap();
    let dist=&args[4];let rel=&args[5];let iterations:u64=args[6].parse().unwrap();let order=&args[7];
    assert!(matches!(peer.as_str(),"map"|"hash"));
    assert!(matches!(kind.as_str(),"int"|"proto"|"lazy"));
    assert!(matches!(dist.as_str(),"distinct"|"duplicate"));
    assert!(matches!(rel.as_str(),"equal"|"value"|"key"|"size"));
    let cardinality=if dist=="duplicate" {(n+3)/4} else {n};
    let left:Vec<(i32,i32)>=(0..n).map(|i| ((i%cardinality) as i32, (i as i32)*7+3)).collect();
    let expected_map:HashMap<i32,i32>=left.iter().copied().collect();
    let mut right:Vec<(i32,i32)>=expected_map.iter().map(|(k,v)|(*k,*v)).collect();
    right.sort_unstable();
    if rel=="value" && !right.is_empty() {right[0].1=-1;}
    if rel=="key" && !right.is_empty() {right[0].0=1_000_000;}
    if rel=="size" {right.push((1_000_001,-1));}
    if order=="reverse" {right.reverse();} else {assert_eq!(order,"forward");}
    let expected=expected_map==right.iter().copied().collect::<HashMap<_,_>>();
    let keys=|i:i32| format!("key-{i:08}-{}", "x".repeat(36));
    let (elapsed,count)=match (peer.as_str(),kind.as_str()) {
        ("map","int")=>measure_map(&map(left.clone()),&map(right.clone()),iterations,expected,phase),
        ("map","proto")=>measure_map(&map(left.iter().map(|(k,v)|(ProtoString::from(keys(*k).as_str()),*v))),&map(right.iter().map(|(k,v)|(ProtoString::from(keys(*k).as_str()),*v))),iterations,expected,phase),
        ("map","lazy")=>measure_map(&map(left.iter().map(|(k,v)|(LazyStr::from(keys(*k).as_str()),*v))),&map(right.iter().map(|(k,v)|(LazyStr::from(keys(*k).as_str()),*v))),iterations,expected,phase),
        ("hash","int")=>measure_hash(&left.iter().copied().collect(),&right.iter().copied().collect(),iterations,expected,phase),
        ("hash",_)=>measure_hash(&left.iter().map(|(k,v)|(keys(*k),*v)).collect(),&right.iter().map(|(k,v)|(keys(*k),*v)).collect(),iterations,expected,phase),
        _=>panic!("unsupported"),
    };
    let (allocation_calls,allocation_bytes)=count::last();
    let allocation_instrumented=cfg!(feature="allocations");
    println!("{{\"peer\":\"{peer}\",\"kind\":\"{kind}\",\"n\":{n},\"cardinality\":{cardinality},\"dist\":\"{dist}\",\"relationship\":\"{rel}\",\"iterations\":{iterations},\"order\":\"{order}\",\"phase\":\"{phase}\",\"expected\":{expected},\"matches\":{count},\"cpu_ns\":{elapsed},\"cpu_ns_per_eq\":{},\"allocation_instrumented\":{allocation_instrumented},\"allocation_calls\":{allocation_calls},\"allocation_bytes\":{allocation_bytes}}}",elapsed as f64/iterations as f64);
}
