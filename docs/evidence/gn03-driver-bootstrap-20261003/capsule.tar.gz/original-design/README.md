# GN03 factor comparison proposal — design only

This directory proposes a bounded comparison of generator source **4b2384e7** and
**5fe226b0**, independently crossed with the existing **default** and
**shared_descriptors** profiles. It contains no implemented coordinator, built
artifact, materialized source snapshot or performance result. Every execution
command in `commands.json` remains `not_run` and needs a separate root lease.
The ordinary runner belongs to the GN03 owner and was only read for this review.

`proposal.json` is the machine-readable design; `schedule-proposal.json` fixes
the proposed order before outcomes; `historical-request-proto-pins.json` selects
the exact original request/FDS/proto identities from the retained archive
manifest. The archive SHA in the proposal is a retained manifest value, not a
fresh observation or a newly decompressed archive. `ordinary-runner-peer-review.json`
records the independent source review and its limits.

## Ordinary runner review

The final runner SHA is
`1ed127fe9a8ec29f41ea898ec7c6112a918befd6d6c2b9d180411581c9308405`;
its sealed config SHA is
`b1c271e1dc4f2519fe06f99db71f201f65e8ecc07345e35308ba12ce400ea445`.
No source blocker was found. The wrapper places `--offline --jobs 1` before the
first Cargo `--`, preserves child arguments, and passes the selected native
Cargo/rustc/rustdoc through the genuine nested consumers. The baseline oracle
test overlay has its own SHA and is correctly attributed separately from
baseline shipping inputs. The seven consumer tests demand real successful
compilations and a real missing-helper failure with the expected diagnostic.
Default30 means the **3+6+21 actual outputs** on the retained seeded requests,
not the 308-member historical evidence archive.

The owner-group cleanup and refusal paths preserve failed gates. The runner
checks source/path ownership, inventories all cache files, verifies retained
ELF/generated/fingerprint payload members, and rechecks immediately before
retirement. Its guard remains a sampled bound with accessible-process limits.
Executable/compiler-driver pins are not a complete sysroot/linker closure.
The selected debug CLI has actual `--bin`, fresh owned target, source/tool/argv
and copied-ELF provenance; it has no Cargo compiler-artifact JSON record or
release-performance BUILD qualification. Historical 4b/5fe source qualification
does not qualify current main. The archived five orchestration stubs cover the
earlier 1ae1 runner; three fake-Cargo wrapper checks cover final 1ed. This review
did not rerun them or launch the runner.

## Factors, inputs and unchanged workloads

| Cell | Generator source | Existing profile |
| --- | --- | --- |
| bdef | 4b2384e728bce17601d56e43a887c354d66b9024 | default |
| cdef | 5fe226b015a2c2bc667db976390b8337db6e9a2e | default |
| bshr | 4b2384e728bce17601d56e43a887c354d66b9024 | shared_descriptors |
| cshr | 5fe226b015a2c2bc667db976390b8337db6e9a2e | shared_descriptors |

The consumer runtime ROOT is fixed to the baseline 4b shipping source. Generator
manifests must resolve the respective 4b or 5fe source, while every generated
consumer manifest resolves the same 4b runtime. A proposed narrow source
projection uses the sealed 1,027 shipping inputs, without copying docs,
evidence, work, targets or history. This projection is not materialized now.
The reviewed baseline test-only overlay is never relabeled as shipping bytes;
the performance projection is built from the actual shipping commit. The
ordinary owner's source snapshots are not mutated.

The untouched harness is `bench/codegen/run.py`, SHA
`cf4cb09d684ca8a976a00ae9ee2ad6ffd05d00326981bb4b71145cda6232cbcd`.
The untouched driver is `bench/codegen/generator.rs`, SHA
`79e5383d967161094303f04f1f3925d14d74812e6a0c15147057c78d24bad796`.
Use the existing `prepare_corpus` and `measure_pbrs_cell` implementations. The
seed remains **190019**; small/100/1000 retain **6/100/1000 messages** and
**2/5/20 proto files**, their exact ordered `part_XX.proto` filenames and bytes.
Check the selected archived proto hashes before any measured cell. Replay the
exact archived default/shared CodeGeneratorRequests with the source-matched
ordinary plugins to preserve default30, shared owner/pool/FDS and filename
oracles. The independently regenerated FDS must match the archived canonical
FDS; no schema/option/field rewrite is allowed to make the workload pass.

Two generator entry points have different APIs. `protoc-gen-pbrs` reads an exact
CodeGeneratorRequest on stdin. The frozen generation measurement calls
`cg19-generator PROTO_DIR OUT_DIR PROTOC PROTO_NAMES...`, and includes actual
protoc parsing plus generation and writes. Therefore new source-matched
cg19-driver bootstraps are required for the original metric. The ordinary
plugins only serve the exact-request replay/equivalence lane. A plugin-only
measurement, if subsequently authorized, gets its own label and cannot replace
the original end-to-end generation metric.

Default profile unsets `SB09_PBRS_SHARED_DESCRIPTOR_SET`; shared profile sets it
to `1`. Reflection, JSON, text, runtime-profile and stubs variables remain
unset; the original driver chooses messages-only emission. Capture all cleared
inherited keys, including the original `PURE_PROTOBUF_*` cleanup. There are no
Cargo profile, Rust flag or compiler-wrapper overrides. Set the original common
jobs1/offline/LC_ALL controls and selected native tool paths. Source correctness
runner debug overrides are not transferred into the measured consumers.

For every factor/repeat, `prepare_corpus` starts a separate initially absent
`CAMPAIGN/cells/CASE/FACTOR/rREPEAT/cases/CASE` directory. The factor names have
equal length and repeats 0–4 have equal length. Its run/report/log directory is
the trial-specific parent, preventing log replacement, reused generated outputs
and marker1 carryover. Cold target absence is checked before compilation. A new
lock is prepared outside the cold-check metric by the original helper; registry
tuples and normalized manifests must match across factors. Drift refuses the
cell instead of silently refreshing dependencies within a measurement.

The original generated consumer roundtrips every message's **default value**.
The original marker0→1 source change and mtime wait precede incremental check.
Release stays opt-level3/thin-LTO/codegen-units1, with check incremental1 and
release incremental0. The actual linked ELF must exist and run with stdout
`1\n` and empty stderr. No added reflection call forces metadata into the ELF.
Equal ELF size is a retained result even when generated source is smaller.

## Commands and evidence sidecars

`commands.json` gives exact argv arrays and labels. For example, after approved
source/manifest/lock preparation, bootstrap base with the selected native Cargo:

```text
/workspace/pure-protobuf/work/toolchain/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo build --offline --locked --manifest-path CAMPAIGN/drivers/base/Cargo.toml --target-dir CAMPAIGN/drivers/base/target/bootstrap --bin cg19-generator
```

The candidate command differs only in its source/manifest/owned target path.
Jobs1 is supplied in the recorded environment. Copy the actual selected debug
driver into `CAMPAIGN/bin/cg19-generator-{base,cand}`, make it immutable, record
its ELF SHA and recheck it before and after every cell. Driver compilation is
excluded setup, never the consumer's cold target. The original old718 driver
and old f6 lock are not silently substituted for a new source-matched bootstrap.
Source-matched driver locks and normalized manifests need review before either
build; use identical registry tuples and original features.

The original measured check/release argv stays:

```text
CARGO check --offline --locked --manifest-path CONSUMER/Cargo.toml --target-dir FRESH_CELL_TARGET --bin cg19-consumer-CASE
CARGO check --offline --locked --manifest-path CONSUMER/Cargo.toml --target-dir SAME_CELL_TARGET --bin cg19-consumer-CASE
CARGO build --release --offline --locked --manifest-path CONSUMER/Cargo.toml --target-dir SAME_CELL_TARGET --bin cg19-consumer-CASE
```

The future coordinator interface proposed in `commands.json` is
`PYTHON -B coordinate-gn03-factors.py --plan proposal.json --case small|100|1000
--stage screen --repeats 1 --jobs 1 --seed 190019 --timeout-seconds 900
--rss-sample-ms 100 --campaign NEW --root-lease NEW_LEASE.json`.
**That coordinator file does not exist yet.** A later repeated campaign uses
`--stage repeated --repeats 5`, separately authorized per corpus. Neither
interface is an execution instruction for the current turn.

Retain a BUILD envelope for each actual driver: exact source/manifest/lock,
selected tool paths/versions/hashes and compiler/linker closure limits, exact
argv/cwd/environment, fresh target identity, raw stdout/stderr, UTC start/end,
exit and actual selected ELF path/hash. Capture before/after source/tool/input
pins, including actual C/linker tools if they are invoked; do not reconstruct
missing before pins. Do not claim compiler-artifact JSON that the unchanged
argv did not emit. Each cell has a RUN envelope linking its root lease,
schedule/observer SHA, factor, repeat, all source/runtime/request/proto/FDS/lock
pins, selected driver and every actual phase/ELF. Preserve the original per-cell
summary and raw logs; independent aggregation adds factor labels in a separate
record without rewriting the original result.

The portable auditor must reject incomplete or duplicate factor/repeat coverage,
bad before/after pins, changed workload/profile/lock, missing raw phases,
nonzero phase exits, wrong smoke output, altered derived metrics and unverified
retirement. All five original measured phases provide elapsed and lower-bound
peak RSS; source bytes and actual linked ELF bytes complete the original **12
metrics**. Source line counts/hash/owner representation and disk telemetry are
additional diagnostics, not replacements for binary/check measurements.

## Guard, retirement and controls

Only one bootstrap or consumer target is active, capped at **2 GiB allocated
bytes**, with **2 GiB global free** retained. Jobs1, 900-second phase timeouts,
100-ms original RSS sampling and 5-second resource telemetry remain fixed.
Before a grant, fresh free space must cover the cache ceiling plus reserve plus
planned retained/source artifact growth. A resource shortfall holds the run;
the ceiling, reserve and workload are not relaxed. Registry/OS caches can remain
warm and are explicitly disclosed; fresh-target cold check does not imply a
cold host or cold registry.

The frozen helper creates a new session for each actual timed/plain phase.
The future work-only coordinator therefore needs a module-local `subprocess`
observer that forwards calls unchanged and records returned Popen PID/start
identity/process-group/session. Its watchdog must terminate/reap only actual
owned phase groups and the coordinator on cancellation/guard failure. Killing
only the outer group is insufficient. No global monkeypatch, extra shell
wrapper or changed timed argv is proposed. Bookkeeping/guard overhead is
included in the timings, equal for all factors, and must be disclosed. Before
execution, synthetic tests must prove cleanup of independent child sessions,
timeouts/resource failures, fail-closed ownership and source/input corruption.
Accessible `/proc` and sampled allocated/free measurements remain bounded
observations, not continuous or exclusive backing-store guarantees.

After each completed cell and outside timed phases, stop readers and verify
ownership/source invariants. Inventory every target file. Stream archives of
all executable ELFs, complete fingerprint payloads, build-script/generated
outputs, exact consumer/source/proto/request/FDS/manifests/locks and all raw
records; verify members and SHA manifests before retiring the exact owned
target. Ordinary unretained dependency/cache contents are explicitly hash-only,
not presented as retained payload. No duplicate uncompressed staging or
deletion of shared targets/caches is permitted. Preservation failure retains
the cache and blocks the next cell. Retained artifact growth is budgeted before
each new lease, not hidden outside the owned-cache cap. Large archive/hash work
occurs outside timed quiet phases and needs root coordination.

The initial four cells per corpus are **unqualified diagnostics**. The proposed
screen order is small `bshr,cshr,cdef,bdef`; 100 `cdef,bdef,bshr,cshr`; 1000
`bdef,cdef,cshr,bshr`. The full schedule retains the original seeded-sample
convention, **five repeats per factor**, **20 cells per corpus**, **60 across all
three corpora**, with raw distributions. Schedule approval precedes outcomes;
failures remain failures and no favorable retakes replace them. Separately
authorized unchanged-driver default/shared replay controls are required before
inferential claims; this plan does not invent a new numerical noise allowance.

Report candidate/default versus baseline/default and candidate/shared versus
baseline/shared separately. Also report sharing versus default within each
source. A descriptive interaction is `(cshr/bshr)/(cdef/bdef)-1` for positive
metrics. Candidate/shared versus baseline/default changes two factors and
cannot be described as the byte-string candidate's causal win. Original GN03
binary-size/check-time acceptance still requires a fall; all original metric
loss/equality flags and parent regression gates remain. No new 2% substitution,
threshold waiver or metadata-retaining consumer closes an equal ELF result.

## Historical scope and remaining parent gaps

The old source **795193f6**, generator **718aef41**, driver lock **f6f3382c** and
single fixed-order 1000 retry remain preserved historical diagnostics. That
retry has equal linked ELF size and **5.28184% slower unchanged generation** in
the shared profile. The first 1000 failure and small-pair overlap remain in
their original records. Those artifacts do not qualify generator 5fe, this
four-factor plan or current main. The fixed4b runtime further limits the future
campaign to the historical generator pair; current-main whole-tree performance
and independent pinned-host qualification remain separate.

The safe Prost hook is still isolated at **10bee600 → 72cfc3e5**. Current72
ordinary correctness, matched original-profile release/source/tool/ELF/lock
proof, the original ≥2% IR-or-allocation screen, full20 and compression/secondary
controls, 244 eligible Prost/Tonic ledger rows (2,928 children), and actual
release default-None folding inspection remain open. Old ed9027 correctness
proof retains its exact source scope. Even a Prost win does not close SV09's
separate pure-pbrs streaming improvement or unary-regression acceptance.

The shared parent campaign still lacks completed BUILD/ELF qualification,
TC32b's 324 eligible actual-bridge cost cells out of 336 (12 maps blocked), and
SB32's 488 eligible unchanged generated-adapter rows out of 512 (24 maps
blocked), their original full matrices, repeats and 1% unchanged controls.
CL08's per-row allocation/byte floors against Tonic, all prior losses and the
SV09 streaming floors remain explicit. Historical10bee controls do not certify
later main's outbound predicate/backend changes. Source completion and
independent correctness are useful progress, but these numeric gates remain
`not_run`; universal fastest-production wording is unsupported.
