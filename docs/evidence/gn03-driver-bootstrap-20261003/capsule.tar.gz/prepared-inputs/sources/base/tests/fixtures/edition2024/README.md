# Edition 2024 Test Fixtures & Oracles

This directory contains versioned test fixtures, compiled descriptor sets, wire-format test vectors,
and expected semantic oracles for Protocol Buffers **Edition 2024** (`edition = "2024";`, enum `1001`).

These fixtures serve as the authoritative test oracle for:

- **CG-12**: Freeze the Edition 2024 semantic contract
- **CG-13**: Implement approved Edition 2024 descriptor semantics (`src/dynamic.rs`)
- **CG-14**: Qualify Edition 2024 generated consumers (`src/codegen.rs`)
- **CG-16**: Select a reviewed Rust proto frontend

---

## 1. Directory Structure

```text
tests/fixtures/edition2024/
├── README.md               # This document: fixture inventory, contracts, and oracles
├── expectations.json       # Consolidated machine-readable test oracle & checksums
├── proto/                  # Canonical Edition 2024 .proto schemas
│   ├── defaults.proto      # Baseline schema exercising all Edition 2024 defaults
│   ├── overrides.proto     # Schema exercising explicit overrides for every feature
│   ├── inheritance.proto   # Schema exercising file -> message -> field / enum inheritance
│   ├── visibility.proto    # Schema exercising export/local visibility keywords and defaults
│   ├── extensions.proto    # Schema exercising Edition 2024 extension syntax and ranges
│   ├── legacy_style.proto  # CG-14: inherited STYLE_LEGACY naming opt-out
│   ├── maps.proto          # CG-14: verified string map key and value
│   ├── maps_none.proto     # CG-14: file-level unverified string map entries
│   └── closed_enum.proto   # CG-14: repeated/expanded/map CLOSED reference
├── fds/                    # Deterministic FileDescriptorSet binaries compiled via protoc 36.1
│   ├── cg14_preview.fds    # Four supplementary schemas, including vendored original extensions
│   ├── closed_enum.fds     # Checked repeated and map CLOSED reference descriptor
│   ├── defaults.fds
│   ├── overrides.fds
│   ├── inheritance.fds
│   ├── visibility.fds
│   └── extensions.fds
├── bin/                    # Canonical wire-encoded binary payloads (.bin)
│   ├── defaults_empty.bin
│   ├── defaults_zero_set.bin
│   ├── defaults_populated.bin
│   ├── overrides_implicit_zero.bin
│   ├── overrides_implicit_set.bin
│   ├── overrides_expanded_repeated.bin
│   ├── overrides_delimited_message.bin
│   └── extensions_populated.bin
├── expectations/           # Per-schema resolved descriptor expectation JSONs
│   ├── defaults.json
│   ├── overrides.json
│   ├── inheritance.json
│   ├── visibility.json
│   └── extensions.json
├── reference/              # Opt-in v36.1 generated/dynamic C++ wire reference
│   ├── roundtrip.cc        # Opt-in generated/dynamic C++ re-encode driver
│   └── observed.txt        # Generated and dynamic parse/re-encode observations
├── test_reference.py       # Offline SHA-256 and nine-vector integrity checks
└── rejected/               # Schemas rejected by upstream protoc & Edition 2024 specification
    ├── README.md
    ├── import_weak.proto
    ├── ctype_option.proto
    ├── java_multiple_files.proto
    ├── group_syntax.proto
    ├── optional_keyword.proto
    ├── required_keyword.proto
    ├── naming_style.proto
    ├── visibility_defs.proto
    └── visibility_import_local.proto
```

---

## 2. Schema Catalog

| Schema Path | Package | Key Behaviors Exercised |
|---|---|---|
| `proto/defaults.proto` | `edition2024.defaults` | Exercises default Edition 2024 behaviors: explicit presence on singular scalars without `optional`, open enum preserving unknown variants, packed repeated scalars, verified UTF-8 strings, length-prefixed submessages, allowed JSON format, STYLE2024 naming, and EXPORT_TOP_LEVEL symbol visibility. |
| `proto/overrides.proto` | `edition2024.overrides` | Exercises explicit feature overrides: `features.field_presence = IMPLICIT`, `features.field_presence = LEGACY_REQUIRED`, `features.repeated_field_encoding = EXPANDED`, `features.utf8_validation = NONE`, `features.message_encoding = DELIMITED`, `features.json_format = LEGACY_BEST_EFFORT`, and `features.enum_type = CLOSED`. |
| `proto/inheritance.proto` | `edition2024.inheritance` | Exercises feature inheritance rules: file-level defaults (`IMPLICIT`, `EXPANDED`, `NONE`), field-level overrides reverting to (`EXPLICIT`, `PACKED`, `VERIFY`), message-level `json_format` overrides with nested message overrides, and enum-level `CLOSED` overrides both at file scope and nested inside messages. |
| `proto/visibility.proto` | `edition2024.visibility` | Exercises symbol visibility: `export` and `local` keywords on top-level and nested messages/enums, and confirms unadorned nested messages/enums default to local under `EXPORT_TOP_LEVEL`. |
| `proto/extensions.proto` | `edition2024.extensions` | Exercises Edition 2024 extensions: `extensions 100 to 1000;` declaration, file-level `extend` block, nested message-scoped `extend` block, scalar, string, repeated, submessage, enum extensions, default values (`[default = 42]`), and extension feature overrides (`features.enum_type = CLOSED`). |
| `proto/legacy_style.proto` | `edition2024.legacy` | File-level `STYLE_LEGACY` inherited by unconventional message, field, and nested names. |
| `proto/maps.proto` | `edition2024.map_cases` | `map<string, string>` verifies both key and value UTF-8 independently of the outer map field. |
| `proto/maps_none.proto` | `edition2024.map_none` | File-level `utf8_validation = NONE` inherited by both map entry strings. |
| `proto/closed_enum.proto` | `cg14.reference` | Independent C++ v36.1 reference for packed and expanded repeated CLOSED enums, negative/high-bit unknown values and map-entry rejection; generation by pbrs remains unsupported. |

The supplemental `fds/cg14_preview.fds` contains these three schemas and the
already vendored `vendor/google/rust/test/extensions.proto` (under the descriptor
name `rust/test/extensions.proto`). It was compiled once with `libprotoc 36.1`:

```sh
protoc -I tests/fixtures/edition2024/proto -I vendor/google \
  --retain_options --include_imports \
  --descriptor_set_out=tests/fixtures/edition2024/fds/cg14_preview.fds \
  legacy_style.proto maps.proto maps_none.proto rust/test/extensions.proto
```

`--retain_options` preserves the source-retention naming override; without it,
the otherwise valid `legacy_style.proto` descriptor loses `STYLE_LEGACY` and
fails closed. Its checked SHA-256 is recorded in `expectations.json`. Mandatory
generated-consumer tests read the checked bytes and do not invoke a compiler
that supports Edition 2024. Source-only rejection or regeneration requires
`libprotoc 36.1` and is explicitly opt-in through the ignored
`edition2024_rejected_source_fixtures_fail_in_protoc` and
`edition2024_preview_descriptor_matches_pinned_source_compiler` tests in
`tests/plugin.rs`.

### Repeated CLOSED-enum reference (outside the qualified subset)

`proto/closed_enum.proto`, `fds/closed_enum.fds`, and `reference/observed.txt`
are checked to the SHA-256 values in `expectations.json`. The observations
come from two paths through local C++ `libprotobuf 36.1`: a generated
`cg14.reference.Cases` and a separate non-delegating
`DynamicMessageFactory` parser. `reference/roundtrip.cc` checks the edition
features at runtime and records all nine packed/unpacked/mixed/map cases.
Upstream source was pinned to
[`protocolbuffers/protobuf@f377bfefc5e2cfab68b816903c25b23e091c439d`](https://github.com/protocolbuffers/protobuf/tree/f377bfefc5e2cfab68b816903c25b23e091c439d)
(`v36.1`); the locally installed `protoc` SHA-256 was
`aba46cd89af664eadb078e74ae717c8ebda0429b0251fc4f428ffe6184c7599b`
and its linked `libprotobuf.36.1.0.dylib` SHA-256 was
`33fc0d349f957fd105bdc773d4757ccccf6239248c826dcd1b5f0e20d7f4f104`.
The local binary was not independently verified as an official-release build.

To reproduce on macOS with those already-installed v36.1 C++ headers and
libraries, without modifying the checked files:

```sh
mkdir -p target/cg14-reference-proof
/opt/homebrew/bin/protoc -I tests/fixtures/edition2024/proto --retain_options \
  --cpp_out=target/cg14-reference-proof \
  --descriptor_set_out=target/cg14-reference-proof/closed_enum.fds closed_enum.proto
cmp tests/fixtures/edition2024/fds/closed_enum.fds target/cg14-reference-proof/closed_enum.fds
clang++ -std=c++17 -DNDEBUG -Itarget/cg14-reference-proof \
  -I/opt/homebrew/include -L/opt/homebrew/lib \
  tests/fixtures/edition2024/reference/roundtrip.cc \
  target/cg14-reference-proof/closed_enum.pb.cc \
  -lprotobuf -labsl_log_internal_message -labsl_log_internal_check_op \
  -o target/cg14-reference-proof/roundtrip
target/cg14-reference-proof/roundtrip > target/cg14-reference-proof/observed.txt
cmp tests/fixtures/edition2024/reference/observed.txt \
  target/cg14-reference-proof/observed.txt
```

The offline default CI runs `test_reference.py` and refuses changed descriptor
or observation bytes without matching checked hashes. That integrity check
does not compile this optional C++ reference or qualify new codegen support. Generated and
dynamic C++ use the same library, not independent runtimes: packed negative
unknown `-1` re-encodes as a ten-byte unknown varint, while an earlier unpinned
Python 6.33.1 probe produced five bytes. Unknown packed values also move after
the known packed field, and unknown CLOSED map entries are retained as entire
unknown entry bytes. C++ wire output is not established as universal upb/Rust
behavior. pbrs rejects repeated/map CLOSED codegen pending a reviewed
cross-runtime contract and original shared/conformance proof. The plugin
advertises `maximum_edition=1001` for the other qualified Edition 2024
features; see the [semantic contract](../../../docs/edition-2024.md).

---

## 3. Pinned Edition 2024 Defaults Matrix

| Feature | FeatureSet Tag | Edition 2024 Default | Enum Name & Value | Semantic Meaning |
|---|---|---|---|---|
| `field_presence` | 1 | `EXPLICIT` | `FieldPresence::EXPLICIT = 1` | Singular scalar fields have presence tracking. Setting a field to `0` or `""` serializes it on the wire. |
| `enum_type` | 2 | `OPEN` | `EnumType::OPEN = 1` | Unknown enum integers are preserved as valid enum numbers and round-trip without corruption. |
| `repeated_field_encoding` | 3 | `PACKED` | `RepeatedFieldEncoding::PACKED = 1` | Packable repeated scalar fields are packed into length-delimited byte chunks on the wire. |
| `utf8_validation` | 4 | `VERIFY` | `Utf8Validation::VERIFY = 2` | String fields must contain valid UTF-8 bytes; invalid sequences trigger deserialization error. |
| `message_encoding` | 5 | `LENGTH_PREFIXED` | `MessageEncoding::LENGTH_PREFIXED = 1` | Submessages are encoded with wire type 2 (`WIRE_LEN`) followed by length varint and message payload. |
| `json_format` | 6 | `ALLOW` | `JsonFormat::ALLOW = 1` | Canonical Protobuf JSON serialization and deserialization is supported and allowed. |
| `enforce_naming_style` | 7 | `STYLE2024` | `EnforceNamingStyle::STYLE2024 = 1` | Enforces PascalCase for types, lower_snake_case for fields/oneofs, and TitleCase for RPC methods during compilation. |
| `default_symbol_visibility`| 8 | `EXPORT_TOP_LEVEL` | `VisibilityFeature::EXPORT_TOP_LEVEL = 2` | Top-level messages/enums default to exported; nested messages/enums default to local. |

---

## 4. Wire-Format Vectors (`.bin`)

The `bin/` directory contains exact binary payloads encoded with `protoc --encode` to serve as golden wire-format oracles:

1. **`defaults_empty.bin` (0 bytes)**:
   An unpopulated `DefaultMessage`. Serializes to empty slice.

2. **`defaults_zero_set.bin` (6 bytes: `08 00 28 00 32 00`)**:
   `DefaultMessage` with `int32_field: 0`, `bool_field: false`, `string_field: ""`.
   - `08 00`: Tag 1 (`(1 << 3) | 0`), varint 0
   - `28 00`: Tag 5 (`(5 << 3) | 0`), varint 0
   - `32 00`: Tag 6 (`(6 << 3) | 2`), length 0
   *Demonstrates that in Edition 2024, default values for fields with EXPLICIT presence are emitted on the wire.*

3. **`defaults_populated.bin` (96 bytes)**:
   `DefaultMessage` populated with all standard types: scalars, enum, repeated int32 (packed: `52 03 01 02 03`), repeated string (unpacked strings: `5a 05 ... 5a 04 ...`), submessage, and map entry.

4. **`overrides_implicit_zero.bin` (0 bytes)**:
   `OverridesMessage` with `implicit_int32: 0`.
   *Demonstrates that with `features.field_presence = IMPLICIT`, setting a field to zero suppresses wire emission.*

5. **`overrides_implicit_set.bin` (2 bytes: `08 2a`)**:
   `OverridesMessage` with `implicit_int32: 42`. Emits tag 1 varint 42.

6. **`overrides_expanded_repeated.bin` (6 bytes: `18 0a 18 14 18 1e`)**:
   `OverridesMessage` with `expanded_int32: [10, 20, 30]`.
   - `18 0a`: Tag 3 (`(3 << 3) | 0`), varint 10
   - `18 14`: Tag 3, varint 20
   - `18 1e`: Tag 3, varint 30
   *Demonstrates `features.repeated_field_encoding = EXPANDED` emitting individual repeated varint tags rather than a packed length-delimited blob.*

7. **`overrides_delimited_message.bin` (9 bytes: `2b 0a 05 68 65 6c 6c 6f 2c`)**:
   `OverridesMessage` with `delimited_message: { text: "hello" }`.
   - `2b`: Tag 5, wire type 3 (`WIRE_SGROUP`, `(5 << 3) | 3`)
   - `0a 05 68 65 6c 6c 6f`: Submessage field tag 1, len 5, `"hello"`
   - `2c`: Tag 5, wire type 4 (`WIRE_EGROUP`, `(5 << 3) | 4`)
   *Demonstrates group-like delimited encoding selected via `features.message_encoding = DELIMITED`.*

8. **`extensions_populated.bin` (34 bytes)**:
   `ExtendableMessage` with base field 1 and extensions 101, 102, 103, 104, 105, 106.
   Includes extension range verification and default value handling.

---

## 5. Negative Oracle Summary (`rejected/`)

All negative fixtures in `rejected/` were verified against `protoc 36.1`.
They require an explicitly opted-in source-compiler test and are not part of
the default Cargo gate, whose Ubuntu compiler may predate Edition 2024:

1. `import_weak.proto`: Weak imports are removed in Edition 2024.
2. `ctype_option.proto`: `[ctype = ...]` option is removed in Edition 2024.
3. `java_multiple_files.proto`: `option java_multiple_files = ...` is removed in Edition 2024.
4. `group_syntax.proto`: `group` keyword syntax is removed in editions.
5. `optional_keyword.proto`: `optional` keyword is removed in editions.
6. `required_keyword.proto`: `required` keyword is removed in editions.
7. `naming_style.proto`: Non-standard naming rejected under `STYLE2024`.
8. `visibility_import_local.proto`: Importing symbols marked `local` is rejected across file boundaries.

---

## 6. Downstream Task Consumption Contract

- **CG-13 (`src/dynamic.rs`)**:
  - Must parse `fds/*.fds` without panic or error.
  - Must verify resolved features on each `FieldDescriptor`, `MessageDescriptor`, and `EnumDescriptor` against `expectations/*.json`.
  - Must correctly identify `enum_type = CLOSED` on enums overriding the default (e.g. `ClosedEnum`).
  - Must decode `bin/*.bin` into `DynamicMessage` and match field presence, packed repeated, and delimited submessages.
- **CG-14 (`src/codegen.rs`)**:
  - Must compile `proto/*.proto` after raising `maximum_edition = 1001`.
  - Must generate typed accessors matching presence and encoding contracts.
