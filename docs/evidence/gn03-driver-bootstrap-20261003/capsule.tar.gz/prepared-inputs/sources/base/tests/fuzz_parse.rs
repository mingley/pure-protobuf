//! In-tree wire-corpus parse. ParseError is ignored; panics are crashes.

#![allow(
    clippy::disallowed_methods,
    clippy::let_underscore_must_use,
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::indexing_slicing,
    clippy::panic,
    clippy::cast_possible_truncation,
    clippy::cast_possible_wrap,
    clippy::cast_sign_loss,
    clippy::too_many_lines,
    clippy::unimplemented,
    unreachable_pub,
    reason = "integration tests are sync; generated fixtures live in the test crate"
)]
use pbrs::gencode::TestAllTypesProto3;
use pbrs::testdata::Person;
use pbrs::{Parse, Serialize};

const EMPTY: &[u8] = &[];
const TRUNCATED_VARINT: &[u8] = &[0x08, 0xff];
// Minimized fuzzer crash (fuzz/corpus/wire/len_overflow_min.bin): field 1,
// length-delimited, length varint far beyond the buffer. Must be a parse
// error, never an arithmetic-overflow panic.
const LEN_OVERFLOW: &[u8] = &[0x0a, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0x01];
// id=1 name=ada email=ada@ex address.city=nyc (tests/typed.rs)
const PERSON: &[u8] = &[
    0x08, 0x01, 0x12, 0x03, b'a', b'd', b'a', 0x1a, 0x06, b'a', b'd', b'a', b'@', b'e', b'x', 0x32,
    0x05, 0x0a, 0x03, b'n', b'y', b'c',
];

fn valid_tat_bytes() -> Vec<u8> {
    let mut m = TestAllTypesProto3::new();
    m.set_optional_int32(7);
    m.set_optional_string("ada");
    m.serialize().expect("serialize TAT")
}

fn feed(bytes: &[u8]) {
    let _ = Person::parse(bytes);
    let _ = TestAllTypesProto3::parse(bytes);
}

#[test]
fn fuzz_parse_short_campaign() {
    let tat = valid_tat_bytes();
    let corpus: [&[u8]; 5] = [EMPTY, TRUNCATED_VARINT, PERSON, &tat, LEN_OVERFLOW];
    for bytes in corpus {
        feed(bytes);
    }
}
