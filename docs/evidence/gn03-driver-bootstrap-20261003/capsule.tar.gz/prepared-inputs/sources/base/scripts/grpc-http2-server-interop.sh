#!/usr/bin/env bash
# Run HTTP/2 server framing and TLS verification probes against native pbrs-grpc-interop-server.
#
# Two phases, two result files, one log directory:
#
#   Local phase (spec-derived adapter, peer local-native-server):
#     server_tls_probe     - ALPN negotiation (h2), rejection of non-h2 ALPN (http/1.1),
#                            TLS 1.2/1.3 ciphers, certificate exchange, and live TLS gRPC RPC.
#     server_framing_probe - HTTP/2 preface and SETTINGS exchange, rapid reset flood
#                            (CVE-2023-44487 simulation), small DATA frames flow control,
#                            CONTINUATION frame reassembly and flood protection,
#                            bad headers / HTTP 405 / HTTP 415 rejection, and post-probe
#                            server health verification.
#     The local phase proves the native server against a purpose-built peer. It is
#     regression coverage, never original-upstream qualification. In-tree hostile
#     tests (pbrs-grpc/tests/hostile.rs) and TLS tests (pbrs-grpc/tests/tls.rs)
#     are complementary and are never recorded as probe results.
#
#   Upstream phase (original runner, peer grpc-http2-probe):
#     Executes the pinned grpc/grpc tools/http2_interop Go probes against a fresh
#     native server via scripts/grpc-http2-upstream-server-interop.py and records
#     one row per probe: the framing mode maps to server_framing_probe and the
#     tls mode maps to server_tls_probe. When the runner prerequisites are
#     unavailable the probes are recorded as not_run with the exact reason and
#     reproduction steps -- never silent, never faked.
#
# Prerequisites for the upstream phase: Go per tests/interop/go/go.mod, a clean
# third_party/grpc checkout at d1487957db6658bc532b72871775148229836627, and a
# cargo cache warm enough for the diagnostic's offline locked debug build.
# See tests/interop/README.md for the exact repro commands.
#
# Usage:
#   ./scripts/grpc-http2-server-interop.sh [OPTIONS]
#
# Options:
#   --cases=CASE1,CASE2,...    Run only specified test cases (default: server_tls_probe,server_framing_probe)
#   --server-host=HOST         Server host to probe (default: 127.0.0.1)
#   --port=PORT                Cleartext port to bind native server to (default: dynamic)
#   --tls-port=PORT            TLS port to bind native server to (default: dynamic)
#   --tls-cert-file=PATH       Path to PEM certificate file (default: pbrs-grpc/tests/tls_data/server.crt)
#   --tls-key-file=PATH        Path to PEM private key file (default: pbrs-grpc/tests/tls_data/server.key)
#   --tls-ca-file=PATH         Path to PEM CA certificate file (default: pbrs-grpc/tests/tls_data/ca.crt)
#   --skip-build               Skip cargo build step (local phase only; the upstream
#                              diagnostic always builds through its own fail-closed path)
#   --skip-upstream            Run only the local spec-derived phase (explicitly narrowed
#                              scope; the original-probe evidence stays missing)
#   --upstream-only            Run only the original-upstream phase
#   --log-dir=DIR              Directory for log files (default: target/interop-logs/server_probes_<timestamp>)
#   --results-json=PATH        Path to write local-phase results JSON
#   --report-json=PATH         Path to write local-phase report JSON
#   -h, --help                 Show this help message
#
# Exit status: 0 only when every executed phase passed and aggregated cleanly.
# A missing probe row, an unexpected failure, or an unavailable upstream runner
# fails the run; use --skip-upstream / --upstream-only to narrow scope explicitly.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

INTEROP_REPORT="$ROOT/scripts/interop-report.py"

DEFAULT_CASES=(
  server_tls_probe
  server_framing_probe
)

CASES=("${DEFAULT_CASES[@]}")
SERVER_HOST="127.0.0.1"
CLEARTEXT_PORT=""
TLS_PORT=""
SKIP_BUILD=0
SKIP_UPSTREAM=0
UPSTREAM_ONLY=0
LOG_DIR=""
RESULTS_JSON=""
REPORT_JSON=""
TLS_CERT_FILE=""
TLS_KEY_FILE=""
TLS_CA_FILE=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --cases)
      IFS=',' read -r -a CASES <<< "$2"
      shift 2
      ;;
    --cases=*)
      IFS=',' read -r -a CASES <<< "${1#*=}"
      shift
      ;;
    --server-host)
      SERVER_HOST="$2"
      shift 2
      ;;
    --server-host=*)
      SERVER_HOST="${1#*=}"
      shift
      ;;
    --port|--cleartext-port)
      CLEARTEXT_PORT="$2"
      shift 2
      ;;
    --port=*|--cleartext-port=*)
      CLEARTEXT_PORT="${1#*=}"
      shift
      ;;
    --tls-port)
      TLS_PORT="$2"
      shift 2
      ;;
    --tls-port=*)
      TLS_PORT="${1#*=}"
      shift
      ;;
    --tls-cert-file)
      TLS_CERT_FILE="$2"
      shift 2
      ;;
    --tls-cert-file=*)
      TLS_CERT_FILE="${1#*=}"
      shift
      ;;
    --tls-key-file)
      TLS_KEY_FILE="$2"
      shift 2
      ;;
    --tls-key-file=*)
      TLS_KEY_FILE="${1#*=}"
      shift
      ;;
    --tls-ca-file)
      TLS_CA_FILE="$2"
      shift 2
      ;;
    --tls-ca-file=*)
      TLS_CA_FILE="${1#*=}"
      shift
      ;;
    --skip-build)
      SKIP_BUILD=1
      shift
      ;;
    --skip-upstream)
      SKIP_UPSTREAM=1
      shift
      ;;
    --upstream-only)
      UPSTREAM_ONLY=1
      shift
      ;;
    --log-dir|--output-dir)
      LOG_DIR="$2"
      shift 2
      ;;
    --log-dir=*|--output-dir=*)
      LOG_DIR="${1#*=}"
      shift
      ;;
    --results-json)
      RESULTS_JSON="$2"
      shift 2
      ;;
    --results-json=*)
      RESULTS_JSON="${1#*=}"
      shift
      ;;
    --report-json)
      REPORT_JSON="$2"
      shift 2
      ;;
    --report-json=*)
      REPORT_JSON="${1#*=}"
      shift
      ;;
    -h|--help)
      grep '^# ' "$0" | cut -c 3-
      exit 0
      ;;
    *)
      echo "Unknown flag: $1" >&2
      exit 1
      ;;
  esac
done

DEFAULT_TLS_DIR="$ROOT/pbrs-grpc/tests/tls_data"
TLS_CERT_FILE="${TLS_CERT_FILE:-$DEFAULT_TLS_DIR/server.crt}"
TLS_KEY_FILE="${TLS_KEY_FILE:-$DEFAULT_TLS_DIR/server.key}"
TLS_CA_FILE="${TLS_CA_FILE:-$DEFAULT_TLS_DIR/ca.crt}"

TIMESTAMP_PID="$(date +%Y%m%d_%H%M%S)_$$"
if [[ -z "$LOG_DIR" ]]; then
  LOG_DIR="$ROOT/target/interop-logs/server_probes_${TIMESTAMP_PID}"
fi
mkdir -p "$LOG_DIR"

RESULTS_JSON="${RESULTS_JSON:-$LOG_DIR/results.json}"
REPORT_JSON="${REPORT_JSON:-$LOG_DIR/report.json}"

RUN_LOCAL=1
RUN_UPSTREAM=1
if [[ "$SKIP_UPSTREAM" -eq 1 && "$UPSTREAM_ONLY" -eq 1 ]]; then
  echo "Error: --skip-upstream and --upstream-only are mutually exclusive" >&2
  exit 1
fi
if [[ "$SKIP_UPSTREAM" -eq 1 ]]; then
  RUN_UPSTREAM=0
fi
if [[ "$UPSTREAM_ONLY" -eq 1 ]]; then
  RUN_LOCAL=0
fi

UPSTREAM_DRIVER="$ROOT/scripts/grpc-http2-upstream-server-interop.py"
UPSTREAM_DIR="$LOG_DIR/upstream"
UPSTREAM_RESULTS_JSON="$LOG_DIR/upstream-results.json"
UPSTREAM_REPORT_JSON="$LOG_DIR/upstream-report.json"
UPSTREAM_DRIVER_LOG="$LOG_DIR/upstream-driver.log"
UPSTREAM_PEER="grpc-http2-probe"
UPSTREAM_PEER_PIN="d1487957db6658bc532b72871775148229836627"

if [[ ! -f "$INTEROP_REPORT" ]]; then
  echo "Error: required interop reporter missing at $INTEROP_REPORT" >&2
  exit 1
fi
if [[ "$RUN_LOCAL" -eq 1 ]]; then
  if [[ "$RESULTS_JSON" == "$REPORT_JSON" ||
        -e "$RESULTS_JSON" || -L "$RESULTS_JSON" ||
        -e "$REPORT_JSON" || -L "$REPORT_JSON" ]]; then
    echo "Error: use distinct, fresh results and report paths for these probes" >&2
    exit 1
  fi
fi
if [[ "$RUN_UPSTREAM" -eq 1 ]]; then
  if [[ "$UPSTREAM_RESULTS_JSON" == "$UPSTREAM_REPORT_JSON" ||
        -e "$UPSTREAM_RESULTS_JSON" || -L "$UPSTREAM_RESULTS_JSON" ||
        -e "$UPSTREAM_REPORT_JSON" || -L "$UPSTREAM_REPORT_JSON" ||
        -e "$UPSTREAM_DIR" || -L "$UPSTREAM_DIR" ]]; then
    echo "Error: use a fresh log directory so upstream probe proof cannot be reused" >&2
    exit 1
  fi
fi

OVERALL_FAILED=0

if [[ "$RUN_LOCAL" -eq 1 ]]; then
  if [[ "$SKIP_BUILD" -ne 1 ]]; then
    echo "== building pbrs-grpc interop server and client =="
    cargo build --release -p pbrs-grpc --bin pbrs-grpc-interop-server --bin pbrs-grpc-interop-client
  fi

  KERNEL_SERVER="${GRPC_INTEROP_KERNEL_SERVER:-$ROOT/target/release/pbrs-grpc-interop-server}"
  if [[ ! -x "$KERNEL_SERVER" && -x "$ROOT/target/debug/pbrs-grpc-interop-server" ]]; then
    KERNEL_SERVER="$ROOT/target/debug/pbrs-grpc-interop-server"
  fi

  if [[ ! -x "$KERNEL_SERVER" ]]; then
    echo "Error: pbrs-grpc-interop-server binary not found at $KERNEL_SERVER" >&2
    exit 1
  fi

  KERNEL_CLIENT="${GRPC_INTEROP_KERNEL_CLIENT:-$ROOT/target/release/pbrs-grpc-interop-client}"
  if [[ ! -x "$KERNEL_CLIENT" && -x "$ROOT/target/debug/pbrs-grpc-interop-client" ]]; then
    KERNEL_CLIENT="$ROOT/target/debug/pbrs-grpc-interop-client"
  fi

  if [[ ! -x "$KERNEL_CLIENT" ]]; then
    echo "Error: pbrs-grpc-interop-client binary not found at $KERNEL_CLIENT" >&2
    exit 1
  fi
fi

find_free_port() {
  python3 -c 'import socket; s = socket.socket(); s.bind(("127.0.0.1", 0)); print(s.getsockname()[1]); s.close()'
}

if [[ "$RUN_LOCAL" -eq 1 ]]; then
  if [[ -z "$CLEARTEXT_PORT" ]]; then
    CLEARTEXT_PORT="$(find_free_port)"
  fi

  if [[ -z "$TLS_PORT" ]]; then
    TLS_PORT="$(find_free_port)"
    while [[ "$TLS_PORT" == "$CLEARTEXT_PORT" ]]; do
      TLS_PORT="$(find_free_port)"
    done
  fi
fi

TRACKED_PIDS=()

cleanup() {
  local exit_status=$?
  for pid in "${TRACKED_PIDS[@]:-}"; do
    if [[ -n "$pid" ]] && kill -0 "$pid" 2>/dev/null; then
      kill -TERM "$pid" 2>/dev/null || true
      for _ in {1..10}; do
        kill -0 "$pid" 2>/dev/null || break
        sleep 0.05
      done
      if kill -0 "$pid" 2>/dev/null; then
        kill -9 "$pid" 2>/dev/null || true
      fi
      wait "$pid" 2>/dev/null || true
    fi
  done
}
trap cleanup EXIT INT TERM

start_server() {
  local name="$1"
  local port="$2"
  local log_file="$3"
  shift 3
  local server_cmd=("$@")

  "${server_cmd[@]}" > "$log_file" 2>&1 &
  local pid=$!
  TRACKED_PIDS+=($pid)

  local deadline=$((SECONDS + 10))
  while (( SECONDS < deadline )); do
    if ! kill -0 "$pid" 2>/dev/null; then
      echo "FAIL: $name (pid $pid) died during startup" >&2
      if [[ -f "$log_file" ]]; then
        cat "$log_file" >&2
      fi
      return 1
    fi
    if python3 -c "import socket; s = socket.socket(); s.settimeout(0.2); s.connect(('$SERVER_HOST', $port)); s.close()" 2>/dev/null; then
      return 0
    fi
    sleep 0.05
  done
  echo "FAIL: $name (pid $pid) never listened on $port within 10s" >&2
  return 1
}

# Start native servers for the local phase. The upstream phase starts and stops
# its own native servers through the diagnostic driver.
if [[ "$RUN_LOCAL" -eq 1 ]]; then
  echo "== starting native pbrs-grpc TLS server on port $TLS_PORT =="
  start_server "pbrs-grpc TLS server" "$TLS_PORT" "$LOG_DIR/server-tls.log" \
    "$KERNEL_SERVER" --port "$TLS_PORT" --use_tls=true --tls_cert_file "$TLS_CERT_FILE" --tls_key_file "$TLS_KEY_FILE"

  echo "== starting native pbrs-grpc cleartext server on port $CLEARTEXT_PORT =="
  start_server "pbrs-grpc cleartext server" "$CLEARTEXT_PORT" "$LOG_DIR/server-cleartext.log" \
    "$KERNEL_SERVER" --port "$CLEARTEXT_PORT"
fi

# Python probe runner implementation
run_probe_python() {
  python3 - "$@" << 'EOF'
import os
import socket
import ssl
import struct
import subprocess
import sys
import time
from scripts.http2_probe_status import decode_first_status

mode = sys.argv[1]
host = sys.argv[2]
port = int(sys.argv[3])
client_bin = sys.argv[4] if len(sys.argv) > 4 else ""
ca_file = sys.argv[5] if len(sys.argv) > 5 else ""
cert_file = sys.argv[6] if len(sys.argv) > 6 else ""
key_file = sys.argv[7] if len(sys.argv) > 7 else ""

def h2_frame(type_, flags, stream_id, payload):
    length = len(payload)
    head = bytes([
        (length >> 16) & 0xff,
        (length >> 8) & 0xff,
        length & 0xff,
        type_,
        flags,
        (stream_id >> 24) & 0x7f,
        (stream_id >> 16) & 0xff,
        (stream_id >> 8) & 0xff,
        stream_id & 0xff,
    ])
    return head + payload

def recv_exact(sock, n):
    buf = bytearray()
    while len(buf) < n:
        chunk = sock.recv(n - len(buf))
        if not chunk:
            return None
        buf.extend(chunk)
    return bytes(buf)

def read_frame(sock, timeout=2.0):
    sock.settimeout(timeout)
    try:
        hdr = recv_exact(sock, 9)
        if not hdr:
            return None
        length = (hdr[0]<<16) | (hdr[1]<<8) | hdr[2]
        type_ = hdr[3]
        flags = hdr[4]
        stream_id = int.from_bytes(hdr[5:9], "big") & 0x7FFFFFFF
        payload = recv_exact(sock, length) if length > 0 else b""
        return type_, flags, stream_id, payload
    except socket.timeout:
        return None

def hpack_literal_new(name, value):
    buf = bytearray([0])
    name_b = name.encode("ascii")
    buf.append(len(name_b))
    buf.extend(name_b)
    val_b = value.encode("ascii")
    buf.append(len(val_b))
    buf.extend(val_b)
    return bytes(buf)

def run_tls_suite():
    print("--- Starting Server TLS Probes (server_tls_probe) ---")
    print(f"Target: {host}:{port}")

    # Sub-probe 1: ALPN negotiation (h2)
    print("\n[Sub-probe 1.1] ALPN h2 negotiation...")
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx.check_hostname = False
    ctx.verify_mode = ssl.CERT_NONE
    ctx.set_alpn_protocols(["h2"])
    s = socket.create_connection((host, port), timeout=5)
    ss = ctx.wrap_socket(s, server_hostname="localhost")
    negotiated_alpn = ss.selected_alpn_protocol()
    tls_ver = ss.version()
    cipher = ss.cipher()
    print(f"  TLS Version: {tls_ver}")
    print(f"  ALPN Selected: {negotiated_alpn}")
    print(f"  Cipher Suite: {cipher[0]} ({cipher[1]}, {cipher[2]} bits)")
    assert negotiated_alpn == "h2", f"Expected ALPN h2, got {negotiated_alpn}"
    assert tls_ver in ("TLSv1.2", "TLSv1.3"), f"Expected TLS 1.2 or 1.3, got {tls_ver}"
    ss.close()
    print("  PASS: ALPN h2 and TLS version successfully negotiated")

    # Sub-probe 2: Rejection of non-h2 ALPN
    print("\n[Sub-probe 1.2] Rejection of non-h2 ALPN (http/1.1)...")
    ctx_bad = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx_bad.check_hostname = False
    ctx_bad.verify_mode = ssl.CERT_NONE
    ctx_bad.set_alpn_protocols(["http/1.1"])
    s = socket.create_connection((host, port), timeout=5)
    rejected = False
    try:
        ss = ctx_bad.wrap_socket(s, server_hostname="localhost")
        ss.close()
    except (ssl.SSLError, ConnectionResetError, BrokenPipeError, socket.error) as e:
        rejected = True
        print(f"  PASS: Handshake correctly failed/rejected without h2 ALPN: {e}")
    assert rejected, "Server accepted TLS handshake without h2 in ALPN protocols"

    # Sub-probe 3: Certificate presentation and SAN verification
    print("\n[Sub-probe 1.3] Server certificate presentation...")
    ctx_cert = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
    ctx_cert.check_hostname = False
    ctx_cert.verify_mode = ssl.CERT_NONE
    s = socket.create_connection((host, port), timeout=5)
    ss = ctx_cert.wrap_socket(s, server_hostname="localhost")
    cert_der = ss.getpeercert(binary_form=True)
    assert cert_der is not None and len(cert_der) > 0, "Server did not present a certificate"
    print(f"  PASS: Certificate presented (DER length: {len(cert_der)} bytes)")
    ss.close()

    # Sub-probe 4: Live gRPC RPC over TLS
    print("\n[Sub-probe 1.4] Live gRPC empty_unary call over TLS...")
    cmd = [
        client_bin,
        f"--server_host={host}",
        f"--server_port={port}",
        "--use_tls=true",
        f"--tls_ca_file={ca_file}",
        "--server_host_override=localhost",
        "--test_case=empty_unary",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"Client stderr: {res.stderr}")
        print(f"Client stdout: {res.stdout}")
        raise RuntimeError(f"Live TLS gRPC client failed with exit code {res.returncode}")
    print(f"  PASS: Live TLS gRPC call succeeded ({res.stdout.strip()})")

    print("\n=== server_tls_probe PASSED ===")

def run_framing_suite():
    print("--- Starting Server Framing Probes (server_framing_probe) ---")
    print(f"Target: {host}:{port}")

    # Sub-probe 1: Preface and SETTINGS exchange
    print("\n[Sub-probe 2.1] HTTP/2 connection preface and SETTINGS exchange...")
    s = socket.create_connection((host, port), timeout=5)
    # Send client preface + empty SETTINGS
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    server_settings = None
    for _ in range(5):
        frame = read_frame(s)
        if not frame:
            break
        ftype, fflags, fstream, fpayload = frame
        if ftype == 4 and (fflags & 0x1) == 0:
            server_settings = frame
            # Acknowledge server settings
            s.sendall(h2_frame(4, 1, 0, b""))
            break
    assert server_settings is not None, "Server never sent SETTINGS frame after connection preface"
    print(f"  PASS: Connection preface accepted, server SETTINGS received (length {len(server_settings[3])}), ACK sent")
    s.close()

    # Sub-probe 2: Rapid reset stream cancellation flood (CVE-2023-44487 simulation)
    print("\n[Sub-probe 2.2] Rapid reset stream cancellation flood...")
    s = socket.create_connection((host, port), timeout=5)
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    f = read_frame(s)
    if f and f[0] == 4 and (f[1] & 0x1) == 0:
        s.sendall(h2_frame(4, 1, 0, b""))
    # Send rapid HEADERS + RST_STREAM across 32 streams
    headers_payload = bytes([0x83, 0x86, 0x84]) # :method POST, :scheme http, :path /
    rst_sent = 0
    for sid in range(1, 65, 2):
        try:
            s.sendall(h2_frame(1, 4, sid, headers_payload))
            s.sendall(h2_frame(3, 0, sid, struct.pack(">I", 8))) # RST_STREAM CANCEL (8)
            rst_sent += 1
        except (BrokenPipeError, ConnectionResetError, socket.error):
            print("  Server closed connection under rapid reset burst (mitigation active)")
            break
    time.sleep(0.1)
    try:
        s.close()
    except Exception:
        pass
    print(f"  PASS: Rapid reset flood handled safely ({rst_sent} reset streams dispatched)")

    # Sub-probe 3: Small DATA frames streaming and flow control
    print("\n[Sub-probe 2.3] Small DATA frames streaming and boundary handling...")
    s = socket.create_connection((host, port), timeout=5)
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    f = read_frame(s)
    if f and f[0] == 4 and (f[1] & 0x1) == 0:
        s.sendall(h2_frame(4, 1, 0, b""))
    s.sendall(h2_frame(1, 4, 1, headers_payload))
    frames_sent = 0
    for _ in range(24):
        try:
            s.sendall(h2_frame(0, 0, 1, b"X"))
            frames_sent += 1
        except (BrokenPipeError, ConnectionResetError, socket.error):
            break
    try:
        s.sendall(h2_frame(0, 1, 1, b"")) # END_STREAM
    except Exception:
        pass
    time.sleep(0.1)
    s.close()
    print(f"  PASS: Small DATA frames stream handled ({frames_sent} tiny frames sent)")

    # Sub-probe 4: Fragmented HEADERS with CONTINUATION and flood protection
    print("\n[Sub-probe 2.4] Fragmented HEADERS across CONTINUATION frames...")
    s = socket.create_connection((host, port), timeout=5)
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    f = read_frame(s)
    if f and f[0] == 4 and (f[1] & 0x1) == 0:
        s.sendall(h2_frame(4, 1, 0, b""))
    # Part 1: HEADERS without END_HEADERS (flags=0)
    s.sendall(h2_frame(1, 0, 1, bytes([0x83, 0x86]))) # :method POST, :scheme http
    # Part 2: CONTINUATION with END_HEADERS (flags=4)
    s.sendall(h2_frame(9, 4, 1, bytes([0x84]))) # :path /
    s.sendall(h2_frame(0, 1, 1, b"")) # END_STREAM
    time.sleep(0.1)
    # Part 3: CONTINUATION flood enforcement
    s.sendall(h2_frame(1, 0, 3, bytes([0x83, 0x86])))
    for _ in range(48):
        try:
            s.sendall(h2_frame(9, 0, 3, b""))
        except (BrokenPipeError, ConnectionResetError, socket.error):
            break
    time.sleep(0.1)
    try:
        s.close()
    except Exception:
        pass
    print("  PASS: Fragmented HEADERS and CONTINUATION flood handled safely")

    # Sub-probe 5: Bad headers and non-POST method rejection
    print("\n[Sub-probe 2.5] Bad headers, non-POST methods, and unsupported content-types...")
    # Test 5A: non-POST method (GET: 0x82) -> 405 Method Not Allowed
    s = socket.create_connection((host, port), timeout=5)
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    f = read_frame(s)
    if f and f[0] == 4 and (f[1] & 0x1) == 0:
        s.sendall(h2_frame(4, 1, 0, b""))
    s.sendall(h2_frame(1, 5, 1, bytes([0x82, 0x86, 0x84]))) # GET, END_HEADERS | END_STREAM
    got_status = None
    for _ in range(5):
        frame = read_frame(s)
        if not frame:
            break
        if frame[0] == 1 and frame[2] == 1:
            print(f"  GET response HPACK: {frame[3].hex()}")
            got_status = decode_first_status(frame)
            break
    assert got_status == 405, f"Expected HTTP 405 for GET, got {got_status!r}"
    s.close()
    print("  PASS: non-POST method returned HTTP 405 Method Not Allowed")

    # Test 5B: bad content-type (application/json) -> 415 Unsupported Media Type
    s = socket.create_connection((host, port), timeout=5)
    s.sendall(b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n" + h2_frame(4, 0, 0, b""))
    f = read_frame(s)
    if f and f[0] == 4 and (f[1] & 0x1) == 0:
        s.sendall(h2_frame(4, 1, 0, b""))
    block = bytearray([0x83, 0x86, 0x84])
    block.extend(hpack_literal_new("content-type", "application/json"))
    s.sendall(h2_frame(1, 5, 1, bytes(block)))
    got_415 = None
    for _ in range(5):
        frame = read_frame(s)
        if not frame:
            break
        if frame[0] == 1 and frame[2] == 1:
            print(f"  bad content-type response HPACK: {frame[3].hex()}")
            got_415 = decode_first_status(frame)
            break
    assert got_415 == 415, f"Expected HTTP 415 for JSON content-type, got {got_415!r}"
    s.close()
    print("  PASS: non-gRPC content-type returned HTTP 415 Unsupported Media Type")

    # Sub-probe 6: Post-probe server health check
    print("\n[Sub-probe 2.6] Post-probe live server health verification...")
    cmd = [
        client_bin,
        f"--server_host={host}",
        f"--server_port={port}",
        "--use_tls=false",
        "--test_case=empty_unary",
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        print(f"Client stderr: {res.stderr}")
        print(f"Client stdout: {res.stdout}")
        raise RuntimeError(f"Server health check failed after framing probes: {res.stderr}")
    print(f"  PASS: Server accept loop healthy and serving RPCs ({res.stdout.strip()})")

    print("\n=== server_framing_probe PASSED ===")

if mode == "tls":
    run_tls_suite()
elif mode == "framing":
    run_framing_suite()
else:
    print(f"Unknown mode: {mode}", file=sys.stderr)
    sys.exit(1)
EOF
}

if [[ "$RUN_LOCAL" -eq 1 ]]; then
echo "== running local server HTTP/2 probes (${#CASES[@]} cases) =="
PASSED_COUNT=0
FAILED_COUNT=0

for case in "${CASES[@]}"; do
  log_file="$LOG_DIR/${case}.log"
  probe_exit=0
  start_time=$(python3 -c 'import time; print(time.perf_counter())')

  case "$case" in
    server_tls_probe)
      echo "--> Running server_tls_probe against port $TLS_PORT (TLS) <--"
      if run_probe_python "tls" "$SERVER_HOST" "$TLS_PORT" "$KERNEL_CLIENT" "$TLS_CA_FILE" "$TLS_CERT_FILE" "$TLS_KEY_FILE" > "$log_file" 2>&1; then
        probe_exit=0
      else
        probe_exit=$?
      fi
      transport="http2_tls"
      ;;
    server_framing_probe)
      echo "--> Running server_framing_probe against port $CLEARTEXT_PORT (cleartext) <--"
      if run_probe_python "framing" "$SERVER_HOST" "$CLEARTEXT_PORT" "$KERNEL_CLIENT" > "$log_file" 2>&1; then
        probe_exit=0
      else
        probe_exit=$?
      fi
      transport="http2_cleartext"
      ;;
    *)
      echo "Unknown server probe case: $case" >&2
      probe_exit=1
      echo "Unknown server probe case: $case" > "$log_file"
      transport="http2_cleartext"
      ;;
  esac

  end_time=$(python3 -c 'import time; print(time.perf_counter())')
  dur_ms=$(python3 -c "print(round(($end_time - $start_time) * 1000, 2))")

  if [[ $probe_exit -eq 0 ]]; then
    echo "  ok   $case (${dur_ms}ms)"
    PASSED_COUNT=$((PASSED_COUNT + 1))
    status="passed"
  else
    echo "  FAIL $case (exit code $probe_exit, ${dur_ms}ms)"
    sed 's/^/       /' "$log_file"
    OVERALL_FAILED=1
    FAILED_COUNT=$((FAILED_COUNT + 1))
    status="failed"
  fi

  if ! python3 "$INTEROP_REPORT" record \
      --output "$RESULTS_JSON" \
      --case "$case" \
      --status "$status" \
      --duration-ms "$dur_ms" \
      --peer "local-native-server" \
      --direction "client_to_server" \
      --transport "$transport" \
      --suite "server_probe" \
      --profile "native" \
      --stdout-log "$log_file" \
      --stderr-log "$log_file" \
      --exit-code "$probe_exit" \
      --attempt-count 1 >/dev/null; then
    echo "FAIL: could not record $case in $RESULTS_JSON" >&2
    OVERALL_FAILED=1
  fi
done

echo ""
echo "=================================================="
echo "Server HTTP/2 probe summary: $PASSED_COUNT passed, $FAILED_COUNT failed"
echo "Logs saved to $LOG_DIR"
echo "=================================================="

echo "== validating local interop results =="
python3 "$INTEROP_REPORT" validate --results "$RESULTS_JSON" --suite server_probe --profile native --spec-adapter --require-matrix || OVERALL_FAILED=1

echo "== aggregating local interop results =="
python3 "$INTEROP_REPORT" aggregate --results "$RESULTS_JSON" --output "$REPORT_JSON" --suite server_probe --profile native --spec-adapter --require-matrix || OVERALL_FAILED=1
fi

# Map the upstream driver's summary.json to one |-separated row per probe mode:
#   mode|status|stdout_log|stderr_log|notes
# Exit 2 (or any driver/mapping failure) yields not_run/failed rows with the
# exact reason and repro steps -- an unavailable runner is never silent.
map_upstream_results() {
  python3 - "$@" << 'EOF'
import json
import sys

summary_path, driver_exit_raw, driver_log, upstream_dir, root, pin = sys.argv[1:7]
try:
    driver_exit = int(driver_exit_raw)
except ValueError:
    driver_exit = 2


def clean(value):
    return " ".join(str(value).split()).replace("|", "/")[:1500]


def go_pin():
    try:
        with open(root + "/tests/interop/go/go.mod", encoding="utf-8") as handle:
            for line in handle:
                parts = line.split()
                if len(parts) == 2 and parts[0] == "go":
                    return parts[1]
    except OSError:
        pass
    return "per tests/interop/go/go.mod"


reason = "driver exited %d" % driver_exit
try:
    with open(driver_log, encoding="utf-8") as handle:
        lines = [line.strip() for line in handle if line.strip()]
    for line in reversed(lines):
        if line.startswith("upstream Go server proof incomplete:"):
            reason = line.split("upstream Go server proof incomplete:", 1)[1]
            reason = reason.split("; logs:")[0].strip()
            break
except OSError:
    reason = "driver produced no log at %s" % driver_log

summary = None
summary_error = ""
if driver_exit in (0, 1):
    try:
        with open(summary_path, encoding="utf-8") as handle:
            summary = json.load(handle)
    except (OSError, ValueError) as exc:
        summary_error = str(exc)
        summary = None


def not_run_notes():
    return (
        "original Go probe did not run: %s; "
        "prereqs: Go %s, clean third_party/grpc@%s "
        "(tools/http2_interop, src/core/tsi/test_creds), warm cargo cache for the "
        "diagnostic offline locked build; repro: git init third_party/grpc && "
        "git -C third_party/grpc remote add origin https://github.com/grpc/grpc.git && "
        "git -C third_party/grpc fetch --depth 1 origin %s && "
        "git -C third_party/grpc checkout FETCH_HEAD && "
        "./scripts/grpc-http2-server-interop.sh --upstream-only; "
        "driver: %s" % (reason, go_pin(), pin, pin, driver_log)
    )


profiles = summary.get("profiles", {}) if isinstance(summary, dict) else {}
for mode in ("tls", "framing"):
    status = "failed"
    stdout_log = driver_log
    stderr_log = driver_log
    notes = ""
    profile = profiles.get(mode)
    if isinstance(profile, dict):
        rows = [row for row in profile.get("cases", []) if isinstance(row, dict)]
        decided = [row for row in rows if row.get("status") in ("passed", "failed", "not_run")]
        passed = sum(1 for row in decided if row.get("status") == "passed")
        status = "passed" if profile.get("qualified") is True else "failed"
        failures = [str(item) for item in profile.get("failures", [])]
        notes = (
            "original Go probe grpc/grpc@%s tools/http2_interop (%s): %d/%d subcases passed"
            % (pin, mode, passed, len(decided))
        )
        if failures:
            notes += "; failures: " + ", ".join(failures)
        notes += "; %s; probe sha256:%s; native sha256:%s git:%s dirty:%s" % (
            profile.get("go_version", "go version unrecorded"),
            profile.get("go_binary_sha256", "unrecorded"),
            profile.get("native_binary_sha256", "unrecorded"),
            profile.get("native_git_sha", "unrecorded"),
            profile.get("native_dirty", "unrecorded"),
        )
        stdout_log = profile.get("raw_log", driver_log)
        stderr_log = profile.get("server_log", driver_log)
        notes += "; raw: %s; server: %s" % (stdout_log, stderr_log)
    elif driver_exit in (0, 1):
        notes = (
            "upstream driver exited %d without a parseable summary (%s); see %s and %s"
            % (driver_exit, summary_error or ("missing " + summary_path), driver_log, upstream_dir)
        )
    else:
        status = "not_run"
        notes = not_run_notes()
    print("%s|%s|%s|%s|%s" % (mode, status, clean(stdout_log), clean(stderr_log), clean(notes)))
EOF
}

if [[ "$RUN_UPSTREAM" -eq 1 ]]; then
echo ""
echo "== running original upstream Go server probes =="
UP_PASSED_COUNT=0
UP_FAILED_COUNT=0
UP_NOTRUN_COUNT=0
upstream_exit=0
upstream_dur_ms=0
UPSTREAM_MAP="$LOG_DIR/upstream-map.tsv"

if [[ ! -f "$UPSTREAM_DRIVER" ]]; then
  echo "Error: required upstream probe driver missing at $UPSTREAM_DRIVER" >&2
  upstream_exit=1
  : > "$UPSTREAM_MAP"
else
  upstream_start=$(python3 -c 'import time; print(time.perf_counter())')
  if python3 "$UPSTREAM_DRIVER" --log-dir="$UPSTREAM_DIR" > "$UPSTREAM_DRIVER_LOG" 2>&1; then
    upstream_exit=0
  else
    upstream_exit=$?
  fi
  upstream_end=$(python3 -c 'import time; print(time.perf_counter())')
  upstream_dur_ms=$(python3 -c "print(round(($upstream_end - $upstream_start) * 1000, 2))")
  if ! map_upstream_results "$UPSTREAM_DIR/summary.json" "$upstream_exit" "$UPSTREAM_DRIVER_LOG" "$UPSTREAM_DIR" "$ROOT" "$UPSTREAM_PEER_PIN" > "$UPSTREAM_MAP" 2>"$LOG_DIR/upstream-map.err"; then
    echo "WARN: upstream result mapping failed; recording failed rows" >&2
    : > "$UPSTREAM_MAP"
  fi
fi

for case in "${CASES[@]}"; do
  case "$case" in
    server_tls_probe)
      mode="tls"
      transport="http2_tls"
      known=1
      ;;
    server_framing_probe)
      mode="framing"
      transport="http2_cleartext"
      known=1
      ;;
    *)
      mode=""
      transport="http2_cleartext"
      known=0
      ;;
  esac

  if [[ "$known" -eq 0 ]]; then
    status="failed"
    out_log="$UPSTREAM_DRIVER_LOG"
    err_log="$UPSTREAM_DRIVER_LOG"
    notes="Unknown server probe case: $case"
    echo "  FAIL $case (unknown server probe case)"
    UP_FAILED_COUNT=$((UP_FAILED_COUNT + 1))
    OVERALL_FAILED=1
  else
    line="$(grep "^${mode}|" "$UPSTREAM_MAP" 2>/dev/null || true)"
    if [[ -z "$line" ]]; then
      status="failed"
      out_log="$UPSTREAM_DRIVER_LOG"
      err_log="$UPSTREAM_DIR"
      notes="upstream result mapping produced no row for $mode; driver exit $upstream_exit; see $UPSTREAM_DRIVER_LOG and $UPSTREAM_DIR"
    else
      IFS='|' read -r _mode status out_log err_log notes <<< "$line"
    fi
    case "$status" in
      passed)
        echo "  ok   $case (upstream $mode)"
        UP_PASSED_COUNT=$((UP_PASSED_COUNT + 1))
        ;;
      not_run)
        echo "  SKIP $case (upstream $mode runner unavailable)"
        echo "       $notes"
        UP_NOTRUN_COUNT=$((UP_NOTRUN_COUNT + 1))
        OVERALL_FAILED=1
        ;;
      *)
        echo "  FAIL $case (upstream $mode)"
        echo "       $notes"
        UP_FAILED_COUNT=$((UP_FAILED_COUNT + 1))
        OVERALL_FAILED=1
        ;;
    esac
  fi

  if ! python3 "$INTEROP_REPORT" record \
      --output "$UPSTREAM_RESULTS_JSON" \
      --case "$case" \
      --status "$status" \
      --duration-ms "$upstream_dur_ms" \
      --peer "$UPSTREAM_PEER" \
      --direction "client_to_server" \
      --transport "$transport" \
      --suite "server_probe" \
      --profile "native" \
      --peer-pin "$UPSTREAM_PEER_PIN" \
      --stdout-log "$out_log" \
      --stderr-log "$err_log" \
      --exit-code "$upstream_exit" \
      --attempt-count 1 \
      --notes "$notes" >/dev/null; then
    echo "FAIL: could not record $case in $UPSTREAM_RESULTS_JSON" >&2
    OVERALL_FAILED=1
  fi
done

echo ""
echo "=================================================="
echo "Upstream Go probe summary: $UP_PASSED_COUNT passed, $UP_FAILED_COUNT failed, $UP_NOTRUN_COUNT not run"
echo "Logs saved to $LOG_DIR"
echo "=================================================="

echo "== validating upstream interop results =="
python3 "$INTEROP_REPORT" validate --results "$UPSTREAM_RESULTS_JSON" --suite server_probe --profile native --require-matrix || OVERALL_FAILED=1

echo "== aggregating upstream interop results =="
python3 "$INTEROP_REPORT" aggregate --results "$UPSTREAM_RESULTS_JSON" --output "$UPSTREAM_REPORT_JSON" --suite server_probe --profile native --require-matrix || OVERALL_FAILED=1
fi

if [[ $OVERALL_FAILED -ne 0 ]]; then
  exit 1
fi
exit 0
