"""Separate offline setup: retain seeds, accept only pinned registry graphs."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
import tomllib
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'driver-graph-amendment-001'
CARGO = Path('/workspace/pure-protobuf/work/toolchain/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/cargo')
BOUND = 2147483648


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def dump(path, data):
    Path(path).write_text(json.dumps(data, indent=2) + '\n')


def stamp(paths):
    return {str(p): sha(p) for p in paths}


def tuples(path):
    return sorted((p['name'], p['version'], p['source'], p['checksum'])
                  for p in tomllib.loads(Path(path).read_text())['package'] if 'source' in p)


def capture(label, argv, cwd, env, immutable):
    out = OUT / 'captures' / label
    out.mkdir(parents=True, exist_ok=False)
    before = stamp(immutable)
    record = {'argv': argv, 'cwd': str(cwd), 'environment': {k: env[k] for k in
              ['CARGO_HOME','RUSTUP_HOME','CARGO_NET_OFFLINE','CARGO_BUILD_JOBS','RUSTC','RUSTDOC']},
              'started_utc': datetime.now(timezone.utc).isoformat(), 'source_tool_before': before,
              'scope': 'offline metadata only; no compiler or semantic/performance result'}
    if (cwd / 'Cargo.lock').exists():
        shutil.copyfile(cwd / 'Cargo.lock', out / 'before.Cargo.lock')
    start = time.monotonic()
    samples = []
    child = None
    try:
        with (out / 'stdout').open('wb') as stdout, (out / 'stderr').open('wb') as stderr:
            child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr,
                                     start_new_session=True)
            record['pid'] = child.pid
            while True:
                v = os.statvfs('/workspace'); free = v.f_bavail * v.f_frsize
                samples.append({'elapsed': time.monotonic()-start, 'global_free': free})
                if free < BOUND or time.monotonic()-start > 30:
                    raise RuntimeError('metadata free-floor/30-second bound')
                try:
                    code = child.wait(timeout=0.2)
                    break
                except subprocess.TimeoutExpired:
                    pass
            record['exit'] = code
    finally:
        if child is not None and child.poll() is None:
            # Unreaped direct child owns this newly created process group.
            os.killpg(child.pid, 15)
            try:
                child.wait(timeout=2)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, 9); child.wait(timeout=2)
        record['source_tool_after'] = stamp(immutable)
        record['source_tool_unchanged'] = before == record['source_tool_after']
        record['finished_utc'] = datetime.now(timezone.utc).isoformat()
        record['samples'] = samples
        if (cwd / 'Cargo.lock').exists():
            shutil.copyfile(cwd / 'Cargo.lock', out / 'after.Cargo.lock')
        record['raw_sha256'] = {s: sha(out / s) for s in ['stdout','stderr']}
        dump(out / 'record.json', record)
    assert record['exit'] == 0 and record['source_tool_unchanged'], label
    return json.loads((out / 'stdout').read_text())


def main():
    assert sys.dont_write_bytecode
    OUT.mkdir(exist_ok=False)
    shutil.copyfile(__file__, OUT / 'executed-source.py')
    prepared = ROOT / 'prepared-inputs/prepared.json'
    original = json.loads(prepared.read_text())
    shutil.copyfile(prepared, OUT / 'original-prepared.json')
    shutil.copyfile(ROOT / 'prepared-inputs/preparation-seal.json', OUT / 'original-preparation-seal.json')
    env = os.environ.copy()
    env.update(CARGO_HOME='/workspace/pure-protobuf/work/toolchain/cargo',
               RUSTUP_HOME='/workspace/pure-protobuf/work/toolchain/rustup',
               CARGO_NET_OFFLINE='true', CARGO_BUILD_JOBS='1',
               RUSTC=str(CARGO.with_name('rustc')), RUSTDOC=str(CARGO.with_name('rustdoc')))
    graphs = {}
    summaries = {}
    for variant in ['base','cand']:
        driver = original['drivers'][variant]
        old = Path(driver['root']); new = OUT / 'drivers' / variant
        (new / 'src').mkdir(parents=True)
        for rel in ['Cargo.toml','Cargo.lock','src/main.rs']:
            shutil.copyfile(old / rel, new / rel)
        immutable = [prepared, old / 'Cargo.toml', old / 'Cargo.lock', old / 'src/main.rs',
                     new / 'Cargo.toml', new / 'src/main.rs', CARGO, CARGO.with_name('rustc'),
                     CARGO.with_name('rustdoc'), Path(__file__)]
        immutable.extend(Path(original['roots'][variant]) / p for p in original['source_sha256'][variant])
        seed = tuples(old / 'Cargo.lock'); assert len(seed) == 14
        shutil.copyfile(new / 'Cargo.lock', new / 'raw-seed.Cargo.lock')
        argv = [str(CARGO), 'metadata','--offline','--format-version=1','--manifest-path',str(new/'Cargo.toml')]
        metadata = capture(variant+'-normalize', argv, new, env, immutable)
        accepted = tuples(new / 'Cargo.lock')
        assert set(accepted) <= set(seed), 'new/drifted registry tuple'
        local = [p for p in tomllib.loads((new/'Cargo.lock').read_text())['package'] if 'source' not in p]
        assert {(p['name'],p['version']) for p in local} == {('pbrs','0.2.0'),('cg19-generator','0.0.0')}
        shutil.copyfile(new/'Cargo.lock', new/'accepted.Cargo.lock')
        before = sha(new/'Cargo.lock')
        locked = argv[:3] + ['--locked'] + argv[3:]
        metadata_locked = capture(variant+'-locked', locked, new, env, immutable)
        assert sha(new/'Cargo.lock') == before
        assert metadata['resolve'] == metadata_locked['resolve']
        root = original['roots'][variant]
        projection = json.dumps(metadata['resolve'],sort_keys=True).replace(root,'SOURCE_ROOT').replace(str(new),'DRIVER_ROOT')
        graphs[variant] = json.loads(projection)
        summaries[variant] = {'seed_registry_count':len(seed),'accepted_registry_count':len(accepted),
                              'registry_tuples':accepted,'accepted_lock_sha256':before,
                              'driver_root':str(new),'local_names':[p['name'] for p in local]}
    assert graphs['base'] == graphs['cand'], 'matched full resolved graph differs'
    dump(OUT/'summary.json',{'status':'pass','sources':original['source_pair'],
         'source_projection_inputs_unchanged':1027,'graph_equal_after_path_normalization':True,
         'drivers':summaries,'normalized_graph':graphs['base'],
         'scope':'explicit offline graph setup only; original locks/prepared inputs/failures untouched; bootstrap/native/performance unqualified'})
    print(json.dumps({'status':'pass','summary':str(OUT/'summary.json')}))


if __name__ == '__main__':
    main()
