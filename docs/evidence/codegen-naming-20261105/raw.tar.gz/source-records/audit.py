#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import statistics
import subprocess

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
source = json.loads((HERE / 'source-plan.json').read_text())
manifest = json.loads((HERE / 'results/manifest.json').read_text())
summary = json.loads((HERE / 'results/summary.json').read_text())
assert manifest['state'] == 'complete'
assert len(manifest['captures']) == 60
assert manifest['successful_processes'] == 120
audits = {}
for variant in ('baseline', 'candidate'):
    build = json.loads((HERE / f'{variant}-build.json').read_text())
    actual = {str(p.relative_to(HERE / variant)): sha(p) for p in sorted((HERE / variant).rglob('*')) if p.is_file()}
    assert actual == source['adapted_sha256'][variant] == build['source_sha256']
    assert sha(HERE / f'{variant}-bin') == build['binary_sha256'] == manifest['binary_sha256'][variant]
    driver = HERE / f'{variant}-harness'
    assert sha(driver / 'src/main.rs') == source['harness_sha256'] == build['harness_sha256']
    assert sha(driver / 'Cargo.toml') == build['manifest_sha256']
    assert sha(driver / 'Cargo.lock') == build['lock_sha256']
    audits[variant] = {'files': len(actual), 'source_and_build_bindings_match': True,
                       'binary_sha256': build['binary_sha256'], 'rustc': build['rustc']}
assert (HERE / 'baseline-harness/Cargo.lock').read_bytes() == (HERE / 'candidate-harness/Cargo.lock').read_bytes()
assert all(hashlib.sha256(subprocess.check_output(['git', 'show', f"{source['baseline_commit']}:{name}"], cwd=ROOT)).hexdigest() == digest
           for name, digest in source['original_sha256']['baseline'].items())
assert all(sha(ROOT / name) == digest for name, digest in source['original_sha256']['candidate'].items())
for name in ('baseline', 'candidate', 'prost'):
    assert sha(Path(manifest['binaries'][name])) == manifest['binary_sha256'][name]
controller = ROOT / 'work/all-benchmarks/measurement/codegen_compare_blocking.py'
helper = ROOT / 'work/all-benchmarks/measurement/canonical_codegen_blocking.py'
protoc = ROOT / 'work/toolchain/protoc/bin/protoc'
assert sha(controller) == manifest['controller_sha256']
assert sha(helper) == manifest['helper_sha256']
assert sha(protoc) == manifest['protoc_sha256']
assert sha(Path(manifest['time_executable'])) == manifest['time_executable_sha256']
rows = []
for row in summary:
    matching = [capture for capture in manifest['captures'] if capture['case'] == row['case']]
    values = {(capture['repeat'], capture['source'], capture['backend']): capture['phases'][row['operation']]['elapsed_ns'] for capture in matching}
    ratios = [values[index, 'after', 'pbrs'] / values[index, 'before', 'pbrs'] for index in range(5)]
    expected = {'median': statistics.median(ratios), 'range': [min(ratios), max(ratios)], 'pairs': ratios}
    assert expected == row['ratios']['after_over_before_pbrs']
    pbrs = [capture for capture in matching if capture['backend'] == 'pbrs']
    assert len({capture['output_tree_sha256'] for capture in pbrs}) == 1
    assert row['baseline_candidate_output_identical']
    rows.append({'case': row['case'], 'operation': row['operation'], 'new_over_old': expected,
                 'output_identical': True, 'generated_bytes': row['generated_bytes']['candidate']})
for capture in manifest['captures']:
    assert all(phase['exit_code'] == 0 and phase['elapsed_ns'] > 0 for phase in capture['phases'].values())
    if capture['backend'] == 'pbrs':
        assert capture['unchanged_mtimes_preserved'] == capture['rust_files']
report = {'scope': 'Local matched CLI generation diagnostic on a shared host; no consumer build, allocation, CPU or ranking claim.',
          'source_scope': '70 selected core-crate source inputs; before/after snapshots and compiler/build records, not filesystem read tracing.',
          'baseline_commit': source['baseline_commit'], 'builds': audits,
          'controller_and_tools_unchanged': True, 'source_matches_current_core': True,
          'successful_processes': 120, 'qualified': False, 'rows': rows,
          'observations': ['All normal-schema output hashes match and unchanged output mtimes are preserved.',
                           'All five-pair ranges cross one; no universal nonregression claim follows.',
                           'Largest median overhead is unchanged 100-message generation, 4.4 percent, with a wide paired range.',
                           'The archived Prost binary is only an optional fresh noise control; its retained metadata lacks a compiler version.',
                           'Companion-name string reuse remains a future optimization; production source was not edited for this diagnostic.']}
(HERE / 'audit.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'passed': True, 'rows': len(rows), 'source_files_per_build': 70, 'successful_processes': 120}))
