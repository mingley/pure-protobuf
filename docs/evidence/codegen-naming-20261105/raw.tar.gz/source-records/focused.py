#!/usr/bin/env python3
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import shutil
import statistics

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
OUT = HERE / 'focused-100-nine-pairs'
OUT.mkdir(exist_ok=False)
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
helper_path = ROOT / 'work/all-benchmarks/measurement/canonical_codegen_blocking.py'
spec = importlib.util.spec_from_file_location('canonical_codegen', helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
helper.ROOT = ROOT
original = json.loads((HERE / 'results/manifest.json').read_text())
binaries = {label: HERE / f'{label}-bin' for label in ('baseline', 'candidate')}
for label, binary in binaries.items():
    assert sha(binary) == original['binary_sha256'][label]
protoc = ROOT / 'work/toolchain/protoc/bin/protoc'
assert sha(helper_path) == original['helper_sha256']
assert sha(protoc) == original['protoc_sha256']
env = os.environ.copy()
env.update(PROTOC=str(protoc), PBRS_CODEGEN_TIME=original['time_executable'], LC_ALL='C')
for name in list(env):
    if name.startswith(('PURE_PROTOBUF_', 'SB09_PBRS_')):
        del env[name]
proto = HERE / 'results/corpora/100/consumer/proto'
names = original['corpora']['100']['names']
rng = random.Random(11052026)
plan = []
for repeat in range(9):
    labels = list(binaries)
    rng.shuffle(labels)
    plan.extend({'repeat': repeat, 'binary': label} for label in labels)
manifest = {'scope': 'Nine randomized paired local CLI wall-time controls for 100-message fresh and unchanged generation; shared host, no qualified performance claim.',
            'plan': plan, 'captures': [], 'state': 'running', 'qualified': False,
            'helper_sha256': sha(helper_path), 'controller_sha256': sha(Path(__file__)),
            'protoc_sha256': sha(protoc), 'time_executable': original['time_executable'],
            'time_executable_sha256': original['time_executable_sha256'],
            'binary_sha256': {label: sha(binary) for label, binary in binaries.items()}}

def save():
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

save()
for index, entry in enumerate(plan):
    generated = OUT / 'outputs' / f'{index:03d}'
    generated.mkdir(parents=True)
    command = [str(binaries[entry['binary']]), str(proto), str(generated), str(protoc), *names]
    phases = {}
    snapshots = {}
    for operation in ('generation', 'generation_unchanged'):
        phases[operation] = helper.timed_command(command, ROOT, env, OUT / 'logs' / f'{index:03d}' / operation, OUT, 900, 100)
        assert phases[operation]['exit_code'] == 0
        snapshots[operation] = {str(p.relative_to(generated)): {'sha256': sha(p), 'bytes': p.stat().st_size, 'mtime_ns': p.stat().st_mtime_ns}
                                for p in sorted(generated.rglob('*.rs'))}
    before, after = snapshots.values()
    assert before == after
    capture = dict(entry, phases=phases, generated=before,
                   output_tree_sha256=hashlib.sha256(json.dumps({k: (v['sha256'], v['bytes']) for k, v in before.items()}, sort_keys=True).encode()).hexdigest())
    assert capture['output_tree_sha256'] == next(c['output_tree_sha256'] for c in original['captures'] if c['case'] == '100' and c['binary'] == entry['binary'])
    representative = OUT / 'representative-generated' / entry['binary']
    if not representative.exists():
        shutil.copytree(generated, representative)
    shutil.rmtree(generated)
    manifest['captures'].append(capture)
    save()
rows = []
for operation in ('generation', 'generation_unchanged'):
    values = {(c['repeat'], c['binary']): c['phases'][operation]['elapsed_ns'] for c in manifest['captures']}
    ratios = [values[i, 'candidate'] / values[i, 'baseline'] for i in range(9)]
    rows.append({'operation': operation, 'candidate_over_baseline': {'median': statistics.median(ratios), 'range': [min(ratios), max(ratios)], 'pairs': ratios},
                 'elapsed_ns_medians': {label: statistics.median(values[i, label] for i in range(9)) for label in binaries},
                 'pairs_above_one': sum(ratio > 1 for ratio in ratios)})
assert len({c['output_tree_sha256'] for c in manifest['captures']}) == 1
for label, binary in binaries.items():
    assert sha(binary) == manifest['binary_sha256'][label]
manifest.update(state='complete', successful_processes=36, all_outputs_identical=True)
save()
(OUT / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
print(json.dumps(rows, indent=2))
