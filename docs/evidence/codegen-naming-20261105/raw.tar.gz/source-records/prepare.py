#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
BASE = '1c6ec8cacd547cce8c3a8e335320b49d34de40b4'
ROOTS = ['src', 'Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml',
         'rustfmt.toml', 'vendor/google/conformance_fds.bin']
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '--', *ROOTS], cwd=ROOT, text=True).splitlines()
base = {name: subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT) for name in paths}
current = {name: (ROOT / name).read_bytes() for name in paths}
harness = ROOT / 'work/benchmark-followup/codegen-selected-release/src/main.rs'
sha = lambda data: hashlib.sha256(data).hexdigest()
report = {'baseline_commit': BASE,
          'final_head_at_snapshot': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
          'scope': 'Selected full core-crate source snapshots; baseline from Git, candidate from current source. Runtime source changes are included, not only naming changes.',
          'manifest_transformation': 'Replace workspace membership with root-only workspace; preserve package, dependencies, features and workspace lints.',
          'harness_source_path': str(harness), 'harness_sha256': sha(harness.read_bytes()),
          'original_sha256': {}, 'adapted_sha256': {},
          'changed_original_files': [name for name in paths if base[name] != current[name]]}
for variant, source in [('baseline', base), ('candidate', current)]:
    folder = HERE / variant
    assert not folder.exists(), folder
    report['original_sha256'][variant] = {name: sha(data) for name, data in source.items()}
    adapted = dict(source)
    manifest = source['Cargo.toml'].decode()
    adapted['Cargo.toml'] = ('[workspace]\nresolver = "2"\n\n' + manifest[manifest.index('[package]'):]).encode()
    for name, data in adapted.items():
        destination = folder / name
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
    report['adapted_sha256'][variant] = {name: sha(data) for name, data in adapted.items()}
    driver = HERE / f'{variant}-harness'
    (driver / 'src').mkdir(parents=True)
    (driver / 'src/main.rs').write_bytes(harness.read_bytes())
    (driver / 'Cargo.toml').write_text(f'''[workspace]
[package]
name = "pbrs-naming-codegen-diagnostic"
version = "0.0.0"
edition = "2024"
[dependencies]
pbrs = {{ path = "../{variant}", default-features = false, features = ["codegen"] }}
[profile.release]
opt-level = 3
debug = 0
codegen-units = 1
lto = "thin"
''')
(HERE / 'source-plan.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'files': len(paths), 'changed_files': report['changed_original_files']}))
