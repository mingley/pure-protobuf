import datetime
import json
import os
import pathlib
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[2]
name, *argv = sys.argv[1:]
prefix = root / 'work' / 'tc30b2a' / name

def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()

record = {
    'schema': 'tc30b2a-command-v1',
    'name': name,
    'argv': argv,
    'cwd': str(root),
    'source_before': git('rev-parse', 'HEAD'),
    'tracked_changes_before': git('status', '--porcelain'),
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'environment': {key: os.environ.get(key) for key in ['CARGO_BUILD_JOBS', 'CARGO_TARGET_DIR', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG', 'RUSTDOCFLAGS']},
    'scope': 'correctness only; elapsed time is not comparative performance evidence',
}
with prefix.with_suffix('.log').open('wb') as log:
    result = subprocess.run(argv, cwd=root, stdout=log, stderr=subprocess.STDOUT).returncode
record.update(exit=result, finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), source_after=git('rev-parse', 'HEAD'), tracked_changes_after=git('status', '--porcelain'))
prefix.with_suffix('.json').write_text(json.dumps(record, indent=2) + '\n')
prefix.with_suffix('.exit').write_text(str(result) + '\n')
print(prefix.with_suffix('.log').read_text())
sys.exit(result)
