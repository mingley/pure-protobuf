#!/usr/bin/env python3
"""Functional N/2N input checks; child timings are not benchmark evidence."""
import argparse, datetime, hashlib, json, os
from pathlib import Path
import re, subprocess, sys

ROOT=Path(__file__).resolve().parents[2]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2)+'\n')
def marker(text,name):
 rows=[json.loads(line[len(name):]) for line in text.splitlines() if line.startswith(name)]
 assert len(rows)==1,(name,len(rows))
 return rows[0]

def main():
 parser=argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--binary',type=Path,required=True)
 parser.add_argument('--build-record',type=Path,required=True)
 parser.add_argument('--out',type=Path,required=True)
 args=parser.parse_args();binary=args.binary.resolve();out=args.out.resolve()
 assert not out.exists(),'preserve previous proof attempts'
 out.mkdir(parents=True)
 build=json.loads(args.build_record.read_text())
 assert build['exit_code']==0 and build['source_inputs_unchanged']
 inputs=build['inputs_sha256']
 assert all(sha(ROOT/path)==digest for path,digest in inputs.items()),'source differs from successful build'
 build_log=args.build_record.with_suffix('.log')
 assert sha(build_log)==build['log_sha256'],'build log changed'
 artifacts=[]
 for line in build_log.read_text().splitlines():
  try: item=json.loads(line)
  except json.JSONDecodeError: continue
  if item.get('reason')=='compiler-artifact' and item.get('executable')==str(binary): artifacts.append(item)
 assert len(artifacts)==1,('missing/duplicate current Cargo executable',len(artifacts))
 artifact=artifacts[0]
 assert artifact['target']['name']=='devloop' and artifact['target']['kind']==['bin']
 assert artifact['profile']['test'] is False and artifact['profile']['opt_level']=='0'
 assert artifact['profile']['debug_assertions'] is True
 inventory=subprocess.run([str(binary),'list'],text=True,capture_output=True,check=True)
 (out/'inventory.stdout.log').write_text(inventory.stdout)
 cells=[line.split()[0] for line in inventory.stdout.splitlines()
        if re.match(r'^rpc\.(adoption|tonic_transport)\.[a-z_]+\.maps\.n(8|64|512)\.(unary|server_stream) ',line)]
 assert len(cells)==48 and len(set(cells))==48,('map inventory',len(cells))
 profiles={'adoption':['native_pbrs','native_prost','tonic_pbrs','tonic_prost'],
           'tonic_transport':['reference_reference','native_client_reference_server','reference_client_native_server','native_native']}
 expected={f'rpc.{stack}.{profile}.maps.n{n}.{shape}'
           for stack,stacks in profiles.items() for profile in stacks for n in [8,64,512]
           for shape in ['unary','server_stream']}
 assert set(cells)==expected,('missing/extra map profiles',expected-set(cells),set(cells)-expected)
 result={'schema':'pbrs.rpc-input-functional-proof.v1','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
         'binary':str(binary),'binary_sha256':sha(binary),'build_record':str(args.build_record),'cargo_artifact':{k:artifact[k] for k in ['package_id','target','profile','features','fresh']},
         'build_record_sha256':sha(args.build_record),'inputs_sha256':inputs,'runner_sha256':sha(Path(__file__)),
         'measurement_scope':'functional identity/length/oracle checks only; no timing ranking or instruction claim',
         'cells':cells,'commands':[],'status':'running'}
 write(out/'report.json',result)
 identities={};counts={}
 try:
  for cell in cells:
   n=int(cell.split('.')[4][1:]);stack=cell.split('.')[1]
   for repeat in range(2):
    pair=[]
    for iters in [1,2]:
     command=[str(binary),'run-cell',cell,'--iters',str(iters),'--warmup','0','--prepare-iters','2']
     proc=subprocess.run(command,cwd=ROOT,text=True,capture_output=True)
     stem=f'{cell}.r{repeat}.n{iters}';stdout=out/(stem+'.stdout.log');stderr=out/(stem+'.stderr.log')
     stdout.write_text(proc.stdout);stderr.write_text(proc.stderr)
     row={'command':command,'exit_code':proc.returncode,'stdout':stdout.name,'stdout_sha256':sha(stdout),
          'stderr':stderr.name,'stderr_sha256':sha(stderr)}
     result['commands'].append(row)
     assert proc.returncode==0,(cell,repeat,iters,proc.stderr[-1500:])
     child=marker(proc.stderr,'__CHILD__ ');network=marker(proc.stderr,'__QUALIFICATION__ ')
     assert child['cell']==cell and child['iters']==iters
     assert isinstance(child['input_wire_bytes'],int) and child['input_wire_bytes']>0
     assert re.fullmatch('fnv1a64:[0-9a-f]{16}',child['input_wire_fingerprint'])
     identity=(child['input_wire_fingerprint'],child['input_wire_bytes'])
     assert (network['input_wire_fingerprint'],network['input_wire_bytes'])==identity
     assert network['input_fingerprint_scope']=='common prepared wire; RPC map entry order may vary'
     assert network['request_bytes']==identity[1]
     if stack=='tonic_transport':
      assert network['id']==cell and network['native_request_bytes']==identity[1]
      assert network['response_bytes_per_message']==identity[1]
      assert network['request_read_checksum']==network['response_read_checksum']
      assert network['responses']==(4 if cell.endswith('.server_stream') else 1)
      assert network['full_decoded_equality'] and network['equal_wire_work'] and network['accepted_tcp_nodelay']
     else:
      assert network['response_bytes']==identity[1] and network['stream_replies']==4
     assert identities.setdefault(n,identity)==identity,('cross-profile/shape input drift',cell)
     pair.append(identity)
     row.update(input_wire_fingerprint=identity[0],input_wire_bytes=identity[1])
    assert pair[0]==pair[1],('N/2N input drift',cell,repeat)
   counts[cell]=4
  assert len(counts)==48 and len(result['commands'])==192
  assert sha(binary)==result['binary_sha256'],'binary changed during proof'
  assert all(sha(ROOT/path)==digest for path,digest in inputs.items()),'source changed during proof'
  result.update(status='passed',source_inputs_unchanged=True,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                checked_cells=len(counts),successful_children=len(result['commands']),
                input_identities={str(n):{'fingerprint':v[0],'bytes':v[1]} for n,v in identities.items()})
  write(out/'report.json',result)
  print(json.dumps({k:v for k,v in result.items() if k not in ['inputs_sha256','commands','cells']},indent=2))
  return 0
 except Exception as error:
  result.update(status='failed',error=str(error),finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
  write(out/'report.json',result)
  raise
if __name__=='__main__': raise SystemExit(main())
