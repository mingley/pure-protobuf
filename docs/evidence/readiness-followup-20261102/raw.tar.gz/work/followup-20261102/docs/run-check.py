#!/usr/bin/env python3
"""Record one bounded local check with selected input hashes and its real exit."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = next(path for path in Path(__file__).resolve().parents if (path / '.git').exists())
OUT = ROOT / 'work/followup-20261102/qa'
INPUT_ROOTS = [
    'Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml', 'rustfmt.toml', '.cargo',
    'src', 'pbrs-grpc', 'protobuf-tonic', 'examples', 'tests', 'bench/devloop',
    'scripts', 'fuzz', 'vendor/google/conformance_fds.bin',
]
FLOOR = 750 * 1024 * 1024


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    paths = subprocess.check_output(
        ['git', 'ls-files', '--cached', '--others', '--exclude-standard', '-z', '--', *INPUT_ROOTS],
        cwd=ROOT,
    ).decode().split('\0')
    return {name: sha(ROOT / name) for name in sorted(set(paths))
            if name and (ROOT / name).is_file() and not (ROOT / name).is_symlink()}


def main():
    label, *command = sys.argv[1:]
    if command[:1] == ['--']:
        command.pop(0)
    assert command and label and all(c.isalnum() or c in '-_' for c in label)
    OUT.mkdir(parents=True, exist_ok=True)
    log_path = OUT / (label + '.log')
    report_path = OUT / (label + '.json')
    assert not log_path.exists() and not report_path.exists(), 'preserve earlier attempts'
    env = os.environ.copy()
    env.update(
        CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
        CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='1',
        CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0',
    )
    env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + str(ROOT / 'work/toolchain/protoc/bin') + ':' + env['PATH']
    rustc = ['rustc']
    if command[0] == 'cargo' and len(command) > 1 and command[1].startswith('+'):
        rustc.append(command[1])
    elif command[:2] == ['rustup', 'run']:
        rustc.append('+' + command[2])
    rustc.append('-Vv')
    before = snapshot()
    report = {
        'schema': 'pbrs.readiness-check.v1', 'label': label,
        'base_commit': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'command': command, 'input_roots': INPUT_ROOTS, 'inputs_sha256': before,
        'source_scope': 'selected tracked and untracked compiler/test inputs; not a filesystem read trace',
        'rustc': subprocess.check_output(rustc, cwd=ROOT, env=env, text=True),
        'validation_flags': {key: env[key] for key in ('MIRIFLAGS', 'RUSTDOCFLAGS') if key in env},
        'started_utc': datetime.now(timezone.utc).isoformat(),
        'free_before': shutil.disk_usage(ROOT).free, 'disk_floor_bytes': FLOOR,
        'disk_guard': False,
    }
    start = time.monotonic()
    with log_path.open('w') as log:
        process = subprocess.Popen(command, cwd=ROOT, env=env,
                                   stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            if shutil.disk_usage(ROOT).free < FLOOR:
                report['disk_guard'] = True
                os.killpg(process.pid, signal.SIGTERM)
                try:
                    process.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait()
                break
            time.sleep(0.2)
    after = snapshot()
    report.update(
        exit_code=99 if report['disk_guard'] else process.returncode,
        process_returncode=process.returncode, elapsed_seconds=time.monotonic() - start,
        finished_utc=datetime.now(timezone.utc).isoformat(), free_after=shutil.disk_usage(ROOT).free,
        source_inputs_unchanged=before == after, log_sha256=sha(log_path), log=log_path.name,
    )
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: v for k, v in report.items() if k != 'inputs_sha256'}, indent=2))
    print('\n'.join(log_path.read_text().splitlines()[-18:]))
    return report['exit_code'] or (0 if report['source_inputs_unchanged'] else 2)


if __name__ == '__main__':
    raise SystemExit(main())
