#!/usr/bin/env python3
"""Freeze selected readiness records after the coordinator approves final labels."""
import argparse
from datetime import datetime, timezone
import gzip
import hashlib
import io
import json
from pathlib import Path
import re
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
ROOT = next(path for path in HERE.parents if (path / '.git').exists())
BASE = 'a35701582fb9e6964c855386b0d9c991c50345ba'
WORK = ROOT / 'work/followup-20261102'
OUT = HERE / 'capsule'
SUFFIXES = {'.json', '.log', '.md', '.patch', '.py', '.rs', '.sh', '.jsonl'}
BENCH_REPORTS = {'devloop-final-build.json', 'devloop-final-tests.json', 'adoption-final-tests.json'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def add(files, path):
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    assert len(data) < 8 * 1024 * 1024, ('proof file too large', str(path))
    name = str(path.relative_to(ROOT))
    legacy = {'work/workspace-partitions.py', 'work/readiness-qa-20261030/partitions-coverage.json'}
    assert (name.startswith('work/followup-20261102/') or name in legacy) and '..' not in path.relative_to(ROOT).parts
    files[name] = data


def collect():
    files = {}
    for path in sorted(WORK.iterdir()):
        if path.is_file() and path.suffix in SUFFIXES:
            add(files, path)
    for directory in ('descriptor', 'i686', 'qa', 'chunk-screen'):
        folder = WORK / directory
        if not folder.exists():
            continue
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in SUFFIXES | {'.bin'}:
                if path.name.startswith('runner-probe') or path.name == 'apt-update.log':
                    continue
                add(files, path)
    for folder in sorted(WORK.glob('rpc-input*children*')):
        if folder.is_dir():
            for path in sorted(folder.iterdir()):
                if path.is_file() and path.suffix in {'.json', '.log'}:
                    add(files, path)
    # Performance investigations remain diagnostic; never traverse a copied
    # source tree, target cache, toolchain or binary directory automatically.
    folder = WORK / 'performance'
    if folder.exists():
        for path in sorted(folder.iterdir()):
            if path.is_file() and path.suffix in SUFFIXES | {'.s', '.ll'}:
                add(files, path)
    for name in ('run-check.py', 'capture.py', 'check.py'):
        add(files, HERE / name)
    for name in ('check-controls.py', 'check-controls.json'):
        if (HERE / name).exists():
            add(files, HERE / name)
    for path in (*sorted(HERE.glob('workspace*part*.py')), ROOT / 'work/workspace-partitions.py',
                 ROOT / 'work/readiness-qa-20261030/partitions-coverage.json'):
        if path.exists():
            add(files, path)
    return files


def approved_reports(files, selections, workspace_report='work/followup-20261102/qa/native-partitions-coverage.json'):
    inputs, rows = {}, []
    for selection in selections:
        display, name = selection.split('=', 1)
        assert display and not any(c in display for c in '|\n\r')
        path = Path(name)
        assert not path.is_absolute() and '..' not in path.parts
        assert name.startswith('work/followup-20261102/') and name.endswith('.json')
        report = json.loads(files[name])
        declared_inputs = report.get('inputs_sha256')
        if name == 'work/followup-20261102/i686/miri-x86_64-integrated-summary.json':
            declared_inputs = report['source_inputs_sha256']
        elif name.startswith('work/followup-20261102/i686/'):
            declared_inputs = report['source_before']
            assert report['inputs_unchanged'] is True and report['source_after'] == declared_inputs
        else:
            assert report['source_inputs_unchanged'] is True
        assert declared_inputs
        logs = []
        if report.get('schema') == 'pbrs.readiness-check.v1':
            kind = 'readiness-check'
            assert name.startswith('work/followup-20261102/qa/')
            assert report['exit_code'] == report['process_returncode'] == 0
            assert report['disk_guard'] is False and report['command'] and report['rustc']
            log = str(path.with_suffix('.log'))
            assert report['log'] == Path(log).name and sha(files[log]) == report['log_sha256']
            logs.append(log)
        elif path.parent == Path('work/followup-20261102') and path.name in BENCH_REPORTS:
            kind = 'benchmark-check'
            assert report['exit_code'] == 0 and report['command'] and report['rustc']
            log = str(path.with_suffix('.log'))
            assert sha(files[log]) == report['log_sha256']
            logs.append(log)
        elif name == 'work/followup-20261102/rpc-python-final.json':
            kind = 'python-contracts'
            assert report['schema'] == 'pbrs.benchmark-python-contracts.v1' and len(report['results']) == 2
            for result in report['results']:
                assert result['exit_code'] == 0 and result['command']
                assert '/' not in result['log'] and '..' not in Path(result['log']).parts
                log = 'work/followup-20261102/' + result['log']
                assert sha(files[log]) == result['log_sha256']
                logs.append(log)
        elif name == 'work/followup-20261102/i686/miri-x86_64-integrated-summary.json':
            kind = 'core-miri-summary'
            assert report['passed'] == 16 and report['failed'] == report['ignored'] == report['measured'] == 0
            assert len(report['reports']) == 2
            for row in report['reports']:
                child = 'work/followup-20261102/i686/' + row['label'] + '.json'
                log = str(Path(child).with_suffix('.log'))
                value = json.loads(files[child])
                assert sha(files[child]) == row['report_sha256']
                assert sha(files[log]) == row['log_sha256'] == value['log_sha256']
                assert value['exit_code'] == 0 and value['inputs_unchanged'] is True
                assert value['source_before'] == value['source_after'] == declared_inputs
                logs.append(log)
        elif name.startswith('work/followup-20261102/i686/'):
            kind = 'target-check'
            assert report['exit_code'] == 0 and report['command'] and report['rustc']
            assert report['execution'] and report['source_commit']
            log = str(path.with_suffix('.log'))
            assert sha(files[log]) == report['log_sha256']
            logs.append(log)
        else:
            raise AssertionError('unsupported final report format: ' + name)
        for source, digest in declared_inputs.items():
            rel = Path(source)
            assert not rel.is_absolute() and '..' not in rel.parts
            file = ROOT / rel
            assert file.is_file() and not file.is_symlink(), source
            assert sha(file.read_bytes()) == digest, ('final source changed', name, source)
            assert source not in inputs or inputs[source] == digest, ('conflicting final inputs', source)
            inputs[source] = digest
        data = b'\n'.join(files[log] for log in logs)
        results = re.findall(rb'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', data)
        assert all(failed == b'0' for _, failed, _ in results)
        status = 'Passed'
        if results:
            status = str(sum(int(passed) for passed, _, _ in results)) + ' Rust tests passed'
            ignored = sum(int(ignored) for _, _, ignored in results)
            if ignored:
                status += '; ' + str(ignored) + ' ignored'
        if not results:
            python = re.findall(rb'Ran (\d+) tests? in ', data)
            if python:
                status = str(sum(map(int, python))) + ' Python checks passed'
        if path.stem.startswith('native-partitions'):
            coverage = json.loads(files[workspace_report])
            assert coverage['status'] == 'passed'
            status = (str(coverage['native_passed']) + ' native tests across ' + str(coverage['native_targets'])
                      + ' targets; ' + str(coverage['doctest_passed']) + ' doctests; '
                      + str(coverage['native_ignored'] + coverage['doctest_ignored']) + ' ignored')
        rows.append({'display': display, 'report': name, 'format': kind, 'result': status})
    assert rows and len({row['report'] for row in rows}) == len(rows)
    return inputs, rows


def snapshot(files, inputs):
    overlays = {}
    for path, digest in sorted(inputs.items()):
        proc = subprocess.run(['git', 'show', BASE + ':' + path], cwd=ROOT, capture_output=True)
        base = proc.stdout if proc.returncode == 0 else None
        if base is None or sha(base) != digest:
            name = 'source-overlay/' + path
            data = (ROOT / path).read_bytes()
            assert sha(data) == digest
            files[name] = data
            overlays[path] = {'archive_path': name, 'sha256': digest,
                              'base_sha256': sha(base) if base is not None else None}
    files['source-inputs.json'] = (json.dumps({
        'base_commit': BASE, 'inputs_sha256': inputs, 'overlays': overlays,
        'scope': 'selected final compiler/test inputs; not a complete filesystem-read trace',
    }, indent=2) + '\n').encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--finalize', action='store_true')
    parser.add_argument('--final-report', action='append', default=[], metavar='DISPLAY=WORK_PATH')
    parser.add_argument('--scheduler-scope', type=Path, help='approved plain Markdown paragraph naming scheduler outcome')
    parser.add_argument('--rpc-report', default='work/followup-20261102/rpc-input-children/report.json',
                        help='explicit functional child proof; earlier proof files remain retained')
    parser.add_argument('--workspace-report', default='work/followup-20261102/qa/native-partitions-coverage.json',
                        help='explicit completed partition union; interrupted attempts remain retained')
    args = parser.parse_args()
    if not args.finalize:
        raise SystemExit('Prepared only. Coordinator must approve final report labels and scheduler outcome before --finalize.')
    assert args.final_report and args.scheduler_scope and args.scheduler_scope.is_file()
    assert not OUT.exists(), 'preserve previous frozen packet; use a new output path for a later attempt'
    files = collect()
    assert args.rpc_report in files
    inputs, rows = approved_reports(files, args.final_report, args.workspace_report)
    rpc = json.loads(files[args.rpc_report])
    assert rpc['status'] == 'passed' and rpc['source_inputs_unchanged'] is True
    for path, digest in rpc['inputs_sha256'].items():
        rel = Path(path)
        assert not rel.is_absolute() and '..' not in rel.parts
        assert (ROOT / rel).is_file() and not (ROOT / rel).is_symlink()
        assert path not in inputs or inputs[path] == digest, ('functional RPC source differs', path)
        assert sha((ROOT / path).read_bytes()) == digest, ('functional RPC source changed', path)
        inputs[path] = digest
    native = json.loads(files[args.workspace_report])
    assert native['schema'] in ('pbrs.workspace-partitions.v2', 'pbrs.workspace-partitions-resume.v1') and native['status'] == 'passed'
    snapshot(files, inputs)
    buffer = io.BytesIO()
    with gzip.GzipFile(fileobj=buffer, mode='wb', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as archive:
            for path, data in sorted(files.items()):
                item = tarfile.TarInfo(path)
                item.size, item.mode = len(data), 0o644
                archive.addfile(item, io.BytesIO(data))
    raw = buffer.getvalue()
    manifest = {
        'schema': 'pbrs.readiness-followup-capsule.v1', 'base_commit': BASE,
        'captured_utc': datetime.now(timezone.utc).isoformat(),
        'capture_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
        'qualified': False, 'performance_ranking_claim': False,
        'final_reports': rows, 'functional_rpc_report': args.rpc_report,
        'workspace_report': args.workspace_report, 'archive_sha256': sha(raw),
        'files': {name: {'bytes': len(data), 'sha256': sha(data)} for name, data in sorted(files.items())},
        'limits': [
            'Source-bound selected local checks only; no production qualification or CPU ranking claim.',
            'Earlier reports bind earlier overlays; only named final reports bind final selected inputs.',
            'Local i686 execution uses QEMU; strict Miri interprets selected i686 and x86_64 cases.',
            'No executable/cache/sysroot/tool binaries, dependency mirror, filesystem read trace or independent attestation.',
            'Debug RPC child timings and counters are functional diagnostics, not comparative performance measurements.',
        ],
    }
    table = ['| Check | Result | Report |', '|---|---|---|']
    table += [f"| {row['display']} | {row['result']} | `{Path(row['report']).stem}` |" for row in rows]
    template = (HERE / 'README.in.md').read_text()
    assert template.count('@@FINAL_CHECKS@@') == template.count('@@SCHEDULER_SCOPE@@') == 1
    readme = template.replace('@@FINAL_CHECKS@@', '\n'.join(table))
    readme = readme.replace('@@SCHEDULER_SCOPE@@', args.scheduler_scope.read_text().strip())
    OUT.mkdir()
    (OUT / 'README.md').write_text(readme)
    (OUT / 'check.py').write_bytes((HERE / 'check.py').read_bytes())
    (OUT / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    (OUT / 'raw.tar.gz').write_bytes(raw)
    print(json.dumps({'out': str(OUT), 'members': len(files), 'final_inputs': len(inputs),
                      'final_reports': len(rows), 'archive_bytes': len(raw), 'archive_sha256': sha(raw)}))


if __name__ == '__main__':
    main()
