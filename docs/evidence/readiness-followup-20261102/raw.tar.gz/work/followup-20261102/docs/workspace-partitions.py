#!/usr/bin/env python3
"""Execute every current workspace test target in bounded Cargo partitions."""
import argparse
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = next(p for p in Path(__file__).resolve().parents if (p / '.git').exists())
OUT = ROOT / 'work/followup-20261102/qa'


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


CHECK = module('partition_check', ROOT / 'work/followup-20261102/docs/run-check.py')
OLD = module('partition_parsers', ROOT / 'work/workspace-partitions.py')
BASE = ['cargo', 'test', '--workspace', '--all-features', '--locked']
ENV = os.environ.copy()
ENV.update(CARGO_HOME=str(ROOT/'work/cargo'), RUSTUP_HOME=str(ROOT/'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT/'target'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH'] = str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
ALLOWED = [ROOT/'target/integration-consumers', ROOT/'target/caller-rustls']


def write(name, value):
    (OUT/name).write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def key(package, target):
    return package+'::'+target['kind'][0]+'::'+target['name']


def plan():
    command = ['cargo', 'metadata', '--no-deps', '--all-features', '--locked', '--format-version=1']
    metadata = json.loads(subprocess.check_output(command, cwd=ROOT, env=ENV, text=True))
    members = set(metadata['workspace_members'])
    registry, docs = {}, {}
    for package in metadata['packages']:
        if package['id'] not in members:
            continue
        for target in package['targets']:
            if target['kind'] == ['lib'] and target['doctest']:
                assert target['name'] not in docs, 'ambiguous doctest library name'
                docs[target['name']] = package['id']
            if target['kind'] not in (['lib'], ['bin'], ['test']) or not target['test']:
                continue
            assert set(target.get('required-features', [])) <= set(package['features'])
            identity = key(package['id'], target)
            assert identity not in registry
            registry[identity] = {'package_id': package['id'], 'target': target,
                                  'expected_features': sorted(package['features'])}
    assert registry and docs
    groups = [['--lib'], ['--bins']] + [['--test', name] for name in sorted(
        {r['target']['name'] for r in registry.values() if r['target']['kind'] == ['test']})]
    prior = json.loads((ROOT/'work/readiness-qa-20261030/partitions-coverage.json').read_text())
    old = {key(r['package_id'], r['target']) for r in prior['inventory'].values()}
    corroboration = {'prior_targets': len(old), 'removed': sorted(old-registry.keys()),
                     'added': sorted(registry.keys()-old), 'executions_reused': 0}
    assert not corroboration['removed'], 'previous workspace targets disappeared'
    write('native-partitions-metadata.json', metadata)
    return {'metadata_command': command, 'registry': registry, 'doctest_libraries': docs,
            'groups': groups, 'native_targets': len(registry), 'corroboration': corroboration}


def inactive(target):
    assert target in ALLOWED and not target.is_symlink()
    prefix = str(target).encode()
    for proc in Path('/proc').iterdir():
        if not proc.name.isdigit() or int(proc.name) == os.getpid():
            continue
        try:
            state = (proc/'stat').read_text().rsplit(')', 1)[1].split()
            if state[0] == 'Z':
                continue
            assert int(state[2]) != os.getpgrp(), ('partition child still active', proc.name)
            args = (proc/'cmdline').read_bytes().split(b'\0')
            if args and (Path(os.fsdecode(args[0])).name in {'cargo', 'rustc', 'rustdoc'}
                         or args[0].startswith(prefix)):
                assert not any(prefix in arg for arg in args), ('consumer cache still active', proc.name)
            assert not os.readlink(proc/'cwd').startswith(str(target)+'/'), ('consumer cwd active', proc.name)
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            continue


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    prepared = plan()
    if not args.run:
        write('native-partitions-plan.json', prepared)
        print(json.dumps({'targets': prepared['native_targets'], 'native_groups': len(prepared['groups']),
                          'doc_libraries': len(prepared['doctest_libraries']),
                          'corroboration': prepared['corroboration']}))
        return
    assert os.getpgrp() == os.getpid(), 'launch through docs/run-check.py for an isolated process group'
    assert not (OUT/'native-partitions-coverage.json').exists(), 'preserve prior attempts'
    inputs = CHECK.snapshot()
    helpers = [Path(__file__).resolve(), Path(CHECK.__file__), Path(OLD.__file__)]
    helper_hashes = {str(p.relative_to(ROOT)): CHECK.sha(p) for p in helpers}
    report = dict(prepared, schema='pbrs.workspace-partitions.v2', status='running', coverage={},
                  commands=[], inputs_sha256=inputs, helper_sha256=helper_hashes,
                  rustc=subprocess.check_output(['rustc', '-Vv'], cwd=ROOT, env=ENV, text=True),
                  limits=['partitioned coverage; every current target executes; no prior-run reuse',
                          'existing ignores are recorded, not qualified',
                          'selected source hashes are not a complete filesystem read trace'])

    def stable():
        return inputs == CHECK.snapshot() and all(CHECK.sha(ROOT/p) == h for p, h in helper_hashes.items())

    def command(argv, stem):
        assert stable(), 'inputs changed before command'
        log = OUT/(stem+'.log')
        assert not log.exists() and not log.with_suffix('.json').exists(), 'preserve command logs'
        print(json.dumps({'starting': stem, 'command': argv}), flush=True)
        started = time.monotonic()
        with log.open('w') as stream:
            code = subprocess.call(argv, cwd=ROOT, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
        row = {'command': argv, 'exit_code': code, 'elapsed_seconds': time.monotonic()-started,
               'log': log.name, 'log_sha256': CHECK.sha(log), 'source_inputs_unchanged': stable()}
        write(stem+'.json', row)
        report['commands'].append(row)
        write('native-partitions-coverage.json', report)
        assert code == 0 and row['source_inputs_unchanged'], row
        return log

    def cleanup(stem):
        for target in ALLOWED:
            if target.exists():
                inactive(target)
                command(['cargo', 'clean', '--target-dir', str(target)], stem+'-'+target.name)

    cleanup('native-partitions-clean-initial')
    for number, group in enumerate(prepared['groups'], 1):
        expected = {k for k, r in prepared['registry'].items() if
                    (group == ['--lib'] and r['target']['kind'] == ['lib']) or
                    (group == ['--bins'] and r['target']['kind'] == ['bin']) or
                    (group[0] == '--test' and r['target']['kind'] == ['test'] and r['target']['name'] == group[1])}
        assert expected, ('empty target group', group)
        log = command(BASE+group+['--message-format=json'], f'native-partitions-{number:03}')
        built = OLD.artifact_rows(log, set(prepared['doctest_libraries'].values()) |
                                  {r['package_id'] for r in prepared['registry'].values()})
        identities = {key(r['package_id'], r['target']): r for r in built.values()}
        assert len(identities) == len(built) and identities.keys() == expected, ('artifact selection differs', group)
        suites, unfinished = OLD.parse_suites(log, built)
        assert suites.keys() == built.keys() and not unfinished, ('suite coverage incomplete', group)
        for identity, artifact in identities.items():
            required = prepared['registry'][identity]
            assert artifact['target'] == required['target'], ('target drift', identity)
            assert sorted(artifact['features']) == required['expected_features'], ('feature drift', identity)
            assert artifact['profile']['test'] is True and artifact['profile']['opt_level'] == '0'
            assert identity not in report['coverage'], ('duplicate target execution', identity)
            assert all(r['executable'] != artifact['executable'] for r in report['coverage'].values())
            report['coverage'][identity] = dict(artifact, result=suites[artifact['executable']], log=log.name)
        write('native-partitions-coverage.json', report)
        cleanup(f'native-partitions-clean-{number:03}')
    assert report['coverage'].keys() == prepared['registry'].keys(), 'native target union incomplete'
    doc_log = command(BASE+['--doc'], 'native-partitions-doctests')
    docs, unfinished = OLD.parse_suites(doc_log, prepared['doctest_libraries'], docs=True)
    assert docs.keys() == prepared['doctest_libraries'].keys() and not unfinished, 'doctest union incomplete'
    cleanup('native-partitions-clean-doc')
    assert all(OLD.digest(r['executable']) == r['binary_sha256'] for r in report['coverage'].values()), 'executable drift'
    report.update(status='passed', doctests=docs, native_passed=sum(r['result']['passed'] for r in report['coverage'].values()),
                  native_ignored=sum(r['result']['ignored'] for r in report['coverage'].values()),
                  doctest_passed=sum(r['passed'] for r in docs.values()), doctest_ignored=sum(r['ignored'] for r in docs.values()))
    write('native-partitions-coverage.json', report)
    print(json.dumps({k: report[k] for k in ['status', 'native_targets', 'native_passed', 'native_ignored', 'doctest_passed', 'doctest_ignored']}), flush=True)


if __name__ == '__main__':
    main()
