#!/usr/bin/env python3
"""Continue only the completed prefix of the same frozen workspace pass."""
import argparse
import copy
import importlib.util
import json
import os
from pathlib import Path
import re
import subprocess
import time

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('original_partitions', HERE/'workspace-partitions.py')
F = importlib.util.module_from_spec(spec)
spec.loader.exec_module(F)
ROOT, OUT, CHECK, OLD = F.ROOT, F.OUT, F.CHECK, F.OLD
PREFIX = 'native-partitions-resume'


def load(name):
    return json.loads((OUT/name).read_text())


def expected_group(group, registry):
    return {k for k, r in registry.items() if
            (group == ['--lib'] and r['target']['kind'] == ['lib']) or
            (group == ['--bins'] and r['target']['kind'] == ['bin']) or
            (group[0] == '--test' and r['target']['kind'] == ['test'] and r['target']['name'] == group[1])}


def verified_suites(log, group, report):
    registry = report['registry']
    artifacts = OLD.artifact_rows(log, {r['package_id'] for r in registry.values()})
    identities = {F.key(r['package_id'], r['target']): r for r in artifacts.values()}
    assert len(identities) == len(artifacts) and identities.keys() == expected_group(group, registry)
    suites, unfinished = OLD.parse_suites(log, artifacts)
    assert suites.keys() == artifacts.keys() and not unfinished
    result = {}
    for identity, artifact in identities.items():
        required = registry[identity]
        assert artifact['target'] == required['target']
        assert sorted(artifact['features']) == required['expected_features']
        assert artifact['profile']['test'] is True and artifact['profile']['opt_level'] == '0'
        result[identity] = dict(artifact, result=suites[artifact['executable']], log=log.name)
    return result


def prepare():
    prior = load('native-partitions-coverage.json')
    wrapper = load('native-partitions-final.json')
    assert prior['schema'] == 'pbrs.workspace-partitions.v2' and prior['status'] == 'running'
    assert wrapper['exit_code'] == wrapper['process_returncode'] == 1 and not wrapper['disk_guard']
    assert wrapper['source_inputs_unchanged'] and wrapper['inputs_sha256'] == prior['inputs_sha256']
    assert wrapper['command'] == ['python3', 'work/followup-20261102/docs/workspace-partitions.py', '--run']
    assert wrapper['log'] == 'native-partitions-final.log'
    assert CHECK.sha(OUT/wrapper['log']) == wrapper['log_sha256']
    assert re.search(r"AssertionError: \('consumer cache still active', '\d+'\)\s*$", (OUT/wrapper['log']).read_text())
    assert CHECK.snapshot() == prior['inputs_sha256'], 'current source differs from this pass'
    assert subprocess.check_output(['rustc', '-Vv'], cwd=ROOT, env=F.ENV, text=True) == prior['rustc'] == wrapper['rustc']
    assert all(CHECK.sha(ROOT/p) == h for p, h in prior['helper_sha256'].items())
    metadata = json.loads(subprocess.check_output(prior['metadata_command'], cwd=ROOT, env=F.ENV, text=True))
    registry, docs = {}, {}
    for package in metadata['packages']:
        if package['id'] not in metadata['workspace_members']:
            continue
        for target in package['targets']:
            if target['kind'] == ['lib'] and target['doctest']:
                assert target['name'] not in docs
                docs[target['name']] = package['id']
            if target['test'] and target['kind'] in (['lib'], ['bin'], ['test']):
                registry[F.key(package['id'], target)] = {'package_id': package['id'], 'target': target,
                                                         'expected_features': sorted(package['features'])}
    groups = [['--lib'], ['--bins']] + [['--test', name] for name in sorted(
        {r['target']['name'] for r in registry.values() if r['target']['kind'] == ['test']})]
    assert registry == prior['registry'] and docs == prior['doctest_libraries'] and groups == prior['groups']
    assert len(registry) == prior['native_targets'] == 153 and len(docs) == 5
    recovered, completed = {}, []
    for record in prior['commands']:
        assert record['exit_code'] == 0 and record['source_inputs_unchanged']
        path = OUT/record['log']
        assert path.parent == OUT and CHECK.sha(path) == record['log_sha256']
        assert load(path.with_suffix('.json').name) == record
        if record['command'][:len(F.BASE)] == F.BASE:
            index = len(completed)
            assert record['command'] == F.BASE+groups[index]+['--message-format=json']
            rows = verified_suites(path, groups[index], prior)
            assert not (rows.keys() & recovered.keys()), 'duplicate completed target'
            recovered.update(rows)
            completed.append(index+1)
        else:
            assert record['command'] in [['cargo', 'clean', '--target-dir', str(p)] for p in F.ALLOWED]
    assert recovered == prior['coverage'], 'partial group or unbound coverage row'
    assert len({r['executable'] for r in recovered.values()}) == len(recovered)
    binding = {'prior_wrapper': 'native-partitions-final.json',
               'prior_wrapper_sha256': CHECK.sha(OUT/'native-partitions-final.json'),
               'prior_wrapper_log_sha256': wrapper['log_sha256'],
               'prior_coverage_sha256': CHECK.sha(OUT/'native-partitions-coverage.json'),
               'completed_groups': completed, 'completed_targets': len(recovered),
               'completed_passes': sum(r['result']['passed'] for r in recovered.values()),
               'source_inputs': len(prior['inputs_sha256']),
               'remaining_groups': len(groups)-len(completed),
               'execution_credit': 'only completed commands from this same frozen partition pass; no earlier baseline executions'}
    return prior, metadata, binding


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--run', action='store_true')
    args = parser.parse_args()
    prior, metadata, binding = prepare()
    if not args.run:
        F.write(PREFIX+'-plan.json', binding)
        print(json.dumps(binding))
        return
    assert os.getpgrp() == os.getpid(), 'launch through docs/run-check.py'
    assert not (OUT/(PREFIX+'-coverage.json')).exists(), 'preserve previous attempts'
    report = copy.deepcopy(prior)
    report.update(schema='pbrs.workspace-partitions-resume.v1', status='running', resume=binding)
    report['helper_sha256'][str(Path(__file__).resolve().relative_to(ROOT))] = CHECK.sha(Path(__file__))
    report['limits'] = ['resumed current frozen partition pass; no earlier baseline execution credit',
                        'original cache-guard refusal is retained; no test failures waived',
                        'existing ignores are recorded, not qualified; selected inputs are not a complete read trace']
    F.write(PREFIX+'-metadata.json', metadata)

    def stable():
        return (CHECK.snapshot() == report['inputs_sha256'] and
                all(CHECK.sha(ROOT/p) == h for p, h in report['helper_sha256'].items()))

    def command(argv, stem):
        assert stable(), 'inputs changed before command'
        path = OUT/(stem+'.log')
        assert not path.exists() and not path.with_suffix('.json').exists(), 'preserve command logs'
        print(json.dumps({'starting': stem, 'command': argv}), flush=True)
        start = time.monotonic()
        with path.open('w') as log:
            code = subprocess.call(argv, cwd=ROOT, env=F.ENV, stdout=log, stderr=subprocess.STDOUT)
        row = {'command': argv, 'exit_code': code, 'elapsed_seconds': time.monotonic()-start,
               'log': path.name, 'log_sha256': CHECK.sha(path), 'source_inputs_unchanged': stable()}
        F.write(stem+'.json', row)
        report['commands'].append(row)
        F.write(PREFIX+'-coverage.json', report)
        assert code == 0 and row['source_inputs_unchanged'], row
        return path

    def cleanup(stem):
        for target in F.ALLOWED:
            if target.exists():
                F.inactive(target)
                command(['cargo', 'clean', '--target-dir', str(target)], stem+'-'+target.name)

    cleanup(PREFIX+'-clean-initial')
    for index, group in enumerate(report['groups']):
        if index+1 in binding['completed_groups']:
            continue
        log = command(F.BASE+group+['--message-format=json'], f'{PREFIX}-{index+1:03}')
        rows = verified_suites(log, group, report)
        assert not (rows.keys() & report['coverage'].keys())
        report['coverage'].update(rows)
        assert len({r['executable'] for r in report['coverage'].values()}) == len(report['coverage'])
        F.write(PREFIX+'-coverage.json', report)
        cleanup(f'{PREFIX}-clean-{index+1:03}')
    assert report['coverage'].keys() == report['registry'].keys()
    log = command(F.BASE+['--doc'], PREFIX+'-doctests')
    docs, unfinished = OLD.parse_suites(log, report['doctest_libraries'], docs=True)
    assert docs.keys() == report['doctest_libraries'].keys() and not unfinished
    cleanup(PREFIX+'-clean-doc')
    assert all(OLD.digest(r['executable']) == r['binary_sha256'] for r in report['coverage'].values())
    report.update(status='passed', doctests=docs, native_passed=sum(r['result']['passed'] for r in report['coverage'].values()),
                  native_ignored=sum(r['result']['ignored'] for r in report['coverage'].values()),
                  doctest_passed=sum(r['passed'] for r in docs.values()), doctest_ignored=sum(r['ignored'] for r in docs.values()))
    F.write(PREFIX+'-coverage.json', report)
    print(json.dumps({k: report[k] for k in ['status', 'native_targets', 'native_passed', 'native_ignored', 'doctest_passed', 'doctest_ignored']}), flush=True)


if __name__ == '__main__':
    main()
