#!/usr/bin/env python3
"""Small in-memory negative controls for the prepared evidence verifier."""
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent


def load(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


pack = load('followup_capture', HERE / 'capture.py')
check = load('followup_checker', HERE / 'check.py')
files = pack.collect()
results = []


def changed_json(changed, name, edit):
    data = json.loads(changed[name])
    edit(data)
    changed[name] = (json.dumps(data) + '\n').encode()


def reject(label, edit, verify):
    changed = dict(files)
    edit(changed)
    try:
        verify(changed)
    except (AssertionError, KeyError, ValueError):
        results.append({'name': label, 'rejected': True})
    else:
        raise AssertionError('mutation accepted: ' + label)


prefix = 'work/followup-20261102/'
rpc = prefix + 'rpc-input-children/report.json'
screen = prefix + 'chunk-screen/results.json'
reject('omitted-rpc-child', lambda f: changed_json(f, rpc, lambda x: x['commands'].pop()), check.rpc_inputs)


def change_one_child(changed):
    report = json.loads(changed[rpc])
    row = report['commands'][0]
    row['input_wire_fingerprint'] = 'fnv1a64:1111111111111111'
    log = prefix + 'rpc-input-children/' + row['stderr']
    lines = []
    for line in changed[log].decode().splitlines():
        for marker in ('__CHILD__ ', '__QUALIFICATION__ '):
            if line.startswith(marker):
                data = json.loads(line[len(marker):])
                data['input_wire_fingerprint'] = row['input_wire_fingerprint']
                line = marker + json.dumps(data)
                break
        lines.append(line)
    changed[log] = ('\n'.join(lines) + '\n').encode()
    row['stderr_sha256'] = hashlib.sha256(changed[log]).hexdigest()
    report['input_identities']['8']['fingerprint'] = row['input_wire_fingerprint']
    changed[rpc] = (json.dumps(report) + '\n').encode()


reject('consistent-one-child-identity-drift', change_one_child, check.rpc_inputs)
reject('changed-mechanism-median',
       lambda f: changed_json(f, screen, lambda x: x['rows'][0].update(median_ratio=0.1)),
       check.mechanism_screen)
reject('omitted-mechanism-pair',
       lambda f: changed_json(f, screen, lambda x: x['rows'][0]['pairs'].pop()),
       check.mechanism_screen)
reject('undisclosed-i686-size',
       lambda f: changed_json(f, prefix + 'i686/layout-after.json',
                              lambda x: x['rows'][1]['result'].update(LazyBytes=[20, 4])),
       check.detecting_controls)
seed = prefix + 'descriptor/crash-52f06f01d32b69d1.bin'
reject('changed-crash-seed', lambda f: f.update({seed: b'\0' + f[seed][1:]}), check.detecting_controls)
report = {
    'scope': 'selected in-memory controls; final capsule member/source/report checks remain separate',
    'checker_sha256': hashlib.sha256((HERE / 'check.py').read_bytes()).hexdigest(),
    'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    'controls': results,
}
(HERE / 'check-controls.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'negative_controls': len(results), 'all_rejected': all(x['rejected'] for x in results)}))
