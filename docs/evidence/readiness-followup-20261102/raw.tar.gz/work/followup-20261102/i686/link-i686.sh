#!/bin/sh
set -eu
exec gcc -m32 --sysroot=/workspace/pure-protobuf/work/followup-20261102/i686/sysroot -B/workspace/pure-protobuf/work/followup-20261102/i686/sysroot/usr/lib/gcc/x86_64-linux-gnu/14/32/ -L/workspace/pure-protobuf/work/followup-20261102/i686/sysroot/usr/lib32 "$@"
