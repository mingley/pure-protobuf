use std::mem::{size_of,align_of};
fn main(){println!(r#"{{"LazyBytes":[{},{}],"LazyStr":[{},{}],"Wire":[{},{}]}}"#,size_of::<pbrs::rt::LazyBytes>(),align_of::<pbrs::rt::LazyBytes>(),size_of::<pbrs::rt::LazyStr>(),align_of::<pbrs::rt::LazyStr>(),size_of::<pbrs::rt::Wire>(),align_of::<pbrs::rt::Wire>()); }
