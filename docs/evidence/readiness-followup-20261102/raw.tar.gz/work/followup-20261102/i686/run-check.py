#!/usr/bin/env python3
import datetime,hashlib,json,os,subprocess,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent
name,*command=sys.argv[1:]
assert command and not (OUT/(name+'.json')).exists()
paths=subprocess.check_output(['git','ls-files','-z','Cargo.toml','Cargo.lock','build.rs','src','tests/runtime.rs','tests/proof/owned_messages','tests/test_miri_grpc_kernels.py'],cwd=ROOT).decode().split('\0')+['scripts/miri-zero-defaults.py']
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if p and (ROOT/p).is_file()}
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_LINKER=str(OUT/'link-i686.sh'),CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_RUNNER=str(OUT/'run-i686.sh'),RUST_BACKTRACE='1')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
if any('miri' in arg for arg in command):
 env.pop('CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_RUNNER',None)
 env.pop('CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_LINKER',None)
record={'name':name,'command':command,'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_status':subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True),'source_before':hashes(),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'execution':('Miri interpretation of the i686 target layout' if any('miri' in arg for arg in command) else ('QEMU i386 user emulation; native ELF32 exec unavailable' if 'i686-unknown-linux-gnu' in command else 'native host execution')),'linker':env.get('CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_LINKER'),'runner':env.get('CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_RUNNER'),'MIRIFLAGS':env.get('MIRIFLAGS')}
start=time.monotonic()
with (OUT/(name+'.log')).open('w') as f:record['exit_code']=subprocess.call(command,cwd=ROOT,env=env,stdout=f,stderr=subprocess.STDOUT)
record.update(elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_after=hashes(),log_sha256=hashlib.sha256((OUT/(name+'.log')).read_bytes()).hexdigest());record['inputs_unchanged']=record['source_before']==record['source_after']
(OUT/(name+'.json')).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({k:v for k,v in record.items() if k not in ('source_before','source_after','rustc')},indent=2))
print('\n'.join((OUT/(name+'.log')).read_text().splitlines()[-25:]))
raise SystemExit(record['exit_code'])
