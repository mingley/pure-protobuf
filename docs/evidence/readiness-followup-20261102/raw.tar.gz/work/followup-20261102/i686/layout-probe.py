#!/usr/bin/env python3
import hashlib,json,os,subprocess,sys
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
label=sys.argv[1];assert not (OUT/('layout-'+label+'.json')).exists()
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_I686_UNKNOWN_LINUX_GNU_LINKER=str(OUT/'link-i686.sh'))
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
source=sha(ROOT/'src/lazy.rs')
probe=OUT/"layout.rs";probe.write_text('use std::mem::{size_of,align_of};\nfn main(){println!(r#"{{"LazyBytes":[{},{}],"LazyStr":[{},{}],"Wire":[{},{}]}}"#,size_of::<pbrs::rt::LazyBytes>(),align_of::<pbrs::rt::LazyBytes>(),size_of::<pbrs::rt::LazyStr>(),align_of::<pbrs::rt::LazyStr>(),size_of::<pbrs::rt::Wire>(),align_of::<pbrs::rt::Wire>()); }\n')
rows=[]
for target in ['native','i686-unknown-linux-gnu']:
 command=['cargo','build','--locked','-p','pbrs','--lib','--message-format=json']+([] if target=='native' else ['--target',target])
 out=OUT/(f'layout-{label}-{target}-build.jsonl');err=OUT/(f'layout-{label}-{target}-build.log')
 with out.open('w') as o,err.open('w') as e:subprocess.run(command,cwd=ROOT,env=env,stdout=o,stderr=e,check=True)
 messages=[json.loads(l) for l in out.read_text().splitlines()]
 artifacts=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(ROOT/'Cargo.toml') and m.get('target',{}).get('kind')==['lib']]
 assert len(artifacts)==1
 libraries=[p for p in artifacts[0]['filenames'] if p.endswith('.rlib')];assert len(libraries)==1
 library=Path(libraries[0]);binary=OUT/(f'layout-{label}-{target}')
 compile=['rustc','--edition=2024',str(probe),'--extern','pbrs='+str(library),'-L','dependency='+str(library.parent/'deps'),'-L','dependency='+str(ROOT/'target/debug/deps'),'-o',str(binary)]+([] if target=='native' else ['--target',target,'-C','linker='+str(OUT/'link-i686.sh')])
 subprocess.run(compile,cwd=ROOT,env=env,check=True)
 run=[str(binary)] if target=='native' else [str(OUT/'run-i686.sh'),str(binary)]
 result=subprocess.check_output(run,env=env,text=True).strip();print(target,result,flush=True)
 rows.append({'target':target,'build_command':command,'rustc_command':compile,'run_command':run,'library':str(library),'library_sha256':sha(library),'binary_sha256':sha(binary),'result':json.loads(result)})
assert sha(ROOT/'src/lazy.rs')==source
report={'source_lazy_sha256':source,'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'rows':rows,'scope':'Rust type layout only; no CPU timing'}
(OUT/('layout-'+label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
