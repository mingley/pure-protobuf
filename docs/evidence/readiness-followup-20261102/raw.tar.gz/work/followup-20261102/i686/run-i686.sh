#!/bin/sh
set -eu
exec /workspace/pure-protobuf/work/followup-20261102/i686/qemu-i386 /workspace/pure-protobuf/work/followup-20261102/i686/sysroot/usr/lib32/ld-linux.so.2 --library-path /workspace/pure-protobuf/work/followup-20261102/i686/sysroot/usr/lib32 "$@"
