# Zero-initialization audit, November 2 follow-up

The detecting source is `a35701582fb9e6964c855386b0d9c991c50345ba`.
The scheduled native i686 library job reported an offset panic-message
mismatch and then SIGSEGV. A serial QEMU i386 run reproduced both. Targeted
strict Miri for i686 identified the independent memory-safety defect:
`TestAllTypesProto3::default()` zeroed `LazyBytes` into its `Wire` variant,
whose private `Arc` pointer was null. The same address-space input exceeds
`usize` on 32-bit targets before it reaches the `u32` narrowing check.

The fix gives `LazyStr` and `LazyBytes` an explicit `repr(u8)` and `Empty = 0`.
Private `string::Repr` also explicitly uses `Inline = 0`, covering the direct
`ProtoString` field in the hand-written `testdata::Address` zeroed default.
The offset test retains both target-specific rejection checks.

## Emitted field families

There is no `ZeroInit` trait or equivalent type-system guard in this repository.
`rt::zeroed_message<T>` remains unsafe and its caller must establish the whole
type's validity. The generator uses it for normal and cold structs. This audit
follows `codegen::scalar_type`, `field_storage_ty`, message/cold emission, and
all non-generated uses of `zeroed_message` / `mem::zeroed`.

| Family | Empty representation and control |
|---|---|
| Numeric scalars and enum values | Full-range integer/float storage; bit zero is numeric zero. Generated enums use `i32` storage. |
| Implicit bool | Zero is `false`. |
| Explicit numeric presence | `Option<i32/i64/u32/u64/f32/f64>`; zero-None behavior is checked with both selected target layouts. These checks are not a promise about arbitrary `Option<T>`. |
| Explicit bool presence | `OptBool(u8)` defines zero as None; the generator does not emit `Option<bool>`. |
| Strings and bytes | `LazyStr`/`LazyBytes` now have explicit zero Empty tags, including the owned nested-message profile. Direct `ProtoString` has explicit zero Inline tag and zero length. |
| Explicit string/byte presence | Nullable `Option<Box<LazyStr/LazyBytes>>`, so zero is absent without constructing the payload. |
| Nested messages and groups | `LazyMsg<T>` contains `Option<Box<_>>`; owned/group storage is `Option<Box<T>>`. Empty initialization does not initialize an arbitrary child `T`. |
| Maps, repeated and packed storage | Nullable Box owners; zero does not construct the internal Vec, index, codec or element types. |
| Unknown fields | `FieldList(Option<Box<Vec<UnknownField>>>)`; zero does not construct an `UnknownField` enum value. |
| Normal and compact cached size | Integer atomic zero is valid and means clean size zero. Both caches are checked. |

Direct `Vec`, direct `bytes::Bytes`/`ProtoBytes`, arbitrary references,
`NonNull`, and `Option<bool>` must not be assumed zero-valid by this helper.
They are not direct fields emitted by the inspected storage selection. The
Box-backed containers can contain such values only after ordinary construction.
Extern message types are also behind absent Box owners in empty messages.

## Validation and limits

The final selected checks cover zeroed storage, generated empty defaults,
parse/serialization/drop, malformed groups, recursion budgets, scalar presence,
and atomics under strict Miri for i686 and x86_64. The same library/runtime
tests run natively on the host and under QEMU i386. The existing generated
consumer now checks fresh owned/lazy/default output, string and byte states,
binary and JSON roundtrips, clone/clear behavior, explicit-empty proto2
presence and empty oneofs. Existing required-field, oneof replacement, UTF-8,
map and group controls remain in place.

Stable 1.99.1 layout measurements retain 40-byte LazyBytes and 40-byte LazyStr
on x86_64. On i686, LazyBytes grows 20 to 24 bytes and LazyStr grows 28 to 32
bytes. Wire remains 32 bytes on x86_64 and 20 bytes on i686. These are layout
measurements, not CPU timing or complete performance qualification.

The managed runtime rejects native ELF32 execution, so local i686 execution
uses QEMU user emulation with a Debian package-managed local sysroot. This
does not replace the hosted native i686 lane. Miri can interpret the i686
layout; the older workflow comment claiming a 64-bit-only limitation was wrong.
Tests establish behavior for the recorded compilers and targets, not validity
of every possible `T`, a complete compiler filesystem trace, or production
qualification.

Keep the red logs and the initial missing-test-import compile failure alongside
the passing records. Early consumer/Miri runs precede the last fixture-only
JSON/presence checks; the `*-complete` consumer records contain those final
checks. Package caches, sysroot files, qemu executables and test executables
are tools/cache material, not documentation packet members.

## Ongoing CI

The existing compatibility target matrix now also runs on main pushes, without
adding a special SHA exception or changing the required release CI job set.
Native i686 library/runtime tests and both big-endian compile checks remain,
with locked dependencies. The scheduled Miri lane additionally runs
`scripts/miri-zero-defaults.py`. It requires the 16 named controls, inventories
library and runtime tests, then checks the actual pass/filter counts and rejects
zero selections, duplicate or missing tests, ignored controls, and required
controls that fall outside the executed filters.

The exact helper passed all 16 controls against the later descriptor grammar
repair with selected inputs unchanged. Its first local run inherited this
worker's QEMU Cargo runner and failed before interpreting any control; the work
launcher was corrected to leave runner ownership to cargo-miri. That failed
attempt is retained. Five Python inventory/result tests pass in the existing
required-CI test module, including detecting missing, duplicated, zero, ignored
and count/filter-drift controls.
