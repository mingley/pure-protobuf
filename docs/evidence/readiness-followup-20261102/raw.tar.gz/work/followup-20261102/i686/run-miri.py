#!/usr/bin/env python3
import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
OUT=Path(__file__).resolve().parent;ROOT=OUT.parents[2]
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',MIRIFLAGS='-Zmiri-disable-isolation -Zmiri-strict-provenance')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
paths=subprocess.check_output(['git','ls-files','-z','Cargo.toml','Cargo.lock','build.rs','.cargo','src','tests/runtime.rs','tests/proof/owned_messages'],cwd=ROOT).decode().split('\0')
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths if p and (ROOT/p).is_file()}
for arch in ['i686-unknown-linux-gnu','x86_64-unknown-linux-gnu']:
 for family in ['zeroed','groups']:
  name='miri-'+arch+'-final-'+family;out=OUT/(name+'.log');record_path=OUT/(name+'.json');assert not out.exists() and not record_path.exists()
  command=['cargo','+nightly-2026-10-29','miri','test','--locked','-p','pbrs','--lib']+(['--test','runtime'] if family=='zeroed' else [])+['--target',arch,('zeroed' if family=='zeroed' else 'wire::unknown_group_structure_tests'),'--','--nocapture','--test-threads=1']
  print(name,flush=True);record={'command':command,'MIRIFLAGS':env['MIRIFLAGS'],'source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source_before':hashes(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'rustc':subprocess.check_output(['rustc','+nightly-2026-10-29','-Vv'],env=env,text=True),'execution':'Miri interpretation of selected target layout'};start=time.monotonic()
  with out.open('w') as log:record['exit_code']=subprocess.call(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
  record.update(source_after=hashes(),elapsed_seconds=time.monotonic()-start,finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),log_sha256=hashlib.sha256(out.read_bytes()).hexdigest());record['inputs_unchanged']=record['source_before']==record['source_after'];record_path.write_text(json.dumps(record,indent=2)+'\n')
  print(json.dumps({k:v for k,v in record.items() if k not in ['source_before','source_after','rustc']}),flush=True)
  if record['exit_code']:raise SystemExit(record['exit_code'])
