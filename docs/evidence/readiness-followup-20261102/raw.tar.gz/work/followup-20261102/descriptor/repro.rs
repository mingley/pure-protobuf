fn main() {
    let data = std::fs::read(std::env::args().nth(1).unwrap()).unwrap();
    eprintln!("descriptor pool: {} bytes", data.len());
    match pbrs::DescriptorPool::from_file_descriptor_set(&data) {
        Ok(pool) => {
            for name in pool.collect_names().iter().take(256) {
                eprintln!("message: {name:?}");
                assert!(pool.get_message(name).is_some());
                let _ = pool.get_message(&format!(".{name}"));
            }
            for name in pool.collect_enum_names().iter().take(256) { let _ = pool.get_enum(name); }
            for svc in pool.collect_services().iter().take(256) { let _ = pool.get_service(&svc.full_name); }
        }
        Err(error) => eprintln!("pool error: {error:?}"),
    }
    eprintln!("code generator request");
    match pbrs::codegen::generate_from_code_generator_request(&data) {
        Ok(files) => for (filename, content) in files.iter().take(64) {
            eprintln!("generated filename: {filename:?}; content bytes: {}", content.len());
            assert!(!filename.is_empty());
            let bound = content.len().min(256 * 1024);
            let _ = &content[..bound];
        },
        Err(error) => eprintln!("codegen error: {error:?}"),
    }
}
