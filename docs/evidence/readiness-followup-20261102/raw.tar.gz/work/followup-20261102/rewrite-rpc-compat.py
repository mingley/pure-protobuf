from pathlib import Path
import json,pprint
root=Path.cwd();script=root/'scripts/devloop-rpc-base-compat.py';old=script.read_text()
known=json.loads((root/'work/followup-20261102/rpc-overlay-known-inputs.json').read_text())
plan=json.loads((root/'work/followup-20261102/rpc-metadata-overlay-source-plan.json').read_text())
constants='\n# Review each immutable baseline and all five reporting sources together.\n'
constants+='LEGACY_INPUT_SOURCES = '+pprint.pformat(known['15e738499f0dc937b0e54fd4325271b75ba7e5f4'],width=110,sort_dicts=False)+'\n'
constants+='CURRENT_INPUT_SOURCES = '+pprint.pformat(known['26389ccf77bf9342fe6e605f1d797853acd6c39a'],width=110,sort_dicts=False)+'\n'
constants+='KNOWN_INPUT_BASES = {\n    "15e738499f0dc937b0e54fd4325271b75ba7e5f4": LEGACY_INPUT_SOURCES,\n    "26389ccf77bf9342fe6e605f1d797853acd6c39a": CURRENT_INPUT_SOURCES,\n    "4a3e2d9f82edb8f0a94ae0f9f6a9bc500537607d": CURRENT_INPUT_SOURCES,\n    "a35701582fb9e6964c855386b0d9c991c50345ba": CURRENT_INPUT_SOURCES,\n}\n'
constants+='HEAD_RUNTIME_PREFIXES = '+pprint.pformat({p:r['after_runtime_prefix_sha256'] for p,r in plan.items()},width=110,sort_dicts=False)+'\n'
constants+='INPUT_PATCH = Path(__file__).with_name("devloop-rpc-input-overlay.patch")\n'
new=old[:old.index('\ndef main():')].replace('Only a disposable CI base worktree is changed; runtime source is untouched.','Only a disposable CI base worktree is changed; production source is untouched.\nThe input overlay repairs benchmark identity/length reporting and its guards,\nnot request values, serialization order or measured RPC loops.').replace('import json\n','import json\nimport re\nimport subprocess\n')+constants
new+='''

def digest(data):
    return hashlib.sha256(data).hexdigest()


def source_hashes(base, paths):
    return {path: digest((base / path).read_bytes()) for path in paths}


def current_commit(base):
    return subprocess.check_output(
        ["git", "-C", str(base), "rev-parse", "HEAD"], text=True
    ).strip()


def input_plan(base, head, commit):
    if commit is None:
        return {"apply": False, "reason": "no immutable base supplied"}
    if not re.fullmatch(r"[0-9a-f]{40}", commit) or current_commit(base) != commit:
        raise ValueError("base commit differs from --base-sha")
    expected = KNOWN_INPUT_BASES.get(commit)
    if expected is None:
        return {"apply": False, "reason": "unknown base commit; normal qualification remains mandatory"}
    actual = source_hashes(base, expected["before"])
    if actual not in (expected["before"], expected["after"]):
        raise ValueError("base input reporting sources differ from the pinned snapshot")
    for path, digest_expected in HEAD_RUNTIME_PREFIXES.items():
        data = (head / path).read_bytes()
        prefix = data.split(b"\\n#[cfg(test)]\\nmod ", 1)[0]
        if digest(prefix) != digest_expected:
            raise ValueError("head input reporting differs from the reviewed overlay: " + path)
    return {"apply": actual == expected["before"],
            "reason": "recognized immutable reporting sources" if actual == expected["before"] else "already applied",
            "before": actual, "expected_after": expected["after"],
            "head": source_hashes(head, expected["before"])}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("base", type=Path)
    parser.add_argument("record", type=Path)
    parser.add_argument("--head", type=Path, required=True)
    parser.add_argument("--base-sha", help="full immutable base commit for input-reporting compatibility")
    args = parser.parse_args()
    file = args.base / FILE
    original = file.read_bytes()
    before = digest(original)
    head_bytes = (args.head / FILE).read_bytes()
    head_sha256 = digest(head_bytes)
    fixture_applied = before == LEGACY_SHA256
    if fixture_applied:
        # Keep the previous fixture guard. A changed candidate fixture cannot
        # silently be made comparable by modifying only the baseline.
        head = head_bytes.decode("utf-8")
        helper_body = HELPER[HELPER.index("fn rpc_maps("):]
        call = "Specimen::Maps(n) => Self::Maps(Pair::prepare(\\n                rpc_maps(n),"
        if head.count(helper_body) != 1 or head.count(call) != 1:
            raise ValueError("head RPC fixture differs from the pinned compatibility overlay")
    # Validate every candidate source before any mutation. git apply is atomic
    # across the reviewed patch; an unknown base is never partially patched.
    plan = input_plan(args.base, args.head, args.base_sha)
    reporting = {"applied": plan["apply"], "reason": plan["reason"],
                 "base_commit": args.base_sha, "files": [],
                 "scope": "prepared benchmark input identity/length reporting and guards only; measured loops unchanged"}
    if plan["apply"]:
        patch = INPUT_PATCH.resolve()
        stats = subprocess.check_output(["git", "apply", "--numstat", str(patch)], text=True)
        paths = [line.split("\\t", 2)[2] for line in stats.splitlines()]
        if set(paths) != set(HEAD_RUNTIME_PREFIXES) or len(paths) != len(set(paths)):
            raise ValueError("input reporting patch changes an unexpected file")
        subprocess.run(["git", "apply", "--check", str(patch)], cwd=args.base, check=True)
        subprocess.run(["git", "apply", str(patch)], cwd=args.base, check=True)
        reporting["patch_sha256"] = digest(patch.read_bytes())
    if fixture_applied:
        source = file.read_text()
        insertion = "impl Inputs {\\n"
        old = "Specimen::Maps(n) => Self::Maps(Pair::prepare(\\n                maps(n),"
        assert source.count(insertion) == source.count(old) == 1
        source = source.replace(insertion, HELPER + insertion, 1)
        source = source.replace(old, old.replace("maps(n),", "rpc_maps(n),"), 1)
        file.write_text(source)
    if plan.get("before") is not None:
        after = source_hashes(args.base, plan["before"])
        if after != plan["expected_after"]:
            raise ValueError("input reporting overlay produced unexpected source bytes")
        reporting["files"] = [
            {"path": path, "before_sha256": value, "after_sha256": after[path],
             "head_sha256": plan["head"][path]}
            for path, value in plan["before"].items()
        ]
    after = digest(file.read_bytes())
    record = {"path": str(FILE), "before_sha256": before, "after_sha256": after,
              "head_sha256": head_sha256,
              "applied": fixture_applied or reporting["applied"],
              "fixture_applied": fixture_applied, "input_reporting": reporting,
              "scope": "benchmark RPC fixture and prepared-input reporting only; production source unchanged",
              "unknown_versions": "left unmodified; normal qualification remains mandatory"}
    args.record.parent.mkdir(parents=True, exist_ok=True)
    args.record.write_text(json.dumps(record, indent=2) + "\\n")
    print(json.dumps(record))


if __name__ == "__main__":
    main()
'''
script.write_text(new)
