from pathlib import Path
root=Path.cwd();driver=root/'bench/devloop/measure-tonic-transport.py';audit=root/'bench/devloop/check-tonic-transport-evidence.py'
legacy='bench/devloop/adoption/evidence/rpc-inventory.json';qualified='bench/devloop/adoption/evidence/rpc-inventory-equal-wire.json'
constant=f'\nLEGACY_SPECIMEN_INVENTORY = {legacy!r}\nQUALIFIED_SPECIMEN_INVENTORY = {qualified!r}\nINPUT_SCOPE = "common prepared wire; RPC map entry order may vary"\n'
helper='''

def validate_inventory(inventory, frozen):
    specimens = {row["specimen"]: row["qualification"] for row in frozen}
    assert len(specimens) == len(frozen) == 64
    expected = {f"{PREFIX}{profile}.{specimen}.{shape}"
                for profile in PROFILES for specimen in specimens for shape in SHAPES}
    blocked = {f"{PREFIX}{profile}.{specimen}.{shape}"
               for profile in PROFILES for specimen, row in specimens.items()
               if not row["equal_wire_work"] for shape in SHAPES}
    ids = inventory["registered_ids"]
    oracle = {row["id"]: row for row in inventory["preflight_rows"]}
    assert len(expected) == len(ids) == len(set(ids)) == 512 and set(ids) == expected
    assert len(inventory["blocked_ids"]) == len(blocked) and set(inventory["blocked_ids"]) == blocked
    assert len(oracle) == len(inventory["preflight_rows"]) == len(expected - blocked)
    assert set(oracle) == expected - blocked
    assert inventory["registered_count"] == 512
    assert inventory["actual_network_passed"] == len(oracle) and inventory["blocked_count"] == len(blocked)
    for cell, row in oracle.items():
        specimen = cell.removeprefix(PREFIX).split(".", 1)[1].rsplit(".", 1)[0]
        original = specimens[specimen]
        for field in ("request_bytes", "native_request_bytes", "response_bytes_per_message",
                      "request_read_checksum", "response_read_checksum"):
            assert row[field] == original[field], (cell, field)
        assert row["responses"] == (4 if cell.endswith(".server_stream") else 1)
    return ids, oracle, blocked


def input_length(row, oracle, required=False):
    if required or "input_wire_bytes" in row or "input_wire_bytes" in oracle:
        value = row.get("input_wire_bytes")
        assert type(value) is int and value >= 0 and value == oracle["request_bytes"], "prepared input length"
        if "input_wire_bytes" in oracle:
            assert type(oracle["input_wire_bytes"]) is int and value == oracle["input_wire_bytes"]
'''
s=driver.read_text();s=s.replace('\ndef validate_network(row, expected):',constant+helper+'\n\ndef validate_network(row, expected):',1)
s=s.replace('def validate_network(row, expected):\n','def validate_network(row, expected):\n    input_length(row, expected, required=True)\n    assert row["input_fingerprint_scope"] == INPUT_SCOPE\n',1)
old='''    ids = inventory["registered_ids"]
    oracle = {r["id"]: r for r in inventory["preflight_rows"]}
    blocked = set(inventory["blocked_ids"])
    assert len(ids) == len(set(ids)) == 512 and len(oracle) == 488 and len(blocked) == 24
    assert set(ids) == oracle.keys() | blocked
    assert all(".maps." in i for i in blocked)
    frozen_specimens = json.loads((ROOT / "bench/devloop/adoption/evidence/rpc-inventory.json").read_bytes())'''
new='''    specimen_path = inventory.get("specimen_inventory_path", LEGACY_SPECIMEN_INVENTORY)
    assert specimen_path in (LEGACY_SPECIMEN_INVENTORY, QUALIFIED_SPECIMEN_INVENTORY)
    specimen_bytes = relative_input(specimen_path).read_bytes()
    frozen_specimens = json.loads(specimen_bytes)
    ids, oracle, blocked = validate_inventory(inventory, frozen_specimens)'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('    build_bytes = args.build_record.resolve().read_bytes()\n','    assert digest(git("show", f"{commit}:{specimen_path}")) == digest(specimen_bytes)\n    build_bytes = args.build_record.resolve().read_bytes()\n',1)
s=s.replace('                  "inventory_sha256": digest(inventory_path.read_bytes()),','                  "inventory_sha256": digest(inventory_path.read_bytes()),\n                  "specimen_inventory_path": specimen_path, "specimen_inventory_sha256": digest(specimen_bytes),\n                  "input_wire_bytes_required": True,',1)
s=s.replace('"24 frozen map equal-wire blocks"','f"{len(blocked)} equal-wire blocks from the pinned specimen inventory"')
s=s.replace('            assert child["input_wire_fingerprint"] == network["input_wire_fingerprint"]\n','            assert child["input_wire_fingerprint"] == network["input_wire_fingerprint"]\n            input_length(child, oracle[cell], required=True)\n',1)
s=s.replace('        assert len(selected) == 61','        assert selected and set(selected) == {cell for cell in oracle if cell.startswith(f"{PREFIX}{profile}.") and cell.endswith(f".{shape}")}')
s=s.replace('and len(report["cells"]) == 61','and len(report["cells"]) == len(selected)')
s=s.replace('print(f"Captured {name}: 61 cells, all raw counters retained", flush=True)','print(f"Captured {name}: {len(selected)} cells, all raw counters retained", flush=True)')
s=s.replace('print("All 512 states retained: 488 captured, 24 map blocks. Run the independent audit.")','print(f"All {len(ids)} states retained: {len(oracle)} captured, {len(blocked)} equal-wire blocks. Run the independent audit.")')
driver.write_text(s)
# Keep the audit independently derived; it does not import the capture code.
s=audit.read_text();s=s.replace('\ndef network(row, oracle):',constant+helper.replace('validate_inventory','inventory_cells')+'\n\ndef network(row, oracle, require_length=False):',1)
s=s.replace('def network(row, oracle, require_length=False):\n','def network(row, oracle, require_length=False):\n    input_length(row, oracle, require_length)\n    if require_length or "input_fingerprint_scope" in row:\n        assert row["input_fingerprint_scope"] == INPUT_SCOPE\n',1)
s=s.replace('def reconstruct(directory, report_info, report, oracle, selected_tool, tools, binary):','def reconstruct(directory, report_info, report, oracle, selected_tool, tools, binary, require_length=False):')
s=s.replace('        assert row["input_wire_fingerprint"] == oracle[cell]["input_wire_fingerprint"]','        assert row["input_wire_fingerprint"] == oracle[cell]["input_wire_fingerprint"]\n        input_length(row, oracle[cell], require_length)',1)
s=s.replace('            network(qualified, oracle[cell])','            input_length(child, oracle[cell], require_length)\n            network(qualified, oracle[cell], require_length)',1)
s=s.replace('                network(qualified, oracle[cell])','                input_length(child, oracle[cell], require_length)\n                network(qualified, oracle[cell], require_length)',1)
start=s.index('    frozen = json.loads(git_file(record["source_commit"], "bench/devloop/adoption/evidence/rpc-inventory.json"))')
end=s.index('    assert set(record["cells"]) == expected',start)
new='''    specimen_path = inventory.get("specimen_inventory_path", LEGACY_SPECIMEN_INVENTORY)
    assert specimen_path in (LEGACY_SPECIMEN_INVENTORY, QUALIFIED_SPECIMEN_INVENTORY)
    specimen_bytes = git_file(record["source_commit"], specimen_path)
    if "specimen_inventory_path" in record:
        assert record["specimen_inventory_path"] == specimen_path
        assert record["specimen_inventory_sha256"] == sha(specimen_bytes)
    else:
        assert specimen_path == LEGACY_SPECIMEN_INVENTORY, "new specimen inventory lacks a source pin"
    frozen = json.loads(specimen_bytes)
    ids, oracle, blocked = inventory_cells(inventory, frozen)
    expected = set(ids)
    require_length = record.get("input_wire_bytes_required", False)
    assert type(require_length) is bool
    if specimen_path == QUALIFIED_SPECIMEN_INVENTORY:
        assert require_length, "new captures require prepared input lengths"
    specimens = {row["specimen"]: row["qualification"] for row in frozen}
'''
s=s[:start]+new+s[end:]
s=s.replace('            network(marked(stderr, "__QUALIFICATION__ "), oracle[cell])','            network(marked(stderr, "__QUALIFICATION__ "), oracle[cell], require_length)')
s=s.replace('            network(state["network"], oracle[cell])','            network(state["network"], oracle[cell], require_length)')
s=s.replace('            assert child["input_wire_fingerprint"] == oracle[cell]["input_wire_fingerprint"]\n    selected_tool', '            assert child["input_wire_fingerprint"] == oracle[cell]["input_wire_fingerprint"]\n            input_length(child, oracle[cell], require_length)\n    selected_tool',1)
s=s.replace('assert len(report["cells"]) == 61 and','assert len(report["cells"]) == len(selected) and')
s=s.replace('and len(argv[3].split(",")) == 61','and len(argv[3].split(",")) == len(selected)')
s=s.replace('reconstruct(directory, info, report, oracle, selected_tool, record["tools"], record["binary"])','reconstruct(directory, info, report, oracle, selected_tool, record["tools"], record["binary"], require_length)')
s=s.replace('    assert len(comparisons) == 366','    expected_comparisons = {cell for cell in oracle if not cell.startswith(f"{PREFIX}reference_reference.")}\n    assert len(comparisons) == len(expected_comparisons) and {row["id"] for row in comparisons} == expected_comparisons')
s=s.replace('    assert len(matrix_rows) == 488','    assert len(matrix_rows) == len(oracle)')
s=s.replace('"registered": 512, "network_qualified": 488, "blocked": 24,','"registered": len(expected), "network_qualified": len(oracle), "blocked": len(blocked),')
s=s.replace('print(f"SB-32 integrity passed: 512 states, 488 cell archives verified, 24 blocked, 366 comparisons; instruction availability {summary[\'metric_available_cells\'][\'instructions\']}/488; original replay gate {summary[\'original_baseline_replay_gate\']}")','print(f"SB-32 integrity passed: {summary[\'registered\']} states, {summary[\'network_qualified\']} cell archives verified, {summary[\'blocked\']} blocked, {len(summary[\'comparisons\'])} comparisons; instruction availability {summary[\'metric_available_cells\'][\'instructions\']}/{summary[\'network_qualified\']}; original replay gate {summary[\'original_baseline_replay_gate\']}")')
audit.write_text(s)
