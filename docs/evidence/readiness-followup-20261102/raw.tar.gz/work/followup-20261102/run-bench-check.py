#!/usr/bin/env python3
"""Capture selected source hashes and bounded functional harness checks."""
import datetime,hashlib,json,os
from pathlib import Path
import shutil,subprocess,sys,time
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'work/followup-20261102'
label,*command=sys.argv[1:];assert command and all(c.isalnum() or c in '-_' for c in label)
assert not (OUT/(label+'.json')).exists(),'preserve prior attempts'
paths=subprocess.check_output(['git','ls-files','-z','Cargo.toml','Cargo.lock','build.rs','.cargo','src',
 'pbrs-grpc/Cargo.toml','pbrs-grpc/Cargo.lock','pbrs-grpc/build.rs','pbrs-grpc/src','pbrs-grpc/proto',
 'protobuf-tonic/Cargo.toml','protobuf-tonic/Cargo.lock','protobuf-tonic/build.rs','protobuf-tonic/src','protobuf-tonic/proto',
 'bench/devloop/Cargo.toml','bench/devloop/Cargo.lock','bench/devloop/build.rs','bench/devloop/src','bench/devloop/proto',
 'bench/devloop/adoption/Cargo.toml','bench/devloop/adoption/Cargo.lock','bench/devloop/adoption/build.rs',
 'bench/devloop/adoption/src','bench/devloop/adoption/proto','vendor/google/PIN','vendor/google/SHA'],cwd=ROOT).decode().split('\0')
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
inputs={p:sha(ROOT/p) for p in paths if p and (ROOT/p).is_file()}
env=os.environ.copy();env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),
 CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',
 PBRS_PROTOC_JOBS='1',CMAKE_BUILD_PARALLEL_LEVEL='1')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
report={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
 'command':command,'inputs_sha256':inputs,'scope':'selected shipping and benchmark compiler inputs; not complete filesystem/tool/dependency attestation',
 'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),
 'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'free_before':shutil.disk_usage(ROOT).free,
 'environment':{k:env[k] for k in ['CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','PBRS_PROTOC_JOBS','CMAKE_BUILD_PARALLEL_LEVEL']}}
start=time.monotonic();print(json.dumps({'starting':label,'command':command,'free_GiB':round(report['free_before']/2**30,2)}),flush=True)
with (OUT/(label+'.log')).open('w') as log:
 report['exit_code']=subprocess.call(['python3',str(ROOT/'work/review30/guard.py'),*command],cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
report.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),elapsed_seconds=time.monotonic()-start,
 free_after=shutil.disk_usage(ROOT).free,source_inputs_unchanged=all(sha(ROOT/p)==v for p,v in inputs.items()),
 log_sha256=sha(OUT/(label+'.log')))
(OUT/(label+'.json')).write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='inputs_sha256'},indent=2));raise SystemExit(report['exit_code'] or (0 if report['source_inputs_unchanged'] else 2))
