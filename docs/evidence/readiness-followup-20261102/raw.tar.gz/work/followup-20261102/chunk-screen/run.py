import hashlib
import json
import os
from pathlib import Path
import random
import resource
import statistics
import subprocess
import time

ROOT = Path.cwd()
OUT = ROOT / 'work/followup-20261102/chunk-screen'
BUILD = json.loads((OUT/'build.json').read_text())
EXE = OUT/'screen'
assert hashlib.sha256(EXE.read_bytes()).hexdigest() == BUILD['executable_sha256']
assert not (OUT/'results.json').exists()
cpu = min(os.sched_getaffinity(0))
cases = [(1048576, 16384, 50001), (8388608, 16384, 8001),
         (8388608, 65536, 32001), (512, 16384, 2000001),
         (65536, 1024, 50001)]
rng = random.Random(20261102)
rows = []
start = time.time()

def pin():
    os.sched_setaffinity(0, {cpu})

for size, chunk, rounds in cases:
    pairs = []
    for pair in range(5):
        order = ['slices', 'split']
        rng.shuffle(order)
        samples = {}
        for mode in order:
            usage = resource.getrusage(resource.RUSAGE_CHILDREN)
            child = subprocess.run([str(EXE), mode, str(size), str(chunk), str(rounds)],
                                   capture_output=True, text=True, check=True,
                                   timeout=15, preexec_fn=pin)
            after = resource.getrusage(resource.RUSAGE_CHILDREN)
            fields = child.stdout.split()
            assert fields[:4] == [mode, str(size), str(chunk), str(rounds)]
            samples[mode] = {
                'timed_wall_ns': int(fields[4]), 'sink': int(fields[5]),
                'whole_process_cpu_ns': round(1e9 * ((after.ru_utime + after.ru_stime)
                                                   - (usage.ru_utime + usage.ru_stime))),
                'stdout': child.stdout, 'stderr': child.stderr,
            }
        pairs.append({'order': order, 'samples': samples,
                      'timed_wall_ratio': samples['split']['timed_wall_ns']/samples['slices']['timed_wall_ns']})
    ratios = [pair['timed_wall_ratio'] for pair in pairs]
    row = {'frame_bytes': size, 'chunk_bytes': chunk, 'rounds': rounds,
           'pairs': pairs, 'median_ratio': statistics.median(ratios),
           'ratio_range': [min(ratios), max(ratios)]}
    rows.append(row)
    print(json.dumps({key: value for key, value in row.items() if key != 'pairs'}), flush=True)

report = {'schema': 'pbrs.buffer-chunk-mechanism-screen.v1',
          'scope': 'isolated shared-buffer chunking only; no end-to-end RPC or production ranking claim',
          'dedicated_host': False, 'cpu_affinity': [cpu], 'seed': 20261102,
          'started_unix_seconds': start, 'finished_unix_seconds': time.time(),
          'build': BUILD, 'driver_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'executable_unchanged': hashlib.sha256(EXE.read_bytes()).hexdigest() == BUILD['executable_sha256'],
          'rows': rows}
assert report['executable_unchanged']
(OUT/'results.json').write_text(json.dumps(report, indent=2)+'\n')
