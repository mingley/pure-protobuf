use bytes::Bytes;
use std::hint::black_box;
use std::time::Instant;

#[inline(never)]
fn slices(source: &Bytes, chunk: usize, rounds: usize) -> usize {
    let mut sink = 0;
    for _ in 0..rounds {
        let mut remaining = source.clone();
        while !remaining.is_empty() {
            let n = remaining.len().min(chunk);
            let prefix = remaining.slice(..n);
            sink ^= black_box(prefix.as_ptr() as usize).wrapping_add(black_box(prefix.len()));
            black_box(&prefix);
            drop(prefix);
            remaining = remaining.slice(n..);
        }
    }
    sink
}

#[inline(never)]
fn split(source: &Bytes, chunk: usize, rounds: usize) -> usize {
    let mut sink = 0;
    for _ in 0..rounds {
        let mut remaining = source.clone();
        while !remaining.is_empty() {
            let n = remaining.len().min(chunk);
            let prefix = remaining.split_to(n);
            sink ^= black_box(prefix.as_ptr() as usize).wrapping_add(black_box(prefix.len()));
            black_box(&prefix);
            drop(prefix);
        }
    }
    sink
}

fn main() {
    let args: Vec<_> = std::env::args().collect();
    let size: usize = args[2].parse().unwrap();
    let chunk: usize = args[3].parse().unwrap();
    let rounds: usize = args[4].parse().unwrap();
    assert!(size > 0 && chunk > 0 && rounds > 0);
    let source = Bytes::from(vec![0x5a; size]);
    let run = match args[1].as_str() { "slices" => slices, "split" => split, _ => panic!("mode") };
    black_box(run(&source, chunk, 10));
    let start = Instant::now();
    let sink = run(black_box(&source), black_box(chunk), black_box(rounds));
    println!("{} {} {} {} {} {}", args[1], size, chunk, rounds, start.elapsed().as_nanos(), black_box(sink));
}
