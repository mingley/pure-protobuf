"""Bounded same-codec endpoint allocation comparison; no timing qualification."""
import argparse
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("encode_smoke", ROOT / "work/encode_smoke.py")
smoke = importlib.util.module_from_spec(spec)
spec.loader.exec_module(smoke)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--smoke", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    builds = {}
    for name in ["baseline", "candidate"]:
        location = ROOT / "work/perf" / ("final-candidate" if name == "candidate" else name)
        source = ROOT / "work" / name
        binary = location / "rpc-bench"
        record = smoke.verified_build(location / "build.json", binary, source)
        builds[name] = dict(binary=binary, source=source, record=record)
    report = dict(schema="pbrs.encode-reuse-comparison.v1", qualified=False,
                  host=platform.uname()._asdict(), affinity=sorted(os.sched_getaffinity(0)),
                  builds={k: v["record"] for k, v in builds.items()},
                  driver_sha256=sha(Path(__file__)), helper_sha256=sha(ROOT / "work/encode_smoke.py"),
                  limits=["Shared Linux host; counters enabled; no timing qualification",
                          "Process allocation requests include startup; use paired N/2N slopes",
                          "Plaintext loopback, two Tokio workers, one connection and one in-flight RPC",
                          "Four messages per stream; zero/noise bodies, gzip level 6",
                          "Noise bodies checked in full by both Prost peers; pbrs uses zero bodies"],
                  runs=[], passed=False, state="running")
    shutil.copy2(__file__, output / "driver.py")
    shutil.copy2(ROOT / "work/encode_smoke.py", output / "helper.py")
    scopes = []
    for shape, pattern, native_side in itertools.product(
            ["server_stream", "client_stream", "bidi", "bidi_pipelined"],
            ["zero", "noise"], ["client", "server"]):
        pair = ["native", "prost", "tonic", "prost"] if native_side == "client" else ["tonic", "prost", "native", "prost"]
        scopes.append(dict(pair=pair, shape=shape, payload_bytes=1048576,
                           payload_pattern=pattern, tls=False, compression="gzip"))
    for side in ["client", "server"]:
        pair = ["native", "pbrs", "tonic", "prost"] if side == "client" else ["tonic", "prost", "native", "pbrs"]
        scopes.append(dict(pair=pair, shape="bidi", payload_bytes=1048576,
                           tls=False, compression="gzip"))
    for pattern in ["zero", "noise"]:
        scopes.append(dict(pair=["tonic", "prost", "tonic", "prost"], shape="bidi",
                           payload_bytes=1048576, payload_pattern=pattern, tls=False, compression="gzip"))
    for shape, side in itertools.product(["unary", "bidi"], ["client", "server"]):
        pair = ["native", "prost", "tonic", "prost"] if side == "client" else ["tonic", "prost", "native", "prost"]
        scopes.append(dict(pair=pair, shape=shape, payload_bytes=1024,
                           tls=False, compression="identity"))
    if args.smoke:
        scopes = [scopes[2], scopes[3]]  # checked noise in both directions
    groups = list(itertools.product(range(2 if not args.smoke else 1), scopes, [10, 20] if not args.smoke else [1]))
    random.Random(260027).shuffle(groups)
    report["expected_captures"] = len(groups) * 2
    path = output / "report.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    for group_index, (repeat, cell, count) in enumerate(groups):
        names = ["baseline", "candidate"] if group_index % 2 == 0 else ["candidate", "baseline"]
        for name in names:
            build = builds[name]
            settings = SimpleNamespace(binary=build["binary"], source_checkout=build["source"],
                                       duration=60, rpc_count=count, allocation_counts=True,
                                       context_switches=False, callgrind=None, strace=None)
            directory = output / f"capture-{len(report['runs']):03d}"
            result = smoke.run_cell(settings, cell, directory)
            if result["passed"] and "payload_pattern" in cell:
                if result["metrics"].get("payload_pattern") != cell["payload_pattern"]:
                    result.update(passed=False, error="pattern validation missing")
                    (directory / "run.json").write_text(json.dumps(result, indent=2) + "\n")
            row = dict(source=name, repeat=repeat, count=count, cell=cell,
                       passed=result["passed"], path=str(directory.relative_to(output) / "run.json"))
            report["runs"].append(row)
            path.write_text(json.dumps(report, indent=2) + "\n")
            if not result["passed"]:
                report.update(state="failed", error=result.get("error"))
                path.write_text(json.dumps(report, indent=2) + "\n")
                print(row, result.get("error"), flush=True)
                return 1
        if group_index % 4 == 0:
            print(f"{len(report['runs'])}/{report['expected_captures']} captures passed", flush=True)
    for build in builds.values():
        smoke.verified_build(build["binary"].parent / "build.json", build["binary"], build["source"])
    report.update(state="complete", passed=True,
                  successful_rpcs=sum(row["count"] for row in report["runs"]))
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"complete: {len(report['runs'])} captures, {report['successful_rpcs']} successful RPCs", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
