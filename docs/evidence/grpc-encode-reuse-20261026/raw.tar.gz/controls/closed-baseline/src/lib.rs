//! A peer may finish an RPC before the client queues an empty half-close.
#![allow(
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    reason = "bounded in-memory transport regression assertions"
)]

use pbrs_grpc::{
    Greeter, GreeterClient, GreeterServer, HelloReply, HelloRequest, Request, Response, Status,
    Streaming,
};
use std::time::Duration;

struct Early;

impl Greeter for Early {
    async fn client_hello(
        &self,
        _: Request<Streaming<HelloRequest>>,
    ) -> Result<Response<HelloReply>, Status> {
        Ok(Response::new(HelloReply::new()))
    }

    async fn server_hello(
        &self,
        _: Request<HelloRequest>,
    ) -> Result<Response<Streaming<HelloReply>>, Status> {
        Ok(Response::new(Streaming::empty()))
    }

    async fn stream_hello(
        &self,
        _: Request<Streaming<HelloRequest>>,
    ) -> Result<Response<Streaming<HelloReply>>, Status> {
        Ok(Response::new(Streaming::empty()))
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn empty_closed_upload_preserves_early_responses_and_sibling_recovery() {
    let (client_io, server_io) = tokio::io::duplex(64 * 1024);
    let server = tokio::spawn(GreeterServer::new(Early).serve_connection(server_io));
    let channel = pbrs_grpc::Channel::from_io(client_io, "localhost")
        .await
        .unwrap();
    let client = GreeterClient::new(channel);
    tokio::time::timeout(Duration::from_secs(30), async {
        for turn in 0..1000 {
            // Drop an unconsumed sibling response before opening the upload.
            drop(
                client
                    .server_hello(Request::new(HelloRequest::new()))
                    .await
                    .unwrap(),
            );
            let (sender, call) = client.client_hello(Request::new(()));
            sender.close();
            call.await.unwrap_or_else(|status| {
                panic!(
                    "client-stream turn {turn}: {:?}: {}",
                    status.code(),
                    status.message()
                )
            });
            let (sender, call) = client.stream_hello(Request::new(()));
            sender.close();
            call.await.unwrap_or_else(|status| {
                panic!(
                    "bidi turn {turn}: {:?}: {}",
                    status.code(),
                    status.message()
                )
            });
        }
    })
    .await
    .expect("bounded repeated early responses");
    server.abort();
}
