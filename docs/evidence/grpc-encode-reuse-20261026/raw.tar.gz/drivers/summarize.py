"""Derive per-RPC slopes and paired changes from every completed capture."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import statistics
import sys

root = Path(sys.argv[1]).resolve()
report = json.loads((root / "report.json").read_text())
assert report["passed"] and report["state"] == "complete"
assert len(report["runs"]) == report["expected_captures"]
groups = defaultdict(dict)
for row in report["runs"]:
    key = (json.dumps(row["cell"], sort_keys=True), row["repeat"], row["source"])
    assert row["count"] not in groups[key]
    run = json.loads((root / row["path"]).read_text())
    assert run["passed"] and row["count"] == run["metrics"]["successful_rpcs"]
    groups[key][row["count"]] = run
slopes = []
for (key, repeat, source), runs in groups.items():
    counts = sorted(runs)
    assert len(counts) == 2 and counts[1] == 2 * counts[0]
    lo, hi = (runs[n] for n in counts)
    denominator = counts[1] - counts[0]
    values = {}
    for side in ["client", "server"]:
        cpu = "client_lifetime_cpu_seconds" if side == "client" else "server_cpu_during_client_seconds"
        values[side] = {"cpu_seconds": (hi[cpu] - lo[cpu]) / denominator}
        if "allocation_totals" in hi:
            for metric in ["allocations", "requested_bytes"]:
                values[side][metric] = (hi["allocation_totals"][side][metric] - lo["allocation_totals"][side][metric]) / denominator
    slopes.append(dict(cell=json.loads(key), repeat=repeat, source=source, counts=counts, per_rpc=values))
comparisons = []
for key in sorted({key[0] for key in groups}):
    cell = json.loads(key)
    rows = [row for row in slopes if row["cell"] == cell]
    comparison = dict(cell=cell, endpoints={})
    for side in ["client", "server"]:
        comparison["endpoints"][side] = {}
        for metric in rows[0]["per_rpc"][side]:
            source_values = {source: {row["repeat"]: row["per_rpc"][side][metric] for row in rows if row["source"] == source} for source in ["baseline", "candidate"]}
            assert source_values["baseline"].keys() == source_values["candidate"].keys()
            before, after = (statistics.median(source_values[source].values()) for source in ["baseline", "candidate"])
            changes = [(source_values["candidate"][r] / value - 1) * 100 for r, value in source_values["baseline"].items() if value > 0]
            comparison["endpoints"][side][metric] = dict(baseline=before, candidate=after,
                values=source_values, median_change_percent=statistics.median(changes) if changes else None,
                min_change_percent=min(changes) if changes else None, max_change_percent=max(changes) if changes else None)
    comparisons.append(comparison)
result = dict(schema="pbrs.endpoint-slopes.v1", qualified=False,
              input_sha256=hashlib.sha256((root / "report.json").read_bytes()).hexdigest(),
              captures=len(report["runs"]), successful_rpcs=report["successful_rpcs"],
              slopes=slopes, comparisons=comparisons)
(root / "slopes.json").write_text(json.dumps(result, indent=2) + "\n")
for row in comparisons:
    cell = row["cell"]
    for side, index in [("client", 0), ("server", 2)]:
        if cell["pair"][index] != "native":
            continue
        metric = "requested_bytes" if "requested_bytes" in row["endpoints"][side] else "cpu_seconds"
        m = row["endpoints"][side][metric]
        scale = 1 / 1048576 if metric == "requested_bytes" else 1000000
        print(cell["compression"], cell["shape"], cell["payload_bytes"], cell.get("stream_messages", 4), cell.get("payload_pattern", "zero"), side, cell["pair"][index+1],
              round(m["baseline"]*scale, 4), round(m["candidate"]*scale, 4), m["median_change_percent"])
