"""Freeze the completed encode and streaming diagnostic record."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "docs/evidence/grpc-encode-reuse-20261026"
BASE = "e7595eb7640c60d5dfdaa708017ca9378e5e5332"
SOURCE = "1d773f9787efd5dd389bb0f9896ba88c2eb1898e"


def sha(data):
    return hashlib.sha256(data).hexdigest()


members = {}


def add(name, path):
    assert name not in members
    members[name] = path.read_bytes()


for name in ["baseline", "candidate", "final-candidate", "repaired-candidate", "bounded-output-candidate", "shipping-baseline", "shipping-candidate"]:
    for leaf in ["build.json", "build.stdout.jsonl", "build.stderr.log"]:
        add(f"builds/{name}/{leaf}", ROOT / "work/perf" / name / leaf)
for name in ["smoke", "comparison", "final-comparison", "bounded-output-comparison", "shipping-comparison"]:
    directory = ROOT / "work/perf" / name
    for path in sorted(directory.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts:
            add(f"measurements/{name}/{path.relative_to(directory).as_posix()}", path)
for path in sorted((ROOT / "work").glob("*.log")):
    add("validation/" + path.name, path)
for name in ["build_shipping.py", "compare_encode.py", "compare_shipping.py", "encode_smoke.py", "summarize.py", "package_evidence.py"]:
    add("drivers/" + name, ROOT / "work" / name)
for name in ["source-equivalence.json", "frozen-source-files.json", "frozen-workspace-summary.json", "final-source.bundle"]:
    add("source/" + name, ROOT / "work" / name)
for name in ["Cargo.toml", "Cargo.lock", "src/lib.rs"]:
    add("controls/closed-baseline/" + name, ROOT / "work/closed-control" / name)
equivalence = json.loads((ROOT / "work/source-equivalence.json").read_text())
for row in equivalence["files"]:
    name = row["path"]
    data = subprocess.check_output(["git", "show", SOURCE + ":" + name], cwd=ROOT)
    assert sha(data) == row["sha256"]
    members["source/candidate/" + name] = data
    previous = subprocess.run(["git", "show", BASE + ":" + name], cwd=ROOT, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    if previous.returncode == 0:
        members["source/baseline/" + name] = previous.stdout

alloc = json.loads((ROOT / "work/perf/bounded-output-comparison/slopes.json").read_text())
cpu = json.loads((ROOT / "work/perf/shipping-comparison/slopes.json").read_text())
workspace = json.loads((ROOT / "work/frozen-workspace-summary.json").read_text())
results = dict(schema="pbrs.encode-reuse-evidence.v1", qualified=False, production_ready=False,
    baseline=BASE, measured_source=SOURCE,
    scope="Linux x86_64 shared-host diagnostics; source pins remain separate from later changes",
    allocation=dict(captures=alloc["captures"], successful_rpcs=alloc["successful_rpcs"], failed_rpcs=0,
        report="measurements/bounded-output-comparison/report.json", slopes="measurements/bounded-output-comparison/slopes.json",
        comparisons=alloc["comparisons"]),
    shipping_cpu=dict(captures=cpu["captures"], successful_rpcs=cpu["successful_rpcs"], failed_rpcs=0,
        counters_enabled=False, repeats=3, cpu_resolution_seconds=0.01,
        report="measurements/shipping-comparison/report.json", slopes="measurements/shipping-comparison/slopes.json",
        comparisons=cpu["comparisons"], terminal_report_observed_after_reconnect=True),
    workspace=workspace, validation=dict(clippy_core_all_targets=True, clippy_native_and_new_integrations=True,
        rustdoc_workspace_all_features_warnings_denied=True, formatting=True,
        source_equivalence="source/source-equivalence.json"),
    reproduction=dict(bundle="source/final-source.bundle", base_required=BASE,
        archive_driver="drivers/package_evidence.py", executable_bytes_included=False),
    remaining=["No controlled-host CPU or latency qualification", "Native noise allocation and small pipeline losses remain",
        "Pbrs message materialization costs remain", "Official conformance records elsewhere keep their own source pins",
        "Full feature/platform/release and sustained-resource qualification remain open"])
assert workspace["failed"] == 0 and alloc["captures"] == 448 and cpu["captures"] == 180
(OUT / "results.json").write_text(json.dumps(results, indent=2) + "\n")
archive = OUT / "raw.tar.gz"
with tarfile.open(archive, "w:gz") as capsule:
    for name, data in sorted(members.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        capsule.addfile(info, io.BytesIO(data))
manifest = dict(schema="pbrs.evidence-manifest.v1", qualified=False, production_ready=False,
    archive=dict(name=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
    logical_bytes=sum(map(len, members.values())),
    files=[dict(path=name, bytes=len(data), sha256=sha(data)) for name, data in sorted(members.items())],
    publication_files=[dict(path=name, bytes=(OUT / name).stat().st_size, sha256=sha((OUT / name).read_bytes())) for name in ["README.md", "results.json", "check.py"]])
(OUT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print(f"packaged {len(members)} files, {archive.stat().st_size} archive bytes")
