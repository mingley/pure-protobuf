"""Counters-off endpoint CPU diagnostics. Shared-host timings are unqualified."""
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import platform
import random
import shutil
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


def verify(name):
    directory = ROOT / "work/perf" / ("shipping-" + name)
    source = ROOT / "work" / name
    helper = module("shipping_" + name, source / "scripts/build-rpc-bench.py")
    record = json.loads((directory / "build.json").read_text())
    assert record["source"] == helper.source_pin()
    assert record["allocation_counts"] is False and record["exit_code"] == 0
    assert record["command"] == ["cargo", "build", "--locked", "--release", "--manifest-path", "rpc-bench/Cargo.toml", "--message-format=json"]
    assert record["binary_sha256"] == digest(directory / "rpc-bench")
    for name, value in record["files"].items():
        assert digest(directory / name) == value
    messages = [json.loads(line) for line in (directory / "build.stdout.jsonl").read_text().splitlines()]
    assert str(helper.artifact(messages)) == record["build_executable"]
    assert set(record["tools"]) == {"cargo", "rustc"}
    return directory, source, record


def main():
    output = ROOT / "work/perf/shipping-comparison"
    output.mkdir(parents=True, exist_ok=False)
    helper = module("shipping_smoke", ROOT / "work/encode_smoke.py")
    builds = {name: verify(name) for name in ["baseline", "candidate"]}
    report = dict(schema="pbrs.shipping-comparison.v1", qualified=False,
                  host=platform.uname()._asdict(), builds={k: v[2] for k, v in builds.items()},
                  driver_sha256=digest(Path(__file__)), helper_sha256=digest(ROOT / "work/encode_smoke.py"),
                  limits=["Counters and profilers disabled; no dedicated-host timing qualification",
                          "Process CPU includes startup; paired N/2N slopes retain all repeats",
                          "Two Tokio workers, one connection, one RPC in flight, plaintext loopback"],
                  runs=[], state="running", passed=False)
    shutil.copy2(__file__, output / "driver.py")
    shutil.copy2(ROOT / "work/encode_smoke.py", output / "helper.py")
    pairs = [["native", "prost", "tonic", "prost"], ["tonic", "prost", "native", "prost"], ["tonic", "prost", "tonic", "prost"]]
    scopes = [dict(pair=pair, shape=shape, payload_bytes=1048576, payload_pattern=pattern,
                   tls=False, compression="gzip") for pair, shape, pattern in itertools.product(pairs, ["unary", "bidi"], ["zero", "noise"])]
    scopes += [dict(pair=pair, shape="unary", payload_bytes=1024, tls=False, compression="identity") for pair in pairs]
    groups = [(repeat, cell, count) for repeat in range(3) for cell in scopes
              for count in ([5000, 10000] if cell["payload_bytes"] == 1024 else [10, 20])]
    random.Random(260028).shuffle(groups)
    report["expected_captures"] = len(groups) * 2
    path = output / "report.json"
    path.write_text(json.dumps(report, indent=2) + "\n")
    for index, (repeat, cell, count) in enumerate(groups):
        for name in (["baseline", "candidate"] if index % 2 == 0 else ["candidate", "baseline"]):
            directory, source, _ = builds[name]
            args = SimpleNamespace(binary=directory / "rpc-bench", source_checkout=source,
                                   duration=60, rpc_count=count, allocation_counts=False,
                                   context_switches=False, callgrind=None, strace=None)
            capture = output / f"capture-{len(report['runs']):03d}"
            result = helper.run_cell(args, cell, capture)
            report["runs"].append(dict(source=name, repeat=repeat, count=count, cell=cell,
                                       path=str(capture.relative_to(output) / "run.json"), passed=result["passed"]))
            path.write_text(json.dumps(report, indent=2) + "\n")
            if not result["passed"]:
                report.update(state="failed", error=result.get("error"))
                path.write_text(json.dumps(report, indent=2) + "\n")
                raise RuntimeError(result.get("error"))
        if index % 4 == 0:
            print(f"{len(report['runs'])}/{report['expected_captures']} captures passed", flush=True)
    for name in builds:
        verify(name)
    report.update(state="complete", passed=True,
                  successful_rpcs=sum(row["count"] for row in report["runs"]))
    path.write_text(json.dumps(report, indent=2) + "\n")
    print(f"complete: {len(report['runs'])} captures, {report['successful_rpcs']} successful RPCs", flush=True)


if __name__ == "__main__":
    main()
