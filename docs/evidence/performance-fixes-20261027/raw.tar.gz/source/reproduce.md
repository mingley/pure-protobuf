# Reconstruct measured sources

Start from baseline `934bba317805356e11b58145f0068ad8279b0ae0` in an isolated checkout.
Apply source/server-repair.patch for the isolated server candidate.
Apply source/owned-profile-and-proofs.patch for the final public API and proofs.
The latter includes benchmark profile selection and untimed JSON metadata;
original frozen timings used the unchanged original timed loops.
For measured replicas, export only the Git paths listed in
work/fix-performance-round/benchmark/variant-files/reconstruction.json;
leave out an installed third_party checkout, which changes build.rs descriptor
inputs. For a specific frozen codec variant, overlay its exact changed files from
work/fix-performance-round/benchmark/variant-files on its documented source
chain. Source manifests describe every file hash; generated-code equivalence
records bind the final public Config API and Cargo feature to the selected
frozen parser output. Follow recorded harness/build scripts and lockfiles.

The rejected eager fixture originally lived at tests/proof/linear_decode;
restore it to that path in a disposable patched checkout before invoking
its Cargo.toml. It was moved under work only to retain the rejected design.

No executables, tool installations, build caches, or duplicate frozen full
source trees are included. Build elapsed times are provenance only: parallel
builds are not a codegen-speed comparison. Raw CPU campaigns are separate
from allocation and diagnostic profiler captures.
