import json,subprocess,time,importlib.util,os
from pathlib import Path
root=Path('/workspace/pure-protobuf');base=root/'work/server_cpu_fix';binary=root/'work/fix-performance-round/benchmark/server-candidate/rpc-shipping'
spec=importlib.util.spec_from_file_location('helper',root/'work/encode_smoke.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
for transport in ['native','tonic']:
 out=base/f'candidate-fdtrace-{transport}';out.mkdir(exist_ok=False)
 command=['strace','-D','-f','-yy','-e','trace=write,futex','-o',str(out/'server.strace'),str(binary),'load-server','--port=0',f'--transport={transport}','--codec=prost','--compression=identity']
 with (out/'server.stdout').open('w') as stdout,(out/'server.stderr').open('w') as stderr:
  env=dict(os.environ,TOKIO_WORKER_THREADS='2')
  server=subprocess.Popen(command,stdout=stdout,stderr=stderr,env=env)
  try:
   deadline=time.monotonic()+10;address=None
   while address is None and time.monotonic()<deadline:
    for line in (out/'server.stdout').read_text().splitlines():
     if line.startswith('READY '):address=next(v.split('=',1)[1] for v in line.split() if v.startswith('addr='))
    if address is None:time.sleep(.01)
   if address is None:raise RuntimeError('no server ready')
   client=[str(binary),'load','--transport=tonic','--codec=prost','--shape=unary','--req-bytes=1024','--resp-bytes=1024','--stream-msgs=4','--connections=1','--max-in-flight=1','--duration-secs=60','--compression=identity','--rpc-count=100',f'--server_addr={address}',f'--output={out/"metrics.json"}']
   result=subprocess.run(client,env=env,stdout=(out/'client.stdout').open('w'),stderr=(out/'client.stderr').open('w'),timeout=75)
   helper.validate_metrics(json.load(open(out/'metrics.json')))
   assert result.returncode==0
   (out/'commands.json').write_text(json.dumps({'server':command,'client':client,'client_exit':result.returncode,'environment':{'TOKIO_WORKER_THREADS':'2'}},indent=2)+'\n')
  finally:helper.stop(server)
