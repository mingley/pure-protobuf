import importlib.util,json,hashlib,os
from pathlib import Path
from types import SimpleNamespace
root=Path('/workspace/pure-protobuf');base=root/'work/server_cpu_fix'
spec=importlib.util.spec_from_file_location('smoke',root/'work/encode_smoke.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
output=base/'candidate-profile';output.mkdir(exist_ok=False)
raw=[]
for server in ['native','tonic']:
 for count in [200,400]:
  cell=dict(pair=['tonic','prost',server,'prost'],shape='unary',payload_bytes=1024,tls=False,compression='identity')
  args=SimpleNamespace(binary=root/'work/fix-performance-round/benchmark/server-candidate/rpc-shipping',source_checkout=root/'work/fix-performance-round/benchmark/server-source',duration=60,rpc_count=count,allocation_counts=False,context_switches=False,callgrind=base/'valgrind/usr/bin/valgrind',strace=None)
  result=helper.run_cell(args,cell,output/f'{server}-{count}')
  raw.append(dict(server=server,count=count,passed=result['passed'],instructions=result.get('instruction_totals'),error=result.get('error')))
  (output/'summary.json').write_text(json.dumps(raw,indent=2)+'\n');print(raw[-1],flush=True)
  if not result['passed']:raise SystemExit(1)
