# Native unary scheduler cost

Baseline shipping source is c1f7e9b4, production-equivalent to 934bba31. The
frozen executable/build record remains under work/proof-rpc/build. A separate
candidate source contains 934bba31 plus only server.rs, server/connection.rs and
new server/coalesced.rs; core decoder/codegen changes are excluded.

Baseline instrumented native/prost server N200/400 gives 42,707.3 simulated
instructions/RPC versus tonic/prost 55,744.815. The native shipping CPU loss is
therefore not explained by higher simulated instruction counts. Selected
shipping N20000 raw process CPU shows native user/system 0.25/0.67 seconds and
control 0.23/0.38, pointing to system work.

Strace N1000/2000, two workers, gives native server incremental futex 5.043,
write 1.1, writev 1.0, sendto 1.0, recvfrom 2.337, epoll_wait 3.544 per RPC.
Tonic gives 0 futex, approximately zero write, writev 2.0, no sendto,
recvfrom 1.751, epoll_wait 2.403. These are scheduling-dependent observations;
tracing changes scheduling and timings are not shipping measurements.

A separate FD-aware trace verifies write calls reach eventfds, not merely
stdout. With two workers and 100 successful RPCs, native has 37 eventfd write
entries and 176 futex entries, control 1 and 6. The earlier default-worker
FD trace is also retained, separately named. The counts vary; no fixed cost
per RPC is inferred from these short traces.

The candidate wraps each complete connection future with a cached proxy
waker and atomic POLLING/NOTIFIED/CLOSED state. Wakes during an active poll are
recorded rather than immediately scheduling the runtime owner. The future
repolls locally at most four times, stops when Tokio's cooperative budget is
exhausted, then forwards the notification. Idle wakes forward immediately.
Ready/drop releases the stored parent waker. This adds one Arc allocation per
connection, no allocation per RPC; CPU/memory effects require measurement.

The narrower hypothesis that FuturesUnordered::push unconditionally wakes
its parent was rejected by inspection of locked futures-util 0.3.34: push only
enqueues. Child wake propagation and ready-set yielding are the relevant
notification sources. No push-suppression hack was implemented.

Six coalescer tests pass, covering consumed self-wakes, finite poll batches,
external wakes, 256 return-Pending races, changed parent wakers, late wake/drop
retention and panic cleanup. Seven focused native suites pass 106 tests:
lifecycle, resource bounds (including mixed gzip, fairness and slow readers),
message sizes, retry safety, deadline admission, server deadline and extended
server deadline. Strict all-feature library Clippy passes. Paired shipping CPU is collected independently by the benchmark agent.
The isolated server candidate improves unary server CPU in all five matched
before/after pairs (median paired ratio 0.452); its displayed independent
medians are 45 and 23.5 µs/RPC. Fresh tonic ratios vary and do not establish
world leadership.

Candidate instrumentation confirms the scheduling hypothesis: native futex
N/2N slope 5.043 → 0/RPC and write slope 1.1 → 0, while total wire writes
remain 2/RPC. FD-aware 100-call observations fall from 37 eventfd writes and
176 futex entries to 1 and 6, equal to the fresh tonic observation.
Simulated native instructions fall 42,707.3 → 40,363.165/RPC (−5.49%);
fresh tonic rises 55,744.815 → 57,971.005 (+4.0%), showing scheduling/control
variance. Native recvfrom slopes increase 2.337 → 3.896 and tonic 1.751 →
2.888; these losses/variations remain recorded. No all-syscall reduction is
claimed. Instrumentation contains one N/2N pair per source/peer and candidate
profiles overlap unrelated compilation. Their timings are not shipping CPU.
All source/binary/controller hashes and raw files are retained.
