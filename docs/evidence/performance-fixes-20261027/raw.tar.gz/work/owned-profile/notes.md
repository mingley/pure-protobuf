# Explicit owned message profile

`Config::owned_message_fields(true)` and `owned_message_fields=true` plugin
parameters select ordinary checked owning storage for singular message fields.
The default remains false. No runtime materialization hook or validation bypass
is used. The private encoded-size cache uses `CachedSize32` only in the owned
profile; the default emits the exact previous `CachedSize` spelling and layout.
The runtime helper keeps its u64 interface and leaves oversized values uncached.

The profile is useful when applications read or mutate most of a nested tree.
Default lazy fields can save parse work/memory when unread; owned fields can
increase cached serialization work by rebuilding child wire. Both retain the
same accessors, protocol semantics, formats and limits. Imported or mapped
child types must be generated with the same profile for complete eager trees.
The guide and public builder Rustdoc explain these choices without claiming
performance before measurement.

Three new unit controls cover builder/plugin precedence and invalid values,
two-target field/cache layout plus default/false byte identity after an owned
request, and worker TLS publication/drop reset. All 22 codegen unit tests pass.
Strict all-features pbrs library Clippy passes. Logs and source hashes are in
this directory. Independent same-schema, required/merge/map/group/format
consumer controls are owned by linear_decode, and frozen CPU/allocation
measurements are owned by benchmark_validation.

OwnedV1 was frozen before the private cache selection. OwnedV2 is a separate
frozen variant using the actual public API and CachedSize32. Do not merge their
results. The preceding output-buffer move and eager-on-getter prototypes were
rejected; their raw records remain under work/codegen_output.
