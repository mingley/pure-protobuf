"""Validate final performance repair source, preserving every result."""
import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'work/fix-performance-round/validation';out.mkdir(exist_ok=False)
def git(*a):return subprocess.check_output(['git',*a],cwd=root,text=True).strip()
# Documentation/evidence may be completed while this runs. Production and test
# inputs must remain byte-identical to the recorded commit throughout.
paths=['src','pbrs-grpc','protobuf-tonic','rpc-bench','tests','scripts','Cargo.toml','Cargo.lock','build.rs','proto','examples','.cargo']
def inputs():
 files=subprocess.check_output(['git','ls-files','-z','--',*paths],cwd=root).split(b'\0')
 return {p.decode():hashlib.sha256((root/p.decode()).read_bytes()).hexdigest() for p in files if p and (root/p.decode()).is_file()}
before=inputs();source=git('rev-parse','HEAD')
if git('diff','HEAD','--',*paths):raise SystemExit('code/test inputs must be committed')
report=dict(source=source,input_sha256=before,checks=[],complete=False)
commands=[
('format',['cargo','fmt','--all','--check'],0),
('workspace',['cargo','test','--locked','--workspace','--all-features'],0),
('core-clippy',['cargo','clippy','--locked','-p','pbrs','--all-targets','--all-features','--','-D','warnings'],0),
('transport-clippy',['cargo','clippy','--locked','--lib','--all-features','-p','pbrs-grpc','-p','protobuf-tonic','-p','pbrs-grpc-example-greeter','--','-D','warnings'],0),
('owned-consumer',['cargo','run','--locked','--manifest-path','tests/proof/owned_messages/Cargo.toml'],0),
('owned-clippy',['cargo','clippy','--locked','--manifest-path','tests/proof/owned_messages/Cargo.toml','--','-D','warnings'],0),
('message-presence',['cargo','test','--locked','--manifest-path','tests/proof/tonic_parity/Cargo.toml','--','--nocapture'],0),
('mixed-peers',['cargo','test','--locked','--manifest-path','tests/interop/tonic/Cargo.toml','--tests'],0),
('prost-known',['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml','--','--check-known-differences'],0),
('prost-strict',['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml'],1),
('prost-tests',['cargo','test','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml'],0),
('prost-owned-known',['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml','--features','owned-messages','--','--check-known-differences'],0),
('prost-owned-strict',['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml','--features','owned-messages'],1),
('prost-owned-tests',['cargo','test','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml','--features','owned-messages'],0),
('codegen-proof',['python3','tests/proof/codegen_parity/run.py','--output',str(out/'codegen')],0),
('claim-checker',['python3','-B','-m','unittest','tests.test_performance_claim','-q'],0),
('msrv-native',['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--lib'],0),
('msrv-tower',['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--features','tower','--lib'],0),
('msrv-owned',['cargo','+1.85.0','check','--locked','--manifest-path','tests/proof/owned_messages/Cargo.toml'],0),
('conformance',['./scripts/conformance.sh'],0),
('regenerate',['./scripts/regen-generated.sh','--check'],0),
('docs',['cargo','test','--locked','--test','documentation','--','--nocapture'],0),
]
for name,cmd,expected in commands:
 env=dict(os.environ)
 if name.startswith('msrv-'):env.update(CARGO_TARGET_DIR=str(root/'work/msrv-target'),CARGO_BUILD_JOBS='1')
 if name=='conformance':env.update(CONFORMANCE_OUTPUT_DIR=str(out/'conformance'),NPROC='2')
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exit_code=r.returncode,expected_exit=expected,seconds=time.monotonic()-start,log=name+'.log')
 report['checks'].append(row);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode!=expected:
  print((out/(name+'.log')).read_text()[-15000:],flush=True);raise SystemExit(1)
 if name.endswith('strict'):
  last=next(l for l in reversed((out/(name+'.log')).read_text().splitlines()) if l.startswith('{'))
  summary=json.loads(last);assert summary['known_differences_match'] is True and summary['parity_equivalent'] is False
 if inputs()!=before:raise SystemExit('production/test input changed during validation')
report.update(complete=True,inputs_unchanged=True)
text=(out/'workspace.log').read_text();counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
report['workspace_test_counts']=dict(zip(['passed','failed','ignored'],map(sum,zip(*counts))))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
