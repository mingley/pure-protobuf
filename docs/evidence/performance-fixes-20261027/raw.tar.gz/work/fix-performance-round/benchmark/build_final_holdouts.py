"""Prepare and freeze final-profile partial/encode holdouts; no core mutations."""
import argparse,hashlib,json,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--variant',required=True);args=p.parse_args()
source=BASE/(args.variant+'-source')
for kind,helper,binary in [('partial','prepare_partial.py','pbrs-partial-getter-proof'),('encode','prepare_encode.py','pbrs-encode-proof')]:
 harness=BASE/(kind+'-'+args.variant)
 subprocess.run(['python3',str(BASE/helper),'--source',str(source),'--output',str(harness)],cwd=ROOT,check=True)
 build=harness/'build.rs';text=build.read_text();assert text.count('pbrs::codegen::Config::new()')==1
 build.write_text(text.replace('pbrs::codegen::Config::new()','pbrs::codegen::Config::new().owned_message_fields(true)'))
 prepared=BASE/(harness.name+'-prepared.json');data=json.loads(prepared.read_text());data['profile']='owned_message_fields(true)';data['files']={str(f.relative_to(harness)):hashlib.sha256(f.read_bytes()).hexdigest() for f in harness.rglob('*') if f.is_file()};prepared.write_text(json.dumps(data,indent=2)+'\n')
 for mode in ('shipping','allocations'):
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(source),'--manifest',str(harness/'Cargo.toml'),'--binary-name',binary,
       '--mode',mode,'--output',str(BASE/(args.variant+'-'+kind)),'--record-key','codec-'+mode]
  print(json.dumps(dict(command=cmd)),flush=True)
  subprocess.run(cmd,cwd=ROOT,check=True)
print('final_holdouts_build_complete',flush=True)
