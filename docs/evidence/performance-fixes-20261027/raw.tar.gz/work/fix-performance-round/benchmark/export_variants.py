"""Retain exact changed source files without duplicating frozen baseline trees."""
from pathlib import Path
import hashlib,json,shutil
BASE=Path(__file__).resolve().parent
out=BASE/'variant-files';out.mkdir(exist_ok=True)
record={}
for name in ['server-source','codec-source','owned-source','owned-v2-source','owned-v3-stack-source','owned-v3-heap-source','owned-v4-source']:
 manifest=BASE/(name+'-source.json')
 if not manifest.exists():continue
 values=json.loads(manifest.read_text());record[name]={}
 for path,value in values['declared_changes'].items():
  source=BASE/name/path;digest=hashlib.sha256(source.read_bytes()).hexdigest()
  assert digest==value['new_sha256'],(name,path)
  dest=out/name/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(source,dest)
  record[name][path]=value
(out/'manifest.json').write_text(json.dumps(record,indent=2)+'\n')
print({key:len(value) for key,value in record.items()})
