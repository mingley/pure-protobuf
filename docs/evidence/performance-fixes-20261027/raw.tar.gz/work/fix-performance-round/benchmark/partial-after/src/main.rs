//! Partial-access holdout; visits only root and its first child in timing.
use pbrs::{Parse,Serialize};
use prost::Message;
use std::hint::black_box;
#[allow(dead_code, unused, nonstandard_style, clippy::all)]
mod p { include!(concat!(env!("OUT_DIR"),"/pbrs/partial-getter.rs")); }
#[allow(dead_code, clippy::all)]
mod r { include!(concat!(env!("OUT_DIR"),"/prost/partial.rs")); }
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    pub static ENABLED: AtomicBool = AtomicBool::new(false);
    pub static CALLS: AtomicU64 = AtomicU64::new(0);
    pub static BYTES: AtomicU64 = AtomicU64::new(0);
    pub struct Alloc;
    unsafe impl GlobalAlloc for Alloc {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc_zeroed(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new: usize) -> *mut u8 {
            let result = unsafe { System.realloc(ptr, old, new) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(new as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC: count::Alloc = count::Alloc;

fn cpu_ns() -> u128 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: ts is a valid timespec out pointer and PROCESS_CPUTIME_ID is read-only.
    assert_eq!(
        unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) },
        0
    );
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}

fn node(depth:i32)->r::Node { r::Node { n:depth,child:(depth>1).then(||Box::new(node(depth-1))) } }
fn hash(bytes:&[u8])->String { format!("{:016x}",bytes.iter().fold(0xcbf29ce484222325u64,|h,b|(h^u64::from(*b)).wrapping_mul(0x100000001b3))) }
fn main() {
 let args:Vec<_>=std::env::args().collect(); assert_eq!(args.len(),6);
 let depth=match args[1].as_str(){"nested_8"=>8,"nested_64"=>64,_=>panic!("unknown fixture")};
 let backend=args[2].as_str();assert!(backend=="pbrs"||backend=="prost");assert_eq!(args[3],"read_first_child");
 let iterations:u64=args[4].parse().unwrap();let samples:usize=args[5].parse().unwrap();assert!(iterations>0&&samples>0);
 let reference=node(depth);let wire=reference.encode_to_vec();
 let native=p::Node::parse(&wire).unwrap();assert_eq!(r::Node::decode(native.serialize().unwrap().as_slice()).unwrap(),reference);
 let mut child=&native;let mut full=child.n() as u64;let mut count=1;
 while child.has_child(){child=child.child();full+=child.n() as u64;count+=1;}
 assert_eq!(count,depth);assert_eq!(full,(depth*(depth+1)/2) as u64);
 let checksum=(2*depth-1) as u64;
 let execute=||{
  if backend=="pbrs" {let message=p::Node::parse(black_box(&wire)).unwrap();assert!(message.has_child());black_box(message.n() as u64+message.child().n() as u64);black_box(message);}
  else {let message=r::Node::decode(black_box(wire.as_slice())).unwrap();black_box(message.n as u64+message.child.as_ref().unwrap().n as u64);black_box(message);}
 };
 for _ in 0..(iterations/10).max(1){execute();}
 let mut values=Vec::with_capacity(samples);
 for _ in 0..samples {
  #[cfg(feature="allocations")] count::start();
  let start=cpu_ns();let wall=std::time::Instant::now();for _ in 0..iterations{execute();}let wall_ns=wall.elapsed().as_nanos();let cpu=cpu_ns()-start;
  #[cfg(feature="allocations")] let(allocations,requested)=count::stop();
  #[cfg(not(feature="allocations"))] let(allocations,requested)=(None::<u64>,None::<u64>);
  values.push(serde_json::json!({"cpu_ns":cpu,"wall_ns":wall_ns,"iterations":iterations,"allocation_calls":allocations,"requested_bytes":requested}));
 }
 println!("{}",serde_json::json!({"schema":"partial-getter-proof/1","case":args[1],"backend":backend,"operation":"read_first_child","wire_bytes":wire.len(),"wire_fnv1a64":hash(&wire),"checksum":checksum,"semantic_prechecks":true,"allocation_instrumentation":cfg!(feature="allocations"),"samples":values,"full_fixture_checksum":full,"visited_in_timing":"root.n and first child.n only; drop fullownedresult"}));
}
