"""Copy only declared stable candidate files onto the frozen baseline."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[3]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--base',type=Path,required=True);p.add_argument('--output',type=Path,required=True);p.add_argument('files',nargs='+')
 args=p.parse_args();base=args.base.resolve();out=args.output.resolve()
 if out.exists():raise ValueError('Snapshot already exists')
 before={name:sha(ROOT/name) for name in args.files}
 shutil.copytree(base,out)
 changed={}
 for name in args.files:
  original=base/name;dest=out/name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/name,dest)
  changed[name]=dict(old_sha256=sha(original) if original.exists() else None,new_sha256=sha(dest))
 after={name:sha(ROOT/name) for name in args.files}
 if before!=after or before!={name:row['new_sha256'] for name,row in changed.items()}:raise ValueError('Candidate files changed during snapshot')
 record=dict(schema='pbrs.performance-variant-source.v1',baseline='934bba317805356e11b58145f0068ad8279b0ae0',
             baseline_snapshot=str(base),source=str(out),declared_changes=changed,
             files={str(path.relative_to(out)):sha(path) for path in sorted(out.rglob('*')) if path.is_file()},
             baseline_manifest_sha256=sha(base.parent/(base.name+'-source.json')))
 dest=out.parent/(out.name+'-source.json');dest.write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(dict(source=str(out),changes=changed,files=len(record['files']))))
if __name__=='__main__':main()
