"""Build both actual-API fused-parser allocation strategies in isolation."""
from pathlib import Path
import json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
for variant in ('stack','heap'):
 for mode in ('shipping','allocations'):
  source=BASE/f'owned-v3-{variant}-source';output=BASE/f'owned-v3-{variant}-candidate'
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(source),'--manifest',str(source/'tests/proof/codec_benchmark/Cargo.toml'),
       '--binary-name','pbrs-codec-proof','--mode',mode,'--output',str(output),'--record-key','codec-'+mode]
  print(json.dumps(dict(command=cmd)),flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  if result.returncode:raise SystemExit(result.returncode)
print('owned_v3_builds_complete',flush=True)
