"""Sequential remaining probe builds; no timings or profile claims here."""
import json
from pathlib import Path
import subprocess
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
commands=[]
def command(source,manifest,binary,mode,output,key):
 return ['python3',str(BASE/'build_probe.py'),'--source',str(BASE/source),'--manifest',str(BASE/manifest),'--binary-name',binary,'--mode',mode,'--output',str(BASE/output),'--record-key',key]
commands.append(command('codec-source','codec-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof','allocations','codec-candidate','codec-allocations'))
for mode in ('shipping','allocations'):
 commands.append(command('baseline-source','baseline-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof',mode,'baseline-refreshed','codec-'+mode))
for mode in ('shipping','allocations'):
 commands.append(command('codec-source','partial-after/Cargo.toml','pbrs-partial-getter-proof',mode,'candidate-partial','codec-'+mode))
for index,cmd in enumerate(commands):
 print(json.dumps(dict(index=index,command=cmd)),flush=True)
 result=subprocess.run(cmd,cwd=ROOT)
 if result.returncode:raise SystemExit(result.returncode)
print('all_remaining_builds_complete',flush=True)
