"""Build and freeze a benchmark executable from an immutable source snapshot."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def snapshot(source):
 return {str(p.relative_to(source)):sha(p) for p in sorted(source.rglob('*')) if p.is_file() and not any(x in ('target','.git','__pycache__') for x in p.relative_to(source).parts)}
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--source',type=Path,required=True);p.add_argument('--manifest',type=Path,required=True)
 p.add_argument('--binary-name',required=True);p.add_argument('--mode',choices=['shipping','allocations'],required=True)
 p.add_argument('--output',type=Path,required=True);p.add_argument('--record-key',required=True)
 args=p.parse_args();source=args.source.resolve();manifest=args.manifest.resolve();out=args.output.resolve();out.mkdir(parents=True,exist_ok=True)
 name=args.record_key;recordpath=out/(name+'-build.json')
 if recordpath.exists():raise ValueError('Build already recorded; choose new output')
 before=snapshot(source);package=manifest.parent
 harness={str(path.relative_to(package)):sha(path) for path in sorted(package.rglob('*')) if path.is_file() and path.name!='Cargo.lock' and not any(x in ('target','.git','__pycache__') for x in path.relative_to(package).parts)}
 cmd=['cargo','build','--locked','--offline','--release','--manifest-path',str(manifest)]
 if args.mode=='allocations':cmd+=['--features','allocations']
 cmd+=['--message-format=json']
 started=datetime.now(timezone.utc).isoformat();timer=time.monotonic()
 with (out/(name+'.jsonl')).open('w') as stdout,(out/(name+'.stderr')).open('w') as stderr:
  result=subprocess.run(cmd,cwd=source,stdout=stdout,stderr=stderr)
 record=dict(schema='pbrs.frozen-probe-build.v1',command=cmd,started=started,ended=datetime.now(timezone.utc).isoformat(),
             elapsed_seconds=time.monotonic()-timer,exit_code=result.returncode,source=str(source),source_files=before,
             manifest=str(manifest),harness_files=harness,cargo_lock_sha256=sha(package/'Cargo.lock'),mode=args.mode,
             environment={key:os.environ.get(key) for key in ('CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','RUSTFLAGS')},
             logs={name+suffix:sha(out/(name+suffix)) for suffix in ('.jsonl','.stderr')})
 record['source_unchanged']=before==snapshot(source)
 record['harness_unchanged']=all((package/name).exists() and sha(package/name)==value for name,value in harness.items())
 recordpath.write_text(json.dumps(record,indent=2)+'\n')
 if result.returncode!=0:raise ValueError('Build failed; logs retained')
 if not record['source_unchanged'] or not record['harness_unchanged']:raise ValueError('Source changed during build')
 messages=[json.loads(line) for line in (out/(name+'.jsonl')).read_text().splitlines()]
 artifacts=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')==args.binary_name and m.get('executable')]
 if len(artifacts)!=1 or artifacts[0].get('features')!=(['allocations','default'] if args.mode=='allocations' else ['default']):
  # Some standalone probes define no explicit default feature, so Cargo records
  # an empty list (or only allocations). Neither may enable other features.
  if len(artifacts)!=1 or set(artifacts[0].get('features',[]))!=({'allocations'} if args.mode=='allocations' else set()):
   raise ValueError('Ambiguous executable or instrumentation feature mismatch')
 binary=out/name;shutil.copy2(artifacts[0]['executable'],binary)
 record.update(binary_sha256=sha(binary),binary=str(binary),build_executable=artifacts[0]['executable'],features=artifacts[0]['features'])
 recordpath.write_text(json.dumps(record,indent=2)+'\n')
 aggregatepath=out/'source.json';aggregate=json.loads(aggregatepath.read_text()) if aggregatepath.exists() else dict(schema='pbrs.frozen-probe-binaries.v1',source=str(source),binaries={})
 aggregate['binaries'][name]=dict(path=str(binary),sha256=record['binary_sha256'],build_record=recordpath.name)
 aggregatepath.write_text(json.dumps(aggregate,indent=2)+'\n')
 print(json.dumps(dict(binary=str(binary),sha256=record['binary_sha256'],seconds=record['elapsed_seconds'])),flush=True)
if __name__=='__main__':main()
