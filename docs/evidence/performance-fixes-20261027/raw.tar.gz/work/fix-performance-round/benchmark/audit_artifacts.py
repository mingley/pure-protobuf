"""Retain actual generated outputs and executable section sizes for each probe."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows={}
for name,package in [('baseline-refreshed','pbrs-codec-proof'),('codec-candidate','pbrs-codec-proof'),('baseline-partial','pbrs-partial-getter-proof'),('candidate-partial','pbrs-partial-getter-proof')]:
 out=BASE/name;rows[name]={}
 for mode in ('shipping','allocations'):
  key='codec-'+mode;record=json.loads((out/(key+'-build.json')).read_text())
  messages=[json.loads(line) for line in (out/(key+'.jsonl')).read_text().splitlines()]
  entries=[entry for entry in messages if entry.get('reason')=='build-script-executed' and package in entry.get('package_id','')]
  if len(entries)!=1:raise ValueError((name,mode,entries))
  generated=Path(entries[0]['out_dir']);files={}
  target=out/'generated'/mode;target.mkdir(parents=True,exist_ok=True)
  for peer in ('pbrs','prost'):
   inputs=list((generated/peer).glob('*.rs'))
   for source in inputs:
    dest=target/(peer+'-'+source.name);shutil.copy2(source,dest)
    files[peer+'/'+source.name]=dict(path=str(source),bytes=source.stat().st_size,sha256=sha(source))
  binary=out/key;result=subprocess.run(['size',str(binary)],capture_output=True,text=True)
  (out/(key+'-size.stdout')).write_text(result.stdout);(out/(key+'-size.stderr')).write_text(result.stderr)
  rows[name][mode]=dict(binary_bytes=binary.stat().st_size,binary_sha256=sha(binary),generated=files,
                         build_elapsed_seconds_not_comparable=record['elapsed_seconds'],size_output=result.stdout)
(BASE/'artifact-sizes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ('baseline-refreshed','codec-candidate'):
 print(name,rows[name]['shipping']['size_output'].strip())
 print(rows[name]['shipping']['generated'])
