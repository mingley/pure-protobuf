"""Build isolated checked owned-child storage profiles without sharedroot changes."""
from pathlib import Path
import json,subprocess
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
for profile,manifest,binary in [('owned-candidate','owned-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof'),('owned-partial','partial-owned/Cargo.toml','pbrs-partial-getter-proof')]:
 for mode in ('shipping','allocations'):
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(BASE/'owned-source'),'--manifest',str(BASE/manifest),
       '--binary-name',binary,'--mode',mode,'--output',str(BASE/profile),'--record-key','codec-'+mode]
  print(json.dumps(dict(command=cmd)),flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  if result.returncode:raise SystemExit(result.returncode)
print('owned_builds_complete',flush=True)
