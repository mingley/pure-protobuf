"""Capture exact generated Rust bound by Cargo artifacts and literal ELF .text sizes.

Build elapsed times are provenance only: builds overlapped semantic checks and
reuse caches. GNU size's aggregate text column is not the .text section.
"""
import argparse,hashlib,json,shutil,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
p=argparse.ArgumentParser(description=__doc__);p.add_argument('names',nargs='+');args=p.parse_args()
path=BASE/'final-artifact-sizes.json';rows=json.loads(path.read_text()) if path.exists() else {}
for name in args.names:
 out=BASE/name;rows[name]={}
 for mode in ('shipping','allocations'):
  key='codec-'+mode;record=json.loads((out/(key+'-build.json')).read_text());assert sha(out/key)==record['binary_sha256']
  messages=[json.loads(line) for line in (out/(key+'.jsonl')).read_text().splitlines()]
  manifest=Path(record['manifest']);package=next(line.split('=',1)[1].strip().strip('"') for line in manifest.read_text().splitlines() if line.startswith('name'))
  entries=[entry for entry in messages if entry.get('reason')=='build-script-executed' and package in entry.get('package_id','')];assert len(entries)==1,(name,mode,entries)
  generated=Path(entries[0]['out_dir']);files={};target=out/'generated'/mode;target.mkdir(parents=True,exist_ok=True)
  for peer in ('pbrs','prost'):
   for source in (generated/peer).glob('*.rs'):
    shutil.copy2(source,target/(peer+'-'+source.name));files[peer+'/'+source.name]=dict(path=str(source),bytes=source.stat().st_size,sha256=sha(source))
  binary=out/key;size=subprocess.run(['size',str(binary)],capture_output=True,text=True,check=True);(out/(key+'-size.stdout')).write_text(size.stdout)
  elf=subprocess.run(['readelf','-SW',str(binary)],capture_output=True,text=True,check=True);(out/(key+'-readelf.stdout')).write_text(elf.stdout)
  text=next(line for line in elf.stdout.splitlines() if '.text ' in line).split();pos=text.index('.text');text_bytes=int(text[pos+4],16)
  rows[name][mode]=dict(binary_bytes=binary.stat().st_size,binary_sha256=sha(binary),generated=files,elf_text_bytes=text_bytes,
   build_elapsed_seconds_not_comparable=record['elapsed_seconds'],size_output=size.stdout)
path.write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({name:{mode:dict(binary_bytes=row['binary_bytes'],elf_text_bytes=row['elf_text_bytes'],generated=row['generated']) for mode,row in rows[name].items()} for name in args.names},indent=2))
