"""Build identical encoder holdouts against old and owned-child storage cores."""
import json,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
for profile,source,manifest in [('baseline-encode','baseline-source','encode-before/Cargo.toml'),('owned-encode','owned-source','encode-owned/Cargo.toml')]:
 for mode in ('shipping','allocations'):
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(BASE/source),'--manifest',str(BASE/manifest),'--binary-name','pbrs-encode-proof',
       '--mode',mode,'--output',str(BASE/profile),'--record-key','codec-'+mode]
  print(json.dumps(dict(command=cmd)),flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  if result.returncode:raise SystemExit(result.returncode)
print('encode_builds_complete',flush=True)
