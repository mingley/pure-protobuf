"""Bind existing frozen executables to the new round's committed baseline."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

ROOT=Path(__file__).resolve().parents[3]
OUT=Path(__file__).resolve().parent/'baseline'
COMMIT='934bba317805356e11b58145f0068ad8279b0ae0'
sha=lambda value:hashlib.sha256(value).hexdigest()
def blob(name):
    return subprocess.check_output(['git','show',f'{COMMIT}:{name}'],cwd=ROOT)
def save(name,data):
    (OUT/name).write_text(json.dumps(data,indent=2)+'\n')
OUT.mkdir(exist_ok=True)
if (OUT/'source.json').exists():raise ValueError('Baseline already frozen')
codec_source=json.loads((ROOT/'work/proof-codec/source-after-measurement.json').read_text())
compared={}
for name,value in codec_source['files'].items():
    actual=sha(blob(name))
    if actual!=value:raise ValueError(f'Codec source changed at baseline: {name}')
    compared[name]=actual
codec_manifest=json.loads((ROOT/'work/proof-codec/campaign/manifest.json').read_text())
review=json.loads((ROOT/'work/proof-review/followup-review.json').read_text())
probe={}
for name in ['tests/proof/codec_benchmark/src/main.rs','tests/proof/codec_benchmark/measure.py']:
    actual=sha(blob(name))
    if actual!=review['source_sha256'][name]:raise ValueError(f'Codec harness changed: {name}')
    probe[name]=actual
for name in ['tests/proof/codec_benchmark/Cargo.toml','tests/proof/codec_benchmark/Cargo.lock','tests/proof/codec_benchmark/build.rs']:
    probe[name]=sha(blob(name))
records={}
for key,name,expected in [('codec-shipping','work/proof-codec/shipping',codec_manifest['shipping_sha256']),('codec-allocations','work/proof-codec/allocations',codec_manifest['allocation_sha256'])]:
    src=ROOT/name
    if sha(src.read_bytes())!=expected:raise ValueError(f'Frozen binary changed: {name}')
    dest=OUT/key
    shutil.copy2(src,dest)
    records[key]=dict(path=str(dest),sha256=expected,original=name)
rpc=json.loads((ROOT/'work/proof-rpc/build/build.json').read_text())
rpc_base=rpc['source']['commit']
paths=['Cargo.toml','Cargo.lock','build.rs','src','proto','vendor','pbrs-grpc','protobuf-tonic','rpc-bench']
difference=subprocess.check_output(['git','diff',rpc_base,COMMIT,'--',*paths],cwd=ROOT)
if difference:raise ValueError('RPC production source differs from frozen build')
for name,value in rpc['files'].items():
    if sha((ROOT/'work/proof-rpc/build'/name).read_bytes())!=value:raise ValueError(f'RPC build log changed: {name}')
src=ROOT/'work/proof-rpc/build/rpc-bench'
if sha(src.read_bytes())!=rpc['binary_sha256']:raise ValueError('Frozen RPC binary changed')
shutil.copy2(src,OUT/'rpc-shipping')
records['rpc-shipping']=dict(path=str(OUT/'rpc-shipping'),sha256=rpc['binary_sha256'],original='work/proof-rpc/build/rpc-bench')
for source,dest in [('work/proof-codec/environment.json','codec-environment.json'),('work/proof-codec/campaign/manifest.json','codec-original-manifest.json'),('work/proof-rpc/build/build.json','rpc-build.json')]:
    shutil.copy2(ROOT/source,OUT/dest)
save('source.json',dict(schema='pbrs.performance-fix-baseline.v1',baseline=COMMIT,
                       codec_original_source=json.loads((ROOT/'work/proof-codec/source-before.json').read_text())['commit'],codec_core_sha256=compared,
                       codec_harness_sha256=probe,rpc_original_source=rpc_base,
                       rpc_shipping_source_unchanged=True,binaries=records,
                       notes=['Existing frozen binaries reused with cryptographic source equivalence checks.',
                              'Codec original builds predate committed harness but independent review hashes bind main and driver.',
                              'No source tree or build target duplicated. New binaries copied to immutable task-specific names.']))
print(json.dumps(dict(baseline=COMMIT,verified_codec_files=len(compared),binaries={key:item['sha256'] for key,item in records.items()}),indent=2))
