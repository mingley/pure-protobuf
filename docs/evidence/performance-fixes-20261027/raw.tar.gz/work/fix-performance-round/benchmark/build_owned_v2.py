"""Build actual public Owned API + compact cache + checked heap staging."""
from pathlib import Path
import json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
for profile,manifest,binary in [('owned-v2-candidate','owned-v2-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof'),('owned-v2-partial','partial-owned-v2/Cargo.toml','pbrs-partial-getter-proof'),('owned-v2-encode','encode-owned-v2/Cargo.toml','pbrs-encode-proof')]:
 for mode in ('shipping','allocations'):
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(BASE/'owned-v2-source'),'--manifest',str(BASE/manifest),'--binary-name',binary,
       '--mode',mode,'--output',str(BASE/profile),'--record-key','codec-'+mode]
  print(json.dumps(dict(command=cmd)),flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  if result.returncode:raise SystemExit(result.returncode)
print('owned_v2_builds_complete',flush=True)
