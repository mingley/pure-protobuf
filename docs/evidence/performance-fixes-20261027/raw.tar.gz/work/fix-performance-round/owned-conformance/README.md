# Owned-profile official conformance

This campaign checks the optional owned nested-message profile against the
pinned Google protobuf conformance runner. It regenerates every registered
bundled binding with `shared_pool=true,owned_message_fields=true` in an isolated
snapshot of commit `ec13f154518cba8cc896e9988f0baf8f7d5f44ef`. The live checkout's
bindings stay unchanged.

`run.py` records the selected source paths, source hashes before and after
regeneration, all upstream proto input hashes, the 13 output hashes, the
handwritten module registry hash, compiler and runner hashes, generation
commands, Cargo artifact records and runner commands. Cargo's JSON artifact
record selects each executable; the selected executables are copied before
use, so a later shared-target build cannot replace them during this campaign.
`owned-generated.patch` records the complete generated-source changes.

The runner executes two required passes and one recommended pass, each in a
fresh output directory, with `--maximum_edition 2023`. The pinned runner has no
Edition 2024 cases. Each pass must report exactly 5,631 binary/JSON and 909 text
successes, with no skipped tests, expected failures or unexpected failures.
The repository's strict conformance report checker validates all six suite
summaries. `publish.py` writes `results.json` with `complete: true` and
`all_passed: true` only after these checks succeed. `report.json` and the raw
logs preserve partial work or a first failure if the campaign fails.

To reproduce, provision the pinned protobuf source and tools using
`scripts/conformance.sh`, provide the recorded Rust toolchain, and place these
scripts in a fresh `work/fix-performance-round/owned-conformance/` directory of
the repository. The driver expects the task-local Cargo/Rustup directories
under `work/` and shares the existing `work/bench-target` build cache. It creates
its own `source/`, `generated/`, `artifacts/` and `passes/` directories; it refuses
to overwrite an existing source snapshot.

```sh
python3 work/fix-performance-round/owned-conformance/run.py
python3 work/fix-performance-round/owned-conformance/publish.py
```

The source snapshot, generated directory and executable copies are local build
artifacts and can be omitted from an evidence archive: the committed source,
script, patches, pin and manifests reconstruct them. The snapshot's
`third_party/protobuf` symlink selects the pinned SDK, whose revision and proto
hashes are recorded. `dirty_source: true` in the conformance summary marks the
intentional generated-profile replacement in that snapshot.

This is finite conformance evidence through Edition 2023. It does not establish
source compatibility with Prost, `no_std` support, performance leadership or
behavior for every possible input.
