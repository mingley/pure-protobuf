"""Post-hoc descriptive latency audit; raw percentiles are never N/2N subtracted."""
import json,statistics
from pathlib import Path
root=Path(__file__).resolve().parents[3]
base=root/'work/fix-performance-round/benchmark/rpc-comparison'
manifest=json.loads((base/'manifest.json').read_text());groups={}
for row in manifest['runs']:
 raw=json.loads((base/row['path']).read_text());m=raw['metrics']
 assert m['successful_rpcs']==row['count'] and m['failed_rpcs']==0
 groups.setdefault((row['name'],row['pair'],row['count'],row['repeat']),{})[row['source']]=m
rows=[]
for name,pair,count in sorted({key[:3] for key in groups}):
 item=dict(cell=name,pair=pair,rpcs=count,metrics={})
 for metric in ('mean_nanos','p50_nanos','p99_nanos','p999_nanos'):
  values={source:[groups[name,pair,count,repeat][source]['e2e_latency_nanos'][metric] for repeat in range(5)] for source in ('before','after')}
  ratios=[values['after'][i]/values['before'][i] for i in range(5)]
  item['metrics'][metric]=dict(values=values,before_median=statistics.median(values['before']),after_median=statistics.median(values['after']),median_paired_ratio=statistics.median(ratios),range=[min(ratios),max(ratios)])
 rows.append(item)
report=dict(qualified=False,source='isolated server coalescer comparison',post_hoc=True,limits=['Closed-loop shared-host diagnostics; no open-loop SLO claim','No warmup qualification; pipeline percentile sample floor not met','Paired raw percentiles at each N; never subtract quantiles or pool repetitions'],rows=rows)
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
for row in rows:
 if row['pair']=='native_server':
  value=row['metrics']['p99_nanos'];print(row['cell'],row['rpcs'],'p99 us',value['before_median']/1000,'->',value['after_median']/1000,'paired ratio',value['median_paired_ratio'],'range',value['range'])
