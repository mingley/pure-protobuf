# Independent source review

No blocking correctness, API compatibility or MSRV issue was found in the inspected changes. This was a source review; it did not duplicate the owners’ executions or establish a performance ranking. Exact inspected hashes are in `review.json`.

The owned profile propagates one explicit option through plugin parsing, worker state and reset guards. Its checked parser keeps the existing merge/required/oneof paths and installs new boxed children only after successful parsing. Shared input uses the same child windows as its byte slice. The 32-bit private size cache treats overflow as an uncached value; size computation remains 64-bit. Default generation retains the lazy profile and the original cache.

The server wrapper cannot lose a notification at its pending boundary: a notification before the POLLING-clearing atomic operation is observed there, and one after it sees POLLING clear and wakes the parent. Polling is bounded, the proxy identity is stable, and Ready/Drop release the parent. Concurrent wakes can still produce redundant schedules; this does not prevent progress.

The consumer covers the important changed storage behaviors, including shared pointers, mutation and clone independence, failed merges, required fragments, oneof replacement and valid-value Prost comparisons. Final workspace, official conformance and MSRV execution remain the root agent’s validation work.

## Selected parser follow-up

The selected implementation is commit `ec13f154518cba8cc896e9988f0baf8f7d5f44ef`, V3A stack parsing. Compared with the initially inspected V4, Owned dispatch now uses the existing complete field match instead of the light/heavy helper split. All merge arms, validation, depth and final required checks remain the same. The default keeps the original helper split and `inline(never)` attribute. Stack construction, compact cache and shared input are unchanged. No blocker was found in this code-placement delta. Final hashes replace the V4 hashes in `review.json`, which also retains the initial inspected hashes.

The performance record, parity guide, benchmark guide and codegen profile guide were also reviewed. Their claims distinguish opt-in Owned from default Lazy, retain slower workloads and known parity gaps, and describe the results as shared-host diagnostics. No material mismatch was found. Final validation and archive completeness remain separate checks.
