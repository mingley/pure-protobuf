# Final benchmark and reconstruction audit

All 12 numeric README table rows match the retained shipping summaries after rounding. The prose keeps the storage costs, controls, shared-host limits and rejected alternatives.

All seven exported source variants reconstruct their complete frozen hash manifests from their declared parents. The baseline reconstructs from commit `934bba31` and its recorded Git archive path set. Six relative protobuf symlinks are present; source manifests hash the referent bytes. The selected source chain is baseline → V2 → V3A. V1 was an independent experiment, not V2's parent.

Every frozen build record's harness and Cargo.lock is either retained by the capsule filters or recoverable in a reconstructed frozen source. Standalone partial and encode harnesses, scripts, lockfiles, build logs and provenance records survive the full-source exclusion. `variant-files/reconstruction.json` records the parent graph and reconstruction procedure. No timings were rerun for this audit.
