"""Check final benchmark claims and reconstruction inputs without rerunning timings."""
from pathlib import Path,PurePosixPath
import ast,hashlib,io,json,posixpath,subprocess,tarfile
ROOT=Path(__file__).resolve().parents[3];B=ROOT/'work/fix-performance-round/benchmark';OUT=Path(__file__).resolve().parent
sha=lambda x:hashlib.sha256(x).hexdigest()
read=lambda p:json.loads(p.read_text())
BASE='934bba317805356e11b58145f0068ad8279b0ae0'
PATHS=['Cargo.toml','Cargo.lock','build.rs','src','proto','vendor','protobuf-tonic','pbrs-grpc','rpc-bench','examples','tests/proof/codec_benchmark','clippy.toml','rustfmt.toml']
git_archive=subprocess.check_output(['git','archive','--format=tar',BASE,*PATHS],cwd=ROOT);git_files={};links={}
with tarfile.open(fileobj=io.BytesIO(git_archive),mode='r:') as ar:
 for member in ar.getmembers():
  if member.isfile():git_files[member.name]=sha(ar.extractfile(member).read())
  elif member.issym():links[member.name]=posixpath.normpath(str(PurePosixPath(member.name).parent/member.linkname))
for path,target in links.items():assert target in git_files;git_files[path]=git_files[target]
assert git_files==read(B/'baseline-source-source.json')['files']
variants={}
for name in ['server-source','codec-source','owned-source','owned-v2-source','owned-v3-stack-source','owned-v3-heap-source','owned-v4-source']:
 m=read(B/(name+'-source.json'));parent=Path(m['baseline_snapshot']).name;pm=read(B/(parent+'-source.json'));expected=dict(pm['files'])
 for path,row in m['declared_changes'].items():
  assert expected.get(path)==row['old_sha256'],(name,path,'oldhash')
  assert sha((B/'variant-files'/name/path).read_bytes())==row['new_sha256'],(name,path,'newhash')
  expected[path]=row['new_sha256']
 assert expected==m['files'],name
 variants[name]=dict(parent=parent,source_manifest=name+'-source.json',changed_files=len(m['declared_changes']),source_file_count=len(m['files']),reconstructed_hash_manifest_matches=True)
reconstruction=dict(schema='pbrs.variant-reconstruction.v1',baseline=BASE,baseline_files=len(git_files),baseline_git_archive_paths=PATHS,baseline_symlinks=links,baseline_archive_matches_source_manifest=True,variants=variants,
 instructions=['Export the baseline Git archive using the recorded path list, avoiding an installed third_party checkout.','Git archive includes six relative proto symlinks; source manifests hash their referent bytes.','For a variant, first reconstruct its parent, then overlay variant-files/<variant> onto that parent.','Verify every reconstructed file against that variant source manifest before building.','V1 owned-source is a separate branch. V2 starts directly from baseline, not from V1.','Use matching harness folders, Cargo.lock, build_probe.py and recorded compiler/profile options.','The final root public-feature main adds untimed profile metadata. Original frozen timings use baseline timed-harness source plus the recorded build.rs profile selection.'])
(B/'variant-files/reconstruction.json').write_text(json.dumps(reconstruction,indent=2)+'\n')
p=B/'final-selection.json';selection=read(p);selection['source_chain']=['baseline-source-source.json','owned-v2-source-source.json','owned-v3-stack-source-source.json'];selection['variant_reconstruction']='variant-files/reconstruction.json';p.write_text(json.dumps(selection,indent=2)+'\n')
# Evaluate only literal packaging filters; do not run a half-complete packager.
packaging=ast.parse((ROOT/'work/fix-performance-round/package.py').read_text());config={}
for node in packaging.body:
 if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name) and node.targets[0].id in ('exts','skip','groups'):
  config[node.targets[0].id]=ast.literal_eval(node.value)
def included(path):
 rel=path.relative_to(ROOT/'work');group=rel.parts[0];inside=Path(*rel.parts[1:])
 return group in config['groups'] and not any(x in config['skip'] for x in inside.parts) and path.suffix in config['exts'] and not (group=='fix-performance-round' and len(inside.parts)>2 and inside.parts[0]=='benchmark' and inside.parts[1].endswith('-source')) and not path.read_bytes().startswith(b'\x7fELF')
probes=[]
for record_path in B.rglob('*-build.json'):
 r=read(record_path)
 if r.get('schema')!='pbrs.frozen-probe-build.v1':continue
 package=Path(r['manifest']).parent;items={}
 for name,expected in dict(r['harness_files'],**{'Cargo.lock':r['cargo_lock_sha256']}).items():
  path=package/name;assert path.exists() and sha(path.read_bytes())==expected,(record_path,name,'harnesschanged')
  if included(path):method='included harness file'
  else:
   source=Path(r['source']);relative=str(path.relative_to(source));manifest=read(B/(source.name+'-source.json'));assert manifest['files'][relative]==expected,(record_path,name,'notrecoverable');method='reconstructed frozen source'
  items[name]=dict(sha256=expected,recovery=method)
 assert included(record_path)
 probes.append(dict(build_record=str(record_path.relative_to(ROOT)),files=items))
# Exact rounded numbers in all three README tables.
readme=ROOT/'docs/evidence/performance-fixes-20261027/README.md';text=readme.read_text();table_checks=[]
full=read(B/'owned-v3-stack-comparison/summary.json');encode=read(B/'owned-v3-stack-encode-comparison/summary.json');rpc=read(B/'rpc-comparison/summary.json')
def table_line(label):return next(x for x in text.splitlines() if x.startswith('| '+label+' |'))
for label,case,op in [('Depth 8, read all','nested_8','read_all'),('Depth 64, read all','nested_64','read_all'),('Depth 64, parse only','nested_64','parse_owned'),('Mixed RPC, read all','rpc_mixed','read_all'),('Sparse RPC, parse only','rpc_sparse','parse_owned'),('Packed 256, read all','packed_256','read_all')]:
 r=next(x for x in full if x['case']==case and x['operation']==op);line=table_line(label);m=r['cpu_ns_medians'];rat=r['ratios'];values=[f"{m['before']['pbrs']:,.1f} ns",f"{m['after']['pbrs']:,.1f} ns",f"{m['after']['prost']:,.1f} ns",f"{rat['after_over_before_pbrs']['median']:.3f}",f"{rat['after_pbrs_over_prost']['median']:.3f}"]
 assert line.split('|')[2:-1]==[' '+v+' ' for v in values],(label,line,values);table_checks.append(label)
for label,op,places in [('Parse and first encode','parse_fresh_encode',0),('First encode, parsing excluded','fresh_encode',1),('Unchanged cached encode','cached_encode',1),('First-child mutation and encode','mutate_encode',1)]:
 r=next(x for x in encode if x['case']=='nested_64' and x['operation']==op);line=table_line(label);m=r['cpu_ns_medians'];rat=r['ratios'];values=[f"{m['before']['pbrs']:,.{places}f} ns",f"{m['after']['pbrs']:,.{places}f} ns",f"{m['after']['prost']:,.0f} ns",f"{rat['after_over_before_pbrs']['median']:.3f}",f"{rat['after_pbrs_over_prost']['median']:.3f}"]
 assert line.split('|')[2:-1]==[' '+v+' ' for v in values],(label,line,values);table_checks.append(label)
for label,cell in [('1 KiB unary','unary_1k_prost'),('64 × 1 KiB pipeline','pipeline_64x1k_prost')]:
 r=next(x for x in rpc if x['cell']==cell and x['endpoint']=='server');m=r['cpu_us_per_rpc_medians'];line=table_line(label)
 numbers=[float(s.strip().split()[0].replace(',','')) for s in line.split('|')[2:-1]];expected=[m['before']['native'],m['after']['native'],m['after']['tonic'],round(r['ratios']['after_over_before_native']['median'],3)];assert all(abs(x-y)<1e-8 for x,y in zip(numbers,expected));table_checks.append(label)
report=dict(schema='pbrs.final-benchmark-audit.v1',passed=True,readme_sha256=sha(readme.read_bytes()),readme_numeric_table_rows_checked=table_checks,baseline_reconstructs=True,variants_reconstruct=variants,frozen_build_records_audited=len(probes),harnesses_and_locks_recoverable=probes,
 notes=['Six proto symlinks are part of the baseline archive; full source hash manifests use referent bytes.','Corrected final-selection source chain: baseline -> V2 -> V3A; V1 is independent.','Standalone partial and encode source/lockfiles survive packaging filters; frozen codec/RPC source is recoverable from exact baseline plus exported variants.','Run the archive checker after packaging to bind these files to the final compressed capsule.'])
(OUT/'benchmark-audit.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'benchmark-audit.md').write_text('''# Final benchmark and reconstruction audit

All 12 numeric README table rows match the retained shipping summaries after rounding. The prose keeps the storage costs, controls, shared-host limits and rejected alternatives.

All seven exported source variants reconstruct their complete frozen hash manifests from their declared parents. The baseline reconstructs from commit `934bba31` and its recorded Git archive path set. Six relative protobuf symlinks are present; source manifests hash the referent bytes. The selected source chain is baseline → V2 → V3A. V1 was an independent experiment, not V2's parent.

Every frozen build record's harness and Cargo.lock is either retained by the capsule filters or recoverable in a reconstructed frozen source. Standalone partial and encode harnesses, scripts, lockfiles, build logs and provenance records survive the full-source exclusion. `variant-files/reconstruction.json` records the parent graph and reconstruction procedure. No timings were rerun for this audit.
''')
print(json.dumps(dict(passed=True,table_rows=len(table_checks),variants=len(variants),build_records=len(probes))))
