# Native unary server design review

Baseline source: `934bba317805356e11b58145f0068ad8279b0ae0`.
Independent reviewer: `/root/server_review`. This file records source review,
not an independent speed ranking. The implementation/profile owner is
`/root/unary_server`; no production files were edited by this reviewer.

## Structural findings

The default unary path allocates `Box<InboundRpc>`, an outer boxed
`read_unary` future, and two nested boxed futures (`read_unary_frame_fut`,
`run_handler_fut`). The last two are candidates for removal while keeping the
outer allocation boundary and small dispatch future. They are not established
as the explanation for the native CPU loss. The unary `Prepared<T>` return is
unboxed; streaming uses a boxed `Prepared<T>`.

The owner deadline wrapper registers its waker twice on a pending poll.
Replacing only its second `poll_at(cx)` with `at()` may remove redundant
registration while preserving deadline visibility. The first registration
must remain even without an initial deadline: a custom service can move the
Rpc to another task and tighten the deadline asynchronously. This is a small
candidate, not a measured change.

The profile owner's measurements change the primary hypothesis: native uses
fewer user instructions per unary RPC than tonic, but pays much more system
CPU and scheduler notification work. Its strace shows roughly one extra
runtime eventfd write per RPC and thousands of futex operations. Socket
writev/sendto counts are comparable. Raw data is in `work/server_cpu_fix/`. Independently recomputed server
instruction slopes are 42,707.3 versus 55,744.815 Ir/RPC (ratio 0.7661).
A separate FD-aware two-worker 100-RPC sample confirms 37 native eventfd writes
versus one tonic eventfd write. These scheduler counts vary with timing; they
are diagnostic samples, not invariant per-call costs.
`server-profile-audit.json` records raw hashes and the independent arithmetic.

## Rejected source hypothesis

An early review message incorrectly inferred an unconditional parent wake in
`FuturesUnordered::push`. The exact cached futures-util 0.3.34 implementation
only enqueues the new task; enqueue does not wake the parent. A proposed noop
waker substitution before empty-to-nonempty push would therefore add work
without addressing the measured churn. The implementation owner caught the
incorrect inference before any such change was made. Do not adopt it.

Actual parent wake sources include child `Task::wake_by_ref` and the
`FuturesUnordered::poll_next` self-yield branch. The latter deliberately yields
after productive self-wakes or after visiting all initial tasks.

## Bounded connection wake coalescing

The current candidate wraps the entire connection-serving future, including
admission and all surrounding async control flow. Wrapping just its steady
poll closure would miss notifications produced after that closure returns
Ready but before the connection future itself returns Pending.

A stable per-connection proxy owns POLLING/NOTIFIED/CLOSED atomic flags and an
AtomicWaker parent. A notification sets NOTIFIED. It forwards to the runtime
only if POLLING and CLOSED were both clear. Each poll registers the current
parent, marks POLLING, clears a consumed notification, and polls the inner
connection with the proxy. On Pending, an atomic fetch-and clears POLLING:

- A wake before that modification appears in the returned NOTIFIED flags and
  causes a bounded local repoll or a parent wake at the budget limit.
- A wake after it sees POLLING clear and forwards to the parent itself.
- A wake between local iterations may cause a redundant parent notification,
  but cannot be lost.

The connection's ordinary body/reset/deadline/flow-control futures and service
state remain unchanged. The stable proxy identity preserves the h2 driver's
waker identity test. CLOSED plus taking the parent waker on Ready and pinned
Drop releases parent references and suppresses late callbacks after shutdown.
No unsafe pin projection is needed (`pin_project_lite`).

Four local polls form a finite batch. The candidate also stops immediately
when Tokio's cooperative budget has been exhausted. Batching can otherwise
multiply synchronous handler or compression work per Tokio poll; existing
mixed load, deadline, cancellation, drain and slow-reader controls remain
required. The cost includes one new allocation per connection, not per RPC.

Recommended deterministic controls: consumed self-notification with no parent
reschedule; finite budget for perpetual self-notification; external wake while
polling and across the return-Pending transition; changed parent waker;
late callbacks and parent-reference release on Ready/Drop; panic cleanup;
Tokio exhausted-budget yielding. The final candidate has six passing units: consumed notification, finite
budget, during-poll external wake, latest-parent/drop cleanup, 256 iterations
of the return-Pending race, and panic/drop cleanup. Source review confirms
parent release on Ready. Seven protocol suites pass 106 tests with zero
failures/ignores, including mixed workload, deadline, cancellation, shutdown,
slow-reader and resource-bound controls. These are the implementation owner’s
retained executions, independently read by this reviewer; the reviewer did not
rerun their builds. Shipping CPU and syscall changes still require the frozen
candidate measurements.
