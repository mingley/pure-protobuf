"""Run the pinned ignored check and check final documentation assets."""
import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'work/fix-performance-round/final-checks';out.mkdir(exist_ok=True)
commands=[('pinned-descriptors',['cargo','test','--locked','-p','pbrs','--test','onboarding','adapter_descriptor_sets_match_pinned_protoc_and_generated_output','--','--exact','--ignored']),('docs-with-capsule',['cargo','test','--locked','--test','documentation','--','--nocapture'])]
report=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),checks=[],complete=False)
for name,cmd in commands:
 env=dict(os.environ);env['PATH']=str(root/'target/conformance-build')+os.pathsep+env['PATH']
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start);report['checks'].append(row)
 (out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((out/(name+'.log')).read_text()[-12000:]);raise SystemExit(r.returncode)
report['complete']=True;(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
