"""Retain performance repairs, complete campaigns, and rejected experiments."""
import hashlib,io,json,re,shutil,subprocess,tarfile
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'docs/evidence/performance-fixes-20261027';out.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
validation=json.loads((root/'work/fix-performance-round/validation/results.json').read_text())
if not validation.get('complete') or not validation.get('inputs_unchanged'):raise ValueError('Final validation incomplete')
selection=json.loads((root/'work/fix-performance-round/benchmark/final-selection.json').read_text())
owned=json.loads((root/'work/fix-performance-round/owned-conformance/results.json').read_text())
if not owned.get('complete') or not owned.get('all_passed'):raise ValueError('Owned conformance incomplete')
if selection['state']!='complete':raise ValueError('Benchmark selection incomplete')
files={}
exts={'.json','.jsonl','.log','.rs','.py','.md','.toml','.lock','.patch','.stderr','.stdout','.proto','.txt','.callgrind','.strace','.asm','.c','.sh','.yaml','.yml','.bin'}
skip={'target','.git','__pycache__','valgrind','packages','apt','frozen-core'}
groups=['fix-performance-round','codegen_output','server_cpu_fix','compact-size-cache','owned-profile']
for group in groups:
 base=root/'work'/group
 for path in sorted(base.rglob('*')):
  rel=path.relative_to(base)
  if not path.is_file() or path.is_symlink() or any(p in skip for p in rel.parts) or path.suffix not in exts:continue
  # Frozen full checkouts are redundant. Keep their source manifests and
  # exact changed-file exports (variant-files) instead.
  if group=='fix-performance-round' and len(rel.parts)>2 and rel.parts[0]=='benchmark' and rel.parts[1].endswith('-source'):continue
  if group=='fix-performance-round' and len(rel.parts)>1 and rel.parts[0]=='owned-conformance' and rel.parts[1] in {'source','artifacts','generated'}:continue
  data=path.read_bytes()
  if data.startswith(b'\x7fELF'):continue
  files[str(path.relative_to(root))]=data
for path in sorted((root/'work').glob('linear-decode-*')):
 if path.is_file() and path.suffix in exts:files[str(path.relative_to(root))]=path.read_bytes()
base=selection['baseline'];server='48c208e96bbebdb925fa6f3416f1606fd09a8e52';profile=validation['source']
def git(*args):return subprocess.check_output(['git',*args],cwd=root)
files['source/validation-provenance.json']=(json.dumps(dict(code_commit=profile, inputs_unchanged=validation['inputs_unchanged'], non_code_working_changes=git('diff','--name-only').decode().splitlines(), note='Documentation and CI cache settings were edited during checks; all production/test input hashes remain bound to the recorded code commit. Owned conformance intentionally regenerates exactly13 bindings in its isolated source.'),indent=2)+'\n').encode()
files['source/parity-workflow.yml']=(root/'.github/workflows/parity.yml').read_bytes()
files['source/server-repair.patch']=git('diff',base,server,'--','pbrs-grpc')
files['source/owned-profile-and-proofs.patch']=git('diff',server,profile,'--','src','tests','docs/guides/codegen.md','.github/workflows/parity.yml')
files['source/reproduce.md']=('''# Reconstruct measured sources

Start from baseline `'''+base+'''` in an isolated checkout.
Apply source/server-repair.patch for the isolated server candidate.
Apply source/owned-profile-and-proofs.patch for the final public API and proofs.
The latter includes benchmark profile selection and untimed JSON metadata;
original frozen timings used the unchanged original timed loops.
For measured replicas, export only the Git paths listed in
work/fix-performance-round/benchmark/variant-files/reconstruction.json;
leave out an installed third_party checkout, which changes build.rs descriptor
inputs. For a specific frozen codec variant, overlay its exact changed files from
work/fix-performance-round/benchmark/variant-files on its documented source
chain. Source manifests describe every file hash; generated-code equivalence
records bind the final public Config API and Cargo feature to the selected
frozen parser output. Follow recorded harness/build scripts and lockfiles.

The rejected eager fixture originally lived at tests/proof/linear_decode;
restore it to that path in a disposable patched checkout before invoking
its Cargo.toml. It was moved under work only to retain the rejected design.

No executables, tool installations, build caches, or duplicate frozen full
source trees are included. Build elapsed times are provenance only: parallel
builds are not a codegen-speed comparison. Raw CPU campaigns are separate
from allocation and diagnostic profiler captures.
''').encode()
matrices={}
bench=root/'work/fix-performance-round/benchmark'
for label,dirname in selection['matrices'].items():
 matrices[label]=json.loads((bench/dirname/'summary.json').read_text())
result=dict(schema='pbrs.performance-fixes.v1',baseline=base,server_commit=server,profile_commit=profile,
 qualified=False,full_tonic_prost_parity=False,world_performance_ranking_established=False,
 selected=selection,matrices=matrices,validation=validation,
 generated_equivalence=json.loads((root/'work/fix-performance-round/linear/final/selected-equivalence.json').read_text()),
 latency_diagnostic=json.loads((root/'work/fix-performance-round/root/rpc_latency.json').read_text()),
 rejected_codegen=json.loads((root/'work/codegen_output/decision.json').read_text()),
 rejected_eager=json.loads((root/'work/fix-performance-round/linear/decision.json').read_text()),
 review=json.loads((root/'work/fix-performance-round/final-review/review.json').read_text()),
 owned_conformance=owned)
final_checks=root/'work/fix-performance-round/final-checks/results.json'
if final_checks.exists():
 result['final_checks']=json.loads(final_checks.read_text())
 if not result['final_checks'].get('complete'):raise ValueError('Final checks incomplete')
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
with tarfile.open(out/'raw.tar.gz','w:gz',compresslevel=6) as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;archive.addfile(info,io.BytesIO(data))
manifest=dict(schema='pbrs.evidence-manifest.v1',archive_sha256=sha((out/'raw.tar.gz').read_bytes()),results_sha256=sha((out/'results.json').read_bytes()),files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(root/'docs/evidence/efficiency-20261027/check.py',out/'check.py')
print(json.dumps(dict(files=len(files),logical_bytes=sum(map(len,files.values())),archive_bytes=(out/'raw.tar.gz').stat().st_size,workspace=validation['workspace_test_counts'])))
