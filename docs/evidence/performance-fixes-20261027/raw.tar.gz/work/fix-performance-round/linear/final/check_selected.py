"""Verify shipping profile API and Cargo feature generate the measured source."""
from pathlib import Path
import hashlib,json,shutil
root=Path(__file__).resolve().parents[4]
base=root/'work/fix-performance-round/linear/final'
benchmark=root/'work/fix-performance-round/benchmark'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def artifact(file,package,relative):
 messages=[json.loads(line) for line in file.read_text().splitlines() if line.startswith('{')]
 outputs=[Path(row['out_dir'])/relative for row in messages if row.get('reason')=='build-script-executed' and package in row.get('package_id','')]
 assert len(outputs)==1,outputs
 return outputs[0]
feature=artifact(base/'selected-feature.jsonl','pbrs-codec-proof','pbrs/codec_cases.rs')
api=artifact(base/'selected-consumer.jsonl','pbrs-owned-messages-proof','api-codec/codec_cases.rs')
frozen=benchmark/'owned-v3-stack-candidate/generated/codec_cases.rs'
if not frozen.exists():
 frozen=artifact(benchmark/'owned-v3-stack-candidate/codec-shipping.jsonl','pbrs-codec-proof','pbrs/codec_cases.rs')
items={'tracked_feature':feature,'public_api':api,'frozen_benchmark':frozen}
record={'selected_variant':'owned-v3-stack','parse_source_sha256':sha(root/'src/codegen/parse.rs'),'generated':{name:{'path':str(path),'sha256':sha(path)} for name,path in items.items()}}
record['identical']=len({item['sha256'] for item in record['generated'].values()})==1
for name,path in items.items():shutil.copy2(path,base/(name+'-codec_cases.rs'))
(base/'selected-equivalence.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
assert record['identical']
