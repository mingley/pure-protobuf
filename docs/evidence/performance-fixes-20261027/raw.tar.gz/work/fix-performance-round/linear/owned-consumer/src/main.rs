use pbrs::{ClearAndParse, Parse, Serialize};
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};

mod generated {
    include!(concat!(env!("OUT_DIR"), "/proof.rs"));
}

mod strict_generated {
    include!(concat!(env!("OUT_DIR"), "/strict.rs"));
}

struct Counting;
static COUNTING: AtomicBool = AtomicBool::new(false);
static ALLOCATIONS: AtomicUsize = AtomicUsize::new(0);
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc(layout) };
        if !result.is_null() && COUNTING.load(Ordering::Relaxed) {
            ALLOCATIONS.fetch_add(1, Ordering::Relaxed);
        }
        result
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let result = unsafe { System.alloc_zeroed(layout) };
        if !result.is_null() && COUNTING.load(Ordering::Relaxed) {
            ALLOCATIONS.fetch_add(1, Ordering::Relaxed);
        }
        result
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let result = unsafe { System.realloc(ptr, layout, size) };
        if !result.is_null() && COUNTING.load(Ordering::Relaxed) {
            ALLOCATIONS.fetch_add(1, Ordering::Relaxed);
        }
        result
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
        unsafe { System.dealloc(ptr, layout) }
    }
}
#[global_allocator]
static GLOBAL: Counting = Counting;

fn varint(out: &mut Vec<u8>, mut n: u64) {
    while n >= 128 {
        out.push(n as u8 | 128);
        n >>= 7;
    }
    out.push(n as u8);
}
fn scalar(number: u32, n: u64) -> Vec<u8> {
    let mut wire = vec![];
    varint(&mut wire, u64::from(number) << 3);
    varint(&mut wire, n);
    wire
}
fn bytes(number: u32, data: &[u8]) -> Vec<u8> {
    let mut wire = vec![];
    varint(&mut wire, (u64::from(number) << 3) | 2);
    varint(&mut wire, data.len() as u64);
    wire.extend_from_slice(data);
    wire
}
fn chain(depth: u32) -> Vec<u8> {
    let mut wire = scalar(1, 1);
    for n in 2..=depth {
        wire = [scalar(1, u64::from(n)), bytes(2, &wire)].concat();
    }
    wire
}
fn allocated(operation: impl FnOnce()) -> usize {
    ALLOCATIONS.store(0, Ordering::Relaxed);
    COUNTING.store(true, Ordering::Relaxed);
    operation();
    COUNTING.store(false, Ordering::Relaxed);
    ALLOCATIONS.load(Ordering::Relaxed)
}
fn main() {
    let wire = chain(64);
    let root = generated::Node::parse(&wire).unwrap();
    let original = root.serialize().unwrap();
    let mut checksum = 0;
    let first = root.child();
    // Once the first child is materialized, its entire owned subtree is ready.
    // This deterministic allocation invariant catches per-getter rebuilding
    // without using a timing threshold or changing the semantic work.
    let later_allocations = allocated(|| {
        let mut cursor = first;
        checksum += cursor.n();
        while cursor.has_child() {
            cursor = cursor.child();
            checksum += cursor.n();
        }
    });
    assert_eq!(checksum, (1..64).sum::<i32>());
    assert_eq!(later_allocations, 0);
    assert_eq!(root.serialize().unwrap(), original);

    let mut merged = root.clone();
    merged.merge_from_bytes(&bytes(2, &scalar(1, 99))).unwrap();
    assert_eq!(merged.child().n(), 99);
    assert_eq!(merged.child().child().n(), 62);
    assert_eq!(root.child().n(), 63);

    // The first unread descendant still has to be valid during ordinary parse.
    let legacy_bytes = bytes(2, &bytes(2, &bytes(3, &[255])));
    assert!(generated::Node::parse(&legacy_bytes).is_ok());
    let invalid = bytes(1, &bytes(1, &bytes(2, &[255])));
    assert!(strict_generated::StrictNode::parse(&invalid).is_err());
    assert!(generated::Node::parse(&bytes(2, &[0x80])).is_err());
    assert!(generated::Node::parse(&chain(pbrs::RECURSION_LIMIT + 2)).is_err());

    // Owned parsing still retains unknown fields through mutation/serialization.
    let unknown = [chain(3), scalar(99, 1234)].concat();
    let parsed = generated::Node::parse(&unknown).unwrap();
    let roundtrip = parsed.serialize().unwrap();
    assert!(roundtrip.ends_with(&scalar(99, 1234)));
    let mut updated = parsed.clone();
    updated.merge_from_bytes(&scalar(1, 77)).unwrap();
    assert!(updated.serialize().unwrap().ends_with(&scalar(99, 1234)));
    assert_eq!(updated.n(), 77);

    // Eager traversal must not enforce replaced or split required values early.
    let split = [bytes(6, &scalar(1, 11)), bytes(6, &scalar(2, 22))].concat();
    let mixed = generated::WithRequired::parse(&bytes(1, &split)).unwrap();
    assert_eq!(mixed.child().required().left(), 11);
    assert_eq!(mixed.child().required().right(), 22);
    let replaced = [bytes(6, &scalar(1, 11)), scalar(7, 5)].concat();
    let mixed = generated::WithRequired::parse(&bytes(1, &replaced)).unwrap();
    assert_eq!(mixed.child().replacement(), 5);

    // Reused free oneof cases merge; switching away and back replaces the tree.
    let reused = [bytes(2, &scalar(1, 11)), bytes(2, &bytes(2, &chain(4)))].concat();
    let choice = generated::FreeChoice::parse(&bytes(1, &reused)).unwrap();
    assert_eq!(choice.child().node().n(), 11);
    assert_eq!(choice.child().node().child().n(), 4);
    let switched = [bytes(2, &chain(4)), scalar(3, 99), bytes(2, &scalar(1, 7))].concat();
    let choice = generated::FreeChoice::parse(&bytes(1, &switched)).unwrap();
    assert_eq!(choice.child().node().n(), 7);
    assert!(!choice.child().node().has_child());

    // Repeated, map and group descendants propagate the checked materializer.
    let node = chain(8);
    let entry = [scalar(1, 7), bytes(2, &node)].concat();
    let group = [vec![(4 << 3) | 3], bytes(5, &node), vec![(4 << 3) | 4]].concat();
    let body = [bytes(2, &node), bytes(3, &entry), group].concat();
    let mixed = generated::Mixed::parse(&bytes(1, &body)).unwrap();
    let child = mixed.child();
    assert_eq!(child.nodes().get(0).unwrap().child().n(), 7);
    assert_eq!(child.values().get(7).unwrap().child().n(), 7);
    assert_eq!(child.group().node().child().n(), 7);

    println!(
        "PASS linear owned traversal, zero later allocations, preserved wire/clone/merge, malformed UTF-8/recursion, split/replaced required, repeated/map/group"
    );
}
