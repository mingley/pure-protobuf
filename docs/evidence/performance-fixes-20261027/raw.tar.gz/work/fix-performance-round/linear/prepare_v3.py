from pathlib import Path
p=Path('src/codegen/parse.rs');s=p.read_text()
old='''    let split_heavy =
        !desc.message_set_wire_format && (1..=4).contains(&lights.len()) && !heavies.is_empty();'''
new='''    let split_heavy = !desc.message_set_wire_format
        && (1..=4).contains(&lights.len())
        && !heavies.is_empty()
        && !OWNED_MESSAGE_FIELDS.with(|owned| owned.get());'''
assert old in s;s=s.replace(old,new,1)
old='''        // Owned children are parsed in their final allocation. Stage the box
        // until checked parsing succeeds so an error still leaves an absent
        // first occurrence absent. Default generation keeps its exact output.
        let (new_inner, store_inner) = if OWNED_MESSAGE_FIELDS.with(|owned| owned.get()) {
            (format!("Box::<{t}>::default()"), "inner")
        } else {
            (format!("{t}::default()"), "Box::new(inner)")
        };
'''
assert old in s;s=s.replace(old,'',1)
s=s.replace('let mut inner = {new_inner};','let mut inner = {t}::default();').replace('Some({store_inner})','Some(Box::new(inner))')
# The option expression is emitted only for message LEN merges. It never
# forces a borrowed input into an Arc just to propagate an absent backing.
start=s.index('pub(crate) fn emit_merge_arm(');end=s.index('pub(crate) fn emit_map_decoders(',start)
piece=s[start:end]
old='''    let num = f.number;
    if f.is_map {'''
new='''    let num = f.number;
    let child_wire = if matches!(f.field_type, FieldType::Message | FieldType::Group)
        && OWNED_MESSAGE_FIELDS.with(|owned| owned.get())
    {
        "wire.as_ref().map(|source| source.window(s, e))"
    } else {
        "None"
    };
    if f.is_map {'''
assert old in piece;piece=piece.replace(old,new,1)
piece=piece.replace('let mut sw = None;', 'let mut sw = {child_wire};')
s=s[:start]+piece+s[end:]
old='''            let _ = writeln!(
                src,
                "        (2, pbrs::rt::WIRE_LEN) => {{ if depth >= pbrs::RECURSION_LIMIT {{ return Err(ParseError::new(\\"recursion limit exceeded\\")); }} let (s, e) = pbrs::rt::read_len_span(data, &mut pos)?; let mut ip = 0; let mut sw = None; val.get_or_insert_with({v}::default).merge_inner(&data[s..e], &mut sw, &mut ip, depth + 1, {enforce}, None)?; }},"
            );'''
new='''            let child_wire = if OWNED_MESSAGE_FIELDS.with(|owned| owned.get()) {
                "Some(wire.window(s, e))"
            } else {
                "None"
            };
            let _ = writeln!(
                src,
                "        (2, pbrs::rt::WIRE_LEN) => {{ if depth >= pbrs::RECURSION_LIMIT {{ return Err(ParseError::new(\\"recursion limit exceeded\\")); }} let (s, e) = pbrs::rt::read_len_span(data, &mut pos)?; let mut ip = 0; let mut sw = {child_wire}; val.get_or_insert_with({v}::default).merge_inner(&data[s..e], &mut sw, &mut ip, depth + 1, {enforce}, None)?; }},"
            );'''
assert old in s;s=s.replace(old,new,1)
p.write_text(s)
