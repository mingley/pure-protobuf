"""Freeze fused checked owned parsing with stack versus heap child staging."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

root=Path(__file__).resolve().parents[3]
base=root/'work/fix-performance-round/benchmark/owned-v2-source'
record_path=base.parent/'owned-v2-source-source.json'
assert base.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name,heap in [('owned-v3-stack-source',False),('owned-v3-heap-source',True)]:
 out=base.parent/name
 assert not out.exists()
 shutil.copytree(base,out)
 text=(root/'src/codegen/parse.rs').read_text()
 if heap:
  patterns=[
   '                    match &mut {st} {{ Some(existing) => existing.merge_group(data, wire, pos, {num}, depth + 1)?, None => {{ let mut inner = {t}::default(); inner.merge_group(data, wire, pos, {num}, depth + 1)?; {st} = Some(Box::new(inner)); }} }}',
   '                    match &mut {st} {{ Some(existing) => {{ let mut ip = 0; let mut sw = {child_wire}; existing.merge_inner(&data[s..e], &mut sw, &mut ip, depth + 1, {enforce}, None)?; }} None => {{ let mut inner = {t}::default(); let mut ip = 0; let mut sw = {child_wire}; inner.merge_inner(&data[s..e], &mut sw, &mut ip, depth + 1, {enforce}, None)?; {st} = Some(Box::new(inner)); }} }}',
  ]
  for pattern in patterns:
   old='''            let _ = writeln!(
                src,
                "'''+pattern+'''"
            );'''
   # The LEN branch is indented four spaces deeper than the group branch.
   if old not in text:
    old='''                let _ = writeln!(
                    src,
                    "'''+pattern+'''"
                );'''
   assert old in text,pattern
   heap_pattern=pattern.replace('let mut inner = {t}::default();','let mut inner = Box::<{t}>::default();').replace('Some(Box::new(inner))','Some(inner)')
   heap_stmt=old.replace(pattern,heap_pattern)
   indent=old[:len(old)-len(old.lstrip())]
   new=indent+'if OWNED_MESSAGE_FIELDS.with(|owned| owned.get()) {\n'+heap_stmt+'\n'+indent+'} else {\n'+old+'\n'+indent+'}'
   text=text.replace(old,new,1)
 (out/'src/codegen/parse.rs').write_text(text)
 changed={}
 for p in sorted(out.rglob('*')):
  if p.is_file() and sha(p)!=sha(base/p.relative_to(out)):
   changed[str(p.relative_to(out))]=dict(old_sha256=sha(base/p.relative_to(out)),new_sha256=sha(p))
 assert set(changed)=={'src/codegen/parse.rs'}
 record=dict(schema='pbrs.performance-variant-source.v1',baseline='934bba317805356e11b58145f0068ad8279b0ae0',baseline_snapshot=str(base),source=str(out),declared_changes=changed,files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},baseline_manifest_sha256=sha(record_path),variant='heap' if heap else 'stack',common_changes='Owned-only fused parser match and shared Wire propagation to LEN and message-valued map children; checks/default Lazy generated output preserved.')
 (out.parent/(out.name+'-source.json')).write_text(json.dumps(record,indent=2)+'\n')
 print(json.dumps(dict(source=str(out),variant=record['variant'],changes=changed)))
