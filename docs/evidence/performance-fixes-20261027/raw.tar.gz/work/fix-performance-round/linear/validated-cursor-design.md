# Safe sparse linear materialization alternative (read-only design)

This is a design sketch, not implemented code, correctness evidence or a
performance prediction. It addresses the current eager-subtree prototype's
partial-getter tradeoff while keeping a real provenance boundary.

## Capability and cursor

1. `Validated<T>` owns an immutable `Wire`, its original root-relative depth,
   and `PhantomData<T>`. Its fields and unchecked constructor stay private to
   the runtime. Its public checked constructor invokes T's real validator,
   requires full span consumption, and enforces the original depth budget.
   New generated types override the trait validator with their existing
   stateless inherent validator; legacy types retain checked merge fallback.
2. `Validated<T>::cursor()` produces an opaque cursor with private position.
   Only `next()` advances it, from the beginning in wire order. It decodes the
   actual tag, bounded wire payload and exact field extent. There is no public
   set_position, arbitrary-range constructor or caller-supplied trusted bool.
3. Each returned field token is tied to this cursor's validated parent type,
   actual field number/wire type and exact span. The token can expose ordinary
   bytes without conferring a child-message capability.
4. New generated types provide schema metadata mapping an actual message
   field number and wire representation to the child type's TypeId. A field
   token's `message<U>()` mints `Validated<U>` only when this metadata matches
   U's identity and the actual wire representation. A byte field, wrong tag,
   mismatched U, or arbitrary slice cannot mint a trusted child.
5. An extra trait method can return Option<TypeId> with default None rather
   than adding a 'static bound to the existing MergeBytes trait. Concrete
   generated owned types can return TypeId::of::<Self>(); old/custom types
   without metadata stay on the fully checked fallback. The same trust in a
   generated schema implementation already underlies its validator. A custom
   user implementation lying about its own validator/metadata is not evidence
   about an otherwise trusted generated type.

A public `Validated<Parent>::child<U>(start,end)` would NOT suffice: the caller
could pass the contents of a bytes field while naming a genuine child field.
Checking only range containment or TypeId does not establish a field boundary.
The opaque ordered cursor is what proves the actual field span.

## Shallow materializer

The generated validated materializer consumes this cursor rather than running
normal merge with a skip-validation flag. It decodes the current message's own
fields and stores child field tokens as lazy validated children. It does not
revalidate descendants, and does not eagerly build them. The ordinary parse
still validates the full unread tree once. Full traversal visits each actual
message field once more for materialization; first-child-only reads construct
only that child.

Immediate scalar/tag/length bounds remain checked in the cursor. UTF-8 can
initially retain its checked scalar materialization path; optimizing repeated
UTF-8 checks would need a separate validated-string capability. Unknown fields
must preserve their exact raw wire and known fields with the wrong wire type
must keep the current unknown-field behavior.

Normal public LazyMsg::from_wire remains untrusted and uses checked merge.
A new checked lazy constructor obtains Validated<T> through T's validator.
Only runtime-created child field tokens select the validated materializer.
Mutation clears the raw cache as today. New merge fragments use ordinary
checked parsing at the actual caller depth; an old token never authorizes a
new buffer. Duplicate singular occurrences still merge their final child tree.
Required-initialization graphs can retain today's eager checked merge/final
required checks; the sparse capability path starts with required-free graphs.

## Maps, repeated messages and groups

Repeated owned message elements and map values still need their immediate
owned value, but can shallow-materialize from child tokens so alternating
repeated/map/singular paths do not restore quadratic validation.

Map entry schemas need explicit metadata for synthetic entry field 2 and its
value type; treating all LEN entry bytes as a message would be insufficient.
This may use a generated private schema marker or a dedicated validated-entry
cursor with the parent's key/value schema metadata.

Groups need special handling. Naively scanning to the matching end tag to
produce every group span can itself become quadratic on nested groups.
Known group fields should create a scoped nested cursor that consumes the same
wire stream until its matching end tag, materializing the mandatory group
owned value on the way. It propagates validated LEN child tokens, then returns
the ending position to the parent. Unknown groups are skipped once and retained
as unknown wire. An alternative is recording group boundaries during the
original validation, but that adds an index/allocation cost that must be measured.

## Required rejection tests

- Public raw Wire and LazyMsg construction cannot choose a trusted path.
- A token for a bytes field cannot become a message token even when payload
  bytes look like protobuf. A real child token cannot be cast to another type.
- Cursor tokens cannot be forged from offsets into payload bytes or from
  another backing allocation, reset or reused after mutation.
- Malformed unread descendants, UTF-8, unknown groups, length/tag truncation
  and root-relative depth fail during ordinary parse as before.
- Old generated bindings/custom MergeBytes types keep checked fallback.
- Split/duplicate singular messages, required graphs, repeated elements,
  map last-wins and oneof replacement preserve existing final-tree semantics.
- Deep scalar-only chains, first-child-only reads and mixed map/repeated/group
  chains prove linear visit counts and retain equivalent read checksums.

The larger cursor and schema-metadata backend must be evaluated for generated
bytes, clean/incremental builds, binary size, runtime CPU, allocation traffic,
retained backing memory and legacy compatibility. It should be prototyped
separately from the current small eager-subtree change, with independent frozen
before/after comparisons. No unsafe unchecked parsing API is necessary.
