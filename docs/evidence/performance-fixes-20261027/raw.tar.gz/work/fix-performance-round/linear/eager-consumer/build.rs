fn main() {
    pbrs::codegen::Config::new()
        .compile_protos(&["proof.proto", "strict.proto"], &["."])
        .unwrap();
    println!("cargo:rerun-if-changed=proof.proto");
    println!("cargo:rerun-if-changed=strict.proto");
}
