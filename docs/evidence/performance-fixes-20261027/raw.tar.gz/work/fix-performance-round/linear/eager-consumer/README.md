# Checked linear materialization

This generated consumer checks the owned nested-message materializer. Ordinary
parse still validates every descendant before storing a lazy child. On the
first getter, newly generated types construct that child's complete owned tree
with the normal wire, UTF-8, recursion and initialization checks.

Run from the repository root with Rust and `protoc` available:

```sh
cargo run --locked --manifest-path tests/proof/linear_decode/Cargo.toml
```

A 64-node fixture checks that reading the remaining descendants after the first
child getter makes no allocations. This catches deferred per-getter rebuilding
without imposing a noisy timing threshold. The consumer also checks unchanged
wire serialization, clone independence, merge behavior, unread malformed data,
recursion limits, required-field merging/replacement, free oneof reuse/switching,
and descendant values through repeated messages, maps and groups. Proto2 legacy
string bytes and proto3 UTF-8 rejection remain separate controls.

Regenerate bindings to opt into the new materializer. The old three-argument
`impl_typed_message!` expansion and custom `MergeBytes` implementations keep the
ordinary checked fallback. This test proves the stated behavior and cost
invariant; it does not establish a performance ranking. The codec benchmark
records full reads, sparse parsing and partial reads separately.
