"""Bind the public API-generated codec source to the frozen owned experiment."""
import argparse
import hashlib
import json
from pathlib import Path

root=Path(__file__).resolve().parents[3]
base=root/'work/fix-performance-round/benchmark'
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--candidate', default='owned-candidate')
parser.add_argument('--output',default='owned-api-equivalence.json')
args=parser.parse_args()
messages=[json.loads(line) for line in (base/args.candidate/'codec-shipping.jsonl').read_text().splitlines()]
outputs=[Path(row['out_dir'])/'pbrs/codec_cases.rs' for row in messages if row.get('reason')=='build-script-executed' and 'pbrs-codec-proof' in row.get('package_id','')]
assert len(outputs)==1,outputs
consumer=[]
for line in (root/'work/fix-performance-round/linear/owned-profile-v3-consumer.jsonl').read_text().splitlines():
 if line.startswith('{'):
  consumer.append(json.loads(line))
api=[Path(row['out_dir'])/'api-codec/codec_cases.rs' for row in consumer if row.get('reason')=='build-script-executed' and 'pbrs-owned-messages-proof' in row.get('package_id','')]
assert len(api)==1,api
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record=dict(frozen=str(outputs[0]),public_api=str(api[0]),frozen_sha256=sha(outputs[0]),public_api_sha256=sha(api[0]))
record['identical']=record['frozen_sha256']==record['public_api_sha256']
(root/'work/fix-performance-round/linear'/args.output).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record))
if not record['identical']:raise SystemExit(1)
