"""Isolate the existing one-pass owned-child path on the committed baseline."""
import difflib
import hashlib
import json
from pathlib import Path
import shutil

base=Path(__file__).resolve().parents[1]/'benchmark/baseline-source'
out=base.parent/'owned-source'
if out.exists():raise ValueError('Owned snapshot already exists')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copytree(base,out)
p=out/'src/codegen/naming.rs'
s=p.read_text()
old='''pub(crate) fn is_lazy_msg(f: &FieldDescriptor) -> bool {
    !f.is_map
        && f.cardinality != Cardinality::Repeated
        && f.field_type == FieldType::Message
        && !f.delimited
}'''
new='''pub(crate) fn is_lazy_msg(_: &FieldDescriptor) -> bool {
    false
}'''
assert old in s
p.write_text(s.replace(old,new,1))
changed={}
for path in sorted(out.rglob('*')):
 if not path.is_file():continue
 name=str(path.relative_to(out))
 if sha(path)!=sha(base/name):changed[name]=dict(old_sha256=sha(base/name),new_sha256=sha(path))
assert set(changed)=={'src/codegen/naming.rs'}
record=dict(schema='pbrs.performance-variant-source.v1',baseline='934bba317805356e11b58145f0068ad8279b0ae0',baseline_snapshot=str(base),source=str(out),declared_changes=changed,files={str(p.relative_to(out)):sha(p) for p in sorted(out.rglob('*')) if p.is_file()},baseline_manifest_sha256=sha(base.parent/(base.name+'-source.json')),scope='Only is_lazy_msg=false, selecting existing Option<Box<T>> checked normal parser/accessor/encoder paths. No EAGER hook/runtime changes.',notes=['is_cold_field also uses is_lazy_msg for WKT placement, so WKT-heavy layouts can differ. The full16 codec corpus has no WKT message fields.','This is a frozen experiment, not a live default change or public configuration API.'])
(out.parent/'owned-source-source.json').write_text(json.dumps(record,indent=2)+'\n')
patch=''.join(difflib.unified_diff(s.splitlines(True),p.read_text().splitlines(True),fromfile='a/src/codegen/naming.rs',tofile='b/src/codegen/naming.rs'))
(Path(__file__).resolve().parent/'owned-only.patch').write_text(patch)
print(json.dumps(dict(source=str(out),changes=changed,files=len(record['files']))))
