use pbrs::codegen::generate_from_code_generator_request;
use pbrs::rt::{encode_len_field, encode_tag, encode_varint};
#[cfg(feature = "allocation-counts")]
use std::alloc::{GlobalAlloc, Layout, System};
use std::path::PathBuf;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::time::Instant;

#[cfg(feature = "allocation-counts")]
struct Counter;
static CALLS: AtomicUsize = AtomicUsize::new(0);
static BYTES: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);

#[cfg(feature = "allocation-counts")]
fn acquired(n: usize) {
    CALLS.fetch_add(1, Ordering::Relaxed);
    BYTES.fetch_add(n, Ordering::Relaxed);
    let live = LIVE.fetch_add(n, Ordering::Relaxed) + n;
    PEAK.fetch_max(live, Ordering::Relaxed);
}

#[cfg(feature = "allocation-counts")]
unsafe impl GlobalAlloc for Counter {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() { acquired(layout.size()); }
        p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() { acquired(layout.size()); }
        p
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, n: usize) -> *mut u8 {
        let out = unsafe { System.realloc(p, layout, n) };
        if !out.is_null() {
            LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
            acquired(n);
        }
        out
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) {
        LIVE.fetch_sub(layout.size(), Ordering::Relaxed);
        unsafe { System.dealloc(p, layout); }
    }
}

#[global_allocator]
#[cfg(feature = "allocation-counts")]
static ALLOCATOR: Counter = Counter;

fn scalar(out: &mut Vec<u8>, tag: u32, value: u64) {
    encode_tag(out, tag, 0);
    encode_varint(out, value);
}

fn request(files: usize, messages: usize, fields: usize, shared: bool, lean: bool) -> Vec<u8> {
    let mut request = Vec::new();
    let option = format!("stubs=none,shared_descriptor_set={shared},emit_json={},emit_text={}",!lean,!lean);
    encode_len_field(&mut request, 2, option.as_bytes());
    for file in 0..files {
        let filename = format!("file_{file:03}.proto");
        encode_len_field(&mut request, 1, filename.as_bytes());
        let mut proto = Vec::new();
        encode_len_field(&mut proto, 1, filename.as_bytes());
        encode_len_field(&mut proto, 2, format!("bench.f{file}").as_bytes());
        encode_len_field(&mut proto, 12, b"proto3");
        if file != 0 { encode_len_field(&mut proto, 3, b"file_000.proto"); }
        for message in 0..messages {
            let mut descriptor = Vec::new();
            encode_len_field(&mut descriptor, 1, format!("Message{message}").as_bytes());
            for field in 0..fields {
                let mut fld = Vec::new();
                encode_len_field(&mut fld, 1, format!("field_{field}").as_bytes());
                scalar(&mut fld, 3, (field + 1) as u64);
                scalar(&mut fld, 4, 1);
                scalar(&mut fld, 5, if file != 0 && field == 0 { 11 } else { 5 });
                if file != 0 && field == 0 { encode_len_field(&mut fld, 6, b".bench.f0.Message0"); }
                encode_len_field(&mut descriptor, 2, &fld);
            }
            encode_len_field(&mut proto, 4, &descriptor);
        }
        encode_len_field(&mut request, 15, &proto);
    }
    request
}

#[repr(C)]
struct CpuTime { seconds: i64, nanos: i64 }
unsafe extern "C" { fn clock_gettime(clock_id: i32, value: *mut CpuTime) -> i32; }
fn process_cpu_nanos() -> u64 {
    let mut value = CpuTime { seconds: 0, nanos: 0 };
    assert_eq!(unsafe { clock_gettime(2, &mut value) }, 0);
    value.seconds as u64 * 1_000_000_000 + value.nanos as u64
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    let files: usize = args[1].parse().unwrap();
    let messages: usize = args[2].parse().unwrap();
    let fields: usize = args[3].parse().unwrap();
    let shared: bool = args[4].parse().unwrap();
    let lean: bool = args[5].parse().unwrap();
    let out = PathBuf::from(&args[6]);
    let repeats: usize = args[7].parse().unwrap();
    let dump = args.get(8).map(|value| value.parse::<bool>().unwrap()).unwrap_or(true);
    std::fs::create_dir_all(&out).unwrap();
    let input = request(files, messages, fields, shared, lean);
    std::fs::write(out.join("request.bin"), &input).unwrap();
    for repeat in 0..repeats {
        let before_calls = CALLS.load(Ordering::Relaxed);
        let before_bytes = BYTES.load(Ordering::Relaxed);
        let before_live = LIVE.load(Ordering::Relaxed);
        PEAK.store(before_live, Ordering::Relaxed);
        let cpu_start = process_cpu_nanos();
        let start = Instant::now();
        let generated = generate_from_code_generator_request(&input).unwrap();
        let nanos = start.elapsed().as_nanos();
        let cpu_nanos = process_cpu_nanos() - cpu_start;
        let peak = PEAK.load(Ordering::Relaxed).saturating_sub(before_live);
        let live = LIVE.load(Ordering::Relaxed).saturating_sub(before_live);
        let calls = CALLS.load(Ordering::Relaxed) - before_calls;
        let bytes = BYTES.load(Ordering::Relaxed) - before_bytes;
        let generated_bytes: usize = generated.iter().map(|(_,text)|text.len()).sum();
        println!("{{\"repeat\":{repeat},\"nanos\":{nanos},\"cpu_nanos\":{cpu_nanos},\"allocations\":{calls},\"requested_bytes\":{bytes},\"peak_live_delta\":{peak},\"retained_delta\":{live},\"generated_bytes\":{generated_bytes},\"files\":{},\"threads_available\":{},\"allocation_counts\":{}}}", generated.len(), std::thread::available_parallelism().map(|n|n.get()).unwrap_or(1), cfg!(feature="allocation-counts"));
        if repeat == 0 && dump {
            for (name, text) in &generated {
                let target = out.join(name);
                if let Some(parent) = target.parent() { std::fs::create_dir_all(parent).unwrap(); }
                std::fs::write(target, text).unwrap();
            }
        }
        drop(generated);
    }
}
