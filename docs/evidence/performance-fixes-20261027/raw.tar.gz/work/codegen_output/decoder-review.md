# Rejected eager-on-getter codegen review

This reviewed prototype was rejected after partial-access measurements. Its
source hashes and measurements describe that frozen prototype, not the current
explicit owned-message profile.

The checked EAGER mode keeps one generated parser source body and selects
normal or eager behavior through a const boolean. Existing three-argument
`impl_typed_message!` invocations retain the legacy checked default; fresh
four-argument invocations statically select checked eager materialization.
The public helper remains valid for untrusted wire and adds no unsafe code.
The initially incorrect UFCS receivers for `Box<T>` were already corrected
by the owner; the mixed group/map/repeated/required consumer compiles.

Existing generator checks pass: 19 unit tests, one shared-descriptor structural
control and one generated unique-stem alias consumer. Source hashes, commands
and exact scopes are in `decoder-review.json`; logs are `live-*.log`.

The first descendant getter now constructs its entire subtree. Sparse initial
parse stays lazy, but partial getter cost and allocations can regress. The
prepared partial-getter campaign is an adoption requirement. Existing bundled
macro3 bindings keep legacy behavior until regenerated. This review does not
establish arbitrary schema correctness or any compile-time speedup.

On the exact codec schema, refreshed baseline output matches the historical
SHA-256. Pbrs generated source grows 173,535→178,686 bytes (+5,151, +2.9683%);
Prost output stays 4,764 bytes with the same hash. Source lines grow
3,286→3,299. This is one fixture and does not establish the cost of checking or
compiling generated consumers. Const-mode monomorphization can produce two
parser implementations where both are reachable, despite one source body.

The counters-off full codec probe grows from 825,520→830,288 file bytes.
Actual ELF `.text` grows 497,441→500,913 bytes (+3,472, +0.698%). GNU size's
default `text` aggregate grows 640,386→644,402 (+4,016, +0.627%); it includes
read-only/unwind sections and is not the literal `.text` section. Exact section
maps and hashes are in `decoder-elf-size.json`. Build wall times overlap queued
and concurrent work and are deliberately not compared. These artifact costs
belong in the evidence alongside runtime wins and partial-getter losses.
