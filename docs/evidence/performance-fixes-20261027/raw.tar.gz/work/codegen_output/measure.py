import argparse, hashlib, json, random, re, statistics, subprocess
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CASES = [
    ("single_100_full", 1, 100, 8, False, False),
    ("twenty_1000_full", 20, 50, 8, False, False),
    ("twenty_1000_shared_lean", 20, 50, 8, True, True),
    ("hundred_1000_shared_lean", 100, 10, 4, True, True),
    ("hundred_1000_shared_full", 100, 10, 4, True, False),
    ("hundred_1000_full", 100, 10, 4, False, False),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(side, phase, case, process=0):
    name, files, messages, fields, shared, lean = case
    directory = ROOT / "measurements" / phase / side / name / str(process)
    directory.mkdir(parents=True, exist_ok=False)
    binary = ROOT / f"{side}-{'alloc' if phase=='allocation' else 'shipping'}"
    command = [str(binary),str(files),str(messages),str(fields),str(shared).lower(),str(lean).lower(),str(directory),"9",str(phase=="allocation").lower()]
    wrapped = [str(ROOT / "rss-wrap"), *command]
    result = subprocess.run(wrapped, text=True, capture_output=True, timeout=90)
    rss = re.findall(r"^MAX_RSS_KIB=(\d+)$", result.stderr, re.M)
    assert len(rss) == 1, result.stderr
    (directory / "stdout.jsonl").write_text(result.stdout)
    (directory / "stderr.log").write_text(result.stderr)
    assert result.returncode == 0, result.stderr
    samples = [json.loads(line) for line in result.stdout.splitlines()]
    assert len(samples)==9 and all(x["allocation_counts"]==(phase=="allocation") for x in samples)
    outputs = {str(p.relative_to(directory)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in directory.rglob('*.rs')}
    row=dict(side=side,phase=phase,case=name,process=process,command=command,
             binary_sha256=sha(binary),input_sha256=sha(directory/"request.bin"),
             samples=samples,generated=outputs,exit_code=result.returncode, wrapper_command=wrapped,max_rss_bytes=int(rss[0])*1024)
    (directory/"capture.json").write_text(json.dumps(row,indent=2)+'\n')
    for generated_path in directory.rglob("*.rs"): generated_path.unlink()
    print(phase,side,name,process,flush=True)
    return row

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--side',choices=['baseline','candidate']);parser.add_argument('--phase',choices=['allocation','shipping'],required=True);args=parser.parse_args()
    rows=[]
    if args.phase=='allocation':
        assert args.side
        for case in CASES: rows.append(run(args.side,args.phase,case))
        report=dict(schema="pbrs.codegen-output-ownership.v1",qualified=False,rows=rows)
        (ROOT/f'{args.side}-allocation.json').write_text(json.dumps(report,indent=2)+'\n')
    else:
        groups=[(process,case) for process in range(7) for case in CASES];random.Random(271349).shuffle(groups)
        for i,(process,case) in enumerate(groups):
            for side in (['baseline','candidate'] if i%2==0 else ['candidate','baseline']): rows.append(run(side,args.phase,case,process))
        (ROOT/'shipping.json').write_text(json.dumps(dict(schema="pbrs.codegen-output-ownership.v1",qualified=False,rows=rows),indent=2)+'\n')

if __name__=='__main__': main()
