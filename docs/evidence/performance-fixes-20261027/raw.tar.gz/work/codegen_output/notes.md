# Rejected codegen output ownership experiment

Baseline: `934bba317805356e11b58145f0068ad8279b0ae0`.
The tested candidate changes only `src/codegen/descriptors.rs` in a compact
frozen root-package copy. It compacts and transfers a target's final String
when that target has no compatibility alias, rather than cloning the whole
source and dropping the scratch allocation. Alias output behavior is unchanged.

Decision: **no-go; production file reverted byte-for-byte to the baseline**.
The apparent copy removal reduced process maximum RSS, but generation CPU
regressed consistently. Both complete paired campaigns and all losses remain.

All six synthetic cases have byte-identical output filenames, sizes and
SHA-256 maps. Allocation calls fall by one per target (1, 20 or 100), while
retained requested bytes rise by five bytes per target from moving the filename
String's capacity. Source Strings remain exactly compacted. Requested-live
peak changes range from -34.94% to +4.61%; worker overlap affects these peaks.
They are not allocator fragmentation, transient allocator-internal realloc
memory, or process RSS measurements.

The separate release binaries disable allocation counters for CPU/RSS runs.
A small compiled `rss-wrap.c` executes the helper and obtains the child's
`ru_maxrss` with Linux wait4. This measures process peak RSS, including all
nine generations and setup, unlike the narrow per-generation CPU timer.
The wrapper is built with `cc -O2 -Wall -Wextra -Werror rss-wrap.c -o rss-wrap`.
Its source is retained; do not archive the executable. The phase uses seven
fresh randomized process pairs per case with seed 271349; each process performs
one cold and eight warm generations, drops each result and saves every sample.
The allocation phase separately performs nine generations per case/side.

## Second explicitly coordinated quiet run

| Case | Warm CPU paired median | Cold CPU paired median | Process max RSS paired median |
|---|---:|---:|---:|
| single_100_full | +14.38% | -10.48% | -3.11% |
| twenty_1000_full | +5.38% | -9.43% | -4.35% |
| twenty_1000_shared_lean | +16.85% | +1.17% | -8.44% |
| hundred_1000_shared_lean | +39.29% | +32.41% | -3.28% |
| hundred_1000_shared_full | +31.30% | +14.87% | -3.81% |
| hundred_1000_full | +12.85% | +25.23% | -3.50% |

All six warm CPU medians lose. Four wall medians lose 12.24–21.94%; the other
two are approximately flat (-0.07% and -0.63%). Individual pairs and every
cold/warm loss remain in `summary.json`, `shipping.json` and the captures.
The run spans 19:30:12.678605Z–19:30:25.846714Z. Cgroup throttling counts and
time do not increase. This is one shared x86_64 VM, not a ranking campaign.

The first phase also loses warm CPU in all cases (+3.71% to +44.81%) with RSS
reductions. Its files retain a provisional `contaminated` label because root
initially suspected a compiler overlap. Subsequent timestamps put that compiler
start after the capture period (first output 19:27:07Z, report 19:27:19Z;
suspected build around19:27:30Z). Actual overlap was not established. The
`contamination.json` record explains the correction; the second quiet run
confirms the no-go independently rather than deleting either result.

A frozen-core unit-test attempt with `--locked` failed before compilation
because narrowing workspace membership requires an isolated lock rewrite.
This is a harness setup failure, not a product test failure; `unit.log` remains.
No codegen correctness claim relies on that invocation. Existing live generator
tests are run separately when the decoder's concurrent changes compile.

## Reproduce

The scratch helper comes from the prior codegen_resolution probe. Before and
after source maps prove only descriptors.rs differs between the frozen variants.
The workspace member list is narrowed identically on both sides. The scratch
lock is identical and resolves serde_json1.0.154 rather than the root1.0.151;
that is a limitation, not a hidden source change. Rust1.99.1 release defaults,
one Cargo build job, incremental off, shared target cache. Keep both frozen
binaries, or rebuild them as recorded in the build logs before measuring.

`measure.py --phase allocation --side baseline` and then candidate produce the
allocation captures; `measure.py --phase shipping` refuses to overwrite its
rows. Preserve prior results before a fresh run. `analyze.py` verifies matching
request/output hashes and retains all paired distributions. Output Rust files
are deleted only after exact hashes and byte sizes are saved to avoid disk
pressure. No consumer compilation timing was measured by this experiment.
