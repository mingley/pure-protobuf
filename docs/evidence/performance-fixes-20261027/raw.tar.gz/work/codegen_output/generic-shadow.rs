#[derive(Default)]
struct EAGER { number: u32 }
fn ordinary<const EAGER: bool>() { let _: EAGER = EAGER::default(); }
fn main() { ordinary::<true>(); }
