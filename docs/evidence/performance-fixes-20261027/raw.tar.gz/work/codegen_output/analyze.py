import hashlib
import json
from pathlib import Path
import statistics

ROOT = Path(__file__).resolve().parent

def read(name):
    return json.loads((ROOT / name).read_text())

def median(samples, key):
    return statistics.median(sample[key] for sample in samples)

def distribution(values):
    return dict(median=statistics.median(values), min=min(values), max=max(values), count=len(values))

before = read("baseline-allocation.json")["rows"]
after = read("candidate-allocation.json")["rows"]
shipping = read("shipping.json")["rows"]
cases = []
for baseline, candidate in zip(before, after):
    assert baseline["case"] == candidate["case"]
    assert baseline["input_sha256"] == candidate["input_sha256"]
    assert baseline["generated"] == candidate["generated"]
    name = baseline["case"]
    case = dict(case=name, input_sha256=baseline["input_sha256"], byte_identical_output=True,
                generated_files=len(baseline["generated"]), generated_bytes=baseline["samples"][0]["generated_bytes"],
                allocation={}, shipping={})
    for key in ["allocations", "requested_bytes", "peak_live_delta", "retained_delta"]:
        left = median(baseline["samples"][1:], key)
        right = median(candidate["samples"][1:], key)
        case["allocation"][key] = dict(baseline=left, candidate=right, difference=right-left,
            percent_change=100*(right/left-1) if left else None,
            baseline_cold=baseline["samples"][0][key], candidate_cold=candidate["samples"][0][key])
    rows = [row for row in shipping if row["case"] == name]
    assert len(rows) == 14
    for side in ["baseline", "candidate"]:
        side_rows = [row for row in rows if row["side"] == side]
        assert all(row["input_sha256"] == case["input_sha256"] for row in side_rows)
        assert all(sample["generated_bytes"] == case["generated_bytes"] for row in side_rows for sample in row["samples"])
        case["shipping"][side] = {"process_max_rss_bytes":distribution([row["max_rss_bytes"] for row in side_rows])}
        for key in ["nanos", "cpu_nanos"]:
            case["shipping"][side][key] = dict(
                warm=distribution([sample[key]/1e6 for row in side_rows for sample in row["samples"][1:]]),
                cold=distribution([row["samples"][0][key]/1e6 for row in side_rows]),
                process_warm_medians=distribution([median(row["samples"][1:], key)/1e6 for row in side_rows]))
    rss_pairs=[]
    for process in range(7):
        left=next(row for row in rows if row["side"]=="baseline" and row["process"]==process)
        right=next(row for row in rows if row["side"]=="candidate" and row["process"]==process)
        rss_pairs.append(100*(right["max_rss_bytes"]/left["max_rss_bytes"]-1))
    case["shipping"]["rss_paired_percent_change"]=dict(distribution(rss_pairs),pairs=rss_pairs)
    for key in ["nanos", "cpu_nanos"]:
        pairs = []
        cold_pairs = []
        for process in range(7):
            left = next(row for row in rows if row["side"] == "baseline" and row["process"] == process)
            right = next(row for row in rows if row["side"] == "candidate" and row["process"] == process)
            pairs.append(100*(median(right["samples"][1:], key)/median(left["samples"][1:], key)-1))
            cold_pairs.append(100*(right["samples"][0][key]/left["samples"][0][key]-1))
        case["shipping"][key+"_paired_warm_percent_change"] = dict(distribution(pairs), pairs=pairs)
        case["shipping"][key+"_paired_cold_percent_change"] = dict(distribution(cold_pairs), pairs=cold_pairs)
    cases.append(case)
    print(name, "alloc",case["allocation"]["allocations"]["difference"],
          "CPU%",round(case["shipping"]["cpu_nanos_paired_warm_percent_change"]["median"],2),
          "wall%",round(case["shipping"]["nanos_paired_warm_percent_change"]["median"],2))

artifact_paths = [ROOT / name for name in ["Cargo.toml", "Cargo.lock", "src/main.rs", "measure.py",
    "baseline-source.json", "candidate-source.json", "baseline-alloc", "candidate-alloc",
    "baseline-shipping", "candidate-shipping", "baseline-allocation.json", "candidate-allocation.json", "shipping.json"]]
report = dict(schema="pbrs.codegen-output-ownership-summary.v1", qualified=False, baseline_commit="934bba317805356e11b58145f0068ad8279b0ae0",
    environment=dict(architecture="x86_64",available_parallelism=4,cgroup_cpu_max="400000 100000",
        clock="CLOCK_PROCESS_CPUTIME_ID (2), all process threads", rustc="1.99.1 (58cf8f9c3 2026-10-13)",
        build="Cargo release defaults, no Rust flag override", shared_host=True),
    limitations=["Synthetic local generation diagnostic; not a qualified tonic/prost or world leadership comparison.",
        "Same scratch lock on both sides; serde_json1.0.154 differs from repository1.0.151.",
        "No source compilation/build-time speed measured. Single-target local-type case is retained.",
        "Output files deleted after recording their exact SHA-256 and byte count.",
        "Requested-live bytes exclude allocator metadata/fragmentation and are not RSS.",
        "Wall time can vary due to scheduling; all paired CPU/wall wins and losses are retained."],
    artifacts={str(path.relative_to(ROOT)):hashlib.sha256(path.read_bytes()).hexdigest() for path in artifact_paths}, cases=cases)
(ROOT / "summary.json").write_text(json.dumps(report,indent=2)+"\n")
