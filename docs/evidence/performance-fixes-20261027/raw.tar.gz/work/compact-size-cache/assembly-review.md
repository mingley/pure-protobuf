# Owned allocation assembly review

Read-only review of the already frozen V1 and V2 shipping executables. No
build, benchmark, profiler, allocator tuning or production source edit was
performed. `assembly-review.json` records executable/generated-source hashes
and disassembler/libc versions. Three small `.asm` files retain the inspected
functions.

## Verified generated-source difference

V1 `owned-candidate/generated/pbrs-codec_cases.rs:1802` constructs a default
`Node` on the stack, recursively merges its child wire, then assigns
`Some(Box::new(inner))`. Its cache is the original `CachedSize`.

V2 `owned-v2-candidate/generated/pbrs-codec_cases.rs:1802` starts with
`Box::<Node>::default()`, recursively merges into that heap allocation, then
assigns the box. Its cache is `CachedSize32`. Both versions use normal checked
parsing; these two variants do not isolate cache width from allocation staging.

## Verified machine-code difference

In the V1 executable, `Node::merge_heavy` is at `0x58320`, size `0x32e` (814
bytes). Its fresh-child path:

1. Calls `Node::merge_inner` with a stack result at `0x584ed`.
2. On success, passes 32 (`0x20`) to `malloc` at `0x5853a`.
3. Copies the 32-byte parsed value with two 16-byte SIMD loads/stores at
   `0x58545`–`0x58552`, then stores the child pointer.

In the V2 executable, `Node::merge_heavy` is at `0x581b0`, size `0x2d2` (722
bytes). Its fresh-child path:

1. Passes 24 (`0x18`) and 1 to `calloc` at `0x5833d`.
2. Calls `Node::merge_inner` on that returned heap pointer at `0x58397`.
3. On success, stores the pointer at `0x583b3`, without the V1 32-byte copy.

The reserved stack frame also shrinks from `0xb8` (184) to `0x98` (152) bytes.
Thus the new code is smaller and avoids copying the parsed child, but it
changes the allocator entry point to zeroed allocation before parsing. It is
not merely the V1 allocation with fewer copied bytes.

The independent Prost control in the same V2 executable has a fresh-child
path in `Node::merge_field` that passes 16 (`0x10`) to `malloc` at `0x45555`,
then explicitly writes a zero pointer and zero scalar at `0x45567` and
`0x4556e`. That path heap-stages its child without using `calloc`.

Commands:

```
nm -S -C EXECUTABLE
objdump -R EXECUTABLE
objdump -d -C --start-address=0x58320 --stop-address=0x58650 V1_EXECUTABLE
objdump -d -C --start-address=0x581b0 --stop-address=0x58490 V2_EXECUTABLE
objdump -d -C --start-address=0x453f0 --stop-address=0x45863 V2_EXECUTABLE
```

The preserved `.asm` files show the GOT relocation comments resolving the
calls to `malloc@GLIBC_2.2.5` and `calloc@GLIBC_2.2.5`. The host is Debian
glibc 2.41 (`2.41-12+deb13u3`). No assumption that this version's `calloc`
bypasses tcache has been verified or used.

## Interpretation and limits

The assembly establishes the allocation/copy tradeoff, not why V2's measured
CPU differs from V1 or Prost. The variants also differ in cache width, generated
layout and code layout. No allocation-path timing, cache-miss data or causal
instruction profile was collected here. V3's separately frozen stack/heap
variants are the appropriate next comparison; preserve all measured losses.

One safe future hypothesis is to initialize a fresh parser-owned child's cache
to DIRTY before boxing, since normal merge immediately dirties it anyway.
That could prevent LLVM's whole-zero-value allocation transformation while
retaining normal allocation and parsing. It is not implemented, its codegen
result is unknown, and it needs imported/old-generated compatibility plus empty,
encode and partial-read holdouts. No custom allocator or unsafe initialization
shortcut is proposed.
