
work/fix-performance-round/benchmark/owned-candidate/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

0000000000058320 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy>:
   58320:	55                   	push   %rbp
   58321:	41 57                	push   %r15
   58323:	41 56                	push   %r14
   58325:	41 55                	push   %r13
   58327:	41 54                	push   %r12
   58329:	53                   	push   %rbx
   5832a:	48 81 ec b8 00 00 00 	sub    $0xb8,%rsp
   58331:	89 d0                	mov    %edx,%eax
   58333:	48 89 fb             	mov    %rdi,%rbx
   58336:	44 8b b4 24 f0 00 00 	mov    0xf0(%rsp),%r14d
   5833d:	00 
   5833e:	83 fe 02             	cmp    $0x2,%esi
   58341:	0f 85 a3 00 00 00    	jne    583ea <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0xca>
   58347:	83 f8 02             	cmp    $0x2,%eax
   5834a:	0f 85 f4 00 00 00    	jne    58444 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x124>
   58350:	49 89 cf             	mov    %rcx,%r15
   58353:	48 89 cf             	mov    %rcx,%rdi
   58356:	4d 89 c4             	mov    %r8,%r12
   58359:	4c 89 c6             	mov    %r8,%rsi
   5835c:	4d 89 cd             	mov    %r9,%r13
   5835f:	4c 89 ca             	mov    %r9,%rdx
   58362:	ff 15 38 74 04 00    	call   *0x47438(%rip)        # 9f7a0 <_DYNAMIC+0x670>
   58368:	40 b5 01             	mov    $0x1,%bpl
   5836b:	a8 01                	test   $0x1,%al
   5836d:	0f 85 17 02 00 00    	jne    5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   58373:	49 8b 7d 00          	mov    0x0(%r13),%rdi
   58377:	31 f6                	xor    %esi,%esi
   58379:	4d 89 e0             	mov    %r12,%r8
   5837c:	49 29 f8             	sub    %rdi,%r8
   5837f:	49 0f 43 f0          	cmovae %r8,%rsi
   58383:	48 39 f2             	cmp    %rsi,%rdx
   58386:	0f 87 fe 01 00 00    	ja     5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   5838c:	4c 89 e0             	mov    %r12,%rax
   5838f:	48 8d 34 17          	lea    (%rdi,%rdx,1),%rsi
   58393:	49 89 75 00          	mov    %rsi,0x0(%r13)
   58397:	4c 8b 0b             	mov    (%rbx),%r9
   5839a:	4d 85 c9             	test   %r9,%r9
   5839d:	0f 84 03 01 00 00    	je     584a6 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x186>
   583a3:	48 c7 44 24 50 00 00 	movq   $0x0,0x50(%rsp)
   583aa:	00 00 
   583ac:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   583b3:	00 00 
   583b5:	48 39 fe             	cmp    %rdi,%rsi
   583b8:	0f 82 e0 01 00 00    	jb     5859e <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x27e>
   583be:	48 39 c6             	cmp    %rax,%rsi
   583c1:	0f 87 d7 01 00 00    	ja     5859e <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x27e>
   583c7:	4d 89 f8             	mov    %r15,%r8
   583ca:	49 01 f8             	add    %rdi,%r8
   583cd:	41 ff c6             	inc    %r14d
   583d0:	48 8d 4c 24 50       	lea    0x50(%rsp),%rcx
   583d5:	4c 89 cf             	mov    %r9,%rdi
   583d8:	4c 89 c6             	mov    %r8,%rsi
   583db:	45 89 f0             	mov    %r14d,%r8d
   583de:	e8 6d 02 00 00       	call   58650 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_inner>
   583e3:	89 c5                	mov    %eax,%ebp
   583e5:	e9 a0 01 00 00       	jmp    5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   583ea:	41 89 f2             	mov    %esi,%r10d
   583ed:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   583f2:	48 89 ce             	mov    %rcx,%rsi
   583f5:	4c 89 c2             	mov    %r8,%rdx
   583f8:	4c 89 c9             	mov    %r9,%rcx
   583fb:	45 89 d0             	mov    %r10d,%r8d
   583fe:	83 f8 03             	cmp    $0x3,%eax
   58401:	0f 84 56 01 00 00    	je     5855d <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x23d>
   58407:	41 89 c1             	mov    %eax,%r9d
   5840a:	ff 15 30 74 04 00    	call   *0x47430(%rip)        # 9f840 <_DYNAMIC+0x710>
   58410:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
   58416:	0f 84 6b 01 00 00    	je     58587 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x267>
   5841c:	48 83 c3 08          	add    $0x8,%rbx
   58420:	0f 10 44 24 20       	movups 0x20(%rsp),%xmm0
   58425:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   5842a:	0f 29 8c 24 a0 00 00 	movaps %xmm1,0xa0(%rsp)
   58431:	00 
   58432:	0f 29 84 24 90 00 00 	movaps %xmm0,0x90(%rsp)
   58439:	00 
   5843a:	48 8d b4 24 90 00 00 	lea    0x90(%rsp),%rsi
   58441:	00 
   58442:	eb 52                	jmp    58496 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x176>
   58444:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   58449:	48 89 ce             	mov    %rcx,%rsi
   5844c:	4c 89 c2             	mov    %r8,%rdx
   5844f:	4c 89 c9             	mov    %r9,%rcx
   58452:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   58458:	83 f8 03             	cmp    $0x3,%eax
   5845b:	0f 84 12 01 00 00    	je     58573 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x253>
   58461:	41 89 c1             	mov    %eax,%r9d
   58464:	ff 15 d6 73 04 00    	call   *0x473d6(%rip)        # 9f840 <_DYNAMIC+0x710>
   5846a:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
   58470:	0f 84 11 01 00 00    	je     58587 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x267>
   58476:	48 83 c3 08          	add    $0x8,%rbx
   5847a:	0f 10 44 24 20       	movups 0x20(%rsp),%xmm0
   5847f:	0f 10 4c 24 30       	movups 0x30(%rsp),%xmm1
   58484:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   5848b:	00 
   5848c:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   58491:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   58496:	48 89 df             	mov    %rbx,%rdi
   58499:	ff 15 51 73 04 00    	call   *0x47351(%rip)        # 9f7f0 <_DYNAMIC+0x6c0>
   5849f:	31 ed                	xor    %ebp,%ebp
   584a1:	e9 e4 00 00 00       	jmp    5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   584a6:	0f 57 c0             	xorps  %xmm0,%xmm0
   584a9:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   584ae:	0f 29 04 24          	movaps %xmm0,(%rsp)
   584b2:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   584b9:	00 00 
   584bb:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   584c2:	00 00 
   584c4:	48 39 fe             	cmp    %rdi,%rsi
   584c7:	0f 82 e3 00 00 00    	jb     585b0 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x290>
   584cd:	48 39 c6             	cmp    %rax,%rsi
   584d0:	0f 87 da 00 00 00    	ja     585b0 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x290>
   584d6:	4d 89 f8             	mov    %r15,%r8
   584d9:	49 01 f8             	add    %rdi,%r8
   584dc:	41 ff c6             	inc    %r14d
   584df:	48 89 e7             	mov    %rsp,%rdi
   584e2:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   584e7:	4c 89 c6             	mov    %r8,%rsi
   584ea:	45 89 f0             	mov    %r14d,%r8d
   584ed:	e8 5e 01 00 00       	call   58650 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_inner>
   584f2:	84 c0                	test   %al,%al
   584f4:	74 2c                	je     58522 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x202>
   584f6:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   584fb:	74 08                	je     58505 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x1e5>
   584fd:	48 89 e7             	mov    %rsp,%rdi
   58500:	e8 bb 91 fe ff       	call   416c0 <core::ptr::drop_glue::<alloc::boxed::Box<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>>>
   58505:	4c 8b 74 24 08       	mov    0x8(%rsp),%r14
   5850a:	4d 85 f6             	test   %r14,%r14
   5850d:	74 7b                	je     5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   5850f:	4c 89 f7             	mov    %r14,%rdi
   58512:	e8 69 8e fe ff       	call   41380 <core::ptr::drop_glue::<alloc::vec::Vec<pbrs::wire::UnknownField>>>
   58517:	4c 89 f7             	mov    %r14,%rdi
   5851a:	ff 15 40 6e 04 00    	call   *0x46e40(%rip)        # 9f360 <free@GLIBC_2.2.5>
   58520:	eb 68                	jmp    5858a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x26a>
   58522:	0f 28 04 24          	movaps (%rsp),%xmm0
   58526:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
   5852b:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
   58530:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   58535:	bf 20 00 00 00       	mov    $0x20,%edi
   5853a:	ff 15 38 6e 04 00    	call   *0x46e38(%rip)        # 9f378 <malloc@GLIBC_2.2.5>
   58540:	48 85 c0             	test   %rax,%rax
   58543:	74 7d                	je     585c2 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x2a2>
   58545:	0f 28 04 24          	movaps (%rsp),%xmm0
   58549:	0f 28 4c 24 10       	movaps 0x10(%rsp),%xmm1
   5854e:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   58552:	0f 11 00             	movups %xmm0,(%rax)
   58555:	48 89 03             	mov    %rax,(%rbx)
   58558:	e9 42 ff ff ff       	jmp    5849f <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x17f>
   5855d:	45 89 f1             	mov    %r14d,%r9d
   58560:	e8 7b 0c fe ff       	call   391e0 <pbrs::wire::capture_group_with_depth>
   58565:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
   5856b:	0f 85 ab fe ff ff    	jne    5841c <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0xfc>
   58571:	eb 14                	jmp    58587 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x267>
   58573:	45 89 f1             	mov    %r14d,%r9d
   58576:	e8 65 0c fe ff       	call   391e0 <pbrs::wire::capture_group_with_depth>
   5857b:	48 83 7c 24 20 ff    	cmpq   $0xffffffffffffffff,0x20(%rsp)
   58581:	0f 85 ef fe ff ff    	jne    58476 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x156>
   58587:	40 b5 01             	mov    $0x1,%bpl
   5858a:	89 e8                	mov    %ebp,%eax
   5858c:	48 81 c4 b8 00 00 00 	add    $0xb8,%rsp
   58593:	5b                   	pop    %rbx
   58594:	41 5c                	pop    %r12
   58596:	41 5d                	pop    %r13
   58598:	41 5e                	pop    %r14
   5859a:	41 5f                	pop    %r15
   5859c:	5d                   	pop    %rbp
   5859d:	c3                   	ret
   5859e:	48 8d 0d 4b 52 04 00 	lea    0x4524b(%rip),%rcx        # 9d7f0 <anon.4c4380c52c4ea4a9b70bfb9118c7b12f.1448.llvm.13649265099515623206+0x770>
   585a5:	48 89 c2             	mov    %rax,%rdx
   585a8:	ff 15 d2 6d 04 00    	call   *0x46dd2(%rip)        # 9f380 <_DYNAMIC+0x250>
   585ae:	eb 22                	jmp    585d2 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x2b2>
   585b0:	48 8d 0d 21 52 04 00 	lea    0x45221(%rip),%rcx        # 9d7d8 <anon.4c4380c52c4ea4a9b70bfb9118c7b12f.1448.llvm.13649265099515623206+0x758>
   585b7:	48 89 c2             	mov    %rax,%rdx
   585ba:	ff 15 c0 6d 04 00    	call   *0x46dc0(%rip)        # 9f380 <_DYNAMIC+0x250>
   585c0:	eb 10                	jmp    585d2 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x2b2>
   585c2:	bf 08 00 00 00       	mov    $0x8,%edi
   585c7:	be 20 00 00 00       	mov    $0x20,%esi
   585cc:	ff 15 ce 6d 04 00    	call   *0x46dce(%rip)        # 9f3a0 <_DYNAMIC+0x270>
   585d2:	0f 0b                	ud2
   585d4:	48 89 c3             	mov    %rax,%rbx
   585d7:	4c 89 f7             	mov    %r14,%rdi
   585da:	ff 15 80 6d 04 00    	call   *0x46d80(%rip)        # 9f360 <free@GLIBC_2.2.5>
   585e0:	48 89 df             	mov    %rbx,%rdi
   585e3:	e8 d8 28 04 00       	call   9aec0 <_Unwind_Resume@plt>
   585e8:	48 89 c3             	mov    %rax,%rbx
   585eb:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   585f0:	e8 1b 96 fe ff       	call   41c10 <core::ptr::drop_glue::<pbrs::wire::UnknownFields>>
   585f5:	eb 49                	jmp    58640 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x320>
   585f7:	ff 15 bb 6d 04 00    	call   *0x46dbb(%rip)        # 9f3b8 <_DYNAMIC+0x288>
   585fd:	48 89 c3             	mov    %rax,%rbx
   58600:	48 8d 7c 24 50       	lea    0x50(%rsp),%rdi
   58605:	e8 c6 9b fe ff       	call   421d0 <core::ptr::drop_glue::<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>>
   5860a:	31 ed                	xor    %ebp,%ebp
   5860c:	eb 0c                	jmp    5861a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x2fa>
   5860e:	ff 15 a4 6d 04 00    	call   *0x46da4(%rip)        # 9f3b8 <_DYNAMIC+0x288>
   58614:	48 89 c3             	mov    %rax,%rbx
   58617:	40 b5 01             	mov    $0x1,%bpl
   5861a:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   5861f:	e8 ec 88 fe ff       	call   40f10 <core::ptr::drop_glue::<core::option::Option<pbrs::lazy::Wire>>>
   58624:	40 84 ed             	test   %bpl,%bpl
   58627:	74 17                	je     58640 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x320>
   58629:	48 89 e7             	mov    %rsp,%rdi
   5862c:	e8 9f 9b fe ff       	call   421d0 <core::ptr::drop_glue::<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>>
   58631:	eb 0d                	jmp    58640 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x320>
   58633:	48 89 c3             	mov    %rax,%rbx
   58636:	48 8d 7c 24 20       	lea    0x20(%rsp),%rdi
   5863b:	e8 d0 88 fe ff       	call   40f10 <core::ptr::drop_glue::<core::option::Option<pbrs::lazy::Wire>>>
   58640:	48 89 df             	mov    %rbx,%rdi
   58643:	e8 78 28 04 00       	call   9aec0 <_Unwind_Resume@plt>
   58648:	ff 15 6a 6d 04 00    	call   *0x46d6a(%rip)        # 9f3b8 <_DYNAMIC+0x288>
   5864e:	cc                   	int3
   5864f:	cc                   	int3
