
work/fix-performance-round/benchmark/owned-v2-candidate/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

00000000000581b0 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy>:
   581b0:	55                   	push   %rbp
   581b1:	41 57                	push   %r15
   581b3:	41 56                	push   %r14
   581b5:	41 55                	push   %r13
   581b7:	41 54                	push   %r12
   581b9:	53                   	push   %rbx
   581ba:	48 81 ec 98 00 00 00 	sub    $0x98,%rsp
   581c1:	89 d0                	mov    %edx,%eax
   581c3:	48 89 fb             	mov    %rdi,%rbx
   581c6:	8b ac 24 d0 00 00 00 	mov    0xd0(%rsp),%ebp
   581cd:	83 fe 02             	cmp    $0x2,%esi
   581d0:	0f 85 9f 00 00 00    	jne    58275 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0xc5>
   581d6:	83 f8 02             	cmp    $0x2,%eax
   581d9:	0f 85 ea 00 00 00    	jne    582c9 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x119>
   581df:	49 89 cf             	mov    %rcx,%r15
   581e2:	48 89 cf             	mov    %rcx,%rdi
   581e5:	4d 89 c5             	mov    %r8,%r13
   581e8:	4c 89 c6             	mov    %r8,%rsi
   581eb:	4d 89 cc             	mov    %r9,%r12
   581ee:	4c 89 ca             	mov    %r9,%rdx
   581f1:	ff 15 69 73 04 00    	call   *0x47369(%rip)        # 9f560 <_DYNAMIC+0x670>
   581f7:	41 b6 01             	mov    $0x1,%r14b
   581fa:	a8 01                	test   $0x1,%al
   581fc:	0f 85 e6 01 00 00    	jne    583e8 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x238>
   58202:	4c 89 e1             	mov    %r12,%rcx
   58205:	4d 8b 24 24          	mov    (%r12),%r12
   58209:	31 f6                	xor    %esi,%esi
   5820b:	4c 89 ef             	mov    %r13,%rdi
   5820e:	4c 29 e7             	sub    %r12,%rdi
   58211:	48 0f 43 f7          	cmovae %rdi,%rsi
   58215:	48 39 f2             	cmp    %rsi,%rdx
   58218:	0f 87 ca 01 00 00    	ja     583e8 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x238>
   5821e:	49 8d 34 14          	lea    (%r12,%rdx,1),%rsi
   58222:	48 89 31             	mov    %rsi,(%rcx)
   58225:	48 8b 3b             	mov    (%rbx),%rdi
   58228:	48 85 ff             	test   %rdi,%rdi
   5822b:	0f 84 f8 00 00 00    	je     58329 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x179>
   58231:	4c 89 e8             	mov    %r13,%rax
   58234:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   5823b:	00 00 
   5823d:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   58244:	00 00 
   58246:	4c 39 e6             	cmp    %r12,%rsi
   58249:	0f 82 ae 01 00 00    	jb     583fd <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x24d>
   5824f:	48 39 c6             	cmp    %rax,%rsi
   58252:	0f 87 a5 01 00 00    	ja     583fd <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x24d>
   58258:	4d 01 e7             	add    %r12,%r15
   5825b:	ff c5                	inc    %ebp
   5825d:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
   58262:	4c 89 fe             	mov    %r15,%rsi
   58265:	41 89 e8             	mov    %ebp,%r8d
   58268:	e8 23 02 00 00       	call   58490 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_inner>
   5826d:	41 89 c6             	mov    %eax,%r14d
   58270:	e9 73 01 00 00       	jmp    583e8 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x238>
   58275:	41 89 f2             	mov    %esi,%r10d
   58278:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   5827d:	48 89 ce             	mov    %rcx,%rsi
   58280:	4c 89 c2             	mov    %r8,%rdx
   58283:	4c 89 c9             	mov    %r9,%rcx
   58286:	45 89 d0             	mov    %r10d,%r8d
   58289:	83 f8 03             	cmp    $0x3,%eax
   5828c:	0f 84 29 01 00 00    	je     583bb <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x20b>
   58292:	41 89 c1             	mov    %eax,%r9d
   58295:	ff 15 65 73 04 00    	call   *0x47365(%rip)        # 9f600 <_DYNAMIC+0x710>
   5829b:	48 83 7c 24 18 ff    	cmpq   $0xffffffffffffffff,0x18(%rsp)
   582a1:	0f 84 3e 01 00 00    	je     583e5 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x235>
   582a7:	48 83 c3 08          	add    $0x8,%rbx
   582ab:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
   582b0:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   582b5:	0f 29 8c 24 80 00 00 	movaps %xmm1,0x80(%rsp)
   582bc:	00 
   582bd:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   582c2:	48 8d 74 24 70       	lea    0x70(%rsp),%rsi
   582c7:	eb 4f                	jmp    58318 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x168>
   582c9:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   582ce:	48 89 ce             	mov    %rcx,%rsi
   582d1:	4c 89 c2             	mov    %r8,%rdx
   582d4:	4c 89 c9             	mov    %r9,%rcx
   582d7:	41 b8 02 00 00 00    	mov    $0x2,%r8d
   582dd:	83 f8 03             	cmp    $0x3,%eax
   582e0:	0f 84 eb 00 00 00    	je     583d1 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x221>
   582e6:	41 89 c1             	mov    %eax,%r9d
   582e9:	ff 15 11 73 04 00    	call   *0x47311(%rip)        # 9f600 <_DYNAMIC+0x710>
   582ef:	48 83 7c 24 18 ff    	cmpq   $0xffffffffffffffff,0x18(%rsp)
   582f5:	0f 84 ea 00 00 00    	je     583e5 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x235>
   582fb:	48 83 c3 08          	add    $0x8,%rbx
   582ff:	0f 10 44 24 18       	movups 0x18(%rsp),%xmm0
   58304:	0f 10 4c 24 28       	movups 0x28(%rsp),%xmm1
   58309:	0f 29 4c 24 60       	movaps %xmm1,0x60(%rsp)
   5830e:	0f 29 44 24 50       	movaps %xmm0,0x50(%rsp)
   58313:	48 8d 74 24 50       	lea    0x50(%rsp),%rsi
   58318:	48 89 df             	mov    %rbx,%rdi
   5831b:	ff 15 8f 72 04 00    	call   *0x4728f(%rip)        # 9f5b0 <_DYNAMIC+0x6c0>
   58321:	45 31 f6             	xor    %r14d,%r14d
   58324:	e9 bf 00 00 00       	jmp    583e8 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x238>
   58329:	48 89 74 24 40       	mov    %rsi,0x40(%rsp)
   5832e:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   58333:	bf 18 00 00 00       	mov    $0x18,%edi
   58338:	be 01 00 00 00       	mov    $0x1,%esi
   5833d:	ff 15 bd 6d 04 00    	call   *0x46dbd(%rip)        # 9f100 <calloc@GLIBC_2.2.5>
   58343:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   58348:	48 85 c0             	test   %rax,%rax
   5834b:	0f 84 d9 00 00 00    	je     5842a <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x27a>
   58351:	48 c7 44 24 08 00 00 	movq   $0x0,0x8(%rsp)
   58358:	00 00 
   5835a:	48 c7 44 24 18 00 00 	movq   $0x0,0x18(%rsp)
   58361:	00 00 
   58363:	4c 8b 44 24 40       	mov    0x40(%rsp),%r8
   58368:	4d 39 e0             	cmp    %r12,%r8
   5836b:	48 8b 54 24 48       	mov    0x48(%rsp),%rdx
   58370:	0f 82 9c 00 00 00    	jb     58412 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x262>
   58376:	4d 39 e8             	cmp    %r13,%r8
   58379:	0f 87 93 00 00 00    	ja     58412 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x262>
   5837f:	4c 89 fe             	mov    %r15,%rsi
   58382:	4c 01 e6             	add    %r12,%rsi
   58385:	ff c5                	inc    %ebp
   58387:	48 8d 4c 24 08       	lea    0x8(%rsp),%rcx
   5838c:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   58391:	4c 89 ff             	mov    %r15,%rdi
   58394:	41 89 e8             	mov    %ebp,%r8d
   58397:	e8 f4 00 00 00       	call   58490 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_inner>
   5839c:	84 c0                	test   %al,%al
   5839e:	74 13                	je     583b3 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x203>
   583a0:	4c 89 ff             	mov    %r15,%rdi
   583a3:	e8 c8 9c fe ff       	call   42070 <core::ptr::drop_glue::<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>>
   583a8:	4c 89 ff             	mov    %r15,%rdi
   583ab:	ff 15 37 6d 04 00    	call   *0x46d37(%rip)        # 9f0e8 <free@GLIBC_2.2.5>
   583b1:	eb 35                	jmp    583e8 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x238>
   583b3:	4c 89 3b             	mov    %r15,(%rbx)
   583b6:	e9 66 ff ff ff       	jmp    58321 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x171>
   583bb:	41 89 e9             	mov    %ebp,%r9d
   583be:	e8 7d 0d fe ff       	call   39140 <pbrs::wire::capture_group_with_depth>
   583c3:	48 83 7c 24 18 ff    	cmpq   $0xffffffffffffffff,0x18(%rsp)
   583c9:	0f 85 d8 fe ff ff    	jne    582a7 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0xf7>
   583cf:	eb 14                	jmp    583e5 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x235>
   583d1:	41 89 e9             	mov    %ebp,%r9d
   583d4:	e8 67 0d fe ff       	call   39140 <pbrs::wire::capture_group_with_depth>
   583d9:	48 83 7c 24 18 ff    	cmpq   $0xffffffffffffffff,0x18(%rsp)
   583df:	0f 85 16 ff ff ff    	jne    582fb <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x14b>
   583e5:	41 b6 01             	mov    $0x1,%r14b
   583e8:	44 89 f0             	mov    %r14d,%eax
   583eb:	48 81 c4 98 00 00 00 	add    $0x98,%rsp
   583f2:	5b                   	pop    %rbx
   583f3:	41 5c                	pop    %r12
   583f5:	41 5d                	pop    %r13
   583f7:	41 5e                	pop    %r14
   583f9:	41 5f                	pop    %r15
   583fb:	5d                   	pop    %rbp
   583fc:	c3                   	ret
   583fd:	48 8d 0d ac 51 04 00 	lea    0x451ac(%rip),%rcx        # 9d5b0 <anon.0c2ca45df2f0f1d1aa999acd93d0dace.1449.llvm.2767789320932521065+0x770>
   58404:	4c 89 e7             	mov    %r12,%rdi
   58407:	48 89 c2             	mov    %rax,%rdx
   5840a:	ff 15 50 6d 04 00    	call   *0x46d50(%rip)        # 9f160 <_DYNAMIC+0x270>
   58410:	eb 16                	jmp    58428 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x278>
   58412:	48 8d 0d 7f 51 04 00 	lea    0x4517f(%rip),%rcx        # 9d598 <anon.0c2ca45df2f0f1d1aa999acd93d0dace.1449.llvm.2767789320932521065+0x758>
   58419:	4c 89 e7             	mov    %r12,%rdi
   5841c:	4c 89 c6             	mov    %r8,%rsi
   5841f:	4c 89 ea             	mov    %r13,%rdx
   58422:	ff 15 38 6d 04 00    	call   *0x46d38(%rip)        # 9f160 <_DYNAMIC+0x270>
   58428:	0f 0b                	ud2
   5842a:	bf 08 00 00 00       	mov    $0x8,%edi
   5842f:	be 18 00 00 00       	mov    $0x18,%esi
   58434:	ff 15 3e 6d 04 00    	call   *0x46d3e(%rip)        # 9f178 <_DYNAMIC+0x288>
   5843a:	48 89 c3             	mov    %rax,%rbx
   5843d:	4c 89 ff             	mov    %r15,%rdi
   58440:	ff 15 a2 6c 04 00    	call   *0x46ca2(%rip)        # 9f0e8 <free@GLIBC_2.2.5>
   58446:	48 89 df             	mov    %rbx,%rdi
   58449:	e8 32 28 04 00       	call   9ac80 <_Unwind_Resume@plt>
   5844e:	48 89 c3             	mov    %rax,%rbx
   58451:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   58456:	e8 95 89 fe ff       	call   40df0 <core::ptr::drop_glue::<core::option::Option<pbrs::lazy::Wire>>>
   5845b:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   58460:	e8 fb 91 fe ff       	call   41660 <core::ptr::drop_glue::<alloc::boxed::Box<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>>>
   58465:	eb 0d                	jmp    58474 <<pbrs_codec_proof::p::__gen_codec_cases_proto::Node>::merge_heavy+0x2c4>
   58467:	48 89 c3             	mov    %rax,%rbx
   5846a:	48 8d 7c 24 18       	lea    0x18(%rsp),%rdi
   5846f:	e8 7c 89 fe ff       	call   40df0 <core::ptr::drop_glue::<core::option::Option<pbrs::lazy::Wire>>>
   58474:	48 89 df             	mov    %rbx,%rdi
   58477:	e8 04 28 04 00       	call   9ac80 <_Unwind_Resume@plt>
   5847c:	ff 15 0e 6d 04 00    	call   *0x46d0e(%rip)        # 9f190 <_DYNAMIC+0x2a0>
   58482:	cc                   	int3
   58483:	cc                   	int3
   58484:	cc                   	int3
   58485:	cc                   	int3
   58486:	cc                   	int3
   58487:	cc                   	int3
   58488:	cc                   	int3
   58489:	cc                   	int3
   5848a:	cc                   	int3
   5848b:	cc                   	int3
   5848c:	cc                   	int3
   5848d:	cc                   	int3
   5848e:	cc                   	int3
   5848f:	cc                   	int3
