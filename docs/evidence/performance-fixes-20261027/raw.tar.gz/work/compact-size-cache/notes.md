# Compact size-cache prototype

Added only `pbrs::rt::CachedSize32` and its focused runtime tests. Generated
field selection is a separate experiment owned by the codegen agent/root.
No speed or memory gain is claimed until that variant is built and measured.

The new helper is a transparent four-byte `AtomicU32`. Its public operations
match the existing cache's `u64` interface: `get`, `set`, `dirty`, `Default`,
`Clone`, `PartialEq`, and `Eq`. Loads and stores remain relaxed: cache state
does not publish message contents. Cache state is excluded from equality.

Values below `u32::MAX` are cached exactly. `u32::MAX` is the dirty sentinel;
that value and all larger inputs return a cache miss. No large value is
truncated, and no input value is rejected. Generated size computation still
returns its original `u64` result and can recompute uncached large sizes.
The existing public `CachedSize(AtomicU64)` is unchanged, preserving previous
generated code and the full-width helper's behavior.

No unsafe code or dependency was added. The helper is `Send + Sync`; its
single atomic field's zero state is the valid cached size zero.

Validation command:

```
cargo test --locked -p pbrs --lib cache_tests
```

Two tests pass (see `tests.log`). They cover 0, 1, MAX-1, MAX, MAX+1 and
`u64::MAX`, clone state/independence, dirty/reset behavior, equality, four-byte
layout, zero state, Send/Sync bounds, and the old cache's unchanged MAX+1 case.
Formatting used `rustfmt --edition 2024 src/rt.rs` only.
