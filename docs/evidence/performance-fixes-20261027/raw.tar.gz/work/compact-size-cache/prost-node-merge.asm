
work/fix-performance-round/benchmark/owned-v2-candidate/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

00000000000453f0 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>>:
   453f0:	55                   	push   %rbp
   453f1:	41 57                	push   %r15
   453f3:	41 56                	push   %r14
   453f5:	41 55                	push   %r13
   453f7:	41 54                	push   %r12
   453f9:	53                   	push   %rbx
   453fa:	48 83 ec 48          	sub    $0x48,%rsp
   453fe:	83 fe 01             	cmp    $0x1,%esi
   45401:	74 51                	je     45454 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x64>
   45403:	83 fe 02             	cmp    $0x2,%esi
   45406:	0f 85 1d 01 00 00    	jne    45529 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x139>
   4540c:	4c 8b 37             	mov    (%rdi),%r14
   4540f:	4d 85 f6             	test   %r14,%r14
   45412:	0f 84 2d 01 00 00    	je     45545 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x155>
   45418:	80 fa 02             	cmp    $0x2,%dl
   4541b:	0f 85 69 01 00 00    	jne    4558a <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x19a>
   45421:	45 85 c0             	test   %r8d,%r8d
   45424:	0f 84 eb 01 00 00    	je     45615 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x225>
   4542a:	44 89 c5             	mov    %r8d,%ebp
   4542d:	49 89 cf             	mov    %rcx,%r15
   45430:	4c 8b 21             	mov    (%rcx),%r12
   45433:	4c 89 e7             	mov    %r12,%rdi
   45436:	e8 f5 de ff ff       	call   43330 <prost::encoding::varint::decode_varint::<&mut &[u8]>>
   4543b:	48 89 d3             	mov    %rdx,%rbx
   4543e:	a8 01                	test   $0x1,%al
   45440:	0f 84 21 02 00 00    	je     45667 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x277>
   45446:	48 85 db             	test   %rbx,%rbx
   45449:	0f 85 94 02 00 00    	jne    456e3 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2f3>
   4544f:	e9 b0 01 00 00       	jmp    45604 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x214>
   45454:	84 d2                	test   %dl,%dl
   45456:	0f 84 89 01 00 00    	je     455e5 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x1f5>
   4545c:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   45463:	00 00 80 
   45466:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   4546b:	88 54 24 20          	mov    %dl,0x20(%rsp)
   4546f:	c6 44 24 21 00       	movb   $0x0,0x21(%rsp)
   45474:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   4547b:	00 
   4547c:	48 c7 44 24 08 08 00 	movq   $0x8,0x8(%rsp)
   45483:	00 00 
   45485:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4548c:	00 00 
   4548e:	bf 48 00 00 00       	mov    $0x48,%edi
   45493:	ff 15 3f 9c 05 00    	call   *0x59c3f(%rip)        # 9f0d8 <malloc@GLIBC_2.2.5>
   45499:	48 85 c0             	test   %rax,%rax
   4549c:	0f 84 5f 03 00 00    	je     45801 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x411>
   454a2:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   454a7:	48 89 48 40          	mov    %rcx,0x40(%rax)
   454ab:	0f 10 04 24          	movups (%rsp),%xmm0
   454af:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
   454b4:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
   454b9:	0f 10 5c 24 30       	movups 0x30(%rsp),%xmm3
   454be:	0f 11 58 30          	movups %xmm3,0x30(%rax)
   454c2:	0f 11 50 20          	movups %xmm2,0x20(%rax)
   454c6:	0f 11 48 10          	movups %xmm1,0x10(%rax)
   454ca:	0f 11 00             	movups %xmm0,(%rax)
   454cd:	48 89 04 24          	mov    %rax,(%rsp)
   454d1:	48 8b 58 10          	mov    0x10(%rax),%rbx
   454d5:	48 3b 18             	cmp    (%rax),%rbx
   454d8:	75 0f                	jne    454e9 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0xf9>
   454da:	48 89 c7             	mov    %rax,%rdi
   454dd:	49 89 c6             	mov    %rax,%r14
   454e0:	ff 15 72 a1 05 00    	call   *0x5a172(%rip)        # 9f658 <_DYNAMIC+0x768>
   454e6:	4c 89 f0             	mov    %r14,%rax
   454e9:	48 8b 48 08          	mov    0x8(%rax),%rcx
   454ed:	48 89 da             	mov    %rbx,%rdx
   454f0:	48 c1 e2 05          	shl    $0x5,%rdx
   454f4:	48 8d 35 c1 58 fc ff 	lea    -0x3a73f(%rip),%rsi        # adbc <anon.0f363c1c2085502831f1e7e323c26323.460.llvm.704920437039905144+0x10>
   454fb:	48 89 34 11          	mov    %rsi,(%rcx,%rdx,1)
   454ff:	48 c7 44 11 08 04 00 	movq   $0x4,0x8(%rcx,%rdx,1)
   45506:	00 00 
   45508:	48 8d 35 01 65 fc ff 	lea    -0x39aff(%rip),%rsi        # ba10 <anon.0c2ca45df2f0f1d1aa999acd93d0dace.1425.llvm.2767789320932521065+0x2af>
   4550f:	48 89 74 11 10       	mov    %rsi,0x10(%rcx,%rdx,1)
   45514:	48 c7 44 11 18 01 00 	movq   $0x1,0x18(%rcx,%rdx,1)
   4551b:	00 00 
   4551d:	48 ff c3             	inc    %rbx
   45520:	48 89 58 10          	mov    %rbx,0x10(%rax)
   45524:	e9 12 02 00 00       	jmp    4573b <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x34b>
   45529:	0f b6 fa             	movzbl %dl,%edi
   4552c:	48 89 ca             	mov    %rcx,%rdx
   4552f:	44 89 c1             	mov    %r8d,%ecx
   45532:	48 83 c4 48          	add    $0x48,%rsp
   45536:	5b                   	pop    %rbx
   45537:	41 5c                	pop    %r12
   45539:	41 5d                	pop    %r13
   4553b:	41 5e                	pop    %r14
   4553d:	41 5f                	pop    %r15
   4553f:	5d                   	pop    %rbp
   45540:	e9 ab b4 ff ff       	jmp    409f0 <prost::encoding::skip_field::<&mut &[u8]>>
   45545:	49 89 fc             	mov    %rdi,%r12
   45548:	89 d3                	mov    %edx,%ebx
   4554a:	44 89 c5             	mov    %r8d,%ebp
   4554d:	49 89 cf             	mov    %rcx,%r15
   45550:	bf 10 00 00 00       	mov    $0x10,%edi
   45555:	ff 15 7d 9b 05 00    	call   *0x59b7d(%rip)        # 9f0d8 <malloc@GLIBC_2.2.5>
   4555b:	48 85 c0             	test   %rax,%rax
   4555e:	0f 84 af 02 00 00    	je     45813 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x423>
   45564:	49 89 c6             	mov    %rax,%r14
   45567:	48 c7 00 00 00 00 00 	movq   $0x0,(%rax)
   4556e:	c7 40 08 00 00 00 00 	movl   $0x0,0x8(%rax)
   45575:	49 89 04 24          	mov    %rax,(%r12)
   45579:	4c 89 f9             	mov    %r15,%rcx
   4557c:	41 89 e8             	mov    %ebp,%r8d
   4557f:	89 da                	mov    %ebx,%edx
   45581:	80 fa 02             	cmp    $0x2,%dl
   45584:	0f 84 97 fe ff ff    	je     45421 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x31>
   4558a:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   45591:	00 00 80 
   45594:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   45599:	88 54 24 20          	mov    %dl,0x20(%rsp)
   4559d:	c6 44 24 21 02       	movb   $0x2,0x21(%rsp)
   455a2:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   455a9:	00 
   455aa:	48 c7 44 24 08 08 00 	movq   $0x8,0x8(%rsp)
   455b1:	00 00 
   455b3:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   455ba:	00 00 
   455bc:	bf 48 00 00 00       	mov    $0x48,%edi
   455c1:	ff 15 11 9b 05 00    	call   *0x59b11(%rip)        # 9f0d8 <malloc@GLIBC_2.2.5>
   455c7:	48 85 c0             	test   %rax,%rax
   455ca:	0f 85 e5 00 00 00    	jne    456b5 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2c5>
   455d0:	bf 08 00 00 00       	mov    $0x8,%edi
   455d5:	be 48 00 00 00       	mov    $0x48,%esi
   455da:	ff 15 98 9b 05 00    	call   *0x59b98(%rip)        # 9f178 <_DYNAMIC+0x288>
   455e0:	e9 4e 02 00 00       	jmp    45833 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x443>
   455e5:	48 89 fb             	mov    %rdi,%rbx
   455e8:	48 8b 39             	mov    (%rcx),%rdi
   455eb:	e8 40 dd ff ff       	call   43330 <prost::encoding::varint::decode_varint::<&mut &[u8]>>
   455f0:	48 89 c1             	mov    %rax,%rcx
   455f3:	48 89 d0             	mov    %rdx,%rax
   455f6:	f6 c1 01             	test   $0x1,%cl
   455f9:	74 10                	je     4560b <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x21b>
   455fb:	48 85 c0             	test   %rax,%rax
   455fe:	0f 85 c9 fe ff ff    	jne    454cd <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0xdd>
   45604:	31 c0                	xor    %eax,%eax
   45606:	e9 30 01 00 00       	jmp    4573b <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x34b>
   4560b:	89 43 08             	mov    %eax,0x8(%rbx)
   4560e:	31 c0                	xor    %eax,%eax
   45610:	e9 26 01 00 00       	jmp    4573b <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x34b>
   45615:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   4561c:	00 00 80 
   4561f:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   45623:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   45628:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   4562f:	00 
   45630:	48 c7 44 24 08 08 00 	movq   $0x8,0x8(%rsp)
   45637:	00 00 
   45639:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   45640:	00 00 
   45642:	bf 48 00 00 00       	mov    $0x48,%edi
   45647:	ff 15 8b 9a 05 00    	call   *0x59a8b(%rip)        # 9f0d8 <malloc@GLIBC_2.2.5>
   4564d:	48 85 c0             	test   %rax,%rax
   45650:	75 63                	jne    456b5 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2c5>
   45652:	bf 08 00 00 00       	mov    $0x8,%edi
   45657:	be 48 00 00 00       	mov    $0x48,%esi
   4565c:	ff 15 16 9b 05 00    	call   *0x59b16(%rip)        # 9f178 <_DYNAMIC+0x288>
   45662:	e9 cc 01 00 00       	jmp    45833 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x443>
   45667:	4d 8b 6c 24 08       	mov    0x8(%r12),%r13
   4566c:	49 29 dd             	sub    %rbx,%r13
   4566f:	0f 83 d5 00 00 00    	jae    4574a <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x35a>
   45675:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   4567c:	00 00 80 
   4567f:	48 ff c0             	inc    %rax
   45682:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   45687:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   4568e:	00 
   4568f:	48 c7 44 24 08 08 00 	movq   $0x8,0x8(%rsp)
   45696:	00 00 
   45698:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   4569f:	00 00 
   456a1:	bf 48 00 00 00       	mov    $0x48,%edi
   456a6:	ff 15 2c 9a 05 00    	call   *0x59a2c(%rip)        # 9f0d8 <malloc@GLIBC_2.2.5>
   456ac:	48 85 c0             	test   %rax,%rax
   456af:	0f 84 6e 01 00 00    	je     45823 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x433>
   456b5:	48 89 c3             	mov    %rax,%rbx
   456b8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   456bd:	48 89 43 40          	mov    %rax,0x40(%rbx)
   456c1:	0f 10 04 24          	movups (%rsp),%xmm0
   456c5:	0f 10 4c 24 10       	movups 0x10(%rsp),%xmm1
   456ca:	0f 10 54 24 20       	movups 0x20(%rsp),%xmm2
   456cf:	0f 10 5c 24 30       	movups 0x30(%rsp),%xmm3
   456d4:	0f 11 5b 30          	movups %xmm3,0x30(%rbx)
   456d8:	0f 11 53 20          	movups %xmm2,0x20(%rbx)
   456dc:	0f 11 4b 10          	movups %xmm1,0x10(%rbx)
   456e0:	0f 11 03             	movups %xmm0,(%rbx)
   456e3:	48 89 1c 24          	mov    %rbx,(%rsp)
   456e7:	4c 8b 73 10          	mov    0x10(%rbx),%r14
   456eb:	48 89 d8             	mov    %rbx,%rax
   456ee:	4c 3b 33             	cmp    (%rbx),%r14
   456f1:	75 0d                	jne    45700 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x310>
   456f3:	48 89 df             	mov    %rbx,%rdi
   456f6:	ff 15 5c 9f 05 00    	call   *0x59f5c(%rip)        # 9f658 <_DYNAMIC+0x768>
   456fc:	48 8b 04 24          	mov    (%rsp),%rax
   45700:	48 8b 4b 08          	mov    0x8(%rbx),%rcx
   45704:	4c 89 f2             	mov    %r14,%rdx
   45707:	48 c1 e2 05          	shl    $0x5,%rdx
   4570b:	48 8d 35 aa 56 fc ff 	lea    -0x3a956(%rip),%rsi        # adbc <anon.0f363c1c2085502831f1e7e323c26323.460.llvm.704920437039905144+0x10>
   45712:	48 89 34 11          	mov    %rsi,(%rcx,%rdx,1)
   45716:	48 c7 44 11 08 04 00 	movq   $0x4,0x8(%rcx,%rdx,1)
   4571d:	00 00 
   4571f:	48 8d 35 eb 62 fc ff 	lea    -0x39d15(%rip),%rsi        # ba11 <anon.0c2ca45df2f0f1d1aa999acd93d0dace.1425.llvm.2767789320932521065+0x2b0>
   45726:	48 89 74 11 10       	mov    %rsi,0x10(%rcx,%rdx,1)
   4572b:	48 c7 44 11 18 05 00 	movq   $0x5,0x18(%rcx,%rdx,1)
   45732:	00 00 
   45734:	49 ff c6             	inc    %r14
   45737:	4c 89 73 10          	mov    %r14,0x10(%rbx)
   4573b:	48 83 c4 48          	add    $0x48,%rsp
   4573f:	5b                   	pop    %rbx
   45740:	41 5c                	pop    %r12
   45742:	41 5d                	pop    %r13
   45744:	41 5e                	pop    %r14
   45746:	41 5f                	pop    %r15
   45748:	5d                   	pop    %rbp
   45749:	c3                   	ret
   4574a:	ff cd                	dec    %ebp
   4574c:	49 8b 44 24 08       	mov    0x8(%r12),%rax
   45751:	4c 39 e8             	cmp    %r13,%rax
   45754:	76 49                	jbe    4579f <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3af>
   45756:	4c 89 e7             	mov    %r12,%rdi
   45759:	e8 d2 db ff ff       	call   43330 <prost::encoding::varint::decode_varint::<&mut &[u8]>>
   4575e:	48 89 d3             	mov    %rdx,%rbx
   45761:	a8 01                	test   $0x1,%al
   45763:	0f 85 7a ff ff ff    	jne    456e3 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2f3>
   45769:	48 89 d8             	mov    %rbx,%rax
   4576c:	48 c1 e8 20          	shr    $0x20,%rax
   45770:	75 43                	jne    457b5 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3c5>
   45772:	89 da                	mov    %ebx,%edx
   45774:	83 e2 07             	and    $0x7,%edx
   45777:	48 83 fa 06          	cmp    $0x6,%rdx
   4577b:	73 4d                	jae    457ca <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3da>
   4577d:	c1 eb 03             	shr    $0x3,%ebx
   45780:	74 5d                	je     457df <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3ef>
   45782:	4c 89 f7             	mov    %r14,%rdi
   45785:	89 de                	mov    %ebx,%esi
   45787:	4c 89 f9             	mov    %r15,%rcx
   4578a:	41 89 e8             	mov    %ebp,%r8d
   4578d:	e8 5e fc ff ff       	call   453f0 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>>
   45792:	48 89 c3             	mov    %rax,%rbx
   45795:	48 85 c0             	test   %rax,%rax
   45798:	74 b2                	je     4574c <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x35c>
   4579a:	e9 44 ff ff ff       	jmp    456e3 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2f3>
   4579f:	0f 84 5f fe ff ff    	je     45604 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x214>
   457a5:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   457ac:	00 00 80 
   457af:	48 83 c0 02          	add    $0x2,%rax
   457b3:	eb 37                	jmp    457ec <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3fc>
   457b5:	48 89 5c 24 08       	mov    %rbx,0x8(%rsp)
   457ba:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   457c1:	00 00 80 
   457c4:	48 83 c0 fe          	add    $0xfffffffffffffffe,%rax
   457c8:	eb 22                	jmp    457ec <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3fc>
   457ca:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   457cf:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   457d6:	00 00 80 
   457d9:	48 83 c0 fd          	add    $0xfffffffffffffffd,%rax
   457dd:	eb 0d                	jmp    457ec <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x3fc>
   457df:	48 b8 06 00 00 00 00 	movabs $0x8000000000000006,%rax
   457e6:	00 00 80 
   457e9:	48 ff c8             	dec    %rax
   457ec:	48 89 04 24          	mov    %rax,(%rsp)
   457f0:	48 89 e7             	mov    %rsp,%rdi
   457f3:	ff 15 57 9e 05 00    	call   *0x59e57(%rip)        # 9f650 <_DYNAMIC+0x760>
   457f9:	48 89 c3             	mov    %rax,%rbx
   457fc:	e9 e2 fe ff ff       	jmp    456e3 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x2f3>
   45801:	bf 08 00 00 00       	mov    $0x8,%edi
   45806:	be 48 00 00 00       	mov    $0x48,%esi
   4580b:	ff 15 67 99 05 00    	call   *0x59967(%rip)        # 9f178 <_DYNAMIC+0x288>
   45811:	eb 20                	jmp    45833 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x443>
   45813:	bf 08 00 00 00       	mov    $0x8,%edi
   45818:	be 10 00 00 00       	mov    $0x10,%esi
   4581d:	ff 15 55 99 05 00    	call   *0x59955(%rip)        # 9f178 <_DYNAMIC+0x288>
   45823:	bf 08 00 00 00       	mov    $0x8,%edi
   45828:	be 48 00 00 00       	mov    $0x48,%esi
   4582d:	ff 15 45 99 05 00    	call   *0x59945(%rip)        # 9f178 <_DYNAMIC+0x288>
   45833:	0f 0b                	ud2
   45835:	eb 00                	jmp    45837 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x447>
   45837:	48 89 c3             	mov    %rax,%rbx
   4583a:	48 89 e7             	mov    %rsp,%rdi
   4583d:	e8 be c4 ff ff       	call   41d00 <core::ptr::drop_glue::<prost::error::DecodeError>>
   45842:	48 89 df             	mov    %rbx,%rdi
   45845:	e8 36 54 05 00       	call   9ac80 <_Unwind_Resume@plt>
   4584a:	eb 04                	jmp    45850 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x460>
   4584c:	eb 02                	jmp    45850 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x460>
   4584e:	eb 00                	jmp    45850 <<pbrs_codec_proof::r::Node as prost::message::Message>::merge_field::<&mut &[u8]>+0x460>
   45850:	48 89 c3             	mov    %rax,%rbx
   45853:	48 89 e7             	mov    %rsp,%rdi
   45856:	e8 15 c0 01 00       	call   61870 <core::ptr::drop_glue::<prost::error::Inner>>
   4585b:	48 89 df             	mov    %rbx,%rdi
   4585e:	e8 1d 54 05 00       	call   9ac80 <_Unwind_Resume@plt>
