"""Publish only dated resource evidence after the actual campaign terminates."""
from pathlib import Path
import datetime,gzip,hashlib,io,json,shutil,subprocess,tarfile
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification'
SOURCE='8fe0f8aeb41356ff427f44542947f36f6d2a2dae'
def git(*args, cwd=ROOT):
 return subprocess.run(['git',*args],cwd=cwd,check=True,text=True,capture_output=True)
report=json.loads((Q/'resource-route-day/report.json').read_text())
if report.get('source',{}).get('commit') != SOURCE or report.get('duration_requested_seconds') != 86400:
 raise ValueError('unexpected campaign source or requested duration')
git('fetch','origin','main')
worktree=ROOT/'work/day-publication'
git('worktree','add','--detach',str(worktree),'origin/main')
dest=worktree/'docs/evidence/grpc-resource-soak-20261022';dest.mkdir(parents=True,exist_ok=False)
files=[];omitted=[]
paths=[p for p in (Q/'resource-route-day').rglob('*') if p.is_file()]
paths += [Q/name for name in ['day-supervisor.json','day-supervisor.stdout','day-supervisor.stderr','day-launch.json'] if (Q/name).is_file()]
for path in sorted(paths):
 data=path.read_bytes();entry={'path':str(path.relative_to(Q)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if data.startswith(b'\x7fELF'):omitted.append(entry)
 else:files.append((entry,data))
data=(json.dumps({'executables':omitted},indent=2)+'\n').encode();files.append(({'path':'omitted-executables.json','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},data))
archive=dest/'raw.tar.gz'
with archive.open('wb') as out:
 with gzip.GzipFile(fileobj=out,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for entry,data in files:
    member=tarfile.TarInfo(entry['path']);member.size=len(data);member.mode=0o644;tar.addfile(member,io.BytesIO(data))
manifest={'schema':'pbrs.resource-capsule.v1','source':SOURCE,'qualified':False,'archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'logical_bytes':sum(e['bytes'] for e,d in files),'files':[e for e,d in files]}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(ROOT/'docs/evidence/grpc-validation-20261022/check.py',dest/'check.py')
soak=report.get('qualification',{}).get('soak_24h',{});smoke=report.get('smoke',{})
(dest/'README.md').write_text(f'''# gRPC resource campaign, started 2026-10-22

Source: `{SOURCE}`. Requested duration: 86,400 seconds.
Recorded duration: {report.get('duration_actual_seconds')} seconds.
Process exit code: {report.get('exit_code')}.
Resource checks: `{smoke.get('status')}`. Day disposition: `{soak.get('status')}`.

The native test run at launch still recorded three failures. This resource
campaign is independent of those functional blockers.

This is a shared-host resource result. It does not establish production readiness
or superiority over tonic/prost. The original limits and validation checks remain
in force. Failures: `{json.dumps(smoke.get('failures',[]))}`.

Run `python3 docs/evidence/grpc-resource-soak-20261022/check.py` to verify every
retained member. The archive contains the command, events, process samples,
validation report and logs. Executables are represented by their hashes.
''')
subprocess.run(['python3',str(dest/'check.py')],check=True)
index=worktree/'docs/evidence/README.md';text=index.read_text();marker='## Benchmark coverage and campaign readiness';text=text.replace(marker,'The [2026-10-22 day campaign](grpc-resource-soak-20261022/README.md) now has a\nterminal resource outcome. Its recorded revision and qualification limits apply.\n\n'+marker,1);index.write_text(text)
git('add','docs/evidence/grpc-resource-soak-20261022','docs/evidence/README.md',cwd=worktree)
git('commit','-m','Record the gRPC resource campaign outcome',cwd=worktree)
for attempt in range(3):
 result=subprocess.run(['git','push','origin','HEAD:main'],cwd=worktree,text=True,capture_output=True)
 if result.returncode==0:
  (Q/'day-publication.json').write_text(json.dumps({'state':'published','source':SOURCE,'evidence_commit':git('rev-parse','HEAD',cwd=worktree).stdout.strip(),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n');break
 git('fetch','origin','main',cwd=worktree);git('rebase','origin/main',cwd=worktree)
else:raise RuntimeError('normal push failed after three attempts; local evidence commit retained')
