from pathlib import Path
import hashlib,json,tarfile,io,gzip,datetime
root=Path('/workspace/pure-protobuf');source=root/'work/qualification';dest=root/'docs/evidence/grpc-validation-20261022'
files=[];excluded=[]
for path in sorted(source.rglob('*')):
 if not path.is_file() or path.is_symlink():continue
 if path.relative_to(source).parts[0] == 'resource-route-day' or path.name.startswith('day-supervisor') or path.name.startswith('day-diagnostic-supervisor.') or path.name.startswith('final-campaign-queue.std'):continue
 data=path.read_bytes();entry={'path':str(path.relative_to(source)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
 if data.startswith(b'\x7fELF'):
  excluded.append(entry);continue
 files.append((entry,data))
(source/'omitted-executables.json').write_text(json.dumps({'reason':'build products omitted; hashes retained','files':excluded},indent=2)+'\n')
path=source/'omitted-executables.json';data=path.read_bytes();files=[item for item in files if item[0]['path']!='omitted-executables.json'];files.append(({'path':'omitted-executables.json','bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()},data));files.sort(key=lambda item:item[0]['path'])
archive=dest/'raw.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(fileobj=raw,mode='wb',mtime=0,filename='') as zipped:
  with tarfile.open(fileobj=zipped,mode='w|') as tar:
   for entry,data in files:
    info=tarfile.TarInfo(entry['path']);info.size=len(data);info.mode=0o755 if entry['path'] == 'run-rust' else 0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
manifest={'schema':'pbrs.validation-capsule.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'delivered_source':'8fe0f8aeb41356ff427f44542947f36f6d2a2dae','qualified':False,'production_readiness':'not_established','broad_superiority':'not_established','archive':{'name':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},'logical_bytes':sum(e['bytes'] for e,d in files),'files':[e for e,d in files]}
(dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'files':len(files),'archive_bytes':archive.stat().st_size,'logical_bytes':manifest['logical_bytes']}))
