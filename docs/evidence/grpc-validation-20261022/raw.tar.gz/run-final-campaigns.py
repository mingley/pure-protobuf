"""Wait for compiler-heavy checks, capture counters, preview resources, then run the day."""
from pathlib import Path
import datetime,json,os,subprocess,time
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification';CWD=ROOT/'work/measurement-final';WRAPPER=ROOT/'work/run-rust';REC=ROOT/'work/record.py';SOURCE='8fe0f8aeb41356ff427f44542947f36f6d2a2dae'
checks=['workspace-followup','grpc-route-repaired','miri-route-followup','rpc-build-route-supervisor','clippy-route-followup','asan-route-followup','msrv-route-followup']
state={'state':'waiting_for_checks','source':SOURCE,'qualified':False,'checks':checks,'queued_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
def save():
 (Q/'final-campaign-queue.json').write_text(json.dumps(state,indent=2)+'\n')
def run(prefix,timeout,args,env):
 return subprocess.run(['python3',str(REC),str(Q/prefix),str(timeout),str(WRAPPER),*args],cwd=CWD,env=env).returncode
save();start=time.monotonic()
while not all((Q/(check+'.json')).exists() for check in checks):
 if time.monotonic()-start>2700:
  state.update(state='blocked',reason='compiler-heavy checks did not all terminate within 45 minutes');save();raise SystemExit(1)
 time.sleep(2)
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(ROOT/'work/stable-target'),CARGO_BUILD_JOBS='1')
if json.loads((Q/'rpc-build-route-supervisor.json').read_text())['exit_code']!=0:
 state.update(state='blocked',reason='verified benchmark build failed');save();raise SystemExit(1)
state.update(state='capturing_native_counters');save()
state['counter_exit_code']=run('counter-route-final',1800,['python3','scripts/grpc-counter-campaign.py','--source-checkout',str(CWD),'--binary',str(Q/'rpc-build-route/rpc-bench'),'--build-record',str(Q/'rpc-build-route/build.json'),'--output',str(Q/'counter-route-final'),'--phase','native','--payloads','1024','--load-levels','1:1','--repeats','3'],env)
state.update(state='resource_preview');save()
preview=run('resource-route-preview',1200,['python3','scripts/grpc-resource-campaign.py','--source',SOURCE,'--output',str(Q/'resource-route-preview'),'--duration','30','--build-profile','release'],env)
state['resource_preview_exit_code']=preview
native=json.loads((Q/'grpc-route-repaired.json').read_text())
if preview!=0 or native['exit_code']!=0:
 state.update(state='finished_without_day',reason='resource preview or final native gRPC checks failed');save()
 (Q/'day-launch.json').write_text(json.dumps({'state':'not_run','source':SOURCE,'reason':state['reason'],'native_exit_code':native['exit_code'],'preview_exit_code':preview,'qualified':False},indent=2)+'\n');raise SystemExit(1)
state.update(state='starting_day');save()
argv=['python3',str(REC),str(Q/'day-supervisor'),'90000',str(WRAPPER),'python3','scripts/grpc-resource-campaign.py','--source',SOURCE,'--output',str(Q/'resource-route-day'),'--duration','86400','--build-profile','release']
child=subprocess.Popen(argv,cwd=CWD,env=env)
(Q/'day-launch.json').write_text(json.dumps({'state':'supervisor_started','pid':child.pid,'source':SOURCE,'command':argv,'qualified':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
state.update(state='day_supervisor_running',pid=child.pid);save()
code=child.wait();state.update(state='day_terminated',day_supervisor_exit_code=code);save()
try:
 subprocess.run(['python3',str(ROOT/'work/publish-day-outcome.py')],cwd=ROOT,env=os.environ.copy(),check=True)
except Exception as error:
 (Q/'day-publication.json').write_text(json.dumps({'state':'failed','error':str(error),'source':SOURCE},indent=2)+'\n');raise
state.update(state='finished');save()
