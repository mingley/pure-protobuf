#![allow(dead_code)]
#[path="/workspace/pure-protobuf/pbrs-grpc/src/h2_backend/proto/streams/lock.rs"]
mod actual_lock;
#[test]
fn shared_guard_cell_races() {
 let value=actual_lock::Mutex::new(std::cell::Cell::new(0));
 let guard=value.lock().unwrap();
 std::thread::scope(|scope| {
  let shared=&guard;
  let a=scope.spawn(move || { for _ in 0..20 { shared.set(shared.get()+1); } });
  let b=scope.spawn(move || { for _ in 0..20 { shared.set(shared.get()+1); } });
  a.join().unwrap(); b.join().unwrap();
 });
}
