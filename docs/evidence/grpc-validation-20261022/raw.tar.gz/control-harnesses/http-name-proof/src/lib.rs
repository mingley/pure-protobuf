#[path="/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/server/http_name.rs"]
mod http_name;
