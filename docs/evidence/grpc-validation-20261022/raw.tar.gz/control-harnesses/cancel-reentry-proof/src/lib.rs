#[path="/workspace/pure-protobuf/pbrs-grpc/src/rpc_cancel.rs"]
mod rpc_cancel;
#[test]
fn replacing_secondary_waker_allows_its_drop_to_cancel() {
    use std::future::Future;
    use std::sync::{Arc,mpsc};
    use std::task::{Context,Wake,Waker};
    struct CancelOnDrop(rpc_cancel::RpcCancel);
    impl Wake for CancelOnDrop { fn wake(self: Arc<Self>) {} }
    impl Drop for CancelOnDrop { fn drop(&mut self) { self.0.signal(); } }
    let cancel = rpc_cancel::RpcCancel::new();
    let mut primary = Box::pin(cancel.wait());
    assert!(primary.as_mut().poll(&mut Context::from_waker(Waker::noop())).is_pending());
    let mut secondary = Box::pin(cancel.wait());
    let waker = Waker::from(Arc::new(CancelOnDrop(cancel.clone())));
    assert!(secondary.as_mut().poll(&mut Context::from_waker(&waker)).is_pending());
    drop(waker);
    let (sent, received) = mpsc::channel();
    let task = std::thread::spawn(move || {
        assert!(secondary.as_mut().poll(&mut Context::from_waker(Waker::noop())).is_ready());
        sent.send(()).unwrap();
    });
    received.recv_timeout(std::time::Duration::from_secs(1)).expect("waker Drop must run outside the registry lock");
    task.join().unwrap();
    assert!(cancel.is_cancelled());
}
