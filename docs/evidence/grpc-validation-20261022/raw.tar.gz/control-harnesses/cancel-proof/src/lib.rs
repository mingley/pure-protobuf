#![allow(dead_code)]
#[path="/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/rpc_cancel.rs"]
mod actual_cancel;
#[cfg(test)]
mod tests {
 use std::sync::{Arc,atomic::{AtomicUsize,Ordering}};
 use std::task::{Context,Wake,Waker};
 use std::future::Future;
 struct Count(AtomicUsize);
 impl Wake for Count { fn wake(self:Arc<Self>) { self.0.fetch_add(1,Ordering::SeqCst); } }
 #[test]
 fn cancellation_wakes_both_pending_tasks() {
  let cancel=super::actual_cancel::RpcCancel::new();
  let a=Arc::new(Count(AtomicUsize::new(0))); let b=Arc::new(Count(AtomicUsize::new(0)));
  let wa=Waker::from(a.clone());let wb=Waker::from(b.clone());
  let mut first=Box::pin(cancel.wait());let mut second=Box::pin(cancel.wait());
  assert!(first.as_mut().poll(&mut Context::from_waker(&wa)).is_pending());
  assert!(second.as_mut().poll(&mut Context::from_waker(&wb)).is_pending());
  cancel.signal();
  assert_eq!(a.0.load(Ordering::SeqCst),1,"first RPC task must wake");
  assert_eq!(b.0.load(Ordering::SeqCst),1,"second RPC task must wake");
 }
}
