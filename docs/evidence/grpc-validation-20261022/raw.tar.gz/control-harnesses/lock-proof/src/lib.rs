#![allow(dead_code)]
#[path = "/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/h2_backend/proto/streams/lock.rs"]
mod actual_lock;

fn guard_must_not_be_sync_for_cell() {
    trait AmbiguousIfSync<A> { fn check() {} }
    impl<T: ?Sized> AmbiguousIfSync<()> for T {}
    struct SyncProbe;
    impl<T: ?Sized + Sync> AmbiguousIfSync<SyncProbe> for T {}
    let _ = <actual_lock::MutexGuard<'static, std::cell::Cell<u8>> as AmbiguousIfSync<_>>::check;
}
