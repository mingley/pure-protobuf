#[path="/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/lazy_ext.rs"]
mod lazy_ext;
