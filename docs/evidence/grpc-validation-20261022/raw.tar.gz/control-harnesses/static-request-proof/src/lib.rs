#[path="/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/static_copy.rs"]
mod static_copy;
#[test]
fn cached_owned_uri_survives_original_drop() {
    let original = http::Request::builder().uri(String::from("http://owned.example.test:443/service/method")).body(()).unwrap();
    let cached = static_copy::clone_http_request(&original);
    drop(original);
    assert_eq!(cached.uri().authority().unwrap().as_str(), "owned.example.test:443");
    assert_eq!(cached.uri().path(), "/service/method");
}
