#[path="/workspace/pure-protobuf/rpc-bench/src/report.rs"]
pub mod report;
#[path="/workspace/pure-protobuf/rpc-bench/src/resources.rs"]
pub mod resources;
#[path="/workspace/pure-protobuf/rpc-bench/src/load.rs"]
mod load;
