#![allow(dead_code)]
#[path="/workspace/pure-protobuf/work/validation-fixes/pbrs-grpc/src/h2_backend/proto/streams/lock/fallback.rs"]
mod actual_lock;
fn check_portable_lock() { let x=actual_lock::Mutex::new(1);drop(x.try_lock()); }
