"""Run the requested day as an independent resource diagnostic, retaining failed native prerequisites."""
from pathlib import Path
import datetime,json,os,shutil,subprocess,time
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification';CWD=ROOT/'work/measurement-final';SOURCE='8fe0f8aeb41356ff427f44542947f36f6d2a2dae'
start=time.monotonic()
while True:
 state=json.loads((Q/'final-campaign-queue.json').read_text())
 if state['state'] in ['finished_without_day','blocked']:break
 if state['state'] in ['day_supervisor_running','starting_day','day_terminated','finished']:raise SystemExit('original supervisor owns the day')
 if time.monotonic()-start>1800:raise RuntimeError('preview did not terminate')
 time.sleep(2)
preview=json.loads((Q/'resource-route-preview.json').read_text())
report=json.loads((Q/'resource-route-preview/report.json').read_text())
if preview['exit_code']!=0 or report['smoke']['status']!='passed':raise RuntimeError('resource preview failed; no day started')
if (Q/'day-launch.json').exists():shutil.copyfile(Q/'day-launch.json',Q/'day-launch-prerequisite-gate.json')
env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(ROOT/'work/stable-target'),CARGO_BUILD_JOBS='1')
argv=['python3',str(ROOT/'work/record.py'),str(Q/'day-supervisor'),'90000',str(ROOT/'work/run-rust'),'python3','scripts/grpc-resource-campaign.py','--source',SOURCE,'--output',str(Q/'resource-route-day'),'--duration','86400','--build-profile','release']
child=subprocess.Popen(argv,cwd=CWD,env=env)
(Q/'day-launch.json').write_text(json.dumps({'state':'diagnostic_supervisor_started','pid':child.pid,'source':SOURCE,'command':argv,'qualified':False,'purpose':'independent resource-duration diagnostic; three native test failures still block production readiness','utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
code=child.wait()
(Q/'day-termination.json').write_text(json.dumps({'source':SOURCE,'exit_code':code,'qualified':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
try:subprocess.run(['python3',str(ROOT/'work/publish-day-outcome.py')],cwd=ROOT,check=True)
except Exception as error:
 (Q/'day-publication.json').write_text(json.dumps({'state':'failed','error':str(error),'source':SOURCE},indent=2)+'\n');raise
