use super::{DecoderError, NeedMore};
use crate::h2_backend::ext::Protocol;

use bytes::Bytes;
use http::header::{HeaderName, HeaderValue};
use http::{Method, StatusCode};
use std::fmt;

/// HTTP/2 Header
#[derive(Debug, Clone, Eq, PartialEq)]
pub enum Header<T = HeaderName> {
    Field { name: T, value: HeaderValue },
    // TODO: Change these types to `http::uri` types.
    Authority(BytesStr),
    Method(Method),
    Scheme(BytesStr),
    Path(BytesStr),
    Protocol(Protocol),
    Status(StatusCode),
}

/// The header field name
#[derive(Debug, Clone, Eq, PartialEq, Hash)]
pub enum Name<'a> {
    Field(&'a HeaderName),
    Authority,
    Method,
    Scheme,
    Path,
    Protocol,
    Status,
}

#[doc(hidden)]
#[derive(Clone, Eq, PartialEq, Default)]
pub struct BytesStr(Bytes);

/// Which repeated pseudo-header string to share on this thread.
#[derive(Copy, Clone)]
pub(crate) enum ReusedStr {
    Path,
    Authority,
}

pub fn len(name: &HeaderName, value: &HeaderValue) -> usize {
    let n: &str = name.as_ref();
    32 + n.len() + value.len()
}

impl Header<Option<HeaderName>> {
    pub fn reify(self) -> Result<Header, HeaderValue> {
        use self::Header::*;

        Ok(match self {
            Field {
                name: Some(n),
                value,
            } => Field { name: n, value },
            Field { name: None, value } => return Err(value),
            Authority(v) => Authority(v),
            Method(v) => Method(v),
            Scheme(v) => Scheme(v),
            Path(v) => Path(v),
            Protocol(v) => Protocol(v),
            Status(v) => Status(v),
        })
    }
}

impl Header {
    pub fn new(name: Bytes, value: Bytes) -> Result<Header, DecoderError> {
        if name.is_empty() {
            return Err(DecoderError::NeedMore(NeedMore::UnexpectedEndOfStream));
        }
        if name[0] == b':' {
            match &name[1..] {
                b"authority" => {
                    let value = BytesStr::try_from(value)?;
                    Ok(Header::Authority(value))
                }
                b"method" => {
                    let method = Method::from_bytes(&value)?;
                    Ok(Header::Method(method))
                }
                b"scheme" => {
                    let value = BytesStr::try_from(value)?;
                    Ok(Header::Scheme(value))
                }
                b"path" => {
                    let value = BytesStr::try_from(value)?;
                    Ok(Header::Path(value))
                }
                b"protocol" => {
                    let value = Protocol::try_from(value)?;
                    Ok(Header::Protocol(value))
                }
                b"status" => {
                    let status = StatusCode::from_bytes(&value)?;
                    Ok(Header::Status(status))
                }
                _ => Err(DecoderError::InvalidPseudoheader),
            }
        } else {
            // HTTP/2 requires lower case header names
            let name = HeaderName::from_lowercase(&name)?;
            let value = HeaderValue::from_bytes(&value)?;

            Ok(Header::Field { name, value })
        }
    }

    pub fn len(&self) -> usize {
        match *self {
            Header::Field {
                ref name,
                ref value,
            } => len(name, value),
            Header::Authority(ref v) => 32 + 10 + v.len(),
            Header::Method(ref v) => 32 + 7 + v.as_ref().len(),
            Header::Scheme(ref v) => 32 + 7 + v.len(),
            Header::Path(ref v) => 32 + 5 + v.len(),
            Header::Protocol(ref v) => 32 + 9 + v.as_str().len(),
            Header::Status(_) => 32 + 7 + 3,
        }
    }

    /// Returns the header name
    pub fn name(&self) -> Name<'_> {
        match *self {
            Header::Field { ref name, .. } => Name::Field(name),
            Header::Authority(..) => Name::Authority,
            Header::Method(..) => Name::Method,
            Header::Scheme(..) => Name::Scheme,
            Header::Path(..) => Name::Path,
            Header::Protocol(..) => Name::Protocol,
            Header::Status(..) => Name::Status,
        }
    }

    pub fn value_slice(&self) -> &[u8] {
        match *self {
            Header::Field { ref value, .. } => value.as_ref(),
            Header::Authority(ref v) => v.as_ref(),
            Header::Method(ref v) => v.as_ref().as_ref(),
            Header::Scheme(ref v) => v.as_ref(),
            Header::Path(ref v) => v.as_ref(),
            Header::Protocol(ref v) => v.as_ref(),
            Header::Status(ref v) => v.as_str().as_ref(),
        }
    }

    pub fn value_eq(&self, other: &Header) -> bool {
        match *self {
            Header::Field { ref value, .. } => {
                let a = value;
                match *other {
                    Header::Field { ref value, .. } => a == value,
                    _ => false,
                }
            }
            Header::Authority(ref a) => match *other {
                Header::Authority(ref b) => a == b,
                _ => false,
            },
            Header::Method(ref a) => match *other {
                Header::Method(ref b) => a == b,
                _ => false,
            },
            Header::Scheme(ref a) => match *other {
                Header::Scheme(ref b) => a == b,
                _ => false,
            },
            Header::Path(ref a) => match *other {
                Header::Path(ref b) => a == b,
                _ => false,
            },
            Header::Protocol(ref a) => match *other {
                Header::Protocol(ref b) => a == b,
                _ => false,
            },
            Header::Status(ref a) => match *other {
                Header::Status(ref b) => a == b,
                _ => false,
            },
        }
    }

    pub fn is_sensitive(&self) -> bool {
        match *self {
            Header::Field { ref value, .. } => value.is_sensitive(),
            // TODO: Technically these other header values can be sensitive too.
            _ => false,
        }
    }

    pub fn skip_value_index(&self) -> bool {
        use http::header;

        match *self {
            Header::Field { ref name, .. } => matches!(
                *name,
                header::AGE
                    | header::AUTHORIZATION
                    | header::CONTENT_LENGTH
                    | header::ETAG
                    | header::IF_MODIFIED_SINCE
                    | header::IF_NONE_MATCH
                    | header::LOCATION
                    | header::COOKIE
                    | header::SET_COOKIE
            ),
            Header::Path(..) => true,
            _ => false,
        }
    }
}

// Mostly for tests
impl From<Header> for Header<Option<HeaderName>> {
    fn from(src: Header) -> Self {
        match src {
            Header::Field { name, value } => Header::Field {
                name: Some(name),
                value,
            },
            Header::Authority(v) => Header::Authority(v),
            Header::Method(v) => Header::Method(v),
            Header::Scheme(v) => Header::Scheme(v),
            Header::Path(v) => Header::Path(v),
            Header::Protocol(v) => Header::Protocol(v),
            Header::Status(v) => Header::Status(v),
        }
    }
}

impl<'a> Name<'a> {
    pub fn into_entry(self, value: Bytes) -> Result<Header, DecoderError> {
        match self {
            Name::Field(name) => Ok(Header::Field {
                name: name.clone(),
                value: HeaderValue::from_bytes(&value)?,
            }),
            Name::Authority => Ok(Header::Authority(BytesStr::try_from(value)?)),
            Name::Method => Ok(Header::Method(Method::from_bytes(&value)?)),
            Name::Scheme => Ok(Header::Scheme(BytesStr::try_from(value)?)),
            Name::Path => Ok(Header::Path(BytesStr::try_from(value)?)),
            Name::Protocol => Ok(Header::Protocol(Protocol::try_from(value)?)),
            Name::Status => {
                match StatusCode::from_bytes(&value) {
                    Ok(status) => Ok(Header::Status(status)),
                    // TODO: better error handling
                    Err(_) => Err(DecoderError::InvalidStatusCode),
                }
            }
        }
    }

    pub fn as_slice(&self) -> &[u8] {
        match *self {
            Name::Field(ref name) => name.as_ref(),
            Name::Authority => b":authority",
            Name::Method => b":method",
            Name::Scheme => b":scheme",
            Name::Path => b":path",
            Name::Protocol => b":protocol",
            Name::Status => b":status",
        }
    }
}

// ===== impl BytesStr =====

impl BytesStr {
    pub(crate) const fn from_static(value: &'static str) -> Self {
        BytesStr(Bytes::from_static(value.as_bytes()))
    }

    pub(crate) fn from(value: &str) -> Self {
        BytesStr(Bytes::copy_from_slice(value.as_bytes()))
    }

    /// Copy `value` once per thread, then share that allocation.
    ///
    /// A connection repeats the same `:path` and `:authority`. The first
    /// request allocates; the rest clone the `Bytes` instead of copying.
    pub(crate) fn reused(slot: ReusedStr, value: &str) -> Self {
        if value.len() > 128 {
            return BytesStr::from(value);
        }
        let cached = match slot {
            ReusedStr::Path => &reuse_cache::PATH,
            ReusedStr::Authority => &reuse_cache::AUTH,
        };
        if let Some(text) = cached.get() {
            if *text == value {
                return BytesStr::from_static(text);
            }
        }
        reused_miss(slot, value)
    }

    #[doc(hidden)]
    pub fn try_from(bytes: Bytes) -> Result<Self, std::str::Utf8Error> {
        std::str::from_utf8(bytes.as_ref())?;
        Ok(BytesStr(bytes))
    }

    #[allow(
        unsafe_code,
        reason = "unchanged pinned h2 UTF-8 access; constructors validate or originate from str"
    )]
    pub(crate) fn as_str(&self) -> &str {
        // SAFETY: every constructor validates UTF-8 or copies a str;
        // BytesStr owns immutable Bytes and exposes no mutation.
        unsafe { std::str::from_utf8_unchecked(self.0.as_ref()) }
    }

    pub(crate) fn into_inner(self) -> Bytes {
        self.0
    }
}

impl std::ops::Deref for BytesStr {
    type Target = str;
    fn deref(&self) -> &str {
        self.as_str()
    }
}

impl AsRef<[u8]> for BytesStr {
    fn as_ref(&self) -> &[u8] {
        self.0.as_ref()
    }
}

impl fmt::Debug for BytesStr {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        self.0.fmt(f)
    }
}

#[cold]
#[inline(never)]
fn reused_miss(slot: ReusedStr, value: &str) -> BytesStr {
    let first = match slot {
        ReusedStr::Path => &reuse_cache::PATH,
        ReusedStr::Authority => &reuse_cache::AUTH,
    };
    // Only the winning initializer allocates process-lifetime storage.
    let text = first.get_or_init(|| Box::leak(value.to_owned().into_boxed_str()));
    if *text == value {
        return BytesStr::from_static(text);
    }
    thread_local! {
        static PATH: std::cell::RefCell<Option<BytesStr>> = const { std::cell::RefCell::new(None) };
        static AUTH: std::cell::RefCell<Option<BytesStr>> = const { std::cell::RefCell::new(None) };
    }
    let previous = match slot {
        ReusedStr::Path => &PATH,
        ReusedStr::Authority => &AUTH,
    };
    previous.with(|previous| {
        let mut previous = previous.borrow_mut();
        if let Some(existing) = previous.as_ref() {
            if existing.as_str() == value {
                return existing.clone();
            }
        }
        let made = BytesStr::from(value);
        *previous = Some(made.clone());
        made
    })
}

/// Leaked `:path` text from the first repeated request, if one was saved.
pub(crate) fn leaked_reused_path() -> Option<&'static str> {
    reuse_cache::PATH.get().copied()
}

/// Leaked `:authority` text from the first repeated request, if one was saved.
pub(crate) fn leaked_reused_authority() -> Option<&'static str> {
    reuse_cache::AUTH.get().copied()
}

mod reuse_cache {
    pub(super) static PATH: std::sync::OnceLock<&'static str> = std::sync::OnceLock::new();
    pub(super) static AUTH: std::sync::OnceLock<&'static str> = std::sync::OnceLock::new();
}

#[cfg(test)]
mod bytes_str_invariant_tests {
    use super::BytesStr;
    use bytes::Bytes;

    #[test]
    fn repeated_path_reuses_the_same_allocation() {
        let first = BytesStr::reused(super::ReusedStr::Path, "/echo.Echo/Echo");
        let second = BytesStr::reused(super::ReusedStr::Path, "/echo.Echo/Echo");
        let third = BytesStr::reused(super::ReusedStr::Path, "/echo.Echo/Echo");
        assert_eq!(first.as_str(), "/echo.Echo/Echo");
        assert_eq!(second.as_ref().as_ptr(), third.as_ref().as_ptr());
        let other = BytesStr::reused(super::ReusedStr::Authority, "127.0.0.1:1");
        assert_eq!(other.as_str(), "127.0.0.1:1");
        assert_ne!(other.as_ref().as_ptr(), first.as_ref().as_ptr());
    }

    #[test]
    fn valid_constructors_retain_exact_utf8_views() {
        for value in ["", "header-value", "λ雪🦀", "a\0b", "\u{10ffff}"] {
            assert_eq!(BytesStr::from_static(value).as_str(), value);
            assert_eq!(BytesStr::from(value).as_str(), value);
            let validated = BytesStr::try_from(Bytes::copy_from_slice(value.as_bytes()))
                .expect("valid str bytes must validate");
            assert_eq!(validated.as_str(), value);
            assert_eq!(&*validated, value);
        }
    }

    #[test]
    fn invalid_utf8_never_constructs_an_unchecked_view() {
        let invalid: &[&[u8]] = &[
            &[0xff],
            &[0xc0, 0xaf],
            &[0xed, 0xa0, 0x80],
            &[0xf4, 0x90, 0x80, 0x80],
            &[0xe2, 0x82],
            &[b'a', 0x80],
        ];
        for bytes in invalid {
            assert!(BytesStr::try_from(Bytes::copy_from_slice(bytes)).is_err());
        }
    }

    #[test]
    fn immutable_shared_view_survives_original_handle_drop() {
        let original = Bytes::copy_from_slice("stable λ header".as_bytes());
        let alias = original.clone();
        let value = BytesStr::try_from(original).expect("valid original");
        drop(alias);
        assert_eq!(value.as_str(), "stable λ header");
        let cloned = value.clone();
        drop(value);
        assert_eq!(cloned.as_str(), "stable λ header");
        assert_eq!(
            cloned.into_inner(),
            Bytes::from_static("stable λ header".as_bytes())
        );
    }
    #[test]
    fn reused_input_address_does_not_reuse_changed_text() {
        for slot in [super::ReusedStr::Path, super::ReusedStr::Authority] {
            let prefix = match slot {
                super::ReusedStr::Path => "/",
                _ => "",
            };
            let before = format!("{prefix}cache-before");
            let after = format!("{prefix}cache-after!");
            let third = format!("{prefix}cache-third!");
            let mut text = String::with_capacity(64);
            text.push_str(&before);
            let address = text.as_ptr();
            let first = BytesStr::reused(slot, &text);
            text.replace_range(.., &after);
            assert_eq!(text.as_ptr(), address);
            assert_eq!(BytesStr::reused(slot, &text).as_str(), after);
            text.replace_range(.., &third);
            assert_eq!(text.as_ptr(), address);
            assert_eq!(BytesStr::reused(slot, &text).as_str(), third);
            assert_eq!(first.as_str(), before);
        }
    }
}
