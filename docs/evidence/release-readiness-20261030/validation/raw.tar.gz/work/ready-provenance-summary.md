# Stream-slot pointer provenance repair

The expanded transport ownership controls found invalid cached raw pointers
under the pinned strict-provenance Miri run. These were shipping runtime
problems, including ordinary end-of-stream, padded DATA and terminal trailers.
They were not repaired by changing a test fixture or the borrow model.

The patch keeps the stream-slot layout and allocation policy. It borrows only
the selected mutable slot, validates the key before deriving a raw pointer,
and reacquires pointers after same-slot safe reborrows. End-of-stream capacity
release returns the original pointer on the common no-op path and a fresh
one after its slow path. Unpadded DATA keeps its existing pointer path.

The strict Miri controls detect six distinct invalidation origins:

- `queue-miri.log` in the root QA record: `stream_ptr` debug validation
  reborrowed a slot after creating the pointer it returned.
- `ready-provenance-1.log`: Counts reused a pointer after an action callback
  reborrowed the stream.
- `ready-provenance-2.log`: a queue-tail lookup borrowed the entire mutable
  slot slice, invalidating a cached pointer to another stream.
- `ready-provenance-6-eos-red.log`: releasing excess reserved capacity
  reborrowed the same stream before the caller reused its pointer.
- `ready-provenance-11-padding-red.log`: padding-credit release reborrowed
  the incoming DATA stream before its receive event was queued.
- `ready-provenance-12-terminal-red.log`: terminal body discard reborrowed
  the stream before its trailers were queued.

`ready-provenance-15-final-retirement.json` records all 32 ownership and wire
controls passing. `ready-provenance-16-final-store.json` records all five Store
controls passing, including mutable and shared accesses, removal and slot
reuse while a distinct live stream pointer is cached. Both runs use
`nightly-2026-10-29` and unchanged `-Zmiri-disable-isolation
-Zmiri-strict-provenance` flags. Their source hashes match the files handed
to root. The source handoff is `ready-provenance.patch` plus its hash report.

Earlier compile mistakes and intermediate attempts remain in the numbered
logs. The optional `streams::*` Miri attempt was interrupted in an unrelated
million-iteration budget test after 92 seconds; its incomplete status is
explicit in `ready-provenance-5-interrupted.json`. No passing full-streams
result is claimed. No test assertion was removed to obtain the final results.

No speed improvement is claimed. The post-action close checks require new
lookups; slow-path refreshes remain conditional. This evidence does not close
the broader sustained-production, fuzz, interop or release gates.
