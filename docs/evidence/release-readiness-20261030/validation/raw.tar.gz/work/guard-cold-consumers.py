"""Guard disk use; reclaim only cold Cargo caches whose test finished."""
import datetime
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
LOG = Path(sys.argv[1])
RECORD = LOG.with_suffix(".cold-cache.json")
CASES = {
    "adapters_build_cold_from_descriptor_sets_without_protoc":
        "pbrs-onboarding-adapters-noprotoc-*/build",
    "packed_core_and_both_adapters_build_cold_without_protoc":
        "pbrs-onboarding-cold-packed-*/cold-build",
}
cleaned = set()
records = []
minimum = 750 * 1024 * 1024
if shutil.disk_usage(ROOT).free < minimum:
    raise SystemExit("disk below guard before command")
child = subprocess.Popen(sys.argv[2:], cwd=ROOT, start_new_session=True)
while True:
    try:
        code = child.wait(timeout=3)
        break
    except subprocess.TimeoutExpired:
        output = LOG.read_text(errors="replace") if LOG.exists() else ""
        for case, pattern in CASES.items():
            if f"test {case} ... ok" not in output:
                continue
            for target in sorted((ROOT / "target").glob(pattern)):
                if target in cleaned or not (target / "CACHEDIR.TAG").is_file():
                    continue
                # This target belongs only to the named finished cold test.
                # Shared consumer caches, sources and binaries remain intact.
                command = ["cargo", "clean", "--target-dir", str(target)]
                before = shutil.disk_usage(ROOT).free
                result = subprocess.run(command, cwd=ROOT, capture_output=True, text=True)
                records.append({
                    "finished_case": case, "command": command,
                    "observed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
                    "exit_code": result.returncode,
                    "output": result.stdout + result.stderr,
                    "disk_before": before, "disk_after": shutil.disk_usage(ROOT).free,
                })
                RECORD.write_text(json.dumps(records, indent=2) + "\n")
                cleaned.add(target)
        if shutil.disk_usage(ROOT).free < minimum:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            print("stopped at 750 MiB disk guard", flush=True)
            code = 99
            break
RECORD.write_text(json.dumps(records, indent=2) + "\n")
raise SystemExit(code)
