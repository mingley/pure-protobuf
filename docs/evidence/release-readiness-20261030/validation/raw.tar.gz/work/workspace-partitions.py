#!/usr/bin/env python3
"""Finish exact-source workspace coverage in Cargo partitions; retain partial runs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'work/readiness-qa-20261030'
PRIOR = OUT / 'native-retry-final.json'
ENV = os.environ.copy()
ENV.update(CARGO_HOME=str(ROOT/'work/cargo'), RUSTUP_HOME=str(ROOT/'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT/'target'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH'] = str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
BASE = ['cargo', 'test', '--workspace', '--all-features', '--locked']
ANSI = re.compile(r'\x1b\[[0-9;]*m')
RUNNING = re.compile(r'^\s+Running .+ \((.+)\)\s*$')
SUMMARY = re.compile(r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;')


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True)+'\n')


def parse_suites(path, known, docs=False):
    active = None
    complete = {}
    interrupted = []
    for raw in path.read_text().splitlines():
        line = ANSI.sub('', raw)
        match = re.match(r'^\s+Doc-tests (\S+)\s*$', line) if docs else RUNNING.match(line)
        if match:
            if active is not None:
                interrupted.append(active)
            active = match.group(1) if docs else str((ROOT/match.group(1)).resolve())
            continue
        match = SUMMARY.match(line)
        if match and active is not None:
            status, passed, failed, ignored, measured, filtered = match.groups()
            row = dict(zip(['passed','failed','ignored','measured','filtered'],
                           map(int,[passed,failed,ignored,measured,filtered])))
            row['status'] = status
            if active in known:
                assert status == 'ok' and row['failed'] == 0, (active, row)
                assert row['filtered'] == 0 and row['measured'] == 0, (active, row)
                if active in complete:
                    assert complete[active] == row, ('inconsistent duplicate suite', active)
                complete[active] = row
            active = None
    if active is not None:
        interrupted.append(active)
    return complete, interrupted


def source_matches(inputs):
    return all((ROOT/p).is_file() and digest(ROOT/p) == h for p,h in inputs.items())


def command(command, stem, inputs):
    assert source_matches(inputs), 'source inputs changed before command'
    path = OUT/(stem+'.log')
    assert not path.exists(), ('preserve previous command log', str(path))
    before = time.monotonic()
    print(json.dumps({'starting': stem, 'command': command}), flush=True)
    with path.open('w') as output:
        code = subprocess.call(command, cwd=ROOT, env=ENV, stdout=output, stderr=subprocess.STDOUT)
    result = {'command':command, 'log':path.name, 'exit_code':code,
              'elapsed_seconds':time.monotonic()-before, 'log_sha256':digest(path),
              'source_inputs_unchanged':source_matches(inputs)}
    write(OUT/(stem+'.json'), result)
    assert code == 0 and result['source_inputs_unchanged'], result
    return result, path


def artifact_rows(path, members):
    rows = {}
    for line in path.read_text().splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if (item.get('reason') != 'compiler-artifact' or item.get('package_id') not in members
                or not item.get('executable') or not item.get('profile',{}).get('test')):
            continue
        executable = str(Path(item['executable']).resolve())
        row = {k:item[k] for k in ['package_id','target','profile','features','fresh']}
        row.update(executable=executable, binary_sha256=digest(executable))
        assert executable not in rows or rows[executable] == row, 'duplicate conflicting artifact'
        rows[executable] = row
    return rows


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--plan', action='store_true', help='inspect existing inventory without running tests')
    args = parser.parse_args()
    prior = json.loads(PRIOR.read_text())
    inputs = prior['inputs_sha256']
    assert prior['source_inputs_unchanged'] and source_matches(inputs), 'prior source inputs differ'
    assert prior['exit_code'] == 99, 'expected preserved disk-guard partial'
    assert set(prior['command']) == set(BASE), 'prior command selected a narrower graph or filter'
    prior_log = PRIOR.with_suffix('.log')
    assert digest(prior_log) == prior['log_sha256'], 'prior log changed'
    rustc = subprocess.check_output(['rustc','-Vv'], cwd=ROOT, env=ENV, text=True)
    assert rustc == prior['rustc'], 'toolchain changed'
    metadata = json.loads(subprocess.check_output(
        ['cargo','metadata','--no-deps','--locked','--format-version=1'], cwd=ROOT, env=ENV, text=True))
    members = set(metadata['workspace_members'])
    write(OUT/('partitions-plan-metadata.json' if args.plan else 'partitions-metadata.json'), metadata)
    inventory_commands = []
    if args.plan:
        inventory_log = OUT/'partitions-inventory-initial.jsonl'
        assert inventory_log.is_file(), 'initial no-run inventory missing'
    else:
        result, inventory_log = command(BASE+['--no-run','--message-format=json'],
                                         'partitions-artifacts', inputs)
        inventory_commands.append(result)
    inventory = artifact_rows(inventory_log, members)
    assert inventory and all(x['target']['kind'] in (['lib'],['bin'],['test']) for x in inventory.values())
    completed, interrupted = parse_suites(prior_log, inventory)
    coverage = {exe:dict(row, origin=prior_log.name, binary_sha256=inventory[exe]['binary_sha256'])
                for exe,row in completed.items() if inventory[exe]['fresh'] is True}
    missing = {exe:row for exe,row in inventory.items() if exe not in coverage}
    groups = []
    if any(x['target']['kind'] == ['lib'] for x in missing.values()):
        groups.append(['--lib'])
    if any(x['target']['kind'] == ['bin'] for x in missing.values()):
        groups.append(['--bins'])
    groups += [['--test',name] for name in sorted({x['target']['name'] for x in missing.values()
                                                   if x['target']['kind'] == ['test']})]
    report = {'schema':'pbrs.workspace-partitions.v1', 'inputs_sha256':inputs,
              'prior_report':PRIOR.name, 'prior_report_sha256':digest(PRIOR),
              'prior_log_sha256':digest(prior_log), 'rustc':rustc,
              'inventory':inventory, 'commands':inventory_commands,
              'reused_targets':len(coverage), 'prior_interrupted':interrupted,
              'planned_groups':groups, 'coverage':coverage, 'status':'planned',
              'limits':['partitioned coverage, not a completed one-shot cargo test run',
                        'prior reuse uses matching recorded source inputs plus Cargo fresh=true; prior binary digests were not recorded',
                        'pre-existing ignored cases are recorded separately; ignored cases are not qualified']}
    write(OUT/('partitions-plan.json' if args.plan else 'partitions-progress.json'), report)
    print(json.dumps({'inventory_targets':len(inventory), 'fresh_targets':sum(x['fresh'] is True for x in inventory.values()),
                      'reused_targets':len(coverage), 'missing_groups':len(groups), 'plan_only':args.plan}), flush=True)
    if args.plan:
        return 0
    for number, group in enumerate(groups,1):
        expected = {exe for exe,row in inventory.items()
                    if (group == ['--lib'] and row['target']['kind'] == ['lib'])
                    or (group == ['--bins'] and row['target']['kind'] == ['bin'])
                    or (group[0] == '--test' and row['target']['kind'] == ['test'] and row['target']['name'] == group[1])}
        assert expected, ('zero target selection',group)
        result,path = command(BASE+group+['--message-format=json'], f'partitions-command-{number:03}', inputs)
        built = artifact_rows(path,members)
        results, unfinished = parse_suites(path,inventory)
        assert expected <= results.keys(), ('missing successful target results',group, sorted(expected-results.keys()))
        assert not unfinished, ('incomplete suite',unfinished)
        for exe,row in results.items():
            assert exe in built, ('missing current artifact record',exe)
            for field in ['package_id','target','profile','features']:
                assert built[exe][field] == inventory[exe][field], ('feature/artifact graph drift',exe,field)
            assert built[exe]['binary_sha256'] == inventory[exe]['binary_sha256'], ('binary changed',exe)
            if exe in coverage:
                assert {k:coverage[exe][k] for k in row} == row, ('duplicate result differs',exe)
            coverage[exe] = dict(row, origin=path.name, binary_sha256=built[exe]['binary_sha256'])
        report['commands'].append(result)
        report['coverage'] = coverage
        report['status'] = 'running'
        write(OUT/'partitions-progress.json',report)
        # Only this child target is disposable. The completed Cargo command and
        # every test process have returned before supported cleanup is invoked.
        child_target = ROOT/'target/integration-consumers'
        if child_target.exists():
            cleanup,_ = command(['cargo','clean','--target-dir',str(child_target)],
                                  f'partitions-clean-{number:03}', inputs)
            report['commands'].append(cleanup)
    assert set(coverage) == set(inventory), 'workspace executable coverage incomplete'
    doc_result,doc_log = command(BASE+['--doc'], 'partitions-doctests', inputs)
    doc_names = {target['name'] for package in metadata['packages'] if package['id'] in members
                 for target in package['targets'] if target['kind'] == ['lib'] and target.get('doctest')}
    docs, unfinished = parse_suites(doc_log,doc_names,docs=True)
    assert doc_names and set(docs) == doc_names and not unfinished, ('doctest coverage incomplete',doc_names,docs,unfinished)
    assert source_matches(inputs), 'source changed at completion'
    report.update(status='passed',coverage=coverage,doctests=docs,
                  native_targets=len(coverage), native_passed=sum(x['passed'] for x in coverage.values()),
                  native_ignored=sum(x['ignored'] for x in coverage.values()),
                  doctest_passed=sum(x['passed'] for x in docs.values()),
                  doctest_ignored=sum(x['ignored'] for x in docs.values()))
    report['commands'].append(doc_result)
    write(OUT/'partitions-coverage.json',report)
    write(OUT/'partitions-progress.json',report)
    print(json.dumps({k:report[k] for k in ['status','native_targets','native_passed','native_ignored','doctest_passed','doctest_ignored']}),flush=True)
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (AssertionError, OSError, ValueError, KeyError, subprocess.SubprocessError) as error:
        print('workspace partitions failed: '+str(error),file=sys.stderr,flush=True)
        raise SystemExit(1)
