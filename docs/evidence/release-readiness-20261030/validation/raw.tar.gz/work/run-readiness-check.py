"""Run one bounded check and retain its source inputs and outcome."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "work/readiness-qa-20261030"
OUT.mkdir(exist_ok=True)
name, *command = sys.argv[1:]
assert command and all(c.isalnum() or c in "-_" for c in name)
assert not (OUT / (name + ".json")).exists(), "preserve previous attempts"
paths = subprocess.check_output(
    ["git", "ls-files", "-z", "Cargo.toml", "Cargo.lock", "build.rs", ".cargo",
     "src", "pbrs-grpc", "protobuf-tonic", "examples", "tests/documentation.rs",
     "scripts/miri-grpc-kernels.py"], cwd=ROOT
).decode().split("\0")


def digest(path):
    return hashlib.sha256((ROOT / path).read_bytes()).hexdigest()


inputs = {p: digest(p) for p in paths if p and (ROOT / p).is_file()}
env = os.environ.copy()
env.update(
    CARGO_HOME=str(ROOT / "work/cargo"),
    RUSTUP_HOME=str(ROOT / "work/rustup"),
    CARGO_TARGET_DIR=str(ROOT / "target"),
    CARGO_BUILD_JOBS="1", CARGO_INCREMENTAL="0", CARGO_PROFILE_DEV_DEBUG="0",
    MIRIFLAGS="-Zmiri-disable-isolation -Zmiri-strict-provenance",
)
env["PATH"] = (str(ROOT / "work/cargo/bin") + ":"
               + str(ROOT / "work/toolchain/protoc/bin") + ":" + env["PATH"])
rustc_command = ["rustc"]
if command[0] == "cargo" and len(command) > 1 and command[1].startswith("+"):
    rustc_command.append(command[1])
elif command[:2] == ["rustup", "run"]:
    rustc_command.append("+" + command[2])
rustc_command.append("-Vv")
report = {
    "base_commit": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True
    ).strip(),
    "inputs_sha256": inputs,
    "command": command,
    "rustc": subprocess.check_output(rustc_command, env=env, text=True),
    "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "free_before": shutil.disk_usage(ROOT).free,
}
start = time.monotonic()
with (OUT / (name + ".log")).open("w") as log:
    guard = ["python3", str(ROOT / "work/review30/guard.py")]
    if name.startswith("native-retry"):
        guard = ["python3", str(ROOT / "work/guard-cold-consumers.py"),
                 str(OUT / (name + ".log"))]
    report["exit_code"] = subprocess.call(
        [*guard, *command],
        cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
    )
report.update(
    elapsed_seconds=time.monotonic() - start,
    finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
    free_after=shutil.disk_usage(ROOT).free,
    source_inputs_unchanged=all(digest(p) == h for p, h in inputs.items()),
    log_sha256=digest("work/readiness-qa-20261030/" + name + ".log"),
)
(OUT / (name + ".json")).write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps({k: v for k, v in report.items() if k != "inputs_sha256"}, indent=2))
print("\n".join((OUT / (name + ".log")).read_text().splitlines()[-18:]))
raise SystemExit(report["exit_code"] or (0 if report["source_inputs_unchanged"] else 2))
