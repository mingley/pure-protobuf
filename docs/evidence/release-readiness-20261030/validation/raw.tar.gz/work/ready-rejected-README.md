# Rejected outbound payload ownership repair

This candidate extends the frozen queued-frame cleanup in `ready-queue-source`.
The separate patch is `ready-rejected.patch`; the report records its full hash,
base file hashes and final file hashes. No shipping source was edited by this
agent. The parent integrates it with its independent provenance and lint fixes.

## Failure and repair

The old send path transferred a DATA frame into validation while holding the
engine and send-buffer locks. An early size or stream-state error, or a panic
from `Buf::remaining`, then destroyed the caller's backing owner under those
locks. A `Bytes::from_owner` destructor that reenters the same connection could
therefore deadlock.

The caller now owns `Option<Data<B>>` in a binding declared before either guard.
Validation borrows it. All rejecting checks and capacity callbacks precede the
single `take` at accepted queue insertion. The queue owns accepted data before
waking the connection. Both terminal-response DATA branches keep that same
outer ownership rule. Capacity-full `try_send_data` still returns the original
buffer without copying or destroying it.

The change introduces no payload clones or new heap-allocation operations on
accepted sends. The Option representation and borrowed call can change machine
code and stack layout. No CPU performance claim is made.

## Detecting controls

Twelve new tests cover direct and try sends after reset, half-close and full
close, including empty/nonempty payloads and both END_STREAM values. Other
controls use a one-byte owner with an oversized reported length, preserve size
error precedence, verify that a full try-send returns the original pointer
without dropping its owner, and catch a first/second `remaining` callback panic.
Two actual server fixtures test terminal DATA before and after response headers.

Before the runtime change, eleven detecting tests failed the actual engine and
send-buffer lock availability check. The full-try ownership control passed.
The `rejected_` filter also selected three older passing tests, giving an
aggregate of 4 passed / 11 failed. The exact baseline inputs and failed log are
retained. After the change, all 28 retirement tests passed (12 new, 16 previous).
The final tested inputs are in `ready-rejected-report.json`.

Commands used the stable toolchain, locked offline dependencies, default
features, debug profile with debug info and incremental compilation disabled,
and one Cargo job. The native command was:

```sh
cargo test --locked --offline -p pbrs-grpc --lib retirement_tests
```

Strict lint, all-feature checks, Miri and release qualification are separate
parent-owned checks on the integrated source.

## Scope

This repairs destruction of newly rejected payload owners and preserves the
queued-owner repair. It does not assert that arbitrary `Buf::chunk` or
`Buf::advance` callbacks run outside locks. Existing capacity/waker callbacks
and their partial-accounting behavior on panic are unchanged. The fixture's
portable mutex poison is cleared only after a deliberately induced callback
panic, matching the existing staging-panic control; no production behavior or
Miri validation is suppressed.
