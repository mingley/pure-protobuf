#!/usr/bin/env python3
"""Record completed partition coverage after losing its outer wrapper.

This does not infer a process exit or reconstruct missing wrapper metadata.
Run only after observing that the partition runner stopped writing its logs.
"""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "work/readiness-qa-20261030"
BASE = "26389ccf77bf9342fe6e605f1d797853acd6c39a"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    destination = OUT / "partitions-final.json"
    assert not destination.exists(), "preserve prior observations"
    assert subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip() == BASE
    coverage = json.loads((OUT / "partitions-coverage.json").read_text())
    assert coverage["schema"] == "pbrs.workspace-partitions.v1" and coverage["status"] == "passed"
    prior = json.loads((OUT / "native-retry-final.json").read_text())
    inputs = coverage["inputs_sha256"]
    assert prior["inputs_sha256"] == inputs and prior["source_inputs_unchanged"] is True
    assert all((ROOT / p).is_file() and sha(ROOT / p) == digest for p, digest in inputs.items())
    assert coverage["rustc"] == prior["rustc"]
    for command in coverage["commands"]:
        assert command["exit_code"] == 0 and command["source_inputs_unchanged"] is True
        assert sha(OUT / command["log"]) == command["log_sha256"]
    process = Path("/proc/51209")
    observation = {"pid": 51209, "proc_present": process.exists()}
    if process.exists():
        cmdline = (process / "cmdline").read_bytes()
        state = (process / "stat").read_text()
        observation.update(cmdline=cmdline.decode().replace("\0", " "), stat=state)
        assert not cmdline, "runner still active; wait before observing stable logs"
    report = {
        "schema": "pbrs.workspace-partitions-observation.v1",
        "observation_only": True,
        "base_commit": BASE,
        "command": ["python3", "work/workspace-partitions.py"],
        "runner_status": coverage["status"],
        "wrapper_exit_status": "not recorded after environment handover",
        "observed_utc": datetime.now(timezone.utc).isoformat(),
        "process_observation": observation,
        "rustc": coverage["rustc"],
        "inputs_sha256": inputs,
        "source_inputs_unchanged": True,
        "log_sha256": sha(OUT / "partitions-final.log"),
        "coverage_sha256": sha(OUT / "partitions-coverage.json"),
        "prior_report_sha256": sha(OUT / "native-retry-final.json"),
        "limits": [
            "Outer wrapper process exit, elapsed time, launch timestamp, disk-before and continuous guard monitoring were not recovered.",
            "Each completed Cargo command has its directly recorded exit code; runner status describes its final coverage record.",
            "Prior target reuse uses matching recorded source/rustc and Cargo fresh=true; binary digests were not recorded at the earlier execution.",
        ],
    }
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print("Recorded source-bound recovered observation; no wrapper exit status asserted.")


if __name__ == "__main__":
    main()
