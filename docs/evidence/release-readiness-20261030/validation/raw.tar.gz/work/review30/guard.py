import os
import shutil
import signal
import subprocess
import sys
import time

minimum = 750 * 1024 * 1024
if shutil.disk_usage('.').free < minimum:
    raise SystemExit('disk below 750 MiB before command')
proc = subprocess.Popen(sys.argv[1:], start_new_session=True)
while True:
    try:
        raise SystemExit(proc.wait(timeout=5))
    except subprocess.TimeoutExpired:
        if shutil.disk_usage('.').free < minimum:
            os.killpg(proc.pid, signal.SIGTERM)
            try:
                proc.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL)
                proc.wait()
            print('stopped at 750 MiB disk guard', flush=True)
            raise SystemExit(99)
