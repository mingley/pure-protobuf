import json,pathlib,re,hashlib,subprocess
root=pathlib.Path(__file__).resolve().parents[3];out=pathlib.Path(__file__).resolve().parent;inv=json.loads((root/'work/qg20/map-migration.json').read_text())
pattern=re.compile(r'(if depth >= pbrs::RECURSION_LIMIT \{\n[ \t]*return Err\(ParseError::new\([ \t\n]*"recursion limit exceeded",?[ \t\n]*\)\);\n[ \t]*\})\n\n([ \t]*let \(s, e\) = pbrs::rt::read_len_span\(data, pos\)\?;\n[ \t]*let \(kk, vv\) =[ \t\n]*decode_map_entry_)')
rows=[];pending=[];sha=lambda b:hashlib.sha256(b).hexdigest()
for row in inv['files']:
 path=root/row['path'];before=path.read_bytes();parent=subprocess.check_output(['git','show','6870a3d0110152c96dd70b47d7bf7c2441624520:'+row['path']],cwd=root);assert before==parent,row['path']
 after,n=pattern.subn(r'\1\n\2',before.decode());assert n==row['map_callers'],(row['path'],n,row['map_callers'])
 pending.append((row['path'],before,after.encode()));rows.append({'path':row['path'],'removed_blank_lines':n,'before_sha256':sha(before),'after_sha256':sha(after.encode()),'before_bytes':len(before),'after_bytes':len(after.encode())})
assert sum(r['removed_blank_lines']for r in rows)==109
for path,before,after in pending:
 for role,data in [('before',before),('after',after)]:
  p=out/role/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
 (root/path).write_bytes(after)
(out/'correction.json').write_text(json.dumps({'schema':'qg20-map-caller-whitespace-correction-v1','parent_candidate':'6870a3d0110152c96dd70b47d7bf7c2441624520','preserved_shipping_candidate':'91c7f86e3b648b11ee3953dbc64bfcbab5890e75','preserved_source_archive_sha256':'3ccbd9f0c200b72f956f09d3637a53addd74f0481a570a4e586116f50eb93fb2','pattern':pattern.pattern,'replacement':'\\1\\n\\2','rows':rows,'removed_blank_lines':109,'scope':'Source-only exact109 blank-line removal after mapcaller guard to match emitter consecutive writeln convention. No token, literal, handwritten generator, oracle, default, wire/API/dependency change. Actual compiler/generator/staging/runtime NOT_RUN.'},indent=2)+'\n')
print(json.dumps({'files':len(rows),'blank_lines_removed':sum(r['removed_blank_lines']for r in rows)}))
