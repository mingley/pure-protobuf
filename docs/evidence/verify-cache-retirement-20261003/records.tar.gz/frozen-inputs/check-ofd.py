#!/usr/bin/env python3
"""Work-only tiny-cache lock regression; never invokes retirement main()."""
import datetime
import errno
import fcntl
import hashlib
import importlib.util
import json
import os
import pathlib
import subprocess
import sys
import traceback

HERE = pathlib.Path(__file__).resolve().parent
OUT = HERE / ("lock-fixture-" + datetime.datetime.now(datetime.timezone.utc).strftime("%Y%m%dT%H%M%S%fZ"))
OUT.mkdir()
helper_path = HERE / "retire-verify-cache.py"
spec = importlib.util.spec_from_file_location("verify_retirement_proposal", helper_path)
helper = importlib.util.module_from_spec(spec)
spec.loader.exec_module(helper)
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
CONTENDER = r'''
import errno,fcntl,json,os,struct,sys
fd=os.open(sys.argv[1],os.O_RDWR)
try:
 try:
  if sys.argv[2]=='flock': fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
  elif sys.argv[2]=='posix': fcntl.lockf(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
  else: fcntl.fcntl(fd,int(sys.argv[3]),struct.pack('@hhqqi4x',fcntl.F_WRLCK,os.SEEK_SET,0,0,0))
  result={'state':'acquired'}
 except OSError as error:
  if error.errno not in (errno.EACCES,errno.EAGAIN): raise
  result={'state':'blocked','errno':error.errno}
 print(json.dumps(result))
finally: os.close(fd)
'''
records = []


def check_contenders(path, phase, expected):
    for mode in ("flock", "posix", "ofd"):
        argv = [str(pathlib.Path(sys.executable).resolve()), "-c", CONTENDER, str(path), mode, str(helper.ofd_abi()["command"])]
        child = subprocess.run(argv, capture_output=True, timeout=5)
        stem = OUT / (phase + "-" + mode)
        stem.with_suffix(".stdout.log").write_bytes(child.stdout)
        stem.with_suffix(".stderr.log").write_bytes(child.stderr)
        stem.with_suffix(".exit").write_text(str(child.returncode) + "\n")
        assert child.returncode == 0, child.stderr
        actual = json.loads(child.stdout)
        row = {"phase": phase, "mode": mode, "argv": argv, "exit": child.returncode,
               "stdout_sha256": hashlib.sha256(child.stdout).hexdigest(),
               "stderr_sha256": hashlib.sha256(child.stderr).hexdigest(),
               "actual": actual, "expected": expected[mode]}
        records.append(row)
        assert actual["state"] == expected[mode], row


def fixture(label, corrected):
    output = OUT / label
    cache = output / "tiny-cache"
    cache.mkdir(parents=True)
    lock = cache / ".cargo-lock"
    lock.write_bytes(b"")
    (cache / "payload.txt").write_bytes(b"tiny cache fixture, not a compiler artifact\n")
    os.link(cache / "payload.txt", cache / "payload-alias.txt")
    (cache / "outside-link").symlink_to("/does/not/exist/fixture-target")
    fd = os.open(lock, os.O_RDWR | os.O_NOFOLLOW)
    try:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if corrected:
            lock_record = helper.hold_cargo_lock(fd)
        else:
            fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            lock_record = {"legacy_pattern": "flock + POSIX lockf, as in immutable bcce/e825 helpers"}
        blocked = {"flock": "blocked", "posix": "blocked", "ofd": "blocked"}
        check_contenders(lock, label + "-initial", blocked)
        resources = helper.Resources(output)
        resources.check("tiny-fixture-initial", force=True)
        inventory = helper.scan(cache)
        manifest = helper.hash_manifest("verify_shared", cache, inventory, resources)
        helper.dump(output / "manifest.json", manifest)
        expected = blocked if corrected else {"flock": "blocked", "posix": "acquired", "ofd": "acquired"}
        check_contenders(lock, label + "-after-hash", expected)
        archive = output / "tiny-payload.tar.gz"
        helper.add_archive(cache, manifest, archive, resources)
        check_contenders(lock, label + "-after-archive", expected)
        verification = helper.verify_archive(archive, manifest, resources)
        helper.verify_live(cache, manifest, resources)
        check_contenders(lock, label + "-after-verification", expected)
        (output / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
        (output / "lock.json").write_text(json.dumps(lock_record, indent=2) + "\n")
    finally:
        os.close(fd)
    check_contenders(lock, label + "-after-dedicated-fd-close",
                     {"flock": "acquired", "posix": "acquired", "ofd": "acquired"})


result = {"scope": "Python-only tiny work cache: no production/source/compiler/performance or retirement launch",
          "helper_sha256_before": sha(helper_path), "fixture_sha256": sha(__file__),
          "python": {"resolved_executable": str(pathlib.Path(sys.executable).resolve()),
                     "sha256": sha(pathlib.Path(sys.executable).resolve()), "version": sys.version},
          "struct_flock_scope": "Linuxx86_64 32-byte native @hhqqi4x matches verified ctypes offsets, fail closed elsewhere",
          "ofd_abi": helper.ofd_abi(), "verified_ofd_import_sha256": sha(HERE / "verified-ofd-import.json"),
          "output": str(OUT)}
try:
    fixture("legacy-posix", False)
    fixture("corrected-ofd", True)
    result.update(status="pass", exit=0, legacy_posix_release_reproduced=True,
                  corrected_flock_and_ofd_retained_after_hash_archive_and_verification=True)
except BaseException as error:
    result.update(status="fail", exit=1, error=repr(error), traceback=traceback.format_exc())
finally:
    result.update(records=records, helper_sha256_after=sha(helper_path))
    (OUT / "result.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: result[k] for k in ("status", "exit", "output")}), flush=True)
raise SystemExit(result["exit"])
