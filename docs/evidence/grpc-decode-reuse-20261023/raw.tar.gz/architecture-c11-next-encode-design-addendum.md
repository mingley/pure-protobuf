# Encode ownership proof addendum

Read-only follow-up to `architecture-c11-next-encode-design.md`, against source
HEAD `beb4ecd9a9b2143c440892607d5b486318062b61` and locked bytes1.12.1.
No production edits, builds, tests or measurements were performed.

## Pointer and capacity equality are insufficient on their own

Starting from a known full BytesMut allocation, ordinary safe splitting behaves as
expected: split_to advances/reduces the original writable window, split_off reduces
its capacity, and an immutable nonempty alias cannot overlap a mutable full window.
If the original allocation remains alive, returning its same base pointer and full
capacity is meaningful evidence that this full writable window was restored.

The missing condition is **allocation lifetime**. WireOut::write_contiguous passes
an actual `&mut BytesMut` to arbitrary downstream encoder code. That code may
mem::take/drop it, allocate a replacement, and return a different view. A raw
address can be reused after its old allocation dies. Equality does not prove that
the old allocation remained alive.

A safe-code counterexample, conditional only on an allowed allocator outcome:

```text
capture original base address P and full capacity C
callback takes and drops the original BytesMut
callback allocates a larger BytesMut with capacity C' > C
allocator returns the now-free address P for that larger allocation
callback splits that replacement at C
callback retains a nonempty immutable tail [C, C') in application state
callback writes the valid protobuf into prefix [0, C) and returns that prefix
```

The prefix reports address P and capacity C, so the proposed equality test passes.
It safely shares a larger allocation with a nonempty tail, and the cache would
charge C although it pins C'. No data race or overlapping mutation is required;
this is an ownership/accounting failure, not a BytesMut memory-safety failure.
If that tail is immediately dropped, the returned prefix can still uniquely pin
larger backing with the same observed P/C. A replacement offset view can similarly
hide a prefix before P.

This note does not claim a particular benchmark allocator/run produced that
outcome. Allocation APIs permit address reuse and the callback may replace storage,
so a universal invariant cannot exclude it. No local unsafe code is needed for the
counterexample's buffer operations. A grow during encoding, even from an inaccurate
encoded_len, is another reason to decline the optimistic path without failing the
RPC, but detecting visible growth does not solve the address-reuse case.

Therefore **freeze only when pointer/capacity changed is not a generic proof**.
Keeping the older strict ownership test is the correct baseline for this API.

## Strict recovery also needs full backing capacity

freeze().try_into_mut() rejects a still-shared current allocation without copying
its input. It does not, by itself, prove that the returned mutable view begins at
the original allocation base. bytes_mut.rs::shared_v_to_mut restores capacity as
`original Vec capacity - current offset`. After an arbitrary replacement/offset
view, that visible capacity can still be less than all backing pinned by it.

For strict generic capacity accounting, normalize uniquely recovered storage to a
canonical Vec. After successful try_into_mut, clear its visible length before
conversion to Vec: BytesMut's unique conversion reconstructs the full backing Vec
and copies visible length bytes, now zero. Charge that Vec's actual full capacity,
then restore a representation whose full origin is known. Never call a conversion
with an implicit copying fallback on a still-shared buffer.

One safe restoration experiment is:

```rust
let restored: BytesMut = full_vec.into_iter().collect();
```

Locked bytes1.12.1 implements FromIterator<u8> with
`BytesMut::from_vec(Vec::from_iter(into_iter))`. The inspected available std source
specializes an unadvanced Vec::IntoIter back into its original allocation, including
an empty Vec with spare capacity. That suggests a restoration without another
Bytes ownership-metadata allocation. **Allocation reuse is not a public Vec
FromIterator guarantee**; verify actual capacity/base-pointer behavior under Rust
1.85 and supported current toolchains before depending on its performance. If it
returns a different capacity or no spare storage, account the observed result and
accept a cache miss; correctness must not assume reuse. No such execution was run
for this note.

Freezing before clearing remains useful: a full Vec-backed output can freeze
without Shared metadata, whereas freezing after clear exposes spare capacity and
can allocate metadata. After successful uniqueness proof, clearing before the
canonical Vec conversion prevents a payload copy. These are two different stages.

## Current-API alternative: keep a private empty liveness anchor

There is a way to make the pointer/capacity proof stronger without freezing every
frame: explicitly keep the original allocation alive through the callback.

After reserving a **known full backing**, create one private empty owner using
`bytes.split_to(0).freeze()`. In bytes1.12.1, split_to(0) leaves the original full
writable window unchanged but promotes/increments shared backing; freezing the
zero-capacity split keeps a zero-length Bytes reference to that backing. Its pointer
still identifies the original base. The framework keeps that owner private.

For each callback, the proof then has all its premises:

1. The captured full allocation has nonzero known capacity C and base P.
2. A private empty Bytes owner keeps that allocation alive until after the callback.
3. Another allocation cannot reuse its live address P.
4. Safe BytesMut APIs cannot leave a nonempty immutable alias overlapping a returned
   mutable full original window [P, P+C). Splits can share disjoint windows, but
   returning the entire original window requires those nonempty overlapping aliases
   to be gone. Extra zero-length owners expose no bytes.
5. Unchanged base/capacity therefore identifies the original full writable backing;
   charge C, including spare capacity. A changed window is a cache miss.

Keep the same anchor across stable warm messages; do not clone/recreate it each
frame. A clear followed by reserve(len <= capacity) takes BytesMut's existing
no-allocation fast path even with the anchor present. Before **planned** growth,
drop the old anchor, reserve through the known full window, then create a new
anchor over the new full backing. Unexpected callback growth/replacement is
ineligible for caching; discard it and reset scratch to BytesMut::new before the
next message. Do not recapture an arbitrary returned view as a new trusted origin.

This induction begins with BytesMut::new/reserve and continues only through known
full windows. The empty anchor closes the address-reuse hole. All live buffer
owners, including the anchor, must drop **before** releasing the capacity lease.
A field order such as bytes, anchor, lease matters. Never store a raw pointer field
that silently makes a Send future non-Send; compare addresses without dereferencing,
or obtain P from the still-live anchor. The lease can hold C.

This is still a design to prove with controls, not production approval. It adds a
persistent Bytes-sized owner and Shared metadata per capacity epoch, and holding
an anchor prevents unique in-place reclaim/growth until it is dropped. A Box can
move that larger retained record off the outbound future but adds a first-use
allocation. Custom temporary splitting may now miss where a more complex recovery
could succeed. Application-held empty aliases can pin backing after the framework
drops it; that application retention remains outside the cache ledger. Actual
layout, metadata requests, growth behavior and small-message CPU require measures.

With this liveness anchor, a conditional strict fallback after an observed origin
change is defensible; it must canonicalize full capacity as above. The simpler
initial policy is to discard changed-origin scratch, avoiding adoption of arbitrary
callback backing. Without the anchor or a stronger handle contract, the conditional
fallback remains unsound as an accounting proof because an unchanged observation
can conceal replacement.

## Stronger handle alternative: append through generic BufMut

A cleaner new API experiment can avoid giving the encoder a replaceable concrete
scratch handle at all. Add a source-compatible default method to CodecMessage:

```rust
fn encode_payload_bufmut<B: bytes::BufMut>(
    &self,
    out: &mut B,
) -> Result<(), Status> {
    self.encode_payload(out)
}
```

The existing WireOut blanket implementation covers B: BufMut. Use an owned
Vec<u8> as stream scratch; bytes already implements BufMut for Vec, so no local
unsafe implementation is needed. Override this new method in the Prost wrapper to
call the existing generic Prost::Message::encode(out) directly.

The downstream method sees generic B through BufMut, not a concrete
`&mut BytesMut` or `&mut Vec`. Safe append APIs cannot take/split/replace/retain the
canonical owner. Borrowed chunk views do not become owned application Bytes.
A user cannot add a stricter concrete-type/Default/Any requirement to the generic
trait method to gain replacement access. Unsafe contract violations are outside
this safe API proof, just as they are for the underlying BufMut implementation.

The default path's detail matters: if an old custom encode_payload calls
WireOut::write_contiguous, the BufMut blanket uses WireOut's **default temporary
BytesMut**, then copies its bytes into canonical Vec scratch. It never exposes that
Vec to the callback. Generated pbrs encoders use ordinary put methods and need no
such temporary; the Prost override also writes directly through BufMut. Custom
contiguous encoders can initially pay a temporary allocation/copy, or implement the
new append-only method efficiently. Document and measure that compatibility cost.

A Vec always reports its own full backing capacity, so this representation needs
no per-frame freeze, keeper or pointer-identity check for retention. Growth is
observed through Vec.capacity and the finite lease is reconciled normally. On
errors, discard scratch and retain OutBatch rollback behavior; no generic truncate
operation is required. It also removes BytesMut's metadata/sliced-origin accounting
problem from plaintext scratch. Wire output stays BytesMut/segmented and its
application-sharing behavior is unaffected.

Vec is three words on this target versus BytesMut's four. A one-word optional
NonZeroUsize-based lease could therefore fit in roughly the original scratch
footprint, without a workspace Box or anchor; confirm real struct/future sizes.
The new public default method, adapter behavior, custom contiguous cost and MSRV
profile need review and controls before choosing it. The sketch has not been built.

A trusted/sealed no-replacement encoder family is another way to justify a fast
path, but an arbitrary public boolean capability is only a promise from a custom
implementation, not a type-enforced invariant. Type-name/address heuristics are
not an ownership proof. An append-only generic handle gives the compiler a
stronger restriction rather than relying on a claimed family label.

## Selection

Keep strict recovery as the current generic baseline. Compare the private empty
anchor under the existing API against the append-only Vec design as isolated
experiments. The former preserves custom contiguous behavior at an ownership-state
cost; the latter simplifies storage/accounting and can keep built-ins direct while
adding a new default method and a temporary path for some custom encoders.
Neither source design establishes a performance result. Both need original/spare
capacity, replace/split/retained nonempty and empty alias controls; partial encode
errors; accurate/inaccurate encoded length; repeated/growing/changing message sizes;
per-buffer and aggregate misses; Drop/cancel/EOF; and the full small/identity/unary/
TLS/multi-flight paired matrix. No production code should adopt pointer equality
alone as proof of full-allocation identity.

## Source references inspected

- `src/wire.rs`: WireOut::write_contiguous and the BufMut blanket implementation.
- `pbrs-grpc/src/codec.rs`: open generic CodecMessage encoder contract.
- Locked `bytes-1.12.1/src/bytes_mut.rs`: split_to, split_off, freeze, reserve,
  shared_v_to_mut, From<BytesMut> for Vec and FromIterator<u8>.
- Locked `bytes-1.12.1/src/buf/buf_mut.rs`: Vec<u8> BufMut append implementation.
- Available `alloc/src/vec/spec_from_iter.rs`: IntoIter specialization; performance
  evidence for the inspected toolchain source, not an MSRV execution result.
