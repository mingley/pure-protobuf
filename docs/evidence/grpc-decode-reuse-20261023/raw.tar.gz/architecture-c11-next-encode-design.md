# Next encode workspace design

Read-only review while C11 qualification is pending. HEAD is
`a675b61fe2775e336f33474c58342764cea814a8`; the working C11 candidate contains
additional changes, so the source hashes below identify this review. No source
edits, builds, tests or measurements were performed. C11's matched captures must
establish the baseline before implementing this next component.

Later ownership review: read `architecture-c11-next-encode-design-addendum.md`
before implementing the generic guard below. Pointer/capacity equality does not
prove allocation identity across a replaceable callback (allocator address reuse).
Strict recovery must establish full canonical backing capacity. The addendum also
examines an origin-liveness anchor and an append-only BufMut/Vec alternative.

## Recommendation

Extend the existing **stream-owned plaintext encode scratch**, under a finite
capacity allowance. Keep plaintext scratch separate from application messages and
compressed wire output. Preserve a successful allocation across messages; do not
replace it above 64 KiB solely because it is large. A full cache, oversized backing
or retained alias should cause a cache miss, never an RPC failure.

For this ownership pattern, consider holding a capacity lease while the same
allocation is both idle and actively reused. Unlike decoded input, built-in encode
scratch is not handed to a returned application message. A stable allocation can
therefore retain its reservation without a release/acquire pair on every message.
This is a deliberate accounting-policy difference from C11's idle-only decode
lease and must be documented as such. Reconcile only new/changed capacity, and
release when discarding storage. Measure the added ownership check and first-use
cost, especially on short streams.

Do this before changing compressed-output reservations. The two costs arise from
different allocations and have different correctness and regression controls.

## Current request/response paths

| RPC side | Current encoder / owner | Effect of stream scratch retention |
|---|---|---|
| Client unary request | `client/unary.rs` calls `encode_msg`; plaintext is a fresh `encode_to_vec` result | None without a separate cross-RPC cache or serialization design. Encoding happens before opening the stream; retry/hedge replay keeps the encoded frame. |
| Client server-streaming request | `client/streaming.rs` single-message path calls `encode_msg` | Same single-shot limitation. |
| Client client-streaming / bidi requests | Budgeted pump in `client/streaming.rs`, ordinary pump in `wire/send.rs`, and closed/prequeued upload each own an `OutBatch` | One scratch can serve messages throughout that upload, including across batch flushes. |
| Server unary / client-streaming response | `server/drain.rs::send_unary_response` calls `encode_msg` | One response per stream; no within-stream reuse opportunity. |
| Server server-streaming / bidi response | `server/drain.rs::drain_to_wire` owns an `OutBatch` | One scratch can serve independently compressed response messages. |
| gRPC-Web text streaming response | `drain_to_web_text` calls `encode_msg` for every message | Not covered by native OutBatch retention. A stream-local scratch-aware helper could cover it later without altering text framing. |

`OutBatch::take_frame` and `flush` replace the wire sink but preserve its
`EncodeScratch` member. There is already a natural lifetime for plaintext reuse;
no global payload pool, sender task or application message layout change is needed.

Uncompressed sends serialize straight into SegSink. Its `put_shared` retains large
application Bytes segments. Compressed EncodeScratch does **not** advertise
`supports_shared`; pbrs copies lazy/shared fields into its private plaintext output.
The Prost adapter writes directly into this output through `write_contiguous`.
Consequently a compressed frame and the application message's original backing are
separate allocations. Reuse that private scratch; never treat SegFrame segments,
RequestReplay frames, decoded messages or their LazyBytes as pool entries.

## Source-derived costs, not site-proven savings

`wire/encode.rs::with_payload` clears and reserves the entire protobuf length,
serializes it, compresses it, then drops capacity above 64 KiB. Four fixed messages
of roughly 1 MiB each therefore request plaintext scratch four times. A successful
stream-local reuse design would retain the first allocation instead: about three
message-sized requests disappear in this source model. Actual BytesMut growth,
codec behavior, cache admission and allocator behavior must be recorded before
publishing any allocation-site savings. Even a nominal 64 KiB body crosses the old
threshold once protobuf envelope bytes are added.

This changes neither the protobuf serialization copy nor compressor creation/history
cost. Each gRPC message still gets a fresh independent compression stream. It does
not eliminate application payload allocations or single-shot encode_to_vec calls.
C9's aggregate approximately 12 MiB per-endpoint requested-byte gap was not an
allocation-site profile, and C11's new result is still pending; neither is proof of
this future component's measured savings.

## Concrete ownership and admission

A candidate private layout is:

```rust
struct EncodeScratch {
    bytes: BytesMut,
    lease: Option<RetainedEncodeLease>,
}
// Non-Clone lease contains NonZeroUsize capacity; Option can use its zero niche.
```

Fields drop in that order so the buffer releases before its charge. A nonzero
capacity lease can fit one word without an Arc, allocation or lock. On this
64-bit target that suggests one extra pointer-sized field in OutBatch; confirm
actual struct/future sizes because alignment and surrounding layouts matter.
Avoid a per-message workspace Box solely to hold the lease.

One possible initial policy is 4 MiB per scratch and 16 MiB of admitted encode
scratch process-wide, independently of the existing 16 MiB idle decode allowance.
That means **up to 32 MiB across these two ledgers**, before application messages,
wire output, compressor state and uncached active work. Alternatively share one
16 MiB ledger and document the combined definition. Do not imply the current
decode cap silently covers encode storage. Keep configuration Copy behavior intact;
this initial private policy needs no per-RPC Arc or public configuration change.

For each compressed message:

1. Check the existing encode limit, clear used length and reserve for its encoded
   length. Do not change compression negotiation or the per-message flag.
2. Serialize and compress synchronously using the stream's owned scratch, with
   compressed output going to its distinct wire sink as today.
3. On serialization/compression error, discard scratch and its lease, and preserve
   OutBatch's rollback/error behavior for earlier complete messages.
4. Verify that the scratch is still eligible for exclusive retention, then compare
   actual capacity with the lease's charged capacity. An unchanged admitted
   allocation needs no global atomic operation.
5. For new or grown capacity, validate the per-buffer cap and admit the **full
   actual capacity**. A resize operation can reserve only the positive delta
   atomically while keeping the old reservation; if admission fails, drop the
   buffer before releasing the old lease. Capacity changes during synchronous
   unadmitted growth are active/transient work, not hidden idle cache capacity.
6. Clear length and leave the admitted buffer for the next message. EOF, producer
   failure, transport error, cancellation/deadline and dropped pump/drain futures
   must destroy or explicitly release scratch before parking a completed object.

A lease held across warm active use conservatively reserves budget while encoding;
other streams may miss although that buffer is not idle. That is the price of
avoiding per-message global contention. It still does not bound first-use or other
uncached active allocations. Outbound message size is unlimited by default, and
the existing ByteBudgetTracker is a different budget with different accounting;
this retention change must not silently alter RPC quotas or claim a total RSS cap.

## Aliases and generic encoders

Built-in pbrs and Prost paths copy input data into scratch. A generic CodecMessage
can also use WireOut::write_contiguous, whose callback receives `&mut BytesMut`;
that API permits splitting or retaining output backing. Do not assert exclusive
ownership for every downstream implementation merely because built-ins copy.
BytesMut protects disjoint views from overwriting one another, but retaining an
application alias is incompatible with a strict uniquely owned cache entry and
can obscure full-backing capacity accounting.

A strict prototype can capture output pointer/capacity after reservation, require
that window to remain unchanged during encoding, and perform
`freeze().try_into_mut()` **before clearing used length**. A sharing failure drops
the framework's view without copying application-retained bytes; a changed window
is simply ineligible for retention. Under the built-in fixed-size path, output
starts at the owned allocation base and the unchanged window provides full
capacity. Test custom encoders that split or retain the contiguous output; do not
try to recover them through a conversion with a copying fallback.

The order matters for cost. In bytes1.12.1, freezing a Vec-backed BytesMut routes
through Bytes::from(Vec). If used length equals capacity, this can keep the boxed
allocation without allocating Shared metadata; `try_into_mut` restores the mutable
owner. If used length is smaller than capacity, Bytes allocates ownership metadata.
Thus a warm large-to-small stream can pay a metadata allocation even while avoiding
a large scratch allocation. Freezing after clear would force that spare-capacity
case for every nonempty allocation. This ownership guard is not free and needs its
own allocation/CPU control. If its generality costs too much, consider a narrower
explicit encoder ownership contract rather than assuming uniqueness or copying
retained application data to make the cache appear successful.

## Small messages and one-shot sends

The current <=64 KiB scratch already reuses storage without reservation atomics.
The proposed fully bounded ledger adds first admission, final release and an
ownership check. Stable warm capacity avoids a CAS per message, which protects
high-rate short streams better than mechanically copying the decoded idle-lease
protocol. There is still one extra field per OutBatch and additional branches;
identity paths must never acquire a scratch lease or allocate cache metadata.

Measure 1 KiB gzip, one-message and four-message streams, all endpoint pairings,
multiple in-flight RPCs and both cold/warm states. If small retention is excluded
from the new ledger to preserve old costs, state explicitly that 64 KiB per live
stream remains outside the aggregate cap. Do not call that a bound on all idle
encode scratch.

This first change should leave `encode_msg` single-shot behavior intact. Later,
`encode_msg_with_scratch` could let gRPC-Web text streams share the same private
primitive. For unary RPCs, cross-RPC reuse needs a distinct bounded checkout cache
owned by ChannelInner / Router or another explicit owner, not by copied configs.
Take a buffer under a short nonblocking lock, encode without holding the lock, and
return it before the first network await. Contention or exhaustion is a cache miss.
Keep entry count, capacity and retained aliases bounded; start above a measured
size threshold so 1 KiB unary does not pay two cache operations. Retries/hedges must
still serialize once and replay the resulting immutable compressed frame.
That separate cache changes synchronization and cross-RPC retention, so do not
bundle it with the stream-owned scratch experiment.

## Separately: compressed-output reservation

Both single-shot encode_msg and compressed append_frame reserve
`5 + plaintext_len / 2 + 32` in the wire output. A roughly 1 KiB gzip of 1 MiB zeros
can therefore reserve about 512 KiB. Ping-pong flushes replace the whole sink, so
this happens again next message. Batched compressed frames can request another
large *additional* reservation despite existing spare capacity. These are source
requests, not measured per-site costs in every RPC.

A smaller capped hint or a bounded predictor based on previous compressed length
may reduce that request on compressible traffic. Incompressible or changing data
can instead incur more growth/copies. First compare existing behavior, a capped
hint, and a bounded prior-output predictor on zeros/random/structured and alternating
inputs. Preserve existing wire caps, length-prefix patching and rollback behavior.

Retaining a mutable remainder while sending a compressed prefix is a different
ownership design. HTTP/2 may retain that prefix while backpressured. Reclaim only
when ownership permits; otherwise allocate a new active buffer without copying
retained wire bytes. Account the full retained backing separately from in-flight
wire permits. Do not pass application/shared SegFrame segments to such a cache.
It may help both unary and streaming paths, but is materially broader than scratch
retention or changing a reservation hint.

## Acceptance controls

Implement one component after C11 is pinned. Preserve raw old/new captures and the
full existing control matrix. Add causal warm allocation checks that count scratch
requests independently of application message creation and compressor state;
require same bytes/checksums through an independent peer. Exercise cache admission,
per-buffer and aggregate misses, growth/rounding, many paused streams, held custom
output aliases, producer/codec failures, rollback, reset, cancellation, deadline,
EOF and Drop. Require zero cache charges after owners terminate and successful
same-channel recovery. Keep identity/unary, all five RPC shapes/endpoint pairings,
TLS, multi-flight, cold/small and compressibility controls. Report CPU, allocations,
requested bytes, admitted capacity and RSS separately.

No additional C11 decoded-input correctness blocker was found in this source
review. Cold short output follows the documented equivalent ordinary decoder;
warm Box presence preserves mixed-size reuse; the unique-owner check still
rejects application-retained Bytes; logical read sizes remain independently
bounded. This is a source review, not a replacement for C11 qualification.

## Reviewed sources

| Source | SHA-256 |
|---|---|
| `pbrs-grpc/src/wire/encode.rs` | `54233a7a7f4ddc3fa2b12df266980b8edd2f257d2549b454d03c2997f6c97061` |
| `pbrs-grpc/src/wire/out_batch.rs` | `8171ac3868d51d1d66da8896d9858973c431c16fd38a829367d6f1329d693e25` |
| `pbrs-grpc/src/client/streaming.rs` | `b86e42d069c5ade4cc031dbbe01ffb153b3a9355d0c3f1594463c0c6b9d38ffa` |
| `pbrs-grpc/src/client/unary.rs` | `4c6b651fa14f3079a3ff4012c7918a5269f910ca9e1bbdb86e02e5410f7b71d8` |
| `pbrs-grpc/src/server/drain.rs` | `57ac9b8af69c6cfa45b2d693889b3ee849fd67addc8b619b8e9839cf8c6a98d8` |
| `pbrs-grpc/src/codec/prost.rs` | `1037fee963faa0996971fcd5a9f11fbe6d06a1cbc1513c57406bc948c477f33b` |
| `pbrs-grpc/src/wire/frame_reader.rs` | `032e54a2f6e9e59810e913c70da0697fea4284fff9c1505cd973130ae2bdcce7` |
