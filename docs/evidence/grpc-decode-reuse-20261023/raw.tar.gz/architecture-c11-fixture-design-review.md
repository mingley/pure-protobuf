# C11 final fixture review

Independent read-only review against C10 `a675b61fe2775e336f33474c58342764cea814a8`. The companion JSON records the reviewed file hashes and actual working-source HEAD. No edits, builds or tests were performed by this reviewer. A later clean pin must match these files before attaching this review to qualification.

No correctness blocker or evidence of masking a production regression was found in the reviewed fixture delta. Production changes remain restricted to decoded-workspace allocation policy/ownership from the separate production review; cancellation and resolver runtime code are unchanged.

## Cancellation and failed upload ordering

The old failure assumption combined two different cases: a locally failed upload may return its status before the remote service is ever admitted, while cancelling already admitted remote work must destroy that work and notify its child. The revised tests prove each condition separately.

SenderFailureService records actual handler entry, consumes and validates the first request, and independently polls Request::cancelled to Pending before the test injects failure or explicit cancellation. Exact cumulative counts prevent a previous call from satisfying a later admission. Before-header calls must remain Pending. Failure status assertions retain NotFound, message and structured ErrorInfo; explicit cancellation still requires Cancelled. Repeated before-header bidi cases remain repeated. After-header cases receive the actual first echoed message, require the cancellation child to have been pending, and verify Cancelled without surfacing the local request status. Exact parent/producer drop counters and child completion are checked after the action. Holding each connection/client until these checks prevents connection destruction from substituting for cancellation.

SpawnHang cancellation cases now prove actual admission plus a Pending cancellation-child poll instead of sleeping40 ms and assuming admission. Their dedicated pending mode cannot naturally finish after200 ms. A guard inside each handler verifies destruction, alongside child completion and a zero normal-completion counter. Cases using the default timed mode retain their old behavior; controlled deadline fixtures were not silently switched to perpetual pending. TLS controlled cancellation retains its separate wrapper admission/drop proof and40 ms logical-time advance. Wait drivers use std::time::Instant for their existing800 ms wall-clock bound, including paused Tokio-time tests, and wake themselves to keep polling progress visible. This is bounded fixture busy polling, not a production scheduler change.

The separate prequeued_request_failure integration test uses an independent h2 server whose connection polling/admission is explicitly gated after handshake. Both client-streaming and bidi Calls queue a request and local NotFound failure, then must complete with the exact local status before this gate opens. The zero-admission counter is structural because the peer is deliberately blocked; the nontrivial assertion is that local completion does not wait for that blocked peer. It does not claim that failed uploads can never reach a remote server. Peer shutdown is independently bounded. This preserves the formerly conflated pre-admission case without inventing a remote cancellation-child obligation.

## Resolver ordering

CurrentAddrs holds the answer set until the test requests the next phase. A lookup returning is not used as proof that picker state changed. Churn tests observe multiple actual B replies and a frozen A request counter before allowing A to return. The drain test establishes a stream and first message on A before removing A, waits for real new requests on B, and only then releases A's second message. Thus timing cannot let the stream finish before removal, and a stale/migrated/aborted stream cannot satisfy the A second-message assertion. Existing finite adoption waits and exact reply assertions remain.

## Limits of the review

These changes remove scheduling assumptions and add observable ownership/admission facts. They do not qualify performance, long-duration reliability or all cancellation timings. The new independent-peer test exercises zero remote admission over from_io/TCP; admitted failure/cancellation cases cover the existing transport families. Full pinned workspace results, the focused Serving result and runtime resource/performance controls remain required. No passing test result is asserted by this review.
