# C11 documentation draft — no measured results yet

Qualification artifact only. Do not edit tracked documentation until the root
grants it after clean C11 checks and actual capture results. The final capsule
can remain `docs/evidence/grpc-decode-reuse-20261023/`.

## Current evidence and source boundaries

| Record | Actual source/scope | State |
|---|---|---|
| C8 matched allocation/profiler results | `9d6fb9c4`, with its actual baseline | Existing historical results; not C11 measurements |
| C8 active resource day | `9d6fb9c4` | Separate attempt; cannot qualify changed C11 runtime |
| C10 candidate | `a675b61f` | Historical candidate |
| C10 complete workspace | `a675b61f` | **3,766 passed, two failed, nine ignored**, 140 targets |
| C10 measurement pipeline v2 | Awaited checks/build | Stopped before any measurements; no performance gains exist |
| C11 candidate | `beb4ecd9a9b2143c440892607d5b486318062b61` | Final source |
| C11 serving-class development run | Actual development snapshot | Initial mTLS startup fixture failure after 1,099 passes; original retained |
| C11 serving-class causal gate v2 | Actual repaired-source record | 1,100 passes; separate raw peer check passes one case |
| C11 focused library/wire/resolver | Actual final-source records | 703 library, one wire and 34 resolver cases pass; scopes overlap the workspace, so do not add them to its count |
| C11 pre-workspace | Final source | All ten checks pass |
| C11 complete workspace | Clean `beb4ecd9` | **3,771 passed, zero failed, nine existing ignores**, 141 targets; 20 min 27.87 s |
| C11 resource preview | Final runtime | Pipeline started preview; terminal outcome pending |
| C11 selected native/profiler and expanded captures | Final plan pending | Planned, **NOT RUN** |

C10's two failures have fixture preconditions identified in source/replay review:
the resolver switched out of a short B-only phase before six expected calls;
the request-stream error case could finish before handler admission, then await
a child that had never existed. Proposed repairs use controlled stable DNS
phases and admission/child-Pending/parent-drop witnesses. These are not broad
production cancellation failures or proof that the repaired suite passes. Keep
the original failures, diagnosis, repair source and actual rerun separate. No
timeout increase or status widening should be described as a fix.

The new buffer correction separates the logical initial decode hint from physical
cached capacity. A retained large allocation must not force a subsequent small
message to initialize the whole allocation. Physical capacity can still be
reused by ordinary vector growth. Read-span tests and cold/warm mixed-size controls
must establish that behavior at the final source; no counter gain is predicted.

## Simple final benchmark page

Keep the page near 100–110 lines and make each number's scope obvious:

1. Lead with the largest **actual** current loss, followed by a measured source
   improvement if one exists. No “fastest”, production or broad superiority claim.
2. Table of the worst equal-prost native-versus-tonic costs: side, workload,
   metric, current, fresh control and difference. Use explicit KiB/MiB units.
3. Matched C8-to-C11 changes: side, workload/codec, before, after, change. Keep
   regressions and identity/retaining-codec controls visible.
4. Small profiler table only if the new diagnostic completes. Name actual
   instrumented artifacts, endpoint, N/2N, repeats and control noise. Do not move
   C8's old instruction values into C11 columns or claim native-client coverage
   until the exact new cells show it.
5. Short scope/count block, raw evidence link and reproducible commands; broader
   speed, interop, platform/release and actual C11 sustained resources remain open.

Current plan: **71 native allocation scopes**, **12 profiler scopes**, balanced
ABBA, plus an **expanded 2,400-capture current matrix**. These are plans, not
results. Derive completed capture/RPC counts and repetitions only from the final
plan and retained terminal ledgers. Do not reuse the superseded C10 46-cell plan.
Include 1 KiB gzip controls in the final scope once their exact cells are recorded.

Use the same matched harness, gzip level 6, zero-filled application payloads and
four messages on each streaming leg. Native accounting/channelz stay enabled.
Preserve the 400 KiB **server** send-buffer and queue-16 framing unless the final
manifest explicitly changes them. Retained input and full interop handler work
are different costs; equal prost handlers are the public API comparison.

Requested allocation bytes, idle retained capacity, live owned messages and RSS
are distinct. Lower requested bytes do not prove lower total retained memory or
CPU. Raw context switches and coarse process CPU ticks are not speed rankings.

## Root README and evidence capsule outline

For the root README, add one concise link to the new decode-reuse capsule beside
the existing execution record after the edit grant. Describe bounded unique-owner
reuse, actual validated source and measured scope. Do not add a headline speed
claim or replace the gRPC preview/support boundaries with “production ready”.

The validated C11 full workspace now passes at its actual pin, while the C10
failed workspace and earlier development failures remain historical records.
Counters, profiler results, sanitizer and actual resource outcomes each retain
their own source and scope. Do not infer pending captures from the passing suite.

Suggested title: **Bounded stream decode reuse**.

Opening: explain the concrete work removed only after measurements establish it.
Describe unique fully consumed prost input recovery, preserved retained-Bytes/pbrs
ownership, optional 4 MiB-per-stream-buffer/16 MiB-process idle retention and
observed-terminal release. A full retention budget declines caching, not the RPC.
Active decoding, messages, compressor scratch and RSS remain separate budgets.

Then use a short validation table with exact source and outcome for:

- Final clean C11 full workspace, strict checks, minimum Rust and sanitizer.
- Ownership, cache saturation, full-capacity backing proof and terminal cleanup.
- Cold small decode and warm large-to-small initialization controls.
- Positive and detecting negative controls with actual source snapshots.
- Selected native allocation/profiler and expanded campaign accounting.
- Actual C11 resource checks; C8's active day remains separate.

Retain C10's wrong-toolchain build attempt (Rust 1.88, rejected before comparison),
corrected stable build, failed workspace, stopped pipeline, C11 development
fixture failures and every final rerun. Do not call a compile-only supersession
a runtime failure or a passing test run. A source-equivalence note is not an
execution record for the later pin.

## Big-picture priorities for TODO and the execution decision

The useful objective is less necessary work per RPC under explicit ownership
and resource bounds. The next directions are:

| Direction | Next bounded experiment | Required evidence |
|---|---|---|
| One pass through framing and codecs | Attribute temporary plaintext frame/encode scratch separately from compressed-output reservation; test checked eager merge of singular nested fields. | Equal logical work and independent decode equality; preserve parse-time validation, recursion, merge, unknown fields and sparse-access behavior. Repeated Query children already parse eagerly. |
| Owned buffer reuse | Reuse only storage whose ownership returns exclusively, under finite idle budgets; keep logical initialized length separate from physical capacity. | Pointer/capacity and retention-budget witnesses, mixed cold/warm sizes, malformed input, retained input and observed-terminal cleanup; measure requested and retained memory separately. |
| Deadline origin and full service ownership — correctness first | Capture one accepted deadline and own the entire cooperative service lifetime before shape selection. | Independent raw-peer gate control; expired calls never get a fresh budget; one terminal responder, exact drops and same-connection recovery. Proposed control NOT RUN. |
| Protocol scheduling independent of arbitrary application polls | Compare inline execution with explicitly owned per-RPC tasks under finite process admission and spare workers. | Event-order controls for PING, small siblings, cooperative reset/deadline, flow control and drain; small-call handoff cost; no detached work or premature permit release. |

For the next performance experiment, keep allocation owners separate:

- **Plaintext single-message reserve:** source reserves four small frames even
  when the collected batch contains one. The count-aware option preserves the
  four-frame policy for two or more ready messages and uses one frame for a
  known singleton. Its patch is unapplied/uncompiled/unmeasured. Do not call the
  source arithmetic a measured share of the identity gap.
- **Batch scratch vectors:** current paths initially reserve 64 items and, when
  budgeted, 64 permits. Test a source-capacity/collected-count hint independently;
  simply replacing 64 with the benchmark's 16 can add growth work for real bursts.
- **Owned plaintext encode scratch:** a stream already owns the compressor's
  plaintext scratch, currently discarded above 64 KiB. Any larger retained scratch
  needs a stated capacity ledger, cleanup and cold/short-stream cost measurement.
  Keeping its lease through active reuse is a different policy from idle-only
  decode charging. An additional 16 MiB encode ledger would allow up to 32 MiB
  across both ledgers; the current decode budget does not silently cover it.
- **Compressed output:** reservation and pending encoded-tail ownership are
  distinct from plaintext scratch. Attribute and test them separately; each gRPC
  message still needs its own independent compression stream.
- **Shared decoded input:** a later opt-in immutable pending keeper may recover
  backing only after every application/transport alias disappears. The proposed
  keeper is bounded and charged by original full capacity; a miss must not wait,
  copy retained input or change pbrs parse/ownership semantics. It is not in C11.

Source reviews: `architecture-c11-next-identity-design.md`,
`architecture-c11-next-encode-design.md` (its own earlier source snapshot), and
`architecture-c11-next-shared-decode-design.md`. None supplies executed controls
or measured gains for these future options.

### Current deadline origin and outer-service ownership gap

The final-source review is `architecture-c11-next-deadline-design.md`. It finds
that the current admitted custom `Service` future has no outer RPC timeout before
choosing a shape. A service can cooperatively hold `Rpc` behind an async gate
beyond its received timeout; shape preparation then starts a fresh full duration.
Repeated `Rpc::deadline()` reads also compute a new `now() + duration`. This gap
exists in the current inline model; a new task/queue is not required to create it.
The proposed causal raw-peer test remains **NOT RUN**. Do not call the report a
reproduced wire failure or claim a timing/compliance verdict from source alone.

Relevant C11 positions: `server/connection.rs:574,644,716–743` accepts headers and
awaits admitted dispatch without a whole-service timer; `server/dispatch.rs:151–191`
and `server/router.rs:1082–1110` directly await custom services;
`server/rpc.rs:338–355,1217–1221,1294–1373` recompute original durations and stamp
deadlines during shape preparation.

The next correctness checkpoint needs one absolute deadline from local header
acceptance and one owner around the entire service future, including cooperative
pre-shape waits and any future queue. Interceptor/server caps may only tighten
it; metadata edits and repeated getters must not restore elapsed time. Preserve
the actual responder lease so expiration can produce one valid terminal status:
blindly dropping `dispatch(rpc)` inside `timeout_at` can reset the owned responder
before an outer driver sends deadline trailers. Keep permit and busy ownership
until actual destruction. An origin-only fix at eventual shape entry must not be
advertised as full pre-shape service expiry.

One handler driver per connection can isolate transport progress but still
couples a cheap RPC to a heavy sibling on that driver. Per-RPC tasks require
runnable worker capacity; a current-thread/per-core runtime does not gain a
thread by spawning. Tokio abort and timers cannot preempt a running poll. Keep
permits, buffers and busy leases owned until actual cleanup; dropping a bare
`JoinHandle` detaches work. Hard isolation needs an explicit execution domain or
process policy. These control proposals remain NOT RUN.

## Publication boundaries

No tracked edits until the explicit grant. Root owns capsule README/results and
the evidence index; preserve the frozen C8 day publisher's index marker. The
publisher changes only its own index/capsule paths. Keep the running C8 day and
all earlier historical evidence immutable; do not relabel them as C11 proof.
