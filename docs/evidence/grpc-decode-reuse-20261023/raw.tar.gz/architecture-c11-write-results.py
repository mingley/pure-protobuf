#!/usr/bin/env python3
"""Derive final C11 results and an optional day snapshot after root grants execution.

Preparation does not write tracked files. --execute requires the completed final
pipeline and immutable source pins; it creates new files without overwriting an
earlier result. The packager remains unchanged.
"""

import argparse
import datetime
import hashlib
import importlib.util
import json
import math
import os
from pathlib import Path
import re
import subprocess
import time


Q = Path(__file__).resolve().parent
ROOT = Q.parents[1]
DEST = ROOT / "docs/evidence/grpc-decode-reuse-20261023"
PINS = Q / "architecture-c11-source-pins.json"
PIPELINE = Q / "architecture-c11-pipeline-state.json"
PACKAGER = Q / "package-architecture-c10-evidence.py"
PACKAGER_SHA256 = "421a3b58036969be5b35f64d09e58be8b3082cd040ae6f4e0bde1948028e9c3b"
PINS_SHA256 = "82366dd76dd17d0c8ac4a27609796f7ae82c8b76fa9dc3efb06fd6f91ea3d619"
FINAL_SOURCE = "beb4ecd9a9b2143c440892607d5b486318062b61"
C10_SOURCE = "a675b61fe2775e336f33474c58342764cea814a8"
BASELINE = "9d6fb9c416fc32732450fd78d32ee16ff8b802de"
DAY_SNAPSHOT = Q / "architecture-c11-evidence-day-snapshot.json"
ACCOUNTING = (
    "offered_rpcs", "dispatched_rpcs", "completed_rpcs", "successful_rpcs",
    "failed_rpcs", "timeouts", "queue_overflows", "unstarted_rpcs", "unfinished_rpcs",
)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + "\n").encode()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def reference(path, archive_path=None):
    assert not path.is_symlink(), path
    name = path.relative_to(Q).as_posix() if path.is_relative_to(Q) else path.relative_to(ROOT).as_posix()
    return {"path": archive_path or name, "bytes": path.stat().st_size, "sha256": digest(path)}


def read_json(path, observed):
    data = path.read_bytes()
    actual = {"bytes": len(data), "sha256": sha(data)}
    if path in observed:
        assert observed[path] == actual, path
    observed[path] = actual
    return json.loads(data)


def gate_validator():
    assert digest(PACKAGER) == PACKAGER_SHA256, "Frozen packager changed"
    spec = importlib.util.spec_from_file_location("final_c11_capsule_gates", PACKAGER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.SOURCE = FINAL_SOURCE
    module.PINS_SHA256 = PINS_SHA256
    return module


def totals(summaries):
    return {key: sum(row[key] for row in summaries) for key in ("passed", "failed", "ignored")}


def finite_positive(value):
    return type(value) in (int, float) and math.isfinite(value) and value > 0


def number(value):
    if 0 < abs(value) < 0.01:
        return f"{value:.6f}".rstrip("0").rstrip(".")
    return f"{value:,.2f}".rstrip("0").rstrip(".")


def readable(metric, value):
    if value is None:
        return "unavailable"
    if metric == "requested_bytes":
        if value >= 1024 * 1024:
            return f"{number(value / (1024 * 1024))} MiB/RPC"
        if value >= 1024:
            return f"{number(value / 1024)} KiB/RPC"
        return f"{number(value)} B/RPC"
    labels = {"allocations": "allocations/RPC", "instructions": "instructions/RPC",
              "context_switches": "context switches/RPC", "syscalls": "syscalls/RPC",
              "task_wakeups": "task wakeups/RPC"}
    return f"{number(value)} {labels.get(metric, metric + '/RPC')}"


def comparison(metric, side, cell, before, after, **extra):
    if not (finite_positive(before) and finite_positive(after)):
        return None
    ratio = after / before
    if not finite_positive(ratio):
        return None
    return {"metric": metric, "side": side, "workload": cell,
            "before_per_rpc": before, "after_per_rpc": after,
            "before_readable": readable(metric, before), "after_readable": readable(metric, after),
            "after_over_before": ratio, "change_percent": (ratio - 1) * 100,
            "change_readable": f"{ratio:.3f}x ({(ratio - 1) * 100:+.2f}%)",
            "qualified": False, **extra}


def catalog(rows):
    """Keep every higher-cost observation, with the worst per side/metric first."""
    rows = [row for row in rows if row is not None]
    higher = sorted((row for row in rows if row["after_over_before"] > 1),
                    key=lambda row: (-row["after_over_before"], row["metric"], row["side"]))
    lower = sorted((row for row in rows if row["after_over_before"] < 1),
                   key=lambda row: (row["after_over_before"], row["metric"], row["side"]))
    worst, reductions = {}, {}
    for row in higher:
        worst.setdefault((row["metric"], row["side"]), row)
    for row in lower:
        reductions.setdefault((row["metric"], row["side"]), row)
    return {
        "available_comparisons": len(rows), "higher_cost_comparisons": len(higher),
        "lower_cost_comparisons": len(lower),
        "worst_higher_cost_by_metric_and_side": [worst[key] for key in sorted(worst)],
        "largest_reduction_by_metric_and_side": [reductions[key] for key in sorted(reductions)],
        "all_higher_cost_groups": higher,
        "interpretation": "Observed counter differences only. Higher cost includes small/noisy differences and is not a qualified speed or regression verdict.",
    }


def ab_performance(stem, observed):
    path = Q / (stem + "-summary.json")
    summary = read_json(path, observed)
    source_rows, control_rows, tonic_rows = [], [], []
    for row in summary["source_ranges"]:
        value = comparison(
            row["metric"], row["side"], row["cell"],
            row["baseline"]["median"], row["candidate"]["median"],
            basis="candidate median / baseline median", baseline=BASELINE, candidate=FINAL_SOURCE,
            paired_source_ratio_median=row["paired_source_ratios"]["median"],
            expected_repeats=row["expected_repeats"],
            baseline_available_repeats=row["baseline"]["available"],
            candidate_available_repeats=row["candidate"]["available"],
            native_endpoint=row["native_side"], dispositions=row["dispositions"],
        )
        (source_rows if row["native_side"] else control_rows).append(value)
    for row in summary["same_side_tonic_ranges"]:
        if row["version"] != "candidate":
            continue
        transport_index = 0 if row["side"] == "client" else 2
        value = comparison(
            row["metric"], row["side"], row["cell"], row["tonic"]["median"], row["native"]["median"],
            basis="native endpoint median / same-side tonic median", source=FINAL_SOURCE,
            paired_native_over_tonic_median=row["native_over_tonic"]["median"],
            expected_repeats=row["expected_repeats"],
            native_available_repeats=row["native"]["available"],
            tonic_available_repeats=row["tonic"]["available"],
            native_endpoint=row["cell"]["pair"][transport_index] == "native",
            dispositions=row["dispositions"],
        )
        tonic_rows.append(value)
    return {
        "summary": reference(path), "phase": summary["phase"], "passed": summary["passed"],
        "qualified": False, "captures": summary["retained_captures"],
        "expected_captures": summary["expected_captures"],
        "actual_rpc_totals_by_source": summary["actual_rpc_totals"],
        "raw_counter_availability": summary["raw_counter_availability"],
        "source_comparison_dispositions": summary["source_comparison_dispositions"],
        "same_side_tonic_dispositions": summary["same_side_tonic_dispositions"],
        "source_change_native_endpoints": catalog(source_rows),
        "source_change_control_endpoints": catalog(control_rows),
        "current_native_vs_same_side_tonic": catalog(tonic_rows),
        "all_group_references": {
            "source": {"path": path.name, "json_pointer": "/source_ranges"},
            "current_tonic": {"path": path.name, "json_pointer": "/same_side_tonic_ranges"},
            "coarse_cpu": {"path": path.name, "json_pointer": "/coarse_cpu_diagnostics"},
        },
        "limits": summary["limits"],
    }


def expanded_performance(observed):
    path = Q / "architecture-c11-counter-expanded-all-counters.json"
    summary = read_json(path, observed)
    rows = []
    statuses = {}
    for row in summary["medians"]:
        statuses[row["status"]] = statuses.get(row["status"], 0) + 1
        workload = {key: row[key] for key in (
            "payload_bytes", "connections", "in_flight", "tls", "compression", "codec", "shape"
        )}
        rows.append(comparison(
            row["metric"], row["side"], workload, row["tonic_per_rpc"], row["native_per_rpc"],
            basis="native median / same-side tonic median", source=FINAL_SOURCE,
            median_repeat_ratio=row["median_repeat_ratio"], status=row["status"],
            repeats_expected=row["repeats_expected"], repeats_observed=row["repeats_observed"],
            repeats_available=row["repeats_available"], repeat_dispositions=row["repeat_dispositions"],
        ))
    return {
        "summary": reference(path), "phase": summary["phase"], "passed": summary["passed"],
        "qualified": False, "captures": summary["captures"], "metrics_records": summary["metrics_records"],
        "expected_captures": summary["expected_captures"], "actual_rpc_totals": summary["actual_rpc_totals"],
        "raw_counter_availability": summary["raw_counter_availability"],
        "differential_counter_availability": summary["differential_counter_availability"],
        "dispositions": summary["dispositions"], "group_statuses": statuses,
        "current_native_vs_same_side_tonic": catalog(rows),
        "all_groups": {"path": path.name, "json_pointer": "/medians"},
        "counters": summary["counters"], "limits": summary["limits"],
    }


def process_summary(pid):
    proc = Path("/proc") / str(pid)
    try:
        raw = (proc / "stat").read_text()
        tail = raw[raw.rfind(")") + 2:].split()
        status = (proc / "status").read_text()
        memory = {}
        for key in ("VmRSS", "VmHWM", "VmSize"):
            match = re.search(r"^" + key + r":\s+(\d+)\s+kB$", status, re.MULTILINE)
            if match:
                memory[key] = int(match.group(1)) * 1024
        return {"pid": pid, "present": True, "state": tail[0], "start_ticks": tail[19],
                "executable": os.readlink(proc / "exe"), "memory_bytes": memory,
                "threads": len(list((proc / "task").iterdir())),
                "file_descriptors": len(list((proc / "fd").iterdir()))}
    except (FileNotFoundError, ProcessLookupError):
        return {"pid": pid, "present": False}
    except PermissionError:
        return {"pid": pid, "present": None, "observation": "permission denied"}


def captured_json(path):
    if not path.exists():
        return None, None
    for attempt in range(5):
        data = path.read_bytes()
        try:
            value = json.loads(data)
            return {"source_path": path.relative_to(Q).as_posix(), "bytes": len(data),
                    "sha256": sha(data), "raw_utf8": data.decode()}, value
        except json.JSONDecodeError:
            if attempt == 4:
                raise
            time.sleep(0.05)


def day_snapshot(prefix, expected_source, role):
    files, values = [], {}
    for name in (prefix + "-launcher.json", prefix + "-launch-request.json", prefix + "-launch.json",
                 prefix + "-termination.json", prefix + "-publication.json"):
        captured, value = captured_json(Q / name)
        if captured is not None:
            assert value.get("source") == expected_source, name
            files.append(captured)
            values[name] = value
    progress_path = Q / ("resource-" + prefix) / "progress.json"
    captured, progress = captured_json(progress_path)
    if captured is not None:
        if "source" in progress:
            assert progress["source"]["commit"] == expected_source
        files.append(captured)
    launch = values.get(prefix + "-launch.json", {})
    launcher = values.get(prefix + "-launcher.json", {})
    pids = {value[key] for value in (launch, launcher, progress or {})
            for key in ("pid", "supervisor_pid") if type(value.get(key)) is int}
    if not files:
        state = "not_launched_at_snapshot"
    elif prefix + "-termination.json" in values:
        state = "terminal_metadata_observed; separate publisher owns outcome"
    elif progress and progress.get("state") == "running":
        state = "running_at_snapshot"
    else:
        state = "launch_metadata_present; test progress not yet confirmed"
    elapsed = None
    if progress and type(progress.get("started_unix_seconds")) in (int, float):
        elapsed = max(0, time.time() - progress["started_unix_seconds"])
    executable = Q / ("resource-" + prefix) / "resource-test"
    binary = None
    if executable.is_file():
        binary = {"source_path": executable.relative_to(Q).as_posix(), "bytes": executable.stat().st_size,
                  "sha256": digest(executable)}
        if progress and progress.get("binary_sha256"):
            assert binary["sha256"] == progress["binary_sha256"]
    return {
        "source": expected_source, "role": role, "state": state, "qualified": False,
        "complete": False, "requested_duration_seconds": launch.get("requested_duration_seconds"),
        "elapsed_wall_seconds_estimate": elapsed, "captured_files": files,
        "processes": [process_summary(pid) for pid in sorted(pids)], "test_binary": binary,
        "scope": "Pack-time launch/progress and process observations only; files were sampled separately. This snapshot does not establish a completed or successful 24-hour outcome.",
    }


def test_run(prefix, observed):
    path = Q / (prefix + ".json")
    record = read_json(path, observed)
    stdout = Q / (prefix + ".stdout")
    stdout_bytes = stdout.read_bytes()
    stderr = Q / (prefix + ".stderr")
    stderr_bytes = stderr.read_bytes()
    for artifact, data in ((stdout, stdout_bytes), (stderr, stderr_bytes)):
        actual = {"bytes": len(data), "sha256": sha(data)}
        if artifact in observed:
            assert observed[artifact] == actual, artifact
        observed[artifact] = actual
    summaries = [
        {"status": state, "passed": int(passed), "failed": int(failed), "ignored": int(ignored)}
        for state, passed, failed, ignored in re.findall(
            r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", stdout_bytes.decode()
        )
    ]
    names = re.findall(r"Running tests/([^\s/]+)\.rs \(", stderr_bytes.decode())
    assert len(names) == len(summaries), prefix
    return {"record": reference(path), "stdout": reference(stdout),
            "stderr": reference(stderr), "source": record["source"],
            "exit_code": record["exit_code"], "target_summaries": summaries,
            "targets": dict(zip(names, summaries)), "totals": totals(summaries)}


def control_family(path, observed):
    state = read_json(path, observed)
    checks = [check for control in state["controls"] for check in control["checks"]]
    return {"record": reference(path), "source": state["pin"], "state": state["state"],
            "negative_checks": len(checks), "detected_negative_checks": sum(check["observed_expected_result"] is True for check in checks),
            "positive_observed_expected_result": state["positive"]["observed_expected_result"],
            "restored_clean": state["restored_clean"], "frozen_unchanged": state["frozen_unchanged"],
            "checks": checks, "positive": state["positive"]}


def write_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + f".tmp.{os.getpid()}")
    with temporary.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(temporary, path, follow_symlinks=False)
    temporary.unlink()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="root grants final results/snapshot writes after pipeline PASS")
    parser.add_argument("--pins-sha256", default=PINS_SHA256)
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"state": "prepared; no writes", "source": FINAL_SOURCE,
                          "output": str(DEST / "results.json")}))
        return 0
    assert __debug__, "Run without Python -O"
    assert args.pins_sha256 == PINS_SHA256 == digest(PINS)
    assert not DEST.is_symlink() and not (DEST / "results.json").exists()
    assert not DAY_SNAPSHOT.exists(), "Prior immutable snapshot must be retained"
    validator = gate_validator()
    observed = {}
    gates = validator.validate_gates(observed, PIPELINE, [], True)
    pins = read_json(PINS, observed)
    assert pins["candidate_runtime"] == FINAL_SOURCE
    pipeline = read_json(PIPELINE, observed)
    checks = read_json(Q / "architecture-c11-checks-state.json", observed)
    asan_path = Q / "architecture-c11-asan-supervisor-state.json"
    asan = read_json(asan_path, observed)
    asan_totals = {key: sum(check["totals"][key] for check in asan["checks"])
                   for key in ("passed", "failed", "ignored")}
    workspace_check = next(check for check in checks["checks"] if check["name"] == "workspace")
    performance = {"selected_native": ab_performance("architecture-c11-counter-ab", observed),
                   "selected_cpu": ab_performance("architecture-c11-cpu-ab", observed),
                   "expanded_native": expanded_performance(observed)}
    benchmark_tests = {check["name"]: check["totals"] for check in checks["checks"]
                       if check["name"] in ("rpc-benchmark-correctness", "tonic-benchmark-correctness")}
    preview_path = Q / "architecture-c11-resource-preview/report.json"
    preview = read_json(preview_path, observed)
    initial_failed = test_run("architecture-c11-focused-cancellation", observed)
    serving_positive = test_run("architecture-c11-focused-cancellation-v2", observed)
    assert initial_failed["totals"]["failed"] == 1 and initial_failed["exit_code"] != 0
    assert serving_positive["exit_code"] == 0 and serving_positive["totals"]["failed"] == 0
    assert len(initial_failed["target_summaries"]) == len(serving_positive["target_summaries"]) == 2
    assert serving_positive["target_summaries"][0]["passed"] == 1
    assert serving_positive["target_summaries"][1]["passed"] == 1100
    assert initial_failed["targets"]["serving"]["passed"] == 1099
    assert initial_failed["targets"]["serving"]["failed"] == 1
    assert initial_failed["targets"]["prequeued_request_failure"]["passed"] == 1
    for check in checks["checks"]:
        assert check["exit_code"] == 0
    designs = []
    for name in ("architecture-c11-next-encode-design.md", "architecture-c10-handler-isolation-review.md",
                 "architecture-c11-final-design-review-pin.json"):
        path = Q / name
        if path.is_file():
            observed[path] = {"bytes": path.stat().st_size, "sha256": digest(path)}
            designs.append(reference(path))
    snapshot = {
        "schema": "pbrs.resource-day-snapshot.v1", "snapshot_utc": now(), "qualified": False,
        "c8": day_snapshot("architecture-c8-day", BASELINE, "older runtime; never inherited by C11"),
        "c11": day_snapshot("architecture-c11-day", FINAL_SOURCE, "final runtime; independent new attempt"),
        "prost_cache_24_hour_qualification": False,
        "fixture_limit": "Both resource days use the pbrs-message resource fixture. The fixture does not exercise Prost decoded-buffer reuse for 24 hours.",
    }
    snapshot_bytes = encoded(snapshot)
    capture_totals = {name: value["captures"] for name, value in performance.items()}
    rpc_totals = {key: 0 for key in ACCOUNTING}
    for name, value in performance.items():
        source_totals = value.get("actual_rpc_totals_by_source")
        groups = source_totals.values() if source_totals is not None else [value["actual_rpc_totals"]]
        for group in groups:
            for key in ACCOUNTING:
                rpc_totals[key] += group[key]
    result = {
        "schema": "pbrs.grpc-decode-reuse-results.v1", "created_utc": now(),
        "source": FINAL_SOURCE, "baseline_source": BASELINE, "initial_candidate_source": C10_SOURCE,
        "source_tree": subprocess.check_output(["git", "rev-parse", FINAL_SOURCE + "^{tree}"], cwd=ROOT, text=True).strip(),
        "qualified": False, "production_ready": False, "broad_speed_superiority": False,
        "world_fastest": False, "spec_complete": False,
        "all_important_cases_beat_tonic_prost": False,
        "source_pins": reference(PINS), "pipeline": reference(PIPELINE),
        "immutable_pipeline_inputs": pipeline["immutable_inputs"],
        "writer": reference(Path(__file__).resolve()),
        "gate_validator": reference(PACKAGER, "controllers/package-architecture-c10-evidence.py"),
        "implementation": {
            "scope": "Within-stream decoded-buffer reuse after unique fully consumed backing is recovered.",
            "per_retained_buffer_capacity_bytes": 4 * 1024 * 1024,
            "process_retained_capacity_bytes": 16 * 1024 * 1024,
            "policy": "Private initial idle-retention policy. Charge actual full allocation capacity; cache misses never fail an RPC.",
            "excluded_from_retention_budget": ["active decoding", "application-owned messages", "codec scratch", "total process memory"],
            "terminal_release": "Observed DATA EOF, cancellation/deadline, errors and Drop release retained scratch.",
            "unary_reuse": False,
        },
        "validation": {
            "checks_record": reference(Q / "architecture-c11-checks-state.json"),
            "workspace": {"source": FINAL_SOURCE, "record": reference(Q / "architecture-c11-workspace.json"),
                          "state": "passed", "counts": gates["tests"]["workspace"],
                          "targets": workspace_check["targets"]},
            "strict_and_release_checks": [{key: check[key] for key in ("name", "exit_code", "duration_seconds", "totals")}
                                          for check in checks["checks"]],
            "benchmark_correctness": benchmark_tests,
            "sanitizer": {"source": FINAL_SOURCE, "record": reference(asan_path), "state": asan["state"],
                          "totals": asan_totals, "phases": [{key: check[key] for key in ("name", "totals", "exit_code")}
                                                          for check in asan["checks"]],
                          "executables": asan["executables"],
                          "scope": "Fresh nightly-2025-06-26 build-std ASAN with leak detection. Six selected binaries; raw-peer coverage additionally appears in the final workspace."},
            "decode_negative_controls": control_family(Q / "architecture-c11-negative-controls-state.json", observed),
            "resolver_negative_controls": control_family(Q / "architecture-c11-resolver-negative-controls-state.json", observed),
            "resource_preview": {"source": FINAL_SOURCE, "record": reference(preview_path),
                                 "requested_seconds": preview["duration_requested_seconds"],
                                 "actual_seconds": preview["duration_actual_seconds"], "smoke": preview["smoke"],
                                 "exit_code": preview["exit_code"], "settings": preview["settings"],
                                 "process_limits": preview["process_limits"], "qualified": False},
        },
        "performance": performance,
        "capture_accounting": {"captures_by_campaign": capture_totals,
                               "total_captures": sum(capture_totals.values()),
                               "actual_rpc_totals_all_campaigns_and_sources": rpc_totals,
                               "scope": "Sums actual retained accounting from both matched source versions and the final-only expanded campaign; no projected RPC counts."},
        "history": {**gates["history"], "first_c11_serving_and_raw_attempt": initial_failed,
                    "repaired_c11_serving_and_raw_attempt": serving_positive,
                    "wrong_toolchain_build": gates["rejected_build"], "correct_matched_tools": gates["matched_build_tools"],
                    "c10_cleanup": reference(Q / "architecture-c10-rpc-cache-reclaim-before-c11.json"),
                    "c11_cleanup": reference(Q / "architecture-c11-rpc-cache-reclaim.json")},
        "resource_days": {"snapshot": {"path": DAY_SNAPSHOT.name, "bytes": len(snapshot_bytes), "sha256": sha(snapshot_bytes)},
                          "c8_source": BASELINE, "c11_source": FINAL_SOURCE,
                          "c8_state_at_snapshot": snapshot["c8"]["state"],
                          "c11_state_at_snapshot": snapshot["c11"]["state"],
                          "c8_qualification_inherited": False, "prost_cache_24_hour_qualification": False,
                          "fixture_limit": snapshot["fixture_limit"],
                          "scope": "Frozen metadata/process snapshot only. Dedicated day publishers own terminal outcomes and immutable day capsules."},
        "next_design": {"state": "source_review_only; not implemented or measured", "references": designs,
                        "experiments": ["Bounded stream-owned plaintext encode scratch with explicit alias/capacity accounting.",
                                        "A separate compressed-output reservation experiment on compressible, random and changing inputs.",
                                        "Protocol progress and absolute deadline controls before changing application-poll scheduling."],
                        "predicted_savings": None},
        "limits": [
            "Passing tests and diagnostics do not establish production readiness, specification completeness, world leadership or broad superiority over tonic/prost.",
            "Allocation bytes are cumulative requested bytes under N/2N subtraction; they are not retained capacity, live heap, RSS or peak memory.",
            "Native capture binaries have allocator counters enabled. Callgrind instructions describe that diagnostic configuration, not shipping CPU speed.",
            "Context switches and coarse process CPU ticks are scheduling observations; all higher-cost rows remain visible without becoming speed rankings.",
            "Ratio of medians and median paired/repeat ratios are distinct and retained separately.",
            "All available higher-cost groups are retained in highlights; missing/partial counter groups remain in referenced complete summaries.",
            "Synthetic payloads, fixed message counts and selected load/transport scopes do not replace complete production workloads or a dedicated-host latency/goodput matrix.",
            "The older C8 resource day is separate. A new C11 pbrs-fixture day still does not provide 24-hour Prost-cache qualification.",
            "The failed C10 workspace and first C11 focused attempt remain failures at their actual source; later passes do not rewrite that history.",
        ],
    }
    for path, expected in observed.items():
        assert path.stat().st_size == expected["bytes"] and digest(path) == expected["sha256"], path
    result_bytes = encoded(result)
    write_new(DAY_SNAPSHOT, snapshot_bytes)
    write_new(DEST / "results.json", result_bytes)
    print(json.dumps({"source": FINAL_SOURCE, "qualified": False,
                      "workspace": gates["tests"]["workspace"], "sanitizer": asan_totals,
                      "captures": sum(capture_totals.values()), "rpc_totals": rpc_totals,
                      "results": {"path": str(DEST / "results.json"), "sha256": sha(result_bytes)},
                      "day_snapshot": {"path": str(DAY_SNAPSHOT), "sha256": sha(snapshot_bytes)}}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
