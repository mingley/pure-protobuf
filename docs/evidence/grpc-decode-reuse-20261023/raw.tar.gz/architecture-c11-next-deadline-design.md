# Deadline origin and service ownership: next design

Reviewed source: `beb4ecd9a9b2143c440892607d5b486318062b61` (C11).
Read-only source analysis. **The proposed control has not run. No new deadline failure is reproduced or qualified by this report.** No source edits, compilation, campaign launch or modification of the prepared C11 day drivers occurred.

## Finding

There is no outer RPC timeout around an admitted custom `Service` future before it chooses a call shape. A cooperative service can keep `Rpc` behind an ordinary async gate longer than its `grpc-timeout`; the kernel has not yet constructed the request timer. Once the service calls the shape helper, `InboundRpc::from_rpc` starts a fresh full duration. This hazard exists in the current execution model; introducing a task or dispatch queue would enlarge it but is not required to create it.

This is distinct from the handler isolation issue. The proposed fixture promptly returns `Pending`, uses no blocking poll and permits the HTTP/2 connection to keep running. Moving protocol/application tasks without changing deadline origin and owner semantics does not fix this gap.

## Exact source chain

| Location | Current behavior |
| --- | --- |
| `server/connection.rs:574` | Pops request-associated header facts and shared headers immediately after HTTP/2 accept. No per-RPC absolute deadline is captured. |
| `connection.rs:644` | Computes effective timeout only to reject a duration of exactly zero. A nonzero duration does not start a timer here. |
| `connection.rs:711` | Only observer queue-wait timing is captured; it is a `std::time::Instant`, optional when no observer is installed. |
| `connection.rs:716–743` | Admitted future owns busy lease and RPC permit, constructs `incoming_rpc`, then directly awaits `dispatch`. There is no RPC timeout wrapper. Connection age/idle/drain timers have different purposes. |
| `connection.rs:311–376` | `incoming_rpc` stores config/headers/handles and interceptor duration cap. `Rpc` has neither admission time nor an absolute deadline. |
| `server/dispatch.rs:151–156,161–191` | `SingleDispatch` directly polls the user service future after hooks/interceptor setup. No timeout surrounds custom `Service::call`/`call_boxed`. |
| `server/router.rs:1082–1110` | Router likewise awaits the chosen dynamic service directly. |
| `server/rpc.rs:338–355` | `effective_timeout()` selects the original durations; every `deadline()` getter returns a new `Instant::now()+duration`. Repeated reads move the reported absolute deadline forward. |
| `rpc.rs:1217–1221` | Unary/server-streaming request preparation creates `InboundRpc` only after entering the shape future, then starts a relative `wrap_timeout`. |
| `rpc.rs:1240,1294–1373` | Streaming preparation also creates `InboundRpc` at shape selection; `from_rpc` recomputes original header/server/interceptor durations and stamps `now()+timeout`. |
| `rpc.rs:1576–1578` | Streaming handler timeout is also a relative duration. The resulting stamped absolute deadline is used for inbound/response stream handling. |
| `wire/send.rs:615–637` | `wrap_timeout` uses Tokio's relative `timeout`; it does not cover time before constructing/polling this wrapper. |

The exact start of shape preparation differs: `unary`, `server_streaming` and `client_streaming` are async methods whose bodies run when polled; `bidi_streaming` constructs preparation synchronously. Neither boundary is an admission timestamp. A custom wrapper may also construct a shape future and then hold it without polling. An origin-only repair must handle that case too.

Before shape preparation there is also no `InboundRpc` cancellation flag/guard for a hypothetical handler child. A control must witness the service future's actual destruction and the uninvoked handler closure; it must not require a cancellation child that never existed.

## Contract and protocol facts

The [gRPC HTTP/2 protocol](https://github.com/grpc/grpc/blob/master/doc/PROTOCOL-HTTP2.md) carries `grpc-timeout` as a relative duration with a decimal value and unit (`H`, `M`, `S`, `m`, `u`, `n`), rather than a shared absolute clock. The wire grammar allows up to eight digits. Absence permits an infinite timeout, subject to a server's own processing limit. This analysis uses the valid header `grpc-timeout: 20m`; malformed/overflow policy is a separate issue.

The [deadline guide](https://grpc.io/docs/guides/deadlines/) describes server cancellation when the client deadline expires and application responsibility for stopping work it has spawned. This does not make arbitrary Rust polls preemptible. It also does not establish a universal exact wire-emission latency. The relevant observable here is causal: after the server has accepted and deliberately held an RPC beyond its budget while its tasks remain cooperative, a later shape choice must not grant it a fresh budget or execute a handler that was already expired.

The [status code guide](https://grpc.io/docs/guides/status-codes/) defines `DEADLINE_EXCEEDED` as expiration before completion. Before response commitment, the intended server result is valid gRPC trailers with `grpc-status: 4`, not an unexplained reset caused by losing the responder. A genuine peer RST/connection death may prevent status delivery; keep the test peer live and avoid those races.

A practical server origin is the earliest local acceptance of complete request headers, before an admitted future, interceptor or service can wait. It cannot recover time before local HTTP/2 parsing without a lower-level receipt timestamp. It need not reproduce the client's absolute clock: the received duration is its local starting budget. The server overlay and interceptor caps must only tighten the accepted deadline. Metadata edits, queue residence and repeated getters must not restore time already spent.

Current Rust API documentation explicitly calls `Rpc::deadline()` a newly computed value and stamps `Request::deadline` at shape dispatch. Correcting that behavior requires updating the documented contract and assertions; do not silently claim that the current implementation already has an admission-origin deadline.

## Small independent-peer causal control (NOT RUN)

Use one current-thread Tokio runtime with paused time, a duplex IO pair, the native server `serve_connection`, and an independent external `h2` client. The h2 client is only a protocol peer; do not use the native gRPC client or Tonic deadline middleware. A `grpc-timeout` header alone must not cause this client to send RST. Keep its response/body handles and connection driver alive through the assertions.

The service implementation is hand-written and cooperative:

1. Its `Service::call` future creates a Drop witness, records entry time and `rpc.deadline()`, and signals an admission acknowledgement. It also constructs the later handler closure with a capture Drop witness before waiting. It then waits on a watch/oneshot gate **while retaining `Rpc` and that uninvoked closure**. This gate returns `Pending` promptly. No shape helper or user handler has run yet.
2. After the gate opens, it records a second `rpc.deadline()` and calls `rpc.unary` with that previously constructed typed handler, which increments `handler_entered` and immediately returns a tiny OK reply. Its capture Drop witness records disposal even when the handler is never invoked. A valid empty protobuf request can be the complete five-byte gRPC prefix with zero payload and DATA END_STREAM.
3. The peer sends POST to the declared service/method, `content-type: application/grpc`, `te: trailers`, and `grpc-timeout: 20m`. Send the complete request immediately and retain it. Witness actual service entry before advancing the clock. Because time remains frozen during handshake/admission, a known header/admission origin and service-entry origin coincide in this smallest test.
4. While the gate remains closed, explicitly advance paused time by21 ms. Continue driving server and peer tasks without permitting extra automatic Tokio time advancement. A self-waking bounded coordinator or an equivalent explicit polling fence is needed: merely waiting on network IO with paused Tokio time can auto-advance to the next timer and hide the intended boundary. Use a finite real-time watchdog only to prevent a test hang; it is not a service latency threshold.
5. Record the service-owner Drop witness, handler count and any peer status while the gate is still closed. Under the corrected full service deadline contract, the owner is destroyed once, `handler_entered==0`, the uninvoked closure/retained Rpc are released, and the peer obtains valid trailers-only `grpc-status: 4`. No release gate, peer cancellation or connection close may satisfy these milestones. If the implementation intentionally guarantees only an origin check on eventual shape entry, label that narrower behavior separately; it will not satisfy this full milestone.
6. Always release the gate in failure cleanup. In a separate origin-only subcase, deliberately release it after21 ms even if no status appeared. The corrected implementation must reject the expired call without invoking the handler; the current source is predicted to invoke it and return OK under a newly started20 ms interval. An immediate-ready handler avoids requiring another clock advance and makes the reset-budget hazard visible.
7. Assert one terminal result, no response message/OK status after expiry, exact owner/capture drops, and no leaked RPC permit/busy lease. Keep resource charges until destruction actually happens. Make an ordinary no-timeout recovery call on the same connection. Decode h2 headers/trailers and all relevant stream frames; do not interpret response-future completion or a reset as proof of valid gRPC deadline trailers.

Expected current-source outcomes are hypotheses: while gated, neither the service-owner drop nor server deadline status is expected; after release, the first and second getter values are expected to differ by21 ms and the unary handler can succeed. **No such outcome was observed in this review.** Existing client capacity/deadline-admission regressions exercise outbound HTTP/2 admission, not this inbound custom-Service gap.

Useful followups are a server-only20 ms cap with no peer header, a shorter interceptor cap, a shape future constructed but held unpolled, all four call shapes, reset-vs-deadline races, and a slow response producer. Keep the small raw-peer control separate from these extensions so its failure is attributable to deadline origin/ownership.

## Minimal correct architecture, independent of protocol scheduling

Capture the accepted timeout budget and a single absolute deadline before the RPC is placed in admitted work. Carry it through `Rpc`, service dispatch, shape preparation, `Request`, response preparation and response draining. Preserve the received duration separately for inspection. Calculate remaining time from the fixed deadline; use absolute timeout operations rather than reconstructing a full relative timeout at each stage. `Rpc::deadline()` must return a stable absolute value, and cap updates must reduce it monotonically. Header metadata changes cannot remove or lengthen an already accepted peer deadline. Define a checked Instant-overflow policy instead of introducing a new unchecked addition.

That origin repair alone does not expire a custom service that never chooses a shape. Add one deadline owner around the **whole service future**, starting before service construction/first poll, including pre-shape waits and any dispatch queue. This can live in the existing concrete admitted child; no per-RPC spawn or protocol scheduling redesign is needed to demonstrate the fix. The no-timeout branch can remain direct. Keep the permit/busy lease with this actual owner until the service future and its resources are destroyed.

The owner must also preserve terminal-response ownership. Simply wrapping `dispatch(rpc)` in `timeout_at` and dropping it is insufficient: the inner future owns `Rpc.respond`, and dropping it can reset the stream before the outer layer can send `grpc-status: 4`. A timer callback must not race a second responder against the one still owned by a handler.

Use a single bounded per-call lifecycle/response record, shared by the driver and Rpc/shape owners, with one terminal transition and an explicit lease for whichever response handle is currently in use. Before headers, cancellation of the service future must return the live SendResponse lease to the driver (or leave it in the record), so the driver can emit trailers-only4 after destruction. After headers, the same ownership discipline must leave the active SendStream/trailer path with the surviving terminal owner, or let the existing response drain finish the already-established deadline without duplicate output. Never reuse a consumed SendResponse after headers. Locks, if used, guard brief ownership transfers only and are not held across application awaits. Reuse the existing per-call heap record where possible; do not layer an unbounded task/channel/response queue on top.

Poll-time ordering matters. A timer is cooperative, and Tokio timeout may first poll an already-ready inner future. Explicitly reject an already expired deadline before invoking a newly admitted service/handler or giving a resumed phase fresh work; do not rely solely on an expired timeout wrapper to prevent an immediate-ready handler from running. Once a response has already completed on wire, later observation of elapsed time must not invent a second terminal result. Define and test this commit boundary once.

Start with the pre-header ownership/control above, then extend the same record through response commitment and all shapes before calling the entire service deadline contract fixed. The absolute-origin repair is a small separable checkpoint; a full outer owner is a slightly larger ownership change and must not be advertised as complete if it only restores the origin at shape entry. Both can be implemented and tested without changing inline/per-task scheduling. Neither can preempt a synchronous blocking poll or safely release its memory/permit before that poll returns.

Keep this work outside frozen C11. After a causal red, implement a separate checkpoint and retain the red/source identities. Require fresh correctness, cancellation/resource and comparative controls for that checkpoint rather than reusing C11 qualification.
