#!/usr/bin/env python3
"""Parse existing Callgrind client profiles; no endpoints or profiler run."""
import collections,gzip,hashlib,json,re,statistics
from pathlib import Path
Q=Path('/workspace/pure-protobuf/work/qualification');DIR=Q/'architecture-c11-cpu-ab'
CAMPAIGN=json.loads((DIR/'campaign.json').read_text())

def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def parse(path):
 names={'ob':{},'fl':{},'fn':{}};self_cost=collections.Counter();edges=collections.Counter();calls=collections.Counter();headers={};counts=collections.Counter()
 current_ob='';current_fn='';callee_fn='';callee_ob=None;pending=False;pending_calls=0;lines=0
 def ref(kind,value):
  match=re.fullmatch(r'\((\d+)\)(?: (.*))?',value)
  if not match:return value
  key=match[1]
  if match[2]is not None:
   if key in names[kind]and names[kind][key]!=match[2]:raise ValueError('conflicting symbol alias')
   names[kind][key]=match[2]
  return '#'+key
 with gzip.open(path,'rt')as source:
  for raw in source:
   line=raw.strip();lines+=1
   if not line or line.startswith('#'):continue
   if line.startswith(('events:','positions:','summary:','totals:','cmd:')):
    key,value=line.split(':',1);counts[key]+=1;headers[key]=value.strip();continue
   if '='in line and not line[0]in '*+-0123456789':
    key,value=line.split('=',1)
    if key in ['ob','cob']:value=ref('ob',value)
    elif key in ['fl','fi','fe','cfi','cfl']:value=ref('fl',value)
    elif key in ['fn','cfn']:value=ref('fn',value)
    if key=='ob':current_ob=value
    elif key=='fn':current_fn=value;callee_ob=None
    elif key=='cob':callee_ob=value
    elif key=='cfn':callee_fn=value
    elif key=='calls':pending=True;pending_calls=int(value.split()[0])
    elif key in ['jump','jcnd','jumps']:raise ValueError('unsupported jump records')
    continue
   if line[0]in '*+-0123456789':
    tokens=line.split();n=len(headers['events'].split());cost=int(tokens[-n:][headers['events'].split().index('Ir')]);key=(current_ob,current_fn)
    assert len(tokens)==len(headers['positions'].split())+n,(path,line)
    if pending:
     edge=(key,(callee_ob if callee_ob is not None else current_ob,callee_fn));edges[edge]+=cost;calls[edge]+=pending_calls;pending=False
    else:self_cost[key]+=cost
 assert not pending
 def resolve(kind,value):return names[kind].get(value[1:],value)if value.startswith('#')else value
 def resolved(key):return (resolve('ob',key[0]),resolve('fn',key[1]))
 costs=collections.Counter()
 for key,value in self_cost.items():costs[resolved(key)]+=value
 resolved_edges=collections.Counter();resolved_calls=collections.Counter()
 for key,value in edges.items():edge=(resolved(key[0]),resolved(key[1]));resolved_edges[edge]+=value;resolved_calls[edge]+=calls[key]
 summary=int(headers['summary']);total=int(headers['totals']);exclusive=sum(costs.values())
 assert counts['summary']==counts['totals']==counts['events']==1
 assert headers['events']=='Ir'
 return dict(path=str(path),sha256=digest(path),headers=headers,summary=summary,totals=total,exclusive_sum=exclusive,summary_difference=exclusive-summary,totals_difference=exclusive-total,lines=lines),costs,resolved_edges,resolved_calls

profiles=[];costs={};edge_costs={};edge_calls={}
for capture in CAMPAIGN['captures']:
 cell=CAMPAIGN['cells'][capture['cell_index']]
 if (capture['version']=='candidate'and cell['payload_bytes']==1024 and cell['shape']=='client_stream'
     and cell['pair']in [['native','prost','tonic','prost'],['tonic','prost','tonic','prost']]):
  run_path=DIR/capture['path'];run=json.loads(run_path.read_text());key=(cell['pair'][0],cell['repeat'],capture['count'])
  record,cost,edge,call=parse(run_path.parent/'client.callgrind.gz');assert record['summary']==run['instruction_totals']['client']
  record.update(transport=key[0],repeat=key[1],rpc_count=key[2],run=str(run_path),run_sha256=digest(run_path))
  profiles.append(record);costs[key]=cost;edge_costs[key]=edge;edge_calls[key]=call
assert len(profiles)==8
functions=sorted(set().union(*(c.keys()for c in costs.values())))
rows=[]
for fn in functions:
 values={transport:[(costs[transport,r,20][fn]-costs[transport,r,10][fn])/10 for r in [0,1]]for transport in ['native','tonic']}
 native=statistics.mean(values['native']);tonic=statistics.mean(values['tonic'])
 rows.append(dict(object=fn[0],function=fn[1],native_ir_per_rpc=native,tonic_ir_per_rpc=tonic,native_minus_tonic=native-tonic,per_repeat=values))
row_sums={k:sum(row[k]for row in rows)for k in ['native_ir_per_rpc','tonic_ir_per_rpc','native_minus_tonic']}
print(json.dumps(dict(profiles=profiles,conserved_totals=row_sums,top_positive=sorted(rows,key=lambda row:row['native_minus_tonic'],reverse=True)[:22],top_negative=sorted(rows,key=lambda row:row['native_minus_tonic'])[:15]),indent=2))
output=Q/'architecture-c11-client-upload-ir-functions.json'
with output.open('x')as target:json.dump(dict(qualified=False,parser_sha256=digest(Path(__file__)),campaign_sha256=digest(DIR/'campaign.json'),profiles=profiles,function_rows=rows,conserved_totals=row_sums),target,indent=2);target.write('\n')
