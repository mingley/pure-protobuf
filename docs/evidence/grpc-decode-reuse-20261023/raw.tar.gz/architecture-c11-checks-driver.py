import datetime,hashlib,json,os,re,shutil,subprocess,sys,time
from pathlib import Path
r=Path('/workspace/pure-protobuf'); q=r/'work/qualification'; pin=sys.argv[1]; statepath=q/'architecture-c11-checks-state.json'
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def git(*args): return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
def source(): return {'head':git('rev-parse','HEAD'),'status':git('status','--porcelain','--untracked-files=all')}
def save():
 temporary=statepath.with_suffix('.tmp');temporary.write_text(json.dumps(state,indent=2)+'\n');temporary.replace(statepath)
before=source(); assert before=={'head':pin,'status':''},before
base=os.environ.copy();base.update(CARGO_TARGET_DIR=str(r/'work/stable-target'),CARGO_BUILD_JOBS='1',PBRS_CODEGEN_TIME=str(q/'architecture-c6-time-dependency/root/usr/bin/time'))
phases=[
 ('format',120,['cargo','+stable','fmt','--all','--','--check'],{}),
 ('clippy-root-alltargets',600,['cargo','+stable','clippy','--locked','--all-targets','--all-features','--','-D','warnings'],{}),
 ('clippy-grpc-alltargets',600,['cargo','+stable','clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'],{}),
 ('clippy-grpc-adapter-example',600,['cargo','+stable','clippy','--locked','--lib','--all-features','-p','pbrs-grpc','-p','protobuf-tonic','-p','pbrs-grpc-example-greeter','--','-D','warnings'],{}),
 ('examples',600,['cargo','+stable','build','--locked','--workspace','--examples'],{}),
 ('rpc-benchmark-correctness',900,['cargo','+stable','test','--locked','--manifest-path','rpc-bench/Cargo.toml','--bin','rpc-bench','--test','worker','--test','fairness','--test','tonic_fairness','--','--test-threads=4'],{}),
 ('tonic-benchmark-correctness',600,['cargo','+stable','test','--locked','--manifest-path','tonic-bench/Cargo.toml','--bin','tonic-bench','--','--test-threads=4'],{'PURE_PROTOBUF_CHECKED_V4':'1'}),
 ('rustdoc',600,['cargo','+stable','doc','--locked','--workspace','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'}),
 ('msrv',600,['cargo','+1.85.0','check','--locked','-p','pbrs','-p','pbrs-grpc','--lib'],{'CARGO_TARGET_DIR':str(r/'work/msrv-c11-target')}),
 ('msrv-zstd',600,['cargo','+1.87.0','check','--locked','-p','pbrs-grpc','--lib','--features','zstd'],{'CARGO_TARGET_DIR':str(r/'work/msrv-c11-zstd-target')}),
 ('workspace',5400,['cargo','+stable','test','--locked','--workspace','--all-features','--no-fail-fast','--','--test-threads=4'],{})]
state={'source':before,'started_utc':now(),'jobs':{'default':1,'workspace':2},'test_workers':4,'cpu_quota_cores':4,'checks':[],'qualification':False,'state':'running'};save()
for name,limit,args,extra in phases:
 assert source()==before,source()
 prefix=q/('architecture-c11-'+name);env=base|extra
 if name=='workspace':env['CARGO_BUILD_JOBS']='2'
 command=[sys.executable,str(r/'work/record.py'),str(prefix),str(limit),str(r/'work/run-rust'),'nice','-n','10',*args]
 state['active']=name;save()
 completed=subprocess.run(command,cwd=r,env=env)
 record=json.loads(prefix.with_suffix('.json').read_text());after=source()
 summary=[{'status':s,'passed':int(a),'failed':int(b),'ignored':int(c)} for s,a,b,c in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',prefix.with_suffix('.stdout').read_text())]
 entry={'name':name,'build_jobs':int(env['CARGO_BUILD_JOBS']),'extra_environment':extra,'exit_code':record['exit_code'],'duration_seconds':record['duration_seconds'],'source_after':after,'summaries':summary,'targets':len(summary),'totals':{k:sum(v[k] for v in summary) for k in ('passed','failed','ignored')},'logs':{f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in (prefix.with_suffix('.stdout'),prefix.with_suffix('.stderr'))}}
 state['checks'].append(entry);save()
 if completed.returncode or after!=before:
  state.update(state='failed',completed_utc=now());save();sys.exit(1)
 if name.startswith('msrv'):
  cache=Path(extra['CARGO_TARGET_DIR']);assert cache.parent==r/'work' and cache.name in ('msrv-c11-target','msrv-c11-zstd-target') and not cache.is_symlink()
  inventory=[dict(path=str(f.relative_to(cache)),bytes=f.stat().st_size,sha256=hashlib.sha256(f.read_bytes()).hexdigest())for f in sorted(cache.rglob('*'))if f.is_file() and not f.is_symlink()]
  proof=q/('architecture-c11-'+name+'-cache-inventory.json');proof.write_text(json.dumps(dict(cache=str(cache),files=inventory,bytes=sum(x['bytes']for x in inventory)),indent=2)+'\n')
  shutil.rmtree(cache);entry['cache_reclaimed']=dict(path=str(proof),sha256=hashlib.sha256(proof.read_bytes()).hexdigest());save()

state.update(state='passed',completed_utc=now(),active=None);save()
