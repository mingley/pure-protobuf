"""Run pinned C10 ASAN/LSan checks, inventory their fresh cache, then reclaim it.

This driver is prepared separately from its launch. It never deletes another
target directory, and preserves the dedicated cache if a pre-cleanup check or
safety gate fails. Run after performance captures and other builds are quiet.
"""

import datetime
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import traceback
from pathlib import Path


Q = Path(__file__).resolve().parent
ROOT = Q.parents[1]
CWD = ROOT / "work/architecture-c11"
CACHE = ROOT / "work/asan-c11-target"
PINS = Q / "architecture-c11-source-pins.json"
STATE = Q / "architecture-c11-asan-supervisor-state.json"
TOOLCHAIN = "nightly-2025-06-26"
TARGET = "x86_64-unknown-linux-gnu"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def source():
    return {
        "head": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=CWD, text=True
        ).strip(),
        "status": subprocess.check_output(
            ["git", "status", "--porcelain", "--untracked-files=all"],
            cwd=CWD,
            text=True,
        ).strip(),
    }


def files_snapshot(paths):
    return {
        str(path): {"bytes": path.stat().st_size, "sha256": digest(path)}
        for path in paths
    }


def cache_users():
    active, inaccessible, zombies = [], [], []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            # Zombies have no mappings or open descriptors, even where procfs
            # permissions prevent reading maps. Record them separately.
            status = (proc / "status").read_text()
            if re.search(r"^State:\s+Z\b", status, re.MULTILINE):
                zombies.append(int(proc.name))
                continue
            maps = (proc / "maps").read_text()
            cmdline = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(
                errors="replace"
            )
            if str(CACHE) in maps or str(CACHE) in cmdline:
                active.append({"pid": int(proc.name), "cmdline": cmdline})
            for descriptor in (proc / "fd").iterdir():
                try:
                    target = os.readlink(descriptor)
                except FileNotFoundError:
                    continue
                if target == str(CACHE) or target.startswith(str(CACHE) + "/"):
                    active.append(
                        {"pid": int(proc.name), "fd": descriptor.name, "target": target}
                    )
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            inaccessible.append(int(proc.name))
    return {"active_users": active, "inaccessible_same_uid_proc": inaccessible, "zombies": zombies}


def main():
    state = {
        "started_utc": now(),
        "supervisor_pid": os.getpid(),
        "state": "running",
        "checks": [],
        "qualification": False,
        "cache_reclaimed": False,
        "free_bytes_before": shutil.disk_usage(ROOT).free,
    }
    atomic(STATE, state)
    try:
        pins = json.loads(PINS.read_text())
        pin = pins["candidate_runtime"]
        assert re.fullmatch(r"[0-9a-f]{40}", pin), pin
        state.update(
            source_pin=pin,
            pins={"path": str(PINS), "sha256": digest(PINS)},
            source_before=source(),
        )
        atomic(STATE, state)
        assert state["source_before"] == {"head": pin, "status": ""}, state["source_before"]
        assert not CACHE.exists() and not CACHE.is_symlink(), "fresh dedicated cache expected"
        assert CACHE.resolve() == ROOT / "work/asan-c11-target"
        env = os.environ.copy()
        env.pop("CARGO_ENCODED_RUSTFLAGS", None)
        env.update(
            RUSTFLAGS="-Zsanitizer=address",
            ASAN_OPTIONS="detect_leaks=1",
            CARGO_BUILD_JOBS="1",
            CARGO_TARGET_DIR=str(CACHE),
        )
        phases = [
            (
                "architecture-c11-asan",
                1800,
                ["--lib", "--test", "decode_workspace", "--test", "closed_upload_response",
                 "--test", "retry_safety", "--test", "pump_panic"],
                [],
            ),
            ("architecture-c11-asan-inbound-owner", 1200, ["--test", "lifecycle"], ["inbound_owner_"]),
        ]
        executables, artifacts = {}, []
        for name, limit, targets, filters in phases:
            assert source() == state["source_before"]
            assert digest(PINS) == state["pins"]["sha256"], "source pins changed"
            prefix = Q / name
            args = [
                "python3", str(ROOT / "work/record.py"), str(prefix), str(limit),
                "nice", "-n", "10", str(ROOT / "work/run-rust"), "cargo",
                "+" + TOOLCHAIN, "test", "--locked", "-p", "pbrs-grpc", "--all-features",
                *targets, "--target", TARGET, "-Zbuild-std", *filters,
                "--", "--test-threads=4",
            ]
            state["active"] = name
            atomic(STATE, state)
            completed = subprocess.run(args, cwd=CWD, env=env)
            phase_files = [prefix.with_suffix(suffix) for suffix in (".json", ".stdout", ".stderr")]
            record = json.loads(phase_files[0].read_text())
            summaries = [
                {"status": status, "passed": int(passed), "failed": int(failed), "ignored": int(ignored)}
                for status, passed, failed, ignored in re.findall(
                    r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;",
                    phase_files[1].read_text(),
                )
            ]
            check = {
                "name": name, "command": args, "exit_code": record["exit_code"],
                "duration_seconds": record["duration_seconds"], "summaries": summaries,
                "totals": {key: sum(item[key] for item in summaries) for key in ("passed", "failed", "ignored")},
                "source_after": source(), "files": files_snapshot(phase_files),
                "free_bytes_after": shutil.disk_usage(ROOT).free,
            }
            state["checks"].append(check)
            atomic(STATE, state)
            assert completed.returncode == 0 and record["exit_code"] == 0, check
            assert check["source_after"] == state["source_before"], check
            assert record["source"] == {
                "head": pin, "diff_sha256": hashlib.sha256(b"").hexdigest(), "untracked": {}
            }, record["source"]
            assert summaries and all(item["status"] == "ok" for item in summaries), summaries
            assert not record.get("timeout"), record
            if name.endswith("inbound-owner"):
                assert check["totals"] == {"passed": 8, "failed": 0, "ignored": 0}, check
                assert len(summaries) == 1, summaries
            else:
                assert len(summaries) == 5, summaries
                assert all(item["passed"] > 0 for item in summaries), summaries
            for match in re.finditer(r"^\s*Running .*?\(([^()]+)\)\s*$", phase_files[2].read_text(), re.MULTILINE):
                path = Path(match.group(1))
                path = (path if path.is_absolute() else CWD / path).resolve()
                assert path.is_relative_to(CACHE.resolve()), path
                with path.open("rb") as stream:
                    assert stream.read(4) == b"\x7fELF", path
                executables[str(path)] = {"bytes": path.stat().st_size, "sha256": digest(path)}
            artifacts.extend(phase_files)
        expected = {"pbrs_grpc", "decode_workspace", "closed_upload_response", "retry_safety", "pump_panic", "lifecycle"}
        assert len(executables) == 6 and {Path(path).name.rsplit("-", 1)[0] for path in executables} == expected, executables
        state.update(
            executables=executables,
            checks_passed_utc=now(),
            active="cache_reclamation",
            source_before_cleanup=source(),
            artifacts_before_cleanup=files_snapshot(artifacts),
        )
        atomic(STATE, state)
        assert state["source_before_cleanup"] == state["source_before"]
        assert files_snapshot([Path(path) for path in executables]) == executables
        assert CACHE.resolve() == ROOT / "work/asan-c11-target" and not CACHE.is_symlink()
        users_before = cache_users()
        assert not users_before["active_users"], users_before
        assert not users_before["inaccessible_same_uid_proc"], users_before
        files = []
        for path in sorted(CACHE.rglob("*")):
            if path.is_symlink():
                files.append({"path": str(path.relative_to(CACHE)), "symlink": os.readlink(path)})
            elif path.is_file():
                files.append({"path": str(path.relative_to(CACHE)), "bytes": path.stat().st_size, "sha256": digest(path)})
        reclaimed = sum(item.get("bytes", 0) for item in files)
        inventory = Q / "architecture-c11-asan-cache-inventory.json"
        atomic(inventory, {"source": pin, "executables": executables, "cache": str(CACHE), "files": files, "bytes": reclaimed, **users_before})
        users_after = cache_users()
        assert not users_after["active_users"] and not users_after["inaccessible_same_uid_proc"], users_after
        assert files_snapshot([Path(path) for path in executables]) == executables
        assert files_snapshot(artifacts) == state["artifacts_before_cleanup"]
        assert source() == state["source_before"]
        assert digest(PINS) == state["pins"]["sha256"], "source pins changed"
        shutil.rmtree(CACHE)
        assert not CACHE.exists()
        state["cache_reclaimed"] = True
        state.update(source_after_cleanup=source(), artifacts_after_cleanup=files_snapshot(artifacts))
        assert state["source_after_cleanup"] == state["source_before"]
        assert state["artifacts_after_cleanup"] == state["artifacts_before_cleanup"]
        cleanup = {
            "source": pin, "cache": str(CACHE), "cache_reclaimed": True,
            "bytes_reclaimed": reclaimed, "files": len(files), "executables": executables,
            "inventory": {"path": str(inventory), "sha256": digest(inventory)},
            "users_before_inventory": users_before, "users_after_inventory": users_after,
            "source_before_cleanup": state["source_before_cleanup"],
            "source_after_cleanup": state["source_after_cleanup"],
            "artifacts_before_cleanup": state["artifacts_before_cleanup"],
            "artifacts_after_cleanup": state["artifacts_after_cleanup"],
            "completed_utc": now(), "free_bytes": shutil.disk_usage(ROOT).free,
        }
        atomic(Q / "architecture-c11-asan-cache-reclaim.json", cleanup)
        state.update(state="passed", active=None, completed_utc=now(), source_after=source(), cache_reclaimed=True, free_bytes=cleanup["free_bytes"])
        atomic(STATE, state)
        atomic(Q / "architecture-c11-workspace-disk-ready.json", {
            "source": pin, "cache_reclaimed": True, "asan_checks_passed": True,
            "free_bytes": cleanup["free_bytes"], "utc": now(),
            "supervisor_state_sha256": digest(STATE),
        })
    except BaseException as error:
        state.update(state="failed", error=repr(error), completed_utc=now())
        if CWD.exists():
            state["source_after"] = source()
        atomic(STATE, state)
        traceback.print_exc()
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
