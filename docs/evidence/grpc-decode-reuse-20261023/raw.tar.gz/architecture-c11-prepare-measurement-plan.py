import datetime,hashlib,json,subprocess,sys
from pathlib import Path
r=Path('/workspace/pure-protobuf'); q=r/'work/qualification'
pins=json.loads((q/'architecture-c11-source-pins.json').read_text()); pin=pins['candidate_runtime']
assert subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip()==pin
path=q/'architecture-c11-measurement-plan.json'; assert not path.exists()
old=json.loads((q/'architecture-c10-measurement-plan.json').read_text())
command=[part.replace('architecture-c10','architecture-c11').replace(old['command'][old['command'].index('--candidate-commit')+1],pin) for part in old['command']]
expanded=['python3',str(r/'work/architecture-c11/scripts/grpc-counter-campaign.py'),'--source-checkout',str(r/'work/architecture-c11'),'--binary',str(q/'architecture-c11-stable-rpc-build/rpc-bench'),'--build-record',str(q/'architecture-c11-stable-rpc-build/build.json'),'--output',str(q/'architecture-c11-counter-expanded'),'--phase','native','--payloads','1024,65536','--load-levels','1:1,1:16','--repeats','3','--seed','20261023']
files=['architecture-c11-workspace-perf-cells.json','architecture-c11-cpu-cells.json','architecture-c11-counter-ab-driver.py','architecture-c11-ab-summary.py']
record=dict(state='PREPARED_NOT_RUN',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),source_pins=pins,command=command,native_expanded=expanded,captures=568,rpcs=21300,cpu_captures=96,cpu_rpcs=1440,expanded_captures=2400,expanded_rpcs=720000,qualified=False,limits=['Shared host with separate frozen C8 24-hour test active.','Allocation-counts-enabled release diagnostics; no shipping-speed qualification.','Synthetic zero application bytes and four messages per streaming leg.','71 selected native cells: Prost large gzip streams, small identity, native pbrs, TLS load16, and all five 1KiB gzip shapes.','12 selected profiler cells: client, server and tonic control, 1KiB/64KiB gzip upload and bidi.','gzip6, server sendbuffer400KiB, requestqueue16 and accounting unchanged.','Baseline and candidate must validate identical Rust1.99.1 tool metadata.','Expanded candidate matrix is not a new matched-source baseline for every cell.'],hashes={name:hashlib.sha256((q/name).read_bytes()).hexdigest() for name in files})
assert len(json.loads((q/files[0]).read_text()))==71
assert len(json.loads((q/files[1]).read_text()))==12
path.write_text(json.dumps(record,indent=2)+'\n')
print(path)
