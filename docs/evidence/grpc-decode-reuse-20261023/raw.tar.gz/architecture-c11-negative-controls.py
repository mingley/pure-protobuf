#!/usr/bin/env python3
"""Isolated C11 regression controls. Builds require an explicit root grant."""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback


ROOT = Path("/workspace/pure-protobuf")
QUAL = ROOT / "work/qualification"
TREE = ROOT / "work/architecture-c11-negative"
SOURCE_PINS = QUAL / "architecture-c11-source-pins.json"
PIN = None
STATE = QUAL / "architecture-c11-negative-controls-state.json"
FILES = [
    "pbrs-grpc/src/codec/prost.rs",
    "pbrs-grpc/src/wire/frame_reader.rs",
    "pbrs-grpc/src/compression/mod.rs",
]
UNIT = "codec::prost::tests::reusable_decode_preserves_owned_and_shared_field_semantics"
READ_SPANS = "compression::tests::retained_capacity_does_not_expand_read_spans_for_a_modest_message"
TRANSPORT = "decoded_storage_preserves_ownership_validation_and_cleanup"


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def git(*arguments, cwd=TREE):
    return subprocess.check_output(["git", *arguments], cwd=cwd)


def save(state):
    temporary = STATE.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(state, indent=2) + "\n")
    temporary.replace(STATE)


def clean():
    assert Path(git("rev-parse", "--show-toplevel").decode().strip()) == TREE
    assert git("rev-parse", "HEAD").decode().strip() == PIN, "unexpected worktree pin"
    assert not git("status", "--porcelain"), "negative worktree must be fully clean"


def restore():
    subprocess.run(
        ["git", "restore", "--source", PIN, "--worktree", "--", *FILES],
        cwd=TREE,
        check=True,
    )
    clean()


def frozen_snapshot():
    snapshots = {}
    for name in ["architecture-c8", "architecture-c10", "architecture-c11"]:
        tree = ROOT / "work" / name
        snapshots[name] = {
            "head": git("rev-parse", "HEAD", cwd=tree).decode().strip(),
            "status": git("status", "--porcelain", cwd=tree).decode(),
            "diff_sha256": digest(git("diff", "HEAD", "--binary", cwd=tree)),
        }
    return snapshots


def apply_control(name, relative, before, after):
    clean()
    path = TREE / relative
    original = path.read_text()
    assert original.count(before) == 1, f"{name}: source seam must occur exactly once"
    path.write_text(original.replace(before, after, 1))
    patch = git("diff", "HEAD", "--binary")
    assert patch, "control must change source"
    patch_path = QUAL / f"architecture-c11-negative-{name}.patch"
    patch_path.write_bytes(patch)
    return {
        "name": name,
        "source_file": relative,
        "original_sha256": digest(original.encode()),
        "mutated_sha256": digest(path.read_bytes()),
        "patch": str(patch_path),
        "patch_sha256": digest(patch),
        "checks": [],
    }


def check(name, arguments, env, expected, marker=None):
    prefix = QUAL / f"architecture-c11-negative-{name}"
    rust = [str(ROOT / "work/run-rust"), "cargo", "+stable", *arguments]
    command = ["nice", "-n", "15", *rust]
    completed = subprocess.run(
        ["python3", str(ROOT / "work/record.py"), str(prefix), "1200", *command],
        cwd=TREE,
        env=env,
        check=False,
    )
    record = json.loads(prefix.with_suffix(".json").read_text())
    stdout = prefix.with_suffix(".stdout").read_text(errors="replace")
    stderr = prefix.with_suffix(".stderr").read_text(errors="replace")
    output = stdout + "\n" + stderr
    compiled = "Finished `test` profile" in output and "Running " in output
    compiled = compiled and "could not compile" not in output
    result = {
        "name": name,
        "record": str(prefix.with_suffix(".json")),
        "exit_code": record["exit_code"],
        "record_driver_exit_code": completed.returncode,
        "compile_succeeded_and_tests_ran": compiled,
        "expected": expected,
        "test_summaries": re.findall(r"test result: [^\n]+", output),
        "stdout_sha256": digest(stdout.encode()),
        "stderr_sha256": digest(stderr.encode()),
        "source": record["source"],
    }
    if expected == "assertion failure":
        assertion = re.search(marker, output, flags=re.S)
        result["expected_assertion_pattern"] = marker
        result["matched_assertion"] = assertion.group(0) if assertion else None
        result["observed_expected_result"] = bool(
            compiled
            and record["exit_code"] == 101
            and "panicked at" in output
            and "test result: FAILED" in output
            and assertion
        )
    else:
        result["observed_expected_result"] = bool(
            compiled
            and record["exit_code"] == 0
            and output.count("test result: ok.") == 2
            and "test result: FAILED" not in output
        )
    return result


def main():
    global PIN
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--execute",
        action="store_true",
        help="run only after root grants the shared target following its full checks",
    )
    args = parser.parse_args()
    source_pin_bytes = SOURCE_PINS.read_bytes()
    PIN = json.loads(source_pin_bytes)["candidate_runtime"]
    assert isinstance(PIN, str) and re.fullmatch(r"[0-9a-f]{40}", PIN), "invalid runtime pin"
    if not args.execute:
        print(json.dumps({
            "state": "prepared; no build or mutation run",
            "pin": PIN,
            "worktree": str(TREE),
            "negative_checks": 4,
            "final_positive": "all-feature library and isolated transport target",
        }, indent=2))
        return 0

    clean()

    state = {
        "state": "starting",
        "started_utc": utc(),
        "pin": PIN,
        "worktree": str(TREE),
        "driver_sha256": digest(Path(__file__).read_bytes()),
        "source_pins": str(SOURCE_PINS),
        "source_pins_sha256": digest(source_pin_bytes),
        "scope": "regression-test sensitivity; not additional production qualification",
        "frozen_before": frozen_snapshot(),
        "controls": [],
    }
    env = os.environ.copy()
    env.update(CARGO_TARGET_DIR=str(ROOT / "work/stable-target"), CARGO_BUILD_JOBS="1")
    common = ["test", "--locked", "-p", "pbrs-grpc", "--all-features"]
    transport = [*common, "--test", "decode_workspace", "--", "--exact", TRANSPORT, "--nocapture"]
    # The strengthened unit checks recovered allocation capacity before base
    # pointer identity. An empty static Bytes must not pass as a recovered owner.
    owner_marker = (
        r"assertion `left == right` failed: last bytes field returns original storage"
        r"\s+left: 0\s+right: [1-9][0-9]*"
    )
    span_marker = (
        r"a 8193-byte message requested a 1040384-byte read target "
        r"from retained capacity 1048576"
    )
    cache_marker = (
        r"panicked at [^\n]*tests/decode_workspace\.rs:[^\n]*\n"
        r"assertion `left == right` failed\s+left: 0\s+right: 1"
    )
    save(state)
    try:
        owner = apply_control(
            "owner", FILES[0], "T::decode(DecodeCursor(payload))", "T::decode(payload)"
        )
        state["controls"].append(owner)
        state["state"] = "running owner-loss unit and transport controls"
        save(state)
        try:
            owner["checks"].append(check(
                "owner-unit",
                [*common, "--lib", UNIT, "--", "--exact", "--nocapture"],
                env, "assertion failure", owner_marker,
            ))
            save(state)
            owner["checks"].append(check(
                "owner-transport", transport, env, "assertion failure", cache_marker,
            ))
            save(state)
        finally:
            restore()

        initialization = apply_control(
            "initialization", FILES[2],
            "n.max(compressed_length.min(256 * 1024)).min(budget)",
            "n.max(compressed_length.min(256 * 1024)).max(out.capacity()).min(budget)",
        )
        state["controls"].append(initialization)
        state["state"] = "running retained-capacity read-span control"
        save(state)
        try:
            initialization["checks"].append(check(
                "initialization-unit",
                [*common, "--lib", READ_SPANS, "--", "--exact", "--nocapture"],
                env, "assertion failure", span_marker,
            ))
            save(state)
        finally:
            restore()

        retention = apply_control(
            "retention", FILES[1],
            "RetainedDecodeLease::try_acquire(buffer.capacity())",
            "RetainedDecodeLease::try_acquire(0)",
        )
        state["controls"].append(retention)
        state["state"] = "running disabled-retention transport control"
        save(state)
        try:
            retention["checks"].append(check(
                "retention-transport", transport, env, "assertion failure", cache_marker,
            ))
            save(state)
        finally:
            restore()
    except Exception:
        state["infrastructure_error"] = traceback.format_exc()
    finally:
        restore()
        state["restored_clean"] = True
        state["state"] = "running restored original positive checks"
        save(state)
        state["positive"] = check(
            "restored-positive",
            [*common, "--lib", "--test", "decode_workspace", "--", "--nocapture"],
            env, "success",
        )
        state["frozen_after"] = frozen_snapshot()
        state["frozen_unchanged"] = state["frozen_before"] == state["frozen_after"]
        clean()
        checks = [item for control in state["controls"] for item in control["checks"]]
        state["source_patches_verified"] = all(
            item["source"]["head"] == PIN
            and item["source"]["diff_sha256"] == control["patch_sha256"]
            for control in state["controls"] for item in control["checks"]
        )
        state["positive_source_clean"] = (
            state["positive"]["source"]["head"] == PIN
            and state["positive"]["source"]["diff_sha256"] == digest(b"")
        )
        passed = (
            "infrastructure_error" not in state
            and len(checks) == 4
            and all(item["observed_expected_result"] for item in checks)
            and state["positive"]["observed_expected_result"]
            and state["source_patches_verified"]
            and state["positive_source_clean"]
            and state["frozen_unchanged"]
        )
        state.update(state="passed" if passed else "failed", ended_utc=utc())
        save(state)
    print(json.dumps({"state": state["state"], "record": str(STATE)}))
    return 0 if state["state"] == "passed" else 1


if __name__ == "__main__":
    sys.exit(main())
