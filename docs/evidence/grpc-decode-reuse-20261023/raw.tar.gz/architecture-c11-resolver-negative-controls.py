#!/usr/bin/env python3
"""Run isolated resolver fixture sensitivity controls after clean C11 checks.

Preparation is the default. --execute requires the genuine final checks PASS.
Only the dedicated negative checkout is mutated; every completed mutation is
restored before the next control. Failures are retained, never silently retried.
"""
import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c11-negative'
PINS = Q / 'architecture-c11-source-pins.json'
PLAN = Q / 'architecture-c11-resolver-fixture-class-control-plan.json'
STATE = Q / 'architecture-c11-resolver-negative-controls-state.json'
RELATIVE = 'pbrs-grpc/tests/resolver.rs'
CHURN = 'round_robin_churn_removes_and_recovers'
DRAIN = 'removed_address_drains_without_migrating'
EMPTY = hashlib.sha256(b'').hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def load(path):
    return json.loads(Path(path).read_text())


def git(*arguments, cwd=TREE):
    return subprocess.check_output(['git', *arguments], cwd=cwd)


def save(state):
    temporary = STATE.with_suffix('.json.next')
    with temporary.open('w') as out:
        json.dump(state, out, indent=2)
        out.write('\n')
        out.flush()
        os.fsync(out.fileno())
    temporary.replace(STATE)


def snapshot(tree):
    return dict(head=git('rev-parse', 'HEAD', cwd=tree).decode().strip(),
                status=git('status', '--porcelain', '--untracked-files=all', cwd=tree).decode(),
                diff_sha256=digest(git('diff', 'HEAD', '--binary', cwd=tree)))


def frozen_snapshot():
    result = {name: snapshot(ROOT / 'work' / name)
              for name in ['architecture-c8', 'architecture-c10', 'architecture-c11']}
    assert all(value['status'] == '' for value in result.values()), result
    return result


def assert_tree(pin, clean=True):
    assert Path(git('rev-parse', '--show-toplevel').decode().strip()) == TREE
    assert git('rev-parse', 'HEAD').decode().strip() == pin, 'wrong negative checkout pin'
    path = TREE / RELATIVE
    assert not path.is_symlink() and path.is_file()
    changed = git('diff', 'HEAD', '--name-only').decode().splitlines()
    assert set(changed) <= {RELATIVE}, changed
    assert not git('ls-files', '--others', '--exclude-standard'), 'unexpected untracked fixture files'
    if clean:
        assert not git('status', '--porcelain'), 'negative checkout is not clean'


def final_checks(pin):
    path = Q / 'architecture-c11-checks-state.json'
    state = load(path)
    assert state.get('state') == 'passed', 'final C11 checks have not passed'
    assert state.get('source') == dict(head=pin, status=''), state.get('source')
    matches = [entry for entry in state['checks'] if entry['name'] == 'workspace']
    assert len(matches) == 1
    workspace = matches[0]
    assert workspace['exit_code'] == 0 and workspace['totals']['failed'] == 0
    assert workspace['totals']['passed'] > 0 and workspace['targets'] > 0
    terminal = Q / 'architecture-c11-workspace.json'
    record = load(terminal)
    assert record['exit_code'] == 0
    assert record['source'] == dict(head=pin, diff_sha256=EMPTY, untracked={})
    assert '--workspace' in record['command'] and '--all-features' in record['command']
    assert '--no-fail-fast' in record['command'] and '--test-threads=4' in record['command']
    return {str(path): digest(path.read_bytes()), str(terminal): digest(terminal.read_bytes())}


def restore(pin, state):
    assert_tree(pin, clean=False)
    path = TREE / RELATIVE
    allowed = {state['pristine_fixture_sha256']}
    allowed.update(control['mutated_fixture_sha256'] for control in state['controls'])
    assert digest(path.read_bytes()) in allowed, 'unexpected source change: refuse to overwrite it'
    subprocess.run(['git', 'restore', '--source', pin, '--worktree', '--', RELATIVE], cwd=TREE, check=True)
    assert_tree(pin)
    assert digest(path.read_bytes()) == state['pristine_fixture_sha256']
    state['restored_clean'] = True
    state['last_restored_utc'] = utc()
    save(state)


def apply_control(pin, state, name, patch_path, expected_patch_sha256):
    assert_tree(pin)
    patch = patch_path.read_bytes()
    assert digest(patch) == expected_patch_sha256, 'reviewed patch changed'
    subprocess.run(['git', 'apply', '--check', str(patch_path)], cwd=TREE, check=True)
    subprocess.run(['git', 'apply', str(patch_path)], cwd=TREE, check=True)
    assert_tree(pin, clean=False)
    observed = git('diff', 'HEAD', '--binary')
    assert git('diff', 'HEAD', '--name-only').decode().splitlines() == [RELATIVE]
    out = Q / f'architecture-c11-resolver-control-{name}-actual.patch'
    with out.open('xb') as target:
        target.write(observed)
    control = dict(name=name, patch=str(patch_path), reviewed_patch_sha256=expected_patch_sha256,
                   actual_patch=str(out), actual_patch_sha256=digest(observed),
                   mutated_fixture_sha256=digest((TREE / RELATIVE).read_bytes()), checks=[])
    state['controls'].append(control)
    state['restored_clean'] = False
    state['active'] = name
    save(state)
    return control


def check(pin, name, test, expected, source_diff, marker=None, panic=None):
    prefix = Q / f'architecture-c11-resolver-control-{name}'
    for suffix in ['.json', '.stdout', '.stderr']:
        assert not prefix.with_suffix(suffix).exists(), 'retained result exists; no automatic retry'
    command = [str(ROOT / 'work/run-rust'), 'nice', '-n', '15', 'cargo', '+stable', 'test', '--locked',
               '-p', 'pbrs-grpc', '--all-features', '--test', 'resolver']
    if test:
        command += [test, '--', '--exact', '--nocapture', '--test-threads=1']
    else:
        command += ['--', '--test-threads=4']
    environment = dict(os.environ, CARGO_TARGET_DIR=str(ROOT / 'work/stable-target'), CARGO_BUILD_JOBS='1')
    completed = subprocess.run(['python3', str(ROOT / 'work/record.py'), str(prefix), '1200', *command],
                               cwd=TREE, env=environment, check=False)
    record = load(prefix.with_suffix('.json'))
    stdout = prefix.with_suffix('.stdout').read_text(errors='replace')
    stderr = prefix.with_suffix('.stderr').read_text(errors='replace')
    output = stdout + '\n' + stderr
    compiled = ('Finished `test` profile' in output and 'Running tests/resolver.rs' in output
                and 'could not compile' not in output)
    match = re.search(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)
    actual = dict(status=match[1], passed=int(match[2]), failed=int(match[3]), ignored=int(match[4])) if match else None
    source_ok = record['source'] == dict(head=pin, diff_sha256=source_diff, untracked={})
    if expected == 'assertion failure':
        observed = bool(compiled and completed.returncode == record['exit_code'] == 101 and source_ok
                        and actual == dict(status='FAILED', passed=0, failed=1, ignored=0)
                        and re.search(r'^test ' + re.escape(test) + r' \.\.\. FAILED$', output, re.M)
                        and marker in output and re.search(panic, output, re.S))
    else:
        observed = bool(compiled and completed.returncode == record['exit_code'] == 0 and source_ok
                        and actual and actual['status'] == 'ok' and actual['passed'] > 0
                        and actual['failed'] == actual['ignored'] == 0
                        and all(re.search(r'^test ' + re.escape(case) + r' \.\.\. ok$', output, re.M)
                                for case in [CHURN, DRAIN]))
    return dict(name=name, record=str(prefix.with_suffix('.json')), record_sha256=digest(prefix.with_suffix('.json').read_bytes()),
                command=command, exit_code=record['exit_code'], duration_seconds=record['duration_seconds'],
                successful_compilation_and_test_execution=compiled, source_matches_reviewed_control=source_ok,
                source=record['source'], expected=expected, expected_marker=marker, expected_panic_pattern=panic,
                marker_observed=marker in output if marker else None, summary=actual,
                stdout_sha256=digest(prefix.with_suffix('.stdout').read_bytes()),
                stderr_sha256=digest(prefix.with_suffix('.stderr').read_bytes()), observed_expected_result=observed)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument('--execute', action='store_true')
    mode.add_argument('--restore-only', action='store_true', help='manual recovery of this driver\'s journalled mutation; runs no tests')
    parser.add_argument('--plan', action='store_true', help='preparation only; default')
    args = parser.parse_args()
    if not args.execute and not args.restore_only:
        pin = load(PINS).get('candidate_runtime') if PINS.exists() else 'PENDING_C11_PIN'
        print(json.dumps(dict(state='PREPARED_NO_EXECUTION', qualified=False, pin=pin, worktree=str(TREE),
                              driver=str(Path(__file__)), final_gate='architecture-c11-checks-state.json passed including full workspace',
                              negatives=['stale provider: exact churn', 'stale provider: exact drain', 'truncated tail: exact drain'],
                              final_positive='all-feature full resolver target', source_mutation=RELATIVE,
                              state_record=str(STATE), restores='after every mutation, including normal errors; explicit --restore-only for hard interruption'), indent=2))
        return 0
    pins = PINS.read_bytes()
    pin = json.loads(pins)['candidate_runtime']
    assert re.fullmatch(r'[0-9a-f]{40}', pin), pin
    with (Q / 'architecture-c11-resolver-negative-controls.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        if args.restore_only:
            state = load(STATE)
            assert state['pin'] == pin
            restore(pin, state)
            return 0
        assert not STATE.exists(), 'retained driver evidence exists; no automatic retry'
        gates = final_checks(pin)
        plan = load(PLAN)
        assert_tree(pin)
        pristine = (TREE / RELATIVE).read_bytes()
        assert digest(pristine) == plan['fixture_sha256'], 'final C11 fixture differs from reviewed controls'
        state = dict(state='running', passed=False, qualified=False, pin=pin, started_utc=utc(),
                     driver_sha256=digest(Path(__file__).read_bytes()), source_pins_sha256=digest(pins),
                     control_plan_sha256=digest(PLAN.read_bytes()), checks_gate_hashes=gates,
                     worktree=str(TREE), pristine_fixture_sha256=digest(pristine), frozen_before=frozen_snapshot(),
                     controls=[], restored_clean=True, scope='Fixture regression sensitivity; not additional production qualification')
        save(state)
        failure = None
        try:
            stale = plan['negative_controls'][0]
            control = apply_control(pin, state, 'stale-provider', Path(stale['patch']), stale['patch_sha256'])
            try:
                for name, test, panic in [('stale-churn', CHURN, r'panicked at[^\n]*resolver\.rs:[^\n]*\nA removed from rotation'),
                                          ('stale-drain', DRAIN, r'panicked at[^\n]*resolver\.rs:[^\n]*\npolicy never moved off A')]:
                    result = check(pin, name, test, 'assertion failure', control['actual_patch_sha256'],
                                   'NEGATIVE CONTROL: B-only requested; holding original A,B', panic)
                    control['checks'].append(result)
                    save(state)
                    assert result['observed_expected_result'], 'expected negative assertion not reached: ' + name
            finally:
                restore(pin, state)
            tail = plan['negative_controls'][1]
            control = apply_control(pin, state, 'truncated-tail', Path(tail['patch']), tail['patch_sha256'])
            try:
                result = check(pin, 'truncated-tail', DRAIN, 'assertion failure', control['actual_patch_sha256'],
                               'NEGATIVE CONTROL: second item released after handoff; truncate A response',
                               r'panicked at[^\n]*resolver\.rs:[^\n]*\nsome(?:\n|$)')
                control['checks'].append(result)
                save(state)
                assert result['observed_expected_result'], 'truncated-tail assertion not reached'
            finally:
                restore(pin, state)
            state['active'] = 'restored full resolver positive'
            save(state)
            state['positive'] = check(pin, 'positive-full-resolver', None, 'pass', EMPTY)
            save(state)
            assert state['positive']['observed_expected_result'], 'restored full resolver suite did not pass'
        except BaseException as error:
            failure = error
            state['error'] = dict(type=type(error).__name__, message=str(error), traceback=traceback.format_exc())
        finally:
            try:
                restore(pin, state)
            except BaseException as error:
                state['restore_error'] = dict(type=type(error).__name__, message=str(error))
                failure = failure or error
            state['frozen_after'] = frozen_snapshot()
            state['frozen_unchanged'] = state['frozen_before'] == state['frozen_after']
            state['source_pins_unchanged'] = digest(PINS.read_bytes()) == state['source_pins_sha256']
            state['passed'] = bool(failure is None and state['restored_clean'] and state['frozen_unchanged']
                                   and state['source_pins_unchanged'] and state.get('positive', {}).get('observed_expected_result'))
            state.update(state='passed' if state['passed'] else 'failed', completed_utc=utc(), active=None)
            save(state)
        print(json.dumps({key: state[key] for key in ['state', 'passed', 'qualified', 'pin', 'restored_clean', 'frozen_unchanged']}))
        return 0 if state['passed'] else 1


if __name__ == '__main__':
    sys.exit(main())
