# C10 documentation draft

Superseded planning draft: C10's pipeline stopped before any measurements. Its
full workspace later failed with 3,766 passes, two failures and nine ignores.
Use `architecture-c11-docs-draft.md` for the current plan; no C10 gains exist.

Qualification-only draft. Tracked files remain frozen. No build, capture or
qualification result is asserted here; fill results only from terminal records.

Candidate: `a675b61fe2775e336f33474c58342764cea814a8`.
Before: `9d6fb9c416fc32732450fd78d32ee16ff8b802de`.
Upcoming capsule: `docs/evidence/grpc-decode-reuse-20261023/`.
Future counter summary: `work/qualification/architecture-c10-counter-ab-summary.json`.

The intended matched candidate build is
`work/qualification/architecture-c10-stable-rpc-build` with Rust 1.99. The initial
`architecture-c10-rpc-build` selected Rust 1.88 and was rejected before comparison;
preserve that record. Do not combine its binary or toolchain attribution with
the corrected campaign. `architecture-c10-pipeline-v2-state.json` currently waits
for checks and the corrected release build; no success is inferred from launch.

## Benchmark page update

Put the latest verified C10 finding first, followed by remaining measured losses.
Keep the page near 100–110 lines. Do not present a placeholder improvement as a
finding, and do not copy C8's tonic column into a C10 comparison.

Suggested introduction, before capture results:

> A candidate reuses decoded stream buffers when ownership permits. Its matched
> allocation campaign is pending. The existing tables measure `9d6fb9c4`; they
> do not measure this candidate. Production readiness and a broad speed advantage
> over tonic/prost remain unproved.

Suggested introduction, after actual results are available:

> [Concrete measured change in a named workload.] [Largest remaining measured
> loss or regression.] These are native allocation diagnostics; current CPU,
> latency, throughput and production qualification remain separate.

Use two compact tables. Populate only complete exact-scope rows from the final
summary; use one decimal for allocations, KiB/MiB for requested bytes and signed
percentages. Identify endpoint, codec, payload, compression and load. Prefer equal
prost handlers for a transport/API comparison; pbrs handlers add interop work.

| Side and workload | Metric | C8 before | C10 candidate | Change |
|---|---|---:|---:|---:|
| [Worst changed prost gzip stream] | [Allocations or KiB/RPC] | [actual] | [actual] | [actual] |
| [Other receiving endpoint] | [same metric] | [actual] | [actual] | [actual] |
| [Largest actual source regression] | [metric] | [actual] | [actual] | [actual] |

| Side and workload | Metric | C10 candidate | Fresh tonic control | Difference |
|---|---|---:|---:|---:|
| [Largest remaining measured gap] | [metric] | [actual] | [actual] | [actual] |
| [Important identity/retaining-codec control] | [metric] | [actual] | [actual] | [actual] |

Before publishing either table:

- Confirm capture completeness, RPC accounting and retained failures. Report
  unchanged and regressing cases alongside wins; do not filter by favorable sign.
- State which percentages are ratios of medians and which are paired ratios.
- Do not infer causation for every counter change from the intended mechanism.
- Separate cumulative allocation requests from idle retained capacity and RSS.
- Keep the C8 instrumented server-instruction table explicitly pinned to C8, or
  replace it with a historical link. It is not C10 CPU evidence. There is no new
  native-client instruction result.

The planned scope is **46 workload scopes, 368 captures and 13,800 RPCs** if all
captures complete: two balanced ABBA repeats, N=25/50, two revisions. These are
planned counts, not passing results. Confirm the final cells in the summary.
Shared host, same harness, gzip level 6, zero-filled payloads and four messages
on each streaming leg. Server send buffers remain 400 KiB and request queues 16;
native accounting/channelz remain enabled. Add actual source/toolchain records.

The C8 day runs against `9d6fb9c4`. Its active state is not a C10 soak or a
qualification of changed production code. Keep its source and terminal result
separate, whatever happens during this campaign.

## Evidence README draft

Suggested title: **Bounded decoded-buffer reuse**.

Proposed opening:

> Candidate `a675b61f` reuses a compressed stream's decoded allocation only after
> its codec fully consumes the input and the allocation remains uniquely owned.
> The prost adapter uses a cursor that permits that recovery. Retained `Bytes`,
> lazy pbrs messages and other shared input keep their ownership; they are never
> overwritten to obtain reuse. This changes idle retention as well as allocation
> requests, so those costs require separate evidence.

### What is bounded

The private policy retains at most **4 MiB per stream buffer** and **16 MiB across
the process**, charged by full allocation capacity, not used length. Retention
is optional: a full cache or oversize allocation declines reuse without failing
an otherwise valid RPC. The policy does not preallocate 16 MiB.

The idle lease releases when the buffer becomes active decoder output. Message
and decompression limits then govern that active output; reacquiring a retention
lease uses the resulting actual capacity. Active decoding, compressor scratch,
application-owned messages and process RSS are outside this idle budget.

Reuse clears length but preserves unique allocation capacity. Validation,
aggregate output, compression member/frame count, checksums and Zstd history
limits stay in force. Errors discard retained workspace. Observed terminal
states, cancellation/deadline observation and stream destruction release idle
workspace even if a terminal response handle stays alive. An idle stream that
has not observed a peer terminal can retain its bounded workspace until further
polling or destruction; do not describe this as an asynchronous global eviction.

### Validation ledger — fill actual terminal records

| Check | Source | Result |
|---|---|---|
| Full workspace and required strict checks | [actual C10 qualification source] | Pending |
| Sanitizer and minimum Rust versions | [actual source and profile] | Pending |
| Ownership, retention-budget and terminal cleanup tests | [actual source] | Pending |
| Matched allocation captures | C8 `9d6fb9c4` / C10 `a675b61f` | Pending |
| C10 actual sustained resource test | [none yet] | Not established |

Do not transfer C8 sanitizer/workspace passes to C10. Preserve initial failed
checks, fixture fixes and negative controls with their actual source snapshots.
For ownership tests, distinguish reuse witnessed through counters/pointers from
simple successful round trips. Budget tests must cover process saturation,
oversize-capacity rejection and terminal handles retained by the application.
Every deliberate runtime mutation must be restored before qualifying the source.

### Counter results — fill after captures

Read `architecture-c10-counter-ab-summary.json`, retain all cells and raw captures,
and report exact offered/dispatched/completed/successful RPCs. Include failures,
timeouts, overflow, unstarted and unfinished calls. A nonempty missing/failure
list blocks a complete campaign claim. Preserve both source and fresh tonic
controls, repeat ranges and actual counter availability.

This is a native allocation/requested-byte campaign. Raw context switches or
coarse CPU ticks, if retained, are scheduling diagnostics. No instruction,
shipping CPU, native-client CPU, latency or throughput claim follows. Synthetic
four-message streams do not establish all long-lived stream behavior. A lower
allocation count may exchange allocation work for bounded idle memory.

Link the complete raw summary and source/build manifests. Keep C8's earlier
matrix, profiler and day records as historical sources; do not merge their
numerical baselines or qualification scope into C10.

## Next architecture experiments

1. **Encode workspace.** Attribute plaintext serialization/frame scratch separately
   from compressed-output reservation. Compare an owned per-stream workspace
   with current output handling under a finite process/per-stream retention budget.
   Preserve frame rollback, terminal flush, reset and byte-permit ownership.
2. **Compressed reservations.** Measure how requested capacity, bytes actually
   written and pending encoded tails differ. Reduce excess reservation only with
   checked growth and existing exact-cap/overflow behavior; never trust remote
   metadata as an unrestricted allocation hint. Do not simply raise retention caps.
3. **Owned read-all decode.** Experiment with one checked merge for singular nested
   fields into the existing representation. Repeated Query children already parse
   eagerly. Preserve parse-time validation, unknown fields, recursion, duplicate
   merge and oneof semantics; compare independent prost equality plus sparse and
   read-all work, allocations, instructions and retention.
4. **Task isolation.** Compare inline scheduling with one owned Tokio task per
   finitely admitted RPC. Measure expensive/cheap work on the same connection and
   small-call handoff cost. Preserve reset, deadlines, drop-abort and drain. Idle
   streams must not occupy CPU-worker threads; decoder-only offload needs separate
   finite workers/queue, owned buffer permits and cancellation checks.

These are experiments with explicit costs and invariants, not promised wins or
a claim that one local change will make the entire stack production ready.

## Eventual TODO.md update after the edit grant

Keep C10's implemented capability separate from its actual validation state:

> C10 adds bounded idle decoded storage for uniquely recoverable prost input.
> Retained `Bytes` and lazy pbrs messages keep their ownership. Idle capacity is
> limited to 4 MiB per stream buffer and 16 MiB process-wide; active decode and
> application memory remain separate. [Actual validation/counter result here.]
> C8's active day still tests `9d6fb9c4` and does not qualify C10.

The next priorities should distinguish these costs:

| Work | Next result | Preserve |
|---|---|---|
| Plaintext encode/frame scratch | Attribute bytes copied, temporary storage and allocation lifetimes before proposing reuse. | Encoded-size limits, rollback and caller-owned buffers; no unbounded idle cache. |
| Compressed-output reservation | Compare reserved capacity with actual compressed bytes and pending encoded tails. | Exact-cap/overflow behavior, finite retained capacity, checksum/framing and byte permits. |
| Owned read-all decode | Test checked eager singular merge against the existing lazy path. | Parse-time rejection, sparse access, unknown fields, duplicate merge, oneof semantics, recursion and retention. |
| Handler isolation and deadline admission | Compare an independently owned per-RPC task policy with inline execution under explicit finite global admission. | Transport progress, small-RPC progress, absolute deadlines through handoff, actual cleanup and normal producer lifetimes. |
| Complete C10 qualification | Finish source-pinned speed, interop, platform/release and actual sustained resource checks. | No inherited C8 day or CPU claim; retain measured losses and failed attempts. |

### Handler-isolation deadline hazard: source-reviewed, not yet tested

Use `architecture-c10-handler-isolation-review.md` as the source review, not a
passing control. At `server/connection.rs:719`, the inline future owns the RPC
permit and begins dispatch when polled; `server/dispatch.rs:161` also invokes
synchronous hooks/future construction. Moving only the returned future would
leave that application work on the transport owner.

Queue residence must count against the request's deadline. `Rpc::deadline()` at
`server/rpc.rs:353` computes `now() + duration`, while preparation at line1372
stamps its deadline. A new queue/handoff must carry admission time and an
absolute expiry rather than grant a fresh full timeout after waiting. Interceptor
caps may tighten that expiry. Require an independent queued-deadline control.

The review also identifies limits on the proposed isolation: a separate driver
per connection can isolate protocol progress but not a small RPC from a heavy
sibling sharing that driver. Per-RPC tasks need runnable worker capacity; a
current-thread/per-core runtime gains no thread merely by spawning. A timer or
abort cannot preempt a currently executing poll. Keep permits, buffers and busy
leases owned until actual cleanup, rather than admitting replacements while
cancelled work is still executing. A task owner must abort/drain explicitly;
dropping a `JoinHandle` detaches the task. Controls proposed by the review remain
NOT RUN and do not establish a compliance failure or a performance result.
