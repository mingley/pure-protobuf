# Next identity bidi allocation investigation

Reviewed source: C11 `beb4ecd9a9b2143c440892607d5b486318062b61`.
This is a read-only source/design review. No measurements, builds, profiles, tests or production changes were made. C11 qualification and captures stay separate from the future option below.

## What the existing numbers establish

C8's three-repeat full matrix,1KiB identity bidi, h2c, one connection/one in-flight call, reports:

| Endpoint, Prost | Native requested bytes/RPC | Tonic requested bytes/RPC | Ratio |
| --- | ---: | ---: | ---: |
| Client | 55,189.45 | 40,366.425 | 1.3672 |
| Server | 44,505.48 | 33,740.15 | 1.3191 |

Source: `architecture-c8-counter-expanded-all-counters.json`. These are **C8** results, not fresh measurements of C11's receive-workspace changes. They show cumulative allocation requests, not wire bytes, retained memory or RSS. Counts include reallocations at their entire new requested size (`bench/devloop/compression/src/allocator.rs:29`). They include the benchmark/application/runtime around the transport. Native's lower allocation count does not imply fewer requested bytes: fewer, larger requests can produce this exact combination.

Both endpoint totals are process-lifetime counters. The ledger uses `(counter(2N)-counter(N))/N`, rejecting nonpositive deltas (`scripts/dominance-ledger.py`). A truly constant per-connection startup allocation should mostly cancel. Capacity stair steps, asynchronous cleanup, additional dials, histogram/report sizing and other N-dependent work may not cancel. No call-site allocation profiler was used to establish the byte gap.

## Source facts and hypotheses

**Certain from source: the first small outbound frame reserves space for four frames.** `wire/encode.rs:389` computes `need =5+encoded_len`, then for an empty sink with `need<=8192` requests `4*need`. This is used by streaming `OutBatch`, not unary's exact-sized encoder. `wire/out_batch.rs:91` transfers the finished sink to HTTP/2 and replaces it with a new empty sink. A following flush therefore starts a fresh allocation rather than reusing that output buffer prematurely.

**Strong execution-path inference, not measured site attribution:** the matched Prost bidi client (`rpc-bench/src/native_prost.rs:208`) sends one request and waits for its reply before sending the next. There is only one intentional request ready at each ping-pong turn. The matching Prost server emits one reply per requested response parameter (`native_prost.rs:319`; tonic Prost implementation `main.rs:1271`). Four-frame initial headroom can therefore be wasted on each one-message flush. Conditional source arithmetic for four separate frames of sizeF is16F requested initially versus4F with exact known-single reservation: a potential12F difference, of the same order as this gap. That is not a measured share of the gap or a prediction of the final native/Tonic difference. Tonic's own allocation/reuse strategy also matters.

**Certain from source: scratch vectors eagerly reserve64 elements per outgoing RPC.** Client `client/streaming.rs:374`, generic `wire/send.rs:364`, and server `server/drain.rs:918` create `items` with capacity `OutBatch::BURST=64`. Budgeted client and server paths additionally reserve64 `BytePermit`s. These requests are `64*sizeof(item)` and `64*sizeof(BytePermit)`, even when the next drain receives one item. Their exact type layouts and allocated-site contribution have not been measured here. BytePermit itself has an optional Arc-backed tracker plus a byte count (`limits.rs:317`); acquiring a permit does not allocate a separate tracker for every message.

**Certain workload distinction:** matching request-queue capacity16 does not make all storage equal. Native queues carry `Result<Framed<T>,Status>`; tonic's client request queue carriesT. Both use Tokio MPSC, which allocates its own queue blocks. The response application queues are8 on both matched Prost servers. Exact queue-block layouts and task/future sizes are unknown without layout/allocator evidence. Native Status keeps optional detail behind a box (`status.rs:343`), so attributing a large inline error object to every item would be unjustified.

**Certain additional per-RPC ownership:** a live native bidi upload has a boxed call future, cancellation state, a spawned upload owner and three oneshot channels (`client/streaming.rs:1085`), plus `items`, permits and framing state. Received messages are read directly from a boxed WireStream, not through an extra receive pump (`stream.rs:64`). The server owns an FU node, method future, inbound/prepared state, response write state and an application producer task. Those owners protect early responses, cancellation, panic/reset and stream completion; deleting them to reduce counters is not a valid experiment. Tonic/Hyper also allocate per-RPC state and execute the same application producer task, so this inventory is not an incremental byte attribution.

**Current C11 receive behavior needs new evidence:** `wire/frame_reader.rs:413` creates decoded workspace storage only after a codec returns reusable backing. `codec/prost.rs:103` now preserves ownership through `DecodeCursor`; original C8 counters predate that change. For owned Prost Vec fields, copying and buffer recovery have different lifetimes from shared Bytes fields. Do not assume all receive copies disappeared or charge compressed scratch to identity: `EncodeScratch` starts empty and is populated only on the compressed branch.

**Lower-priority explanation: connection defaults.** Native's HTTP/2 framed writer starts with16KiB (`h2_backend/codec/framed_write.rs:70`), as does the locked upstream h2 writer used by tonic. The benchmark matches stream/connection windows, max frame size, header cap and adaptive-window mode (`rpc-bench/src/process.rs:2595`), and native server send-buffer limit is400KiB to match locked Hyper's default (`main.rs:325`). A16MiB flow-control window is credit, not an eager16MiB allocation. A400KiB send-buffer cap is not an unconditional400KiB allocation per RPC. These limits can affect batching/copy behavior, but their numerical values cannot be added to explain a small-RPC requested-byte slope. Both implementations' actual per-stream allocations, header tables and arena reuse still need evidence.

## Count-aware first-reserve option: prepared, not applied

Patch: `architecture-c11-identity-count-aware-reserve-option.patch`.
Metadata: `architecture-c11-identity-count-aware-reserve-option.json`.
The patch applies cleanly under a read-only `git apply --check` against frozen C11. It has **not** been compiled, applied, tested or measured.

Use the already collected message count after `recv_many` and any existing `try_recv_many`. Iterate linearly with an index, passing the remaining collected count to `OutBatch::encode_ready`. On an empty uncompressed small-message sink:

- A known single ready message reserves one frame.
- Any known burst of two or more retains the existing four-frame prefetch.

A known four-message burst therefore keeps the old growth avoidance. Retaining the old reserve for two/three messages is deliberate: with mixed sizesF,F,2F, reserving3F can trigger a growth request where the old4F buffer fits. The earlier1..4clamped proposal is retained as `...-clamped-v1.patch` history; the final option avoids that additional intermediate-burst tradeoff. Count0 is treated as a conservative single frame, although the nonempty loop cannot normally supply it. Large messages and compression use their existing branches.

| Caller | Known count and hint lifetime |
| --- | --- |
| Client `pump_outbound_budget` | Read `items.len()` after catch-up, pass remaining count on each iteration. |
| Generic `wire::send::pump_outbound` | Same; do not omit the non-budget helper. |
| Server `drain_to_wire` | Same, after codec negotiation/catch-up and before consuming the items. |
| Closed `write_closed_upload` | Use the already owned vector length and a consuming iterator. After `take_frame`, remaining-count hint describes the next new sink. |

No producer wait, additional message scan or additional `encoded_len()` pass is introduced. Existing budget computation and encoder length computation remain as they were. Recomputing remaining count also handles a32KiB flush in the middle of a collected burst. No sticky batch-policy field is added.

The scalar hint changes reservation only. It does not alter message limits, wire bytes, order, permit ownership, cancellation or error precedence. It adds no new rollback state. Existing `SinkCheckpoint` rollback must continue to preserve completed prefixes and original shared head data after partial encoding. An error later in a collected vector may cause conservative over-reservation, but no more than the old four-frame policy. This draft retains test-only default-four wrappers as compatibility scaffolding. **An eventual implementation must update existing tests to the new API with actual ready counts and remove those shortcuts**, so golden/error coverage and capacity controls exercise the intended policy directly.

Before promoting a candidate, validate single/four-frame capacity and byte identity; mixed sizes and8KiB/32KiB boundaries; partial first-frame failures; completed/shared prefixes followed by errors; compressed failures; empty/huge hints; blocked sends, reset and cancellation. No claim about fewer allocation calls, CPU, wakeups or latency follows from the source arithmetic alone.

## Tune vector initial capacity separately

Do not combine an eager-vector change with the first-reserve option: it would obscure the first causal result. Also do not replace64 with the benchmark's16 everywhere. Applications can use queue capacities1,4,16,64or256, and the existing catch-up turn may gather more than one queueful. A wire-backed source's `recv_many` contributes one item at a time (`stream.rs:462`); a channel-backed source has a real maximum capacity that can supply a separate initial hint.

A later option could initialize `items` from a capped actual source-capacity hint and initialize the permit vector from the count already collected. Continue receiving up to the existing64-item bound, allow ordinary growth, retain backpressure and all byte charges. Record both growth reallocations and requested bytes: starting too small can increase cumulative requests for bulk streams. Test independent producer/consumer scheduling and varied queue sizes. Keeping one merged permit could avoid a vector but changes token accounting; that is a separate design decision, not part of this hint experiment.

## Smallest useful attribution experiment, not run

1. First, in an isolated new source, exercise one-message flush repeated four times versus a known four-message batch through the real count-aware encoder, with the forwarding allocator armed only around that operation. Record actual requested bytes, allocation/reallocation counts, encoded output, requested/logical capacities and errors. This validates the reservation mechanism without a network or unrelated task allocations. Use a contiguous Prost message and keep validation/rollback enabled. This is a proposed control, not an executed measurement.
2. Then compare unchanged C11 with only the first-reserve option for1KiB identity bidi/four pairs/h2c1:1. Two native-Prost endpoint directions plus a fresh tonic/Prost reference, two N/2N counts and two balanced source repeats require24 captures. Retain every actual completion/status/drop count and per-side metric. Use existing defaults and deadlines. This is a small diagnostic, not a replacement for bulk/mixed-size/production qualification.
3. If requested-byte slopes change as expected but a material gap remains, attribute the remaining allocation-size buckets/call stacks before selecting the next owner/task/queue change. Preserve tonic's8KiB encode/decode defaults (`tonic0.14.6/src/codec/mod.rs:26`), its actual buffer splitting/reuse and native's live-task ownership in the comparison. Measure CPU/tail latency/wakeups and peak memory separately; requested-byte reduction alone proves none of them.

The proposed option must receive a new source pin and qualification after the running C11 campaign. No C11 source or accepted measurement is changed by this review.
