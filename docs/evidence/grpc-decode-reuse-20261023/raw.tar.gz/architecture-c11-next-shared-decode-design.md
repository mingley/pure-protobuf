# A bounded pending owner for shared decoded input

Read-only design review against C11 source at
`beb4ecd9a9b2143c440892607d5b486318062b61`; hashes below pin reviewed files.
No tracked source changes, builds, tests or measurements were performed.
This is a possible later experiment, not a change to C11 or a performance result.

## Assessment

Yes: one stream-local immutable Bytes owner can keep a validated decoded allocation
available until a later frame, then recover it **only after every application and
transport alias disappears**. Charge its original Vec capacity while that owner
is retained, whether or not the allocation is currently unique. A miss must decode
normally, without waiting for the application, copying retained input or changing
message semantics.

This can recover storage for lazy pbrs consumers that drop previous input before
reading more. It cannot force reuse when an application collects messages, keeps a
field Bytes, forwards shared input to a response, or leaves an earlier message alive
while awaiting its successor. Those ownership patterns are valid. The optimization
must preserve them, and some will pay extra ownership overhead with no reuse.
The stream-owned encode proposal can proceed independently; do not bundle this
shared-input experiment into C11 qualification.

## Current source facts

- C11's CodecMessage default moves Bytes into decode_payload. Its pbrs blanket
  implementation calls Parse::parse_bytes; the transport then owns no original
  handle to reclaim. This is intentional and avoids a keeper clone today.
- The Prost adapter overrides the reusable hook with a Buf cursor. Owned fields
  can release temporary input references before return, allowing immediate unique
  recovery; retained Bytes fields prevent it. That existing owned path should
  remain separate and unchanged in the first shared-input experiment.
- Parse::parse_bytes invokes ClearAndParse::merge_from_bytes_shared. Generated
  support creates Wire::from_bytes and windows the same immutable backing for
  suitable fields. LazyBytes uses a 4 KiB sharing threshold for shared parents;
  smaller bytes fields copy out. Nested LazyMsg can retain a wire span as well.
- LazyMsg::as_deref materializes a nested message but keeps inner.wire. Therefore
  merely reading every getter does **not** establish that input backing was
  released. An owned accessor or mutation may change ownership, but only an
  actual uniqueness check can decide whether all aliases disappeared.
- Large shared fields can escape through LazyBytes::as_shared / Wire::as_bytes,
  message clones, nested clones, outbound SegSink segments and HTTP/2 queues.
  Dropping the original request alone does not prove unique ownership.
- Wire-backed Streaming::recv_many currently returns one frame and
  try_recv_many returns zero. Application collect/containers/combinators can
  nevertheless retain arbitrarily many earlier messages. Do not attribute a
  multi-item retained batch to that wire recv_many implementation.

## Preserve identity through an explicit opt-in

Do not clone input for every CodecMessage. Default/custom codecs, uncompressed
frames and the C11 cold <=8 KiB path must retain their current behavior. An
illustrative source-compatible seam is a new default-false capability on
CodecMessage indicating that a framework-owned pending input keeper is useful.
The pbrs blanket adapter opts in; other codecs remain out unless explicitly
reviewed. The name/API needs a later review, not an edit in this note.

For an opted-in eligible compressed frame:

1. Finish complete bounded decompression exactly as C11 does. Before converting
   Vec to Bytes, record its **actual capacity** C and its original base pointer
   for controls. Do not derive C from payload length, gzip ISIZE, a zstd field,
   compressed length or an application estimate.
2. If an older pending owner still occupies the slot, do not create a keeper for
   this message. Decode the new output through the current ordinary move path.
3. Otherwise admit C under a finite per-stream and process ledger **before**
   cloning. If admission fails or C is oversized, use the ordinary move path;
   there is no extra keeper clone, Box or RPC error from this policy miss.
4. Convert output to Bytes, clone one framework-owned keeper, and advance only
   that keeper through the original decoded length so its visible length is zero.
   Pass the other original Bytes to the same ordinary decode_payload used today.
5. On decode error, drop the keeper before releasing its charge; retain no cache
   entry. On success, try immediate recovery. If it is already unique, store a
   ready Vec. If it is shared, keep the immutable empty cursor and its lease.

The framework, rather than a mutable codec callback, should own this keeper.
Its allocation identity and original capacity then remain tied to the Vec the
transport allocated, even if a custom opt-in decoder consumes/replaces/splits its
input or retains references elsewhere. No decoded message is ever asked to give
back bytes it owns.

An alternative is a pbrs override of decode_payload_reusable that clones its input
and leaves an exhausted original cursor. It has the same essential extra reference
cost, but it needs a separate policy/capability to avoid cloning after budget
admission fails, and the transport must distinguish a genuine preserved owner from
the default hook's static empty cursor. Relying on arbitrary mutable hooks to
preserve identity complicates capacity accounting. An explicit framework keeper
plus opt-in capability is the cleaner first prototype; keep the default move-only
hook and current Prost cursor behavior intact.

The pbrs call is still Parse::parse_bytes on the same bytes. Do not substitute the
copying Parse::parse path, eagerly materialize fields, detach LazyBytes or alter
lazy validation to make ownership easier. Such changes would be separate codec
experiments with their own semantics and copy costs.

## One slot, no retired-input queue

An internal boxed state can hold either ready Vec storage or one pending owner:

```text
Empty
  -> Pending(original empty Bytes owner, original capacity lease)
  -> Ready(Vec with recovered base/capacity, same capacity lease)
  -> Active decode output (release idle/pending lease as C11 does)
  -> Pending / Ready / Empty
```

Use one enum rather than simultaneously accumulating a ready Vec and a list of
retired owners. Keep allocation fields before lease fields, including in error
paths, so dropping the framework owner precedes releasing its reservation.
WireStream can retain one optional Box pointer as in C11; the Box becomes larger
for the pending variant but no new field or heap allocation is needed on cold
uncompressed streams. Measure actual record/future sizes, not an assumed layout.

At a later eligible compressed frame, take the pending Bytes by value and call
try_into_mut. If it succeeds, convert the empty BytesMut to Vec, validate the
recovered capacity, and use that exclusively owned allocation for decompression.
The locked bytes1.12.1 implementation reconstructs the full original Vec backing;
its BytesMut-to-Vec conversion copies visible length bytes. The preserved cursor
has length zero, so that operation requests a zero-byte copy even though the
pointer advanced to the old end. Existing C11 pointer/full-capacity controls prove
this mechanism for an exact-size and a spare-capacity Vec; extend them across the
new delayed state. No local unsafe set_len or raw pointer reconstruction is needed.

Do not recover from a sliced child field: hold the original framework cursor over
the full decoded buffer. If recovered capacity differs from the recorded charge,
reconcile it before retaining Ready state, or discard and fall back. Never cache
through a conversion that silently copies a still-shared view. Actual capacity
must drive every later Ready reservation, including after growth and smaller
message allowances.

A shared miss is not EOF and must not stall the RPC. The best initial bounded
policy is to **keep the existing pending owner on a miss**, decode the current
message normally, and create no new keeper for that current message. Retry once
when another eligible frame is actually ready, rather than on every spurious
poll while waiting for DATA. This keeps one owner/lease and avoids per-message
clone/admission churn when an application retains old input.

That policy also handles one-item-late release. In:

```text
next = await message()
old = next              # old backing drops only after next was decoded
```

replacing the pending owner with the newest input on every miss can fail forever.
Keeping the older owner lets it become unique after the later delivery, so a
subsequent frame may reuse it. A permanently held first message can instead occupy
the slot for the stream's lifetime. There is no universal best replacement policy;
measure bounded keep-old against drop-and-replace on real lifetime patterns before
adding hit-rate/age heuristics.

For mixed identity/compressed streams, the simplest prototype retries only before
another compressed frame, preserving the cold identity fast path. It may keep a
pending owner across identity frames; EOF/error/cancel still releases it. If a
later design retries on every frame instead, state and measure that extra branch.
Neither policy may delay delivery of an identity frame.

## Budget definition and cleanup

C11 currently calls its counter idle, uniquely owned decoded scratch. A pending
owner is different: it can share physical backing with a live application value
or an in-flight shared response. Its reservation must remain charged throughout
that pending interval. Rename/document the counter as stream-retained decoded
backing capacity, or introduce an explicit pending class under the same finite
ledger. Do not silently describe a pending shared owner as unique idle scratch.

A candidate can reuse the present 4 MiB per-stream and 16 MiB process limits across
the union of Ready and Pending states. Capacity is charged once per original
transport allocation, not once per Bytes reference. Holding app aliases does not
waive the charge. An unavailable budget declines the extra framework owner; it
does not reject the message, wait for another RPC or borrow the active-RPC byte
quota. C11's decoded-byte, compression-frame/window and complete-input policies
remain independent and unchanged.

Shared pending owners can also occupy the ledger while immediate owned-Prost
recovery elsewhere would have reused it. A long-held pbrs message could therefore
reduce another stream's cache hit rate without changing either RPC's correctness.
Do not promise fairness. Compare a separate finite pending sub-limit or conservative
pending admission policy if mixed-codec contention shows this cost; keep the total
capacity allowance explicit and do not add a second unreported full-size budget.
Additional class counters/admission steps introduce their own atomics and rollback
requirements, so do not choose their size from a single zero-filled workload.

If the current active-decode protocol is retained, release the lease only after
unique recovery has transferred storage into active decode, then admit the output
again before making a new keeper. A separate experiment could keep a stable
reservation across active reuse, but that changes budget semantics and contention
tradeoffs and should not be bundled into the first pending-owner change.

Clear both Pending and Ready state on protobuf/decompression/framing/transport
error, DATA EOF before trailer wait, terminal status, observed local cancellation,
deadline and Drop. An independent cancellation handle cannot synchronously mutate
an otherwise unpolled reader; retained capacity remains charged until cancellation
is observed or the reader is dropped, as documented for C11. Malformed current
input must also release an older pending slot without altering its application's
retained bytes.

Dropping the framework owner can release its charge while application aliases
still keep the allocation alive. Those aliases are outside this ledger. Pending
leases may overlap existing outbound byte charges for the same physical backing;
counters are not disjoint RSS measurements. Boxes, Bytes metadata, codec state,
active output and arbitrary application retention also remain outside the vector
capacity counter. This design makes no total-memory, fairness, hit-rate, latency
or production-readiness promise.

## Costs and hypotheses to test

A keeper adds a Bytes clone, later reference release and ownership checks. Cloning
an exact-capacity Bytes Vec can allocate shared-ownership metadata. The existing
pbrs lazy parser may already promote that backing while making field windows, so
source inspection does not prove an extra metadata allocation in every lazy case;
the promotion can instead happen earlier. Scalar-only or fully copied parse paths
may pay metadata they did not need before. A pending-state Box and budget admission
are additional first-use costs; retained aliases can make them produce no reuse.

A successful later recovery can avoid a new output allocation/growth sequence.
It does not remove inflate initialization/copies, protobuf validation, application
objects or independent compressor histories. It may pin output after an application
would otherwise have freed it, until the next eligible frame or termination. Those
are source-level possibilities, not measured savings or regressions.

Required controls include:

- Drop each complete pbrs message before the next read; witness delayed reuse with
  full base-pointer/capacity recovery while ownership stays continuous.
- Keep one message alive, keep only an extracted shared field alive, clone nested
  messages, materialize all getters, and collect every message. Their bytes and
  pointers must remain unchanged; none may be overwritten to obtain a hit.
- Release the old message only after a successor arrives; verify the keep-old
  policy eventually recovers without accumulating owners or delaying delivery.
- Forward an uncompressed shared response and hold the HTTP/2 send queue under
  backpressure; the pending source must miss while any wire alias remains.
  Compare a compressed response, whose plaintext serialization copies input.
- Cover scalar-only pbrs with no retained backing, default/custom codecs with zero
  opt-in, actual Prost Bytes fields and the unchanged owned Prost path.
- Exact/spare Vec capacity; large-small/zero-small mixes; over-budget/oversized
  admission; many live streams; held aliases beyond RPC completion; and no charges
  after the framework owner terminates.
- Corrupt later gzip members/checksums/trailing input, deflate and optional zstd
  frame/window/count checks, invalid protobuf/UTF-8/required fields, and same-channel
  recovery. A cache transition must never substitute for validation.
- Source-paired allocations/requested bytes and CPU, cold/warm 1 KiB/64 KiB/1 MiB,
  all RPC shapes and endpoint pairings, identity/unary/TLS/multi-flight controls,
  retained-capacity and peak-RSS diagnostics. Record actual hit and pending-miss
  counts; do not infer hits from allocator-recycled pointer addresses.

The prototype is defensible only as a bounded opportunity tied to application
lifetimes. C11's move-only pbrs behavior remains a reasonable baseline when those
lifetimes prevent recovery or when ownership overhead exceeds avoided growth.

## Reviewed sources

| Source | SHA-256 |
|---|---|
| `pbrs-grpc/src/codec.rs` | `42156546f509da5b60489498d49ded6f4af474d005b219dbb725404fa2e884b4` |
| `pbrs-grpc/src/codec/prost.rs` | `1037fee963faa0996971fcd5a9f11fbe6d06a1cbc1513c57406bc948c477f33b` |
| `pbrs-grpc/src/wire/frame_reader.rs` | `032e54a2f6e9e59810e913c70da0697fea4284fff9c1505cd973130ae2bdcce7` |
| `pbrs-grpc/src/workspace.rs` | `925e68b5ca9a2487b37db58d0b2f309bcc6b13807011258bdcf09d0c47b91f59` |
| `src/message.rs` | `af04d67b1da49a4fee716d2546064d7666ca54b209cbe9e99c92a197b987cfd7` |
| `src/gen_support.rs` | `c52c7e9f29fac31cf5295f174f0be32af07d7c171c5040fde79d68fe9fc299da` |
| `src/lazy.rs` | `064df7d97f7fdb15867a593e671797c6bb372de55c85a67c9cc50c21c437af53` |
| `pbrs-grpc/src/stream.rs` | `6db1e4bc892203dcbc14da596e3fba77a72b0089c729484c3834166475461ad9` |
| `pbrs-grpc/src/wire/encode.rs` | `54233a7a7f4ddc3fa2b12df266980b8edd2f257d2549b454d03c2997f6c97061` |
