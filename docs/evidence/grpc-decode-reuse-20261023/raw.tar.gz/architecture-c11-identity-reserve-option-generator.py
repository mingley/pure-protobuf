from pathlib import Path
import difflib,hashlib,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';pin='beb4ecd9a9b2143c440892607d5b486318062b61'
paths=['pbrs-grpc/src/wire/encode.rs','pbrs-grpc/src/wire/out_batch.rs','pbrs-grpc/src/client/streaming.rs','pbrs-grpc/src/server/drain.rs','pbrs-grpc/src/wire/send.rs']
original={p:subprocess.check_output(['git','show',pin+':'+p],cwd=root).decode()for p in paths};changed=dict(original)
p=paths[0];s=changed[p];s=s.replace('pub(crate) fn append_frame<T: CodecMessage>(', 'pub(crate) fn append_frame_with_ready<T: CodecMessage>(',1)
old='''    gzip_level: u32,
) -> Result<(), Status> {
    let len = msg.encoded_len();''';new='''    gzip_level: u32,
    ready_messages: usize,
) -> Result<(), Status> {
    let len = msg.encoded_len();''';assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace('''    // A batch of equal frames otherwise reallocates and copies the prefix on
    // every message. The first small frame reserves room for three more.
    // `frame_from_msg` keeps the exact size for a single message.
    if sink.is_empty() && need <= 8 * 1024 {
        sink.reserve_new(need.saturating_mul(4));''','''    // Reserve one frame for a known singleton.
    // Any collected burst of at least two retains four-frame prefetch,
    // preserving the existing growth policy for mixed-size small bursts.
    if sink.is_empty() && need <= 8 * 1024 {
        let frames = if ready_messages <= 1 { 1 } else { 4 };
        sink.reserve_new(need.saturating_mul(frames));''',1)
marker='''/// Compression flag plus the 4-byte length, written into the reserved head.
'''
wrapper='''// Existing wire-format tests retain their original four-message assumption.
// Count-aware capacity/error tests must exercise append_frame_with_ready directly.
#[cfg(test)]
fn append_frame<T: CodecMessage>(
    sink: &mut SegSink,
    scratch: &mut EncodeScratch,
    msg: &T,
    codec: Option<CompressionAlgorithm>,
    limits: MessageLimits,
    gzip_level: u32,
) -> Result<(), Status> {
    append_frame_with_ready(sink, scratch, msg, codec, limits, gzip_level, 4)
}

''';assert s.count(marker)==1;s=s.replace(marker,wrapper+marker,1);changed[p]=s
p=paths[1];s=changed[p].replace('SegSink, append_frame}', 'SegSink, append_frame_with_ready}',1)
old='''    pub(crate) fn encode<T: CodecMessage>(&mut self, item: Framed<T>) -> Result<(), Status> {'''
new='''    pub(crate) fn encode_ready<T: CodecMessage>(
        &mut self,
        item: Framed<T>,
        ready_messages: usize,
    ) -> Result<(), Status> {''';assert s.count(old)==1;s=s.replace(old,new,1)
s=s.replace('if let Err(status) = append_frame(', 'if let Err(status) = append_frame_with_ready(',1)
s=s.replace('''            self.wire.gzip_level,
        ) {''','''            self.wire.gzip_level,
            ready_messages,
        ) {''',1)
marker='''    /// Whether the batch has reached the size worth writing on its own.
''';wrapper='''    #[cfg(test)]
    fn encode<T: CodecMessage>(&mut self, item: Framed<T>) -> Result<(), Status> {
        self.encode_ready(item, 4)
    }

''';assert s.count(marker)==1;s=s.replace(marker,wrapper+marker,1);changed[p]=s
for p in [paths[2],paths[3],paths[4]]:
 s=changed[p]
 assert s.count('        for item in items.drain(..) {')==1
 s=s.replace('        for item in items.drain(..) {','        let ready_messages = items.len();\n        for (index, item) in items.drain(..).enumerate() {',1)
 expected=2 if p==paths[2] else 1
 assert s.count('batch.encode(item)')==expected
 s=s.replace('batch.encode(item)', 'batch.encode_ready(item, ready_messages - index)')
 if p==paths[2]:
  assert s.count('    for item in items {')==1
  s=s.replace('    for item in items {','    let ready_messages = items.len();\n    for (index, item) in items.into_iter().enumerate() {',1)
 changed[p]=s
patch=''.join(''.join(difflib.unified_diff(original[p].splitlines(True),changed[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p))for p in paths)
out=q/'architecture-c11-identity-count-aware-reserve-option.patch'
with out.open('x')as f:f.write(patch)
result=subprocess.run(['git','apply','--check',str(out)],cwd=root/'work/architecture-c11',text=True,capture_output=True)
review=dict(state='DESIGN_OPTION_ONLY_NOT_APPLIED_BUILT_OR_MEASURED',qualified=False,source_pin=pin,patch=str(out),patch_sha256=hashlib.sha256(patch.encode()).hexdigest(),read_only_apply_check=dict(exit_code=result.returncode,stderr=result.stderr),files=paths,all_live_paths=['client pump_outbound_budget','generic wire pump_outbound','server drain_to_wire','closed-upload write_closed_upload'],algorithm='After any try_recv_many, use the already-collected len and a linear enumeration. Pass remaining collected count to encode. For an empty uncompressed small-message sink reserve need for a known single message; keep the old4*need for any known burst>=2. Compression and large-message branches unchanged. No extra encoded_len pass or speculative future-message wait.',excluded='Vec initial-capacity tuning is separate. For2/3ready frames retain old4prefetch to avoid variable-size burst regrowth; the clamped1..4proposal is retained as v1 history. No bounds, validation, cancellation, ownership or status behavior removed.',required_before_any_candidate=['Compile and strict lint in an isolated new source. This patch is not a validated implementation.','Count-aware one-message/four-message capacity and encoded-byte/order tests; sizes around8KiBthreshold and32KiBflush.','Error rollback: partial first message, completed prefix plus shared segments, compressed errors, and retry after failed append.','Queues1/4/16/64/256, ping-pong/pipelined bursts, mixed sizes, blocked windows/cancellation and count clamping.','Matched requested-byte/allocation counters and CPU/wakeup/throughput/latency checks before accepting tradeoffs.'])
with(q/'architecture-c11-identity-count-aware-reserve-option.json').open('x')as f:json.dump(review,f,indent=2);f.write('\n')
print(json.dumps({'patch':str(out),'sha256':review['patch_sha256'],'apply_check':result.returncode,'no_application_or_build':True}))
