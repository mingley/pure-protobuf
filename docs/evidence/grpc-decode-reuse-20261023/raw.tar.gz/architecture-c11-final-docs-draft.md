# C11 final documentation draft — actual captures, final gates pending

Q only. No tracked edits. Prepared after selected native, selected CPU and expanded
native terminal success. ASAN is still running; C11 day has not been launched.
Do not infer either outcome from the workspace or completed captures.

Candidate/runtime/benchmark: `beb4ecd9a9b2143c440892607d5b486318062b61`.
Matched C8 baseline: `9d6fb9c416fc32732450fd78d32ee16ff8b802de`.
The corrected C10 initialization and fixture changes are part of C11, not extra
uncommitted runtime edits. Root owns final results.json/index/archive publication.

## docs/benchmarks.md

````markdown
# Benchmarks

Prost gzip streams request **31–36% fewer bytes** than C8 in selected cases.
Important bidi byte and instruction losses remain. Production readiness and a
broad speed advantage over tonic/prost remain unproved.

2026-10-23 · Linux x86_64 · Rust 1.99.1 · Shared host.

## Remaining byte costs

**Requested allocation bytes/RPC.** Prost, plaintext, one connection/one in flight.
The 1 MiB rows use selected N25/50 two-repeat medians; 1 KiB rows use expanded
N200/400 three-repeat medians. Lower is better.

| Side | Workload | C11 | tonic/prost | More |
|---|---|---:|---:|---:|
| Server | Bidi, 1 MiB gzip | 18.5 MiB | 15.7 MiB | +18.2% |
| Client | Bidi, 1 MiB gzip | 19.5 MiB | 16.7 MiB | +17.1% |
| Client | Bidi, 1 KiB identity | 53.9 KiB | 39.4 KiB | +36.7% |
| Server | Bidi, 1 KiB identity | 43.5 KiB | 32.9 KiB | +31.9% |

The full pbrs interop server requests **43.5 MiB versus 15.7 MiB (+178%)** for
1 MiB gzip bidi. That route includes extra handler work; it is not an isolated
codec or transport comparison. Unique prost buffer recovery does not force
retained pbrs/Bytes input to give up ownership.

## Source changes

**Gzip requested bytes/RPC:** `9d6fb9c4` → `beb4ecd9`, matched handlers/settings,
two ABBA repeats with 25/50-call differences.

| Side | Workload | C8 | C11 | Change |
|---|---|---:|---:|---:|
| Server | Bidi, 1 MiB | 27.5 MiB | 18.5 MiB | -32.6% |
| Client | Bidi, 1 MiB | 28.5 MiB | 19.5 MiB | -31.5% |
| Server | Upload, 64 KiB | 1,516.3 KiB | 964.4 KiB | -36.4% |
| Client | Server stream, 64 KiB | 1,671.6 KiB | 1,119.8 KiB | -33.0% |

Observed increases remain: 1 MiB server-stream server bytes +2.9% with mixed
repeat directions; tiny identity bidi client allocations +1.6% in both repeats.
Tiny unary client bytes rise 0.86%; the fresh tonic source control rises 0.87%.
All byte/count increases and repeat ranges remain in the raw ledger, without a
2% cutoff or unsupported allocation-site attribution.

Values/percentages use unrounded medians, displayed to one decimal. Requested
bytes are cumulative allocation requests, not retained memory or RSS.

## Instruction diagnostics

**Million instructions/RPC.** Prost gzip, plaintext, one in flight; N10/20,
two ABBA repeats. These are the four cases outside the 2% tonic tie band.

| Side | Workload | C11 | tonic/prost | Difference |
|---|---|---:|---:|---:|
| Client | Upload, 1 KiB | 2.385 | 2.237 | +6.6% |
| Server | Bidi, 1 KiB | 2.834 | 2.774 | +2.2% |
| Server | Upload, 1 KiB | 1.063 | 1.163 | -8.6% |
| Server | Upload, 64 KiB | 1.939 | 2.037 | -4.8% |

The other four cases are ties. All eight C8→C11 changes are under 0.4%: **no C11
CPU gain is established**. Both endpoints run under Callgrind using release
binaries with allocation counting enabled; this is not shipping CPU, latency or
throughput qualification. Profiles attribute the client upload gap chiefly to
repeated gzip output-scratch initialization; no replacement is implemented.

## Scope and records

| Completed campaign | Captures | Successful RPCs |
|---|---:|---:|
| Selected source pairs | 568 | 21,300 |
| Current expanded matrix | 2,400 | 720,000 |
| Selected instructions | 96 | 1,440 |

Every offered/dispatched/completed call reconciles; zero failures/timeouts.
Expanded: all five RPC shapes, plaintext/TLS, identity/gzip, both native codecs,
1/64 KiB and one/16 in-flight calls. Only selected scopes have a matched C8
baseline. Gzip level 6, zero-filled application payloads, four messages on each
streaming leg; server send buffers 400 KiB, queues 16. Shipping defaults and native
accounting/channelz are unchanged. Payload size is not encoded message size.

[Full results, dated source and raw captures](evidence/grpc-decode-reuse-20261023/README.md)
· [Benchmark contract](benchmark-contract.md)

## Reproduce

Build a clean source with `scripts/build-rpc-bench.py`; keep its source/toolchain/
binary record and identical harness settings on both revisions. For the expanded
native matrix:

```sh
python3 scripts/grpc-counter-campaign.py \
  --source-checkout "$PWD" --binary "$bench_binary" \
  --build-record "$build_record" --output "$counter_output" --phase native \
  --payloads 1024,65536 --load-levels 1:1,1:16 --repeats 3
```

Exact selected ABBA/profiler commands are in the raw record. Context switches and
coarse CPU ticks do not qualify scheduling; syscalls/task wakes, native latency,
throughput, retained memory, full feature/platform coverage and a C11 day remain
open. C8's separate day does not qualify C11.

[Earlier C8 results](evidence/grpc-architecture-20261022/README.md) retain their
original source and scope. [Current priorities](../TODO.md#current-priorities)
include the source-reviewed pre-shape service-deadline gap; its independent
reproduction and repair are still pending.

````

## Root README opening addition

Link the new capsule after actual-result grant, keeping the existing feature,
preview and support boundaries intact:

> [Bounded stream decode reuse](docs/evidence/grpc-decode-reuse-20261023/README.md)
> records the current source, checked ownership limits, matched allocation gains
> and remaining byte/instruction losses. [Earlier execution results](docs/evidence/grpc-architecture-20261022/README.md)
> retain their original validation and resource-run scope.

## TODO current priorities replacement outline

Delivered in C11: unique fully consumed prost decoded-buffer reuse with bounded
idle capacity (4 MiB per buffer, 16 MiB process-wide), bounded initialization,
cold-short ordinary path and observed-terminal cleanup. Retained Bytes/pbrs input
keeps its ownership. Workspace **3,771 passed, zero failed, nine ignored** across
141 targets; all ten prechecks pass. Fill final sanitizer/preview/day records only
when their terminal records arrive. Keep C10's failed 3,766/2/9 and original
fixture/control/automation failures in the capsule.

1. **Deadline origin and outer service ownership, correctness first.** Current
   source starts shape timers after a custom service can wait, and repeated
   deadline getters recompute `now()+duration`. Capture one absolute local
   admission deadline and own the full cooperative service future, preserving a
   single responder/terminal transition. The raw-peer causal control is NOT RUN;
   this is a source-proven gap, not a reproduced new wire failure or passing fix.
2. **Profile-attributed gzip output initialization.** The 1 KiB upload client uses
   6.629% more diagnostic instructions than tonic. Retained profiles attribute
   the excess mainly to repeated writer output initialization; common compressor
   initialization is equal. Test a safe bounded initialized-output path without
   changing member/checksum/finish/error semantics; replacement is not implemented.
3. **Identity reservations, one component at a time.** Compare a known-single
   first-frame reservation with current four-frame prefetch; retain existing
   burst behavior. Tune 64-slot item/permit vector hints separately. Prepared
   patches are unapplied and unmeasured; do not assign the byte gap to source
   arithmetic without allocator evidence.
4. **Owned encode storage and compressed output.** Retain plaintext scratch only
   under its own stated capacity budget, separate from compressed reservation
   and pending wire tail ownership. An extra 16 MiB ledger means up to 32 MiB
   across encode/decode ledgers, not an unchanged total memory bound.
5. **One-pass owned read-all decode and shared-input options.** Checked eager
   singular merge must retain parse-time rejection, unknown/merge/oneof/recursion
   semantics. Repeated Query children already parse eagerly. Any pending shared
   keeper must wait for actual uniqueness, never copy or invalidate retained
   application input to force reuse; this option is not implemented.
6. **Protocol isolation under bounded admission.** Compare inline execution with
   owned per-RPC tasks and spare workers. A single per-connection handler driver
   cannot isolate cheap RPCs from a blocked sibling. Preserve fixed deadlines,
   cancellation, permits until actual cleanup, and explicit abort/drain ownership.
   Timers/abort do not preempt an executing poll; current-thread/per-core serving
   does not gain a thread by spawning. Hard isolation needs an explicit policy.
7. **Finish the complete claim.** Remaining interop/features, platform/release,
   native latency/throughput/client-server CPU and actual C11 24-hour resources
   remain open. Keep every measured loss and failed attempt. C8's active day stays
   pinned to C8 regardless of its later outcome.

## Capsule README structure

Title: **Bounded stream decode reuse**. Keep the main page readable; detailed
original failures and controls belong here and in raw artifacts.

Opening: C11 reuses only a uniquely recoverable fully consumed decoded allocation.
The private idle policy is 4 MiB per buffer and 16 MiB process-wide, charged by
capacity. Retention misses do not fail an RPC. Active decode, application-owned
messages, compressor scratch and RSS are separate. Logical initialized length
is independent of cached physical capacity. Limits/checksums/frames/ownership
remain unchanged; observed terminals release cached storage.

Validation table, actual source and terminal result for each:

| Check | Actual C11 state at this draft |
|---|---|
| All-feature workspace | 3,771 passed, zero failed, nine ignores; 141 targets; 20 min 27.87 s |
| Ten prechecks | Passed |
| Focused library/wire/resolver | 703 / 1 / 34 passed; overlapping scopes are not summed |
| Repaired Serving v2 and independent raw peer | 1,100 / 1 passed |
| Sanitizer | Running; no result inserted |
| Resource preview | Use actual final preview record; do not infer from offline controls |
| Native and instruction captures | 568/21,300; 2,400/720,000; 96/1,440 captures/RPCs; all pass |
| Actual C11 day | Not launched at draft time; use actual source/start/result later |

Performance: reuse the allocation tables plus full eight-row instruction table
from `architecture-c11-final-allocation-tables.md`. Keep all 112 native alloc/byte
groups, 45 higher source medians and 64 groups with a higher repeat, no 2% cutoff.
Retain all full-interop pbrs rows separately. The selected largest median source
increase is 1 MiB gzip server-stream server bytes +2.88%, mixed repeat directions.
Tiny unary client +0.857% and TT source +0.866% must both remain visible; no site
cause was measured. Expanded identity medians have their own N200/400 scope.

Retain these failures without rewriting their original outcomes:

- C10 wrong Rust1.88 build selection, rejected before comparison; corrected stable
  build and source identities remain separate.
- C10 full workspace: 3,766 passes, two failures, nine ignores, 140 targets.
  Preserve resolver phase expiry and unadmitted-child fixture diagnoses/repairs.
- C11 initial mTLS startup fixture failure after 1,099 passes; retain initial raw
  peer result and exact repaired v2 source/gate.
- Original C11 automation pipeline failed when its unit classifier demanded a
  later capacity-assertion marker. The actual uniqueness assertion caught the
  faulty implementation; the other three negatives caught too. Read-only
  adjudication passed using original source/compile/raw evidence, with no new
  tests and no change to the original failed controller. Restored 703 library
  and wire1 checks passed. Pipeline v2 is a separate successor, not a relabeled
  original success.

Next design references: current admission-origin/full-service deadline source
finding (causal control NOT RUN), gzip writer output initialization attributed
from retained profiles (no replacement), and unapplied identity/encode/shared
input options. Link the raw review members and their exact source scopes.

Raw/public files: `results.json`, `manifest.json`, `raw.tar.gz`, `check.py`;
link actual archive members/records after packager output. Preserve the C8 day
publisher marker when root updates the evidence index. The new capsule cannot
inherit C8 workspace, profiler or resource qualification.
