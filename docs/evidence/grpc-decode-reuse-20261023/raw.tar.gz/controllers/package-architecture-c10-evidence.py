#!/usr/bin/env python3
"""Package final C11 evidence and its C10 history after --execute.

Preparation and syntax checks do not write tracked files. The final capsule is
created once, with no binaries, live logs, extraction, or qualification claim.
An optional publication plan selects reviewed final documents by SHA256.
"""

import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import runpy
import subprocess
import tarfile
import time


Q = Path(__file__).resolve().parent
ROOT = Q.parents[1]
DEST = ROOT / "docs/evidence/grpc-decode-reuse-20261023"
C10_SOURCE = "a675b61fe2775e336f33474c58342764cea814a8"
SOURCE = None
BASELINE = "9d6fb9c416fc32732450fd78d32ee16ff8b802de"
CHANGE_BASE = "b03c3458f25abef73b79af30e72e628b799f053d"
C10_PINS_SHA256 = "4fcc5230eae3d9648222e4149489f52f794a11fe6929b31c4db200c992b938b5"
PINS_SHA256 = None
PINS = Q / "architecture-c11-source-pins.json"

CHECK_PY = '''#!/usr/bin/env python3
"""Verify retained gRPC evidence without extracting the archive."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def safe_name(name):
    path = PurePosixPath(name)
    return (bool(name) and not path.is_absolute() and str(path) == name
            and not any(part in (".", "..") for part in path.parts)
            and "\\\\" not in name and ":" not in name)


def digest_file(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def check(directory):
    manifest = json.loads((directory / "manifest.json").read_text())
    if manifest.get("qualified") is not False:
        raise ValueError("unexpected qualification claim")
    archive_name = manifest["archive"]["name"]
    if not safe_name(archive_name) or len(PurePosixPath(archive_name).parts) != 1:
        raise ValueError("unsafe archive name")
    archive = directory / archive_name
    if archive.stat().st_size != manifest["archive"]["bytes"]:
        raise ValueError("archive size mismatch")
    if digest_file(archive) != manifest["archive"]["sha256"]:
        raise ValueError("archive checksum mismatch")
    expected = {entry["path"]: entry for entry in manifest["files"]}
    if len(expected) != len(manifest["files"]) or not all(map(safe_name, expected)):
        raise ValueError("duplicate or unsafe manifest path")
    seen, total = set(), 0
    with tarfile.open(archive, "r:gz") as capsule:
        for member in capsule:
            if (not member.isfile() or not safe_name(member.name)
                    or member.name in seen or member.name not in expected):
                raise ValueError(f"unexpected archive member: {member.name}")
            entry = expected[member.name]
            if member.size != entry["bytes"]:
                raise ValueError(f"size mismatch: {member.name}")
            stream = capsule.extractfile(member)
            if stream is None:
                raise ValueError(f"missing content: {member.name}")
            checksum = hashlib.sha256()
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                checksum.update(block)
            if checksum.hexdigest() != entry["sha256"]:
                raise ValueError(f"file checksum mismatch: {member.name}")
            total += member.size
            seen.add(member.name)
    if seen != set(expected) or total != manifest["logical_bytes"]:
        raise ValueError("archive inventory is incomplete")
    print(f"verified {len(seen)} files, {total} bytes; no production qualification")


if __name__ == "__main__":
    check(Path(__file__).resolve().parent)
'''


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + "\n").encode()


def git(*arguments):
    return subprocess.check_output(["git", *arguments], cwd=ROOT)


def safe_name(name):
    path = PurePosixPath(name)
    return (bool(name) and not path.is_absolute() and str(path) == name
            and not any(part in (".", "..") for part in path.parts)
            and "\\" not in name and ":" not in name)


def json_file(path):
    return json.loads(path.read_text())


def checked_json(path, observed):
    data = path.read_bytes()
    actual = {"bytes": len(data), "sha256": sha(data)}
    if path in observed:
        assert observed[path] == actual, path
    observed[path] = actual
    return json.loads(data)


def verify_frozen_checkout(name, commit):
    checkout = ROOT / "work" / name
    head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip()
    status = subprocess.check_output(
        ["git", "status", "--porcelain", "--untracked-files=all"], cwd=checkout, text=True
    ).strip()
    assert head == commit and not status, {"checkout": str(checkout), "head": head, "status": status}


def test_summaries(path):
    return [
        {"status": status, "passed": int(passed), "failed": int(failed), "ignored": int(ignored)}
        for status, passed, failed, ignored in re.findall(
            r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", path.read_text()
        )
    ]


def totals(summaries):
    return {key: sum(item[key] for item in summaries) for key in ("passed", "failed", "ignored")}


def validate_logs(logs, observed):
    for name, expected in logs.items():
        path = Path(name) if Path(name).is_absolute() else Q / name
        assert not path.is_symlink() and path.resolve().is_relative_to(Q), path
        actual = {"bytes": path.stat().st_size, "sha256": digest(path)}
        assert actual == expected, path
        if path in observed:
            assert observed[path] == actual, path
        observed[path] = actual


def validate_failed_history(observed):
    c10_pins = checked_json(Q / "architecture-c10-source-pins.json", observed)
    assert observed[Q / "architecture-c10-source-pins.json"]["sha256"] == C10_PINS_SHA256
    assert c10_pins["candidate_runtime"] == C10_SOURCE
    checks = checked_json(Q / "architecture-c10-checks-state.json", observed)
    assert checks["state"] == "failed" and checks["source"] == {"head": C10_SOURCE, "status": ""}
    workspace = [item for item in checks["checks"] if item["name"] == "workspace"]
    assert len(workspace) == 1 and workspace[0]["exit_code"] != 0
    assert workspace[0]["source_after"] == {"head": C10_SOURCE, "status": ""}
    record = checked_json(Q / "architecture-c10-workspace.json", observed)
    assert record["exit_code"] != 0 and record["source"]["head"] == C10_SOURCE
    assert record["source"]["diff_sha256"] == sha(b"") and not record["source"]["untracked"]
    validate_logs(workspace[0]["logs"], observed)
    summaries = test_summaries(Q / "architecture-c10-workspace.stdout")
    assert summaries == workspace[0]["summaries"]
    assert totals(summaries) == workspace[0]["totals"] and totals(summaries)["failed"] == 2
    focused_prefix = Q / "architecture-c11-focused-cancellation"
    focused = checked_json(focused_prefix.with_suffix(".json"), observed)
    assert focused["exit_code"] != 0 and focused["source"]["head"] == C10_SOURCE
    focused_summaries = test_summaries(focused_prefix.with_suffix(".stdout"))
    assert totals(focused_summaries)["failed"] == 1
    for suffix in (".stdout", ".stderr"):
        artifact = focused_prefix.with_suffix(suffix)
        observed[artifact] = {"bytes": artifact.stat().st_size, "sha256": digest(artifact)}
    c10_pipeline = checked_json(Q / "architecture-c10-pipeline-v2-state.json", observed)
    assert c10_pipeline["state"] == "superseded_before_measurement" and not c10_pipeline["phases"]
    return {
        "c10_workspace": {"source": C10_SOURCE, "state": "failed", "counts": totals(summaries),
                          "record": "architecture-c10-workspace.json"},
        "first_c11_serving_attempt": {
            "source": focused["source"], "state": "failed", "counts": totals(focused_summaries),
            "target_summaries": focused_summaries,
            "record": "architecture-c11-focused-cancellation.json",
            "scope": "Serving and raw-peer targets from an uncommitted repair attempt based on C10; not the final C11 source.",
        },
        "c10_measurements": "Not run; superseded before measurement.",
    }


def retained_build(directory, expected_source, observed):
    build = checked_json(Q / directory / "build.json", observed)
    assert build["source"]["commit"] == expected_source and build["exit_code"] == 0
    for name, checksum in build["files"].items():
        assert safe_name(name) and len(PurePosixPath(name).parts) == 1
        path = Q / directory / name
        assert digest(path) == checksum, path
        observed[path] = {"bytes": path.stat().st_size, "sha256": checksum}
    binary = Q / directory / "rpc-bench"
    assert digest(binary) == build["binary_sha256"], binary
    observed[binary] = {"bytes": binary.stat().st_size, "sha256": build["binary_sha256"]}
    return build


def validate_gates(observed, pipeline_path, extra_gate_paths, require_expanded):
    pins = checked_json(PINS, observed)
    assert observed[PINS]["sha256"] == PINS_SHA256, "immutable final source-pins input changed"
    assert pins["candidate_runtime"] == SOURCE and pins["baseline_runtime"] == BASELINE
    assert pins["qualified"] is False
    verify_frozen_checkout("architecture-c11", SOURCE)
    verify_frozen_checkout("architecture-c10", C10_SOURCE)
    verify_frozen_checkout("architecture-c8", BASELINE)
    history = validate_failed_history(observed)
    clean = {"head": SOURCE, "status": ""}
    pipeline_path = pipeline_path.resolve(strict=True)
    assert pipeline_path.parent == Q and pipeline_path.name.startswith("architecture-c11-")
    pipeline = checked_json(pipeline_path, observed)
    assert pipeline["state"] == "passed" and pipeline["qualified"] is False, pipeline
    assert pipeline["pin"] == SOURCE
    assert pipeline["source_before"] == pipeline["source_after"] == clean
    assert pipeline["active"] is None and pipeline["phases"]
    for name, checksum in pipeline["immutable_inputs"].items():
        path = Path(name)
        assert digest(path) == checksum, path
        observed[path] = {"bytes": path.stat().st_size, "sha256": checksum}
    assert pipeline["immutable_inputs"][str(PINS)] == PINS_SHA256
    validate_logs(pipeline["evidence"], observed)
    for phase in pipeline["phases"]:
        assert phase["exit_code"] == 0, phase
        path = Path(phase["record"])
        assert path.parent == Q
        record = checked_json(path, observed)
        validate_logs(phase["files"], observed)
        assert record["exit_code"] == 0 and not record.get("timeout")
        assert record["source"] == {"head": SOURCE, "diff_sha256": sha(b""), "untracked": {}}

    checks_path = Q / "architecture-c11-checks-state.json"
    checks = checked_json(checks_path, observed)
    assert checks["state"] == "passed" and checks["source"] == clean and checks["active"] is None
    assert pipeline["evidence"][str(checks_path)]["sha256"] == observed[checks_path]["sha256"]
    expected_checks = {
        "format", "clippy-root-alltargets", "clippy-grpc-alltargets",
        "clippy-grpc-adapter-example", "examples", "rpc-benchmark-correctness",
        "tonic-benchmark-correctness", "rustdoc", "msrv", "msrv-zstd", "workspace",
    }
    assert {check["name"] for check in checks["checks"]} == expected_checks
    assert len(checks["checks"]) == len(expected_checks)
    actual_tests = {}
    for check in checks["checks"]:
        assert check["exit_code"] == 0 and check["source_after"] == clean, check
        prefix = Q / ("architecture-c11-" + check["name"])
        record = checked_json(prefix.with_suffix(".json"), observed)
        assert record["exit_code"] == 0 and not record.get("timeout"), record
        assert record["source"]["head"] == SOURCE
        assert record["source"]["diff_sha256"] == sha(b"") and not record["source"]["untracked"]
        validate_logs(check["logs"], observed)
        summaries = test_summaries(prefix.with_suffix(".stdout"))
        assert summaries == check["summaries"]
        assert all(item["status"] == "ok" and item["failed"] == 0 for item in summaries)
        assert totals(summaries) == check["totals"]
        if check["name"] in {"workspace", "rpc-benchmark-correctness", "tonic-benchmark-correctness"}:
            assert summaries and totals(summaries)["passed"] > 0
            actual_tests[check["name"]] = totals(summaries)

    asan = checked_json(Q / "architecture-c11-asan-supervisor-state.json", observed)
    assert asan["state"] == "passed" and asan["cache_reclaimed"] is True
    assert asan["source_pin"] == SOURCE and asan["source_before"] == asan["source_after"] == clean
    assert asan["pins"]["sha256"] == PINS_SHA256
    assert asan["artifacts_before_cleanup"] == asan["artifacts_after_cleanup"]
    assert len(asan["checks"]) == 2
    for check in asan["checks"]:
        assert check["exit_code"] == 0 and check["source_after"] == clean
        assert check["summaries"] and all(item["status"] == "ok" and item["failed"] == 0 for item in check["summaries"])
        assert totals(check["summaries"]) == check["totals"]
        actual_tests[check["name"]] = check["totals"]
        validate_logs(check["files"], observed)
    controls = checked_json(Q / "architecture-c11-negative-controls-state.json", observed)
    assert controls["state"] == "passed" and controls["pin"] == SOURCE
    assert controls["source_pins_sha256"] == PINS_SHA256
    assert all(controls[key] is True for key in (
        "restored_clean", "frozen_unchanged", "source_patches_verified", "positive_source_clean"
    ))
    negative_checks = [check for control in controls["controls"] for check in control["checks"]]
    assert len(negative_checks) >= 4 and all(check["observed_expected_result"] is True for check in negative_checks)
    assert controls["positive"]["observed_expected_result"] is True
    assert "infrastructure_error" not in controls
    extra_gates = []
    resolver_path = Q / "architecture-c11-resolver-negative-controls-state.json"
    resolver = checked_json(resolver_path, observed)
    assert resolver["pin"] == SOURCE and resolver["state"] == "passed" and resolver["passed"] is True
    assert all(resolver[key] is True for key in (
        "restored_clean", "frozen_unchanged", "source_pins_unchanged"
    ))
    assert resolver["positive"]["observed_expected_result"] is True
    assert resolver["controls"] and all(
        check["observed_expected_result"] is True
        for control in resolver["controls"] for check in control["checks"]
    )
    extra_gates.append({"path": str(resolver_path), "sha256": observed[resolver_path]["sha256"]})
    for path in extra_gate_paths:
        path = path.resolve(strict=True)
        assert path.is_relative_to(Q)
        gate = checked_json(path, observed)
        assert gate.get("state") == "passed" or gate.get("passed") is True, path
        extra_gates.append({"path": str(path), "sha256": observed[path]["sha256"]})

    baseline = retained_build("architecture-c8-rpc-build", BASELINE, observed)
    rejected = retained_build("architecture-c10-rpc-build", C10_SOURCE, observed)
    c10_stable = retained_build("architecture-c10-stable-rpc-build", C10_SOURCE, observed)
    candidate_directory = "architecture-c11-stable-rpc-build"
    if not (Q / candidate_directory / "build.json").exists():
        candidate_directory = "architecture-c11-rpc-build"
    candidate = retained_build(candidate_directory, SOURCE, observed)
    assert baseline["tools"] == candidate["tools"] == c10_stable["tools"]
    assert rejected["tools"] != candidate["tools"]

    summaries = {}
    for name, phase, campaign_name in (("native", "native", "architecture-c11-counter-ab"),
                                      ("cpu", "callgrind", "architecture-c11-cpu-ab")):
        summary = checked_json(Q / (campaign_name + "-summary.json"), observed)
        campaign = checked_json(Q / campaign_name / "campaign.json", observed)
        assert summary["passed"] is True and summary["controller_passed"] is True
        assert summary["qualified"] is False and summary["phase"] == phase
        assert summary["state"] == campaign["state"] == "finished" and campaign["passed"] is True
        assert campaign["qualified"] is False
        for field in ("failed_captures", "missing_data", "missing_keys", "extra_keys", "status_errors"):
            assert not summary[field], (name, field, summary[field])
        for version, build in (("baseline", baseline), ("candidate", candidate)):
            assert campaign["versions"][version]["source"] == build["source"]
            assert campaign["versions"][version]["binary_sha256"] == build["binary_sha256"]
            assert campaign["versions"][version]["build_record"] == build
            assert summary["source_pins"][version] == campaign["versions"][version]
        summaries[name] = {"path": campaign_name + "-summary.json", "qualified": False,
                           "retained_captures": summary["retained_captures"],
                           "actual_rpc_totals": summary["actual_rpc_totals"]}
    if require_expanded or pipeline["expanded_requested"]:
        extra_inputs = {}
        validator = runpy.run_path(str(Q / "reclaim-rpc-cache.py"))["validate_expanded"]
        summaries["expanded"] = validator(SOURCE, candidate["binary_sha256"], extra_inputs)
        for name, actual in extra_inputs.items():
            path = Path(name)
            if path in observed:
                assert observed[path] == actual, path
            observed[path] = actual
    return {"source": SOURCE, "baseline": BASELINE, "qualified": False,
            "tests": actual_tests, "summaries": summaries, "history": history, "extra_gates": extra_gates,
            "rejected_build": {"source": C10_SOURCE, "tools": rejected["tools"],
                               "binary_sha256": rejected["binary_sha256"], "comparison_eligible": False},
            "matched_build_tools": candidate["tools"]}


def live_writers():
    """Find known writable Q descriptors; unreadable processes stay disclosed."""
    writers, inaccessible = {}, []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            for fd in (proc / "fd").iterdir():
                try:
                    name = os.readlink(fd)
                    if not name.startswith(str(Q) + "/"):
                        continue
                    flags = re.search(r"^flags:\s+([0-7]+)$", (proc / "fdinfo" / fd.name).read_text(), re.MULTILINE)
                    if flags and int(flags.group(1), 8) & os.O_ACCMODE != os.O_RDONLY:
                        writers.setdefault(Path(name), []).append({"pid": int(proc.name), "fd": fd.name})
                except (FileNotFoundError, ProcessLookupError):
                    continue
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            inaccessible.append(int(proc.name))
    return writers, inaccessible


def select_inputs(writers):
    paths, omitted = set(), []
    for child in sorted([*Q.glob("architecture-c10*"), *Q.glob("architecture-c11*")]):
        assert not child.is_symlink(), child
        if child.name.startswith("architecture-c11-day") and child.name != "architecture-c11-day-prepared.json":
            omitted.append({"path": child.relative_to(Q).as_posix(),
                            "reason": "Dedicated C11 soak publisher owns live day records and harness."})
            continue
        candidates = child.rglob("*") if child.is_dir() else [child]
        for path in candidates:
            assert not path.is_symlink(), path
            if not path.is_file():
                continue
            name = path.relative_to(Q).as_posix()
            if "__pycache__" in path.parts or path.suffix in (".pyc", ".pyo"):
                omitted.append({"path": name, "reason": "Python bytecode cache"})
            elif path in writers:
                assert path.suffix in (".stdout", ".stderr", ".log", ".jsonl"), (path, writers[path])
                omitted.append({"path": name, "reason": "live writable log", "writers": writers[path]})
            else:
                paths.add(path)
    for name in ("build.json", "build.stdout.jsonl", "build.stderr.log", "rpc-bench"):
        paths.add(Q / "architecture-c8-rpc-build" / name)
    prepared_day = Q / "c11-day-controller-prepared"
    if prepared_day.exists():
        assert not prepared_day.is_symlink()
        for path in prepared_day.rglob("*"):
            assert not path.is_symlink(), path
            if path.is_file() and "__pycache__" not in path.parts:
                paths.add(path)
    return paths, omitted


def source_snapshot():
    generated, identical = {}, []
    names = git("diff", "--name-only", CHANGE_BASE, SOURCE).decode().splitlines()
    assert names and all(name == "docs/resource-budgets.md" or name.startswith("pbrs-grpc/") for name in names)
    for name in names:
        assert safe_name(name), name
        generated["source-delivered/" + name] = git("show", SOURCE + ":" + name)
    patch = git("diff", "--binary", BASELINE, SOURCE, "--", "pbrs-grpc")
    assert patch and len(patch) < 1024 * 1024, "runtime-only patch unexpectedly large"
    generated["source-delivered/runtime-changes.patch"] = patch
    generated["source-delivered/c10-to-final-runtime.patch"] = git(
        "diff", "--binary", C10_SOURCE, SOURCE, "--", "pbrs-grpc"
    )
    c10_names = git("diff", "--name-only", CHANGE_BASE, C10_SOURCE).decode().splitlines()
    for name in c10_names:
        assert safe_name(name) and not name.startswith("docs/evidence/"), name
        generated["source-history/c10/" + name] = git("show", C10_SOURCE + ":" + name)
    generated["source-history/c10/pin.json"] = encoded({
        "source": C10_SOURCE, "change_base": CHANGE_BASE, "snapshot_paths": c10_names,
        "workspace_state": "failed", "qualified": False,
    })
    benchmark_paths = [
        "Cargo.toml", "Cargo.lock", "pbrs-grpc/Cargo.toml", "rpc-bench/Cargo.toml",
        "rpc-bench/Cargo.lock", "rpc-bench/build.rs", "rpc-bench/src/main.rs",
        "tonic-bench/Cargo.toml", "tonic-bench/Cargo.lock",
        "scripts/grpc-load-smoke.py", "scripts/dominance-ledger.py",
        "scripts/build-rpc-bench.py", "scripts/grpc-resource-campaign.py",
    ]
    for name in benchmark_paths:
        candidate, baseline = git("show", SOURCE + ":" + name), git("show", BASELINE + ":" + name)
        assert candidate == baseline, name
        generated["identical-benchmark/" + name] = candidate
        identical.append({"path": name, "bytes": len(candidate), "sha256": sha(candidate),
                          "baseline": BASELINE, "candidate": SOURCE})
    generated["source-delivered/pin.json"] = encoded({
        "source": SOURCE, "source_tree": git("rev-parse", SOURCE + "^{tree}").decode().strip(),
        "change_base": CHANGE_BASE, "snapshot_paths": names,
        "runtime_patch_base": BASELINE, "runtime_patch_scope": ["pbrs-grpc"],
        "runtime_patch_sha256": sha(patch), "qualified": False,
        "intermediate_c10_source": C10_SOURCE,
        "scope": "Final source snapshots derive changes since the publication checkpoint. The runtime-only patch includes C10 reuse, C11 repairs, and the earlier serving-fixture difference from C8.",
    })
    generated["identical-benchmark/equivalence.json"] = encoded({"files": identical, "qualified": False})
    return generated


def day_snapshot():
    generated, files = {}, []
    sources = [
        (Q / "architecture-c8-day-launch-request.json", "architecture-c8-day-launch-request.json"),
        (Q / "architecture-c8-day-launcher.json", "architecture-c8-day-launcher.json"),
        (Q / "architecture-c8-day-launch.json", "architecture-c8-day-launch.json"),
        (Q / "architecture-c8-day-readiness.json", "architecture-c8-day-readiness.json"),
        (Q / "resource-architecture-c8-day/progress.json", "progress.json"),
    ]
    sources.extend((path, "harness/" + path.name) for path in sorted((Q / "architecture-c8-day-harness").iterdir()) if path.is_file())
    progress = None
    for path, name in sources:
        assert not path.is_symlink(), path
        data = path.read_bytes()
        generated["architecture-c8-day-snapshot-at-pack/" + name] = data
        files.append({"source_path": path.relative_to(Q).as_posix(), "snapshot_path": name,
                      "bytes": len(data), "sha256": sha(data)})
        if name == "progress.json":
            progress = json.loads(data)
    launch = json.loads(generated["architecture-c8-day-snapshot-at-pack/architecture-c8-day-launch.json"])
    assert launch["source"] == BASELINE
    if "source" in progress:
        assert progress["source"]["commit"] == BASELINE
    started = progress.get("started_unix_seconds")
    if started is None:
        started = datetime.datetime.fromisoformat(launch["started_utc"]).timestamp()
    generated["architecture-c8-day-snapshot-at-pack/snapshot.json"] = encoded({
        "snapshot_utc": now(), "source": BASELINE, "qualified": False, "complete": False,
        "state": "incomplete_snapshot", "observed_progress_state": progress["state"],
        "elapsed_wall_seconds_estimate": max(0, time.time() - started),
        "requested_duration_seconds": launch["requested_duration_seconds"], "files": files,
        "terminal_record_observed": (Q / "architecture-c8-day-termination.json").exists(),
        "scope": "A pack-time copy of atomic launch/progress metadata and harness only. Live events, logs, and test binary are excluded. This subset does not establish a completed day or qualify the final candidate.",
    })
    return generated


def publication_snapshot(plan_path, observed):
    if plan_path is None:
        return {}, {"included": False, "reason": "No explicit finalized publication plan supplied."}
    plan_path = plan_path.resolve(strict=True)
    assert plan_path.is_relative_to(Q) and not plan_path.is_symlink(), plan_path
    plan = checked_json(plan_path, observed)
    assert plan["source"] == SOURCE and plan["finalized"] is True and plan["qualified"] is False
    generated, entries = {}, []
    for item in plan["files"]:
        relative = item["path"]
        assert safe_name(relative), relative
        path = ROOT / relative
        assert not path.is_symlink() and path.resolve().is_relative_to(ROOT), path
        if path.is_relative_to(DEST):
            assert path.parent == DEST and path.name in ("README.md", "results.json"), path
            name = "published-documents/capsule/" + path.name
        else:
            assert relative == "README.md" or relative == "TODO.md" or relative.startswith("docs/"), relative
            assert not relative.startswith("docs/evidence/"), "only this capsule's explicit README/results may be nested"
            name = "published-documents/" + relative
        data = path.read_bytes()
        assert sha(data) == item["sha256"], path
        observed[path] = {"bytes": len(data), "sha256": sha(data)}
        assert name not in generated
        generated[name] = data
        entries.append({"path": relative, "archive_path": name, "sha256": sha(data)})
    return generated, {"included": True, "plan_path": str(plan_path), "plan_sha256": digest(plan_path), "files": entries}


def main():
    global SOURCE, PINS_SHA256
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="write the immutable capsule only after root grants packaging")
    parser.add_argument("--pins-sha256", help="immutable final architecture-c11-source-pins.json SHA256")
    parser.add_argument("--pipeline-state", type=Path, default=Q / "architecture-c11-pipeline-state.json")
    parser.add_argument("--extra-gate", action="append", type=Path, default=[], help="additional completed control state; repeatable")
    parser.add_argument("--require-expanded", action="store_true", help="require the completed final expanded native campaign")
    parser.add_argument("--published-plan", type=Path, help="JSON: source, finalized=true, qualified=false, files=[{path, sha256}]")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"state": "prepared; no capsule writes", "source_input": str(PINS),
                          "destination": str(DEST), "qualified": False}))
        return 0
    assert __debug__, "Run without Python -O; safety assertions must remain enabled"
    assert args.pins_sha256 and re.fullmatch(r"[0-9a-f]{64}", args.pins_sha256)
    assert digest(PINS) == args.pins_sha256, "immutable final source-pins input changed"
    PINS_SHA256 = args.pins_sha256
    SOURCE = json_file(PINS)["candidate_runtime"]
    assert re.fullmatch(r"[0-9a-f]{40}", SOURCE) and SOURCE != C10_SOURCE
    assert not DEST.is_symlink()
    for name in ("raw.tar.gz", "manifest.json", "check.py"):
        assert not (DEST / name).exists(), "immutable capsule already exists: " + name
    if DEST.exists():
        assert all(path.is_file() and path.name in ("README.md", "results.json") for path in DEST.iterdir())
        assert not any(DEST.iterdir()) or args.published_plan is not None, "Existing publication documents require a finalized snapshot plan"
    observed = {}
    require_expanded = args.require_expanded or (Q / "architecture-c11-counter-expanded/campaign.json").exists()
    gates = validate_gates(observed, args.pipeline_state, args.extra_gate, require_expanded)
    writers, inaccessible = live_writers()
    assert not any(path in writers for path in observed), "gate metadata is still open for writing"
    paths, omitted = select_inputs(writers)
    generated = source_snapshot() | day_snapshot()
    publications, publication_metadata = publication_snapshot(args.published_plan, observed)
    generated.update(publications)
    for name in ("record.py", "run-rust"):
        path = ROOT / "work" / name
        data = path.read_bytes()
        generated["controllers/" + name] = data
        observed[path] = {"bytes": len(data), "sha256": sha(data)}
    generated["controllers/architecture-c8-counter-summary.py"] = (Q / "architecture-c8-counter-summary.py").read_bytes()
    generated["controllers/package-architecture-c10-evidence.py"] = Path(__file__).read_bytes()
    generated["controllers/reclaim-rpc-cache.py"] = (Q / "reclaim-rpc-cache.py").read_bytes()
    for name in ("run-architecture-c11-day.py", "publish-architecture-c11-day.py"):
        path = ROOT / "work" / name
        if path.is_file():
            data = path.read_bytes()
            generated["controllers/" + name] = data
            observed[path] = {"bytes": len(data), "sha256": sha(data)}
    generated["packaging/gates.json"] = encoded(gates)
    generated["packaging/publication-snapshot.json"] = encoded(publication_metadata)
    generated["packaging/scope.json"] = encoded({
        "source": SOURCE, "baseline": BASELINE, "qualified": False,
        "captured_utc": now(), "source_pins_sha256": PINS_SHA256,
        "live_writers_seen": {str(path): users for path, users in writers.items()},
        "inaccessible_same_uid_proc": inaccessible,
        "limits": [
            "Retained source-pinned checks and selected diagnostic comparisons; no universal speed or production-readiness proof.",
            "Native allocator-counter release runs and Callgrind runs remain qualified=false, including losses and missing metrics.",
            "The initial C10 Rust 1.88 build is retained as rejected provenance and is never a measurement comparator.",
            "The failed C10 workspace and first C11 Serving run remain failed historical results with their actual source and counts.",
            "The C8 day snapshot is explicitly incomplete and belongs to an older runtime; it does not qualify the final candidate.",
            "Known live writable logs and bytecode caches are omitted. Selected regular-file hashes are checked again before publication.",
        ],
    })
    entries, executables = [], []
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / "raw.tar.gz"
    with archive.open("xb") as output:
        with gzip.GzipFile(fileobj=output, mode="wb", mtime=0, filename="") as zipped:
            with tarfile.open(fileobj=zipped, mode="w|", format=tarfile.PAX_FORMAT) as capsule:
                def add(name, data):
                    assert safe_name(name), name
                    member = tarfile.TarInfo(name)
                    member.mode, member.size, member.mtime = 0o644, len(data), 0
                    member.uid = member.gid = 0
                    member.uname = member.gname = ""
                    capsule.addfile(member, io.BytesIO(data))
                    entries.append({"path": name, "bytes": len(data), "sha256": sha(data)})

                for path in sorted(paths):
                    assert not path.is_symlink() and path.resolve().is_relative_to(Q), path
                    name = path.relative_to(Q).as_posix()
                    with path.open("rb") as stream:
                        header = stream.read(512)
                    binary = header.startswith(b"\x7fELF") or (
                        path.stat().st_mode & 0o111 and b"\0" in header and not header.startswith(b"#!")
                    )
                    if binary:
                        metadata = {"path": name, "bytes": path.stat().st_size, "sha256": digest(path)}
                        executables.append(metadata)
                        actual = {key: metadata[key] for key in ("bytes", "sha256")}
                        if path in observed:
                            assert observed[path] == actual, path
                        observed[path] = actual
                        continue
                    data = path.read_bytes()
                    metadata = {"bytes": len(data), "sha256": sha(data)}
                    if path in observed:
                        assert observed[path] == metadata, "validated input changed: " + name
                    observed[path] = metadata
                    add(name, data)
                generated["omitted-executables.json"] = encoded({"executables": executables})
                generated["packaging/omitted-files.json"] = encoded({"files": omitted})
                for name, data in sorted(generated.items()):
                    add(name, data)
    assert len({entry["path"] for entry in entries}) == len(entries)
    # Compare all frozen inputs to their actual archived bytes. The live day
    # metadata is intentionally a once-read snapshot and is excluded here.
    for path, metadata in observed.items():
        assert path.stat().st_size == metadata["bytes"] and digest(path) == metadata["sha256"], path
    assert digest(PINS) == PINS_SHA256
    verify_frozen_checkout("architecture-c11", SOURCE)
    verify_frozen_checkout("architecture-c10", C10_SOURCE)
    verify_frozen_checkout("architecture-c8", BASELINE)
    manifest = {
        "schema": "pbrs.architecture-capsule.v1", "source": SOURCE, "baseline": BASELINE,
        "qualified": False, "archive": {"name": archive.name, "bytes": archive.stat().st_size,
                                        "sha256": digest(archive)},
        "logical_bytes": sum(entry["bytes"] for entry in entries), "files": entries,
        "scope": "Final C11 decoded-buffer reuse and repairs, with failed C10 history; diagnostic comparisons and checks only.",
    }
    with (DEST / "manifest.json").open("x") as output:
        json.dump(manifest, output, indent=2)
        output.write("\n")
    with (DEST / "check.py").open("x") as output:
        output.write(CHECK_PY)
    subprocess.run(["python3", str(DEST / "check.py")], check=True)
    print(json.dumps({"files": len(entries), "logical_bytes": manifest["logical_bytes"],
                      "archive_bytes": archive.stat().st_size, "source": SOURCE, "qualified": False}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
