#!/usr/bin/env python3
"""Successor cache reclaim after explicit adjudication of failed control matching.

No files are written without --execute. That option declares that root has
granted reclamation, builds and captures are quiet, and no further build using
this RPC cache is planned. A caller must also pin the immutable C11 input file
by SHA256. ASAN uses its own fresh target directory after this step.
"""

import argparse
import datetime
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import traceback


Q = Path(__file__).resolve().parent
ROOT = Q.parents[1]
CACHE = ROOT / "work/rpc-target"
PINS = Q / "architecture-c11-source-pins.json"
CHECKOUT = ROOT / "work/architecture-c11"
BASELINE = "9d6fb9c416fc32732450fd78d32ee16ff8b802de"
STATE = Q / "architecture-c11-rpc-cache-reclaim-v2.json"
INVENTORY = Q / "architecture-c11-rpc-cache-reclaim-v2-inventory.json"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def metadata(path):
    return {"bytes": path.stat().st_size, "sha256": digest(path)}


def source(checkout):
    return {
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
        "status": subprocess.check_output(
            ["git", "status", "--porcelain", "--untracked-files=all"], cwd=checkout, text=True
        ).strip(),
    }


def check_path():
    if not __debug__:
        raise RuntimeError("Run without Python -O; safety assertions must remain enabled")
    if (CACHE != ROOT / "work/rpc-target" or CACHE.is_symlink()
            or CACHE.parent.is_symlink() or CACHE.resolve() != CACHE or not CACHE.is_dir()):
        raise ValueError("Only the existing, nonsymlink work/rpc-target cache may be reclaimed")
    if not shutil.rmtree.avoids_symlink_attacks:
        raise ValueError("This platform lacks fd-based safe directory reclamation")


def proc_scan():
    active, inaccessible, zombies = [], [], []
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            status = (proc / "status").read_text()
            if re.search(r"^State:\s+Z\b", status, re.MULTILINE):
                zombies.append(int(proc.name))
                continue
            maps = (proc / "maps").read_text()
            cmdline = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            mapped = [line for line in maps.splitlines() if str(CACHE) in line]
            if mapped or str(CACHE) in cmdline:
                active.append({"pid": int(proc.name), "cmdline": cmdline, "cache_mappings": mapped})
            for descriptor in (proc / "fd").iterdir():
                try:
                    target = os.readlink(descriptor)
                except FileNotFoundError:
                    continue
                if target == str(CACHE) or target.startswith(str(CACHE) + "/"):
                    active.append({"pid": int(proc.name), "fd": descriptor.name, "target": target})
            for name in ("cwd", "exe"):
                try:
                    target = os.readlink(proc / name)
                except FileNotFoundError:
                    continue
                if target == str(CACHE) or target.startswith(str(CACHE) + "/"):
                    active.append({"pid": int(proc.name), "reference": name, "target": target})
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            inaccessible.append(int(proc.name))
    return {"active_users": active, "inaccessible_live_same_uid_proc": inaccessible, "zombies": zombies}


def assert_quiet(scan):
    assert not scan["active_users"], scan
    assert not scan["inaccessible_live_same_uid_proc"], scan


def verify_build(directory, checkout):
    path = directory / "build.json"
    spec = importlib.util.spec_from_file_location(
        "retained_build_" + directory.name.replace("-", "_"), checkout / "scripts/build-rpc-bench.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    record = module.validate_record(path, directory / "rpc-bench")
    return {"record": str(path), "record_sha256": digest(path), "source": record["source"],
            "tools": record["tools"], "binary": str(directory / "rpc-bench"),
            "binary_sha256": record["binary_sha256"]}


def freeze_json(path, inputs):
    data = path.read_bytes()
    inputs[str(path)] = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
    return json.loads(data)


def validate_expanded(candidate, binary_sha256, inputs):
    """Validate actual expanded captures, including every RPC outcome."""
    directory = Q / "architecture-c11-counter-expanded"
    campaign = freeze_json(directory / "campaign.json", inputs)
    summary = freeze_json(Q / "architecture-c11-counter-expanded-all-counters.json", inputs)
    plan = freeze_json(Q / "architecture-c11-measurement-plan.json", inputs)
    argv = plan["native_expanded"]
    for flag, expected in (("--output", str(directory)), ("--source-checkout", str(CHECKOUT)),
                           ("--phase", "native")):
        assert argv[argv.index(flag) + 1] == expected, flag
    assert digest(Path(argv[argv.index("--binary") + 1])) == binary_sha256
    declared_build = json.loads(Path(argv[argv.index("--build-record") + 1]).read_text())
    assert declared_build["source"]["commit"] == candidate and declared_build["binary_sha256"] == binary_sha256
    assert campaign["schema"] == "pbrs.counter-campaign.v1"
    assert campaign["source"] == summary["source"] == candidate
    assert campaign["state"] == summary["state"] == "finished"
    assert campaign["phase"] == summary["phase"] == "native"
    assert campaign["passed"] is True and summary["passed"] is True and summary["controller_passed"] is True
    assert campaign["qualified"] is False and summary["qualified"] is False
    assert campaign["binary_sha256"] == summary["binary_sha256"] == binary_sha256
    assert not summary["raw_failed_captures"] and not summary["missing_ledgers"] and not summary["status_errors"]
    controller = CHECKOUT / "scripts/grpc-counter-campaign.py"
    constants = runpy.run_path(str(controller))
    assert digest(directory / "controller.py") == digest(controller) == campaign["controller_sha256"]
    inputs[str(controller)] = metadata(controller)
    inputs[str(directory / "controller.py")] = metadata(directory / "controller.py")
    cells_per_batch = len(constants["PAIRS"]) * len(constants["SHAPES"]) * campaign["repeats"]
    expected_groups = set(itertools.product(
        campaign["payloads"], (False, True), ("identity", "gzip"),
        (tuple(level) for level in campaign["load_levels"]),
    ))
    assert campaign["expected_groups"] == len(campaign["groups"]) == len(expected_groups)
    observed_groups, raw_paths, batch_paths = set(), set(), set()
    actual = {key: 0 for key in ("offered_rpcs", "dispatched_rpcs", "completed_rpcs", "successful_rpcs",
                               "failed_rpcs", "timeouts", "queue_overflows", "unstarted_rpcs", "unfinished_rpcs")}
    for group in campaign["groups"]:
        identity = (group["payload_bytes"], group["tls"], group["compression"],
                    (group["connections"], group["in_flight"]))
        assert identity in expected_groups and identity not in observed_groups
        observed_groups.add(identity)
        group_path = directory / group["path"]
        assert group_path.resolve().is_relative_to(directory) and group_path.parent == directory
        ledger = freeze_json(group_path / "ledger.json", inputs)
        assert ledger["source"] == candidate and ledger["binary_sha256"] == binary_sha256
        assert ledger["qualified"] is False and ledger["rows"]
        assert all(not row["failed_captures"] for row in ledger["rows"])
        assert len(group["captures"]) == len(group["rpc_counts"]) == 2
        assert sorted(group["rpc_counts"])[1] == 2 * sorted(group["rpc_counts"])[0]
        for capture in group["captures"]:
            batch = group_path / capture["path"]
            assert batch.resolve().is_relative_to(group_path) and batch.parent == group_path and batch not in batch_paths
            batch_paths.add(batch)
            report = freeze_json(batch / "report.json", inputs)
            assert capture["passed"] is True and capture["total"] == capture["passed_cells"] == cells_per_batch
            assert len(report["runs"]) == len(report["cells"]) == cells_per_batch
            assert report["rpc_count"] in group["rpc_counts"]
            assert report["head"] == candidate and report["dirty"] is False and report["source_verified"] is True
            assert report["binary_sha256"] == binary_sha256 and report["passed"] is True
            assert all(report[key] is True for key in (
                "binary_unchanged", "source_unchanged", "harness_script_unchanged", "campaign_controller_unchanged"
            ))
            assert report["build_record"] == declared_build
            for index, run in enumerate(report["runs"]):
                path = batch / run["path"]
                assert path.resolve().is_relative_to(batch) and path not in raw_paths
                raw_paths.add(path)
                raw = freeze_json(path, inputs)
                assert run["passed"] is True and raw["passed"] is True
                assert raw["cell"] == report["cells"][index]
                metrics = raw["metrics"]
                assert not metrics["status_errors"]
                for key in actual:
                    expected = report["rpc_count"] if key in (
                        "offered_rpcs", "dispatched_rpcs", "completed_rpcs", "successful_rpcs"
                    ) else 0
                    assert metrics[key] == expected, (path, key, metrics[key])
                    actual[key] += metrics[key]
    assert observed_groups == expected_groups
    assert raw_paths == set(directory.glob("group-*/n-*/cell-*/run.json"))
    assert len(raw_paths) == campaign["expected_captures"] == summary["captures"] == summary["metrics_records"]
    assert campaign["expected_captures"] == len(expected_groups) * 2 * cells_per_batch
    assert actual == summary["actual_rpc_totals"]
    return {"source": candidate, "qualified": False, "captures": len(raw_paths),
            "groups": len(observed_groups), "actual_rpc_totals": actual,
            "summary_sha256": digest(Q / "architecture-c11-counter-expanded-all-counters.json")}


def prerequisites(pins_sha256, require_expanded=False):
    assert re.fullmatch(r"[0-9a-f]{64}", pins_sha256), "Expected immutable source-pins SHA256 required"
    assert digest(PINS) == pins_sha256, "C11 source-pins changed"
    pins = json.loads(PINS.read_text())
    candidate = pins["candidate_runtime"]
    assert re.fullmatch(r"[0-9a-f]{40}", candidate)
    assert pins["baseline_runtime"] == BASELINE and pins["qualified"] is False
    assert source(CHECKOUT) == {"head": candidate, "status": ""}
    checks_path = Q / "architecture-c11-checks-state.json"
    checks = json.loads(checks_path.read_text())
    assert checks["state"] == "passed" and checks["source"] == {"head": candidate, "status": ""}
    assert checks["checks"] and all(check["exit_code"] == 0 for check in checks["checks"])
    workspace = [check for check in checks["checks"] if check["name"] == "workspace"]
    assert len(workspace) == 1 and workspace[0]["totals"]["passed"] > 0
    assert workspace[0]["totals"]["failed"] == 0
    controls_path = Q / "architecture-c11-negative-controls-state.json"
    original_controls = json.loads(controls_path.read_text())
    assert original_controls["state"] == "failed" and original_controls["pin"] == candidate
    assert original_controls["source_pins_sha256"] == pins_sha256
    assert original_controls["positive"]["observed_expected_result"] is True
    original_checks = [check for control in original_controls["controls"] for check in control["checks"]]
    assert any(check["observed_expected_result"] is False for check in original_checks)
    adjudication_path = Q / "architecture-c11-negative-controls-adjudication.json"
    adjudication = json.loads(adjudication_path.read_text())
    assert adjudication["state"] == "passed" and adjudication["passed"] is True
    assert adjudication["pin"] == candidate and adjudication["qualified"] is False
    assert all(adjudication[key] is True for key in (
        "original_dispositions_preserved", "no_tests_run", "restored_clean", "frozen_unchanged",
        "source_pins_unchanged", "source_patches_verified"
    ))
    original_reference = adjudication["original_record"]
    original_path = Path(original_reference["path"])
    original_path = original_path if original_path.is_absolute() else Q / original_path
    assert original_path == controls_path and original_reference["state"] == "failed"
    assert original_reference["sha256"] == digest(controls_path)
    assert len(adjudication["validated_checks"]) == len(original_checks) == 4
    assert all(check["observed_expected_result"] is True for check in adjudication["validated_checks"])
    assert all(check["compile_succeeded_and_tests_ran"] is True and check["exit_code"] == 101
               for check in adjudication["validated_checks"])
    assert any(check["original_observed_expected_result"] is False for check in adjudication["validated_checks"])
    assert adjudication["positive"]["observed_expected_result"] is True
    assert adjudication["positive"]["compile_succeeded_and_tests_ran"] is True
    assert adjudication["positive"]["exit_code"] == 0
    assert adjudication["positive"]["source"] == {
        "head": candidate, "diff_sha256": hashlib.sha256(b"").hexdigest(), "untracked": {}
    }
    resolver_path = Q / "architecture-c11-resolver-negative-controls-state.json"
    resolver = json.loads(resolver_path.read_text())
    assert resolver["pin"] == candidate and resolver["state"] == "passed" and resolver["passed"] is True
    assert all(resolver[key] is True for key in ("restored_clean", "frozen_unchanged", "source_pins_unchanged"))
    assert resolver["positive"]["observed_expected_result"] is True
    assert resolver["controls"] and all(check["observed_expected_result"] is True
        for control in resolver["controls"] for check in control["checks"])
    builds = []
    for prefix, checkout_name in (("architecture-c8", "architecture-c8"),
                                  ("architecture-c10", "architecture-c10"),
                                  ("architecture-c11", "architecture-c11")):
        for suffix in ("-rpc-build", "-stable-rpc-build"):
            directory = Q / (prefix + suffix)
            if (directory / "build.json").exists():
                builds.append(verify_build(directory, ROOT / "work" / checkout_name))
    assert any(build["source"]["commit"] == BASELINE for build in builds)
    candidates = [build for build in builds if build["source"]["commit"] == candidate]
    assert candidates, "No verified retained final-candidate ELF"
    inputs = {str(PINS): metadata(PINS), str(checks_path): metadata(checks_path),
              str(controls_path): metadata(controls_path), str(resolver_path): metadata(resolver_path),
              str(adjudication_path): metadata(adjudication_path)}
    for name, expected in adjudication["immutable_inputs"].items():
        path = Path(name)
        checksum = expected["sha256"] if isinstance(expected, dict) else expected
        assert digest(path) == checksum, path
        inputs[str(path)] = metadata(path)
    captured_candidate_hashes = set()
    for campaign_name, phase in (("architecture-c11-counter-ab", "native"),
                                  ("architecture-c11-cpu-ab", "callgrind")):
        summary_path = Q / (campaign_name + "-summary.json")
        campaign_path = Q / campaign_name / "campaign.json"
        summary = json.loads(summary_path.read_text())
        campaign = json.loads(campaign_path.read_text())
        assert summary["passed"] is True and summary["controller_passed"] is True
        assert summary["qualified"] is False and summary["phase"] == phase
        assert campaign["state"] == "finished" and campaign["passed"] is True and campaign["qualified"] is False
        assert not any(summary[field] for field in (
            "failed_captures", "missing_data", "missing_keys", "extra_keys", "status_errors"
        ))
        assert campaign["versions"]["baseline"]["build_record"]["tools"] == campaign["versions"]["candidate"]["build_record"]["tools"]
        captured_candidate_hashes.add(campaign["versions"]["candidate"]["binary_sha256"])
        for version, commit in (("baseline", BASELINE), ("candidate", candidate)):
            retained = campaign["versions"][version]
            assert retained["source"]["commit"] == commit
            assert summary["source_pins"][version] == retained
            matches = [build for build in builds if build["source"] == retained["source"]
                       and build["binary_sha256"] == retained["binary_sha256"]]
            assert matches, "Campaign ELF has no retained verified build"
        inputs[str(summary_path)] = metadata(summary_path)
        inputs[str(campaign_path)] = metadata(campaign_path)
    preview_path = Q / "architecture-c11-resource-preview/report.json"
    preview = json.loads(preview_path.read_text())
    controller_path = CHECKOUT / "scripts/grpc-resource-campaign.py"
    validator = runpy.run_path(str(controller_path))["validate_report"]
    assert not validator(preview)
    assert preview["source"]["commit"] == candidate and preview["smoke"]["status"] == "passed"
    assert preview["exit_code"] == 0
    preview_elf = Q / "architecture-c11-resource-preview/resource-test"
    assert Path(preview["binary"]["path"]) == preview_elf
    assert digest(preview_elf) == preview["binary"]["sha256"]
    inputs[str(preview_path)] = metadata(preview_path)
    inputs[str(controller_path)] = metadata(controller_path)
    for build in builds:
        inputs[build["record"]] = metadata(Path(build["record"]))
        inputs[build["binary"]] = metadata(Path(build["binary"]))
        directory = Path(build["record"]).parent
        for name in ("build.stdout.jsonl", "build.stderr.log"):
            inputs[str(directory / name)] = metadata(directory / name)
    inputs[str(preview_elf)] = metadata(preview_elf)
    expanded = None
    assert len(captured_candidate_hashes) == 1
    if require_expanded:
        campaign = json.loads((Q / "architecture-c11-counter-expanded/campaign.json").read_text())
        assert any(build["binary_sha256"] == campaign["binary_sha256"] for build in candidates)
        assert campaign["binary_sha256"] in captured_candidate_hashes
        expanded = validate_expanded(candidate, campaign["binary_sha256"], inputs)
    return {"source": candidate, "source_pins_sha256": pins_sha256, "builds": builds,
            "frozen_inputs": inputs, "expanded": expanded, "qualification": False,
            "control_adjudication": {"path": str(adjudication_path), "sha256": digest(adjudication_path),
                                      "original_record": original_reference,
                                      "no_tests_run": True, "original_dispositions_preserved": True}}


def day_snapshot():
    checkout = ROOT / "work/architecture-c8"
    snapshot = {"source": source(checkout), "files": {}, "process_observations": []}
    assert snapshot["source"] == {"head": BASELINE, "status": ""}
    launch_path = Q / "architecture-c8-day-launch.json"
    launch = json.loads(launch_path.read_text())
    assert launch["source"] == BASELINE
    executable = Q / "resource-architecture-c8-day/resource-test"
    expected = launch["readiness"]["preview"]["binary"]["sha256"]
    assert digest(executable) == expected
    snapshot["test_executable"] = {"path": str(executable), **metadata(executable)}
    for relative in ("scripts/grpc-resource-campaign.py", "pbrs-grpc/tests/resource_qualification.rs", "Cargo.lock"):
        snapshot["files"][str(checkout / relative)] = metadata(checkout / relative)
    for path in sorted((Q / "architecture-c8-day-harness").iterdir()):
        if path.is_file():
            snapshot["files"][str(path)] = metadata(path)
    for name in ("architecture-c8-day-launch.json", "architecture-c8-day-launcher.json",
                 "architecture-c8-day-launch-request.json", "architecture-c8-day-readiness.json",
                 "architecture-c8-day-termination.json", "architecture-c8-day-publication.json"):
        path = Q / name
        snapshot["files"][str(path)] = metadata(path) if path.exists() else None
    progress_path = Q / "resource-architecture-c8-day/progress.json"
    snapshot["files"][str(progress_path)] = metadata(progress_path)
    progress = json.loads(progress_path.read_text())
    snapshot["progress"] = progress
    pids = {launch["pid"], launch["supervisor_pid"]}
    if progress.get("pid"):
        pids.add(progress["pid"])
    for pid in sorted(pids):
        proc = Path("/proc") / str(pid)
        try:
            raw = (proc / "stat").read_text()
            tail = raw[raw.rfind(")") + 2:].split()
            snapshot["process_observations"].append({"pid": pid, "state": tail[0], "start_ticks": tail[19],
                                                     "executable": os.readlink(proc / "exe")})
        except (FileNotFoundError, ProcessLookupError):
            snapshot["process_observations"].append({"pid": pid, "state": "not present"})
    return snapshot


def assert_day_unchanged(before, after):
    for field in ("source", "files", "test_executable", "progress"):
        assert before[field] == after[field], "C8 day metadata changed during reclamation: " + field


def cache_inventory():
    entries = []
    for path in sorted(CACHE.rglob("*")):
        stat = path.lstat()
        entry = {"path": path.relative_to(CACHE).as_posix(), "device": stat.st_dev,
                 "inode": stat.st_ino, "mode": stat.st_mode, "mtime_ns": stat.st_mtime_ns}
        if path.is_symlink():
            entry.update(kind="symlink", target=os.readlink(path))
        elif path.is_file():
            assert path.resolve().is_relative_to(CACHE), path
            entry.update(kind="file", bytes=stat.st_size, sha256=digest(path))
            after = path.stat()
            assert (stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns) == (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns
            ), path
        elif path.is_dir():
            entry.update(kind="directory")
        else:
            raise ValueError("Unexpected cache special file: " + str(path))
        entries.append(entry)
    return entries


def verify_inventory(entries):
    assert {path.relative_to(CACHE).as_posix() for path in CACHE.rglob("*")} == {item["path"] for item in entries}
    for item in entries:
        path = CACHE / item["path"]
        stat = path.lstat()
        assert (stat.st_dev, stat.st_ino, stat.st_mode, stat.st_mtime_ns) == (
            item["device"], item["inode"], item["mode"], item["mtime_ns"]
        ), path
        if item["kind"] == "symlink":
            assert path.is_symlink() and os.readlink(path) == item["target"], path
        elif item["kind"] == "file":
            assert not path.is_symlink() and stat.st_size == item["bytes"], path


def verify_inputs(inputs):
    for name, expected in inputs.items():
        assert metadata(Path(name)) == expected, "Frozen input changed: " + name


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="root grants this cache deletion; no further RPC-cache builds planned")
    parser.add_argument("--pins-sha256", help="immutable architecture-c11-source-pins.json SHA256")
    parser.add_argument("--require-expanded", action="store_true", help="also require final expanded native matrix with every raw RPC successful")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"state": "prepared; no deletion or metadata writes", "cache": str(CACHE)}))
        return 0
    if not args.pins_sha256:
        parser.error("--execute also requires --pins-sha256")
    state = {"state": "running", "started_utc": now(), "supervisor_pid": os.getpid(),
             "cache": str(CACHE), "cache_reclaimed": False, "qualification": False,
             "root_grant": "--execute; builds and captures quiet; no further RPC-cache build planned",
             "free_bytes_before": shutil.disk_usage(ROOT).free}
    with STATE.open("x") as stream:
        json.dump(state, stream, indent=2)
        stream.write("\n")
    try:
        check_path()
        assert not INVENTORY.exists(), "Retained inventory must not be overwritten"
        state["prerequisites"] = prerequisites(args.pins_sha256, args.require_expanded)
        state["day_before"] = day_snapshot()
        state["scan_before_inventory"] = proc_scan()
        atomic(STATE, state)
        assert_quiet(state["scan_before_inventory"])
        entries = cache_inventory()
        inventory = {"cache": str(CACHE), "source": state["prerequisites"]["source"],
                     "source_pins_sha256": args.pins_sha256, "created_utc": now(), "files": entries,
                     "logical_bytes": sum(item.get("bytes", 0) for item in entries)}
        with INVENTORY.open("x") as stream:
            json.dump(inventory, stream, indent=2)
            stream.write("\n")
        state["inventory"] = {"path": str(INVENTORY), **metadata(INVENTORY)}
        state["scan_after_inventory"] = proc_scan()
        atomic(STATE, state)
        assert_quiet(state["scan_after_inventory"])
        verify_inventory(entries)
        verify_inputs(state["prerequisites"]["frozen_inputs"])
        state["day_before_delete"] = day_snapshot()
        assert_day_unchanged(state["day_before"], state["day_before_delete"])
        check_path()
        state["scan_before_delete"] = proc_scan()
        assert_quiet(state["scan_before_delete"])
        atomic(STATE, state)
        shutil.rmtree(CACHE)
        assert not CACHE.exists() and not CACHE.is_symlink()
        state["cache_reclaimed"] = True
        atomic(STATE, state)
        state["scan_after_delete"] = proc_scan()
        assert_quiet(state["scan_after_delete"])
        verify_inputs(state["prerequisites"]["frozen_inputs"])
        assert digest(PINS) == args.pins_sha256
        state["day_after"] = day_snapshot()
        assert_day_unchanged(state["day_before"], state["day_after"])
        state.update(state="passed", completed_utc=now(),
                     logical_bytes_reclaimed=inventory["logical_bytes"], entries=len(entries),
                     free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(STATE, state)
        print(json.dumps({"state": state["state"], "record": str(STATE),
                          "logical_bytes_reclaimed": inventory["logical_bytes"], "free_bytes": state["free_bytes_after"]}))
        return 0
    except BaseException as error:
        state.update(state="failed", error=repr(error), completed_utc=now(), free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(STATE, state)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
