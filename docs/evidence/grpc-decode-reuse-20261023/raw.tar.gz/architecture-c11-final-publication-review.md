# Independent C11 publication review

Reviewed at 2026-10-23T06:10:50.445443+00:00 by `/root/compression_review`.

Conclusion: **no actionable issue found** in the reviewed versions. Their specification, ownership and performance statements preserve the scope of the evidence and retain unresolved production and performance gaps. This is a documentation review, not production certification.

## Exact reviewed versions

The first four files were reviewed in full. Only lines 1–55 of `docs/status.md` were reviewed; its whole-file hash pins the version, not an expanded review scope.

| File | SHA256 |
|---|---|
| `docs/benchmarks.md` | `d3c3fff0cbab98b7b2aa5ce13980af20cdcc4a0cf4843461ce1d7f8f7ee37683` |
| `docs/decisions/grpc-execution.md` | `00e6aca7115a0c61cf1ac237c4c4e6e077a9100d734a54371af1fb939e2905d4` |
| `docs/evidence/grpc-decode-reuse-20261023/README.md` | `3dcf7d6a1edb7e3e2b8ee4fa77d73a43a42251fee2e26b87afcb17e9b30a33cf` |
| `TODO.md` | `c29cbd74eac8faf406cbb96f0ed1a35979e09bc0d7825ab4928d1b736b03ff7c` |
| `docs/status.md` | `547465d0c7e4cb2c8830a8e251244444c4cff03330d3dc088c3e97532ae536c3` |

Runtime/current benchmark source: `beb4ecd9a9b2143c440892607d5b486318062b61`. Matched baseline: `9d6fb9c416fc32732450fd78d32ee16ff8b802de`.

## Evidence and limits checked

- Selected source comparisons: **568 captures / 21,300 successful RPCs**, including both sources. Expanded current matrix: **2,400 / 720,000**. Selected instruction campaign: **96 / 1,440**. Total **3,064 / 742,740**; offered/dispatched/completed/successful accounting reconciles, with no failures/timeouts. Checked the actual `architecture-c11-counter-ab-summary.json`, `architecture-c11-counter-expanded-all-counters.json` and `architecture-c11-cpu-ab-summary.json`.
- Workspace **3,771 passed / zero failed / nine existing ignores, 141 targets** and selected leak-detecting ASAN **746 / zero / one existing ignore** remain distinct. Focused counts overlap the workspace. The docs do not claim all-workspace sanitizer, complete platform/feature qualification or production readiness.
- Allocation tables distinguish cumulative requested bytes from retained memory/RSS, preserve losing cases and separate the full interop handler from isolated transport/codec attribution. Selected gains do not establish broad superiority.
- All **eight unique instruction cells** and the four rows outside the tonic ±2% band match the summaries. All eight C8-to-C11 instruction changes are under 0.4%. The retained `architecture-c11-client-upload-ir-review.md/json` conserves exclusive totals/edges: repeated writer output-scratch initialization explains the principal 1 KiB upload client instruction gap; common compressor initialization is equal. Allocation-counting Callgrind small-N diagnostics are not shipping CPU, latency or throughput qualification. No replacement is claimed implemented or measured.
- Ownership wording matches `DecodeCursor`, exhausted-cursor checks and unique `Bytes::try_into_mut` recovery. Retained Bytes/pbrs input keeps ownership. Actual capacity admission bounds **idle** storage to 4 MiB per stream / 16 MiB process-wide; active decoding and other memory are outside that budget. Cache rejection is a miss, not an RPC failure. Unpolled streams may retain bounded storage until polling/drop. Compression validation/output/history/member limits remain separate.
- `architecture-c11-resource-preview/report.json` records clean current source, **31.69866036800522 seconds**, nine cancelled cycles and final drain with zero accounted bytes/tokens/active calls. It is a preview, not a completed day or sustained Prost-cache proof.
- Updated day wording was reread after its earlier build-pending text changed. `resource-architecture-c11-day/progress.json` now records running state, clean current source and actual workload start **2026-10-23T06:07:05.090402+00:00**, consistent with the displayed **06:07 UTC**. No completed 24-hour result exists in the reviewed text. The standard pbrs fixture does not exercise the new Prost cache; separate sustained cache coverage remains unrun/unqualified.
- The pre-shape custom-Service deadline finding is explicitly source-reviewed; independent reproduction and repair remain pending. Proposed scheduling, encoding and decoding experiments remain proposals, not performance results.

No builds, new captures, tests or tracked-file edits were performed for this review. The raw-record capsule is assembled separately by its owner. Later day text may change only to reflect actually observed state; the owner must recheck changed text. This review applies to the hashes above and does not silently cover subsequent file changes.
