# C10 decoded-workspace design review

Independent, read-only review of the working candidate. No builds, tests or
measurements were run by this reviewer. `architecture-c10-design-review.json`
records the actual HEAD, tracked diff hash and individual changed/untracked file
hashes; the later clean qualification commit must pin the final source.

## Finding caught and corrected before qualification

The initial Prost override called `T::decode(&mut Bytes)` and assumed a fully
consumed cursor still owned its allocation. This is false for a last bytes field:
prost0.14.4 `encoding::bytes::merge` uses `copy_to_bytes`, and bytes1.12.1
`Bytes::split_to` at the entire remaining length moves the backing owner out,
replacing the cursor with a static empty value. An owned Vec field copies and
drops that temporary. The intended cache then sees zero capacity and misses.
A Sample with a trailing scalar masked this case; the benchmark's nested payload
body can be the last field, making it relevant to the targeted large bidi loss.

The candidate now uses a private `DecodeCursor` implementing Buf. A full-range
`copy_to_bytes` clones only that range's owner, then advances the original cursor;
partial ranges keep Bytes' normal split behavior and zero-length copies return an
empty Bytes. This preserves the exhausted original owner without an unconditional
keeper clone on scalar-only paths. Buf::Take forwards `copy_to_bytes` to its inner
Buf, so nested last-body fields also use the override. Other ordinary Buf reads
and advance retain their normal contiguous-input behavior.

The root added owned-last, nested-owned-last, shared-last, empty and malformed-last
cases. Those cases are present in source; their execution belongs to the final
qualification run, not this review. A shared Bytes field still owns a reference,
so `try_into_mut` declines reuse instead of allowing aliasing. Source inspection
finds the wrapper correction sound.

## Ownership and admission

- Only compressed WireStream decoding calls the reusable codec seam. Its public
  default transfers the input to the existing `decode_payload`, preserving pbrs
  and downstream codec ownership. Default paths leave no reusable allocation;
  zero capacity is explicitly declined without a lease or workspace Box.
- Successful decoding must leave an empty cursor, and Bytes must permit unique
  mutable ownership before conversion to Vec. Retained input or a partial cursor
  produces a cache miss. The transport does not force a copy or mutate aliased
  message backing. Decode errors clear the retained workspace.
- `DecodedWorkspace` owns its Vec and an optional non-Clone lease. Buffer fields
  drop before leases when discarding a workspace. Taking a buffer for active
  synchronous decode removes its idle lease; successful unique reclamation then
  reacquires a lease for the resulting full Vec capacity.
- The private budget uses checked addition and a single atomic compare-exchange
  modification order to enforce aggregate admission. Relaxed ordering is enough:
  the counter arbitrates capacity, while Rust ownership transfers actual storage.
  A lease releases once from Drop. Zero, oversize, exhausted-budget and overflow
  cases decline retention without becoming RPC errors.
- Policy is fixed at4 MiB per retained vector and16 MiB of idle Vec capacity per
  process. It is not a total cache-byte/RSS limit: Box records, allocator metadata,
  active decode output, codec state and application messages are outside it.
  Capacity, rather than used length, is charged. Global contention may reduce
  reuse for another connection but does not alter its accepted messages/statuses.

## Length, validation and cleanup

`read_bounded_into` clears old length and clips every read/probe to the current
message allowance. Reusing capacity larger than a later allowance does not expose
extra output bytes or relax its limit. Existing capacity can remain larger;
new reservations still use the bounded growth path and allocation checks.
Short reads, Interrupted handling, final EOF/overflow probing and output
initialization remain in the existing checked reader.

Gzip uses the same complete-member reader, checksums, trailing-input and member
admission checks. Deflate still requires complete consumption of exactly one
zlib stream. Zstd still creates message-local frame validation/history state and
checks standard/skippable frames, checksums, windows and count limits. Reusing
output does not reuse DEFLATE/Zstd history across gRPC messages.

WireStream releases its cache on decoded/framing/transport errors, deadlines,
clean stream completion and Drop. The new DATA-EOF release happens before waiting
for trailers, so a peer withholding trailers does not keep the decoded cache.
Streaming's local-cancel path releases before returning a cancellation result,
including cancellation detected after a successful poll. Cancellation through a
separate handle cannot synchronously mutate an otherwise unpolled owned reader;
its cached capacity stays charged until the reader observes cancellation or is
dropped. The documentation states that limitation explicitly.

## Costs that still require measurements

Uncompressed and default pbrs paths create no cache allocation. Every WireStream
has an additional optional workspace pointer (8 bytes on this target), and the
new dispatch/empty-owner checks add branches. Small owned Prost streams may pay
an initial workspace Box and reservation atomics while saving tiny allocations;
a one-message stream may never reuse what it briefly retains. A full-range Prost
bytes copy can promote Bytes ownership metadata before the owned-field copy.
These are real tradeoffs, not free optimizations.

The expanded source-paired matrix must retain identity/unary/bidi, native pbrs,
TLS and16-in-flight controls alongside the1 MiB gzip target. Measure requested
bytes, allocations and CPU separately from retained-capacity/peak-RSS diagnostics.
Also require actual-peer EOF/error/deadline/cancel cleanup, retained/shared input,
cache misses under contention, complete coding validation and same-channel
recovery. A lower cumulative requested-byte count does not justify hidden idle
memory growth or an unreported regression in small/uncompressed calls.

No additional correctness blocker was found in this snapshot after the
last-field fix. This is a source review, not a production qualification or a
performance acceptance. Final compilation, controls, sanitizer/resource checks
and matched captures remain authoritative for the pinned candidate.
