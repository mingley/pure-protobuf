#!/usr/bin/env python3
"""Read retained profiles and source only. No measurement, build, or source edit."""
from pathlib import Path
import collections,hashlib,json,statistics,subprocess
Q=Path('/workspace/pure-protobuf/work/qualification');ROOT=Q.parent.parent
P=Q/'architecture-c11-client-upload-ir-parse.py';ns={};exec(P.read_text().split('profiles=[]')[0],ns)
functions=json.loads((Q/'architecture-c11-client-upload-ir-functions.json').read_text())
leaf=json.loads((Q/'architecture-c11-client-upload-ir-leaf-edges.json').read_text())
buildpath=Q/'architecture-c11-stable-rpc-build/build.json';build=json.loads(buildpath.read_text())
assert build['source']['commit']=='beb4ecd9a9b2143c440892607d5b486318062b61'
assert '--release'in build['command'] and 'allocation-counts'in build['command']
rows=functions['function_rows'];fill=next(x for x in rows if x['function']=='0x0000000000163540');copy=next(x for x in rows if x['function']=='0x0000000000162b40')
edge_checks=[];actual=collections.Counter()
for p in functions['profiles']:
 record,own,edges,calls=ns['parse'](Path(p['path']))
 assert record['summary']==record['totals']==sum(own.values())
 for primitive in ['0x0000000000163540','0x0000000000162b40']:
  owncost=sum(v for k,v in own.items()if k[1]==primitive)
  inbound=sum(v for k,v in edges.items()if k[1][1]==primitive)
  assert inbound==owncost,(p['path'],primitive,owncost,inbound)
  edge_checks.append(dict(path=p['path'],function=primitive,self_ir=owncost,inbound_ir=inbound,difference=inbound-owncost))
 run=json.loads(Path(p['run']).read_text());metrics_path=Path(p['run']).parent/'metrics.json';metrics=json.loads(metrics_path.read_text())
 assert run['passed']and metrics['successful_rpcs']==p['rpc_count']
 assert all(metrics[k]==0 for k in ['failed_rpcs','timeouts','unstarted_rpcs','unfinished_rpcs','queue_overflows'])
 for k in ['offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs','failed_rpcs','timeouts']:actual[k]+=metrics[k]
for primitive,row in [('0x0000000000163540',fill),('0x0000000000162b40',copy)]:
 for transport in ['native','tonic']:
  inbound=sum(statistics.mean(e['ir'][transport])for e in leaf if e['callee'][1]==primitive)
  assert abs(inbound-row[transport+'_ir_per_rpc'])<1e-6
libc=Path('/usr/lib/x86_64-linux-gnu/libc.so.6')
disasm=Q/'architecture-c11-client-upload-ir-libc-disassembly.txt'
with disasm.open('x')as out:
 for lo,hi in [('0x163540','0x1636a0'),('0x162b40','0x162e40')]:
  result=subprocess.run(['objdump','-d','--start-address='+lo,'--stop-address='+hi,str(libc)],check=True,text=True,capture_output=True);out.write(result.stdout)
registry=ROOT/'work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f'
source_paths=[ROOT/'work/architecture-c11/pbrs-grpc/src/compression/gzip.rs',ROOT/'work/architecture-c11/rpc-bench/src/main.rs',ROOT/'work/architecture-c11/rpc-bench/Cargo.lock']+[registry/('flate2-1.1.10/src/'+n)for n in ['ffi/mod.rs','ffi/miniz_oxide.rs','zio.rs','mem.rs','gz/read.rs','gz/write.rs']]+[registry/'tonic-0.14.6/src/codec/compression.rs']
artifacts=[P,Q/'architecture-c11-client-upload-ir-functions.json',Q/'architecture-c11-client-upload-ir-leaf-edges.json',Q/'architecture-c11-cpu-ab-summary.json',Q/'architecture-c11-cpu-ab/campaign.json',Q/'architecture-c11-source-pins.json',buildpath,buildpath.parent/'build.stdout.jsonl',libc,disasm,Path(__file__)]+source_paths
flate2=[json.loads(line)for line in (buildpath.parent/'build.stdout.jsonl').read_text().splitlines()if '"reason":"compiler-artifact"'in line and '"name":"flate2"'in line]
assert len(flate2)==1 and 'miniz_oxide'in flate2[0]['features'] and 'any_zlib'not in flate2[0]['features']
net=functions['conserved_totals']['native_minus_tonic'];other=net-fill['native_minus_tonic']-copy['native_minus_tonic']
review=dict(qualified=False,review_passed=True,method='Read-only parsing of retained candidate client Callgrind Ir profiles at nice15; no new captures/builds/source edits',candidate_commit=build['source']['commit'],baseline_reference='Current C11 native/prost client versus current C11 tonic/prost client; both connect to tonic/prost server. Historical C8 source comparison not remeasured.',build=build,flate2_artifact=dict(package_id=flate2[0]['package_id'],features=flate2[0]['features'],profile=flate2[0]['profile']),scope=dict(payload_bytes=1024,payload='zero-filled application payload',shape='client_stream',request_messages=4,compression='gzip',compression_level=6,tls=False,connections=1,in_flight=1,counts=[10,20],repeats=2,client_profiles=8,actual_rpcs=dict(actual)),formula='For each repeat/function: (Ir(N20)-Ir(N10))/10; report mean of two slopes (equals median for two). No clamping of negative slopes.',totals=functions['conserved_totals'],native_over_tonic_percent=(functions['conserved_totals']['native_ir_per_rpc']/functions['conserved_totals']['tonic_ir_per_rpc']-1)*100,profiles=functions['profiles'],primitive_inbound_conservation=edge_checks,additive_groups=[dict(group='libc byte-fill primitive 0x163540',**{k:fill[k]for k in ['native_ir_per_rpc','tonic_ir_per_rpc','native_minus_tonic']}),dict(group='libc byte-copy/move primitive 0x162b40',**{k:copy[k]for k in ['native_ir_per_rpc','tonic_ir_per_rpc','native_minus_tonic']}),dict(group='all remaining exclusive functions',native_ir_per_rpc=functions['conserved_totals']['native_ir_per_rpc']-fill['native_ir_per_rpc']-copy['native_ir_per_rpc'],tonic_ir_per_rpc=functions['conserved_totals']['tonic_ir_per_rpc']-fill['tonic_ir_per_rpc']-copy['tonic_ir_per_rpc'],native_minus_tonic=other)],fill_edge_groups=dict(native_upload_write_with_status_ir=131144,native_upload_finish_ir=262288,tonic_upload_compress_ir=163984,upload_difference_ir=229448,native_decode_ir=51161,tonic_decode_ir=83947,decode_difference_ir=-32786,common_compressor_default_ir_each=620424,common_hashbuffers_default_ir_each=656608,remaining_fill_difference_ir=fill['native_minus_tonic']-229448+32786),leaf_edges=leaf,top_positive_exclusive=sorted(rows,key=lambda r:r['native_minus_tonic'],reverse=True)[:15],top_negative_exclusive=sorted(rows,key=lambda r:r['native_minus_tonic'])[:15],source_conclusion='The native write::GzEncoder path uses flate2 zio::Writer with32KiB Vec scratch. compress_vec calls compress_uninit; the measured miniz backend inherits the default compress_uninit, which zero-initializes all spare output before compressing. write/finish call this repeatedly. Tonic uses read::GzEncoder with initialized Read output and does not traverse compress_vec on upload. The retained direct caller edges place extra byte-fill work in the native write/finish path; they do not prove exact zeroed byte counts or shipping wall-time cost.',next_experiment='After current qualification, compare a safe bufread::GzEncoder<&[u8]> + bounded initialized output copy loop against the current write encoder at the same level, payloads and writer error semantics. Retain per-message independent gzip state/CRC/trailer completion, validate encoded/decode limits and multi-message isolation, compressed/incompressible and boundary payloads, allocation bytes and instructions. Avoid cross-message compressor caching initially; profile shows compressor initialization is common, whereas repeated writer scratch initialization is asymmetric.',limits=['Allocation-counts-enabled release artifacts: instructions include allocator instrumentation; not uninstrumented shipping CPU superiority or throughput/latency.','Small N10/20 and two repeats; slopes remove fixed startup approximately, not scheduling variations. Negative slopes and all profiles retained.','Client process only for this attribution. Server and complete matrix not attributed here.','Callgrind reports machine instructions; rep stos behavior and emulator-selected libc implementation do not translate1:1 to native elapsed time or memory bandwidth.','Stripped libc routines retain numeric names; primitive identity inferred from actual local disassembly, not nearest exported objdump label. Copy and move variants cannot be distinguished by this analysis.','Compiler inlining folds initialization into caller symbols; function identities are machine-code attribution, not a complete source-line or semantic operation partition.','Inclusive edges generally overlap; only direct inbound edges of these leaf primitives are added, after exact self-cost conservation.','No production code or benchmark harness change; no new experiment performed.'],inputs_sha256={str(p):ns['digest'](p)for p in artifacts})
out=Q/'architecture-c11-client-upload-ir-review.json'
with out.open('x')as f:json.dump(review,f,indent=2);f.write('\n')
md=f'''# C11 client-stream gzip instruction review

The retained profiles place the main extra work in the native gzip writer's output-buffer initialization. This is a concrete next optimization target; it is not a native wall-time speed claim.

Scope: C11 `{build['source']['commit']}`, Prost clients, Tonic/Prost server, h2c, one connection/one in flight, four1KiB zero-filled request messages, gzip level6. Eight existing client profiles cover N10/20 for two repeats and two clients. All120 actual RPCs succeeded, with zero failures or timeouts. The full selected CPU campaign separately passed96 captures/1440 RPCs. Build: release **with `allocation-counts`**, rustc1.99.1; binary SHA-256 `{build['binary_sha256']}`. Profiles include production native observability.

For each repeat: `(Ir20-Ir10)/10`; then average the two slopes. Native: **2,384,777.05 instructions/RPC**, Tonic: **2,236,524.95**, difference **148,252.10 (+6.629%)**. Native repeat range2,384,687.9–2,384,866.2; Tonic2,236,289.0–2,236,760.9. Historical C8→C11 total change is essentially flat in the accepted summary; this review attributes current C11 versus current Tonic only.

| Additive exclusive cost | Native Ir/RPC | Tonic Ir/RPC | Difference |
|---|---:|---:|---:|
| libc byte-fill primitive (`0x163540`) |1,776,283.20|1,579,673.35|+196,609.85|
| libc byte-copy/move primitive (`0x162b40`) |320,478.25|333,723.25|−13,245.00|
| All remaining functions |288,015.60|323,128.35|−35,112.75|
| **Total** |**2,384,777.05**|**2,236,524.95**|**+148,252.10**|

All eight exclusive-cost sums equal both the raw profile `summary:` and `totals:` exactly, and each summary matches its retained `run.json`. Their N/2N sums reproduce the accepted total. For both numeric libc primitives, all direct incoming edge costs also sum exactly to self cost in every profile. No negative differential was dropped.

The numeric fill primitive broadcasts the input byte to vector registers and stores it; its large branch executes `rep stos`. The numeric copy/move primitive loads source data and stores it to the destination. `objdump`'s nearest exported `_dl_mcount_wrapper` label is not the function's actual identity. The retained disassembly and libc hash are recorded.

| Direct incoming fill calls | Ir/RPC | Calls/RPC |
|---|---:|---:|
| Native `flate2::zio::Writer::write_with_status` |131,144|4|
| Native `flate2::zio::Writer::finish` |262,288|8|
| Tonic `codec::compression::compress` |163,984|8|

The upload-path difference is **+229,448 fill instructions/RPC**. Native decode-path fill is32,786 lower than Tonic; other fill edges differ by−52.15, giving the overall+196,609.85 fill delta. Common `CompressorOxide::default` fill620,424 and `HashBuffers::default` fill656,608 instructions/RPC are **identical**. This does not support blaming different compressor initialization, compression levels or backends for the difference.

The source agrees with the machine-code attribution. Native `gzip.rs:133` uses `flate2::write::GzEncoder`; Tonic `compression.rs:222` uses `flate2::read::GzEncoder`. Both use the single measured flate2 1.1.10 miniz backend (build artifact features recorded). `flate2/src/zio.rs:174` creates32KiB writer scratch. `write_with_status` and `finish` invoke `run_vec`; `mem.rs:389` routes `compress_vec` through `compress_uninit`. The miniz backend inherits `ffi/mod.rs:51`'s default implementation, whose `initialize_buffer` zeroes all supplied spare output before compression. Repeated write/finish calls therefore reinitialize spare output. The read interface instead supplies already initialized output through `zio::read` and `compress`. Caller attribution includes inlined code, so these are not exact source-line costs or proof of bytes cleared.

The smallest follow-up is an isolated, safe `bufread::GzEncoder<&[u8]>` plus initialized bounded output-copy loop, preserving independent gzip members, CRC/trailer completion, writer failures and existing resource limits. Test compressed/incompressible and boundary payloads and compare instructions plus allocations/bytes before changing runtime. A bounded initialized reusable chunk avoids both the read wrapper's input buffer and the writer's repeated spare-capacity initialization. Its cost and benefit remain **unmeasured**. Cross-message compressor caching adds lifecycle/RSS concerns and is not required to test this asymmetry.

Limits: these are small-N, allocation-instrumented instruction diagnostics for one client workload. Inlining, stripped symbols and repeated-string instructions limit source-level and native-time inference. Do not sum arbitrary inclusive call edges. No builds, captures, tracked edits, runtime changes or new qualification claims were made. Full paths, hashes, raw function differentials and edge conservation are in the adjacent JSON and its input artifacts.
'''
mdpath=Q/'architecture-c11-client-upload-ir-review.md'
with mdpath.open('x')as f:f.write(md)
print(json.dumps(dict(review=str(out),review_sha256=ns['digest'](out),markdown=str(mdpath),markdown_sha256=ns['digest'](mdpath),totals=review['totals'],actual_rpcs=dict(actual),all_conservation_checks_passed=True),indent=2))
