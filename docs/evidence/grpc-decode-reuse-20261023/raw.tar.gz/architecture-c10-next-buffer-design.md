# Next buffer changes after decoded reuse

Read-only source review of frozen candidate `a675b61fe2775e336f33474c58342764cea814a8`.
No source changes, builds, tests or measurements were performed for this note.
Byte counts below describe operations requested by source code, not observed CPU
instructions, cache traffic or allocation-site attribution. C10's matched captures
must establish the current result before another component changes.

## Recommended order

1. Remove the old-capacity term from the initial logical read size, then qualify
   decoded reuse and retain every regression/control cell. The prepared patch is
   `architecture-c10-bounded-initialization.patch`; it is not applied by this review.
2. Prototype **bounded plaintext encode scratch retention** separately. It addresses
   an explicit repeated allocation without replacing a wire-format parser.
3. Compare a **bounded decoded-output staging loop** with the current direct-read
   loop on changing message sizes. This exchanges initialization for copying;
   neither wins from source inspection alone.
4. Evaluate **compressed-output reservation/ownership** as its own change. A smaller
   hint helps compressible payloads but can cost more growth on incompressible ones.
5. Consider a backend or output-append redesign only if fresh profiles show the
   remaining work matters. `decompress_uninit` alone does not remove initialization
   on the current flate2 Rust backends.

## What decoded reuse still writes

`compression/mod.rs::read_bounded_into` clears the recovered Vec's length, reads an
8 KiB stack lookahead, copies that lookahead into the Vec, then calls
`out.resize(capacity, 0)` before the decoder reads directly into the remaining tail.
The chosen capacity includes the old Vec capacity, clipped to the current decoded
allowance. A later small allowance still bounds every read and the overflow probe;
large spare capacity is not permission to decode extra bytes.

For an already warm output allocation with capacity C and output D >= 8192, the
first resize requests initialization of `min(C, budget) - 8192` heap bytes. The
stack buffer also starts as 8192 initialized zero bytes. The decoder subsequently
overwrites the initialized output range. The source does not prove which writes
LLVM retains, how much memset costs, or which cache level serves them.

| Warm sequence | Source-level consequence |
|---|---|
| Repeated `1 MiB + 5 B`, exact capacity | Each later message requests initialization of 1,040,389 heap bytes after the 8 KiB lookahead; the initial 8 KiB is also copied. |
| `1 MiB + 5 B` then 8,193 B, unchanged large decode allowance | The small second message can still request roughly 1 MiB of tail initialization before producing its final byte and reaching EOF. |
| Large message then <=8,191 B | The initial lookahead reaches EOF, so the early return avoids the large heap resize. |
| Large message then 8,193 B, allowance explicitly reduced to 8,193 B | Capacity is clipped to the smaller allowance; only one heap tail byte is initialized. |

These are candidate CPU/memory costs, **not additional heap allocation requests**
when the retained capacity suffices. They cannot explain a remaining requested-byte
counter gap by themselves.

The recovered Vec has length zero because the successful cursor was consumed.
Although its old allocation once held initialized bytes, safe Vec APIs no longer
carry that prefix length. Recording the old length in a scalar and restoring it
with `set_len` would require unsafe code, forbidden in the compression module.
A 2026 host compiler does not change the declared base MSRV of Rust 1.85.

## Immediate correction: separate logical size from physical capacity

The proposed patch removes `.max(out.capacity())` from the first logical-capacity
calculation. `reserve` already checks actual physical capacity and skips allocation
when that storage suffices. Therefore a retained large allocation can satisfy all
the original bounded growth steps without becoming the next small message's first
initialized/read span. No lower-level inflater, new unsafe code or wire policy is
needed for this correction.

The patch includes a Read spy with a 1 MiB retained Vec, 8,193 output bytes, a tiny
compressed-length hint and a larger 2 MiB allowance. It checks output and continuous
ownership of the same allocation, then requires the largest requested read slice to
stay proportional to current output, rather than old retained capacity. The bound
is twice output length, not an assertion of an exact implementation chunk size.
Source predicts the old path requests a 1,040,384-byte slice and the proposed path
at most 8,192 bytes; these are not reported as executed test results.

The tradeoff is additional bounded lookahead copying for a steady large output.
With a sub-8-KiB hint and `D = 1 MiB + 5 B`, the restored logical growth boundaries
are 8,16,32,64,128,256,512,1024 KiB, then EOF. The source requests eight complete
8 KiB lookahead copies plus the final five bytes: 65,541 bytes total. The initial
warm-direct path copies only its first 8,192 bytes. Thus the proposed correction
adds 57,349 copied bytes per such message while requesting that many fewer heap
zero bytes. It still copies about 6.25% of D, far below the full-output staging
alternative. These operations can have different CPU/cache costs; the matched
campaign must measure the net effect rather than call it a speed improvement.

## Concrete decoder alternatives

| Approach | What it changes | Limits / decision |
|---|---|---|
| Current initialized direct read | Initial 8 KiB copy, then direct decoder writes to initialized Vec tail | Good baseline; warm large/small variation may initialize unused tail. Keep until measured. |
| Reuse one 8 KiB stack buffer and append each filled chunk | Removes heap-tail zero filling; appends initialize Vec length safely by copying produced bytes | Adds one copy of approximately D decoded bytes and more read-loop calls. Keeps the existing Read-based format/checksum/member/window validators. Strongest bounded low-risk experiment. |
| Initialize bounded output windows, such as 8/32/64 KiB, and read directly | Bounds unused initialization after a short final message; no full-output staging copy | Still initializes roughly D bytes for sustained large output; window size trades call count against unused final zeroing. Must retain the final one-byte overflow/EOF probe and complete input validation. |
| `flate2::Decompress::decompress_vec` | Safe append API manages Vec length without local unsafe code and never grows it itself | This is the raw DEFLATE/zlib layer, not the current gzip member/checksum wrapper. Current miniz and zlib-rs flate2 backends still initialize the supplied spare span. Not a demonstrated no-zero win. |
| `decompress_uninit` over Vec spare capacity | Exposes MaybeUninit output to the backend | The caller still needs a safe way to publish initialized Vec length. Current Rust backend fallback zeroes the target; moving initialization into a dependency is not removing it. |
| `ReadBuf` / new std I/O APIs | Can represent initialized and filled regions separately | std Read::read_buf/BorrowedBuf are unavailable on the base 1.85 profile; the available later nightly source still marks them unstable. Tokio ReadBuf exists, but its safe initialization path zeroes memory and asserting initialization requires unsafe. No direct solution for these synchronous Read decoders. |
| Preserve an initialized owner through codec decode | Could retain a nonzero initialized length rather than recover an exhausted cursor | Requires a different codec/output ownership seam, such as a logical-offset Buf over an unchanged owner. It must distinguish validated consumption, never copy retained input, and avoid unconditional keeper clones. Larger API/representation work; do not replace the current ownership correction without profiles. |

Dependency source is decisive here. In locked flate2 1.1.10,
`src/mem.rs::decompress_vec` calls `decompress_uninit` over the Vec spare capacity.
`src/ffi/mod.rs::InflateBackend::decompress_uninit` defaults to
`initialize_buffer`, which writes zeroes over that entire slice before converting
it to `[u8]`. Both `ffi/miniz_oxide.rs` and `ffi/zlib_rs.rs` implement `decompress`
without overriding this default. The requested default backend is miniz_oxide
0.9.1; confirm activated features for each benchmark because Cargo feature
unification can select another backend. The lockfile alone is not an activation
record.

Optional ruzstd 0.9.0 has `FrameDecoder::decode_all_to_vec`, but its implementation
also resizes output to capacity with zeroes before decoding. It does not preserve
the native wrapper's separate frame/window/checksum/count policy automatically.
Its `collect_to_writer` can append already decoded internal output, which still
copies and would require careful coupling to the existing admission checks.
The optional zstd profile has a documented higher MSRV of 1.87.

A direct gzip append backend would need to preserve RFC1952 headers and optional
fields, CRC32 and ISIZE checks, every concatenated member, malformed later members,
trailing-data rejection and count admission before reset. Deflate must still consume
exactly one complete zlib stream. Moving below GzDecoder to avoid a memset creates
that implementation and verification burden; it should not be bundled with a
buffer-window comparison.

## Additional proposed C11 control: cold short messages

`architecture-c11-small-cold-path.patch` keeps cold compressed output at or below
the decoder's 8 KiB lookahead on the ordinary codec decode path. It does not call
the ownership-preserving reuse hook or create a workspace. This ties the threshold
to the existing algorithmic lookahead, rather than to a benchmark payload size.
Existing warm workspaces still serve later short/empty messages, so a large-small
stream retains its storage reuse. A later large cold message can still establish a
workspace after unique recovery and admission.

This avoids the ownership-preserving Prost adapter, first cache Box and reservation
atomics on common short cold streams. It also gives up repeated-small output reuse;
the net allocation/CPU effect is a measurement question. At exactly 8,192 output
bytes the initial lookahead still requires a subsequent EOF probe, and a larger
compressed hint can reserve more than output length. Do not describe the policy
as proving no growth allocation for every short compressed input.

The proposed unit control covers cold zero/one/1 KiB/lookahead-boundary outputs,
then a first just-over-lookahead output, then warm short and empty outputs while
holding the same allocation continuously. Expand matched 1 KiB gzip controls across
all five RPC shapes and endpoint pairings before selecting the policy. The existing
identity controls and native-client instruction checks remain required.

## Next: bounded plaintext encode scratch

`wire/encode.rs::EncodeScratch::with_payload` owns a BytesMut, reserves the full
protobuf payload, serializes it, compresses it, then discards capacity above 64 KiB.
The `1 MiB + envelope` case therefore requests fresh plaintext storage on every
stream message. So does a nominal 64 KiB body once its envelope crosses that cap.
Unlike decoded input, this scratch never leaves the stream or aliases an
application's returned message, so ownership recovery is straightforward.

The next bounded experiment should retain this scratch under an explicit idle
capacity lease, charging actual BytesMut capacity. Release that lease while the
scratch is active; reacquire after successful compression; a budget miss discards
the allocation and must not fail the RPC. Free the buffer before releasing a retained
lease. Error/cancel/EOF/Drop paths must release it even if a surrounding stream
object remains alive. Keep the existing per-message limits and independent
compressor history for each message.

Do not simply raise the 64 KiB constant: many parked streams would each retain a
message-sized allocation. Decide explicitly whether encode and decode share one
process-wide retention allowance or have separate finite allowances; separate
16 MiB budgets mean up to 32 MiB idle vector capacity, not 16 MiB. Record scratch
record/lease size and outbound-future size separately from retained buffer bytes.
A lease or Box added to EncodeScratch changes every OutBatch's layout, including
uncompressed paths, even when it causes no heap allocation.

A later serializer-to-compressor streaming interface could avoid whole-message
plaintext scratch for suitable codecs. It is a separate design: WireOut methods
and Prost's contiguous BufMut adapter currently shape error handling and output
ownership, and a staging adapter can introduce its own copies. The bounded
workspace is the smaller experiment with a direct known repeated-allocation cost.

## Separately: compressed-output hint and ownership

Both `wire/encode.rs::encode_msg` and the compressed `append_frame` path reserve
`5 + plaintext_len / 2 + 32` bytes before compression. A 1 MiB zero body can therefore
reserve roughly 512 KiB for about 1 KiB of compressed output. `OutBatch::take_frame`
and `flush` replace the sink, so ping-pong traffic repeats the reservation.
Appending several tiny compressed frames before flush can also request a large
additional reservation despite existing spare capacity.

A smaller fixed or capped initial hint is easy to prototype, but incompressible
payloads may pay more reallocations/copies, and changing payload distributions can
fool a previous-message size predictor. Compare a conservative capped hint, a
bounded prior-output predictor, and existing behavior across compressibility and
message order. Do not infer the winner from zero-filled payloads alone.

Preserving a mutable remainder while handing a prefix to HTTP/2 is the larger
ownership alternative. It must handle in-flight prefix aliases and backpressure:
reclaim only when unique, fall back without copying retained wire bytes, and charge
idle backing capacity separately from active outbound bytes. That change should
not be mixed with an encode-scratch lease or decoder output policy.

## Measurements needed before selection

Keep the same source-paired old/new matrix and raw data. Add deterministic zero,
random and structured/mixed payloads; repeated sizes and alternating large/small
sizes; 1 KiB, 64 KiB and 1 MiB bodies; cold/warm streams; owned Prost, shared Bytes,
and lazy pbrs codecs; client/server/client-streaming/server-streaming/bidi sides;
identity and compressed controls; TLS and multiple in-flight RPCs.

For the decoded staging/window experiment, use a small deterministic codec control
in addition to the real Prost nested-last-body fixture. Count allocations/requested
bytes separately from CPU instructions, source-qualified profiles, wall time,
retained capacity and peak RSS. A profile that assigns substantial cost to output
initialization/copying, or a repeatable case-level CPU improvement, is needed to
promote the experiment. There is currently no such measurement in this note.

For bounded encode scratch, isolate scratch retention from hint changes. Require
cache-hit/miss and aggregate-capacity diagnostics, paused-stream memory controls,
error/cancel/EOF cleanup, malformed/limit behavior and same-channel recovery.
For any lower-level inflater change, rerun independent malformed/member/checksum/
trailing/frame-count/window oracles and feature/MSRV profiles before performance
acceptance. No source cost model establishes production readiness or superiority.
