# Handler isolation review

Reviewed source: `a675b61fe2775e336f33474c58342764cea814a8`.
Scope: read-only source review. No control, test, benchmark, profile or build was run. The proposed controls below are **NOT RUN**.

## Finding

The server currently polls HTTP/2 and application RPC futures on the same connection task. A handler that returns `Pending` promptly is supported well. A handler, interceptor, codec or destructor that spends a long time inside one synchronous call can stop that connection's protocol progress and every sibling RPC. A ready queue avoids polling sleeping handlers; it does not make a running `Future::poll` preemptible.

The minimum change that separates protocol progress is a separate owned handler driver per connection. That change alone does **not** isolate a small unary RPC from an expensive sibling handler: both still share the handler driver's thread of execution. For that mixed workload, independently scheduled per-RPC tasks are the smallest direct design on a multithread runtime with a spare worker. Neither design can preempt the expensive poll. Neither protects a current-thread runtime without moving application execution onto other threads.

## Source relationships

| Code position | What it does |
| --- | --- |
| `pbrs-grpc/src/server/connection.rs:476` | Explicitly runs admitted RPCs on the connection task, using concrete `FuturesUnordered` nodes. |
| `connection.rs:527` | Steady loop polls admitted RPCs before polling the connection at line530. A child poll can occupy this call indefinitely. |
| `connection.rs:546` | Timed/draining path uses a biased select with admitted work first, then accept, drain, age, idle, force-close and keepalive-death branches. Branch order cannot interrupt a poll already running. |
| `connection.rs:719` | Admitted child owns the RPC semaphore permit and optional busy lease through dispatch completion. Its first poll invokes `dispatch.dispatch(...)` directly. |
| `connection.rs:750` | `poll_admitted` delegates to `FuturesUnordered::poll_next`; it is not a Tokio task boundary. |
| `pbrs-grpc/src/transport/h2.rs:803` | Connection polling delegates to backend `poll_accept_with`. |
| `pbrs-grpc/src/h2_backend/server.rs:452` | Backend accept first advances `poll_closed`; line540 delegates to the HTTP/2 connection state machine. Receive, flush and control-frame progress require this owner to be polled. |
| `pbrs-grpc/src/server/dispatch.rs:161` | Dispatch invokes logging/interceptor hooks and constructs the service future. `SingleDispatch::poll` at line152 directly polls that future. Moving only the returned future misses synchronous construction and interceptor work. |
| `pbrs-grpc/src/server/rpc.rs:1524` | Invokes the user's handler closure synchronously, then races the returned future with reset handling. Streaming does the same at line1577. |
| `pbrs-grpc/src/wire/frame_reader.rs:245` | Decompression and protobuf decode are synchronous work inside the RPC's poll. A size cap bounds output, not the duration of an arbitrary user codec. |
| `pbrs-grpc/src/server/drain.rs:199` | Handler/reset select polls the handler first. A reset branch cannot run until that poll returns. It also polls the handler once more after reset notification at line214. |
| `pbrs-grpc/src/wire/send.rs:615` | Deadline uses Tokio timeout around a future. A timer wake does not interrupt a running user poll. |
| `pbrs-grpc/src/keepalive.rs:64` | Keepalive has a spawned task, but the connection owner must still drive the socket/control-frame state machine. This task alone cannot guarantee an outgoing PING is flushed or its ACK processed. |
| `pbrs-grpc/src/server/accept.rs:1422` | Per-core serving creates current-thread Tokio runtimes. Spawning more tasks on that same shard does not supply another execution thread. |

Existing coverage has a narrower contract. `server/connection/inline_dispatch_tests.rs:25` parks its handler through `watch::Receiver::wait_for`, so the poll returns `Pending`. `ready_set_tests.rs:56` establishes that unrelated connection wakes do not scan4096 sleeping handlers. Both are useful; neither exercises a handler that stays inside one poll.

## What can and cannot be promised

HTTP/2 stream multiplexing requires the connection state machine to continue running. It does not specify a universal PING latency or make arbitrary application CPU cooperative. The concrete production risk here is coupling protocol progress to application execution, rather than a measured timing SLA violation. This review does not prove a new compliance failure or a performance ranking.

With an independent transport owner and an available execution thread, PING/SETTINGS/GOAWAY, socket I/O, flow control and reset parsing can continue while one handler poll runs. A reset becoming visible in the HTTP/2 state is distinct from the blocked handler's cancellation wrapper observing it. Likewise, a timer firing is distinct from the same blocked handler future being dropped.

Tokio cancellation/abort is cooperative at the task boundary. It cannot safely drop a future while that future is executing on another thread. Its RPC permit, byte charges, buffers and busy lease remain owned until the running poll returns and cleanup occurs. Do not release them early merely because a reset, deadline or drain grace elapsed: that would admit replacement work while the original memory/CPU is still live.

An application that blocks every runtime worker can starve both per-RPC tasks and the transport owner. A current-thread runtime can be stalled by a single such poll. `spawn_blocking` is also not preemptive, and transparently running arbitrary asynchronous service futures on a blocking thread is not a small compatible substitution. Hard isolation from a stuck application requires a separate execution domain with explicit ownership/capacity, or a process boundary. It cannot promise recovery from an indefinitely stuck task without additional application/process policy.

## Design choices

| Design | Protocol owner isolated from one user poll? | Small unary independent of that poll? | Cost and boundary |
| --- | --- | --- | --- |
| Current connection + FU | No | No | Efficient ready queue; one child poll can block everything on the socket. |
| One owned handler driver per connection, retaining FU | Yes, with a spare worker | No | One driver/task plus a bounded handoff channel per connection. All RPCs still share one handler driver. Useful only if the stated contract is protocol isolation. |
| One owned task per admitted RPC | Yes, with a spare worker | Yes, with runnable capacity | Task allocation/scheduling and lifecycle bookkeeping per RPC. Replaces the inline child owner; do not simply layer detached tasks on top of it. Requires cancellation/panic/join ownership. |
| Inline first poll, then handoff | No guarantee | No guarantee | The first arbitrary poll can already block. Timing its duration afterward cannot undo the stall. |
| Explicit trusted inline mode | Conditional | Conditional | Suitable only with an explicit cooperative handler/codec/hook contract. Handler size, payload size or method name cannot prove that contract. |
| Separate bounded application executor | Yes, if transport threads do not run user work | Potentially, subject to executor capacity | Larger runtime/API/affinity decision, particularly for per-core serving. Still cannot preempt a user poll; saturation policy must be explicit. |

For a first change on the normal multithread Tokio path, prefer a bounded, owned per-RPC task design if the requirement includes small-unary isolation. A per-connection driver is a smaller protocol-only step but should not be described as solving the mixed workload. Preserve the FU approach as a measured cooperative/explicit policy only if its contract is intentionally offered. No allocation or latency improvement is established by this review; a task-based candidate would need fresh matched measurements.

## Ownership requirements before any implementation

1. Acquire the existing process RPC permit before creating runnable application work. Keep it with that work through handler **and response** completion. Keep HTTP/2 stream limits, connection limits and decoded/outbound byte budgets. `accept.rs:1617` returns no process semaphore when the limit is unset; a new executor must not silently advertise a global task bound in that configuration. The configured HTTP/2 stream cap is per connection, not a process-wide bound.
2. Use owned data for handoff. Capture `take_accept_facts()` and shared request headers on the connection thread immediately at `connection.rs:574`; those thread-local facts cannot be fetched later on an arbitrary worker. Move the request/respond handles, dispatch `Arc`, configuration, peer information, byte tracker, channelz attribution, permit and busy lease together.
3. Invoke `dispatch()` inside the owned application task, not on the transport thread before spawning. This includes synchronous service-future construction and interceptors. Audit remaining connection-side observer/rejection callbacks at lines585,611,657 and684: user-provided callbacks there can still block the protocol owner. A claim of isolating all user code requires moving or explicitly constraining those hooks too.
4. Timestamp admission and preserve an absolute deadline across handoff. `Rpc::deadline()` at `rpc.rs:353` computes `now()+duration`, and `InboundRpc::from_rpc` stamps its deadline at line1372. A new queue must not give a request a fresh full timeout after waiting there. Carry the accepted-time deadline/elapsed budget into preparation; interceptor caps can only tighten it. Add a queued-deadline control before claiming this property.
5. Own task completion, panic and connection termination. Dropping a `JoinHandle` detaches work; it does not cancel it. Use an explicit task owner/completion mechanism, request cancellation on socket termination/drain, retain permits until actual cleanup, and keep existing reset/drop guards effective. Avoid a second unbounded completion queue.
6. Keep graceful drain's protocol and application outcomes separate: stop admission, send/flush GOAWAY, allow existing cooperative calls to finish, enforce wire grace, then cancel owned work. A poll that never returns cannot be forcibly reclaimed by a Tokio abort. Do not claim a strict handler-reclamation deadline or drop channelz/socket ownership while claiming still-running work is gone.
7. Preserve cancellation through response streaming, including `CancelOnDrop`/`HoldCancel` at `drain.rs:243` and line288, inbound-drop cancellation, waiter deregistration and server observer end events. Do not recreate an unbounded waiter per loop while adding task supervision.

## Next independent-peer control: event ordering, not a latency target

Use a separate raw HTTP/2 peer driven on its own OS thread/runtime. Run the server first on a multithread runtime with at least one worker available after a single application poll is occupied. Keep the test coordinator/release watchdog outside that server runtime. Explicitly configure finite connection/RPC/byte budgets and count accepted sockets so every request below demonstrably shares one connection.

Prepare four service methods:

- `Heavy`: accepts and verifies a complete valid64KiB gzip message, then enters a custom future whose **single poll** sets `entered` and waits on an atomic release gate without returning. This deliberate fixture occupies one execution thread; an async `Notify` wait is not an equivalent control. Retain a Drop witness and verify the decoded payload digest.
- `Small`: returns a tiny unary message and OK trailers.
- `Park`: cooperatively waits for request cancellation, recording cancellation/drop witnesses.
- `Deadline`: cooperatively stays pending under a known client timeout, recording preparation and completion witnesses.

Perform separate subcases so cancellation, drain and flow control do not accidentally satisfy one another:

1. Complete HTTP/2 SETTINGS/PING exchange first. Admit `Park` and `Deadline` and witness their entry. Start `Heavy`; wait for its `entered` witness. Only then send a fresh uniquely identified PING and `Small` HEADERS/DATA on that same connection.
2. While the heavy release gate is still closed, require peer-observed PING ACK and complete valid `Small` response/message/trailers. A separate watchdog eventually opens the gate even on failure; the outer guard is only a finite test-hang limit, not an arbitrary service latency claim.
3. In a reset subcase, send `RST_STREAM(CANCEL)` to the already admitted cooperative `Park` stream while `Heavy` remains gated. Require the cancellation/drop witness and a subsequent successful unary. Do not require the actively executing `Heavy` future itself to be dropped before its poll returns.
4. In a deadline subcase, witness the cooperative `Deadline` handler's entry before gating `Heavy`; allow its actual deadline to expire and require exact DeadlineExceeded completion before releasing `Heavy`. For a new queued executor, add a distinct request admitted before its timeout but not yet dispatched; prove queue residence does not reset its remaining timeout.
5. In a drain subcase, signal server drain from the external coordinator after the heavy-entry witness. Require actual GOAWAY bytes to reach the peer while the gate is closed, correct handling of existing streams, and no new application admission beyond the advertised GOAWAY boundary. Release `Heavy`, then require complete cleanup. Test force-close/wire grace separately; do not confuse it with preemptive user-task cleanup.
6. In a flow-control subcase, send/receive additional bounded DATA on a cooperative sibling stream and witness WINDOW_UPDATE/progress while the heavy poll is gated. Keep request bodies and response handles owned and drained correctly so an unread body cannot fill the shared connection window and manufacture a false scheduler failure.
7. Finally release `Heavy`, await every handler/task drop witness, verify all RPC permits and byte charges return to their baseline, and make a recovery RPC. Assert no detached work, duplicate trailers, hidden retries or replacement work exceeding the configured cap.

Expected causal separation, still **unmeasured**: the current design fails the gated PING and small-unary milestones; one independent connection handler driver can satisfy PING but cannot satisfy `Small`/cooperative sibling deadline/reset milestones while its sole driver is inside `Heavy`; per-RPC execution can satisfy those milestones with spare workers. Repeat the current-thread/per-core variant to document its limitation rather than assuming a spawn creates a thread.

After this deterministic control, a separate representative workload could use bounded cooperative CPU work and compressible/incompressible64KiB gzip data. Measure mixed-load tail latency, transport responsiveness, allocations, requested bytes, task/worker saturation and cancellation/drain cleanup with matched sources. Do not turn a finite test guard or the synthetic gated poll into a performance or production-readiness claim.
