# C11 final selected allocation tables — qualification draft only

No tracked edits. Source summary is complete and passes; Expanded results remain pending; the completed CPU scope is appended below. All numbers below come from the actual selected summary.

**C8 `9d6fb9c4` → C11 `beb4ecd9` · Rust 1.99.1 · Linux x86_64 · shared host.**
Same harness and locks. **568 captures, 21,300 successful RPCs**, with all offered,
dispatched and completed counts reconciled and zero errors/timeouts/overflows.
Two balanced ABBA repeats, N=25/50; 71 selected workload scopes. Representative
rows below use prost, plaintext HTTP/2, one connection and one in-flight call.
Gzip level 6; zero-filled application payloads; four messages per streaming leg.

## Source gains: requested bytes/RPC

| Native side | Workload | C8 before | C11 current | Source change |
|---|---|---:|---:|---:|
| Server | Bidi, 1 MiB gzip | 27.5 MiB | 18.5 MiB | -32.6% |
| Client | Bidi, 1 MiB gzip | 28.5 MiB | 19.5 MiB | -31.5% |
| Server | Upload, 64 KiB gzip | 1,516.3 KiB | 964.4 KiB | -36.4% |
| Client | Server stream, 64 KiB gzip | 1,671.6 KiB | 1,119.8 KiB | -33.0% |

The 64 KiB gzip upload server is also 19.0% below its fresh tonic byte control;
the 64 KiB server-stream client is 18.7% below. Each source pair improves in both
repeats. These are cumulative allocation requests, not retained memory or RSS.

## Remaining selected byte gaps

| Native side | Workload | C11 current | Fresh tonic/prost | More |
|---|---|---:|---:|---:|
| Client | Bidi, 1 KiB identity | 54.1 KiB | 40.2 KiB | +34.6% |
| Server | Bidi, 1 KiB identity | 43.5 KiB | 33.0 KiB | +32.0% |
| Server | Bidi, 1 MiB gzip | 18.5 MiB | 15.7 MiB | +18.2% |
| Client | Bidi, 1 MiB gzip | 19.5 MiB | 16.7 MiB | +17.1% |
| Client | Upload, 1 MiB gzip | 11.9 MiB | 10.5 MiB | +13.5% |

Do not use these N=25/50 identity medians as the pending expanded N=200/400
medians. Do not reuse C8's older tonic column. Pbrs full-interop routes remain
in the raw ledger and are not a codec-only comparison with minimal prost handlers.

## Observed source increases — retain even below 2%

| Native side and workload | Metric | C8 | C11 | Change | Repeat directions |
|---|---|---:|---:|---:|---|
| Server Server stream, 1 MiB gzip | MiB/RPC | 14.93 | 15.36 | +2.88% | mixed |
| Server Server stream, 1 MiB gzip | allocations/RPC | 82.20 | 83.96 | +2.14% | mixed |
| Client Bidi, 1 KiB identity | allocations/RPC | 38.04 | 38.66 | +1.63% | higher in both |
| Client Unary, 1 KiB identity | allocations/RPC | 8.10 | 8.18 | +0.99% | higher in both |
| Client Unary, 1 KiB identity | KiB/RPC | 9.62 | 9.70 | +0.86% | higher in both |

The 1 KiB identity unary client byte increase is 0.857%; the matched tonic-to-tonic
source control rises 0.866% too. Keep the native increase, but do not attribute it
to a workspace field or other site without allocation attribution. Mixed-repeat
increases are not repeatable causal regressions established by two samples.

All values are actual medians; percentages here are ratios of unrounded medians.
The raw summary separately retains paired ratios, minima/maxima and repeat
classification. The table is a readable selection, not a filtered loss inventory.

The companion `architecture-c11-allocation-loss-ledger.json` retains **all 112**
native byte/count groups, their same-side fresh tonic and tonic-to-tonic source
controls. **45** groups have a higher source median; **64** have at least one
higher-cost repeat. There is no 2% cutoff, and no group count is a statistical
significance test. All full-interop pbrs groups remain included separately from
canonical prost groups. The complete source summary retains nonnative endpoint,
context-switch, coarse CPU and missing-counter rows as well.

No CPU, native-client instruction, latency, throughput, broad speed, production
or C11 day claim follows from these allocation results. C8's running day stays
at C8. Final current-table selection waits for the actual expanded summary.

## Completed C11 instruction diagnostic — no source CPU gain

Actual **96 captures and 1,440 successful RPCs**, zero errors/timeouts, from
`architecture-c11-cpu-ab-summary.json`. Two balanced ABBA repeats, N=10/20,
prost, plaintext HTTP/2, one connection and one in-flight call; 12 pair/workload
scopes, both endpoints under Callgrind. These now include native clients as well
as servers. Binaries are release builds **with allocation counting enabled**.

**Million instructions/RPC.** Ratios use unrounded medians; the comparator is
its fresh current same-side tonic/prost control.

| Native side | Workload | C11 | tonic/prost | Difference | Diagnostic band |
|---|---|---:|---:|---:|---|
| Client | Upload, 1 KiB gzip | 2.385 | 2.237 | +6.63% | higher |
| Server | Bidi, 1 KiB gzip | 2.834 | 2.774 | +2.17% | higher |
| Client | Bidi, 1 KiB gzip | 2.831 | 2.786 | +1.61% | tie band |
| Client | Upload, 64 KiB gzip | 10.589 | 10.710 | -1.13% | tie band |
| Client | Bidi, 64 KiB gzip | 11.931 | 12.138 | -1.71% | tie band |
| Server | Bidi, 64 KiB gzip | 11.857 | 12.069 | -1.75% | tie band |
| Server | Upload, 64 KiB gzip | 1.939 | 2.037 | -4.80% | lower |
| Server | Upload, 1 KiB gzip | 1.063 | 1.163 | -8.61% | lower |

All eight native instruction changes against C8 are under 0.4% in magnitude and
within the existing 2% band. **Do not market the allocation changes as a C11 CPU
gain.** Four current tonic comparisons are inside that band. The two measured
higher-cost cases (+6.63% client upload, +2.17% server bidi at 1 KiB) and two
lower-cost cases (-8.61% server upload at 1 KiB, -4.80% at 64 KiB) remain scoped
instrumented diagnostics, not shipping CPU, latency or throughput qualification.

For a compact main page, show those four outside-band rows and state that the
other four are ties; retain this complete table and every actual range in the
capsule. Expanded allocation medians and final source-qualified sanitizer results
remain pending. No tracked edits or additional captures were made for this draft.
