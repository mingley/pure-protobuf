#[derive(Default)]
struct SpawnHangProbe {
    child_pending: AtomicUsize,
    dropped: AtomicUsize,
    stay_pending: bool,
}

impl SpawnHangProbe {
    fn pending() -> Arc<Self> {
        Arc::new(Self {
            stay_pending: true,
            ..Self::default()
        })
    }
}

struct SpawnHangGuard<'a>(&'a AtomicUsize);

impl Drop for SpawnHangGuard<'_> {
    fn drop(&mut self) {
        self.0.fetch_add(1, Ordering::Release);
    }
}

async fn drive_spawned_cancel<F: std::future::Future>(
    future: F,
    probe: &SpawnHangProbe,
    label: &str,
) -> F::Output {
    let deadline = Instant::now() + Duration::from_millis(800);
    let mut future = std::pin::pin!(future);
    std::future::poll_fn(|cx| {
        assert!(
            Instant::now() < deadline,
            "spawned cancellation stalled: {label}; child_pending={}, handler_drop={}",
            probe.child_pending.load(Ordering::Acquire),
            probe.dropped.load(Ordering::Acquire),
        );
        cx.waker().wake_by_ref();
        future.as_mut().poll(cx)
    })
    .await
}

async fn await_spawned_cancel_admission<T: std::fmt::Debug>(
    call: &mut Call<T>,
    probe: &SpawnHangProbe,
    started: &AtomicUsize,
    finished: &AtomicUsize,
    child_done: &AtomicUsize,
) {
    started.store(0, Ordering::Relaxed);
    finished.store(0, Ordering::Relaxed);
    child_done.store(0, Ordering::Relaxed);
    probe.child_pending.store(0, Ordering::Relaxed);
    probe.dropped.store(0, Ordering::Relaxed);
    drive_spawned_cancel(
        std::future::poll_fn(|cx| {
            let result = std::pin::Pin::new(&mut *call).poll(cx);
            assert!(result.is_pending(), "SpawnHang returned before cancel: {result:?}");
            if started.load(Ordering::Relaxed) == 1
                && probe.child_pending.load(Ordering::Acquire) == 1
            {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        probe,
        "handler admission and cancellation-child Pending poll",
    )
    .await;
    assert_eq!(finished.load(Ordering::Relaxed), 0);
    assert_eq!(child_done.load(Ordering::Relaxed), 0);
    assert_eq!(probe.dropped.load(Ordering::Acquire), 0);
}

async fn await_spawned_cancel_drop(
    probe: &SpawnHangProbe,
    finished: &AtomicUsize,
    child_done: &AtomicUsize,
) {
    drive_spawned_cancel(
        std::future::poll_fn(|_| {
            if child_done.load(Ordering::Relaxed) == 1
                && probe.dropped.load(Ordering::Acquire) == 1
            {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        probe,
        "spawned child cancellation and actual parent destruction",
    )
    .await;
    assert_eq!(finished.load(Ordering::Relaxed), 0, "handler completed");
    assert_eq!(probe.child_pending.load(Ordering::Acquire), 1);
    assert_eq!(child_done.load(Ordering::Relaxed), 1);
    assert_eq!(probe.dropped.load(Ordering::Acquire), 1);
}
