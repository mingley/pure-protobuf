"""Finish frozen C10 evidence sequentially; retain and stop on any failure."""
import datetime, hashlib, importlib.util, json, os, runpy, shutil, subprocess, sys, time, traceback
from pathlib import Path

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
CWD = ROOT / 'work/architecture-c10'
PINS = json.loads((Q / 'architecture-c10-source-pins.json').read_text())
STATE = Q / 'architecture-c10-pipeline-state.json'

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save():
    temporary = STATE.with_suffix('.tmp')
    temporary.write_text(json.dumps(state, indent=2) + '\n')
    temporary.replace(STATE)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def source():
    return dict(head=subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=CWD, text=True).strip(),
                status=subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=all'], cwd=CWD, text=True).strip())

def run(name, seconds, argv, cwd=CWD, extra=None):
    state['active'] = name
    save()
    prefix = Q / ('architecture-c10-' + name)
    assert not prefix.with_suffix('.json').exists(), 'retained phase must not be overwritten'
    command = ['python3', str(ROOT / 'work/record.py'), str(prefix), str(seconds), *argv]
    result = subprocess.run(command, cwd=cwd, env=env | (extra or {}))
    record = json.loads(prefix.with_suffix('.json').read_text())
    state['phases'].append(dict(name=name, record=str(prefix.with_suffix('.json')),
                               sha256=digest(prefix.with_suffix('.json')), exit_code=record['exit_code'],
                               duration_seconds=record['duration_seconds']))
    save()
    assert result.returncode == record['exit_code'] == 0, name
    assert source() == state['source_before'], 'frozen source changed'

state = dict(state='running', active='waiting_for_checks_and_release_build', started_utc=now(),
             supervisor_pid=os.getpid(), qualified=False, source_before=source(), phases=[],
             limits=['Shared host; original C8 day remains active against its own source.',
                     'Allocator-counter release binaries; instruction diagnostics do not qualify shipping speed.',
                     'No reuse of C8 soak qualification for C10.'])
env = os.environ.copy()
env.update(CARGO_BUILD_JOBS='1', CARGO_TARGET_DIR=str(ROOT / 'work/rpc-target'), RUSTUP_TOOLCHAIN='stable')
save()
try:
    assert state['source_before'] == dict(head=PINS['candidate_runtime'], status='')
    deadline = time.monotonic() + 7200
    while True:
        checks = json.loads((Q / 'architecture-c10-checks-state.json').read_text())
        assert checks['state'] != 'failed', 'source-pinned check failure requires review'
        build_path = Q / 'architecture-c10-rpc-build-record.json'
        build = json.loads(build_path.read_text()) if build_path.exists() else None
        if build is not None:
            assert build['exit_code'] == 0, 'source-pinned release build failed'
        if checks['state'] == 'passed' and build is not None:
            break
        assert time.monotonic() < deadline, 'qualification prerequisites timed out'
        time.sleep(2)
    state['checks_sha256'] = digest(Q / 'architecture-c10-checks-state.json')
    assert checks['source'] == dict(head=PINS['candidate_runtime'], status='')
    spec = importlib.util.spec_from_file_location('c10_build', CWD / 'scripts/build-rpc-bench.py')
    build_module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(build_module)
    verified = build_module.validate_record(Q / 'architecture-c10-rpc-build/build.json', Q / 'architecture-c10-rpc-build/rpc-bench')
    assert verified['source']['commit'] == PINS['candidate_runtime']
    state['binary_sha256'] = verified['binary_sha256']
    for relative in ['scripts/grpc-load-smoke.py', 'scripts/dominance-ledger.py', 'rpc-bench/src/main.rs']:
        assert digest(CWD / relative) == digest(ROOT / 'work/architecture-c8' / relative), relative
    save()

    run('resource-preview-run', 1800,
        [str(ROOT / 'work/run-rust'), 'nice', '-n', '10', 'python3', 'scripts/grpc-resource-campaign.py',
         '--source', PINS['candidate_runtime'], '--output', str(Q / 'architecture-c10-resource-preview'),
         '--duration', '30', '--build-profile', 'release', '--seed', '20261002',
         '--memory-bytes', '1073741824', '--max-fds', '128', '--max-uid-processes', '4096'])
    report = json.loads((Q / 'architecture-c10-resource-preview/report.json').read_text())
    validator = runpy.run_path(str(CWD / 'scripts/grpc-resource-campaign.py'))
    errors = validator['validate_report'](report)
    assert not errors, errors
    assert report['source']['commit'] == PINS['candidate_runtime'] and report['smoke']['status'] == 'passed'

    run('negative-controls-run', 3600,
        ['python3', str(Q / 'architecture-c10-negative-controls.py'), '--execute'])
    controls = json.loads((Q / 'architecture-c10-negative-controls-state.json').read_text())
    assert controls['state'] == 'passed', controls['state']

    plan = json.loads((Q / 'architecture-c10-measurement-plan.json').read_text())
    run('native-counter-run', 1800, plan['command'])
    run('native-counter-summary-run', 120,
        ['python3', str(Q / 'architecture-c10-ab-summary.py'), '--campaign', str(Q / 'architecture-c10-counter-ab'),
         '--output', str(Q / 'architecture-c10-counter-ab-summary.json')])

    cpu = plan['command'].copy()
    for flag, value in [('--output', str(Q / 'architecture-c10-cpu-ab')),
                        ('--phase', 'callgrind'), ('--cells-file', str(Q / 'architecture-c10-cpu-cells.json')),
                        ('--count', '10')]:
        cpu[cpu.index(flag) + 1] = value
    cpu += ['--valgrind', str(ROOT / 'work/toolchain/valgrind/usr/bin/valgrind'),
            '--valgrind-lib', str(ROOT / 'work/toolchain/valgrind/usr/libexec/valgrind')]
    run('cpu-counter-run', 900, cpu)
    run('cpu-counter-summary-run', 120,
        ['python3', str(Q / 'architecture-c10-ab-summary.py'), '--campaign', str(Q / 'architecture-c10-cpu-ab'),
         '--output', str(Q / 'architecture-c10-cpu-ab-summary.json')])

    state['free_bytes_before_asan'] = shutil.disk_usage(ROOT).free
    save()
    assert state['free_bytes_before_asan'] >= 1900 * 1024 * 1024, 'fresh ASAN cache needs disk reclamation review'
    run('asan-pipeline-run', 3600, ['python3', str(Q / 'architecture-c10-asan-supervisor.py')])
    asan = json.loads((Q / 'architecture-c10-asan-supervisor-state.json').read_text())
    assert asan['state'] == 'passed' and asan['cache_reclaimed'] is True
    state.update(state='passed', active=None, source_after=source(), completed_utc=now())
    save()
except BaseException as error:
    state.update(state='failed', error=repr(error), source_after=source(), completed_utc=now())
    save()
    traceback.print_exc()
    sys.exit(1)
