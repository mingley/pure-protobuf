# C11 admission and deadline review

Read-only review of clean `beb4ecd9a9b2143c440892607d5b486318062b61`. **No reproduction, build or test was executed for this finding.** Existing qualification/fixture evidence is unchanged.

## Source finding: high confidence

A custom asynchronous `Service::call` can hold an accepted `Rpc` before choosing its shape. That wait does not consume the duration subsequently enforced by the shape:

| Stage | Exact source evidence |
| --- | --- |
| Admission | `server/connection.rs:647` rejects initially zero budgets. For positive budgets, `connection.rs:719–740` owns the permit and simply awaits dispatch; there is no outer call-expiry wrapper. |
| Arbitrary service work | `server/dispatch.rs:189` starts `Service::call`; its public contract at74 permits asynchronous work before consuming `Rpc`. |
| Late deadline origin | `server/rpc.rs:1293` converts to `InboundRpc` only when a shape starts. At1372 it stamps `now + timeout`, carrying no admission instant or elapsed deduction. A20ms request held50ms before its shape receives a fresh20ms at shape entry. |
| Moving getter | `rpc.rs:353–355` recomputes `Rpc::deadline()` as the current time plus the same duration. Its documentation347 explicitly describes this. Two observations separated by a wait can return later instants. |

The first gap applies to every shape. An ordinary client's independent deadline/RST can mask it; server-side lifetime must be observed separately.

**A distinct relative-timer restart is also visible.** Public `rpc.bidi_streaming(...)` synchronously constructs its future (`rpc.rs:1069`,1087/1097). `run_streaming_request` immediately creates `InboundRpc` at1240, stamping the absolute deadline at1372. A service can hold that returned future behind an async gate. When later polled, `read_streaming` gives the inbound stream the stored deadline at1567, but starts a full relative `wrap_timeout(self.timeout, ...)` at1578. `wire/send.rs:615–619` creates Tokio's timer only then. Tokio1.53.1 computes `now + duration` in `src/time/timeout.rs:86–97`. Handler enforcement can therefore extend beyond its stored absolute deadline; a handler need not poll its inbound stream.

Unary uses the same relative wrapper at `rpc.rs:1221`, but do not claim an arbitrary public construction-to-poll delay inside its small setup gap without a separate experiment. Streaming drains use the stored `timeout_at` instant (`server/drain.rs:578`,700,745); this does not retroactively bound earlier service/handler work. Substituting `timeout_at` alone also does not establish expiry-before-handler-poll: Tokio's timeout polls the inner future first (`tokio1.53.1/src/time/timeout.rs:216–221`).

## gRPC semantics and limits

The [official deadline guide](https://raw.githubusercontent.com/grpc/grpc.io/main/content/en/docs/guides/deadlines.md) defines timeout as the maximum duration the **call** may take (16–20), describes server resource cancellation after the client deadline (35–47), and deducts elapsed time during budget propagation (60–64). The [HTTP/2 protocol](https://raw.githubusercontent.com/grpc/grpc/master/doc/PROTOCOL-HTTP2.md) encodes `grpc-timeout` as a relative duration (31–33); omission means infinite timeout (62).

This supports consuming one peer budget across dispatch and application waiting, rather than restarting it at the shape. It does not specify a nanosecond-exact header-receipt API or recover unknown network transit time. Test from actual service entry as a conservative latest origin. Server/interceptor caps must never extend a shorter peer budget; the repo already promises tightening only (`rpc.rs:282`). The guide describes server cancellation as `CANCELLED`; it does not mandate one universal wire code for every cancellation. Check this implementation's existing `DEADLINE_EXCEEDED` timeout contract separately from local-client expiry or peer-RST outcomes.

## Next causal tests — unexecuted

1. Independent raw HTTP/2 peer sends `grpc-timeout: 20m`, remains alive and sends **no deadline-driven RST**. A custom service acknowledges entry and holds `Rpc` behind a gate. Paused Tokio time plus a finite independent wall guard: prove held at19ms; at21ms require expiry, actual service-owner Drop, released capacity and no handler invocation. Releasing the gate afterward must not grant a fresh budget. Cover all four shapes. A gate released at10ms is the positive control: only the remaining budget is available. Server/interceptor caps are separate controls.
2. Construct `rpc.bidi_streaming(...)` synchronously, acknowledge construction and its original deadline, then gate polling until past that deadline. The handler deliberately never reads inbound messages. Check handler entry/Drop and cancellation independently so the inbound stream's earlier timer cannot conceal a relative handler extension. Include an unexpired delayed-poll control.
3. Read `Rpc::deadline()` on both sides of an explicit clock advance. Characterize the current documented moving getter; a fixed contract should preserve one peer deadline while allowing caps only to shorten it, keeping original peer duration metadata separately.

These are concrete source findings and proposed experiments, **not executed failures or a claim that the current full qualification result failed**.

## Provenance

Official guide content SHA256: `e310a0e5a4bdc8f353ef04a641336d9a51176ffaa0ba0ee8b8b1aad98263a900`. HTTP/2 protocol content SHA256: `b51ea1b8cee67ad3477e73152bb60ac3ebf6e164962b46ba79434e980739256f`. Both public source documents were read during this review; the grpc.io website itself was unavailable through the environment proxy, so its official GitHub source was used.

Reviewed local file hashes:

```json
{
  "pbrs-grpc/src/server/connection.rs": "0b64e4a4a8425a0040d89c7a7bf281dde9c491537f867e6e2fed0698280a14c3",
  "pbrs-grpc/src/server/dispatch.rs": "bd1b695c9684754fc899b46a20a09b65648faffdb5108a8c8c8d265ecf352298",
  "pbrs-grpc/src/server/rpc.rs": "930e437871a0f40885de32f0df6fe9bd5307684ff5eb37e72cb9880e1c4b6013",
  "pbrs-grpc/src/wire/send.rs": "be6f050a9cb0e764bfd77f67b10c026f5c5157566a2d389c96f0dc6980432d3e",
  "pbrs-grpc/src/server/drain.rs": "57ac9b8af69c6cfa45b2d693889b3ee849fd67addc8b619b8e9839cf8c6a98d8",
  "Cargo.lock": "a5ca5a8efb2ba7f3ae0f0a62d5344e267c96794c69dd2d751321d0a0d6ab5c33"
}
```
