# C11 production delta review

Read-only review against C10 commit `a675b61fe2775e336f33474c58342764cea814a8`. This is a working-source snapshot, pending the final C11 pin. No builds or tests were run by this reviewer. Fixture changes are not accepted by this interim report and await their final freeze.

No production correctness blocker was found in the reviewed delta.

The bounded reader now distinguishes logical initialized length from retained physical Vec capacity. The initial growth hint remains the first decoded lookahead or bounded compressed-length hint, capped by the current decoded-byte budget. Already-owned physical capacity satisfies reservation without changing logical length. Consequently a previous large buffer does not cause a later modest message to initialize or offer its whole retained allocation to the decoder. Every extension, probe, checked allocation and EOF check remains on the original bounded path. This does not shrink a retained allocation or claim that the per-message byte limit bounds total idle capacity.

Cold decoded output up to 8 KiB uses the ordinary codec method after complete bounded decompression. Negotiated encoding and acceptance checks occur before this branch, and gzip/deflate/Zstd validation paths are unchanged. CodecMessage explicitly requires reusable decoding to produce the same message and errors as ordinary decoding; the Prost implementation runs the same Prost decoder through its ownership-preserving Buf adapter. Thus the cold branch changes retention costs, not wire acceptance or decoded semantics. It avoids a cold workspace Box, idle-capacity lease and conditional full-range ownership promotion. Warm workspaces still use reusable decoding for short and empty messages, so large/small mixtures preserve their existing owned allocation. If a custom codec violates the parity contract, that is not made safe by either routing decision.

The 8 KiB cutoff is private policy shared with the decoder lookahead; its performance merits still require the matched controls. Exactly-boundary outputs still complete the existing EOF/overflow probe before routing. Allocation failure, exhausted idle capacity, shared backing and decoder errors retain their previous behavior. The change adds no unsafe code, public option or new unbounded retention.

The Prost last-field and nested-last-field unit assertions now recover the Vec and compare its full original capacity and pointer, closing the earlier weak proof where an empty static Bytes also passed try_into_mut. Shared-input and malformed-message cases remain needed alongside these owned-storage proofs.

The resolver fixture diff was inspected provisionally: manually held DNS phases replace timing-based lookup progression; actual B replies witness adoption; A's second stream item remains gated until the handoff. This strengthens the intended draining property without runtime resolver changes. Serving/cancellation fixtures were still being edited and require a separate final review.

Acceptance remains conditional on a clean final source pin, full test results and matched allocation/CPU/resource controls. This report is not production or broad-superiority qualification.
