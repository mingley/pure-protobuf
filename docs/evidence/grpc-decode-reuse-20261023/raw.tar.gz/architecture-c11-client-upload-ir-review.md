# C11 client-stream gzip instruction review

The retained profiles place the main extra work in the native gzip writer's output-buffer initialization. This is a concrete next optimization target; it is not a native wall-time speed claim.

Scope: C11 `beb4ecd9a9b2143c440892607d5b486318062b61`, Prost clients, Tonic/Prost server, h2c, one connection/one in flight, four 1 KiB zero-filled request messages, gzip level 6. Eight existing client profiles cover N 10/20 for two repeats and two clients. All 120 actual RPCs succeeded, with zero failures or timeouts. The full selected CPU campaign separately passed 96 captures / 1440 RPCs. Build: release **with `allocation-counts`**, rustc 1.99.1; binary SHA-256 `a1135e25f1af185202c1eb06032ba5a5d7556c83a975cdd5d39ef72eb49fc11f`. Profiles include production native observability.

For each repeat: `(Ir20-Ir10)/10`; then average the two slopes. Native: **2,384,777.05 instructions/RPC**, Tonic: **2,236,524.95**, difference **148,252.10 (+6.629%)**. Native repeat range 2,384,687.9–2,384,866.2; Tonic 2,236,289.0–2,236,760.9. Historical C8→C11 total change is essentially flat in the accepted summary; this review attributes current C11 versus current Tonic only.

| Additive exclusive cost | Native Ir/RPC | Tonic Ir/RPC | Difference |
|---|---:|---:|---:|
| libc byte-fill primitive (`0x163540`) |1,776,283.20|1,579,673.35|+196,609.85|
| libc byte-copy/move primitive (`0x162b40`) |320,478.25|333,723.25|−13,245.00|
| All remaining functions |288,015.60|323,128.35|−35,112.75|
| **Total** |**2,384,777.05**|**2,236,524.95**|**+148,252.10**|

All eight exclusive-cost sums equal both the raw profile `summary:` and `totals:` exactly, and each summary matches its retained `run.json`. Their N/2N sums reproduce the accepted total. For both numeric libc primitives, all direct incoming edge costs also sum exactly to self cost in every profile. No negative differential was dropped.

The numeric fill primitive broadcasts the input byte to vector registers and stores it; its large branch executes `rep stos`. The numeric copy/move primitive loads source data and stores it to the destination. `objdump`'s nearest exported `_dl_mcount_wrapper` label is not the function's actual identity. The retained disassembly and libc hash are recorded.

| Direct incoming fill calls | Ir/RPC | Calls/RPC |
|---|---:|---:|
| Native `flate2::zio::Writer::write_with_status` |131,144|4|
| Native `flate2::zio::Writer::finish` |262,288|8|
| Tonic `codec::compression::compress` |163,984|8|

The upload-path difference is **+229,448 fill instructions/RPC**. Native decode-path fill is 32,786 lower than Tonic; other fill edges differ by−52.15, giving the overall+196,609.85 fill delta. Common `CompressorOxide::default` fill 620,424 and `HashBuffers::default` fill 656,608 instructions/RPC are **identical**. This does not support blaming different compressor initialization, compression levels or backends for the difference.

The source agrees with the machine-code attribution. Native `gzip.rs:133` uses `flate2::write::GzEncoder`; Tonic `compression.rs:222` uses `flate2::read::GzEncoder`. Both use the single measured flate2 1.1.10 miniz backend (build artifact features recorded). `flate2/src/zio.rs:174` creates 32 KiB writer scratch. `write_with_status` and `finish` invoke `run_vec`; `mem.rs:389` routes `compress_vec` through `compress_uninit`. The miniz backend inherits `ffi/mod.rs:51`'s default implementation, whose `initialize_buffer` zeroes all supplied spare output before compression. Repeated write/finish calls therefore reinitialize spare output. The read interface instead supplies already initialized output through `zio::read` and `compress`. Caller attribution includes inlined code, so these are not exact source-line costs or proof of bytes cleared.

The smallest follow-up is an isolated, safe `bufread::GzEncoder<&[u8]>` plus initialized bounded output-copy loop, preserving independent gzip members, CRC/trailer completion, writer failures and existing resource limits. Test compressed/incompressible and boundary payloads and compare instructions plus allocations/bytes before changing runtime. A bounded initialized reusable chunk avoids both the read wrapper's input buffer and the writer's repeated spare-capacity initialization. Its cost and benefit remain **unmeasured**. Cross-message compressor caching adds lifecycle/RSS concerns and is not required to test this asymmetry.

Limits: these are small-N, allocation-instrumented instruction diagnostics for one client workload. Inlining, stripped symbols and repeated-string instructions limit source-level and native-time inference. Do not sum arbitrary inclusive call edges. No builds, captures, tracked edits, runtime changes or new qualification claims were made. Full paths, hashes, raw function differentials and edge conservation are in the adjacent JSON and its input artifacts.
