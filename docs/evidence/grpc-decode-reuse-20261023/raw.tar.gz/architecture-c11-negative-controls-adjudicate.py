#!/usr/bin/env python3
"""Read-only adjudication of retained C11 control results; run no Rust tests.

The original failed driver disposition stays unchanged. Its owner-unit matcher
expected a later capacity assertion, but the same regression was caught earlier
by the explicit unique-ownership expectation. This successor verifies that exact
panic, every other negative, their precise source patches, and the restored
positive run. It does not convert compilation failures into negative evidence.
"""

import argparse
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import traceback


ROOT = Path("/workspace/pure-protobuf")
Q = ROOT / "work/qualification"
PINS = Q / "architecture-c11-source-pins.json"
ORIGINAL = Q / "architecture-c11-negative-controls-state.json"
PIPELINE = Q / "architecture-c11-pipeline-state.json"
OUTPUT = Q / "architecture-c11-negative-controls-adjudication.json"
EMPTY = hashlib.sha256(b"").hexdigest()
UNIT = "codec::prost::tests::reusable_decode_preserves_owned_and_shared_field_semantics"
SPANS = "compression::tests::retained_capacity_does_not_expand_read_spans_for_a_modest_message"
TRANSPORT = "decoded_storage_preserves_ownership_validation_and_cleanup"
MUTATIONS = {
    "owner": ("pbrs-grpc/src/codec/prost.rs", "T::decode(DecodeCursor(payload))", "T::decode(payload)"),
    "initialization": ("pbrs-grpc/src/compression/mod.rs", "n.max(compressed_length.min(256 * 1024)).min(budget)", "n.max(compressed_length.min(256 * 1024)).max(out.capacity()).min(budget)"),
    "retention": ("pbrs-grpc/src/wire/frame_reader.rs", "RetainedDecodeLease::try_acquire(buffer.capacity())", "RetainedDecodeLease::try_acquire(0)"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def snapshot(tree):
    def git(*args):
        return subprocess.check_output(["git", *args], cwd=tree)
    return {"head": git("rev-parse", "HEAD").decode().strip(),
            "status": git("status", "--porcelain").decode(),
            "diff_sha256": digest(git("diff", "HEAD", "--binary"))}


def apply_in_memory(pristine, patch, relative):
    """Validate the complete single-file unified diff without changing files."""
    lines = patch.decode().splitlines(keepends=True)
    assert lines[0] == f"diff --git a/{relative} b/{relative}\n"
    assert sum(line.startswith("diff --git ") for line in lines) == 1
    assert f"--- a/{relative}\n" in lines and f"+++ b/{relative}\n" in lines
    source = pristine.decode().splitlines(keepends=True)
    output, cursor, index, hunks = [], 0, 0, 0
    while index < len(lines):
        match = re.match(r"@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", lines[index])
        if not match:
            assert hunks == 0, "unexpected trailing patch data"
            index += 1
            continue
        hunks += 1
        start = int(match.group(1)) - 1
        assert start >= cursor
        output.extend(source[cursor:start])
        cursor = start
        removed = added = 0
        index += 1
        while index < len(lines) and not lines[index].startswith("@@ "):
            line = lines[index]
            assert line and line[0] in " +-", "unsupported patch line"
            if line[0] in " -":
                assert source[cursor] == line[1:]
                cursor += 1
                removed += 1
            if line[0] in " +":
                output.append(line[1:])
                added += 1
            index += 1
        assert removed == int(match.group(2) or 1)
        assert added == int(match.group(4) or 1)
    assert hunks > 0
    output.extend(source[cursor:])
    return "".join(output).encode()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"state": "prepared; no validation, metadata writes or tests run", "output": str(OUTPUT)}))
        return 0
    assert __debug__, "evidence checks require assertions"
    assert not OUTPUT.exists(), "retained adjudication must not be overwritten"
    state = {"state": "running", "passed": False, "qualified": False,
             "started_utc": utc(), "no_tests_run": True, "validated_checks": [],
             "scope": "Read-only assertion/provenance adjudication; no new production qualification",
             "immutable_inputs": {}}

    def save():
        temporary = OUTPUT.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(state, indent=2) + "\n")
        temporary.replace(OUTPUT)

    def read(path):
        data = path.read_bytes()
        state["immutable_inputs"][str(path)] = {"sha256": digest(data), "bytes": len(data)}
        return data

    def load(path):
        return json.loads(read(path))

    def source_bytes(pin, relative):
        return subprocess.check_output(["git", "show", f"{pin}:{relative}"], cwd=ROOT)

    def check_capture(prior, pin, patch_hash, test, arguments, marker):
        path = Path(prior["record"])
        record = load(path)
        out = read(path.with_suffix(".stdout"))
        err = read(path.with_suffix(".stderr"))
        assert digest(out) == prior["stdout_sha256"] and digest(err) == prior["stderr_sha256"]
        stdout, stderr = out.decode(), err.decode()
        combined = stdout + "\n" + stderr
        expected_source = {"head": pin, "diff_sha256": patch_hash, "untracked": {}}
        assert record["source"] == prior["source"] == expected_source
        assert Path(record["cwd"]) == ROOT / "work/architecture-c11-negative"
        expected = ["nice", "-n", "15", str(ROOT / "work/run-rust"), "cargo", "+stable", "test", "--locked", "-p", "pbrs-grpc", "--all-features", *arguments]
        assert record["command"] == expected, record["command"]
        assert not record.get("timeout")
        assert "Finished `test` profile" in stderr and "Running " in stderr
        assert "could not compile" not in combined
        summaries = [{"status": status, "passed": int(passed), "failed": int(failed), "ignored": int(ignored)}
                     for status, passed, failed, ignored in re.findall(r"test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;", stdout)]
        if test:
            assert record["exit_code"] == prior["exit_code"] == prior["record_driver_exit_code"] == 101
            assert summaries == [{"status": "FAILED", "passed": 0, "failed": 1, "ignored": 0}]
            assert f"test {test} ... FAILED" in stdout
            assertion = re.search(marker, stderr, re.S)
            assert assertion, (prior["name"], stderr)
            assert "panicked at" in assertion.group(0)
            result = {"name": prior["name"], "record": str(path), "exit_code": 101,
                      "source": expected_source, "compile_succeeded_and_tests_ran": True,
                      "original_observed_expected_result": prior["observed_expected_result"],
                      "observed_expected_result": True, "matched_assertion": assertion.group(0),
                      "expected_assertion_pattern": marker, "summaries": summaries}
        else:
            assert record["exit_code"] == prior["exit_code"] == 0
            assert len(summaries) == 2 and all(row["status"] == "ok" and row["failed"] == 0 and row["passed"] > 0 for row in summaries)
            assert summaries[1] == {"status": "ok", "passed": 1, "failed": 0, "ignored": 0}
            for name in [UNIT, SPANS, TRANSPORT]:
                assert f"test {name} ... ok" in stdout
            result = {"record": str(path), "exit_code": 0, "source": expected_source,
                      "compile_succeeded_and_tests_ran": True, "observed_expected_result": True,
                      "summaries": summaries, "totals": {key: sum(row[key] for row in summaries) for key in ["passed", "failed", "ignored"]}}
        return result

    save()
    try:
        pins = load(PINS)
        pin = pins["candidate_runtime"]
        assert re.fullmatch(r"[0-9a-f]{40}", pin)
        original, pipeline = load(ORIGINAL), load(PIPELINE)
        assert original["state"] == pipeline["state"] == "failed", "original runs must finish first"
        assert original["pin"] == pipeline["pin"] == pin
        assert original["restored_clean"] is True and original["frozen_unchanged"] is True
        assert original["source_patches_verified"] is True and original["positive_source_clean"] is True
        assert "infrastructure_error" not in original
        assert digest(read(PINS)) == original["source_pins_sha256"]
        state.update(pin=pin, original_record={"path": str(ORIGINAL), "sha256": digest(ORIGINAL.read_bytes()), "state": original["state"]},
                     original_pipeline={"path": str(PIPELINE), "sha256": digest(PIPELINE.read_bytes()), "state": pipeline["state"]})
        for path, expected in pipeline["immutable_inputs"].items():
            assert digest(read(Path(path))) == expected, path
        original_driver = Q / "architecture-c11-negative-controls.py"
        assert digest(read(original_driver)) == original["driver_sha256"]
        pristine = {name: source_bytes(pin, relative) for name, (relative, _, _) in MUTATIONS.items()}
        controls = {control["name"]: control for control in original["controls"]}
        assert set(controls) == set(MUTATIONS)
        expected_checks = {"owner": ["owner-unit", "owner-transport"], "initialization": ["initialization-unit"], "retention": ["retention-transport"]}
        for name, (relative, before, after) in MUTATIONS.items():
            control = controls[name]
            assert control["source_file"] == relative and digest(pristine[name]) == control["original_sha256"]
            assert pristine[name].count(before.encode()) == 1
            mutated = pristine[name].replace(before.encode(), after.encode(), 1)
            assert digest(mutated) == control["mutated_sha256"]
            patch = read(Path(control["patch"]))
            assert digest(patch) == control["patch_sha256"]
            assert apply_in_memory(pristine[name], patch, relative) == mutated
            assert [item["name"] for item in control["checks"]] == expected_checks[name]

        owner_marker = r'panicked at pbrs-grpc/src/codec/prost\.rs:(\d+):\d+:\nlast bytes field preserves unique ownership: b""'
        cache_marker = r"panicked at pbrs-grpc/tests/decode_workspace\.rs:(\d+):\d+:\nassertion `left == right` failed\s+left: 0\s+right: 1"
        span_marker = r"panicked at pbrs-grpc/src/compression/mod\.rs:(\d+):\d+:\na 8193-byte message requested a 1040384-byte read target from retained capacity 1048576"
        for control_name, name, test, arguments, marker in [
            ("owner", "owner-unit", UNIT, ["--lib", UNIT, "--", "--exact", "--nocapture"], owner_marker),
            ("owner", "owner-transport", TRANSPORT, ["--test", "decode_workspace", "--", "--exact", TRANSPORT, "--nocapture"], cache_marker),
            ("initialization", "initialization-unit", SPANS, ["--lib", SPANS, "--", "--exact", "--nocapture"], span_marker),
            ("retention", "retention-transport", TRANSPORT, ["--test", "decode_workspace", "--", "--exact", TRANSPORT, "--nocapture"], cache_marker),
        ]:
            control = controls[control_name]
            prior = next(item for item in control["checks"] if item["name"] == name)
            assert prior["observed_expected_result"] is (name != "owner-unit")
            result = check_capture(prior, pin, control["patch_sha256"], test, arguments, marker)
            line = int(re.search(marker, result["matched_assertion"], re.S).group(1))
            relative = "pbrs-grpc/tests/decode_workspace.rs" if "transport" in name else MUTATIONS[control_name][0]
            source_line = source_bytes(pin, relative).decode().splitlines()[line - 1]
            expected_line = '.expect("last bytes field preserves unique ownership")' if name == "owner-unit" else "assert_eq!(counts.retained_buffers, 1);" if "transport" in name else "assert!("
            assert expected_line in source_line, (name, source_line)
            result["source_assertion_line"] = source_line.strip()
            state["validated_checks"].append(result)

        state["positive"] = check_capture(original["positive"], pin, EMPTY, None,
            ["--lib", "--test", "decode_workspace", "--", "--nocapture"], None)
        negative_tree = ROOT / "work/architecture-c11-negative"
        assert snapshot(negative_tree) == {"head": pin, "status": "", "diff_sha256": EMPTY}
        frozen = {name: snapshot(ROOT / "work" / name) for name in original["frozen_after"]}
        assert frozen == original["frozen_before"] == original["frozen_after"]
        for path, expected in state["immutable_inputs"].items():
            assert digest(Path(path).read_bytes()) == expected["sha256"], path
        state.update(state="passed", passed=True, restored_clean=True, frozen_unchanged=True,
                     source_pins_unchanged=True, source_patches_verified=True,
                     original_dispositions_preserved=True,
                     correction="The owner-loss regression panics at the earlier unique-ownership expectation; no capacity value is observed after that panic.")
    except BaseException as error:
        state.update(state="failed", passed=False, error=repr(error))
        traceback.print_exc()
    state["completed_utc"] = utc()
    save()
    print(json.dumps({"state": state["state"], "record": str(OUTPUT), "no_tests_run": True}))
    return 0 if state["passed"] else 1


if __name__ == "__main__":
    sys.exit(main())
