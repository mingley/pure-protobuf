#!/usr/bin/env python3
"""Run frozen C11 checks and diagnostics sequentially; stop and retain failures.

Preparation is separate from execution. Root creates both pinned worktrees and
launches this driver with --execute --expanded after granting the queued work.
Counters on this shared host do not qualify production readiness or speed.
"""

import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import time
import traceback


ROOT = Path("/workspace/pure-protobuf")
Q = ROOT / "work/qualification"
CWD = ROOT / "work/architecture-c11"
PINS_PATH = Q / "architecture-c11-source-pins.json"
PLAN_PATH = Q / "architecture-c11-measurement-plan.json"
STATE_PATH = Q / "architecture-c11-pipeline-state.json"
BASELINE = "9d6fb9c416fc32732450fd78d32ee16ff8b802de"
ACCOUNTING = ["offered_rpcs", "dispatched_rpcs", "completed_rpcs", "successful_rpcs"]
FAILURES = ["failed_rpcs", "timeouts", "queue_overflows", "unstarted_rpcs", "unfinished_rpcs"]


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def load(path):
    return json.loads(path.read_text())


def source(checkout=CWD):
    return {
        "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
        "status": subprocess.check_output(
            ["git", "status", "--porcelain", "--untracked-files=all"], cwd=checkout, text=True
        ).strip(),
    }


def option(argv, flag):
    assert argv.count(flag) == 1, (flag, argv)
    return argv[argv.index(flag) + 1]


def replace(argv, flag, value):
    option(argv, flag)
    argv[argv.index(flag) + 1] = value


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--expanded", action="store_true", help="also collect the 2400-capture candidate matrix")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({
            "state": "prepared; no builds, captures, mutations or metadata writes",
            "pins": str(PINS_PATH), "plan": str(PLAN_PATH),
            "launch": ["python3", str(Path(__file__).resolve()), "--execute", "--expanded"],
        }, indent=2))
        return 0
    assert __debug__, "Python optimization must not disable evidence gates"
    assert not STATE_PATH.exists(), "retained pipeline state must not be overwritten"
    pins, plan = load(PINS_PATH), load(PLAN_PATH)
    pin = pins["candidate_runtime"]
    assert re.fullmatch(r"[0-9a-f]{40}", pin)
    assert pins["baseline_runtime"] == BASELINE and pins["qualified"] is False
    assert plan["source_pins"] == pins and plan["qualified"] is False
    expected_source = {"head": pin, "status": ""}
    assert source() == expected_source
    assert source(ROOT / "work/architecture-c11-negative") == expected_source
    frozen = {name: source(ROOT / "work" / name) for name in ["architecture-c8", "architecture-c10", "architecture-c11"]}
    assert frozen["architecture-c8"] == {"head": BASELINE, "status": ""}
    assert all(not item["status"] for item in frozen.values())
    inputs = {
        PINS_PATH, PLAN_PATH, Path(__file__).resolve(),
        Q / "architecture-c11-negative-controls.py",
        Q / "architecture-c11-resolver-negative-controls.py",
        Q / "architecture-c11-counter-ab-driver.py", Q / "architecture-c11-ab-summary.py",
        Q / "architecture-c8-counter-summary.py", Q / "reclaim-rpc-cache.py",
        Q / "architecture-c11-asan-supervisor.py", Q / "architecture-c11-cpu-cells.json",
        Q / "architecture-c11-resolver-fixture-class-control-plan.json",
    }
    for relative, expected in plan.get("hashes", {}).items():
        path = Path(relative)
        path = path if path.is_absolute() else Q / path
        assert digest(path) == expected, path
        inputs.add(path)
    for control in load(Q / "architecture-c11-resolver-fixture-class-control-plan.json")["negative_controls"]:
        patch = Path(control["patch"])
        assert digest(patch) == control["patch_sha256"]
        inputs.add(patch)
    native = plan["command"].copy()
    cells_path = Path(option(native, "--cells-file"))
    inputs.add(cells_path)
    assert len(load(cells_path)) == 71
    assert len(load(Q / "architecture-c11-cpu-cells.json")) == 12
    assert option(native, "--candidate-commit") == pin
    assert option(native, "--baseline-commit") == BASELINE
    assert Path(option(native, "--candidate-checkout")) == CWD
    assert Path(option(native, "--baseline-checkout")) == ROOT / "work/architecture-c8"
    assert option(native, "--phase") == "native" and option(native, "--count") == "25"
    assert option(native, "--repeats") == "2" and "--abba" in native
    assert Path(option(native, "--output")) == Q / "architecture-c11-counter-ab"
    inputs = {str(path): digest(path) for path in inputs}
    pins_hash = inputs[str(PINS_PATH)]
    state = {
        "state": "running", "active": "waiting_for_checks_and_release_build",
        "started_utc": now(), "supervisor_pid": os.getpid(), "qualified": False,
        "pin": pin, "source_before": expected_source, "frozen_before": frozen,
        "immutable_inputs": inputs, "expanded_requested": args.expanded, "phases": [],
        "limits": [
            "Shared host; the separate frozen C8 day is independent evidence.",
            "Allocator-instrumented release counters and Callgrind are diagnostics, not shipping speed proof.",
            "The 30-second resource preview does not replace a final-candidate 24-hour soak.",
        ],
    }
    env = os.environ.copy()
    env.update(CARGO_BUILD_JOBS="1", CARGO_TARGET_DIR=str(ROOT / "work/rpc-target"), RUSTUP_TOOLCHAIN="stable")

    def save():
        temporary = STATE_PATH.with_suffix(".json.tmp")
        temporary.write_text(json.dumps(state, indent=2) + "\n")
        temporary.replace(STATE_PATH)

    def unchanged():
        assert source() == expected_source, "final candidate changed"
        assert {name: source(ROOT / "work" / name) for name in frozen} == frozen, "frozen worktree changed"
        for path, expected in inputs.items():
            assert digest(Path(path)) == expected, "immutable pipeline input changed: " + path
        for path, expected in state.get("evidence", {}).items():
            assert digest(Path(path)) == expected["sha256"], "retained phase evidence changed: " + path

    def retain(path):
        state.setdefault("evidence", {})[str(path)] = {"sha256": digest(path), "bytes": path.stat().st_size}
        save()

    def run(name, seconds, argv):
        unchanged()
        state["active"] = name
        save()
        prefix = Q / ("architecture-c11-pipeline-" + name)
        phase_files = [prefix.with_suffix(suffix) for suffix in (".json", ".stdout", ".stderr")]
        assert not any(path.exists() for path in phase_files), "phase logs must not be overwritten"
        result = subprocess.run(
            ["python3", str(ROOT / "work/record.py"), str(prefix), str(seconds), *argv],
            cwd=CWD, env=env,
        )
        record = load(phase_files[0])
        state["phases"].append({
            "name": name, "record": str(phase_files[0]), "exit_code": record["exit_code"],
            "duration_seconds": record["duration_seconds"],
            "files": {str(path): {"sha256": digest(path), "bytes": path.stat().st_size} for path in phase_files},
        })
        save()
        assert result.returncode == record["exit_code"] == 0, name
        assert not record.get("timeout"), name
        assert record["source"] == {"head": pin, "diff_sha256": hashlib.sha256(b"").hexdigest(), "untracked": {}}
        unchanged()

    def validate_ab(stem, phase, captures, rpc_calls):
        summary_path = Q / (stem + "-summary.json")
        campaign_path = Q / stem / "campaign.json"
        summary, campaign = load(summary_path), load(campaign_path)
        assert summary["passed"] is True and summary["controller_passed"] is True
        assert campaign["state"] == "finished" and campaign["passed"] is True
        assert summary["qualified"] is False and campaign["qualified"] is False
        assert summary["phase"] == campaign["phase"] == phase
        assert summary["retained_captures"] == summary["expected_captures"] == captures
        assert len(campaign["captures"]) == campaign["expected_captures"] == captures
        assert not any(summary[key] for key in ["failed_captures", "missing_data", "missing_keys", "extra_keys", "status_errors"])
        for version, commit in [("baseline", BASELINE), ("candidate", pin)]:
            assert campaign["versions"][version]["source"]["commit"] == commit
            assert summary["source_pins"][version] == campaign["versions"][version]
            actual = summary["actual_rpc_totals"][version]
            assert all(actual[key] == rpc_calls // 2 for key in ACCOUNTING)
            assert all(actual[key] == 0 for key in FAILURES)
        retain(summary_path)
        retain(campaign_path)

    def validate_expanded():
        directory = Q / "architecture-c11-counter-expanded"
        campaign_path = directory / "campaign.json"
        summary_path = Q / "architecture-c11-counter-expanded-all-counters.json"
        campaign, summary = load(campaign_path), load(summary_path)
        assert campaign["state"] == "finished" and campaign["passed"] is True
        assert campaign["source"] == pin and campaign["phase"] == "native"
        assert campaign["qualified"] is False and summary["qualified"] is False
        assert campaign["expected_groups"] == len(campaign["groups"]) == 16
        assert campaign["expected_captures"] == summary["expected_captures"] == summary["captures"] == 2400
        assert summary["passed"] is True and summary["controller_passed"] is True
        assert summary["source"] == pin and summary["metrics_records"] == 2400
        assert not summary["raw_failed_captures"] and not summary["missing_ledgers"] and not summary["status_errors"]
        actual = summary["actual_rpc_totals"]
        assert all(actual[key] == 720000 for key in ACCOUNTING)
        assert all(actual[key] == 0 for key in FAILURES)
        paths = list(directory.glob("group-*/n-*/cell-*/run.json"))
        assert len(paths) == 2400
        for path in paths:
            result = load(path)
            count = int(path.parent.parent.name.removeprefix("n-"))
            assert count in (200, 400) and result["passed"] is True, str(path)
            metrics = result["metrics"]
            assert all(metrics[key] == count for key in ACCOUNTING), str(path)
            assert all(metrics[key] == 0 for key in FAILURES), str(path)
            assert not metrics.get("status_errors"), str(path)
        retain(campaign_path)
        retain(summary_path)

    save()
    try:
        deadline = time.monotonic() + 10800
        checks_path = Q / "architecture-c11-checks-state.json"
        build_path = Q / "architecture-c11-stable-rpc-build-record.json"
        while True:
            unchanged()
            checks = load(checks_path) if checks_path.exists() else None
            build = load(build_path) if build_path.exists() else None
            assert checks is None or checks["state"] != "failed", "source-pinned root checks failed"
            assert build is None or build["exit_code"] == 0, "source-pinned release build failed"
            if checks and checks["state"] == "passed" and build:
                break
            assert time.monotonic() < deadline, "clean checks/build prerequisites timed out"
            time.sleep(2)
        assert checks["source"] == expected_source
        assert checks["checks"] and all(check["exit_code"] == 0 for check in checks["checks"])
        workspace = [check for check in checks["checks"] if check["name"] == "workspace"]
        assert len(workspace) == 1 and workspace[0]["totals"]["passed"] > 0 and workspace[0]["totals"]["failed"] == 0
        assert build["source"] == {"head": pin, "diff_sha256": hashlib.sha256(b"").hexdigest(), "untracked": {}}
        retain(checks_path)
        retain(build_path)
        verifier = module("c11_build_verifier", CWD / "scripts/build-rpc-bench.py")
        candidate_dir = Q / "architecture-c11-stable-rpc-build"
        baseline_dir = Q / "architecture-c8-rpc-build"
        candidate = verifier.validate_record(candidate_dir / "build.json", candidate_dir / "rpc-bench")
        baseline_verifier = module("c8_build_verifier", ROOT / "work/architecture-c8/scripts/build-rpc-bench.py")
        baseline = baseline_verifier.validate_record(baseline_dir / "build.json", baseline_dir / "rpc-bench")
        assert candidate["source"]["commit"] == pin and baseline["source"]["commit"] == BASELINE
        assert candidate["tools"] == baseline["tools"], "candidate and baseline toolchains differ"
        for relative in ["scripts/grpc-load-smoke.py", "scripts/grpc-counter-campaign.py", "scripts/dominance-ledger.py", "scripts/build-rpc-bench.py", "rpc-bench/src/main.rs"]:
            assert digest(CWD / relative) == digest(ROOT / "work/architecture-c8" / relative), relative
        for directory in [candidate_dir, baseline_dir]:
            retain(directory / "build.json")
            retain(directory / "rpc-bench")

        run("resource-preview", 1800, [
            str(ROOT / "work/run-rust"), "nice", "-n", "10", "python3", "scripts/grpc-resource-campaign.py",
            "--source", pin, "--output", str(Q / "architecture-c11-resource-preview"),
            "--duration", "30", "--build-profile", "release", "--seed", "20261002",
            "--memory-bytes", "1073741824", "--max-fds", "128", "--max-uid-processes", "4096",
        ])
        report_path = Q / "architecture-c11-resource-preview/report.json"
        report = load(report_path)
        errors = runpy.run_path(str(CWD / "scripts/grpc-resource-campaign.py"))["validate_report"](report)
        assert not errors, errors
        assert report["source"]["commit"] == pin and report["smoke"]["status"] == "passed" and report["exit_code"] == 0
        retain(report_path)

        run("decoded-negative-controls", 4800, ["python3", str(Q / "architecture-c11-negative-controls.py"), "--execute"])
        path = Q / "architecture-c11-negative-controls-state.json"
        controls = load(path)
        assert controls["state"] == "passed" and controls["pin"] == pin
        assert controls["restored_clean"] is True and controls["frozen_unchanged"] is True
        retain(path)
        run("resolver-negative-controls", 4800, ["python3", str(Q / "architecture-c11-resolver-negative-controls.py"), "--execute"])
        path = Q / "architecture-c11-resolver-negative-controls-state.json"
        controls = load(path)
        assert controls["state"] == "passed" and controls["passed"] is True
        assert controls["restored_clean"] is True and controls["frozen_unchanged"] is True
        assert controls["pin"] == pin
        retain(path)

        run("native-counter", 1800, native)
        run("native-summary", 120, ["python3", str(Q / "architecture-c11-ab-summary.py"), "--campaign", str(Q / "architecture-c11-counter-ab"), "--output", str(Q / "architecture-c11-counter-ab-summary.json")])
        validate_ab("architecture-c11-counter-ab", "native", 568, 21300)
        cpu = native.copy()
        for flag, value in [("--output", str(Q / "architecture-c11-cpu-ab")), ("--phase", "callgrind"), ("--cells-file", str(Q / "architecture-c11-cpu-cells.json")), ("--count", "10")]:
            replace(cpu, flag, value)
        cpu += ["--valgrind", str(ROOT / "work/toolchain/valgrind/usr/bin/valgrind"), "--valgrind-lib", str(ROOT / "work/toolchain/valgrind/usr/libexec/valgrind")]
        run("cpu-counter", 900, cpu)
        run("cpu-summary", 120, ["python3", str(Q / "architecture-c11-ab-summary.py"), "--campaign", str(Q / "architecture-c11-cpu-ab"), "--output", str(Q / "architecture-c11-cpu-ab-summary.json")])
        validate_ab("architecture-c11-cpu-ab", "callgrind", 96, 1440)
        if args.expanded:
            expanded = plan["native_expanded"].copy()
            assert Path(option(expanded, "--source-checkout")) == CWD
            assert Path(option(expanded, "--output")) == Q / "architecture-c11-counter-expanded"
            assert option(expanded, "--phase") == "native"
            assert option(expanded, "--payloads") == "1024,65536"
            assert option(expanded, "--load-levels") == "1:1,1:16"
            assert option(expanded, "--repeats") == "3"
            # The immutable unchanged controller's default is N=200.
            assert "--count" not in expanded or option(expanded, "--count") == "200"
            run("expanded-counter", 3600, expanded)
            run("expanded-summary", 180, ["python3", str(Q / "architecture-c8-counter-summary.py"), "--campaign", str(Q / "architecture-c11-counter-expanded"), "--output", str(Q / "architecture-c11-counter-expanded-all-counters.json")])
            validate_expanded()

        reclaim = ["python3", str(Q / "reclaim-rpc-cache.py"), "--execute", "--pins-sha256", pins_hash]
        if args.expanded:
            reclaim.append("--require-expanded")
        run("rpc-cache-reclaim", 1800, reclaim)
        path = Q / "architecture-c11-rpc-cache-reclaim.json"
        reclaimed = load(path)
        assert reclaimed["state"] == "passed" and reclaimed["cache_reclaimed"] is True
        assert not (ROOT / "work/rpc-target").exists()
        retain(path)
        state["free_bytes_before_asan"] = shutil.disk_usage(ROOT).free
        save()
        assert state["free_bytes_before_asan"] >= 1900 * 1024 * 1024, "fresh ASAN cache needs disk review"
        run("asan", 3600, ["python3", str(Q / "architecture-c11-asan-supervisor.py")])
        path = Q / "architecture-c11-asan-supervisor-state.json"
        asan = load(path)
        assert asan["state"] == "passed" and asan["cache_reclaimed"] is True and asan["source_pin"] == pin
        retain(path)
        unchanged()
        state.update(state="passed", active=None, source_after=source(), completed_utc=now())
        save()
        return 0
    except BaseException as error:
        state.update(state="failed", error=repr(error), source_after=source(), completed_utc=now())
        save()
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
