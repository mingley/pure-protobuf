#!/usr/bin/env python3
"""Reclaim the inactive shared integration-consumer compiler cache after grant.

Only --execute writes evidence or removes cache files. The known root alias is
preserved; its exact physical target is emptied and recreated. No other target
child, source checkout, frozen Q executable, stable target or toolchain is removed.
"""

import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import traceback

Q = Path(__file__).resolve().parent
ROOT = Q.parents[1]
LINK = ROOT / "target/integration-consumers"
CACHE = ROOT / "work/validation-fixes/target/integration-consumers"
SOURCE = "beb4ecd9a9b2143c440892607d5b486318062b61"
PINS_SHA256 = "82366dd76dd17d0c8ac4a27609796f7ae82c8b76fa9dc3efb06fd6f91ea3d619"
STATE = Q / "architecture-c11-consumer-cache-reclaim.json"
INVENTORY = Q / "architecture-c11-consumer-cache-reclaim-inventory.json"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic(path, value):
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def digest(path):
    checksum = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            checksum.update(block)
    return checksum.hexdigest()


def metadata(path):
    return {"bytes": path.stat().st_size, "sha256": digest(path)}


def source(checkout):
    return {"head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=checkout, text=True).strip(),
            "status": subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all"], cwd=checkout, text=True).strip()}


def check_path():
    if not __debug__:
        raise RuntimeError("Run without Python -O")
    if (CACHE != ROOT / "work/validation-fixes/target/integration-consumers"
            or not CACHE.is_dir() or CACHE.is_symlink() or CACHE.resolve() != CACHE
            or CACHE.parent.is_symlink() or not LINK.is_symlink()
            or os.readlink(LINK) != str(CACHE) or LINK.resolve() != CACHE):
        raise ValueError("Unexpected integration-consumer alias or physical cache path")
    if not shutil.rmtree.avoids_symlink_attacks:
        raise ValueError("Safe fd-based rmtree is required")


def identity(path):
    info = path.lstat()
    return {"device": info.st_dev, "inode": info.st_ino, "mode": info.st_mode}


def boundaries():
    return {"alias": {**identity(LINK), "target": os.readlink(LINK)},
            "root_target": identity(ROOT / "target"), "physical_parent": identity(CACHE.parent),
            "root_target_other_children": sorted(path.name for path in (ROOT / "target").iterdir() if path != LINK),
            "physical_target_other_children": sorted(path.name for path in CACHE.parent.iterdir() if path != CACHE),
            "stable_target": identity(ROOT / "work/stable-target"),
            "toolchain": identity(ROOT / "work/toolchain")}


def scan():
    active, blocked, zombies = [], [], []
    aliases = (str(LINK), str(CACHE))
    def hits(value):
        return any(alias in value for alias in aliases)
    for proc in Path("/proc").iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            status = (proc / "status").read_text()
            if re.search(r"^State:\s+Z\b", status, re.MULTILINE):
                zombies.append(int(proc.name))
                continue
            maps = (proc / "maps").read_text()
            cmdline = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
            if hits(maps) or hits(cmdline):
                active.append({"pid": int(proc.name), "cmdline": cmdline,
                               "mappings": [line for line in maps.splitlines() if hits(line)]})
            for fd in (proc / "fd").iterdir():
                try:
                    target = os.readlink(fd)
                except FileNotFoundError:
                    continue
                if hits(target):
                    active.append({"pid": int(proc.name), "fd": fd.name, "target": target})
            for name in ("cwd", "exe"):
                try:
                    target = os.readlink(proc / name)
                except FileNotFoundError:
                    continue
                if hits(target):
                    active.append({"pid": int(proc.name), "reference": name, "target": target})
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            blocked.append(int(proc.name))
    return {"active_users": active, "inaccessible_live_same_uid": blocked, "zombies": zombies}


def quiet(value):
    assert not value["active_users"] and not value["inaccessible_live_same_uid"], value


def proofs():
    retained = {}
    def keep(path):
        assert not path.is_symlink(), path
        retained[str(path)] = metadata(path)
    pins_path = Q / "architecture-c11-source-pins.json"
    assert digest(pins_path) == PINS_SHA256
    pins = json.loads(pins_path.read_text())
    assert pins["candidate_runtime"] == SOURCE and pins["qualified"] is False
    keep(pins_path)
    checks_path = Q / "architecture-c11-checks-state.json"
    checks = json.loads(checks_path.read_text())
    assert checks["state"] == "passed" and checks["source"] == {"head": SOURCE, "status": ""}
    assert checks["active"] is None and len(checks["checks"]) == 11
    keep(checks_path)
    workspace = next(check for check in checks["checks"] if check["name"] == "workspace")
    assert workspace["exit_code"] == 0 and workspace["totals"]["passed"] > 0 and workspace["totals"]["failed"] == 0
    for check in checks["checks"]:
        assert check["exit_code"] == 0 and check["source_after"] == {"head": SOURCE, "status": ""}
        path = Q / ("architecture-c11-" + check["name"] + ".json")
        record = json.loads(path.read_text())
        assert record["exit_code"] == 0 and not record.get("timeout")
        assert record["source"] == {"head": SOURCE, "diff_sha256": hashlib.sha256(b"").hexdigest(), "untracked": {}}
        keep(path)
        for name, expected in check["logs"].items():
            path = Q / name
            assert path.parent == Q and metadata(path) == expected, path
            keep(path)
    sources = {}
    for name, expected in (("architecture-c8", pins["baseline_runtime"]),
                           ("architecture-c10", pins["initial_candidate_runtime"]),
                           ("architecture-c11", SOURCE)):
        checkout = ROOT / "work" / name
        sources[name] = source(checkout)
        assert sources[name] == {"head": expected, "status": ""}
    sources["root"] = source(ROOT)
    assert sources["root"] == {"head": SOURCE, "status": ""}
    for relative in ("Cargo.toml", "Cargo.lock", "tests/onboarding.rs", "tests/package_consumer.rs",
                     "tests/codegen_compat.rs", "tests/plugin.rs", "tests/pbrs_build.rs"):
        keep(ROOT / relative)
    binaries = []
    for directory in ("architecture-c8-rpc-build", "architecture-c10-rpc-build",
                      "architecture-c10-stable-rpc-build", "architecture-c11-stable-rpc-build"):
        build_path = Q / directory / "build.json"
        build = json.loads(build_path.read_text())
        assert build["exit_code"] == 0
        expected_source = pins["baseline_runtime"] if directory.startswith("architecture-c8-") else (
            SOURCE if directory.startswith("architecture-c11-") else pins["initial_candidate_runtime"]
        )
        assert build["source"]["commit"] == expected_source
        binary = Q / directory / "rpc-bench"
        assert digest(binary) == build["binary_sha256"]
        keep(build_path)
        keep(binary)
        for name, expected in build["files"].items():
            path = build_path.parent / name
            assert path.parent == build_path.parent and digest(path) == expected
            keep(path)
        binaries.append({"path": str(binary), "source": build["source"], "sha256": build["binary_sha256"]})
    day_launch_path = Q / "architecture-c8-day-launch.json"
    day_launch = json.loads(day_launch_path.read_text())
    day_binary = Q / "resource-architecture-c8-day/resource-test"
    assert digest(day_binary) == day_launch["readiness"]["preview"]["binary"]["sha256"]
    keep(day_binary)
    keep(day_launch_path)
    binaries.append({"path": str(day_binary), "source": day_launch["source"], "sha256": digest(day_binary)})
    tools = {}
    runner = ROOT / "work/run-rust"
    keep(runner)
    keep(ROOT / "work/record.py")
    for name in ("rustc", "cargo"):
        path = Path(subprocess.check_output(
            [str(runner), "rustup", "which", "--toolchain", "stable", name], text=True
        ).strip()).resolve(strict=True)
        keep(path)
        tools[name] = {"path": str(path), **metadata(path),
                       "version": subprocess.check_output([str(runner), name, "+stable", "--version"], text=True).strip()}
    return {"source": SOURCE, "workspace_counts": workspace["totals"], "workspace_targets": workspace["targets"],
            "source_before": sources, "tools": tools, "frozen_binaries": binaries, "files": retained}


def verify_proofs(proof):
    for name, expected in proof["files"].items():
        assert metadata(Path(name)) == expected, name
    for name, expected in proof["source_before"].items():
        checkout = ROOT if name == "root" else ROOT / "work" / name
        assert source(checkout) == expected, checkout


def inventory():
    files = []
    for path in sorted(CACHE.rglob("*")):
        info = path.lstat()
        item = {"path": path.relative_to(CACHE).as_posix(), "device": info.st_dev,
                "inode": info.st_ino, "mode": info.st_mode, "mtime_ns": info.st_mtime_ns}
        if path.is_symlink():
            item.update(kind="symlink", target=os.readlink(path))
        elif path.is_file():
            assert path.resolve().is_relative_to(CACHE), path
            item.update(kind="file", bytes=info.st_size, sha256=digest(path))
            after = path.stat()
            assert (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns) == (
                after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns
            ), path
        elif path.is_dir():
            item.update(kind="directory")
        else:
            raise ValueError("Unexpected cache special file: " + str(path))
        files.append(item)
    return files


def verify_inventory(files):
    assert {path.relative_to(CACHE).as_posix() for path in CACHE.rglob("*")} == {item["path"] for item in files}
    for item in files:
        path = CACHE / item["path"]
        info = path.lstat()
        assert (info.st_dev, info.st_ino, info.st_mode, info.st_mtime_ns) == (
            item["device"], item["inode"], item["mode"], item["mtime_ns"]
        ), path
        if item["kind"] == "file":
            assert not path.is_symlink() and info.st_size == item["bytes"], path
        elif item["kind"] == "symlink":
            assert os.readlink(path) == item["target"], path


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--execute", action="store_true", help="root grants exact resolved cache reclamation; no further consumer build planned")
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({"state": "prepared; no evidence writes or deletion", "alias": str(LINK), "physical_cache": str(CACHE)}))
        return 0
    state = {"state": "running", "started_utc": now(), "supervisor_pid": os.getpid(),
             "driver_sha256": digest(Path(__file__)),
             "alias": str(LINK), "cache": str(CACHE), "cache_reclaimed": False, "qualified": False,
             "grant": "--execute; inactive exact compiler-consumer cache; no further consumer build planned",
             "free_bytes_before": shutil.disk_usage(ROOT).free}
    with STATE.open("x") as stream:
        json.dump(state, stream, indent=2)
        stream.write("\n")
    try:
        check_path()
        assert not INVENTORY.exists(), "Retained inventory must not be overwritten"
        mode = stat.S_IMODE(CACHE.stat().st_mode)
        state["boundaries_before"] = boundaries()
        state["proof_before"] = proofs()
        state["scan_before_inventory"] = scan()
        atomic(STATE, state)
        quiet(state["scan_before_inventory"])
        files = inventory()
        payload = {"source": SOURCE, "cache": str(CACHE), "alias": str(LINK), "created_utc": now(),
                   "files": files, "logical_file_bytes": sum(item.get("bytes", 0) for item in files)}
        with INVENTORY.open("x") as stream:
            json.dump(payload, stream, indent=2)
            stream.write("\n")
        state["inventory"] = {"path": str(INVENTORY), **metadata(INVENTORY)}
        state["scan_after_inventory"] = scan()
        atomic(STATE, state)
        quiet(state["scan_after_inventory"])
        verify_inventory(files)
        verify_proofs(state["proof_before"])
        assert boundaries() == state["boundaries_before"]
        check_path()
        state["scan_before_delete"] = scan()
        quiet(state["scan_before_delete"])
        atomic(STATE, state)
        shutil.rmtree(CACHE)
        assert not CACHE.exists() and LINK.is_symlink()
        state["cache_reclaimed"] = True
        CACHE.mkdir(mode=mode)
        state["empty_cache_recreated"] = True
        check_path()
        assert not any(CACHE.iterdir())
        state["scan_after_delete"] = scan()
        quiet(state["scan_after_delete"])
        verify_proofs(state["proof_before"])
        state["boundaries_after"] = boundaries()
        assert state["boundaries_after"] == state["boundaries_before"]
        state.update(state="passed", completed_utc=now(),
                     logical_file_bytes_reclaimed=payload["logical_file_bytes"], entries=len(files),
                     files=sum(item["kind"] == "file" for item in files), free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(STATE, state)
        print(json.dumps({"state": "passed", "record": str(STATE), "inventory": str(INVENTORY),
                          "logical_file_bytes_reclaimed": state["logical_file_bytes_reclaimed"],
                          "free_bytes_after": state["free_bytes_after"], "alias_preserved": True}))
        return 0
    except BaseException as error:
        state.update(state="failed", error=repr(error), completed_utc=now(), free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(STATE, state)
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())
