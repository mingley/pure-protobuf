// A locally failed upload can finish before the server admits any request.
// These probes make cancellation assertions only after actual handler entry,
// request consumption, and a Pending poll of the spawned cancellation child.
#[derive(Default)]
struct SenderFailureProbe {
    admitted: AtomicUsize,
    received: AtomicUsize,
    child_pending: AtomicUsize,
    child_done: AtomicUsize,
    handler_dropped: AtomicUsize,
    producer_dropped: AtomicUsize,
}

impl SenderFailureProbe {
    fn counts(&self) -> [usize; 6] {
        [
            self.admitted.load(Ordering::Acquire),
            self.received.load(Ordering::Acquire),
            self.child_pending.load(Ordering::Acquire),
            self.child_done.load(Ordering::Acquire),
            self.handler_dropped.load(Ordering::Acquire),
            self.producer_dropped.load(Ordering::Acquire),
        ]
    }

    fn spawn_child<T>(self: &Arc<Self>, request: &Request<T>) {
        let probe = Arc::clone(self);
        let cancelled = request.cancelled();
        drop(tokio::spawn(async move {
            let mut cancelled = std::pin::pin!(cancelled);
            let mut registered = false;
            std::future::poll_fn(|cx| {
                let result = cancelled.as_mut().poll(cx);
                if result.is_pending() && !registered {
                    registered = true;
                    probe.child_pending.fetch_add(1, Ordering::Release);
                }
                result
            })
            .await;
            probe.child_done.fetch_add(1, Ordering::Release);
        }));
    }
}

struct SenderFailureGuard {
    probe: Arc<SenderFailureProbe>,
    producer: bool,
}

impl Drop for SenderFailureGuard {
    fn drop(&mut self) {
        let counter = if self.producer {
            &self.probe.producer_dropped
        } else {
            &self.probe.handler_dropped
        };
        counter.fetch_add(1, Ordering::Release);
    }
}

struct SenderFailureService {
    probe: Arc<SenderFailureProbe>,
    echo_first: bool,
}

impl SenderFailureService {
    fn enter<T>(&self, request: &Request<T>) -> SenderFailureGuard {
        self.probe.admitted.fetch_add(1, Ordering::Release);
        self.probe.spawn_child(request);
        SenderFailureGuard {
            probe: Arc::clone(&self.probe),
            producer: false,
        }
    }

    async fn read_first(
        inbound: &mut Streaming<HelloRequest>,
        probe: &SenderFailureProbe,
    ) -> Result<HelloRequest, Status> {
        let first = inbound
            .message()
            .await?
            .ok_or_else(|| Status::internal("empty"))?;
        if first.name().to_str().unwrap_or("") != "ada" {
            return Err(Status::internal("unexpected name"));
        }
        probe.received.fetch_add(1, Ordering::Release);
        Ok(first)
    }
}

impl Greeter for SenderFailureService {
    async fn say_hello(
        &self,
        _request: Request<HelloRequest>,
    ) -> Result<Response<HelloReply>, Status> {
        Err(Status::unimplemented("sender-failure fixture"))
    }

    async fn server_hello(
        &self,
        _request: Request<HelloRequest>,
    ) -> Result<Response<Streaming<HelloReply>>, Status> {
        Err(Status::unimplemented("sender-failure fixture"))
    }

    async fn client_hello(
        &self,
        request: Request<Streaming<HelloRequest>>,
    ) -> Result<Response<HelloReply>, Status> {
        let _guard = self.enter(&request);
        let mut inbound = request.into_inner();
        Self::read_first(&mut inbound, &self.probe).await?;
        std::future::pending().await
    }

    async fn stream_hello(
        &self,
        request: Request<Streaming<HelloRequest>>,
    ) -> Result<Response<Streaming<HelloReply>>, Status> {
        let _guard = self.enter(&request);
        if !self.echo_first {
            let mut inbound = request.into_inner();
            Self::read_first(&mut inbound, &self.probe).await?;
            return std::future::pending().await;
        }
        let cancelled = request.cancelled();
        let mut inbound = request.into_inner();
        let (tx, stream) = Streaming::channel(8);
        let probe = Arc::clone(&self.probe);
        let producer_guard = SenderFailureGuard {
            probe: Arc::clone(&probe),
            producer: true,
        };
        drop(tokio::spawn(async move {
            let _guard = producer_guard;
            let first = Self::read_first(&mut inbound, &probe)
                .await
                .expect("first request message");
            let mut reply = HelloReply::new();
            reply.set_message(first.name());
            tx.send(reply).await.expect("first response message");
            cancelled.await;
            drop(tx);
        }));
        Ok(Response::new(stream))
    }
}

async fn drive_sender_failure<F: std::future::Future>(
    future: F,
    probe: &SenderFailureProbe,
    label: &str,
) -> F::Output {
    // Keep the existing wait_flag budget: 80 ten-millisecond intervals.
    let deadline = Instant::now() + Duration::from_millis(800);
    let mut future = std::pin::pin!(future);
    std::future::poll_fn(|cx| {
        assert!(
            Instant::now() < deadline,
            "sender failure stalled: {label}; [admitted, received, child_pending, child_done, handler_drop, producer_drop]={:?}",
            probe.counts(),
        );
        cx.waker().wake_by_ref();
        future.as_mut().poll(cx)
    })
    .await
}

async fn await_sender_failure_admission<T>(
    call: &mut Call<T>,
    probe: &SenderFailureProbe,
    expected: usize,
) {
    drive_sender_failure(
        std::future::poll_fn(|cx| {
            assert!(
                std::pin::Pin::new(&mut *call).poll(cx).is_pending(),
                "call completed before request failure admission: {:?}",
                probe.counts(),
            );
            if probe.admitted.load(Ordering::Acquire) == expected
                && probe.received.load(Ordering::Acquire) == expected
                && probe.child_pending.load(Ordering::Acquire) == expected
            {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        probe,
        "handler and cancellation-child admission",
    )
    .await;
    assert_eq!(probe.child_done.load(Ordering::Acquire), expected - 1);
    assert_eq!(probe.handler_dropped.load(Ordering::Acquire), expected - 1);
}

async fn await_sender_failure_drop(
    probe: &SenderFailureProbe,
    expected: usize,
    after_headers: bool,
) {
    drive_sender_failure(
        std::future::poll_fn(|_| {
            if probe.child_done.load(Ordering::Acquire) == expected
                && probe.handler_dropped.load(Ordering::Acquire) == expected
                && (!after_headers
                    || probe.producer_dropped.load(Ordering::Acquire) == expected)
            {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        probe,
        "child cancellation and actual owner destruction",
    )
    .await;
    assert_eq!(
        probe.counts(),
        [expected, expected, expected, expected, expected, if after_headers { expected } else { 0 }],
    );
}
