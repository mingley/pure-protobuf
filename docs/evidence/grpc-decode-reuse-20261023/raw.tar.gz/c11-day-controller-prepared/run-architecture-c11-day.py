#!/usr/bin/env python3
"""Launch the pinned streaming resource day, then publish its terminal evidence."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
CHECKOUT = ROOT / 'work/architecture-c11'
PREFIX = 'architecture-c11-day'
OUTPUT = Q / 'resource-architecture-c11-day'
PREVIEW = Q / 'architecture-c11-resource-preview/report.json'
PUBLISHER = Path(__file__).resolve().with_name('publish-architecture-c11-day.py')
SCRIPT = Path(__file__).resolve()
HARNESS = Q / (PREFIX + '-harness')
PINS = Q / 'architecture-c11-source-pins.json'
PINS_SHA256 = '82366dd76dd17d0c8ac4a27609796f7ae82c8b76fa9dc3efb06fd6f91ea3d619'
GRANT = Q / (PREFIX + '-grant.json')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic_json(path, value):
    temporary = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def git(*args):
    return subprocess.run(['git', *args], cwd=CHECKOUT, check=True,
                          text=True, capture_output=True).stdout.strip()


def prerequisites():
    pins_bytes = PINS.read_bytes()
    if hashlib.sha256(pins_bytes).hexdigest() != PINS_SHA256:
        raise ValueError('immutable final C11 source pins changed')
    if json.loads(pins_bytes).get('candidate_runtime') != SOURCE:
        raise ValueError('C11 pins identify another candidate')
    pipeline_path = Q / 'architecture-c11-pipeline-state.json'
    pipeline = json.loads(pipeline_path.read_text())
    pipeline_driver = Q / 'architecture-c11-pipeline.py'
    if hashlib.sha256(pipeline_driver.read_bytes()).hexdigest() != 'f9a6f9f6426553247e76ad71f146861ca0c527f3e6ffd6997ced65002eda539d':
        raise ValueError('final C11 pipeline controller changed')
    if (pipeline.get('state') != 'passed' or pipeline.get('pin') != SOURCE
            or pipeline.get('active') is not None
            or pipeline.get('source_after') != {'head': SOURCE, 'status': ''}
            or pipeline.get('expanded_requested') is not True):
        raise ValueError('complete C11 pipeline including expanded controls has not passed')
    phase_names = {phase.get('name') for phase in pipeline.get('phases', [])}
    required_phases = {'resource-preview', 'decoded-negative-controls', 'resolver-negative-controls',
        'native-counter', 'native-summary', 'cpu-counter', 'cpu-summary',
        'expanded-counter', 'expanded-summary', 'rpc-cache-reclaim', 'asan'}
    if phase_names != required_phases or len(pipeline['phases']) != len(required_phases):
        raise ValueError('C11 pipeline did not retain every required phase exactly once')
    retained = dict(pipeline.get('evidence', {}))
    for phase in pipeline['phases']:
        if phase.get('exit_code') != 0:
            raise ValueError('C11 pipeline phase failed')
        retained.update(phase.get('files', {}))
    for path, expected in retained.items():
        file = Path(path)
        if (not file.is_relative_to(Q) or file.is_symlink()
                or file.stat().st_size != expected['bytes']
                or hashlib.sha256(file.read_bytes()).hexdigest() != expected['sha256']):
            raise ValueError('retained C11 pipeline evidence changed: ' + path)
    for path, expected in pipeline.get('immutable_inputs', {}).items():
        if hashlib.sha256(Path(path).read_bytes()).hexdigest() != expected:
            raise ValueError('C11 immutable pipeline input changed: ' + path)
    gates = {}
    for name in ['checks-state', 'negative-controls-state', 'resolver-negative-controls-state',
                 'asan-supervisor-state', 'rpc-cache-reclaim']:
        path = Q / ('architecture-c11-' + name + '.json')
        data = json.loads(path.read_text())
        if data.get('state') != 'passed':
            raise ValueError('C11 terminal gate has not passed: ' + name)
        gates[name] = {'path': str(path), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
    checks = json.loads((Q / 'architecture-c11-checks-state.json').read_text())
    if checks.get('source') != {'head': SOURCE, 'status': ''}:
        raise ValueError('C11 full check source mismatch')
    asan = json.loads((Q / 'architecture-c11-asan-supervisor-state.json').read_text())
    if asan.get('source_pin') != SOURCE or asan.get('cache_reclaimed') is not True:
        raise ValueError('C11 sanitizer source or reclamation gate failed')
    gate_manifest = {'pins': {'path': str(PINS), 'sha256': PINS_SHA256},
        'pipeline': {'path': str(pipeline_path), 'sha256': hashlib.sha256(pipeline_path.read_bytes()).hexdigest()},
        'terminal_gates': gates, 'pipeline_evidence': retained}
    if git('rev-parse', 'HEAD') != SOURCE:
        raise ValueError('frozen checkout is not the requested source')
    if git('status', '--porcelain', '--untracked-files=all'):
        raise ValueError('frozen checkout has local changes')
    branch = subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=CHECKOUT,
                            capture_output=True)
    if branch.returncode != 1:
        raise ValueError('campaign checkout must remain detached')
    preview_bytes = PREVIEW.read_bytes()
    preview = json.loads(preview_bytes)
    if (preview.get('source', {}).get('commit') != SOURCE
            or preview.get('source', {}).get('dirty') is not False
            or preview.get('smoke', {}).get('status') != 'passed'
            or preview.get('exit_code') != 0
            or preview.get('duration_requested_seconds', 0) < 30
            or preview.get('duration_actual_seconds', 0) < 30
            or preview.get('build', {}).get('profile') != 'release'):
        raise ValueError('pinned release resource preview has not passed')
    controller = CHECKOUT / 'scripts/grpc-resource-campaign.py'
    expected = subprocess.check_output(
        ['git', 'show', SOURCE + ':scripts/grpc-resource-campaign.py'], cwd=ROOT)
    if controller.read_bytes() != expected:
        raise ValueError('campaign controller differs from the pinned source')
    import runpy
    validation_errors = runpy.run_path(str(controller))['validate_report'](preview)
    if validation_errors:
        raise ValueError('C11 resource preview validation failed: ' + repr(validation_errors))
    wanted_preview_limits = {key: {'soft': value, 'hard': value} for key, value in {
        'address_space': 1073741824, 'file_descriptors': 128,
        'same_uid_processes': 4096, 'cpu_seconds': 60}.items()}
    if preview.get('process_limits') != wanted_preview_limits:
        raise ValueError('C11 preview process caps differ from the original fixed caps')
    return {
        'gate_manifest': gate_manifest,
        'preview': {'path': str(PREVIEW), 'sha256': hashlib.sha256(preview_bytes).hexdigest(),
                    'source': preview['source'], 'smoke': preview['smoke'],
                    'duration_actual_seconds': preview['duration_actual_seconds'],
                    'binary': preview.get('binary')},
        'settings': preview.get('settings'),
        'preview_process_limits': preview.get('process_limits_requested'),
        'preview_tool_metadata': preview.get('tools'),
        # These are the unchanged defaults in the verified pinned controller;
        # its CPU allowance is requested duration + 30, hence 86,430 for a day.
        'process_limits': {key: {'soft': value, 'hard': value} for key, value in {
            'address_space': 1024 * 1024 * 1024, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': 86400 + 30}.items()},
        'controller_sha256': hashlib.sha256(expected).hexdigest(),
        'qualified': False,
        'qualification_limit': 'Shared-host pbrs resource duration; this fixture does not exercise the new Prost decoded workspace and cannot qualify its cache for 24 hours. Other release and performance gates remain separate.',
        'prost_decoded_cache_exercised': False,
    }


def campaign_command():
    return [sys.executable, str(HARNESS / 'record.py'),
            str(Q / (PREFIX + '-supervisor')), '90000',
            str(HARNESS / 'run-rust'), 'python3', 'scripts/grpc-resource-campaign.py',
            '--source', SOURCE, '--output', str(OUTPUT), '--duration', '86400',
            '--build-profile', 'release', '--seed', '20261002',
            '--memory-bytes', '1073741824', '--max-fds', '128', '--max-uid-processes', '4096']


def launch():
    Q.mkdir(parents=True, exist_ok=True)
    readiness = prerequisites()
    grant = json.loads(GRANT.read_text())
    if grant.get('source') != SOURCE or grant.get('root_granted') is not True or grant.get('action') != 'launch-c11-resource-day':
        raise ValueError('explicit root C11 resource-day grant required')
    readiness['root_grant'] = {'path': str(GRANT), 'sha256': hashlib.sha256(GRANT.read_bytes()).hexdigest()}
    if OUTPUT.exists() or (Q / (PREFIX + '-launch.json')).exists():
        raise ValueError('this attempt already exists; prior evidence will not be overwritten')
    request = Q / (PREFIX + '-launch-request.json')
    # Exclusive creation prevents two launchers from reserving the same attempt.
    with request.open('x') as stream:
        json.dump({'requested_utc': now(), 'source': SOURCE, 'readiness': readiness}, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    HARNESS.mkdir(exist_ok=False)
    for name in ['run-architecture-c11-day.py', 'publish-architecture-c11-day.py', 'record.py', 'run-rust']:
        source = SCRIPT.parent / name if name.endswith('.py') and name != 'record.py' else ROOT / 'work' / name
        shutil.copy2(source, HARNESS / name)
    shutil.copy2(CHECKOUT / 'scripts/grpc-resource-campaign.py', HARNESS / 'resource-controller.py')
    shutil.copy2(PINS, HARNESS / PINS.name)
    shutil.copy2(GRANT, HARNESS / GRANT.name)
    frozen_supervisor = HARNESS / SCRIPT.name
    log = Q / (PREFIX + '-supervisor.log')
    with log.open('xb') as stream:
        child = subprocess.Popen([sys.executable, str(frozen_supervisor), '--supervise'], cwd=ROOT,
                                 stdin=subprocess.DEVNULL, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True,
                                 close_fds=True)
    # Popen's pid is recorded immediately, even if prerequisite revalidation fails.
    atomic_json(Q / (PREFIX + '-launcher.json'), {
        'state': 'supervisor_spawned', 'pid': child.pid, 'source': SOURCE,
        'started_utc': now(), 'command': [sys.executable, str(frozen_supervisor), '--supervise'],
        'log': str(log), 'qualified': False})
    print(json.dumps({'pid': child.pid, 'log': str(log), 'source': SOURCE}), flush=True)


def supervise():
    Q.mkdir(parents=True, exist_ok=True)
    with (Q / (PREFIX + '.lock')).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        started = time.monotonic()
        termination = {'source': SOURCE, 'supervisor_pid': os.getpid(), 'qualified': False,
            'prost_decoded_cache_exercised': False,
            'qualification_limit': 'The unchanged resource fixture uses pbrs decoding; this does not qualify the Prost decoded workspace cache for 24 hours.'}
        child = None
        try:
            readiness = prerequisites()
            grant = json.loads(GRANT.read_text())
            if grant.get('source') != SOURCE or grant.get('root_granted') is not True or grant.get('action') != 'launch-c11-resource-day':
                raise ValueError('explicit root C11 resource-day grant required')
            if (HARNESS / GRANT.name).read_bytes() != GRANT.read_bytes():
                raise ValueError('root day grant changed after launch')
            if OUTPUT.exists() or (Q / (PREFIX + '-launch.json')).exists():
                raise ValueError('campaign attempt already exists')
            argv = campaign_command()
            env = os.environ.copy()
            for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'ASAN_OPTIONS', 'RUSTUP_TOOLCHAIN']:
                env.pop(key, None)
            env.update(RUSTUP_TOOLCHAIN='stable',
                       CARGO_TARGET_DIR=str(ROOT / 'work/rpc-target'), CARGO_BUILD_JOBS='1')
            harness_hashes = {str(p.relative_to(Q)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(HARNESS.iterdir()) if p.is_file()}
            child = subprocess.Popen(argv, cwd=CHECKOUT, env=env, stdin=subprocess.DEVNULL)
            atomic_json(Q / (PREFIX + '-launch.json'), {
                'state': 'running', 'source': SOURCE, 'pid': child.pid,
                'pid_role': 'record_wrapper',
                'supervisor_pid': os.getpid(), 'started_utc': now(),
                'cwd': str(CHECKOUT), 'command': argv,
                'requested_duration_seconds': 86400, 'wrapper_timeout_seconds': 90000,
                'readiness': readiness, 'qualified': False,
                'harness': harness_hashes})
            termination['exit_code'] = child.wait()
            termination['source_pin_verified_at_end'] = (
                git('rev-parse', 'HEAD') == SOURCE
                and not git('status', '--porcelain', '--untracked-files=all'))
            termination['state'] = 'terminated'
            report_path = OUTPUT / 'report.json'
            if report_path.exists():
                report = json.loads(report_path.read_text())
                termination['tool_metadata_matches_preview'] = (report.get('tools') == readiness['preview_tool_metadata'])
        except Exception as error:
            termination.update(state='supervisor_failed', error=str(error))
            traceback.print_exc()
            if child is not None and child.poll() is None:
                # Do not publish a live campaign if writing its launch record
                # failed. The record wrapper still owns the 90,000s timeout.
                termination['exit_code'] = child.wait()
        termination.update(ended_utc=now(), supervisor_elapsed_seconds=time.monotonic() - started)
        atomic_json(Q / (PREFIX + '-termination.json'), termination)
        # Archive only terminal logs; the publisher must not hash its own active stdout.
        # The publisher reports missing/incomplete reports truthfully as well.
        publication_error = None
        try:
            result = subprocess.run([sys.executable, str(HARNESS / PUBLISHER.name)], cwd=ROOT,
                                    stdin=subprocess.DEVNULL)
            publication_code = result.returncode
        except Exception as error:
            publication_code = 1
            publication_error = str(error)
            traceback.print_exc()
        if publication_code:
            state_path = Q / (PREFIX + '-publication.json')
            previous = json.loads(state_path.read_text()) if state_path.is_file() else {}
            if previous.get('state') not in ('failed', 'published'):
                atomic_json(state_path, {
                    'state': 'failed', 'source': SOURCE, 'qualified': False,
                    'ended_utc': now(), 'publisher_exit_code': publication_code,
                    'error': publication_error or 'Publisher exited without a terminal publication record.',
                    'previous_state': previous})
            print(f'publisher failed with exit code {publication_code}; retained records identify the failure',
                  flush=True)
        return publication_code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--launch', action='store_true', help='detach a durable supervisor; requires passing preview')
    mode.add_argument('--check-ready', action='store_true', help='read-only prerequisite validation; starts nothing')
    mode.add_argument('--supervise', action='store_true', help='internal durable process mode')
    args = parser.parse_args()
    if args.check_ready:
        print(json.dumps(prerequisites(), indent=2))
    elif args.launch:
        launch()
    else:
        raise SystemExit(supervise())
