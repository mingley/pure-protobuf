from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';pins=json.loads((q/'architecture-c4-source-pins.json').read_text())
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
replacements=[(str(root/'work/validation-fixes'),str(root/'work/architecture-b4')),("root/'work/validation-fixes'","root/'work/architecture-b4'"),('architecture-c1-baseline-rpc-build','architecture-b4-rpc-build'),('architecture-c3','architecture-c4'),('783bcd53c723032cd0ccbff5d4550f9a1c92cbb8',pins['candidate_benchmark']),('6cd91911afce24cceee6df3f60a945453e5b04da',pins['baseline_benchmark']),('FINALC3','FINALC4')]
def replace(value):
 if isinstance(value,str):
  for a,b in replacements:value=value.replace(a,b)
  return value
 if isinstance(value,list):return [replace(v) for v in value]
 if isinstance(value,dict):return {replace(k):replace(v) for k,v in value.items()}
 return value
for stem in ['counter-ab-driver.py','ab-summary.py','selected-native-workloads.json','instruction-pilot-workload.json','counter-summary.py','native-ab-summary.py','legacy-summary.py','oversized-workloads.json','oversized-pilot-workload.json','instruction-focused72-workloads.json','instruction-with_unary108-workloads.json','instruction-with_pipeline144-workloads.json']:
 (q/('architecture-c4-'+stem)).write_bytes((q/('architecture-c3-'+stem)).read_bytes())
# The external controller default source pin must match the explicitly passed B4 pin, too.
p=q/'architecture-c4-counter-ab-driver.py';p.write_text(p.read_text().replace("BASELINE_COMMIT = '6cd91911afce24cceee6df3f60a945453e5b04da'", "BASELINE_COMMIT = '"+pins['baseline_benchmark']+"'"))
record=replace(json.loads((q/'architecture-c3-measurement-plan.json').read_text()))
record.update(state='prepared_not_executed_B4_C4_builds_and_parent_quiet_grant_pending',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_note='C4 benchmark source has runtime783; B4 benchmark source has runtime6cd. Both include the identical matched benchmark settings patch. All prior C1/C2/C3 plans, builds and controls remain historical.')
record['runtime_sources']={'baseline':pins['baseline_runtime'],'candidate':pins['candidate_runtime']}
record['benchmark_fairness']=dict(source_pins_record=str(q/'architecture-c4-source-pins.json'),benchmark_sha256=pins['identical_benchmark_sha256'],native_server_send_buffer_bytes=400*1024,tonic_server_send_buffer='Hyper1.11 default400KiB',native_request_queue=16,tonic_request_queue=16,observability='Native production observability remains enabled; no transport validation removed.',interpretation='Native/prost versus tonic/prost uses the closest handler parity. Pbrs handler application logic differs; cross-codec differences do not isolate codec cost.')
record['summaries'].pop('full_native_historical_source_comparison',None)
record['not_run']={'full_b4_expanded_baseline':dict(state='NOT_RUN',reason='Selected400, CPU and oversized scopes provide matched B4/C4 source comparisons. Historical full6cd captures use different benchmark settings and cannot establish runtime-only gains in the full C4 matrix.')}
record['limits']=[value for value in record['limits'] if not any(term in value for term in ['Fresh6cd','historical6cd','ELF bd3','ELF ed550'])]
record['limits']+=['B4/C4 source comparisons are limited to retained matched selected ABBA, CPU and oversized captures. No historical full-matrix baseline is treated as a matched runtime-only Before result.',
'Full C4 expanded matrix compares native and tonic within the same matched-settings source and capture harness.',
'Baseline benchmark2eba72d8 maps exactly to runtime6cd; candidate benchmark804b5c59 maps exactly to runtime783. Source tree equivalence is verified for the recorded runtime paths.',
'All C1/C2/C3 ELF, settings and capture records remain unchanged historical evidence.']
record['harness_hashes']={f:digest(root/'work/architecture-c4'/f) for f in record['harness_hashes']}
record['controller_hashes']={f:digest(q/f) for f in record['controller_hashes']}
for phase in ['selected_native_ab','instruction_pilot']:
 argv=record[phase]['argv']+['--plan'];r=subprocess.run(argv,text=True,capture_output=True,check=True)
 (q/f'architecture-c4-{phase}-argv-plan.json').write_text(json.dumps(dict(argv=argv,result=json.loads(r.stdout)),indent=2)+'\n')
for kind in ['oversized-final-plan','instruction-expansion-plan']:
 s=replace(json.loads((q/f'architecture-c3-{kind}.json').read_text()))
 s['state']='PREPARED_NOT_EXECUTED_B4_C4_BUILDS_AND_PARENT_QUIET_GRANT_PENDING'
 if kind=='oversized-final-plan':
  s['driver_sha256']=digest(q/'architecture-c4-counter-ab-driver.py');s['baseline_source']=pins['baseline_benchmark'];s['candidate_source']=pins['candidate_benchmark'];s['runtime_sources']=record['runtime_sources']
  for row in s['phases'].values():
   r=subprocess.run(row['argv']+['--plan'],text=True,capture_output=True,check=True);row['offline_plan']=json.loads(r.stdout)
 else:
  for row in s['options'].values():
   r=subprocess.run(row['argv']+['--plan'],text=True,capture_output=True,check=True);row['offline_argv_plan']=json.loads(r.stdout)
 s['limits'].append('Both benchmark sources have identical matched400KiB native server send buffer and16message producer queues. Runtime source identity is recorded separately from benchmark settings source identity.')
 (q/f'architecture-c4-{kind}.json').write_text(json.dumps(s,indent=2)+'\n')
(q/'architecture-c4-measurement-plan.json').write_text(json.dumps(record,indent=2)+'\n')
preflight=replace((q/'architecture-c3-build-preflight.py').read_text())
(q/'architecture-c4-build-preflight.py').write_text(preflight)
print(json.dumps(dict(state=record['state'],benchmark_sources=record['sources'],runtime_sources=record['runtime_sources'],phases={key:record[key]['expected_captures'] for key in ['native_expanded','selected_native_ab','instruction_pilot']},full_b4_expanded_baseline=record['not_run']['full_b4_expanded_baseline']),indent=2))
