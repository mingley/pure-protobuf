"""Detached read-only build verification, then parent disk-gated final marker."""
from pathlib import Path
import datetime,json,subprocess,time
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';pin='9d6fb9c416fc32732450fd78d32ee16ff8b802de';started=time.monotonic();deadline=started+3600
state=dict(source=pin,state='WAITING_FOR_RELEASE_BUILD',started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),no_capture=True)
def save():
 state['elapsed_seconds']=time.monotonic()-started;p=q/'architecture-c8-release-followup-state.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(p)
def execute(label,argv):
 with (q/('architecture-c8-release-followup-'+label+'.stdout')).open('xb') as stdout,(q/('architecture-c8-release-followup-'+label+'.stderr')).open('xb') as stderr:
  r=subprocess.run(argv,cwd=root,stdout=stdout,stderr=stderr,timeout=120)
 if r.returncode:raise RuntimeError(label+' exit'+str(r.returncode))
save()
try:
 while not (q/'architecture-c8-rpc-build/build.json').is_file():
  record=q/'architecture-c8-rpc-build-run.json'
  if record.is_file() and json.loads(record.read_text()).get('exit_code')!=0:raise RuntimeError('release recorder reports failure; records retained')
  if time.monotonic()>deadline:raise TimeoutError('release build record did not appear')
  time.sleep(1)
 execute('verification',['python3',str(q/'architecture-c8-build-preflight.py'),'--verify-only'])
 state['state']='VERIFIED_WAITING_FOR_PARENT_DISK_GATE';save()
 gate=q/'architecture-c8-workspace-disk-ready.json'
 while True:
  if gate.is_file():
   data=json.loads(gate.read_text())
   if data.get('source')==pin and data.get('cache_reclaimed') is True:break
  if time.monotonic()>deadline:raise TimeoutError('matching parent disk gate did not appear')
  time.sleep(1)
 execute('preflight',['python3',str(q/'architecture-c8-build-preflight.py')])
 state['state']='FINAL_PREFLIGHT_COMPLETE';state['marker']=str(q/'architecture-c8-build-preflight.json');save()
except BaseException as error:
 state['state']='FAILED';state['error']=dict(type=type(error).__name__,message=str(error));save();raise
