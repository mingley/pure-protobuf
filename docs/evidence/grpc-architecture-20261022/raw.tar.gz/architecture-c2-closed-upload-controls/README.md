# Closed-upload negative controls

Source-attested original 902014588792c8eb9c5bd65c782704e099535259 release libraries: standalone test compilation succeeds; execution has **3 positive controls pass and 9 intended failures**, with no ignored tests.

| Check | Original 902 result |
| --- | --- |
| Client-stream ordinary headers alone, then full upload after credit | Pass |
| Client-stream response transport error without upload credit | Pass; valid unary recovery |
| Bidi response transport error without upload credit | Pass; valid unary recovery |
| Client-stream and bidi trailers-only rejection without credit | Both fail the two-second external guard |
| Client-stream and bidi rejection followed by actual NO_ERROR reset | Both fail exact status: Unavailable instead of ResourceExhausted |
| Bidi headers and first reply before upload credit | Fails external guard |
| Complete client-stream reply and OK before upload credit | Fails external guard |
| Dropping a live bidi reply releases blocked upload budget | Fails earlier while awaiting headers |
| Multiple closed batches respect their aggregate finite byte budget | Client-stream and bidi fail external guard rather than rejecting allocation |

All cases use a raw registry h2 peer, an initial zero stream window, a completed PING/ACK barrier before the first RPC, and an explicit request-body Pending witness. No RPC timeout is configured. The NO_ERROR cases observe complete terminal HEADERS written to TCP before enqueueing reset, and observe the actual NO_ERROR RST frame written before proceeding. They therefore do not mistake a response discarded inside the peer's send queue for transmitted rejection headers. Handles are retained and the peer does not impose its own RPC timer.

`manifest.json` preserves source build attribution, exact commands and source/rlib/executable hashes; all recorded input release rlib/rmeta hashes remained unchanged. `original902-run.stdout` and `.stderr` preserve the complete failures. `compile-attempt-1/` preserves initial harness compile diagnostics. `attempt-2-call-polling-corrected/` preserves a rejected harness run whose client-stream positive control awaited the upload witness without continuing to poll its Call; the final harness corrects this ordering and that positive control passes.

`probe.rs` is the exact executed negative-control harness. `final-source.rs`, `final-source.json`, and `final-recovery-addition.patch` preserve the final tracked test source, which additionally performs a successful unary after its two rejection assertions. That addition runs strictly after the old902 failures and has not been claimed as executed against old902. The integrated C2 gate must validate the complete final tracked tests.

These are functional ordering and resource-ownership controls on a contended host, not performance qualification or a complete production-readiness claim.

## Focused C2 gate fixture corrections

The first C2 gate passed 10 cases and failed two later recovery checks. Both were harness issues, preserved in the root gate logs and `../architecture-c2-recovery-trace/`:

- The live bidi response still owned its documented concurrency permit after EOF/trailers. The test now drops that completed response before starting the next RPC.
- The no-reset rejection peer granted stream credit immediately after queuing the second rejection, before the client had observed it. Actual frame tracing showed the SETTINGS update preceding terminal HEADERS, then exactly 65,535 bytes of stream3 upload DATA consuming connection receive credit in an intentionally retained, unread request body. Recovery stream5 HEADERS arrived, but no DATA could flow. The corrected peer waits for an explicit client acknowledgment after both exact rejection assertions and byte-accounting checks. It then releases the completed request handles and grants recovery credit. This keeps both uploads at zero credit for the entire behavior being checked.

`post-gate-fixture/` preserves the corrected final test source and exact delta. No runtime change was required by this investigation. Root's integrated positive rerun is the authority for that final source.
