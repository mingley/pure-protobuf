fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<usize, Status> {
        loop {
            match decoder.read(target) {
                Ok(n) if n <= target.len() => return Ok(n),
                Ok(_) => return Err(Status::internal("compression decode: invalid read length")),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    let exceeded =
        || Status::resource_exhausted(format!("decompressed message exceeds limit {budget}"));
    let mut first = [0u8; 8192];
    let want = budget.saturating_add(1).min(first.len());
    let target = first
        .get_mut(..want)
        .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
    let n = read_retry(&mut decoder, target, coding)?;
    if n == 0 {
        return Ok(Vec::new());
    }
    if n > budget {
        return Err(exceeded());
    }
    let mut out = Vec::new();
    let capacity = n.max(compressed_length.min(256 * 1024)).min(budget);
    out.try_reserve_exact(capacity)
        .map_err(|_| Status::resource_exhausted("decompressed message allocation failed"))?;
    // Initialize each new tail once, then read directly into it. Keeping the
    // used length separately avoids repeated clearing and per-chunk copies.
    out.resize(capacity, 0);
    out.get_mut(..n)
        .ok_or_else(|| Status::internal("compression decode: short output"))?
        .copy_from_slice(
            first
                .get(..n)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
        );
    let mut used = n;
    loop {
        if used == out.len() {
            // Probe before growing: exact fits need no spare heap capacity,
            // and EOF must still validate the coding's checksum/trailer.
            let probe = first
                .get_mut(..1)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let n = read_retry(&mut decoder, probe, coding)?;
            if n == 0 {
                out.truncate(used);
                return Ok(out);
            }
            if used == budget {
                return Err(exceeded());
            }
            let capacity = out.len().saturating_mul(2).max(used + 1).min(budget);
            out.try_reserve_exact(capacity - out.len()).map_err(|_| {
                Status::resource_exhausted("decompressed message allocation failed")
            })?;
            out.resize(capacity, 0);
            *out.get_mut(used)
                .ok_or_else(|| Status::internal("compression decode: short output"))? =
                probe.first().copied().unwrap_or_default();
            used += 1;
            // A cap one byte past the previous capacity is now full. Loop
            // back to probe it; reading an empty tail would falsely mean EOF.
            continue;
        }
        let target = out
            .get_mut(used..)
            .ok_or_else(|| Status::internal("compression decode: short output"))?;
        let n = read_retry(&mut decoder, target, coding)?;
        if n == 0 {
            out.truncate(used);
            return Ok(out);
        }
        used += n;
    }
}
