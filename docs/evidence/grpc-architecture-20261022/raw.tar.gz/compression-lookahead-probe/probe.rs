use std::io::Write;
use std::sync::atomic::{AtomicU64, Ordering};
struct Counting;
static ALLOCS: AtomicU64 = AtomicU64::new(0);
static BYTES: AtomicU64 = AtomicU64::new(0);
unsafe impl std::alloc::GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: std::alloc::Layout) -> *mut u8 {
        ALLOCS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
        unsafe { std::alloc::System.alloc(layout) }
    }
    unsafe fn dealloc(&self, ptr: *mut u8, layout: std::alloc::Layout) {
        unsafe { std::alloc::System.dealloc(ptr, layout) }
    }
    unsafe fn realloc(&self, ptr: *mut u8, layout: std::alloc::Layout, size: usize) -> *mut u8 {
        ALLOCS.fetch_add(1, Ordering::Relaxed);
        BYTES.fetch_add(size as u64, Ordering::Relaxed);
        unsafe { std::alloc::System.realloc(ptr, layout, size) }
    }
}
#[global_allocator] static ALLOCATOR: Counting = Counting;
#[derive(Debug, PartialEq, Eq)]
struct Status { code: &'static str, message: String }
impl Status {
    fn internal(message: impl Into<String>) -> Self { Self { code: "internal", message: message.into() } }
    fn resource_exhausted(message: impl Into<String>) -> Self { Self { code: "resource_exhausted", message: message.into() } }
}

mod baseline { use super::Status;
pub(super) fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<usize, Status> {
        loop {
            match decoder.read(target) {
                Ok(n) if n <= target.len() => return Ok(n),
                Ok(_) => return Err(Status::internal("compression decode: invalid read length")),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    let exceeded =
        || Status::resource_exhausted(format!("decompressed message exceeds limit {budget}"));
    let mut first = [0u8; 8192];
    let want = budget.saturating_add(1).min(first.len());
    let target = first
        .get_mut(..want)
        .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
    let n = read_retry(&mut decoder, target, coding)?;
    if n == 0 {
        return Ok(Vec::new());
    }
    if n > budget {
        return Err(exceeded());
    }
    let mut out = Vec::new();
    let capacity = n.max(compressed_length.min(256 * 1024)).min(budget);
    out.try_reserve_exact(capacity)
        .map_err(|_| Status::resource_exhausted("decompressed message allocation failed"))?;
    // Initialize each new tail once, then read directly into it. Keeping the
    // used length separately avoids repeated clearing and per-chunk copies.
    out.resize(capacity, 0);
    out.get_mut(..n)
        .ok_or_else(|| Status::internal("compression decode: short output"))?
        .copy_from_slice(
            first
                .get(..n)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
        );
    let mut used = n;
    loop {
        if used == out.len() {
            // Probe before growing: exact fits need no spare heap capacity,
            // and EOF must still validate the coding's checksum/trailer.
            let probe = first
                .get_mut(..1)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let n = read_retry(&mut decoder, probe, coding)?;
            if n == 0 {
                out.truncate(used);
                return Ok(out);
            }
            if used == budget {
                return Err(exceeded());
            }
            let capacity = out.len().saturating_mul(2).max(used + 1).min(budget);
            out.try_reserve_exact(capacity - out.len()).map_err(|_| {
                Status::resource_exhausted("decompressed message allocation failed")
            })?;
            out.resize(capacity, 0);
            *out.get_mut(used)
                .ok_or_else(|| Status::internal("compression decode: short output"))? =
                probe.first().copied().unwrap_or_default();
            used += 1;
            // A cap one byte past the previous capacity is now full. Loop
            // back to probe it; reading an empty tail would falsely mean EOF.
            continue;
        }
        let target = out
            .get_mut(used..)
            .ok_or_else(|| Status::internal("compression decode: short output"))?;
        let n = read_retry(&mut decoder, target, coding)?;
        if n == 0 {
            out.truncate(used);
            return Ok(out);
        }
        used += n;
    }
}
}
mod candidate { use super::Status;
pub(super) fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<usize, Status> {
        loop {
            match decoder.read(target) {
                Ok(n) if n <= target.len() => return Ok(n),
                Ok(_) => return Err(Status::internal("compression decode: invalid read length")),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    // A short Read is not EOF. Fill the bounded lookahead so adversarial short
    // reads cannot cause one reallocation per byte, or bypass trailer checks.
    fn read_chunk(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<(usize, bool), Status> {
        let mut used = 0;
        while used < target.len() {
            let tail = target
                .get_mut(used..)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let n = read_retry(decoder, tail, coding)?;
            if n == 0 {
                return Ok((used, true));
            }
            used += n;
        }
        Ok((used, false))
    }
    fn reserve(out: &mut Vec<u8>, capacity: usize, budget: usize) -> Result<(), Status> {
        out.try_reserve_exact(capacity - out.len())
            .map_err(|_| Status::resource_exhausted("decompressed message allocation failed"))?;
        if out.capacity() > budget {
            return Err(Status::resource_exhausted(
                "decompressed message allocation exceeds limit",
            ));
        }
        Ok(())
    }
    let exceeded =
        || Status::resource_exhausted(format!("decompressed message exceeds limit {budget}"));
    let mut chunk = [0u8; 8192];
    let want = budget.saturating_add(1).min(chunk.len());
    let target = chunk
        .get_mut(..want)
        .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
    let (n, eof) = read_chunk(&mut decoder, target, coding)?;
    if n > budget {
        return Err(exceeded());
    }
    if n == 0 {
        return Ok(Vec::new());
    }
    let mut out = Vec::new();
    let capacity = if eof {
        n
    } else {
        n.max(compressed_length.min(256 * 1024)).min(budget)
    };
    reserve(&mut out, capacity, budget)?;
    out.extend_from_slice(
        chunk
            .get(..n)
            .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
    );
    if eof {
        return Ok(out);
    }
    // Keep used length separately and initialize each unread tail once. Reads
    // between growths go directly into output, without per-chunk heap copies.
    out.resize(capacity, 0);
    let mut used = n;
    loop {
        if used == out.len() {
            // Observe the final tail before growing. For output just beyond a
            // capacity boundary (for example a 64 KiB protobuf plus headers),
            // EOF gives an exact reservation instead of doubling the buffer.
            // At the budget this is exactly the required one-byte probe.
            let want = (budget - used).saturating_add(1).min(chunk.len());
            let target = chunk
                .get_mut(..want)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let (n, eof) = read_chunk(&mut decoder, target, coding)?;
            if n > budget - used {
                return Err(exceeded());
            }
            if n == 0 {
                return Ok(out);
            }
            let decoded = used + n;
            let capacity = if eof {
                decoded
            } else {
                used.saturating_mul(2).max(decoded).min(budget)
            };
            reserve(&mut out, capacity, budget)?;
            out.extend_from_slice(
                chunk
                    .get(..n)
                    .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
            );
            if eof {
                return Ok(out);
            }
            out.resize(capacity, 0);
            used = decoded;
            // A clipped budget may now be full. Loop back for the overflow /
            // EOF probe; an empty read target would falsely prove completion.
            continue;
        }
        let target = out
            .get_mut(used..)
            .ok_or_else(|| Status::internal("compression decode: short output"))?;
        let n = read_retry(&mut decoder, target, coding)?;
        if n == 0 {
            out.truncate(used);
            return Ok(out);
        }
        used += n;
    }
}
}

fn decode(input: &[u8], budget: usize, candidate: bool) -> Result<Vec<u8>, Status> {
    let decoder = flate2::bufread::MultiGzDecoder::new(input);
    if candidate { candidate::read_bounded(decoder, budget, input.len(), "gzip") }
    else { baseline::read_bounded(decoder, budget, input.len(), "gzip") }
}
fn main() {
    let budget = 4 * 1024 * 1024;
    for size in [0, 1, 1001, 8191, 8192, 8193, 65535, 65536, 65537, 65539, 65550, 73728, 1048576, 1048583] {
        for noise in [false, true] {
            let mut seed = 0x5eeda5e5u64;
            let payload: Vec<u8> = (0..size).map(|_| {
                if !noise { return 0; }
                seed ^= seed << 13; seed ^= seed >> 7; seed ^= seed << 17; seed as u8
            }).collect();
            let mut encoder = flate2::write::GzEncoder::new(Vec::new(), flate2::Compression::new(6));
            encoder.write_all(&payload).unwrap();
            let encoded = encoder.finish().unwrap();
            for max_decoded in [size, budget] {
                for repeat in 0..4 {
                    let order = if repeat % 2 == 0 { [false, true] } else { [true, false] };
                    for candidate in order {
                        let proof = decode(&encoded, max_decoded, candidate).unwrap();
                        assert_eq!(proof, payload);
                        assert!(proof.capacity() <= max_decoded);
                        let capacity = proof.capacity();
                        drop(proof);
                        let allocations = ALLOCS.load(Ordering::Relaxed);
                        let requested = BYTES.load(Ordering::Relaxed);
                        for _ in 0..20 {
                            let output = decode(std::hint::black_box(&encoded), max_decoded, candidate).unwrap();
                            assert_eq!(output.len(), size);
                            std::hint::black_box(output);
                        }
                        let allocations = ALLOCS.load(Ordering::Relaxed) - allocations;
                        let requested = BYTES.load(Ordering::Relaxed) - requested;
                        println!("{{\"kind\":\"allocations\",\"size\":{size},\"noise\":{noise},\"compressed_length\":{},\"budget\":{max_decoded},\"candidate\":{candidate},\"repeat\":{repeat},\"rounds\":20,\"capacity\":{capacity},\"allocations\":{allocations},\"requested_bytes\":{requested}}}", encoded.len());
                    }
                }
            }
            for mutation in ["crc", "isize", "truncated"] {
                let mut bad = encoded.clone();
                if mutation == "truncated" { bad.pop(); }
                else {
                    let offset = if mutation == "crc" { bad.len() - 8 } else { bad.len() - 4 };
                    bad[offset] ^= 0x80;
                }
                for candidate in [false, true] {
                    let error = decode(&bad, budget, candidate).expect_err("forged trailer");
                    assert_eq!(error.code, "internal");
                    println!("{{\"kind\":\"malformed\",\"size\":{size},\"noise\":{noise},\"mutation\":\"{mutation}\",\"candidate\":{candidate},\"code\":\"{}\"}}",error.code);
                }
            }
        }
    }
}
