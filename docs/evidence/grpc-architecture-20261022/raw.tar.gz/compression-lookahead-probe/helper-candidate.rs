fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<usize, Status> {
        loop {
            match decoder.read(target) {
                Ok(n) if n <= target.len() => return Ok(n),
                Ok(_) => return Err(Status::internal("compression decode: invalid read length")),
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    // A short Read is not EOF. Fill the bounded lookahead so adversarial short
    // reads cannot cause one reallocation per byte, or bypass trailer checks.
    fn read_chunk(
        decoder: &mut impl std::io::Read,
        target: &mut [u8],
        coding: &str,
    ) -> Result<(usize, bool), Status> {
        let mut used = 0;
        while used < target.len() {
            let tail = target
                .get_mut(used..)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let n = read_retry(decoder, tail, coding)?;
            if n == 0 {
                return Ok((used, true));
            }
            used += n;
        }
        Ok((used, false))
    }
    fn reserve(out: &mut Vec<u8>, capacity: usize, budget: usize) -> Result<(), Status> {
        out.try_reserve_exact(capacity - out.len())
            .map_err(|_| Status::resource_exhausted("decompressed message allocation failed"))?;
        if out.capacity() > budget {
            return Err(Status::resource_exhausted(
                "decompressed message allocation exceeds limit",
            ));
        }
        Ok(())
    }
    let exceeded =
        || Status::resource_exhausted(format!("decompressed message exceeds limit {budget}"));
    let mut chunk = [0u8; 8192];
    let want = budget.saturating_add(1).min(chunk.len());
    let target = chunk
        .get_mut(..want)
        .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
    let (n, eof) = read_chunk(&mut decoder, target, coding)?;
    if n > budget {
        return Err(exceeded());
    }
    if n == 0 {
        return Ok(Vec::new());
    }
    let mut out = Vec::new();
    let capacity = if eof {
        n
    } else {
        n.max(compressed_length.min(256 * 1024)).min(budget)
    };
    reserve(&mut out, capacity, budget)?;
    out.extend_from_slice(
        chunk
            .get(..n)
            .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
    );
    if eof {
        return Ok(out);
    }
    // Keep used length separately and initialize each unread tail once. Reads
    // between growths go directly into output, without per-chunk heap copies.
    out.resize(capacity, 0);
    let mut used = n;
    loop {
        if used == out.len() {
            // Observe the final tail before growing. For output just beyond a
            // capacity boundary (for example a 64 KiB protobuf plus headers),
            // EOF gives an exact reservation instead of doubling the buffer.
            // At the budget this is exactly the required one-byte probe.
            let want = (budget - used).saturating_add(1).min(chunk.len());
            let target = chunk
                .get_mut(..want)
                .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
            let (n, eof) = read_chunk(&mut decoder, target, coding)?;
            if n > budget - used {
                return Err(exceeded());
            }
            if n == 0 {
                return Ok(out);
            }
            let decoded = used + n;
            let capacity = if eof {
                decoded
            } else {
                used.saturating_mul(2).max(decoded).min(budget)
            };
            reserve(&mut out, capacity, budget)?;
            out.extend_from_slice(
                chunk
                    .get(..n)
                    .ok_or_else(|| Status::internal("compression decode: short buffer"))?,
            );
            if eof {
                return Ok(out);
            }
            out.resize(capacity, 0);
            used = decoded;
            // A clipped budget may now be full. Loop back for the overflow /
            // EOF probe; an empty read target would falsely prove completion.
            continue;
        }
        let target = out
            .get_mut(used..)
            .ok_or_else(|| Status::internal("compression decode: short output"))?;
        let n = read_retry(&mut decoder, target, coding)?;
        if n == 0 {
            out.truncate(used);
            return Ok(out);
        }
        used += n;
    }
}
