# C9 documentation drafts

Qualification-only drafts. No shipping edits. Replace the pending C9 pin and
outcome only from completed `architecture-c9-workspace-final` records. Never
prefill a passing count. Root owns the evidence capsule and root README.

## Source and result ledger for every page

| Record | Actual source | Result |
|---|---|---|
| Runtime and release benchmark binary | `9d6fb9c4` | Build passes; no fresh performance captures yet. |
| C8 full workspace | clean `9d6fb9c4` | **3,753 passed, two failed, nine existing ignores**, 139 targets. Failure retained. |
| C8 AddressSanitizer, leak detection | `9d6fb9c4` | **731 passed, one existing ignore.** |
| C8 pre-workspace checks | clean `9d6fb9c4` | All ten pass; retain their individual commands and scopes. |
| C9 complete workspace | Pin pending; only `serving.rs` changes from C8 | **Pending.** Verify whole-source equivalence before describing it. |
| C9 resource-supervisor offline controls | Preserve actual control record scope | **24 pass.** No actual resource preview or day-long result. |
| Fresh matched performance captures | No completed capture | **Pending.** No current performance figures. |

The C9 fixture repair does not turn the C8 failed workspace into a pass, and
does not repin C8 sanitizer, library or release-binary runs to C9. Earlier C3
failures and interrupted-recorder disclosure, C7 compile-only supersession and
C8 intermediate failures remain in the evidence capsule.

## docs/benchmarks.md — full replacement structure before results

````markdown
# Benchmarks

Production readiness and a broad speed advantage over tonic/prost remain
unproved. Fresh captures of runtime `9d6fb9c4` have not completed.

## Current comparison

The corrected harness matches server send buffers at **400 KiB** and request
queues at **16**. Shipping defaults are unchanged. Native accounting and
channelz remain enabled. Equal prost handlers compare public API costs, not a
bare kernel; the pbrs route includes additional interop-handler work.

| Result | Status |
|---|---|
| Selected worst-cost source pairs | Pending |
| Expanded current native-versus-tonic matrix | Pending |
| Qualified CPU, latency and throughput | Open |
| Retained memory and actual 24-hour resources | Open |

The expanded current matrix and selected source-paired comparisons have
different coverage. Do not use an older full matrix as an uncaptured Before
column. Gzip comparisons use level 6 on both stacks. Payload sizes describe
zero-filled application bytes; encoded messages also contain protobuf fields.
Streaming cases send four messages per direction where specified.

Once captures complete, report the largest remaining costs first, then measured
source improvements and regressions. Use allocations/RPC and KiB/RPC in separate
tables, with each side and codec identified. Requested allocation bytes are
cumulative requests, not retained memory or RSS. Fewer allocations do not alone
prove lower CPU or faster calls.

[Current investigation and raw records](evidence/grpc-architecture-20261022/README.md)
· [Benchmark contract](benchmark-contract.md)

## Run the comparison

Use a clean source checkout with Rust, Cargo and protoc on `PATH`. Keep build
outputs outside the checkout. The build record pins source, tools and binary.

```sh
source_commit=$(git rev-parse HEAD)
bench_output=$(mktemp -d)
python3 scripts/build-rpc-bench.py \
  --source "$source_commit" --output "$bench_output/build"
python3 scripts/grpc-counter-campaign.py \
  --source-checkout "$PWD" \
  --binary "$bench_output/build/rpc-bench" \
  --build-record "$bench_output/build/build.json" \
  --output "$bench_output/counters" --phase native \
  --payloads 1024,65536 --load-levels 1:1,1:16 --repeats 3
```

Run selected before/after sources with identical harness code on a quiet host.
Verify offered and completed calls and retain failures. The native phase records
allocations, requested bytes and raw process context switches; it does not
measure instructions, syscalls or task wakeups. Separate profiler captures need
their own scope. Neither phase by itself qualifies native latency or throughput.

## Earlier results

The [earlier streaming record](evidence/grpc-streaming-20261022/README.md) retains
selected allocation gains and large gzip/identity byte and instruction losses.
It used unequal send buffers and bidi queue depths. Those numeric comparisons
describe their historical sources/settings and are not a matched baseline for
the corrected harness.

The [scoreboard](scoreboard.md) tracks missing qualification, including broader
payloads, real field access, overload, cold connections and real-network traffic.
````

The fenced page above is a temporary no-results state, not the requested final
numeric page. After actual capture results arrive, replace the status table and
instructional table paragraph with compact measured tables. Aim for about 100
lines total; do not publish placeholder numbers or an old “Now” column.

## docs/status.md — replace current qualification paragraphs

At runtime `9d6fb9c4`, AddressSanitizer with leak detection passes **731 tests**
with one existing ignore. All ten clean-source pre-workspace checks pass, and
the source-attested release binary builds successfully. The full workspace
nevertheless fails: **3,753 passed, two failed and nine existing ignores** across
139 targets. Keep that original failed result and logs.

The remaining serving deadline fixtures are being repaired without changing
production code. A new C9 whole-workspace run is pending; its source pin and
equivalence record must identify the `serving.rs` difference. C8 sanitizer,
library and binary results remain pinned to C8. Twenty-four resource-supervisor
offline controls pass; an actual current preview and day-long campaign have not
started. Fresh benchmark captures and a broad speed ranking remain unproved.

## docs/scoreboard.md — current checks paragraph

Runtime `9d6fb9c4` passes 731 leak-detecting sanitizer tests with one existing
ignore and all ten clean-source pre-workspace checks. Its full workspace fails
with 3,753 passes, two failures and nine existing ignores across 139 targets.
A new workspace run with serving-only fixture repairs is pending. The original
failure remains recorded. Fresh measurements and actual day-long qualification
are still open; no performance standing changes.

## TODO.md — current priorities

The immediate gate is a genuine clean C9 workspace run after deterministic
serving-fixture repairs. Preserve C8's failed 3,753/2/9 result. C8's sanitizer,
library and release-binary proofs stay at `9d6fb9c4`; only an explicit equivalence
record may connect their unchanged runtime to the later qualification source.

| Work | Next result | Completion criterion |
|---|---|---|
| Current qualification | Finish the clean C9 workspace and required checks after serving-only fixture repairs. | Original failures retained; unchanged deadline/status/drop requirements pass; actual source and result recorded. |
| Worst measured costs | Capture selected gzip/identity source pairs, then the expanded current matrix. | Every offered/completed RPC reconciles; report losses, gains and failures; requested bytes and retained memory remain separate. |
| Actual resource qualification | Run a current preview, then an actual day. | Original finite limits, deadlines, recovery and fairness pass; offline controls do not substitute for execution. |
| One-pass owned nested decode | Compare checked eager merge of singular nested fields in the existing representation. | Equal read-all/sparse corpora; parse-time validation, recursion, unknown fields, duplicate merge, oneofs and retention preserved. |
| Connection fairness | Compare inline execution with one owned Tokio task per finitely admitted RPC. | Drop-abort, reset, deadlines, backpressure and drain preserved; small-call handoff and mixed expensive/cheap work measured. |

Keep existing feature, credentials, platform, packaged-consumer, complete matrix
and dedicated-host cards. Repeated Query children already parse eagerly; do not
attribute all recursive-query costs to lazy singular materialization. CPU-worker
offload remains a separate finite-queue experiment; idle streams consume no
worker threads.

## docs/decisions/grpc-execution.md — validation and ownership

Cancellation cleanup belongs to the state that owns the RPC, not merely to
statements after an await. A guard must signal on task abortion and connection
age teardown while preserving normal producer lifetimes. Waiter registration
likewise owns its slot until drop; O(1) removal keeps storage proportional to
peak live registrations. Reentrant callbacks run outside registry locks.

At `9d6fb9c4`, all 11 detecting old/new mechanism controls have their expected
outcomes, 689 library tests pass with one existing ignore, and five normal
producer-lifetime checks pass. C8 sanitizer separately passes 731 tests with one
ignore. All ten exact pre-workspace checks pass. Its complete workspace still
fails 3,753/2/9 across 139 targets. The serving-only C9 source and full result are
pending. These records do not establish production readiness or measured speed.

## docs/decisions/compression.md — current validation scope

The complete-input, aggregate output, Zstd history and 1,024-member/frame policies
remain unchanged. Current runtime proof belongs to `9d6fb9c4`; C8 sanitizer and
pre-workspace checks pass, while its full workspace fails with two tests. A later
serving-only fixture qualification is pending and must retain its own source pin.
Fresh matched gzip costs are unmeasured. Historical backend tables remain
rationale, not reproducible current CPU proof.

## docs/resource-budgets.md — current lifecycle qualification

Runtime `9d6fb9c4` owns cancellation through task-abort and connection-age teardown;
waiter slots release on drop in O(1), with storage proportional to peak live
registrations. Eleven detecting controls and five normal producer-lifetime
checks cover these mechanisms. The unchanged admission, output, frame-count,
history and permit rules remain separate limits.

Twenty-four offline supervisor controls pass, but no actual current resource
preview or 24-hour campaign has started. The earlier short preview belongs to
its older source. Do not infer total RSS, fairness under all loads or day-long
recovery from offline controls or sanitizer success. Keep the actual old soak
failures and all resource math, profiles and linked test requirements.
