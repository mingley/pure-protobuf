from pathlib import Path
import datetime,hashlib,importlib.util,json
from types import SimpleNamespace
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';driver=q/'architecture-c1-counter-ab-driver.py'
spec=importlib.util.spec_from_file_location('oversized_schedule',driver);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
pairs=module.PAIRS
workloads=[dict(pair=list(pair),shape=shape,payload_bytes=1048576,tls=False,compression=compression,connections=1,in_flight=1)
 for shape,compression in [('client_stream','identity'),('bidi','identity'),('bidi','gzip')] for pair in pairs]
full=q/'architecture-c2-oversized-workloads.json';full.write_text(json.dumps(workloads,indent=2)+'\n')
pilot=q/'architecture-c2-oversized-pilot-workload.json';pilot.write_text(json.dumps([workloads[1]],indent=2)+'\n')
base=['python3',str(driver),'--baseline-checkout',str(root/'work/validation-fixes'),'--baseline-binary',str(q/'architecture-c1-baseline-rpc-build/rpc-bench'),'--baseline-build-record',str(q/'architecture-c1-baseline-rpc-build/build.json'),'--candidate-checkout','C2_CHECKOUT_PENDING','--candidate-binary','C2_BINARY_PENDING','--candidate-build-record','C2_BUILD_RECORD_PENDING','--baseline-commit',module.BASELINE_COMMIT,'--candidate-commit','C2_FULL_COMMIT_PENDING']
phases={}
for name,path,is_pilot,repeats,supervisor in [('pilot',pilot,True,1,600),('full',full,False,2,1200)]:
 args=SimpleNamespace(cells_file=path,repeats=repeats,pilot=is_pilot,scope='selected',seed=20261022,count=25,abba=True)
 cells=module.cells_for(args);schedule=module.schedule_for(cells,args)
 identities=[(r['version'],r['count'],json.dumps(cells[r['cell_index']],sort_keys=True)) for r in schedule]
 assert len(identities)==len(set(identities))
 assert len(schedule)==(4 if is_pilot else 120)
 assert sum(row['count'] for row in schedule)==(150 if is_pilot else 4500)
 counts={}
 for row in schedule:counts[row['version']]=counts.get(row['version'],0)+1
 assert len(set(counts.values()))==1
 command=base+['--output',str(q/f'architecture-c2-oversized-{name}'),'--phase','native','--scope','selected','--cells-file',str(path),'--count','25','--abba']
 command+=['--pilot'] if is_pilot else ['--repeats',str(repeats)]
 phases[name]=dict(argv_template=command,expected_captures=len(schedule),expected_actual_rpc_calls=sum(row['count'] for row in schedule),source_capture_counts=counts,supervisor_seconds=supervisor,workloads_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),schedule=schedule)
record=dict(state='PREPARED_NOT_EXECUTED_C2_PIN_BUILD_AND_PARENT_QUIET_GRANT_PENDING',qualified=False,created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),driver=str(driver),driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),phases=phases,limits=[
'Preserve unchanged run_cell harness, per-RPC5s default, readiness/teardown and outer60s percell deadlines; no budget or message-size changes.',
'Pilot first; report runtime/failures to root before full120capture campaign. Four balanced repeats/240captures are NOTRUN unless explicitly selected afterward.',
'Both endpoints retain native allocation, requested-byte, and context-switch snapshots. Instructions, syscalls, and task wakeups are absent. Raw CPU ticks and context switches remain diagnostics, not qualified speed or scheduling proof.',
'Retain every failed capture, unavailable or nonpositive counter, actual completed RPC count, source/build/controller hashes before and after, and matched tonic controls.',
'Each protobuf payload contains 1 MiB of zeros. Client streaming sends four requests; bidi sends four requests and four responses. The default send buffer is 1 MiB.',
'The native client-stream producer is normally polled first by join and closes four queued messages before the Call. Identity frames exceed the default send buffer and exercise the encoded rest path.',
'The bidi benchmark keeps its producer live while awaiting headers. Identity bidi controls large-message behavior in the existing live pump; it does not isolate the new closed-upload fallback.',
'At gzip level 6, zero-filled payloads compress below the default send buffer. Gzip bidi controls large-message compression behavior; it does not force the encoded rest path.',
'Handlers differ across codecs. The native/prost versus tonic comparison uses minimal handlers; before/after comparisons use matched handlers. Neither isolates pbrs versus prost codec cost.',
'No endpoints/builds/tests started by preparation script.'
])
(q/'architecture-c2-oversized-plan.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:{k:value[k] for k in ['expected_captures','expected_actual_rpc_calls','source_capture_counts']} for key,value in phases.items()},indent=2))
