# Next design experiment after C4

Reviewed C4 `804b5c593fc209cbc5714fd3e77710b54711cc63` and the current generated-message, stream-reader and connection code. This is a source review and experiment proposal; no new performance capture or implementation was run.

## Recommendation: measure one-pass owned nested decode

Implement one isolated generator experiment for the adoption schema: eagerly materialize singular length-delimited messages into the existing `LazyMsg` representation, rather than validate their bytes now and parse them again on first access. Keep shipping defaults and public generated APIs unchanged during this experiment. This attacks work that every read-all consumer necessarily performs and applies to unary as well as streaming RPCs. It is a smaller change to qualify than replacing the executor or transport.

Concrete seam: the first-occurrence lazy-message arm of `emit_merge_arm` in `src/codegen/parse.rs:608` currently calls the child `validate_inner`, then stores `LazyMsg::from_wire`. In the experimental generator only, create a child, invoke the existing checked child `merge_inner` with the same depth/enforcement inputs, and store it with `LazyMsg::from_owned`. Keep the existing subsequent-occurrence merge path. Apply that generated policy recursively to the adoption message family; do not merely force the outermost getter after ordinary parsing. Do not turn off validation or reinterpret raw `Wire` as proof of checked input.

Why this is a structural cost:

- `LazyMsg` stores a boxed `OnceLock<T>` and optional wire (`src/lazy.rs:676`). Its first immutable getter runs `merge_inner` again (`src/lazy.rs:733`); mutable access does likewise (`src/lazy.rs:755`). A full field walk therefore pays initial validation plus materialization and nested validation. A chain of singular nested messages can revisit overlapping descendant spans at successive getters.
- This does **not** mean all recursive messages use deferred decoding. Repeated message children are already constructed recursively by `emit_merge_arm` (`src/codegen/parse.rs:543`). The adoption Query's recursive children/subqueries are repeated; its singular Predicate.value and EdgeTraversal.target are different paths (`bench/devloop/adoption/proto/adoption.proto`). Do not attribute the entire recursive-query cost to lazy singular fields.
- Owned read-all decoding does not automatically eliminate boxing, `OnceLock`, string/bytes storage, reference counts, unknown-field storage, or cached-size work. The experiment isolates duplicated traversal; it does not promise an eager representation equivalent to prost.

### Workload and acceptance gates

Use the existing independently qualified adoption inputs, not the zero-filled transport payloads. `workloads::Pair::work` already separates owned decode, parse-plus-read-all, fresh encoding and fully-read clone (`bench/devloop/adoption/src/workloads.rs:148`). Start with all 48 Query depth3–8/variant0–7 specimens and their independent whole-field walks (`corpus.rs:241`, `266`). Include EntityList and MapHeavy as separately reported controls and all sparse-access cases; none may be silently replaced by an easier payload. Record common wire fingerprints and equal logical work.

Before timing, require full decoded equality through independent prost decoding, field-walk checksum agreement, unknown-field retention and semantically equivalent reserialization. Add focused malformed nested-length/tag/UTF-8, exact recursion-limit, proto2 required-field, duplicate singular occurrence/merge and oneof replacement cases. Compare success/failure at parse time, not merely whether a getter eventually fails. Mutation and clone after a complete walk must remain correct. Bytes-backed parsing and borrowed-slice parsing need separate rows: their copying/retention contracts differ (`src/lazy.rs:62`, `77`, `129`).

Then run source-pinned old/experimental/prost N-versus-2N allocation/requested-byte and instruction captures with warmup and input/output destruction inside identical windows. Record retained live bytes/peak RSS separately; lower requested bytes does not prove lower retained memory. Only after a repeatable read-all benefit survives the existing control-noise rule should this become a proposed explicit owned/eager mode. Preserve the ordinary sparse/default path until its measured tradeoff is understood. Finish with unary and four-message streaming adoption RPCs whose server and client both perform the same complete field walk; standalone codec gains are not automatically RPC gains.

## The inline executor has a separate limitation

`server/connection.rs:719` stores dispatch futures in the connection's `FuturesUnordered`; `poll_admitted` at line750 polls them from the same task that polls HTTP/2 acceptance at line530. The wake-indexed set avoids polling unrelated sleeping handlers. It does not preempt one expensive handler poll. A synchronous field walk, decompression or application computation inside that poll can delay that connection's PING/DATA/reset handling and other RPCs even when another Tokio worker is idle. `WireStream::poll_next_inner` decodes synchronously on the reader (`wire/frame_reader.rs:425`), so ordinary valid decoding can contribute to this effect.

There is no source evidence here that this is the largest measured C4 cost, and no new mixed-handler experiment was run. Keep it an explicit architecture limit, not a claimed production failure. Its eventual comparison is inline execution versus independently owned tasks under the same finite RPC admission: one CPU-heavy read-all request plus small unary/control traffic on the same connection, with equal runtime cores, handler work and peer load. A spawned implementation must abort/drain owned jobs when the connection ends; dropping a bare JoinHandle would detach work. Automatic post-poll time budgeting cannot preempt a poll that is already running. Do not introduce a thread per idle stream or globally enable one task per RPC without measuring the small-unary handoff cost.

## Why this experiment precedes the other local changes

| Candidate | Expected scope | Main tradeoff |
| --- | --- | --- |
| One-pass owned nested decode — recommended next | Read-all nested messages in unary and streaming; repeated traversal removed by construction | May increase eager allocations/work for sparse consumers; representation and merge/error semantics must remain exact |
| Per-stream compressed output/decoder workspace reuse | Repeated compressed messages on a surviving stream | Can reduce repeated allocations but retains memory per idle stream, requires a finite retention policy, and does not improve ordinary unary decode; see `architecture-c2-decode-reuse-review.md` |
| Channelz/byte-accounting optimization | Fixed and per-message cost, most visible on small RPCs | Existing C4 shipping costs are included; removing counters would change feature scope. Optimize only a measured hot lookup/atomic while preserving exact attribution/admission |
| Independently scheduled admitted RPCs | Same-connection CPU-heavy/cheap traffic isolation | Adds tasks/allocations/handoffs and more cancellation/drain ownership; benefit needs a mixed-load witness, not an idle-stream poll count |

The choice is a bounded hypothesis based on identifiable repeated work, not a claim that the next change will beat prost or cure every bottleneck. C4's matched transport captures and the missing read-all measurements should determine whether it earns a shipping API.
