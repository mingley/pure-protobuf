"""Scoped fixture controls; never a substitute for full-suite qualification."""
import argparse
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification/architecture-c5-fixture-controls'
SERVING = 'pbrs-grpc/tests/serving.rs'
TOWER = 'pbrs-grpc/tests/tower_client.rs'
ORIGINALS = (SERVING, TOWER)
TEMP = 'pbrs-grpc/tests/architecture_fixture_controls.rs'
TARGET = 'architecture_fixture_controls'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def git(checkout, *args):
    return subprocess.check_output(['git', *args], cwd=checkout)


def function_span(text, name):
    matches = list(re.finditer(r'(?m)^(?:async )?fn ' + re.escape(name) + r'\b', text))
    assert len(matches) == 1, (name, len(matches))
    start = matches[0].start()
    return start, text.index('\n}', start) + 2


def function_body(text, name):
    start, end = function_span(text, name)
    return text[start:end]


def replace_in_function(text, name, find, replacement, occurrence=None):
    start, end = function_span(text, name)
    body = text[start:end]
    if occurrence is None:
        assert body.count(find) == 1, (name, find, body.count(find))
        changed = body.replace(find, replacement, 1)
    else:
        positions = [m.start() for m in re.finditer(re.escape(find), body)]
        assert len(positions) == 3 and occurrence == 2, (name, positions)
        offset = positions[occurrence]
        changed = body[:offset] + replacement + body[offset + len(find):]
        assert changed.count(find) == 2
    return text[:start] + changed + text[end:]


def focused_copy(text, focused):
    attribute = re.compile(r'(?m)^([ \t]*)#\[(?:tokio::test|test)\b[^\]]*\]')
    changes = []
    names = []
    for match in attribute.finditer(text):
        function = re.search(r'\bfn\s+([A-Za-z_$][A-Za-z0-9_$]*)', text[match.end():])
        assert function is not None, text[match.start():match.end() + 100]
        name = function[1]
        names.append(name)
        if name not in focused:
            changes.append((match.start(), match[1] + '#[cfg(any())]\n'))
    for position, addition in reversed(changes):
        text = text[:position] + addition + text[position:]
    assert all(name in names for name in focused), (focused, names)
    return text, {'test_attributes_seen': len(names), 'disabled_attributes': len(changes),
                  'focused_attributes': [name for name in names if name in focused],
                  'disabled_macro_template_attributes': sum('$' in name for name in names)}


def core_hashes(checkout):
    paths = git(checkout, 'ls-files', '-z', 'src', 'pbrs-grpc/src', 'protobuf-tonic/src',
                'Cargo.toml', 'Cargo.lock', 'pbrs-grpc/Cargo.toml').split(b'\0')
    return {os.fsdecode(p): digest((checkout / os.fsdecode(p)).read_bytes()) for p in paths if p}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkout', required=True, type=Path)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--allow-root-checkout', action='store_true')
    parser.add_argument('--explicit-execution-grant', required=True,
                        choices=['root-granted-negative-controls'])
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    assert checkout != ROOT or args.allow_root_checkout
    assert git(checkout, 'rev-parse', 'HEAD').decode().strip() == args.expected_head
    initial_status = git(checkout, 'status', '--porcelain=v1')
    assert initial_status == b'', initial_status
    owned = checkout / TEMP
    assert not owned.exists() and not owned.is_symlink(), 'Temporary target must initially be absent.'
    plan = json.loads((Q / 'plan.json').read_text())
    original = {name: (checkout / name).read_bytes() for name in ORIGINALS}
    core_before = core_hashes(checkout)
    (Q / 'original').mkdir(exist_ok=False)
    for name, data in original.items():
        (Q / 'original' / Path(name).name).write_bytes(data)
    save(Q / 'runtime-core-before.json', core_before)
    state = {'status': 'running', 'started_utc': utc(), 'checkout': str(checkout),
             'head': args.expected_head, 'initial_status': initial_status.decode(),
             'plan_sha256': digest((Q / 'plan.json').read_bytes()),
             'original_execution_snapshot_sha256': {name: digest(data) for name, data in original.items()},
             'scope': 'Filtered copied fixture correctness controls only; not full-suite qualification.',
             'groups': [], 'known_generated_sha256': [], 'source_restored': False}
    save(Q / 'state.json', state)
    env = os.environ.copy()
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(ROOT / 'work/stable-target'), CARGO_BUILD_JOBS='1')

    def assert_originals_unchanged():
        assert all((checkout / name).read_bytes() == data for name, data in original.items())
        assert core_hashes(checkout) == core_before
        assert git(checkout, 'rev-parse', 'HEAD').decode().strip() == args.expected_head

    def remove_owned():
        if owned.exists() or owned.is_symlink():
            assert not owned.is_symlink(), 'Unexpected replacement symlink preserved.'
            assert digest(owned.read_bytes()) in state['known_generated_sha256'], 'Unexpected target edits preserved.'
            owned.unlink()

    def record(prefix, seconds, command):
        assert not prefix.with_suffix('.json').exists(), prefix
        result = subprocess.run([sys.executable, str(ROOT / 'work/record.py'), str(prefix),
                                 str(seconds), *command], cwd=checkout, env=env)
        assert prefix.with_suffix('.json').exists(), 'Recorder failed to write terminal metadata.'
        return result.returncode, json.loads(prefix.with_suffix('.json').read_text())

    try:
        for group in plan['groups']:
            assert_originals_unchanged()
            remove_owned()
            directory = Q / group['id']
            directory.mkdir(exist_ok=False)
            row = {'id': group['id'], 'status': 'preparing', 'runs': []}
            state['groups'].append(row)
            try:
                source = original[group['source_file']].decode()
                mutated = source
                for change in group['mutations']:
                    mutated = replace_in_function(mutated, change['function'], change['find'],
                                                  change['replace'], change.get('occurrence'))
                generated, filtering = focused_copy(mutated, group['focused_tests'])
                row['filtering'] = filtering
                row['focused_function_sha256'] = {}
                for name in group['focused_tests']:
                    expected = function_body(mutated, name)
                    copied = function_body(generated, name)
                    assert copied == expected, name
                    row['focused_function_sha256'][name] = {'original': digest(function_body(source, name).encode()),
                                                           'expected_variant': digest(expected.encode()),
                                                           'copied': digest(copied.encode())}
                (directory / 'mutation-only.patch').write_text(''.join(difflib.unified_diff(
                    source.splitlines(True), mutated.splitlines(True), fromfile='a/' + group['source_file'],
                    tofile='b/' + group['source_file'])))
                (directory / 'test-filtering.patch').write_text(''.join(difflib.unified_diff(
                    mutated.splitlines(True), generated.splitlines(True), fromfile='unfiltered-copy', tofile=TEMP)))
                data = generated.encode()
                (directory / 'generated.rs').write_bytes(data)
                sha = digest(data)
                state['known_generated_sha256'].append(sha)
                row['generated_sha256'] = sha
                # Record ownership before creating the one temporary test file.
                save(Q / 'state.json', state)
                owned.write_bytes(data)
                row['status'] = 'compiling'
                save(Q / 'state.json', state)
                command = [str(ROOT / 'work/run-rust'), 'cargo', 'test', '--locked', '-p', 'pbrs-grpc',
                           '--all-features', '--test', TARGET, '--no-run', '--message-format=json']
                code, _ = record(directory / 'compile', 900, command)
                row['compile_exit_code'] = code
                if code != 0:
                    raise RuntimeError('Compile failure is a failed control, never an expected runtime failure.')
                artifacts = []
                for line in (directory / 'compile.stdout').read_text().splitlines():
                    try:
                        artifact = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if artifact.get('reason') == 'compiler-artifact' and artifact.get('target', {}).get('name') == TARGET and artifact.get('executable'):
                        artifacts.append(artifact['executable'])
                assert len(set(artifacts)) == 1, artifacts
                executable = Path(artifacts[-1])
                row['executable'] = {'path': str(executable), 'bytes': executable.stat().st_size,
                                     'sha256': digest(executable.read_bytes())}
                code, _ = record(directory / 'compiled-list', 20, [str(executable), '--list'])
                listing = (directory / 'compiled-list.stdout').read_text()
                listed = re.findall(r'^(.+): test$', listing, re.M)
                row['compiled_tests'] = listed
                assert code == 0 and sorted(listed) == sorted(group['focused_tests']), listed
                row['status'] = 'running'
                save(Q / 'state.json', state)
                for case in group['runs']:
                    command = [str(executable), '--nocapture']
                    if case.get('test'):
                        command += ['--exact', case['test']]
                    code, run_record = record(directory / case['id'], 20, command)
                    output = ((directory / (case['id'] + '.stdout')).read_text()
                              + (directory / (case['id'] + '.stderr')).read_text())
                    if case.get('positive'):
                        expected_summary = 'test result: ok. ' + str(len(group['focused_tests'])) + ' passed; 0 failed; 0 ignored;'
                        valid = code == 0 and run_record.get('exit_code') == 0 and expected_summary in output
                        detail = {'positive_all_cases_passed': valid}
                    else:
                        message_matches = case.get('expected_message', '\0') in output
                        if case.get('expected_lower_bound_assertion'):
                            helper = function_body(generated, 'assert_controlled_server_timeout')
                            needle = 'assert_eq!(probe.dropped.load(Ordering::Relaxed), expected - 1);'
                            assert helper.count(needle) == 1
                            start, end = function_span(generated, 'assert_controlled_server_timeout')
                            line = generated.count('\n', 0, generated.index(needle, start, end)) + 1
                            message_matches = (re.search(r'architecture_fixture_controls\.rs:' + str(line) + r':\d+', output) is not None
                                and 'assertion `left == right` failed' in output)
                        single_failure = re.search(r'^test result: FAILED\. 0 passed; 1 failed; 0 ignored;', output, re.M) is not None
                        valid = code == 101 and run_record.get('exit_code') == 101 and single_failure and message_matches
                        valid = valid and run_record['duration_seconds'] >= case.get('minimum_wall_seconds', 0)
                        detail = {'expected_message_matches': message_matches, 'exact_single_failure_summary': single_failure}
                    row['runs'].append({'id': case['id'], 'test': case.get('test'), 'actual_exit_code': code,
                        'duration_seconds': run_record['duration_seconds'], 'oracle_satisfied': valid, **detail})
                    save(Q / 'state.json', state)
                row['status'] = 'passed' if all(run['oracle_satisfied'] for run in row['runs']) else 'CONTROL FAILED'
            except Exception as error:
                row['status'] = 'CONTROL FAILED'
                row['error'] = repr(error)
            finally:
                remove_owned()
                assert_originals_unchanged()
                save(Q / 'state.json', state)
            # A failed positive copy invalidates subsequent controls for it.
            if group.get('positive_baseline') and row['status'] != 'passed':
                break
    finally:
        try:
            remove_owned()
            assert_originals_unchanged()
            final_core = core_hashes(checkout)
            save(Q / 'runtime-core-after.json', final_core)
            state['runtime_core_unchanged'] = final_core == core_before
            state['original_tests_unchanged'] = all((checkout / name).read_bytes() == data for name, data in original.items())
            state['final_status'] = git(checkout, 'status', '--porcelain=v1').decode()
            state['final_head'] = git(checkout, 'rev-parse', 'HEAD').decode().strip()
            state['source_restored'] = (not owned.exists() and state['runtime_core_unchanged']
                and state['original_tests_unchanged'] and state['final_status'] == initial_status.decode()
                and state['final_head'] == args.expected_head)
        except Exception as error:
            state['restoration_error'] = repr(error)
            state['source_restored'] = False
        state['completed_utc'] = utc()
        state['status'] = ('all controls passed' if state['source_restored'] and len(state['groups']) == len(plan['groups'])
            and all(group['status'] == 'passed' for group in state['groups']) else 'CONTROL QUALIFICATION FAILED')
        save(Q / 'state.json', state)
    return 0 if state['status'] == 'all controls passed' else 1


if __name__ == '__main__':
    sys.exit(main())
