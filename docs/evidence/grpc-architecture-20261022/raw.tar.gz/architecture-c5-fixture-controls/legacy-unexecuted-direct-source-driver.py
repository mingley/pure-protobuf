"""Test-only mutation controls. Requires an explicit later execution grant."""
import argparse
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification/architecture-c5-fixture-controls'
SERVING = 'pbrs-grpc/tests/serving.rs'
TOWER = 'pbrs-grpc/tests/tower_client.rs'
OWNED = (SERVING, TOWER)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, data):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(path)

def git(checkout, *args):
    return subprocess.check_output(['git', *args], cwd=checkout)

def function_span(text, name):
    matches = list(re.finditer(r'(?m)^(?:async )?fn ' + re.escape(name) + r'\b', text))
    assert len(matches) == 1, (name, len(matches))
    start = matches[0].start()
    # These rustfmt-formatted top-level functions end with an unindented brace.
    end = text.index('\n}', start) + len('\n}')
    return start, end

def replace_in_function(text, name, find, replacement, occurrence=None):
    start, end = function_span(text, name)
    body = text[start:end]
    if occurrence is None:
        assert body.count(find) == 1, (name, find, body.count(find))
        changed = body.replace(find, replacement, 1)
    else:
        positions = [m.start() for m in re.finditer(re.escape(find), body)]
        assert len(positions) == 3 and occurrence == 2, (name, positions)
        position = positions[occurrence]
        changed = body[:position] + replacement + body[position + len(find):]
        assert changed.count(find) == 2
    return text[:start] + changed + text[end:]

def runtime_hashes(checkout):
    paths = git(checkout, 'ls-files', '-z', 'src', 'pbrs-grpc/src', 'protobuf-tonic/src',
                'Cargo.toml', 'Cargo.lock', 'pbrs-grpc/Cargo.toml').split(b'\0')
    return {os.fsdecode(p): digest((checkout / os.fsdecode(p)).read_bytes()) for p in paths if p}

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkout', required=True, type=Path)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--allow-root-checkout', action='store_true')
    parser.add_argument('--explicit-execution-grant', required=True,
                        choices=['root-granted-negative-controls'])
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    # Root source/docs edits must be frozen before granting this explicit opt-in.
    assert checkout != ROOT or args.allow_root_checkout, 'Root checkout requires explicit --allow-root-checkout.'
    assert git(checkout, 'rev-parse', 'HEAD').decode().strip() == args.expected_head
    initial_status = git(checkout, 'status', '--porcelain=v1')
    assert initial_status == b'', initial_status
    plan = json.loads((Q / 'plan.json').read_text())
    original = {name: (checkout / name).read_bytes() for name in OWNED}
    assert {name: digest(value) for name, value in original.items()} == plan['baseline_test_sha256']
    baseline_core = runtime_hashes(checkout)
    (Q / 'original').mkdir(exist_ok=False)
    for name, data in original.items():
        (Q / 'original' / Path(name).name).write_bytes(data)
    save(Q / 'runtime-core-before.json', baseline_core)
    state = {'started_utc': utc(), 'checkout': str(checkout), 'head': args.expected_head,
             'initial_status': initial_status.decode(), 'plan_sha256': digest((Q / 'plan.json').read_bytes()),
             'original_sha256': {name: digest(data) for name, data in original.items()},
             'groups': [], 'status': 'running', 'source_restored': False}
    save(Q / 'state.json', state)
    env = os.environ.copy()
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(ROOT / 'work/stable-target'), CARGO_BUILD_JOBS='1')

    def restore():
        for name, data in original.items():
            (checkout / name).write_bytes(data)
        assert all((checkout / name).read_bytes() == data for name, data in original.items())

    def record(prefix, seconds, command):
        assert not prefix.with_suffix('.json').exists(), prefix
        result = subprocess.run([sys.executable, str(ROOT / 'work/record.py'), str(prefix),
                                 str(seconds), *command], cwd=checkout, env=env)
        assert prefix.with_suffix('.json').exists(), 'Recorder did not produce a terminal record'
        data = json.loads(prefix.with_suffix('.json').read_text())
        return result.returncode, data

    try:
        for group in plan['groups']:
            restore()
            group_dir = Q / group['id']
            group_dir.mkdir(exist_ok=False)
            row = {'id': group['id'], 'status': 'preparing', 'runs': []}
            state['groups'].append(row)
            try:
                changed = {name: data.decode() for name, data in original.items()}
                for change in group['mutations']:
                    name = change['file']
                    changed[name] = replace_in_function(changed[name], change['function'], change['find'],
                                                       change['replace'], change.get('occurrence'))
                for name, text in changed.items():
                    data = text.encode()
                    (checkout / name).write_bytes(data)
                    if data != original[name]:
                        patch = ''.join(difflib.unified_diff(original[name].decode().splitlines(True),
                            text.splitlines(True), fromfile='a/' + name, tofile='b/' + name))
                        (group_dir / (Path(name).name + '.patch')).write_text(patch)
                        (group_dir / Path(name).name).write_bytes(data)
                row['mutated_test_sha256'] = {name: digest((checkout / name).read_bytes()) for name in OWNED}
                assert runtime_hashes(checkout) == baseline_core
                row['status'] = 'compiling'
                save(Q / 'state.json', state)
                target = group['target']
                command = [str(ROOT / 'work/run-rust'), 'cargo', 'test', '--locked', '-p', 'pbrs-grpc',
                           '--all-features', '--test', target, '--no-run', '--message-format=json']
                code, compile_record = record(group_dir / 'compile', 900, command)
                row['compile_exit_code'] = code
                if code != 0:
                    raise RuntimeError('Control compilation failed; this is not an expected negative-control result.')
                artifacts = []
                for line in (group_dir / 'compile.stdout').read_text().splitlines():
                    try:
                        artifact = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    if artifact.get('reason') == 'compiler-artifact' and artifact.get('target', {}).get('name') == target and artifact.get('executable'):
                        artifacts.append(artifact['executable'])
                assert len(set(artifacts)) == 1, artifacts
                executable = Path(artifacts[-1])
                row['executable'] = {'path': str(executable), 'bytes': executable.stat().st_size,
                                     'sha256': digest(executable.read_bytes())}
                row['status'] = 'running expected failures'
                save(Q / 'state.json', state)
                for case in group['runs']:
                    code, run_record = record(group_dir / case['id'], 20,
                        [str(executable), '--exact', case['test'], '--nocapture'])
                    output = ((group_dir / (case['id'] + '.stdout')).read_text()
                              + (group_dir / (case['id'] + '.stderr')).read_text())
                    expected = case.get('expected_message')
                    message_matches = expected in output if expected else False
                    if case.get('expected_lower_bound_assertion'):
                        text = (checkout / SERVING).read_text()
                        start, end = function_span(text, 'assert_controlled_server_timeout')
                        needle = 'assert_eq!(probe.dropped.load(Ordering::Relaxed), expected - 1);'
                        assert text[start:end].count(needle) == 1
                        line_number = text.count('\n', 0, text.index(needle, start, end)) + 1
                        message_matches = (re.search(r'serving\.rs:' + str(line_number) + r':\d+', output) is not None
                            and 'assertion `left == right` failed' in output)
                    failed_exact_test = re.search(r'^test result: FAILED\. 0 passed; 1 failed; 0 ignored;', output, re.M) is not None
                    valid = code == 101 and run_record.get('exit_code') == 101 and failed_exact_test and message_matches
                    if case.get('minimum_wall_seconds') is not None:
                        valid = valid and run_record['duration_seconds'] >= case['minimum_wall_seconds']
                    run = {'id': case['id'], 'test': case['test'], 'actual_exit_code': code,
                           'record': str(group_dir / (case['id'] + '.json')),
                           'duration_seconds': run_record['duration_seconds'], 'expected_failure_observed': valid,
                           'expected_message_matches': message_matches, 'exact_single_failure_summary': failed_exact_test}
                    row['runs'].append(run)
                    save(Q / 'state.json', state)
                row['status'] = 'passed' if all(run['expected_failure_observed'] for run in row['runs']) else 'CONTROL FAILED'
            except Exception as error:
                row['status'] = 'CONTROL FAILED'
                row['error'] = repr(error)
            finally:
                restore()
                row['restored_test_sha256'] = {name: digest((checkout / name).read_bytes()) for name in OWNED}
                save(Q / 'state.json', state)
    finally:
        restore()
        final_core = runtime_hashes(checkout)
        save(Q / 'runtime-core-after.json', final_core)
        state['runtime_core_unchanged'] = final_core == baseline_core
        state['final_status'] = git(checkout, 'status', '--porcelain=v1').decode()
        state['final_head'] = git(checkout, 'rev-parse', 'HEAD').decode().strip()
        state['source_restored'] = (all((checkout / name).read_bytes() == data for name, data in original.items())
            and final_core == baseline_core and state['final_status'] == initial_status.decode()
            and state['final_head'] == args.expected_head)
        state['completed_utc'] = utc()
        state['status'] = ('all controls passed' if state['source_restored'] and len(state['groups']) == len(plan['groups'])
            and all(group['status'] == 'passed' for group in state['groups']) else 'CONTROL QUALIFICATION FAILED')
        save(Q / 'state.json', state)
    return 0 if state['status'] == 'all controls passed' else 1

if __name__ == '__main__':
    sys.exit(main())
