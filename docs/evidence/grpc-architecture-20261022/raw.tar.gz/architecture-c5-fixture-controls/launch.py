"""Launch the prepared control driver only after an explicit execution grant."""
import argparse
import datetime
import json
from pathlib import Path
import subprocess
import sys

q = Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--checkout', required=True)
parser.add_argument('--expected-head', required=True)
parser.add_argument('--allow-root-checkout', action='store_true')
parser.add_argument('--explicit-execution-grant', required=True,
                    choices=['root-granted-negative-controls'])
args = parser.parse_args()
assert not (q / 'launch.json').exists(), 'Driver already launched; do not duplicate mutations.'
command = [sys.executable, str(q / 'driver.py'), '--checkout', args.checkout,
           '--expected-head', args.expected_head, '--explicit-execution-grant', args.explicit_execution_grant]
if args.allow_root_checkout:
    command.append('--allow-root-checkout')
with (q / 'driver.stdout').open('xb') as out, (q / 'driver.stderr').open('xb') as err:
    process = subprocess.Popen(command, stdout=out, stderr=err, stdin=subprocess.DEVNULL,
        cwd=args.checkout, start_new_session=True, close_fds=True)
    record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'pid': process.pid, 'command': command, 'detached_session': True}
    (q / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps(record))
