//! Inbound reads: frame parsing, message reads, call completion.

use super::headers::{
    GRPC_MESSAGE, GRPC_RETRY_PUSHBACK_MS, GRPC_STATUS, GRPC_STATUS_DETAILS_BIN,
    encoding_not_supported, grpc_encoding, inbound_codec_from_token,
};
use crate::binlog::{CallLogger, Logger};
use crate::codec::{self, CodecMessage, Frame};
use crate::compression::CompressionAlgorithm;
use crate::limits::MessageLimits;
use crate::metadata::{self, Metadata};
use crate::status::{Code, Status, parse_pushback_value};
use crate::stream::{Framed, Streaming};
use crate::transport::{Error as TransportError, RecvStream, h2 as backend};
use bytes::{Bytes, BytesMut};
use futures_util::future::Either;
use http::{HeaderMap, StatusCode};
use std::future::{Future, poll_fn};
use std::pin::Pin;
use std::task::{Context, Poll};

/// Read `grpc-status` from trailers, falling back to headers for
/// Trailers-Only responses.
pub(crate) fn status_from(headers: &HeaderMap, trailers: Option<&HeaderMap>) -> Status {
    // The success trailer is exactly `grpc-status: 0`.
    if let Some(trailers) = trailers {
        if trailers.len() == 1 {
            if let Some((name, value)) = trailers.iter().next() {
                let bytes = value.as_bytes();
                if name == GRPC_STATUS && bytes.len() == 1 && bytes[0] == b'0' {
                    return Status::ok();
                }
            }
        }
    }
    // Single pass over the status block. OK responses carry exactly one
    // trailer, so this replaces four hashed lookups with one short scan.
    // First values win, matching `HeaderMap::get`; an unreadable or
    // unparseable first `grpc-status` fails the pick, as before.
    let pick = |map: &HeaderMap| {
        let mut code = None;
        let mut message = None;
        let mut pushback = None;
        let mut details = None;
        for (name, value) in map.iter() {
            if name == GRPC_STATUS {
                if code.is_none() {
                    code = Some(value.to_str().ok()?.parse::<i32>().ok()?);
                }
            } else if name == GRPC_MESSAGE {
                if message.is_none() {
                    message = value.to_str().ok().map(percent_decode);
                }
            } else if name == GRPC_RETRY_PUSHBACK_MS {
                if pushback.is_none() {
                    pushback = value.to_str().ok().and_then(parse_pushback_value);
                }
            } else if name == GRPC_STATUS_DETAILS_BIN && details.is_none() {
                details = value.to_str().ok().and_then(metadata::decode_base64);
            }
        }
        let code = code?;
        Some((
            Code::from_i32(code),
            message.unwrap_or_default(),
            pushback,
            details,
        ))
    };
    let found = trailers
        .and_then(|t| pick(t).map(|hit| (hit, t)))
        .or_else(|| pick(headers).map(|hit| (hit, headers)));
    match found {
        Some(((code, message, pushback, details), map)) => {
            let mut status = Status::new(code, message);
            if code != Code::Ok {
                *status.metadata_mut() = Metadata::from_headers(map);
            }
            if let Some(pushback) = pushback {
                status.set_retry_pushback(pushback);
            }
            if let Some(details) = details {
                status.set_details(details);
            }
            status
        }
        None => Status::unknown("missing grpc-status"),
    }
}

// An explicit non-OK wire status can terminate an unfinished response.
// Missing or malformed statuses must not hide a truncated frame.
fn has_error_status(headers: &HeaderMap) -> bool {
    headers
        .get(GRPC_STATUS)
        .and_then(|value| value.to_str().ok())
        .and_then(|value| value.parse::<i32>().ok())
        .is_some_and(|code| code != 0)
}

/// Next HTTP/2 DATA chunk. Flow-control capacity is *not* released; the caller
/// releases it once the chunk has been handed on, which is what turns a slow
/// reader into peer backpressure.
#[allow(
    dead_code,
    reason = "delayed-release callers; the steady path uses poll_data_released"
)]
pub(crate) fn poll_data(
    recv: &mut backend::RecvStream,
    cx: &mut Context<'_>,
) -> Poll<Result<Option<Bytes>, Status>> {
    match recv.poll_data(cx) {
        Poll::Pending => Poll::Pending,
        Poll::Ready(None) => Poll::Ready(Ok(None)),
        Poll::Ready(Some(Ok(bytes))) => Poll::Ready(Ok(Some(bytes))),
        Poll::Ready(Some(Err(e))) => Poll::Ready(Err(h2_error(e))),
    }
}

/// [`poll_data`] plus the immediate window release, under one stream lock.
///
/// The caller matches this chunk immediately. Out of line, the bytes
/// landed in this return slot and were copied out again.
#[inline(always)]
pub(crate) fn poll_data_released(
    recv: &mut backend::RecvStream,
    cx: &mut Context<'_>,
) -> Poll<Result<Option<Bytes>, Status>> {
    match recv.poll_data_released(cx) {
        Poll::Pending => Poll::Pending,
        Poll::Ready(None) => Poll::Ready(Ok(None)),
        Poll::Ready(Some(Ok(bytes))) => Poll::Ready(Ok(Some(bytes))),
        Poll::Ready(Some(Err(e))) => Poll::Ready(Err(h2_error(e))),
    }
}

#[allow(
    dead_code,
    reason = "delayed-release callers; the steady path uses next_data_released"
)]
pub(crate) async fn next_data(recv: &mut backend::RecvStream) -> Result<Option<Bytes>, Status> {
    poll_fn(|cx| poll_data(recv, cx)).await
}

pub(crate) async fn next_data_released(
    recv: &mut backend::RecvStream,
) -> Result<Option<Bytes>, Status> {
    poll_fn(|cx| poll_data_released(recv, cx)).await
}

#[allow(
    dead_code,
    reason = "delayed-release callers; the steady path releases inside poll_data_released"
)]
pub(crate) fn release(recv: &mut backend::RecvStream, n: usize) -> Result<(), Status> {
    if n == 0 {
        return Ok(());
    }
    recv.release_capacity(n)
        .map_err(|e| Status::internal(e.to_string()))
}

pub(crate) fn h2_error(e: TransportError) -> Status {
    Status::from_h2(e)
}

/// Splits inbound DATA chunks into gRPC frames.
///
/// Invariant: `carry` is non-empty only while `chunk` is empty. A frame that
/// arrived whole inside one DATA chunk is sliced out of it and never copied;
/// only a frame straddling a chunk boundary passes through `carry`.
pub(crate) struct FrameReader {
    pub(crate) chunk: Bytes,
    pub(crate) carry: BytesMut,
    pub(crate) limits: MessageLimits,
}

impl FrameReader {
    pub(crate) fn new(limits: MessageLimits) -> Self {
        Self {
            chunk: Bytes::new(),
            carry: BytesMut::new(),
            limits,
        }
    }

    pub(crate) fn push(&mut self, next: Bytes) {
        if self.carry.is_empty() && self.chunk.is_empty() {
            self.chunk = next;
            return;
        }
        if !self.chunk.is_empty() {
            crate::copy_counts::note_carry(self.chunk.len());
            self.carry.extend_from_slice(&self.chunk);
            self.chunk = Bytes::new();
        }
        crate::copy_counts::note_carry(next.len());
        self.carry.extend_from_slice(&next);
        // NOTE (PK-09): a reserve-once here (Phase 1a) removes regrowth
        // copies in isolation (5x microbench win, fewer cycles/faults/RSS)
        // but reproducibly costs -18% on loopback 8 MiB RPCs: both sides do
        // less CPU work yet wait longer in recvfrom, an emergent
        // pipeline/batch interaction, not CPU. Reverted per ship-only-if-
        // faster-or-better; Phase 3 (segmented receive) re-asks framing
        // with fresh data. See docs/evidence/pk09-zero-copy.md.
    }

    pub(crate) fn next_frame(&mut self) -> Result<Option<Frame>, Status> {
        if !self.chunk.is_empty() {
            return codec::pop_from_chunk(&mut self.chunk, self.limits);
        }
        if !self.carry.is_empty() {
            return codec::pop_limited(&mut self.carry, self.limits);
        }
        Ok(None)
    }

    /// A stream that ended mid-frame is a protocol violation, not an
    /// empty message.
    pub(crate) fn finish(&self) -> Result<(), Status> {
        if self.chunk.is_empty() && self.carry.is_empty() {
            Ok(())
        } else {
            Err(Status::internal("truncated gRPC frame"))
        }
    }
}

pub(crate) fn decode_frame<T: CodecMessage>(
    frame: Frame,
    limits: MessageLimits,
    accept_gzip: bool,
    codec: Option<CompressionAlgorithm>,
) -> Result<Framed<T>, Status> {
    let message = if frame.compressed {
        // gRPC compression requires INTERNAL for flag one without a named,
        // non-identity coding; accepting it as gzip hides a negotiation error.
        let codec = codec.ok_or_else(|| {
            Status::internal("compressed-flag set without a non-identity grpc-encoding")
        })?;
        if !accept_gzip {
            return Err(encoding_not_supported(false));
        }
        let raw = codec.decode_limited(&frame.payload, limits)?;
        T::decode_payload(Bytes::from(raw))?
    } else {
        T::decode_payload(frame.payload)?
    };
    Ok(Framed {
        message,
        compressed: frame.compressed,
    })
}

/// Read the single message of a unary request or response.
///
/// An empty body decodes to `T::default()`, matching gRPC's treatment of a
/// zero-field message. More than one message is a protocol violation.
pub(crate) async fn read_one_message<T: CodecMessage>(
    recv: &mut backend::RecvStream,
    limits: MessageLimits,
    accept_gzip: bool,
    codec: Option<CompressionAlgorithm>,
    tap: Option<&CallLogger>,
    response: bool,
) -> Result<Framed<T>, Status> {
    let mut reader = FrameReader::new(limits);
    let mut found: Option<Framed<T>> = None;
    while let Some(chunk) = next_data_released(recv).await? {
        reader.push(chunk);
        while let Some(frame) = reader.next_frame()? {
            if found.is_some() {
                return Err(Status::internal("unary rpc received more than one message"));
            }
            if let Some(tap) = tap {
                tap.log_read(&frame.payload);
            }
            found = Some(decode_frame(frame, limits, accept_gzip, codec)?);
        }
    }
    if let Err(framing_error) = reader.finish() {
        if response {
            if let Some(trailers) = read_trailers(recv).await? {
                if has_error_status(&trailers) {
                    return Err(status_from(&trailers, Some(&trailers)));
                }
            }
        }
        return Err(framing_error);
    }
    // A clean unary-request end is the client's half-close. Response reads
    // end in a trailer, logged by the caller.
    if let Some(tap) = tap.filter(|tap| matches!(tap.role(), Logger::Server)) {
        tap.log_half_close();
    }
    Ok(found.unwrap_or_else(|| Framed::new(T::empty())))
}

/// Drain trailers so the HTTP/2 stream closes cleanly.
pub(crate) async fn read_trailers(
    recv: &mut backend::RecvStream,
) -> Result<Option<HeaderMap>, Status> {
    recv.trailers().await.map_err(h2_error)
}

type DecodeFrame<T> =
    fn(Frame, MessageLimits, bool, Option<CompressionAlgorithm>) -> Result<Framed<T>, Status>;

/// An inbound message stream, decoded straight off its HTTP/2 stream.
///
/// There is no pump task and no intermediate queue: reading a message reads the
/// wire. That removes a task hop and a copy per message, and makes backpressure
/// exact, because a reader that stops reading stops releasing HTTP/2 capacity
/// and the peer stalls at the window.
pub(crate) struct WireStream<T> {
    recv: backend::RecvStream,
    reader: FrameReader,
    limits: MessageLimits,
    /// Bound at construction, where `T: CodecMessage` is known, so the public
    /// [`Streaming`] type needs no `Parse` bound of its own.
    decode: DecodeFrame<T>,
    accept_gzip: bool,
    codec: Option<CompressionAlgorithm>,
    /// When the RPC's deadline expires. A deadline has to reach the reads, not
    /// just the call setup: a server that answers with headers and then goes
    /// quiet would otherwise hang the reader forever.
    deadline: Option<tokio::time::Instant>,
    sleep: Option<Pin<Box<tokio::time::Sleep>>>,
    ended: bool,
    trailers_done: bool,
    /// Requests may half-close without status; body responses must finish
    /// with grpc-status unless it was validated in Trailers-Only headers.
    require_response_status: bool,
    trailers: Metadata,
    tap: Option<CallLogger>,
}

impl<T: CodecMessage> WireStream<T> {
    pub(crate) fn new(
        recv: backend::RecvStream,
        limits: MessageLimits,
        deadline: Option<tokio::time::Instant>,
        accept_gzip: bool,
        codec: Option<CompressionAlgorithm>,
        tap: Option<CallLogger>,
    ) -> Self {
        Self {
            recv,
            reader: FrameReader::new(limits),
            limits,
            decode: decode_frame::<T>,
            accept_gzip,
            codec,
            deadline,
            sleep: deadline.map(|at| Box::pin(tokio::time::sleep_until(at))),
            ended: false,
            trailers_done: false,
            require_response_status: false,
            trailers: Metadata::new(),
            tap,
        }
    }
}

impl<T> WireStream<T> {
    fn requiring_response_status(mut self, required: bool) -> Self {
        self.require_response_status = required;
        self
    }

    /// Whether DATA and trailers have both been consumed, so a Drop must
    /// not RST a finished RPC.
    pub(crate) fn finished(&self) -> bool {
        self.trailers_done
    }

    /// Preserve deadline precedence when a local cancellation bypasses the
    /// asynchronous HTTP/2 reset that normally supplies the read error.
    pub(crate) fn local_cancel_status(&self) -> Status {
        if self
            .deadline
            .is_some_and(|at| tokio::time::Instant::now() >= at)
        {
            Status::deadline_exceeded()
        } else {
            Status::cancelled()
        }
    }

    /// The next message, or `Ok(None)` once the stream has ended cleanly.
    ///
    /// A non-OK `grpc-status` in the trailers surfaces here as `Err`, and so
    /// does an expired deadline.
    pub(crate) async fn next(&mut self) -> Result<Option<Framed<T>>, Status> {
        poll_fn(|cx| self.poll_next(cx)).await
    }

    pub(crate) fn poll_next(
        &mut self,
        cx: &mut Context<'_>,
    ) -> Poll<Result<Option<Framed<T>>, Status>> {
        if let Some(at) = self.deadline {
            if tokio::time::Instant::now() >= at {
                return Poll::Ready(Err(Status::deadline_exceeded()));
            }
            if let Some(sleep) = &mut self.sleep {
                if sleep.as_mut().poll(cx).is_ready() {
                    return Poll::Ready(Err(Status::deadline_exceeded()));
                }
            }
        }
        match self.poll_next_inner(cx) {
            Poll::Ready(Err(status))
                if matches!(status.code(), Code::Unavailable | Code::Cancelled)
                    && self
                        .deadline
                        .is_some_and(|at| tokio::time::Instant::now() >= at) =>
            {
                Poll::Ready(Err(Status::deadline_exceeded()))
            }
            other => other,
        }
    }

    fn poll_next_inner(&mut self, cx: &mut Context<'_>) -> Poll<Result<Option<Framed<T>>, Status>> {
        loop {
            match self.reader.next_frame() {
                Err(e) => return Poll::Ready(Err(e)),
                Ok(Some(frame)) => {
                    if let Some(tap) = &self.tap {
                        tap.log_read(&frame.payload);
                    }
                    return Poll::Ready(
                        (self.decode)(frame, self.limits, self.accept_gzip, self.codec).map(Some),
                    );
                }
                Ok(None) => {}
            }
            if self.ended {
                if self.trailers_done {
                    return Poll::Ready(Ok(None));
                }
                return match self.poll_finish_trailers(cx) {
                    Poll::Pending => Poll::Pending,
                    Poll::Ready(Ok(())) => {
                        self.trailers_done = true;
                        Poll::Ready(Ok(None))
                    }
                    Poll::Ready(Err(e)) => {
                        self.trailers_done = true;
                        Poll::Ready(Err(e))
                    }
                };
            }
            match poll_data_released(&mut self.recv, cx) {
                Poll::Pending => return Poll::Pending,
                Poll::Ready(Err(e)) => return Poll::Ready(Err(e)),
                Poll::Ready(Ok(Some(chunk))) => {
                    self.reader.push(chunk);
                }
                Poll::Ready(Ok(None)) => {
                    self.ended = true;
                    if !self.require_response_status {
                        if let Err(e) = self.reader.finish() {
                            return Poll::Ready(Err(e));
                        }
                    }
                    // A clean request-stream end is the client's half-close.
                    // Response streams end in a trailer instead.
                    if let Some(tap) = self
                        .tap
                        .as_ref()
                        .filter(|tap| matches!(tap.role(), Logger::Server))
                    {
                        tap.log_half_close();
                    }
                }
            }
        }
    }

    fn poll_finish_trailers(&mut self, cx: &mut Context<'_>) -> Poll<Result<(), Status>> {
        match self.recv.poll_trailers(cx) {
            Poll::Pending => Poll::Pending,
            Poll::Ready(Err(e)) => {
                let status = h2_error(e);
                self.log_response_trailer(&status);
                Poll::Ready(Err(status))
            }
            Poll::Ready(Ok(None)) => {
                if self.require_response_status {
                    let status = self
                        .reader
                        .finish()
                        .err()
                        .unwrap_or_else(|| Status::unknown("missing grpc-status"));
                    self.log_response_trailer(&status);
                    Poll::Ready(Err(status))
                } else {
                    self.log_response_trailer(&Status::from_code(Code::Ok));
                    Poll::Ready(Ok(()))
                }
            }
            Poll::Ready(Ok(Some(map))) => {
                // `status_from` repeats this check. A bare OK trailer is the
                // common block, so classify it once and recycle from that.
                let bare_ok = crate::h2_backend::header_pool::is_bare_ok_trailer(&map);
                let mut status = if bare_ok {
                    Status::ok()
                } else {
                    status_from(&map, Some(&map))
                };
                if self.require_response_status {
                    if let Err(framing_error) = self.reader.finish() {
                        if !has_error_status(&map) {
                            status = framing_error;
                        }
                    }
                }
                self.trailers = if bare_ok {
                    crate::h2_backend::header_pool::recycle_received_ok_trailer(map);
                    Metadata::new()
                } else {
                    metadata_from_trailers(map)
                };
                self.log_response_trailer(&status);
                if status.code() == Code::Ok {
                    Poll::Ready(Ok(()))
                } else {
                    Poll::Ready(Err(status))
                }
            }
        }
    }

    /// Log the response trailer exactly once, when this stream reads
    /// responses. Request streams end in a half-close instead.
    fn log_response_trailer(&self, status: &Status) {
        if let Some(tap) = self
            .tap
            .as_ref()
            .filter(|tap| matches!(tap.role(), Logger::Client))
        {
            tap.log_trailer(&self.trailers, status);
        }
    }

    /// Trailing metadata, available once the stream has ended.
    pub(crate) fn trailers(&self) -> &Metadata {
        &self.trailers
    }
}

/// Refuse a reply coding this channel will not inflate.
///
/// A coding the registry does not know is refused even when inbound
/// compression is on: failing the gunzip with `Internal` would hide a
/// negotiation bug as a data error. A known coding is refused only when
/// the channel opted out of inbound compression.
pub(crate) fn refuse_encoding_reply(token: Option<&str>, accept_gzip: bool) -> Result<(), Status> {
    let Some(token) = token else {
        return Ok(());
    };
    if CompressionAlgorithm::parse(token).is_none() {
        #[cfg(feature = "zstd")]
        let accepted = "identity, gzip, deflate, and zstd";
        #[cfg(not(feature = "zstd"))]
        let accepted = "identity, gzip, and deflate";
        return Err(Status::unimplemented(format!(
            "grpc-encoding {token} not supported; this client accepts {accepted}"
        )));
    }
    if !accept_gzip {
        return Err(Status::unimplemented(
            "grpc-encoding not supported; this client accepts identity",
        ));
    }
    Ok(())
}

struct PreparedUnary {
    parts: http::response::Parts,
    body: backend::RecvStream,
    codec: Option<crate::compression::CompressionAlgorithm>,
    stock_response: Option<bool>,
    encoding: Option<String>,
}

fn prepare_unary(
    response: http::Response<backend::RecvStream>,
    accept_gzip: bool,
    tap: Option<&CallLogger>,
) -> Result<PreparedUnary, Status> {
    if response.status() != StatusCode::OK {
        let status = Status::unknown(format!("http {}", response.status()));
        if let Some(tap) = tap {
            tap.log_trailer(&Metadata::new(), &status);
        }
        return Err(status);
    }
    let (parts, body) = response.into_parts();
    if body.is_end_stream() {
        let status = status_from(&parts.headers, None);
        if status.code() != Code::Ok {
            if let Some(tap) = tap {
                tap.log_trailer(
                    &Metadata::from_owned_headers(parts.headers.clone()),
                    &status,
                );
            }
            return Err(status);
        }
    }
    if let Some(tap) = tap {
        tap.log_server_header(&Metadata::from_owned_headers(parts.headers.clone()));
    }
    let stock_response = crate::h2_backend::header_pool::is_stock_response(&parts.headers);
    let encoding = if stock_response.is_some() {
        None
    } else {
        grpc_encoding(&parts.headers).map(str::to_owned)
    };
    if let Err(status) = refuse_encoding_reply(encoding.as_deref(), accept_gzip) {
        if let Some(tap) = tap {
            tap.log_trailer(&Metadata::new(), &status);
        }
        return Err(status);
    }
    let codec = inbound_codec_from_token(encoding.as_deref());
    Ok(PreparedUnary {
        parts,
        body,
        codec,
        stock_response,
        encoding,
    })
}

pub(crate) fn finish_unary<Resp: CodecMessage>(
    response: http::Response<backend::RecvStream>,
    limits: MessageLimits,
    accept_gzip: bool,
    tap: Option<&CallLogger>,
) -> impl Future<Output = Result<crate::request::Response<Resp>, Status>> {
    match prepare_unary(response, accept_gzip, tap) {
        Err(status) => Either::Left(std::future::ready(Err(status))),
        Ok(prepared) => Either::Right(complete_unary::<Resp>(prepared, limits, accept_gzip, tap)),
    }
}

async fn complete_unary<Resp: CodecMessage>(
    prepared: PreparedUnary,
    limits: MessageLimits,
    accept_gzip: bool,
    tap: Option<&CallLogger>,
) -> Result<crate::request::Response<Resp>, Status> {
    let PreparedUnary {
        parts,
        mut body,
        codec,
        stock_response,
        encoding,
    } = prepared;
    let framed =
        match read_one_message::<Resp>(&mut body, limits, accept_gzip, codec, tap, true).await {
            Ok(framed) => framed,
            Err(status) => {
                if let Some(tap) = tap {
                    tap.log_trailer(status.metadata(), &status);
                }
                return Err(status);
            }
        };
    let trailers = match read_trailers(&mut body).await {
        Ok(trailers) => trailers,
        Err(status) => {
            if let Some(tap) = tap {
                tap.log_trailer(&Metadata::new(), &status);
            }
            return Err(status);
        }
    };
    let (status, trailers_md) = match trailers {
        Some(map) => {
            let bare_ok = crate::h2_backend::header_pool::is_bare_ok_trailer(&map);
            let status = if bare_ok {
                Status::ok()
            } else {
                status_from(&parts.headers, Some(&map))
            };
            let trailers_md = if bare_ok {
                crate::h2_backend::header_pool::recycle_received_ok_trailer(map);
                Metadata::new()
            } else {
                metadata_from_trailers(map)
            };
            (status, trailers_md)
        }
        None => (status_from(&parts.headers, None), Metadata::new()),
    };
    let header_md = metadata_from_response(parts.headers, stock_response);
    if let Some(tap) = tap {
        tap.log_trailer(&trailers_md, &status);
    }
    if status.code() != Code::Ok {
        return Err(status);
    }
    Ok(crate::request::Response::from_parts_compress(
        framed.message,
        header_md,
        trailers_md,
        framed.compressed,
    )
    .with_encoding(encoding))
}

pub(crate) fn finish_stream<Resp: CodecMessage + Send + 'static>(
    response: http::Response<backend::RecvStream>,
    limits: MessageLimits,
    deadline: Option<tokio::time::Instant>,
    accept_gzip: bool,
    tap: Option<CallLogger>,
) -> Result<crate::request::Response<Streaming<Resp>>, Status> {
    if response.status() != StatusCode::OK {
        let status = Status::unknown(format!("http {}", response.status()));
        if let Some(tap) = &tap {
            tap.log_trailer(&Metadata::new(), &status);
        }
        return Err(status);
    }
    let (parts, body) = response.into_parts();
    let trailers_only = body.is_end_stream();
    if trailers_only {
        // Trailers-Only: the status is in the headers and there is no stream.
        let status = status_from(&parts.headers, None);
        if status.code() != Code::Ok {
            if let Some(tap) = &tap {
                tap.log_trailer(
                    &Metadata::from_owned_headers(parts.headers.clone()),
                    &status,
                );
            }
            return Err(status);
        }
    }
    // A stock response is content-type plus accept-encoding. It has no
    // grpc-encoding, so the hashed miss is skipped.
    let stock_response = crate::h2_backend::header_pool::is_stock_response(&parts.headers);
    let encoding_token = if stock_response.is_some() {
        None
    } else {
        grpc_encoding(&parts.headers)
    };
    if let Err(status) = refuse_encoding_reply(encoding_token, accept_gzip) {
        if let Some(tap) = &tap {
            tap.log_server_header(&Metadata::from_owned_headers(parts.headers.clone()));
            tap.log_trailer(&Metadata::new(), &status);
        }
        return Err(status);
    }
    let encoding = encoding_token.map(str::to_owned);
    let codec = inbound_codec_from_token(encoding_token);
    let header_md = metadata_from_response(parts.headers, stock_response);
    if let Some(tap) = &tap {
        tap.log_server_header(&header_md);
    }
    Ok(crate::request::Response::from_parts(
        Streaming::from_wire(
            WireStream::<Resp>::new(body, limits, deadline, accept_gzip, codec, tap)
                .requiring_response_status(!trailers_only),
        ),
        header_md,
        Metadata::new(),
    )
    .with_encoding(encoding))
}

fn metadata_from_response(map: HeaderMap, stock: Option<bool>) -> Metadata {
    if let Some(grpc_proto) = stock {
        crate::h2_backend::header_pool::recycle_received_response(map, grpc_proto);
        Metadata::new()
    } else {
        Metadata::from_owned_headers(map)
    }
}

fn metadata_from_trailers(map: HeaderMap) -> Metadata {
    if crate::h2_backend::header_pool::is_bare_ok_trailer(&map) {
        crate::h2_backend::header_pool::recycle_received_ok_trailer(map);
        Metadata::new()
    } else {
        Metadata::from_owned_headers(map)
    }
}

pub(crate) fn hex_value(b: u8) -> Option<u8> {
    match b {
        b'0'..=b'9' => Some(b - b'0'),
        b'a'..=b'f' => Some(b - b'a' + 10),
        b'A'..=b'F' => Some(b - b'A' + 10),
        _ => None,
    }
}

pub(crate) fn percent_decode(s: &str) -> String {
    let bytes = s.as_bytes();
    if !bytes.contains(&b'%') {
        return s.to_owned();
    }
    let mut out = Vec::with_capacity(bytes.len());
    let mut i = 0;
    while let Some(&b) = bytes.get(i) {
        if b == b'%' {
            let hi = bytes.get(i + 1).copied().and_then(hex_value);
            let lo = bytes.get(i + 2).copied().and_then(hex_value);
            if let (Some(hi), Some(lo)) = (hi, lo) {
                out.push((hi << 4) | lo);
                i += 3;
                continue;
            }
        }
        out.push(b);
        i += 1;
    }
    String::from_utf8(out).unwrap_or_else(|e| String::from_utf8_lossy(e.as_bytes()).into_owned())
}

#[cfg(test)]
mod tests {
    use super::*;

    fn framed(payload: &[u8]) -> Vec<u8> {
        let mut buf = Vec::with_capacity(codec::HEADER_LEN + payload.len());
        buf.push(0);
        buf.extend_from_slice(
            &u32::try_from(payload.len())
                .expect("test len fits u32")
                .to_be_bytes(),
        );
        buf.extend_from_slice(payload);
        buf
    }

    #[derive(Debug, PartialEq, Eq)]
    struct RawMessage(Bytes);

    impl CodecMessage for RawMessage {
        fn encoded_len(&self) -> usize {
            self.0.len()
        }

        fn encode_payload<W: pbrs::WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.put_slice(&self.0);
            Ok(())
        }

        fn decode_payload(payload: Bytes) -> Result<Self, Status> {
            Ok(Self(payload))
        }

        fn empty() -> Self {
            Self(Bytes::new())
        }
    }

    #[test]
    fn compressed_frames_require_a_negotiated_encoding() {
        let limits = MessageLimits::default();
        let payload = Bytes::from_static(b"message");
        for token in [None, Some("identity"), Some("")] {
            let codec = inbound_codec_from_token(token);
            assert!(codec.is_none());
            let frame = Frame {
                compressed: true,
                payload: CompressionAlgorithm::Gzip
                    .encode(&payload)
                    .expect("gzip")
                    .into(),
            };
            let status = decode_frame::<RawMessage>(frame, limits, true, codec)
                .expect_err("flag one without a coding");
            assert_eq!(status.code(), Code::Internal);
        }
        for codec in [CompressionAlgorithm::Gzip, CompressionAlgorithm::Deflate] {
            let frame = Frame {
                compressed: true,
                payload: codec.encode(&payload).expect("compress").into(),
            };
            assert_eq!(
                decode_frame::<RawMessage>(frame, limits, true, Some(codec))
                    .expect("negotiated coding")
                    .message,
                RawMessage(payload.clone())
            );
            // A named coding does not require every message to be compressed.
            let frame = Frame {
                compressed: false,
                payload: payload.clone(),
            };
            assert_eq!(
                decode_frame::<RawMessage>(frame, limits, true, Some(codec))
                    .expect("per-message identity")
                    .message,
                RawMessage(payload.clone())
            );
        }
    }

    #[test]
    fn spanning_frame_pops_intact() {
        // A frame split across three chunks reassembles with an intact
        // payload, whatever the split points (including inside the header).
        for split in [1, 4, 5, 6, 64] {
            let wire = framed(&vec![0xABu8; 300]);
            let (a, rest) = wire.split_at(split.min(wire.len() - 1));
            let (b, c) = rest.split_at(rest.len() / 2);
            let mut reader = FrameReader::new(MessageLimits::new());
            reader.push(Bytes::copy_from_slice(a));
            assert!(reader.next_frame().expect("frame").is_none());
            reader.push(Bytes::copy_from_slice(b));
            reader.push(Bytes::copy_from_slice(c));
            let frame = reader.next_frame().expect("frame").expect("one frame");
            assert!(!frame.compressed);
            assert_eq!(frame.payload.as_ref(), vec![0xABu8; 300]);
            assert!(reader.next_frame().expect("frame").is_none());
        }
    }

    #[test]
    fn hostile_header_still_errors_at_pop() {
        // A length past the decode limit surfaces at pop (reserve-once was
        // reverted; see the NOTE on push).
        let mut wire = framed(&[9u8; 16]);
        wire[1..5].copy_from_slice(&u32::MAX.to_be_bytes());
        let mut reader = FrameReader::new(MessageLimits::new());
        reader.push(Bytes::copy_from_slice(&wire[..8]));
        reader.push(Bytes::copy_from_slice(&wire[8..]));
        assert!(reader.next_frame().is_err());
    }
}
