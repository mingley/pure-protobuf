from pathlib import Path
import hashlib,importlib.util,json,subprocess
from types import SimpleNamespace
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';driver=q/'architecture-c4-counter-ab-driver.py'
spec=importlib.util.spec_from_file_location('fallback_schedule',driver);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
p=q/'architecture-c4-instruction-expansion-plan.json';master=json.loads(p.read_text());base=master['options']['focused72']['argv'];base=base[:base.index('--output')]
cells=[dict(pair=list(pair),shape='client_stream',payload_bytes=65536,tls=False,compression='gzip',connections=1,in_flight=1) for pair in [m.PAIRS[3],m.PAIRS[4]]]
options={}
for label,repeats,abba in [('fallback24',3,False),('fallback32',4,True)]:
 workload=q/f'architecture-c4-instruction-{label}-workloads.json';workload.write_text(json.dumps(cells,indent=2)+'\n')
 args=SimpleNamespace(cells_file=workload,repeats=repeats,pilot=False,scope='selected',seed=20261022,count=10,abba=abba)
 expanded=m.cells_for(args);schedule=m.schedule_for(expanded,args)
 assert len(schedule)==2*repeats*4
 assert len({(row['version'],row['count'],json.dumps(expanded[row['cell_index']],sort_keys=True)) for row in schedule})==len(schedule)
 argv=base+['--output',str(q/f'architecture-c4-instruction-{label}'),'--phase','callgrind','--scope','selected','--cells-file',str(workload),'--repeats',str(repeats),'--count','10','--valgrind',str(root/'work/toolchain/valgrind/usr/bin/valgrind'),'--valgrind-lib',str(root/'work/toolchain/valgrind/usr/libexec/valgrind')]+(['--abba'] if abba else [])
 r=subprocess.run(argv+['--plan'],text=True,capture_output=True,check=True);offline=json.loads(r.stdout)
 options[label]=dict(argv=argv,expected_captures=len(schedule),expected_actual_rpc_calls=sum(row['count'] for row in schedule),scope_count=1,source_repeats=repeats,count=10,count2=20,supervisor_seconds=900,workloads_sha256=hashlib.sha256(workload.read_bytes()).hexdigest(),schedule=schedule,requires_root_followup=True,offline_argv_plan=offline,ordering='four repeats in seeded balanced ABBA blocks' if abba else 'three seeded randomized repeats; not balanced ABBA',instruction_profiles=len(schedule)*2,excluded='native/pbrs server and all bidi, pipeline, unary, TLS and higher-in-flight scopes are NOT_RUN in this fallback',estimate='pilot_elapsed_seconds / 4 * planned_captures * 1.3; same client_stream payload/compression as pilot, so no bidi factor')
 assert options[label]['expected_captures']==offline['captures']
 assert options[label]['expected_actual_rpc_calls']==offline['total_rpc_calls']
master['options'].update(options)
master['selection'].update(aggregate_cpu_capture_budget_seconds=900,pilot_counts_against_aggregate_budget=True,remaining_budget_formula='max(0, 900 - actual_pilot_elapsed_seconds)',fallback_formula='pilot_elapsed_seconds / 4 * planned_captures * 1.3',fallback_preference='If the broader options exceed the remaining budget, prefer fallback32 when it fits; otherwise fallback24 when it fits. Run only one selected expansion, after root followup.',execution_supervisor='Before starting the selected option, cap its global supervisor by the remaining aggregate budget; per-cell outer60s and RPC/readiness/teardown deadlines stay unchanged.')
master['limits']+=['Fallback scopes use only tonic/prost client to native/prost server and tonic/prost server. Both sources, endpoints and exact workload are retained.','Fallback24 has three randomized repeats and is not balanced ABBA. Fallback32 has four repeats in balanced ABBA blocks. No shipping harness or driver schedule changes.','The900s CPU capture budget includes pilot and at most one selected expansion; do not run the fallback options sequentially.']
p.write_text(json.dumps(master,indent=2)+'\n')
(q/'architecture-c4-instruction-fallback-plans.json').write_text(json.dumps(dict(state='PREPARED_NOT_RUN_ROOT_QUIET_AND_POST_PILOT_SELECTION_REQUIRED',qualified=False,options=options,selection=master['selection']),indent=2)+'\n')
print(json.dumps({label:{key:row[key] for key in ['expected_captures','expected_actual_rpc_calls','instruction_profiles','ordering']} for label,row in options.items()},indent=2))
