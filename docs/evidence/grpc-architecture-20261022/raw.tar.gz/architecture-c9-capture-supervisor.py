#!/usr/bin/env python3
"""Durable ordered source9d captures after C9 fixture-only qualification. Preparation alone never grants a quiet host.

Run only after the root's explicit quiet grant. The supervisor detaches each
phase through the reviewed launcher and journals progress. --resume reattaches
or validates successful retained work; it never repeats a failed capture.
"""
import argparse
import datetime
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
STEM = 'architecture-c8'  # Actual measured source/build/plans; unchanged.
QUAL_STEM = 'architecture-c9'  # New immutable qualification/supervisor journals.
QUALIFICATION = 'deb0d1d6b9855188a23128c0dca54c03dc2c8bfc'
CANDIDATE = '9d6fb9c416fc32732450fd78d32ee16ff8b802de'
BASELINE = '2eba72d86b4bb7db133120797e3c4746d86713bc'
STATE = Q / f'{QUAL_STEM}-capture-supervisor-state.json'
EVENTS = Q / f'{QUAL_STEM}-capture-supervisor-events.jsonl'
BUDGET = 900


def load(path):
    return json.loads(Path(path).read_text())


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.next')
    with temporary.open('w') as out:
        json.dump(value, out, indent=2)
        out.write('\n')
        out.flush()
        os.fsync(out.fileno())
    temporary.replace(path)


def inputs():
    master = load(Q / f'{STEM}-measurement-plan.json')
    oversized = load(Q / f'{STEM}-oversized-final-plan.json')
    cpu = load(Q / f'{STEM}-instruction-expansion-plan.json')
    rows = {key: master[key] for key in ['selected_native_ab', 'instruction_pilot', 'native_expanded']}
    rows.update({'oversized_' + key: value for key, value in oversized['phases'].items()})
    rows.update({'cpu_' + key: value for key, value in cpu['options'].items()})
    return master, rows


def output_of(row):
    return Path(row['argv'][row['argv'].index('--output') + 1])


def inventory(master, rows):
    paths = {Path(__file__), Q / f'{QUAL_STEM}-launch-supervisor.py', ROOT / 'work/record.py', Q / f'{STEM}-launch-phase.py',
             Q / f'{STEM}-source-pins.json', Q / f'{STEM}-build-preflight.json',
             Q / f'{STEM}-scope-corrections.json', Q / f'{QUAL_STEM}-workspace-final-state.json',
             Q / f'{QUAL_STEM}-workspace-final.json', Q / f'{QUAL_STEM}-qualification-source.json', Q / f'{STEM}-asan-supervisor-state.json',
             Q / f'{STEM}-workspace-disk-ready.json'}
    paths.update(Q / f'{STEM}-{name}.json' for name in
                 ['measurement-plan', 'oversized-final-plan', 'instruction-expansion-plan', 'instruction-fallback-plans'])
    for row in rows.values():
        paths.add(Path(row['argv'][1]))
        for flag in ['--cells-file', '--build-record', '--baseline-build-record', '--candidate-build-record',
                     '--binary', '--baseline-binary', '--candidate-binary']:
            if flag in row['argv']:
                paths.add(Path(row['argv'][row['argv'].index(flag) + 1]))
    for argv in master['summaries'].values():
        paths.add(Path(argv[1]))
    for checkout in ['architecture-c8', 'architecture-b4']:
        paths.update(ROOT / 'work' / checkout / relative for relative in master['harness_hashes'])
    return {str(path): digest(path) for path in sorted(paths)}


def proc_alive(pid, ticks=None):
    try:
        fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
        return fields[0] != 'Z' and (ticks is None or int(fields[19]) == ticks)
    except (FileNotFoundError, ProcessLookupError):
        return False


def matching_controllers(argv):
    # If only the outer recorder dies, do not relaunch its surviving controller.
    found = []
    for path in Path('/proc').glob('[0-9]*/cmdline'):
        try:
            args = path.read_bytes().rstrip(b'\0').split(b'\0')
            args = [os.fsdecode(value) for value in args]
            if args == argv and proc_alive(int(path.parent.name)):
                found.append(int(path.parent.name))
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    return found


def plan_view(master, rows):
    return dict(qualified=False, no_capture=True, candidate=CANDIDATE, baseline=BASELINE, qualification_checkpoint=QUALIFICATION,
                qualification_manifest=str(Q / f'{QUAL_STEM}-qualification-source.json'),
                order=['selected_native_ab', 'instruction_pilot', 'oversized_pilot',
                       'oversized_full_if_pilot_passes', 'native_expanded', 'one_cpu_expansion_if_budget_fits'],
                phases={key: {k: row[k] for k in ['expected_captures', 'expected_actual_rpc_calls', 'supervisor_seconds']}
                        for key, row in rows.items()},
                cpu_budget_seconds=BUDGET, cpu_selection_order=['with_pipeline144', 'with_unary108', 'focused72', 'fallback32', 'fallback24'],
                resume='Reattach an existing phase or validate successful retained results; never retry a failed phase.',
                requires='Explicit root quiet grant, successful C8 source9d build preflight, genuine C9 full-workspace PASS, and exact fixture-only9d-to-C9 diff. This plan authorizes no captures.',
                scope=master['limits'])


def qualification_equivalence():
    record = load(Q / f'{QUAL_STEM}-qualification-source.json')
    pin = record['qualification_source']
    if record.get('measured_source') != CANDIDATE or pin != QUALIFICATION or len(pin) != 40 or any(c not in '0123456789abcdef' for c in pin):
        raise RuntimeError('C9 full pin and explicit measured source9d required')
    changed = subprocess.check_output(['git', 'diff', '--name-only', CANDIDATE, pin, '--'],
                                      cwd=ROOT, text=True).splitlines()
    if changed != ['pbrs-grpc/tests/serving.rs']:
        raise RuntimeError('C9 qualification may change ONLY pbrs-grpc/tests/serving.rs; production/source differences rejected')
    diff = subprocess.check_output(['git', 'diff', '--binary', CANDIDATE, pin, '--'], cwd=ROOT)
    if record.get('changed_paths') != changed or record.get('diff_sha256') != hashlib.sha256(diff).hexdigest():
        raise RuntimeError('C9 fixture-only diff attestation mismatch')
    return record


def qualification_gates():
    qualification = qualification_equivalence()
    workspace = load(Q / f'{QUAL_STEM}-workspace-final-state.json')
    workspace_record = load(Q / f'{QUAL_STEM}-workspace-final.json')
    expected_source = dict(head=qualification['qualification_source'], status='')
    if (workspace.get('passed') is not True or workspace.get('source_before') != expected_source
            or workspace.get('source_after') != expected_source or workspace.get('cargo_exit_code') != 0
            or workspace.get('recorder_exit_code') != 0 or workspace_record.get('exit_code') != 0
            or workspace.get('jobs') != 2 or workspace.get('test_workers') != 4
            or workspace_record.get('command') != [str(ROOT / 'work/run-rust'), 'cargo', '+stable', 'test',
                '--locked', '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4']
            or workspace_record.get('environment', {}).get('CARGO_BUILD_JOBS') != '2'
            or workspace.get('totals', {}).get('failed') != 0
            or workspace.get('totals', {}).get('passed', 0) <= 0):
        raise RuntimeError('genuine final workspace PASS required; superseded workspace records cannot qualify')
    runtime_source = dict(head=CANDIDATE, status='')
    asan = load(Q / f'{STEM}-asan-supervisor-state.json')
    disk = load(Q / f'{STEM}-workspace-disk-ready.json')
    if (asan.get('state') != 'passed' or asan.get('source_before') != runtime_source
            or disk.get('source') != CANDIDATE or disk.get('cache_reclaimed') is not True
            or disk.get('asan_checks_passed') is not True):
        raise RuntimeError('fresh ASAN PASS/cache-reclaimed gate required')

    return qualification


class Supervisor:
    def __init__(self, args, master, rows):
        self.args, self.master, self.rows = args, master, rows
        manifest = inventory(master, rows)
        if args.resume:
            self.state = load(STATE)
            if self.state['quiet_grant'] != args.quiet_grant:
                raise RuntimeError('resume must use the original quiet-grant identifier')
            if self.state['inputs_sha256'] != manifest:
                raise RuntimeError('retained input manifest changed; refuse resume')
            if self.state['state'] == 'FAILED':
                raise RuntimeError('actual failure retained: root review required; no automatic retry')
        else:
            if STATE.exists() or EVENTS.exists():
                raise RuntimeError('retained supervisor evidence exists; use --resume')
            self.state = dict(state='PREPARING', qualified=False, candidate=CANDIDATE, baseline=BASELINE,
                              started_utc=now(), quiet_grant=args.quiet_grant, phases={}, summaries={},
                              inputs_sha256=manifest, cpu_budget_seconds=BUDGET)
        self.state['qualification_source'] = qualification_equivalence()
        self.preflight()
        self.event('RESUMED' if args.resume else 'INITIALIZED')

    def event(self, name, **details):
        entry = dict(at_utc=now(), event=name, **details)
        with EVENTS.open('a') as out:
            out.write(json.dumps(entry) + '\n')
            out.flush()
            os.fsync(out.fileno())
        self.state['updated_utc'] = entry['at_utc']
        atomic(STATE, self.state)
        print(json.dumps(entry), flush=True)

    def preflight(self):
        if inventory(self.master, self.rows) != self.state['inputs_sha256']:
            raise RuntimeError('source/controller/build input hash changed')
        qualification_gates()
        pins = load(Q / f'{STEM}-source-pins.json')
        if pins['candidate_benchmark'] != CANDIDATE or pins['baseline_benchmark'] != BASELINE:
            raise RuntimeError('wrong immutable source pins')
        verified = load(Q / f'{STEM}-build-preflight.json')
        if verified['state'] != 'both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED':
            raise RuntimeError('successful final build preflight is required')
        for name, pin in [('candidate', CANDIDATE), ('baseline', BASELINE)]:
            variant = verified['variants'][name]
            if variant['source']['commit'] != pin:
                raise RuntimeError('preflight source mismatch')
            checkout = Path(variant['checkout'])
            head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=checkout, text=True).strip()
            status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=checkout)
            if head != pin or status:
                raise RuntimeError('immutable benchmark source changed: ' + name)
            build = Path(variant['build_directory'])
            if digest(build / 'rpc-bench') != variant['binary_sha256'] or digest(build / 'build.json') != variant['build_record_sha256']:
                raise RuntimeError('attested build changed: ' + name)
        if self.master['sources'] != {'baseline': BASELINE, 'candidate': CANDIDATE}:
            raise RuntimeError('measurement plan source mismatch')

    def phase(self, name, bound=None):
        self.preflight()
        row = self.rows[name]
        prefix = Q / (STEM + '-' + name.replace('_', '-') + '-run')
        launch_path = prefix.with_name(prefix.name + '-launch.json')
        terminal_path = prefix.with_suffix('.json')
        campaign_path = output_of(row) / 'campaign.json'
        prior = self.state['phases'].get(name)
        if prior and prior['state'] == 'FAILED':
            raise RuntimeError('failed phase cannot be retried: ' + name)
        if not launch_path.exists():
            # A death between Popen and launch-journal publication is ambiguous.
            # Retained wrapper/controller evidence forbids starting it again.
            evidence = [prefix.with_name(prefix.name + '-wrapper.stdout'), prefix.with_suffix('.stdout'), output_of(row)]
            if prior or any(path.exists() for path in evidence):
                raise RuntimeError('incomplete phase launch evidence: ' + name + '; root review required')
            argv = ['python3', str(Q / f'{STEM}-launch-phase.py'), '--phase', name, '--quiet-grant', self.args.quiet_grant]
            if bound is not None:
                argv += ['--supervisor-seconds', str(bound)]
            self.state['state'] = 'RUNNING'
            self.event('PHASE_LAUNCH_INTENT', phase=name, command=argv)
            result = subprocess.run(argv, text=True, capture_output=True)
            for suffix, text in [('stdout', result.stdout), ('stderr', result.stderr)]:
                with prefix.with_name(prefix.name + '-supervisor-launch.' + suffix).open('x') as out:
                    out.write(text)
            if result.returncode:
                raise RuntimeError('phase launcher failed: ' + name + ': ' + result.stderr[-2000:])
        launch = load(launch_path)
        if launch['quiet_grant'] != self.args.quiet_grant or launch['phase'] != name:
            raise RuntimeError('retained phase launch does not match grant/phase')
        if launch['command'][4:] != row['argv']:
            raise RuntimeError('retained phase command changed')
        if bound is not None and launch['supervisor_seconds'] != bound:
            raise RuntimeError('retained phase CPU bound changed')
        launch_hash = digest(launch_path)
        if prior and prior['launch_sha256'] != launch_hash:
            raise RuntimeError('retained launch metadata changed')
        if not prior:
            self.state['phases'][name] = dict(state='RUNNING', launch=str(launch_path), launch_sha256=launch_hash)
            self.event('PHASE_ATTACHED', phase=name, pid=launch['pid'])
        while not terminal_path.exists():
            if not proc_alive(launch['pid'], launch['proc_start_ticks']):
                surviving = matching_controllers(row['argv'])
                if surviving:
                    self.state['phases'][name]['surviving_controller_pids'] = surviving
                    self.event('OUTER_RECORDER_LOST_CONTROLLER_STILL_RUNNING', phase=name, pids=surviving)
                    # Continue preserving the inner controller. Without the outer
                    # terminal record its completion will require manual audit.
                else:
                    raise RuntimeError('phase recorder died without a terminal record: ' + name + '; no retry')
            time.sleep(2)
        terminal = load(terminal_path)
        if prior and prior.get('terminal_sha256') and prior['terminal_sha256'] != digest(terminal_path):
            raise RuntimeError('retained terminal result changed')
        if terminal['command'] != row['argv']:
            raise RuntimeError('terminal command mismatch')
        campaign = load(campaign_path) if campaign_path.exists() else None
        passed = terminal.get('exit_code') == 0 and campaign and campaign.get('passed') is True and campaign.get('state') == 'finished'
        record = self.state['phases'][name]
        if prior and prior.get('campaign_sha256') and prior['campaign_sha256'] != (digest(campaign_path) if campaign else None):
            raise RuntimeError('retained campaign changed: ' + name)
        record.update(state='PASSED' if passed else 'FAILED', terminal=str(terminal_path), terminal_sha256=digest(terminal_path),
                      duration_seconds=terminal['duration_seconds'], exit_code=terminal.get('exit_code'),
                      campaign=str(campaign_path), campaign_sha256=digest(campaign_path) if campaign else None)
        self.event('PHASE_TERMINAL', phase=name, **record)
        if not passed:
            # Summaries can still be run manually to inspect every failed row.
            raise RuntimeError('capture phase failed, evidence retained: ' + name)
        if campaign.get('expected_captures') != row['expected_captures']:
            raise RuntimeError('campaign expected-capture count mismatch: ' + name)
        return record

    def summarize(self, name):
        if name in self.master['summaries']:
            argv = self.master['summaries'][name]
        else:
            argv = ['python3', str(Q / f'{STEM}-ab-summary.py'), '--campaign', str(output_of(self.rows[name])),
                    '--output', str(Q / f'{STEM}-{name.replace("_", "-")}-summary.json')]
        output = Path(argv[argv.index('--output') + 1])
        previous = self.state['summaries'].get(name)
        if previous:
            if digest(output) != previous['sha256']:
                raise RuntimeError('retained summary changed: ' + name)
        elif not output.exists():
            prefix = Q / f'{STEM}-{name.replace("_", "-")}-summary-controller'
            self.event('SUMMARY_INTENT', phase=name, command=argv)
            result = subprocess.run(argv, text=True, capture_output=True)
            attempt = 1
            while prefix.with_name(prefix.name + f'-attempt{attempt}.stdout').exists():
                attempt += 1
            with prefix.with_name(prefix.name + f'-attempt{attempt}.stdout').open('x') as out:
                out.write(result.stdout)
            with prefix.with_name(prefix.name + f'-attempt{attempt}.stderr').open('x') as out:
                out.write(result.stderr)
            if result.returncode:
                raise RuntimeError('summary failed: ' + name + ': ' + result.stderr[-2000:])
        value = load(output)
        if not value.get('passed') or value.get('qualified') is not False:
            raise RuntimeError('summary functional validation failed: ' + name)
        actual = value['actual_rpc_totals']
        if name == 'native_all_counters':
            completed = actual.get('completed_rpcs')
            expected = self.rows['native_expanded']['expected_actual_rpc_calls']
        else:
            completed = sum(v['completed_rpcs'] for v in actual.values())
            expected = self.rows[name]['expected_actual_rpc_calls']
        accounting_rows = [actual] if name == 'native_all_counters' else list(actual.values())
        expected_each = expected if name == 'native_all_counters' else expected // 2
        for accounting in accounting_rows:
            if any(accounting.get(key) != expected_each for key in ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs']):
                raise RuntimeError('actual offered/dispatched/completed/successful RPC count mismatch: ' + name)
            if any(accounting.get(key) != 0 for key in ['failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']):
                raise RuntimeError('RPC failures/dropped work retained: ' + name)
        if completed != expected:
            raise RuntimeError('actual completed RPC count mismatch: ' + name)
        record = dict(path=str(output), sha256=digest(output), actual_completed_rpcs=completed, qualified=False)
        self.state['summaries'][name] = record
        self.event('EARLY_SELECTED_SUMMARY_READY' if name == 'selected_native_ab' else 'SUMMARY_READY', phase=name, **record)
        return value

    def choose_cpu(self):
        previous = self.state.get('cpu_selection')
        if previous:
            return previous
        pilot = self.state['phases']['instruction_pilot']['duration_seconds']
        remaining = max(0, BUDGET - pilot)
        estimates = {}
        choice = None
        for option in ['with_pipeline144', 'with_unary108', 'focused72', 'fallback32', 'fallback24']:
            row = self.rows['cpu_' + option]
            factor = 1 if option.startswith('fallback') else 2
            estimated = pilot / 4 * row['expected_captures'] * factor * 1.3
            estimates[option] = estimated
            if choice is None and estimated <= remaining - 6:
                choice = option
        result = dict(option=choice, estimated_seconds=estimates, pilot_actual_wall_seconds=pilot,
                      remaining_seconds=remaining, supervisor_seconds=max(0, math.floor(remaining - 6)),
                      state='PLANNED' if choice else 'NOT_RUN',
                      reason='At most one expansion; fresh same-side tonic references. Conservative pilot extrapolation; no relaxed deadlines.',
                      not_run_options=[name for name in estimates if name != choice], qualified=False)
        self.state['cpu_selection'] = result
        self.event('CPU_SELECTION', **result)
        return result

    def run(self):
        for name in ['selected_native_ab', 'instruction_pilot', 'oversized_pilot', 'oversized_full', 'native_expanded']:
            self.phase(name)
            self.summarize('native_all_counters' if name == 'native_expanded' else name)
        decision = self.choose_cpu()
        if decision['option']:
            name = 'cpu_' + decision['option']
            self.phase(name, decision['supervisor_seconds'])
            self.summarize(name)
            spent = (self.state['phases']['instruction_pilot']['duration_seconds'] + self.state['phases'][name]['duration_seconds'])
            self.state['cpu_actual_wall_seconds'] = spent
            if spent > BUDGET:
                raise RuntimeError('aggregate profiler wall budget exceeded; all evidence retained')
        else:
            self.state['cpu_actual_wall_seconds'] = self.state['phases']['instruction_pilot']['duration_seconds']
        # Keep original legacy summary, after the strict all-counter summary.
        legacy = Q / f'{STEM}-counter-expanded-summary.json'
        if not legacy.exists():
            argv = self.master['summaries']['native_legacy']
            result = subprocess.run(argv, text=True, capture_output=True)
            self.event('LEGACY_SUMMARY_TERMINAL', command=argv, exit_code=result.returncode,
                       stdout=result.stdout, stderr=result.stderr)
            if result.returncode:
                raise RuntimeError('legacy summary failed')
        self.state['legacy_summary'] = dict(path=str(legacy), sha256=digest(legacy))
        self.preflight()
        self.state['state'] = 'FINISHED'
        self.event('QUIET_CAPTURES_ENDED', actual_completed_rpcs=sum(row['actual_completed_rpcs'] for row in self.state['summaries'].values()),
                   cpu_actual_wall_seconds=self.state['cpu_actual_wall_seconds'], qualified=False)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    modes.add_argument('--plan', action='store_true')
    modes.add_argument('--run', action='store_true')
    modes.add_argument('--resume', action='store_true')
    parser.add_argument('--quiet-grant', help='Exact root explicit quiet-grant identifier, authorizing this ordered conditional chain')
    args = parser.parse_args()
    master, rows = inputs()
    if args.plan:
        print(json.dumps(plan_view(master, rows), indent=2))
        return
    if not args.quiet_grant:
        parser.error('--run/--resume require the root explicit quiet grant; a build marker is not a grant')
    with (Q / f'{QUAL_STEM}-capture-supervisor.lock').open('a') as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            parser.error('another capture supervisor holds the lock')
        supervisor = None
        try:
            supervisor = Supervisor(args, master, rows)
            supervisor.run()
        except Exception as error:
            if supervisor is not None:
                supervisor.state['state'] = 'FAILED'
                supervisor.event('FAILED_REVIEW_REQUIRED_NO_RETRY', error=repr(error))
            raise


if __name__ == '__main__':
    main()
