from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,time
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';state={'state':'waiting for diagnostic build','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'runs':[]}
statepath=q/'architecture-c9-diagnostic-state.json'
def save(): statepath.write_text(json.dumps(state,indent=2)+'\n')
save();deadline=time.monotonic()+900
while not (q/'architecture-c9-diagnostic-build.json').exists():
 if time.monotonic()>deadline:raise TimeoutError('diagnostic build record missing')
 time.sleep(1)
record=json.loads((q/'architecture-c9-diagnostic-build.json').read_text());assert record['exit_code']==0,record
source=(q/'architecture-c9-diagnostic-serving.rs').read_bytes();assert source==(r/'pbrs-grpc/tests/serving.rs').read_bytes()
messages=[json.loads(line) for line in (q/'architecture-c9-diagnostic-build.stdout').read_text().splitlines()]
artifacts=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')=='serving' and m.get('executable')];assert len(artifacts)==1,artifacts
exe=q/'architecture-c9-diagnostic-serving-elf';assert not exe.exists();shutil.copy2(artifacts[0],exe);state.update(state='running diagnostic real-clock replays',executable=str(exe),elf_sha256=hashlib.file_digest(exe.open('rb'),'sha256').hexdigest(),source_sha256=hashlib.sha256(source).hexdigest());save()
checks=[('full',[str(exe),'--nocapture'])]+[(f'cap-repeat-{repeat}',[str(exe),'handler_sees_the_interceptor_deadline_on_request','--nocapture']) for repeat in range(10)]
for name,command in checks:
 assert source==(r/'pbrs-grpc/tests/serving.rs').read_bytes(),'source changed before diagnostic replay finished'
 prefix=q/('architecture-c9-diagnostic-'+name)
 result=subprocess.run(['python3',str(r/'work/record.py'),str(prefix),'300',*command],cwd=r)
 state['runs'].append({'name':name,'exit_code':result.returncode,'record':prefix.name+'.json'});save()
state.update(state='completed diagnostic real-clock replays',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
