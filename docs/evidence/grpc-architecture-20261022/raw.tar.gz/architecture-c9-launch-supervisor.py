#!/usr/bin/env python3
"""Detach the durable source9d chain qualified by C9 fixture-only checkpoint only after the explicit root quiet grant."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--quiet-grant', required=True)
p.add_argument('--resume', action='store_true', help='Reattach retained successful/running work; never retry failures')
a = p.parse_args()
script = Q / 'architecture-c9-capture-supervisor.py'
state = Q / 'architecture-c9-capture-supervisor-state.json'
if state.exists() and not a.resume:
    p.error('retained state exists; use --resume, which never retries failed captures')
if a.resume and not state.exists():
    p.error('no saved supervisor state to resume')
if a.resume and json.loads(state.read_text())['state'] == 'FAILED':
    p.error('actual failure requires root review; this launcher cannot retry failed captures')
verified = json.loads((Q / 'architecture-c8-build-preflight.json').read_text())
if verified['state'] != 'both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED':
    p.error('final build preflight required')
if verified['variants']['candidate']['source']['commit'] != '9d6fb9c416fc32732450fd78d32ee16ff8b802de':
    p.error('wrong candidate source')
spec = importlib.util.spec_from_file_location('qualified_capture_supervisor', script)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
qualification = module.qualification_gates()
index = 1
while (Q / f'architecture-c9-capture-supervisor-launch{index}.json').exists():
    index += 1
prefix = Q / f'architecture-c9-capture-supervisor-launch{index}'
argv = ['python3', '-u', str(script), '--resume' if a.resume else '--run', '--quiet-grant', a.quiet_grant]
record = dict(state='LAUNCH_INTENT', command=argv, started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              quiet_grant=a.quiet_grant, resume=a.resume, detached=True, qualification=qualification,
              supervisor_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),
              preflight_sha256=hashlib.sha256((Q / 'architecture-c8-build-preflight.json').read_bytes()).hexdigest())
with prefix.with_suffix('.json').open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
    out.flush()
    os.fsync(out.fileno())
with prefix.with_suffix('.stdout').open('xb') as stdout, prefix.with_suffix('.stderr').open('xb') as stderr:
    proc = subprocess.Popen(argv, cwd=ROOT / 'work/architecture-c8', stdin=subprocess.DEVNULL,
                            stdout=stdout, stderr=stderr, start_new_session=True,
                            env=dict(os.environ, RUSTUP_TOOLCHAIN='stable'))
fields = Path(f'/proc/{proc.pid}/stat').read_text().rsplit(')', 1)[1].split()
record.update(state='LAUNCHED', pid=proc.pid, proc_start_ticks=int(fields[19]))
temporary = prefix.with_suffix('.json.next')
with temporary.open('x') as out:
    json.dump(record, out, indent=2)
    out.write('\n')
    out.flush()
    os.fsync(out.fileno())
temporary.replace(prefix.with_suffix('.json'))
print(json.dumps(record, indent=2))
