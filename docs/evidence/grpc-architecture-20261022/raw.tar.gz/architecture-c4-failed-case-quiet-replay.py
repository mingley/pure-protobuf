from pathlib import Path
import subprocess,json,hashlib,datetime
r=Path('/workspace/pure-protobuf');q=r/'work/qualification'; cwd=r/'work/architecture-c3'
serving=r/'work/stable-target/debug/deps/serving-32fef501e8a47122'
tower=r/'work/stable-target/debug/deps/tower_client-5ee3edc62e8fa09f'
cases=[(serving,'a_handler_deadline_is_an_instant_that_elapses'),(serving,'a_tls_server_timeout_expires_when_the_client_sends_none'),(serving,'client_max_connection_age_resets_a_delayed_stream'),(serving,'tls_spawned_work_stops_when_the_client_cancels'),(tower,'streaming_adapters_keep_deadlines_after_headers_and_with_idle_producers')]
results=[]
for repeat in range(3):
 for i,(binary,name) in enumerate(cases):
  prefix=q/f'architecture-c4-failure-quiet-r{repeat}-case{i}'
  assert not prefix.with_suffix('.json').exists()
  command=['python3',str(r/'work/record.py'),str(prefix),'30',str(binary),'--exact',name,'--nocapture','--test-threads=1']
  completed=subprocess.run(command,cwd=cwd)
  results.append({'name':name,'repeat':repeat,'exit_code':completed.returncode,'record':str(prefix.with_suffix('.json')),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()})
(q/'architecture-c4-failed-case-quiet-replay.json').write_text(json.dumps({'scope':'exact C3 binaries, isolated cases, no concurrent builds; historical failures remain','source':'783bcd53c723032cd0ccbff5d4550f9a1c92cbb8','results':results,'ended_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
