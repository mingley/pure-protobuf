# Remaining large-gzip allocation cost

Read-only source review of runtime `9d6fb9c4` (also the runtime of fixture-only
qualification checkpoint `deb0d1d6`). No new build, test or benchmark was run.
The figures are cumulative allocation requests, including the full new size of
reallocations. They are not peak or retained memory and do not establish speed.

## Recorded worst case

Four-message ping-pong bidi, 1 MiB zero-filled payloads, gzip6, h2c, one connection,
one in-flight RPC, prost on both sides, native endpoint against tonic/prost.
The two-repetition source-paired diagnostic retains fresh tonic controls.

| Native endpoint | Native MiB/RPC | Tonic MiB/RPC | Extra MiB/RPC |
|---|---:|---:|---:|
| Client | 28.506 | 16.672 | 11.835 |
| Server | 27.497 | 15.666 | 11.831 |

## Where roughly 12 MiB can arise

Each endpoint encodes four messages and decodes four messages. Protobuf envelope
bytes put the decoded/encoded payload just above 1 MiB. Three source-level costs
have the right magnitude to explain the remaining gap:

| Component | Native path | Tonic path | Approximate extra native requests/RPC |
|---|---|---|---:|
| Plaintext encode scratch | Allocate about 1 MiB per message, discard each time | Retain/reclaim the same stream-owned buffer | 3 MiB |
| Decoded output | Restart geometric growth for each message: about 3 MiB requested per message | First message grows to about 2 MiB capacity, then capacity is reused | 8 MiB |
| Compressed output reservation | About 512 KiB reserved for roughly 1 KiB wire output, with fresh sink after each ping-pong flush | Stream keeps the remaining mutable allocation and can reclaim prior space | Roughly 1 MiB; batching/ownership affect it |

This is an explanatory allocation model, **not measured allocation-site
attribution**. Its roughly 12 MiB sum matches the observed 11.83 MiB difference.
Fixed compressor/decoder state, buffering, headers and scheduling can explain
residual differences; the current aggregate counters cannot assign them exactly.
Do not publish these components as separately measured savings.

### 1. Encode scratch deliberately discards these buffers

`pbrs-grpc/src/wire/encode.rs:190` caps retained scratch at 64 KiB.
`with_payload` reserves the whole encoded protobuf at line206, then replaces its
buffer with an empty one whenever capacity exceeds that cap (211–212). Therefore
all four 1 MiB protobufs allocate fresh plaintext scratch. Even a nominal 64 KiB
payload crosses this cap once protobuf envelope bytes are added.

Tonic0.14.6's `codec/encode.rs` keeps `uncompression_buf` on `EncodedBytes` and
clears it for subsequent messages (line153). `compression.rs` advances its read
position after compression (249); bytes1.12.1 can reclaim consumed front space
in `bytes_mut.rs:640–659`. The shared prost codec and application payload
allocations do not remove this transport scratch difference.

### 2. Bounded decode fixes final doubling, but restarts every message

`compression/mod.rs:89–107` creates a fresh Vec after an 8 KiB validated lookahead.
For a roughly 1 KiB compressed message producing `1 MiB + delta`, requests follow
8 KiB,16 KiB,...,1 MiB,then an exact `1 MiB + delta` final reservation. Their sum is
`3 MiB - 8 KiB + delta`. The C8 lookahead already removes the former final 2 MiB
capacity; it does not eliminate the preceding geometric allocation requests.

`wire/frame_reader.rs:244–245` converts that Vec to Bytes and moves it into the
codec. No decoded workspace returns to the stream. This repeats four times:
about12 MiB of decoded-output requests alone.

Tonic's `StreamingInner` owns a persistent `decompress_buf`; `codec/decode.rs:215`
clears it before decoding the next message. `codec/compression.rs:265–278` reserves
an initial bounded hint and writes through BytesMut. A first-message capacity
around2 MiB can serve later messages without repeating the growth sequence.
Bytes1.12.1 reclaims consumed front space when the mutable buffer is unique.

### 3. Compressed output guesses half the uncompressed size

`wire/encode.rs:322` and373 reserve `5 + plaintext_len/2 + 32`, although zeros
compress to roughly1 KiB. `OutBatch::take_frame`/`flush` replace the entire sink
at `wire/out_batch.rs:82`/91, so the next ping-pong message starts over.
Appending another compressed frame before flushing asks for the same large
*additional* capacity even when substantial spare capacity already exists;
this can double a roughly512 KiB allocation around the second tiny frame.
That batch scenario must not be asserted for every recorded ping-pong call.

Tonic `codec/encode.rs:102` splits the sent prefix while retaining the remaining
mutable handle. `compression.rs:213` also reserves a plaintext-sized hint, so it
is not allocation-free; its remaining buffer can be reclaimed once the prior
HTTP/2 bytes have been released (`bytes_mut.rs:704–746`). Actual sharing and
producer scheduling affect these allocations.

## Next bounded experiment

Prioritize reclaiming validated decoded output for owned codecs, then encode
scratch retention under an explicit aggregate workspace budget. These target the
roughly8 MiB and3 MiB components, rather than tuning only the smaller output hint.

- Add stream-owned decoded scratch with no extra allocation for uncompressed
  calls. Keep complete gzip-member/checksum/trailing-input validation, decoded
  caps and frame-count/work limits unchanged.
- After `T::decode_payload`, reclaim the backing allocation only if ownership is
  unique. Prost's owned Vec fields normally release the input; a lazy pbrs value
  may retain it. A retained input must cause a cache miss, not a forced copy,
  invalid reuse or a change to the message's retention semantics. A diagnostic
  `Bytes::try_into_mut` reclamation path is one concrete seam to test.
- Charge retained capacity, including spare capacity, to a finite shared cache
  budget with a per-stream ceiling. Make unavailable budget a cache miss, never
  an RPC failure. Release leases/buffers at EOF, error, cancellation and Drop.
  Include both encode and decode workspaces in the aggregate accounting. Do not
  simply raise the64 KiB constant or add an unbounded global pool.
- Measure current versus one-component-at-a-time variants on this exact
  four-message workload, plus long streams, many idle streams and concurrent
  traffic. Record requested bytes, retained live bytes/RSS, CPU and same-channel
  recovery. A lower requested-byte count alone cannot justify retention growth.
- Test output-reservation changes separately. A bounded small initial hint could
  save nearly2 MiB on four highly compressible messages, but may add growth/copies
  for incompressible output. Cover random and structured payloads, exact power-of-
  two boundaries and protobuf overhead. It is not a universal quick fix.

Before promoting a variant, require malformed later members, checksum/tail
failures, exact-cap/one-byte-overflow, count limits, cancellation/early reset,
retained-input and error cleanup controls. Then rerun the matched real-RPC
allocation cells and resource/soak checks. No shipping policy change is justified
by this source review alone.
