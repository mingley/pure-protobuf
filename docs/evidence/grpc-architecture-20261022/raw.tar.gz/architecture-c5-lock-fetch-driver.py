from pathlib import Path
import subprocess,os,json
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';env=os.environ.copy();env['RUSTUP_TOOLCHAIN']='stable';results=[]
for name,manifest in [('devloop','bench/devloop/Cargo.toml'),('rpc','rpc-bench/Cargo.toml'),('tonicbench','tonic-bench/Cargo.toml'),('interoptonic','tests/interop/tonic/Cargo.toml')]:
 prefix=q/('architecture-c5-lock-fetch-'+name)
 assert not prefix.with_suffix('.json').exists()
 command=['python3',str(r/'work/record.py'),str(prefix),'180',str(r/'work/run-rust'),'cargo','fetch','--locked','--manifest-path',manifest]
 completed=subprocess.run(command,cwd=r,env=env);results.append({'manifest':manifest,'exit_code':completed.returncode,'record':str(prefix.with_suffix('.json'))})
(q/'architecture-c5-lock-fetch-results.json').write_text(json.dumps({'scope':'existing CI lock-resolution checks; no tracked edits permitted, independent of test lint development','results':results},indent=2)+'\n')
