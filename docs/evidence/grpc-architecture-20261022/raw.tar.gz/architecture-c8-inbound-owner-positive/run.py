from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys
root=Path('/workspace/pure-protobuf');q=root/'work/qualification/architecture-c8-inbound-owner-positive';temp=root/'pbrs-grpc/tests/architecture_inbound_producer_controls.rs'
owned=['pbrs-grpc/src/server/drain.rs','pbrs-grpc/src/server/rpc.rs','pbrs-grpc/tests/lifecycle.rs']
sha=lambda b:hashlib.sha256(b).hexdigest()
source={p:sha((root/p).read_bytes()) for p in owned}
state={'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','owned_source_sha256':source,'records':[]}
save=lambda:(q/'state.json').write_text(json.dumps(state,indent=2)+'\n')
save();env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(root/'work/stable-target'),CARGO_BUILD_JOBS='1',RUST_TEST_THREADS='4')
rust=[str(root/'work/run-rust'),'cargo'];generated_hash=None

def run(name,command,timeout=900):
 state['active']=name;save()
 p=q/name;assert not p.with_suffix('.json').exists()
 r=subprocess.run([sys.executable,str(root/'work/record.py'),str(p),str(timeout),*command],cwd=root,env=env)
 state['records'].append({'name':name,'exit_code':r.returncode});save()
 assert r.returncode==0,(name,r.returncode)
 assert {p:sha((root/p).read_bytes()) for p in owned}==source,'owned runtime/test source changed during checks'

try:
 run('focused',rust+['test','--locked','-p','pbrs-grpc','--all-features','--lib','--test','lifecycle','--no-fail-fast','inbound_owner_','--','--test-threads=4'])
 run('all-lib',rust+['test','--locked','-p','pbrs-grpc','--all-features','--lib','--','--test-threads=4'])
 spec=importlib.util.spec_from_file_location('focused_copier',root/'work/qualification/architecture-c5-fixture-controls/driver.py');copier=importlib.util.module_from_spec(spec);spec.loader.exec_module(copier)
 original=(root/'pbrs-grpc/tests/serving.rs').read_text()
 names=['a_streaming_producer_is_not_cancelled_when_the_handler_returns','tls_streaming_producer_is_not_cancelled_when_the_handler_returns','mtls_streaming_producer_is_not_cancelled_when_the_handler_returns','unix_streaming_producer_is_not_cancelled_when_the_handler_returns','from_io_streaming_producer_is_not_cancelled_when_the_handler_returns']
 generated,stats=copier.focused_copy(original,names)
 assert all(copier.function_body(generated,n)==copier.function_body(original,n) for n in names)
 assert not temp.exists();generated_hash=sha(generated.encode());(q/'producer-generated.rs').write_text(generated);temp.write_text(generated)
 (q/'producer-manifest.json').write_text(json.dumps({'scope':'Positive filtered existing real transport producer-lifetime tests; not full-suite qualification.','shipping_source_sha256':sha(original.encode()),'generated_sha256':generated_hash,'focused_names':names,'filter':stats},indent=2)+'\n')
 run('producer-compile',rust+['test','--locked','-p','pbrs-grpc','--all-features','--test','architecture_inbound_producer_controls','--no-run','--message-format=json'])
 artifacts=[]
 for line in (q/'producer-compile.stdout').read_text().splitlines():
  try:a=json.loads(line)
  except json.JSONDecodeError:continue
  if a.get('reason')=='compiler-artifact' and a.get('target',{}).get('name')=='architecture_inbound_producer_controls' and a.get('executable'):artifacts.append(a['executable'])
 assert len(set(artifacts))==1,artifacts
 elf=Path(artifacts[-1]);(q/'producer-elf.json').write_text(json.dumps({'path':str(elf),'sha256':sha(elf.read_bytes())},indent=2)+'\n')
 run('producer-list',[str(elf),'--list'],30)
 import re
 listed=re.findall(r'^(.+): test$',(q/'producer-list.stdout').read_text(),re.M);assert sorted(listed)==sorted(names),listed
 run('producer-lifetime',[str(elf),'--test-threads=4'],60)
 assert sha(temp.read_bytes())==generated_hash;temp.unlink()
 run('fmt',rust+['fmt','--all','--check'],120)
 run('clippy',rust+['clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'])
 state['status']='passed'
except Exception as error:
 state['status']='FAILED';state['error']=repr(error)
finally:
 if temp.exists():
  if generated_hash is not None and sha(temp.read_bytes())==generated_hash:temp.unlink()
  else:state['status']='FAILED';state['cleanup_error']='Unexpected owned temporary-file edits preserved.'
 state['owned_sources_unchanged']={p:sha((root/p).read_bytes()) for p in owned}==source
 state['completed_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
print(json.dumps(state),flush=True)
sys.exit(0 if state['status']=='passed' else 1)
