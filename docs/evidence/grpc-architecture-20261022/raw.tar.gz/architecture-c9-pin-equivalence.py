from pathlib import Path
import datetime,hashlib,json,subprocess,sys
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';base='9d6fb9c416fc32732450fd78d32ee16ff8b802de'
def git(*args):return subprocess.check_output(['git',*args],cwd=r)
pin=git('rev-parse',sys.argv[1]+'^{commit}').decode().strip()
assert git('rev-parse','HEAD').decode().strip()==pin
assert not git('status','--porcelain','--untracked-files=all').strip()
changed=git('diff','--name-only',base,pin,'--').decode().splitlines()
assert changed==['pbrs-grpc/tests/serving.rs'],changed
diff=git('diff','--binary',base,pin,'--')
record={'measured_source':base,'qualification_source':pin,'changed_paths':changed,'diff_sha256':hashlib.sha256(diff).hexdigest(),'diff_bytes':len(diff),'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified':False,'scope':'All tracked files including runtime, build scripts, lockfiles and benchmark/controller sources are byte-identical except the corrected serving integration test; previous run results retain their actual source pins.'}
p=q/'architecture-c9-qualification-source.json';assert not p.exists();p.write_text(json.dumps(record,indent=2)+'\n')
(q/'architecture-c9-fixture-only.patch').write_bytes(diff)
print(json.dumps(record))
