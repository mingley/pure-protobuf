//! Kernel-only model of CancelFlag registration/signal, not the transport.
//! The registry mutex and one waiter are included; runtime integration tests
//! separately exercise multiple actual Wakers and cache reuse.

#[cfg(test)]
mod tests {
    use loom::sync::atomic::{AtomicBool, AtomicU8, Ordering};
    use loom::sync::{Arc, Mutex};
    use loom::thread;

    #[test]
    fn old_two_flags_can_lose_the_wake() {
        loom::model(|| {
            let cancelled = Arc::new(AtomicBool::new(false));
            let armed = Arc::new(AtomicBool::new(false));
            let registry = Arc::new(Mutex::new(false));
            let c = Arc::clone(&cancelled);
            let a = Arc::clone(&armed);
            let r = Arc::clone(&registry);
            let waiter = thread::spawn(move || {
                if c.load(Ordering::Acquire) {
                    return true;
                }
                *r.lock().unwrap() = true;
                a.store(true, Ordering::Release);
                c.load(Ordering::Acquire)
            });
            let signal = thread::spawn(move || {
                cancelled.store(true, Ordering::Release);
                armed.load(Ordering::Acquire) && *registry.lock().unwrap()
            });
            let ready = waiter.join().unwrap();
            let woke = signal.join().unwrap();
            assert!(ready || woke, "waiter is Pending and signal skipped its wake");
        });
    }

    #[test]
    fn new_shared_state_cannot_lose_the_wake() {
        loom::model(|| {
            const CANCELLED: u8 = 1;
            const ARMED: u8 = 2;
            let state = Arc::new(AtomicU8::new(0));
            let registry = Arc::new(Mutex::new(false));
            let s = Arc::clone(&state);
            let r = Arc::clone(&registry);
            let waiter = thread::spawn(move || {
                if s.load(Ordering::Acquire) & CANCELLED != 0 {
                    return true;
                }
                *r.lock().unwrap() = true;
                s.fetch_or(ARMED, Ordering::AcqRel) & CANCELLED != 0
            });
            let signal = thread::spawn(move || {
                state.fetch_or(CANCELLED, Ordering::AcqRel) & ARMED != 0
                    && *registry.lock().unwrap()
            });
            let ready = waiter.join().unwrap();
            let woke = signal.join().unwrap();
            assert!(ready || woke, "waiter is Pending and signal skipped its wake");
        });
    }
}
