#!/usr/bin/env python3
"""Offline controls: no campaign process, git mutation, or network is started."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch, Mock

BASE = Path('/workspace/pure-protobuf')

def load(name):
    spec = importlib.util.spec_from_file_location(name, BASE / 'work' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module

runner = load('run-architecture-c1-day')
publisher = load('publish-architecture-c1-day')

def report():
    return {'source': {'commit': publisher.SOURCE, 'dirty': False},
            'duration_requested_seconds': 86400, 'duration_actual_seconds': 86401.25,
            'exit_code': 0, 'qualification': {'qualified': True, 'soak_24h': {'status': 'completed'}},
            'smoke': {'status': 'passed', 'failures': []}}

def termination():
    return {'source': publisher.SOURCE, 'source_pin_verified_at_end': True,
            'exit_code': 0, 'state': 'terminated'}

class OutcomeControls(unittest.TestCase):
    def setUp(self):
        self.validation = Mock(return_value=[])
        patched = patch('runpy.run_path', return_value={'validate_report': self.validation})
        patched.start()
        self.addCleanup(patched.stop)
    def test_complete_day_still_never_qualifies_production(self):
        outcome = publisher.derive_outcome(report(), termination())
        self.assertEqual(outcome['day_status'], 'completed')
        self.assertIs(outcome['qualified'], False)
    def test_full_report_validation_is_required_for_completed_day(self):
        self.validation.return_value = ['missing recovery sample']
        value = report()
        outcome = publisher.derive_outcome(value, termination())
        self.validation.assert_called_once_with(value)
        self.assertEqual(outcome['day_status'], 'incomplete')
        self.assertEqual(outcome['validation_errors'], ['missing recovery sample'])
        self.assertIn('Report validation: missing recovery sample', outcome['failures'])
    def test_unknown_terminal_status_is_incomplete(self):
        for state in ['passed', 'running', 'not_run', '']:
            value = report(); value['qualification']['soak_24h']['status'] = state
            self.assertEqual(publisher.derive_outcome(value, termination())['day_status'], 'incomplete')
    def test_failed_campaign_preserves_status_and_reason(self):
        value = report(); value['qualification']['soak_24h']['status'] = 'failed'
        value['smoke'] = {'status': 'failed', 'failures': ['original failure']}
        value['exit_code'] = 101
        outcome = publisher.derive_outcome(value, termination())
        self.assertEqual(outcome['day_status'], 'failed')
        self.assertEqual(outcome['failures'], ['original failure'])
    def test_missing_report_is_incomplete(self):
        self.assertEqual(publisher.derive_outcome(None, termination())['day_status'], 'incomplete')
    def test_wrong_source_is_rejected(self):
        value = report(); value['source']['commit'] = '0' * 40
        with self.assertRaises(ValueError): publisher.derive_outcome(value, termination())
    def test_dirty_source_is_rejected(self):
        value = report(); value['source']['dirty'] = True
        with self.assertRaises(ValueError): publisher.derive_outcome(value, termination())
    def test_wrong_requested_duration_is_rejected(self):
        value = report(); value['duration_requested_seconds'] = 30
        with self.assertRaises(ValueError): publisher.derive_outcome(value, termination())
    def test_short_or_nonfinite_day_cannot_pass(self):
        for elapsed in [30, float('nan'), float('inf'), None]:
            value = report(); value['duration_actual_seconds'] = elapsed
            with self.subTest(elapsed=elapsed):
                self.assertEqual(publisher.derive_outcome(value, termination())['day_status'], 'incomplete')
    def test_changed_source_is_invalid(self):
        end = termination(); end['source_pin_verified_at_end'] = False
        self.assertEqual(publisher.derive_outcome(report(), end)['day_status'], 'invalid-source-pin')
    def test_failed_supervisor_cannot_publish_pass(self):
        for change in [{'exit_code': 124}, {'state': 'supervisor_failed'}]:
            end = termination(); end.update(change)
            self.assertEqual(publisher.derive_outcome(report(), end)['day_status'], 'incomplete')

class RealReportControls(unittest.TestCase):
    def complete_synthetic_report(self):
        # Data-level control only: these samples are synthetic, never a run.
        import runpy
        fixture = runpy.run_path(str(BASE / 'work/architecture-c1/tests/test_grpc_resource_campaign.py'))
        value = fixture['report']()
        value['source']['commit'] = publisher.SOURCE
        value.update(schema='pbrs.resource-campaign.v5', duration_requested_seconds=86400,
                     duration_actual_seconds=86401.25, smoke={'status': 'passed', 'failures': []})
        value['qualification']['soak_24h']['status'] = 'completed'
        value['build'] = {'profile': 'release', 'cargo_profile': {
            'opt_level': '3', 'debug_assertions': False, 'test': True}}
        value['commands']['build'] = fixture['CAMPAIGN'].build_command('release')
        sample = value['process_samples'][0]
        value['process_samples'] = [{**sample, 'elapsed_seconds': t} for t in range(0, 86401, 2)]
        return value
    def test_actual_controller_accepts_complete_synthetic_report(self):
        outcome = publisher.derive_outcome(self.complete_synthetic_report(), termination())
        self.assertEqual(outcome['day_status'], 'completed')
        self.assertEqual(outcome['validation_errors'], [])
        self.assertIs(outcome['qualified'], False)
    def test_actual_controller_rejects_nonrecovered_token_in_synthetic_report(self):
        value = self.complete_synthetic_report()
        value['events'][-1]['server_byte_tokens'] = 1
        outcome = publisher.derive_outcome(value, termination())
        self.assertEqual(outcome['day_status'], 'incomplete')
        self.assertIn('post-fault permits or observed streaming calls failed to recover', outcome['validation_errors'])

class LauncherControls(unittest.TestCase):
    def test_real_prerequisite_validation(self):
        for change, expected in [(None, True), ('wrong_head', False), ('dirty_tree', False),
                                 ('failed_preview', False), ('short_preview', False),
                                 ('debug_profile', False), ('changed_controller', False)]:
            with self.subTest(change=change), tempfile.TemporaryDirectory() as directory:
                root=Path(directory); checkout=root/'checkout'; (checkout/'scripts').mkdir(parents=True)
                (checkout/'scripts/grpc-resource-campaign.py').write_bytes(b'controller')
                preview=root/'preview.json'
                value={'source':{'commit':runner.SOURCE,'dirty':False},
                       'smoke':{'status':'passed'},'exit_code':0,
                       'duration_requested_seconds':30,'duration_actual_seconds':30.1,
                       'build':{'profile':'release'},'process_limits_requested':{'file_descriptors':128}}
                if change=='failed_preview': value['smoke']['status']='failed'
                if change=='short_preview': value['duration_actual_seconds']=29.9
                if change=='debug_profile': value['build']['profile']='debug'
                preview.write_text(json.dumps(value))
                def git(*args):
                    if args[0]=='rev-parse': return 'wrong' if change=='wrong_head' else runner.SOURCE
                    return ' M tracked' if change=='dirty_tree' else ''
                with patch.multiple(runner,CHECKOUT=checkout,PREVIEW=preview), \
                     patch.object(runner,'git',side_effect=git), \
                     patch.object(runner.subprocess,'run',return_value=subprocess.CompletedProcess([],1)), \
                     patch.object(runner.subprocess,'check_output',return_value=b'changed' if change=='changed_controller' else b'controller'):
                    if expected:
                        ready=runner.prerequisites()
                        self.assertEqual(ready['preview_process_limits'], {'file_descriptors':128})
                        self.assertEqual(ready['process_limits']['cpu_seconds'], {'soft':86430,'hard':86430})
                        self.assertEqual(ready['process_limits']['address_space'], {'soft':1073741824,'hard':1073741824})
                    else:
                        with self.assertRaises(ValueError): runner.prerequisites()
    def test_launch_snapshots_harness_and_refuses_second_attempt(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory); q = root/'q'; q.mkdir(); (root/'work').mkdir()
            names = ['run-architecture-c1-day.py', 'publish-architecture-c1-day.py', 'record.py', 'run-rust']
            for name in names: (root/'work'/name).write_text('snapshot ' + name)
            child = Mock(pid=4321)
            with patch.multiple(runner, ROOT=root, Q=q, OUTPUT=q/'day', HARNESS=q/'snapshot'), \
                 patch.object(runner, 'prerequisites', return_value={'qualified': False}), \
                 patch.object(runner.subprocess, 'Popen', return_value=child) as spawn, \
                 contextlib.redirect_stdout(io.StringIO()):
                runner.launch()
                launched = json.loads((q/(runner.PREFIX+'-launcher.json')).read_text())
                self.assertEqual(launched['pid'], 4321)
                self.assertTrue(spawn.call_args.kwargs['start_new_session'])
                for name in names: self.assertEqual((q/'snapshot'/name).read_text(), 'snapshot '+name)
                with self.assertRaises(FileExistsError): runner.launch()
                self.assertEqual(spawn.call_count, 1)
    def test_failed_prerequisite_starts_nothing(self):
        with tempfile.TemporaryDirectory() as directory:
            q = Path(directory)/'q'
            with patch.object(runner, 'Q', q), \
                 patch.object(runner, 'prerequisites', side_effect=ValueError('wrong source')), \
                 patch.object(runner.subprocess, 'Popen') as spawn:
                with self.assertRaises(ValueError): runner.launch()
                spawn.assert_not_called()
                self.assertEqual(list(q.iterdir()), [])
    def test_supervisor_records_real_pids_and_termination(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); q=root/'q'; q.mkdir(); harness=q/'harness'; harness.mkdir()
            (harness/'publisher.py').write_text('snapshot')
            child=Mock(pid=1234); child.wait.return_value=0
            def git(*args): return runner.SOURCE if args[0]=='rev-parse' else ''
            with patch.multiple(runner, ROOT=root, Q=q, OUTPUT=q/'day', HARNESS=harness), \
                 patch.object(runner, 'prerequisites', return_value={'qualified': False}), \
                 patch.object(runner, 'git', side_effect=git), \
                 patch.object(runner.subprocess, 'Popen', return_value=child), \
                 patch.object(runner.subprocess, 'run', return_value=subprocess.CompletedProcess([],0)):
                self.assertEqual(runner.supervise(), 0)
                launch=json.loads((q/(runner.PREFIX+'-launch.json')).read_text())
                end=json.loads((q/(runner.PREFIX+'-termination.json')).read_text())
                self.assertEqual(launch['pid'],1234)
                self.assertEqual(launch['pid_role'],'record_wrapper')
                self.assertTrue(end['source_pin_verified_at_end'])
                self.assertFalse(end['qualified'])

class PublisherControls(unittest.TestCase):
    def setUp(self):
        self.validation = Mock(return_value=[])
        patched = patch('runpy.run_path', return_value={'validate_report': self.validation})
        patched.start()
        self.addCleanup(patched.stop)
    def run_publication(self, pushes, conflict=False, ancestor=True):
        temporary = tempfile.TemporaryDirectory(); self.addCleanup(temporary.cleanup)
        root=Path(temporary.name); q=root/'q'; q.mkdir(); output=q/'day'; output.mkdir()
        worktree=root/'publication'; state=q/'publication.json'
        (output/'report.json').write_text(json.dumps(report()))
        (q/(publisher.PREFIX+'-termination.json')).write_text(json.dumps(termination()))
        calls=[]; push_number=0
        def git(*args, cwd=None, check=True):
            nonlocal push_number
            calls.append(args); result=0; stdout=''; stderr=''
            if args[0]=='merge-base': result=0 if ancestor else 1
            if args[:2]==('worktree','add'):
                (worktree/'docs/evidence').mkdir(parents=True)
                (worktree/'docs/evidence/README.md').write_text('# Evidence\n\n## Benchmark coverage and campaign readiness\n')
            if args[0]=='rev-parse': stdout='a'*40+'\n'
            if args[0]=='push': result=pushes[push_number]; push_number+=1
            if args[0]=='rebase' and args[1]!='--abort' and conflict:
                result=1; stderr='conflict'
            if args[0]=='diff': stdout='docs/evidence/README.md\n'
            return subprocess.CompletedProcess(args,result,stdout,stderr)
        with patch.multiple(publisher, ROOT=root,Q=q,OUTPUT=output,WORKTREE=worktree,STATE=state), \
             patch.object(publisher,'git',side_effect=git), \
             patch.object(publisher,'archive'), \
             contextlib.redirect_stdout(io.StringIO()), contextlib.redirect_stderr(io.StringIO()):
            code=publisher.publish()
        return code,json.loads(state.read_text()),calls
    def test_retry_uses_only_normal_push(self):
        code,state,calls=self.run_publication([1,1,0])
        self.assertEqual(code,0); self.assertEqual(state['state'],'published')
        self.assertEqual(sum(c[0]=='push' for c in calls),3)
        self.assertEqual(sum(c[:2]==('rebase','origin/main') for c in calls),2)
        self.assertFalse(any('--force' in part for c in calls for part in c))
    def test_three_failed_pushes_retain_failure(self):
        code,state,calls=self.run_publication([1,1,1])
        self.assertEqual(code,1); self.assertEqual(state['state'],'failed')
        self.assertEqual(len(state['push_attempts']),3)
        self.assertIn('evidence_commit',state)
    def test_conflicting_rebase_aborts_and_records(self):
        code,state,calls=self.run_publication([1],conflict=True)
        self.assertEqual(code,1); self.assertIn(('rebase','--abort'),calls)
        self.assertEqual(state['rebase_abort_returncode'],0)
        self.assertEqual(state['rebase_error']['conflicts'],['docs/evidence/README.md'])
    def test_source_must_be_on_main_before_publication(self):
        code,state,calls=self.run_publication([],ancestor=False)
        self.assertEqual(code,1)
        self.assertIn('not present in origin/main',state['error'])
        self.assertFalse(any(c[0]=='push' or c[0]=='worktree' for c in calls))

class ArchiveControls(unittest.TestCase):
    def test_archive_includes_source_and_logs_omits_binary_and_detects_tampering(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory); q=root/'q'; q.mkdir(); output=q/'resource-architecture-c1-day'; output.mkdir()
            (output/'report.json').write_text(json.dumps(report()))
            (output/'events.jsonl').write_text('{"phase":"terminal"}\n')
            (output/'resource-test').write_bytes(b'\x7fELFbinary omitted')
            harness=q/(publisher.PREFIX+'-harness'); harness.mkdir()
            (harness/'record.py').write_text('immutable harness snapshot')
            dest=root/'capsule'; dest.mkdir()
            with patch.multiple(publisher,Q=q,OUTPUT=output): publisher.archive(dest,report(),termination())
            manifest=json.loads((dest/'manifest.json').read_text())
            names={entry['path'] for entry in manifest['files']}
            self.assertIn('source/scripts/grpc-resource-campaign.py',names)
            self.assertIn('resource-architecture-c1-day/events.jsonl',names)
            self.assertIn(publisher.PREFIX+'-harness/record.py',names)
            self.assertNotIn('resource-architecture-c1-day/resource-test',names)
            archive=dest/'raw.tar.gz'; data=bytearray(archive.read_bytes()); data[-1]^=1; archive.write_bytes(data)
            checked=subprocess.run([sys.executable,str(dest/'check.py')],capture_output=True)
            self.assertNotEqual(checked.returncode,0)
            self.assertIn(b'archive checksum mismatch',checked.stderr)

if __name__=='__main__': unittest.main(verbosity=2)
