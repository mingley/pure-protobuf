#!/usr/bin/env python3
"""Launch the pinned streaming resource day, then publish its terminal evidence."""
from pathlib import Path
import argparse
import datetime
import fcntl
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '783bcd53c723032cd0ccbff5d4550f9a1c92cbb8'
CHECKOUT = ROOT / 'work/architecture-c3'
PREFIX = 'architecture-c3-day'
OUTPUT = Q / 'resource-architecture-c3-day'
PREVIEW = Q / 'architecture-c3-resource-preview/report.json'
PUBLISHER = ROOT / 'work/publish-architecture-c3-day.py'
SCRIPT = Path(__file__).resolve()
HARNESS = Q / (PREFIX + '-harness')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic_json(path, value):
    temporary = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def git(*args):
    return subprocess.run(['git', *args], cwd=CHECKOUT, check=True,
                          text=True, capture_output=True).stdout.strip()


def prerequisites():
    if git('rev-parse', 'HEAD') != SOURCE:
        raise ValueError('frozen checkout is not the requested source')
    if git('status', '--porcelain', '--untracked-files=all'):
        raise ValueError('frozen checkout has local changes')
    branch = subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=CHECKOUT,
                            capture_output=True)
    if branch.returncode != 1:
        raise ValueError('campaign checkout must remain detached')
    preview_bytes = PREVIEW.read_bytes()
    preview = json.loads(preview_bytes)
    if (preview.get('source', {}).get('commit') != SOURCE
            or preview.get('source', {}).get('dirty') is not False
            or preview.get('smoke', {}).get('status') != 'passed'
            or preview.get('exit_code') != 0
            or preview.get('duration_requested_seconds', 0) < 30
            or preview.get('duration_actual_seconds', 0) < 30
            or preview.get('build', {}).get('profile') != 'release'):
        raise ValueError('pinned release resource preview has not passed')
    controller = CHECKOUT / 'scripts/grpc-resource-campaign.py'
    expected = subprocess.check_output(
        ['git', 'show', SOURCE + ':scripts/grpc-resource-campaign.py'], cwd=ROOT)
    if controller.read_bytes() != expected:
        raise ValueError('campaign controller differs from the pinned source')
    return {
        'preview': {'path': str(PREVIEW), 'sha256': hashlib.sha256(preview_bytes).hexdigest(),
                    'source': preview['source'], 'smoke': preview['smoke'],
                    'duration_actual_seconds': preview['duration_actual_seconds'],
                    'binary': preview.get('binary')},
        'settings': preview.get('settings'),
        'preview_process_limits': preview.get('process_limits_requested'),
        # These are the unchanged defaults in the verified pinned controller;
        # its CPU allowance is requested duration + 30, hence 86,430 for a day.
        'process_limits': {key: {'soft': value, 'hard': value} for key, value in {
            'address_space': 1024 * 1024 * 1024, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': 86400 + 30}.items()},
        'controller_sha256': hashlib.sha256(expected).hexdigest(),
        'qualified': False,
        'qualification_limit': 'Shared-host resource duration; other release and performance gates remain separate.',
    }


def campaign_command():
    return [sys.executable, str(HARNESS / 'record.py'),
            str(Q / (PREFIX + '-supervisor')), '90000',
            str(HARNESS / 'run-rust'), 'python3', 'scripts/grpc-resource-campaign.py',
            '--source', SOURCE, '--output', str(OUTPUT), '--duration', '86400',
            '--build-profile', 'release']


def launch():
    Q.mkdir(parents=True, exist_ok=True)
    readiness = prerequisites()
    if OUTPUT.exists() or (Q / (PREFIX + '-launch.json')).exists():
        raise ValueError('this attempt already exists; prior evidence will not be overwritten')
    request = Q / (PREFIX + '-launch-request.json')
    # Exclusive creation prevents two launchers from reserving the same attempt.
    with request.open('x') as stream:
        json.dump({'requested_utc': now(), 'source': SOURCE, 'readiness': readiness}, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    HARNESS.mkdir(exist_ok=False)
    for name in ['run-architecture-c3-day.py', 'publish-architecture-c3-day.py', 'record.py', 'run-rust']:
        shutil.copy2(ROOT / 'work' / name, HARNESS / name)
    frozen_supervisor = HARNESS / SCRIPT.name
    log = Q / (PREFIX + '-supervisor.log')
    with log.open('xb') as stream:
        child = subprocess.Popen([sys.executable, str(frozen_supervisor), '--supervise'], cwd=ROOT,
                                 stdin=subprocess.DEVNULL, stdout=stream,
                                 stderr=subprocess.STDOUT, start_new_session=True,
                                 close_fds=True)
    # Popen's pid is recorded immediately, even if prerequisite revalidation fails.
    atomic_json(Q / (PREFIX + '-launcher.json'), {
        'state': 'supervisor_spawned', 'pid': child.pid, 'source': SOURCE,
        'started_utc': now(), 'command': [sys.executable, str(frozen_supervisor), '--supervise'],
        'log': str(log), 'qualified': False})
    print(json.dumps({'pid': child.pid, 'log': str(log), 'source': SOURCE}), flush=True)


def supervise():
    Q.mkdir(parents=True, exist_ok=True)
    with (Q / (PREFIX + '.lock')).open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        started = time.monotonic()
        termination = {'source': SOURCE, 'supervisor_pid': os.getpid(), 'qualified': False}
        child = None
        try:
            readiness = prerequisites()
            if OUTPUT.exists() or (Q / (PREFIX + '-launch.json')).exists():
                raise ValueError('campaign attempt already exists')
            argv = campaign_command()
            env = os.environ.copy()
            env.update(RUSTUP_TOOLCHAIN='stable',
                       CARGO_TARGET_DIR=str(ROOT / 'work/rpc-target'), CARGO_BUILD_JOBS='1')
            harness_hashes = {str(p.relative_to(Q)): hashlib.sha256(p.read_bytes()).hexdigest()
                              for p in sorted(HARNESS.iterdir()) if p.is_file()}
            child = subprocess.Popen(argv, cwd=CHECKOUT, env=env, stdin=subprocess.DEVNULL)
            atomic_json(Q / (PREFIX + '-launch.json'), {
                'state': 'running', 'source': SOURCE, 'pid': child.pid,
                'pid_role': 'record_wrapper',
                'supervisor_pid': os.getpid(), 'started_utc': now(),
                'cwd': str(CHECKOUT), 'command': argv,
                'requested_duration_seconds': 86400, 'wrapper_timeout_seconds': 90000,
                'readiness': readiness, 'qualified': False,
                'harness': harness_hashes})
            termination['exit_code'] = child.wait()
            termination['source_pin_verified_at_end'] = (
                git('rev-parse', 'HEAD') == SOURCE
                and not git('status', '--porcelain', '--untracked-files=all'))
            termination['state'] = 'terminated'
        except Exception as error:
            termination.update(state='supervisor_failed', error=str(error))
            traceback.print_exc()
            if child is not None and child.poll() is None:
                # Do not publish a live campaign if writing its launch record
                # failed. The record wrapper still owns the 90,000s timeout.
                termination['exit_code'] = child.wait()
        termination.update(ended_utc=now(), supervisor_elapsed_seconds=time.monotonic() - started)
        atomic_json(Q / (PREFIX + '-termination.json'), termination)
        # The publisher reports missing/incomplete reports truthfully as well.
        publication_error = None
        try:
            result = subprocess.run([sys.executable, str(HARNESS / PUBLISHER.name)], cwd=ROOT,
                                    stdin=subprocess.DEVNULL)
            publication_code = result.returncode
        except Exception as error:
            publication_code = 1
            publication_error = str(error)
            traceback.print_exc()
        if publication_code:
            state_path = Q / (PREFIX + '-publication.json')
            previous = json.loads(state_path.read_text()) if state_path.is_file() else {}
            if previous.get('state') not in ('failed', 'published'):
                atomic_json(state_path, {
                    'state': 'failed', 'source': SOURCE, 'qualified': False,
                    'ended_utc': now(), 'publisher_exit_code': publication_code,
                    'error': publication_error or 'Publisher exited without a terminal publication record.',
                    'previous_state': previous})
            print(f'publisher failed with exit code {publication_code}; retained records identify the failure',
                  flush=True)
        return publication_code


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--launch', action='store_true', help='detach a durable supervisor; requires passing preview')
    mode.add_argument('--check-ready', action='store_true', help='read-only prerequisite validation; starts nothing')
    mode.add_argument('--supervise', action='store_true', help='internal durable process mode')
    args = parser.parse_args()
    if args.check_ready:
        print(json.dumps(prerequisites(), indent=2))
    elif args.launch:
        launch()
    else:
        raise SystemExit(supervise())
