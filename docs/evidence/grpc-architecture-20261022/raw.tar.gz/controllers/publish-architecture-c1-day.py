#!/usr/bin/env python3
"""Archive the streaming day result and push its evidence with a normal main update."""
from pathlib import Path
import datetime
import gzip
import hashlib
import io
import json
import math
import os
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '902014588792c8eb9c5bd65c782704e099535259'
PREFIX = 'architecture-c1-day'
OUTPUT = Q / 'resource-architecture-c1-day'
WORKTREE = ROOT / 'work/architecture-c1-day-publication'
EVIDENCE = Path('docs/evidence/grpc-architecture-soak-20261022')
STATE = Q / (PREFIX + '-publication.json')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def atomic_json(path, value):
    temporary = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with temporary.open('w') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def git(*args, cwd=ROOT, check=True):
    return subprocess.run(['git', *args], cwd=cwd, check=check, text=True, capture_output=True)


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def derive_outcome(report, termination):
    if not report:
        return {'report_available': False, 'day_status': 'incomplete',
                'resource_status': 'incomplete', 'duration_actual_seconds': None,
                'exit_code': termination.get('exit_code'),
                'failures': ['No terminal resource report was produced.'], 'qualified': False}
    if (report.get('source', {}).get('commit') != SOURCE
            or report.get('source', {}).get('dirty') is not False
            or report.get('duration_requested_seconds') != 86400):
        raise ValueError('terminal report has an unexpected source or requested duration')
    smoke = report.get('smoke', {})
    day = report.get('qualification', {}).get('soak_24h', {})
    status = day.get('status', 'incomplete')
    if status not in ('completed', 'failed'):
        status = 'incomplete'
    elapsed = report.get('duration_actual_seconds')
    failures = list(smoke.get('failures', []))
    if termination.get('source_pin_verified_at_end') is not True:
        status = 'invalid-source-pin'
        failures.append('The frozen source pin was not verified at termination.')
    if status == 'completed' and (report.get('exit_code') != 0 or smoke.get('status') != 'passed'
                               or termination.get('exit_code') != 0
                               or termination.get('state') != 'terminated'
                               or not isinstance(elapsed, (int, float))
                               or not math.isfinite(elapsed) or elapsed < 86400):
        status = 'incomplete'
        failures.append('A reported pass lacked complete successful duration and resource checks.')
    # A completed day must satisfy the pinned controller's full validation,
    # including exact event order, resource recovery and executable attestation.
    import runpy
    controller = runpy.run_path(str(ROOT / 'work/architecture-c1/scripts/grpc-resource-campaign.py'))
    validation_errors = controller['validate_report'](report)
    if status == 'completed' and validation_errors:
        status = 'incomplete'
        failures.extend('Report validation: ' + item for item in validation_errors)
    return {'report_available': True, 'day_status': status,
            'validation_errors': validation_errors,
            'report_day_status': day.get('status'), 'resource_status': smoke.get('status', 'incomplete'),
            'duration_actual_seconds': elapsed, 'exit_code': report.get('exit_code'),
            'failures': failures, 'qualified': False}


def archive(dest, report, termination):
    paths = sorted(p for p in OUTPUT.rglob('*') if p.is_file()) if OUTPUT.exists() else []
    paths += sorted(p for p in Q.glob(PREFIX + '-*') if p.is_file()
                    and p != STATE and '.tmp.' not in p.name)
    paths += sorted(p for p in (Q / (PREFIX + '-harness')).rglob('*') if p.is_file())
    preview = Q / 'architecture-c1-resource-preview/report.json'
    if preview.is_file():
        paths.append(preview)
    files = []
    omitted = []
    for path in sorted(set(paths)):
        if path.is_symlink() or not path.resolve().is_relative_to(Q.resolve()):
            raise ValueError(f'unexpected evidence path: {path}')
        entry = {'path': str(path.relative_to(Q)), 'bytes': path.stat().st_size,
                 'sha256': digest(path)}
        with path.open('rb') as stream:
            executable = stream.read(4) == b'\x7fELF'
        if executable:
            omitted.append(entry)
        else:
            files.append((entry, path))
    memory = {}
    for name in ['scripts/grpc-resource-campaign.py', 'pbrs-grpc/tests/resource_qualification.rs',
                 'pbrs-grpc/tests/common/mod.rs', 'Cargo.toml', 'Cargo.lock']:
        memory['source/' + name] = subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=ROOT)
    memory['omitted-executables.json'] = (json.dumps({'executables': omitted}, indent=2) + '\n').encode()
    for name, data in memory.items():
        files.append(({'path': name, 'bytes': len(data),
                       'sha256': hashlib.sha256(data).hexdigest()}, data))
    target = dest / 'raw.tar.gz'
    with target.open('wb') as raw:
        with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                for entry, source in files:
                    member = tarfile.TarInfo(entry['path'])
                    member.size = entry['bytes']
                    member.mode = 0o644
                    if isinstance(source, bytes):
                        tar.addfile(member, io.BytesIO(source))
                    else:
                        with source.open('rb') as stream:
                            tar.addfile(member, stream)
    manifest = {'schema': 'pbrs.resource-capsule.v1', 'source': SOURCE, 'qualified': False,
                'archive': {'name': target.name, 'bytes': target.stat().st_size, 'sha256': digest(target)},
                'logical_bytes': sum(e['bytes'] for e, _ in files), 'files': [e for e, _ in files]}
    (dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    checker = subprocess.check_output(
        ['git', 'show', SOURCE + ':docs/evidence/grpc-validation-20261022/check.py'], cwd=ROOT)
    (dest / 'check.py').write_bytes(checker)
    subprocess.run([sys.executable, str(dest / 'check.py')], check=True)


def publish():
    if STATE.is_file() and json.loads(STATE.read_text()).get('state') == 'published':
        print(STATE.read_text(), end='', flush=True)
        return 0
    state = {'state': 'preparing', 'source': SOURCE, 'qualified': False,
             'started_utc': now(), 'worktree': str(WORKTREE), 'push_attempts': []}
    atomic_json(STATE, state)
    try:
        termination = json.loads((Q / (PREFIX + '-termination.json')).read_text())
        if termination.get('source') != SOURCE:
            raise ValueError('termination record source mismatch')
        report_path = OUTPUT / 'report.json'
        report_bytes = report_path.read_bytes() if report_path.is_file() else None
        report = json.loads(report_bytes) if report_bytes is not None else None
        outcome = derive_outcome(report, termination)
        state['outcome'] = outcome
        if report_bytes is not None:
            state['terminal_report'] = {'bytes': len(report_bytes),
                'sha256': hashlib.sha256(report_bytes).hexdigest()}
        if WORKTREE.exists():
            raise ValueError('publication worktree already exists; retained attempt requires review')
        git('fetch', 'origin', 'main')
        if git('merge-base', '--is-ancestor', SOURCE, 'origin/main', check=False).returncode:
            raise ValueError('campaign source is not present in origin/main; retained evidence was not published')
        git('worktree', 'add', '--detach', str(WORKTREE), 'origin/main')
        dest = WORKTREE / EVIDENCE
        dest.mkdir(parents=True, exist_ok=False)
        archive(dest, report, termination)
        if report_bytes is not None and digest(report_path) != state['terminal_report']['sha256']:
            raise ValueError('terminal report changed during publication')
        (dest / 'results.json').write_text(json.dumps({
            'source': SOURCE, 'requested_duration_seconds': 86400, **outcome,
            'termination': termination}, indent=2) + '\n')
        elapsed = outcome['duration_actual_seconds']
        duration = 'unavailable' if elapsed is None else f'{elapsed:,.2f} seconds ({elapsed / 3600:.2f} hours)'
        failures = '\n'.join('- ' + str(item).replace('\n', ' ') for item in outcome['failures']) or '- None reported.'
        (dest / 'README.md').write_text(f'''# Architecture resource soak, 2026-10-22

| Check | Result |
|---|---|
| Requested duration | 24 hours |
| Recorded duration | {duration} |
| Day status | {outcome['day_status']} |
| Resource checks | {outcome['resource_status']} |
| Process exit code | {outcome['exit_code']} |
| Production qualified | No |

Source: `{SOURCE}`.

This is a shared-host resource campaign with the original limits and checks.
Other feature, release and comparative performance gates remain separate.

Reported failures:

{failures}

The archive retains events, process samples, logs, command records, the preview
prerequisite and the pinned source controller. Executables are represented by
their hashes. A missing or incomplete report remains an incomplete result.

Verify every archived member:

```sh
python3 {EVIDENCE}/check.py
```
''')
        index = WORKTREE / 'docs/evidence/README.md'
        link = ('The [architecture resource day, source `90201458`](grpc-architecture-soak-20261022/README.md) '
                'has a terminal resource outcome; its source and qualification limits apply.\n\n')
        text = index.read_text()
        marker = '## Benchmark coverage and campaign readiness'
        index.write_text(text.replace(marker, link + marker, 1) if marker in text else text + '\n' + link)
        git('add', '--', str(EVIDENCE), 'docs/evidence/README.md', cwd=WORKTREE)
        git('commit', '-m', 'Record the architecture resource soak outcome', cwd=WORKTREE)
        state['evidence_commit'] = git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip()
        atomic_json(STATE, state)
        for attempt in range(1, 4):
            pushed = git('push', '--porcelain', 'origin', 'HEAD:main', cwd=WORKTREE, check=False)
            state['push_attempts'].append({'attempt': attempt, 'returncode': pushed.returncode,
                                           'stdout': pushed.stdout, 'stderr': pushed.stderr})
            if pushed.returncode == 0:
                state.update(state='published', ended_utc=now(),
                             evidence_commit=git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip())
                atomic_json(STATE, state)
                print(json.dumps(state), flush=True)
                return 0
            atomic_json(STATE, state)
            if attempt == 3:
                break
            git('fetch', 'origin', 'main', cwd=WORKTREE)
            rebased = git('rebase', 'origin/main', cwd=WORKTREE, check=False)
            if rebased.returncode:
                state['rebase_error'] = {'stdout': rebased.stdout, 'stderr': rebased.stderr,
                    'conflicts': git('diff', '--name-only', '--diff-filter=U', cwd=WORKTREE).stdout.splitlines()}
                aborted = git('rebase', '--abort', cwd=WORKTREE, check=False)
                state['rebase_abort_returncode'] = aborted.returncode
                raise RuntimeError('publication rebase conflicted; aborted and retained evidence commit')
            state['evidence_commit'] = git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip()
        raise RuntimeError('normal push failed three times; evidence commit retained for review')
    except Exception as error:
        state.update(state='failed', error=str(error), ended_utc=now())
        atomic_json(STATE, state)
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    raise SystemExit(publish())
