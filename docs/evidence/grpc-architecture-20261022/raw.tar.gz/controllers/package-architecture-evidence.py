#!/usr/bin/env python3
"""Snapshot this architecture attempt; hashes never imply qualification."""
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
BASE = '87fa88c134f07af6f1860545e9012bfebf0a2834'
DEST = ROOT / 'docs/evidence/grpc-architecture-20261022'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True)
    args = parser.parse_args()
    source = subprocess.check_output(['git', 'rev-parse', args.source + '^{commit}'],
                                     cwd=ROOT, text=True).strip()
    paths = set()
    for path in Q.iterdir():
        if path.name.startswith(('architecture-c1-', 'architecture-c2-', 'architecture-c3-', 'architecture-b4-', 'architecture-c4-', 'architecture-c5-', 'architecture-c6-', 'architecture-c7-', 'architecture-c8-', 'architecture-c9-', 'architecture-docs-final-',
                                 'compression-lookahead-probe', 'parker-controls', 'docs-style-')) or path.name in (
                                     'cancel-flag-loom', 'cancel-flag-reentrant-control'):
            # Day logs/events remain live. Its separate terminal capsule owns
            # those; this capsule includes only a deliberately frozen snapshot.
            if path.name.startswith(('architecture-c1-day-', 'architecture-c2-day-',
                                     'architecture-c3-day-', 'architecture-c8-day-')) and not (
                    path.name.endswith('-day-snapshot')
                    or '-day-tools' in path.name):
                continue
            if path.is_file():
                paths.add(path)
            elif path.is_dir():
                paths.update(p for p in path.rglob('*') if p.is_file())
    entries, omitted = [], []
    # Keep paths, not all contents, resident while writing. Capture mutable
    # contents exactly once below so each manifest hash describes archived bytes.
    generated = {}
    for name in ['record.py', 'run-rust', 'package-architecture-evidence.py',
                 'prepare-architecture-c1.py', 'run-architecture-c1-day.py',
                 'publish-architecture-c1-day.py', 'test-architecture-c1-day-tools.py',
                 'run-architecture-c2-day.py', 'publish-architecture-c2-day.py',
                 'test-architecture-c2-day-tools.py', 'run-architecture-c3-day.py',
                 'publish-architecture-c3-day.py', 'test-architecture-c3-day-tools.py',
                 'run-architecture-c8-day.py', 'publish-architecture-c8-day.py',
                 'test-architecture-c8-day-tools.py']:
        generated['controllers/' + name] = (ROOT / 'work' / name).read_bytes()
    # Publication prose is distinct from the tested-source snapshot below.
    for name in ['README.md', 'results.json']:
        generated['published-documents/capsule/' + name] = (DEST / name).read_bytes()
    for name in ['TODO.md', 'docs/benchmarks.md', 'docs/status.md', 'docs/scoreboard.md',
                 'docs/resource-budgets.md', 'docs/decisions/grpc-execution.md',
                 'docs/decisions/compression.md', 'docs/evidence/README.md']:
        generated['published-documents/' + name] = (ROOT / name).read_bytes()
    for name in ['architecture-codegen-20261022.md', 'architecture-transport-20261022.md']:
        generated['reviews/' + name] = (ROOT / 'work' / name).read_bytes()
    generated['source-delivered/changes.patch'] = subprocess.check_output(
        ['git', 'diff', '--binary', BASE, source], cwd=ROOT)
    generated['source-delivered/pin.json'] = (json.dumps({
        'commit': source, 'base': BASE, 'qualified': False,
        'tree': subprocess.check_output(['git', 'rev-parse', source + '^{tree}'], cwd=ROOT, text=True).strip()
    }, indent=2) + '\n').encode()
    names = subprocess.check_output(['git', 'diff', '--name-only', BASE, source], cwd=ROOT, text=True).splitlines()
    for name in names:
        generated['source-delivered/' + name] = subprocess.check_output(['git', 'show', source + ':' + name], cwd=ROOT)
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / 'raw.tar.gz'
    with archive.open('wb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as tar:
                def add(name, data):
                    entry = {'path': name, 'bytes': len(data), 'sha256': sha(data)}
                    member = tarfile.TarInfo(name)
                    member.mode, member.size = 0o644, len(data)
                    tar.addfile(member, io.BytesIO(data))
                    entries.append(entry)

                for path in sorted(paths):
                    if path.is_symlink() or not path.resolve().is_relative_to(Q.resolve()):
                        raise ValueError(f'unexpected evidence path: {path}')
                    data = path.read_bytes()
                    name = str(path.relative_to(Q))
                    if data.startswith(b'\x7fELF'):
                        omitted.append({'path': name, 'bytes': len(data), 'sha256': sha(data)})
                    else:
                        add(name, data)
                generated['omitted-executables.json'] = (json.dumps({'executables': omitted}, indent=2) + '\n').encode()
                for name, data in sorted(generated.items()):
                    add(name, data)
    manifest = {
        'schema': 'pbrs.architecture-capsule.v1', 'source': source, 'qualified': False,
        'archive': {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive.read_bytes())},
        'logical_bytes': sum(e['bytes'] for e in entries), 'files': entries,
    }
    (DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copyfile(ROOT / 'docs/evidence/grpc-validation-20261022/check.py', DEST / 'check.py')
    subprocess.run(['python3', str(DEST / 'check.py')], check=True)
    print(json.dumps({'files': len(entries), 'logical_bytes': manifest['logical_bytes'],
                      'archive_bytes': archive.stat().st_size, 'qualified': False}))


if __name__ == '__main__':
    main()
