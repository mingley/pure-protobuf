#!/usr/bin/env python3
"""Prepare source-pinned validation commands. This program never executes them."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import shutil
import subprocess
import sys

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
OLD_DAY_SOURCE = '6cd91911afce24cceee6df3f60a945453e5b04da'
EARLIER_SOURCE = '8fe0f8aeb41356ff427f44542947f36f6d2a2dae'


def git(checkout, *args):
    return subprocess.check_output(['git', *args], cwd=checkout, text=True).strip()


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(block)
    return value.hexdigest()


def baseline(directory, checkout, source):
    record = json.loads((directory / 'build.json').read_text())
    binary = directory / 'rpc-bench'
    if (record.get('source', {}).get('commit') != source or record.get('exit_code') != 0
            or record.get('binary_sha256') != digest(binary)
            or git(checkout, 'rev-parse', 'HEAD') != source
            or git(checkout, 'status', '--porcelain', '--untracked-files=all')):
        raise ValueError('baseline source or artifact does not match its retained record')
    return {'source': source, 'checkout': str(checkout), 'binary': str(binary),
            'build_record': str(directory / 'build.json'), 'binary_sha256': digest(binary)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', required=True, help='full next-candidate commit; no inferred default')
    parser.add_argument('--checkout', type=Path, required=True, help='clean candidate checkout; never changed by this tool')
    parser.add_argument('--prefix', default='architecture-c1')
    args = parser.parse_args()
    checkout = args.checkout.resolve(strict=True)
    if not re.fullmatch(r'[0-9a-f]{40}', args.source) or not re.fullmatch(r'[a-z0-9-]+', args.prefix):
        parser.error('source must be a full commit and prefix must contain lowercase letters, digits or hyphens')
    if args.source in (OLD_DAY_SOURCE, EARLIER_SOURCE):
        parser.error('the next candidate must have its own source pin')
    if checkout in ((ROOT / 'work/validation-fixes').resolve(),
                    (ROOT / 'work/measurement-final').resolve()):
        parser.error('existing baseline checkouts are immutable; use another candidate checkout')
    if (git(checkout, 'rev-parse', 'HEAD') != args.source
            or git(checkout, 'status', '--porcelain', '--untracked-files=all')):
        parser.error('candidate must be clean at the explicit source pin')
    previous = baseline(Q / 'rpc-build-streaming-c3', ROOT / 'work/validation-fixes', OLD_DAY_SOURCE)
    earlier = baseline(Q / 'rpc-build-route', ROOT / 'work/measurement-final', EARLIER_SOURCE)
    directory = Q / (args.prefix + '-plan')
    directory.mkdir(parents=True, exist_ok=False)
    wrapper = str(ROOT / 'work/run-rust')
    record = str(ROOT / 'work/record.py')
    stable = {'RUSTUP_TOOLCHAIN': 'stable', 'CARGO_BUILD_JOBS': '1',
              'CARGO_TARGET_DIR': str(ROOT / 'work/stable-target')}
    phases = []

    def phase(name, commands, requires=(), target=None, timeout=2400, note=''):
        env = dict(stable)
        if target:
            env['CARGO_TARGET_DIR'] = str(ROOT / 'work' / target)
        phases.append({'name': name, 'status': 'not_run', 'requires': list(requires),
                       'cwd': str(checkout), 'environment': env, 'note': note,
                       'commands': [[sys.executable, record,
                                     str(Q / f'{args.prefix}-{name}-{index + 1}'), str(timeout),
                                     wrapper, *command] for index, command in enumerate(commands)]})

    phase('focused', [
        ['cargo', 'fmt', '--all', '--', '--check'],
        ['cargo', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', '--lib'],
        ['cargo', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features',
         '--test', 'compression', '--test', 'compression_negotiation',
         '--test', 'streaming_final_status', '--test', 'bidi_completion',
         '--test', 'resource_bounds', '--no-fail-fast'],
    ], note='Reject malformed/truncated/extra compressed input on native and adapter paths; retain deadlines and fused cancellation behavior.')
    phase('all-features', [
        ['cargo', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', '--tests', '--no-fail-fast'],
    ], requires=['focused'], note='Includes seeded lifecycle, socket schedules, adapters, interop and serving. Do not weaken existing assertions.')
    phase('msrv', [
        ['cargo', '+1.85.0', 'check', '--locked', '-p', 'pbrs', '-p', 'pbrs-grpc', '--lib'],
    ], requires=['focused'], target='msrv-target',
          note='Default feature MSRV only; optional zstd declares a higher MSRV and needs its own feature claim.')
    phase('workspace', [
        ['cargo', 'test', '--locked', '--workspace', '--all-features', '--no-fail-fast'],
    ], requires=['focused'], note='Arrange >=6 GiB disk headroom first: consumer fixtures can create several GiB of additional cache.')
    phase('strict-lint', [
        ['cargo', 'clippy', '--locked', '-p', 'pbrs-grpc', '--all-targets', '--all-features', '--', '-D', 'warnings'],
    ], requires=['focused'], note='Retain all diagnostics. Existing strict lint failures remain production blockers; no blanket allows.')
    phase('resource-preview', [
        ['python3', 'scripts/grpc-resource-campaign.py', '--source', args.source,
         '--output', str(Q / (args.prefix + '-resource-preview')), '--duration', '30', '--build-profile', 'release'],
    ], requires=['focused', 'all-features', 'msrv'], timeout=1800,
          note='Original finite caps and resource checks. Independent of the still-running old 6cd day; never stop or repin that job.')
    build_directory = Q / (args.prefix + '-rpc-build')
    phase('rpc-build', [
        ['python3', 'scripts/build-rpc-bench.py', '--source', args.source, '--output', str(build_directory)],
    ], target='rpc-target', timeout=1800,
          note='Build and preserve its exact executable/log hashes before any allocation comparison.')
    native_commands = []
    candidate = {'checkout': str(checkout), 'binary': str(build_directory / 'rpc-bench'),
                 'build_record': str(build_directory / 'build.json')}
    for repeat, order in enumerate((('6cd', 'candidate'), ('candidate', '6cd'), ('6cd', 'candidate')), 1):
        for label in order:
            build = previous if label == '6cd' else candidate
            native_commands.append([
                'python3', str(checkout / 'scripts/grpc-counter-campaign.py'),
                '--source-checkout', build['checkout'], '--binary', build['binary'],
                '--build-record', build['build_record'],
                '--output', str(Q / f'{args.prefix}-native-r{repeat}-{label}'),
                '--phase', 'native', '--payloads', '1024', '--load-levels', '1:1',
                '--count', '200', '--repeats', '1', '--seed', str(20261009 + repeat - 1),
            ])
    phase('native-ab', native_commands, requires=['focused', 'all-features', 'msrv', 'rpc-build'],
          target='rpc-target', timeout=600,
          note='AB/BA/AB, 600 captures per source, all five pairs/shapes and four h2c/TLS identity/gzip profiles. Basic zero-filled 1KiB corpus only. Compare per-side allocation/requested-byte medians; no qualified latency/speed claim while the old day runs.')
    old_progress = Q / 'resource-streaming-c3-day/progress.json'
    state = json.loads(old_progress.read_text()) if old_progress.is_file() else None
    plan = {'schema': 'pbrs.architecture-validation-plan.v1', 'state': 'prepared_not_run',
            'source': args.source, 'tree': git(checkout, 'rev-parse', 'HEAD^{tree}'),
            'checkout': str(checkout), 'qualified': False,
            'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'disk_free_bytes_at_preparation': shutil.disk_usage(ROOT).free,
            'old_6cd_day_snapshot': state,
            'limits': ['The old day belongs exclusively to 6cd, even if it later passes.',
                       'A running resource campaign excludes quiet-host latency qualification.',
                       'No new day, test, build, benchmark or remote write is started by this planner.',
                       'Statuses remain not_run until the coordinator executes and records each command.'],
            'baselines': {'previous': previous, 'earlier': earlier}, 'phases': phases}
    (directory / 'plan.json').write_text(json.dumps(plan, indent=2) + '\n')
    patch = subprocess.check_output(['git', 'diff', OLD_DAY_SOURCE, args.source, '--',
                                     'pbrs-grpc/src', 'pbrs-grpc/tests'], cwd=checkout)
    (directory / 'candidate-changes.patch').write_bytes(patch)
    print(directory / 'plan.json')


if __name__ == '__main__':
    main()
