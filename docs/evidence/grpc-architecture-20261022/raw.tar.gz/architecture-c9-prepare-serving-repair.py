from pathlib import Path
import re
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';s=(q/'architecture-c9-diagnostic-serving.rs').read_text()

def body(name):
 a=s.index('async fn '+name);b=s.index('\n}',a)+2;return a,b,s[a:b]
def replace_body(name,new):
 global s
 a,b,_=body(name);s=s[:a]+new+s[b:]
def paused(name):
 global s
 pattern=r'#\[tokio::test(?:\([^\n]*\))?\]\n(async fn '+re.escape(name)+r'\()'
 s,n=re.subn(pattern,r'#[tokio::test(start_paused = true)]\n\1',s);assert n==1,(name,n)
def connect_frozen(b):
 for old,label in [('tls_channel(addr).await','TLS connect'),('channel(addr).await','TCP connect'),('tls_channel_with(addr, client_tls).await','mTLS connect'),('unix_channel(&path).await','Unix connect')]:
  if old in b:b=b.replace(old,f'drive_frozen_fixture({old[:-6]}, "{label}").await')
 old='''Channel::from_io(client_io, "localhost")
            .await'''
 if old in b:b=b.replace(old,'''drive_frozen_fixture(Channel::from_io(client_io, "localhost"), "from_io connect")
            .await''')
 return b

client_names=['a_client_interceptor_can_set_a_deadline','a_tls_client_interceptor_can_set_a_deadline','an_mtls_client_interceptor_can_set_a_deadline','a_unix_client_interceptor_can_set_a_deadline','a_from_io_client_interceptor_can_set_a_deadline']
server_names=['spawned_work_stops_when_the_deadline_fires','tls_spawned_work_stops_when_the_deadline_fires','mtls_spawned_work_stops_when_the_deadline_fires','unix_spawned_work_stops_when_the_deadline_fires','from_io_spawned_work_stops_when_the_deadline_fires']
for name in client_names+server_names:
 _,_,b=body(name);ms=40 if name in client_names else 20
 old='''    let child_done = Arc::new(AtomicUsize::new(0));''';assert b.count(old)==1;b=b.replace(old,old+'\n    let probe = Arc::new(FixtureHandlerProbe::default());',1)
 old='''    let hang = SpawnHang {
        started: Arc::clone(&started),
        finished: Arc::clone(&finished),
        child_done: Arc::clone(&child_done),
    };'''
 new='''    let hang = ProbedFixtureGreeter {
        inner: SpawnHang {
            started: Arc::clone(&started),
            finished: Arc::clone(&finished),
            child_done: Arc::clone(&child_done),
        },
        probe: Arc::clone(&probe),
    };''';assert b.count(old)==1;b=b.replace(old,new,1);b=connect_frozen(b)
 if 'unix' in name:
  pos=b.index('    let client =');b=b[:pos]+'    await_fixture_unix_listener(&path).await;\n'+b[pos:]
 start=b.index('    assert_');end=b.rfind('    task.abort();') if '    task.abort();' in b else b.rfind('    server.abort();');assert end>start
 b=b[:start]+f'''    assert_controlled_deadline_on_every_shape(
        &client, &probe, &started, &finished, &child_done,
        Duration::from_millis({ms}),
    ).await;
'''+b[end:]
 replace_body(name,b);paused(name)

cap_names=['a_handler_sees_the_interceptor_deadline_on_request','a_tls_handler_sees_the_interceptor_deadline_on_request','an_mtls_handler_sees_the_interceptor_deadline_on_request','a_unix_handler_sees_the_interceptor_deadline_on_request','a_from_io_handler_sees_the_interceptor_deadline_on_request']
for name in cap_names:
 _,_,b=body(name);b=connect_frozen(b)
 if 'unix' in name:
  pos=b.index('    assert_handler_');b=b[:pos]+'    await_fixture_unix_listener(&path).await;\n'+b[pos:]
 a=b.index('    assert_handler_sees_interceptor_deadline(');end=b.index('.await;',a)+len('.await;');expr=b[a:end].strip();assert expr.endswith('.await;');expr=expr[:-len('.await;')]
 b=b[:a]+'    drive_frozen_fixture(\n        '+expr+',\n        "four interceptor-cap calls",\n    ).await;'+b[end:]
 replace_body(name,b);paused(name)

# Reuse the same real inner-handler poll witness for all logical boundaries.
a=s.index('    let previous_polls = probe.polled.load(Ordering::Relaxed);',s.index('async fn assert_controlled_server_timeout(')) if 'async fn assert_controlled_server_timeout(' in s else s.index('    let previous_polls = probe.polled.load(Ordering::Relaxed);',s.index('async fn assert_controlled_server_timeout<'))
b=s.index('    .await;',a)+len('    .await;')
witness=s[a:b].replace('"handler poll before the server deadline"','"handler poll before configured deadline"')
s=s[:a]+'    await_fixture_repoll(probe, expected).await;'+s[b:]
helper='''async fn await_fixture_repoll(probe: &FixtureHandlerProbe, expected: usize) {
'''+witness+'''
}

#[cfg(unix)]
async fn await_fixture_unix_listener(path: &std::path::Path) {
    drive_frozen_fixture(
        std::future::poll_fn(|_| {
            if path.exists() {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        "Unix listener readiness",
    ).await;
}

'''
pos=s.index('async fn await_fixture_drop(');s=s[:pos]+helper+s[pos:]

_,_,old=body('assert_paused_deadline_dropped_spawned')
new='''async fn assert_paused_deadline_dropped_spawned<T>(
    mut call: Call<T>,
    probe: &FixtureHandlerProbe,
    started: &AtomicUsize,
    finished: &AtomicUsize,
    child_done: &AtomicUsize,
    deadline: Duration,
) {
    started.store(0, Ordering::Relaxed);
    finished.store(0, Ordering::Relaxed);
    child_done.store(0, Ordering::Relaxed);
    let expected = probe.admitted.load(Ordering::Relaxed) + 1;
    await_fixture_admission(std::pin::Pin::new(&mut call), probe, expected).await;
    assert!(started.load(Ordering::Relaxed) >= 1, "handler and child must be admitted");
    tokio::time::advance(deadline - Duration::from_millis(1)).await;
    await_fixture_repoll(probe, expected).await;
    assert_eq!(probe.dropped.load(Ordering::Relaxed), expected - 1,
        "handler dropped before configured deadline");
    assert_eq!(finished.load(Ordering::Relaxed), 0, "handler completed before deadline");
    assert_fixture_pending(std::pin::Pin::new(&mut call)).await;
    tokio::time::advance(Duration::from_millis(2)).await;
    let err = drive_frozen_fixture(call, "controlled handler deadline")
        .await.err().expect("expected deadline");
    assert_eq!(err.code(), Code::DeadlineExceeded, "{}", err.message());
    drive_frozen_fixture(
        std::future::poll_fn(|_| {
            if child_done.load(Ordering::Relaxed) >= 1 {
                std::task::Poll::Ready(())
            } else {
                std::task::Poll::Pending
            }
        }),
        "deadline cancellation of spawned child",
    ).await;
    await_fixture_drop(probe, expected).await;
    assert_eq!(finished.load(Ordering::Relaxed), 0, "handler completed instead of dropping");
}'''
replace_body('assert_paused_deadline_dropped_spawned',new)
_,_,old=body('assert_deadline_on_every_shape')
new='''async fn assert_controlled_deadline_on_every_shape(
    client: &GreeterClient,
    probe: &FixtureHandlerProbe,
    started: &AtomicUsize,
    finished: &AtomicUsize,
    child_done: &AtomicUsize,
    deadline: Duration,
) {
    assert_paused_deadline_dropped_spawned(
        client.say_hello(Request::new(req("ada"))), probe,
        started, finished, child_done, deadline,
    ).await;
    assert_paused_deadline_dropped_spawned(
        client.server_hello(Request::new(req("ada"))), probe,
        started, finished, child_done, deadline,
    ).await;
    let (tx, call) = client.client_hello(Request::new(()));
    assert_paused_deadline_dropped_spawned(
        call, probe, started, finished, child_done, deadline,
    ).await;
    drop(tx);
    let (tx, call) = client.stream_hello(Request::new(()));
    assert_paused_deadline_dropped_spawned(
        call, probe, started, finished, child_done, deadline,
    ).await;
    drop(tx);
}'''
replace_body('assert_deadline_on_every_shape',new)
assert s.count('assert_deadline_on_every_shape(')==0
(q/'architecture-c9-repaired-serving-draft.rs').write_text(s)
print('Prepared fixture-only draft; root shipping source unchanged.')
