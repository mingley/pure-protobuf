from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,shutil
base=Path('/workspace/pure-protobuf/work');root=base.parent;q=base/'qualification';pin='14d28e76641078a01a89d9e5dde084f5c8fcd86d'
state_path=q/'architecture-c6-preworkspace-state.json'
state={'status':'starting exclusive clean C6 pre-workspace phase','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pin':pin,'completed':[]}
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def source():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)}
save();assert source()=={'head':pin,'status':''}
rust=[str(base/'run-rust'),'cargo','+stable'];common=os.environ.copy();common.update(CARGO_TARGET_DIR=str(base/'stable-target'),CARGO_BUILD_JOBS='1')
checks=[
 ('architecture-c6-format',rust+['fmt','--all','--','--check'],{},300),
 ('architecture-c6-clippy-grpc-alltargets',rust+['clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'],{},1200),
 ('architecture-c6-examples',rust+['build','--locked','--workspace','--examples'],{},1200),
 ('architecture-c6-rpc-benchmark-correctness',rust+['test','--locked','--manifest-path','rpc-bench/Cargo.toml','--bin','rpc-bench','--test','worker','--test','fairness','--test','tonic_fairness'],{},1800),
 ('architecture-c6-tonic-benchmark-correctness',[str(base/'run-rust'),'env','PURE_PROTOBUF_CHECKED_V4=1','cargo','+stable','test','--locked','--manifest-path','tonic-bench/Cargo.toml','--bin','tonic-bench'],{'PURE_PROTOBUF_CHECKED_V4':'1'},1800),
 ('architecture-c6-rustdoc',rust+['doc','--locked','--workspace','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'},1200),
]
for name,command,extra,timeout in checks:
 assert source()=={'head':pin,'status':''}
 assert not (q/f'{name}.json').exists(),name
 assert shutil.disk_usage('/workspace').free>=2*1024**3,'disk below 2 GiB floor'
 state['status']='running '+name;save();print(state['status'],flush=True)
 env=common.copy();env.update(extra)
 result=subprocess.run([sys.executable,str(base/'record.py'),str(q/name),str(timeout),*command],cwd=root,env=env)
 end=source();state['completed'].append({'name':name,'exit_code':result.returncode,'source_at_completion':end,'extra_environment':extra});save()
 if result.returncode or end!={'head':pin,'status':''}:
  state['status']='stopped on first failure; stable-target released';state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(state['status'],flush=True);sys.exit(result.returncode or 2)
state['status']='all pre-workspace checks passed; stable-target released';state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(state['status'],flush=True)
