//! Replay the raw fault which failed the six-cd resource day.
mod common;
use common::lifecycle::{CallShape, FaultKind, LifecycleBoundary, LifecycleRunner, LifecycleScenario, RstReason, TransportKind};
#[tokio::main(flavor="multi_thread", worker_threads=2)]
async fn main() {
    let count: u64 = std::env::args().nth(1).expect("bounded count").parse().unwrap();
    assert!((1..=2000).contains(&count));
    for iteration in 0..count {
        println!("replay_iteration={iteration} seed=20261588");
        LifecycleRunner::run_scenario(LifecycleScenario {
            shape: CallShape::Bidi, transport: TransportKind::Tcp,
            boundary: LifecycleBoundary::BodyStarted,
            fault: FaultKind::RstStream(RstReason::Cancel), seed:20261588,
        }).await;
    }
    println!("completed={count}");
}
