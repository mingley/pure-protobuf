#!/usr/bin/env python3
from pathlib import Path
import os,resource,sys
count=int(sys.argv[1]);assert 1<=count<=2000
resource.setrlimit(resource.RLIMIT_AS,(1024*1024*1024,)*2)
resource.setrlimit(resource.RLIMIT_NOFILE,(128,128))
resource.setrlimit(resource.RLIMIT_NPROC,(4096,4096))
resource.setrlimit(resource.RLIMIT_CPU,(120,120))
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
binary=Path(__file__).resolve().parent/'replay'
os.execv(binary,[str(binary),str(count)])
