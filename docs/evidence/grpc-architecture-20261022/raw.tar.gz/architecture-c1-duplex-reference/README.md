# Independent full-duplex reference

Tonic 0.14.6 / prost passes all four real-wire ordering checks over a registry h2 peer:

| Case | Result before upload credit | Request/recovery witness |
| --- | --- | --- |
| Bidirectional initial headers and first reply | Pass | After credit, all 1,048,585 framed request bytes and END_STREAM; final OK; successful unary on the same connection |
| Client-stream complete reply and OK | Pass | Result returned while upload remained blocked; credit then allowed the upload to finish; successful unary recovery |
| Bidirectional response transport error | Pass | Error returned without upload credit; request reset; successful unary recovery |
| Client-stream response transport error | Pass | Error returned without upload credit; request reset; successful unary recovery |

The peer advertises a zero stream window. A server PING/ACK barrier completes before the client starts its first RPC. SETTINGS is the server's first frame, so this establishes that the client processed the zero-window setting. The peer additionally checks its request body has no DATA ready before sending the response. Request/response handles remain alive. No RPC timeout is configured; each operation has the same external two-second test guard. This is an API/protocol ordering reference, not a latency or throughput benchmark.

`manifest.json` records the exact source-attested release build, peer crate versions and paths, compiler commands, harness/executable hashes, and all recorded release rlib/rmeta hashes before and after execution. All input artifact hashes remained unchanged. `tonic-run.stdout` and `.stderr` preserve the result and request counts.

`attempt-1/` preserves a rejected harness attempt that started the RPC before confirming the peer SETTINGS had arrived. Its zero-DATA assertion failed because the client could use the initial HTTP/2 window. The corrected probe adds the explicit PING barrier and does not classify that startup race as a library defect. Tonic exposes grpc-status in trailing metadata, so the corrected assertion checks its actual value rather than expecting empty trailers.

These checks establish the contract: bidirectional response progress is independent of upload progress; a complete client-streaming response may finish while its upload is blocked. They do not require an implementation to finish an unnecessary upload after receiving terminal response trailers.
