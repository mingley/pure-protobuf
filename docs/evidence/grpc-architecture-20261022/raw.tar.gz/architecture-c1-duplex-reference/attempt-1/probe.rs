//! Independent Tonic/prost full-duplex ordering reference over registry h2.
use bytes::Bytes;
use prost::Message;
use std::future::poll_fn;
use std::task::Poll;
use std::time::Duration;
use tonic::Request;
const GUARD: Duration = Duration::from_secs(2);
#[derive(Clone, PartialEq, Message)]
struct Msg { #[prost(bytes="vec", tag="1")] data: Vec<u8> }
#[derive(Clone, Copy, Debug)]
enum Mode { Bidi, EarlyOk, TransportError }
fn frame(text: &str) -> Bytes {
    let body=Msg{data:text.as_bytes().to_vec()}.encode_to_vec();
    let mut bytes=vec![0];bytes.extend_from_slice(&(body.len() as u32).to_be_bytes());bytes.extend_from_slice(&body);Bytes::from(bytes)
}
fn trailers() -> http::HeaderMap {
    let mut map=http::HeaderMap::new();map.insert("grpc-status",http::HeaderValue::from_static("0"));map
}
async fn read_request(body: &mut h2::RecvStream) -> (usize,bool) {
    let mut received=0;
    while let Some(data)=body.data().await {
        match data {
            Ok(data)=>{received+=data.len();body.flow_control().release_capacity(data.len()).unwrap();}
            Err(_)=>return(received,false),
        }
    }
    (received,true)
}
async fn reference(mode: Mode,bidi: bool) {
    let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address=listener.local_addr().unwrap();
    let (credit,allow_credit)=tokio::sync::oneshot::channel();
    let (uploaded,upload)=tokio::sync::oneshot::channel();
    let peer=tokio::spawn(async move {
        let(socket,_)=listener.accept().await.unwrap();
        let mut builder=h2::server::Builder::new();builder.initial_window_size(0);
        let mut connection=builder.handshake::<_,Bytes>(socket).await.unwrap();
        let(request,mut respond)=connection.accept().await.unwrap().unwrap();
        let mut body=request.into_body();
        poll_fn(|cx|{assert!(body.poll_data(cx).is_pending(),"zero stream window must hold upload");Poll::Ready(())}).await;
        let mut send=if matches!(mode,Mode::TransportError) {
            respond.send_reset(h2::Reason::INTERNAL_ERROR);None
        } else {
            let mut send=respond.send_response(http::Response::builder().header("content-type","application/grpc").header("x-initial","observed").body(()).unwrap(),false).unwrap();
            send.send_data(frame(if matches!(mode,Mode::Bidi){"first"}else{"early"}),false).unwrap();
            if matches!(mode,Mode::EarlyOk){send.send_trailers(trailers()).unwrap();}
            Some(send)
        };
        tokio::select! {
            biased;
            result=allow_credit=>result.unwrap(),
            result=connection.accept()=>panic!("unexpected stream before upload credit: {result:?}"),
        }
        connection.set_initial_window_size(2*1024*1024).unwrap();
        let result={
            let read=read_request(&mut body);tokio::pin!(read);
            tokio::select! {
                result=&mut read=>result,
                result=connection.accept()=>panic!("unexpected stream during upload: {result:?}"),
            }
        };
        if matches!(mode,Mode::Bidi) {
            assert!(result.1,"bidi upload must finish independently");
            assert_eq!(result.0,1024*1024+9);
            send.as_mut().unwrap().send_trailers(trailers()).unwrap();
        }
        uploaded.send(result).unwrap();
        let(request,mut respond)=connection.accept().await.unwrap().unwrap();
        let mut recovery_body=request.into_body();
        let read=read_request(&mut recovery_body);tokio::pin!(read);
        let read=tokio::select! {result=&mut read=>result,result=connection.accept()=>panic!("unexpected recovery stream: {result:?}")};
        assert!(read.1);
        let mut recovery=respond.send_response(http::Response::builder().header("content-type","application/grpc").body(()).unwrap(),false).unwrap();
        recovery.send_data(frame("recovered"),false).unwrap();recovery.send_trailers(trailers()).unwrap();
        while let Some(request)=connection.accept().await {request.unwrap();}
        drop((body,send,recovery));
    });
    let channel=tonic::transport::Endpoint::from_shared(format!("http://{address}")).unwrap().connect().await.unwrap();
    let mut grpc=tonic::client::Grpc::new(channel);
    grpc.ready().await.unwrap();
    let request=Request::new(tokio_stream::iter(vec![Msg{data:vec![b'x';1024*1024]}]));
    let path=http::uri::PathAndQuery::from_static("/test/Upload");
    if bidi {
        let result=tokio::time::timeout(GUARD,grpc.streaming(request,path,tonic_prost::ProstCodec::<Msg,Msg>::default())).await.expect("bidi headers must not wait for upload credit");
        if matches!(mode,Mode::TransportError){assert!(result.is_err());}
        else {
            let mut response=result.unwrap();assert_eq!(response.metadata().get("x-initial").unwrap(),"observed");
            assert_eq!(tokio::time::timeout(GUARD,response.get_mut().message()).await.unwrap().unwrap().unwrap().data,b"first");
            credit.send(()).unwrap();
            let received=tokio::time::timeout(GUARD,upload).await.unwrap().unwrap();assert_eq!(received,(1024*1024+9,true));
            assert!(tokio::time::timeout(GUARD,response.get_mut().message()).await.unwrap().unwrap().is_none());
            let trailers=response.get_mut().trailers().await.unwrap().unwrap();assert!(trailers.is_empty());
            grpc.ready().await.unwrap();let reply=tokio::time::timeout(GUARD,grpc.unary(Request::new(Msg{data:vec![1]}),http::uri::PathAndQuery::from_static("/test/Recovery"),tonic_prost::ProstCodec::<Msg,Msg>::default())).await.unwrap().unwrap();assert_eq!(reply.into_inner().data,b"recovered");
            println!("reference mode={mode:?} bidi={bidi} headers_before_credit=true first_reply_before_credit=true full_upload={} recovery=true",received.0);
            peer.abort();return;
        }
    } else {
        let result=tokio::time::timeout(GUARD,grpc.client_streaming(request,path,tonic_prost::ProstCodec::<Msg,Msg>::default())).await.expect("complete response must not wait for upload credit");
        if matches!(mode,Mode::TransportError){assert!(result.is_err());}
        else {assert_eq!(result.unwrap().into_inner().data,b"early");}
    }
    credit.send(()).unwrap();let received=tokio::time::timeout(GUARD,upload).await.unwrap().unwrap();
    grpc.ready().await.unwrap();let reply=tokio::time::timeout(GUARD,grpc.unary(Request::new(Msg{data:vec![1]}),http::uri::PathAndQuery::from_static("/test/Recovery"),tonic_prost::ProstCodec::<Msg,Msg>::default())).await.unwrap().unwrap();assert_eq!(reply.into_inner().data,b"recovered");
    println!("reference mode={mode:?} bidi={bidi} result_before_credit=true upload_after_terminal={received:?} recovery=true");
    peer.abort();
}
#[tokio::test] async fn tonic_bidi_returns_headers_and_message_before_upload_credit(){reference(Mode::Bidi,true).await;}
#[tokio::test] async fn tonic_client_stream_returns_complete_ok_before_upload_credit(){reference(Mode::EarlyOk,false).await;}
#[tokio::test] async fn tonic_client_stream_returns_terminal_transport_error_without_credit(){reference(Mode::TransportError,false).await;}
#[tokio::test] async fn tonic_bidi_returns_terminal_transport_error_without_credit(){reference(Mode::TransportError,true).await;}
