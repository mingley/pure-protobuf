# C8 documentation integration plan

Working proposal only. Do not copy pending results into shipping documentation.
Runtime and corrected benchmark source: `9d6fb9c416fc32732450fd78d32ee16ff8b802de`.
Style cleanup `4d66bfff` is already separate. No build or check was run for this plan.

## Benchmark page: about 90–100 lines

Lead with the strongest current measured finding and largest remaining loss,
once verified. State plainly that production readiness and the broad comparison
remain open. Do not lead with the old 6cd allocation table.

Use these sections, in this order:

1. **Current results.** Two sentences naming source, workload scope and limits.
2. **Largest remaining costs.** Three to five rows, sorted by important measured
   losses. Columns: side, workload/payload, metric, native, tonic/prost, difference.
   Use allocations/RPC or KiB/RPC with one decimal; keep metrics separate.
3. **Measured improvements.** Four to eight selected matched source-paired rows.
   Columns: side, workload/codec, before, current, change. Identify exactly which
   metric applies. Include relevant regressions in the same source-paired scope.
4. **What was measured.** About six lines plus raw-evidence link. Name selected
   versus expanded coverage, repetitions, offered/completed calls and failures.
   Explicitly separate a completed selected campaign from a pending expanded one.
5. **Run it.** A compact reproducible command and links to pinned build/campaign
   records and the benchmark contract. Avoid duplicating the full contract.
6. **Still open.** Qualified CPU/latency/throughput/retention, broader important
   cases and actual day-long result; update only from completed records.

Table values must come from final summaries, not this proposal. If no captures
have completed, report “captures pending” and link the historical record rather
than presenting historical counts as current evidence.

Keep these scope details in a compact paragraph:

- Gzip level 6 on both stacks; zero-filled payload bytes, not encoded message size.
- Four messages per streaming direction where the captured workload specifies it.
- Corrected equal server send buffers: 400 KiB; request queues: 16.
- Shipping defaults unchanged. Native accounting and channelz stay enabled.
- Equal prost handlers compare API costs; pbrs interop handlers add application work.
- Cumulative requested allocation bytes do not measure retained memory or RSS.
- Raw process context switches are collected; they do not by themselves qualify
  scheduling. Allocation counts do not establish a CPU or latency win.

Retain historical settings in two lines, with a raw-record link: old full matrices
used unequal native/tonic send buffers and bidi queue depths. They cannot serve
as a matched runtime-only Before column for the corrected harness. The corrected
expanded current matrix and selected matched A/B scopes have different coverage.

## Status and scoreboard replacement capsule

The current source is `9d6fb9c4`. Cancellation ownership now survives transport
task abortion and connection-age cleanup. Waiter registrations release their
slots on drop in O(1), with storage bounded by peak live registrations. The RPC
guard adds no reference-count clone or allocation. These are mechanism changes;
their broader efficiency still needs measurement.

All 11 detecting controls fail against the former mechanisms and pass against
the repaired source: eight TCP abort/age cases across four RPC shapes and three
waiter churn/reentrancy cases. The source also passes 689 library tests with one
existing ignore and five normal producer-lifetime checks. Ten exact clean-source
pre-workspace checks pass, including formatting, strict Clippy, strict rustdoc,
193 benchmark tests and Rust 1.85 default/Rust 1.87 optional-Zstd checks. The fresh
release build passes and is source verified; it is not a performance capture.

Fresh sanitizer and full-workspace qualification remain pending. A 22-case
offline resource-driver control passes; no actual C8 preview or day-long run
has started. No current benchmark figures or performance ranking are established.

Keep the following history in the capsule, with a short link from current pages:

- C3 `783bcd53`: workspace failed, 3,739 passes/five failures/nine ignores across
  139 targets; outer recorder interrupted, full logs and kernel Cargo exit 101
  establish the failure. Do not replace its sanitizer scope with C8 scope.
- C7: workspace intentionally superseded after about 25 seconds of compilation,
  exit -15 and zero tests. It is neither a workspace pass nor a test failure.
- C8 development: two test lint failures were preserved before corrected strict
  checks passed. Do not report the final pass as the only observed attempt.
- Earlier actual day-long attempts failed; no source has a full recorded day pass.

## TODO priorities after final results

1. Finish exact C8 sanitizer/workspace and required release checks; preserve
   intermediate failures and distinguish corrected fixtures from runtime fixes.
2. Run selected worst-cost captures, then the expanded current matrix; retain
   every measured loss and failed/partial capture. Promote a win only for its scope.
3. Complete actual C8 resource preview and a new full day at the original limits.
4. Experiment with one checked owned merge for singular nested fields. Keep
   existing representation/API and compare sparse/read-all inputs; repeated Query
   children already parse eagerly. Preserve parse-time rejection, recursion,
   duplicate merge, oneof, unknown fields and independent prost equality.
5. Compare inline scheduling with one owned Tokio task per finitely admitted RPC.
   Measure same-connection expensive/cheap traffic and small-call handoff cost;
   preserve drop-abort/reset/deadline/backpressure/drain. Idle streams must not
   occupy CPU-worker threads. Decoder-only offload needs its own finite queue,
   workers, owned buffer permits and cancellation checks.
6. Keep remaining discovery/balancer, credential, codec, platform, packaged
   consumer, full matrix and dedicated-host qualification cards visible.

## Other owned pages

- **Execution decision:** add owning-guard teardown and waiter slot-lifetime
  invariants at C8; identify independent positive/negative control scope. Retain
  earlier pins where they describe actual runs rather than silently repinning.
- **Compression decision:** identify the current source and its exact validation
  when available; keep complete-input policy, 1,024-frame work cap, separate Zstd
  history/output limits and historical backend rationale. Do not transfer an older
  sanitizer/full-workspace result to C8.
- **Resource budgets:** document guard-owned cancellation and bounded waiter
  storage; keep permits until actual ownership ends. Preserve finite resource
  math/profiles and reset/deadline/drain rules. Offline driver controls are not
  a resource preview, and a short preview is not a day-long result.

Root owns the evidence capsule README, results, raw files and archive manifest.
Only link a future terminal soak capsule after its actual terminal record exists.
