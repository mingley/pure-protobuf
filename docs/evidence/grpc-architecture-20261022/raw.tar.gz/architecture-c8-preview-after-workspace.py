from pathlib import Path
import datetime,json,subprocess,time
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';p=q/'architecture-c8-workspace-final-state.json';journal=q/'architecture-c8-preview-queue-state.json'
def save(state,**extra):journal.write_text(json.dumps({'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),**extra},indent=2)+'\n')
save('waiting_for_final_workspace')
while True:
 d=json.loads(p.read_text())
 if 'passed' in d:
  if not d['passed']:save('workspace_failed_no_preview');raise SystemExit(1)
  break
 time.sleep(2)
assert d['cargo_exit_code']==0 and d['source_after']==d['source_before']
save('launching_preview',workspace_totals=d['totals'])
c=subprocess.run(['python3',str(q/'architecture-c8-resource-preview-supervisor.py'),'--launch'],cwd=r)
save('preview_launched'if c.returncode==0 else'preview_launch_failed',launch_exit=c.returncode)
raise SystemExit(c.returncode)
