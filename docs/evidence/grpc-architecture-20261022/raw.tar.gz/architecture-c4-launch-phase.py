#!/usr/bin/env python3
"""Detach a reviewed, recorded capture phase only after root's quiet grant."""
import argparse,datetime,hashlib,json,os,subprocess
from pathlib import Path
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--phase',required=True,choices=['native_expanded','selected_native_ab','instruction_pilot','oversized_pilot','oversized_full','cpu_focused72','cpu_with_unary108','cpu_with_pipeline144','cpu_fallback24','cpu_fallback32'])
parser.add_argument('--quiet-grant',required=True,help='root quiet-grant message identifier, recorded verbatim')
parser.add_argument('--supervisor-seconds',type=int,help='reduce the planned overall bound; required remaining CPU budget for expanded CPU phases')
args=parser.parse_args();plan_path=q/'architecture-c4-measurement-plan.json';plan=json.loads(plan_path.read_text())
if args.phase.startswith('oversized_'):
 plan_path=q/'architecture-c4-oversized-final-plan.json';row=json.loads(plan_path.read_text())['phases'][args.phase.removeprefix('oversized_')]
elif args.phase.startswith('cpu_'):
 plan_path=q/'architecture-c4-instruction-expansion-plan.json';row=json.loads(plan_path.read_text())['options'][args.phase.removeprefix('cpu_')]
 if args.supervisor_seconds is None:parser.error('expanded CPU phase requires its remaining aggregate budget')
else:row=plan[args.phase]
limit=row['supervisor_seconds'] if args.supervisor_seconds is None else args.supervisor_seconds
if not 1<=limit<=row['supervisor_seconds']:parser.error('supervisor must not exceed the reviewed phase bound')
preflight=json.loads((q/'architecture-c4-build-preflight.json').read_text())
if preflight['state']!='both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED':parser.error('completed source/build preflight is required')
prefix=q/('architecture-c4-'+args.phase.replace('_','-')+'-run');launch=prefix.with_name(prefix.name+'-launch.json')
for path in [launch,*[prefix.with_suffix(suffix) for suffix in ['.json','.stdout','.stderr']]]:
 if path.exists():parser.error('refusing to overwrite retained phase evidence: '+str(path))
argv=['python3',str(root/'work/record.py'),str(prefix),str(limit),*row['argv']]
with prefix.with_name(prefix.name+'-wrapper.stdout').open('xb') as stdout,prefix.with_name(prefix.name+'-wrapper.stderr').open('xb') as stderr:
 process=subprocess.Popen(argv,cwd=root/'work/architecture-c4',stdin=subprocess.DEVNULL,stdout=stdout,stderr=stderr,start_new_session=True,env=dict(os.environ,RUSTUP_TOOLCHAIN='stable'))
stat=Path(f'/proc/{process.pid}/stat').read_text().rsplit(')',1)[1].split()
record=dict(pid=process.pid,proc_start_ticks=int(stat[19]),detached=True,quiet_grant=args.quiet_grant,phase=args.phase,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),cwd=str(root/'work/architecture-c4'),command=argv,supervisor_seconds=limit,plan=str(plan_path),plan_sha256=digest(plan_path),launcher_sha256=digest(Path(__file__)),record_supervisor_sha256=digest(root/'work/record.py'),preflight_sha256=digest(q/'architecture-c4-build-preflight.json'),expected_captures=row['expected_captures'],expected_actual_rpc_calls=row['expected_actual_rpc_calls'])
with launch.open('x') as target:json.dump(record,target,indent=2);target.write('\n')
print(json.dumps(record,indent=2))
