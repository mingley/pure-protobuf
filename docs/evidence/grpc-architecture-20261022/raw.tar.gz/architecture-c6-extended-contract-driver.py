from pathlib import Path
import subprocess,os,json
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';env=os.environ.copy();env['RUSTUP_TOOLCHAIN']='stable';steps=[('plan-lint',['python3','scripts/plan-lint.py']),('codegen-harness',['python3','-B','-m','unittest','discover','-s','bench/codegen','-p','test_run.py','-q']),('edition2024-oracle',['python3','-B','-m','unittest','discover','-s','tests/fixtures/edition2024','-p','test_reference.py','-q']),('checked-v4-oracle',['python3','-B','-m','unittest','discover','-s','tonic-bench','-p','test_checked_v4.py','-q'])];results=[]
for name,command in steps:
 prefix=q/('architecture-c6-'+name)
 assert not prefix.with_suffix('.json').exists()
 completed=subprocess.run(['python3',str(r/'work/record.py'),str(prefix),'180',*command],cwd=r,env=env);results.append({'name':name,'exit_code':completed.returncode,'record':str(prefix.with_suffix('.json'))})
(q/'architecture-c6-extended-contract-results.json').write_text(json.dumps({'scope':'existing CI harness and checked-oracle contracts; no performance captures','results':results},indent=2)+'\n')
