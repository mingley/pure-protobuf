# Spawned bidi upload panic containment

Pinned source: `a3b1d4cced143de481d461c725d0ebda4ffcef26`.

A bounded standalone Rust test links the exact debug dependency fingerprints used by the clean C2 focused gate. A public custom `CodecMessage` panics in `encode_payload` while its producer remains open, forcing the existing live bidi upload task. The independent registry h2 peer receives the request headers and retains both request and response handles. It sends no response or reset and has no peer timer. The panic witness executes, but the client Call remains pending until its external two-second guard expires. No RPC timeout is configured.

`run.stdout` reports `codec_panicked=true request_headers_received=true result=Err(Elapsed(()))`; `run.stderr` preserves the actual upload-task panic stack and the failed termination assertion. `manifest.json` records compiler/run commands, exact input hashes, Cargo fingerprints, source-qualification record hash, and harness/executable hashes. Input library hashes remained unchanged. `compile-attempt-1/` retains a corrected fixture-only generic handshake compile error.

This is a cleanup defect under an application codec panic with unwinding enabled. The test deliberately violates normal codec behavior; it does not show a valid peer can trigger a panic in generated codecs, and it does not establish a gRPC wire-spec violation. Tokio contains the task panic, so it does not necessarily stop the process. The affected call can retain its RPC admission slot until cancellation/drop/deadline because no task now owns request termination. Panic-abort builds have different process-level behavior.

The mechanism predates C2: original902 `run_bidi_live` also moves a bare send stream into its spawned task and treats closed `fail_rx` as merely disabling that arm. C2's closed encoded remainder shares this lifecycle, but encoding that remainder occurs on the Call task, before spawning; the demonstrated application-codec panic therefore exercises the preexisting live-producer path.

The minimal next-source fix is an armed `ResetSend` captured by the upload task before the task is spawned. Its destructor resets an unfinished stream during panic, cancellation, or destruction before first poll. Existing normal terminal branches must explicitly disarm it after their current reset/clean-half-close handling, preserving clean completion without a new reset. This proposal is not implemented here and is not included in C2 qualification.
