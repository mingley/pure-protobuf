//! Functional panic containment witness: application codec in spawned upload.
use bytes::Bytes;
use pbrs_grpc::{Channel, CodecMessage, HelloReply, Request, Status};
use std::sync::{Arc, atomic::{AtomicBool, Ordering}};
use std::time::Duration;
struct PanicMessage(Arc<AtomicBool>);
impl CodecMessage for PanicMessage {
    fn encoded_len(&self) -> usize { 1 }
    fn encode_payload<W: pbrs::WireOut>(&self, _out: &mut W) -> Result<(), Status> {
        self.0.store(true, Ordering::SeqCst);
        panic!("deliberate application codec panic in spawned upload");
    }
    fn decode_payload(_payload: Bytes) -> Result<Self, Status> { Err(Status::internal("not a response codec")) }
    fn empty() -> Self { Self(Arc::new(AtomicBool::new(false))) }
}
#[tokio::test]
async fn spawned_upload_codec_panic_must_not_leave_call_pending() {
    let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address=listener.local_addr().unwrap();
    let (accepted,request_accepted)=tokio::sync::oneshot::channel();
    let peer=tokio::spawn(async move {
        let(socket,_)=listener.accept().await.unwrap();
        let mut connection=h2::server::handshake(socket).await.unwrap();
        let(request,respond)=connection.accept().await.unwrap().unwrap();
        accepted.send(()).unwrap();
        // Deliberately retain both handles: no peer response, reset, timeout,
        // or dropped handle supplies termination that the client must own.
        while let Some(next)=connection.accept().await {next.unwrap();}
        drop((request,respond));
    });
    let channel=Channel::connect(address).await.unwrap();
    let panicked=Arc::new(AtomicBool::new(false));
    let(sender,call)=channel.bidi::<PanicMessage,HelloReply>("/test/Panic",Request::new(()));
    sender.send(PanicMessage(panicked.clone())).await.unwrap();
    // Keep producer alive so the codec runs in the independent live pump.
    let result=tokio::time::timeout(Duration::from_secs(2),call).await;
    assert!(panicked.load(Ordering::SeqCst),"codec panic witness did not execute");
    tokio::time::timeout(Duration::from_secs(2),request_accepted).await.unwrap().unwrap();
    println!("codec_panicked=true request_headers_received=true result={result:?}");
    assert!(result.is_ok(),"spawned codec panic left the no-deadline Call pending");
    assert!(result.unwrap().is_err(),"codec panic must not become a successful response");
    drop(sender);peer.abort();
}
