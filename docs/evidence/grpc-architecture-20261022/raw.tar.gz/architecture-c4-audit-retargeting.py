from pathlib import Path
import ast,datetime,hashlib,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';pins=json.loads((q/'architecture-c4-source-pins.json').read_text())
expected={'--baseline-checkout':str(root/'work/architecture-b4'),'--baseline-binary':str(q/'architecture-b4-rpc-build/rpc-bench'),'--baseline-build-record':str(q/'architecture-b4-rpc-build/build.json'),'--baseline-commit':pins['baseline_benchmark'],'--candidate-checkout':str(root/'work/architecture-c4'),'--candidate-binary':str(q/'architecture-c4-rpc-build/rpc-bench'),'--candidate-build-record':str(q/'architecture-c4-rpc-build/build.json'),'--candidate-commit':pins['candidate_benchmark'],'--source-checkout':str(root/'work/architecture-c4')}
checked=[]
def walk(value,path):
 if isinstance(value,dict):
  for key,item in value.items():
   if key in ('argv','argv_template') and isinstance(item,list):
    assert all(isinstance(v,str) for v in item)
    for arg in item:
     assert 'validation-fixes' not in arg and 'architecture-c1-baseline' not in arg,(path,key,arg)
     assert not any('/architecture-'+old+'/' in arg or 'architecture-'+old+'-rpc-build' in arg for old in ['c1','c2','c3']),(path,key,arg)
    for flag,exp in expected.items():
     if flag in item:assert item[item.index(flag)+1]==exp,(path,key,flag,item)
    if '--baseline-checkout' in item:
     for flag in ['--baseline-checkout','--baseline-binary','--baseline-build-record','--baseline-commit','--candidate-checkout','--candidate-binary','--candidate-build-record','--candidate-commit']:assert flag in item
    checked.append(dict(location=str(path)+'.'+key,argv=item))
   walk(item,str(path)+'.'+key)
 elif isinstance(value,list):
  for i,item in enumerate(value):walk(item,str(path)+f'[{i}]')
plans=sorted(q.glob('architecture-c4*plan*.json'))
for path in plans:
 raw=path.read_text();assert 'validation-fixes' not in raw,path
 walk(json.loads(raw),path)
driver=q/'architecture-c4-counter-ab-driver.py';tree=ast.parse(driver.read_text());default=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='BASELINE_COMMIT' for t in n.targets));assert default==pins['baseline_benchmark']
controllers=['architecture-c4-counter-ab-driver.py','architecture-c4-build-preflight.py','architecture-c4-launch-phase.py','architecture-c4-ab-summary.py','architecture-c4-counter-summary.py','architecture-c4-native-ab-summary.py','architecture-c4-legacy-summary.py']
for name in controllers:assert 'validation-fixes' not in (q/name).read_text(),name
# Every profiler/fallback command is checked through the real parser's plan-only branch.
executed=[]
master=json.loads((q/'architecture-c4-measurement-plan.json').read_text())
commands=[master[name]['argv'] for name in ['selected_native_ab','instruction_pilot']]
commands += [row['argv'] for row in json.loads((q/'architecture-c4-oversized-final-plan.json').read_text())['phases'].values()]
commands += [row['argv'] for row in json.loads((q/'architecture-c4-instruction-expansion-plan.json').read_text())['options'].values()]
for argv in commands:
 r=subprocess.run(argv+['--plan'],text=True,capture_output=True,check=True);executed.append(dict(argv=argv+['--plan'],offline_plan=json.loads(r.stdout)))
record=dict(state='PASS_ALL_LIVE_C4_ARGV_AND_CONTROLLER_SOURCE_PINS_AUDITED',qualified=False,no_capture_executed=True,recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),expected=expected,plan_files=[str(p) for p in plans],checked_argv_count=len(checked),checked_argv=checked,offline_parser_checks=executed,controller_hashes={name:hashlib.sha256((q/name).read_bytes()).hexdigest() for name in controllers},baseline_default=default,notes=['The preparation transformer necessarily mentions old paths as replacement inputs; those are not live capture argv.','Runtime source6cd remains intentionally recorded separately from benchmark B4source2eba.','B4 outer-wrapper interruption audit is retained separately; unchanged inner build verifier requires successful actual build source/logs/binary.'])
(q/'architecture-c4-retarget-audit.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({key:record[key] for key in ['state','no_capture_executed','checked_argv_count','baseline_default']},indent=2))
