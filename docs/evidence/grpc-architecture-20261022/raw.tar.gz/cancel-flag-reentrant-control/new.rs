#![allow(dead_code, unused_imports)]
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool,AtomicU8,AtomicUsize,Ordering};
use std::sync::{Arc,Mutex};
use std::task::{Context,Poll,Wake,Waker};
pub(crate) struct CancelFlag {
    /// Cancellation and waiter registration share one modification order.
    state: AtomicU8,
    #[allow(
        clippy::disallowed_types,
        reason = "short waker-registry sections; no await under lock and wakers run after unlocking"
    )]
    waiters: Mutex<Vec<Waker>>,
}

impl CancelFlag {
    const CANCELLED: u8 = 1;
    const ARMED: u8 = 2;

    pub(crate) fn new() -> Arc<Self> {
        if let Some(flag) = take_spare_cancel() {
            // The slot may still be marked cancelled from the call that
            // finished. The next call has not been cancelled.
            flag.state.store(0, Ordering::Release);
            return flag;
        }
        #[allow(
            clippy::disallowed_types,
            reason = "short waker-registry sections; no await under lock and wakers run after unlocking"
        )]
        let waiters = Mutex::new(Vec::new());
        Arc::new(Self {
            state: AtomicU8::new(0),
            waiters,
        })
    }

    pub(crate) fn is_cancelled(&self) -> bool {
        self.state.load(Ordering::Acquire) & Self::CANCELLED != 0
    }

    pub(crate) fn signal(&self) {
        // Either registration observes CANCELLED, or this operation observes
        // ARMED and wakes it. Separate release/acquire flags could both miss.
        if self.state.fetch_or(Self::CANCELLED, Ordering::AcqRel) & Self::ARMED != 0 {
            self.wake_waiters();
        }
    }

    #[cold]
    #[inline(never)]
    fn wake_waiters(&self) {
        let waiters = match self.waiters.lock() {
            Ok(mut waiters) => std::mem::take(&mut *waiters),
            Err(poisoned) => std::mem::take(&mut *poisoned.into_inner()),
        };
        for waiter in waiters {
            waiter.wake();
        }
    }
}

/// Resolves when `flag` is signalled. `None` never resolves.
pub(crate) fn wait_cancel(flag: Option<Arc<CancelFlag>>) -> WaitCancel {
    WaitCancel { flag, slot: None }
}

/// [`wait_cancel`]'s state.
pub(crate) struct WaitCancel {
    flag: Option<Arc<CancelFlag>>,
    slot: Option<usize>,
}

impl Future for WaitCancel {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
        let this = self.get_mut();
        let Some(flag) = this.flag.as_ref() else {
            return Poll::Pending;
        };
        if flag.is_cancelled() {
            return Poll::Ready(());
        }
        let needs_update = this.slot.is_none_or(|index| {
            let waiters = match flag.waiters.lock() {
                Ok(waiters) => waiters,
                Err(poisoned) => poisoned.into_inner(),
            };
            waiters
                .get(index)
                .is_none_or(|waiter| !waiter.will_wake(cx.waker()))
        });
        if needs_update {
            // RawWaker clone/drop callbacks may reenter signal. Neither runs
            // under the registry lock; an unchanged waker needs no clone.
            let replacement = cx.waker().clone();
            let previous = {
                let mut waiters = match flag.waiters.lock() {
                    Ok(waiters) => waiters,
                    Err(poisoned) => poisoned.into_inner(),
                };
                if let Some(waiter) = this.slot.and_then(|index| waiters.get_mut(index)) {
                    Some(std::mem::replace(waiter, replacement))
                } else {
                    this.slot = Some(waiters.len());
                    waiters.push(replacement);
                    None
                }
            };
            drop(previous);
        }
        if flag.state.fetch_or(CancelFlag::ARMED, Ordering::AcqRel) & CancelFlag::CANCELLED != 0 {
            // A signal that preceded ARMED could not drain this registration.
            // Release its waker too, including any references back to the flag.
            flag.wake_waiters();
            Poll::Ready(())
        } else {
            Poll::Pending
        }
    }
}


pub(crate) struct CancelOnDrop(Option<Arc<CancelFlag>>);

impl CancelOnDrop {
    pub(crate) fn new(flag: Arc<CancelFlag>) -> Self {
        Self(Some(flag))
    }
}

impl Drop for CancelOnDrop {
    fn drop(&mut self) {
        let Some(flag) = self.0.take() else {
            return;
        };
        // Other clones (the handler request, an in-flight reset waiter) still
        // need the signal. The last owner is the usual end of a call that
        // nobody waited on: keep the allocation for the next call.
        if Arc::strong_count(&flag) == 1 {
            if flag.state.load(Ordering::Acquire) & CancelFlag::ARMED != 0 {
                flag.wake_waiters();
            }
            flag.state.store(0, Ordering::Release);
            stash_spare_cancel(flag);
            return;
        }
        flag.signal();
    }
}

thread_local! {
    static SPARE_CANCEL: std::cell::Cell<Option<Arc<CancelFlag>>> = const { std::cell::Cell::new(None) };
}

fn take_spare_cancel() -> Option<Arc<CancelFlag>> {
    SPARE_CANCEL.try_with(std::cell::Cell::take).ok().flatten()
}

fn stash_spare_cancel(flag: Arc<CancelFlag>) {
    // Thread shutdown drops the slot; the flag is freed with the closure.
    let _thread_shutdown = SPARE_CANCEL.try_with(|cell| cell.set(Some(flag)));
}


#[cfg(test)]
mod tests {
 use super::*;
    #[derive(Default)]
    struct WakeCount(AtomicUsize);

    impl Wake for WakeCount {
        fn wake(self: Arc<Self>) {
            self.wake_by_ref();
        }

        fn wake_by_ref(self: &Arc<Self>) {
            self.0.fetch_add(1, Ordering::Relaxed);
        }
    }

    #[test]
    fn replacing_a_waker_allows_its_drop_to_signal_cancellation() {
        struct SignalOnDrop {
            flag: Arc<CancelFlag>,
            dropped: Arc<AtomicUsize>,
        }

        impl Wake for SignalOnDrop {
            fn wake(self: Arc<Self>) {}
        }

        impl Drop for SignalOnDrop {
            fn drop(&mut self) {
                self.dropped.fetch_add(1, Ordering::Relaxed);
                self.flag.signal();
            }
        }

        let (done_tx, done_rx) = std::sync::mpsc::channel();
        let worker = std::thread::spawn(move || {
            let flag = CancelFlag::new();
            let dropped = Arc::new(AtomicUsize::new(0));
            let previous = Waker::from(Arc::new(SignalOnDrop {
                flag: Arc::clone(&flag),
                dropped: Arc::clone(&dropped),
            }));
            let mut waiting = wait_cancel(Some(Arc::clone(&flag)));
            assert!(
                Pin::new(&mut waiting)
                    .poll(&mut Context::from_waker(&previous))
                    .is_pending()
            );
            // Leave the registry as the last owner, so replacement runs Drop.
            drop(previous);
            let count = Arc::new(WakeCount::default());
            let replacement = Waker::from(Arc::clone(&count));
            assert!(
                Pin::new(&mut waiting)
                    .poll(&mut Context::from_waker(&replacement))
                    .is_ready()
            );
            assert_eq!(dropped.load(Ordering::Relaxed), 1);
            assert_eq!(count.0.load(Ordering::Relaxed), 1);
            assert!(flag.is_cancelled());
            done_tx.send(()).expect("test observer remains alive");
        });
        // A reentrant lock deadlock fails this test without hanging libtest.
        done_rx
            .recv_timeout(std::time::Duration::from_secs(2))
            .expect("waker replacement deadlocked while signaling cancellation");
        worker.join().expect("waker replacement worker panicked");
    }


}
