"""Read-only retained-evidence audit; writes a new review, never runs endpoints."""
import collections
import datetime
import gzip
import hashlib
import json
import subprocess
from pathlib import Path

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'

def load(path):
    return json.loads(Path(path).read_text())

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

S = load(Q / 'architecture-c9-capture-supervisor-state.json')
assert S['state'] == 'FINISHED' and S['qualified'] is False
errors, inputs, summary_checks = [], [], []
for path, expected in S['inputs_sha256'].items():
    observed = sha(path)
    inputs.append(dict(path=path, expected_sha256=expected, observed_sha256=observed, match=observed == expected))
    if observed != expected:
        errors.append('Input hash mismatch: ' + path)
summaries = {}
for name, row in S['summaries'].items():
    value = load(row['path'])
    summaries[name] = value
    observed = sha(row['path'])
    summary_checks.append(dict(name=name, path=row['path'], sha256=observed, match=observed == row['sha256']))
    if observed != row['sha256'] or value.get('passed') is not True or value.get('qualified') is not False:
        errors.append('Invalid summary: ' + name)
legacy = S['legacy_summary']
if sha(legacy['path']) != legacy['sha256']:
    errors.append('Legacy summary hash mismatch')
ACCOUNT = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs', 'failed_rpcs',
           'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']
phase_reviews, raw_manifest, profiles = [], [], []
totals = collections.Counter()
by_source = collections.defaultdict(collections.Counter)
envs = collections.Counter()
builds = {}
for version, folder in [('baseline', 'architecture-b4-rpc-build'), ('candidate', 'architecture-c8-rpc-build')]:
    build = load(Q / folder / 'build.json')
    assert build['exit_code'] == 0
    for filename, expected in build['files'].items():
        if sha(Q / folder / filename) != expected:
            errors.append('Build log hash mismatch: ' + version + '/' + filename)
    if sha(Q / folder / 'rpc-bench') != build['binary_sha256']:
        errors.append('Binary hash mismatch: ' + version)
    builds[version] = build
for name, phase in S['phases'].items():
    problems = []
    for key in ['launch', 'terminal', 'campaign']:
        if sha(phase[key]) != phase[key + '_sha256']:
            problems.append(key + ' hash mismatch')
    launch, terminal, campaign = (load(phase[key]) for key in ['launch', 'terminal', 'campaign'])
    directory = Path(phase['campaign']).parent
    if phase['state'] != 'PASSED' or terminal['exit_code'] != 0 or campaign.get('passed') is not True or campaign['state'] != 'finished':
        problems.append('Phase did not pass')
    if name == 'native_expanded':
        captures = [dict(version='candidate', path=str(path.relative_to(directory)))
                    for path in sorted(directory.glob('group-*/n-*/cell-*/run.json'))]
        if campaign['source'] != S['candidate'] or campaign['binary_sha256'] != builds['candidate']['binary_sha256']:
            problems.append('Native campaign source/binary mismatch')
        controller = ROOT / 'work/architecture-c8/scripts/grpc-counter-campaign.py'
    else:
        captures = campaign['captures']
        controller = Q / 'architecture-c8-counter-ab-driver.py'
        for version in ['baseline', 'candidate']:
            source = campaign['versions'][version]
            if (source['source'] != builds[version]['source']
                    or source['binary_sha256'] != builds[version]['binary_sha256']
                    or source['build_record'] != builds[version]):
                problems.append('Campaign source/build mismatch: ' + version)
    if campaign['controller_sha256'] != sha(controller):
        problems.append('Campaign controller hash mismatch')
    listed = {str(Path(capture['path'])) for capture in captures}
    found = {str(path.relative_to(directory)) for path in directory.rglob('run.json')}
    if listed != found:
        problems.append('Raw manifest has missing or extra run.json')
    if len(captures) != campaign['expected_captures']:
        problems.append('Capture count mismatch')
    accounting = collections.Counter()
    version_accounting = collections.defaultdict(collections.Counter)
    availability = collections.defaultdict(collections.Counter)
    for capture in captures:
        path = directory / capture['path']
        run = load(path)
        metrics, version, commands = run.get('metrics', {}), capture['version'], run['commands']
        client, server = commands['client'], commands['server']
        if run.get('passed') is not True or run.get('client_exit_code') != 0:
            problems.append('Raw run failed: ' + str(path))
        count = int(next(arg.split('=', 1)[1] for arg in client if arg.startswith('--rpc-count=')))
        binary = str(Q / ('architecture-c8-rpc-build' if version == 'candidate' else 'architecture-b4-rpc-build') / 'rpc-bench')
        if binary not in client or binary not in server:
            problems.append('Wrong endpoint binary: ' + str(path))
        if (any(metrics.get(key) != count for key in ACCOUNT[:4])
                or any(metrics.get(key) != 0 for key in ACCOUNT[4:]) or metrics.get('status_errors')):
            problems.append('Raw actual RPC accounting mismatch: ' + str(path))
        report = Path(next(arg.split('=', 1)[1] for arg in client if arg.startswith('--output=')))
        if load(report) != metrics:
            problems.append('Client report/run metrics mismatch: ' + str(path))
        for key in ACCOUNT:
            accounting[key] += metrics[key]
            version_accounting[version][key] += metrics[key]
            totals[key] += metrics[key]
            by_source[version][key] += metrics[key]
        envs[json.dumps(run['environment'], sort_keys=True)] += 1
        for side in ['client', 'server']:
            for metric, section in [('allocations', 'allocation_totals'), ('requested_bytes', 'allocation_totals'),
                                    ('context_switches', 'context_switch_totals'), ('instructions', 'instruction_totals'),
                                    ('syscalls', 'syscall_totals'), ('task_wakeups', 'task_wakeup_totals')]:
                value = run.get(section, {}).get(side)
                if value is not None and (metric not in ['allocations', 'requested_bytes'] or metric in value):
                    availability[side][metric] += 1
            if campaign['phase'] == 'callgrind':
                profile = path.parent / (side + '.callgrind.gz')
                if not profile.exists():
                    problems.append('Missing raw profile: ' + str(profile))
                    continue
                fields = {}
                with gzip.open(profile, 'rt') as stream:
                    for line in stream:
                        if line.startswith(('events:', 'summary:', 'totals:', 'cmd:')):
                            key, value = line.split(':', 1)
                            fields[key] = value.strip()
                if (fields.get('events') != 'Ir'
                        or int(fields['summary']) != run['instruction_totals'][side]
                        or int(fields['totals']) != run['instruction_totals'][side]):
                    problems.append('Raw Callgrind counter mismatch: ' + str(profile))
                if binary not in fields.get('cmd', ''):
                    problems.append('Raw Callgrind binary mismatch: ' + str(profile))
                profiles.append(dict(path=str(profile), sha256=sha(profile), side=side, version=version,
                                     instructions=run['instruction_totals'][side]))
        raw_manifest.append(dict(phase=name, path=str(path), sha256=sha(path), client_report=str(report),
                                 client_report_sha256=sha(report), version=version,
                                 actual_completed_rpcs=metrics['completed_rpcs']))
    summary = summaries['native_all_counters' if name == 'native_expanded' else name]
    observed = dict(accounting) if name == 'native_expanded' else {key: dict(value) for key, value in version_accounting.items()}
    if observed != summary['actual_rpc_totals']:
        problems.append('Actual summary accounting mismatch')
    phase_reviews.append(dict(phase=name, captures=len(captures), actual_rpc_totals=dict(accounting),
                              per_source_actual_rpc_totals={key: dict(value) for key, value in version_accounting.items()},
                              both_endpoint_raw_counter_availability={key: dict(value) for key, value in availability.items()},
                              wall_seconds=phase['duration_seconds'], checks_passed=not problems, errors=problems))
    errors.extend(name + ': ' + problem for problem in problems)
qual = S['qualification_source']
changed = subprocess.check_output(['git', 'diff', '--name-only', qual['measured_source'], qual['qualification_source'], '--'], cwd=ROOT, text=True).splitlines()
diff = subprocess.check_output(['git', 'diff', '--binary', qual['measured_source'], qual['qualification_source'], '--'], cwd=ROOT)
if changed != qual['changed_paths'] or changed != ['pbrs-grpc/tests/serving.rs'] or hashlib.sha256(diff).hexdigest() != qual['diff_sha256']:
    errors.append('Fixture-only qualification diff mismatch')
for version, checkout in [('baseline', 'architecture-b4'), ('candidate', 'architecture-c8')]:
    head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT / 'work' / checkout, text=True).strip()
    status = subprocess.check_output(['git', 'status', '--porcelain'], cwd=ROOT / 'work' / checkout)
    if head != builds[version]['source']['commit'] or status:
        errors.append('Immutable source changed: ' + version)
full, selected, cpu, oversized = (summaries[key] for key in ['native_all_counters', 'selected_native_ab', 'cpu_focused72', 'oversized_full'])

def codec(row):
    return row['cell']['pair'][1 if row['side'] == 'client' else 3]

def canonical_source(summary, metrics):
    return [row for row in summary['source_ranges'] if row['native_side'] and codec(row) == 'prost' and row['metric'] in metrics]

def canonical_tonic(summary, metrics):
    return [row for row in summary['same_side_tonic_ranges'] if row['version'] == 'candidate' and codec(row) == 'prost' and row['metric'] in metrics]

major_losses = {}
for coding in ['prost', 'pbrs']:
    for metric in ['requested_bytes', 'allocations']:
        rows = [row for row in full['medians'] if row['codec'] == coding and row['metric'] == metric and row.get('ratio') is not None and row['ratio'] > 1]
        major_losses[coding + ':' + metric] = sorted(rows, key=lambda row: row['ratio'], reverse=True)[:8]
regressions = [row for row in selected['source_ranges'] if row['native_side'] and row['metric'] in ['allocations', 'requested_bytes'] and row.get('ratio_of_medians') and row['ratio_of_medians'] > 1.02]
flags = dict(build_commands={version: build['command'] for version, build in builds.items()},
             tools={version: build['tools'] for version, build in builds.items()},
             allocation_instrumentation_enabled=all('--features' in build['command'] and build['command'][build['command'].index('--features') + 1] == 'allocation-counts' for build in builds.values()),
             profile='release', observed_endpoint_environments=dict(envs), stream_messages_each_direction=4,
             selected_N_2N=[200, 400], expanded_N_2N=[200, 400], cpu_N_2N=[10, 20], oversized_N_2N=[25, 50],
             native_server_send_buffer_bytes=409600, tonic_server_send_buffer='Hyper1.11 default400KiB',
             request_producer_queue_messages=16, gzip_level=6, per_rpc_timeout='Unchanged benchmark default5seconds',
             cell_outer_timeout_seconds=60, production_observability='Native channelz included',
             no_new_builds_tests_or_captures_in_this_audit=True)
limits = [
    'All results remain qualified=false: shared-host separate-process diagnostics, not broad superiority or production qualification.',
    'Builds use --release --features allocation-counts. Callgrind instruction findings cover this diagnostic configuration, not shipping uninstrumented CPU, latency or throughput.',
    'Native matrix spans1KiB/64KiB synthetic zero-filled payloads; identity/gzip; h2c/TLS; one connection at1or16inflight; five RPC shapes; five implementation pairs;3repeats. Other payload distributions, network regimes and deployments remain uncovered.',
    'Matched source comparisons cover selected400/CPU/oversized only. FullB4expanded was NOT_RUN. Historical different-settings controls cannot serve as causal full-matrix Before.',
    'Selected400 uses4repeats in balancedABBA blocks; oversized120 uses2repeats in balancedABBA blocks. CPU72 uses3seeded randomized repeats, not balancedABBA.',
    'CPU72 covers only64KiBgzip server client_stream/bidi, h2c1:1, nativeProst/nativePbrs plus freshTonic controls. Native-client instructions, TLS, higher inflight, unary and pipeline CPU scopes remain NOT_RUN.',
    'CPU uses the existing2percent ledger band: Prost bidi0.984xTonic is a tie in all3repeats. Ratios of medians and medians of paired ratios remain separately labelled.',
    'Native matrix has rawgetrusage context switches for both endpoints; some N/2N deltas are nonpositive/unavailable. These noisy counts are not qualified scheduling wins/losses. Native instructions, syscalls and task wakes were not measured.',
    'Requested bytes count cumulative allocation/reallocation requests, not peak live memory, RSS or wire bytes. Allocation counts include reallocations.',
    'Pbrs handlers perform different application logic from Prost. Cross-codec figures cannot isolate codec cost. NativeProst versus TonicProst provides the closest handler-parity transport comparison.',
    'Oversized1MiB API cases use join!(send,call); producer completion beforeCall is not guaranteed or witnessed per capture. Independent-peer tests establish that mechanism. Zero-filled gzip1MiB payloads compress below send buffers and do not force encoded-tail fallback.',
    'Combined runtime changes are compared; these counters do not individually attribute causation. Source regressions and remaining Tonic losses remain visible.',
    'C9deb0 fixture checkpoint changes onlyserving.rs relative to measured9d. Qualification and measured binary source pins are separate. Failed C8 workspace history remains intact.',
    'This counter review does not establish the required24hour soak. Separate continuous-soak evidence and production gates remain necessary.'
]
review = dict(schema='pbrs.independent-final-measurement-review.v1', reviewed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
              state='PASS' if not errors else 'FAILED', qualified=False,
              source_pins=dict(baseline_benchmark=S['baseline'], baseline_runtime='6cd91911afce24cceee6df3f60a945453e5b04da', measured_candidate=S['candidate'], qualification=qual),
              source_build_binary_sha256={version: build['binary_sha256'] for version, build in builds.items()},
              read_only_audit_method='Hash41retained inputs, every phase journal/campaign and summary; parse all3000run.json plus retained client reports; compare actualRPCaccounting; parse/hash all152gzipped Callgrind profiles and verify Ir summary/totals; verify fixture-only git diff. No tests, builds or captures.',
              audit_controller_sha256=sha(__file__), controller_input_hash_checks=inputs, summary_hash_checks=summary_checks,
              legacy_summary_hash_match=sha(legacy['path']) == legacy['sha256'], phases=phase_reviews,
              total_captures=len(raw_manifest), actual_rpc_totals=dict(totals),
              actual_rpc_totals_per_source={key: dict(value) for key, value in by_source.items()},
              profiler=dict(profile_files=len(profiles), pilot_and_one_expansion_seconds=S['cpu_actual_wall_seconds'],
                            aggregate_budget_seconds=900, within_budget=S['cpu_actual_wall_seconds'] <= 900,
                            selected_expansion='focused72', other_options_not_run=S['cpu_selection']['not_run_options']),
              flags_and_configuration=flags,
              canonical_prost_selected_source_ranges=canonical_source(selected, ['allocations', 'requested_bytes']),
              canonical_prost_selected_vs_tonic=canonical_tonic(selected, ['allocations', 'requested_bytes']),
              canonical_prost_instruction_source_ranges=canonical_source(cpu, ['instructions']),
              canonical_prost_instruction_vs_tonic=canonical_tonic(cpu, ['instructions']),
              canonical_prost_oversized_vs_tonic=canonical_tonic(oversized, ['allocations', 'requested_bytes']),
              remaining_major_fullmatrix_losses=major_losses, selected_native_source_regressions_over2percent=regressions,
              all_counter_dispositions=dict(native_expanded=full['dispositions'], cpu_source=cpu['source_comparison_dispositions'],
                                            cpu_tonic=cpu['same_side_tonic_dispositions'], selected_source=selected['source_comparison_dispositions'],
                                            selected_tonic=selected['same_side_tonic_dispositions'], oversized_source=oversized['source_comparison_dispositions'],
                                            oversized_tonic=oversized['same_side_tonic_dispositions']),
              native_raw_counter_availability=full['raw_counter_availability'],
              native_differential_counter_availability=full['differential_counter_availability'],
              raw_run_and_report_hashes=raw_manifest, raw_profile_hashes=profiles, errors=errors, claims_scope_limits=limits)
assert review['total_captures'] == 3000
assert totals['completed_rpcs'] == totals['successful_rpcs'] == 845790
output = Q / 'architecture-c9-final-measurement-review.json'
with output.open('x') as out:
    json.dump(review, out, indent=2)
    out.write('\n')
print(json.dumps(dict(path=str(output), state=review['state'], qualified=False, total_captures=review['total_captures'],
                     actual_rpc_totals=review['actual_rpc_totals'], input_hashes=len(inputs), raw_profiles=len(profiles), errors=errors), indent=2))
