import hashlib,json,os,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/pure-protobuf')
checkout=root/'work/parker-controls-final'
out=root/'work/qualification/architecture-c1-parker-controls'
manifest=json.loads((out/'manifest.json').read_text())
source=manifest['source_commit']
paths=list(manifest['base_files_sha256'])
base={p:subprocess.check_output(['git','show',source+':'+p],cwd=checkout) for p in paths}
for p,b in base.items():
 assert hashlib.sha256(b).hexdigest()==manifest['base_files_sha256'][p]
summary={'source_commit':source,'classification':manifest['classification'],'controls':{},'started_utc':__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()}
env=dict(os.environ,RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(root/'work/stable-target'),CARGO_BUILD_JOBS='1')
def save():
 (out/'progress.json').write_text(json.dumps(summary,indent=2)+'\n')
def record(prefix,command,timeout=900):
 return subprocess.run([sys.executable,str(root/'work/record.py'),str(prefix),str(timeout),*command],cwd=checkout,env=env).returncode
try:
 assert subprocess.check_output(['git','status','--porcelain'],cwd=checkout)==b''
 for control,details in manifest['controls'].items():
  for p,b in base.items(): (checkout/p).write_bytes(b)
  for p in paths: (checkout/p).write_bytes((out/control/p).read_bytes())
  patch=subprocess.check_output(['git','diff','HEAD','--binary'],cwd=checkout)
  (out/(control+'.source.patch')).write_bytes(patch)
  row={'state':'building','diff_sha256':hashlib.sha256(patch).hexdigest(),'tests':[]};summary['controls'][control]=row;save()
  prefix=out/(control+'-build')
  code=record(prefix,[str(root/'work/run-rust'),'cargo','test','--locked','-p','pbrs-grpc','--all-features','--lib','--no-run','--message-format=json'])
  row['build_exit_code']=code;save()
  if code!=0: raise RuntimeError(control+' failed compilation, not a valid regression control')
  artifacts=[]
  for line in prefix.with_suffix('.stdout').read_text().splitlines():
   try: item=json.loads(line)
   except ValueError: continue
   if item.get('reason')=='compiler-artifact' and item.get('target',{}).get('name')=='pbrs_grpc' and item.get('executable'): artifacts.append(item)
  assert artifacts,'no test executable'
  binary=Path(artifacts[-1]['executable'])
  digest=hashlib.sha256()
  with binary.open('rb') as f:
   for chunk in iter(lambda:f.read(1024*1024),b''):digest.update(chunk)
  row['binary']={'path':str(binary),'sha256':digest.hexdigest(),'bytes':binary.stat().st_size};row['state']='running-tests';save()
  for index,filter in enumerate(details['test_filters'],1):
   prefix=out/(control+'-test-'+str(index))
   code=record(prefix,[str(binary),'--exact',filter,'--nocapture'],30)
   stdout=prefix.with_suffix('.stdout').read_text();stderr=prefix.with_suffix('.stderr').read_text()
   ran_one='running 1 test' in stdout and '0 passed; 1 failed;' in stdout
   result={'filter':filter,'exit_code':code,'ran_one_failed_test':ran_one,'expected_failure_observed':code==101 and ran_one}
   row['tests'].append(result);save()
   if not result['expected_failure_observed']:raise RuntimeError('negative control did not fail as expected: '+filter)
  row['state']='expected-failures-observed';save()
 summary['state']='complete'
except Exception as error:
 summary['state']='failed';summary['error']=repr(error)
finally:
 for p,b in base.items(): (checkout/p).write_bytes(b)
 summary['restored_clean']=subprocess.check_output(['git','status','--porcelain'],cwd=checkout)==b''
 summary['finished_utc']=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat()
 save();(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
sys.exit(0 if summary['state']=='complete' and summary['restored_clean'] else 1)
