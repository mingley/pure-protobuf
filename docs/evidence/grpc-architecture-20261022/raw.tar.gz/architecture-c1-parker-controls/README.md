# Scheduler and cancellation mechanism controls

Source: `902014588792c8eb9c5bd65c782704e099535259`.

Both isolated control variants compiled successfully. All three exact regression tests failed for the intended reason:

| Control | Test | Result |
|---|---|---|
| Full pending-future scans | Server with 4,096 parked handlers and unrelated connection wakes | Detected extra polls of idle handlers |
| Full pending-future scans | One ready job among 4,096 cancellation jobs | 8,192 total polls; expected 4,097 |
| First-live-runtime process-global owner | Shut down runtime A while cancelling runtime B's live HTTP/2 stream | Real-wire cancellation did not arrive; bounded wait expired |

These are explicit mechanism controls, **not untouched historical implementations**. The full-scan variant retains the current pinned ready-set storage to isolate polling selection. The global-runtime variant retains current selective polling to isolate ownership. Their failures establish that the regression tests detect those mechanisms; they do not measure an overall transport speed advantage.

`manifest.json` records the clean base and intended overlays. The `*.source.patch` files are the exact Git diffs used by the builds and tests; `record-integrity.json` verifies every recorded source commit and diff hash against them. Expanded controlled source, generated patches, command records, stdout/stderr, binary hashes and `results.json` are retained. ELF hashes identify each control build; the shared target's executable path was subsequently reused, so it is not an immutable copy of both executables.

The dedicated `work/parker-controls-final` worktree was restored clean to the pinned commit after execution. The main checkout and `work/architecture-c1` were not modified. The build slot was then released for the full workspace gate.
