# Living documentation wording review

Read-only search of root and crate READMEs plus current guides, decisions,
status, roadmap and benchmark documents. Excluded evidence capsules, archived
experiments and task-card inventories. No shipping files were changed.

No affirmative, unqualified “fastest in the world” claim remains in the searched
living prose. Remaining uses are explicit goals, acceptance rules or prohibitions.
The small edits below would make the language more descriptive.

| Location | Current wording | Proposed wording |
|---|---|---|
| `TODO.md:6–7` | “defines the route to leadership” | “defines the required comparisons and checks” |
| `TODO.md:92–99` | “Dominance program”; “beats … in every cell”; “flip the known losses” | Heading “Workload comparisons”; “Measure client and server CPU, allocations and wall time against tonic/prost across the defined matrix”; “address the recorded losses”. Keep the same task IDs and goal, without implying success. |
| `docs/scoreboard.md:3–5` | “comparative leadership” | “repeatable comparisons across the required workloads” |
| `docs/ROADMAP.md:3–8` | “leading … efficiency”; “route to leadership” | “lower client and server costs”; “required measurements and release checks” |
| `README.md:294`; `docs/documentation-map.md:59`; `TODO.md:96` | Link label “Dominance program” | “Workload comparison plan”. Keep existing paths. |
| `docs/decisions/borrowed-views.md:240–247` | Sparse handlers “strictly dominate” owned parsing; caching is “a footgun” | “Views may avoid allocation and copying for handlers that read a few fields. Confirm the benefit with equal validation and field access. Caching a small field can retain the entire input; copy it into independent storage when needed.” This is a proposal/tradeoff, not measured universal superiority. |
| `docs/decisions/upb-kernel.md:258`; `docs/decisions/borrowed-views.md:304`; `docs/decisions/pbrs-h2.md:487` | “pure Rust, no new C”; “pure-Rust audit”; “F7 pure-Rust graph” | Remove the parenthetical after `hashbrown`; use “dependency audit”; label F7 “Dependency graph”. Preserve all dependency restrictions and gate IDs. |
| `docs/edition-2024.md:15`; `docs/cacheable-rpc.md:18` | “Executive Summary & Architectural Scope”; “Executive Summary & Disposition Decision” | “Scope”; “Protocol decision”. Retain explicit old anchors if any external links depend on them. |

One additional wording fix needs a source check before editing:
`docs/resource-budgets.md:346` calls its rejection path an “Infallible
Zero-Allocation Invariant”. Its actual bullets specify no body buffering,
decoding or handler admission; they do not establish that header construction
and transport bookkeeping allocate nothing. Rename the label “Reject before
reading the request body” and retain the concrete rules, unless a separate
allocation control proves the stronger wording. This would avoid silently
turning an admission rule into an end-to-end allocation claim.

Keep the necessary distinctions:

- `CompressionLevel::Fastest` is an API variant, not marketing prose.
- `scripts/pure-rust-audit.sh` is a real filename; do not rename links casually.
- `SECURITY.md:51` states an active dependency policy. Its requirements need
  to remain explicit; removing repeated marketing language does not authorize
  changing allowed dependencies, build steps or licenses.
- The opening `upb-kernel.md` quote is historical rationale, not a new product
  claim. Preserve the quote and all immutable evidence.
- Benchmark-contract thresholds and exact safety invariants are technical
  requirements. Do not weaken them as a prose cleanup.

The pending C8 runtime and validation repin is separate from this wording list.
Do not publish new pass, performance or day-long claims from C7's superseded
compile-only workspace attempt.
