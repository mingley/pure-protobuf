# Architecture candidate measurements

Candidate: `902014588792c8eb9c5bd65c782704e099535259`.
Control: `6cd91911afce24cceee6df3f60a945453e5b04da`.

The candidate release build is frozen in `architecture-c1-rpc-build/`. The
control build is being reproduced in `architecture-c1-baseline-rpc-build/`.
Both use Rust/Cargo 1.99.1, the locked release build and allocation counters.
The source-specific build, capture and ledger scripts are byte-identical.

The original control build record embeds the original checkout's manifest
path. Its unchanged verifier cannot validate that record against a different
checkout path. The new control build solves this without rewriting a record
or relaxing validation. The old binary, build logs and captures remain intact.
A rebuilt binary may differ because of source paths; both source pins, build
commands, tool versions, logs and binary hashes are retained.

Planned captures, pending the coordinator's quiet-host grant:

| Run | Captures | Expected completed calls | Purpose |
| --- | ---: | ---: | --- |
| Candidate native matrix | 2,400 | 720,000 | Both sides; all five shapes, h2c/TLS, identity/gzip, 1/64 KiB, concurrency 1/16 |
| Selected native ABBA | 400 | 120,000 | Fresh control and candidate; small identity requests and large gzip streams |
| Instruction pilot | 4 | 60 | 64 KiB gzip client streaming, native/prost server; estimate profiler cost |

Expected call totals are plans. Final reports must sum actual retained client
accounting and validate every offered/dispatched/completed/successful count.
Four-message bidirectional streams exchange four messages in each direction.
All payloads are synthetic zero-filled bytes; gzip level 6 is matched.

The selected native controller runs balanced A/B/B/A blocks across source
versions, retaining every repeat and both N/2N counts. It uses the unchanged
capture harness and ledger. The instruction pilot uses N=10/20 and instruments
both endpoints. It has no tonic-server reference and is a small-N diagnostic.
A larger instruction campaign needs a separate decision after pilot runtime
and failures are reported. No deadlines or acceptance bands are changed.

All results remain `qualified=false`. Allocation counts include reallocations;
requested bytes are cumulative requests, not live or retained RSS. Native
context switches and process CPU ticks are coarse scheduling diagnostics.
Missing and nonpositive differences remain unavailable. Callgrind wall time is
not native latency or throughput. The pbrs interop handler does additional work
compared with the minimal prost handlers, so a cross-codec gap is not isolated
codec overhead. Source comparisons combine all architecture changes and do
not attribute a change to one helper.
