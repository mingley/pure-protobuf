from pathlib import Path
p=Path('pbrs-grpc/src/client/streaming.rs');s=Path('work/architecture-c1/pbrs-grpc/src/client/streaming.rs').read_text()
# Remove two closed-source state machines that tied response completion to send completion.
a=s.index('#[allow(\n    clippy::too_many_arguments,\n    reason = "response and send halves plus cancel, limits, deadline, and tap"\n)]\n/// Bidi upload is already half-closed')
b=s.index('enum ClosedUpload',a);s=s[:a]+s[b:]
a=s.index('/// Build the flushed pump inside this function');b=s.index('/// Build the live upload inside this function',a);s=s[:a]+s[b:]
a=s.index('#[allow(\n    clippy::too_many_arguments,\n    reason = "response half plus the unsent tail of a closed upload"');b=s.index('async fn run_bidi<',a);s=s[:a]+s[b:]
s=s.replace('return box_bidi_flushed(', 'return box_bidi_live(')
# Reuse the existing bidi upload ownership/lifetime machinery for encoded tails.
s=s.replace('fn box_bidi_rest<Resp>(', 'fn box_bidi_rest<Req, Resp>(')
a=s.index('fn box_bidi_rest<Req, Resp>');b=s.index('/// Build the live upload',a)
block=s[a:b].replace("    Resp: CodecMessage + Send + 'static,", "    Req: CodecMessage + Send + 'static,\n    Resp: CodecMessage + Send + 'static,")
block=block.replace('Box::pin(send_rest_and_await_bidi_headers(', 'Box::pin(run_bidi_live(').replace('        rest,\n', '        BidiUpload::<Req>::Encoded(rest),\n')
s=s[:a]+block+s[b:]
s=s.replace('box_bidi_rest(', 'box_bidi_rest::<Req, Resp>(')
a=s.index('fn box_bidi_live<');b=s.index('#[allow(',a)
block=s[a:b].replace('        rx,\n','        BidiUpload::Messages { rx, budget },\n').replace('        budget,\n','')
s=s[:a]+block+s[b:]
a=s.index('async fn run_bidi_live<');b=s.index('impl super::Channel',a)
block=s[a:b].replace('    rx: Streaming<Req>,','    upload: BidiUpload<Req>,').replace('    budget: ByteBudgetTracker,\n','')
old='''                let pump = pump_outbound_budget(
                    &mut send,
                    rx,
                    cancel_rx.clone(),
                    wire,
                    &budget,
                    tap,
                    socket,
                );'''
new='''                let pump = async {
                    match upload {
                        BidiUpload::Messages { rx, budget } => {
                            pump_outbound_budget(
                                &mut send, rx, cancel_rx.clone(), wire, &budget, tap, socket,
                            ).await
                        }
                        BidiUpload::Encoded(rest) => {
                            pump_encoded_rest(&mut send, rest, &cancel_rx, wire, tap.as_ref()).await
                        }
                    }
                };'''
assert old in block;block=block.replace(old,new)
s=s[:a]+'''/// Closed uploads that exceed the send buffer need the same independent
/// response and upload lifetimes as a live producer. Fully queued uploads
/// continue to use the smaller, task-free header wait.
enum BidiUpload<Req> {
    Messages { rx: Streaming<Req>, budget: ByteBudgetTracker },
    Encoded(Vec<Bytes>),
}

async fn pump_encoded_rest(
    send: &mut backend::SendStream,
    rest: Vec<Bytes>,
    cancel_rx: &crate::rpc_cancel::RpcCancel,
    wire: Wire,
    tap: Option<&CallLogger>,
) -> PumpEnd {
    let sending = async {
        for segment in rest {
            crate::wire::send::send_bytes(send, segment, false, wire.send_buffer).await?;
        }
        send.send_data(Bytes::new(), true).map_err(Status::from_h2_send)
    };
    let result = tokio::select! {
        biased;
        _ = cancel_rx.wait() => None,
        result = sending => Some(result),
    };
    match result {
        Some(Ok(())) => {
            if let Some(tap) = tap { tap.log_half_close(); }
            PumpEnd::HalfClosed
        }
        Some(Err(_)) => {
            send.send_reset(Reason::INTERNAL_ERROR);
            PumpEnd::Reset
        }
        None => {
            send.send_reset(Reason::CANCEL);
            PumpEnd::Reset
        }
    }
}

'''+block+s[b:]
# The single final client response is independent of upload completion, too.
a=s.index('/// Finish a closed upload that did not fit in the send buffer');b=s.index('fn note_client_stream_end',a)
s=s[:a]+'''/// Send a closed upload while reading its final unary response. A completed
/// response ends the RPC even when the peer stops accepting request bytes.
async fn send_client_rest<Resp: CodecMessage>(
    resp_fut: backend::ResponseFuture,
    send_stream: backend::SendStream,
    rest: Vec<Bytes>,
    cancel_rx: crate::rpc_cancel::RpcCancel,
    wire: Wire,
    tap: Option<CallLogger>,
    socket: Option<crate::channelz::SocketId>,
) -> Result<Response<Resp>, Status> {
    let mut send = ResetSend::new(send_stream);
    let mut send_done = false;
    let mut send_failed = false;
    let result = {
        let send_fut = async {
            for segment in rest {
                crate::wire::send::send_bytes(send.stream_mut(), segment, false, wire.send_buffer).await?;
            }
            send.stream_mut().send_data(Bytes::new(), true).map_err(Status::from_h2_send)?;
            if let Some(tap) = &tap { tap.log_half_close(); }
            Ok::<(), Status>(())
        };
        tokio::pin!(send_fut);
        let response_fut = async {
            let response = resp_fut.await.map_err(Status::from_h2_post_dispatch)?;
            finish_unary::<Resp>(response, wire.limits, wire.accept_gzip, tap.as_ref()).await
        };
        tokio::pin!(response_fut);
        loop {
            tokio::select! {
                biased;
                _ = cancel_rx.wait() => break Err(Status::cancelled()),
                result = &mut response_fut => break result,
                sent = &mut send_fut, if !send_done => {
                    send_done = true;
                    // Like the live upload pump, a wire send failure does not
                    // discard a response already queued by the peer.
                    send_failed = sent.is_err();
                }
            }
        }
    };
    if !send_done || send_failed || matches!(&result, Err(status) if status.code() == Code::Cancelled) {
        send.stream_mut().send_reset(Reason::CANCEL);
    }
    send.live = false;
    if let (Some(tap), Err(status)) = (&tap, &result) {
        if status.code() == Code::Cancelled { tap.log_cancel(); }
    }
    note_client_stream_end(socket, &result);
    result
}

'''+s[b:]
p.write_text(s)
