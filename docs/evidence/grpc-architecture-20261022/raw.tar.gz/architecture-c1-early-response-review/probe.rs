//! A terminal peer response must not wait for request flow-control credit.
#![allow(clippy::expect_used, clippy::unwrap_used, clippy::panic)]
use bytes::Bytes;
use pbrs_grpc::{Channel, Code, HelloReply, HelloRequest, Request};
use std::time::Duration;

async fn rejection(bidi: bool) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let peer = tokio::spawn(async move {
        let mut builder = h2::server::Builder::new();
        builder.initial_window_size(0);
        let (socket, _) = listener.accept().await.unwrap();
        let mut connection = builder.handshake::<_, Bytes>(socket).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        let send = respond.send_response(http::Response::builder()
            .header("content-type", "application/grpc")
            .header("grpc-status", "8")
            .header("grpc-message", "busy")
            .header("x-terminal", "rejected")
            .header("grpc-status-details-bin", "AQID")
            .body(()).unwrap(), true).unwrap();
        // No reset, request read, credit release, or peer-side timeout. Keep
        // every stream handle alive while driving delivery of the response.
        let held = (request, respond, send);
        while let Some(request) = connection.accept().await { request.unwrap(); }
        drop(held);
    });
    let channel = Channel::connect(address).await.unwrap().max_send_buffer_size(16 * 1024);
    let mut message = HelloRequest::new();
    message.set_name("x".repeat(1024 * 1024));
    // Intentionally no RPC timeout: a timeout selects another client-upload
    // implementation and would hide the closed-producer regression.
    let status = if bidi {
        let (sender, call) = channel.bidi::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
        sender.send(message).await.unwrap(); sender.close();
        tokio::time::timeout(Duration::from_secs(2), call).await
            .expect("terminal response waited for request upload credit").unwrap_err()
    } else {
        let (sender, call) = channel.client_streaming::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
        sender.send(message).await.unwrap(); sender.close();
        tokio::time::timeout(Duration::from_secs(2), call).await
            .expect("terminal response waited for request upload credit").unwrap_err()
    };
    assert_eq!(status.code(), Code::ResourceExhausted);
    assert_eq!(status.message(), "busy");
    assert_eq!(status.metadata().get("x-terminal"), Some("rejected"));
    assert_eq!(status.details(), &[1, 2, 3]);
    peer.abort();
}
#[tokio::test]
async fn closed_client_upload_returns_terminal_rejection_without_credit() { rejection(false).await; }
#[tokio::test]
async fn closed_bidi_upload_returns_terminal_rejection_without_credit() { rejection(true).await; }
