//! A terminal peer response must not wait for request flow-control credit.
#![allow(clippy::expect_used, clippy::unwrap_used, clippy::panic)]
use bytes::Bytes;
use pbrs_grpc::{ByteBudgetTracker, Channel, Code, HelloReply, HelloRequest, Request};
use std::time::Duration;

async fn rejection(bidi: bool, reset: bool) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let peer = tokio::spawn(async move {
        let mut builder = h2::server::Builder::new();
        builder.initial_window_size(0);
        let (socket, _) = listener.accept().await.unwrap();
        let mut connection = builder.handshake::<_, Bytes>(socket).await.unwrap();
        let mut held = Vec::new();
        for _ in 0..2 {
            let (request, mut respond) = connection.accept().await.unwrap().unwrap();
            let mut send = respond
                .send_response(
                    http::Response::builder()
                        .header("content-type", "application/grpc")
                        .header("grpc-status", "8")
                        .header("grpc-message", "busy")
                        .header("x-terminal", "rejected")
                        .header("grpc-status-details-bin", "AQID")
                        .body(())
                        .unwrap(),
                    true,
                )
                .unwrap();
            // The no-reset cases retain every handle without reading requests,
            // releasing credit, or imposing a peer-side timeout. The reset
            // cases independently check response precedence over NO_ERROR.
            if reset {
                send.send_reset(h2::Reason::NO_ERROR);
            }
            held.push((request, respond, send));
        }
        while let Some(request) = connection.accept().await {
            request.unwrap();
        }
        drop(held);
    });
    let budget = ByteBudgetTracker::with_limit(4 * 1024 * 1024);
    let channel = Channel::connect(address)
        .await
        .unwrap()
        .max_send_buffer_size(16 * 1024)
        .max_concurrent_rpcs(1)
        .with_byte_budget_tracker(budget.clone());
    // The second RPC proves admission is released after the early response.
    for _ in 0..2 {
        let mut message = HelloRequest::new();
        message.set_name("x".repeat(1024 * 1024));
        // Intentionally no RPC timeout: a timeout selects another client-upload
        // implementation and would hide the closed-producer regression.
        let status = if bidi {
            let (sender, call) =
                channel.bidi::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
            sender.send(message).await.unwrap();
            sender.close();
            tokio::time::timeout(Duration::from_secs(2), call)
                .await
                .expect("terminal response waited for request upload credit")
                .unwrap_err()
        } else {
            let (sender, call) = channel
                .client_streaming::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
            sender.send(message).await.unwrap();
            sender.close();
            tokio::time::timeout(Duration::from_secs(2), call)
                .await
                .expect("terminal response waited for request upload credit")
                .unwrap_err()
        };
        assert_eq!(status.code(), Code::ResourceExhausted);
        assert_eq!(status.message(), "busy");
        assert_eq!(status.metadata().get("x-terminal"), Some("rejected"));
        assert_eq!(status.details(), &[1, 2, 3]);
        assert_eq!(budget.allocated(), 0);
        assert_eq!(budget.active_byte_permit_tokens(), 0);
    }
    peer.abort();
}
#[tokio::test]
async fn closed_client_upload_returns_terminal_rejection_without_credit() {
    rejection(false, false).await;
}
#[tokio::test]
async fn closed_bidi_upload_returns_terminal_rejection_without_credit() {
    rejection(true, false).await;
}

#[tokio::test]
async fn closed_client_upload_retains_rejection_with_peer_no_error_reset() {
    rejection(false, true).await;
}
#[tokio::test]
async fn closed_bidi_upload_retains_rejection_with_peer_no_error_reset() {
    rejection(true, true).await;
}

async fn initial_headers_wait_for_upload(bidi: bool) {
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let address = listener.local_addr().unwrap();
    let (allow_upload, wait_for_upload) = tokio::sync::oneshot::channel();
    let peer = tokio::spawn(async move {
        let mut builder = h2::server::Builder::new();
        builder.initial_window_size(0);
        let (socket, _) = listener.accept().await.unwrap();
        let mut connection = builder.handshake::<_, Bytes>(socket).await.unwrap();
        let (request, mut respond) = connection.accept().await.unwrap().unwrap();
        let mut send = respond
            .send_response(
                http::Response::builder()
                    .header("content-type", "application/grpc")
                    .header("x-initial", "observed")
                    .body(())
                    .unwrap(),
                false,
            )
            .unwrap();
        // Drive the headers while the client proves that ordinary headers
        // cannot complete this closed upload. Credit comes only afterward.
        tokio::select! {
            result = connection.accept() => panic!("unexpected second request: {result:?}"),
            result = wait_for_upload => result.unwrap(),
        }
        connection.set_initial_window_size(2 * 1024 * 1024).unwrap();
        let read = async {
            let mut body = request.into_body();
            let mut received = 0;
            while let Some(data) = body.data().await {
                let data = data.unwrap();
                received += data.len();
                body.flow_control().release_capacity(data.len()).unwrap();
            }
            assert!(
                received > 1024 * 1024,
                "complete encoded request must arrive"
            );
            send.send_data(Bytes::from_static(b"\0\0\0\0\x0a\x0a\x08accepted"), false)
                .unwrap();
            let mut trailers = http::HeaderMap::new();
            trailers.insert("grpc-status", http::HeaderValue::from_static("0"));
            send.send_trailers(trailers).unwrap();
        };
        let drive = async {
            while let Some(request) = connection.accept().await {
                request.unwrap();
            }
        };
        tokio::join!(read, drive);
    });
    let channel = Channel::connect(address)
        .await
        .unwrap()
        .max_send_buffer_size(16 * 1024);
    let mut message = HelloRequest::new();
    message.set_name("x".repeat(1024 * 1024));
    let returned_headers = std::sync::atomic::AtomicBool::new(false);
    let result = async {
        if bidi {
            let (sender, call) =
                channel.bidi::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
            sender.send(message).await.unwrap();
            sender.close();
            let mut response = call.await.unwrap();
            returned_headers.store(true, std::sync::atomic::Ordering::SeqCst);
            assert_eq!(response.metadata().get("x-initial"), Some("observed"));
            assert_eq!(
                response
                    .get_mut()
                    .message()
                    .await
                    .unwrap()
                    .unwrap()
                    .message(),
                "accepted"
            );
            assert!(response.get_mut().message().await.unwrap().is_none());
        } else {
            let (sender, call) = channel
                .client_streaming::<HelloRequest, HelloReply>("/test/Upload", Request::new(()));
            sender.send(message).await.unwrap();
            sender.close();
            let response = call.await.unwrap();
            assert_eq!(response.metadata().get("x-initial"), Some("observed"));
            assert_eq!(response.get_ref().message(), "accepted");
        }
    };
    tokio::pin!(result);
    assert!(
        tokio::time::timeout(Duration::from_millis(80), &mut result)
            .await
            .is_err(),
        "ordinary headers completed before upload credit was granted"
    );
    assert!(
        !returned_headers.load(std::sync::atomic::Ordering::SeqCst),
        "bidi returned ordinary headers before finishing the closed upload"
    );
    allow_upload.send(()).unwrap();
    tokio::time::timeout(Duration::from_secs(2), result)
        .await
        .unwrap();
    peer.abort();
}
#[tokio::test]
async fn closed_client_upload_preserves_headers_and_completes_after_credit() {
    initial_headers_wait_for_upload(false).await;
}
#[tokio::test]
async fn closed_bidi_upload_preserves_headers_and_completes_after_credit() {
    initial_headers_wait_for_upload(true).await;
}
