from pathlib import Path
p=Path('pbrs-grpc/src/client/streaming.rs');s=p.read_text()
s=s.replace('prefer_peer_rejection_after_send, race, reject_attempt, send_request_frame,','prefer_peer_rejection_after_send, race, reject_attempt, response_commits, send_request_frame,')
# Change only the three closed-but-not-fully-sent upload helpers.
for name,end in [('run_bidi_flushed','enum ClosedUpload'),('send_client_rest','fn note_client_stream_end'),('send_rest_and_await_bidi_headers','async fn run_bidi')]:
 start=s.index('async fn '+name);stop=s.index(end,start+1);block=s[start:stop]
 block=block.replace('let mut send = ResetSend::new(send_stream);','let mut send = ResetSend::new(send_stream);\n    let mut peer_rejected = false;',1)
 a=block.index('        let response_fut = async {');b=block.index('        tokio::pin!(response_fut);',a)
 old=block[a:b]
 body=old.replace('        let response_fut = async {\n            let response = resp_fut.await.map_err(Status::from_h2_post_dispatch)?;', '''        let response_fut = async {
            let response = match resp_fut.await {
                Ok(response) => response,
                Err(error) => return (false, Err(Status::from_h2_post_dispatch(error))),
            };
            // Only a complete, non-OK gRPC response can end an incomplete
            // upload. Ordinary headers and success still wait for the send.
            let rejected = !response_commits(&response);
            let result =''')
 # The original finish expression ends without semicolon immediately before async close.
 body=body.rsplit('\n        };',1)[0]+';\n            (rejected, result)\n        };\n'
 block=block[:a]+body+block[b:]
 oldbranch='''                result = &mut response_fut, if headers.is_none() => {
                    headers = Some(result);
                }
'''
 newbranch='''                (rejected, result) = &mut response_fut, if headers.is_none() => {
                    peer_rejected = rejected;
                    headers = Some(result);
                    if rejected {
                        break'''+(' headers.take();' if name=='run_bidi_flushed' else ';')+'''
                    }
                }
'''
 assert oldbranch in block,name
 block=block.replace(oldbranch,newbranch,1)
 if name!='run_bidi_flushed':
  # Read queued terminal headers before an upload error. Cancellation/deadline
  # stay earlier; ordinary headers are retained and sending continues.
  a=block.index('                sent = &mut send_fut');b=block.index('                (rejected, result) = &mut response_fut',a);c=block.index('\n            }\n            if send_done',b)
  block=block[:a]+block[b:c]+block[a:b]+block[c:]
 block=block.replace('    if reset_after && send.live {','    if (reset_after || peer_rejected) && send.live {',1)
 s=s[:start]+block+s[stop:]
p.write_text(s)
