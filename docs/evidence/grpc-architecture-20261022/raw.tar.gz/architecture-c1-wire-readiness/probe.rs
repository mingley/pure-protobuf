//! Counts real idle-handler polls while an independent registry h2 peer drives TCP traffic.
use bytes::Bytes;
use native::{Empty, Request, Response, Rpc, Server, Service, Status};
use std::future::{Future, poll_fn};
use std::pin::Pin;
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering};
use std::task::{Context, Poll};
use std::time::Duration;
use tokio::sync::Notify;

const OP_TIMEOUT: Duration = Duration::from_secs(5);
const CASE_TIMEOUT: Duration = Duration::from_secs(30);
const ROUNDS: usize = 16;

#[derive(Default)]
struct State {
    started: AtomicUsize,
    dropped: AtomicUsize,
    polls: AtomicUsize,
    active_handlers: AtomicUsize,
    entered: Notify,
    destroyed: Notify,
}
struct Parked {
    state: Arc<State>,
    entered: bool,
}
impl Future for Parked {
    type Output = Result<Response<Empty>, Status>;
    fn poll(self: Pin<&mut Self>, _cx: &mut Context<'_>) -> Poll<Self::Output> {
        let this = self.get_mut();
        if !this.entered {
            this.entered = true;
            this.state.started.fetch_add(1, Ordering::Relaxed);
            this.state.entered.notify_one();
        }
        this.state.polls.fetch_add(1, Ordering::Relaxed);
        // This handler deliberately never wakes itself. HTTP/2 RST_STREAM is
        // observed by the native RPC wrapper, which must destroy this future.
        Poll::Pending
    }
}
impl Drop for Parked {
    fn drop(&mut self) {
        if self.entered {
            self.state.dropped.fetch_add(1, Ordering::Relaxed);
            self.state.destroyed.notify_one();
        }
    }
}
struct ProbeService(Arc<State>);
impl Service for ProbeService {
    const NAME: &'static str = "wire.Readiness";
    async fn call(&self, rpc: Rpc) {
        match rpc.method() {
            "Idle" => {
                let state = Arc::clone(&self.0);
                rpc.unary(move |_request: Request<Empty>| Parked { state, entered: false }).await;
            }
            "Active" => {
                let state = Arc::clone(&self.0);
                rpc.unary(move |_request: Request<Empty>| async move {
                    state.active_handlers.fetch_add(1, Ordering::Relaxed);
                    Ok::<_, Status>(Response::new(Empty::new()))
                }).await;
            }
            _ => rpc.unimplemented(),
        }
    }
}

async fn wait_count(counter: &AtomicUsize, notify: &Notify, target: usize, label: &str) {
    tokio::time::timeout(OP_TIMEOUT, async {
        loop {
            let notified = notify.notified();
            if counter.load(Ordering::Relaxed) == target { break; }
            notified.await;
        }
    }).await.unwrap_or_else(|_| panic!("{label} did not reach {target}"));
}

async fn open(
    sender: &mut h2::client::SendRequest<Bytes>,
    authority: &str,
    method: &str,
) -> (h2::client::ResponseFuture, h2::SendStream<Bytes>) {
    tokio::time::timeout(OP_TIMEOUT, poll_fn(|cx| sender.poll_ready(cx)))
        .await.expect("peer admission timeout").expect("peer admission");
    let request = http::Request::builder()
        .method("POST")
        .uri(format!("http://{authority}/wire.Readiness/{method}"))
        .header("content-type", "application/grpc")
        .header("te", "trailers")
        .body(()).expect("request");
    let (response, mut send) = sender.send_request(request, false).expect("open stream");
    send.send_data(Bytes::from_static(&[0, 0, 0, 0, 0]), true).expect("empty protobuf request");
    (response, send)
}

async fn unary(sender: &mut h2::client::SendRequest<Bytes>, authority: &str) {
    tokio::time::timeout(OP_TIMEOUT, async {
        let (response, _send) = open(sender, authority, "Active").await;
        let response = response.await.expect("active response");
        assert_eq!(response.status(), http::StatusCode::OK);
        assert_eq!(response.headers().get("content-type").expect("content-type"), "application/grpc");
        let mut body = response.into_body();
        let mut bytes = Vec::new();
        while let Some(data) = body.data().await {
            let data = data.expect("active DATA");
            body.flow_control().release_capacity(data.len()).expect("release receive window");
            bytes.extend_from_slice(&data);
        }
        assert_eq!(bytes, [0, 0, 0, 0, 0], "one complete empty protobuf response");
        let trailers = body.trailers().await.expect("active trailers").expect("grpc trailers");
        assert_eq!(trailers.get("grpc-status").expect("grpc-status"), "0");
    }).await.expect("complete unary timeout");
}

async fn ping(ping: &mut h2::PingPong) {
    tokio::time::timeout(OP_TIMEOUT, ping.ping(h2::Ping::opaque()))
        .await.expect("PING ACK timeout").expect("PING ACK");
}

async fn scenario(idles: usize) -> serde_json::Value {
    let state = Arc::new(State::default());
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.expect("listener");
    let address = listener.local_addr().expect("address");
    let (shutdown, stopped) = tokio::sync::oneshot::channel();
    let native = Server::new(ProbeService(Arc::clone(&state)))
        .max_concurrent_streams(512)
        .max_concurrent_rpcs(idles + 8);
    let server = tokio::spawn(native.serve_with_shutdown(listener, async { stopped.await.ok(); }));
    let socket = tokio::net::TcpStream::connect(address).await.expect("TCP connect");
    socket.set_nodelay(true).expect("TCP_NODELAY");
    let mut builder = h2::client::Builder::new();
    builder.initial_max_send_streams(512);
    let (mut sender, mut connection) = tokio::time::timeout(OP_TIMEOUT, builder.handshake(socket))
        .await.expect("handshake timeout").expect("registry h2 handshake");
    let mut keepalive = connection.ping_pong().expect("PING handle");
    let driver = tokio::spawn(connection);
    let authority = address.to_string();
    let mut parked = Vec::new();
    for _ in 0..idles { parked.push(open(&mut sender, &authority, "Idle").await); }
    wait_count(&state.started, &state.entered, idles, "handler entry").await;
    ping(&mut keepalive).await;
    assert_eq!(state.dropped.load(Ordering::Relaxed), 0, "idle handlers must remain alive");
    let before = state.polls.load(Ordering::Relaxed);
    let mut previous = before;
    let mut ping_polls = 0usize;
    let mut active_polls = 0usize;
    let mut round_counts = Vec::new();
    for round in 0..ROUNDS {
        ping(&mut keepalive).await;
        let after_ping = state.polls.load(Ordering::Relaxed);
        unary(&mut sender, &authority).await;
        let after_rpc = state.polls.load(Ordering::Relaxed);
        let for_ping = after_ping - previous;
        let for_rpc = after_rpc - after_ping;
        ping_polls += for_ping;
        active_polls += for_rpc;
        round_counts.push(serde_json::json!({"round":round,"idle_polls_during_ping":for_ping,"idle_polls_during_active_unary":for_rpc}));
        previous = after_rpc;
    }
    assert_eq!(state.dropped.load(Ordering::Relaxed), 0, "traffic must not terminate idle handlers");
    let after = state.polls.load(Ordering::Relaxed);
    for (_, send) in &mut parked { send.send_reset(h2::Reason::CANCEL); }
    wait_count(&state.dropped, &state.destroyed, idles, "handler destruction after RST_STREAM").await;
    ping(&mut keepalive).await;
    unary(&mut sender, &authority).await;
    assert_eq!(state.active_handlers.load(Ordering::Relaxed), ROUNDS + 1);
    let destruction = state.dropped.load(Ordering::Relaxed);
    let active = state.active_handlers.load(Ordering::Relaxed);
    drop(parked);
    drop(sender);
    drop(keepalive);
    driver.abort();
    let _ = driver.await;
    shutdown.send(()).expect("shutdown");
    tokio::time::timeout(OP_TIMEOUT, server).await.expect("native shutdown timeout")
        .expect("native serve task").expect("native serve result");
    serde_json::json!({
        "idle_handlers":idles,"idle_started":idles,"idle_dropped_after_reset":destruction,
        "active_rpcs_completed":active,"active_rpcs_before_reset":ROUNDS,"recovery_rpc_completed":true,
        "warmup_pings":1,"measurement_pings_completed":ROUNDS,"recovery_pings_completed":1,
        "idle_polls_before_traffic":before,"idle_polls_after_traffic":after,
        "idle_polls_during_traffic":after-before,"idle_polls_during_pings":ping_polls,
        "idle_polls_during_active_unary":active_polls,"rounds":round_counts,
        "operation_timeout_seconds":OP_TIMEOUT.as_secs(),"scenario_timeout_seconds":CASE_TIMEOUT.as_secs(),
        "transport":"TCP loopback h2c","runtime":"Tokio current_thread","qualified":false
    })
}

fn main() {
    let mode = std::env::args().nth(1).expect("baseline or current");
    assert!(mode == "baseline" || mode == "current");
    let runtime = tokio::runtime::Builder::new_current_thread().enable_all().build().expect("runtime");
    for idles in [1, 64, 256] {
        let mut row = runtime.block_on(async { tokio::time::timeout(CASE_TIMEOUT, scenario(idles)).await })
            .expect("bounded scenario");
        row["mode"] = mode.clone().into();
        println!("{row}");
        let polls = row["idle_polls_during_traffic"].as_u64().expect("poll counter");
        if mode == "current" { assert_eq!(polls, 0, "unrelated traffic woke idle handler futures"); }
        else { assert!(polls > 0, "baseline must witness the former full scan"); }
    }
}
