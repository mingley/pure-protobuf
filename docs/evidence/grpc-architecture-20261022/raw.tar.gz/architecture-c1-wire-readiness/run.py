import hashlib,json,os,subprocess,time,datetime
from pathlib import Path
root=Path('/workspace/pure-protobuf');out=root/'work/qualification/architecture-c1-wire-readiness';deps=root/'work/rpc-target/release/deps';wrapper=root/'work/run-rust';source=out/'probe.rs'
def digest(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as stream:
  for chunk in iter(lambda:stream.read(1024*1024),b''):h.update(chunk)
 return h.hexdigest()
def snapshot(paths):return {str(p):{'sha256':digest(p),'bytes':p.stat().st_size} for p in sorted(paths)}
def execute(prefix,command,limit):
 t=time.monotonic();record={'command':command,'cwd':str(root),'timeout_seconds':limit,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 with (out/(prefix+'.stdout')).open('w') as stdout,(out/(prefix+'.stderr')).open('w') as stderr:
  p=subprocess.Popen(command,cwd=root,env=dict(os.environ,RUSTUP_TOOLCHAIN='stable'),stdout=stdout,stderr=stderr,start_new_session=True)
  try:code=p.wait(timeout=limit)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=5)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait()
   code=124;record['timeout']=True
 record.update(exit_code=code,duration_seconds=time.monotonic()-t);(out/(prefix+'.json')).write_text(json.dumps(record,indent=2)+'\n');return code
manifest={'harness_sha256':digest(source),'classification':'Source-attested release-rlib TCP wire readiness control; handler-poll counts only, not latency/performance qualification.','variants':{}}
for mode,builddir in [('baseline','architecture-c1-baseline-rpc-build'),('current','architecture-c1-rpc-build')]:
 build=root/'work/qualification'/builddir;record=json.loads((build/'build.json').read_text());log=build/'build.stdout.jsonl'
 assert record['exit_code']==0 and digest(log)==record['files']['build.stdout.jsonl']
 messages=[json.loads(line) for line in log.read_text().splitlines() if line.strip()]
 artifacts=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('profile',{}).get('opt_level')=='3']
 extern={}
 for name in ['pbrs_grpc','tokio','bytes','h2','http','serde_json']:
  matching=[m for m in artifacts if m.get('target',{}).get('name')==name]
  assert len(matching)==1,(name,len(matching))
  extern['native' if name=='pbrs_grpc' else name]=Path(next(f for f in matching[0]['filenames'] if f.endswith('.rlib')))
 libraries={Path(f) for m in artifacts for f in m.get('filenames',[]) if f.endswith(('.rlib','.rmeta'))}
 before=snapshot(libraries)
 binary=out/(mode+'-probe')
 command=[str(wrapper),'rustc','--edition=2024','--crate-name','wire_readiness_probe','-C','opt-level=0','-C','debuginfo=0',str(source),'-o',str(binary),'-L','dependency='+str(deps)]
 for name,path in extern.items():command.extend(['--extern',name+'='+str(path)])
 linked_paths=sorted({p for m in messages if m.get('reason')=='build-script-executed' for p in m.get('linked_paths',[])})
 for path in linked_paths:command.extend(['-L',path])
 row={'source':record['source'],'source_build_record':str(build/'build.json'),'source_build_record_sha256':digest(build/'build.json'),'source_build_stdout_sha256':digest(log),'externs':{k:str(v) for k,v in extern.items()},'input_libraries_before':before,'peer_crate_manifest':next(m['manifest_path'] for m in artifacts if m.get('target',{}).get('name')=='h2')}
 manifest['variants'][mode]=row;(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 code=execute(mode+'-compile',command,120);row['compile_exit_code']=code
 after=snapshot(libraries);row['input_libraries_after_compile']=after;row['input_artifacts_unchanged_after_compile']=before==after
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if code!=0 or before!=after:raise SystemExit('compile failure or source artifact drift: '+mode)
 row['binary_sha256']=digest(binary)
 code=execute(mode+'-run',[str(binary),mode],100);row['run_exit_code']=code
 row['input_libraries_after_run']=snapshot(libraries);row['input_artifacts_unchanged_after_run']=before==row['input_libraries_after_run']
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 if code!=0 or not row['input_artifacts_unchanged_after_run']:raise SystemExit('wire readiness failure or artifact drift: '+mode)
manifest['state']='complete';(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'state':'complete','harness_sha256':manifest['harness_sha256'],'variants':{k:{'source':v['source']['commit'],'compile':v['compile_exit_code'],'run':v['run_exit_code'],'binary_sha256':v['binary_sha256']} for k,v in manifest['variants'].items()}},indent=2))
