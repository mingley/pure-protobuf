# Idle-handler polling over TCP

An independent registry `h2` 0.4.19 client keeps native gRPC handlers pending while sending 16 PINGs and 16 successful unary calls over the same TCP connection. The pending handler future counts every actual poll and never wakes itself.

| Pending handlers | Before (`6cd91911`) | Current (`90201458`) |
|---:|---:|---:|
| 1 | 80 extra polls | 0 |
| 64 | 5,120 extra polls | 0 |
| 256 | 20,480 extra polls | 0 |

Counts exclude initial handler admission and the later intentional cancellation. In the baseline, PING traffic adds 16 polls per idle handler and active unary traffic adds 64. The current source avoids these unrelated polls. This is a source comparison with a real HTTP/2 peer, not a timing benchmark or a claim about tonic throughput.

Each revision completed 51 successful unary RPCs across three cases, including a recovery call after cancellation on every connection. All 321 pending handler futures were explicitly reset and their destruction was acknowledged. Each revision also received 54 PING acknowledgements, including warmup and recovery. Responses required HTTP 200, one complete empty protobuf message, and `grpc-status:0` trailers. Native server shutdown completed cleanly.

Both sources use identical finite limits: 5 seconds per operation, 30 seconds per case, 512 HTTP/2 stream slots and `pending handlers + 8` application RPC slots. The runtime is Tokio current-thread and the transport is plaintext TCP loopback. This shared-host control does not qualify latency, CPU, goodput, total retained memory or production readiness.

`probe.rs` is the identical external harness. `run.py` compiles it with rustc against release rlibs named by the already completed, source-attested benchmark build logs. No Cargo build, source edit or shared stable-target mutation was needed. `manifest.json` records the source build records, log hashes, complete recorded release rlib/rmeta hashes, exact externs and executable hashes. Artifact hashes were unchanged before and after each compilation and run. `*-compile.json` and `*-run.json` retain commands, limits and exit codes; stdout retains individual cases and rounds. `results.json` and `tools.json` summarize the verified results and compiler/peer versions.
