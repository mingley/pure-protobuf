from pathlib import Path
import subprocess,json,os
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';env=os.environ.copy();env.update(RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(r/'work/stable-target'),CARGO_BUILD_JOBS='1')
names=['a_handler_deadline_is_an_instant_that_elapses','a_tls_server_timeout_expires_when_the_client_sends_none','client_max_connection_age_resets_a_delayed_stream','tls_spawned_work_stops_when_the_client_cancels'];results=[]
for i,name in enumerate(names):
 p=q/f'architecture-c5-serving-development-{i}'
 assert not p.with_suffix('.json').exists()
 command=['python3',str(r/'work/record.py'),str(p),'900',str(r/'work/run-rust'),'cargo','test','--locked','-p','pbrs-grpc','--all-features','--test','serving',name,'--','--exact','--nocapture','--test-threads=1']
 result=subprocess.run(command,cwd=r,env=env);results.append({'test':name,'exit_code':result.returncode,'record':str(p.with_suffix('.json'))})
 if result.returncode: break
(q/'architecture-c5-serving-development.json').write_text(json.dumps({'scope':'development, exact retained fixture patches; source not yet committed','results':results},indent=2)+'\n')
