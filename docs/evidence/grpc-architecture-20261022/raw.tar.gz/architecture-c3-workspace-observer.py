import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
CHECKOUT = ROOT / 'work/architecture-c3'
PREFIX = ROOT / 'work/qualification/architecture-c3-workspace'
PID = 137832
HEAD = '783bcd53c723032cd0ccbff5d4550f9a1c92cbb8'
EXPECTED_TARGETS = 139

def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def stat():
    raw = Path(f'/proc/{PID}/stat').read_text()
    fields = raw[raw.rfind(')') + 2:].split()
    return {'raw': raw, 'state': fields[0], 'ppid': int(fields[1]),
            'pgid': int(fields[2]), 'sid': int(fields[3]),
            'start_ticks': int(fields[19]), 'wait_status': int(fields[49])}

def source():
    return {'head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=CHECKOUT, text=True).strip(),
            'status': subprocess.check_output(['git', 'status', '--porcelain=v1'], cwd=CHECKOUT, text=True)}

def summaries():
    stdout = PREFIX.with_suffix('.stdout').read_bytes()
    stderr = PREFIX.with_suffix('.stderr').read_bytes()
    text = stdout.decode(errors='replace')
    pattern = r'^test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out; finished in (.+)$'
    results = []
    for m in re.finditer(pattern, text, re.M):
        results.append(dict(status=m[1], passed=int(m[2]), failed=int(m[3]),
                            ignored=int(m[4]), measured=int(m[5]), filtered=int(m[6]), duration=m[7]))
    required = ['upload_task_panic_before_headers_resets_and_releases_resources',
                'upload_task_panic_after_headers_resets_and_releases_resources',
                'dropping_closed_upload_call_before_headers_releases_resources',
                'cancelling_closed_upload_call_before_headers_releases_resources']
    return {'result_targets': len(results), 'expected_result_targets': EXPECTED_TARGETS,
            'totals': {k: sum(r[k] for r in results) for k in ('passed', 'failed', 'ignored', 'measured', 'filtered')},
            'failed_tests': re.findall(r'^test (.+) \.\.\. FAILED$', text, re.M),
            'required_pump_tests_passed': {name: f'test {name} ... ok' in text for name in required},
            'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
            'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
            'stdout_bytes': len(stdout), 'stderr_bytes': len(stderr), 'results': results}

first = stat()
command = Path(f'/proc/{PID}/cmdline').read_bytes().split(b'\0')
command = [os.fsdecode(x) for x in command if x]
assert first['state'] != 'Z'
assert first['pgid'] == PID and first['sid'] == PID
assert command[1:] == ['test', '--locked', '--workspace', '--all-features', '--no-fail-fast'], command
assert Path(f'/proc/{PID}/cwd').resolve() == CHECKOUT
initial_source = source()
assert initial_source == {'head': HEAD, 'status': ''}, initial_source
ticks = os.sysconf('SC_CLK_TCK')
boot_seconds = int(next(l.split()[1] for l in Path('/proc/stat').read_text().splitlines() if l.startswith('btime ')))
initial = {'observer_started_utc': utc(), 'observer_pid': os.getpid(),
           'observer_source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
           'original_recorder_pid': 137819, 'original_recorder_interrupted': True,
           'original_terminal_record_missing_at_recovery': not PREFIX.with_suffix('.json').exists(),
           'original_start_metadata_file_unavailable': True,
           'initial_launch_source_verified_in_assistant_tool_transcript': True,
           'scope': 'Recovery observation of the surviving original Cargo. Does not manufacture the lost record.py terminal record.',
           'cargo_pid': PID, 'cargo_command': command, 'cargo_cwd': str(CHECKOUT),
           'cargo_initial_stat': first, 'kernel_clock_ticks_per_second': ticks,
           'kernel_boot_time_seconds': boot_seconds,
           'cargo_kernel_start_utc_approx': datetime.datetime.fromtimestamp(boot_seconds + first['start_ticks'] / ticks, datetime.timezone.utc).isoformat(),
           'boot_id': Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
           'source_at_recovery': initial_source, 'hard_timeout_seconds_from_cargo_kernel_start': 4800,
           'summary_at_recovery': summaries()}
write_json(PREFIX.with_name(PREFIX.name + '-recovery-initial').with_suffix('.json'), initial)
timeout_term = None
timeout_kill = None
failure = None
last = first
while True:
    try:
        last = stat()
    except FileNotFoundError:
        failure = 'Cargo was reaped before its kernel wait status could be observed; actual exit status unavailable.'
        break
    if last['start_ticks'] != first['start_ticks']:
        failure = 'PID identity changed; refusing to infer the original Cargo exit status.'
        break
    if last['state'] == 'Z':
        break
    elapsed = float(Path('/proc/uptime').read_text().split()[0]) - first['start_ticks'] / ticks
    if elapsed >= 4800 and timeout_term is None:
        assert last['pgid'] == PID
        os.killpg(PID, signal.SIGTERM)
        timeout_term = utc()
        term_monotonic = time.monotonic()
    elif timeout_term is not None and timeout_kill is None and time.monotonic() - term_monotonic >= 5:
        os.killpg(PID, signal.SIGKILL)
        timeout_kill = utc()
    time.sleep(0.5)

result = {'observed_utc': utc(), 'original_recorder_interrupted': True,
          'original_terminal_record_not_fabricated': True,
          'initial_observation_record': str(PREFIX.with_name(PREFIX.name + '-recovery-initial').with_suffix('.json')),
          'cargo_pid': PID, 'cargo_start_ticks': first['start_ticks'], 'cargo_last_stat': last,
          'status_observation_error': failure, 'timeout_sigterm_utc': timeout_term,
          'timeout_sigkill_utc': timeout_kill, 'source_at_completion': source(), 'summary': summaries()}
if failure is None:
    status = last['wait_status']
    result.update(cargo_kernel_wait_status=status, cargo_exited_normally=os.WIFEXITED(status),
                  cargo_exit_code=os.WEXITSTATUS(status) if os.WIFEXITED(status) else None,
                  cargo_signal=os.WTERMSIG(status) if os.WIFSIGNALED(status) else None)
summary = result['summary']
result['complete_workspace_summaries'] = summary['result_targets'] == EXPECTED_TARGETS
result['qualification_passed'] = (failure is None and result.get('cargo_exited_normally') is True
    and result.get('cargo_exit_code') == 0 and timeout_term is None
    and result['source_at_completion'] == {'head': HEAD, 'status': ''}
    and result['complete_workspace_summaries'] and summary['totals']['failed'] == 0
    and all(r['status'] == 'ok' for r in summary['results'])
    and all(summary['required_pump_tests_passed'].values()))
terminal = PREFIX.with_name(PREFIX.name + '-observed').with_suffix('.json')
write_json(terminal, result)
print(json.dumps({'terminal_record': str(terminal), 'cargo_exit_code': result.get('cargo_exit_code'),
                  'qualification_passed': result['qualification_passed'], 'totals': summary['totals'],
                  'result_targets': summary['result_targets']}), flush=True)
