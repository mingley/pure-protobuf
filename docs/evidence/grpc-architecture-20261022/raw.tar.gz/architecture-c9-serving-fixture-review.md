# Deadline fixture follow-up, C9

Runtime remains `9d6fb9c416fc32732450fd78d32ee16ff8b802de`. The repair changes only `pbrs-grpc/tests/serving.rs`; it does not change timeout policy, wire behavior, or production code.

## Original failures and diagnostics

The C8 workspace finished with 3,753 passes, two failures and nine ignores across 139 result targets. Serving had 1,098 passes and two failures:

- `a_from_io_client_interceptor_can_set_a_deadline` observed DEADLINE_EXCEEDED before its handler/child were admitted (`started=0`, `child_done=0`, `finished=0`). Its real 40 ms timer included all scheduling before admission.
- `a_tls_handler_sees_the_interceptor_deadline_on_request` observed INTERNAL at server-stream response setup. The original Status Debug intentionally redacted the message, so that exact predicate is unknown.

The unchanged C8 ELF passed both cases in three quiet repeats each (six passes). Its full source snapshot, binary hash and command logs remain in `architecture-c9-original-*`. A diagnostic-only patch changed the four-shape SeesCap helper to print the actual public `Status.message()` with the code and RPC shape. All deadlines and predicates remained unchanged. That version passed the full 1,100-case Serving suite in 22.00 test seconds, plus ten focused repeats of all five SeesCap transport variants (50 more passes). The diagnostic source, patch, ELF hash and logs remain in `architecture-c9-diagnostic-*`. These passes do not erase the original failures or establish a unique cause for INTERNAL.

A source dependency explains why the SeesCap exact-peer oracle needs controlled time: `client/call.rs::outgoing_timeout` preserves the original timeout for the initial short scheduling window, then writes the remaining duration after 20 ms. A 5 s request may therefore correctly reach the server with a shorter wire timeout after delayed admission. The test requires exactly 5 s. Frozen virtual time preserves that exact input while real network I/O progresses. This is an identified dependency, not a reproduction of the original redacted message.

## Repair scope

All variants are covered together: TCP, TLS, mTLS, Unix sockets and supplied I/O.

| Fixture class | Cases | Logical checks |
| --- | ---: | --- |
| Client interceptor deadline | 5 | Original 40 ms; actual admission first; alive/pending at 39 ms; exact DEADLINE_EXCEEDED at 41 ms; child cancellation and parent Drop; zero normal completion |
| Server interceptor deadline lifecycle | 5 | Original 20 ms; actual admission first; alive/pending at 19 ms; exact DEADLINE_EXCEEDED at 21 ms; child cancellation and parent Drop; zero normal completion |
| Handler sees interceptor cap | 5 | Original exact 20 ms cap and 5 s peer; Request/Parts timeout and peer-timeout agreement; no server timeout overlay; deadline Instant cap; all four RPC shapes |

Each lifecycle case exercises unary, server streaming, client streaming and bidi. The shared probe registers the real inner-handler waker and counts polls and actual future destruction. At the pre-deadline boundary, the fixture explicitly wakes the handler and waits for another poll or Drop before asserting that it is still alive and the client call remains pending. A single client Pending poll could otherwise miss an early server deadline that had not yet been processed. The probe clears its retained waker on Drop, preventing a task/probe reference cycle.

Current-thread paused clocks advance only at the explicit test boundaries. A self-waking driver keeps real sockets/TLS runnable while an independent five-second wall guard detects stalled admission, deadline propagation, cancellation or destruction. Unix variants first witness the listener path before connecting, so a retry sleep cannot deadlock a frozen setup. No configured deadline or tolerance was increased. The original finite 200 ms SpawnHang completion remains and cannot be reached before the deadline assertions.

Existing generic real-time helpers used by unrelated fixtures remain. The older 50 ms server-timeout fixture reuses the extracted inner-poll witness without changing its 49/51 ms checks. Public status diagnostics remain local to the SeesCap fixture helper; production Debug redaction is unchanged.

## Validation status

The repaired-source snapshot and patch are `architecture-c9-serving-repair-source.json` and `architecture-c9-serving-repair.patch`. Its detached positive driver records the full Serving suite, strict Serving Clippy and formatting. The driver passed all 1,100 Serving cases (23.71 test seconds; 193.40 build seconds), strict all-feature Serving Clippy and formatting. The repaired file is committed at `deb0d1d6b9855188a23128c0dca54c03dc2c8bfc`; its SHA256 is `a084207767979a8d720be2035a63529daf01c6dcb1eb5baaf4dfa0dc585d0f4c`. The parent owns the copied-fixture negative controls and the next clean-source full workspace run.

Two draft-preparation errors were corrected before the shipping file changed: a generic helper name was initially not found by the preparation script, and formatting the standalone draft required `skip_children=true` because its temporary directory has no sibling `common` module. Neither was a Cargo build or test result, and neither changed production code.
