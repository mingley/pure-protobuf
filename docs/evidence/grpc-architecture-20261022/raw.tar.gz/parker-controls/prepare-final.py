"""Prepare mechanism controls from an exact checkout revision; does not mutate it."""
import argparse,difflib,hashlib,json,subprocess
from pathlib import Path

parser=argparse.ArgumentParser()
parser.add_argument('--checkout',required=True,type=Path)
parser.add_argument('--source',required=True)
parser.add_argument('--output',required=True,type=Path)
args=parser.parse_args()
commit=subprocess.check_output(['git','-C',str(args.checkout),'rev-parse',args.source+'^{commit}'],text=True).strip()
args.output.mkdir(parents=True,exist_ok=True)
paths=['pbrs-grpc/src/wire/send.rs','pbrs-grpc/src/server/connection.rs']
base={p:subprocess.check_output(['git','-C',str(args.checkout),'show',commit+':'+p],text=True) for p in paths}
basehash={p:hashlib.sha256(s.encode()).hexdigest() for p,s in base.items()}

def scan(source,name,next_marker):
    a=source.index(f'fn {name}<F: Future<Output = ()>>(')
    b=source.index(next_marker,a)
    return source[:a]+f'''fn {name}<F: Future<Output = ()>>(
    pending: &mut futures_util::stream::FuturesUnordered<F>,
    cx: &mut Context<'_>,
) -> Poll<()> {{
    // Mechanism negative control: the former full pending-future scan,
    // keeping current storage to isolate scheduling selection work.
    let mut finished = false;
    for future in Pin::new(pending).iter_pin_mut() {{
        if future.poll(cx).is_ready() {{ finished = true; }}
    }}
    if finished {{ Poll::Ready(()) }} else {{ Poll::Pending }}
}}
''' +source[b:]

fullscan=dict(base)
fullscan[paths[0]]=scan(base[paths[0]],'poll_parked','\n#[cfg(test)]\nmod park_tests;')
fullscan[paths[1]]=scan(base[paths[1]],'poll_admitted','\n/// Sleep until')

global_runtime=dict(base)
s=base[paths[0]];a=s.index('fn park_cancel(job: CancelJob) {');b=s.index('\nasync fn run_parker(',a)
global_runtime[paths[0]]=s[:a]+'''fn park_cancel(job: CancelJob) {
    // Mechanism negative control: first-live-runtime process-global owner,
    // keeping current ready-set scheduling to isolate runtime ownership.
    use std::sync::{Mutex, OnceLock};
    static PARK: OnceLock<Mutex<Option<tokio::sync::mpsc::UnboundedSender<CancelJob>>>> = OnceLock::new();
    let mut guard = PARK.get_or_init(|| Mutex::new(None)).lock().unwrap_or_else(|error| error.into_inner());
    if guard.as_ref().is_none_or(|sender| sender.is_closed()) {
        let (sender, mut receiver) = tokio::sync::mpsc::unbounded_channel::<CancelJob>();
        drop(tokio::spawn(async move {
            let mut parked = futures_util::stream::FuturesUnordered::new();
            loop {
                tokio::select! {
                    biased;
                    incoming = receiver.recv() => match incoming {
                        Some(job) => parked.push(job),
                        None => break,
                    },
                    _ = std::future::poll_fn(|cx| poll_parked(&mut parked, cx)), if !parked.is_empty() => {},
                }
            }
        }));
        *guard = Some(sender);
    }
    if let Some(sender) = guard.as_ref() { sender.send(job).ok(); }
}
''' +s[b:]

manifest={'source_commit':commit,'base_files_sha256':basehash,'classification':'Explicit mechanism negative controls; not untouched historical source.','controls':{}}
for name,files,tests in [
    ('fullscan',fullscan,[
        'server::connection::ready_set_tests::unrelated_connection_activity_does_not_scan_idle_handlers',
        'wire::send::park_tests::one_wake_polls_only_one_of_4096_parked_jobs']),
    ('global-runtime',global_runtime,[
        'wire::send::park_tests::shutting_down_another_runtime_does_not_lose_wire_cancellation'])]:
    patch=''.join(''.join(difflib.unified_diff(base[p].splitlines(True),files[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in paths)
    (args.output/(name+'.patch')).write_text(patch)
    for path,text in files.items():
        target=args.output/name/path;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
    manifest['controls'][name]={'patch':name+'.patch','patch_sha256':hashlib.sha256(patch.encode()).hexdigest(),'test_filters':tests,'expected_test_exit_code':101,'must_compile':True}
(args.output/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'source':commit,'output':str(args.output),'controls':list(manifest['controls'])}))
