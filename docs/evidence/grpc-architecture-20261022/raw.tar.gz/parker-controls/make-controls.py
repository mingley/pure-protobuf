from pathlib import Path
import difflib,hashlib,json
source=Path('pbrs-grpc/src/wire/send.rs').read_text()
a=source.index('fn poll_parked<F: Future<Output = ()>>(')
b=source.index('\n#[cfg(test)]\nmod park_tests;',a)
scan='''fn poll_parked<F: Future<Output = ()>>(
    parked: &mut futures_util::stream::FuturesUnordered<F>,
    cx: &mut Context<'_>,
) -> Poll<()> {
    // Negative control: reproduce the former scheduler's full pending scan.
    let mut finished = false;
    for future in Pin::new(parked).iter_pin_mut() {
        if future.poll(cx).is_ready() {
            finished = true;
        }
    }
    if finished { Poll::Ready(()) } else { Poll::Pending }
}
'''
scan_source=source[:a]+scan+source[b:]
a=source.index('fn park_cancel(job: CancelJob) {')
b=source.index('\nasync fn run_parker(',a)
global_control='''fn park_cancel(job: CancelJob) {
    // Negative control: the former process-global sender chooses the first
    // live runtime even when a job belongs to another concurrently live one.
    use std::sync::{Mutex, OnceLock};
    static PARK: OnceLock<Mutex<Option<tokio::sync::mpsc::UnboundedSender<CancelJob>>>> = OnceLock::new();
    let slot = PARK.get_or_init(|| Mutex::new(None));
    let mut guard = slot.lock().unwrap_or_else(|error| error.into_inner());
    if guard.as_ref().is_none_or(|sender| sender.is_closed()) {
        let (sender, mut receiver) = tokio::sync::mpsc::unbounded_channel::<CancelJob>();
        drop(tokio::spawn(async move {
            let mut parked = futures_util::stream::FuturesUnordered::new();
            loop {
                tokio::select! {
                    biased;
                    incoming = receiver.recv() => match incoming {
                        Some(job) => parked.push(job),
                        None => break,
                    },
                    _ = std::future::poll_fn(|cx| poll_parked(&mut parked, cx)), if !parked.is_empty() => {},
                }
            }
        }));
        *guard = Some(sender);
    }
    if let Some(sender) = guard.as_ref() { sender.send(job).ok(); }
}
'''
global_source=source[:a]+global_control+source[b:]
out=Path('work/qualification/parker-controls')
(out/'source-base.rs').write_text(source)
for name,text in [('full-scan',scan_source),('global-runtime',global_source)]:
 (out/f'{name}.rs').write_text(text)
 patch=''.join(difflib.unified_diff(source.splitlines(True),text.splitlines(True),fromfile='a/pbrs-grpc/src/wire/send.rs',tofile='b/pbrs-grpc/src/wire/send.rs'))
 (out/f'{name}.patch').write_text(patch)
(out/'manifest.json').write_text(json.dumps({'base_send_sha256':hashlib.sha256(source.encode()).hexdigest(),'controls':{'full-scan':'Replay the former all-futures-poll mechanism with the same pinned ready-set storage, to isolate selection work. Expected one_wake_polls_only_one_of_4096_parked_jobs failure:8192 polls rather than4097. This does not reproduce old allocation/layout.','global-runtime':'Replay the former process-global first-live-runtime registration while keeping new ready-set selection, to isolate runtime ownership. Expected shutting_down_another_runtime_does_not_lose_wire_cancellation failure. These are explicit controlled regressions, not untouched historical source.'}},indent=2)+'\n')
