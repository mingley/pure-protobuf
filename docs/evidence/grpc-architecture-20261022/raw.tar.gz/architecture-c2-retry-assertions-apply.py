from pathlib import Path
p=Path('pbrs-grpc/tests/retry_safety.rs');s=p.read_text()
insert='''
/// Observe a complete response HEADERS frame accepted by the TCP socket.
/// Merely queueing HEADERS before send_reset can discard them inside h2.
struct HeaderWriteWitness {
    socket: TcpStream,
    pending: Vec<u8>,
    written: Option<tokio::sync::oneshot::Sender<()>>,
}

impl HeaderWriteWitness {
    fn new(socket: TcpStream) -> (Self, tokio::sync::oneshot::Receiver<()>) {
        let (written, received) = tokio::sync::oneshot::channel();
        (Self { socket, pending: Vec::new(), written: Some(written) }, received)
    }

    fn record(&mut self, bytes: &[u8]) {
        if self.written.is_none() { return; }
        self.pending.extend_from_slice(bytes);
        while self.pending.len() >= 9 {
            let length = (usize::from(self.pending[0]) << 16)
                | (usize::from(self.pending[1]) << 8) | usize::from(self.pending[2]);
            if self.pending.len() < 9 + length { break; }
            let stream = u32::from_be_bytes(self.pending[5..9].try_into().unwrap()) & 0x7fff_ffff;
            if self.pending[3] == 1 && self.pending[4] & 4 != 0 && stream == 1 {
                self.written.take().unwrap().send(()).unwrap();
                self.pending.clear();
                return;
            }
            self.pending.drain(..9 + length);
        }
        assert!(self.pending.len() < 64 * 1024, "unexpected peer frame size");
    }
}

impl tokio::io::AsyncRead for HeaderWriteWitness {
    fn poll_read(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>,
        buf: &mut tokio::io::ReadBuf<'_>) -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut self.socket).poll_read(cx, buf)
    }
}

impl tokio::io::AsyncWrite for HeaderWriteWitness {
    fn poll_write(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>,
        bytes: &[u8]) -> std::task::Poll<std::io::Result<usize>> {
        let result = std::pin::Pin::new(&mut self.socket).poll_write(cx, bytes);
        if let std::task::Poll::Ready(Ok(count)) = result { self.record(&bytes[..count]); }
        result
    }
    fn poll_flush(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>)
        -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut self.socket).poll_flush(cx)
    }
    fn poll_shutdown(mut self: std::pin::Pin<&mut Self>, cx: &mut std::task::Context<'_>)
        -> std::task::Poll<std::io::Result<()>> {
        std::pin::Pin::new(&mut self.socket).poll_shutdown(cx)
    }
}

'''
pos=s.index('/// Greeter implementation');s=s[:pos]+insert+s[pos:]
a=s.index('async fn caller_driven_streams_keep');b=s.index('// ============================================================================',a)
block=s[a:b].replace('assert_eq!(status.code(), Code::Unavailable, "{shape}");','''// A peer CANCEL is CANCELLED; it provides no proof that execution
        // did not occur and must not enable a transparent or policy replay.
        assert_eq!(status.code(), Code::Cancelled, "{shape}");''').replace('        assert_eq!(channel.retry_stats().policy_retries, 0);','        assert_eq!(channel.retry_stats().policy_retries, 0);\n        assert_eq!(channel.retry_stats().transparent_retries, 0);')
s=s[:a]+block+s[b:]
a=s.index('async fn scenario_c_unary_response_headers_committed_no_retry_on_stream_error');b=s.index('/// Scenario C (Server Streaming)',a)
block=s[a:b].replace('        let mut conn = h2::server::handshake(socket).await.expect("handshake");','''        let (socket, headers_written) = HeaderWriteWitness::new(socket);
        let mut conn = h2::server::handshake(socket).await.expect("handshake");''',1)
block=block.replace('''            // Reset stream after response headers have been committed:
            send_stream.send_reset(h2::Reason::CANCEL);''','''            // Independently drive the connection until complete HEADERS
            // actually reach TCP, then send the later cancellation reset.
            tokio::time::timeout(Duration::from_secs(2), async {
                tokio::select! {
                    result = headers_written => result.expect("HEADERS write witness"),
                    result = conn.accept() => panic!("unexpected second RPC: {result:?}"),
                }
            }).await.expect("response HEADERS must be written before reset");
            send_stream.send_reset(h2::Reason::CANCEL);''')
block=block.replace('''    let client = GreeterClient::connect(addr).await.expect("connect");
    let result = client.say_hello(Request::new(req("test"))).await;''','''    let channel = Channel::connect(addr).await.expect("connect");
    let client = GreeterClient::new(channel.clone());
    let result = tokio::time::timeout(
        Duration::from_secs(3), client.say_hello(Request::new(req("test"))),
    ).await.expect("committed reset must terminate the call");''')
block=block.replace('    assert_eq!(status.code(), Code::Unavailable);','''    assert_eq!(status.code(), Code::Cancelled);
    assert_eq!(channel.retry_stats().transparent_retries, 0);
    assert_eq!(channel.retry_stats().policy_retries, 0);''')
s=s[:a]+block+s[b:];p.write_text(s)
