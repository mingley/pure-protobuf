#!/usr/bin/env python3
"""Source-pinned selected native/Callgrind A/B diagnostics; never qualification."""
import argparse
import datetime
import gzip
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import re
import shutil
import subprocess
import time
from types import SimpleNamespace

PAIRS = [
    ('native', 'pbrs', 'tonic', 'prost'),
    ('native', 'prost', 'tonic', 'prost'),
    ('tonic', 'prost', 'native', 'pbrs'),
    ('tonic', 'prost', 'native', 'prost'),
    ('tonic', 'prost', 'tonic', 'prost'),
]
SHAPES = ['unary', 'bidi', 'bidi_pipelined']
BASELINE_COMMIT = '2eba72d86b4bb7db133120797e3c4746d86713bc'


def digest(path):
    sha = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            sha.update(block)
    return sha.hexdigest()


def save(path, record):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(record, indent=2) + '\n')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def host():
    result = dict(uname=platform.uname()._asdict(), affinity=sorted(os.sched_getaffinity(0)),
                  cpu_count=os.cpu_count(), load_average=list(os.getloadavg()))
    for name in ('cpu.max', 'memory.max'):
        path = Path('/sys/fs/cgroup') / name
        result[name] = path.read_text().strip() if path.exists() else None
    return result


def cells_for(args):
    if args.cells_file:
        workloads = json.loads(args.cells_file.read_text())
        if not isinstance(workloads, list) or not workloads:
            raise ValueError('selected workloads must be a nonempty JSON list')
        keys = {'pair', 'shape', 'payload_bytes', 'tls', 'compression', 'connections', 'in_flight'}
        seen = set()
        for cell in workloads:
            if (not isinstance(cell, dict) or set(cell) != keys
                    or tuple(cell['pair']) not in PAIRS
                    or cell['shape'] not in ['unary', 'server_stream', 'client_stream', 'bidi', 'bidi_pipelined']
                    or cell['payload_bytes'] not in [0, 1024, 65536, 1048576]
                    or type(cell['tls']) is not bool
                    or cell['compression'] not in ['identity', 'gzip']
                    or type(cell['connections']) is not int or not 1 <= cell['connections'] <= 64
                    or type(cell['in_flight']) is not int or not cell['connections'] <= cell['in_flight'] <= 1024):
                raise ValueError('workload outside unchanged harness bounds')
            identity = tuple((key, tuple(cell[key]) if key == 'pair' else cell[key]) for key in sorted(keys))
            if identity in seen:
                raise ValueError('duplicate selected workload')
            seen.add(identity)
        cells = [dict(cell, repeat=repeat) for cell, repeat in itertools.product(workloads, range(args.repeats))]
        if args.pilot:
            cells = [dict(workloads[0], repeat=0)]
    else:
        pairs = PAIRS if args.scope == 'full' else PAIRS[2:]
        shapes = SHAPES if args.scope == 'full' else ['bidi', 'bidi_pipelined']
        cells = [dict(pair=list(pair), shape=shape, payload_bytes=1024, tls=False,
                      compression=compression, connections=1, in_flight=1, repeat=repeat)
                 for pair, shape, compression, repeat in itertools.product(
                     pairs, shapes, ['identity', 'gzip'], range(args.repeats))]
        if args.pilot:
            cells = [cell for cell in cells if cell['pair'] == ['tonic', 'prost', 'native', 'pbrs']
                     and cell['shape'] == 'bidi' and cell['compression'] == 'gzip' and cell['repeat'] == 0]
    random.Random(args.seed).shuffle(cells)
    return cells


def schedule_for(cells, args):
    rng = random.Random(args.seed ^ 0xABBA)
    if args.pilot:
        versions = ['baseline', 'candidate']
        rng.shuffle(versions)
        counts = [args.count, args.count * 2]
        rng.shuffle(counts)
        return [dict(version=name, count=count, cell_index=0) for name, count in
                [(versions[0], counts[0]), (versions[1], counts[0]),
                 (versions[1], counts[1]), (versions[0], counts[1])]]
    if args.abba:
        if args.repeats % 2:
            raise ValueError('balanced ABBA blocks require an even repeat count')
        groups = {}
        for index, cell in enumerate(cells):
            key = json.dumps({k: v for k, v in cell.items() if k != 'repeat'}, sort_keys=True)
            groups.setdefault(key, {})[cell['repeat']] = index
        blocks = [(indexes, repeat) for indexes in groups.values() for repeat in range(0, args.repeats, 2)]
        rng.shuffle(blocks)
        schedule = []
        for indexes, repeat in blocks:
            versions = ['baseline', 'candidate']
            rng.shuffle(versions)
            for name, rep in [(versions[0], repeat), (versions[1], repeat),
                              (versions[1], repeat + 1), (versions[0], repeat + 1)]:
                counts = [args.count, args.count * 2]
                rng.shuffle(counts)
                schedule.extend(dict(version=name, count=count, cell_index=indexes[rep]) for count in counts)
        return schedule
    schedule = []
    for index, cell in enumerate(cells):
        versions = ['baseline', 'candidate']
        rng.shuffle(versions)
        for name in versions:
            counts = [args.count, args.count * 2]
            rng.shuffle(counts)
            schedule.extend(dict(version=name, count=count, cell_index=index) for count in counts)
    return schedule


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('baseline', 'candidate'):
        parser.add_argument(f'--{name}-checkout', type=Path, required=True)
        parser.add_argument(f'--{name}-binary', type=Path, required=True)
        parser.add_argument(f'--{name}-build-record', type=Path, required=True)
    parser.add_argument('--baseline-commit', default=BASELINE_COMMIT)
    parser.add_argument('--candidate-commit', required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--valgrind', type=Path)
    parser.add_argument('--valgrind-lib', type=Path)
    parser.add_argument('--count', type=int, default=100)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--outer-timeout', type=float, default=60)
    parser.add_argument('--seed', type=int, default=20261022)
    parser.add_argument('--phase', choices=['native', 'callgrind'], default='callgrind')
    parser.add_argument('--cells-file', type=Path)
    parser.add_argument('--abba', action='store_true')
    parser.add_argument('--scope', choices=['full', 'server-streaming', 'selected'], default='full',
                        help='full targets or native-server bidi/pipeline plus tonic reference')
    parser.add_argument('--pilot', action='store_true', help='one worst-case workload, both sources, N/2N; no tonic reference')
    parser.add_argument('--plan', action='store_true', help='print workload counts without reading builds or running endpoints')
    args = parser.parse_args()
    if (not 1 <= args.count <= 100000 or not 1 <= args.repeats <= 10
            or not 0.01 <= args.outer_timeout <= 60):
        parser.error('count/repeats/outer-timeout outside the existing campaign bounds')
    for name in ('baseline', 'candidate'):
        if re.fullmatch(r'[0-9a-f]{40}', getattr(args, f'{name}_commit')) is None:
            parser.error(f'{name} commit must be the full 40-character source hash')
    if args.phase == 'callgrind' and (args.valgrind is None or args.valgrind_lib is None):
        parser.error('Callgrind requires both executable and library paths')
    if args.scope == 'selected' and args.cells_file is None:
        parser.error('selected scope needs --cells-file')
    cells = cells_for(args)
    if args.plan:
        print(json.dumps(dict(qualified=False, pilot=args.pilot, scope=args.scope, phase=args.phase, abba=args.abba or args.pilot, cells_per_source=len(cells),
                              rpc_counts=[args.count, args.count * 2], captures=len(cells) * 4,
                              instrumented_endpoint_processes=len(cells) * 8,
                              total_rpc_calls=len(cells) * 2 * 3 * args.count,
                              per_rpc_deadlines='unchanged benchmark defaults',
                              shapes=sorted({cell["shape"] for cell in cells}),
                              pairs=[list(pair) for pair in dict.fromkeys(tuple(cell["pair"]) for cell in cells)],
                              payloads=sorted({cell['payload_bytes'] for cell in cells}),
                              tls=sorted({cell['tls'] for cell in cells})), indent=2))
        return 0
    campaign_started = time.monotonic()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    controller = output / 'controller.py'
    shutil.copy2(__file__, controller)
    controller_hash = digest(controller)
    state = dict(schema='pbrs.targeted-counter-ab.v1', qualified=False, passed=False, state='preparing',
                 phase=args.phase, abba=args.abba or args.pilot, pilot=args.pilot, scope=args.scope, small_n=args.count < 100, seed=args.seed, cells=cells, rpc_counts=[args.count, args.count * 2],
                 expected_captures=len(cells) * 4, expected_endpoint_processes=len(cells) * 8,
                 started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 controller_sha256=controller_hash, host_before=host(), versions={}, captures=[],
                 missing_metrics=(['syscalls', 'context_switches', 'task_wakeups', 'native latency/goodput'] if args.phase == 'callgrind' else ['instructions', 'syscalls', 'task_wakeups', 'qualified native latency/goodput']),
                 limits=['shared-host separate-process diagnostics; qualified=false',
                         'process-lifetime Callgrind instructions, paired N/2N setup subtraction',
                         'both endpoints instrumented; profiler timings are not native latency or throughput',
                         'process CPU seconds include profiler overhead; instruction totals describe instrumented work',
                         'synthetic zero-filled payloads and exact selected scopes are recorded in cells; four streaming messages',
                         'per-RPC deadlines, readiness and teardown timeouts remain unchanged',
                         'no measured scheduling noise, independent host statistics or broad superiority proof'])
    if args.cells_file:
        inputs_copy = output / 'workloads.json'
        shutil.copy2(args.cells_file, inputs_copy)
        state['workloads_input'] = dict(path=str(args.cells_file.resolve()), sha256=digest(inputs_copy))
    if args.count < 100:
        state['limits'].append(f'small-N diagnostic ({args.count}/{args.count * 2}); setup subtraction and scheduling can dominate differences')
    if args.scope == 'server-streaming':
        state['limits'].append('focused scope omits unary and native-client pairs; tonic peers remain instrumented')
    if args.pilot:
        state['limits'].append('pilot omits same-peer tonic/prost reference and other workloads')
    save(output / 'campaign.json', state)
    records, loaded = {}, {}
    try:
        valgrind = None
        if args.phase == 'callgrind':
            os.environ['VALGRIND_LIB'] = str(args.valgrind_lib.resolve(strict=True))
            valgrind = args.valgrind.resolve(strict=True)
            state['tools'] = dict(valgrind=str(valgrind), valgrind_sha256=digest(valgrind),
                                  valgrind_lib=os.environ['VALGRIND_LIB'],
                                  version=subprocess.check_output([str(valgrind), '--version'], text=True).strip())
        else:
            state['tools'] = dict(native=True)
            state['limits'] = [limit for limit in state['limits'] if not any(word in limit for word in ['Callgrind', 'profiler', 'instrumented'])]
            state['limits'].append('native process CPU ticks and getrusage context switches are coarse scheduling diagnostics, not qualified speed claims')
        for name in ('baseline', 'candidate'):
            checkout = getattr(args, f'{name}_checkout').resolve(strict=True)
            binary = getattr(args, f'{name}_binary').resolve(strict=True)
            build_path = getattr(args, f'{name}_build_record').resolve(strict=True)
            smoke_path = checkout / 'scripts/grpc-load-smoke.py'
            ledger_path = checkout / 'scripts/dominance-ledger.py'
            smoke = module(f'{name}_callgrind_smoke', smoke_path)
            ledger = module(f'{name}_callgrind_ledger', ledger_path)
            build = smoke.verified_build(build_path, binary, checkout)
            if build['source']['commit'] != getattr(args, f'{name}_commit'):
                raise ValueError(f'{name} source differs from the explicitly requested commit')
            pin = dict(checkout=checkout, binary=binary, build_path=build_path,
                       smoke_path=smoke_path, ledger_path=ledger_path, smoke=smoke, ledger=ledger,
                       build=build, binary_hash=digest(binary), harness_hash=digest(smoke_path),
                       ledger_hash=digest(ledger_path))
            loaded[name] = pin
            directory = output / name
            directory.mkdir()
            shutil.copy2(smoke_path, directory / 'harness.py')
            shutil.copy2(ledger_path, directory / 'dominance-ledger.py')
            shutil.copy2(checkout / 'scripts/build-rpc-bench.py', directory / 'build-rpc-bench.py')
            build_copy = directory / 'build'
            build_copy.mkdir()
            for filename in ('build.json', 'build.stdout.jsonl', 'build.stderr.log'):
                shutil.copy2(build_path.parent / filename, build_copy / filename)
            state['versions'][name] = dict(source=build['source'], build_record=build,
                                           checkout=str(checkout), binary_sha256=pin['binary_hash'],
                                           harness_sha256=pin['harness_hash'], ledger_sha256=pin['ledger_hash'])
            for count in (args.count, args.count * 2):
                capture = directory / f'n-{count}'
                capture.mkdir()
                record = dict(schema='pbrs.load-smoke.v2', binary_sha256=pin['binary_hash'],
                              harness_script_sha256=pin['harness_hash'], campaign_controller_sha256=controller_hash,
                              harness_head=build['source']['commit'], harness_dirty=False,
                              head=build['source']['commit'], dirty=False, source_verified=True,
                              build_record=build, host=platform.uname()._asdict(),
                              cpu_affinity=sorted(os.sched_getaffinity(0)), seed=args.seed, cells=cells,
                              rpc_count=count, duration_per_cell_seconds=args.outer_timeout,
                              allocation_counts=True, context_switches=args.phase == 'native',
                              callgrind=str(valgrind) if valgrind else None,
                              strace=None, strace_version=None, qualification={'qualified': False}, runs=[])
                records[(name, count)] = record
                shutil.copy2(smoke_path, capture / 'harness.py')
                save(capture / 'manifest.json', record)
        if loaded['baseline']['build']['tools'] != loaded['candidate']['build']['tools']:
            raise ValueError('A/B requires matching recorded Rust and Cargo toolchains')
        if loaded['baseline']['harness_hash'] != loaded['candidate']['harness_hash']:
            raise ValueError('A/B must run exactly the same unchanged capture harness')
        if loaded['baseline']['ledger_hash'] != loaded['candidate']['ledger_hash']:
            raise ValueError('A/B must use exactly the same unchanged ledger interpretation')
        schedule = schedule_for(cells, args)
        state.update(state='running', schedule=schedule)
        save(output / 'campaign.json', state)
        for sequence, task in enumerate(schedule):
            name, count, index = task['version'], task['count'], task['cell_index']
            pin = loaded[name]
            # Pin checks before AND after each capture reject source, log, binary or harness drift.
            pin['smoke'].verified_build(pin['build_path'], pin['binary'], pin['checkout'])
            if digest(pin['smoke_path']) != pin['harness_hash'] or digest(pin['ledger_path']) != pin['ledger_hash']:
                raise ValueError(f'{name} harness or ledger changed before capture')
            directory = output / name / f'n-{count}'
            child = directory / f'cell-{index:03d}'
            settings = SimpleNamespace(binary=pin['binary'], source_checkout=pin['checkout'],
                                       duration=args.outer_timeout, rpc_count=count,
                                       allocation_counts=True, context_switches=args.phase == 'native',
                                       callgrind=valgrind, strace=None)
            began = time.monotonic()
            result = pin['smoke'].run_cell(settings, cells[index], child)
            elapsed = time.monotonic() - began
            for profile in child.glob('*.callgrind'):
                with profile.open('rb') as source, gzip.open(str(profile) + '.gz', 'xb') as zipped:
                    shutil.copyfileobj(source, zipped)
                profile.unlink()
            pin['smoke'].verified_build(pin['build_path'], pin['binary'], pin['checkout'])
            if digest(pin['smoke_path']) != pin['harness_hash'] or digest(pin['ledger_path']) != pin['ledger_hash']:
                raise ValueError(f'{name} harness or ledger changed after capture')
            if digest(Path(__file__).resolve()) != controller_hash:
                raise ValueError('campaign controller changed during captures')
            if args.cells_file and digest(args.cells_file) != state['workloads_input']['sha256']:
                raise ValueError('selected workload input changed during captures')
            records[(name, count)]['runs'].append(dict(path=f'{child.name}/run.json', passed=result['passed']))
            save(directory / 'partial-report.json', records[(name, count)])
            state['captures'].append(dict(sequence=sequence, **task, passed=result['passed'],
                                          duration_seconds=elapsed, path=str(child.relative_to(output) / 'run.json'),
                                          error=result.get('error')))
            save(output / 'campaign.json', state)
            print(json.dumps(state['captures'][-1]), flush=True)
        for name, pin in loaded.items():
            pin['smoke'].verified_build(pin['build_path'], pin['binary'], pin['checkout'])
            for count in (args.count, args.count * 2):
                record = records[(name, count)]
                record['binary_unchanged'] = digest(pin['binary']) == pin['binary_hash']
                record['source_unchanged'] = True
                record['harness_script_unchanged'] = digest(pin['smoke_path']) == pin['harness_hash']
                record['campaign_controller_unchanged'] = digest(Path(__file__).resolve()) == controller_hash
                record['passed'] = (len(record['runs']) == len(cells) and all(row['passed'] for row in record['runs'])
                                    and record['binary_unchanged'] and record['harness_script_unchanged']
                                    and record['campaign_controller_unchanged'])
                save(output / name / f'n-{count}' / 'report.json', record)
            if not args.pilot:
                compared = pin['ledger'].compare(output / name / f'n-{args.count}',
                                                 output / name / f'n-{args.count * 2}', allow_failed=True)
                save(output / name / 'ledger.json', compared)
        # Reuse the ledger's exact count/counter validation and differential calculation for source A/B.
        ledger = loaded['candidate']['ledger']
        captures = {}
        for name in loaded:
            captures[name] = [ledger.load(output / name / f'n-{count}', allow_failed=True)[1]
                              for count in (args.count, args.count * 2)]
        comparisons = []
        for cell in cells:
            identity = ledger.key(cell)
            for side, metric in itertools.product(('client', 'server'), ledger.REQUIRED_METRICS):
                row = dict(cell=cell, side=side, metric=metric, qualified=False,
                           native_side=cell['pair'][0 if side == 'client' else 2] == 'native',
                           baseline_per_rpc=None, candidate_per_rpc=None, ratio=None)
                endpoints = [captures[name][count][identity] for name in loaded for count in (0, 1)]
                row['failed_captures'] = [dict(path=x['capture_path'], error=x.get('error', 'incomplete RPC count'))
                                          for x in endpoints if not x['capture_complete']]
                if metric in ledger.METRICS and not row['failed_captures']:
                    for name in loaded:
                        row[f'{name}_per_rpc'] = ledger.differential(
                            captures[name][0][identity], captures[name][1][identity], side, metric, args.count)
                    if row['baseline_per_rpc'] is not None and row['candidate_per_rpc'] is not None:
                        row['ratio'] = row['candidate_per_rpc'] / row['baseline_per_rpc']
                band = .02 if metric == 'instructions' else 0
                row['disposition'] = ('failed_capture' if row['failed_captures'] else 'not_run' if row['ratio'] is None
                                      else 'regression' if row['ratio'] > 1 + band
                                      else 'improvement' if row['ratio'] < 1 - band else 'tie')
                comparisons.append(row)
        save(output / 'source-comparison.json', dict(qualified=False, rows=comparisons,
             instruction_band=0.02, missing_metrics=state['missing_metrics'],
             limits=state['limits'], source_pins=state['versions']))
        state.update(state='finished', passed=all(row['passed'] for row in state['captures']),
                     endpoint_capture_seconds=sum(row['duration_seconds'] for row in state['captures']),
                     duration_actual_seconds=time.monotonic() - campaign_started, host_after=host(),
                     finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(output / 'campaign.json', state)
        return 0 if state['passed'] else 1
    except BaseException as error:
        state.update(state='failed', passed=False, duration_actual_seconds=time.monotonic() - campaign_started,
                     host_after=host(), error=dict(type=type(error).__name__, message=str(error)))
        save(output / 'campaign.json', state)
        raise


if __name__ == '__main__':
    raise SystemExit(main())
