from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
pin='a3b1d4cced143de481d461c725d0ebda4ffcef26'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for old,new in [('architecture-c1-counter-ab-driver.py','architecture-c2-counter-ab-driver.py'),('architecture-c1-ab-summary.py','architecture-c2-ab-summary.py'),('architecture-c1-selected-native-workloads.json','architecture-c2-selected-native-workloads.json'),('architecture-c1-instruction-pilot-workload.json','architecture-c2-instruction-pilot-workload.json')]:
 (q/new).write_bytes((q/old).read_bytes())
replacements=[(str(root/'work/architecture-c1'),str(root/'work/architecture-c2')),('902014588792c8eb9c5bd65c782704e099535259',pin),('architecture-c1-rpc-build','architecture-c2-rpc-build'),('architecture-c1-counter-expanded','architecture-c2-counter-expanded'),('architecture-c1-counter-ab-driver.py','architecture-c2-counter-ab-driver.py'),('architecture-c1-selected-native','architecture-c2-selected-native'),('architecture-c1-instruction-pilot','architecture-c2-instruction-pilot')]
def replace(value):
 if isinstance(value,str):
  for old,new in replacements:value=value.replace(old,new)
  return value
 if isinstance(value,list):return [replace(v) for v in value]
 if isinstance(value,dict):return {key:replace(v) for key,v in value.items()}
 return value
record=replace(json.loads((q/'architecture-c1-measurement-plan.json').read_text()))
record.update(state='prepared_not_executed_C2_build_and_parent_quiet_grant_pending',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_note='FINALC2 source. All 902/C1 records remain historical and unchanged.')
record['harness_hashes']={f:digest(root/'work/architecture-c2'/f) for f in record['harness_hashes']}
record['controller_hashes']={f:digest(q/f) for f in ['architecture-c2-counter-ab-driver.py','architecture-c2-ab-summary.py']}
for phase in ['selected_native_ab','instruction_pilot']:
 argv=record[phase]['argv']+['--plan'];result=subprocess.run(argv,text=True,capture_output=True,check=True)
 (q/f'architecture-c2-{phase}-argv-plan.json').write_text(json.dumps(dict(argv=argv,result=json.loads(result.stdout)),indent=2)+'\n')
oversized=json.loads((q/'architecture-c2-oversized-plan.json').read_text())
for phase,row in oversized['phases'].items():
 argv=row.pop('argv_template')
 tokens={'C2_CHECKOUT_PENDING':str(root/'work/architecture-c2'),'C2_BINARY_PENDING':str(q/'architecture-c2-rpc-build/rpc-bench'),'C2_BUILD_RECORD_PENDING':str(q/'architecture-c2-rpc-build/build.json'),'C2_FULL_COMMIT_PENDING':pin,str(q/'architecture-c1-counter-ab-driver.py'):str(q/'architecture-c2-counter-ab-driver.py')}
 row['argv']=[tokens.get(arg,arg) for arg in argv]
 result=subprocess.run(row['argv']+['--plan'],text=True,capture_output=True,check=True)
 row['offline_plan']=json.loads(result.stdout)
 assert row['expected_captures']==row['offline_plan']['captures']
 assert row['expected_actual_rpc_calls']==row['offline_plan']['total_rpc_calls']
oversized['state']='PREPARED_NOT_EXECUTED_C2_BUILD_AND_PARENT_QUIET_GRANT_PENDING';oversized['candidate_source']=pin;oversized['driver']=str(q/'architecture-c2-counter-ab-driver.py');oversized['driver_sha256']=digest(q/'architecture-c2-counter-ab-driver.py')
(q/'architecture-c2-oversized-final-plan.json').write_text(json.dumps(oversized,indent=2)+'\n');record['oversized_diagnostic']=str(q/'architecture-c2-oversized-final-plan.json')
record['limits']+=['C2 includes correctness and memory-safety changes; preserve every new regression, failure, unavailable counter and actual completed-work count.','The old902/C1 candidate build is never used as the final candidate.','Oversized diagnostics run a pilot first; report runtime and failures before the full120capture run.','No measurements until root grants a quiet host after all builds/tests finish.']
(q/'architecture-c2-measurement-plan.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(state=record['state'],candidate=record['sources']['candidate'],baseline_build=record['builds']['baseline'],phases={key:record[key]['expected_captures'] for key in ['native_expanded','selected_native_ab','instruction_pilot']},oversized={key:row['expected_captures'] for key,row in oversized['phases'].items()}),indent=2))
