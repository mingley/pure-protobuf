from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
variants=[('candidate',root/'work/architecture-c4',q/'architecture-c4-rpc-build','804b5c593fc209cbc5714fd3e77710b54711cc63'),('baseline',root/'work/architecture-b4',q/'architecture-b4-rpc-build','2eba72d86b4bb7db133120797e3c4746d86713bc')]
result=dict(qualified=False,no_endpoint_measurement_executed=True,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),variants={})
for name,checkout,build,pin in variants:
 smoke=module('preflight_'+name,checkout/'scripts/grpc-load-smoke.py');record=smoke.verified_build(build/'build.json',build/'rpc-bench',checkout)
 assert record['source']['commit']==pin,(name,record['source']['commit'])
 result['variants'][name]=dict(checkout=str(checkout),build_directory=str(build),source=record['source'],binary_sha256=digest(build/'rpc-bench'),build_record_sha256=digest(build/'build.json'),tools=record['tools'],harness_hashes={f:digest(checkout/f) for f in ['scripts/grpc-load-smoke.py','scripts/grpc-counter-campaign.py','scripts/dominance-ledger.py','scripts/build-rpc-bench.py']})
assert result['variants']['candidate']['tools']==result['variants']['baseline']['tools']
assert result['variants']['candidate']['harness_hashes']==result['variants']['baseline']['harness_hashes']
result['controller_hashes']={f:digest(q/f) for f in ['architecture-c4-counter-ab-driver.py','architecture-c4-ab-summary.py']}
pins_path=q/'architecture-c4-source-pins.json'
pins=json.loads(pins_path.read_text())
result['source_pins_record_sha256']=digest(pins_path)
result['runtime_equivalence']={}
for name,checkout,build,pin in variants:
 runtime=pins[name+'_runtime']
 subprocess.run(['git','diff','--exit-code',runtime,pin,'--',*pins['runtime_tree_equivalence']],cwd=checkout,check=True,capture_output=True)
 main_hash=digest(checkout/'rpc-bench/src/main.rs')
 assert main_hash==pins['identical_benchmark_sha256']
 result['runtime_equivalence'][name]=dict(runtime_source=runtime,benchmark_source=pin,unchanged_runtime_paths=pins['runtime_tree_equivalence'],benchmark_main_sha256=main_hash,sparse_checkout_patterns=subprocess.check_output(['git','sparse-checkout','list'],cwd=checkout,text=True).splitlines())
benchmark_differences=subprocess.check_output(['git','diff','--name-only',pins['baseline_benchmark'],pins['candidate_benchmark'],'--','rpc-bench'],cwd=root/'work/architecture-c4',text=True).splitlines()
assert set(benchmark_differences) <= {'rpc-bench/Cargo.lock'}
result['benchmark_source_difference_paths']=benchmark_differences
result['benchmark_source_equivalence']='All rpc-bench tracked source files are identical; only its Cargo.lock differs with runtime dependency graph.'
result['matched_benchmark_settings']=dict(native_server_send_buffer_bytes=400*1024,tonic_server_send_buffer='Hyper1.11 default400KiB',native_request_queue=16,tonic_request_queue=16,observability='Native production instrumentation remains enabled.')
result['state']='both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED'
(q/'architecture-c4-build-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
