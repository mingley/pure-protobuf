from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,shutil
base=Path('/workspace/pure-protobuf/work');q=base/'qualification';cwd=base/'architecture-c3';pin='783bcd53c723032cd0ccbff5d4550f9a1c92cbb8'
state_path=q/'architecture-c3-independent-gates-state.json'
state={'status':'starting independent gates under explicit root grant','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'workspace_test_gate':'FAILED; independent lint/docs checks do not certify workspace tests','workspace_observation':'architecture-c3-workspace-observed.json','completed':[]}
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def source():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)}
save();assert source()=={'head':pin,'status':''}
rust=[str(base/'run-rust'),'cargo','+stable'];env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(base/'stable-target'),CARGO_BUILD_JOBS='1')
checks=[
 ('architecture-c3-clippy-root',rust+['clippy','--locked','--all-targets','--all-features','--','-D','warnings'],{}),
 ('architecture-c3-clippy-grpc-lib',rust+['clippy','--locked','--lib','--all-features','-p','pbrs-grpc','-p','protobuf-tonic','-p','pbrs-grpc-example-greeter','--','-D','warnings'],{}),
 ('architecture-c3-clippy-grpc-alltargets',rust+['clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'],{}),
 ('architecture-c3-rustdoc',rust+['doc','--locked','--workspace','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'}),
]
for name,command,extra in checks:
 assert source()=={'head':pin,'status':''}
 assert not (q/f'{name}.json').exists(),name
 assert shutil.disk_usage('/workspace').free>=2*1024**3,'disk below required 2 GiB floor'
 state['status']='running '+name;save();print(state['status'],flush=True)
 task_env=env.copy();task_env.update(extra)
 result=subprocess.run([sys.executable,str(base/'record.py'),str(q/name),'1200',*command],cwd=cwd,env=task_env)
 end=source();state['completed'].append({'name':name,'exit_code':result.returncode,'source_at_completion':end});save()
 assert end=={'head':pin,'status':''},end
state['status']='finished; shared stable-target released';state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(state['status'],flush=True)
sys.exit(0 if all(row['exit_code']==0 for row in state['completed']) else 1)
