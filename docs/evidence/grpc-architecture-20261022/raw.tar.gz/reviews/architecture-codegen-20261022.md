# Code generation and codec architecture audit

Inspected source: `6d236a65cbd4f7e539877466d6cc969a601aa974` (read-only).
The audit stage performed no compilation, profiling or source edits. File/line
references below identify the inspected revision. A later authorized candidate
change is recorded at the end. The day on `6cd91911` later failed after 32 min 2.73 s; it does not qualify
the later `90201458` architecture candidate. The source inspection below remains
pinned to `6d236a65`.

The largest codec redesign opportunity is to stop validating a nested tree and
then reconstructing/revalidating that same tree as getters are called. Keep
lazy storage for sparse/forwarding workloads, but offer an explicit eager
construction path for handlers that read everything. First normalize generated
server dispatch and benchmark handler work so that changes can be attributed.
This is separate from the current large gzip allocation-byte losses: those also
occur with prost and require transport/compression attribution.

## Findings and priorities

| Priority | Finding | Concrete next change |
|---|---|---|
| 1 | Lazy nested decode still repeats work on full traversal. | Add an explicit generated eager mode using the existing eager merge arm; benchmark it before selecting any default. |
| 1 | Native pbrs and native prost generators build different server future shapes. | Give prost stubs the same selected-method `call_boxed` hook; measure future bytes, allocations and instructions. |
| 2 | Raw spans carry ownership but no type-enforced validation proof. | Introduce an internal validated-span contract before adding any unchecked materialization path. |
| 2 | Repeated message parsing discards the supplied shared-wire context. | Propagate checked child backing where retention policy permits; measure copies and retained parent bytes separately. |
| 3 | Generated code duplicates parse/validation/formatting work across types. | Separate wire-only and full-feature profiles, share metadata, and qualify table-driven wide-message emission. |

## PK-26: the original getter mechanism is already fixed

Current hot/cold getters use a function-local `OnceLock<T>` and
`unwrap_or_else`, so a present field never evaluates the absent default:
`src/codegen/messages.rs:733`, `:749`. Bundled output has the same pattern at
`src/generated/test_messages_proto3.rs:7650`. These statics are per generated
getter, not one global TypeId registry. `View::default()` also uses its own
OnceLock (`src/gen_support.rs:773`).

The old mutex/TypeId implementation remains as the compatibility helper
`default_instance_of` (`src/gen_support.rs:23`), but no current generated getter
calls it. The card's original diagnosis is stale for newly generated code.
Its requested current-source instruction improvement and regeneration acceptance
are not proved by this audit; do not close the card from source inspection.

## PK-27: the structural cause remains; the old magnitude is not current proof

All ordinary singular length-delimited message fields are classified lazy;
there is no eager/lazy workload policy in `is_lazy_msg`
(`src/codegen/naming.rs:491`). Storage becomes `LazyMsg<T>`
(`src/codegen/messages.rs:80`). Parsing the first occurrence validates the whole
child subtree, creates another child window and boxes lazy state
(`src/codegen/parse.rs:608`). Later, `LazyMsg::as_deref` constructs `T` and calls
`merge_inner` again (`src/lazy.rs:733`). That merge validates lazy descendants
again. A fully read nested chain can repeatedly walk successively smaller
subtrees; aggregate work can grow roughly quadratically with nesting depth.
The validator checks strings (`src/codegen/parse.rs:392`); materialization checks
the same UTF-8 again (`src/lazy.rs:224`). Packed fields similarly validate input
then decode to a cached vector when iterated (`src/packed.rs:307`, `:365`).

Ownership adds work: `Wire::window` clones an Arc or slices `Bytes`
(`src/lazy.rs:134`), and `LazyMsg` boxes a OnceLock plus optional raw wire
(`src/lazy.rs:676`). A read-only materialized node can retain both its raw wire
and constructed representation; cloning clones both states (`:783`). Some leaf
copy policies deliberately release large parents, so this is not uniformly a
second full byte copy. Measure retention, rather than count references as bytes.

PK-27's recorded 2–5x/Any-heavy losses came from `18e36617` and a private corpus,
not this HEAD (`docs/plan/world-class/tasks.json:9271`, adoption notes). Current
code confirms repeated work, not those exact ratios. Public recursive/Any
corpora now exist (`bench/devloop/adoption/src/corpus.rs:571`), and the RPC lane
actually reads every field with equal checksums
(`bench/devloop/src/adoption_rpc.rs:33`). Entity reads also unpack and inspect
Any payloads on both sides (`corpus.rs:342`, `:367`). These are the right replay
inputs; fixture qualification alone is not a current performance measurement.

## Recommended codec implementation sequence

1. Add an opt-in generated eager mode first, without an automatic heuristic.
   Reuse the existing eager singular-message branch
   (`src/codegen/parse.rs:614`) and `Option<Box<T>>` storage. Generate the same
   schema into lazy/eager modules and keep public accessor behavior identical.
   Eager mode must propagate across the reachable graph; forcing only the root
   to construct children leaves their descendants lazy. Keep strings/bytes
   ownership and packed-array choices explicit rather than label everything
   “eager” after changing only message boxes.
2. Preserve lazy mode, but make validated input explicit. An internal
   `ValidatedSpan<T>` needs immutable backing, checked offsets, matching schema,
   inherited depth/required/UTF-8/closed-enum policy and complete span consumption.
   Only a successful validator may create it. Then a materializer may avoid
   repeating checks already proved for that exact span. Mutation, duplicate-field
   merging and unknown/extension handling must invalidate or compose that proof.
   This is not permission to remove validation from public decode.
3. Reduce owner churn after measuring the first two steps. Repeated messages
   currently call children with `sw = None` even under shared root parsing
   (`src/codegen/parse.rs:553`); maps also create fresh child slots (`:760`).
   Root `parse_bytes` already provides shared backing
   (`src/gen_support.rs:925`), and native gRPC calls it
   (`pbrs-grpc/src/codec.rs:74`). Propagating a checked child window can avoid
   copies, but can pin a large parent for a tiny surviving field. Keep the
   existing sparse-field copy policy or a measured replacement.

Important safety boundary: `LazyMsg::from_wire` is public and takes raw `Wire`
(`src/lazy.rs:695`); its getter/mutator ignores `merge_inner` errors (`:742`,
`:769`). Generated RPC parsing validates first, but the invariant is conventional,
not encoded in that constructor. A new fast materializer must not accept
arbitrary raw spans or silently turn a validation error into partial/default
state. The generic `MergeBytes::validate_inner` fallback constructs a `T`
(`src/lazy.rs:666`); generic callers must not assume it is a cheap scan.

“Owned” also needs precise accounting: `parse(&[u8])` may create private backing
(`src/lazy.rs:62`), while `parse_bytes(Bytes)` can retain shared input. Generated
`FooView<'a>` wraps `&'a Foo` (`src/gen_support.rs:737`); it is not a separately
parsed borrowed wire view. Compare equal ownership/lifetime contracts, and
account for retained input when measuring a forwarding or borrowed path.

## Dispatch and generated size

Native pbrs stubs select the method before boxing its future
(`src/codegen/native_stubs.rs:861`). Both Single and Router servers consume
that hook (`pbrs-grpc/src/server/dispatch.rs:80`, `:119`). Prost stubs only emit
one `async fn call` containing every method (`src/codegen/prost_stubs.rs:225`),
so the default boxes the combined state machine. This is a concrete parity gap:
outer future storage can depend on unrelated RPC wrapper states. User handler
futures are already boxed by `run_handler_fut` (`server/rpc.rs:1637`), so a large
user handler is not evidence of a correspondingly large outer dispatch future.
Both hooks still allocate a box; this does not explain all allocation losses.
Also test path/alias/unknown-method parity: the generators match `rpc.path()`
and `rpc.method()` respectively. Generated clients are already thin typed
Channel calls with static paths (`native_stubs.rs:1644`); replacing these with
another dynamic dispatch layer has no demonstrated benefit. Prost codec
wrapping already writes directly into the native sink
(`pbrs-grpc/src/codec/prost.rs:41`). Preserve that interoperability boundary.

Generated messages emit separate merge, validator, size/encode and optional
JSON/text/reflection bodies (`src/codegen/messages.rs:609`). Defaults enable
JSON/text, while `Config::no_reflect` and separate format switches already exist
(`src/codegen/config.rs:1249`). The typed table engine exists
(`src/table.rs:548`), but the current generator does not emit a `merge_table`
call. Use shared loops for wide/cold types while retaining measured small-message
specializations; include validator generation in source-size accounting.

Do not repeat old compile-cost ratios as current facts. SB-09's 34.1 MB versus
413 KB on its 1,000-message corpus is historical
(`docs/evidence/sb09-codegen-matrix.md:104`). Later WKT sharing and opt-in shared
descriptors already reduce duplication; GN-03 records 35.8 MB to 19.3 MB without
claiming compile-time improvement (`docs/evidence/gn-03-source-sharing.md:36`).
Compare wire-only profiles with equivalent prost work and full-feature profiles
with equivalent reflection/formatting support; do not remove features to produce
an unlabeled win. Re-run source bytes, clean/incremental check, release RSS,
build time and executable size after a concrete generator change.

## Tests and measurements that decide the redesign

Use parse-only, read-one, read-all, clone-before/after-touch, mutate/re-encode and
forward-without-touch separately. Pair slice input and shared Bytes input fairly.
Reuse 48 recursive query variants (depths 3–8), 10/100/1,000 Any-bearing records,
128-field sparse messages and 8/64/512-entry maps. Add long/deep chains, packed
arrays and ASCII/non-ASCII strings. Keep exact read checksums, malformed nested
input, required/presence/oneof/duplicate merges, unknown/closed enums, map/group
recursion and mutation-cache correctness in every mode.

For dispatch, generate 1/10/100-method services with different typed RPC wrapper
states; compare generated direct/selected hooks and Single/Router serving.
Do not infer outer state size from already-boxed user-handler futures.
Record future allocation size, instructions and allocations, plus codegen/build
cost. For RPC codec comparisons, use the same minimal handler implementation.
The current pbrs interop handler builds a response-plan Vec and handles echo,
delay and status (`pbrs-grpc/src/testing.rs:99`, `:241`); native prost benchmark
handlers are separate (`rpc-bench/src/native_prost.rs:253`). Preserve full interop
coverage, but keep that application work out of a transport-only attribution.

## Subsequent implementation and validation scope

Candidate `902014588792c8eb9c5bd65c782704e099535259` now implements the
selected-method prost hook with conversion logic shared by the direct hook.
The corrected generated RouteGuide consumer exercises all four shapes,
unknown status and Single/Router serving.

`work/qualification/architecture-c1-codegen-layout.stdout` records selected
unary/chat futures of **1,808/88 bytes**, versus **2,976/2,976 bytes** through
the generated direct hook. Its JSON record identifies a dirty `87fa88c1`
preparation snapshot. This is actual compiled-consumer evidence from that
snapshot, not an exact-source execution of `90201458` or a wall-time win.

An earlier 64 KiB user-handler-bloat assertion failed because the RPC layer
already boxes that state. The original failure remains retained as a test-design
error. The corrected control compares identical unary service/data across the
generated hooks, without an arbitrary size threshold.

The old `6cd91911` day failed at cycle 586, seed 20261588, TCP bidi reset at
`BodyStarted`: INTERNAL instead of CANCELLED/UNAVAILABLE. Two thousand eight
scenario replays did not uniquely reproduce it. Candidate independent-peer
controls preserve actual reset reasons on failed DATA, empty-EOS, try-send and
trailer writes and check mappings across 15 reasons; they do not prove the
unique cause of the old failure. Clean-half-close local misuse remains INTERNAL.

Complete native/adapter compressed-input handling and a default 1,024-member/
frame budget also ship in `90201458`. No eager/lazy codec representation or
validation-proof redesign has been applied. Fresh validation and measurements
must describe the new candidate; the old day and old performance captures do not.
