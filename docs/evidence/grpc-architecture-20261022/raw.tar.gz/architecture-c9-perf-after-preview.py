from pathlib import Path
import datetime,json,subprocess,time
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';journal=q/'architecture-c9-perf-queue-state.json';grant='root-c9-after-passed-full-suite-and-resource-preview-20261023'
def save(state,**extra):
 p=journal.with_suffix('.tmp');p.write_text(json.dumps({'state':state,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'quiet_grant':grant,**extra},indent=2)+'\n');p.replace(journal)
def load(p):
 try:return json.loads(p.read_text())
 except(FileNotFoundError,json.JSONDecodeError):return {}
def busy():
 found=[]
 for proc in Path('/proc').glob('[0-9]*'):
  try:
   if proc.joinpath('stat').read_text().rsplit(')',1)[1].split()[0]=='Z':continue
   argv=[v.decode(errors='replace')for v in proc.joinpath('cmdline').read_bytes().rstrip(b'\0').split(b'\0')]
   if argv and(Path(argv[0]).name in {'cargo','rustc','rust-lld','cc','gcc','clang','valgrind','rpc-bench'}or any(Path(v).name=='grpc-resource-campaign.py'for v in argv[:3])):found.append({'pid':int(proc.name),'argv':argv})
  except(OSError,PermissionError):pass
 return found
save('waiting_for_genuine_workspace_and_preview')
while True:
 full=load(q/'architecture-c9-workspace-final-state.json');preview=load(q/'architecture-c9-resource-preview-state.json')
 if full.get('passed')is False:save('workspace_failed_no_captures');raise SystemExit(1)
 if preview.get('state')=='failed':save('preview_failed_no_captures');raise SystemExit(1)
 if full.get('passed')is True and preview.get('state')=='passed':
  active=busy()
  if not active:break
  save('waiting_for_idle_build_and_resource_processes',active_processes=active)
 time.sleep(2)
save('launching_captures',workspace_totals=full['totals'],preview_report=preview['report'],active_processes=[])
argv=['python3',str(q/'architecture-c9-launch-supervisor.py'),'--quiet-grant',grant]
result=subprocess.run(argv,cwd=r,capture_output=True,text=True)
(q/'architecture-c9-perf-queue-launch.stdout').write_text(result.stdout);(q/'architecture-c9-perf-queue-launch.stderr').write_text(result.stderr)
save('captures_launched'if result.returncode==0 else'capture_launch_failed',command=argv,launch_exit_code=result.returncode)
raise SystemExit(result.returncode)
