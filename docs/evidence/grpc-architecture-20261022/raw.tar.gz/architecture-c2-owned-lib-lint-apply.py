from pathlib import Path
root=Path('pbrs-grpc/src')
p=root/'client/call.rs';s=p.read_text().replace('cancel_requested(&cancel_rx)','cancel_requested(cancel_rx)').replace('''    let remaining = match remaining_timeout(deadline) {
        Ok(remaining) => outgoing_timeout(timeout, remaining),
        Err(status) => return Err(status),
    };''','''    let remaining = outgoing_timeout(timeout, remaining_timeout(deadline)?);''');p.write_text(s)
p=root/'keepalive.rs';s=p.read_text().replace('''    if interval.is_none() {
        return None;
    }
''','''    interval?;
''');p.write_text(s)
p=root/'limits.rs';s=p.read_text().replace('''        if self.inner.limit.is_none() {
            return self.acquire_unlimited(bytes);
        }
        self.acquire_limited(bytes)''','''        match self.inner.limit {
            None => self.acquire_unlimited(bytes),
            Some(limit) => self.acquire_limited(bytes, limit),
        }''',1).replace('fn acquire_limited(&self, bytes: usize)', 'fn acquire_limited(&self, bytes: usize, limit: usize)').replace('        let limit = self.inner.limit.expect("capped budget");\n','',1);p.write_text(s)
p=root/'channelz/model.rs';s=p.read_text().replace('''// Client and server sockets are noted from the same task. Two slots''','''type CachedSocket = (*const Registry, u64, Arc<SocketEntry>);
type HotSocketSlots = [Option<CachedSocket>; 2];

// Client and server sockets are noted from the same task. Two slots''',1).replace('UnsafeCell<[Option<(*const Registry, u64, Arc<SocketEntry>)>; 2]>','UnsafeCell<HotSocketSlots>').replace('fn hot_socket_slots() -> *mut [Option<(*const Registry, u64, Arc<SocketEntry>)>; 2]', 'fn hot_socket_slots() -> *mut HotSocketSlots').replace('        let _ = HOT_SOCKETS.try_with(|cell| {','''        // The thread-local cache may already have been destroyed at shutdown.
        let _cache_cleanup = HOT_SOCKETS.try_with(|cell| {''',1);p.write_text(s)
p=root/'request.rs';s=p.read_text().replace('''    #[inline]
    pub(crate) fn apply_outbound(''','''    #[inline]
    #[allow(
        clippy::too_many_arguments,
        reason = "stamp the existing outbound overlays in place without moving response maps"
    )]
    pub(crate) fn apply_outbound(''',1);p.write_text(s)
p=root/'client/streaming.rs';s=p.read_text().replace('''    fn stream_mut(&mut self) -> &mut backend::SendStream {''','''    #[expect(
        clippy::expect_used,
        reason = "send access ends before the guard transfers its stream into the completion holder"
    )]
    fn stream_mut(&mut self) -> &mut backend::SendStream {''',1).replace('            let _ = pump_task.await;', '            let _pump_result = pump_task.await;',1)
for name,reason in [('box_bidi_rest','build the cold encoded-upload future from the existing transport and call state'),('box_bidi_live','build the cold live-upload future from the existing transport and call state'),('run_bidi','dispatch the opened stream with its upload, cancellation, deadline, and resource state'),('run_bidi_live','own the opened stream and independent upload with call cancellation and deadline state')]:
 token=('async fn ' if name.startswith('run_') else 'fn ')+name+'<'
 assert s.count(token)==1,(name,s.count(token))
 s=s.replace(token, '#[allow(\n    clippy::too_many_arguments,\n    reason = "'+reason+'"\n)]\n'+token,1)
p.write_text(s)
