from pathlib import Path
import datetime,hashlib,importlib.util,json
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
variants=[('candidate',root/'work/architecture-c3',q/'architecture-c3-rpc-build','783bcd53c723032cd0ccbff5d4550f9a1c92cbb8'),('baseline',root/'work/validation-fixes',q/'architecture-c1-baseline-rpc-build','6cd91911afce24cceee6df3f60a945453e5b04da')]
result=dict(qualified=False,no_endpoint_measurement_executed=True,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),variants={})
for name,checkout,build,pin in variants:
 smoke=module('preflight_'+name,checkout/'scripts/grpc-load-smoke.py');record=smoke.verified_build(build/'build.json',build/'rpc-bench',checkout)
 assert record['source']['commit']==pin,(name,record['source']['commit'])
 result['variants'][name]=dict(checkout=str(checkout),build_directory=str(build),source=record['source'],binary_sha256=digest(build/'rpc-bench'),build_record_sha256=digest(build/'build.json'),tools=record['tools'],harness_hashes={f:digest(checkout/f) for f in ['scripts/grpc-load-smoke.py','scripts/grpc-counter-campaign.py','scripts/dominance-ledger.py','scripts/build-rpc-bench.py']})
assert result['variants']['candidate']['tools']==result['variants']['baseline']['tools']
assert result['variants']['candidate']['harness_hashes']==result['variants']['baseline']['harness_hashes']
result['controller_hashes']={f:digest(q/f) for f in ['architecture-c3-counter-ab-driver.py','architecture-c3-ab-summary.py']}
result['state']='both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED'
(q/'architecture-c3-build-preflight.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
