#![allow(dead_code)]
mod resolver { pub enum ResolvedAddress { Tcp(std::net::SocketAddr), Unix(std::path::PathBuf), UnixAbstract(Vec<u8>) } }
mod channelz {
#[path = "/workspace/pure-protobuf/work/qualification/architecture-c2-channelz-identity-control/current/trace.rs"] mod trace;
#[path = "/workspace/pure-protobuf/work/qualification/architecture-c2-channelz-identity-control/current/model.rs"] mod model;
}
