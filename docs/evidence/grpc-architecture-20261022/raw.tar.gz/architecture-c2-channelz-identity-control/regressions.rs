
#[cfg(test)]
mod regression_control {
    use super::*;
    #[test]
    fn default_registry_ids_start_at_one() {
        for registry in [Registry::default(), Registry::new()] {
            let registry = Arc::new(registry);
            let first = registry.register_channel("first", "test:///first");
            let second = registry.register_channel("second", "test:///second");
            assert_eq!(first.id().get(), 1);
            assert_eq!(second.id().get(), 2);
        }
    }

    #[test]
    fn socket_cache_cannot_alias_replaced_registry_after_cross_thread_drop() {
        // A dedicated thread starts with an empty TLS cache. The Box provides
        // deterministic address reuse through safe in-place replacement.
        std::thread::spawn(|| {
            let make_entry = || {
                let source = Arc::new(Registry::new());
                let socket = source.register_socket(
                    SocketParent::Channel(ChannelId(1)),
                    None,
                    None,
                    None,
                    SocketSecurity::None,
                    false,
                );
                source.socket(socket.id()).expect("registered socket")
            };
            let old_entry = make_entry();
            let new_entry = make_entry();
            assert_eq!(old_entry.id, new_entry.id, "local ids intentionally repeat");
            let mut registry = Box::new(Registry::new());
            let address = std::ptr::from_ref(registry.as_ref());
            registry
                .sockets
                .write()
                .expect("sockets")
                .insert(old_entry.id.0, Arc::clone(&old_entry));
            registry.note_messages(old_entry.id, true, 1);
            let old = std::mem::replace(registry.as_mut(), Registry::new());
            std::thread::spawn(move || drop(old))
                .join()
                .expect("drop old registry");
            assert_eq!(std::ptr::from_ref(registry.as_ref()), address);
            registry
                .sockets
                .write()
                .expect("sockets")
                .insert(new_entry.id.0, Arc::clone(&new_entry));
            registry.note_messages(new_entry.id, true, 3);
            assert_eq!(
                old_entry
                    .messages_sent
                    .load(std::sync::atomic::Ordering::Relaxed),
                1,
                "the old thread-local entry must not receive replacement events"
            );
            assert_eq!(
                new_entry
                    .messages_sent
                    .load(std::sync::atomic::Ordering::Relaxed),
                3,
                "the replacement registry must receive its own events"
            );
        })
        .join()
        .expect("cache worker");
    }

}
