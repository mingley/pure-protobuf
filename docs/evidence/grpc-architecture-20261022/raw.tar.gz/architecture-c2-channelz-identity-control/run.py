from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
root=Path('/workspace/pure-protobuf');out=root/'work/qualification/architecture-c2-channelz-identity-control';wrapper=root/'work/run-rust'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def execute(prefix,argv):
 t=time.monotonic()
 with (out/(prefix+'.stdout')).open('w') as so,(out/(prefix+'.stderr')).open('w') as se:
  try:r=subprocess.run(argv,env=dict(os.environ,RUSTUP_TOOLCHAIN='stable'),cwd=root,stdout=so,stderr=se,timeout=60);code=r.returncode
  except subprocess.TimeoutExpired:code=124
 rec=dict(argv=argv,cwd=str(root),exit_code=code,elapsed_seconds=time.monotonic()-t,guard_seconds=60)
 (out/(prefix+'.json')).write_text(json.dumps(rec,indent=2)+'\n');return code
current=(root/'pbrs-grpc/src/channelz/model.rs').read_text();a=current.index('    #[test]\n    fn default_registry_ids_start_at_one');b=current.index('    #[test]\n    fn ids_are_positive_ordered_and_never_reused',a)
tests='\n#[cfg(test)]\nmod regression_control {\n    use super::*;\n'+current[a:b]+'}\n';(out/'regressions.rs').write_text(tests)
manifest=dict(recorded_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),classification='Source-copied std-only functional negative/positive controls, no Cargo, performance or full-library qualification.',regression_sha256=digest(out/'regressions.rs'),variants={})
for name,checkout in [('old902',root/'work/architecture-c1'),('current',root)]:
 d=out/name;d.mkdir(exist_ok=True)
 paths={f:checkout/'pbrs-grpc/src/channelz'/f for f in ['model.rs','trace.rs']}
 before={f:digest(p) for f,p in paths.items()}
 # Preserve the complete model source including its pre-existing tests;
 # append identical private-field regression controls to both variants.
 (d/'model.rs').write_text(paths['model.rs'].read_text()+tests)
 (d/'trace.rs').write_bytes(paths['trace.rs'].read_bytes())
 harness='''#![allow(dead_code)]
mod resolver { pub enum ResolvedAddress { Tcp(std::net::SocketAddr), Unix(std::path::PathBuf), UnixAbstract(Vec<u8>) } }
mod channelz {
'''+f'#[path = "{d}/trace.rs"] mod trace;\n#[path = "{d}/model.rs"] mod model;\n'+'}\n'
 (d/'control.rs').write_text(harness);binary=d/'control'
 row=dict(source_checkout=str(checkout),original_source_sha256=before,compiled_files_sha256={f:digest(d/f) for f in ['control.rs','model.rs','trace.rs']})
 manifest['variants'][name]=row
 argv=[str(wrapper),'rustc','--edition=2024','--test','--crate-name','channelz_identity_control','-C','opt-level=0','-C','debuginfo=0',str(d/'control.rs'),'-o',str(binary)]
 row['compile_exit']=execute(name+'-compile',argv)
 if row['compile_exit']!=0:
  (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');raise SystemExit('compile failure '+name)
 row['binary_sha256']=digest(binary)
 row['test_exit']=execute(name+'-run',[str(binary),'channelz::model::regression_control::','--test-threads=1','--nocapture'])
 row['source_unchanged']={f:digest(p) for f,p in paths.items()}==before
 assert row['source_unchanged']
 (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
assert manifest['variants']['old902']['test_exit']==101
assert manifest['variants']['current']['test_exit']==0
manifest['state']='expected_old_two_failures_and_current_two_passes';(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({name:{k:row[k] for k in ['compile_exit','test_exit','source_unchanged','binary_sha256']} for name,row in manifest['variants'].items()},indent=2))
