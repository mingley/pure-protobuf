import datetime,hashlib,json,os,re,subprocess,sys,time
from pathlib import Path
r=Path('/workspace/pure-protobuf'); q=r/'work/qualification'; pin=sys.argv[1]; prefix=q/'architecture-c8-workspace-final'
def git(*args): return subprocess.check_output(['git',*args],cwd=r,text=True).strip()
def source(): return {'head':git('rev-parse','HEAD'),'status':git('status','--porcelain','--untracked-files=all')}
before=source(); assert before=={'head':pin,'status':''},before
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(r/'work/stable-target'),CARGO_BUILD_JOBS='2')
command=[sys.executable,str(r/'work/record.py'),str(prefix),'5400',str(r/'work/run-rust'),'cargo','+stable','test','--locked','--workspace','--all-features','--no-fail-fast','--','--test-threads=4']
state={'source_before':before,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'command':command,'jobs':2,'test_workers':4,'cpu_quota_cores':4,'qualification':False}
(q/'architecture-c8-workspace-final-state.json').write_text(json.dumps(state,indent=2)+'\n')
result=subprocess.run(command,cwd=r,env=env)
state.update(source_after=source(),recorder_exit_code=result.returncode,completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
record=json.loads(prefix.with_suffix('.json').read_text()); state['cargo_exit_code']=record['exit_code']; state['duration_seconds']=record['duration_seconds']
state['summaries']=[{'status':s,'passed':int(a),'failed':int(b),'ignored':int(c)} for s,a,b,c in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',prefix.with_suffix('.stdout').read_text())]
state['totals']={k:sum(v[k] for v in state['summaries']) for k in ('passed','failed','ignored')}; state['targets']=len(state['summaries'])
state['logs']={f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in (prefix.with_suffix('.stdout'),prefix.with_suffix('.stderr'))}
state['passed']=result.returncode==0 and state['source_after']==before
(q/'architecture-c8-workspace-final-state.json').write_text(json.dumps(state,indent=2)+'\n')
sys.exit(0 if state['passed'] else 1)
