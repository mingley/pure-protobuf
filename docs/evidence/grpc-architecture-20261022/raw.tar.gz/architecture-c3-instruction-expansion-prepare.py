from pathlib import Path
import hashlib,importlib.util,json
from types import SimpleNamespace
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';driver=q/'architecture-c3-counter-ab-driver.py'
spec=importlib.util.spec_from_file_location('instruction_plans',driver);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
main=json.loads((q/'architecture-c3-measurement-plan.json').read_text());pilot=main['instruction_pilot']['argv'];base=pilot[:pilot.index('--output')]
scopes=[('client_stream',65536,'gzip'),('bidi',65536,'gzip'),('unary',1024,'identity'),('bidi_pipelined',65536,'gzip')]
plans={}
for label,scope_count in [('focused72',2),('with_unary108',3),('with_pipeline144',4)]:
 cells=[dict(pair=list(pair),shape=shape,payload_bytes=payload,tls=False,compression=compression,connections=1,in_flight=1)
  for shape,payload,compression in scopes[:scope_count] for pair in m.PAIRS[2:]]
 path=q/f'architecture-c3-instruction-{label}-workloads.json';path.write_text(json.dumps(cells,indent=2)+'\n')
 args=SimpleNamespace(cells_file=path,repeats=3,pilot=False,scope='selected',seed=20261022,count=10,abba=False)
 expanded=m.cells_for(args);schedule=m.schedule_for(expanded,args)
 assert len(schedule)==scope_count*3*3*4
 assert len({(r['version'],r['count'],json.dumps(expanded[r['cell_index']],sort_keys=True)) for r in schedule})==len(schedule)
 argv=base+['--output',str(q/f'architecture-c3-instruction-{label}'),'--phase','callgrind','--scope','selected','--cells-file',str(path),'--repeats','3','--count','10','--valgrind',str(root/'work/toolchain/valgrind/usr/bin/valgrind'),'--valgrind-lib',str(root/'work/toolchain/valgrind/usr/libexec/valgrind')]
 plans[label]=dict(argv=argv,expected_captures=len(schedule),expected_actual_rpc_calls=sum(row['count'] for row in schedule),scope_count=scope_count,source_repeats=3,count=10,count2=20,supervisor_seconds=900,workloads_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),schedule=schedule,requires_root_followup=True)
record=dict(state='PREPARED_NOT_RUN_ROOT_SELECTION_AFTER_INSTRUCTION_PILOT_REQUIRED',qualified=False,candidate=main['sources']['candidate'],baseline=main['sources']['baseline'],pilot_plan=main['instruction_pilot'],options=plans,
selection=dict(budget_seconds=900,formula='pilot_elapsed_seconds / 4 * planned_captures * 2.0 * 1.3',work_factor=2.0,archive_host_variation_factor=1.3,reason='Pilot is 64 KiB gzip client-streaming with tiny final response. Bidi/pipeline add four compressed responses; use a conservative factor of 2 until measured.',if_no_option_fits='Ask root to choose a smaller explicitly scoped set or retain pilot-only NOT_RUN gaps. Do not alter per-RPC/readiness/teardown/outer60s deadlines.'),
limits=['Every scope includes native/pbrs server, native/prost server and a fresh same-side tonic/prost server reference driven by tonic/prost client, for both sources.',
'Three repeated N/2N pairs per source; workload/source/count order randomized by the unchanged driver. No balanced ABBA flag because its block design requires even repeat counts.',
'Instruction counts are small-N diagnostics with the existing 2% ledger band. All failures, nonpositive deltas, missing counters and losses remain. No native speed or broad-superiority claim.',
'Both endpoints profiled and raw Callgrind profiles retained compressed; native context-switch/syscall/task-wakeup counters are absent in this profiler phase.',
'Use paired-source ratio ranges and source medians separately; compare native and tonic from the same fresh profile set.',
'Pbrs and prost handlers have different application logic; cross-codec differences do not isolate codec cost.',
'No capture is authorized by this preparation record.'])
(q/'architecture-c3-instruction-expansion-plan.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({label:{k:row[k] for k in ['expected_captures','expected_actual_rpc_calls']} for label,row in plans.items()},indent=2))
