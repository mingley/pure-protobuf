"""Verify the final C8 source/build only after the parent supplies its pin."""
from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--verify-only',action='store_true');args=parser.parse_args()
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def module(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
pins_path=q/'architecture-c8-source-pins.json';pins=json.loads(pins_path.read_text())
variants=[('candidate',root/'work/architecture-c8',q/'architecture-c8-rpc-build',pins['candidate_benchmark']),('baseline',root/'work/architecture-b4',q/'architecture-b4-rpc-build',pins['baseline_benchmark'])]
result=dict(qualified=False,no_endpoint_measurement_executed=True,verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),variants={},source_pins_record_sha256=digest(pins_path),runtime_equivalence={})
for name,checkout,build,pin in variants:
 smoke=module('preflight_'+name,checkout/'scripts/grpc-load-smoke.py');record=smoke.verified_build(build/'build.json',build/'rpc-bench',checkout)
 assert record['source']['commit']==pin
 result['variants'][name]=dict(checkout=str(checkout),build_directory=str(build),source=record['source'],binary_sha256=digest(build/'rpc-bench'),build_record_sha256=digest(build/'build.json'),tools=record['tools'],harness_hashes={f:digest(checkout/f) for f in ['scripts/grpc-load-smoke.py','scripts/grpc-counter-campaign.py','scripts/dominance-ledger.py','scripts/build-rpc-bench.py']})
 runtime=pins[name+'_runtime'];paths=pins['runtime_tree_equivalence']
 subprocess.run(['git','diff','--exit-code',runtime,pin,'--',*paths],cwd=checkout,check=True,capture_output=True)
 main_hash=digest(checkout/'rpc-bench/src/main.rs');assert main_hash==pins['identical_benchmark_sha256']
 result['runtime_equivalence'][name]=dict(runtime_source=runtime,benchmark_source=pin,unchanged_runtime_paths=paths,benchmark_main_sha256=main_hash)
assert result['variants']['candidate']['tools']==result['variants']['baseline']['tools']
assert result['variants']['candidate']['harness_hashes']==result['variants']['baseline']['harness_hashes']
differences=subprocess.check_output(['git','diff','--name-only',pins['baseline_benchmark'],pins['candidate_benchmark'],'--','rpc-bench'],cwd=root/'work/architecture-c8',text=True).splitlines();assert set(differences)<={'rpc-bench/Cargo.lock'}
result['benchmark_source_difference_paths']=differences
result['controller_hashes']={f:digest(q/f) for f in ['architecture-c8-counter-ab-driver.py','architecture-c8-ab-summary.py']}
result['matched_benchmark_settings']=dict(native_server_send_buffer_bytes=400*1024,tonic_server_send_buffer='Hyper1.11 default400KiB',native_request_queue=16,tonic_request_queue=16,observability='Native production channelz remains enabled.')
result['state']='both_clean_source_builds_verified_NO_MEASUREMENTS_STARTED'
if not args.verify_only:
 gate_path=q/'architecture-c8-workspace-disk-ready.json';gate=json.loads(gate_path.read_text())
 assert gate['source']==pins['candidate_benchmark'] and gate['cache_reclaimed'] is True
 result['workspace_disk_gate']=gate;result['workspace_disk_gate_sha256']=digest(gate_path)
output=q/('architecture-c8-build-verification.json' if args.verify_only else 'architecture-c8-build-preflight.json')
output.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
