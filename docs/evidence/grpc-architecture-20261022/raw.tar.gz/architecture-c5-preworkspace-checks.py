from pathlib import Path
import os,sys,json,subprocess,datetime,hashlib,shutil
base=Path('/workspace/pure-protobuf/work');root=base.parent;q=base/'qualification';pin='e210c67983fab1ea1731074b8506e60aadddc3e9'
state_path=q/'architecture-c5-preworkspace-state.json'
state={'status':'starting exclusive pre-workspace phase','started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_pin':pin,'controls_terminal_observation':str(q/'architecture-c5-fixture-controls/terminal-observed.json'),'completed':[]}
def save():state_path.write_text(json.dumps(state,indent=2)+'\n')
def source():return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain'],cwd=root,text=True)}
save();assert source()=={'head':pin,'status':''}
rust=[str(base/'run-rust'),'cargo','+stable'];common=os.environ.copy();common.update(CARGO_TARGET_DIR=str(base/'stable-target'),CARGO_BUILD_JOBS='1')
checks=[
 ('architecture-c5-clippy-grpc-alltargets',rust+['clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'],{},1200),
 ('architecture-c5-examples',rust+['build','--locked','--workspace','--examples'],{},1200),
 ('architecture-c5-rpc-benchmark-correctness',rust+['test','--locked','--manifest-path','rpc-bench/Cargo.toml','--bin','rpc-bench','--test','worker','--test','fairness','--test','tonic_fairness'],{},1800),
 ('architecture-c5-tonic-benchmark-correctness',rust+['test','--locked','--manifest-path','tonic-bench/Cargo.toml','--bin','tonic-bench'],{'PURE_PROTOBUF_CHECKED_V4':'1'},1800),
]
for name,command,extra,timeout in checks:
 assert source()=={'head':pin,'status':''}
 assert not (q/f'{name}.json').exists(),name
 assert shutil.disk_usage('/workspace').free>=2*1024**3,'disk below 2 GiB floor'
 state['status']='running '+name;save();print(state['status'],flush=True)
 env=common.copy();env.update(extra)
 result=subprocess.run([sys.executable,str(base/'record.py'),str(q/name),str(timeout),*command],cwd=root,env=env)
 end=source();state['completed'].append({'name':name,'exit_code':result.returncode,'source_at_completion':end});save()
 if result.returncode or end!={'head':pin,'status':''}:
  state['status']='stopped on first failure; stable-target released';state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(state['status'],flush=True);sys.exit(result.returncode or 2)
state['status']='all pre-workspace checks passed; stable-target released';state['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(state['status'],flush=True)
