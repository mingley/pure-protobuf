from pathlib import Path
import datetime,hashlib,json,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
pin='783bcd53c723032cd0ccbff5d4550f9a1c92cbb8'
for stem in ['counter-ab-driver.py','ab-summary.py','selected-native-workloads.json','instruction-pilot-workload.json','counter-summary.py','native-ab-summary.py','legacy-summary.py','oversized-workloads.json','oversized-pilot-workload.json']:
 (q/('architecture-c3-'+stem)).write_bytes((q/('architecture-c2-'+stem)).read_bytes())
def replace(value):
 if isinstance(value,str):return value.replace('architecture-c2','architecture-c3').replace('a3b1d4cced143de481d461c725d0ebda4ffcef26',pin).replace('FINALC2','FINALC3')
 if isinstance(value,list):return [replace(v) for v in value]
 if isinstance(value,dict):return {replace(k):replace(v) for k,v in value.items()}
 return value
record=replace(json.loads((q/'architecture-c2-measurement-plan.json').read_text()))
record.update(state='prepared_not_executed_C3_build_and_parent_quiet_grant_pending',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),candidate_note='FINALC3 source. All C1/C2 source preparation, builds and controls remain unchanged historical checkpoints.')
record['limits']=[limit.replace('C2 includes','C3 includes') for limit in record['limits']]
record['limits'].append('C3 includes the owned upload panic guard and exact-source qualification; no C2 binary is substituted for the final candidate.')
record['controller_hashes']={f:hashlib.sha256((q/f).read_bytes()).hexdigest() for f in record['controller_hashes']}
record['harness_hashes']={f:hashlib.sha256((root/'work/architecture-c3'/f).read_bytes()).hexdigest() for f in record['harness_hashes']}
for phase in ['selected_native_ab','instruction_pilot']:
 argv=record[phase]['argv']+['--plan'];result=subprocess.run(argv,text=True,capture_output=True,check=True)
 (q/f'architecture-c3-{phase}-argv-plan.json').write_text(json.dumps(dict(argv=argv,result=json.loads(result.stdout)),indent=2)+'\n')
oversized=replace(json.loads((q/'architecture-c2-oversized-final-plan.json').read_text()))
oversized['state']='PREPARED_NOT_EXECUTED_C3_BUILD_AND_PARENT_QUIET_GRANT_PENDING';oversized['driver_sha256']=hashlib.sha256((q/'architecture-c3-counter-ab-driver.py').read_bytes()).hexdigest()
for phase,row in oversized['phases'].items():
 result=subprocess.run(row['argv']+['--plan'],text=True,capture_output=True,check=True);row['offline_plan']=json.loads(result.stdout)
 assert row['expected_captures']==row['offline_plan']['captures']
 assert row['expected_actual_rpc_calls']==row['offline_plan']['total_rpc_calls']
(q/'architecture-c3-oversized-final-plan.json').write_text(json.dumps(oversized,indent=2)+'\n')
(q/'architecture-c3-measurement-plan.json').write_text(json.dumps(record,indent=2)+'\n')
preflight=(q/'architecture-c2-build-preflight.py').read_text().replace('architecture-c2','architecture-c3').replace('a3b1d4cced143de481d461c725d0ebda4ffcef26',pin)
(q/'architecture-c3-build-preflight.py').write_text(preflight)
print(json.dumps(dict(state=record['state'],candidate=record['sources']['candidate'],baseline_build=record['builds']['baseline'],phases={key:record[key]['expected_captures'] for key in ['native_expanded','selected_native_ab','instruction_pilot']},oversized={key:row['expected_captures'] for key,row in oversized['phases'].items()}),indent=2))
