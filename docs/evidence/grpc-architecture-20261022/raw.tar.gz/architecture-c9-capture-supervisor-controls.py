#!/usr/bin/env python3
"""Offline orchestration controls: no endpoint, profiler, Cargo or capture is run."""
import importlib.util
import json
from pathlib import Path
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

PATH = Path(__file__).with_name('architecture-c9-capture-supervisor.py')
spec = importlib.util.spec_from_file_location('capture_supervisor', PATH)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


class Controls(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.q = Path(self.tmp.name)
        self.patch_q = patch.object(m, 'Q', self.q)
        self.patch_q.start()
        self.addCleanup(self.patch_q.stop)
        self.qualification_record = dict(measured_source=m.CANDIDATE, qualification_source=m.QUALIFICATION)
        self.original_equivalence = m.qualification_equivalence
        qualification_patch = patch.object(m, 'qualification_equivalence', return_value=self.qualification_record)
        qualification_patch.start()
        self.addCleanup(qualification_patch.stop)
        self.s = m.Supervisor.__new__(m.Supervisor)
        self.s.args = SimpleNamespace(quiet_grant='offline-control-NOT-A-QUIET-GRANT')
        self.s.rows = {'selected_native_ab': dict(argv=['python3', 'controller.py', '--output', str(self.q / 'campaign')],
                                                expected_captures=4, expected_actual_rpc_calls=60)}
        self.s.master = {'summaries': {}}
        self.s.state = {'phases': {}, 'summaries': {}}
        self.s.preflight = lambda: None
        self.events = []
        self.s.event = lambda event, **details: self.events.append((event, details))

    def gate_fixture(self):
        source = dict(head=self.qualification_record['qualification_source'], status='')
        state = dict(passed=True, source_before=source, source_after=source, cargo_exit_code=0,
                     recorder_exit_code=0, jobs=2, test_workers=4, totals=dict(passed=100, failed=0))
        record = dict(exit_code=0, command=[str(m.ROOT / 'work/run-rust'), 'cargo', '+stable', 'test',
                      '--locked', '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4'],
                      environment=dict(CARGO_BUILD_JOBS='2'))
        for name, value in [('workspace-final-state', state), ('workspace-final', record),
                            ('asan-supervisor-state', dict(state='passed', source_before=dict(head=m.CANDIDATE, status=''))),
                            ('workspace-disk-ready', dict(source=m.CANDIDATE, cache_reclaimed=True, asan_checks_passed=True))]:
            prefix = 'architecture-c9' if name.startswith('workspace-final') else 'architecture-c8'
            (self.q / f'{prefix}-{name}.json').write_text(json.dumps(value))

    def change_gate(self, name, **fields):
        prefix = 'architecture-c9' if name.startswith('workspace-final') else 'architecture-c8'
        path = self.q / f'{prefix}-{name}.json'
        value = json.loads(path.read_text())
        value.update(fields)
        path.write_text(json.dumps(value))

    def test_genuine_final_workspace_and_asan_gate_pass(self):
        self.gate_fixture()
        m.qualification_gates()

    def test_superseded_workspace_pass_cannot_substitute_final(self):
        self.gate_fixture()
        (self.q / 'architecture-c9-workspace-final-state.json').unlink()
        (self.q / 'architecture-c8-checks-state.json').write_text(json.dumps(dict(state='passed')))
        with self.assertRaises(FileNotFoundError):
            m.qualification_gates()

    def test_final_recorder_failure_blocks_capture(self):
        self.gate_fixture()
        self.change_gate('workspace-final-state', recorder_exit_code=1)
        with self.assertRaisesRegex(RuntimeError, 'genuine final workspace PASS'):
            m.qualification_gates()

    def test_final_source_mismatch_blocks_capture(self):
        self.gate_fixture()
        self.change_gate('workspace-final-state', source_after=dict(head='old-source', status=''))
        with self.assertRaisesRegex(RuntimeError, 'genuine final workspace PASS'):
            m.qualification_gates()

    def test_changed_final_test_command_blocks_capture(self):
        self.gate_fixture()
        self.change_gate('workspace-final', command=['cargo', 'test'])
        with self.assertRaisesRegex(RuntimeError, 'genuine final workspace PASS'):
            m.qualification_gates()

    def test_unreclaimed_asan_cache_gate_blocks_capture(self):
        self.gate_fixture()
        self.change_gate('workspace-disk-ready', cache_reclaimed=False)
        with self.assertRaisesRegex(RuntimeError, 'ASAN PASS/cache-reclaimed'):
            m.qualification_gates()

    def equivalence_fixture(self, paths=None, measured_source=None, forged_diff=False):
        import hashlib
        diff = b'fixture-only diff bytes'
        value = dict(measured_source=measured_source or m.CANDIDATE, qualification_source=m.QUALIFICATION,
                     changed_paths=['pbrs-grpc/tests/serving.rs'],
                     diff_sha256=hashlib.sha256(b'forged' if forged_diff else diff).hexdigest())
        (self.q / 'architecture-c9-qualification-source.json').write_text(json.dumps(value))
        return ['pbrs-grpc/tests/serving.rs'] if paths is None else paths, diff

    def test_fixture_only_equivalence_proof_passes(self):
        paths, diff = self.equivalence_fixture()
        with patch.object(m.subprocess, 'check_output', side_effect=['\n'.join(paths), diff]):
            self.assertEqual(self.original_equivalence()['qualification_source'], m.QUALIFICATION)

    def test_production_source_difference_rejects_reused_runtime(self):
        paths, diff = self.equivalence_fixture(paths=['pbrs-grpc/src/server.rs', 'pbrs-grpc/tests/serving.rs'])
        with patch.object(m.subprocess, 'check_output', return_value='\n'.join(paths)):
            with self.assertRaisesRegex(RuntimeError, 'ONLY pbrs-grpc/tests/serving.rs'):
                self.original_equivalence()

    def test_forged_fixture_diff_attestation_rejected(self):
        paths, diff = self.equivalence_fixture(forged_diff=True)
        with patch.object(m.subprocess, 'check_output', side_effect=['\n'.join(paths), diff]):
            with self.assertRaisesRegex(RuntimeError, 'attestation mismatch'):
                self.original_equivalence()

    def test_wrong_measured_runtime_rejected(self):
        self.equivalence_fixture(measured_source='b' * 40)
        with self.assertRaisesRegex(RuntimeError, 'explicit measured source9d required'):
            self.original_equivalence()

    def phase_fixture(self, passed=True, terminal=True):
        name = 'selected_native_ab'
        prefix = self.q / 'architecture-c8-selected-native-ab-run'
        launch = dict(quiet_grant=self.s.args.quiet_grant, phase=name, pid=999999999, proc_start_ticks=1,
                      command=['python3', 'record.py', str(prefix), '60', *self.s.rows[name]['argv']], supervisor_seconds=60)
        (self.q / (prefix.name + '-launch.json')).write_text(json.dumps(launch))
        if terminal:
            prefix.with_suffix('.json').write_text(json.dumps(dict(command=self.s.rows[name]['argv'], exit_code=0 if passed else 1,
                                                                   duration_seconds=3)))
        campaign = self.q / 'campaign'
        campaign.mkdir()
        (campaign / 'campaign.json').write_text(json.dumps(dict(state='finished' if passed else 'failed', passed=passed,
                                                               expected_captures=4)))
        return prefix

    def test_completed_phase_is_validated_without_relaunch(self):
        self.phase_fixture()
        with patch.object(m.subprocess, 'run', side_effect=AssertionError('capture launch forbidden')):
            self.assertEqual(self.s.phase('selected_native_ab')['state'], 'PASSED')
            self.assertEqual(self.s.phase('selected_native_ab')['state'], 'PASSED')

    def test_failed_phase_stops_and_never_retries(self):
        self.phase_fixture(passed=False)
        with patch.object(m.subprocess, 'run', side_effect=AssertionError('capture launch forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'capture phase failed'):
                self.s.phase('selected_native_ab')
            self.assertEqual(self.s.state['phases']['selected_native_ab']['state'], 'FAILED')
            with self.assertRaisesRegex(RuntimeError, 'cannot be retried'):
                self.s.phase('selected_native_ab')

    def test_dead_recorder_without_terminal_never_relaunches(self):
        self.phase_fixture(terminal=False)
        with patch.object(m, 'proc_alive', return_value=False), patch.object(m, 'matching_controllers', return_value=[]), \
             patch.object(m.subprocess, 'run', side_effect=AssertionError('capture launch forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'died without a terminal'):
                self.s.phase('selected_native_ab')

    def test_ambiguous_launch_gap_stops(self):
        (self.q / 'architecture-c8-selected-native-ab-run-wrapper.stdout').touch()
        with patch.object(m.subprocess, 'run', side_effect=AssertionError('capture launch forbidden')):
            with self.assertRaisesRegex(RuntimeError, 'incomplete phase launch evidence'):
                self.s.phase('selected_native_ab')

    def test_altered_campaign_cannot_be_adopted(self):
        self.phase_fixture()
        self.s.phase('selected_native_ab')
        path = self.q / 'campaign/campaign.json'
        value = json.loads(path.read_text())
        value['unreviewed'] = True
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(RuntimeError, 'campaign changed'):
            self.s.phase('selected_native_ab')

    def test_altered_launch_cannot_be_adopted(self):
        self.phase_fixture()
        self.s.phase('selected_native_ab')
        path = self.q / 'architecture-c8-selected-native-ab-run-launch.json'
        value = json.loads(path.read_text())
        value['extra'] = True
        path.write_text(json.dumps(value))
        with self.assertRaisesRegex(RuntimeError, 'launch metadata changed'):
            self.s.phase('selected_native_ab')

    def cpu(self, seconds):
        self.s.state['phases']['instruction_pilot'] = {'duration_seconds': seconds}
        self.s.rows.update({'cpu_' + key: {'expected_captures': count} for key, count in
                            [('with_pipeline144', 144), ('with_unary108', 108), ('focused72', 72), ('fallback32', 32), ('fallback24', 24)]})
        return self.s.choose_cpu()

    def test_fast_pilot_selects_one_broadest_cpu_scope(self):
        value = self.cpu(4)
        self.assertEqual(value['option'], 'with_pipeline144')
        self.assertEqual(value['supervisor_seconds'], 890)

    def test_middle_pilot_prefers_four_repeat_abba_fallback(self):
        self.assertEqual(self.cpu(20)['option'], 'fallback32')

    def test_slow_pilot_chooses_three_randomized_repeats(self):
        self.assertEqual(self.cpu(80)['option'], 'fallback24')

    def test_no_cpu_scope_fits_preserves_not_run(self):
        value = self.cpu(120)
        self.assertIsNone(value['option'])
        self.assertEqual(value['state'], 'NOT_RUN')

    def test_saved_cpu_choice_is_not_replanned_on_resume(self):
        value = self.cpu(20)
        self.assertEqual(self.cpu(4), value)

    def summary(self, successful=30):
        name = 'selected_native_ab'
        output = self.q / 'summary.json'
        self.s.master['summaries'][name] = ['python3', 'summary.py', '--output', str(output)]
        accounting = dict(offered_rpcs=30, dispatched_rpcs=30, completed_rpcs=30, successful_rpcs=successful,
                          failed_rpcs=0, timeouts=0, queue_overflows=0, unstarted_rpcs=0, unfinished_rpcs=0)
        output.write_text(json.dumps(dict(passed=True, qualified=False, actual_rpc_totals=dict(baseline=accounting, candidate=accounting))))
        return output

    def test_successful_summary_validates_actual_work(self):
        self.summary()
        with patch.object(m.subprocess, 'run', side_effect=AssertionError('summary execution unnecessary')):
            self.s.summarize('selected_native_ab')
        self.assertEqual(self.s.state['summaries']['selected_native_ab']['actual_completed_rpcs'], 60)
        self.assertEqual(self.events[-1][0], 'EARLY_SELECTED_SUMMARY_READY')

    def test_successful_flag_cannot_hide_dropped_work(self):
        self.summary(successful=29)
        with self.assertRaisesRegex(RuntimeError, 'successful RPC count mismatch'):
            self.s.summarize('selected_native_ab')

    def test_changed_summary_refuses_resume(self):
        output = self.summary()
        self.s.summarize('selected_native_ab')
        output.write_text(output.read_text() + '\n')
        with self.assertRaisesRegex(RuntimeError, 'summary changed'):
            self.s.summarize('selected_native_ab')


if __name__ == '__main__':
    unittest.main(verbosity=2)
