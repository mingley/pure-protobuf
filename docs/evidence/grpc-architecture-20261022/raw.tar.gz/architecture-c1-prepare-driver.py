from pathlib import Path
p=Path('work/qualification/architecture-c1-counter-ab-driver.py')
s=Path('work/qualification/callgrind-streaming-driver.py').read_text()
s=s.replace('"""Source-pinned, separate-endpoint Callgrind diagnostics; never qualification."""','"""Source-pinned selected native/Callgrind A/B diagnostics; never qualification."""',1)
s=s.replace("BASELINE_COMMIT = '8fe0f8aeb41356ff427f44542947f36f6d2a2dae'", "BASELINE_COMMIT = '6cd91911afce24cceee6df3f60a945453e5b04da'",1)
start=s.index('def cells_for(args):');end=s.index('\n\ndef main():',start)
s=s[:start]+'''def cells_for(args):
    if args.cells_file:
        workloads = json.loads(args.cells_file.read_text())
        if not isinstance(workloads, list) or not workloads:
            raise ValueError('selected workloads must be a nonempty JSON list')
        keys = {'pair', 'shape', 'payload_bytes', 'tls', 'compression', 'connections', 'in_flight'}
        seen = set()
        for cell in workloads:
            if (not isinstance(cell, dict) or set(cell) != keys
                    or tuple(cell['pair']) not in PAIRS
                    or cell['shape'] not in ['unary', 'server_stream', 'client_stream', 'bidi', 'bidi_pipelined']
                    or cell['payload_bytes'] not in [0, 1024, 65536, 1048576]
                    or type(cell['tls']) is not bool
                    or cell['compression'] not in ['identity', 'gzip']
                    or type(cell['connections']) is not int or not 1 <= cell['connections'] <= 64
                    or type(cell['in_flight']) is not int or not cell['connections'] <= cell['in_flight'] <= 1024):
                raise ValueError('workload outside unchanged harness bounds')
            identity = tuple((key, tuple(cell[key]) if key == 'pair' else cell[key]) for key in sorted(keys))
            if identity in seen:
                raise ValueError('duplicate selected workload')
            seen.add(identity)
        cells = [dict(cell, repeat=repeat) for cell, repeat in itertools.product(workloads, range(args.repeats))]
        if args.pilot:
            cells = [dict(workloads[0], repeat=0)]
    else:
        pairs = PAIRS if args.scope == 'full' else PAIRS[2:]
        shapes = SHAPES if args.scope == 'full' else ['bidi', 'bidi_pipelined']
        cells = [dict(pair=list(pair), shape=shape, payload_bytes=1024, tls=False,
                      compression=compression, connections=1, in_flight=1, repeat=repeat)
                 for pair, shape, compression, repeat in itertools.product(
                     pairs, shapes, ['identity', 'gzip'], range(args.repeats))]
        if args.pilot:
            cells = [cell for cell in cells if cell['pair'] == ['tonic', 'prost', 'native', 'pbrs']
                     and cell['shape'] == 'bidi' and cell['compression'] == 'gzip' and cell['repeat'] == 0]
    random.Random(args.seed).shuffle(cells)
    return cells


def schedule_for(cells, args):
    rng = random.Random(args.seed ^ 0xABBA)
    if args.pilot:
        versions = ['baseline', 'candidate']
        rng.shuffle(versions)
        counts = [args.count, args.count * 2]
        rng.shuffle(counts)
        return [dict(version=name, count=count, cell_index=0) for name, count in
                [(versions[0], counts[0]), (versions[1], counts[0]),
                 (versions[1], counts[1]), (versions[0], counts[1])]]
    if args.abba:
        if args.repeats % 2:
            raise ValueError('balanced ABBA blocks require an even repeat count')
        groups = {}
        for index, cell in enumerate(cells):
            key = json.dumps({k: v for k, v in cell.items() if k != 'repeat'}, sort_keys=True)
            groups.setdefault(key, {})[cell['repeat']] = index
        blocks = [(indexes, repeat) for indexes in groups.values() for repeat in range(0, args.repeats, 2)]
        rng.shuffle(blocks)
        schedule = []
        for indexes, repeat in blocks:
            versions = ['baseline', 'candidate']
            rng.shuffle(versions)
            for name, rep in [(versions[0], repeat), (versions[1], repeat),
                              (versions[1], repeat + 1), (versions[0], repeat + 1)]:
                counts = [args.count, args.count * 2]
                rng.shuffle(counts)
                schedule.extend(dict(version=name, count=count, cell_index=indexes[rep]) for count in counts)
        return schedule
    schedule = []
    for index, cell in enumerate(cells):
        versions = ['baseline', 'candidate']
        rng.shuffle(versions)
        for name in versions:
            counts = [args.count, args.count * 2]
            rng.shuffle(counts)
            schedule.extend(dict(version=name, count=count, cell_index=index) for count in counts)
    return schedule
''' +s[end:]
s=s.replace("    parser.add_argument('--valgrind', type=Path, required=True)","    parser.add_argument('--valgrind', type=Path)",1).replace("    parser.add_argument('--valgrind-lib', type=Path, required=True)","    parser.add_argument('--valgrind-lib', type=Path)",1)
s=s.replace("    parser.add_argument('--scope', choices=['full', 'server-streaming'], default='full',", "    parser.add_argument('--phase', choices=['native', 'callgrind'], default='callgrind')\n    parser.add_argument('--cells-file', type=Path)\n    parser.add_argument('--abba', action='store_true')\n    parser.add_argument('--scope', choices=['full', 'server-streaming', 'selected'], default='full',",1)
s=s.replace("    cells = cells_for(args)\n", "    if args.phase == 'callgrind' and (args.valgrind is None or args.valgrind_lib is None):\n        parser.error('Callgrind requires both executable and library paths')\n    if args.scope == 'selected' and args.cells_file is None:\n        parser.error('selected scope needs --cells-file')\n    cells = cells_for(args)\n",1)
s=s.replace("pilot=args.pilot, scope=args.scope, cells_per_source=len(cells),", "pilot=args.pilot, scope=args.scope, phase=args.phase, abba=args.abba or args.pilot, cells_per_source=len(cells),",1)
s=s.replace("                              tls=False, payload_bytes=1024), indent=2))", "                              payloads=sorted({cell['payload_bytes'] for cell in cells}),\n                              tls=sorted({cell['tls'] for cell in cells})), indent=2))",1)
s=s.replace("                 pilot=args.pilot, scope=args.scope, small_n=", "                 phase=args.phase, abba=args.abba or args.pilot, pilot=args.pilot, scope=args.scope, small_n=",1)
s=s.replace("                 missing_metrics=['syscalls', 'context_switches', 'task_wakeups', 'native latency/goodput'],", "                 missing_metrics=(['syscalls', 'context_switches', 'task_wakeups', 'native latency/goodput'] if args.phase == 'callgrind' else ['instructions', 'syscalls', 'task_wakeups', 'qualified native latency/goodput']),",1)
s=s.replace("                         '1 KiB zero-filled synthetic payloads, h2c, one connection/in-flight RPC, four streaming messages',", "                         'synthetic zero-filled payloads and exact selected scopes are recorded in cells; four streaming messages',",1)
s=s.replace("        os.environ['VALGRIND_LIB'] = str(args.valgrind_lib.resolve(strict=True))\n        valgrind = args.valgrind.resolve(strict=True)\n        state['tools'] = dict(valgrind=str(valgrind), valgrind_sha256=digest(valgrind),\n                              valgrind_lib=os.environ['VALGRIND_LIB'],\n                              version=subprocess.check_output([str(valgrind), '--version'], text=True).strip())", "        valgrind = None\n        if args.phase == 'callgrind':\n            os.environ['VALGRIND_LIB'] = str(args.valgrind_lib.resolve(strict=True))\n            valgrind = args.valgrind.resolve(strict=True)\n            state['tools'] = dict(valgrind=str(valgrind), valgrind_sha256=digest(valgrind),\n                                  valgrind_lib=os.environ['VALGRIND_LIB'],\n                                  version=subprocess.check_output([str(valgrind), '--version'], text=True).strip())\n        else:\n            state['tools'] = dict(native=True)\n            state['limits'] = [limit for limit in state['limits'] if not any(word in limit for word in ['Callgrind', 'profiler', 'instrumented'])]\n            state['limits'].append('native process CPU ticks and getrusage context switches are coarse scheduling diagnostics, not qualified speed claims')",1)
s=s.replace("                              allocation_counts=True, context_switches=False, callgrind=str(valgrind),", "                              allocation_counts=True, context_switches=args.phase == 'native',\n                              callgrind=str(valgrind) if valgrind else None,",1)
start=s.index('        schedule = []\n        rng = random.Random(args.seed ^ 0xABBA)',s.index('def main():'));end=s.index("        state.update(state='running', schedule=schedule)",start)
s=s[:start]+"        schedule = schedule_for(cells, args)\n"+s[end:]
s=s.replace("                                       allocation_counts=True, context_switches=False,", "                                       allocation_counts=True, context_switches=args.phase == 'native',",1)
p.write_text(s)
print(p)
