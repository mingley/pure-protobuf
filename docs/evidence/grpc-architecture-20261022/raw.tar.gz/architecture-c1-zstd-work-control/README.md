# Zstd per-frame allocation control

Completed 24 bounded controls: both modes, 1/2/64/256/1,024/4,096 frames,
64 KiB and 8 MiB logical windows. Every process exited successfully and had
zero tracked live bytes on return. Limits per case: 256 MiB address space,
10 CPU seconds, 64 file descriptors, 60-second wall timeout.

At 4,096 valid empty frames (36,864 encoded bytes):

| Strategy | Window | Allocations | Requested bytes | Peak live bytes |
|---|---:|---:|---:|---:|
| Fresh per frame | 64 KiB or 8 MiB | 49,152 | 36,192,256 | 8,836 |
| Reuse within message | 64 KiB | 13 | 74,373 | 74,373 |
| Reuse within message | 8 MiB | 13 | 8,397,445 | 8,397,445 |

`runs.json` retains all commands, stdout/stderr, caps, source/binary/dependency
hashes and diagnostic wall times. `build.*` records the optimized rustc build
which reused the existing unoptimized ruzstd dependency rlib. This is an
allocation diagnostic of the two backend API strategies, not an RPC benchmark
or a final source-pinned shipping-kernel test. The old 6cd resource day remained
active; no timing or RSS superiority is claimed.

The maximum legal 4 MiB encoded example was not executed. Linear extrapolation
from the measured fresh strategy gives 5,592,396 allocations and 4,117,867,588
requested bytes for 466,033 empty frames. Reuse removes that per-frame churn;
it has a larger per-message peak because reset eagerly reserves its window.

`source-snapshot.json` records the exact fresh-per-frame native implementation
before the reuse change. The tree was dirty; these snapshots are a control,
not source-pinned release evidence.

The probe compares the same `ruzstd 0.9.0` API with a fresh FrameDecoder per frame
and with one decoder reset/reused within the message. Both paths validate each
frame's completion and must produce zero bytes from the independently specified
valid nine-byte empty raw frame with an 8 MiB window. The allocator counts total
requests, reallocations, requested bytes, and peak live bytes. Payload creation
and report formatting occur outside the tracking interval.

The fresh backend creates fixed FSE/Huffman workspaces per frame; its advertised
window is initially lazy. Reusing resets reserves the window once, so inspect
peak memory as well as total allocation. Counts are capped at 4,096 frames.
A legal encoded payload below 4 MiB can hold 466,033 such frames; do not execute
that maximum just to demonstrate the linear mechanism.

Optional standalone Cargo rebuild after the coordinator releases a compile slot:

```sh
CARGO_TARGET_DIR=/workspace/pure-protobuf/work/zstd-work-target /workspace/pure-protobuf/work/run-rust cargo +stable build --offline --release --manifest-path /workspace/pure-protobuf/work/qualification/architecture-c1-zstd-work-control/probe/Cargo.toml
```

The recorded build used rustc directly with the cached ruzstd rlib instead.
The exact command is in build.json. `run-probe.py` runs the 24 bounded controls
against that retained binary, with per-case caps. Nothing in this directory
changes the running day or its source pin.
