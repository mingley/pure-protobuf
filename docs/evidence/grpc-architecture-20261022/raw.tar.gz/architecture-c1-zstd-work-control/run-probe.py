#!/usr/bin/env python3
"""Run only bounded allocation controls under finite per-process limits."""
from pathlib import Path
import datetime,hashlib,json,resource,subprocess,time
out=Path(__file__).resolve().parent
binary=out/'probe-bin'
def digest(path):
 with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()
def caps():
 resource.setrlimit(resource.RLIMIT_AS,(256*1024*1024,)*2)
 resource.setrlimit(resource.RLIMIT_CPU,(10,10))
 resource.setrlimit(resource.RLIMIT_NOFILE,(64,64))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
rows=[]
for window in [65536,8388608]:
 for count in [1,2,64,256,1024,4096]:
  for mode in ['fresh','reused']:
   command=[str(binary),mode,str(count),str(window)];start=time.monotonic()
   try:
    child=subprocess.run(command,capture_output=True,text=True,timeout=60,preexec_fn=caps)
    row={'command':command,'exit_code':child.returncode,'stdout':child.stdout,'stderr':child.stderr,'wall_seconds_diagnostic':time.monotonic()-start}
    if child.returncode==0:row['result']=json.loads(child.stdout)
   except Exception as error:row={'command':command,'error':str(error),'wall_seconds_diagnostic':time.monotonic()-start}
   rows.append(row)
   (out/'runs.json').write_text(json.dumps({'qualified':False,'state':'running','binary_sha256':digest(binary),'rows':rows},indent=2)+'\n')
report={'qualified':False,'state':'completed','utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'binary_sha256':digest(binary),'source_sha256':digest(out/'probe/src/main.rs'),'dependency_rlib_sha256':digest(Path('/workspace/pure-protobuf/work/stable-target/debug/deps/libruzstd-ea657bed19cae19c.rlib')),'limits':{'address_space_bytes':256*1024*1024,'cpu_seconds':10,'file_descriptors':64,'wall_timeout_seconds':60},'notes':['Allocation diagnostic only; old6cdresourcecampaignwasactive.','Callerbuiltwithrustc-O;ruzstdreusedfromdebugdependencycache. Noqualifiedtiming/RSSclaims.','InputpayloadconstructionandJSONprintingoutsideallocationtracking.'], 'rows':rows}
report['passed']=all(r.get('exit_code')==0 and r.get('result',{}).get('live_bytes_at_end')==0 for r in rows)
(out/'runs.json').write_text(json.dumps(report,indent=2)+'\n')
print('passed',report['passed'],'cases',len(rows))
for r in rows:
 x=r.get('result',{})
 print(*(x.get(k) for k in ['mode','logical_window_bytes','frames','allocations','requested_bytes','peak_live_bytes','live_bytes_at_end']))
raise SystemExit(0 if report['passed'] else 1)
