//! Bounded allocation diagnostic; this is not an RPC performance qualification.
use ruzstd::decoding::{FrameDecoder, StreamingDecoder};
use std::alloc::{GlobalAlloc, Layout, System};
use std::io::Read;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering::Relaxed};
use std::time::Instant;

struct Counting;
static TRACK: AtomicBool = AtomicBool::new(false);
static ALLOCS: AtomicUsize = AtomicUsize::new(0);
static REALLOCS: AtomicUsize = AtomicUsize::new(0);
static REQUESTED: AtomicUsize = AtomicUsize::new(0);
static LIVE: AtomicUsize = AtomicUsize::new(0);
static PEAK: AtomicUsize = AtomicUsize::new(0);
fn add(bytes: usize) {
    REQUESTED.fetch_add(bytes, Relaxed);
    let live = LIVE.fetch_add(bytes, Relaxed) + bytes;
    PEAK.fetch_max(live, Relaxed);
}
// SAFETY: Each method forwards the exact pointer/layout to System; atomics
// observe allocation sizes and never change the allocator's ownership rules.
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        // SAFETY: Caller supplies GlobalAlloc's valid layout.
        let pointer = unsafe { System.alloc(layout) };
        if !pointer.is_null() && TRACK.load(Relaxed) {
            ALLOCS.fetch_add(1, Relaxed);
            add(layout.size());
        }
        pointer
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        // SAFETY: Caller supplies GlobalAlloc's valid layout.
        let pointer = unsafe { System.alloc_zeroed(layout) };
        if !pointer.is_null() && TRACK.load(Relaxed) {
            ALLOCS.fetch_add(1, Relaxed);
            add(layout.size());
        }
        pointer
    }
    unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
        if TRACK.load(Relaxed) { LIVE.fetch_sub(layout.size(), Relaxed); }
        // SAFETY: The pointer/layout pair is forwarded unchanged to System.
        unsafe { System.dealloc(pointer, layout) };
    }
    unsafe fn realloc(&self, pointer: *mut u8, layout: Layout, new_size: usize) -> *mut u8 {
        // SAFETY: The caller's allocation and valid requested size go to System.
        let result = unsafe { System.realloc(pointer, layout, new_size) };
        if !result.is_null() && TRACK.load(Relaxed) {
            REALLOCS.fetch_add(1, Relaxed);
            LIVE.fetch_sub(layout.size(), Relaxed);
            add(new_size);
        }
        result
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;

// Standard Zstd magic, descriptor=0 (unknown FCS), window=8 MiB,
// last raw block with zero decoded bytes. A valid complete nine-byte frame.
const EMPTY_FRAME: [u8; 9] = [0x28, 0xb5, 0x2f, 0xfd, 0, 0x68, 1, 0, 0];

fn fresh(mut input: &[u8], window: u64) {
    let mut output = [0u8; 1];
    while !input.is_empty() {
        let mut decoder = StreamingDecoder::new_with_max_window_size(input, window).unwrap();
        assert_eq!(decoder.read(&mut output).unwrap(), 0);
        assert!(decoder.decoder.is_finished());
        let remaining = decoder.into_inner();
        assert!(remaining.len() < input.len());
        input = remaining;
    }
}
fn reused(mut input: &[u8], window: u64) {
    let mut state = FrameDecoder::new();
    state.set_max_window_size(window);
    let mut output = [0u8; 1];
    while !input.is_empty() {
        let mut decoder = StreamingDecoder::new_with_decoder(input, &mut state).unwrap();
        assert_eq!(decoder.read(&mut output).unwrap(), 0);
        assert!(decoder.decoder.is_finished());
        let remaining = decoder.into_inner();
        assert!(remaining.len() < input.len());
        input = remaining;
    }
}
fn main() {
    let mut args = std::env::args().skip(1);
    let mode = args.next().expect("fresh or reused");
    let frames: usize = args.next().expect("bounded frame count").parse().unwrap();
    let window: u64 = args.next().expect("65536 or 8388608 window").parse().unwrap();
    assert!(matches!(window, 65536 | 8388608));
    assert!(args.next().is_none());
    assert!((1..=4096).contains(&frames), "bounded control only: 1..4096 frames");
    let mut frame = EMPTY_FRAME;
    frame[5] = if window == 65536 { 0x30 } else { 0x68 };
    let input = frame.repeat(frames);
    // Payload creation and reporting stay outside the tracking interval. All
    // decoder allocations are created and dropped inside the measured call.
    TRACK.store(true, Relaxed);
    let started = Instant::now();
    match mode.as_str() {
        "fresh" => fresh(&input, window),
        "reused" => reused(&input, window),
        _ => panic!("fresh or reused"),
    }
    let elapsed = started.elapsed().as_nanos();
    TRACK.store(false, Relaxed);
    println!("{{\"mode\":\"{}\",\"frames\":{},\"logical_window_bytes\":{},\"encoded_bytes\":{},\"allocations\":{},\"reallocations\":{},\"requested_bytes\":{},\"peak_live_bytes\":{},\"live_bytes_at_end\":{},\"elapsed_ns_diagnostic\":{},\"qualified\":false}}",
        mode, frames, window, input.len(), ALLOCS.load(Relaxed), REALLOCS.load(Relaxed),
        REQUESTED.load(Relaxed), PEAK.load(Relaxed), LIVE.load(Relaxed), elapsed);
}
