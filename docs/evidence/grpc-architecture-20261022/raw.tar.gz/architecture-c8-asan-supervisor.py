import datetime,hashlib,json,os,re,shutil,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification';CWD=ROOT/'work/architecture-c8';CACHE=ROOT/'work/asan-target';PIN='9d6fb9c416fc32732450fd78d32ee16ff8b802de'
STATE=Q/'architecture-c8-asan-supervisor-state.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic(path,value):
 temporary=path.with_name(path.name+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)
def digest(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def source():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=CWD,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=CWD,text=True).strip()}
state={'started_utc':now(),'supervisor_pid':os.getpid(),'source_before':source(),'state':'running','checks':[],'qualification':False}
atomic(STATE,state)
try:
 assert state['source_before']=={'head':PIN,'status':''},state['source_before']
 assert not CACHE.exists(),'fresh dedicated cache was expected'
 env=os.environ.copy();env.update(RUSTFLAGS='-Zsanitizer=address',ASAN_OPTIONS='detect_leaks=1',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(CACHE))
 phases=[('architecture-c8-asan',1800,['--lib','--test','pump_panic','--test','closed_upload_response','--test','retry_safety'],[]),('architecture-c8-asan-inbound-owner',1200,['--test','lifecycle'],['inbound_owner_'])]
 executables={}
 for name,limit,targets,filters in phases:
  assert source()==state['source_before']
  prefix=Q/name
  args=['python3',str(ROOT/'work/record.py'),str(prefix),str(limit),str(ROOT/'work/run-rust'),'cargo','+nightly-2025-06-26','test','--locked','-p','pbrs-grpc','--all-features',*targets,'--target','x86_64-unknown-linux-gnu','-Zbuild-std',*filters,'--','--test-threads=4']
  state['active']=name;atomic(STATE,state)
  completed=subprocess.run(args,cwd=CWD,env=env)
  record=json.loads(prefix.with_suffix('.json').read_text())
  summaries=[{'status':s,'passed':int(a),'failed':int(b),'ignored':int(c)}for s,a,b,c in re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',prefix.with_suffix('.stdout').read_text())]
  check={'name':name,'command':args,'exit_code':record['exit_code'],'duration_seconds':record['duration_seconds'],'summaries':summaries,'totals':{k:sum(v[k]for v in summaries)for k in ('passed','failed','ignored')},'source_after':source(),'files':{p.name:{'bytes':p.stat().st_size,'sha256':digest(p)}for p in(prefix.with_suffix('.json'),prefix.with_suffix('.stdout'),prefix.with_suffix('.stderr'))}}
  state['checks'].append(check);atomic(STATE,state)
  assert completed.returncode==0 and check['source_after']==state['source_before'],check
  assert summaries and all(x['status']=='ok' for x in summaries),summaries
  if name.endswith('inbound-owner'):assert check['totals']=={'passed':8,'failed':0,'ignored':0},check['totals']
  for match in re.finditer(r'^\s*Running .*?\(([^()]+)\)\s*$',prefix.with_suffix('.stderr').read_text(),re.MULTILINE):
   path=Path(match.group(1));path=path if path.is_absolute()else CWD/path
   path=path.resolve();assert path.is_relative_to(CACHE.resolve()),path
   assert path.read_bytes()[:4]==b'\x7fELF',path
   executables[str(path)]={'bytes':path.stat().st_size,'sha256':digest(path)}
 state['executables']=executables;assert len(executables)==5,executables
 state['checks_passed_utc']=now();state['active']='cache_reclamation';atomic(STATE,state)
 assert CACHE.resolve()==ROOT/'work/asan-target' and not CACHE.is_symlink()
 active=[];inaccessible=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdecimal()or proc.stat().st_uid!=os.getuid():continue
  try:
   maps=(proc/'maps').read_text();cmd=(proc/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   if str(CACHE)in maps or str(CACHE)in cmd:active.append({'pid':int(proc.name),'cmdline':cmd})
   for fd in(proc/'fd').iterdir():
    try:target=os.readlink(fd)
    except OSError:continue
    if target.startswith(str(CACHE)+'/'):active.append({'pid':int(proc.name),'fd':fd.name,'target':target})
  except(FileNotFoundError,ProcessLookupError):continue
  except PermissionError:inaccessible.append(int(proc.name))
 assert not active,active
 files=[]
 for path in sorted(CACHE.rglob('*')):
  if path.is_symlink():files.append({'path':str(path.relative_to(CACHE)),'symlink':os.readlink(path)})
  elif path.is_file():files.append({'path':str(path.relative_to(CACHE)),'bytes':path.stat().st_size,'sha256':digest(path)})
 reclaimed=sum(x.get('bytes',0)for x in files)
 inventory=Q/'architecture-c8-asan-cache-inventory.json';atomic(inventory,{'source':PIN,'executables':executables,'cache':str(CACHE),'files':files,'bytes':reclaimed,'active_users':active,'inaccessible_same_uid_proc':inaccessible})
 shutil.rmtree(CACHE);assert not CACHE.exists()
 cleanup={'source':PIN,'cache':str(CACHE),'cache_reclaimed':True,'bytes_reclaimed':reclaimed,'files':len(files),'executables':executables,'inventory':{'path':str(inventory),'sha256':digest(inventory)},'active_users':active,'completed_utc':now(),'free_bytes':shutil.disk_usage(ROOT).free}
 atomic(Q/'architecture-c8-asan-cache-reclaim.json',cleanup)
 state.update(state='passed',active=None,completed_utc=now(),source_after=source(),cache_reclaimed=True,free_bytes=cleanup['free_bytes']);atomic(STATE,state)
 assert source()==state['source_before']
 atomic(Q/'architecture-c8-workspace-disk-ready.json',{'source':PIN,'cache_reclaimed':True,'asan_checks_passed':True,'free_bytes':cleanup['free_bytes'],'utc':now(),'supervisor_state_sha256':digest(STATE)})
except BaseException as error:
 state.update(state='failed',error=repr(error),completed_utc=now(),source_after=source());atomic(STATE,state);traceback.print_exc();sys.exit(1)
