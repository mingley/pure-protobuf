from pathlib import Path
import datetime,hashlib,importlib.util,json
from types import SimpleNamespace
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';pending='CANDIDATE_C8_FULL_COMMIT_PENDING'
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def replace(value):
 if isinstance(value,str):return value.replace('architecture-c4','architecture-c8').replace('804b5c593fc209cbc5714fd3e77710b54711cc63',pending).replace('783bcd53c723032cd0ccbff5d4550f9a1c92cbb8',pending).replace('B4/C4','B4/C8').replace('Full C4','Full C8')
 if isinstance(value,list):return [replace(v) for v in value]
 if isinstance(value,dict):return {replace(k):replace(v) for k,v in value.items()}
 return value
old_paths=list(q.glob('architecture-c4*'));before={str(p):digest(p) for p in old_paths if p.is_file()}
for stem in ['counter-ab-driver.py','ab-summary.py','counter-summary.py','native-ab-summary.py','legacy-summary.py','launch-phase.py']:
 source=(q/('architecture-c4-'+stem)).read_text();(q/('architecture-c8-'+stem)).write_text(replace(source))
for p in q.glob('architecture-c4*workload*.json'):(q/p.name.replace('architecture-c4','architecture-c8')).write_bytes(p.read_bytes())
scope=json.loads((q/'architecture-c4-scope-corrections.json').read_text())['scope'][:5]+['B4 remains the immutable baseline. C8 must be a new source-pinned build containing the inbound-drop cancellation and waiter-deregistration fixes; C4 is historical evidence only.']
driver=q/'architecture-c8-counter-ab-driver.py';text=driver.read_text();anchor='    if args.cells_file:\n        inputs_copy = output / \'workloads.json\''
addition="    state['limits'].extend("+repr(scope)+")\n"
assert anchor in text;text=text.replace(anchor,addition+anchor,1);driver.write_text(text)
for name in ['measurement-plan','oversized-final-plan','instruction-expansion-plan','instruction-fallback-plans']:
 data=replace(json.loads((q/f'architecture-c4-{name}.json').read_text()))
 data['state']='PREPARED_NOT_RUN_C8_SOURCE_PIN_BUILD_AND_ROOT_QUIET_GRANT_PENDING';data['pending_candidate_source']=True
 data['scope_correction_record']=str(q/'architecture-c8-scope-corrections.json')
 data['limits']=[v for v in data.get('limits',[]) if not any(t in v for t in ['candidate benchmark804','candidate C4','C3 includes','runtime783','source783'])]
 data['limits']+=['C8 must include the server inbound-drop cancellation and cancellation-waiter deregistration fixes. Prior C3/C4 binaries are historical mechanism evidence only.','No build, preflight or capture until the root provides the final C8 pin; all per-RPC/readiness/teardown deadlines remain unchanged.']
 if name=='measurement-plan':
  data['candidate_note']='Final C8 source pending. Baseline B4 remains unchanged; no C4 ELF is substituted for the new runtime.'
  data['controller_hashes']={f:digest(q/f) for f in data['controller_hashes']}
  data['benchmark_fairness']['source_pins_record']=str(q/'architecture-c8-source-pins.json')
 if name=='oversized-final-plan':data['driver_sha256']=digest(driver)
 (q/f'architecture-c8-{name}.json').write_text(json.dumps(data,indent=2)+'\n')
scope_record=dict(state='PENDING_C8_PIN_NO_CAPTURE',qualified=False,no_capture_executed=True,scope=scope,source_pending=pending,baseline_benchmark='2eba72d86b4bb7db133120797e3c4746d86713bc',baseline_runtime='6cd91911afce24cceee6df3f60a945453e5b04da',driver_limits_builtin=True)
(q/'architecture-c8-scope-corrections.json').write_text(json.dumps(scope_record,indent=2)+'\n')
# Schedule-only checks do not require a source hash or execute endpoints.
spec=importlib.util.spec_from_file_location('c8_pending_schedules',driver);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
master=json.loads((q/'architecture-c8-measurement-plan.json').read_text());oversized=json.loads((q/'architecture-c8-oversized-final-plan.json').read_text());cpu=json.loads((q/'architecture-c8-instruction-expansion-plan.json').read_text());checks=[]
phases=[master[k] for k in ['selected_native_ab','instruction_pilot']]+list(oversized['phases'].values())+list(cpu['options'].values())
for row in phases:
 argv=row['argv'];get=lambda flag,default=None:argv[argv.index(flag)+1] if flag in argv else default
 args=SimpleNamespace(cells_file=Path(get('--cells-file')),repeats=int(get('--repeats','3')),pilot='--pilot' in argv,scope=get('--scope'),seed=int(get('--seed','20261022')),count=int(get('--count')),abba='--abba' in argv)
 cells=m.cells_for(args);schedule=m.schedule_for(cells,args)
 assert len(schedule)==row['expected_captures'];assert sum(r['count'] for r in schedule)==row['expected_actual_rpc_calls']
 checks.append(dict(output=get('--output'),captures=len(schedule),rpc_calls=sum(r['count'] for r in schedule)))
assert {str(p):digest(p) for p in old_paths if p.is_file()}==before
record=dict(state='READY_PENDING_C8_PIN_BUILD_AND_QUIET_GRANT',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),old_c4_files_unchanged=True,old_c4_file_hashes=before,schedule_checks=checks,no_build_or_capture_executed=True)
(q/'architecture-c8-pending-preparation.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({key:record[key] for key in ['state','old_c4_files_unchanged','schedule_checks','no_build_or_capture_executed']},indent=2))
