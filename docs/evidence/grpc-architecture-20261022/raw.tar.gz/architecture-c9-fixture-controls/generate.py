"""Generate a scoped copied-fixture control target, never shipping source."""
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import re

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification/architecture-c9-fixture-controls'
spec = importlib.util.spec_from_file_location('previous_controls', ROOT / 'work/qualification/architecture-c5-fixture-controls/driver.py')
previous = importlib.util.module_from_spec(spec)
spec.loader.exec_module(previous)
body = previous.function_body
span = previous.function_span
replace = previous.replace_in_function
sha = lambda value: hashlib.sha256(value.encode() if isinstance(value, str) else value).hexdigest()
SHAPES = ['unary', 'server_stream', 'client_stream', 'bidi']
CLIENT = ['a_client_interceptor_can_set_a_deadline', 'a_tls_client_interceptor_can_set_a_deadline', 'an_mtls_client_interceptor_can_set_a_deadline', 'a_unix_client_interceptor_can_set_a_deadline', 'a_from_io_client_interceptor_can_set_a_deadline']
SERVER = ['spawned_work_stops_when_the_deadline_fires', 'tls_spawned_work_stops_when_the_deadline_fires', 'mtls_spawned_work_stops_when_the_deadline_fires', 'unix_spawned_work_stops_when_the_deadline_fires', 'from_io_spawned_work_stops_when_the_deadline_fires']
CAP = ['a_handler_sees_the_interceptor_deadline_on_request', 'a_tls_handler_sees_the_interceptor_deadline_on_request', 'an_mtls_handler_sees_the_interceptor_deadline_on_request', 'a_unix_handler_sees_the_interceptor_deadline_on_request', 'a_from_io_handler_sees_the_interceptor_deadline_on_request']
FOCUSED = CLIENT + SERVER + CAP
HELPERS = '''
// These controls exist only in this generated fixture copy. Every negative runs
// in a separate process; the shipping runtime and original oracles are unchanged.
fn architecture_control_mode() -> String {
    std::env::var("PBRS_C9_CONTROL").unwrap_or_default()
}
fn architecture_control_shape(shape: &str) -> bool {
    let selected = std::env::var("PBRS_C9_SHAPE").unwrap_or_default();
    selected.is_empty() || selected == shape
}
fn architecture_control_timeout(normal: Duration, missing: &str, early: &str) -> Option<Duration> {
    let mode = architecture_control_mode();
    if mode == missing { None }
    else if mode == early { Some(Duration::from_millis(1)) }
    else { Some(normal) }
}
'''

def generate(source):
    provenance = {'source_sha256': sha(source), 'preserved_oracles': {}, 'call_blocks': {}, 'focused_functions': {}}
    changed = source
    for function in ['interceptor_set_timeout', CLIENT[0]]:
        changed = replace(changed, function, 'call.set_timeout(Duration::from_millis(40));',
            'if let Some(timeout) = architecture_control_timeout(Duration::from_millis(40), "client_missing", "client_early") {\n                call.set_timeout(timeout);\n            }')
    changed = replace(changed, 'interceptor_server_set_timeout', 'rpc.set_timeout(Duration::from_millis(20));',
        'if let Some(timeout) = architecture_control_timeout(Duration::from_millis(20), "server_missing", "server_early") {\n        rpc.set_timeout(timeout);\n    }')
    changed = replace(changed, 'interceptor_check_peer_and_tighten', 'rpc.set_timeout(Duration::from_millis(20));',
        'match architecture_control_mode().as_str() {\n        "cap_missing" => {}\n        "cap_wrong" => rpc.set_timeout(Duration::from_millis(19)),\n        _ => rpc.set_timeout(Duration::from_millis(20)),\n    }')
    name = 'assert_controlled_deadline_on_every_shape'
    start, end = span(changed, name)
    function = changed[start:end]
    markers = ['    assert_paused_deadline_dropped_spawned(', '    assert_paused_deadline_dropped_spawned(', '    let (tx, call) = client.client_hello(', '    let (tx, call) = client.stream_hello(']
    positions = []
    cursor = 0
    for marker in markers:
        position = function.index(marker, cursor)
        positions.append(position)
        cursor = position + len(marker)
    blocks = [function[a:b] for a, b in zip(positions, positions[1:] + [function.rindex('\n}')])]
    assert all(marker in block for marker, block in zip(['client.say_hello(', 'client.server_hello(', 'client.client_hello(', 'client.stream_hello('], blocks))
    rewritten = function[:positions[0]]
    for shape, block in zip(SHAPES, blocks):
        rewritten += '    if architecture_control_shape("' + shape + '") {\n' + block + '\n    }\n'
        assert rewritten.count(block) == 1
    rewritten += function[function.rindex('\n}'):]
    provenance['call_blocks'][name] = {shape: {'original_sha256': sha(block), 'copied_sha256': sha(block), 'byte_equal': True} for shape, block in zip(SHAPES, blocks)}
    changed = changed[:start] + rewritten + changed[end:]

    name = 'assert_handler_sees_interceptor_deadline'
    start, end = span(changed, name)
    function = changed[start:end]
    positions = [match.start() for match in re.finditer('    let mut request =', function)]
    assert len(positions) == 4
    blocks = [function[a:b] for a, b in zip(positions, positions[1:] + [function.rindex('\n}')])]
    rewritten = function[:positions[0]] + '''    let control_client = (architecture_control_mode() == "peer_wrong").then(|| {
        client.clone().intercept(|call: &mut Outgoing<'_>| {
            call.set_timeout(Duration::from_secs(7));
            Ok(())
        })
    });
    let client = control_client.as_ref().unwrap_or(client);
'''
    for shape, block in zip(SHAPES, blocks):
        rewritten += '    if architecture_control_shape("' + shape + '") {\n' + block + '\n    }\n'
        assert rewritten.count(block) == 1
    rewritten += function[function.rindex('\n}'):]
    provenance['call_blocks'][name] = {shape: {'original_sha256': sha(block), 'copied_sha256': sha(block), 'byte_equal': True} for shape, block in zip(SHAPES, blocks)}
    changed = changed[:start] + rewritten + changed[end:] + HELPERS
    generated, filtering = previous.focused_copy(changed, FOCUSED)
    for name in ['assert_paused_deadline_dropped_spawned', 'take_interceptor_deadline_cap', 'assert_fixture_pending', 'await_fixture_repoll', 'await_fixture_admission', 'await_fixture_drop', 'drive_frozen_fixture']:
        original = body(source, name)
        copied = body(generated, name)
        assert original == copied, name
        provenance['preserved_oracles'][name] = {'original_sha256': sha(original), 'copied_sha256': sha(copied), 'byte_equal': True}
    for name in FOCUSED:
        expected = body(changed, name)
        copied = body(generated, name)
        assert expected == copied
        if name != CLIENT[0]:
            assert copied == body(source, name), name
        provenance['focused_functions'][name] = {'original_sha256': sha(body(source, name)), 'copied_sha256': sha(copied), 'byte_equal': name != CLIENT[0], 'scoped_inline_timeout_hook': name == CLIENT[0]}
    provenance['filtering'] = filtering
    provenance['generated_sha256'] = sha(generated)
    provenance['temporary_target'] = 'pbrs-grpc/tests/architecture_c9_fixture_controls.rs'
    return generated, changed, provenance

def write_snapshot(source_path, directory):
    directory.mkdir(parents=True, exist_ok=False)
    source = source_path.read_text()
    generated, changed, provenance = generate(source)
    (directory / 'original-serving.rs').write_text(source)
    (directory / 'generated.rs').write_text(generated)
    (directory / 'trigger-and-shape-hooks.patch').write_text(''.join(difflib.unified_diff(source.splitlines(True), changed.splitlines(True), fromfile='original-serving.rs', tofile='hooked-copy.rs')))
    (directory / 'test-filtering.patch').write_text(''.join(difflib.unified_diff(changed.splitlines(True), generated.splitlines(True), fromfile='hooked-copy.rs', tofile=provenance['temporary_target'])))
    (directory / 'provenance.json').write_text(json.dumps(provenance, indent=2) + '\n')
    return provenance

if __name__ == '__main__':
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    print(json.dumps(write_snapshot(args.source, args.output), indent=2))
