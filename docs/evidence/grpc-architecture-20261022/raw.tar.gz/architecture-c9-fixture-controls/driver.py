"""One-build fixture-oracle controls. Requires a clean granted checkout."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import generate

ROOT = generate.ROOT
Q = generate.Q
TEMP = Path('pbrs-grpc/tests/architecture_c9_fixture_controls.rs')
TARGET = TEMP.stem
sha = generate.sha
utc = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()

def save(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)

def git(checkout, *args):
    return subprocess.check_output(['git', *args], cwd=checkout)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--checkout', type=Path, required=True)
    parser.add_argument('--expected-head', required=True)
    parser.add_argument('--allow-root-checkout', action='store_true')
    parser.add_argument('--explicit-execution-grant', required=True, choices=['root-granted-negative-controls'])
    args = parser.parse_args()
    checkout = args.checkout.resolve()
    assert checkout != ROOT or args.allow_root_checkout
    assert git(checkout, 'rev-parse', 'HEAD').decode().strip() == args.expected_head
    initial_status = git(checkout, 'status', '--porcelain=v1')
    assert initial_status == b'', initial_status
    owned = checkout / TEMP
    assert not owned.exists() and not owned.is_symlink()
    directory = Q / 'execution'
    directory.mkdir(exist_ok=False)
    source = checkout / 'pbrs-grpc/tests/serving.rs'
    source_bytes = source.read_bytes()
    core_before = generate.previous.core_hashes(checkout)
    save(directory / 'runtime-core-before.json', core_before)
    state = {'status': 'running', 'started_utc': utc(), 'checkout': str(checkout), 'head': args.expected_head,
             'scope': 'Copied fixture-oracle controls only, not full-suite qualification.',
             'initial_status': initial_status.decode(), 'runs': [], 'source_restored': False}
    save(directory / 'state.json', state)
    env = os.environ.copy()
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(ROOT / 'work/stable-target'), CARGO_BUILD_JOBS='1', RUST_TEST_THREADS='4')
    env.pop('PBRS_C9_CONTROL', None)
    env.pop('PBRS_C9_SHAPE', None)
    known_sha = None

    def assert_originals_unchanged():
        assert source.read_bytes() == source_bytes, 'Original fixture changed'
        assert generate.previous.core_hashes(checkout) == core_before, 'Production core changed'
        assert git(checkout, 'rev-parse', 'HEAD').decode().strip() == args.expected_head
        assert git(checkout, 'diff', 'HEAD', '--binary') == b'', 'Tracked files changed'

    def record(name, seconds, command, mode='', shape=''):
        prefix = directory / name
        assert not prefix.with_suffix('.json').exists()
        child_env = env.copy()
        child_env.update(PBRS_C9_CONTROL=mode, PBRS_C9_SHAPE=shape)
        result = subprocess.run([sys.executable, str(ROOT / 'work/record.py'), str(prefix), str(seconds), *command], cwd=checkout, env=child_env)
        assert prefix.with_suffix('.json').exists(), 'Recorder missing actual terminal metadata'
        metadata = json.loads(prefix.with_suffix('.json').read_text())
        metadata['fixture_control_environment'] = {'PBRS_C9_CONTROL': mode, 'PBRS_C9_SHAPE': shape}
        save(prefix.with_suffix('.json'), metadata)
        assert metadata['exit_code'] == result.returncode
        output = prefix.with_suffix('.stdout').read_text() + prefix.with_suffix('.stderr').read_text()
        return result.returncode, metadata, output

    try:
        provenance = generate.write_snapshot(source, directory / 'source')
        data = (directory / 'source/generated.rs').read_bytes()
        known_sha = sha(data)
        state['generated_sha256'] = known_sha
        state['original_serving_sha256'] = sha(source_bytes)
        save(directory / 'state.json', state)
        owned.write_bytes(data)
        assert_originals_unchanged()
        code, _, _ = record('compile', 900, [str(ROOT / 'work/run-rust'), 'cargo', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', '--test', TARGET, '--no-run', '--message-format=json'])
        assert code == 0, 'Compile failure invalidates controls'
        artifacts = []
        for line in (directory / 'compile.stdout').read_text().splitlines():
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == TARGET and item.get('executable'):
                artifacts.append(item['executable'])
        assert len(set(artifacts)) == 1, artifacts
        executable = Path(artifacts[-1])
        state['executable'] = {'path': str(executable), 'sha256': sha(executable.read_bytes()), 'bytes': executable.stat().st_size}
        code, _, output = record('compiled-list', 20, [str(executable), '--list'])
        listed = re.findall(r'^(.+): test$', output, re.M)
        assert code == 0 and sorted(listed) == sorted(generate.FOCUSED), listed
        state['compiled_tests'] = listed
        save(directory / 'state.json', state)
        code, metadata, output = record('positive-all-15', 120, [str(executable), '--nocapture', '--test-threads=4'])
        valid = code == 0 and 'test result: ok. 15 passed; 0 failed; 0 ignored;' in output
        state['runs'].append({'id': 'positive-all-15', 'actual_exit_code': code, 'duration_seconds': metadata['duration_seconds'], 'oracle_satisfied': valid})
        save(directory / 'state.json', state)
        assert valid, 'Positive copied fixture failure; no negative runs are valid'
        modes = [
            ('client_missing', generate.CLIENT[0], ['fixture stalled: controlled handler deadline'], 4.5),
            ('client_early', generate.CLIENT[0], ['handler dropped before configured deadline', 'call completed before the controlled boundary'], 0),
            ('server_missing', generate.SERVER[0], ['fixture stalled: controlled handler deadline'], 4.5),
            ('server_early', generate.SERVER[0], ['handler dropped before configured deadline', 'call completed before the controlled boundary'], 0),
            ('cap_missing', generate.CAP[0], ['stamped timeout 5s is not the interceptor cap'], 0),
            ('cap_wrong', generate.CAP[0], ['stamped timeout 19ms is not the interceptor cap'], 0),
            ('peer_wrong', generate.CAP[0], ['rpc peer timeout Some(7s)'], 0),
        ]
        for mode, test, messages, minimum_wall in modes:
            for shape in generate.SHAPES:
                assert_originals_unchanged()
                code, metadata, output = record(mode + '-' + shape, 15, [str(executable), '--exact', test, '--nocapture'], mode, shape)
                single_failure = re.search(r'^test result: FAILED\. 0 passed; 1 failed; 0 ignored;', output, re.M) is not None
                matched = [message for message in messages if message in output]
                valid = code == 101 and single_failure and bool(matched) and metadata['duration_seconds'] >= minimum_wall
                if mode.startswith('cap_') or mode == 'peer_wrong':
                    label = {'unary':'unary', 'server_stream':'server-stream', 'client_stream':'client-stream', 'bidi':'bidi'}[shape]
                    valid = valid and label + ': Internal:' in output
                state['runs'].append({'id': mode + '-' + shape, 'test': test, 'mode': mode, 'shape': shape, 'actual_exit_code': code,
                    'duration_seconds': metadata['duration_seconds'], 'exact_single_failure_summary': single_failure,
                    'matched_expected_messages': matched, 'oracle_satisfied': valid})
                save(directory / 'state.json', state)
                assert valid, 'Unexpected result invalidates control: ' + mode + '/' + shape
        state['all_29_runs_passed'] = len(state['runs']) == 29 and all(row['oracle_satisfied'] for row in state['runs'])
    except BaseException as error:
        state['error'] = repr(error)
    finally:
        try:
            if owned.exists() or owned.is_symlink():
                assert not owned.is_symlink(), 'Unexpected symlink preserved'
                assert known_sha and sha(owned.read_bytes()) == known_sha, 'Unexpected tempfile edits preserved'
                owned.unlink()
            assert_originals_unchanged()
            state['final_head'] = git(checkout, 'rev-parse', 'HEAD').decode().strip()
            state['final_status'] = git(checkout, 'status', '--porcelain=v1').decode()
            state['source_restored'] = state['final_status'] == initial_status.decode() and not owned.exists()
            save(directory / 'runtime-core-after.json', generate.previous.core_hashes(checkout))
        except BaseException as error:
            state['restoration_error'] = repr(error)
        state['completed_utc'] = utc()
        state['status'] = 'all controls passed' if state.get('all_29_runs_passed') and state['source_restored'] and 'error' not in state else 'CONTROL QUALIFICATION FAILED'
        save(directory / 'state.json', state)
    return 0 if state['status'] == 'all controls passed' else 1

if __name__ == '__main__':
    sys.exit(main())
