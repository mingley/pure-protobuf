"""Explicit-grant detached launcher; does not itself grant execution."""
import datetime
import hashlib
import json
from pathlib import Path
import subprocess
import sys
Q = Path(__file__).resolve().parent
assert '--explicit-execution-grant' in sys.argv[1:]
assert not (Q / 'launch.json').exists()
command = [sys.executable, str(Q / 'driver.py'), *sys.argv[1:]]
with (Q / 'driver.stdout').open('xb') as stdout, (Q / 'driver.stderr').open('xb') as stderr:
    process = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True, close_fds=True)
record = {'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pid': process.pid, 'command': command,
          'script_sha256': {name: hashlib.sha256((Q / name).read_bytes()).hexdigest() for name in ['driver.py', 'generate.py', 'launch.py']}}
(Q / 'launch.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
