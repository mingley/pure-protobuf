# C3 serving failure review

Reviewed immutable runtime source `783bcd53c723032cd0ccbff5d4550f9a1c92cbb8` in `work/architecture-c3`. This is source review only: no builds, edits, or replays were run by this agent. The original workspace failures remain evidence. Quiet replays alone cannot establish a unique cause or make the original run pass.

## Findings

| Failed case | Concrete fixture assumption | Assessment |
| --- | --- | --- |
| `a_handler_deadline_is_an_instant_that_elapses` | `assert_handler_deadline_elapses` stamps a 200 ms client deadline; `sees_deadline` sleeps 50 ms; `echo_every_shape` requires successful response headers and DATA before that deadline. | A late poll or socket delivery can consume the remaining time after headers. The actual DATA `DeadlineExceeded` is legal when the deadline elapsed. The test intends to check stable duration versus diminishing Instant, but also accidentally asserts wall-clock scheduling performance. |
| `a_tls_server_timeout_expires_when_the_client_sends_none` | The server timeout is 50 ms, but `assert_deadline_in` measures `std::time::Instant` and requires the observed result in under 150 ms. | A scheduled-late test task can observe a correctly expired deadline at 204 ms. This is an explicit wall-clock upper-bound failure, not evidence that the server used the wrong configured deadline. |
| `client_max_connection_age_resets_a_delayed_stream` | Age starts at handshake, with configured 80 ms age plus 1 ms grace. The fixture first requires successful headers, then expects the delayed body to fail. | `spawn_age_watch` begins its Tokio sleep after acquiring the live socket generation; `age_close` removes the socket then stops it after grace. A scheduling delay before the initial RPC/headers can legitimately exhaust age and yield `Unavailable` at headers. The setup never establishes that headers arrived before the age boundary. |
| `tls_spawned_work_stops_when_the_client_cancels` | `SpawnHang::hang_until_dropped` actually finishes after 200 ms. `assert_spawned_cancel_dropped` waits a nominal 40 ms before cancelling. | A scheduler delay can let the handler reach its legitimate 200 ms completion before cancellation/reset arrives. Local `CallHandle::cancel` can still return `Cancelled`; `Request::cancelled` is also signalled by ordinary RPC teardown. Thus `finished == 1` is consistent with the fixture having missed the intended cancellation-before-completion ordering. It remains important to replay and test actual Drop ownership, rather than assuming this explanation proves it. |

## Relevant source locations

All paths are relative to `work/architecture-c3`.

- `pbrs-grpc/tests/serving.rs:2310`: 200 ms deadline helper and four-shape echo call.
- `pbrs-grpc/tests/serving.rs:20025`: handler deadline duration/Instant checks and 50 ms sleep.
- `pbrs-grpc/tests/serving.rs:19372`: successful stream DATA assertions in `echo_every_shape`.
- `pbrs-grpc/tests/serving.rs:17204`: server timeout helper with 150 ms wall bound.
- `pbrs-grpc/tests/serving.rs:20489`: wall-clock observation in `assert_deadline_in`.
- `pbrs-grpc/tests/serving.rs:14681`: max-age setup and mandatory successful headers.
- `pbrs-grpc/src/client/pool.rs:2697`: `spawn_age_watch`; age begins with the live socket generation.
- `pbrs-grpc/src/client/pool.rs:2721`: `age_close`; generation removal, grace, driver stop.
- `pbrs-grpc/src/client/channel.rs:550`: documented age closure even with in-flight calls.
- `pbrs-grpc/tests/serving.rs:19022`: SpawnHang; 200 ms finite completion at `19047`.
- `pbrs-grpc/tests/serving.rs:19266`: nominal 40 ms cancellation helper.
- `pbrs-grpc/tests/serving.rs:19179`: existing self-waking paused-clock real-I/O pattern.

## Repair direction

Keep every original protocol duration and outcome. Do not enlarge the 200/50/80+1 ms values or permit an early header error merely to pass.

Use a current-thread paused Tokio clock, with explicit real-I/O progress polled through a self-waking `poll_fn` and an independent five-second `std::time::Instant` wall guard. This keeps socket/TLS drivers runnable without Tokio automatically advancing to the next timer while the peer is waiting on real I/O. Pause before channel setup, then drive setup under the same guard; simply setting `start_paused` and awaiting network operations can itself auto-advance age/deadline timers and is insufficient.

1. Handler Instant: establish handler admission; advance virtual time by 50 ms while the 200 ms deadline remains unexpired; drive the successful response and complete all four shapes. Retain stable `request.timeout()` and decreasing `request.deadline()` checks. Use explicit admission/sleep readiness so advancing before a handler registered its timer cannot stall the test.
2. Server timeout: establish admission with no client timeout, assert the call remains pending before the configured 50 ms boundary, then advance across that boundary and require `DeadlineExceeded`. Check virtual elapsed time, preserving a separate finite real-time watchdog. Use a producer that does not complete first.
3. Connection age: keep virtual time frozen through channel handshake and successful response headers. Only then advance past the actual age+jitter+grace boundary but before the producer's 200 ms message. Require the already-open stream to fail. Retain existing separate redial and in-flight-grace tests.
4. Spawned cancellation: establish handler admission and its child waiter explicitly while virtual time remains below 200 ms, cancel the call, then require exact `Cancelled`, child cancellation, and zero completion. Prefer also observing actual handler Drop under the finite wall guard; a child token alone is not proof that the parent future was destroyed. Existing HangState drop/reset tests provide direct Drop witnesses elsewhere.

## Controls

Retain the original failed workspace run and repeat each unchanged ELF case quietly before changing fixtures; parent owns those replays. After a deterministic fixture exists, mutate the isolated mechanism in a control checkout: a nondecreasing/fixed deadline Instant must fail the Instant check; omitting the server timeout must fail the guarded expiry; omitting age shutdown must leave the stream pending and fail; suppressing request cancellation/drop must fail the cancellation or destruction witness. Controls must not alter the test oracle or increase protocol timeouts. A quiet pass demonstrates reproducibility limits, not that all scheduling-sensitive behavior is fixed.

## Fixture repair handoff

The parent ran 15 unchanged-ELF quiet replays: 14 passed and one TLS spawned-work case failed. That isolated failure was the earlier `handler should have started` assertion, not the original full-suite `finished == 1` assertion. These are distinct sides of the same uncontrolled setup: the nominal 40 ms may precede handler admission, while an observed late cancellation may follow the finite 200 ms completion. Both failures remain recorded.

The root `serving.rs` patch changes only these four cases and adds target-only helpers. A probe records handler admission and actual future destruction around the unchanged underlying Greeter implementations. The frozen-clock driver continuously wakes real TCP/TLS progress and uses a five-second wall guard. The original shared real-time helpers remain unchanged for all unrelated tests.

- Instant case: the existing four-shape echo is driven to each handler admission; each original 50 ms sleep is explicitly advanced under the unchanged 200 ms request deadline. Duration/Instant semantics and successful DATA assertions remain.
- Server timeout: all four admitted calls remain pending at 49 ms, expire at 51 ms under the unchanged 50 ms server default, return exact DEADLINE_EXCEEDED, and destroy their handler futures. There is no client timeout.
- Age: freeze before handshake and through successful headers; the body remains pending at 60 ms and fails after 100 ms, crossing the unchanged 80 ms +/-10% age and 1 ms grace while staying below the unchanged 200 ms producer delay.
- TLS spawned cancellation: explicitly admit the handler, advance the original 40 ms wait while still below its unchanged 200 ms completion, then require exact CANCELLED, spawned-child cancellation, zero completion, and actual parent-future Drop. The last condition prevents frozen time from masking a retained parent future.

Direct rustfmt and diff whitespace checks pass. No Cargo build or test was run by this agent; parent owns compilation, replay, and negative controls.

## Lower-bound witness correction

A single client Pending poll at49ms was insufficient: a prematurely expired server timer could still be queued, then appear to expire correctly during the51ms drive. The target-only probe now registers its actual inner-handler waker and counts completed polls through `AtomicWaker`. At49ms the fixture explicitly wakes that handler and waits until either its poll count advances or its future is destroyed. Because the test and server run on the same current-thread runtime, the observed inner poll implies the containing deadline poll returned before the test continues. It then requires zero premature destruction and a pending client call before advancing to51ms. The guard takes and drops the retained waker on destruction, preventing a task/probe retention cycle.

Negative-control plans are in `architecture-c4-serving-fixture-negative-controls.json`: omit the target50ms timeout; replace only that timeout with1ms; omit the target80ms age; omit the controlled call-cancel operation. Each preserves the original test oracle and is expected to fail. None was run by this agent.

## Age/grace development correction

The parent development replay passed the deadline Instant and TLS50ms cases, but the age case reached its five-second real-time guard. This was a fixture sequencing error: after jumping virtual time to100ms, `age_close` first processed its due age event and only then registered a new relative1ms grace timer at100ms. Keeping time frozen at100ms cannot expire that grace. The corrected target retains the public Channel handle and drives until `connected()` becomes false, witnessing socket retirement. On this current-thread runtime the age task has completed that poll and registered its grace before the test can observe retirement. The fixture then advances exactly the unchanged1ms grace and requires the delayed stream to fail at101ms, below the unchanged200ms producer timer. The original age80ms, jitter, and1ms grace remain unchanged. This development failure is retained, not counted as a pass.
