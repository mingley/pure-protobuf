from pathlib import Path
import subprocess,hashlib,json,os,datetime
r=Path('/workspace/pure-protobuf');q=r/'work/qualification';source=(r/'pbrs-grpc/tests/serving.rs').read_bytes();state={'state':'starting','source_sha256':hashlib.sha256(source).hexdigest(),'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'checks':[]}
p=q/'architecture-c9-serving-positive-state.json'
def save():p.write_text(json.dumps(state,indent=2)+'\n')
save();env=os.environ.copy();env.update(CARGO_TARGET_DIR=str(r/'work/stable-target'),CARGO_BUILD_JOBS='1')
rust=[str(r/'work/run-rust'),'cargo','+stable']
checks=[('architecture-c9-serving-positive',rust+['test','--locked','-p','pbrs-grpc','--all-features','--test','serving','--','--nocapture'],1200),('architecture-c9-serving-clippy',rust+['clippy','--locked','-p','pbrs-grpc','--all-features','--test','serving','--','-D','warnings'],900),('architecture-c9-serving-format',[str(r/'work/toolchain/rustup/toolchains/stable-x86_64-unknown-linux-gnu/bin/rustfmt'),'--edition','2024','--check',str(r/'pbrs-grpc/tests/serving.rs')],60)]
for name,command,timeout in checks:
 assert source==(r/'pbrs-grpc/tests/serving.rs').read_bytes(),'serving source changed during positive checks'
 state['state']='running '+name;save();result=subprocess.run(['python3',str(r/'work/record.py'),str(q/name),str(timeout),*command],cwd=r,env=env)
 state['checks'].append({'name':name,'exit_code':result.returncode});save()
 if result.returncode:state['state']='failed '+name;save();raise SystemExit(result.returncode)
state.update(state='passed',ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());save()
