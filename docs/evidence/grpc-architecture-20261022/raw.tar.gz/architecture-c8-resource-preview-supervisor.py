import argparse,datetime,hashlib,json,os,runpy,subprocess,sys,time,traceback
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification';CWD=ROOT/'work/architecture-c8';PIN='9d6fb9c416fc32732450fd78d32ee16ff8b802de'
PREFIX=Q/'architecture-c8-resource-preview-run';OUTPUT=Q/'architecture-c8-resource-preview';STATE=Q/'architecture-c8-resource-preview-state.json';GRANT=Q/'architecture-c8-resource-preview-grant.json'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def atomic(path,value):
 temporary=path.with_name(path.name+'.tmp');temporary.write_text(json.dumps(value,indent=2)+'\n');temporary.replace(path)
def sha(path):
 h=hashlib.sha256()
 with path.open('rb')as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def source():
 return {'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=CWD,text=True).strip(),'status':subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=CWD,text=True).strip()}
def command():
 return [sys.executable,str(ROOT/'work/record.py'),str(PREFIX),'1800',str(ROOT/'work/run-rust'),'python3','scripts/grpc-resource-campaign.py','--source',PIN,'--output',str(OUTPUT),'--duration','30','--build-profile','release','--seed','20261002','--memory-bytes','1073741824','--max-fds','128','--max-uid-processes','4096']
def prerequisites():
 assert source()=={'head':PIN,'status':''},source()
 assert subprocess.run(['git','symbolic-ref','-q','HEAD'],cwd=CWD,capture_output=True).returncode==1,'checkout must remain detached'
 controller=CWD/'scripts/grpc-resource-campaign.py'
 expected=subprocess.check_output(['git','show',PIN+':scripts/grpc-resource-campaign.py'],cwd=ROOT)
 assert controller.read_bytes()==expected,'resource controller differs from source pin'
 statefile=Q/'architecture-c8-workspace-final-state.json';state=json.loads(statefile.read_text())
 assert state.get('passed')is True and state.get('cargo_exit_code')==0 and state.get('recorder_exit_code')==0 and state.get('completed_utc'),state
 assert state.get('source_before')==state.get('source_after')=={'head':PIN,'status':''},state
 assert state.get('targets')==len(state.get('summaries',[])) and state['targets']>0,state
 assert all(x['status']=='ok'and x['failed']==0 for x in state['summaries']),state
 totals={k:sum(x[k]for x in state['summaries'])for k in('passed','failed','ignored')};assert totals==state.get('totals')and totals['failed']==0,state
 recordfile=Q/'architecture-c8-workspace-final.json';record=json.loads(recordfile.read_text())
 assert record.get('exit_code')==0 and record.get('source',{}).get('head')==PIN and record['source'].get('diff_sha256')==hashlib.sha256(b'').hexdigest() and record['source'].get('untracked')=={},record
 expected_command=[str(ROOT/'work/run-rust'),'cargo','+stable','test','--locked','--workspace','--all-features','--no-fail-fast','--','--test-threads=4']
 assert record.get('command')==expected_command,record
 for name,metadata in state['logs'].items():
  log=Q/name;assert log.stat().st_size==metadata['bytes']and sha(log)==metadata['sha256'],name
 grant=json.loads(GRANT.read_text());assert grant.get('source')==PIN and grant.get('root_granted')is True and grant.get('action')=='release-resource-preview',grant
 return {'workspace_state_sha256':sha(statefile),'workspace_record_sha256':sha(recordfile),'workspace_totals':totals,'workspace_targets':state['targets'],'grant_sha256':sha(GRANT),'controller_sha256':hashlib.sha256(expected).hexdigest(),'source':source()}
def supervise():
 state={'started_utc':now(),'supervisor_pid':os.getpid(),'source_before':source(),'state':'running','qualified':False}
 atomic(STATE,state)
 try:
  state['prerequisites']=prerequisites();assert not OUTPUT.exists(),'output already exists';atomic(STATE,state)
  env=os.environ.copy();env.pop('RUSTFLAGS',None);env.pop('ASAN_OPTIONS',None);env.update(RUSTUP_TOOLCHAIN='stable',CARGO_BUILD_JOBS='1',CARGO_TARGET_DIR=str(ROOT/'work/rpc-target'))
  state['command']=command();state['active']='resource-preview';atomic(STATE,state)
  completed=subprocess.run(command(),cwd=CWD,env=env);record=json.loads(PREFIX.with_suffix('.json').read_text());state['record_exit_code']=record['exit_code'];state['duration_seconds']=record['duration_seconds'];state['source_after']=source();atomic(STATE,state)
  assert completed.returncode==0 and record['exit_code']==0 and state['source_after']==state['source_before'],state
  reportfile=OUTPUT/'report.json';report=json.loads(reportfile.read_text());controller=runpy.run_path(str(CWD/'scripts/grpc-resource-campaign.py'));errors=controller['validate_report'](report);state['report_validation_errors']=errors;atomic(STATE,state);assert not errors,errors
  assert report['source']['commit']==PIN and report['source']['dirty']is False and report['exit_code']==0 and report['smoke']['status']=='passed' and report['build']['profile']=='release'
  expected_limits={k:{'soft':v,'hard':v}for k,v in {'address_space':1073741824,'file_descriptors':128,'same_uid_processes':4096,'cpu_seconds':60}.items()};assert report['process_limits_requested']==report['process_limits']==expected_limits
  executable=Path(report['binary']['path']);assert sha(executable)==report['binary']['sha256']
  state['report']={'path':str(reportfile),'sha256':sha(reportfile),'source':report['source'],'duration_requested_seconds':report['duration_requested_seconds'],'duration_actual_seconds':report['duration_actual_seconds'],'sampled_rss_peak_bytes':report.get('sampled_rss_peak_bytes'),'binary':report['binary'],'smoke':report['smoke'],'process_limits':report['process_limits'],'qualification':report['qualification']}
  state['active']='read-only-day-readiness';atomic(STATE,state)
  ready_prefix=Q/'architecture-c8-day-readiness-run';ready_command=[sys.executable,str(ROOT/'work/record.py'),str(ready_prefix),'120',sys.executable,str(ROOT/'work/run-architecture-c8-day.py'),'--check-ready']
  ready=subprocess.run(ready_command,cwd=CWD,env=env);assert ready.returncode==0,'day read-only readiness failed'
  readiness=json.loads(ready_prefix.with_suffix('.stdout').read_text());assert readiness['preview']['source']['commit']==PIN and readiness['preview']['smoke']['status']=='passed'
  atomic(Q/'architecture-c8-day-readiness.json',readiness)
  state.update(state='passed',active=None,completed_utc=now(),source_after=source(),day_launched=False,day_readiness_command=ready_command,day_readiness_sha256=sha(Q/'architecture-c8-day-readiness.json'),files={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)}for p in(PREFIX.with_suffix('.json'),PREFIX.with_suffix('.stdout'),PREFIX.with_suffix('.stderr'),reportfile)})
  assert state['source_after']==state['source_before'];atomic(STATE,state)
 except BaseException as error:
  state.update(state='failed',error=repr(error),completed_utc=now(),source_after=source());atomic(STATE,state);traceback.print_exc();return 1
 return 0
def launch():
 readiness=prerequisites();assert not OUTPUT.exists()and not STATE.exists(),'attempt already exists'
 request=Q/'architecture-c8-resource-preview-launch-request.json'
 with request.open('x')as f:json.dump({'source':PIN,'requested_utc':now(),'prerequisites':readiness},f,indent=2);f.write('\n')
 with(Q/'architecture-c8-resource-preview-supervisor.stdout').open('wb')as out,(Q/'architecture-c8-resource-preview-supervisor.stderr').open('wb')as err:
  child=subprocess.Popen([sys.executable,str(Path(__file__).resolve()),'--supervise'],cwd=CWD,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True)
 atomic(Q/'architecture-c8-resource-preview-launch.json',{'pid':child.pid,'source':PIN,'started_utc':now(),'script_sha256':sha(Path(__file__).resolve()),'detached':True,'prerequisites':readiness});print(child.pid)
if __name__=='__main__':
 parser=argparse.ArgumentParser();mode=parser.add_mutually_exclusive_group(required=True);mode.add_argument('--launch',action='store_true');mode.add_argument('--supervise',action='store_true');args=parser.parse_args()
 if args.launch:launch()
 else:sys.exit(supervise())
