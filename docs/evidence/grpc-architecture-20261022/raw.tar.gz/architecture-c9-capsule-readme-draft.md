# gRPC execution, compression and ownership

Draft: qualification and measurement records must be inserted before publication.

Runtime and benchmark source: `9d6fb9c416fc32732450fd78d32ee16ff8b802de`.
Matched benchmark control: `2eba72d86b4bb7db133120797e3c4746d86713bc`
(runtime `6cd91911`). The control and candidate use identical benchmark code.
The later fixture checkpoint changes only `pbrs-grpc/tests/serving.rs`; its exact
diff is retained separately. Results keep their actual source pins.

Production readiness, full specification coverage and broad superiority over
tonic/prost remain unproved.

## Changes

- Poll ready handlers and cancellation jobs without scanning idle ones.
- Own cancellation through handler teardown, including connection task abortion
  and forced connection-age cleanup. Remove abandoned waiter registrations in
  constant time; storage follows peak live registrations rather than churn.
- Validate complete compressed inputs, including later members, checksums and
  trailing data. Bound decoded bytes, history windows and member/frame count.
- Grow decoded output from observed bytes and decompress opaque tonic uploads once.
- Box the selected generated prost method's future.
- Return responses independently of blocked request uploads; retain encoded-tail
  byte charges until enqueue or cleanup.
- Use one atomic cancellation handshake and invoke waker callbacks outside locks.
- Publish replacement owners before reentrant destructors, release live stream
  fields at teardown, and give upload tasks reset guards.
- Test deadlines after explicit admission with controlled time, unchanged timeout
  values, before-expiry checks and actual handler destruction witnesses.

## Validation

Insert final scoped validation table here. Runtime sanitizer scope is 731 passed
and one existing ignore at `9d6fb9c4`. The fixture checkpoint, full workspace,
resource preview, matched captures and actual day status must use final records.

The runtime's eleven new teardown/waiter controls fail against the former
mechanisms and pass against the replacement. Eight use independent registry h2
TCP peers across all four RPC shapes; three cover waiter churn and reentrancy.
They prove the detecting mechanisms, not complete production qualification.

## Performance

Insert final captured results and campaign counts here. Use
[benchmarks](../../benchmarks.md) for short readable tables.

The corrected harness gives both servers a 400 KiB send buffer and both clients
16-message request queues. Shipping defaults are unchanged. Native channelz and
accounting remain enabled. Prost routes keep application work equal; pbrs interop
routes include extra handler work. These compare APIs, not bare transport kernels.

The expanded candidate matrix and selected matched source comparison have
different coverage. Allocation requests do not measure retained memory.
Allocation-instrumented Callgrind counts do not establish shipping latency,
throughput or uninstrumented CPU superiority. Missing counters remain unavailable.

## Retained failures

The original `783bcd53` workspace failed: 3,739 passed, five failed and nine
ignored across 139 targets. A detached observer retained the actual Cargo exit
101, complete summaries, source checks and raw log hashes after the outer
recorder was interrupted. The missing recorder result is not treated as success.

The `9d6fb9c4` workspace failed: 3,753 passed, two failed and nine ignored across
139 targets. One deadline expired before handler admission. The other returned
a redacted Internal status; its original message was not recovered. Both passed
quiet replays. The strict five-second header assertion depends on time not
advancing: after admission delay, the client may correctly send a reduced
remaining timeout. This dependency does not establish that failure's unique cause.

The archive also retains intentionally superseded builds, test lint failures,
failed fixture development attempts and the final corrected checks. Offline
controller tests are synthetic; they are not resource runs or performance captures.

Earlier actual resource-day attempts failed. The `6cd91911` attempt failed after
32 min 2.73 s; 2,008 scenario replays did not uniquely reproduce its cause. A
short resource preview and an active day run do not constitute a completed day.

## Remaining work

Measure read-all nested-message decoding, sparse access, both endpoint CPU costs,
latency, throughput and retained memory on controlled hosts. Compare independently
scheduled admitted RPCs against inline execution for mixed expensive/cheap calls
on one connection, preserving ownership, cancellation and finite admission.
Complete remaining features, platform and network coverage, specification gates
and a full recorded resource day before claiming production qualification.

## Evidence

`results.json` identifies final records and their scopes. `manifest.json` indexes
commands, raw logs, failures, controls, source changes and hashes in `raw.tar.gz`.
Executables are represented by hashes. Run `python3 check.py` to verify archive
integrity; integrity is separate from qualification.
