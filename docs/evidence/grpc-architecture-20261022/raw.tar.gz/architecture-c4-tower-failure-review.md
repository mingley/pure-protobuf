# Tower deadline fixture review

Reviewed immutable runtime/test source `783bcd53c723032cd0ccbff5d4550f9a1c92cbb8` and the retained workspace failure. This review did not run Cargo or change runtime code.

## Failure and scope

The workspace failure is `pbrs-grpc/tests/tower_client.rs:276`, the bidi `oneshot(request).await.unwrap()` before response headers. The request has a real 100 ms deadline; the test assumes headers arrive before it. A `DeadlineExceeded` here is a permitted pre-header result, while the test intends to exercise deadline enforcement after headers with an idle request producer.

The preceding server-streaming phase likewise assumes headers within 100 ms. The idle client-streaming phase has no handler-admission witness, so it can expire during setup without exercising an admitted idle producer. The three original sender/header assertions are not sufficient to distinguish these phases under load.

The unchanged C3 ELF passed this exact case in each of the parent's three isolated quiet replays (`architecture-c4-failed-case-quiet-replay.json`). That supports a scheduling-sensitive fixture diagnosis. It does not prove an upper bound on production header latency or excuse a future runtime regression.

## Runtime source checks

- `src/tower_client.rs` forwards the original request parts into native `Channel::bidi`; the adapter's response future is the native `Call`.
- `src/client/streaming.rs:2082` constructs the deadline on first native call polling. The live bidi header wait races this same deadline before headers (`run_bidi_live`, around line1181) and carries it into `finish_stream` for post-header enforcement.
- The forwarding task watches `sender.closed()` independently of input polling, including an idle external producer.
- The server echo sends response headers immediately after admitting bidi and starts a separate request reader. It does not require an input message to construct the response.

No source witness of a lost deadline was found. This is a test-fixture correction, not a claimed runtime speed or correctness repair.

## Authorized repair in root working tree

Only `pbrs-grpc/tests/tower_client.rs` is changed:

1. Connect with ordinary real time, then pause Tokio time in this one current-thread test.
2. Drive real socket/Tower progress with a self-waking poll helper. Every operation has a **real two-second** wall guard, preserving the existing sender-cleanup bound and preventing a frozen-clock hang.
3. Require actual tagged response headers before advancing time in server-streaming and bidi phases.
4. Record actual client-streaming handler admission in the test service and require admission before advancing its idle-input deadline.
5. Keep all three request deadlines at **100 ms** and advance only **101 ms** after the intended phase witness.
6. Preserve exact `DeadlineExceeded` assertions, full balance/buffer/retry layers, both idle senders and both sender-closure assertions.

The frozen C3/C4 source worktrees and shipping runtime are untouched. Formatting and `git diff --check` pass. No Cargo validation has run for this patch yet.

## Required validation and negative controls

Run the complete seven-test Tower target, then repeat the repaired exact case while loaded. For a small fixture-level negative control, clear the request timeout only in one phase before dispatch: the corresponding wall guard must fail after deliberate clock advance instead of passing from automatic virtual time movement. In particular, clearing only the third bidi request timeout must fail at `bidi deadline stalled`; the first two phases still need to pass. This is an explicit timeout-loss simulation, not proof that every possible adapter mutation is detected. An actual adapter deadline-removal control is stronger if a separate isolated build is affordable.

Patch SHA-256: `e917999e3d040cc4476697167ee15cf4df04841e8e8412e1162fab3b01486057`.
