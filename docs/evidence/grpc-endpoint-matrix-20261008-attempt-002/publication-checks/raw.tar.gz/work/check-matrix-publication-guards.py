"""Check the real publisher against local Git repos; no network or live main."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path('/workspace/pure-protobuf')
out = root / 'work/matrix-publication-guards'
out.mkdir(exist_ok=False)
controller = root / 'docs/evidence/grpc-endpoint-matrix-20261008-attempt-002/controller.py'
results = []

def git(directory, *args):
    return subprocess.check_output(['git', *args], cwd=directory, stderr=subprocess.STDOUT, text=True).strip()

for mismatch in [False, True]:
    case = out / ('mismatch' if mismatch else 'failed-build')
    case.mkdir()
    bare, repo = case / 'origin.git', case / 'repo'
    git(case, 'init', '--bare', '--initial-branch=main', str(bare))
    repo.mkdir()
    git(repo, 'init', '--initial-branch=main')
    git(repo, 'config', 'user.name', 'Publisher guard')
    git(repo, 'config', 'user.email', 'publisher-guard@example.invalid')
    git(repo, 'remote', 'add', 'origin', str(bare))
    relative = Path('docs/evidence/test-publication')
    (repo / relative).mkdir(parents=True)
    (repo / relative / 'started.json').write_text(json.dumps({
        'source_commit': 'b' * 40 if mismatch else 'a' * 40,
        'controller_sha256': hashlib.sha256(controller.read_bytes()).hexdigest()}))
    git(repo, 'add', '.')
    git(repo, 'commit', '-m', 'Synthetic preparation')
    git(repo, 'push', 'origin', 'HEAD:main')
    before = git(bare, 'rev-parse', 'main')
    source = case / 'source'
    (source / 'scripts').mkdir(parents=True)
    # The injected builder always fails. No real build/counter qualification.
    (source / 'scripts/build-rpc-bench.py').write_text("import sys\nprint('synthetic compiler failure retained')\nsys.exit(7)\n")
    check = source / 'docs/evidence/grpc-readiness-20261008/check.py'
    check.parent.mkdir(parents=True)
    shutil.copy2(root / 'docs/evidence/grpc-readiness-20261008/check.py', check)
    capture = case / 'capture'
    argv = ['python3', str(controller), '--source', 'a' * 40, '--source-dir', str(source),
            '--root', str(repo), '--output', str(capture), '--evidence-path', str(relative),
            '--valgrind', '/unused/synthetic-valgrind']
    result = subprocess.run(argv, capture_output=True)
    (case / 'publisher.stdout').write_bytes(result.stdout)
    (case / 'publisher.stderr').write_bytes(result.stderr)
    after = git(bare, 'rev-parse', 'main')
    if mismatch:
        assert result.returncode != 0 and before == after
        assert b'publication source/controller mismatch' in result.stderr
    else:
        assert result.returncode == 0 and before != after
        checkout = capture / 'publication-checkout'
        subprocess.run(['python3', str(checkout / relative / 'check.py')], check=True, capture_output=True)
        outcome = json.loads((checkout / relative / 'outcome.json').read_text())
        assert outcome['commands'][0]['exit_code'] == 7
        assert outcome['qualified'] is False
        manifest = json.loads((checkout / relative / 'manifest.json').read_text())
        assert {entry['path'] for entry in manifest['files']} >= {'build.stdout', 'build.stderr', 'controller-status.json'}
        assert json.loads((capture / 'controller-status.json').read_text())['publication_commit'] == after
    results.append({'synthetic': True, 'mismatch': mismatch, 'command': argv,
                    'exit_code': result.returncode, 'main_changed': before != after,
                    'passed': True, 'production_qualification': False})
(out / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps({'passed': len(results), 'scope': 'local fake-build Git publication controls only'}))
