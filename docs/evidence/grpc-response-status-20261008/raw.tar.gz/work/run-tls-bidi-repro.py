from pathlib import Path
import os,json,subprocess,shutil,hashlib,resource
root=Path('/workspace/pure-protobuf')
messages=[json.loads(line) for line in (root/'work/readiness/tls-bidi-diagnostic-build.jsonl').read_text().splitlines()]
artifacts=[m['executable'] for m in messages if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(root/'pbrs-grpc/Cargo.toml') and m.get('target',{}).get('name')=='resource_qualification' and m.get('executable')]
assert len(artifacts)==1
base=root/'work/tls-bidi-repro';base.mkdir(exist_ok=False)
exe=base/'resource-test';shutil.copy2(artifacts[0],exe)
limits={'address_space':1073741824,'file_descriptors':128,'same_uid_processes':4096,'cpu_seconds':60}
def apply_limits():
 for name,kind in [('address_space',resource.RLIMIT_AS),('file_descriptors',resource.RLIMIT_NOFILE),('same_uid_processes',resource.RLIMIT_NPROC),('cpu_seconds',resource.RLIMIT_CPU)]:
  resource.setrlimit(kind,(limits[name],limits[name]))
 resource.setrlimit(resource.RLIMIT_CORE,(0,0))
results=[]
for repeat in range(5):
 directory=base/f'repeat-{repeat:02}';directory.mkdir()
 argv=[str(exe),'--exact','current_h2_resource_campaign','--ignored','--nocapture','--test-threads=1']
 env={**os.environ,'PBRS_CURRENT_H2_EVENTS':str(directory/'events.jsonl'),'PBRS_CURRENT_H2_SECONDS':'30','PBRS_CURRENT_H2_SEED':'20261008'}
 with (directory/'stdout.log').open('w') as out,(directory/'stderr.log').open('w') as err:
  result=subprocess.run(argv,cwd=root,env=env,stdout=out,stderr=err,preexec_fn=apply_limits,timeout=50,check=False)
 results.append({'repeat':repeat,'command':argv,'exit_code':result.returncode,'limits':limits})
 (base/'replays.json').write_text(json.dumps({'scope':'diagnostic replays; not a source-clean soak','binary_sha256':hashlib.sha256(exe.read_bytes()).hexdigest(),'runs':results},indent=2)+'\n')
 if result.returncode:break
