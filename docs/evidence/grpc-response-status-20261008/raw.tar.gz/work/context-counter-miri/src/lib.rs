#[cfg(target_os = "linux")]
mod linux_ffi {
    #[repr(C)]
    pub struct Timeval {
        pub tv_sec: i64,
        pub tv_usec: i64,
    }

    #[repr(C)]
    pub struct Rusage {
        pub ru_utime: Timeval,
        pub ru_stime: Timeval,
        pub ru_maxrss: i64,
        pub ru_ixrss: i64,
        pub ru_idrss: i64,
        pub ru_isrss: i64,
        pub ru_minflt: i64,
        pub ru_majflt: i64,
        pub ru_nswap: i64,
        pub ru_inblock: i64,
        pub ru_oublock: i64,
        pub ru_msgsnd: i64,
        pub ru_msgrcv: i64,
        pub ru_nsignals: i64,
        pub ru_nvcsw: i64,
        pub ru_nivcsw: i64,
    }

    pub const RUSAGE_SELF: i32 = 0;

    unsafe extern "C" {
        pub fn getrusage(who: i32, usage: *mut Rusage) -> i32;
    }
}

/// Cumulative context switches across all threads, including exited threads.
#[derive(Debug, Clone, Copy)]
pub struct ContextSwitches {
    pub voluntary: u64,
    pub involuntary: u64,
}

/// Read Linux process-lifetime totals, without substituting missing counters.
#[cfg(all(target_os = "linux", target_pointer_width = "64"))]
pub fn context_switches() -> std::io::Result<ContextSwitches> {
    use linux_ffi::{RUSAGE_SELF, Rusage, getrusage};
    // SAFETY: Rusage has the Linux 64-bit C layout, the output pointer is
    // valid, and the initialized buffer remains local to this call.
    let usage = unsafe {
        let mut usage: Rusage = std::mem::zeroed();
        if getrusage(RUSAGE_SELF, &mut usage) != 0 {
            return Err(std::io::Error::last_os_error());
        }
        usage
    };
    let count = |value| {
        u64::try_from(value).map_err(|_| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "negative process context-switch counter",
            )
        })
    };
    Ok(ContextSwitches {
        voluntary: count(usage.ru_nvcsw)?,
        involuntary: count(usage.ru_nivcsw)?,
    })
}

/// Context-switch capture is currently available on 64-bit Linux only.
#[cfg(not(all(target_os = "linux", target_pointer_width = "64")))]
pub fn context_switches() -> std::io::Result<ContextSwitches> {
    Err(std::io::Error::new(
        std::io::ErrorKind::Unsupported,
        "process context-switch capture requires 64-bit Linux",
    ))
}


#[test]
fn process_counter_call() { let value=context_switches().expect("counters"); assert!(value.voluntary < u64::MAX); assert!(value.involuntary < u64::MAX); }
