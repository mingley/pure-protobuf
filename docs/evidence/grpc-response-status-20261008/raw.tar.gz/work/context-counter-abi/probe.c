#include <sys/resource.h>
#include <stddef.h>
#include <stdio.h>
_Static_assert(sizeof(long) == 8, "Linux long");
_Static_assert(sizeof(struct timeval) == 16, "timeval size");
_Static_assert(sizeof(struct rusage) == 144, "rusage size");
_Static_assert(_Alignof(struct rusage) == 8, "rusage alignment");
_Static_assert(offsetof(struct rusage, ru_nvcsw) == 128, "voluntary offset");
_Static_assert(offsetof(struct rusage, ru_nivcsw) == 136, "involuntary offset");
int main(void) { struct rusage r = {0}; if (getrusage(RUSAGE_SELF, &r)) return 1;
printf("{\"rusage_size\":%zu,\"rusage_alignment\":%zu,\"voluntary_offset\":%zu,\"involuntary_offset\":%zu,\"getrusage_succeeded\":true}\n", sizeof(r), _Alignof(struct rusage), offsetof(struct rusage, ru_nvcsw), offsetof(struct rusage, ru_nivcsw)); return 0; }
