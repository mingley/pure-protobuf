import json,os,subprocess,time,hashlib
from pathlib import Path
root=Path('/workspace/pure-protobuf');out=root/'work/readiness/final-status-gates';out.mkdir(exist_ok=False)
commands=[
 ['cargo','clippy','--locked','-p','pbrs-grpc','--all-features','--all-targets','--','-D','warnings'],
 ['cargo','doc','--locked','-p','pbrs-grpc','--no-deps','--all-features'],
 ['cargo','clippy','--locked','--manifest-path','rpc-bench/Cargo.toml','--all-targets','--features','allocation-counts','--','-D','warnings'],
 ['cargo','test','--locked','--manifest-path','rpc-bench/Cargo.toml','--features','allocation-counts','--test','load_shapes','--','--test-threads=1'],
 ['cargo','test','--locked','-p','pbrs-grpc','--test','resource_bounds','--','--test-threads=1'],
]
results=[]
for i,argv in enumerate(commands):
 env={**os.environ,'PATH':str(root/'work/toolchain/protoc/bin')+':'+os.environ['PATH']}
 if argv[1]=='doc':env['RUSTDOCFLAGS']='-D warnings'
 (out/f'{i:02}.source.patch').write_bytes(subprocess.check_output(['git','diff','HEAD'],cwd=root))
 start=time.time()
 with (out/f'{i:02}.stdout').open('w') as stdout,(out/f'{i:02}.stderr').open('w') as stderr:
  result=subprocess.run([str(root/'work/run-rust'),*argv],cwd=root,env=env,stdout=stdout,stderr=stderr)
 results.append({'command':argv,'exit_code':result.returncode,'elapsed_seconds':time.time()-start,'environment_overrides':{'RUSTDOCFLAGS':'-D warnings'} if argv[1]=='doc' else {}})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
