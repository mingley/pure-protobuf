import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/pure-protobuf')
out=root/'work/readiness/partial-status-gates'
out.mkdir(exist_ok=False)
paths=['pbrs-grpc/src/wire/frame_reader.rs','pbrs-grpc/src/server/rpc.rs','pbrs-grpc/tests/resource_qualification.rs','pbrs-grpc/tests/streaming_final_status.rs']
source={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'working_tree':True,'files':{p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}}
(out/'source.json').write_text(json.dumps(source,indent=2)+'\n')
commands=[
 ['cargo','test','--locked','-p','pbrs-grpc','--lib'],
 ['cargo','test','--locked','-p','pbrs-grpc','--test','rpc','--test','tls','--test','hostile','--test','message_size','--test','bidi_completion','--test','regress_timeout','--test','byte_budget_public','--test','resource_qualification','--test','lifecycle'],
 ['cargo','test','--locked','-p','pbrs-grpc','--all-features','--test','prost_codec','--test','grpc_web','--test','tower_client','--test','tonic_behavior','--test','binlog'],
 ['cargo','clippy','--locked','-p','pbrs-grpc','--all-features','--all-targets','--','-D','warnings'],
 ['cargo','test','--locked','--manifest-path','rpc-bench/Cargo.toml'],
 ['cargo','clippy','--locked','--manifest-path','rpc-bench/Cargo.toml','--all-targets','--','-D','warnings'],
 ['cargo','test','--locked','-p','pbrs-grpc','--test','resource_bounds','--','--test-threads=1'],
]
results=[]
for i,argv in enumerate(commands):
 start=time.time()
 with (out/f'{i:02}.stdout').open('w') as stdout,(out/f'{i:02}.stderr').open('w') as stderr:
  result=subprocess.run([str(root/'work/run-rust'),*argv],cwd=root,env={**os.environ,'PATH':str(root/'work/toolchain/protoc/bin')+':'+os.environ['PATH']},stdout=stdout,stderr=stderr)
 results.append({'command':argv,'exit_code':result.returncode,'elapsed_seconds':time.time()-start})
 (out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
