#[cfg(target_os = "linux")]
mod linux_ffi {
    #[repr(C)]
    pub struct Timeval {
        pub tv_sec: i64,
        pub tv_usec: i64,
    }

    #[repr(C)]
    pub struct Rusage {
        pub ru_utime: Timeval,
        pub ru_stime: Timeval,
        pub ru_maxrss: i64,
        pub ru_ixrss: i64,
        pub ru_idrss: i64,
        pub ru_isrss: i64,
        pub ru_minflt: i64,
        pub ru_majflt: i64,
        pub ru_nswap: i64,
        pub ru_inblock: i64,
        pub ru_oublock: i64,
        pub ru_msgsnd: i64,
        pub ru_msgrcv: i64,
        pub ru_nsignals: i64,
        pub ru_nvcsw: i64,
        pub ru_nivcsw: i64,
    }

    pub const RUSAGE_SELF: i32 = 0;

    pub static COUNT: std::sync::atomic::AtomicI64 = std::sync::atomic::AtomicI64::new(0);
    pub static FAIL: std::sync::atomic::AtomicBool = std::sync::atomic::AtomicBool::new(false);
    pub unsafe extern "C" fn getrusage(who: i32, usage: *mut Rusage) -> i32 {
        assert_eq!(who, RUSAGE_SELF);
        if FAIL.load(std::sync::atomic::Ordering::SeqCst) { return -1; }
        // Mock only: Miri checks the actual caller's initialized stack buffer.
        unsafe {
            let record = &mut *usage;
            record.ru_nvcsw = COUNT.load(std::sync::atomic::Ordering::SeqCst);
            record.ru_nivcsw = 7;
        }
        0
    }
}

/// Cumulative context switches across all threads, including exited threads.
#[derive(Debug, Clone, Copy)]
pub struct ContextSwitches {
    pub voluntary: u64,
    pub involuntary: u64,
}

/// Read Linux process-lifetime totals, without substituting missing counters.
#[cfg(all(target_os = "linux", target_pointer_width = "64"))]
pub fn context_switches() -> std::io::Result<ContextSwitches> {
    use linux_ffi::{RUSAGE_SELF, Rusage, getrusage};
    // SAFETY: Rusage has the Linux 64-bit C layout, the output pointer is
    // valid, and the initialized buffer remains local to this call.
    let usage = unsafe {
        let mut usage: Rusage = std::mem::zeroed();
        if getrusage(RUSAGE_SELF, &mut usage) != 0 {
            return Err(std::io::Error::last_os_error());
        }
        usage
    };
    let count = |value| {
        u64::try_from(value).map_err(|_| {
            std::io::Error::new(
                std::io::ErrorKind::InvalidData,
                "negative process context-switch counter",
            )
        })
    };
    Ok(ContextSwitches {
        voluntary: count(usage.ru_nvcsw)?,
        involuntary: count(usage.ru_nivcsw)?,
    })
}

/// Context-switch capture is currently available on 64-bit Linux only.
#[cfg(not(all(target_os = "linux", target_pointer_width = "64")))]
pub fn context_switches() -> std::io::Result<ContextSwitches> {
    Err(std::io::Error::new(
        std::io::ErrorKind::Unsupported,
        "process context-switch capture requires 64-bit Linux",
    ))
}


#[test]
fn caller_buffer_layout_and_conversion() {
    use std::sync::atomic::Ordering::SeqCst;
    assert_eq!(std::mem::size_of::<linux_ffi::Timeval>(), 16);
    assert_eq!(std::mem::size_of::<linux_ffi::Rusage>(), 144);
    assert_eq!(std::mem::align_of::<linux_ffi::Rusage>(), 8);
    assert_eq!(std::mem::offset_of!(linux_ffi::Rusage, ru_nvcsw), 128);
    assert_eq!(std::mem::offset_of!(linux_ffi::Rusage, ru_nivcsw), 136);
    for n in [0, 1, i64::MAX] {
        linux_ffi::COUNT.store(n, SeqCst);
        let observed=context_switches().expect("mock counts");
        assert_eq!(observed.voluntary, u64::try_from(n).unwrap());
        assert_eq!(observed.involuntary, 7);
    }
    linux_ffi::COUNT.store(-1, SeqCst);
    assert_eq!(context_switches().unwrap_err().kind(), std::io::ErrorKind::InvalidData);
    linux_ffi::FAIL.store(true, SeqCst);
    assert!(context_switches().is_err());
}
