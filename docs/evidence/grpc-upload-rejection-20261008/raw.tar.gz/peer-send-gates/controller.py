import json,os,subprocess,time
from pathlib import Path
root=Path('/workspace/pure-protobuf');out=root/'work/peer-send-gates'
commands=[['cargo', 'clippy', '--locked', '-p', 'pbrs-grpc', '--all-features', '--all-targets', '--', '-D', 'warnings'], ['cargo', 'doc', '--locked', '-p', 'pbrs-grpc', '--all-features', '--no-deps'], ['cargo', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', '--test', 'retry_safety', '--test', 'policy_retry', '--test', 'streaming_final_status', '--test', 'deadline_admission']]
records=[]
for i,cmd in enumerate(commands):
 start=time.monotonic()
 env=dict(os.environ)
 if cmd[1]=='doc':env['RUSTDOCFLAGS']='-D warnings'
 with (out/f'{i}.stdout').open('w') as stdout,(out/f'{i}.stderr').open('w') as stderr:
  result=subprocess.run([str(root/'work/run-rust'),*cmd],cwd=root,stdout=stdout,stderr=stderr,env=env)
 records.append(dict(command=cmd,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start))
 (out/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(i,result.returncode,flush=True)
 if result.returncode:break
