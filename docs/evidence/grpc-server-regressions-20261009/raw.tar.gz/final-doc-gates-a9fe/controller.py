import json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');OUT=ROOT/'work/final-doc-gates-a9fe';OUT.mkdir(exist_ok=False)
PIN='a9fe4c2d336710cea6f997b00277e6410eee672a'
SOURCE=ROOT/'work/gates-candidate-05f5'
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report={'source':PIN,'state':'waiting_for_native_suites','passed':False,'qualified':False,'results':[]}
def save(): (OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
while True:
 try: native=json.loads((ROOT/'work/native-sequential-gates-a9fe/results.json').read_text())
 except (OSError,json.JSONDecodeError): native={}
 if native.get('state')=='finished':break
 time.sleep(3)
report['state']='running'; report['retries']='documentation and Rustdoc only; prior formatting, plan, queue, Clippy passed';save()
os.environ['PATH']=str(ROOT/'work/toolchain/protoc/bin')+os.pathsep+os.environ['PATH']
os.environ['PROTOC']=str(ROOT/'work/toolchain/protoc/bin/protoc')
steps=[('format',['cargo','fmt','--all','--','--check'],{}),('clippy',['cargo','clippy','--locked','-p','pbrs-grpc','--all-features','--test','serving','--','-D','warnings'],{})]
for name,args,extra in steps:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==PIN
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=SOURCE,text=True)
 start=time.monotonic();directory=OUT/name;directory.mkdir()
 argv=[str(ROOT/'work/run-rust'),*args] if args[0]=='cargo' else args
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  p=subprocess.run(argv,cwd=SOURCE,env={**os.environ,**extra},stdout=out,stderr=err)
 report['results'].append(dict(name=name,argv=argv,environment_overrides=extra,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start));save();print(name,p.returncode,flush=True)
 if p.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(steps) and all(r['exit_code']==0 for r in report['results']);save()
