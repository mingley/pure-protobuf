import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');OUT=ROOT/'work/server-failure-isolation-a9fe';OUT.mkdir(exist_ok=False)
BINARY=ROOT/'work/native-sequential-gates-a9fe/serving/failed-test'
expected=json.loads((ROOT/'work/native-sequential-gates-a9fe/results.json').read_text())['results'][0]['executable_sha256']
assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==expected
report=dict(source='a9fe4c2d336710cea6f997b00277e6410eee672a',binary_sha256=expected,qualified=False,state='running',limits='isolated original regressions with unchanged deadline and cancellation assertions',runs=[])
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
for repeat in range(10):
 for name in ['a_from_io_server_timeout_expires_when_the_client_sends_none','mtls_spawned_work_stops_when_the_client_cancels','mtls_wait_for_ready_completes_once_the_server_listens','mtls_wait_for_ready_times_out_when_nothing_is_listening']:
  directory=OUT/f'{repeat:02d}-{name}';directory.mkdir();start=time.monotonic();args=[str(BINARY),'--exact',name,'--test-threads=1']
  with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
   try:p=subprocess.run(args,stdout=out,stderr=err,timeout=15);code=p.returncode
   except subprocess.TimeoutExpired:code='watchdog_expired'
  report['runs'].append(dict(command=args,repeat=repeat,exit_code=code,elapsed_seconds=time.monotonic()-start));(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(repeat,name,code,flush=True)
report['state']='finished';report['passed']=all(row['exit_code']==0 for row in report['runs']);(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
