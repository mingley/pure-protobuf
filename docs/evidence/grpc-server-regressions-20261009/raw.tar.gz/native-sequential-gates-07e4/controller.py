import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');SOURCE=ROOT/'work/gates-candidate-05f5';OUTPUT=ROOT/'work/native-sequential-gates-07e4';OUTPUT.mkdir(exist_ok=False)
PIN='07e409aed328c9716718eb70ff05c15848fbb664'
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def clean():assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain','--untracked-files=all')
(OUTPUT/'results.json').write_text(json.dumps(dict(source=PIN,state='waiting_for_prior_suite',passed=False,qualified=False))+'\n')
while True:
 try: prior=json.loads((ROOT/'work/native-sequential-gates-05f5/results.json').read_text())
 except (FileNotFoundError,json.JSONDecodeError):prior={}
 if prior.get('state')=='finished':break
 time.sleep(3)
assert git('rev-parse','HEAD')=='05f51220786702350712ecd301f87839d1bbc5d0'
assert not git('status','--porcelain','--untracked-files=all')
subprocess.run(['git','checkout','--detach',PIN],cwd=SOURCE,check=True)
clean();shutil.copy2(__file__,OUTPUT/'controller.py')
targets=['codegen','lib']+[p.stem for p in sorted((SOURCE/'pbrs-grpc/tests').glob('*.rs')) if p.stem not in ['caller_rustls','codegen']]+['caller_rustls']
completed=set()
prior_reports=['native-sequential-gates-2c66','native-sequential-gates-2c66-continuation','native-sequential-gates-05f5']
for directory in prior_reports:
 prior=json.loads((ROOT/'work'/directory/'results.json').read_text())
 for row in prior['results']:
  if row['exit_code']==0 and 'artifact_error' not in row:
   completed.add('lib' if '--lib' in row['command'] else row['command'][-2])
targets=['serving']+[t for t in targets if t not in completed and t!='serving']
os.environ['PROTOC']=str(ROOT/'work/toolchain/protoc/bin/protoc')
os.environ['PATH']=str(ROOT/'work/toolchain/protoc/bin')+os.pathsep+os.environ['PATH']
report=dict(source=PIN,qualified=False,state='running',prior_reports=prior_reports,environment_overrides={'PROTOC':os.environ['PROTOC']},targets=targets,results=[],limits=['all native library and integration targets on a clean source; no timing or production qualification'])
for name in targets:
 args=['cargo','test','--locked','-p','pbrs-grpc','--all-features',*(['--lib'] if name=='lib' else ['--test',name]),'--message-format=json']
 directory=OUTPUT/name;directory.mkdir();start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  result=subprocess.run([str(ROOT/'work/run-rust'),*args],cwd=SOURCE,stdout=out,stderr=err)
 record=dict(command=args,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
 artifacts=[]
 for line in (directory/'stdout').read_text().splitlines():
  try:m=json.loads(line)
  except json.JSONDecodeError:continue
  if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(SOURCE/'pbrs-grpc/Cargo.toml') and m.get('target',{}).get('name')==('pbrs_grpc' if name=='lib' else name) and m.get('executable') and m.get('profile',{}).get('test') is True:artifacts.append(m)
 if len(artifacts)==1:
  artifact=artifacts[0];p=Path(artifact['executable']);record['artifact']=artifact
  record['executable_sha256']=sha(p);record['executable_bytes']=p.stat().st_size
  if result.returncode:
   shutil.copy2(p,directory/'failed-test')
  p.unlink();record['inactive_executable_cache_removed']=True
 else:record['artifact_error']='expected one compiler-selected test executable'
 clean();record['source_unchanged']=True
 if name!='lib':
  active=[]
  for proc in Path('/proc').iterdir():
   if proc.name.isdigit():
    try:active.extend(a.decode().split('incremental=',1)[1] for a in (proc/'cmdline').read_bytes().split(b'\0') if a.startswith(b'incremental='))
    except OSError:pass
  record['inactive_incremental_caches_removed']=[]
  for p in (ROOT/'work/target/debug/incremental').glob(name+'-*'):
   if p.is_dir() and str(p) not in active:
    size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file());shutil.rmtree(p);record['inactive_incremental_caches_removed'].append(dict(path=str(p),bytes=size))
 report['results'].append(record);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(targets) and all(r['exit_code']==0 and 'artifact_error' not in r for r in report['results']);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
