fn channel_config_max_connection_idle_documents_with_idle_timeout() {
    let src = include_str!("../src/config.rs");
    assert!(
        src.contains(
            "There is no grpc-go `WithIdleTimeout` idle mode: that shuts down the\n    /// name resolver and load balancer after channel idle (default 30 min;\n    /// zero disables). This cap closes the socket when no RPCs are outstanding\n    /// (unset by default; sub-millisecond values are raised to 1 ms, not\n    /// disabled). Distinct from [`Self::max_connection_age`] (age, not idle).\n    /// Distinct from [`ServerConfig::max_connection_idle`] (server GOAWAY).\n    /// There is no resolver or load balancer to shut down."
        ),
        "ChannelConfig::max_connection_idle rustdoc must Distinct socket close from grpc-go WithIdleTimeout idle mode"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithIdleTimeout`").count(),
        1,
        "ServerConfig::max_connection_idle must not copy the WithIdleTimeout Distinct"
    );
}
