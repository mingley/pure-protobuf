fn server_and_router_config_document_every_call_shape() {
    let src = concat!(
        include_str!("../src/server.rs"),
        include_str!("../src/server/accept.rs"),
        include_str!("../src/server/connection.rs"),
        include_str!("../src/server/dispatch.rs"),
        include_str!("../src/server/drain.rs"),
        include_str!("../src/server/router.rs"),
        include_str!("../src/server/rpc.rs"),
    );
    assert_eq!(
        src.matches("The configuration in effect. Applies to every call shape.")
            .count(),
        2,
        "Server::server_config and Router::server_config must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Replace the transport and limit configuration. Applies to every call\n    /// shape."
        )
        .count(),
        2,
        "Server::config and Router::config must name every call shape"
    );
    assert_eq!(
        src.matches("Cap every RPC even when the client omits `grpc-timeout`.\n    /// Applies to every call shape.")
            .count(),
        2,
        "Server::rpc_timeout and Router::rpc_timeout must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Whether responses are gzipped when the client accepts gzip.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::compresses_outbound and Router::compresses_outbound must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Whether inbound gzip is inflated. Default `true`.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::accepts_compressed and Router::accepts_compressed must name every call shape"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::max_concurrent_rpcs`], which sets it.")
            .count(),
        2,
        "Server::concurrent_rpc_limit and Router::concurrent_rpc_limit must Distinct the setter"
    );
    assert!(
        src.contains(
            "Serve until `shutdown` resolves, then drain. Applies to every call\n    /// shape. In-flight RPCs finish; new connections are refused. TLS and"
        ),
        "Server::serve_with_shutdown must name TLS and Unix drain"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WaitForHandlers` setter: grpc-go `Stop` can\n    /// return before handlers exit; this drain always waits for in-flight\n    /// RPCs. Distinct from [`ServerConfig::max_connection_age_grace`]: that\n    /// is GOAWAY then force-close, not this process-wide drain. Distinct\n    /// from [`crate::health::HealthReporter::shutdown`]: that flips serving\n    /// status, it does not drain. [`Self::serve_connection`] is one duplex:\n    /// no accept loop to refuse."
        ),
        "Server::serve_with_shutdown rustdoc must Distinct drain wait from grpc-go WaitForHandlers"
    );
    assert!(
        src.contains(
            "There is no tonic `Server::trace_fn`: that intercepts inbound headers and\n/// installs a `tracing::Span` on each response future. This type has no span\n/// installer. Distinct from [`crate::Interceptor`] (envelope mutation, not a\n/// span). Distinct from grpc.stats `Handler` (Begin/End/payload). Distinct from\n/// binary logging (`grpc.binarylog.v1`). Distinct from OpenTelemetry. Distinct\n/// from tonic `Server::layer` (tower)."
        ),
        "Server rustdoc must Distinct no span installer from tonic Server::trace_fn"
    );
    assert_eq!(
        src.matches("There is no tonic `Server::trace_fn`").count(),
        1,
        "Router must not copy the Server::trace_fn Distinct"
    );
    assert_eq!(
        src.matches("HTTP/2 PING keepalive. Applies to every call shape.")
            .count(),
        2,
        "Server::keep_alive_interval and Router::keep_alive_interval must name every call shape"
    );
    assert_eq!(
        src.matches(
            "How long to wait for a PING acknowledgement. Applies to every call\n    /// shape."
        )
        .count(),
        2,
        "Server::keep_alive_timeout and Router::keep_alive_timeout must name every call shape"
    );
    assert_eq!(
        src.matches("TCP `SO_KEEPALIVE`. Applies to every call shape.")
            .count(),
        2,
        "Server::tcp_keepalive and Router::tcp_keepalive must name every call shape"
    );
    assert_eq!(
        src.matches("TCP `TCP_KEEPINTVL` probe interval. Applies to every call shape.")
            .count(),
        2,
        "Server::tcp_keepalive_interval and Router::tcp_keepalive_interval must name every call shape"
    );
    assert_eq!(
        src.matches("TCP `TCP_KEEPCNT` probe count. Applies to every call shape.")
            .count(),
        2,
        "Server::tcp_keepalive_retries and Router::tcp_keepalive_retries must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Send GOAWAY this long after accept. The next RPC of every call shape\n    /// redials, including over TLS, mTLS, and Unix; transparent retry of the\n    /// same in-flight RPC is unary and server-streaming after request bytes,"
        )
        .count(),
        2,
        "Server::max_connection_age and Router::max_connection_age must name redial on TLS, mTLS, and Unix"
    );
    assert_eq!(
        src.matches(
            "Send GOAWAY after this long with no outstanding RPCs. The next RPC of\n    /// every call shape redials, including over TLS, mTLS, and Unix."
        )
        .count(),
        2,
        "Server::max_connection_idle and Router::max_connection_idle must name redial on TLS, mTLS, and Unix"
    );
    assert_eq!(
        src.matches(
            "including over TLS, mTLS, Unix, and [`Self::serve_connection`].\n    /// Applies to every call shape. See [`ServerConfig::max_connection_age_grace`]."
        )
        .count(),
        2,
        "Server::max_connection_age_grace and Router::max_connection_age_grace must name every transport"
    );
    assert_eq!(
        src.matches(
            "Cap how many TCP/Unix connections the accept loop will serve at once,\n    /// including TLS and mTLS listeners. Applies to every call shape."
        )
        .count(),
        2,
        "Server::max_concurrent_connections and Router::max_concurrent_connections must name TLS and mTLS"
    );
    assert_eq!(
        src.matches(
            "Drop a client that never finishes TLS or the HTTP/2 preface.\n    /// Applies to every call shape, including over TLS, mTLS, and Unix."
        )
        .count(),
        2,
        "Server::handshake_timeout and Router::handshake_timeout must name TLS, mTLS, and Unix"
    );
    assert_eq!(
        src.matches("fails. Applies to every call shape.").count(),
        2,
        "Server::serve_unix and Router::serve_unix must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Serve over TLS until `shutdown` resolves, then drain.\n    /// Applies to every call shape, including mTLS. In-flight RPCs finish;\n    /// new connections are refused."
        )
        .count(),
        2,
        "Server::serve_tls_with_shutdown and Router::serve_tls_with_shutdown must name mTLS drain"
    );
    assert_eq!(
        src.matches(
            "Serve h2c on a Unix listener until `shutdown` resolves, then drain.\n    /// Applies to every call shape. In-flight RPCs finish; new connections\n    /// are refused."
        )
        .count(),
        2,
        "Server::serve_unix_with_shutdown and Router::serve_unix_with_shutdown must name drain"
    );
    assert_eq!(
        src.matches("Replace both message caps at once. Applies to every call shape.")
            .count(),
        2,
        "Server::message_limits and Router::message_limits must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`Self::max_decoding_message_size`] /\n    /// [`Self::max_encoding_message_size`]. Oversize inbound or outbound\n    /// is [`Code::ResourceExhausted`], including over TLS, mTLS, Unix, and\n    /// [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::message_limits and Router::message_limits must name combined-setter oversize on every transport"
    );
    assert_eq!(
        src.matches(
            "Cap how many RPCs the process will run at once.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::max_concurrent_rpcs and Router::max_concurrent_rpcs must name every transport"
    );
    assert_eq!(
        src.matches(
            "Concurrent RPCs allowed per HTTP/2 connection. Applies to every call\n    /// shape."
        )
        .count(),
        2,
        "Server::max_concurrent_streams and Router::max_concurrent_streams must name every call shape"
    );
    assert_eq!(
        src.matches(
            "HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`. Distinct from\n    /// [`Self::max_concurrent_rpcs`], which refuses extras as\n    /// [`Code::ResourceExhausted`]. A well-behaved client waits; both RPCs\n    /// still complete, including over TLS, mTLS, Unix, and\n    /// [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::max_concurrent_streams and Router::max_concurrent_streams must name serialize vs RESOURCE_EXHAUSTED on every transport"
    );
    assert_eq!(
        src.matches("HTTP/2 per-stream receive window. Applies to every call shape.")
            .count(),
        2,
        "Server::initial_stream_window_size and Router::initial_stream_window_size must name every call shape"
    );
    assert_eq!(
        src.matches("HTTP/2 per-connection receive window. Applies to every call shape.")
            .count(),
        2,
        "Server::initial_connection_window_size and Router::initial_connection_window_size must name every call shape"
    );
    assert_eq!(
        src.matches("HTTP/2 `SETTINGS_MAX_FRAME_SIZE`. Applies to every call shape.")
            .count(),
        2,
        "Server::max_frame_size and Router::max_frame_size must name every call shape"
    );
    assert_eq!(
        src.matches(
            "A well-behaved client splits DATA; every call shape still completes,\n    /// including over TLS, mTLS, Unix, and [`Self::serve_connection`]. Distinct\n    /// from [`Self::max_header_list_size`], which refuses oversize metadata,\n    /// and from [`Self::max_concurrent_streams`], which serializes extra RPCs."
        )
        .count(),
        2,
        "Server::max_frame_size and Router::max_frame_size must name still-serves Distinct from header-list and stream cap"
    );
    assert_eq!(
        src.matches(
            "A well-behaved client still completes every call shape, including over\n    /// TLS, mTLS, Unix, and [`Self::serve_connection`]. Distinct from\n    /// [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS\n    /// minimum, and from [`Self::max_concurrent_streams`], which serializes\n    /// extra RPCs."
        )
        .count(),
        4,
        "Server and Router window setters must name still-serves Distinct from frame size and stream cap"
    );
    assert_eq!(
        src.matches("HTTP/2 `SETTINGS_MAX_HEADER_LIST_SIZE`. Applies to every call shape.")
            .count(),
        2,
        "Server::max_header_list_size and Router::max_header_list_size must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Oversize metadata is refused, including over TLS, mTLS, Unix, and\n    /// [`Self::serve_connection`]. Distinct from a raw HTTP/2 peer."
        )
        .count(),
        2,
        "Server::max_header_list_size and Router::max_header_list_size must name oversize metadata on every transport"
    );
    assert_eq!(
        src.matches("Per-connection HTTP/2 send buffer. Applies to every call shape.")
            .count(),
        2,
        "Server::max_send_buffer_size and Router::max_send_buffer_size must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Write backpressure still completes every call shape, including over\n    /// TLS, mTLS, Unix, and [`Self::serve_connection`]. Distinct from\n    /// [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS\n    /// minimum, and from [`Self::initial_stream_window_size`], which still\n    /// serves at a small receive window."
        )
        .count(),
        2,
        "Server::max_send_buffer_size and Router::max_send_buffer_size must name still-serves Distinct from frame size and windows"
    );
    assert_eq!(
        src.matches(
            "Configured write-time HTTP/2 send buffer. See [`Self::max_send_buffer_size`]."
        )
        .count(),
        2,
        "Server::send_buffer_size and Router::send_buffer_size must Distinct the setter"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::max_send_buffer_size`], which sets it.")
            .count(),
        2,
        "Server::send_buffer_size and Router::send_buffer_size must Distinct from the setter"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`Self::message_limits`]: that is uncompressed protobuf bytes, not this send buffer."
        )
        .count(),
        2,
        "Server::send_buffer_size and Router::send_buffer_size must Distinct message size from the send buffer"
    );
    assert_eq!(
        src.matches("Configured message caps. See [`Self::message_limits`].")
            .count(),
        2,
        "Server::limits and Router::limits must Distinct the setter"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::message_limits`], which sets them.")
            .count(),
        2,
        "Server::limits and Router::limits must Distinct from the setter"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`Self::send_buffer_size`]: that is the HTTP/2 send buffer, not uncompressed protobuf bytes."
        )
        .count(),
        2,
        "Server::limits and Router::limits must Distinct the send buffer from message caps"
    );
    assert_eq!(
        src.matches("Same overlay as [`crate::Rpc::limits`].")
            .count(),
        2,
        "Server::limits and Router::limits must name the interceptor overlay"
    );
    assert_eq!(
        src.matches(
            "Cap remotely-reset HTTP/2 streams waiting in the accept queue.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::max_pending_accept_reset_streams and Router::max_pending_accept_reset_streams must name every call shape"
    );
    assert_eq!(
        src.matches(
            "A well-behaved client never fills that queue; every call shape still\n    /// completes, including over TLS, mTLS, Unix, and [`Self::serve_connection`].\n    /// Distinct from a raw HTTP/2 peer."
        )
        .count(),
        2,
        "Server and Router max_pending_accept_reset_streams must name still-serves Distinct from a raw RST flood"
    );
    assert_eq!(
        src.matches(
            "Cap locally-reset HTTP/2 streams caused by a peer protocol error.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::max_local_error_reset_streams and Router::max_local_error_reset_streams must name every call shape"
    );
    assert_eq!(
        src.matches("This caps RSTs we send after an invalid frame.")
            .count(),
        2,
        "Server and Router max_local_error_reset_streams must Distinct library RSTs from rapid reset"
    );
    assert_eq!(
        src.matches(
            "HTTP/2 `SETTINGS_HEADER_TABLE_SIZE` (HPACK dynamic table). Default 4096.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::header_table_size and Router::header_table_size must name every call shape"
    );
    assert_eq!(
        src.matches(
            "[`Self::max_header_list_size`], which caps uncompressed header-block\n    /// bytes (`SETTINGS_MAX_HEADER_LIST_SIZE`)."
        )
        .count(),
        2,
        "Server and Router header_table_size must Distinct from max_header_list_size"
    );
    assert_eq!(
        src.matches("HTTP/2 small-DATA framing budget. Default 25600.")
            .count(),
        2,
        "Server::data_frame_budget and Router::data_frame_budget must name every call shape"
    );
    assert_eq!(
        src.matches("h2 Auto (half the connection window) is not exposed.")
            .count(),
        2,
        "Server and Router data_frame_budget must not expose h2 Auto"
    );
    assert_eq!(
        src.matches("Cap remembered locally-reset HTTP/2 stream IDs.")
            .count(),
        2,
        "Server::max_concurrent_reset_streams and Router::max_concurrent_reset_streams must name remembered locally-reset stream IDs"
    );
    assert_eq!(
        src.matches("at this memory cap").count(),
        2,
        "Server and Router max_concurrent_reset_streams must still-serve at this memory cap"
    );
    assert_eq!(
        src.matches("How long locally-reset HTTP/2 stream IDs are remembered.")
            .count(),
        2,
        "Server::reset_stream_duration and Router::reset_stream_duration must name how long IDs are remembered"
    );
    assert_eq!(
        src.matches("at this reset duration").count(),
        2,
        "Server and Router reset_stream_duration must still-serve at this reset duration"
    );
    assert_eq!(
        src.matches(
            "Serve a single already-accepted byte stream until it closes.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::serve_connection and Router::serve_connection must name every call shape"
    );
    assert!(
        src.contains(
            "and [`Rpc::peer_cred`] are `None`. Generated handlers see the same\n    /// empty facts on [`Request`] and [`crate::Parts`]."
        ),
        "Server::serve_connection must name empty peer facts on Request/Parts"
    );
    assert!(
        src.contains("listener-side work fails.\n    /// Applies to every call shape."),
        "Server::serve_with_incoming must name every call shape"
    );
    assert_eq!(
        src.matches(
            "Override [`Incoming::peer`] to fill [`Rpc::local_addr`],\n    /// [`Rpc::peer_identity`], [`Rpc::peer_cred`], or a transport\n    /// [`Rpc::scheme`] without changing [`IncomingAccept`]."
        )
        .count(),
        2,
        "Server::serve_with_incoming and Router::serve_with_incoming must name Incoming::peer"
    );
    assert!(
        src.contains(
            "you accepted yourself). Applies to every call shape on that\n    /// connection."
        ),
        "Incoming::peer must name every call shape on that connection"
    );
    assert!(
        src.contains(
            "fn peer(&self, io: &Self::Io, remote: Option<SocketAddr>) -> ConnectionInfo {\n///         let _ = (self, io, remote);\n///         ConnectionInfo::new()\n///             .with_remote_addr(\"192.0.2.1:8\".parse().expect(\"remote\"))\n///             .with_local_addr(\"127.0.0.1:9\".parse().expect(\"local\"))\n///             .with_peer_identity(PeerIdentity::from_der_certs([b\"leaf\"]).expect(\"leaf\"))\n///             .with_peer_cred(PeerCred::new(42, 43, Some(44)))\n///             .with_scheme(\"https\")"
        ),
        "Incoming rustdoc must compile a ConnectionInfo peer dump"
    );
    assert!(
        src.contains(
            "[`Incoming::peer`] is how a custom acceptor supplies a local address,\n/// mTLS identity, Unix credentials, or a transport `:scheme`. The default\n/// keeps the `SocketAddr` from [`IncomingAccept`] and does not override\n/// `:scheme`. [`Server::serve_connection`] leaves every field unset.\n/// Applies to every call shape on that connection."
        ),
        "ConnectionInfo rustdoc must name Incoming::peer on every call shape"
    );
    assert!(
        src.contains(
            "Transport `:scheme` override, if set.\n    /// Distinct from [`Self::with_scheme`], which sets it."
        ),
        "ConnectionInfo::scheme must Distinct the setter"
    );
    assert!(
        src.contains(
            "Peer address, if set.\n    /// Distinct from [`Self::with_remote_addr`], which sets it."
        ),
        "ConnectionInfo::remote_addr must Distinct the setter"
    );
    assert!(
        src.contains(
            "Local address, if set.\n    /// Distinct from [`Self::with_local_addr`], which sets it."
        ),
        "ConnectionInfo::local_addr must Distinct the setter"
    );
    assert!(
        src.contains(
            "mTLS client certificate chain, if set.\n    /// Distinct from [`Self::with_peer_identity`], which sets it."
        ),
        "ConnectionInfo::peer_identity must Distinct the setter"
    );
    assert!(
        src.contains(
            "Unix credentials, if set.\n    /// Distinct from [`Self::with_peer_cred`], which sets it."
        ),
        "ConnectionInfo::peer_cred must Distinct the setter"
    );
    assert!(
        src.contains(
            "Start from the `SocketAddr` [`Incoming::accept`] returned.\n    /// Distinct from [`Self::new`]: that is empty facts, not this accept tuple."
        ),
        "ConnectionInfo::from_accept must Distinct empty facts"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::with_remote_addr`]: that overlays a builder; this starts from IncomingAccept.\n    #[must_use]\n    pub fn from_accept"
        ),
        "ConnectionInfo::from_accept must Distinct the remote-addr overlay"
    );
    assert!(
        src.contains(
            "override. Same as [`Default`].\n    /// Distinct from [`Self::from_accept`]: that copies the IncomingAccept tuple."
        ),
        "ConnectionInfo::new must Distinct the accept-tuple constructor"
    );
    assert!(
        src.contains(
            "Peer address reported as [`Rpc::remote_addr`].\n    /// Distinct from [`Self::from_accept`]: that starts from IncomingAccept; this overlays a builder."
        ),
        "ConnectionInfo::with_remote_addr must Distinct the accept-tuple constructor"
    );
    assert!(
        src.contains(
            "Serve connections from `incoming` until it is exhausted.\n    /// Applies to every call shape. See [`Server::serve_with_incoming`]."
        ),
        "Router::serve_with_incoming must name every call shape"
    );
    assert_eq!(
        src.matches(
            "[`Self::serve_with_incoming`] until `shutdown` resolves, then drain.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::serve_with_incoming_shutdown and Router::serve_with_incoming_shutdown must name every call shape"
    );
    assert!(
        src.contains(
            "TLS uses the client's [`crate::Target`], not SNI, unless\n    /// [`crate::Channel::origin`] overrode `:authority` on that clone."
        ),
        "Rpc::authority must name Target unless origin overrode it, not TLS SNI"
    );
    assert!(
        src.contains(
            "[`Self::max_decoding_message_size`] and\n    /// [`Self::max_encoding_message_size`] stay in effect on every mounted\n    /// service, on every call shape of those mounts, including over TLS, mTLS,\n    /// Unix, and [`Self::serve_connection`]."
        ),
        "Server::add_service must name decode and encode caps on every mount and transport"
    );
    assert!(
        src.contains(
            "A path whose service is not mounted, or a method a mounted service does\n/// not have, is [`crate::Code::Unimplemented`] on every call shape, including\n/// over TLS, mTLS, Unix, and [`Server::serve_connection`]."
        ),
        "Router rustdoc must name UNIMPLEMENTED on every mount miss and transport"
    );
    assert!(
        src.contains(
            "There is no grpc-go `UnknownServiceHandler` setter: that is a catch-all\n/// bidi handler for unregistered services. An unmounted service is\n/// [`crate::Code::Unimplemented`], not a fallback [`Service`]. Distinct from\n/// [`Server`]: that is one service; an unknown method there is still\n/// unimplemented, not a catch-all. Distinct from [`Service::ALIASES`]: that\n/// is a known path alias, not an unknown-service handler."
        ),
        "Router rustdoc must Distinct UNIMPLEMENTED from grpc-go UnknownServiceHandler catch-all"
    );
    assert!(
        src.contains(
            "Generated reflection also mounts `grpc.reflection.v1alpha.ServerReflection`\n/// as a [`Service::ALIASES`] path of v1, so older grpcurl still lists.\n/// Distinct from a second proto. Distinct from [`Server`], which does not\n/// look up the path."
        ),
        "Router rustdoc must Distinct v1alpha path alias from a second proto and from Server"
    );
    assert!(
        src.contains(
            "aliases `grpc.reflection.v1alpha.ServerReflection` so older grpcurl\n    /// that falls back to v1alpha hits the same handler. That is a path\n    /// alias, not a second proto and not a second `ServerReflectionServer`."
        ),
        "Service::ALIASES rustdoc must Distinct v1alpha path alias from a second proto"
    );
    assert!(
        src.contains(
            "Router with greeter + health + reflection still answers older grpcurl.\n    /// Distinct from a second proto: messages are the v1 types. Distinct from\n    /// [`Server::new`], which does not look up the path."
        ),
        "Router::add_service rustdoc must Distinct v1alpha alias from a second proto and from Server::new"
    );
    assert!(
        src.contains(
            "Mounted service names, in unspecified order, including [`Service::ALIASES`].\n    /// Distinct from reflection `list_services`, which reports\n    /// `FILE_DESCRIPTOR_SET` names, not these route keys."
        ),
        "Router::service_names rustdoc must Distinct ALIASES route keys from list_services FILE_DESCRIPTOR_SET names"
    );
    assert!(
        src.contains(
            "The last mount is the one that serves, on every call shape, including\n    /// over TLS, mTLS, Unix, and [`Self::serve_connection`]."
        ),
        "Router::add_service must name last-wins remount on every transport"
    );
    assert_eq!(
        src.matches(
            "Mount `service` when `Some`. `None` is a no-op.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "Server::add_optional_service and Router::add_optional_service must name every call shape"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::add_service`], which always mounts.")
            .count(),
        2,
        "Server and Router add_optional_service must Distinct None from always-mount"
    );
    assert_eq!(
        src.matches("`None` does not replace a service already there.")
            .count(),
        2,
        "Server and Router add_optional_service must not replace a mount on None"
    );
    assert!(
        src.contains(
            "A hand-written [`Service`] is first-class. Unknown methods are\n/// [`crate::Code::Unimplemented`] on every call shape, including over TLS,\n/// mTLS, Unix, and [`Server::serve_connection`]."
        ),
        "Server rustdoc must name hand-written unknown-method UNIMPLEMENTED on every transport"
    );
    assert!(
        src.contains(
            "A single\n    /// interceptor still rejects before the handler on every call shape,\n    /// including over TLS, mTLS, Unix, and [`Self::serve_connection`]."
        ),
        "Server::intercept rustdoc must name a single intercept reject on every transport"
    );
    assert!(
        src.contains(
            "[`Status::from_error_details`] is the typed bag after this Server intercept Err; those trailers reach the client without reading the body."
        ),
        "Server::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct handler Err after the handler ran from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Server intercept Err is trailers without reading the body."
        ),
        "Server::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this Server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::intercept`]: that runs on the outbound call before the stream opens; this runs on the inbound RPC before the handler."
        ),
        "Server::intercept rustdoc must Distinct Channel outbound-before-stream from inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::intercept`]: that runs on the outbound call before the stream opens; this Server intercept runs on the inbound RPC before the handler."
        ),
        "Server::intercept rustdoc must Distinct Channel outbound-before-stream from this Server intercept inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this runs on the inbound RPC before the handler."
        ),
        "Server::intercept rustdoc must Distinct on_response after-Ok from inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this Server intercept runs on the inbound RPC before the handler."
        ),
        "Server::intercept rustdoc must Distinct on_response after-Ok from this Server intercept inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Router::intercept`]: that runs on the inbound RPC before every mounted service on that Router; this Server intercept runs on the inbound RPC before the Server's Service."
        ),
        "Server::intercept rustdoc must Distinct Router mounted-service coverage from this Server intercept Service coverage"
    );
    assert!(
        src.contains("server.intercept(|rpc: &mut pbrs_grpc::Rpc| {"),
        "Server::intercept rustdoc example must attach a closure"
    );
    assert!(
        src.contains(
            "server.intercept(|rpc: &mut pbrs_grpc::Rpc| {\n    ///     let _ = (\n    ///         rpc.path(),\n    ///         rpc.service(),\n    ///         rpc.method(),\n    ///         rpc.metadata(),\n    ///         rpc.timeout(),\n    ///         rpc.peer_timeout(),\n    ///         rpc.rpc_timeout(),\n    ///         rpc.effective_timeout(),\n    ///         rpc.deadline(),\n    ///         rpc.accepts_gzip(),\n    ///         rpc.encoding(),\n    ///         rpc.compresses_outbound(),\n    ///         rpc.gzip_level(),\n    ///         rpc.accepts_compressed(),\n    ///         rpc.concurrent_rpc_limit(),\n    ///         rpc.send_buffer_size(),\n    ///         rpc.limits(),\n    ///         rpc.local_addr(),\n    ///         rpc.remote_addr(),\n    ///         rpc.peer_identity(),\n    ///         rpc.peer_cred(),\n    ///         rpc.authority(),\n    ///         rpc.scheme(),\n    ///         rpc.extensions(),"
        ),
        "Server::intercept rustdoc example must read Incoming-stamped peer facts"
    );
    assert!(
        src.contains("///         rpc.send_buffer_size(),"),
        "Server::intercept rustdoc example must read send_buffer_size"
    );
    assert!(
        src.contains("///         rpc.concurrent_rpc_limit(),"),
        "Server::intercept rustdoc example must read concurrent_rpc_limit"
    );
    assert!(
        src.contains("router.intercept(|rpc: &mut pbrs_grpc::Rpc| {"),
        "Router::intercept rustdoc example must attach a closure"
    );
    assert!(
        src.contains(
            "[`Status::from_error_details`] is the typed bag after this Router intercept Err; those trailers reach the client without reading the body."
        ),
        "Router::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct handler Err after the handler ran from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Router intercept Err is trailers without reading the body."
        ),
        "Router::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this Router intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::intercept`]: that runs on the outbound call before the stream opens; this Router intercept runs on the inbound RPC before the handler."
        ),
        "Router::intercept rustdoc must Distinct Channel outbound-before-stream from inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this Router intercept runs on the inbound RPC before the handler."
        ),
        "Router::intercept rustdoc must Distinct on_response after-Ok from inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Server::intercept`]: that runs on the inbound RPC before the Server's Service; this Router intercept runs on the inbound RPC before every mounted service on this Router."
        ),
        "Router::intercept rustdoc must Distinct Server Service coverage from this Router intercept mounted-service coverage"
    );
    assert!(
        src.contains(
            "router.intercept(|rpc: &mut pbrs_grpc::Rpc| {\n    ///     let _ = (\n    ///         rpc.path(),\n    ///         rpc.service(),\n    ///         rpc.method(),\n    ///         rpc.metadata(),\n    ///         rpc.timeout(),\n    ///         rpc.peer_timeout(),\n    ///         rpc.rpc_timeout(),\n    ///         rpc.effective_timeout(),\n    ///         rpc.deadline(),\n    ///         rpc.accepts_gzip(),\n    ///         rpc.encoding(),\n    ///         rpc.compresses_outbound(),\n    ///         rpc.gzip_level(),\n    ///         rpc.accepts_compressed(),\n    ///         rpc.concurrent_rpc_limit(),\n    ///         rpc.send_buffer_size(),\n    ///         rpc.limits(),\n    ///         rpc.local_addr(),\n    ///         rpc.remote_addr(),\n    ///         rpc.peer_identity(),\n    ///         rpc.peer_cred(),\n    ///         rpc.authority(),\n    ///         rpc.scheme(),\n    ///         rpc.extensions(),"
        ),
        "Router::intercept rustdoc example must read Incoming-stamped peer facts"
    );
    assert_eq!(
        src.matches(
            "Those extensions are not on the\n    /// wire; stamp [`crate::ResponseParts::metadata_mut`] to send a header."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct extensions from wire metadata"
    );
    assert_eq!(
        src.matches(
            "`Err` after the handler already ran; that status is sent trailers-only\n    /// instead of the response, including [`Status::with_error_details`].\n    /// A handler `Err` skips this hook."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must name trailers-only after the handler"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::path`] is kernel-stamped.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name kernel-stamped path"
    );
    assert!(
        src.contains("server.on_response(|parts: &mut pbrs_grpc::ResponseParts| {"),
        "Server::on_response rustdoc example must attach a closure"
    );
    assert!(
        src.contains("router.on_response(|parts: &mut pbrs_grpc::ResponseParts| {"),
        "Router::on_response rustdoc example must attach a closure"
    );
    assert!(
        src.contains("///         parts.path(),"),
        "Server::on_response rustdoc example must read path"
    );
    assert!(
        src.contains(
            "server.on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n    ///     let _ = (\n    ///         parts.path(),\n    ///         parts.service(),\n    ///         parts.method(),\n    ///         parts.metadata(),\n    ///         parts.trailers(),\n    ///         parts.compress(),\n    ///         parts.compress_is_set(),\n    ///         parts.encoding(),"
        ),
        "Server::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        src.contains("///         parts.compress_is_set(),"),
        "Server::on_response rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        src.contains(
            "router.on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n    ///     let _ = (\n    ///         parts.path(),\n    ///         parts.service(),\n    ///         parts.method(),\n    ///         parts.metadata(),\n    ///         parts.trailers(),\n    ///         parts.compress(),\n    ///         parts.compress_is_set(),\n    ///         parts.encoding(),"
        ),
        "Router::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        src.contains("///         parts.send_buffer_size(),"),
        "Server::on_response rustdoc example must read send_buffer_size"
    );
    assert!(
        src.contains(
            "    ///         parts.send_buffer_size(),\n    ///         parts.extensions(),"
        ),
        "Server::on_response rustdoc example must dump extensions Distinct from extensions_mut"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::Request::path`]: that is the inbound request.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct inbound Request::path"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::gzip_level`] is the server encode overlay.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name gzip_level overlay"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::ResponseParts::compress`]: that is on or off.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct gzip_level from compress"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::compresses_outbound`] is the server encode overlay.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name compresses_outbound overlay"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::compress`]: that is the per-RPC Compressed-Flag."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct compresses_outbound from per-RPC compress"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::accepts_gzip`] is the peer `grpc-accept-encoding` advertisement.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name accepts_gzip advertisement"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::encoding`]: that is received `grpc-encoding`."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct accepts_gzip from received encoding"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::deadline`] is kernel-stamped when writing.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name kernel-stamped deadline"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::Request::deadline`]: that is the inbound request.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct inbound Request::deadline"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::Rpc::deadline`]: that is computed when that getter runs."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct Rpc::deadline computed getter"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::timeout`] is the duration stamped at dispatch.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name timeout duration stamped at dispatch"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::ResponseParts::deadline`]: that is the Instant.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct timeout from deadline Instant"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::limits`] is the encode cap when writing.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name encode caps when writing"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::Request::limits`]: that is the inbound request.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct inbound Request::limits"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::Rpc::limits`]: that is a server interceptor before the handler."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct Rpc::limits before the handler"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::peer_timeout`] is the client's `grpc-timeout`.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name client grpc-timeout"
    );
    assert_eq!(
        src.matches("Distinct from [`crate::ResponseParts::timeout`]: that is the effective cap.")
            .count(),
        2,
        "Server::on_response and Router::on_response must Distinct peer_timeout from effective timeout"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::rpc_timeout`] is the server overlay.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name server overlay"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::timeout`]: that is soonest-of-three, not the overlay."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct rpc_timeout from effective timeout"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::peer_timeout`]: that is the client's `grpc-timeout`."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct rpc_timeout from client header"
    );
    assert_eq!(
        src.matches("[`crate::ResponseParts::accepts_compressed`] is the inbound gzip overlay.")
            .count(),
        2,
        "Server::on_response and Router::on_response must name inbound gzip overlay"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::accepts_gzip`]: that is the peer advertisement."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct accepts_compressed from peer advertisement"
    );
    assert_eq!(
        src.matches(
            "[`crate::ResponseParts::send_buffer_size`] is the write-time HTTP/2 send buffer overlay."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must name write-time send buffer overlay"
    );
    assert_eq!(
        src.matches(
            "Distinct from [`crate::ResponseParts::limits`]: that is the encode cap, not this send buffer."
        )
        .count(),
        2,
        "Server::on_response and Router::on_response must Distinct send_buffer_size from encode caps"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after this Server on_response, so a later interceptor can fill compress only when unset."
        ),
        "Server::on_response rustdoc must name compress_is_set occupancy next to send_buffer Distinct"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay after this Server on_response."
        ),
        "Server::on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        src.contains(
            "[`Status::from_error_details`] is the typed bag after this Server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct handler Err after the handler ran from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct Server intercept Err without reading the body from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct Interceptor Err without reading the body from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct method-level Interceptor Err without reading the body from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct Router intercept Err without reading the body from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct ServiceExt intercept Err without reading the body from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct Channel on_response Err Call fail after receive from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Server on_response Err is trailers-only after handler Ok."
        ),
        "Server::on_response rustdoc must Distinct StreamSender fail after any messages already sent from this Server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this runs after the handler returns Ok."
        ),
        "Server::on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this Server on_response runs after the handler returns Ok."
        ),
        "Server::on_response rustdoc must Distinct intercept inbound-before-handler from this Server on_response after-Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Router::on_response`]: that runs after the handler returns Ok on every mounted service on that Router; this Server on_response runs after the handler returns Ok on the Server's Service."
        ),
        "Server::on_response rustdoc must Distinct Router mounted-service coverage from this Server on_response Service coverage"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after this Router on_response, so a later interceptor can fill compress only when unset."
        ),
        "Router::on_response rustdoc must name compress_is_set occupancy next to send_buffer Distinct"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay after this Router on_response."
        ),
        "Router::on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        src.contains(
            "[`Status::from_error_details`] is the typed bag after this Router on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct handler Err after the handler ran from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct Router intercept Err without reading the body from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct Interceptor Err without reading the body from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct method-level Interceptor Err without reading the body from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct Server intercept Err without reading the body from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct ServiceExt intercept Err without reading the body from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct Channel on_response Err Call fail after receive from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Router on_response Err is trailers-only after handler Ok."
        ),
        "Router::on_response rustdoc must Distinct StreamSender fail after any messages already sent from this Router on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this Router on_response runs after the handler returns Ok."
        ),
        "Router::on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Server::on_response`]: that runs after the handler returns Ok on the Server's Service; this Router on_response runs after the handler returns Ok on every mounted service on this Router."
        ),
        "Router::on_response rustdoc must Distinct Server Service coverage from this Router on_response mounted-service coverage"
    );
    assert_eq!(
        src.matches(
            "gzip responses when the client advertises gzip. Applies to every call\n    /// shape, including over TLS, mTLS, Unix, and [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::send_compressed and Router::send_compressed must name every transport"
    );
    assert_eq!(
        src.matches(
            "Inflate inbound gzip. Default `true`. Applies to every call shape,\n    /// including over TLS, mTLS, Unix, and [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::accept_compressed and Router::accept_compressed must name every transport"
    );
    assert_eq!(
        src.matches(
            "Passing `false` refuses `grpc-encoding: gzip` as\n    /// [`Code::Unimplemented`] before the handler runs."
        )
        .count(),
        2,
        "Server::accept_compressed and Router::accept_compressed must refuse gzip as UNIMPLEMENTED"
    );
    assert_eq!(
        src.matches(
            "Deflate effort for outbound gzip. Default 1 (`flate2` fast).\n    /// Applies to every call shape"
        )
        .count(),
        2,
        "Server::gzip_compression_level and Router::gzip_compression_level must name every call shape"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::send_compressed`], which is on or off.")
            .count(),
        2,
        "Server and Router gzip_compression_level must Distinct deflate effort from on/off"
    );
    assert!(
        src.contains("Generated handlers see the same value on [`Request::gzip_level`]."),
        "Rpc::gzip_level must name the Request stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::gzip_level`]: that is a client interceptor overlay."
        ),
        "Rpc::gzip_level must Distinct client interceptor overlay"
    );
    assert!(
        src.contains(
            "Response interceptors see the same value on [`crate::Response::gzip_level`]."
        ),
        "Rpc::gzip_level must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Response interceptors see the same value on [`crate::Response::compresses_outbound`]."
        ),
        "Rpc::compresses_outbound must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Response interceptors see the same value on [`crate::Response::accepts_gzip`]."
        ),
        "Rpc::accepts_gzip must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::accepts_compressed`]: that is this server overlay, not the peer advertisement."
        ),
        "Rpc::accepts_gzip must Distinct this server overlay from the peer advertisement"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates the inbound map; this borrows it."
        ),
        "Rpc::metadata must Distinct the mutable inbound map from the borrow"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::metadata`]: that borrows the inbound map; this mutates it."
        ),
        "Rpc::metadata_mut must Distinct the borrow from the mutable inbound map"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values the handler will see; this borrows the map."
        ),
        "Rpc::extensions must Distinct the mutator from the borrow"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::extensions`]: that borrows the map; this inserts typed values the handler will see."
        ),
        "Rpc::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::timeout`]: that reads the interceptor cap; this tightens it."
        ),
        "Rpc::set_timeout must Distinct the getter from tightening the interceptor cap"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::rpc_timeout`]: that is the server overlay; this is the interceptor cap."
        ),
        "Rpc::timeout must Distinct the server overlay from the interceptor cap"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this received `grpc-encoding`."
        ),
        "Rpc::encoding must Distinct peer advertisement from received grpc-encoding"
    );
    assert!(
        src.contains(
            "Response interceptors see the same Instant as [`Request::deadline`] on [`crate::Response::deadline`]."
        ),
        "Rpc::deadline must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::timeout`]: that is the interceptor duration cap; this Instant is computed when the getter runs."
        ),
        "Rpc::deadline must Distinct the interceptor duration cap from the computed Instant"
    );
    assert!(
        src.contains(
            "Response interceptors see the same duration on [`crate::Response::timeout`]."
        ),
        "Rpc::effective_timeout must name the Response interceptor stamp"
    );
    assert!(
        src.contains("Response interceptors see the same caps on [`crate::Response::limits`]."),
        "Rpc::limits must name the Response interceptor stamp"
    );
    assert!(
        src.contains("Same overlay as [`crate::Server::limits`]."),
        "Rpc::limits must name the Server::limits overlay"
    );
    assert!(
        src.contains(
            "Response interceptors see the same duration on [`crate::Response::peer_timeout`]."
        ),
        "Rpc::peer_timeout must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Response interceptors see the same duration on [`crate::Response::rpc_timeout`]."
        ),
        "Rpc::rpc_timeout must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Response interceptors see the same value on [`crate::Response::accepts_compressed`]."
        ),
        "Rpc::accepts_compressed must name the Response interceptor stamp"
    );
    assert!(
        src.contains("Generated handlers see the same value on [`Request::accepts_compressed`]."),
        "Rpc::accepts_compressed must name the Request stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this overlay."
        ),
        "Rpc::accepts_compressed must Distinct peer accepts_gzip from inbound overlay"
    );
    assert!(
        src.contains("Generated handlers see the same value on [`Request::concurrent_rpc_limit`]."),
        "Rpc::concurrent_rpc_limit must name the Request stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::concurrent_rpc_limit`]: that is a client interceptor overlay."
        ),
        "Rpc::concurrent_rpc_limit must Distinct client interceptor overlay"
    );
    assert!(
        src.contains("Generated handlers see the same value on [`Request::send_buffer_size`]."),
        "Rpc::send_buffer_size must name the Request stamp"
    );
    assert!(
        src.contains(
            "Response interceptors see the same value on [`crate::Response::send_buffer_size`]."
        ),
        "Rpc::send_buffer_size must name the Response interceptor stamp"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::send_buffer_size`]: that is a client interceptor overlay."
        ),
        "Rpc::send_buffer_size must Distinct client interceptor overlay"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::limits`]: that is uncompressed protobuf bytes, not this HTTP/2 send buffer."
        ),
        "Rpc::send_buffer_size must Distinct message size from the HTTP/2 send buffer"
    );
    assert!(
        src.contains("0 stores; 9 is best"),
        "Server::gzip_compression_level must name store and best levels"
    );
    assert_eq!(
        src.matches(
            "Cap every RPC even when the client omits `grpc-timeout`. Applies to\n    /// every call shape, including over TLS, mTLS, Unix, and\n    /// [`Self::serve_connection`]."
        )
        .count(),
        2,
        "Server::timeout and Router::timeout must name every transport"
    );
}
