fn channel_call_apis_document_hand_written_services() {
    let src = concat!(
        include_str!("../src/client.rs"),
        include_str!("../src/client/channel.rs"),
        include_str!("../src/client/call.rs"),
        include_str!("../src/client/config_glue.rs"),
        include_str!("../src/client/pool.rs"),
        include_str!("../src/client/retry.rs"),
        include_str!("../src/client/streaming.rs"),
        include_str!("../src/client/unary.rs"),
    );
    let needle = "A hand-written [`crate::Service`] is first-class on this path;";
    assert_eq!(
        src.matches(needle).count(),
        4,
        "Channel unary / server_streaming / client_streaming / bidi must name hand-written Service as first-class"
    );
    let caps = "[`Self::max_encoding_message_size`] / [`Self::max_decoding_message_size`]\n    /// fail this path as [`Code::ResourceExhausted`], including over TLS, mTLS,\n    /// Unix, and [`Self::from_io`]. Distinct from generated client wrappers.";
    assert_eq!(
        src.matches(caps).count(),
        4,
        "Channel unary / server_streaming / client_streaming / bidi must name message caps on every transport"
    );
    assert!(
        src.contains("inbound cap. Applies to every call shape."),
        "Channel::connect must name every call shape"
    );
    assert!(
        src.contains(
            "Distinct from tonic's `Endpoint::from_static`, which takes an\n    /// `http://` / `https://` URI: [`Target`] is `host:port` (see [`Target`])."
        ),
        "Channel::connect must Distinct tonic Endpoint::from_static URI from Target host:port"
    );
    assert!(
        src.contains(
            "Distinct from grpc-go `NewClient(\"dns:///host:port\")`: still\n    /// `host:port`, not a resolver URI (see [`Target`])."
        ),
        "Channel::connect must Distinct grpc-go NewClient dns URI from Target host:port"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithBlock` DialOption: that makes deprecated\n    /// `Dial` wait until READY. This constructor already waits for the TCP\n    /// dial and HTTP/2 preface; there is no READY state. Distinct from\n    /// [`Self::connect_lazy`] (first RPC dials). Distinct from\n    /// [`Self::wait_for_ready`] (RPC queue, not Dial). Distinct from\n    /// [`Self::connected`] (live-socket snapshot). Distinct from gRPC\n    /// `GetState` / `WaitForStateChange`. There is no\n    /// `WithReturnConnectionError`: handshake failure is the returned\n    /// [`Status`]."
        ),
        "Channel::connect rustdoc must Distinct handshake wait from grpc-go WithBlock READY"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithBlock`").count(),
        1,
        "Channel::connect_lazy must not copy the WithBlock Distinct"
    );
    assert!(
        src.contains("Build a channel that dials on the first RPC instead of now.\n    /// Applies to every call shape."),
        "Channel::connect_lazy must name every call shape"
    );
    assert!(
        src.contains("Dial `target` over TLS with `config`. Applies to every call shape."),
        "Channel::connect_tls_with must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_lazy`] with `config`. Each slot dials when an RPC first\n    /// lands on it, not all at once. Applies to every call shape."
        ),
        "Channel::connect_lazy_with must name every call shape"
    );
    assert!(
        src.contains("[`Self::connect_lazy`] over TLS. Applies to every call shape."),
        "Channel::connect_tls_lazy must name every call shape"
    );
    assert!(
        src.contains("[`Self::connect_lazy_with`] over TLS. Applies to every call shape."),
        "Channel::connect_tls_lazy_with must name every call shape"
    );
    assert!(
        src.contains("Dial `target` with `config`. Applies to every call shape."),
        "Channel::connect_with must name every call shape"
    );
    assert!(
        src.contains("not a `unix://` URI.\n    /// Applies to every call shape."),
        "Channel::connect_unix must name every call shape"
    );
    assert!(
        src.contains("[`Self::connect_unix`] with `config`. Applies to every call shape."),
        "Channel::connect_unix_with must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_unix`] that dials on the first RPC instead of now.\n    /// Applies to every call shape."
        ),
        "Channel::connect_unix_lazy must name every call shape"
    );
    assert!(
        src.contains("[`Self::connect_unix_lazy`] with `config`. Applies to every call shape."),
        "Channel::connect_unix_lazy_with must name every call shape"
    );
    assert!(
        src.contains("call [`Self::https_scheme`].\n    /// Applies to every call shape."),
        "Channel::from_io must name every call shape"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::connect_with_connector`: that is a tower\n    /// `Service<Uri>` that still dials. This stream is already connected; there\n    /// is no connector and no URI. Distinct from [`Self::connect_unix`]\n    /// (filesystem path, not a connector). [`ChannelConfig::connect_timeout`]\n    /// still bounds the HTTP/2 preface. Distinct from `tower` integration,\n    /// which is protobuf-tonic keeping tonic."
        ),
        "Channel::from_io rustdoc must Distinct already-connected bytes from tonic Endpoint::connect_with_connector"
    );
    assert_eq!(
        src.matches("There is no tonic `Endpoint::connect_with_connector`")
            .count(),
        1,
        "Channel::from_io_with must not copy the connect_with_connector Distinct"
    );
    assert!(
        src.contains(
            "next RPC on that slot dials again, including over TLS, mTLS, and Unix.\n/// [`Self::from_io`] cannot redial."
        ),
        "Channel rustdoc must name redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains("Client-streaming and bidi retry that same redial once when HEADERS never"),
        "Channel rustdoc must name client-streaming/bidi transparent retry before HEADERS"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithDisableRetry` DialOption: that disables\n/// service-config retries and does not impact transparent retries.\n/// Service-config `retryPolicy`/`hedgingPolicy` attach with\n/// [`Self::service_config`]; omit the document (or the method's policy) for\n/// no policy retries, in which case application retries stay at the call\n/// site ([`Code::is_retryable`]). Transparent retry cannot be turned off.\n/// Distinct from [`Self::from_io`] (no transparent retry)."
        ),
        "Channel rustdoc must Distinct transparent retry from grpc-go WithDisableRetry"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithDisableRetry`")
            .count(),
        1,
        "Channel::connect must not copy the WithDisableRetry Distinct"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithMaxCallAttempts`: that caps retries and hedging\n/// per call (default 5; values below 2 become 5). Here `maxAttempts` comes\n/// from the method's `retryPolicy`/`hedgingPolicy` (values above 5 count as\n/// 5); transparent retry is at most once on top and cannot be raised.\n/// Distinct from [`Code::is_retryable`] (application retries at the call\n/// site, unbounded by this kernel)."
        ),
        "Channel rustdoc must Distinct at-most-once transparent retry from grpc-go WithMaxCallAttempts"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithMaxCallAttempts`")
            .count(),
        1,
        "Channel::connect must not copy the WithMaxCallAttempts Distinct"
    );
    assert!(
        src.contains(
            "TCP sockets always set `TCP_NODELAY` (Nagle off) at connect; Unix and\n/// [`Self::from_io`] skip that. There is no `tcp_nodelay` setter. Distinct"
        ),
        "Channel rustdoc must Distinct TCP_NODELAY always-on from tonic tcp_nodelay"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithNoProxy`: grpc-go honors `HTTPS_PROXY` by\n/// default; that DialOption disables it. TCP dials consult `HTTPS_PROXY`\n/// / `NO_PROXY` and tunnel through HTTP CONNECT; there is no per-channel\n/// proxy disable. There is no\n/// `WithLocalDNSResolution`: that resolves locally so the proxy CONNECT\n/// sees an IP. Distinct from [`Self::from_io`] (already-connected bytes,\n/// not a proxy bypass). Distinct from [`Self::connect_unix`] (filesystem\n/// path; this dialer is skipped). Distinct from\n/// [`ChannelConfig::local_address`] (source bind, not proxy)."
        ),
        "Channel rustdoc must Distinct direct TCP dial from grpc-go WithNoProxy HTTPS_PROXY"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithNoProxy`").count(),
        1,
        "Channel::connect must not copy the WithNoProxy Distinct"
    );
    assert!(
        src.contains(
            "[`ChannelConfig::local_address`] binds the TCP source before connect\n/// (TLS and mTLS included). Unix and [`Self::from_io`] skip that bind.\n/// Distinct from [`crate::Rpc::local_addr`], which is the accepted"
        ),
        "Channel rustdoc must Distinct local_address bind from Rpc::local_addr"
    );
    assert!(
        src.contains("keepalive, local bind, connection count"),
        "Channel rustdoc must name local bind as handshake-only"
    );
    assert!(
        src.contains(
            "dropping the last `Channel`\n/// clone after headers still lets you read the stream to the end, including\n/// over TLS, mTLS, Unix, and [`Self::from_io`]."
        ),
        "Channel rustdoc must name drop-Channel live stream on every transport"
    );
    assert!(
        src.contains(
            "Cap inbound messages at `limit` bytes. Default 4 MiB.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`Self::from_io`]."
        ),
        "Channel::max_decoding_message_size must name every transport"
    );
    assert!(
        src.contains(
            "Cap outbound messages at `limit` bytes. Default unlimited.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`Self::from_io`]."
        ),
        "Channel::max_encoding_message_size must name every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_encoding_message_size`] /\n    /// [`Self::max_decoding_message_size`]. Oversize is\n    /// [`Code::ResourceExhausted`], including over TLS, mTLS, Unix, and\n    /// [`Self::from_io`]."
        ),
        "Channel::message_limits must name the combined setter on every transport"
    );
    let stream = include_str!("../src/stream.rs");
    assert!(
        stream.contains(
            "dropping the client after headers still lets you read to the end,\n/// including over TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "Streaming rustdoc must name drop-Channel live stream on every transport"
    );
    assert!(
        stream.contains("(`futures_core::stream::FusedStream`): combinators that skip terminated"),
        "Streaming rustdoc must name FusedStream after end-of-stream or error"
    );
    assert!(
        stream.contains("A subsequent [`Self::message`] is `Ok(None)`"),
        "Streaming rustdoc must name fused subsequent message as Ok(None)"
    );
    assert!(
        stream.contains(
            "returns [`crate::Code::DeadlineExceeded`], not `Ok(None)`, including\n/// over TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "Streaming rustdoc must name expired deadline is not a clean end on every transport"
    );
    assert!(
        stream.contains(
            "trailer must not appear as a header, including over TLS, mTLS, Unix,\n    /// and [`crate::Channel::from_io`]."
        ),
        "Streaming::trailers rustdoc must name -bin trailers on every transport"
    );
    assert!(
        stream.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "StreamSender::fail rustdoc must name from_error_details typed bag next to server-producer trailers"
    );
    assert!(
        stream.contains(
            "Distinct from a handler Err: that is after the handler ran; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct handler Err after the handler ran from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Interceptor Err without reading the body from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct method-level Interceptor Err without reading the body from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Server intercept Err without reading the body from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Router intercept Err without reading the body from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct ServiceExt intercept Err without reading the body from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Channel on_response Err Call fail after receive from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct method-level intercept Err local reject never opens a stream from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this StreamSender fail is trailers after any messages already sent."
        ),
        "StreamSender::fail rustdoc must Distinct Channel intercept Err local reject never opens a stream from this StreamSender fail after any messages already sent"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::compress`]: that reads whether subsequent send payloads gzip; this writes it."
        ),
        "StreamSender::set_compress must Distinct the getter from the writer"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send_compressed`]: that gzips one message regardless of this flag; this sets the default for later send."
        ),
        "StreamSender::set_compress must Distinct one-message gzip from the later-send default"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::set_compress`]: that sets the default for later send; this gzips one message regardless of that flag."
        ),
        "StreamSender::send_compressed must Distinct the later-send default from one-message gzip"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send`]: that follows [`Self::compress`]; this gzips one message regardless of that flag."
        ),
        "StreamSender::send_compressed must Distinct following the compress default from one-message gzip"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send_compressed`]: that gzips one message regardless of the default; this follows [`Self::compress`]."
        ),
        "StreamSender::send must Distinct one-message gzip from following the compress default"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send_framed`]: that takes an explicit Compressed-Flag; this follows [`Self::compress`]."
        ),
        "StreamSender::send must Distinct an explicit Compressed-Flag from following the compress default"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send`]: that follows [`Self::compress`]; this takes an explicit Compressed-Flag."
        ),
        "StreamSender::send_framed must Distinct following the compress default from an explicit Compressed-Flag"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::send_compressed`]: that always sets Compressed-Flag 1; this takes an explicit Compressed-Flag."
        ),
        "StreamSender::send_framed must Distinct always-gzip from an explicit Compressed-Flag"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::close`]: that half-closes; this ends with an error status."
        ),
        "StreamSender::fail must Distinct a clean half-close from an error status"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::fail`]: that ends with an error status; this half-closes."
        ),
        "StreamSender::close must Distinct an error status from a clean half-close"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::closed`]: that waits until the reader is gone; this is a snapshot."
        ),
        "StreamSender::is_closed must Distinct waiting from a snapshot"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::is_closed`]: that is a snapshot; this waits until the reader is gone."
        ),
        "StreamSender::closed must Distinct a snapshot from waiting"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::compressed`]: that sets the Compressed-Flag; this clears it."
        ),
        "Framed::new must Distinct setting the Compressed-Flag from clearing it"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::new`]: that clears the Compressed-Flag; this sets it."
        ),
        "Framed::compressed must Distinct clearing the Compressed-Flag from setting it"
    );
    assert!(
        stream.contains(
            "Distinct from keeping this frame: that still carries the Compressed-Flag; this returns the payload and drops the flag."
        ),
        "Framed::into_inner must Distinct keeping the flag from dropping it"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::next_framed`]: that keeps the Compressed-Flag; this discards it."
        ),
        "Streaming::message must Distinct keeping the Compressed-Flag from discarding it"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::message`]: that discards the Compressed-Flag; this keeps it."
        ),
        "Streaming::next_framed must Distinct discarding the Compressed-Flag from keeping it"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::message`]: that yields one message; this drains the stream."
        ),
        "Streaming::collect must Distinct one message from draining the stream"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::message`]: that yields payloads; this waits for trailing metadata."
        ),
        "Streaming::trailers must Distinct payloads from trailing metadata"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::empty`]: that is already finished; this is a live sender/receiver pair."
        ),
        "Streaming::channel must Distinct an already-finished stream from a live pair"
    );
    assert!(
        stream.contains(
            "Distinct from [`Self::channel`]: that is a live sender/receiver pair; this is already finished."
        ),
        "Streaming::empty must Distinct a live pair from an already-finished stream"
    );
    assert!(
        stream.contains(
            "Distinct from [`Stream::poll_next`]: that is `Poll<Option<Result<T, Status>>>`; this awaits `Result<Option<T>, Status>`. Both use the same poll."
        ),
        "Streaming::message must Distinct Stream poll shape from the await helper"
    );
    assert!(
        stream.contains(
            "Distinct from [`Streaming::message`]: that awaits `Result<Option<T>, Status>`; this is `Poll<Option<Result<T, Status>>>`. Both use the same poll."
        ),
        "Stream::poll_next must Distinct the await helper from the Stream poll shape"
    );
    assert!(
        stream.contains(
            "Distinct from [`Streaming::message`]: that awaits the next payload; this reports whether the stream already fused."
        ),
        "FusedStream::is_terminated must Distinct awaiting the next payload from the fuse snapshot"
    );
    let outgoing = include_str!("../src/request.rs");
    assert!(
        outgoing.contains("fn dump_request(request: &pbrs_grpc::Request<()>) {"),
        "Request rustdoc must attach a compiling dump_request example"
    );
    assert!(
        outgoing.contains("fn dump_parts(parts: &pbrs_grpc::Parts) {"),
        "Parts rustdoc must attach a compiling dump_parts example"
    );
    assert!(
        outgoing.contains(
            "fn dump_parts(parts: &pbrs_grpc::Parts) {\n///     let _ = (\n///         parts.path(),\n///         parts.service(),\n///         parts.method(),\n///         parts.metadata(),\n///         parts.timeout(),\n///         parts.rpc_timeout(),\n///         parts.peer_timeout(),"
        ),
        "Parts rustdoc must dump peer_timeout Distinct from timeout"
    );
    assert!(
        outgoing.contains("///         parts.peer_timeout(),\n///         parts.deadline(),"),
        "Parts rustdoc must dump deadline Distinct from timeout"
    );
    assert!(
        outgoing.contains("///         parts.deadline(),\n///         parts.compress(),"),
        "Parts rustdoc must dump compress Distinct from compressed"
    );
    assert!(
        outgoing.contains("///         parts.compress(),\n///         parts.compressed(),"),
        "Parts rustdoc must dump compressed Distinct from compress"
    );
    assert!(
        outgoing.contains("///         parts.compressed(),\n///         parts.encoding(),"),
        "Parts rustdoc must dump encoding Distinct from compressed"
    );
    assert!(
        outgoing.contains("///         parts.encoding(),\n///         parts.accepts_gzip(),"),
        "Parts rustdoc must dump accepts_gzip Distinct from encoding"
    );
    assert!(
        outgoing.contains(
            "///         parts.accepts_gzip(),\n///         parts.compresses_outbound(),"
        ),
        "Parts rustdoc must dump compresses_outbound Distinct from accepts_gzip"
    );
    assert!(
        outgoing
            .contains("///         parts.compresses_outbound(),\n///         parts.gzip_level(),"),
        "Parts rustdoc must dump gzip_level Distinct from compresses_outbound"
    );
    assert!(
        outgoing
            .contains("///         parts.gzip_level(),\n///         parts.accepts_compressed(),"),
        "Parts rustdoc must dump accepts_compressed Distinct from gzip_level"
    );
    assert!(
        outgoing.contains(
            "///         parts.accepts_compressed(),\n///         parts.concurrent_rpc_limit(),"
        ),
        "Parts rustdoc must dump concurrent_rpc_limit Distinct from accepts_compressed"
    );
    assert!(
        outgoing.contains(
            "///         parts.concurrent_rpc_limit(),\n///         parts.send_buffer_size(),"
        ),
        "Parts rustdoc must dump send_buffer_size Distinct from concurrent_rpc_limit"
    );
    assert!(
        outgoing
            .contains("///         parts.send_buffer_size(),\n///         parts.remote_addr(),"),
        "Parts rustdoc must dump remote_addr Distinct from send_buffer_size"
    );
    assert!(
        outgoing.contains("///         parts.remote_addr(),\n///         parts.local_addr(),"),
        "Parts rustdoc must dump local_addr Distinct from remote_addr"
    );
    assert!(
        outgoing.contains("///         parts.local_addr(),\n///         parts.peer_identity(),"),
        "Parts rustdoc must dump peer_identity Distinct from local_addr"
    );
    assert!(
        outgoing.contains("///         parts.peer_identity(),\n///         parts.peer_cred(),"),
        "Parts rustdoc must dump peer_cred Distinct from peer_identity"
    );
    assert!(
        outgoing.contains("///         parts.peer_cred(),\n///         parts.authority(),"),
        "Parts rustdoc must dump authority Distinct from peer_cred"
    );
    assert!(
        outgoing.contains("///         parts.authority(),\n///         parts.scheme(),"),
        "Parts rustdoc must dump scheme Distinct from authority"
    );
    assert!(
        outgoing.contains("///         parts.scheme(),\n///         parts.wait_for_ready(),"),
        "Parts rustdoc must dump wait_for_ready Distinct from scheme"
    );
    assert!(
        outgoing.contains("///         parts.wait_for_ready(),\n///         parts.limits(),"),
        "Parts rustdoc must dump limits Distinct from wait_for_ready"
    );
    assert!(
        outgoing.contains("///         parts.limits(),\n///         parts.extensions(),"),
        "Parts rustdoc must dump extensions Distinct from limits"
    );
    assert!(
        outgoing.contains("///         parts.extensions(),\n///         parts.user_agent(),"),
        "Parts rustdoc must dump user_agent Distinct from extensions"
    );
    assert!(
        outgoing.contains("///     let _ = parts.cancelled();"),
        "Parts rustdoc must dump cancelled Distinct from the Parts tuple"
    );
    assert!(
        outgoing.contains(
            "[`Self::user_agent_is_set`] is occupancy on this split envelope, so a later interceptor can prefix only when unset."
        ),
        "Parts rustdoc must name user_agent_is_set occupancy next to cancelled dump"
    );
    assert!(
        outgoing.contains(
            "[`Self::wait_for_ready_is_set`] is occupancy on this split envelope, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "Parts rustdoc must name wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::compress_is_set`] is occupancy on this split envelope, so a later interceptor can fill compress only when unset."
        ),
        "Parts rustdoc must name compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_timeout`] opts out of the channel timeout on this split envelope."
        ),
        "Parts rustdoc must name clear_timeout next to compress occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_wait_for_ready`] restores the channel wait-for-ready overlay on this split envelope."
        ),
        "Parts rustdoc must name clear_wait_for_ready next to clear_timeout"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] restores the channel gzip overlay on this split envelope."
        ),
        "Parts rustdoc must name clear_compress next to clear_wait_for_ready"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_user_agent`] restores the channel user-agent on this split envelope."
        ),
        "Parts rustdoc must name clear_user_agent next to clear_compress"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates this split envelope; this borrows it."
        ),
        "Parts::metadata must Distinct the mutable split envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values this split envelope carries; this borrows them."
        ),
        "Parts::extensions must Distinct the mutable split envelope map from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this split envelope's inbound `grpc-encoding`."
        ),
        "Parts::encoding must Distinct peer advertisement from split envelope grpc-encoding"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`timeout`](Self::timeout): that is the effective cap on this split envelope; this is the server overlay."
        ),
        "Parts::rpc_timeout must Distinct the effective cap from the server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`timeout`](Self::timeout): that is the effective cap on this split envelope; this is the client's original header."
        ),
        "Parts::peer_timeout must Distinct the effective cap from the client header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`timeout`](Self::timeout): that is the duration stamped at dispatch on this split envelope; this Instant does not shrink."
        ),
        "Parts::deadline must Distinct the dispatch duration from the Instant"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compressed`]: that is the inbound unary Compressed-Flag on this split envelope; this is outbound gzip intent."
        ),
        "Parts::compress must Distinct outbound gzip intent from the inbound Compressed-Flag"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_compressed`]: that is the inbound overlay on this split envelope, not the peer advertisement."
        ),
        "Parts::accepts_gzip must Distinct inbound overlay from peer advertisement"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is on or off on this split envelope; this is deflate effort."
        ),
        "Parts::gzip_level must Distinct on/off from deflate effort"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::gzip_level`]: that is a client interceptor overlay, not this split envelope's server overlay."
        ),
        "Parts::gzip_level must Distinct client interceptor overlay from server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this split envelope's inbound overlay."
        ),
        "Parts::accepts_compressed must Distinct peer advertisement from inbound overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay, not this split envelope's server overlay."
        ),
        "Parts::accepts_compressed must Distinct client interceptor overlay from server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::concurrent_rpc_limit`]: that is a client interceptor overlay, not this split envelope's server overlay."
        ),
        "Parts::concurrent_rpc_limit must Distinct client interceptor overlay from server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is message size on this split envelope, not how many RPCs."
        ),
        "Parts::concurrent_rpc_limit must Distinct message size from the process RPC cap"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::send_buffer_size`]: that is a client interceptor overlay, not this split envelope's server overlay."
        ),
        "Parts::send_buffer_size must Distinct client interceptor overlay from server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is message size on this split envelope, not this HTTP/2 send buffer."
        ),
        "Parts::send_buffer_size must Distinct message size from the HTTP/2 send buffer"
    );
    assert!(
        outgoing.contains(
            "Distinct from HTTP/2 `SETTINGS_MAX_FRAME_SIZE` and stream/connection windows: those are handshake SETTINGS, not this split envelope's write-time threshold."
        ),
        "Parts::send_buffer_size must Distinct handshake SETTINGS from the write-time send buffer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that is outbound request-payload gzip on this split envelope; this is the server encode overlay."
        ),
        "Parts::compresses_outbound must Distinct request-payload gzip from the server encode overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::user_agent`]: that is the effective header; this split envelope is the override only."
        ),
        "Parts::user_agent must Distinct the Outgoing effective header from the override"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::user_agent_is_set`]: that is the same flag after interceptors run, not this split envelope."
        ),
        "Parts::user_agent_is_set Distinct from Outgoing::user_agent_is_set: that is the same flag after interceptors run, not this split envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::wait_for_ready`], which is `false` when unset on this split envelope."
        ),
        "Parts::wait_for_ready_is_set must Distinct occupancy from the fail-fast snapshot"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`], which is `false` when unset on this split envelope."
        ),
        "Parts::compress_is_set must Distinct occupancy from outbound gzip intent"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`compressed`](Self::compressed): that is the per-message Compressed-Flag on this split envelope; this is the HTTP header."
        ),
        "Parts::encoding must Distinct Compressed-Flag from inbound grpc-encoding"
    );
    assert!(
        outgoing.contains("///         request.compress(),\n///         request.compressed(),"),
        "Request rustdoc must dump compressed Distinct from compress"
    );
    assert!(
        outgoing.contains("///         request.compressed(),\n///         request.encoding(),"),
        "Request rustdoc must dump encoding Distinct from compressed"
    );
    assert!(
        outgoing.contains("///         request.encoding(),\n///         request.accepts_gzip(),"),
        "Request rustdoc must dump accepts_gzip Distinct from encoding"
    );
    assert!(
        outgoing.contains(
            "///         request.accepts_gzip(),\n///         request.compresses_outbound(),"
        ),
        "Request rustdoc must dump compresses_outbound Distinct from accepts_gzip"
    );
    assert!(
        outgoing.contains(
            "///         request.compresses_outbound(),\n///         request.gzip_level(),"
        ),
        "Request rustdoc must dump gzip_level Distinct from compresses_outbound"
    );
    assert!(
        outgoing.contains(
            "///         request.gzip_level(),\n///         request.accepts_compressed(),"
        ),
        "Request rustdoc must dump accepts_compressed Distinct from gzip_level"
    );
    assert!(
        outgoing.contains(
            "///         request.accepts_compressed(),\n///         request.concurrent_rpc_limit(),"
        ),
        "Request rustdoc must dump concurrent_rpc_limit Distinct from accepts_compressed"
    );
    assert!(
        outgoing.contains(
            "///         request.concurrent_rpc_limit(),\n///         request.send_buffer_size(),"
        ),
        "Request rustdoc must dump send_buffer_size Distinct from concurrent_rpc_limit"
    );
    assert!(
        outgoing.contains(
            "///         request.send_buffer_size(),\n///         request.remote_addr(),"
        ),
        "Request rustdoc must dump remote_addr Distinct from send_buffer_size"
    );
    assert!(
        outgoing.contains("///         request.remote_addr(),\n///         request.local_addr(),"),
        "Request rustdoc must dump local_addr Distinct from remote_addr"
    );
    assert!(
        outgoing
            .contains("///         request.local_addr(),\n///         request.peer_identity(),"),
        "Request rustdoc must dump peer_identity Distinct from local_addr"
    );
    assert!(
        outgoing.contains("///         request.peer_identity(),\n///         request.peer_cred(),"),
        "Request rustdoc must dump peer_cred Distinct from peer_identity"
    );
    assert!(
        outgoing.contains("///         request.peer_cred(),\n///         request.authority(),"),
        "Request rustdoc must dump authority Distinct from peer_cred"
    );
    assert!(
        outgoing.contains("///         request.authority(),\n///         request.scheme(),"),
        "Request rustdoc must dump scheme Distinct from authority"
    );
    assert!(
        outgoing.contains("///         request.scheme(),\n///         request.wait_for_ready(),"),
        "Request rustdoc must dump wait_for_ready Distinct from scheme"
    );
    assert!(
        outgoing.contains("///         request.wait_for_ready(),\n///         request.limits(),"),
        "Request rustdoc must dump limits Distinct from wait_for_ready"
    );
    assert!(
        outgoing.contains("///         request.limits(),\n///         request.extensions(),"),
        "Request rustdoc must dump extensions Distinct from limits"
    );
    assert!(
        outgoing.contains("///         request.extensions(),\n///         request.user_agent(),"),
        "Request rustdoc must dump user_agent Distinct from extensions"
    );
    assert!(
        outgoing.contains("///     let _ = request.cancelled();"),
        "Request rustdoc must dump cancelled Distinct from limits"
    );
    assert!(
        outgoing.contains(
            "[`Self::user_agent_is_set`] is occupancy on this request envelope, so a later interceptor can prefix only when unset."
        ),
        "Request rustdoc must name user_agent_is_set occupancy next to cancelled dump"
    );
    assert!(
        outgoing.contains(
            "[`Self::wait_for_ready_is_set`] is occupancy on this request envelope, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "Request rustdoc must name wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::compress_is_set`] is occupancy on this request envelope, so a later interceptor can fill compress only when unset."
        ),
        "Request rustdoc must name compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_timeout`] opts out of the channel timeout on this request envelope."
        ),
        "Request rustdoc must name clear_timeout next to compress occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_wait_for_ready`] restores the channel wait-for-ready overlay on this request envelope."
        ),
        "Request rustdoc must name clear_wait_for_ready next to clear_timeout"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] restores the channel gzip overlay on this request envelope."
        ),
        "Request rustdoc must name clear_compress next to clear_wait_for_ready"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_user_agent`] restores the channel user-agent on this request envelope."
        ),
        "Request rustdoc must name clear_user_agent next to clear_compress"
    );
    assert!(
        outgoing.contains("prefixes this RPC's `user-agent` (kernel suffix"),
        "Outgoing rustdoc must name set_user_agent kernel suffix"
    );
    assert!(
        outgoing.contains(
            "[`Self::user_agent_is_set`] is occupancy on this outbound envelope, so a later interceptor can prefix only when unset."
        ),
        "Outgoing rustdoc must name user_agent_is_set occupancy next to set_user_agent"
    );
    assert!(
        outgoing.contains(
            "[`Self::wait_for_ready_is_set`] is occupancy on this outbound envelope, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "Outgoing rustdoc must name wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::compress_is_set`] is occupancy on this outbound envelope, so a later interceptor can fill compress only when unset."
        ),
        "Outgoing rustdoc must name compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_timeout`] opts out of the channel timeout on this outbound envelope."
        ),
        "Outgoing rustdoc must name clear_timeout next to compress occupancy"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_wait_for_ready`] restores the channel wait-for-ready overlay on this outbound envelope."
        ),
        "Outgoing rustdoc must name clear_wait_for_ready next to clear_timeout"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] then [`Self::set_compress`] from [`Self::compresses_outbound`] reapplies channel gzip on this outbound envelope."
        ),
        "Outgoing rustdoc must name clear_compress reapply next to clear_wait_for_ready"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_user_agent`] restores the channel user-agent on this outbound envelope."
        ),
        "Outgoing rustdoc must name clear_user_agent next to clear_compress"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] / [`Self::clear_user_agent`] opt out of an already-applied default."
        ),
        "Outgoing rustdoc must name clear_user_agent next to the other clear_* opt-outs"
    );
    assert!(
        outgoing.contains("Distinct from inserting `user-agent` into metadata"),
        "Outgoing::set_user_agent must Distinct metadata overwrite"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::user_agent`]: that is the effective header this RPC will send; this prefixes it."
        ),
        "Outgoing::set_user_agent must Distinct the effective header from prefixing it"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_user_agent`]: that prefixes this RPC; this restores the channel value."
        ),
        "Outgoing::clear_user_agent must Distinct prefixing this RPC from restoring the channel value"
    );
    assert!(
        outgoing.contains("The override only, like [`Self::timeout`]"),
        "Request::user_agent must Distinct the override from Outgoing's effective value"
    );
    assert!(
        outgoing.contains("that runs after the call site wins."),
        "Request::set_user_agent must Distinct interceptor win after the call site"
    );
    assert!(
        outgoing.contains("Same snapshot as [`crate::Channel::connected`], taken when this"),
        "Outgoing::connected must name the Channel snapshot at interceptor time"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::connected`]: that is a live snapshot; this still queues when a slot is empty."
        ),
        "Outgoing::set_wait_for_ready must Distinct the live-socket snapshot"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::wait_for_ready`]: that reads the per-RPC choice; this writes it."
        ),
        "Outgoing::set_wait_for_ready must Distinct reading the per-RPC choice from writing it"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_wait_for_ready`]: that queues this RPC; this opts out."
        ),
        "Outgoing::clear_wait_for_ready must Distinct queueing this RPC from opting out"
    );
    assert!(
        outgoing.contains("Distinct from [`Self::wait_for_ready`]: that queues"),
        "Outgoing::connected must Distinct wait-for-ready queueing from a live socket"
    );
    assert!(
        outgoing.contains("Channel [`crate::Channel::gzip_compression_level`] overlay."),
        "Outgoing::gzip_level must name the channel gzip_compression_level overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is on or off; this is deflate effort."
        ),
        "Outgoing::gzip_level must Distinct deflate effort from on/off"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::gzip_compression_level`] overlay, when the kernel dispatched this call."
        ),
        "Request::gzip_level must name the server gzip_compression_level overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::gzip_level`]: that is a client interceptor overlay."
        ),
        "Request::gzip_level must Distinct client interceptor overlay from inbound dispatch"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::accept_compressed`] overlay, when the kernel dispatched this call."
        ),
        "Request::accepts_compressed must name the server accept_compressed overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this overlay."
        ),
        "Request::accepts_compressed must Distinct peer accepts_gzip from inbound overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_compressed`]: that is the inbound overlay, not the peer advertisement."
        ),
        "Request::accepts_gzip must Distinct inbound overlay from peer advertisement"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer's `grpc-accept-encoding`, not this inbound `grpc-encoding`."
        ),
        "Request::encoding must Distinct peer advertisement from inbound grpc-encoding"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates this envelope; this borrows it."
        ),
        "Request::metadata must Distinct the mutable envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that borrows this envelope; this mutates it."
        ),
        "Request::metadata_mut must Distinct the borrow from the mutable envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values this envelope carries; this borrows them."
        ),
        "Request::extensions must Distinct the mutable envelope map from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions`]: that borrows them; this inserts typed values this envelope carries."
        ),
        "Request::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that borrows this split envelope; this mutates it."
        ),
        "Parts::metadata_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions`]: that borrows them; this inserts typed values this split envelope carries."
        ),
        "Parts::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that borrows this reply envelope; this mutates it."
        ),
        "Response::metadata_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that borrows this split reply envelope; this mutates it."
        ),
        "ResponseParts::metadata_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::trailers`]: that borrows this reply envelope; this mutates it."
        ),
        "Response::trailers_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::trailers`]: that borrows this split reply envelope; this mutates it."
        ),
        "ResponseParts::trailers_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions`]: that borrows them; this inserts typed values this reply envelope carries."
        ),
        "Response::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions`]: that borrows them; this inserts typed values this split reply envelope carries."
        ),
        "ResponseParts::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that reads the relative timeout this envelope carries; this writes it."
        ),
        "Request::set_timeout must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_timeout`]: that writes the relative timeout this envelope carries; this opts out."
        ),
        "Request::clear_timeout must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that reads outbound payload gzip on this envelope; this writes it."
        ),
        "Request::set_compress must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_compress`]: that writes outbound payload gzip on this envelope; this opts out."
        ),
        "Request::clear_compress must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that reads the relative timeout this split envelope carries; this writes it."
        ),
        "Parts::set_timeout must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_timeout`]: that writes the relative timeout this split envelope carries; this opts out."
        ),
        "Parts::clear_timeout must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that reads outbound payload gzip on this split envelope; this writes it."
        ),
        "Parts::set_compress must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_compress`]: that writes outbound payload gzip on this split envelope; this opts out."
        ),
        "Parts::clear_compress must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that reads outbound payload gzip on this reply envelope; this writes it."
        ),
        "Response::set_compress must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_compress`]: that writes outbound payload gzip on this reply envelope; this opts out."
        ),
        "Response::clear_compress must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that reads outbound payload gzip on this split reply envelope; this writes it."
        ),
        "ResponseParts::set_compress must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_compress`]: that writes outbound payload gzip on this split reply envelope; this opts out."
        ),
        "ResponseParts::clear_compress must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::wait_for_ready`]: that reads the wait-for-ready choice this envelope carries; this writes it."
        ),
        "Request::set_wait_for_ready must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_wait_for_ready`]: that writes the wait-for-ready choice this envelope carries; this opts out."
        ),
        "Request::clear_wait_for_ready must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::user_agent`]: that is the override this envelope carries; this prefixes it."
        ),
        "Request::set_user_agent must Distinct the override getter from prefixing"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::user_agent`]: that is the effective value after interceptors; this prefixes the override this envelope carries."
        ),
        "Request::set_user_agent must Distinct the effective interceptor header from prefixing this envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_user_agent`]: that prefixes this envelope; this restores the channel value."
        ),
        "Request::clear_user_agent must Distinct prefixing from restoring the channel value"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::wait_for_ready`]: that reads the wait-for-ready choice this split envelope carries; this writes it."
        ),
        "Parts::set_wait_for_ready must Distinct the getter from the writer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_wait_for_ready`]: that writes the wait-for-ready choice this split envelope carries; this opts out."
        ),
        "Parts::clear_wait_for_ready must Distinct writing from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::user_agent`]: that is the override this split envelope carries; this prefixes it."
        ),
        "Parts::set_user_agent must Distinct the override getter from prefixing"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_user_agent`]: that prefixes this split envelope; this restores the channel value."
        ),
        "Parts::clear_user_agent must Distinct prefixing from restoring the channel value"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay."
        ),
        "Request::accepts_compressed must Distinct client interceptor overlay from inbound dispatch"
    );
    assert!(
        outgoing.contains("Channel [`crate::Channel::max_concurrent_rpcs`] overlay."),
        "Outgoing::concurrent_rpc_limit must name the channel max_concurrent_rpcs overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::waits_for_ready`]: that waits for a connection; this refuses extras."
        ),
        "Outgoing::concurrent_rpc_limit must Distinct wait-for-ready from refusing extras"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::max_concurrent_rpcs`] overlay, when the kernel dispatched this call."
        ),
        "Request::concurrent_rpc_limit must name the server max_concurrent_rpcs overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::concurrent_rpc_limit`]: that is a client interceptor overlay."
        ),
        "Request::concurrent_rpc_limit must Distinct client interceptor overlay from inbound dispatch"
    );
    assert!(
        outgoing
            .contains("Distinct from [`Self::limits`]: that is message size, not how many RPCs."),
        "Request::concurrent_rpc_limit must Distinct message size from the process RPC cap"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::max_send_buffer_size`] overlay, when the kernel dispatched this call."
        ),
        "Request::send_buffer_size must name the server max_send_buffer_size overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::send_buffer_size`]: that is a client interceptor overlay."
        ),
        "Request::send_buffer_size must Distinct client interceptor overlay from inbound dispatch"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is message size, not this HTTP/2 send buffer."
        ),
        "Request::send_buffer_size must Distinct message size from the HTTP/2 send buffer"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel still applies this buffer when writing DATA."
        ),
        "Request::send_buffer_size must name the write-time DATA apply"
    );
    assert!(
        outgoing.contains("Channel [`crate::Channel::stream_buffer`] overlay."),
        "Outgoing::stream_buffer_size must name the channel stream_buffer overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is message size, not how many messages sit in the outbound queue."
        ),
        "Outgoing::stream_buffer_size must Distinct message size from queue depth"
    );
    assert!(
        outgoing.contains(
            "Applies to client-streaming and bidi request streams. Unary and server-streaming have no request stream to queue."
        ),
        "Outgoing::stream_buffer_size must name the streaming shapes it queues"
    );
    assert!(
        outgoing.contains("Same overlay as [`crate::Channel::limits`]."),
        "Outgoing::limits must name the Channel::limits overlay"
    );
    assert!(
        outgoing.contains(
            "[`Self::send_buffer_size`] / [`Self::limits`]), and the service/method halves of the path,"
        ),
        "Outgoing rustdoc must name limits next to the interceptor-visible overlays"
    );
    assert!(
        outgoing.contains("        call.limits(),"),
        "Outgoing rustdoc example must read limits"
    );
    assert!(
        outgoing.contains("        call.timeout(),"),
        "Outgoing rustdoc example must read timeout Distinct from rpc_timeout"
    );
    assert!(
        outgoing.contains("        call.deadline(),"),
        "Outgoing rustdoc example must read deadline Distinct from timeout"
    );
    assert!(
        outgoing.contains("        call.metadata(),"),
        "Outgoing rustdoc example must read metadata Distinct from metadata_mut"
    );
    assert!(
        outgoing.contains("        call.path(),"),
        "Outgoing rustdoc example must read path Distinct from Request::path"
    );
    assert!(
        outgoing.contains("        call.service(),"),
        "Outgoing rustdoc example must read service Distinct from Rpc::service"
    );
    assert!(
        outgoing.contains("        call.method(),"),
        "Outgoing rustdoc example must read method Distinct from Rpc::method"
    );
    assert!(
        outgoing.contains("        call.authority(),"),
        "Outgoing rustdoc example must read authority Distinct from Rpc::authority"
    );
    assert!(
        outgoing.contains("        call.scheme(),"),
        "Outgoing rustdoc example must read scheme Distinct from Rpc::scheme"
    );
    assert!(
        outgoing.contains("        call.user_agent(),"),
        "Outgoing rustdoc example must read user_agent Distinct from inserting user-agent into metadata"
    );
    assert!(
        outgoing.contains("        call.user_agent_is_set(),"),
        "Outgoing rustdoc example must dump user_agent_is_set Distinct from user_agent"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::user_agent`]: that is the override only; this is the effective header this RPC will send."
        ),
        "Outgoing::user_agent must Distinct the Request override from the effective header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::user_agent`]: that is the effective header this RPC will send; this is occupancy."
        ),
        "Outgoing::user_agent_is_set Distinct from user_agent: that is the effective header this RPC will send; this is occupancy"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::user_agent_is_set`]: that is the call-site occupancy; this is the same flag after interceptors run."
        ),
        "Outgoing::user_agent_is_set Distinct from Request::user_agent_is_set: that is the call-site occupancy; this is the same flag after interceptors run"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::scheme`]: that is the inbound `:scheme`; this is the `:scheme` this channel sends."
        ),
        "Outgoing::scheme must Distinct the inbound :scheme from the outbound :scheme"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::authority`]: that is the inbound `:authority`; this is the `:authority` this channel sends."
        ),
        "Outgoing::authority must Distinct the inbound :authority from the outbound :authority"
    );
    assert!(
        outgoing.contains(
            "TLS uses the channel [`crate::Target`], not SNI, unless\n    /// [`crate::Channel::origin`] overrode it on this clone."
        ),
        "Outgoing::authority must name origin overlay Distinct from Target and SNI"
    );
    assert!(
        outgoing.contains(
            "[`crate::Target`], not SNI, unless [`crate::Channel::origin`] overrode\n    /// `:authority` on that clone."
        ),
        "Request::authority must name origin overlay Distinct from Target and SNI"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::method`]: that is a server interceptor; this is a client interceptor before send."
        ),
        "Outgoing::method must Distinct the server interceptor method from the outbound split"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::service`]: that is a server interceptor; this is a client interceptor before send."
        ),
        "Outgoing::service must Distinct the server interceptor service from the outbound split"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::path`]: that is a server interceptor; this is a client interceptor before send."
        ),
        "Outgoing::path must Distinct the server interceptor path from the outbound path"
    );
    assert!(
        outgoing.contains("        call.extensions(),"),
        "Outgoing rustdoc example must read extensions Distinct from extensions_mut"
    );
    assert!(
        outgoing.contains("        call.wait_for_ready(),"),
        "Outgoing rustdoc example must read wait_for_ready Distinct from waits_for_ready"
    );
    assert!(
        outgoing.contains("        call.wait_for_ready_is_set(),"),
        "Outgoing rustdoc example must dump wait_for_ready_is_set Distinct from wait_for_ready"
    );
    assert!(
        outgoing.contains("        call.compress(),"),
        "Outgoing rustdoc example must read compress Distinct from compresses_outbound"
    );
    assert!(
        outgoing.contains("        call.compress_is_set(),"),
        "Outgoing rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is the channel overlay; this is the per-RPC choice."
        ),
        "Outgoing::compress must Distinct the channel overlay from the per-RPC choice"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that reads the per-RPC Compressed-Flag; this writes it."
        ),
        "Outgoing::set_compress must Distinct reading the per-RPC Compressed-Flag from writing it"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_compress`]: that writes the per-RPC Compressed-Flag; this opts out."
        ),
        "Outgoing::clear_compress must Distinct writing the per-RPC Compressed-Flag from opting out"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::waits_for_ready`]: that is the channel overlay; this is the per-RPC choice."
        ),
        "Outgoing::wait_for_ready must Distinct the channel overlay from the per-RPC choice"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values; this borrows the map."
        ),
        "Outgoing::extensions must Distinct the mutator from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions`]: that borrows the map; this inserts typed values."
        ),
        "Outgoing::extensions_mut must Distinct the borrow from the mutator"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates the outbound map; this borrows it."
        ),
        "Outgoing::metadata must Distinct the mutable outbound map from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that borrows the outbound map; this mutates it."
        ),
        "Outgoing::metadata_mut must Distinct the borrow from the mutable outbound map"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is the duration; this Instant is computed when the getter runs."
        ),
        "Outgoing::deadline must Distinct the duration from the computed Instant"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::rpc_timeout`]: that is the duration overlay; this Instant is computed when the getter runs."
        ),
        "Outgoing::deadline must Distinct the channel overlay duration from the computed Instant"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::rpc_timeout`]: that is the channel overlay; this is the Call `grpc-timeout`."
        ),
        "Outgoing::timeout must Distinct the channel overlay from the Call grpc-timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that reads the Call `grpc-timeout`; this writes it."
        ),
        "Outgoing::set_timeout must Distinct reading the Call grpc-timeout from writing it"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::set_timeout`]: that writes the Call `grpc-timeout`; this opts out."
        ),
        "Outgoing::clear_timeout must Distinct writing the Call grpc-timeout from opting out"
    );
    assert!(
        outgoing.contains("Channel [`crate::Channel::max_send_buffer_size`] overlay."),
        "Outgoing::send_buffer_size must name the channel max_send_buffer_size overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is uncompressed protobuf bytes, not this HTTP/2 send buffer."
        ),
        "Outgoing::send_buffer_size must Distinct message size from the HTTP/2 send buffer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::stream_buffer_size`]: that is decoded-message queue depth, not this send buffer."
        ),
        "Outgoing::send_buffer_size must Distinct queue depth from the send buffer"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel applies it when sending DATA."
        ),
        "Outgoing::send_buffer_size must name the write-time DATA apply"
    );
    assert!(
        outgoing.contains("Kernel-stamped after a handler `Ok` and after a successful receive."),
        "Response::path must name kernel stamp after Ok and after receive"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates this reply envelope; this borrows it."
        ),
        "Response::metadata must Distinct the mutable reply envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates this split reply envelope; this borrows it."
        ),
        "ResponseParts::metadata must Distinct the mutable split reply envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::trailers_mut`]: that mutates this reply envelope; this borrows it."
        ),
        "Response::trailers must Distinct the mutable reply envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::trailers_mut`]: that mutates this split reply envelope; this borrows it."
        ),
        "ResponseParts::trailers must Distinct the mutable split reply envelope from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values this reply envelope carries; this borrows them."
        ),
        "Response::extensions must Distinct the mutable reply envelope map from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::extensions_mut`]: that inserts typed values this split reply envelope carries; this borrows them."
        ),
        "ResponseParts::extensions must Distinct the mutable split reply envelope map from the borrow"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::metadata`]: that is headers on this split reply envelope; this is typed local state, not on the wire."
        ),
        "ResponseParts::extensions Distinct from metadata: that is headers on this split reply envelope; this is typed local state, not on the wire"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::path`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::path must Distinct inbound Request::path from the split reply"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::path`]: that is a client interceptor before send, not this split reply envelope."
        ),
        "ResponseParts::path must Distinct Outgoing::path from the split reply"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that is on or off on this split reply envelope; this is deflate effort."
        ),
        "ResponseParts::gzip_level must Distinct on/off from deflate effort"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::gzip_level`]: that is a client interceptor overlay, not this split reply envelope's server overlay."
        ),
        "ResponseParts::gzip_level must Distinct client interceptor overlay from server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::gzip_level`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::gzip_level must Distinct Rpc overlay from the split reply"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is the received `grpc-encoding` token on this split reply envelope."
        ),
        "ResponseParts::gzip_level must Distinct received encoding from deflate effort"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that is the per-RPC choice after overlay and interceptor mutation on this split reply envelope."
        ),
        "ResponseParts::compresses_outbound must Distinct compress as the per-RPC flag"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::compresses_outbound`]: that is a client interceptor overlay, not this split reply envelope's server overlay."
        ),
        "ResponseParts::compresses_outbound must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::compresses_outbound`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::compresses_outbound must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::gzip_level`]: that is deflate effort on this split reply envelope, not on or off."
        ),
        "ResponseParts::compresses_outbound must Distinct gzip_level deflate effort"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is received `grpc-encoding`, not `grpc-accept-encoding` on this split reply envelope."
        ),
        "ResponseParts::accepts_gzip must Distinct received encoding from accept-encoding"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::accepts_gzip`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::accepts_gzip must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::accepts_gzip`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::accepts_gzip must Distinct inbound Request::accepts_gzip"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is the server encode overlay on this split reply envelope, not the peer advertisement."
        ),
        "ResponseParts::accepts_gzip must Distinct send_compressed overlay from peer advertisement"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay, not this split reply envelope's server overlay."
        ),
        "ResponseParts::accepts_gzip must Distinct Outgoing inbound overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer advertisement on this split reply envelope, not this overlay."
        ),
        "ResponseParts::accepts_compressed Distinct from accepts_gzip: that is the peer advertisement on this split reply envelope, not this overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::accepts_compressed`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::accepts_compressed Distinct from Rpc::accepts_compressed: that is a server interceptor before the handler, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay, not this split reply envelope's inbound overlay."
        ),
        "ResponseParts::accepts_compressed Distinct from Outgoing::accepts_compressed: that is a client interceptor overlay, not this split reply envelope's inbound overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is whether this reply is gzipped on this split reply envelope."
        ),
        "ResponseParts::accepts_compressed Distinct from compresses_outbound: that is whether this reply is gzipped on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is received `grpc-encoding`, not this advertisement on this split reply envelope."
        ),
        "ResponseParts::accepts_compressed Distinct from encoding: that is received grpc-encoding, not this advertisement on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::deadline`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::deadline Distinct from Request::deadline: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::deadline`]: that is computed when that getter runs, not this split reply envelope."
        ),
        "ResponseParts::deadline Distinct from Rpc::deadline: that is computed when that getter runs, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::timeout`]: that is the duration stamped at dispatch, not this split reply envelope."
        ),
        "ResponseParts::deadline Distinct from Request::timeout: that is the duration stamped at dispatch, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::deadline`]: that is a client interceptor Instant, not this split reply envelope."
        ),
        "ResponseParts::deadline Distinct from Outgoing::deadline: that is a client interceptor Instant, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::timeout`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Request::timeout: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant on this split reply envelope; this duration does not shrink."
        ),
        "ResponseParts::timeout Distinct from deadline: that is the Instant on this split reply envelope; this duration does not shrink"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the effective duration on this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Rpc::timeout: that is the interceptor cap, not the effective duration on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::effective_timeout`]: that is computed when that getter runs, not this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Rpc::effective_timeout: that is computed when that getter runs, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is the server overlay, not the effective cap on this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Rpc::rpc_timeout: that is the server overlay, not the effective cap on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::peer_timeout`]: that is the client's `grpc-timeout`, not this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Request::peer_timeout: that is the client's grpc-timeout, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::timeout`]: that is a client interceptor duration, not this split reply envelope."
        ),
        "ResponseParts::timeout Distinct from Outgoing::timeout: that is a client interceptor duration, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::peer_timeout`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::peer_timeout Distinct from Request::peer_timeout: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is the effective cap on this split reply envelope; this is the client's original header."
        ),
        "ResponseParts::peer_timeout Distinct from timeout: that is the effective cap on this split reply envelope; this is the client's original header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the client header on this split reply envelope."
        ),
        "ResponseParts::peer_timeout Distinct from Rpc::timeout: that is the interceptor cap, not the client header on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is the server overlay, not the client header on this split reply envelope."
        ),
        "ResponseParts::peer_timeout Distinct from Rpc::rpc_timeout: that is the server overlay, not the client header on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::peer_timeout`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::peer_timeout Distinct from Rpc::peer_timeout: that is a server interceptor before the handler, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::effective_timeout`]: that is the soonest of the three caps on this split reply envelope."
        ),
        "ResponseParts::peer_timeout Distinct from Rpc::effective_timeout: that is the soonest of the three caps on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant on this split reply envelope, not the client header."
        ),
        "ResponseParts::peer_timeout Distinct from deadline: that is the Instant on this split reply envelope, not the client header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::rpc_timeout`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::rpc_timeout Distinct from Request::rpc_timeout: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is the effective cap on this split reply envelope; this is the server overlay."
        ),
        "ResponseParts::rpc_timeout Distinct from timeout: that is the effective cap on this split reply envelope; this is the server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::peer_timeout`]: that is the client's `grpc-timeout` on this split reply envelope, not the server overlay."
        ),
        "ResponseParts::rpc_timeout Distinct from peer_timeout: that is the client's grpc-timeout on this split reply envelope, not the server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::rpc_timeout Distinct from Rpc::rpc_timeout: that is a server interceptor before the handler, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the server overlay on this split reply envelope."
        ),
        "ResponseParts::rpc_timeout Distinct from Rpc::timeout: that is the interceptor cap, not the server overlay on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::rpc_timeout`]: that is a client interceptor overlay, not this split reply envelope."
        ),
        "ResponseParts::rpc_timeout Distinct from Outgoing::rpc_timeout: that is a client interceptor overlay, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant on this split reply envelope, not the server overlay."
        ),
        "ResponseParts::rpc_timeout Distinct from deadline: that is the Instant on this split reply envelope, not the server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::limits`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::limits Distinct from Request::limits: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::limits`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::limits Distinct from Rpc::limits: that is a server interceptor before the handler, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::limits`]: that is a client interceptor overlay, not this split reply envelope."
        ),
        "ResponseParts::limits Distinct from Outgoing::limits: that is a client interceptor overlay, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is a duration on this split reply envelope, not a size cap."
        ),
        "ResponseParts::limits Distinct from timeout: that is a duration on this split reply envelope, not a size cap"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is queue depth, not message size on this split reply envelope."
        ),
        "ResponseParts::limits Distinct from Outgoing::stream_buffer_size: that is queue depth, not message size on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::send_buffer_size`]: that is the inbound request, not this split reply envelope."
        ),
        "ResponseParts::send_buffer_size Distinct from Request::send_buffer_size: that is the inbound request, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::send_buffer_size`]: that is a server interceptor before the handler, not this split reply envelope."
        ),
        "ResponseParts::send_buffer_size Distinct from Rpc::send_buffer_size: that is a server interceptor before the handler, not this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::send_buffer_size`]: that is a client interceptor overlay, not this split reply envelope's server overlay."
        ),
        "ResponseParts::send_buffer_size Distinct from Outgoing::send_buffer_size: that is a client interceptor overlay, not this split reply envelope's server overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is the encode cap on this split reply envelope, not this HTTP/2 send buffer."
        ),
        "ResponseParts::send_buffer_size Distinct from limits: that is the encode cap on this split reply envelope, not this HTTP/2 send buffer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is decoded-message queue depth, not this send buffer on this split reply envelope."
        ),
        "ResponseParts::send_buffer_size Distinct from Outgoing::stream_buffer_size: that is decoded-message queue depth, not this send buffer on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compressed`]: that is the unary Compressed-Flag (and outbound intent) on this split reply envelope; this is the HTTP header."
        ),
        "ResponseParts::encoding Distinct from compressed: that is the unary Compressed-Flag (and outbound intent) on this split reply envelope; this is the HTTP header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`], which is `false` when unset on this split reply envelope."
        ),
        "ResponseParts::compress_is_set Distinct from compress: which is false when unset on this split reply envelope"
    );
    assert!(
        outgoing.contains(
            "[`Self::compress_is_set`] is occupancy on this split reply envelope, so a later interceptor can fill compress only when unset."
        ),
        "ResponseParts rustdoc must name compress_is_set occupancy next to the method Distinct"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] restores the server gzip overlay on this split reply envelope."
        ),
        "ResponseParts rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        outgoing.contains("Distinct from [`crate::Request::path`]: that is the inbound request."),
        "Response::path must Distinct inbound Request::path"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::path`]: that is a client interceptor before send."
        ),
        "Response::path must Distinct Outgoing::path before send"
    );
    assert!(
        outgoing.contains(
            "[`Self::compress_is_set`] is occupancy on this reply envelope, so a later interceptor can fill compress only when unset."
        ),
        "Response rustdoc must name compress_is_set occupancy next to path Distincts"
    );
    assert!(
        outgoing.contains(
            "[`Self::clear_compress`] restores the server gzip overlay on this reply envelope."
        ),
        "Response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::gzip_compression_level`] overlay, when the kernel is encoding this reply."
        ),
        "Response::gzip_level must name the server encode overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that is on or off; this is deflate effort."
        ),
        "Response::gzip_level must Distinct compress on/off from deflate effort"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::gzip_level`]: that is a server interceptor before the handler."
        ),
        "Response::gzip_level must Distinct Rpc::gzip_level before the handler"
    );
    assert!(
        outgoing.contains(
            "[`crate::DEFAULT_GZIP_COMPRESSION_LEVEL`] on a response you built or a received reply (deflate effort is not on the wire)."
        ),
        "Response::gzip_level must name DEFAULT on a received reply"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is the received `grpc-encoding` token."
        ),
        "Response::gzip_level must Distinct received encoding from deflate effort"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::send_compressed`] overlay, when the kernel is encoding this reply."
        ),
        "Response::compresses_outbound must name the server encode overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compress`]: that is the per-RPC choice after overlay and interceptor mutation."
        ),
        "Response::compresses_outbound must Distinct compress as the per-RPC flag"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::compresses_outbound`]: that is a client interceptor overlay."
        ),
        "Response::compresses_outbound must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::compresses_outbound`]: that is a server interceptor before the handler."
        ),
        "Response::compresses_outbound must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing
            .contains("Distinct from [`Self::gzip_level`]: that is deflate effort, not on or off."),
        "Response::compresses_outbound must Distinct gzip_level deflate effort"
    );
    assert!(
        outgoing.contains(
            "`false` on a response you built or a received reply (the overlay is not on the wire)."
        ),
        "Response::compresses_outbound must name false on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; unset [`Self::compress`] follows this default when the peer advertised gzip."
        ),
        "Response::compresses_outbound must name fill-if-unset when the peer advertised gzip"
    );
    assert!(
        outgoing.contains(
            "Peer `grpc-accept-encoding` gzip advertisement, when the kernel is encoding this reply."
        ),
        "Response::accepts_gzip must name the peer advertisement at encode"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is received `grpc-encoding`, not `grpc-accept-encoding`."
        ),
        "Response::accepts_gzip must Distinct received encoding from accept-encoding"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::accepts_gzip`]: that is a server interceptor before the handler."
        ),
        "Response::accepts_gzip must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::accepts_gzip`]: that is the inbound request."
        ),
        "Response::accepts_gzip must Distinct inbound Request::accepts_gzip"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is the server encode overlay, not the peer advertisement."
        ),
        "Response::accepts_gzip must Distinct send_compressed overlay from peer advertisement"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay."
        ),
        "Response::accepts_gzip must Distinct Outgoing inbound overlay"
    );
    assert!(
        outgoing.contains(
            "`false` on a response you built or a received reply (the advertisement is not on the reply wire)."
        ),
        "Response::accepts_gzip must name false on a received reply"
    );
    assert!(
        outgoing
            .contains("An interceptor cannot change this; gzip only goes out when this is true."),
        "Response::accepts_gzip must name that gzip only goes out when the peer advertised it"
    );
    assert!(
        outgoing.contains(
            "Kernel-stamped remaining Instant after a handler `Ok`, when the kernel is writing this reply."
        ),
        "Response::deadline must name kernel stamp when writing"
    );
    assert!(
        outgoing.contains("Same Instant as [`crate::Request::deadline`] after dispatch."),
        "Response::deadline must name the Request Instant"
    );
    assert!(
        outgoing
            .contains("Distinct from [`crate::Request::deadline`]: that is the inbound request."),
        "Response::deadline must Distinct inbound Request::deadline"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::deadline`]: that is computed when that getter runs."
        ),
        "Response::deadline must Distinct Rpc::deadline computed getter"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::timeout`]: that is the duration stamped at dispatch."
        ),
        "Response::deadline must Distinct Request::timeout duration"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::deadline`]: that is a client interceptor Instant."
        ),
        "Response::deadline must Distinct Outgoing Instant"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the peer deadline is not on the wire)."
        ),
        "Response::deadline must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel still enforces it when writing."
        ),
        "Response::deadline must name kernel enforcement when writing"
    );
    assert!(
        outgoing.contains(
            "Effective timeout duration stamped at dispatch, when the kernel is writing this reply."
        ),
        "Response::timeout must name duration stamped at dispatch when writing"
    );
    assert!(
        outgoing.contains(
            "Same duration as [`crate::Request::timeout`] after dispatch. This duration does not shrink."
        ),
        "Response::timeout must name the Request duration"
    );
    assert!(
        outgoing
            .contains("Distinct from [`crate::Request::timeout`]: that is the inbound request."),
        "Response::timeout must Distinct inbound Request::timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant; this duration does not shrink."
        ),
        "Response::timeout must Distinct deadline Instant"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the effective duration."
        ),
        "Response::timeout must Distinct Rpc interceptor cap"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::effective_timeout`]: that is computed when that getter runs."
        ),
        "Response::timeout must Distinct Rpc::effective_timeout computed getter"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is the server overlay, not the effective cap."
        ),
        "Response::timeout must Distinct Rpc::rpc_timeout overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::peer_timeout`]: that is the client's `grpc-timeout`."
        ),
        "Response::timeout must Distinct Request::peer_timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::timeout`]: that is a client interceptor duration."
        ),
        "Response::timeout must Distinct Outgoing duration"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the peer timeout is not on the reply wire)."
        ),
        "Response::timeout must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel still enforces [`Self::deadline`] when writing."
        ),
        "Response::timeout must name kernel enforcement of deadline when writing"
    );
    assert!(
        outgoing.contains("Message caps the kernel is enforcing when encoding this reply."),
        "Response::limits must name encode caps when writing"
    );
    assert!(
        outgoing.contains(
            "Same caps as [`crate::Rpc::limits`] / [`crate::Request::limits`] after dispatch."
        ),
        "Response::limits must name the Request/Rpc caps"
    );
    assert!(
        outgoing.contains("Distinct from [`crate::Request::limits`]: that is the inbound request."),
        "Response::limits must Distinct inbound Request::limits"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::limits`]: that is a server interceptor before the handler."
        ),
        "Response::limits must Distinct Rpc::limits before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::limits`]: that is a client interceptor overlay."
        ),
        "Response::limits must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains("Distinct from [`Self::timeout`]: that is a duration, not a size cap."),
        "Response::limits must Distinct timeout duration"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is queue depth, not message size."
        ),
        "Response::limits must Distinct stream_buffer_size queue depth"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the peer encode cap is not on the wire)."
        ),
        "Response::limits must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot raise them; the kernel still checks these caps when encoding."
        ),
        "Response::limits must name kernel encode check"
    );
    assert!(
        outgoing.contains(
            "The client's original `grpc-timeout`, when the kernel is writing this reply."
        ),
        "Response::peer_timeout must name client grpc-timeout when writing"
    );
    assert!(
        outgoing.contains("Same duration as [`crate::Request::peer_timeout`] after dispatch."),
        "Response::peer_timeout must name the Request duration"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::peer_timeout`]: that is the inbound request."
        ),
        "Response::peer_timeout must Distinct inbound Request::peer_timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is the effective cap; this is the client's original header."
        ),
        "Response::peer_timeout must Distinct effective timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the client header."
        ),
        "Response::peer_timeout must Distinct Rpc interceptor cap"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is the server overlay, not the client header."
        ),
        "Response::peer_timeout must Distinct Rpc::rpc_timeout overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::peer_timeout`]: that is a server interceptor before the handler."
        ),
        "Response::peer_timeout must Distinct Rpc::peer_timeout before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::effective_timeout`]: that is the soonest of the three caps."
        ),
        "Response::peer_timeout must Distinct Rpc::effective_timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant, not the client header."
        ),
        "Response::peer_timeout must Distinct deadline Instant"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the client's `grpc-timeout` is not on the reply wire)."
        ),
        "Response::peer_timeout must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel already combined it into [`Self::timeout`]."
        ),
        "Response::peer_timeout must name fold into effective timeout"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::timeout`] overlay, when the kernel is writing this reply."
        ),
        "Response::rpc_timeout must name server overlay when writing"
    );
    assert!(
        outgoing.contains("Same duration as [`crate::Request::rpc_timeout`] after dispatch."),
        "Response::rpc_timeout must name the Request duration"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::rpc_timeout`]: that is the inbound request."
        ),
        "Response::rpc_timeout must Distinct inbound Request::rpc_timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::timeout`]: that is the effective cap; this is the server overlay."
        ),
        "Response::rpc_timeout must Distinct effective timeout"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::peer_timeout`]: that is the client's `grpc-timeout`, not the server overlay."
        ),
        "Response::rpc_timeout must Distinct peer_timeout client header"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::rpc_timeout`]: that is a server interceptor before the handler."
        ),
        "Response::rpc_timeout must Distinct Rpc::rpc_timeout before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::timeout`]: that is the interceptor cap, not the server overlay."
        ),
        "Response::rpc_timeout must Distinct Rpc interceptor cap"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::rpc_timeout`]: that is a client interceptor overlay."
        ),
        "Response::rpc_timeout must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::deadline`]: that is the Instant, not the server overlay."
        ),
        "Response::rpc_timeout must Distinct deadline Instant"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the server overlay is not on the reply wire)."
        ),
        "Response::rpc_timeout must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; an interceptor cap only tightens [`Self::timeout`]."
        ),
        "Response::rpc_timeout must name interceptor cap only tightens timeout"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::accept_compressed`] overlay, when the kernel is writing this reply."
        ),
        "Response::accepts_compressed must name inbound overlay when writing"
    );
    assert!(
        outgoing.contains(
            "Same overlay as [`crate::Rpc::accepts_compressed`] / [`crate::Request::accepts_compressed`]."
        ),
        "Response::accepts_compressed must name the Request/Rpc overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::accepts_gzip`]: that is the peer advertisement, not this overlay."
        ),
        "Response::accepts_compressed must Distinct peer accepts_gzip"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::accepts_compressed`]: that is a server interceptor before the handler."
        ),
        "Response::accepts_compressed must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::accepts_compressed`]: that is a client interceptor overlay, not this server stamp."
        ),
        "Response::accepts_compressed must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::compresses_outbound`]: that is whether this reply is gzipped."
        ),
        "Response::accepts_compressed must Distinct compresses_outbound"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::encoding`]: that is received `grpc-encoding`, not this advertisement."
        ),
        "Response::accepts_compressed must Distinct encoding"
    );
    assert!(
        outgoing.contains(
            "`false` on a response you built or a received reply (this overlay is not a received-reply field)."
        ),
        "Response::accepts_compressed must name false on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel still advertises `grpc-accept-encoding` from this."
        ),
        "Response::accepts_compressed must name grpc-accept-encoding advertisement"
    );
    assert!(
        outgoing.contains(
            "Server [`crate::Server::max_send_buffer_size`] overlay, when the kernel is writing this reply."
        ),
        "Response::send_buffer_size must name server overlay when writing"
    );
    assert!(
        outgoing.contains(
            "Same overlay as [`crate::Rpc::send_buffer_size`] / [`crate::Request::send_buffer_size`]."
        ),
        "Response::send_buffer_size must name the Request/Rpc overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Request::send_buffer_size`]: that is the inbound request."
        ),
        "Response::send_buffer_size must Distinct inbound Request::send_buffer_size"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Rpc::send_buffer_size`]: that is a server interceptor before the handler."
        ),
        "Response::send_buffer_size must Distinct Rpc overlay before the handler"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::send_buffer_size`]: that is a client interceptor overlay, not this server stamp."
        ),
        "Response::send_buffer_size must Distinct Outgoing overlay"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`Self::limits`]: that is the encode cap, not this HTTP/2 send buffer."
        ),
        "Response::send_buffer_size must Distinct encode caps from the send buffer"
    );
    assert!(
        outgoing.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is decoded-message queue depth, not this send buffer."
        ),
        "Response::send_buffer_size must Distinct queue depth from the send buffer"
    );
    assert!(
        outgoing.contains(
            "`None` on a response you built or a received reply (the peer send buffer is not on the reply wire)."
        ),
        "Response::send_buffer_size must name None on a received reply"
    );
    assert!(
        outgoing.contains(
            "An interceptor cannot change this; the kernel still applies this buffer when writing DATA."
        ),
        "Response::send_buffer_size must name the write-time DATA apply"
    );
    assert!(
        outgoing
            .contains("An interceptor cannot change this; the kernel applies it when encoding."),
        "Outgoing::gzip_level must Distinct interceptor-visible overlay from per-RPC mutation"
    );
    assert!(
        src.contains(
            "OK-path custom trailers land on [`crate::Response::trailers`]; a `-bin`\n    /// trailer must not appear as a header, including over TLS, mTLS, Unix,\n    /// and [`Self::from_io`]."
        ),
        "Channel unary and client-streaming rustdoc must name OK-path -bin trailers on every transport"
    );
    assert!(
        src.contains(
            "[`crate::Streaming::trailers`] waits for end-of-stream, including when\n    /// called before draining messages. A non-OK trailing `grpc-status` is\n    /// `Err`. A `-bin` trailer must not appear as a header, including over\n    /// TLS, mTLS, Unix, and [`Self::from_io`]."
        ),
        "Channel server-streaming and bidi rustdoc must name Streaming::trailers on every transport"
    );
    assert!(
        src.contains(
            "RPC as [`Code::Unavailable`] (including over TLS, mTLS, and Unix), or\n    /// waits until the deadline if that RPC"
        ),
        "Channel::connect_lazy must name fail-fast on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains("[`Self::from_io`] with `config`. Applies to every call shape."),
        "Channel::from_io_with must name every call shape"
    );
    assert!(
        src.contains(
            "[`ChannelConfig::connections`] is forced to 1: one duplex is one\n    /// HTTP/2 connection."
        ),
        "Channel::from_io_with must name that pooling is forced to one duplex"
    );
    assert!(
        src.contains(
            "[`ChannelConfig::connections`] opens that many TLS sockets (including\n    /// mTLS); all of them must succeed. [`Self::from_io`] cannot pool."
        ),
        "Channel::connect_tls_with must name TLS pooling"
    );
    assert!(
        src.contains(
            "[`ChannelConfig::connections`] opens that many Unix sockets; all of\n    /// them must succeed. [`Self::from_io`] cannot pool."
        ),
        "Channel::connect_unix_with must name Unix pooling"
    );
    assert!(
        src.contains(
            "TLS (including mTLS) pooling is [`Self::connect_tls_with`] plus\n    /// [`ChannelConfig::connections`]; Unix is [`Self::connect_unix_with`].\n    /// [`Self::from_io`] cannot pool."
        ),
        "Channel::connect_pool must name TLS and Unix pooling"
    );
    assert!(
        src.contains("The configuration in effect. Applies to every call shape."),
        "Channel::config must name every call shape"
    );
    assert!(
        src.contains(
            "Distinct from gRPC `GetState` / `WaitForStateChange`: this does not\n    /// dial, wait, or remember `TRANSIENT_FAILURE`."
        ),
        "Channel::connected must Distinct gRPC GetState"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::wait_for_ready`]: that overlay queues; this is a live snapshot."
        ),
        "Channel::connected must Distinct wait-for-ready overlay from the live snapshot"
    );
    assert!(
        src.contains(
            "RPC redials. [`Self::from_io`] stays `false` after that close.\n    /// Applies to every call shape, including over TLS, mTLS, and Unix."
        ),
        "Channel::connected must name idle/age redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "Client interceptors see the same snapshot as [`crate::Outgoing::connected`]."
        ),
        "Channel::connected must name the interceptor snapshot"
    );
    assert!(
        src.contains(
            "Run `interceptor` on every outbound RPC before the stream opens.\n    /// Applies to every call shape."
        ),
        "Channel::intercept must name every call shape"
    );
    assert!(
        src.contains(
            "visible even after `clear_*` opts out of\n    /// the already-applied default."
        ),
        "Channel::intercept must name overlays after clear_*"
    );
    assert!(
        src.contains("[`crate::Outgoing::gzip_level`] is deflate effort."),
        "Channel::intercept must name Outgoing::gzip_level as deflate effort"
    );
    assert!(
        src.contains("Distinct from [`crate::Outgoing::compresses_outbound`] (on or off)."),
        "Channel::intercept must Distinct gzip_level from compresses_outbound"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_compress`] then\n    /// [`crate::Outgoing::set_compress`] from [`Self::compresses_outbound`]\n    /// reapplies channel gzip on every call shape."
        ),
        "Channel::intercept must name gzip reapply after clear"
    );
    assert!(
        src.contains(
            "stamps [`crate::StreamSender::compress`] on client-streaming and bidi\n    /// request streams."
        ),
        "Channel::intercept must name StreamSender gzip stamp on request streams"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the\n    /// channel timeout on every call shape."
        ),
        "Channel::intercept must name clear_timeout opt-out"
    );
    assert!(
        src.contains(
            "Interceptors run after this fill and can still set or\n    /// [`crate::Outgoing::clear_timeout`]."
        ),
        "Channel::timeout must name interceptor clear_timeout"
    );
    assert!(
        src.contains(
            "Default per-RPC deadline when the request omits one. Applies to every\n    /// call shape, including over TLS, mTLS, Unix, and [`Self::from_io`]."
        ),
        "Channel::timeout must name every transport"
    );
    assert!(
        src.contains(
            "Taken from the [`Target`] used to dial, unless [`Self::origin`]\n    /// overrode it on this clone. A [`SocketAddr`] is that\n    /// address"
        ),
        "Channel::authority must name Target unless origin overrode it, not TLS SNI"
    );
    assert!(
        src.contains(
            "Distinct from tonic's `Endpoint::origin`, which takes a `Uri` and\n    /// also sets `:scheme`; scheme on this kernel is [`Self::connect_tls`]\n    /// or [`Self::https_scheme`]."
        ),
        "Channel::origin must Distinct tonic Endpoint::origin Uri scheme"
    );
    assert!(
        src.contains("Invalid HTTP `:authority` is [`Code::InvalidArgument`]."),
        "Channel::origin must name InvalidArgument for a bad authority"
    );
    let intercept = include_str!("../src/interceptor.rs");
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the channel timeout\n/// on every call shape."
        ),
        "ClientInterceptor rustdoc must name clear_timeout opt-out"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_user_agent`] drops an interceptor prefix so this RPC uses the channel user-agent again."
        ),
        "ClientInterceptor rustdoc must name clear_user_agent opt-out"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_wait_for_ready`] drops an interceptor wait-for-ready choice so this RPC uses the channel overlay again."
        ),
        "ClientInterceptor rustdoc must name clear_wait_for_ready opt-out next to clear_user_agent"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the channel timeout on this ClientInterceptor path."
        ),
        "ClientInterceptor rustdoc must name clear_timeout opt-out next to clear_wait_for_ready"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_compress`] then [`crate::Outgoing::set_compress`] from [`crate::Outgoing::compresses_outbound`] reapplies channel gzip on this ClientInterceptor path."
        ),
        "ClientInterceptor rustdoc must name clear_compress reapply next to clear_timeout"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this ClientInterceptor Err; a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct handler Err after the handler ran from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Interceptor Err without reading the body from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct method-level Interceptor Err without reading the body from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Server intercept Err without reading the body from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Router intercept Err without reading the body from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct ServiceExt intercept Err without reading the body from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct Channel on_response Err Call fail after receive from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this ClientInterceptor Err is a local reject never opens a stream."
        ),
        "ClientInterceptor rustdoc must Distinct StreamSender fail after any messages already sent from this ClientInterceptor Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this ClientInterceptor already ran, so a local Err never consumes that budget."
        ),
        "ClientInterceptor rustdoc must Distinct max_concurrent_rpcs slot grab after intercept"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Interceptor`]: that runs on the inbound RPC before the handler; this runs on the outbound call before the stream opens."
        ),
        "ClientInterceptor rustdoc must Distinct Interceptor inbound-before-handler from outbound-before-stream"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Interceptor`]: that runs on the inbound RPC before the handler; this ClientInterceptor runs on the outbound call before the stream opens."
        ),
        "ClientInterceptor rustdoc must Distinct Interceptor inbound-before-handler from this ClientInterceptor outbound-before-stream"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this runs on the outbound call before the stream opens."
        ),
        "ClientInterceptor rustdoc must Distinct ResponseInterceptor after-Ok-or-receive from outbound-before-stream"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this ClientInterceptor runs on the outbound call before the stream opens."
        ),
        "ClientInterceptor rustdoc must Distinct ResponseInterceptor after-Ok-or-receive from this ClientInterceptor outbound-before-stream"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_user_agent`] drops a method-level interceptor prefix so this RPC uses the channel user-agent again."
        ),
        "ClientInterceptor::intercept rustdoc must name clear_user_agent opt-out"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_wait_for_ready`] drops a method-level interceptor wait-for-ready choice so this RPC uses the channel overlay again."
        ),
        "ClientInterceptor::intercept rustdoc must name clear_wait_for_ready opt-out next to clear_user_agent"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the channel timeout on this method-level intercept."
        ),
        "ClientInterceptor::intercept rustdoc must name clear_timeout opt-out next to clear_wait_for_ready"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::user_agent_is_set`] is occupancy on this method-level intercept, so a later interceptor can prefix only when unset."
        ),
        "ClientInterceptor::intercept rustdoc must name Outgoing::user_agent_is_set occupancy next to clear_user_agent"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::wait_for_ready_is_set`] is occupancy on this method-level intercept, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "ClientInterceptor::intercept rustdoc must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::compress_is_set`] is occupancy on this method-level intercept, so a later interceptor can fill compress only when unset."
        ),
        "ClientInterceptor::intercept rustdoc must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::clear_compress`] then [`crate::Outgoing::set_compress`] from [`crate::Outgoing::compresses_outbound`] reapplies channel gzip on this method-level intercept."
        ),
        "ClientInterceptor::intercept rustdoc must name clear_compress opt-out"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this method-level intercept Err; a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct handler Err after the handler ran from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct method-level Interceptor Err without reading the body from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Interceptor Err without reading the body from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Server intercept Err without reading the body from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Router intercept Err without reading the body from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct ServiceExt intercept Err without reading the body from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this method-level intercept Err is a local reject never opens a stream."
        ),
        "ClientInterceptor::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this method-level intercept Err local reject never opens a stream"
    );
    assert!(
        intercept.contains("prefix ([`crate::Outgoing::set_user_agent`]), or typed"),
        "ClientInterceptor rustdoc must name Outgoing::set_user_agent"
    );
    assert!(
        intercept.contains("same prefix at the call site; an interceptor"),
        "ClientInterceptor rustdoc must Distinct Request::set_user_agent at the call site"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::user_agent_is_set`] distinguishes that override from the channel value, so a later interceptor can prefix only when unset."
        ),
        "ClientInterceptor rustdoc must name Outgoing::user_agent_is_set occupancy next to set_user_agent"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::wait_for_ready_is_set`] is occupancy on this ClientInterceptor path, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "ClientInterceptor rustdoc must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::compress_is_set`] is occupancy on this ClientInterceptor path, so a later interceptor can fill compress only when unset."
        ),
        "ClientInterceptor rustdoc must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        intercept.contains(
            "`gzip_level`, `accepts_compressed`, `concurrent_rpc_limit`, `stream_buffer_size`, `send_buffer_size`, `limits`) stay visible after `clear_*`"
        ),
        "ClientInterceptor rustdoc must name the full channel overlay set next to gzip_level"
    );
    assert!(
        intercept.contains("[`crate::Outgoing::accepts_compressed`] is the inbound gzip overlay"),
        "ClientInterceptor rustdoc must name Outgoing::accepts_compressed"
    );
    assert!(
        intercept.contains("[`crate::Outgoing::limits`] is the channel message-cap overlay."),
        "ClientInterceptor rustdoc must name Outgoing::limits as the message-cap overlay"
    );
    assert!(
        intercept.contains("Same overlay as [`crate::Channel::limits`]."),
        "ClientInterceptor rustdoc must Distinct Outgoing::limits as the same overlay as Channel::limits"
    );
    assert!(
        intercept
            .contains("[`crate::Outgoing::concurrent_rpc_limit`] is the channel RPC cap overlay"),
        "ClientInterceptor rustdoc must name Outgoing::concurrent_rpc_limit"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Outgoing::waits_for_ready`]: that waits for a connection; this refuses extras."
        ),
        "ClientInterceptor rustdoc must Distinct concurrent_rpc_limit from waits_for_ready"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::stream_buffer_size`] is the outbound streaming queue overlay"
        ),
        "ClientInterceptor rustdoc must name Outgoing::stream_buffer_size"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Outgoing::limits`]: that is message size, not queue depth."
        ),
        "ClientInterceptor rustdoc must Distinct stream_buffer_size from limits"
    );
    assert!(
        intercept.contains(
            "[`crate::Outgoing::send_buffer_size`] is the outbound HTTP/2 send buffer overlay"
        ),
        "ClientInterceptor rustdoc must name Outgoing::send_buffer_size"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is queue depth, not this send buffer."
        ),
        "ClientInterceptor rustdoc must Distinct send_buffer_size from stream_buffer_size"
    );
    assert!(
        intercept.contains("[`crate::Outgoing::connected`] is the live-socket snapshot"),
        "ClientInterceptor rustdoc must name Outgoing::connected"
    );
    assert!(
        intercept.contains("[`crate::Outgoing::gzip_level`] is deflate effort"),
        "ClientInterceptor rustdoc must name Outgoing::gzip_level as deflate effort"
    );
    assert!(
        intercept.contains("        call.accepts_compressed(),"),
        "ClientInterceptor rustdoc example must read accepts_compressed"
    );
    assert!(
        intercept.contains("        call.concurrent_rpc_limit(),"),
        "ClientInterceptor rustdoc example must read concurrent_rpc_limit"
    );
    assert!(
        intercept.contains("        call.stream_buffer_size(),"),
        "ClientInterceptor rustdoc example must read stream_buffer_size"
    );
    assert!(
        intercept.contains("        call.limits(),"),
        "ClientInterceptor rustdoc example must read limits"
    );
    assert!(
        intercept.contains("        call.timeout(),"),
        "ClientInterceptor rustdoc example must read timeout Distinct from rpc_timeout"
    );
    assert!(
        intercept.contains("        call.deadline(),"),
        "ClientInterceptor rustdoc example must read deadline Distinct from timeout"
    );
    assert!(
        intercept.contains("        call.metadata(),"),
        "ClientInterceptor rustdoc example must read metadata Distinct from metadata_mut"
    );
    assert!(
        intercept.contains("        call.path(),"),
        "ClientInterceptor rustdoc example must read path Distinct from Request::path"
    );
    assert!(
        intercept.contains("        call.service(),"),
        "ClientInterceptor rustdoc example must read service Distinct from Rpc::service"
    );
    assert!(
        intercept.contains("        call.method(),"),
        "ClientInterceptor rustdoc example must read method Distinct from Rpc::method"
    );
    assert!(
        intercept.contains("        call.authority(),"),
        "ClientInterceptor rustdoc example must read authority Distinct from Rpc::authority"
    );
    assert!(
        intercept.contains("        call.scheme(),"),
        "ClientInterceptor rustdoc example must read scheme Distinct from Rpc::scheme"
    );
    assert!(
        intercept.contains("        call.user_agent(),"),
        "ClientInterceptor rustdoc example must read user_agent Distinct from inserting user-agent into metadata"
    );
    assert!(
        intercept.contains("        call.user_agent_is_set(),"),
        "ClientInterceptor rustdoc example must dump user_agent_is_set Distinct from user_agent"
    );
    assert!(
        intercept.contains("        call.extensions(),"),
        "ClientInterceptor rustdoc example must read extensions Distinct from extensions_mut"
    );
    assert!(
        intercept.contains("        call.wait_for_ready(),"),
        "ClientInterceptor rustdoc example must read wait_for_ready Distinct from waits_for_ready"
    );
    assert!(
        intercept.contains("        call.wait_for_ready_is_set(),"),
        "ClientInterceptor rustdoc example must dump wait_for_ready_is_set Distinct from wait_for_ready"
    );
    assert!(
        intercept.contains("        call.compress(),"),
        "ClientInterceptor rustdoc example must read compress Distinct from compresses_outbound"
    );
    assert!(
        intercept.contains("        call.compress_is_set(),"),
        "ClientInterceptor rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        intercept.contains("[`Rpc::gzip_level`] is deflate effort"),
        "Interceptor rustdoc must name Rpc::gzip_level as deflate effort"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Rpc::compresses_outbound`]: that is on or off; [`Rpc::gzip_level`] is deflate effort."
        ),
        "Interceptor rustdoc must Distinct Rpc::gzip_level from compresses_outbound"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Rpc::accepts_gzip`]: that is the peer's `grpc-accept-encoding`; [`Rpc::accepts_compressed`] is this overlay."
        ),
        "Interceptor rustdoc must Distinct Rpc::accepts_compressed from peer accepts_gzip"
    );
    assert!(
        intercept.contains("[`Rpc::limits`], `accepts_gzip` / encoding with"),
        "Interceptor rustdoc must name accepts_gzip like Dumping Rpc"
    );
    assert!(
        intercept.contains(
            "Distinct from HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`, which waits; [`Rpc::concurrent_rpc_limit`] is this overlay."
        ),
        "Interceptor rustdoc must Distinct Rpc::concurrent_rpc_limit from SETTINGS wait"
    );
    assert!(
        intercept.contains(
            "Distinct from HTTP/2 `SETTINGS_MAX_FRAME_SIZE` and stream/connection windows, which are handshake; [`Rpc::send_buffer_size`] is this write-time overlay."
        ),
        "Interceptor rustdoc must Distinct Rpc::send_buffer_size from handshake SETTINGS"
    );
    assert!(
        intercept.contains("///         rpc.send_buffer_size(),"),
        "Interceptor rustdoc example must read send_buffer_size"
    );
    assert!(
        intercept.contains("///         rpc.limits(),"),
        "Interceptor rustdoc example must read limits"
    );
    assert!(
        intercept.contains(
            "rpc.metadata_mut().set(\"x-actor\", \"gateway\")?;\n///     let _ = (\n///         rpc.path(),\n///         rpc.service(),\n///         rpc.method(),\n///         rpc.metadata(),\n///         rpc.timeout(),\n///         rpc.peer_timeout(),\n///         rpc.rpc_timeout(),\n///         rpc.effective_timeout(),\n///         rpc.deadline(),\n///         rpc.accepts_gzip(),\n///         rpc.encoding(),\n///         rpc.compresses_outbound(),\n///         rpc.gzip_level(),\n///         rpc.accepts_compressed(),\n///         rpc.concurrent_rpc_limit(),\n///         rpc.send_buffer_size(),\n///         rpc.limits(),\n///         rpc.local_addr(),\n///         rpc.remote_addr(),\n///         rpc.peer_identity(),\n///         rpc.peer_cred(),\n///         rpc.authority(),\n///         rpc.scheme(),\n///         rpc.extensions(),"
        ),
        "Interceptor rustdoc example must read Incoming-stamped peer facts"
    );
    assert!(
        intercept.contains("///         rpc.gzip_level(),"),
        "Interceptor rustdoc example must read gzip_level"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this Interceptor Err; those trailers reach the client without reading the body."
        ),
        "Interceptor rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct handler Err after the handler ran from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct Channel on_response Err Call fail after receive from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Interceptor Err is trailers without reading the body."
        ),
        "Interceptor rustdoc must Distinct StreamSender fail after any messages already sent from this Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this method-level Interceptor Err; those trailers reach the client without reading the body."
        ),
        "Interceptor::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct handler Err after the handler ran from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct method-level intercept Err local reject never opens a stream from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct Channel intercept Err local reject never opens a stream from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this method-level Interceptor Err is trailers without reading the body."
        ),
        "Interceptor::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this method-level Interceptor Err without reading the body"
    );
    assert!(
        intercept.contains("Distinct from wait-for-ready: a lazy first RPC sees `false` even when"),
        "ClientInterceptor rustdoc must Distinct connected from wait-for-ready"
    );
    assert!(
        intercept.contains(
            "stamps [`crate::StreamSender::compress`] on client-streaming and bidi\n/// request streams."
        ),
        "ClientInterceptor rustdoc must name StreamSender gzip stamp"
    );
    assert!(
        intercept.contains(
            "overwrite a hop with [`crate::Metadata::set`] / [`crate::Metadata::set_bin`];\n/// those mutations reach the\n/// handler on h2c, TLS including mTLS, Unix, and [`crate::Channel::from_io`]"
        ),
        "Interceptor rustdoc must name set/remove/retain on every transport"
    );
    assert!(
        intercept.contains(
            "[`crate::Request::extensions`] / [`crate::Parts::extensions`] (including\n/// over TLS, mTLS, Unix, and [`crate::Channel::from_io`])"
        ),
        "Interceptor rustdoc must name typed extensions on Request/Parts every transport"
    );
    assert!(
        intercept.contains(
            "A single interceptor\n/// still rejects before the handler on every call shape, including over TLS,\n/// mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "Interceptor rustdoc must name a single ServiceExt intercept reject on every transport"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ClientInterceptor`]: that runs on the outbound call before the stream opens; this runs on the inbound RPC before the handler."
        ),
        "Interceptor rustdoc must Distinct ClientInterceptor outbound-before-stream from inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ClientInterceptor`]: that runs on the outbound call before the stream opens; this Interceptor runs on the inbound RPC before the handler."
        ),
        "Interceptor rustdoc must Distinct ClientInterceptor outbound-before-stream from this Interceptor inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this runs on the inbound RPC before the handler."
        ),
        "Interceptor rustdoc must Distinct ResponseInterceptor after-Ok-or-receive from inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this Interceptor runs on the inbound RPC before the handler."
        ),
        "Interceptor rustdoc must Distinct ResponseInterceptor after-Ok-or-receive from this Interceptor inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "A single interceptor\n    /// still rejects before the handler on every call shape, including over\n    /// TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "ServiceExt::intercept rustdoc must name a single intercept reject on every transport"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this ServiceExt intercept Err; those trailers reach the client without reading the body."
        ),
        "ServiceExt::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct handler Err after the handler ran from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct Channel intercept Err local reject never opens a stream from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct method-level intercept Err local reject never opens a stream from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this ServiceExt intercept Err is trailers without reading the body."
        ),
        "ServiceExt::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this ServiceExt intercept Err without reading the body"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Channel::intercept`]: that runs on the outbound call before the stream opens; this ServiceExt intercept runs on the inbound RPC before the handler."
        ),
        "ServiceExt::intercept rustdoc must Distinct Channel outbound-before-stream from inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this ServiceExt intercept runs on the inbound RPC before the handler."
        ),
        "ServiceExt::intercept rustdoc must Distinct on_response after-Ok from inbound-before-handler"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Server::intercept`]: that runs on the inbound RPC before the Server's Service; this ServiceExt intercept wraps one service with an inbound hook."
        ),
        "ServiceExt::intercept rustdoc must Distinct Server Service coverage from wrapping one service"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Router::intercept`]: that runs on the inbound RPC before every mounted service on that Router; this ServiceExt intercept wraps one service with an inbound hook."
        ),
        "ServiceExt::intercept rustdoc must Distinct Router mounted-service coverage from wrapping one service"
    );
    assert!(
        intercept.contains("svc.intercept(|rpc: &mut pbrs_grpc::Rpc| {"),
        "ServiceExt::intercept rustdoc example must attach a closure"
    );
    assert!(
        intercept.contains(
            "svc.intercept(|rpc: &mut pbrs_grpc::Rpc| {\n    ///     let _ = (\n    ///         rpc.path(),\n    ///         rpc.service(),\n    ///         rpc.method(),\n    ///         rpc.metadata(),\n    ///         rpc.timeout(),\n    ///         rpc.peer_timeout(),\n    ///         rpc.rpc_timeout(),\n    ///         rpc.effective_timeout(),\n    ///         rpc.deadline(),\n    ///         rpc.accepts_gzip(),\n    ///         rpc.encoding(),\n    ///         rpc.compresses_outbound(),\n    ///         rpc.gzip_level(),\n    ///         rpc.accepts_compressed(),\n    ///         rpc.concurrent_rpc_limit(),\n    ///         rpc.send_buffer_size(),\n    ///         rpc.limits(),\n    ///         rpc.local_addr(),\n    ///         rpc.remote_addr(),\n    ///         rpc.peer_identity(),\n    ///         rpc.peer_cred(),\n    ///         rpc.authority(),\n    ///         rpc.scheme(),\n    ///         rpc.extensions(),"
        ),
        "ServiceExt::intercept rustdoc example must read Incoming-stamped peer facts"
    );
    assert!(
        intercept.contains("`Ok`, before headers go out."),
        "ResponseInterceptor rustdoc must name after Ok, before headers"
    );
    assert!(
        intercept
            .contains("`Err` after the handler already ran; that status is sent trailers-only"),
        "ResponseInterceptor rustdoc must name trailers-only after the handler"
    );
    assert!(
        intercept.contains("A handler `Err` skips this hook."),
        "ResponseInterceptor rustdoc must name handler Err skip"
    );
    assert!(
        intercept.contains("they are not on the wire. Stamp"),
        "ResponseInterceptor rustdoc must Distinct extensions from wire metadata"
    );
    assert!(
        intercept.contains("A non-OK peer status skips this hook."),
        "ResponseInterceptor rustdoc must name client skip on non-OK peer status"
    );
    assert!(
        intercept.contains("the peer already sent OK"),
        "ResponseInterceptor rustdoc must name client Err after the peer sent OK"
    );
    assert!(
        intercept.contains("[`crate::ResponseParts::path`] is kernel-stamped."),
        "ResponseInterceptor rustdoc must name kernel-stamped path"
    );
    assert!(
        intercept.contains("Distinct from [`crate::Request::path`]: that is the inbound request."),
        "ResponseInterceptor rustdoc must Distinct inbound Request::path"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Outgoing::path`]: that is a client interceptor before send."
        ),
        "ResponseInterceptor rustdoc must Distinct Outgoing::path before send"
    );
    assert!(
        intercept.contains("[`crate::ResponseParts::gzip_level`] is the server encode overlay."),
        "ResponseInterceptor rustdoc must name gzip_level overlay"
    );
    assert!(
        intercept.contains("Distinct from [`crate::ResponseParts::compress`]: that is on or off."),
        "ResponseInterceptor rustdoc must Distinct gzip_level from compress"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::compresses_outbound`] is the server encode overlay."
        ),
        "ResponseInterceptor rustdoc must name compresses_outbound overlay"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::compress`]: that is the per-RPC Compressed-Flag."
        ),
        "ResponseInterceptor rustdoc must Distinct compresses_outbound from per-RPC compress"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::accepts_gzip`] is the peer `grpc-accept-encoding` advertisement."
        ),
        "ResponseInterceptor rustdoc must name accepts_gzip peer advertisement"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::encoding`]: that is received `grpc-encoding`."
        ),
        "ResponseInterceptor rustdoc must Distinct accepts_gzip from received encoding"
    );
    assert!(
        intercept.contains("[`crate::ResponseParts::deadline`] is kernel-stamped when writing."),
        "ResponseInterceptor rustdoc must name kernel-stamped deadline"
    );
    assert!(
        intercept
            .contains("Distinct from [`crate::Request::deadline`]: that is the inbound request."),
        "ResponseInterceptor rustdoc must Distinct inbound Request::deadline"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Rpc::deadline`]: that is computed when that getter runs."
        ),
        "ResponseInterceptor rustdoc must Distinct Rpc::deadline computed getter"
    );
    assert!(
        intercept
            .contains("[`crate::ResponseParts::timeout`] is the duration stamped at dispatch."),
        "ResponseInterceptor rustdoc must name timeout duration stamped at dispatch"
    );
    assert!(
        intercept
            .contains("Distinct from [`crate::ResponseParts::deadline`]: that is the Instant."),
        "ResponseInterceptor rustdoc must Distinct timeout from deadline Instant"
    );
    assert!(
        intercept.contains("[`crate::ResponseParts::limits`] is the encode cap when writing."),
        "ResponseInterceptor rustdoc must name encode caps when writing"
    );
    assert!(
        intercept
            .contains("Distinct from [`crate::Request::limits`]: that is the inbound request."),
        "ResponseInterceptor rustdoc must Distinct inbound Request::limits"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Rpc::limits`]: that is a server interceptor before the handler."
        ),
        "ResponseInterceptor rustdoc must Distinct Rpc::limits before the handler"
    );
    assert!(
        intercept
            .contains("[`crate::ResponseParts::peer_timeout`] is the client's `grpc-timeout`."),
        "ResponseInterceptor rustdoc must name client grpc-timeout"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::timeout`]: that is the effective cap."
        ),
        "ResponseInterceptor rustdoc must Distinct peer_timeout from effective timeout"
    );
    assert!(
        intercept.contains("[`crate::ResponseParts::rpc_timeout`] is the server overlay."),
        "ResponseInterceptor rustdoc must name server overlay"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::timeout`]: that is soonest-of-three, not the overlay."
        ),
        "ResponseInterceptor rustdoc must Distinct rpc_timeout from effective timeout"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::peer_timeout`]: that is the client's `grpc-timeout`."
        ),
        "ResponseInterceptor rustdoc must Distinct rpc_timeout from client header"
    );
    assert!(
        intercept
            .contains("[`crate::ResponseParts::accepts_compressed`] is the inbound gzip overlay."),
        "ResponseInterceptor rustdoc must name inbound gzip overlay"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::accepts_gzip`]: that is the peer advertisement."
        ),
        "ResponseInterceptor rustdoc must Distinct accepts_compressed from peer advertisement"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::send_buffer_size`] is the write-time HTTP/2 send buffer overlay."
        ),
        "ResponseInterceptor rustdoc must name write-time send buffer overlay"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::ResponseParts::limits`]: that is the encode cap, not this send buffer."
        ),
        "ResponseInterceptor rustdoc must Distinct send_buffer_size from encode caps"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy on this ResponseInterceptor path, so a later interceptor can fill compress only when unset."
        ),
        "ResponseInterceptor rustdoc must name compress_is_set occupancy next to send_buffer Distinct"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay on this ResponseInterceptor path."
        ),
        "ResponseInterceptor rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this ResponseInterceptor Err; a local reject is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct handler Err after the handler ran from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Interceptor Err without reading the body from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct method-level Interceptor Err without reading the body from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Server intercept Err without reading the body from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Router intercept Err without reading the body from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct ServiceExt intercept Err without reading the body from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Channel intercept Err local reject never opens a stream from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct method-level intercept Err local reject never opens a stream from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this ResponseInterceptor Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct StreamSender fail after any messages already sent from this ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Interceptor`]: that runs on the inbound RPC before the handler; this ResponseInterceptor runs after the handler returns Ok or after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct Interceptor inbound-before-handler from after-Ok-or-receive"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ClientInterceptor`]: that runs on the outbound call before the stream opens; this ResponseInterceptor runs after the handler returns Ok or after a successful receive."
        ),
        "ResponseInterceptor rustdoc must Distinct ClientInterceptor outbound-before-stream from after-Ok-or-receive"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag on this method-level on_response Err; a local reject is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct handler Err after the handler ran from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct method-level Interceptor Err without reading the body from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Interceptor Err without reading the body from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Server intercept Err without reading the body from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Router intercept Err without reading the body from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct ServiceExt intercept Err without reading the body from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct method-level intercept Err local reject never opens a stream from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Channel intercept Err local reject never opens a stream from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this method-level on_response Err is trailers-only after handler Ok, or fails the Call after a successful receive."
        ),
        "ResponseInterceptor::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this method-level on_response Err trailers-only after handler Ok or Call fail after receive"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy on this method-level on_response, so a later interceptor can fill compress only when unset."
        ),
        "ResponseInterceptor::intercept rustdoc must name compress_is_set occupancy next to the envelope"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay on this method-level on_response."
        ),
        "ResponseInterceptor::intercept rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        intercept.contains("///         parts.path(),"),
        "ResponseInterceptor rustdoc example must read path"
    );
    assert!(
        intercept.contains("///         parts.service(),"),
        "ResponseInterceptor rustdoc example must dump service Distinct from path"
    );
    assert!(
        intercept.contains("///         parts.method(),"),
        "ResponseInterceptor rustdoc example must dump method Distinct from path"
    );
    assert!(
        intercept.contains("///         parts.metadata(),"),
        "ResponseInterceptor rustdoc example must dump metadata Distinct from metadata_mut"
    );
    assert!(
        intercept.contains("///         parts.trailers(),"),
        "ResponseInterceptor rustdoc example must dump trailers Distinct from trailers_mut"
    );
    assert!(
        intercept.contains("///         parts.compress(),"),
        "ResponseInterceptor rustdoc example must dump compress intent Distinct from gzip_level"
    );
    assert!(
        intercept.contains("///         parts.compress_is_set(),"),
        "ResponseInterceptor rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        intercept.contains("///         parts.encoding(),"),
        "ResponseInterceptor rustdoc example must dump received encoding Distinct from compress"
    );
    assert!(
        intercept.contains(
            "fn stamp_trace(parts: &mut ResponseParts) -> Result<(), Status> {\n///     if let Some(n) = parts.extensions().get::<u8>().copied() {\n///         parts.metadata_mut().insert(\"x-trace\", n.to_string())?;\n///     }\n///     let _ = (\n///         parts.path(),\n///         parts.service(),\n///         parts.method(),\n///         parts.metadata(),\n///         parts.trailers(),\n///         parts.compress(),\n///         parts.compress_is_set(),\n///         parts.encoding(),"
        ),
        "ResponseInterceptor rustdoc example must dump service after path with unique stamp_trace attach"
    );
    assert!(
        intercept.contains("///         parts.gzip_level(),"),
        "ResponseInterceptor rustdoc example must read gzip_level"
    );
    assert!(
        intercept.contains("///         parts.send_buffer_size(),"),
        "ResponseInterceptor rustdoc example must read send_buffer_size"
    );
    assert!(
        intercept
            .contains("///         parts.send_buffer_size(),\n///         parts.extensions(),"),
        "ResponseInterceptor rustdoc example must dump extensions after send_buffer_size"
    );
    assert!(
        intercept.contains("///         parts.limits(),"),
        "ResponseInterceptor rustdoc example must read limits"
    );
    assert!(
        intercept.contains("svc.on_response(|parts: &mut pbrs_grpc::ResponseParts| {"),
        "ServiceExt::on_response rustdoc example must attach a closure"
    );
    assert!(
        intercept.contains(
            "svc.on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n    ///     let _ = (\n    ///         parts.path(),\n    ///         parts.service(),\n    ///         parts.method(),\n    ///         parts.metadata(),\n    ///         parts.trailers(),\n    ///         parts.compress(),\n    ///         parts.compress_is_set(),\n    ///         parts.encoding(),"
        ),
        "ServiceExt::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        intercept.contains(
            "wrapped.on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n    ///     let _ = (\n    ///         parts.path(),\n    ///         parts.service(),\n    ///         parts.method(),\n    ///         parts.metadata(),\n    ///         parts.trailers(),\n    ///         parts.compress(),\n    ///         parts.compress_is_set(),\n    ///         parts.encoding(),"
        ),
        "Intercepted::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        intercept.contains("wrapped.on_response(|parts: &mut pbrs_grpc::ResponseParts| {"),
        "Intercepted::on_response rustdoc example must attach a closure"
    );
    assert!(
        intercept.contains("wrapped.intercept(|rpc: &mut pbrs_grpc::Rpc| {"),
        "Intercepted::intercept rustdoc example must attach a closure"
    );
    assert!(
        intercept.contains(
            "wrapped.intercept(|rpc: &mut pbrs_grpc::Rpc| {\n    ///     let _ = (\n    ///         rpc.path(),\n    ///         rpc.service(),\n    ///         rpc.method(),\n    ///         rpc.metadata(),\n    ///         rpc.timeout(),\n    ///         rpc.peer_timeout(),\n    ///         rpc.rpc_timeout(),\n    ///         rpc.effective_timeout(),\n    ///         rpc.deadline(),\n    ///         rpc.accepts_gzip(),\n    ///         rpc.encoding(),\n    ///         rpc.compresses_outbound(),\n    ///         rpc.gzip_level(),\n    ///         rpc.accepts_compressed(),\n    ///         rpc.concurrent_rpc_limit(),\n    ///         rpc.send_buffer_size(),\n    ///         rpc.limits(),\n    ///         rpc.local_addr(),\n    ///         rpc.remote_addr(),\n    ///         rpc.peer_identity(),\n    ///         rpc.peer_cred(),\n    ///         rpc.authority(),\n    ///         rpc.scheme(),\n    ///         rpc.extensions(),"
        ),
        "Intercepted::intercept rustdoc example must read Incoming-stamped peer facts"
    );
    assert!(
        intercept.contains("does not cover other mounts."),
        "ServiceExt::on_response must Distinct a per-service hook from other mounts"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Interceptor`]: that is the inbound hook; this wrapper runs it before the handler."
        ),
        "Intercepted rustdoc must Distinct Interceptor inbound hook from the wrapper that runs it"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ClientInterceptor`]: that is the outbound hook; this wrapper runs an inbound [`Interceptor`] before the handler."
        ),
        "Intercepted rustdoc must Distinct ClientInterceptor outbound hook from the inbound wrapper"
    );
    assert!(
        intercept.contains(
            "Distinct from [`ResponseInterceptor`]: that is the after-Ok hook; this wrapper runs before the handler and may hold that hook for after Ok."
        ),
        "Intercepted rustdoc must Distinct ResponseInterceptor after-Ok hook from the inbound wrapper"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Channel::intercept`]: that runs on the outbound call before the stream opens; this Intercepted intercept stacks another inbound hook before the handler."
        ),
        "Intercepted::intercept rustdoc must Distinct Channel outbound-before-stream from stacking inbound hooks"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this Intercepted intercept stacks another inbound hook before the handler."
        ),
        "Intercepted::intercept rustdoc must Distinct on_response after-Ok from stacking inbound hooks"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Server::intercept`]: that runs on the inbound RPC before the Server's Service; this Intercepted intercept stacks another inbound hook before one wrapped service."
        ),
        "Intercepted::intercept rustdoc must Distinct Server Service coverage from stacking inbound hooks on one wrapped service"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Router::intercept`]: that runs on the inbound RPC before every mounted service on that Router; this Intercepted intercept stacks another inbound hook before one wrapped service."
        ),
        "Intercepted::intercept rustdoc must Distinct Router mounted-service coverage from stacking inbound hooks on one wrapped service"
    );
    assert_eq!(
        intercept
            .matches("Same kernel-stamped [`crate::ResponseParts`] overlays as [`crate::Server::on_response`]:")
            .count(),
        2,
        "Intercepted::on_response and ServiceExt::on_response must name the same overlays as Server::on_response"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after this Intercepted on_response, so a later interceptor can fill compress only when unset."
        ),
        "Intercepted::on_response rustdoc must name compress_is_set occupancy next to overlay inventory"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay after this Intercepted on_response."
        ),
        "Intercepted::on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this Intercepted on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct handler Err after the handler ran from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct Interceptor Err without reading the body from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct method-level Interceptor Err without reading the body from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct Server intercept Err without reading the body from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct Router intercept Err without reading the body from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct ServiceExt intercept Err without reading the body from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct Channel on_response Err Call fail after receive from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Intercepted on_response Err is trailers-only after handler Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct StreamSender fail after any messages already sent from this Intercepted on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this Intercepted on_response runs after the handler returns Ok."
        ),
        "Intercepted::on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Server::on_response`]: that runs after the handler returns Ok on the Server's Service; this Intercepted on_response runs after the handler returns Ok on one wrapped service."
        ),
        "Intercepted::on_response rustdoc must Distinct Server Service coverage from after-Ok on one wrapped service"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Router::on_response`]: that runs after the handler returns Ok on every mounted service on that Router; this Intercepted on_response runs after the handler returns Ok on one wrapped service."
        ),
        "Intercepted::on_response rustdoc must Distinct Router mounted-service coverage from after-Ok on one wrapped service"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after this ServiceExt on_response, so a later interceptor can fill compress only when unset."
        ),
        "ServiceExt::on_response rustdoc must name compress_is_set occupancy next to overlay inventory"
    );
    assert!(
        intercept.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay after this ServiceExt on_response."
        ),
        "ServiceExt::on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        intercept.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this ServiceExt on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        intercept.contains(
            "Distinct from a handler Err: that is after the handler ran; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct handler Err after the handler ran from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct ServiceExt intercept Err without reading the body from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct Interceptor Err without reading the body from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct method-level Interceptor Err without reading the body from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct Server intercept Err without reading the body from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct Router intercept Err without reading the body from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct Channel on_response Err Call fail after receive from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct Channel intercept Err local reject never opens a stream from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct method-level intercept Err local reject never opens a stream from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this ServiceExt on_response Err is trailers-only after handler Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct StreamSender fail after any messages already sent from this ServiceExt on_response Err trailers-only after handler Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this ServiceExt on_response runs after the handler returns Ok."
        ),
        "ServiceExt::on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Server::on_response`]: that runs after the handler returns Ok on the Server's Service; this ServiceExt on_response wraps one service with an after-Ok hook."
        ),
        "ServiceExt::on_response rustdoc must Distinct Server Service coverage from wrapping one service after-Ok"
    );
    assert!(
        intercept.contains(
            "Distinct from [`crate::Router::on_response`]: that runs after the handler returns Ok on every mounted service on that Router; this ServiceExt on_response wraps one service with an after-Ok hook."
        ),
        "ServiceExt::on_response rustdoc must Distinct Router mounted-service coverage from wrapping one service after-Ok"
    );
    assert!(
        src.contains("starts empty; this is how a client inserts typed context after the"),
        "Channel::on_response must Distinct receive-side insert from the peer"
    );
    assert!(
        src.contains("A non-OK peer status skips"),
        "Channel::on_response must name skip on non-OK peer status"
    );
    assert!(
        src.contains("the peer already sent OK"),
        "Channel::on_response must name Err after the peer sent OK"
    );
    assert!(
        src.contains("[`crate::ResponseParts::path`] is kernel-stamped."),
        "Channel::on_response must name kernel-stamped path"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::path`]: that is a client interceptor before send."
        ),
        "Channel::on_response must Distinct Outgoing::path before send"
    );
    assert!(
        src.contains(
            "[`crate::Response::gzip_level`] on a received reply is not the peer's deflate effort."
        ),
        "Channel::on_response must name received gzip_level is not peer effort"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Response::encoding`]: that is the received `grpc-encoding` token."
        ),
        "Channel::on_response must Distinct gzip_level from encoding"
    );
    assert!(
        src.contains(
            "[`crate::Response::compresses_outbound`] on a received reply is `false` (the overlay is not on the wire)."
        ),
        "Channel::on_response must name received compresses_outbound is false"
    );
    assert!(
        src.contains(
            "[`crate::Response::accepts_gzip`] on a received reply is `false` (the advertisement is not on the reply wire)."
        ),
        "Channel::on_response must name received accepts_gzip is false"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Response::encoding`]: that is received `grpc-encoding`, not `grpc-accept-encoding`."
        ),
        "Channel::on_response must Distinct accepts_gzip from encoding"
    );
    assert!(
        src.contains(
            "[`crate::Response::deadline`] on a received reply is `None` (the peer deadline is not on the wire)."
        ),
        "Channel::on_response must name received deadline is None"
    );
    assert!(
        src.contains(
            "[`crate::Response::timeout`] on a received reply is `None` (the peer timeout is not on the reply wire)."
        ),
        "Channel::on_response must name received timeout is None"
    );
    assert!(
        src.contains(
            "[`crate::Response::limits`] on a received reply is `None` (the peer encode cap is not on the wire)."
        ),
        "Channel::on_response must name received limits is None"
    );
    assert!(
        src.contains(
            "[`crate::Response::peer_timeout`] on a received reply is `None` (the client's `grpc-timeout` is not on the reply wire)."
        ),
        "Channel::on_response must name received peer_timeout is None"
    );
    assert!(
        src.contains(
            "[`crate::Response::rpc_timeout`] on a received reply is `None` (the server overlay is not on the reply wire)."
        ),
        "Channel::on_response must name received rpc_timeout is None"
    );
    assert!(
        src.contains(
            "[`crate::Response::accepts_compressed`] on a received reply is `false` (this overlay is not a received-reply field)."
        ),
        "Channel::on_response must name received accepts_compressed is false"
    );
    assert!(
        src.contains(
            "[`crate::Response::send_buffer_size`] on a received reply is `None` (the peer send buffer is not on the reply wire)."
        ),
        "Channel::on_response must name received send_buffer_size is None"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after this Channel on_response, so a later interceptor can fill compress only when unset."
        ),
        "Channel::on_response rustdoc must name compress_is_set occupancy next to received send_buffer"
    );
    assert!(
        src.contains(
            "[`crate::ResponseParts::clear_compress`] drops a compress choice after this Channel on_response; a received reply has no server gzip overlay to restore."
        ),
        "Channel::on_response rustdoc must name clear_compress receive-path next to compress occupancy"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this Channel on_response Err; a local reject fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct handler Err after the handler ran from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Interceptor Err without reading the body from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct method-level Interceptor Err without reading the body from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a Channel intercept Err: that is a local reject never opens a stream; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Channel intercept Err local reject never opens a stream from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a ClientInterceptor Err: that is a local reject never opens a stream; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct ClientInterceptor Err local reject never opens a stream from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a method-level intercept Err: that is a local reject never opens a stream; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct method-level intercept Err local reject never opens a stream from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Server intercept Err without reading the body from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Router intercept Err without reading the body from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct ServiceExt intercept Err without reading the body from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Channel on_response Err fails the Call after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct StreamSender fail after any messages already sent from this Channel on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the outbound call before the stream opens; this Channel on_response runs after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct intercept outbound-before-stream from after-receive"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Server::on_response`]: that runs after the handler returns Ok; this Channel on_response runs after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Server after-Ok from this Channel on_response after-receive"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Router::on_response`]: that runs after the handler returns Ok; this Channel on_response runs after a successful receive."
        ),
        "Channel::on_response rustdoc must Distinct Router after-Ok from this Channel on_response after-receive"
    );
    assert!(
        src.contains("channel.on_response(|parts: &mut pbrs_grpc::ResponseParts| {"),
        "Channel::on_response rustdoc example must attach a closure"
    );
    assert!(
        src.contains(
            "channel.on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n    ///     let _ = (\n    ///         parts.path(),\n    ///         parts.service(),\n    ///         parts.method(),\n    ///         parts.metadata(),\n    ///         parts.trailers(),\n    ///         parts.compress(),\n    ///         parts.compress_is_set(),\n    ///         parts.encoding(),"
        ),
        "Channel::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        src.contains("///         parts.path(),"),
        "Channel::on_response rustdoc example must read path"
    );
    assert!(
        src.contains("///         parts.service(),"),
        "Channel::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        src.contains("///         parts.method(),"),
        "Channel::on_response rustdoc example must dump method Distinct from path"
    );
    assert!(
        src.contains("///         parts.metadata(),"),
        "Channel::on_response rustdoc example must dump metadata Distinct from metadata_mut"
    );
    assert!(
        src.contains("///         parts.trailers(),"),
        "Channel::on_response rustdoc example must dump trailers Distinct from trailers_mut"
    );
    assert!(
        src.contains("///         parts.compress(),"),
        "Channel::on_response rustdoc example must dump compress intent Distinct from gzip_level"
    );
    assert!(
        src.contains("///         parts.compress_is_set(),"),
        "Channel::on_response rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        src.contains("///         parts.encoding(),"),
        "Channel::on_response rustdoc example must dump received encoding Distinct from compress"
    );
    assert!(
        src.contains("///         parts.send_buffer_size(),"),
        "Channel::on_response rustdoc example must read send_buffer_size"
    );
    assert!(
        src.contains(
            "    ///         parts.send_buffer_size(),\n    ///         parts.extensions(),"
        ),
        "Channel::on_response rustdoc example must dump extensions Distinct from extensions_mut"
    );
    assert!(
        src.contains(
            "Applies to client-streaming and bidi request streams opened from this\n    /// clone."
        ),
        "Channel::stream_buffer must name the streaming shapes it queues"
    );
    assert!(
        src.contains("Configured outbound streaming queue depth. See [`Self::stream_buffer`]."),
        "Channel::stream_buffer_size must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::stream_buffer`], which sets it."),
        "Channel::stream_buffer_size must Distinct from the setter"
    );
    assert!(
        src.contains("Write-time HTTP/2 send buffer threshold for outbound DATA on this clone."),
        "Channel::max_send_buffer_size must name the write-time DATA overlay"
    );
    assert!(
        src.contains("redialed; the handshake h2 send buffer stays the dial-time value."),
        "Channel::max_send_buffer_size must Distinct handshake h2 buffer from the overlay"
    );
    assert!(
        src.contains(
            "Configured write-time HTTP/2 send buffer. See [`Self::max_send_buffer_size`]."
        ),
        "Channel::send_buffer_size must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::max_send_buffer_size`], which sets it."),
        "Channel::send_buffer_size must Distinct from the setter"
    );
    assert!(
        src.contains("Configured message caps. See [`Self::message_limits`]."),
        "Channel::limits must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::message_limits`], which sets them."),
        "Channel::limits must Distinct from the setter"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::stream_buffer_size`]: that is queue depth, not uncompressed protobuf bytes."
        ),
        "Channel::limits must Distinct queue depth from message caps"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::send_buffer_size`]: that is the HTTP/2 send buffer, not these caps."
        ),
        "Channel::limits must Distinct the send buffer from message caps"
    );
    assert!(
        src.contains("Same overlay as [`crate::Outgoing::limits`]."),
        "Channel::limits must name the interceptor overlay"
    );
    assert!(
        src.contains(
            "Further RPCs are refused with [`Code::ResourceExhausted`] before the\n    /// stream opens. Distinct from HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`"
        ),
        "Channel::max_concurrent_rpcs must refuse extras before the stream opens"
    );
    assert!(
        src.contains("Clones share the budget. Calling this twice replaces the cap."),
        "Channel::max_concurrent_rpcs must name that clones share the budget"
    );
    assert!(
        src.contains(
            "A server-streaming or bidi slot is held until the received\n    /// [`Streaming`] is dropped."
        ),
        "Channel::max_concurrent_rpcs must hold a stream slot until drop"
    );
    assert!(
        src.contains(
            "Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`Self::from_io`]. Inserting `user-agent` into request metadata cannot\n    /// replace this value on those transports."
        ),
        "Channel::user_agent must name every transport and that metadata cannot override"
    );
    assert!(
        src.contains("[`crate::Outgoing::set_user_agent`], which prefixes this RPC."),
        "Channel::user_agent must Distinct Outgoing::set_user_agent as the per-RPC prefix"
    );
    assert!(
        src.contains("[`crate::Request::set_user_agent`] is the same prefix at the call site."),
        "Channel::user_agent must Distinct Request::set_user_agent as the call-site prefix"
    );
    assert!(
        src.contains("user-agent prefix ([`crate::Outgoing::set_user_agent`]), a"),
        "Channel::intercept rustdoc must name Outgoing::set_user_agent"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::user_agent_is_set`] is occupancy after this Channel intercept, so a later interceptor can prefix only when unset."
        ),
        "Channel::intercept rustdoc must name Outgoing::user_agent_is_set occupancy next to set_user_agent"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::wait_for_ready_is_set`] is occupancy after this Channel intercept, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "Channel::intercept rustdoc must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::compress_is_set`] is occupancy after this Channel intercept, so a later interceptor can fill compress only when unset."
        ),
        "Channel::intercept rustdoc must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        src.contains(
            "`gzip_level`, `accepts_compressed`, `concurrent_rpc_limit`, `stream_buffer_size`, `send_buffer_size`, `limits`) are visible even after `clear_*`"
        ),
        "Channel::intercept rustdoc must name the full channel overlay set next to gzip_level"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_user_agent`] restores the channel user-agent after this Channel intercept prefix."
        ),
        "Channel::intercept rustdoc must name clear_user_agent opt-out"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_wait_for_ready`] restores the channel wait-for-ready overlay after this Channel intercept choice."
        ),
        "Channel::intercept rustdoc must name clear_wait_for_ready opt-out next to clear_user_agent"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the channel timeout after this Channel intercept choice."
        ),
        "Channel::intercept rustdoc must name clear_timeout opt-out next to clear_wait_for_ready"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::clear_compress`] then [`crate::Outgoing::set_compress`] from [`Self::compresses_outbound`] reapplies channel gzip after this Channel intercept choice."
        ),
        "Channel::intercept rustdoc must name clear_compress reapply next to clear_timeout"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this Channel intercept Err; a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        src.contains(
            "Distinct from a handler Err: that is after the handler ran; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct handler Err after the handler ran from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a Channel on_response Err: that fails the Call after a successful receive; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Channel on_response Err Call fail after receive from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a ResponseInterceptor Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct ResponseInterceptor Err trailers-only after handler Ok or Call fail after receive from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a method-level on_response Err: that is trailers-only after handler Ok, or fails the Call after a successful receive; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct method-level on_response Err trailers-only after handler Ok or Call fail after receive from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a Server on_response Err: that is trailers-only after handler Ok; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Server on_response Err trailers-only after handler Ok from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a Router on_response Err: that is trailers-only after handler Ok; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Router on_response Err trailers-only after handler Ok from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from an Intercepted on_response Err: that is trailers-only after handler Ok; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Intercepted on_response Err trailers-only after handler Ok from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt on_response Err: that is trailers-only after handler Ok; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct ServiceExt on_response Err trailers-only after handler Ok from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a Server intercept Err: that is trailers without reading the body; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Server intercept Err without reading the body from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a Router intercept Err: that is trailers without reading the body; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Router intercept Err without reading the body from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a ServiceExt intercept Err: that is trailers without reading the body; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct ServiceExt intercept Err without reading the body from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from an Interceptor Err: that is trailers without reading the body; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct Interceptor Err without reading the body from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a method-level Interceptor Err: that is trailers without reading the body; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct method-level Interceptor Err without reading the body from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a StreamSender fail: that is trailers after any messages already sent; this Channel intercept Err is a local reject never opens a stream."
        ),
        "Channel::intercept rustdoc must Distinct StreamSender fail after any messages already sent from this Channel intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this interceptor already ran, so a local Err never consumes that budget."
        ),
        "Channel::intercept rustdoc must Distinct max_concurrent_rpcs slot grab after intercept"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Server::intercept`]: that runs on the inbound RPC before the handler; this runs on the outbound call before the stream opens."
        ),
        "Channel::intercept rustdoc must Distinct Server inbound-before-handler from outbound-before-stream"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Server::intercept`]: that runs on the inbound RPC before the handler; this Channel intercept runs on the outbound call before the stream opens."
        ),
        "Channel::intercept rustdoc must Distinct Server inbound-before-handler from this Channel intercept outbound-before-stream"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Router::intercept`]: that runs on the inbound RPC before the handler; this Channel intercept runs on the outbound call before the stream opens."
        ),
        "Channel::intercept rustdoc must Distinct Router inbound-before-handler from this Channel intercept outbound-before-stream"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after a successful receive; this runs on the outbound call before the stream opens."
        ),
        "Channel::intercept rustdoc must Distinct on_response after-receive from outbound-before-stream"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after a successful receive; this Channel intercept runs on the outbound call before the stream opens."
        ),
        "Channel::intercept rustdoc must Distinct on_response after-receive from this Channel intercept outbound-before-stream"
    );
    assert!(
        src.contains("[`crate::Outgoing::accepts_compressed`] is the inbound gzip overlay"),
        "Channel::intercept rustdoc must name Outgoing::accepts_compressed"
    );
    assert!(
        src.contains("[`crate::Outgoing::limits`] is the channel message-cap overlay."),
        "Channel::intercept rustdoc must name Outgoing::limits as the message-cap overlay"
    );
    assert!(
        src.contains("[`crate::Outgoing::concurrent_rpc_limit`] is the channel RPC cap overlay"),
        "Channel::intercept rustdoc must name Outgoing::concurrent_rpc_limit"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::waits_for_ready`]: that waits for a connection; this refuses extras."
        ),
        "Channel::intercept rustdoc must Distinct concurrent_rpc_limit from waits_for_ready"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::stream_buffer_size`] is the outbound streaming queue overlay"
        ),
        "Channel::intercept rustdoc must name Outgoing::stream_buffer_size"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::limits`]: that is message size, not queue depth."
        ),
        "Channel::intercept rustdoc must Distinct stream_buffer_size from limits"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::send_buffer_size`] is the outbound HTTP/2 send buffer overlay"
        ),
        "Channel::intercept rustdoc must name Outgoing::send_buffer_size"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Outgoing::stream_buffer_size`]: that is queue depth, not this send buffer."
        ),
        "Channel::intercept rustdoc must Distinct send_buffer_size from stream_buffer_size"
    );
    assert!(
        src.contains("[`crate::Outgoing::connected`] is the live-socket snapshot"),
        "Channel::intercept rustdoc must name Outgoing::connected"
    );
    assert!(
        src.contains("Distinct from wait-for-ready: a lazy first RPC sees `false` even when"),
        "Channel::intercept rustdoc must Distinct connected from wait-for-ready"
    );
    assert!(
        src.contains("channel.intercept(|call: &mut pbrs_grpc::Outgoing<'_>| {"),
        "Channel::intercept rustdoc example must attach a closure"
    );
    assert!(
        src.contains(
            "channel.intercept(|call: &mut pbrs_grpc::Outgoing<'_>| {\n    ///     let _ = (\n    ///         call.path(),\n    ///         call.service(),\n    ///         call.method(),\n    ///         call.authority(),\n    ///         call.scheme(),\n    ///         call.user_agent(),\n    ///         call.user_agent_is_set(),\n    ///         call.metadata(),\n    ///         call.timeout(),\n    ///         call.deadline(),\n    ///         call.rpc_timeout(),\n    ///         call.wait_for_ready(),\n    ///         call.wait_for_ready_is_set(),\n    ///         call.waits_for_ready(),\n    ///         call.compress(),\n    ///         call.compress_is_set(),"
        ),
        "Channel::intercept rustdoc example must read user_agent Distinct from inserting user-agent into metadata"
    );
    let hello = include_str!("../src/hello.rs");
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterClient::new(channel).intercept(|call: &mut pbrs_grpc::Outgoing<'_>| {"
        ),
        "hello module rustdoc must attach a compiling GreeterClient::intercept example"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterClient::new(channel).intercept(|call: &mut pbrs_grpc::Outgoing<'_>| {\n//!     let _ = (\n//!         call.path(),\n//!         call.service(),\n//!         call.method(),\n//!         call.authority(),\n//!         call.scheme(),\n//!         call.user_agent(),\n//!         call.user_agent_is_set(),\n//!         call.metadata(),\n//!         call.timeout(),\n//!         call.deadline(),\n//!         call.rpc_timeout(),\n//!         call.wait_for_ready(),\n//!         call.wait_for_ready_is_set(),\n//!         call.waits_for_ready(),\n//!         call.compress(),\n//!         call.compress_is_set(),"
        ),
        "hello GreeterClient::intercept rustdoc example must read user_agent Distinct from inserting user-agent into metadata"
    );
    assert!(
        hello.contains("//!         call.user_agent_is_set(),"),
        "hello GreeterClient::intercept rustdoc example must dump user_agent_is_set Distinct from user_agent"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::user_agent_is_set`] is occupancy on this hello intercept path, so a later interceptor can prefix only when unset."
        ),
        "hello GreeterClient::intercept rustdoc must name Outgoing::user_agent_is_set occupancy next to the dump"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::wait_for_ready_is_set`] is occupancy on this hello intercept path, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "hello GreeterClient::intercept rustdoc must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::compress_is_set`] is occupancy on this hello intercept path, so a later interceptor can fill compress only when unset."
        ),
        "hello GreeterClient::intercept rustdoc must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::clear_user_agent`] restores the channel user-agent after a hello intercept prefix."
        ),
        "hello GreeterClient::intercept rustdoc must name clear_user_agent next to compress occupancy"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::clear_wait_for_ready`] restores the channel wait-for-ready overlay after a hello intercept choice."
        ),
        "hello GreeterClient::intercept rustdoc must name clear_wait_for_ready next to clear_user_agent"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::clear_compress`] then [`crate::Outgoing::set_compress`] from [`crate::Outgoing::compresses_outbound`] reapplies channel gzip after a hello intercept choice."
        ),
        "hello GreeterClient::intercept rustdoc must name clear_compress reapply next to clear_wait_for_ready"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::clear_timeout`] opts out of the channel timeout after a hello intercept choice."
        ),
        "hello GreeterClient::intercept rustdoc must name clear_timeout next to clear_compress"
    );
    assert!(
        hello.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this hello intercept path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "hello GreeterClient::intercept rustdoc must name Outgoing::connected live-socket snapshot next to clear_timeout"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello intercept Err; a local reject never opens a stream."
        ),
        "hello GreeterClient::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        hello.contains(
            "Distinct from a hello handler Err: that is after the handler ran; this hello intercept Err is a local reject never opens a stream."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct hello handler Err after the handler ran from this hello intercept Err local reject never opens a stream"
    );
    assert!(
        hello.contains(
            "Distinct from a hello client on_response Err: that fails the Call after a successful receive; this hello intercept Err is a local reject never opens a stream."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct hello client on_response Err Call fail after receive from this hello intercept Err local reject never opens a stream"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server intercept Err: that is trailers without reading the body; this hello intercept Err is a local reject never opens a stream."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct hello server intercept Err without reading the body from this hello intercept Err local reject never opens a stream"
    );
    assert!(
        hello.contains(
            "Distinct from a hello StreamSender fail: that is trailers after any messages already sent; this hello intercept Err is a local reject never opens a stream."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct hello StreamSender fail after any messages already sent from this hello intercept Err local reject never opens a stream"
    );
    assert!(
        hello.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; a hello intercept already ran, so a local Err never consumes that budget."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct max_concurrent_rpcs slot grab after intercept"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterServer::intercept`]: that runs on the inbound RPC before the handler; this hello intercept runs on the outbound call before the stream opens."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct GreeterServer inbound-before-handler from outbound-before-stream"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterClient::on_response`]: that runs after a successful receive; this hello intercept runs on the outbound call before the stream opens."
        ),
        "hello GreeterClient::intercept rustdoc must Distinct on_response after-receive from outbound-before-stream"
    );
    assert!(
        hello.contains("//!         call.connected(),\n//!         call.extensions(),"),
        "hello GreeterClient::intercept rustdoc example must read extensions Distinct from extensions_mut"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterClient::new(channel).on_response(|parts: &mut pbrs_grpc::ResponseParts| {"
        ),
        "hello module rustdoc must attach a compiling GreeterClient::on_response example"
    );
    assert!(
        hello.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after a hello client on_response, so a later interceptor can fill compress only when unset."
        ),
        "hello GreeterClient::on_response rustdoc must name compress_is_set occupancy next to Channel::on_response"
    );
    assert!(
        hello.contains(
            "[`crate::ResponseParts::clear_compress`] drops a compress choice after a hello client on_response; a received reply has no server gzip overlay to restore."
        ),
        "hello GreeterClient::on_response rustdoc must name clear_compress receive-path next to compress occupancy"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello client on_response Err; a local reject fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        hello.contains(
            "Distinct from a hello handler Err: that is after the handler ran; this hello client on_response Err fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct hello handler Err after the handler ran from this hello client on_response Err Call fail after receive"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server intercept Err: that is trailers without reading the body; this hello client on_response Err fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct hello server intercept Err without reading the body from this hello client on_response Err Call fail after receive"
    );
    assert!(
        hello.contains(
            "Distinct from a hello intercept Err: that is a local reject never opens a stream; this hello client on_response Err fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct hello intercept Err local reject never opens a stream from this hello client on_response Err Call fail after receive"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server on_response Err: that is trailers-only after handler Ok; this hello client on_response Err fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct hello server on_response Err trailers-only after handler Ok from this hello client on_response Err Call fail after receive"
    );
    assert!(
        hello.contains(
            "Distinct from a hello StreamSender fail: that is trailers after any messages already sent; this hello client on_response Err fails the Call after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct hello StreamSender fail after any messages already sent from this hello client on_response Err Call fail after receive"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterClient::intercept`]: that runs on the outbound call before the stream opens; this hello client on_response runs after a successful receive."
        ),
        "hello GreeterClient::on_response rustdoc must Distinct intercept outbound-before-stream from after-receive"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterClient::new(channel).on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n//!     let _ = (\n//!         parts.path(),\n//!         parts.service(),\n//!         parts.method(),\n//!         parts.metadata(),\n//!         parts.trailers(),\n//!         parts.compress(),\n//!         parts.compress_is_set(),\n//!         parts.encoding(),"
        ),
        "hello GreeterClient::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        hello.contains("//!         parts.compress_is_set(),"),
        "hello on_response rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        hello.contains("//!         parts.send_buffer_size(),\n//!         parts.extensions(),"),
        "hello on_response rustdoc example must dump extensions Distinct from extensions_mut"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterServer::new(Svc).intercept(|rpc: &mut pbrs_grpc::Rpc| {"
        ),
        "hello module rustdoc must attach a compiling GreeterServer::intercept example"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello server intercept Err; those trailers reach the client without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        hello.contains(
            "Distinct from a hello handler Err: that is after the handler ran; this hello server intercept Err is trailers without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct hello handler Err after the handler ran from this hello server intercept Err without reading the body"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server on_response Err: that is trailers-only after handler Ok; this hello server intercept Err is trailers without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct hello server on_response Err trailers-only after handler Ok from this hello server intercept Err without reading the body"
    );
    assert!(
        hello.contains(
            "Distinct from a hello intercept Err: that is a local reject never opens a stream; this hello server intercept Err is trailers without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct hello intercept Err local reject never opens a stream from this hello server intercept Err without reading the body"
    );
    assert!(
        hello.contains(
            "Distinct from a hello client on_response Err: that fails the Call after a successful receive; this hello server intercept Err is trailers without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct hello client on_response Err Call fail after receive from this hello server intercept Err without reading the body"
    );
    assert!(
        hello.contains(
            "Distinct from a hello StreamSender fail: that is trailers after any messages already sent; this hello server intercept Err is trailers without reading the body."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct hello StreamSender fail after any messages already sent from this hello server intercept Err without reading the body"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterClient::intercept`]: that runs on the outbound call before the stream opens; this hello server intercept runs on the inbound RPC before the handler."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct GreeterClient outbound-before-stream from inbound-before-handler"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterServer::on_response`]: that runs after the handler returns Ok; this hello server intercept runs on the inbound RPC before the handler."
        ),
        "hello GreeterServer::intercept rustdoc must Distinct on_response after-Ok from inbound-before-handler"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterServer::new(Svc).intercept(|rpc: &mut pbrs_grpc::Rpc| {\n//!     let _ = (\n//!         rpc.path(),\n//!         rpc.service(),\n//!         rpc.method(),\n//!         rpc.metadata(),\n//!         rpc.timeout(),\n//!         rpc.peer_timeout(),\n//!         rpc.rpc_timeout(),\n//!         rpc.effective_timeout(),\n//!         rpc.deadline(),\n//!         rpc.accepts_gzip(),\n//!         rpc.encoding(),\n//!         rpc.compresses_outbound(),\n//!         rpc.gzip_level(),\n//!         rpc.accepts_compressed(),\n//!         rpc.concurrent_rpc_limit(),\n//!         rpc.send_buffer_size(),\n//!         rpc.limits(),\n//!         rpc.local_addr(),\n//!         rpc.remote_addr(),\n//!         rpc.peer_identity(),\n//!         rpc.peer_cred(),\n//!         rpc.authority(),\n//!         rpc.scheme(),\n//!         rpc.extensions(),"
        ),
        "hello GreeterServer::intercept rustdoc example must read Incoming-stamped peer facts"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterServer::new(Svc).on_response(|parts: &mut pbrs_grpc::ResponseParts| {"
        ),
        "hello module rustdoc must attach a compiling GreeterServer::on_response example"
    );
    assert!(
        hello.contains(
            "[`crate::ResponseParts::compress_is_set`] is occupancy after a hello server on_response, so a later interceptor can fill compress only when unset."
        ),
        "hello GreeterServer::on_response rustdoc must name compress_is_set occupancy next to Server::on_response"
    );
    assert!(
        hello.contains(
            "[`crate::ResponseParts::clear_compress`] restores the server gzip overlay after a hello server on_response."
        ),
        "hello GreeterServer::on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "hello GreeterServer::on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        hello.contains(
            "Distinct from a hello handler Err: that is after the handler ran; this hello server on_response Err is trailers-only after handler Ok."
        ),
        "hello GreeterServer::on_response rustdoc must Distinct hello handler Err after the handler ran from this hello server on_response Err trailers-only after handler Ok"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server intercept Err: that is trailers without reading the body; this hello server on_response Err is trailers-only after handler Ok."
        ),
        "hello GreeterServer::on_response rustdoc must Distinct hello server intercept Err without reading the body from this hello server on_response Err trailers-only after handler Ok"
    );
    assert!(
        hello.contains(
            "Distinct from a hello client on_response Err: that fails the Call after a successful receive; this hello server on_response Err is trailers-only after handler Ok."
        ),
        "hello GreeterServer::on_response rustdoc must Distinct hello client on_response Err Call fail after receive from this hello server on_response Err trailers-only after handler Ok"
    );
    assert!(
        hello.contains(
            "Distinct from a hello StreamSender fail: that is trailers after any messages already sent; this hello server on_response Err is trailers-only after handler Ok."
        ),
        "hello GreeterServer::on_response rustdoc must Distinct hello StreamSender fail after any messages already sent from this hello server on_response Err trailers-only after handler Ok"
    );
    assert!(
        hello.contains(
            "Distinct from [`GreeterServer::intercept`]: that runs on the inbound RPC before the handler; this hello server on_response runs after the handler returns Ok."
        ),
        "hello GreeterServer::on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello handler Err; those trailers reach the client."
        ),
        "hello Greeter handler rustdoc must name from_error_details typed bag next to handler Err"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server intercept Err: that is trailers without reading the body; this hello handler Err is after the handler ran."
        ),
        "hello Greeter rustdoc must Distinct server intercept Err without reading the body from this hello handler Err after the handler ran"
    );
    assert!(
        hello.contains(
            "Distinct from a hello intercept Err: that is a local reject never opens a stream; this hello handler Err is after the handler ran."
        ),
        "hello Greeter rustdoc must Distinct intercept Err local reject never opens a stream from this hello handler Err after the handler ran"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server on_response Err: that is trailers-only after handler Ok; this hello handler Err is after the handler ran."
        ),
        "hello Greeter rustdoc must Distinct server on_response Err trailers-only after handler Ok from this hello handler Err after the handler ran"
    );
    assert!(
        hello.contains(
            "Distinct from a hello client on_response Err: that fails the Call after a successful receive; this hello handler Err is after the handler ran."
        ),
        "hello Greeter rustdoc must Distinct client on_response Err Call fail after receive from this hello handler Err after the handler ran"
    );
    assert!(
        hello.contains(
            "Distinct from a hello StreamSender fail: that is trailers after any messages already sent; this hello handler Err is after the handler ran."
        ),
        "hello Greeter rustdoc must Distinct StreamSender fail after any messages already sent from this hello handler Err after the handler ran"
    );
    assert!(
        hello.contains(
            "[`crate::Status::from_error_details`] is the typed bag after a hello StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "hello Greeter StreamSender rustdoc must name from_error_details typed bag next to StreamSender fail"
    );
    assert!(
        hello.contains(
            "Distinct from a hello handler Err: that is after the handler ran; this hello StreamSender fail is trailers after any messages already sent."
        ),
        "hello Greeter rustdoc must Distinct handler Err after the handler ran from this hello StreamSender fail after any messages already sent"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server intercept Err: that is trailers without reading the body; this hello StreamSender fail is trailers after any messages already sent."
        ),
        "hello Greeter rustdoc must Distinct hello server intercept Err without reading the body from this hello StreamSender fail after any messages already sent"
    );
    assert!(
        hello.contains(
            "Distinct from a hello server on_response Err: that is trailers-only after handler Ok; this hello StreamSender fail is trailers after any messages already sent."
        ),
        "hello Greeter rustdoc must Distinct hello server on_response Err trailers-only after handler Ok from this hello StreamSender fail after any messages already sent"
    );
    assert!(
        hello.contains(
            "Distinct from a hello intercept Err: that is a local reject never opens a stream; this hello StreamSender fail is trailers after any messages already sent."
        ),
        "hello Greeter rustdoc must Distinct hello intercept Err local reject never opens a stream from this hello StreamSender fail after any messages already sent"
    );
    assert!(
        hello.contains(
            "Distinct from a hello client on_response Err: that fails the Call after a successful receive; this hello StreamSender fail is trailers after any messages already sent."
        ),
        "hello Greeter rustdoc must Distinct hello client on_response Err Call fail after receive from this hello StreamSender fail after any messages already sent"
    );
    assert!(
        hello.contains(
            "pbrs_grpc::hello::GreeterServer::new(Svc).on_response(|parts: &mut pbrs_grpc::ResponseParts| {\n//!     let _ = (\n//!         parts.path(),\n//!         parts.service(),\n//!         parts.method(),\n//!         parts.metadata(),\n//!         parts.trailers(),\n//!         parts.compress(),\n//!         parts.compress_is_set(),\n//!         parts.encoding(),"
        ),
        "hello GreeterServer::on_response rustdoc example must dump service Distinct from path"
    );
    assert!(
        src.contains("///         call.rpc_timeout(),"),
        "Channel::intercept rustdoc example must read rpc_timeout"
    );
    assert!(
        src.contains("///         call.user_agent_is_set(),"),
        "Channel::intercept rustdoc example must dump user_agent_is_set Distinct from user_agent"
    );
    assert!(
        src.contains("///         call.wait_for_ready_is_set(),"),
        "Channel::intercept rustdoc example must dump wait_for_ready_is_set Distinct from wait_for_ready"
    );
    assert!(
        src.contains("///         call.compress_is_set(),"),
        "Channel::intercept rustdoc example must dump compress_is_set Distinct from compress"
    );
    assert!(
        src.contains("///         call.send_buffer_size(),"),
        "Channel::intercept rustdoc example must read send_buffer_size"
    );
    assert!(
        src.contains("///         call.limits(),"),
        "Channel::intercept rustdoc example must read limits"
    );
    assert!(
        src.contains("///         call.connected(),"),
        "Channel::intercept rustdoc example must read connected"
    );
    assert!(
        src.contains("    ///         call.connected(),\n    ///         call.extensions(),"),
        "Channel::intercept rustdoc example must read extensions Distinct from extensions_mut"
    );
    assert!(
        src.contains(
            "Applies to every call shape, including over TLS, mTLS,\n    /// Unix, and [`Self::from_io`]."
        ),
        "Channel::send_compressed must name every transport"
    );
    assert!(
        src.contains(
            "Passing `false` omits gzip from `grpc-accept-encoding` and refuses a\n    /// `grpc-encoding: gzip` reply as [`Code::Unimplemented`]."
        ),
        "Channel::accept_compressed must omit gzip from accept-encoding"
    );
    assert!(
        src.contains("Distinct from [`Self::accept_compressed`], which sets it."),
        "Channel::accepts_compressed must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::wait_for_ready`], which sets it."),
        "Channel::waits_for_ready must Distinct the setter"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::connected`]: that is a live snapshot, not this overlay."
        ),
        "Channel::waits_for_ready must Distinct the live-socket snapshot"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::connected`]: that is a live snapshot; this fill still queues when a slot is empty."
        ),
        "Channel::wait_for_ready must Distinct the live-socket snapshot"
    );
    assert!(
        src.contains("Distinct from [`Self::send_compressed`], which sets it."),
        "Channel::compresses_outbound must Distinct the setter"
    );
    assert!(
        src.contains("call shape. Distinct from [`Self::timeout`], which sets it."),
        "Channel::rpc_timeout must Distinct the setter"
    );
    assert!(
        src.contains("Interceptors run after this fill and can still set\n    /// or clear it."),
        "Channel::wait_for_ready must name interceptor set/clear"
    );
    assert!(
        src.contains(
            "(`cancel_after_begin`) is [`crate::Code::Cancelled`], not OK from a\n    /// half-close: hold the [`StreamSender`] until the [`Call`] settles,\n    /// including over TLS, mTLS, Unix, and [`Self::from_io`]."
        ),
        "Channel::client_streaming must name cancel_after_begin on every transport"
    );
    let status = include_str!("../src/status.rs");
    assert!(
        status.contains(
            "Raw bytes still round-trip on every call shape, including over TLS,\n    /// mTLS, Unix, and [`crate::Channel::from_io`]. They do not appear as a\n    /// `grpc-status-details-bin` metadata key."
        ),
        "Status::details must name raw bytes on every transport"
    );
    assert!(
        status.contains(
            "A non-empty blob is `grpc-status-details-bin` on the wire for every\n    /// call shape, including over TLS, mTLS, Unix, and [`crate::Channel::from_io`].\n    /// [`Self::details`] returns those bytes; they do not appear as a metadata\n    /// key."
        ),
        "Status::set_details must name the wire trailer on every transport"
    );
    assert!(
        status.contains("A peer trailer has no cause. Distinct"),
        "Status rustdoc must Distinct Error::source from a peer trailer"
    );
    assert!(
        status.contains("no cause: [`std::error::Error::source`] is `None`"),
        "Status::with_cause rustdoc must name Error::source is None on a peer trailer"
    );
}
