fn channel_config_documents_with_default_service_config() {
    let src = include_str!("../src/config.rs");
    assert!(
        src.contains(
            "There is no grpc-go `WithDefaultServiceConfig`: that is JSON used when\n/// the name resolver does not provide a service config, or when\n/// `WithDisableServiceConfig` ignores the resolver. This config is typed\n/// `Copy` fields, not JSON; there is no resolver. Distinct from grpc-go\n/// `WithDisableRetry` (`retryPolicy` only). Distinct from [`Self::timeout`]\n/// (kernel overlay, not methodConfig timeout). There is no\n/// `WithDisableServiceConfig`: nothing to ignore."
        ),
        "ChannelConfig rustdoc must Distinct typed Copy fields from grpc-go WithDefaultServiceConfig JSON"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithDefaultServiceConfig`")
            .count(),
        1,
        "ServerConfig must not copy the WithDefaultServiceConfig Distinct"
    );
}
