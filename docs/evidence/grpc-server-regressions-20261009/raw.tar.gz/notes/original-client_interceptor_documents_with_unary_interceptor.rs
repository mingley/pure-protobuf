fn client_interceptor_documents_with_unary_interceptor() {
    let src = include_str!("../src/interceptor.rs");
    assert!(
        src.contains(
            "There is no grpc-go `WithUnaryInterceptor`: that is a DialOption for\n/// unary RPCs only. `WithStreamInterceptor` is the stream split.\n/// `WithChainUnaryInterceptor` / `WithChainStreamInterceptor` append\n/// DialOption lists. This trait is one hook for every call shape, attached\n/// with [`crate::Channel::intercept`] after connect (not a DialOption).\n/// Calling intercept twice stacks; there is no chain DialOption. Distinct\n/// from [`Interceptor`] (inbound before the handler). Distinct from\n/// [`ResponseInterceptor`] (after Ok or after receive). Distinct from\n/// tonic `Interceptor` / `InterceptorLayer` (tower; this kernel has no\n/// tower)."
        ),
        "ClientInterceptor rustdoc must Distinct one hook for every call shape from grpc-go WithUnaryInterceptor DialOption split"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithUnaryInterceptor`")
            .count(),
        1,
        "Interceptor must not copy the WithUnaryInterceptor Distinct"
    );
}
