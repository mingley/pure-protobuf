fn official_interop_rustdoc_names_every_transport() {
    let testing = include_str!("../src/testing.rs");
    assert!(
        testing.contains(
            "Official uncompressed `_TEST_CASES` and the four gzip cases pass against
/// this server over TLS, mTLS, Unix, and [`crate::Server::serve_connection`]."
        ),
        "InteropTestService rustdoc must name official cases on every transport"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this InteropTestService interceptor Err; those trailers reach the client without reading the body."
        ),
        "InteropTestService rustdoc must name from_error_details typed bag next to interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService handler Err: that is after the handler ran; this InteropTestService interceptor Err is trailers without reading the body."
        ),
        "InteropTestService rustdoc must Distinct handler Err after the handler ran from this InteropTestService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this InteropTestService interceptor Err is trailers without reading the body."
        ),
        "InteropTestService rustdoc must Distinct testing server on_response Err trailers-only after handler Ok from this InteropTestService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService client interceptor Err: that is a local reject never opens a stream; this InteropTestService interceptor Err is trailers without reading the body."
        ),
        "InteropTestService rustdoc must Distinct client interceptor Err local reject never opens a stream from this InteropTestService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this InteropTestService interceptor Err is trailers without reading the body."
        ),
        "InteropTestService rustdoc must Distinct Channel on_response Err Call fail after receive from this InteropTestService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService StreamSender fail: that is trailers after any messages already sent; this InteropTestService interceptor Err is trailers without reading the body."
        ),
        "InteropTestService rustdoc must Distinct StreamSender fail after any messages already sent from this InteropTestService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService client interceptor: that runs on the outbound call before the stream opens; this InteropTestService interceptor runs on the inbound RPC before the handler."
        ),
        "InteropTestService rustdoc must Distinct client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this InteropTestService handler Err; those trailers reach the client."
        ),
        "InteropTestService rustdoc must name from_error_details typed bag next to handler Err"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor Err: that is trailers without reading the body; this InteropTestService handler Err is after the handler ran."
        ),
        "InteropTestService rustdoc must Distinct interceptor Err without reading the body from this InteropTestService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService client interceptor Err: that is a local reject never opens a stream; this InteropTestService handler Err is after the handler ran."
        ),
        "InteropTestService rustdoc must Distinct client interceptor Err local reject never opens a stream from this InteropTestService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this InteropTestService handler Err is after the handler ran."
        ),
        "InteropTestService rustdoc must Distinct server on_response Err trailers-only after handler Ok from this InteropTestService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this InteropTestService handler Err is after the handler ran."
        ),
        "InteropTestService rustdoc must Distinct Channel on_response Err Call fail after receive from this InteropTestService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService StreamSender fail: that is trailers after any messages already sent; this InteropTestService handler Err is after the handler ran."
        ),
        "InteropTestService rustdoc must Distinct StreamSender fail after any messages already sent from this InteropTestService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this InteropTestService client interceptor path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "InteropTestService rustdoc must name Outgoing::connected live-socket snapshot"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this InteropTestService client interceptor Err; a local reject never opens a stream."
        ),
        "InteropTestService rustdoc must name from_error_details typed bag next to client interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService handler Err: that is after the handler ran; this InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "InteropTestService rustdoc must Distinct InteropTestService handler Err after the handler ran from this InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "InteropTestService rustdoc must Distinct Channel on_response Err Call fail after receive from this InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor Err: that is trailers without reading the body; this InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "InteropTestService rustdoc must Distinct interceptor Err without reading the body from this InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService StreamSender fail: that is trailers after any messages already sent; this InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "InteropTestService rustdoc must Distinct StreamSender fail after any messages already sent from this InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this InteropTestService client interceptor already ran, so a local Err never consumes that budget."
        ),
        "InteropTestService rustdoc must Distinct max_concurrent_rpcs slot grab after client intercept"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor: that runs on the inbound RPC before the handler; this InteropTestService client interceptor runs on the outbound call before the stream opens."
        ),
        "InteropTestService rustdoc must Distinct inbound interceptor from client outbound-before-stream"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this InteropTestService StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "InteropTestService rustdoc must name from_error_details typed bag next to StreamSender fail"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService handler Err: that is after the handler ran; this InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "InteropTestService rustdoc must Distinct handler Err after the handler ran from this InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor Err: that is trailers without reading the body; this InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "InteropTestService rustdoc must Distinct interceptor Err without reading the body from this InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "InteropTestService rustdoc must Distinct testing server on_response Err trailers-only after handler Ok from this InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService client interceptor Err: that is a local reject never opens a stream; this InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "InteropTestService rustdoc must Distinct client interceptor Err local reject never opens a stream from this InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "InteropTestService rustdoc must Distinct testing Channel on_response Err Call fail after receive from this InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "A [`TestServiceClient`]\n//! `message_limits` is `RESOURCE_EXHAUSTED` on UnaryCall /\n//! StreamingOutputCall / StreamingInputCall / FullDuplexCall, including over\n//! TLS, mTLS, Unix, and [`crate::Channel::from_io`]. Distinct from wrapping\n//! `max_encoding_message_size` / `max_decoding_message_size`."
        ),
        "testing crate rustdoc must name TestServiceClient message_limits on every transport"
    );
    assert!(
        testing.contains(
            "[`TestServiceClient::connect_tls_with`] /\n//! [`TestServiceClient::connect_unix_with`] /\n//! [`TestServiceClient::from_io_with`] with\n//! [`crate::ChannelConfig::message_limits`] refuse the same oversize, distinct\n//! from wrapping a live client."
        ),
        "testing crate rustdoc must name dial-time ChannelConfig message_limits on every transport"
    );
    assert!(
        testing.contains(
            "[`TestServiceServer::max_header_list_size`]\n//! refuses oversize metadata on EmptyCall / StreamingOutputCall /\n//! StreamingInputCall / FullDuplexCall, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter\n//! server."
        ),
        "testing crate rustdoc must name header-list flood on every TestService shape"
    );
    assert!(
        testing.contains(
            "[`TestServiceServer::max_frame_size`] still serves EmptyCall /
//! StreamingOutputCall / StreamingInputCall / FullDuplexCall at the HTTP/2
//! 16 KiB SETTINGS minimum, including over TLS, mTLS, Unix, and
//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter
//! server."
        ),
        "testing crate rustdoc must name max_frame_size still-serves on every TestService shape"
    );
    assert!(
        testing.contains(
            "[`TestServiceServer::max_pending_accept_reset_streams`] still serves
//! EmptyCall / StreamingOutputCall / StreamingInputCall / FullDuplexCall at a
//! pending-reset cap of 1, including over TLS, mTLS, Unix, and
//! [`crate::Server::serve_connection`]. A well-behaved client never fills that
//! queue. Distinct from wrapping only a Greeter server."
        ),
        "testing crate rustdoc must name pending-reset still-serves on every TestService shape"
    );
    assert!(
        testing.contains(
            "[`TestServiceServer::max_send_buffer_size`] still serves EmptyCall /
//! StreamingOutputCall / StreamingInputCall / FullDuplexCall at a 16 KiB send
//! buffer, including over TLS, mTLS, Unix, and
//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter
//! server."
        ),
        "testing crate rustdoc must name send-buffer still-serves on every TestService shape"
    );
    assert!(
        testing.contains(
            "[`TestServiceServer::initial_stream_window_size`] /
//! [`TestServiceServer::initial_connection_window_size`] still serve EmptyCall /
//! StreamingOutputCall / StreamingInputCall / FullDuplexCall at a 64 KiB stream
//! / 128 KiB connection window, including over TLS, mTLS, Unix, and
//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter
//! server."
        ),
        "testing crate rustdoc must name HTTP/2 window still-serves on every TestService shape"
    );
    assert!(
        testing.contains(
            "A [`TestServiceClient`] pool larger than
//! [`TestServiceServer::max_concurrent_connections`] fails the whole dial as
//! `UNAVAILABLE` on TLS, mTLS, and Unix. [`TestServiceClient::from_io_with`]
//! cannot pool."
        ),
        "testing crate rustdoc must name pool-vs-cap UNAVAILABLE on TLS, mTLS, and Unix"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing interceptor Err; those trailers reach the client without reading the body."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to TestService interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from a testing handler Err: that is after the handler ran; this testing interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct handler Err after the handler ran from this testing interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this testing interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this testing interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing client interceptor Err: that is a local reject never opens a stream; this testing interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this testing interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this testing interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this testing interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing StreamSender fail: that is trailers after any messages already sent; this testing interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct StreamSender fail after any messages already sent from this testing interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing client interceptor: that runs on the outbound call before the stream opens; this testing interceptor runs on the inbound RPC before the handler."
        ),
        "testing crate rustdoc must Distinct client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing handler Err; those trailers reach the client."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to TestService handler Err"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor Err: that is trailers without reading the body; this testing handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct interceptor Err without reading the body from this testing handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing client interceptor Err: that is a local reject never opens a stream; this testing handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this testing handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this testing handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this testing handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this testing handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this testing handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing StreamSender fail: that is trailers after any messages already sent; this testing handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct StreamSender fail after any messages already sent from this testing handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this testing client interceptor path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "testing crate rustdoc must name Outgoing::connected live-socket snapshot on TestService"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing client interceptor Err; a local reject never opens a stream."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to TestService client interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from a testing handler Err: that is after the handler ran; this testing client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct testing handler Err after the handler ran from this testing client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this testing client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this testing client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor Err: that is trailers without reading the body; this testing client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct interceptor Err without reading the body from this testing client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from a testing StreamSender fail: that is trailers after any messages already sent; this testing client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct StreamSender fail after any messages already sent from this testing client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this testing client interceptor already ran, so a local Err never consumes that budget."
        ),
        "testing crate rustdoc must Distinct max_concurrent_rpcs slot grab after TestService client intercept"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor: that runs on the inbound RPC before the handler; this testing client interceptor runs on the outbound call before the stream opens."
        ),
        "testing crate rustdoc must Distinct inbound interceptor from client outbound-before-stream"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to TestService StreamSender fail"
    );
    assert!(
        testing.contains(
            "Distinct from a testing handler Err: that is after the handler ran; this testing StreamSender fail is trailers after any messages already sent."
        ),
        "testing crate rustdoc must Distinct handler Err after the handler ran from this testing StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor Err: that is trailers without reading the body; this testing StreamSender fail is trailers after any messages already sent."
        ),
        "testing crate rustdoc must Distinct interceptor Err without reading the body from this testing StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this testing StreamSender fail is trailers after any messages already sent."
        ),
        "testing crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this testing StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing client interceptor Err: that is a local reject never opens a stream; this testing StreamSender fail is trailers after any messages already sent."
        ),
        "testing crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this testing StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this testing StreamSender fail is trailers after any messages already sent."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this testing StreamSender fail after any messages already sent"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to testing server on_response Err"
    );
    assert!(
        testing.contains(
            "Distinct from a testing handler Err: that is after the handler ran; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct handler Err after the handler ran from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor Err: that is trailers without reading the body; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct interceptor Err without reading the body from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService interceptor Err: that is trailers without reading the body; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct UnimplementedService interceptor Err without reading the body from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from a testing StreamSender fail: that is trailers after any messages already sent; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct StreamSender fail after any messages already sent from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor Err: that is trailers without reading the body; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct InteropTestService interceptor Err without reading the body from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService StreamSender fail: that is trailers after any messages already sent; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct InteropTestService StreamSender fail after any messages already sent from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this testing server on_response Err is trailers-only after handler Ok."
        ),
        "testing crate rustdoc must Distinct testing Channel on_response Err Call fail after receive from this testing server on_response Err trailers-only after handler Ok"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this testing Channel on_response Err; a local reject fails the Call after a successful receive."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to testing Channel on_response Err"
    );
    assert!(
        testing.contains(
            "Distinct from a testing handler Err: that is after the handler ran; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct handler Err after the handler ran from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from a testing interceptor Err: that is trailers without reading the body; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct interceptor Err without reading the body from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from a testing client interceptor Err: that is a local reject never opens a stream; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService client interceptor Err: that is a local reject never opens a stream; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct UnimplementedService client interceptor Err local reject never opens a stream from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService interceptor Err: that is trailers without reading the body; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct UnimplementedService interceptor Err without reading the body from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from a testing StreamSender fail: that is trailers after any messages already sent; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct StreamSender fail after any messages already sent from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService client interceptor Err: that is a local reject never opens a stream; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct InteropTestService client interceptor Err local reject never opens a stream from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService interceptor Err: that is trailers without reading the body; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct InteropTestService interceptor Err without reading the body from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from an InteropTestService StreamSender fail: that is trailers after any messages already sent; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct InteropTestService StreamSender fail after any messages already sent from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this testing Channel on_response Err fails the Call after a successful receive."
        ),
        "testing crate rustdoc must Distinct testing server on_response Err trailers-only after handler Ok from this testing Channel on_response Err Call fail after receive"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this UnimplementedService interceptor Err; those trailers reach the client without reading the body."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to UnimplementedService interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService handler Err: that is after the handler ran; this UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct UnimplementedService handler Err after the handler ran from this UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct testing server on_response Err trailers-only after handler Ok from this UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService client interceptor Err: that is a local reject never opens a stream; this UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct UnimplementedService client interceptor Err local reject never opens a stream from this UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService client interceptor: that runs on the outbound call before the stream opens; this UnimplementedService interceptor runs on the inbound RPC before the handler."
        ),
        "testing crate rustdoc must Distinct UnimplementedService client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this UnimplementedService handler Err; those trailers reach the client."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to UnimplementedService handler Err"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService interceptor Err: that is trailers without reading the body; this UnimplementedService handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct UnimplementedService interceptor Err without reading the body from this UnimplementedService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService client interceptor Err: that is a local reject never opens a stream; this UnimplementedService handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct UnimplementedService client interceptor Err local reject never opens a stream from this UnimplementedService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing server on_response Err: that is trailers-only after handler Ok; this UnimplementedService handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this UnimplementedService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this UnimplementedService handler Err is after the handler ran."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this UnimplementedService handler Err after the handler ran"
    );
    assert!(
        testing.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this UnimplementedService client interceptor path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "testing crate rustdoc must name Outgoing::connected live-socket snapshot on UnimplementedService"
    );
    assert!(
        testing.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this UnimplementedService client interceptor Err; a local reject never opens a stream."
        ),
        "testing crate rustdoc must name from_error_details typed bag next to UnimplementedService client interceptor Err"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService handler Err: that is after the handler ran; this UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct UnimplementedService handler Err after the handler ran from this UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from a testing Channel on_response Err: that fails the Call after a successful receive; this UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct Channel on_response Err Call fail after receive from this UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService interceptor Err: that is trailers without reading the body; this UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "testing crate rustdoc must Distinct UnimplementedService interceptor Err without reading the body from this UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        testing.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this UnimplementedService client interceptor already ran, so a local Err never consumes that budget."
        ),
        "testing crate rustdoc must Distinct max_concurrent_rpcs slot grab after UnimplementedService client intercept"
    );
    assert!(
        testing.contains(
            "Distinct from an UnimplementedService interceptor: that runs on the inbound RPC before the handler; this UnimplementedService client interceptor runs on the outbound call before the stream opens."
        ),
        "testing crate rustdoc must Distinct UnimplementedService inbound interceptor from client outbound-before-stream"
    );
    let cases = include_str!("../src/interop_cases.rs");
    assert!(
        cases.contains(
            "Applies to the call shapes that case uses, including over TLS, mTLS,
/// Unix, and [`crate::Channel::from_io`]."
        ),
        "run_case rustdoc must name every transport"
    );
}
