#[test]
fn generated_stubs_name_encoding_cancel_and_stream_drop() {
    let src = include_str!(concat!(env!("OUT_DIR"), "/kv.rs"));
    assert!(
        src.contains("Inbound `grpc-encoding` is [`::pbrs_grpc::Request::encoding`]"),
        "trait methods must name inbound encoding"
    );
    assert!(
        src.contains("Spawned producers should select on [`::pbrs_grpc::Request::cancelled`] and [`::pbrs_grpc::StreamSender::closed`]"),
        "server-streaming trait methods must name cancelled/closed"
    );
    assert!(
        src.contains("[`::pbrs_grpc::StreamSender::fail`] after a message ships trailing metadata and `grpc-status-details-bin` the same as a handler `Err`."),
        "server-streaming trait methods must name StreamSender::fail trailers"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated StreamSender fail on a server response producer; those trailers ship after any messages already sent."),
        "server-streaming trait methods must name from_error_details typed bag next to StreamSender fail"
    );
    assert!(
        src.contains("Distinct from a generated handler Err: that is after the handler ran; this generated StreamSender fail is trailers after any messages already sent."),
        "server-streaming trait methods must Distinct generated handler Err after the handler ran from this generated StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains("Distinct from a generated server intercept Err: that is trailers without reading the body; this generated StreamSender fail is trailers after any messages already sent."),
        "server-streaming trait methods must Distinct generated server intercept Err without reading the body from this generated StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains("Distinct from a generated server on_response Err: that is trailers-only after handler Ok; this generated StreamSender fail is trailers after any messages already sent."),
        "server-streaming trait methods must Distinct generated server on_response Err trailers-only after handler Ok from this generated StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains("Distinct from a generated intercept Err: that is a local reject never opens a stream; this generated StreamSender fail is trailers after any messages already sent."),
        "server-streaming trait methods must Distinct generated intercept Err local reject never opens a stream from this generated StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains("Distinct from a generated client on_response Err: that fails the Call after a successful receive; this generated StreamSender fail is trailers after any messages already sent."),
        "server-streaming trait methods must Distinct generated client on_response Err Call fail after receive from this generated StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains("Spawned work should await [`::pbrs_grpc::Request::cancelled`]"),
        "trait methods must name spawned cancelled"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated handler Err; those trailers reach the client."),
        "trait methods must name from_error_details typed bag next to handler Err"
    );
    assert!(
        src.contains("Distinct from a generated server intercept Err: that is trailers without reading the body; this generated handler Err is after the handler ran."),
        "trait methods must Distinct generated server intercept Err without reading the body from this generated handler Err after the handler ran"
    );
    assert!(
        src.contains("Distinct from a generated intercept Err: that is a local reject never opens a stream; this generated handler Err is after the handler ran."),
        "trait methods must Distinct generated intercept Err local reject never opens a stream from this generated handler Err after the handler ran"
    );
    assert!(
        src.contains("Distinct from a generated server on_response Err: that is trailers-only after handler Ok; this generated handler Err is after the handler ran."),
        "trait methods must Distinct generated server on_response Err trailers-only after handler Ok from this generated handler Err after the handler ran"
    );
    assert!(
        src.contains("Distinct from a generated client on_response Err: that fails the Call after a successful receive; this generated handler Err is after the handler ran."),
        "trait methods must Distinct generated client on_response Err Call fail after receive from this generated handler Err after the handler ran"
    );
    assert!(
        src.contains("Distinct from a generated StreamSender fail: that is trailers after any messages already sent; this generated handler Err is after the handler ran."),
        "trait methods must Distinct generated StreamSender fail after any messages already sent from this generated handler Err after the handler ran"
    );
    assert!(
        src.contains("That signal still fires after the client half-closes the request stream."),
        "client-streaming trait methods must name cancelled after half-close"
    );
    assert!(
        src.contains(
            "Dropping the received [`::pbrs_grpc::Streaming`] before the end resets the RPC."
        ),
        "server-streaming client methods must name stream drop"
    );
    assert!(
        src.contains("A [`::pbrs_grpc::CallHandle`] taken before await cancels the RPC."),
        "unary client methods must name CallHandle"
    );
    assert!(
        src.contains("A [`::pbrs_grpc::CallHandle`] taken before await still cancels while waiting for headers, and still cancels that live stream after headers."),
        "server-streaming and bidi client methods must name CallHandle before and after headers"
    );
    assert!(
        src.contains("Letting the deadline fire RSTs the send half before headers and after headers the same way."),
        "server-streaming and bidi client methods must name deadline RST before and after headers"
    );
    assert!(
        src.contains("A [`::pbrs_grpc::CallHandle`] taken before await still cancels after the sender is closed, while the unary response is pending."),
        "client-streaming client methods must name CallHandle after half-close"
    );
    assert!(
        src.contains(
            "Cancelling before any request message (`cancel_after_begin`) is [`::pbrs_grpc::Code::Cancelled`], not OK from a half-close: hold the [`::pbrs_grpc::StreamSender`] until the [`::pbrs_grpc::Call`] settles, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client-streaming methods must name cancel_after_begin on every transport"
    );
    assert!(
        src.contains(
            "OK-path custom trailers land on [`::pbrs_grpc::Response::trailers`]; a `-bin` trailer must not appear as a header, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated unary and client-streaming methods must name OK-path -bin trailers on every transport"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Streaming::trailers`] waits for end-of-stream, including when called before draining messages. A non-OK trailing `grpc-status` is `Err`. A `-bin` trailer must not appear as a header, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated server-streaming and bidi methods must name Streaming::trailers on every transport"
    );
    assert!(
        src.contains("Dropping the [`::pbrs_grpc::Call`] or letting its deadline fire after that half-close resets the same way."),
        "client-streaming client methods must name drop and deadline after half-close"
    );
    assert!(
        src.contains("[`::pbrs_grpc::StreamSender::fail`] resolves the [`::pbrs_grpc::Call`] with that status (no request-side `grpc-status`; the stream is reset with CANCEL)."),
        "client-streaming client methods must name StreamSender::fail"
    );
    assert!(
        src.contains("[`::pbrs_grpc::StreamSender::fail`] before headers resolves the [`::pbrs_grpc::Call`] with that status, not `UNAVAILABLE` from the reset; after headers the received [`::pbrs_grpc::Streaming`] sees [`::pbrs_grpc::Code::Cancelled`], not that status."),
        "bidi client methods must name StreamSender::fail before headers, not UNAVAILABLE, and CANCELLED after headers"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::set_timeout`] is that Call's deadline on every call shape."
        ),
        "generated client intercept rustdoc must name set_timeout as the Call deadline"
    );
    assert!(
        src.contains("`clear_timeout` opts out of the channel timeout on every call shape."),
        "generated client intercept rustdoc must name clear_timeout opt-out"
    );
    assert!(
        src.contains(
            "Interceptors run after this fill and can still set or [`::pbrs_grpc::Outgoing::clear_timeout`]."
        ),
        "generated timeout rustdoc must name interceptor clear_timeout"
    );
    assert!(
        src.contains(
            "`clear_compress` then `set_compress(compresses_outbound())` reapplies channel gzip on every call shape."
        ),
        "generated client intercept rustdoc must name gzip reapply after clear"
    );
    assert!(
        src.contains(
            "`clear_user_agent` restores the channel user-agent after a generated intercept prefix."
        ),
        "generated client intercept rustdoc must name clear_user_agent opt-out"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::user_agent_is_set`] is occupancy on this generated intercept path, so a later interceptor can prefix only when unset."
        ),
        "generated client intercept rustdoc must name Outgoing::user_agent_is_set occupancy next to clear_user_agent"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::wait_for_ready_is_set`] is occupancy on this generated intercept path, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "generated client intercept rustdoc must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::compress_is_set`] is occupancy on this generated intercept path, so a later interceptor can fill compress only when unset."
        ),
        "generated client intercept rustdoc must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        src.contains(
            "`clear_wait_for_ready` restores the channel wait-for-ready overlay after a generated intercept choice."
        ),
        "generated client intercept rustdoc must name clear_wait_for_ready opt-out next to compress occupancy"
    );
    assert!(
        src.contains(
            "`clear_timeout` opts out of the channel timeout after a generated intercept choice."
        ),
        "generated client intercept rustdoc must name clear_timeout next to clear_wait_for_ready"
    );
    assert!(
        src.contains(
            "`clear_compress` then `set_compress` from `compresses_outbound` reapplies channel gzip after a generated intercept choice."
        ),
        "generated client intercept rustdoc must name clear_compress reapply next to clear_timeout"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::connected`] is the live-socket snapshot on this generated intercept path ([`::pbrs_grpc::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "generated client intercept rustdoc must name Outgoing::connected live-socket snapshot next to clear_compress"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated intercept Err; a local reject never opens a stream."
        ),
        "generated client intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        src.contains(
            "Distinct from a generated handler Err: that is after the handler ran; this generated intercept Err is a local reject never opens a stream."
        ),
        "generated client intercept rustdoc must Distinct generated handler Err after the handler ran from this generated intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a generated client on_response Err: that fails the Call after a successful receive; this generated intercept Err is a local reject never opens a stream."
        ),
        "generated client intercept rustdoc must Distinct generated client on_response Err Call fail after receive from this generated intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a generated server intercept Err: that is trailers without reading the body; this generated intercept Err is a local reject never opens a stream."
        ),
        "generated client intercept rustdoc must Distinct generated server intercept Err without reading the body from this generated intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a generated StreamSender fail: that is trailers after any messages already sent; this generated intercept Err is a local reject never opens a stream."
        ),
        "generated client intercept rustdoc must Distinct generated StreamSender fail after any messages already sent from this generated intercept Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from [`::pbrs_grpc::Channel::max_concurrent_rpcs`]: that takes a slot when the [`::pbrs_grpc::Call`] is polled; a generated intercept already ran, so a local Err never consumes that budget."
        ),
        "generated client intercept rustdoc must Distinct max_concurrent_rpcs slot grab after intercept"
    );
    assert!(
        src.contains(
            "Distinct from [`::pbrs_grpc::Server::intercept`]: that runs on the inbound RPC before the handler; this generated intercept runs on the outbound call before the stream opens."
        ),
        "generated client intercept rustdoc must Distinct Server inbound-before-handler from outbound-before-stream"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after a successful receive; this generated intercept runs on the outbound call before the stream opens."
        ),
        "generated client intercept rustdoc must Distinct on_response after-receive from outbound-before-stream"
    );
    assert!(
        src.contains(
            "`set_compress` stamps [`::pbrs_grpc::StreamSender::compress`] on client-streaming and bidi request streams."
        ),
        "generated client intercept rustdoc must name StreamSender gzip stamp"
    );
    assert!(
        src.contains("dropping a streaming Call resets the stream"),
        "client-streaming and bidi pairs must be must_use"
    );
    assert!(
        src.contains("The [`::pbrs_grpc::Call`] is fused after it resolves."),
        "client methods must name fused Call"
    );
    assert!(
        src.contains("After end-of-stream or error that stream is fused"),
        "server-streaming and bidi methods must name fused Streaming"
    );
    assert!(
        src.contains(
            "channel overlays (`rpc_timeout` / `waits_for_ready` / `compresses_outbound` / `gzip_level` / `accepts_compressed` / `concurrent_rpc_limit` / `stream_buffer_size` / `send_buffer_size` / `limits`; `clear_*` opts out of the already-applied default)"
        ),
        "generated intercept rustdoc must name channel overlays and clear_*"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Outgoing::gzip_level`] is deflate effort"),
        "generated intercept rustdoc must name Outgoing::gzip_level as deflate effort"
    );
    assert!(
        src.contains("Distinct from [`::pbrs_grpc::Outgoing::compresses_outbound`] (on or off)."),
        "generated intercept rustdoc must Distinct gzip_level from compresses_outbound"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::accepts_compressed`] is the inbound gzip overlay (default on)."
        ),
        "generated intercept rustdoc must name Outgoing::accepts_compressed"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Outgoing::limits`] is the channel message-cap overlay"),
        "generated intercept rustdoc must name Outgoing::limits as the message-cap overlay"
    );
    assert!(
        src.contains("Same overlay as [`::pbrs_grpc::Channel::limits`]."),
        "generated intercept rustdoc must Distinct Outgoing::limits as the same overlay as Channel::limits"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Outgoing::set_user_agent`] prefixes this RPC."),
        "generated intercept rustdoc must name Outgoing::set_user_agent"
    );
    assert!(
        src.contains("`user-agent` (`user_agent_is_set`), message caps,"),
        "generated intercept rustdoc must name user_agent_is_set next to user-agent"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Request::set_user_agent`] is the same prefix at the call site."
        ),
        "generated intercept rustdoc must Distinct Request::set_user_agent at the call site"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Outgoing::connected`] is the live-socket snapshot"),
        "generated intercept rustdoc must name Outgoing::connected"
    );
    assert!(
        src.contains(
            "Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "generated intercept rustdoc must Distinct connected from wait-for-ready"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::concurrent_rpc_limit`] is the channel RPC cap overlay"
        ),
        "generated intercept rustdoc must name Outgoing::concurrent_rpc_limit"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::stream_buffer_size`] is the outbound streaming queue overlay"
        ),
        "generated intercept rustdoc must name Outgoing::stream_buffer_size"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Outgoing::send_buffer_size`] is the outbound HTTP/2 send buffer overlay"
        ),
        "generated intercept rustdoc must name Outgoing::send_buffer_size"
    );
    assert!(
        src.contains(
            "Distinct from [`::pbrs_grpc::Outgoing::stream_buffer_size`]: that is queue depth, not this send buffer."
        ),
        "generated intercept rustdoc must Distinct send_buffer_size from stream_buffer_size"
    );
    assert!(
        src.contains(
            "Compiling overlay dumps live on [`::pbrs_grpc::hello`] (`GreeterClient::new(channel).intercept`)."
        ),
        "generated intercept rustdoc must point at the compiling hello overlay dump"
    );
    assert!(
        src.contains("`peer_timeout` / `rpc_timeout` / `effective_timeout`"),
        "generated server intercept rustdoc must name the server timeout overlay"
    );
    assert!(
        src.contains("gzip accept and encoding / `compresses_outbound` / `gzip_level`"),
        "generated server intercept rustdoc must name gzip_level overlay"
    );
    assert!(
        src.contains(
            "`gzip_level` / `accepts_compressed` / `concurrent_rpc_limit` / `send_buffer_size`, attach extensions"
        ),
        "generated server intercept rustdoc must name accepts_compressed overlay"
    );
    assert!(
        src.contains(
            "`gzip_level` / `accepts_compressed` / `concurrent_rpc_limit` / `send_buffer_size`, attach extensions"
        ),
        "generated server intercept rustdoc must name concurrent_rpc_limit overlay"
    );
    assert!(
        src.contains(
            "`gzip_level` / `accepts_compressed` / `concurrent_rpc_limit` / `send_buffer_size`, attach extensions"
        ),
        "generated server intercept rustdoc must name send_buffer_size overlay"
    );
    assert!(
        src.contains(
            "gzip unary and server-streaming request payloads and [`::pbrs_grpc::StreamSender::send`]. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client send_compressed rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "gzip responses when the client advertises gzip. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated server send_compressed rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::send_compressed`], which is on or off. 0 stores; 9 is best. A well-behaved client still completes every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated gzip_compression_level rustdoc must Distinct deflate effort from on/off on every transport"
    );
    assert!(
        src.contains(
            "including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]. Distinct from [`Self::send_compressed`], which is on or off."
        ),
        "generated client gzip_compression_level rustdoc must Distinct deflate effort from on/off on every transport"
    );
    assert!(
        src.contains(
            "Inflate inbound gzip. Default `true`. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated server accept_compressed rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Inflate inbound gzip. Default `true`. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client accept_compressed rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Cap every RPC even when the client omits `grpc-timeout`. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated server timeout rustdoc must name every transport"
    );
    assert!(
        src.contains("Replace both message caps at once. Applies to every call shape."),
        "generated message_limits rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_encoding_message_size`] / [`Self::max_decoding_message_size`]. Oversize is `RESOURCE_EXHAUSTED` on every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client message_limits rustdoc must name the combined setter on every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_decoding_message_size`] / [`Self::max_encoding_message_size`]. Oversize inbound or outbound is `RESOURCE_EXHAUSTED` on every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated server message_limits rustdoc must name combined-setter oversize on every transport"
    );
    assert!(
        src.contains(
            "Cap how many RPCs the process will run at once. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated max_concurrent_rpcs rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Configured process-wide RPC cap, if any. Distinct from [`Self::max_concurrent_rpcs`], which sets it. See [`::pbrs_grpc::Server::concurrent_rpc_limit`]."
        ),
        "generated server concurrent_rpc_limit rustdoc must Distinct the setter"
    );
    assert!(
        src.contains(
            "Cap how many RPCs this channel will run at once. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]. Extra RPCs are `RESOURCE_EXHAUSTED` before the stream opens. Distinct from HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`, which waits. Distinct from [`::pbrs_grpc::Server::max_concurrent_rpcs`], which refuses inbound. Clones share the budget. See [`::pbrs_grpc::Channel::max_concurrent_rpcs`]."
        ),
        "generated client max_concurrent_rpcs rustdoc must Distinct SETTINGS wait from the server inbound cap"
    );
    assert!(
        src.contains(
            "Cap how many TCP/Unix connections the accept loop will serve at once, including TLS and mTLS listeners. Applies to every call shape."
        ),
        "generated max_concurrent_connections rustdoc must name TLS and mTLS"
    );
    assert!(
        src.contains("Concurrent RPCs allowed per HTTP/2 connection. Applies to every call shape."),
        "generated max_concurrent_streams rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`. Distinct from [`Self::max_concurrent_rpcs`], which refuses extras as `RESOURCE_EXHAUSTED`. A well-behaved client waits; both RPCs still complete, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated max_concurrent_streams rustdoc must name serialize vs RESOURCE_EXHAUSTED on every transport"
    );
    assert!(
        src.contains("HTTP/2 per-stream receive window. Applies to every call shape."),
        "generated initial_stream_window_size rustdoc must name every call shape"
    );
    assert!(
        src.contains("HTTP/2 per-connection receive window. Applies to every call shape."),
        "generated initial_connection_window_size rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "A well-behaved client still completes every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Distinct from [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS minimum, and from [`Self::max_concurrent_streams`], which serializes extra RPCs."
        ),
        "generated window rustdoc must name still-serves Distinct from frame size and stream cap"
    );
    assert!(
        src.contains("HTTP/2 `SETTINGS_MAX_FRAME_SIZE`. Applies to every call shape."),
        "generated max_frame_size rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "A well-behaved client splits DATA; every call shape still completes, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Distinct from [`Self::max_header_list_size`], which refuses oversize metadata, and from [`Self::max_concurrent_streams`], which serializes extra RPCs."
        ),
        "generated max_frame_size rustdoc must name still-serves Distinct from header-list and stream cap"
    );
    assert!(
        src.contains("HTTP/2 `SETTINGS_MAX_HEADER_LIST_SIZE`. Applies to every call shape."),
        "generated max_header_list_size rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Oversize metadata is refused, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Distinct from a raw HTTP/2 peer."
        ),
        "generated max_header_list_size rustdoc must name oversize metadata on every transport"
    );
    assert!(
        src.contains("Per-connection HTTP/2 send buffer. Applies to every call shape."),
        "generated max_send_buffer_size rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Write backpressure still completes every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Distinct from [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS minimum, and from [`Self::initial_stream_window_size`], which still serves at a small receive window."
        ),
        "generated max_send_buffer_size rustdoc must name still-serves Distinct from frame size and windows"
    );
    assert!(
        src.contains(
            "Cap remotely-reset HTTP/2 streams waiting in the accept queue. Applies to every call shape."
        ),
        "generated max_pending_accept_reset_streams rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "A well-behaved client never fills that queue; every call shape still completes, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Distinct from a raw HTTP/2 peer."
        ),
        "generated max_pending_accept_reset_streams rustdoc must name still-serves Distinct from a raw RST flood"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_pending_accept_reset_streams`], which caps remotely-reset streams (rapid reset). This caps RSTs we send after an invalid frame. A well-behaved client never triggers one; every call shape still completes, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated max_local_error_reset_streams rustdoc must Distinct library RSTs from rapid reset on every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_header_list_size`], which caps uncompressed header-block bytes (`SETTINGS_MAX_HEADER_LIST_SIZE`). A well-behaved client still completes every call shape at this table size, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated header_table_size rustdoc must Distinct HPACK table from header-list cap on every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::initial_connection_window_size`], which is flow-control bytes, and from [`Self::max_frame_size`], which caps one DATA payload. h2 Auto (half the connection window) is not exposed. A well-behaved client still completes every call shape at this framing budget, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated data_frame_budget rustdoc must Distinct small-DATA budget from windows on every transport"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_pending_accept_reset_streams`] (rapid-reset GOAWAY) and [`Self::max_local_error_reset_streams`] (protocol-error RST GOAWAY). A well-behaved client still completes every call shape at this memory cap, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated max_concurrent_reset_streams rustdoc must Distinct eviction from pending-reset and local-error RST GOAWAY"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_concurrent_reset_streams`], which is how many IDs are remembered (count). This is how long (time). A well-behaved client still completes every call shape at this reset duration, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated reset_stream_duration rustdoc must Distinct time from count on every transport"
    );
    assert!(
        src.contains(
            "Serve a single already-accepted byte stream until it closes. Applies to every call shape."
        ),
        "generated serve_connection rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Serve connections from `incoming` until it is exhausted. Applies to every call shape. Override [`::pbrs_grpc::Incoming::peer`] to stamp connection facts."
        ),
        "generated serve_with_incoming rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Serve from `incoming` until `shutdown` resolves, then drain. Applies to every call shape."
        ),
        "generated serve_with_incoming_shutdown rustdoc must name every call shape"
    );
    assert!(
        src.contains("`Err` fails that Call on poll, including [`::pbrs_grpc::Status::with_error_details`]; nothing is sent."),
        "generated client intercept rustdoc must name typed Err"
    );
    assert!(
        src.contains("`Err` may carry [`::pbrs_grpc::Status::with_error_details`]; those trailers reach the client."),
        "generated server intercept rustdoc must name typed Err trailers"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated server intercept Err; those trailers reach the client without reading the body."
        ),
        "generated server intercept rustdoc must name from_error_details typed bag next to intercept Err"
    );
    assert!(
        src.contains(
            "Distinct from a generated handler Err: that is after the handler ran; this generated server intercept Err is trailers without reading the body."
        ),
        "generated server intercept rustdoc must Distinct generated handler Err after the handler ran from this generated server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a generated server on_response Err: that is trailers-only after handler Ok; this generated server intercept Err is trailers without reading the body."
        ),
        "generated server intercept rustdoc must Distinct generated server on_response Err trailers-only after handler Ok from this generated server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a generated intercept Err: that is a local reject never opens a stream; this generated server intercept Err is trailers without reading the body."
        ),
        "generated server intercept rustdoc must Distinct generated intercept Err local reject never opens a stream from this generated server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a generated client on_response Err: that fails the Call after a successful receive; this generated server intercept Err is trailers without reading the body."
        ),
        "generated server intercept rustdoc must Distinct generated client on_response Err Call fail after receive from this generated server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a generated StreamSender fail: that is trailers after any messages already sent; this generated server intercept Err is trailers without reading the body."
        ),
        "generated server intercept rustdoc must Distinct generated StreamSender fail after any messages already sent from this generated server intercept Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from [`::pbrs_grpc::Channel::intercept`]: that runs on the outbound call before the stream opens; this generated server intercept runs on the inbound RPC before the handler."
        ),
        "generated server intercept rustdoc must Distinct Channel outbound-before-stream from inbound-before-handler"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::on_response`]: that runs after the handler returns Ok; this generated server intercept runs on the inbound RPC before the handler."
        ),
        "generated server intercept rustdoc must Distinct on_response after-Ok from inbound-before-handler"
    );
    assert!(
        src.contains("Applies to every call shape; `Err` rejects before the body is read, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."),
        "generated server intercept rustdoc must name a single intercept reject on every transport"
    );
    assert!(
        src.contains(
            "Compiling overlay dumps live on [`::pbrs_grpc::hello`] (`GreeterServer::new(Svc).intercept`)."
        ),
        "generated server intercept rustdoc must point at the compiling hello overlay dump"
    );
    assert!(
        src.contains("`Response::extensions` is not on the wire; stamp metadata here to send it"),
        "generated on_response rustdoc must Distinct extensions from wire metadata"
    );
    assert!(
        src.contains("`Err` after the handler already ran; that status is sent trailers-only instead of the response"),
        "generated on_response rustdoc must name trailers-only after the handler"
    );
    assert!(
        src.contains("A handler `Err` skips this hook."),
        "generated on_response rustdoc must name handler Err skip"
    );
    assert!(
        src.contains("A received reply starts empty; this is how a client inserts typed context after the peer cannot."),
        "generated client on_response rustdoc must Distinct receive-side insert from the peer"
    );
    assert!(
        src.contains("A non-OK peer status skips this hook."),
        "generated client on_response rustdoc must name skip on non-OK peer status"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::path`] is kernel-stamped. Distinct from [`::pbrs_grpc::Request::path`]."),
        "generated on_response rustdoc must name kernel-stamped path"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::path`] is kernel-stamped. Distinct from [`::pbrs_grpc::Outgoing::path`]."),
        "generated client on_response rustdoc must Distinct Outgoing::path"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::gzip_level`] is the server encode overlay. Distinct from [`::pbrs_grpc::ResponseParts::compress`]."),
        "generated on_response rustdoc must name gzip_level overlay"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::gzip_level`] on a received reply is not the peer's deflate effort. Distinct from [`::pbrs_grpc::Response::encoding`]."),
        "generated client on_response rustdoc must Distinct received gzip_level from encoding"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::compresses_outbound`] is the server encode overlay. Distinct from [`::pbrs_grpc::ResponseParts::compress`], which is the per-RPC Compressed-Flag."),
        "generated on_response rustdoc must name compresses_outbound overlay"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::compresses_outbound`] on a received reply is `false` (the overlay is not on the wire)."),
        "generated client on_response rustdoc must name received compresses_outbound is false"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::accepts_gzip`] is the peer `grpc-accept-encoding` advertisement. Distinct from [`::pbrs_grpc::ResponseParts::encoding`]."),
        "generated on_response rustdoc must name accepts_gzip advertisement"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::accepts_gzip`] on a received reply is `false` (the advertisement is not on the reply wire)."),
        "generated client on_response rustdoc must name received accepts_gzip is false"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::deadline`] is kernel-stamped when writing. Distinct from [`::pbrs_grpc::Request::deadline`]. Distinct from [`::pbrs_grpc::Rpc::deadline`]."),
        "generated on_response rustdoc must name kernel-stamped deadline"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::deadline`] on a received reply is `None` (the peer deadline is not on the wire)."),
        "generated client on_response rustdoc must name received deadline is None"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::timeout`] is the duration stamped at dispatch. Distinct from [`::pbrs_grpc::ResponseParts::deadline`]."),
        "generated on_response rustdoc must name timeout duration stamped at dispatch"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::timeout`] on a received reply is `None` (the peer timeout is not on the reply wire)."),
        "generated client on_response rustdoc must name received timeout is None"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::limits`] is the encode cap when writing. Distinct from [`::pbrs_grpc::Request::limits`]. Distinct from [`::pbrs_grpc::Rpc::limits`]."),
        "generated on_response rustdoc must name encode caps when writing"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::limits`] on a received reply is `None` (the peer encode cap is not on the wire)."),
        "generated client on_response rustdoc must name received limits is None"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::peer_timeout`] is the client's `grpc-timeout`. Distinct from [`::pbrs_grpc::ResponseParts::timeout`]."),
        "generated on_response rustdoc must name client grpc-timeout"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::peer_timeout`] on a received reply is `None` (the client's `grpc-timeout` is not on the reply wire)."),
        "generated client on_response rustdoc must name received peer_timeout is None"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::rpc_timeout`] is the server overlay. Distinct from [`::pbrs_grpc::ResponseParts::timeout`]. Distinct from [`::pbrs_grpc::ResponseParts::peer_timeout`]."),
        "generated on_response rustdoc must name server overlay"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::rpc_timeout`] on a received reply is `None` (the server overlay is not on the reply wire)."),
        "generated client on_response rustdoc must name received rpc_timeout is None"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::accepts_compressed`] is the inbound gzip overlay. Distinct from [`::pbrs_grpc::ResponseParts::accepts_gzip`]."),
        "generated on_response rustdoc must name inbound gzip overlay"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::accepts_compressed`] on a received reply is `false` (this overlay is not a received-reply field)."),
        "generated client on_response rustdoc must name received accepts_compressed is false"
    );
    assert!(
        src.contains("[`::pbrs_grpc::ResponseParts::send_buffer_size`] is the write-time HTTP/2 send buffer overlay. Distinct from [`::pbrs_grpc::ResponseParts::limits`]."),
        "generated on_response rustdoc must name write-time send buffer overlay"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ResponseParts::compress_is_set`] is occupancy after a generated server on_response, so a later interceptor can fill compress only when unset."
        ),
        "generated server on_response rustdoc must name compress_is_set occupancy next to send_buffer overlay"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ResponseParts::clear_compress`] restores the server gzip overlay after a generated server on_response."
        ),
        "generated server on_response rustdoc must name clear_compress next to compress occupancy"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "generated server on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a generated handler Err: that is after the handler ran; this generated server on_response Err is trailers-only after handler Ok."
        ),
        "generated server on_response rustdoc must Distinct generated handler Err after the handler ran from this generated server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a generated server intercept Err: that is trailers without reading the body; this generated server on_response Err is trailers-only after handler Ok."
        ),
        "generated server on_response rustdoc must Distinct generated server intercept Err without reading the body from this generated server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a generated client on_response Err: that fails the Call after a successful receive; this generated server on_response Err is trailers-only after handler Ok."
        ),
        "generated server on_response rustdoc must Distinct generated client on_response Err Call fail after receive from this generated server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a generated StreamSender fail: that is trailers after any messages already sent; this generated server on_response Err is trailers-only after handler Ok."
        ),
        "generated server on_response rustdoc must Distinct generated StreamSender fail after any messages already sent from this generated server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the inbound RPC before the handler; this generated server on_response runs after the handler returns Ok."
        ),
        "generated server on_response rustdoc must Distinct intercept inbound-before-handler from after-Ok"
    );
    assert!(
        src.contains(
            "Compiling overlay dumps live on [`::pbrs_grpc::hello`] (`GreeterServer::new(Svc).on_response`)."
        ),
        "generated server on_response rustdoc must point at the compiling hello overlay dump"
    );
    assert!(
        src.contains("[`::pbrs_grpc::Response::send_buffer_size`] on a received reply is `None` (the peer send buffer is not on the reply wire)."),
        "generated client on_response rustdoc must name received send_buffer_size is None"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ResponseParts::compress_is_set`] is occupancy after a generated client on_response, so a later interceptor can fill compress only when unset."
        ),
        "generated client on_response rustdoc must name compress_is_set occupancy next to received send_buffer"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ResponseParts::clear_compress`] drops a compress choice after a generated client on_response; a received reply has no server gzip overlay to restore."
        ),
        "generated client on_response rustdoc must name clear_compress receive-path next to compress occupancy"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::Status::from_error_details`] is the typed bag after a generated client on_response Err; a local reject fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must name from_error_details typed bag next to on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a generated handler Err: that is after the handler ran; this generated client on_response Err fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct generated handler Err after the handler ran from this generated client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a generated server intercept Err: that is trailers without reading the body; this generated client on_response Err fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct generated server intercept Err without reading the body from this generated client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a generated intercept Err: that is a local reject never opens a stream; this generated client on_response Err fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct generated intercept Err local reject never opens a stream from this generated client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a generated server on_response Err: that is trailers-only after handler Ok; this generated client on_response Err fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct generated server on_response Err trailers-only after handler Ok from this generated client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a generated StreamSender fail: that is trailers after any messages already sent; this generated client on_response Err fails the Call after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct generated StreamSender fail after any messages already sent from this generated client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::intercept`]: that runs on the outbound call before the stream opens; this generated client on_response runs after a successful receive."
        ),
        "generated client on_response rustdoc must Distinct intercept outbound-before-stream from after-receive"
    );
    assert!(
        src.contains(
            "Compiling overlay dumps live on [`::pbrs_grpc::hello`] (`GreeterClient::new(channel).on_response`)."
        ),
        "generated client on_response rustdoc must point at the compiling hello overlay dump"
    );
    assert!(
        src.contains(
            "Bind `addr` and serve over TLS until the listener fails. Applies to every call shape."
        ),
        "generated serve_tls rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Dial over TLS. See [`::pbrs_grpc::Channel::connect_tls`]. Applies to every call shape."
        ),
        "generated connect_tls rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Cap inbound messages at `limit` bytes. Default 4 MiB. Applies to every call shape,"
        ),
        "generated max_decoding rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Cap inbound messages at `limit` bytes. Default 4 MiB. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated server max_decoding rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Mount alongside another service. [`Self::max_decoding_message_size`] and [`Self::max_encoding_message_size`] stay in effect on every mounted service, on every call shape of those mounts, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated add_service rustdoc must name decode and encode caps on every mount and transport"
    );
    assert!(
        src.contains(
            "Mount `service` when `Some`. `None` is a no-op. Distinct from [`Self::add_service`], which always mounts. `None` does not replace a service already there. Services that stay mounted still complete every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]."
        ),
        "generated add_optional_service rustdoc must Distinct None from always-mount on every transport"
    );
    assert!(
        src.contains(
            "Cap outbound messages at `limit` bytes. Default unlimited. Applies to every call shape."
        ),
        "generated max_encoding rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Cap outbound messages at `limit` bytes. Default unlimited. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client max_encoding rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Cap inbound messages at `limit` bytes. Default 4 MiB. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated client max_decoding rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "Wait for a connection instead of failing fast. See [`::pbrs_grpc::Channel::wait_for_ready`]. Applies to every call shape."
        ),
        "generated wait_for_ready rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "A request that already called [`::pbrs_grpc::Request::set_wait_for_ready`] is left alone. Interceptors run after this fill and can still set or clear it."
        ),
        "generated wait_for_ready rustdoc must name interceptor set/clear"
    );
    assert!(
        src.contains(
            "Send `:scheme https` from a [`Self::from_io`] channel. See [`::pbrs_grpc::Channel::https_scheme`]. Applies to every call shape."
        ),
        "generated https_scheme rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Override `:authority` on this clone without changing the dial. See [`::pbrs_grpc::Channel::origin`]. Applies to every call shape."
        ),
        "generated origin rustdoc must name every call shape"
    );
    assert!(
        src.contains("A local [`::pbrs_grpc::Status::with_error_details`] is [`::pbrs_grpc::Status::rpc`] / [`::pbrs_grpc::Status::error_details`] on that Call for every call shape."),
        "generated client intercept rustdoc must name packed Status unpacking on local Err"
    );
    assert!(
        src.contains("Outgoing getters apply to every call shape."),
        "generated client intercept rustdoc must name Outgoing getters on every call shape"
    );
    assert!(
        src.contains(
            "The HTTP/2 `:authority` this client sends. See [`::pbrs_grpc::Channel::authority`]. Applies to every call shape."
        ),
        "generated authority rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "HTTP/2 `:scheme` this client sends. See [`::pbrs_grpc::Channel::scheme`]. Applies to every call shape."
        ),
        "generated scheme rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "The `user-agent` this client sends. See [`::pbrs_grpc::Channel::grpc_user_agent`]. Applies to every call shape."
        ),
        "generated grpc_user_agent rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Prefix the kernel `user-agent`. See [`::pbrs_grpc::Channel::user_agent`]. Applies to every call shape."
        ),
        "generated user_agent rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Default per-RPC deadline when the request omits one. See [`::pbrs_grpc::Channel::timeout`]. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]."
        ),
        "generated timeout rustdoc must name every transport"
    );
    assert!(
        src.contains(
            "[`Self::connect`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Whether any pool slot currently holds a live HTTP/2 connection. Distinct from gRPC `GetState`. See [`::pbrs_grpc::Channel::connected`]. Applies to every call shape."
        ),
        "generated connected rustdoc must Distinct GetState"
    );
    assert!(
        src.contains(
            "Client interceptors see the same snapshot as [`::pbrs_grpc::Outgoing::connected`]."
        ),
        "generated connected rustdoc must name the interceptor snapshot"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::wait_for_ready`]: that overlay queues; this getter is a live snapshot."
        ),
        "generated connected rustdoc must Distinct wait-for-ready overlay from the live snapshot"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::connected`]: that getter is a live snapshot, not this overlay."
        ),
        "generated waits_for_ready rustdoc must Distinct the live-socket snapshot"
    );
    assert!(
        src.contains(
            "Open `connections` slots. See [`::pbrs_grpc::Channel::connect_pool`]. Applies to every call shape."
        ),
        "generated connect_pool rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "TLS (including mTLS) pooling is [`Self::connect_tls_with`] plus [`::pbrs_grpc::ChannelConfig::connections`]; Unix is [`Self::connect_unix_with`]. [`::pbrs_grpc::Channel::from_io`] cannot pool."
        ),
        "generated connect_pool rustdoc must name TLS and Unix pooling"
    );
    assert!(
        src.contains(
            "A pool larger than the server's [`::pbrs_grpc::Server::max_concurrent_connections`] fails the dial as `UNAVAILABLE`."
        ),
        "generated connect_pool rustdoc must name pool-vs-cap UNAVAILABLE"
    );
    assert!(
        src.contains(
            "Dial a Unix domain socket. See [`::pbrs_grpc::Channel::connect_unix`]. Applies to every call shape."
        ),
        "generated connect_unix rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Speak gRPC over an already-connected byte stream. See [`::pbrs_grpc::Channel::from_io`]. Applies to every call shape."
        ),
        "generated from_io rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::from_io`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated from_io_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ChannelConfig::connections`] is forced to 1: one duplex is one HTTP/2 connection."
        ),
        "generated from_io_with rustdoc must name that pooling is forced to one duplex"
    );
    assert!(
        src.contains(
            "Bind `path` and serve h2c over a Unix domain socket. Applies to every call shape."
        ),
        "generated serve_unix rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Bind `path` after unlinking a crash leftover. A live listener is left alone and this fails with UNAVAILABLE. Applies to every call shape."
        ),
        "generated serve_unix_unlink rustdoc must name every call shape"
    );
    assert!(
        src.contains("HTTP/2 PING keepalive. Applies to every call shape."),
        "generated keep_alive_interval rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Send GOAWAY this long after accept. The next RPC of every call shape redials, including over TLS, mTLS, and Unix; transparent retry of the same in-flight RPC is unary and server-streaming after request bytes, client-streaming and bidi before HEADERS."
        ),
        "generated max_connection_age rustdoc must name redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "After age or idle fires, wait this long for in-flight RPCs, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Server::serve_connection`]. Applies to every call shape."
        ),
        "generated max_connection_age_grace rustdoc must name in-flight finish on every transport"
    );
    assert!(
        src.contains(
            "Send GOAWAY after this long with no outstanding RPCs. The next RPC of every call shape redials, including over TLS, mTLS, and Unix."
        ),
        "generated max_connection_idle rustdoc must name redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "Drop a client that never finishes TLS or the HTTP/2 preface. Applies to every call shape, including over TLS, mTLS, and Unix."
        ),
        "generated handshake_timeout rustdoc must name TLS, mTLS, and Unix"
    );
    assert!(
        src.contains("Serve h2c on an existing Unix listener. Applies to every call shape."),
        "generated serve_unix_listener rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Serve until `shutdown` resolves, then drain. Applies to every call shape. In-flight RPCs finish; new connections are refused. TLS and Unix drain the same way (`serve_tls_with_shutdown`, `serve_unix_with_shutdown`)."
        ),
        "generated serve_with_shutdown rustdoc must name TLS and Unix drain"
    );
    assert!(
        src.contains(
            "Serve over TLS until `shutdown` resolves, then drain. Applies to every call shape, including mTLS. In-flight RPCs finish; new connections are refused."
        ),
        "generated serve_tls_with_shutdown rustdoc must name mTLS drain"
    );
    assert!(
        src.contains(
            "Serve a single already-accepted byte stream until it closes. Applies to every call shape."
        ),
        "generated serve_connection rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Generated handlers see empty peer facts on [`::pbrs_grpc::Request`] / [`::pbrs_grpc::Parts`]; [`::pbrs_grpc::Rpc::scheme`] is the peer's `:scheme`."
        ),
        "generated serve_connection rustdoc must name empty Request/Parts peer facts"
    );
    assert!(
        src.contains(
            "Bind `addr` and serve until the listener fails. Applies to every call shape."
        ),
        "generated serve rustdoc must name every call shape"
    );
    assert!(
        src.contains("Serve on an existing listener until it fails. Applies to every call shape."),
        "generated serve_listener rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "Dial `target` (`host:port`, not a tonic `http://` / `https://` URI). See [`::pbrs_grpc::Channel::connect`]. Applies to every call shape."
        ),
        "generated connect rustdoc must Distinct tonic URI from Target host:port"
    );
    assert!(
        src.contains(
            "Dial on the first RPC. See [`::pbrs_grpc::Channel::connect_lazy`]. Applies to every call shape."
        ),
        "generated connect_lazy rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_unix`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_unix_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ChannelConfig::connections`] opens that many Unix sockets; all must succeed. [`::pbrs_grpc::Channel::from_io`] cannot pool."
        ),
        "generated connect_unix_with rustdoc must name Unix pooling"
    );
    assert!(
        src.contains(
            "[`Self::connect_unix`] that dials on the first RPC. Applies to every call shape."
        ),
        "generated connect_unix_lazy rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_tls`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_tls_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`::pbrs_grpc::ChannelConfig::connections`] opens that many TLS sockets (including mTLS); all must succeed. [`::pbrs_grpc::Channel::from_io`] cannot pool."
        ),
        "generated connect_tls_with rustdoc must name TLS pooling"
    );
    assert!(
        src.contains(
            "[`Self::connect_lazy`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_lazy_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_lazy`] over TLS. See [`::pbrs_grpc::Channel::connect_tls_lazy`]. Applies to every call shape."
        ),
        "generated connect_tls_lazy rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_tls_lazy`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_tls_lazy_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "[`Self::connect_unix_lazy`] with [`::pbrs_grpc::ChannelConfig`]. Applies to every call shape."
        ),
        "generated connect_unix_lazy_with rustdoc must name every call shape"
    );
    assert!(
        src.contains(
            "How many messages sit between a client-streaming caller and the wire. See [`::pbrs_grpc::Channel::stream_buffer`]. Applies to client-streaming and bidi request streams."
        ),
        "generated stream_buffer rustdoc must name the streaming shapes it queues"
    );
    assert!(
        src.contains(
            "Configured outbound streaming queue depth. Distinct from [`Self::stream_buffer`], which sets it."
        ),
        "generated stream_buffer_size rustdoc must Distinct the setter"
    );
    assert!(
        src.contains(
            "Write-time HTTP/2 send buffer threshold for outbound DATA. See [`::pbrs_grpc::Channel::max_send_buffer_size`]. Applies to every call shape, including over TLS, mTLS, Unix, and [`::pbrs_grpc::Channel::from_io`]. Overlay: does not change how a dead slot is redialed."
        ),
        "generated client max_send_buffer_size rustdoc must name the write-time DATA overlay"
    );
    assert!(
        src.contains(
            "Configured write-time HTTP/2 send buffer. Distinct from [`Self::max_send_buffer_size`], which sets it. Distinct from [`Self::stream_buffer_size`]: that is queue depth, not this send buffer."
        ),
        "generated send_buffer_size rustdoc must Distinct the setter and queue depth"
    );
    assert!(
        src.contains(
            "Configured write-time HTTP/2 send buffer. Distinct from [`Self::max_send_buffer_size`], which sets it. Distinct from [`Self::message_limits`]: that is uncompressed protobuf bytes, not this send buffer."
        ),
        "generated server send_buffer_size rustdoc must Distinct the setter and message size"
    );
    assert!(
        src.contains(
            "Configured message caps. Distinct from [`Self::message_limits`], which sets them. Distinct from [`Self::stream_buffer_size`]: that is queue depth, not uncompressed protobuf bytes. Distinct from [`Self::send_buffer_size`]: that is the HTTP/2 send buffer, not these caps."
        ),
        "generated client limits rustdoc must Distinct the setter, queue depth, and send buffer"
    );
    assert!(
        src.contains(
            "Configured message caps. Distinct from [`Self::message_limits`], which sets them. Distinct from [`Self::send_buffer_size`]: that is the HTTP/2 send buffer, not uncompressed protobuf bytes."
        ),
        "generated server limits rustdoc must Distinct the setter and send buffer"
    );
    assert!(
        src.contains("[`Self::send_buffer_size`], and [`Self::limits`] read that overlay without colliding with the setters."),
        "generated client rustdoc must name limits as a colliding-free overlay getter"
    );
    assert!(
        src.contains("[`Self::connected`] is the live-socket snapshot. Distinct from [`Self::waits_for_ready`]. Same snapshot as [`::pbrs_grpc::Channel::connected`]."),
        "generated client rustdoc must name connected as the live-socket snapshot Distinct from waits_for_ready"
    );
    assert!(
        src.contains("[`Self::send_buffer_size`], and [`Self::limits`] read the server overlay without colliding with the setters."),
        "generated server rustdoc must name limits as a colliding-free overlay getter"
    );
}
