fn channel_config_connect_timeout_documents_every_call_shape() {
    let src = include_str!("../src/config.rs");
    assert!(
        src.contains(
            "This is a dial bound, not an RPC overlay. Every call shape uses the\n    /// same bound when the channel actually dials (eager `connect`, a lazy\n    /// first RPC, or a reconnect). Applies to every call shape once that\n    /// dial happens."
        ),
        "ChannelConfig::connect_timeout must name every call shape as a dial bound"
    );
    assert!(
        src.contains(
            "never speaks HTTP/2\n    /// (or never finishes TLS, including mTLS) fails with\n    /// [`crate::Code::Unavailable`] instead of hanging [`crate::Channel::connect`]\n    /// / [`crate::Channel::connect_tls`] / [`crate::Channel::connect_unix`] forever."
        ),
        "ChannelConfig::connect_timeout must name TLS, mTLS, and Unix hang"
    );
    assert!(
        src.contains(
            "Connection refused still fails immediately on those dialers; this bound is\n    /// for the hang, not the bounce."
        ),
        "ChannelConfig::connect_timeout must name refused-connect fail-fast on TLS and Unix"
    );
    assert!(
        src.contains(
            "`TCP_NODELAY` is always on for TCP connect and accept (Nagle off).\n    /// There is no `tcp_nodelay(bool)` setter. Distinct from tonic, which"
        ),
        "ChannelConfig/ServerConfig::tcp_keepalive must Distinct TCP_NODELAY always-on from tonic"
    );
    assert_eq!(
        src.matches("`TCP_NODELAY` is always on for TCP connect and accept (Nagle off).")
            .count(),
        2,
        "ServerConfig and ChannelConfig tcp_keepalive must both name TCP_NODELAY"
    );
    assert!(
        src.contains(
            "Only applied when [`Self::tcp_keepalive`] is also set; this does\n    /// not turn `SO_KEEPALIVE` on by itself. Probe retry count is\n    /// [`Self::tcp_keepalive_retries`] (`TCP_KEEPCNT`); this interval does\n    /// not set it. Only TCP sockets are affected; Unix domain sockets and\n    /// [`crate::Channel::from_io`] streams are not.\n    ///\n    /// Distinct from [`Self::keep_alive_interval`], which sends HTTP/2 PINGs.\n    /// Distinct from [`Self::tcp_keepalive`], which is idle time before the\n    /// first probe (`TCP_KEEPIDLE`)."
        ),
        "ChannelConfig/ServerConfig::tcp_keepalive_interval must Distinct TCP_KEEPINTVL from HTTP/2 PING and from idle SO_KEEPALIVE"
    );
    assert_eq!(
        src.matches("not turn `SO_KEEPALIVE` on by itself. Probe retry count is")
            .count(),
        2,
        "ServerConfig and ChannelConfig tcp_keepalive_interval must both Distinct idle enable"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::tcp_keepalive_interval`], which is probe\n    /// spacing (`TCP_KEEPINTVL`), not how many probes. Distinct from\n    /// [`Self::keep_alive_interval`], which sends HTTP/2 PINGs."
        ),
        "ChannelConfig/ServerConfig::tcp_keepalive_retries must Distinct TCP_KEEPCNT from TCP_KEEPINTVL time"
    );
    assert_eq!(
        src.matches("spacing (`TCP_KEEPINTVL`), not how many probes.")
            .count(),
        2,
        "ServerConfig and ChannelConfig tcp_keepalive_retries must both Distinct count from interval"
    );
    assert!(
        src.contains(
            "mTLS bind the TCP socket first, then handshake. Unix domain sockets\n    /// and [`crate::Channel::from_io`] skip this bind: those streams are not\n    /// TCP."
        ),
        "ChannelConfig::local_address must skip Unix and from_io"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Rpc::local_addr`] / [`crate::Request::local_addr`]:\n    /// those are the accepted interface after the handshake, not this source\n    /// bind. Distinct from tonic's `Endpoint::local_address`, which takes an\n    /// `IpAddr` and always binds port 0. There is no live\n    /// `Channel::local_address` setter: this overlay is handshake-only."
        ),
        "ChannelConfig::local_address must Distinct Rpc::local_addr and tonic Endpoint::local_address"
    );
    assert!(
        src.contains("Distinct from [`Self::local_address`], which sets it."),
        "ChannelConfig::bound_local_address must Distinct the setter"
    );
    assert!(
        src.contains("a long-running stream is not idle, but"),
        "ChannelConfig::max_connection_age must Distinct idle from age"
    );
    assert!(
        src.contains(
            "shape redial, including over TLS, mTLS, and Unix, except on\n    /// [`crate::Channel::from_io`], which cannot redial and fails with"
        ),
        "ChannelConfig::max_connection_age must name client age redial on TLS, mTLS, and Unix"
    );
    let channel = concat!(
        include_str!("../src/client.rs"),
        include_str!("../src/client/channel.rs"),
        include_str!("../src/client/call.rs"),
        include_str!("../src/client/config_glue.rs"),
        include_str!("../src/client/pool.rs"),
        include_str!("../src/client/retry.rs"),
        include_str!("../src/client/streaming.rs"),
        include_str!("../src/client/unary.rs"),
    );
    let tls = include_str!("../src/tls.rs");
    let health = include_str!("../src/health.rs");
    let intercept = include_str!("../src/interceptor.rs");
    assert!(
        channel.contains("does not postpone age. The next RPC of every call shape redials"),
        "Channel rustdoc must name client max_connection_age redial"
    );
    assert!(
        channel.contains("Keepalive PINGs do not postpone age."),
        "Channel rustdoc must Distinct keepalive PINGs from postponing age"
    );
    assert!(
        channel.contains(
            "Certificate and protocol failures (rustls `InvalidData`) are\n    /// [`Code::Unauthenticated`]. Distinct from [`Status`]'s\n    /// `From<std::io::Error>`: that maps local I/O `InvalidData` to\n    /// [`Code::Internal`]."
        ),
        "Channel::connect_tls must Distinct handshake InvalidData Unauthenticated from local I/O Internal"
    );
    assert!(
        channel.contains(
            "[`std::io::ErrorKind::AddrNotAvailable`] is that same dropped-socket\n    /// set (unroutable bind), Distinct from leftover kinds which stay\n    /// [`Code::Unauthenticated`]."
        ),
        "Channel::connect_tls must Distinct handshake AddrNotAvailable Unavailable from leftover Unauthenticated"
    );
    assert!(
        channel.contains(
            "[`ChannelConfig::local_address`] binds the TCP source before connect\n/// (TLS and mTLS included). Unix and [`Self::from_io`] skip that bind.\n/// Distinct from [`crate::Rpc::local_addr`], which is the accepted"
        ),
        "Channel rustdoc must Distinct local_address bind from Rpc::local_addr"
    );
    assert!(
        channel.contains(
            "Distinct from tonic's `Endpoint::origin`, which takes a `Uri` and\n    /// also sets `:scheme`; scheme on this kernel is [`Self::connect_tls`]\n    /// or [`Self::https_scheme`]."
        ),
        "Channel::origin must Distinct tonic Endpoint::origin Uri scheme"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithAuthority`: that sets `:authority` and the\n    /// TLS authentication server name. This overlay is `:authority` only.\n    /// Distinct from [`crate::ClientTls`] (SNI / certificate name). Distinct\n    /// from tonic `Endpoint::origin` (Uri, also `:scheme`). There is no\n    /// `CallAuthority`: interceptors cannot override `:authority` per call."
        ),
        "Channel::origin rustdoc must Distinct :authority-only overlay from grpc-go WithAuthority TLS server name"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithAuthority`")
            .count(),
        1,
        "Channel::authority must not copy the WithAuthority Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithConnectParams`: that is exponential reconnect\n    /// backoff plus `MinConnectTimeout` for creating and maintaining\n    /// connections. A dead slot is redialed on the next RPC with no\n    /// channel-level reconnect backoff. There is no `WithBackoffMaxDelay` /\n    /// `WithBackoffConfig` (deprecated aliases). Distinct from\n    /// [`Self::wait_for_ready`] (handshake retries at `[20, 40, 80, 160, 320,\n    /// 640, 1000]` ms, not channel reconnect). Distinct from\n    /// [`ChannelConfig::connect_timeout`] (max dial bound, default 20 s; not\n    /// grpc-go `MinConnectTimeout`, also default 20 s). Distinct from\n    /// transparent retry (one redial of the same RPC, not connect backoff)."
        ),
        "Channel::connect_with rustdoc must Distinct next-RPC redial from grpc-go WithConnectParams reconnect backoff"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithConnectParams`")
            .count(),
        1,
        "Channel::connect must not copy the WithConnectParams Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithNoProxy`: grpc-go honors `HTTPS_PROXY` by\n/// default; that DialOption disables it. TCP dials consult `HTTPS_PROXY`\n/// / `NO_PROXY` and tunnel through HTTP CONNECT; there is no per-channel\n/// proxy disable. There is no\n/// `WithLocalDNSResolution`: that resolves locally so the proxy CONNECT\n/// sees an IP. Distinct from [`Self::from_io`] (already-connected bytes,\n/// not a proxy bypass). Distinct from [`Self::connect_unix`] (filesystem\n/// path; this dialer is skipped). Distinct from\n/// [`ChannelConfig::local_address`] (source bind, not proxy)."
        ),
        "Channel rustdoc must Distinct direct TCP dial from grpc-go WithNoProxy HTTPS_PROXY"
    );
    assert_eq!(
        channel.matches("There is no grpc-go `WithNoProxy`").count(),
        1,
        "Channel::connect must not copy the WithNoProxy Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithInsecure`: modern grpc-go `NewClient` requires\n    /// credentials (`insecure.NewCredentials()` or TLS). [`Self::connect`] is\n    /// h2c by default; TLS is this constructor. There is no\n    /// `WithTransportCredentials` DialOption (TLS is this constructor plus\n    /// [`crate::ClientTls`]). Distinct from a skip-verify constructor (there\n    /// is none). Distinct from [`Self::https_scheme`] (`from_io` label; it\n    /// does not handshake)."
        ),
        "Channel::connect_tls rustdoc must Distinct h2c-default connect from grpc-go WithInsecure credentials"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithInsecure`")
            .count(),
        1,
        "Channel::connect_tls_with must not copy the WithInsecure Distinct"
    );
    assert!(
        channel.contains(
            "There is no tonic `Endpoint::connect_with_connector`: that is a tower\n    /// `Service<Uri>` that still dials. This stream is already connected; there\n    /// is no connector and no URI. Distinct from [`Self::connect_unix`]\n    /// (filesystem path, not a connector). [`ChannelConfig::connect_timeout`]\n    /// still bounds the HTTP/2 preface. Distinct from `tower` integration,\n    /// which is protobuf-tonic keeping tonic."
        ),
        "Channel::from_io rustdoc must Distinct already-connected bytes from tonic Endpoint::connect_with_connector"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithBlock` DialOption: that makes deprecated\n    /// `Dial` wait until READY. This constructor already waits for the TCP\n    /// dial and HTTP/2 preface; there is no READY state. Distinct from\n    /// [`Self::connect_lazy`] (first RPC dials). Distinct from\n    /// [`Self::wait_for_ready`] (RPC queue, not Dial). Distinct from\n    /// [`Self::connected`] (live-socket snapshot). Distinct from gRPC\n    /// `GetState` / `WaitForStateChange`. There is no\n    /// `WithReturnConnectionError`: handshake failure is the returned\n    /// [`Status`]."
        ),
        "Channel::connect rustdoc must Distinct handshake wait from grpc-go WithBlock READY"
    );
    assert_eq!(
        channel.matches("There is no grpc-go `WithBlock`").count(),
        1,
        "Channel::connect_lazy must not copy the WithBlock Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithDisableRetry` DialOption: that disables\n/// service-config retries and does not impact transparent retries.\n/// Service-config `retryPolicy`/`hedgingPolicy` attach with\n/// [`Self::service_config`]; omit the document (or the method's policy) for\n/// no policy retries, in which case application retries stay at the call\n/// site ([`Code::is_retryable`]). Transparent retry cannot be turned off.\n/// Distinct from [`Self::from_io`] (no transparent retry)."
        ),
        "Channel rustdoc must Distinct transparent retry from grpc-go WithDisableRetry"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithDisableRetry`")
            .count(),
        1,
        "Channel::connect must not copy the WithDisableRetry Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithMaxCallAttempts`: that caps retries and hedging\n/// per call (default 5; values below 2 become 5). Here `maxAttempts` comes\n/// from the method's `retryPolicy`/`hedgingPolicy` (values above 5 count as\n/// 5); transparent retry is at most once on top and cannot be raised.\n/// Distinct from [`Code::is_retryable`] (application retries at the call\n/// site, unbounded by this kernel)."
        ),
        "Channel rustdoc must Distinct at-most-once transparent retry from grpc-go WithMaxCallAttempts"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithMaxCallAttempts`")
            .count(),
        1,
        "Channel::connect must not copy the WithMaxCallAttempts Distinct"
    );
    assert!(
        tls.contains(
            "tonic `Endpoint::tls_config_with_verifier` replaces WebPKI with a custom\n    /// rustls `ServerCertVerifier`. This constructor always verifies against\n    /// Mozilla's CA set. [`Self::from_rustls`] retains a trusted application's\n    /// configuration and verification policy; it cannot certify a custom\n    /// verifier's security. `ClientTls::native_roots` uses operating-system\n    /// roots with the `native-roots` feature, and [`Self::ca`] pins a CA.\n    /// Disabling verification is unsupported."
        ),
        "ClientTls::webpki rustdoc must Distinct WebPKI verify from tonic tls_config_with_verifier"
    );
    assert_eq!(
        tls.matches("tonic `Endpoint::tls_config_with_verifier` replaces WebPKI")
            .count(),
        1,
        "ClientTls::webpki_mtls must not copy the tls_config_with_verifier Distinct"
    );
    assert!(
        tls.contains(
            "There is no grpc-go `WithPerRPCCredentials`: that is a DialOption plugging\n/// `credentials.PerRPCCredentials` that add per-RPC metadata. This type is\n/// transport TLS, not call credentials. There is no `WithCredentialsBundle`\n/// (transport plus per-RPC credentials). Distinct from GCP-auth (a library,\n/// not this DialOption). Distinct from grpc-go `WithTransportCredentials`\n/// (transport; TLS is [`crate::Channel::connect_tls`] plus this type). Distinct\n/// from [`crate::ClientInterceptor`] (user hook that can add metadata, not a\n/// credentials plugin). Distinct from [`crate::Channel::intercept`] (attaches\n/// that hook after connect)."
        ),
        "ClientTls rustdoc must Distinct transport TLS from grpc-go WithPerRPCCredentials call credentials"
    );
    assert_eq!(
        tls.matches("There is no grpc-go `WithPerRPCCredentials`")
            .count(),
        1,
        "ClientTls::webpki must not copy the WithPerRPCCredentials Distinct"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithPerRPCCredentials`")
            .count(),
        0,
        "Channel::connect_tls must not copy the WithPerRPCCredentials Distinct"
    );
    assert_eq!(
        intercept
            .matches("There is no grpc-go `WithPerRPCCredentials`")
            .count(),
        0,
        "ClientInterceptor must not copy the WithPerRPCCredentials Distinct"
    );
    assert!(
        tls.contains(
            "Use [`Self::optional_mtls`] for tonic-style optional client auth. This\n    /// constructor always requires a client certificate issued by that CA.\n    /// Distinct from [`Self::new`] (clients are not asked). Distinct from a\n    /// skip-verify constructor (there is none). Distinct from\n    /// [`ClientTls::ca_mtls`] / [`ClientTls::webpki_mtls`] (client presents;\n    /// this is the server require)."
        ),
        "ServerTls::mtls rustdoc must Distinct required client cert from tonic client_auth_optional"
    );
    assert_eq!(
        tls.matches("Use [`Self::optional_mtls`] for tonic-style optional client auth.")
            .count(),
        1,
        "ServerTls::new must not copy the client_auth_optional Distinct"
    );
    assert!(
        tls.contains(
            "There is no tonic `ServerTlsConfig::timeout`: that is a TLS-handshake-only\n/// timeout on the tonic acceptor. This type has no timeout setter; the bound is\n/// [`crate::ServerConfig::handshake_timeout`] (20 s TLS accept and 20 s HTTP/2\n/// preface, separately). Distinct from grpc-go `ConnectionTimeout` (one 120 s\n/// deadline covering both). Distinct from [`crate::ChannelConfig::connect_timeout`]\n/// (client whole dial). Distinct from tonic `ClientTlsConfig::timeout` (client\n/// TLS handshake). Distinct from [`crate::ServerConfig::timeout`] (RPC deadline\n/// overlay)."
        ),
        "ServerTls rustdoc must Distinct sequential handshake caps from tonic ServerTlsConfig::timeout TLS-only"
    );
    assert_eq!(
        tls.matches("There is no tonic `ServerTlsConfig::timeout`")
            .count(),
        1,
        "ServerTls::mtls must not copy the ServerTlsConfig::timeout Distinct"
    );
    assert_eq!(
        src.matches("There is no tonic `ServerTlsConfig::timeout`")
            .count(),
        0,
        "ServerConfig::handshake_timeout must not copy the ServerTlsConfig::timeout Distinct"
    );
    assert_eq!(
        channel
            .matches("There is no tonic `ServerTlsConfig::timeout`")
            .count(),
        0,
        "Channel must not copy the ServerTlsConfig::timeout Distinct"
    );
    assert_eq!(
        intercept
            .matches("There is no tonic `ServerTlsConfig::timeout`")
            .count(),
        0,
        "ClientInterceptor must not copy the ServerTlsConfig::timeout Distinct"
    );
    assert!(
        tls.contains(
            "This constructor does not enable rustls key logging; call\n    /// [`Self::key_log_file`] to opt into `SSLKEYLOGFILE` for local debugging.\n    /// Distinct from tonic `ClientTlsConfig::use_key_log` (client handshake).\n    /// Distinct from [`Self::mtls`] (client cert require) and\n    /// [`Self::optional_mtls`] (client cert requested but optional). Distinct\n    /// from a skip-verify constructor (there is none)."
        ),
        "ServerTls::new rustdoc must Distinct no key log from tonic ServerTlsConfig::use_key_log"
    );
    assert_eq!(
        tls.matches("to opt into `SSLKEYLOGFILE` for local debugging.")
            .count(),
        1,
        "ServerTls::mtls must not copy the use_key_log Distinct"
    );
    assert_eq!(
        src.matches("There is no tonic `ServerTlsConfig::use_key_log`")
            .count(),
        0,
        "ServerConfig must not copy the use_key_log Distinct"
    );
    assert_eq!(
        channel
            .matches("There is no tonic `ServerTlsConfig::use_key_log`")
            .count(),
        0,
        "Channel must not copy the use_key_log Distinct"
    );
    assert_eq!(
        intercept
            .matches("There is no tonic `ServerTlsConfig::use_key_log`")
            .count(),
        0,
        "ClientInterceptor must not copy the use_key_log Distinct"
    );
    assert!(
        tls.contains(
            "There is no tonic `ClientTlsConfig::assume_http2`: that skips ALPN and\n    /// still treats the socket as HTTP/2. This constructor always requires ALPN\n    /// `h2` after handshake. Distinct from [`crate::Channel::connect`] (h2c, no\n    /// TLS). Distinct from grpc-web / HTTP/1.1 (not prior-knowledge HTTP/2 on\n    /// TLS). Distinct from [`crate::ServerTls`] (server ALPN require; this is\n    /// the client require). Distinct from a skip-verify constructor (there is\n    /// none)."
        ),
        "ClientTls::ca rustdoc must Distinct required ALPN h2 from tonic ClientTlsConfig::assume_http2"
    );
    assert_eq!(
        tls.matches("There is no tonic `ClientTlsConfig::assume_http2`")
            .count(),
        1,
        "ClientTls::webpki must not copy the assume_http2 Distinct"
    );
    assert_eq!(
        src.matches("There is no tonic `ClientTlsConfig::assume_http2`")
            .count(),
        0,
        "ChannelConfig must not copy the assume_http2 Distinct"
    );
    assert_eq!(
        channel
            .matches("There is no tonic `ClientTlsConfig::assume_http2`")
            .count(),
        0,
        "Channel::connect_tls must not copy the assume_http2 Distinct"
    );
    assert_eq!(
        intercept
            .matches("There is no tonic `ClientTlsConfig::assume_http2`")
            .count(),
        0,
        "ClientInterceptor must not copy the assume_http2 Distinct"
    );
    assert_eq!(
        intercept
            .matches("There is no tonic `Server::trace_fn`")
            .count(),
        0,
        "ClientInterceptor must not copy the Server::trace_fn Distinct"
    );
    assert_eq!(
        src.matches("There is no tonic `Server::trace_fn`").count(),
        0,
        "ServerConfig must not copy the Server::trace_fn Distinct"
    );
    assert_eq!(
        tls.matches("There is no tonic `Server::trace_fn`").count(),
        0,
        "ServerTls must not copy the Server::trace_fn Distinct"
    );
    assert_eq!(
        channel
            .matches("There is no tonic `Server::trace_fn`")
            .count(),
        0,
        "Channel must not copy the Server::trace_fn Distinct"
    );
    assert!(
        health.contains(
            "There is no grpc-go `WithDisableHealthCheck`: that disables LB channel\n/// health checking for all SubConns. This reporter is `grpc.health.v1`\n/// serving status; [`crate::Channel`] does not run LB health probes.\n/// Distinct from [`Self::shutdown`] (serving status, not a DialOption).\n/// Distinct from [`crate::Server::serve_with_shutdown`] (drain wait, not\n/// health probes). Distinct from [`crate::Channel::connect`] (one duplex,\n/// no SubConns)."
        ),
        "HealthReporter rustdoc must Distinct grpc.health.v1 serving status from grpc-go WithDisableHealthCheck"
    );
    assert_eq!(
        health
            .matches("There is no grpc-go `WithDisableHealthCheck`")
            .count(),
        1,
        "HealthReporter::shutdown must not copy the WithDisableHealthCheck Distinct"
    );
    assert!(
        intercept.contains(
            "There is no grpc-go `WithUnaryInterceptor`: that is a DialOption for\n/// unary RPCs only. `WithStreamInterceptor` is the stream split.\n/// `WithChainUnaryInterceptor` / `WithChainStreamInterceptor` append\n/// DialOption lists. This trait is one hook for every call shape, attached\n/// with [`crate::Channel::intercept`] after connect (not a DialOption).\n/// Calling intercept twice stacks; there is no chain DialOption. Distinct\n/// from [`Interceptor`] (inbound before the handler). Distinct from\n/// [`ResponseInterceptor`] (after Ok or after receive). Distinct from\n/// tonic `Interceptor` / `InterceptorLayer` (tower; this kernel has no\n/// tower)."
        ),
        "ClientInterceptor rustdoc must Distinct one hook for every call shape from grpc-go WithUnaryInterceptor DialOption split"
    );
    assert_eq!(
        intercept
            .matches("There is no grpc-go `WithUnaryInterceptor`")
            .count(),
        1,
        "Interceptor must not copy the WithUnaryInterceptor Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithDefaultCallOptions`: that is a DialOption bag of\n/// per-call options (`WaitForReady`, `MaxCallRecvMsgSize`, compressor, …)\n/// applied as channel defaults. These methods are typed overlays on this\n/// clone, not a `CallOption` list and not a DialOption. Distinct from\n/// grpc-go `WithDefaultServiceConfig` (JSON service config, not CallOptions).\n/// Distinct from [`ChannelConfig`] (handshake `Copy` fields). Distinct from\n/// [`Self::intercept`] (per-RPC mutation after connect)."
        ),
        "Channel rustdoc must Distinct typed clone overlays from grpc-go WithDefaultCallOptions bag"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithDefaultCallOptions`")
            .count(),
        1,
        "Channel::timeout must not copy the WithDefaultCallOptions Distinct"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithDefaultCallOptions`")
            .count(),
        0,
        "ChannelConfig must not copy the WithDefaultCallOptions Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithCompressor`: that is a DialOption plugging a\n    /// custom `encoding.Compressor` (deprecated; `encoding.RegisterCompressor`\n    /// is global). This overlay is gzip on or off, not a compressor plugin.\n    /// There is no `WithDecompressor` (deprecated inbound plugin). Distinct\n    /// from encodings other than gzip (`UNIMPLEMENTED`, not a plugin). Distinct\n    /// from [`Self::gzip_compression_level`] (deflate effort, not a plugin).\n    /// Distinct from grpc-go `UseCompressor` (a CallOption name, not this\n    /// overlay)."
        ),
        "Channel::send_compressed rustdoc must Distinct gzip on/off from grpc-go WithCompressor plugin"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithCompressor`")
            .count(),
        1,
        "Channel::gzip_compression_level must not copy the WithCompressor Distinct"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithCompressor`").count(),
        0,
        "ChannelConfig::send_compressed must not copy the WithCompressor Distinct"
    );
    assert!(
        channel.contains(
            "There is no grpc-go `WithContextDialer`: that is a DialOption plugging a\n    /// custom `func(context.Context, string) (net.Conn, error)` that still\n    /// dials. `WithDialer` is the deprecated context-less form. The first RPC\n    /// still dials TCP `host:port`; there is no replacement hook. Distinct from\n    /// tonic `Endpoint::connect_with_connector` (tower `Service<Uri>` that still\n    /// dials). Distinct from [`Self::from_io`] (already-connected bytes; it\n    /// does not dial). Distinct from [`Self::connect_unix`] (filesystem path,\n    /// not a custom TCP dialer). Distinct from [`ChannelConfig::local_address`]\n    /// (source bind, still this kernel's TCP dialer). Distinct from grpc-go\n    /// `WithNoProxy` (proxy bypass, not a dial function). Distinct from grpc-go\n    /// `WithBlock` (handshake wait, not a dial function)."
        ),
        "Channel::connect_lazy rustdoc must Distinct kernel TCP dial from grpc-go WithContextDialer"
    );
    assert_eq!(
        channel
            .matches("There is no grpc-go `WithContextDialer`")
            .count(),
        1,
        "Channel::from_io must not copy the WithContextDialer Distinct"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithContextDialer`")
            .count(),
        0,
        "ChannelConfig::local_address must not copy the WithContextDialer Distinct"
    );
    assert!(
        channel.contains(
            "Distinct from tonic's `Endpoint`, which takes an `http://` /\n/// `https://` URI and infers TLS from the scheme. This kernel does\n/// not parse that URI: TLS is [`Channel::connect_tls`] plus"
        ),
        "Target rustdoc must Distinct tonic Endpoint URI TLS inference from connect_tls"
    );
    assert!(
        channel.contains(
            "[`Code::Unavailable`]. Distinct from tonic's\n/// `Endpoint::from_static`, which is that URI constructor."
        ),
        "Target rustdoc must Distinct tonic Endpoint::from_static URI constructor"
    );
    assert!(
        channel.contains(
            "Distinct from grpc-go `NewClient(\"dns:///host:port\")`, which takes\n/// a resolver URI (`dns:///` / `passthrough:///` / `xds:///`). Those\n/// are [`Code::InvalidArgument`] at connect, not a silent resolver."
        ),
        "Target rustdoc must Distinct grpc-go NewClient resolver URIs from silent xDS"
    );
    assert!(
        channel.contains(
            "Distinct from grpc-go `unix-abstract://`, which names a Linux\n/// abstract Unix socket. That is [`Code::InvalidArgument`] at connect,\n/// not a silent `\\0`-prefixed Unix dial. Distinct from tonic `unix://`"
        ),
        "Target rustdoc must Distinct grpc-go unix-abstract:// from tonic unix:// and connect_unix"
    );
    assert!(
        channel.contains(
            "Distinct from a `grpc://` / `grpcs://` URI, which some stacks use as\n/// an h2c / TLS gRPC target. That is [`Code::InvalidArgument`] at connect,\n/// not a silent strip of the scheme and not a silent\n/// [`Channel::connect_tls`]. Distinct from tonic `https://`"
        ),
        "Target rustdoc must Distinct grpc:// from tonic https:// TLS inference and Unavailable"
    );
    assert!(
        channel.contains(
            "[`ChannelConfig::connections`] pools to one `host:port`; it does\n/// not speak xDS."
        ),
        "Target rustdoc must Distinct ChannelConfig::connections from xDS"
    );
    assert!(
        channel.contains(
            "Distinct from tonic's `Endpoint::from_static`, which takes an\n    /// `http://` / `https://` URI: [`Target`] is `host:port` (see [`Target`])."
        ),
        "Channel::connect must Distinct tonic Endpoint::from_static URI from Target host:port"
    );
    assert!(
        channel.contains(
            "Distinct from grpc-go `NewClient(\"dns:///host:port\")`: still\n    /// `host:port`, not a resolver URI (see [`Target`])."
        ),
        "Channel::connect must Distinct grpc-go NewClient dns URI from Target host:port"
    );
    assert!(
        channel.contains(
            "[`Self::https_scheme`] (for [`Self::from_io`]), and [`Self::origin`]\n/// overlay this clone."
        ),
        "Channel rustdoc must name origin as a clone overlay next to https_scheme"
    );
    assert!(
        channel.contains("keepalive, local bind, connection count"),
        "Channel rustdoc must name local bind as handshake-only"
    );
    assert!(
        channel.contains("protocol-error RST cap are set at handshake"),
        "Channel rustdoc must name protocol-error RST cap as handshake-only"
    );
    assert!(
        channel.contains("the HPACK table"),
        "Channel rustdoc must name HPACK table as handshake-only"
    );
    assert!(
        channel.contains("small-DATA budget"),
        "Channel rustdoc must name small-DATA budget as handshake-only"
    );
    assert!(
        channel.contains("locally-reset stream memory"),
        "Channel rustdoc must name locally-reset stream memory as handshake-only"
    );
    assert!(
        channel.contains("[`Self::send_compressed`], [`Self::gzip_compression_level`]"),
        "Channel rustdoc must overlay gzip_compression_level with send_compressed"
    );
    assert!(
        channel.contains("Distinct from [`Self::send_compressed`], which is on or off."),
        "Channel::gzip_compression_level must Distinct deflate effort from on/off"
    );
    assert!(
        src.contains(
            "Open `n` independent HTTP/2 connections and spread RPCs round-robin.\n    /// Applies to every call shape, including over TLS, mTLS, and Unix.\n    /// [`crate::Channel::from_io`] cannot pool: [`crate::Channel::from_io_with`]\n    /// forces `connections` to 1."
        ),
        "ChannelConfig::connections must name every call shape"
    );
    assert!(
        src.contains(
            "All of them must succeed: a pool larger than the server's\n    /// [`crate::Server::max_concurrent_connections`] fails the dial as\n    /// [`crate::Code::Unavailable`]."
        ),
        "ChannelConfig::connections must name pool-vs-cap UNAVAILABLE on every transport"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::executor` setter: that is `SharedExec` on\n    /// tonic's hyper stack. Each pooled connection's `h2` driver is\n    /// `tokio::spawn`ed on the current tokio runtime. This kernel is not a\n    /// hyper/tower stack. [`Self`] is `Copy`, so it cannot store a non-`Copy`\n    /// executor. Distinct from `tower` integration, which is protobuf-tonic\n    /// keeping tonic. Distinct from [`Self::max_concurrent_rpcs`]: that is\n    /// in-flight slots, not where tasks run."
        ),
        "ChannelConfig::connections rustdoc must Distinct h2 driver spawn from tonic Endpoint::executor SharedExec"
    );
    assert!(
        src.contains(
            "Applies to every call shape, including when set on\n    /// [`crate::Channel::connect_tls_with`] / [`crate::Channel::connect_unix_with`]\n    /// / [`crate::Channel::from_io_with`]. Distinct from wrapping a live\n    /// [`crate::Channel`] with [`crate::Channel::max_decoding_message_size`]."
        ),
        "ChannelConfig::max_decoding_message_size must name dial-time overlay on every transport"
    );
    assert!(
        src.contains(
            "Applies to every call shape, including when set on\n    /// [`crate::Channel::connect_tls_with`] / [`crate::Channel::connect_unix_with`]\n    /// / [`crate::Channel::from_io_with`]. Distinct from wrapping a live\n    /// [`crate::Channel`] with [`crate::Channel::max_encoding_message_size`]."
        ),
        "ChannelConfig::max_encoding_message_size must name dial-time overlay on every transport"
    );
    assert!(
        src.contains(
            "Dial-time overlay on [`crate::Channel::connect_tls_with`] /\n    /// [`crate::Channel::connect_unix_with`] / [`crate::Channel::from_io_with`].\n    /// Distinct from [`Self::max_encoding_message_size`] /\n    /// [`Self::max_decoding_message_size`]."
        ),
        "ChannelConfig::message_limits must name dial-time combined setter on every transport"
    );
    assert!(
        src.contains(
            "Oversize response headers or trailers are refused, including over TLS,\n    /// mTLS, Unix, and [`crate::Channel::from_io`]. Distinct from\n    /// [`ServerConfig::max_header_list_size`], which caps inbound request\n    /// metadata."
        ),
        "ChannelConfig::max_header_list_size must name oversize response metadata on every transport"
    );
    assert!(
        src.contains(
            "Messages queued between a client-streaming caller and the wire.\n    /// Default 16. Applies to client-streaming and bidi request streams."
        ),
        "ChannelConfig::stream_buffer must name the streaming shapes it queues"
    );
    assert!(
        src.contains("Configured message caps. Applies to every call shape."),
        "ServerConfig::limits and ChannelConfig::limits must name every call shape"
    );
    assert!(
        src.contains(
            "Server interceptors read this overlay on [`crate::Rpc::limits`] / [`crate::Request::limits`]."
        ),
        "ServerConfig::limits must name the interceptor overlay"
    );
    assert!(
        src.contains(
            "[`crate::Channel::limits`] reads this overlay on a live clone without building a [`ChannelConfig`]."
        ),
        "ChannelConfig::limits must name the live Channel overlay"
    );
    assert!(
        src.contains("Configured per-connection send buffer. Applies to every call shape."),
        "send_buffer_size getters must name every call shape"
    );
    assert!(
        src.contains(
            "Server interceptors read this overlay on [`crate::Rpc::send_buffer_size`] / [`crate::Request::send_buffer_size`]."
        ),
        "ServerConfig::send_buffer_size must name the interceptor overlay"
    );
    assert!(
        src.contains(
            "HTTP/2 per-stream receive window. See [`Self::initial_stream_window_size`].\n    /// Applies to every call shape."
        ),
        "stream_window getters must name every call shape"
    );
    assert!(
        src.contains(
            "HTTP/2 per-connection receive window. See [`Self::initial_connection_window_size`].\n    /// Applies to every call shape."
        ),
        "connection_window getters must name every call shape"
    );
    assert!(
        src.contains(
            "HTTP/2 `SETTINGS_MAX_FRAME_SIZE`. See [`Self::max_frame_size`].\n    /// Applies to every call shape."
        ),
        "frame_size getters must name every call shape"
    );
    assert!(
        src.contains(
            "Configured outbound streaming queue depth. Applies to client-streaming\n    /// and bidi request streams."
        ),
        "ChannelConfig::stream_buffer_size must not claim every call shape"
    );
    assert!(
        src.contains(
            "Configured max connection age, if any. The next RPC of every call\n    /// shape redials. See [`Self::max_connection_age`]."
        ),
        "ServerConfig::connection_age must name redial, not in-flight retry on every shape"
    );
    assert!(
        src.contains(
            "Dial bound: TCP/Unix connect, optional TLS, peer SETTINGS.\n    /// See [`Self::connect_timeout`]. Applies to every call shape once that\n    /// dial happens."
        ),
        "ChannelConfig::dial_timeout must name the dial bound"
    );
    assert!(
        src.contains("a later interceptor\n    /// can still set or clear it."),
        "ChannelConfig::wait_for_ready must name interceptor set/clear"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::connected`]: that is a live snapshot; this overlay still queues when a slot is empty."
        ),
        "ChannelConfig::wait_for_ready must Distinct the live-socket snapshot"
    );
    assert!(
        src.contains("Distinct from [`Self::wait_for_ready`], which sets it."),
        "ChannelConfig::waits_for_ready must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::timeout`], which sets it."),
        "ChannelConfig::rpc_timeout must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::send_compressed`], which sets it."),
        "ChannelConfig::compresses_outbound must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::gzip_compression_level`], which sets it."),
        "ChannelConfig::gzip_level must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::accept_compressed`], which sets it."),
        "ChannelConfig::accepts_compressed must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::max_concurrent_rpcs`], which sets it."),
        "ChannelConfig::concurrent_rpc_limit must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::stream_buffer`], which sets it."),
        "ChannelConfig::stream_buffer_size must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::max_send_buffer_size`], which sets it."),
        "ChannelConfig::send_buffer_size must Distinct the setter"
    );
    assert!(
        src.contains("Distinct from [`Self::message_limits`], which sets them."),
        "ChannelConfig::limits must Distinct the setter"
    );
    assert!(
        src.contains(
            "/ [`crate::Request::rpc_timeout`].\n    /// Distinct from [`Self::timeout`], which sets it."
        ),
        "ServerConfig::rpc_timeout must Distinct the setter"
    );
    assert!(
        src.contains(
            "Configured process-wide RPC cap, if any. See [`Self::max_concurrent_rpcs`].\n    /// Applies to every call shape.\n    /// Distinct from [`Self::max_concurrent_rpcs`], which sets it."
        ),
        "ServerConfig::concurrent_rpc_limit must Distinct the setter"
    );
    assert!(
        src.contains(
            "Whether responses are gzipped when the client accepts gzip.\n    /// See [`Self::send_compressed`]. Applies to every call shape.\n    /// Distinct from [`Self::send_compressed`], which sets it."
        ),
        "ServerConfig::compresses_outbound must Distinct the setter"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::gzip_compression_level`], which sets it.\n    #[must_use]\n    pub fn gzip_level(self) -> u32 {\n        self.gzip_compression_level\n    }"
        ),
        "ServerConfig::gzip_level must Distinct the setter"
    );
    assert_eq!(
        src.matches("Last configured gzip/deflate selection. See [`Self::compression_codec`].")
            .count(),
        2,
        "both legacy getters must describe their gzip/deflate selection"
    );
    assert_eq!(
        src.matches("be represented by [`Codec`]; use [`Self::send_algorithm`] to inspect")
            .count(),
        2,
        "both legacy getters must direct optional-coding users to the current preference"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::accept_compressed`], which sets it.\n    /// Distinct from [`crate::Rpc::accepts_gzip`], which is the peer's\n    /// `grpc-accept-encoding`.\n    #[must_use]\n    pub fn accepts_compressed(self) -> bool {\n        self.accept_compressed\n    }\n\n    /// Configured HTTP/2 PING interval, if any. See [`Self::keep_alive_interval`]."
        ),
        "ServerConfig::accepts_compressed must Distinct the setter"
    );
    assert!(
        src.contains(
            "Server interceptors read this overlay on [`crate::Rpc::limits`] / [`crate::Request::limits`].\n    /// Distinct from [`Self::message_limits`], which sets them."
        ),
        "ServerConfig::limits must Distinct the setter"
    );
    assert!(
        src.contains(
            "Server interceptors read this overlay on [`crate::Rpc::send_buffer_size`] / [`crate::Request::send_buffer_size`].\n    /// Distinct from [`Self::max_send_buffer_size`], which sets it."
        ),
        "ServerConfig::send_buffer_size must Distinct the setter"
    );
    assert!(
        src.contains(
            "This is not TCP keepalive. PINGs run on Unix sockets and TLS\n    /// (including mTLS);"
        ),
        "ServerConfig::keep_alive_interval must name Unix and mTLS"
    );
    assert!(
        src.contains(
            "PINGs run on Unix sockets, TLS (including\n    /// mTLS), and [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::keep_alive_interval must name Unix, mTLS, and from_io"
    );
    assert!(
        src.contains("they do not postpone\n    /// [`Self::max_connection_age`]"),
        "ChannelConfig::keep_alive_interval must name that PINGs do not postpone age"
    );
    assert!(
        src.contains(
            "There is no `http2_keep_alive_while_idle` setter: once this interval\n    /// is set, idle connections PING too. Distinct from tonic's\n    /// `Endpoint::http2_keep_alive_while_idle`, which defaults off so a\n    /// client interval does not PING an idle socket."
        ),
        "ChannelConfig::keep_alive_interval must Distinct tonic http2_keep_alive_while_idle default-off"
    );
    assert!(
        src.contains(
            "Distinct from grpc-go\n    /// `PermitWithoutStream`, which is that same idle-PING flag (omitted\n    /// because this behavior is already on)."
        ),
        "ChannelConfig::keep_alive_interval must Distinct grpc-go PermitWithoutStream as already-on"
    );
    assert!(
        src.contains(
            "postpone [`Self::max_connection_age`] (age is wall-clock from\n    /// accept)."
        ),
        "ServerConfig::keep_alive_interval must name that PINGs do not postpone age"
    );
    assert!(
        src.contains(
            "There is no grpc-go `EnforcementPolicy` / `MinTime` setter: inbound\n    /// client PINGs are not GOAWAY'd. Distinct from [`Self::data_frame_budget`],\n    /// which is `ENHANCE_YOUR_CALM` (`too_many_data_frames`) for tiny DATA,\n    /// not PING rate (`too_many_pings`)."
        ),
        "ServerConfig::keep_alive_interval rustdoc must Distinct grpc-go EnforcementPolicy MinTime from too_many_data_frames"
    );
    assert!(
        src.contains(
            "Distinct from\n    /// [`ChannelConfig::keep_alive_interval`]: that sends client PINGs (and\n    /// already Distincts tonic `http2_keep_alive_while_idle` / grpc-go\n    /// `PermitWithoutStream`)."
        ),
        "ServerConfig::keep_alive_interval rustdoc must Distinct ChannelConfig keep_alive_interval client PINGs"
    );
    assert!(
        src.contains(
            "Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::send_compressed must name every transport"
    );
    assert!(
        src.contains(
            "Passing `false` omits gzip and deflate from `grpc-accept-encoding`\n    /// and refuses a compressed reply as [`crate::Code::Unimplemented`]\n    /// without inflating."
        ),
        "ChannelConfig::accept_compressed must omit gzip from accept-encoding"
    );
    assert!(
        src.contains(
            "Passing `false` refuses `grpc-encoding: gzip` and `deflate` as\n    /// [`crate::Code::Unimplemented`] before a handler runs, advertises"
        ),
        "ServerConfig::accept_compressed must refuse gzip before the handler"
    );
    assert!(
        src.contains(
            "Default per-RPC deadline when the request omits `grpc-timeout`.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::timeout must name every transport"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::timeout` that omits `grpc-timeout`: that\n    /// times out the client future without informing the server. This overlay\n    /// writes `grpc-timeout` when the request omits one. Distinct from\n    /// [`ServerConfig::timeout`] (server overlay). Distinct from `tower`\n    /// integration, which is protobuf-tonic keeping tonic."
        ),
        "ChannelConfig::timeout rustdoc must Distinct grpc-timeout write from tonic Endpoint::timeout skip"
    );
    assert_eq!(
        src.matches("There is no tonic `Endpoint::timeout` that omits")
            .count(),
        1,
        "ServerConfig::timeout must not copy the client Endpoint::timeout Distinct"
    );
    assert!(
        src.contains(
            "Cap every RPC to this duration even when the client omits `grpc-timeout`.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::timeout must name every transport"
    );
    assert!(
        src.contains(
            "There is no tonic `Server::timeout` tower layer: that is `TimeoutLayer`\n    /// wrapping every request handler. This cap is a gRPC deadline overlay\n    /// when the client omits `grpc-timeout`. This kernel is not a tower stack.\n    /// Distinct from [`ChannelConfig::timeout`] (client overlay). Distinct from\n    /// [`Self::keep_alive_timeout`] (PING ACK). Distinct from `tower`\n    /// integration, which is protobuf-tonic keeping tonic."
        ),
        "ServerConfig::timeout rustdoc must Distinct gRPC deadline overlay from tonic Server::timeout TimeoutLayer"
    );
    assert_eq!(
        src.matches("There is no tonic `Server::timeout` tower layer")
            .count(),
        1,
        "ChannelConfig::timeout must not copy the server TimeoutLayer Distinct"
    );
    assert!(
        src.contains(
            "the other end redials the next RPC of every call shape, including over\n    /// TLS, mTLS, and Unix."
        ),
        "ServerConfig::max_connection_age must name redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "dropping the socket. Default 10 s. Values below 1 ms are raised to 1 ms.\n    /// Applies to every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::max_connection_age_grace must name in-flight finish on every transport"
    );
    assert!(
        src.contains("of every call shape redials, including over TLS, mTLS, and Unix."),
        "ServerConfig::max_connection_idle must name redial on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "not look idle, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::max_connection_idle must name in-flight not-idle on every transport"
    );
    assert!(
        src.contains(
            "Cap how many TCP/Unix connections the accept loop will serve at once,\n    /// including TLS and mTLS listeners. Applies to every call shape."
        ),
        "ServerConfig::max_concurrent_connections must name TLS and mTLS"
    );
    assert!(
        src.contains(
            "accept storm cannot pin an unbounded number of handshake tasks.\n    /// Disabled by default.\n    /// There is no tonic `Server::executor` setter: that is `SharedExec` on\n    /// tonic's hyper stack. Each accept-loop handshake task is `tokio::spawn`ed\n    /// on the current tokio runtime. This kernel is not a hyper/tower stack.\n    /// [`Self`] is `Copy`, so it cannot store a non-`Copy` executor. Distinct\n    /// from tonic `Endpoint::executor`, which is the client `SharedExec` (see\n    /// [`ChannelConfig::connections`]). Distinct from `tower` integration,\n    /// which is protobuf-tonic keeping tonic. [`crate::Server::serve_connection`]\n    /// is already-connected: it is not an accept-loop spawn."
        ),
        "ServerConfig::max_concurrent_connections rustdoc must Distinct accept-loop spawn from tonic Server::executor SharedExec"
    );
    assert!(
        src.contains(
            "How long TLS accept (if any) and the HTTP/2 preface may each take.\n    /// Default 20 s. Values below 1 ms are raised to 1 ms.\n    /// Applies to every call shape, including over TLS, mTLS, and Unix."
        ),
        "ServerConfig::handshake_timeout must name TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "There is no grpc-go `ConnectionTimeout` setter: that is one deadline\n    /// from accept through HTTP/2 handshake (default 120 s). This cap is 20 s\n    /// on TLS accept (if any) and 20 s on the HTTP/2 preface, separately.\n    /// Distinct from [`ChannelConfig::connect_timeout`] (client whole dial).\n    /// Distinct from [`Self::timeout`] (RPC deadline overlay). Distinct from\n    /// [`Self::keep_alive_timeout`] (PING ACK). Distinct from\n    /// [`Self::max_connection_age`] (live connections after handshake)."
        ),
        "ServerConfig::handshake_timeout rustdoc must Distinct two sequential 20 s caps from grpc-go ConnectionTimeout"
    );
    assert_eq!(
        src.matches("There is no grpc-go `ConnectionTimeout` setter")
            .count(),
        1,
        "ChannelConfig::connect_timeout must not copy the server ConnectionTimeout Distinct"
    );
    assert!(
        src.contains(
            "Cap how many RPCs the process will run at once, across every\n    /// connection. Applies to every call shape, including over TLS, mTLS,\n    /// Unix, and [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::max_concurrent_rpcs must name every transport"
    );
    assert!(
        src.contains(
            "There is no grpc-go `NumStreamWorkers` setter: that is a worker pool\n    /// for stream dispatch (0 means a goroutine per stream). Each accepted\n    /// stream is `tokio::spawn`ed on the current tokio runtime. This cap is\n    /// in-flight handler slots, not a worker count. Distinct from tonic\n    /// `Server::executor` (`SharedExec`, which executor, not a worker pool)."
        ),
        "ServerConfig::max_concurrent_rpcs rustdoc must Distinct in-flight handler slots from grpc-go NumStreamWorkers"
    );
    assert!(
        src.contains(
            "There is no tonic `Server::concurrency_limit_per_connection` setter:\n    /// that is tower `ConcurrencyLimitLayer` on each spawned connection.\n    /// This kernel is not a tower stack. This cap is process-wide handler\n    /// slots, not a per-connection tower layer. Distinct from\n    /// [`Self::max_concurrent_streams`]: extras wait on that SETTINGS cap.\n    /// Distinct from `tower` integration, which is protobuf-tonic keeping tonic."
        ),
        "ServerConfig::max_concurrent_rpcs rustdoc must Distinct process-wide slots from tonic concurrency_limit_per_connection"
    );
    assert!(
        src.contains(
            "There is no tonic `Server::load_shed` setter: that is tower\n    /// `LoadShedLayer` (fail when `poll_ready` is pending, instead of waiting).\n    /// This kernel is not a tower stack. This cap already refuses extras as\n    /// [`crate::Code::ResourceExhausted`] (`try_acquire`, not wait). Distinct\n    /// from [`Self::max_concurrent_streams`]: extras wait on that SETTINGS cap.\n    /// Distinct from tonic `Server::concurrency_limit_per_connection` (per-connection\n    /// wait layer). Distinct from `tower` integration, which is protobuf-tonic\n    /// keeping tonic."
        ),
        "ServerConfig::max_concurrent_rpcs rustdoc must Distinct try_acquire refuse from tonic Server::load_shed"
    );
    assert!(
        src.contains(
            "HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`. Distinct from\n    /// [`Self::max_concurrent_rpcs`], which refuses extras as\n    /// [`crate::Code::ResourceExhausted`]. A well-behaved client waits; both\n    /// RPCs still complete, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::max_concurrent_streams must name serialize vs RESOURCE_EXHAUSTED on every transport"
    );
    assert_eq!(
        src.matches(
            "A well-behaved client waits; both\n    /// RPCs still complete, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        )
        .count(),
        1,
        "ChannelConfig::max_concurrent_streams must not copy the server serialize Distinct"
    );
    assert!(
        src.contains(
            "HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS` the client advertises. Distinct\n    /// from [`ServerConfig::max_concurrent_streams`], which serializes extra\n    /// RPCs on the server. Push is disabled, including over TLS, mTLS, Unix,\n    /// and [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::max_concurrent_streams must name client SETTINGS Distinct from server serialize"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_concurrent_rpcs`], which refuses extras\n    /// before the stream opens."
        ),
        "ChannelConfig::max_concurrent_streams must Distinct the client RPC cap"
    );
    assert!(
        src.contains(
            "Further RPCs are refused with [`crate::Code::ResourceExhausted`]\n    /// before the stream opens. Distinct from\n    /// [`Self::max_concurrent_streams`] (per HTTP/2 connection SETTINGS;"
        ),
        "ChannelConfig::max_concurrent_rpcs must refuse extras before the stream opens"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::rate_limit` setter: that is tower\n    /// `RateLimitLayer` (at most N RPCs per duration). This kernel is not a\n    /// tower stack. This cap is in-flight slots, not a token bucket.\n    /// Distinct from `tower` integration, which is protobuf-tonic keeping tonic."
        ),
        "ChannelConfig::max_concurrent_rpcs must Distinct in-flight slots from tonic Endpoint::rate_limit"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::concurrency_limit` setter: that is tower\n    /// `ConcurrencyLimitLayer` (wait when `poll_ready` is pending). This kernel\n    /// is not a tower stack. This cap already refuses extras as\n    /// [`crate::Code::ResourceExhausted`] (`try_acquire`, not wait). Distinct\n    /// from `Endpoint::rate_limit` (token bucket). Distinct from tonic\n    /// `Server::concurrency_limit_per_connection` (server per-connection wait\n    /// layer). Distinct from `tower` integration, which is protobuf-tonic\n    /// keeping tonic."
        ),
        "ChannelConfig::max_concurrent_rpcs rustdoc must Distinct try_acquire refuse from tonic Endpoint::concurrency_limit wait"
    );
    assert_eq!(
        src.matches("There is no tonic `Endpoint::concurrency_limit` setter")
            .count(),
        1,
        "ServerConfig::max_concurrent_rpcs must not copy the client concurrency_limit Distinct"
    );
    assert!(
        src.contains(
            "pooled connection. Applies to every call shape, including over TLS,\n    /// mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::max_concurrent_rpcs must name every transport"
    );
    assert!(
        src.contains(
            "A well-behaved client splits DATA; every call shape still completes,\n    /// including over TLS, mTLS, Unix, and [`crate::Server::serve_connection`].\n    /// Distinct from [`Self::max_header_list_size`], which refuses oversize\n    /// metadata, and from [`Self::max_concurrent_streams`], which serializes\n    /// extra RPCs."
        ),
        "ServerConfig::max_frame_size must name still-serves Distinct from header-list and stream cap"
    );
    assert_eq!(
        src.matches("A well-behaved client splits DATA; every call shape still completes,")
            .count(),
        1,
        "ChannelConfig::max_frame_size must not copy the server still-serves Distinct"
    );
    assert!(
        src.contains(
            "HTTP/2 `SETTINGS_MAX_FRAME_SIZE` the client advertises. Distinct\n    /// from [`ServerConfig::max_frame_size`], which still serves every call\n    /// shape when the server advertises a small cap. A well-behaved server\n    /// splits DATA, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::max_frame_size must name client SETTINGS Distinct from server still-serves"
    );
    assert!(
        src.contains(
            "A well-behaved client still completes every call shape, including over\n    /// TLS, mTLS, Unix, and [`crate::Server::serve_connection`]. Distinct from\n    /// [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS\n    /// minimum, and from [`Self::max_concurrent_streams`], which serializes\n    /// extra RPCs."
        ),
        "ServerConfig window setters must name still-serves Distinct from frame size and stream cap"
    );
    assert_eq!(
        src.matches("A well-behaved client still completes every call shape, including over")
            .count(),
        2,
        "ChannelConfig window setters must not copy the server still-serves Distinct"
    );
    assert!(
        src.contains(
            "HTTP/2 stream receive window the client advertises. Distinct from\n    /// [`ServerConfig::initial_stream_window_size`], which still serves when\n    /// the server advertises a small window. A well-behaved server still\n    /// completes every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::initial_stream_window_size must name client advertised Distinct from server still-serves"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::http2_adaptive_window`: that enables\n    /// hyper adaptive flow control and overrides stream and connection\n    /// windows. This cap is a fixed SETTINGS window. Distinct from\n    /// [`Self::initial_connection_window_size`] (connection window, still\n    /// fixed). Distinct from [`Self::data_frame_budget`] (`h2 Auto` tiny-DATA\n    /// budget, not window adaptation). Distinct from tonic\n    /// `Server::http2_adaptive_window` (server adaptive override)."
        ),
        "ChannelConfig::initial_stream_window_size rustdoc must Distinct fixed SETTINGS window from tonic http2_adaptive_window"
    );
    assert_eq!(
        src.matches("There is no tonic `Endpoint::http2_adaptive_window`")
            .count(),
        1,
        "ChannelConfig::initial_connection_window_size must not copy the http2_adaptive_window Distinct"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithDefaultServiceConfig`: that is JSON used when\n/// the name resolver does not provide a service config, or when\n/// `WithDisableServiceConfig` ignores the resolver. This config is typed\n/// `Copy` fields, not JSON; there is no resolver. Distinct from grpc-go\n/// `WithDisableRetry` (`retryPolicy` only). Distinct from [`Self::timeout`]\n/// (kernel overlay, not methodConfig timeout). There is no\n/// `WithDisableServiceConfig`: nothing to ignore."
        ),
        "ChannelConfig rustdoc must Distinct typed Copy fields from grpc-go WithDefaultServiceConfig JSON"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithDefaultServiceConfig`")
            .count(),
        1,
        "ServerConfig must not copy the WithDefaultServiceConfig Distinct"
    );
    assert!(
        src.contains(
            "There is no grpc-go `WithIdleTimeout` idle mode: that shuts down the\n    /// name resolver and load balancer after channel idle (default 30 min;\n    /// zero disables). This cap closes the socket when no RPCs are outstanding\n    /// (unset by default; sub-millisecond values are raised to 1 ms, not\n    /// disabled). Distinct from [`Self::max_connection_age`] (age, not idle).\n    /// Distinct from [`ServerConfig::max_connection_idle`] (server GOAWAY).\n    /// There is no resolver or load balancer to shut down."
        ),
        "ChannelConfig::max_connection_idle rustdoc must Distinct socket close from grpc-go WithIdleTimeout idle mode"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithIdleTimeout`").count(),
        1,
        "ServerConfig::max_connection_idle must not copy the WithIdleTimeout Distinct"
    );
    assert!(
        src.contains(
            "HTTP/2 connection receive window the client advertises. Distinct from\n    /// [`ServerConfig::initial_connection_window_size`], which still serves when\n    /// the server advertises a small window. A well-behaved server still\n    /// completes every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::initial_connection_window_size must name client advertised Distinct from server still-serves"
    );
    assert!(
        src.contains(
            "Write backpressure still completes every call shape, including over\n    /// TLS, mTLS, Unix, and [`crate::Server::serve_connection`]. Distinct from\n    /// [`Self::max_frame_size`], which still serves at the 16 KiB SETTINGS\n    /// minimum, and from [`Self::initial_stream_window_size`], which still\n    /// serves at a small receive window."
        ),
        "ServerConfig::max_send_buffer_size must name still-serves Distinct from frame size and windows"
    );
    assert!(
        src.contains(
            "There is no grpc-go `SharedWriteBuffer` setter: that reuses a\n    /// per-connection transport write buffer after flush. This cap is HTTP/2\n    /// write-byte backpressure per connection; buffers are not pooled across\n    /// connections. Distinct from grpc-go `WriteBufferSize` / `ReadBufferSize`\n    /// (socket byte buffers, default 32 KiB). Distinct from tonic\n    /// `Endpoint::buffer_size` (tower `Buffer` request slots)."
        ),
        "ServerConfig::max_send_buffer_size rustdoc must Distinct per-connection HTTP/2 buffer from grpc-go SharedWriteBuffer"
    );
    assert_eq!(
        src.matches("Write backpressure still completes every call shape, including over")
            .count(),
        1,
        "ChannelConfig::max_send_buffer_size must not copy the server still-serves Distinct"
    );
    assert!(
        src.contains(
            "HTTP/2 send buffer the client applies on outbound frames. Distinct from\n    /// [`ServerConfig::max_send_buffer_size`], which still serves when the\n    /// server advertises a small buffer. A well-behaved server still completes\n    /// every call shape, including over TLS, mTLS, Unix, and\n    /// [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::max_send_buffer_size must name client buffer Distinct from server still-serves"
    );
    assert!(
        src.contains(
            "[`crate::Channel::max_send_buffer_size`] sets the write-time DATA threshold on a live clone without building a [`ChannelConfig`]."
        ),
        "ChannelConfig::max_send_buffer_size must name the live Channel write-time overlay"
    );
    assert!(
        src.contains(
            "There is no tonic `Endpoint::buffer_size`: that is tower `Buffer` request\n    /// slots (default 1024), not these bytes. This kernel is not a tower stack;\n    /// clones share the pool without an mpsc of RPCs."
        ),
        "ChannelConfig::max_send_buffer_size rustdoc must Distinct tonic Endpoint::buffer_size as tower Buffer slots"
    );
    assert!(
        src.contains(
            "Distinct from grpc-go `ReadBufferSize` /\n    /// `WriteBufferSize`, which are socket byte buffers (default 32 KiB), not\n    /// this HTTP/2 send buffer."
        ),
        "ChannelConfig::max_send_buffer_size rustdoc must Distinct grpc-go ReadBufferSize as socket bytes"
    );
    assert!(
        src.contains(
            "A well-behaved client never fills that queue; every call shape still\n    /// completes, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]. Distinct from a raw HTTP/2 peer."
        ),
        "ServerConfig::max_pending_accept_reset_streams must name still-serves Distinct from a raw RST flood"
    );
    assert_eq!(
        src.matches("This caps RSTs we send after an invalid frame.")
            .count(),
        2,
        "ServerConfig and ChannelConfig max_local_error_reset_streams must Distinct library RSTs from rapid reset"
    );
    assert!(
        src.contains("h2's `None` disable is not exposed"),
        "ServerConfig::max_local_error_reset_streams must not expose h2's None disable"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::max_local_error_reset_streams`], which\n    /// still serves when the server caps protocol-error RSTs."
        ),
        "ChannelConfig::max_local_error_reset_streams must name client handshake Distinct from server still-serves"
    );
    assert_eq!(
        src.matches(
            "HTTP/2 `SETTINGS_HEADER_TABLE_SIZE` (HPACK dynamic table). Default 4096.\n    /// Applies to every call shape."
        )
        .count(),
        2,
        "ServerConfig and ChannelConfig header_table_size must name HPACK table default 4096"
    );
    assert_eq!(
        src.matches(
            "[`Self::max_header_list_size`], which caps uncompressed header-block\n    /// bytes (`SETTINGS_MAX_HEADER_LIST_SIZE`)."
        )
        .count(),
        2,
        "ServerConfig and ChannelConfig header_table_size must Distinct from max_header_list_size"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::header_table_size`], which still serves\n    /// when the server advertises a smaller table."
        ),
        "ChannelConfig::header_table_size must name client handshake Distinct from server still-serves"
    );
    assert_eq!(
        src.matches("HTTP/2 small-DATA framing budget. Default 25600.")
            .count(),
        2,
        "ServerConfig and ChannelConfig data_frame_budget must name default 25600"
    );
    assert_eq!(
        src.matches("h2 Auto (half the connection window) is not exposed")
            .count(),
        2,
        "ServerConfig and ChannelConfig data_frame_budget must not expose h2 Auto"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::data_frame_budget`], which still serves\n    /// when the server caps small-DATA framing."
        ),
        "ChannelConfig::data_frame_budget must name client handshake Distinct from server still-serves"
    );
    assert_eq!(
        src.matches("Cap remembered locally-reset HTTP/2 stream IDs.")
            .count(),
        2,
        "ServerConfig and ChannelConfig max_concurrent_reset_streams must name remembered locally-reset stream IDs"
    );
    assert!(
        src.contains("oldest ID is purged from memory"),
        "ServerConfig::max_concurrent_reset_streams must name eviction, not GOAWAY"
    );
    assert!(
        src.contains("not `ENHANCE_YOUR_CALM`"),
        "ServerConfig::max_concurrent_reset_streams must Distinct eviction from ENHANCE_YOUR_CALM"
    );
    assert!(
        src.contains("Frames on a purged ID are a connection `PROTOCOL_ERROR`"),
        "ServerConfig::max_concurrent_reset_streams must name PROTOCOL_ERROR after purge"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::max_concurrent_reset_streams`], which still\n    /// serves when the server remembers fewer reset stream IDs."
        ),
        "ChannelConfig::max_concurrent_reset_streams must name client handshake Distinct from server still-serves"
    );
    assert_eq!(
        src.matches("at this memory cap").count(),
        2,
        "ServerConfig and ChannelConfig max_concurrent_reset_streams must still-serve at this memory cap"
    );
    assert_eq!(
        src.matches("How long locally-reset HTTP/2 stream IDs are remembered.")
            .count(),
        2,
        "ServerConfig and ChannelConfig reset_stream_duration must name how long IDs are remembered"
    );
    assert!(
        src.contains("After this duration the ID is forgotten, not `ENHANCE_YOUR_CALM`."),
        "ServerConfig::reset_stream_duration must Distinct expiry from ENHANCE_YOUR_CALM"
    );
    assert!(
        src.contains("Frames on a forgotten ID are a connection `PROTOCOL_ERROR`"),
        "ServerConfig::reset_stream_duration must name PROTOCOL_ERROR after expiry"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::reset_stream_duration`], which still\n    /// serves when the server remembers reset stream IDs for less time."
        ),
        "ChannelConfig::reset_stream_duration must name client handshake Distinct from server still-serves"
    );
    assert_eq!(
        src.matches("at this reset duration").count(),
        2,
        "ServerConfig and ChannelConfig reset_stream_duration must still-serve at this reset duration"
    );
    assert_eq!(
        src.matches("Applied at handshake, not as a live overlay.")
            .count(),
        6,
        "ChannelConfig header_table_size / data_frame_budget / pending-reset / local-error RST / concurrent-reset memory / reset duration must be handshake-only"
    );
    assert_eq!(
        src.matches("Distinct from [`Self::send_compressed`], which is on or off.")
            .count(),
        4,
        "ServerConfig and ChannelConfig gzip_compression_level + compression_codec must Distinct effort/coding from on/off"
    );
    assert_eq!(
        src.matches(
            "Deflate effort for outbound gzip. Default 1 (`flate2` fast).\n    /// Applies to every call shape"
        )
        .count(),
        2,
        "ServerConfig and ChannelConfig gzip_compression_level must name deflate effort"
    );
    assert!(
        src.contains("0 stores; 9 is best"),
        "ServerConfig::gzip_compression_level must name store and best levels"
    );
    assert_eq!(
        src.matches("A well-behaved client never fills that queue; every call shape still")
            .count(),
        1,
        "ChannelConfig::max_pending_accept_reset_streams must not copy the server still-serves Distinct"
    );
    assert!(
        src.contains(
            "Distinct from [`ServerConfig::max_pending_accept_reset_streams`], which\n    /// still serves when the server caps that queue. A well-behaved server\n    /// never fills this client queue; every call shape still completes,\n    /// including over TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "ChannelConfig::max_pending_accept_reset_streams must name client queue Distinct from server still-serves"
    );
    assert!(
        src.contains(
            "Distinct from [`Self::max_decoding_message_size`] /\n    /// [`Self::max_encoding_message_size`]. Oversize inbound or outbound is\n    /// [`crate::Code::ResourceExhausted`], including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]."
        ),
        "ServerConfig::message_limits must name combined-setter oversize on every transport"
    );
    assert!(
        src.contains(
            "Oversize metadata is refused, including over TLS, mTLS, Unix, and\n    /// [`crate::Server::serve_connection`]. Distinct from a raw HTTP/2 peer."
        ),
        "ServerConfig::max_header_list_size must name oversize metadata on every transport"
    );
    let crate_src = include_str!("../src/lib.rs");
    assert!(
        crate_src.contains(
            "HTTP/2 `SETTINGS_MAX_CONCURRENT_STREAMS`; extras wait, they are not `RESOURCE_EXHAUSTED`"
        ),
        "crate docs must name stream-cap serialize vs RESOURCE_EXHAUSTED"
    );
    assert!(
        crate_src.contains(
            "Compiling intercept / on_response overlay dumps live on [`hello`] (`GreeterClient` / `GreeterServer`)."
        ),
        "crate docs must point at the compiling hello intercept and on_response overlay dumps"
    );
    assert!(
        crate_src.contains("Compiling ConnectionInfo peer dumps live on [`Incoming`]."),
        "crate docs must point at the compiling Incoming ConnectionInfo peer dump"
    );
    assert!(
        crate_src.contains("including a rapid-reset flood that exceeds"),
        "crate docs must name the hostile rapid-reset flood"
    );
    assert!(
        crate_src.contains("keepalive PINGs do not reset idle and do not postpone age"),
        "crate threat table must Distinct keepalive PINGs from postponing age"
    );
    assert!(
        crate_src.contains("[`Status::error_info`]"),
        "crate map must name Status::error_info"
    );
    assert!(
        crate_src.contains(
            "[`Status::rpc`], [`Status::error_details`], [`Status::from_rpc`], [`Status::set_rpc`]"
        ),
        "crate map must name Status::rpc, error_details, from_rpc, and set_rpc together"
    );
    assert!(
        crate_src.contains("[`Status::with_error_details`], [`Status::from_error_details`]"),
        "crate map must name Status::from_error_details next to the Any packer"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::from_rpc`], [`Status::new`]"),
        "crate map must name Status::new next to ErrorDetails::from_rpc"
    );
    assert!(
        crate_src.contains("[`Status::new`], [`Status::from_code`]"),
        "crate map must name Status::from_code next to Status::new"
    );
    assert!(
        crate_src.contains("[`Status::from_code`], [`Status::code`]"),
        "crate map must name Status::code next to Status::from_code"
    );
    assert!(
        crate_src.contains("[`Status::code`], [`Status::message`]"),
        "crate map must name Status::message next to Status::code"
    );
    assert!(
        crate_src.contains("[`Status::message`], [`Status::set_code`]"),
        "crate map must name Status::set_code next to Status::message"
    );
    assert!(
        crate_src.contains("[`Status::set_code`], [`Status::with_code`]"),
        "crate map must name Status::with_code next to Status::set_code"
    );
    assert!(
        crate_src.contains("[`Status::with_code`], [`Status::set_message`]"),
        "crate map must name Status::set_message next to Status::with_code"
    );
    assert!(
        crate_src.contains("[`Status::set_message`], [`Status::with_message`]"),
        "crate map must name Status::with_message next to Status::set_message"
    );
    assert!(
        crate_src.contains("[`Status::with_message`], [`Status::with_error_details`]"),
        "crate map must name Status::with_error_details next to Status::with_message"
    );
    assert!(
        crate_src.contains("[`Code`], [`Code::from_i32`]"),
        "crate map must name Code::from_i32 next to Code"
    );
    assert!(
        crate_src.contains("[`Code::from_i32`], [`Code::to_i32`]"),
        "crate map must name Code::to_i32 next to Code::from_i32"
    );
    assert!(
        crate_src.contains("[`Code::to_i32`], [`Code::name`]"),
        "crate map must name Code::name next to Code::to_i32"
    );
    assert!(
        crate_src.contains("[`Code::name`], [`Code::description`]"),
        "crate map must name Code::description next to Code::name"
    );
    assert!(
        crate_src.contains("[`Code::description`], [`Code::is_retryable`]"),
        "crate map must name Code::is_retryable next to Code::description"
    );
    assert!(
        crate_src.contains("[`Code::is_retryable`], [`ParseCodeError`]"),
        "crate map must name ParseCodeError next to Code::is_retryable"
    );
    assert!(
        crate_src.contains("[`ParseCodeError`], [`Any`]"),
        "crate map must name Any next to ParseCodeError"
    );
    assert!(
        crate_src.contains("[`Interceptor`], [`ResponseInterceptor`]"),
        "crate map must name ResponseInterceptor next to Interceptor"
    );
    assert!(
        crate_src.contains("[`ResponseInterceptor`], [`Intercepted`]"),
        "crate map must name Intercepted next to ResponseInterceptor"
    );
    assert!(
        crate_src.contains("[`Intercepted`], [`ClientInterceptor`]"),
        "crate map must name ClientInterceptor next to Intercepted"
    );
    assert!(
        crate_src.contains("[`ClientInterceptor`], [`Outgoing`]"),
        "crate map must name Outgoing next to ClientInterceptor"
    );
    assert!(
        crate_src.contains("[`Outgoing`], [`Extensions`]"),
        "crate map must name Extensions next to Outgoing"
    );
    assert!(
        crate_src.contains("[`Request`], [`Parts`]"),
        "crate map must name Parts next to Request"
    );
    assert!(
        crate_src.contains("[`Parts`], [`Response`]"),
        "crate map must name Response next to Parts"
    );
    assert!(
        crate_src.contains("[`Response`], [`ResponseParts`]"),
        "crate map must name ResponseParts next to Response"
    );
    assert!(
        crate_src.contains("[`ResponseParts`], [`Metadata`]"),
        "crate map must name Metadata next to ResponseParts"
    );
    assert!(
        crate_src.contains("[`Metadata`], [`Status`]"),
        "crate map must name Status next to Metadata"
    );
    assert!(
        crate_src.contains("[`Status`], [`Code`]"),
        "crate map must name Code next to Status"
    );
    assert!(
        crate_src.contains("[`Service`], [`Rpc`]"),
        "crate map must name Rpc next to Service"
    );
    assert!(
        crate_src.contains("[`Rpc`], [`Server`]"),
        "crate map must name Server next to Rpc"
    );
    assert!(
        crate_src.contains("[`Server`], [`Router`]"),
        "crate map must name Router next to Server"
    );
    assert!(
        crate_src.contains("[`Router`], [`Incoming`]"),
        "crate map must name Incoming next to Router"
    );
    assert!(
        crate_src.contains("[`Incoming`], [`IncomingAccept`]"),
        "crate map must name IncomingAccept next to Incoming"
    );
    assert!(
        crate_src.contains("[`IncomingAccept`], [`ConnectionInfo`]"),
        "crate map must name ConnectionInfo next to IncomingAccept"
    );
    assert!(
        crate_src.contains("[`ConnectionInfo`], [`ServerConfig`]"),
        "crate map must name ServerConfig next to ConnectionInfo"
    );
    assert!(
        crate_src.contains("[`ServerConfig`], [`PeerCred`]"),
        "crate map must name PeerCred next to ServerConfig"
    );
    assert!(
        crate_src.contains("[`Channel`], [`ChannelConfig`]"),
        "crate map must name ChannelConfig next to Channel"
    );
    assert!(
        crate_src.contains("[`ChannelConfig`], [`Target`]"),
        "crate map must name Target next to ChannelConfig"
    );
    assert!(
        crate_src.contains("[`Target`], [`Call`]"),
        "crate map must name Call next to Target"
    );
    assert!(
        crate_src.contains("[`Call`], [`CallHandle`]"),
        "crate map must name CallHandle next to Call"
    );
    assert!(
        crate_src.contains("[`CallHandle`], [`FusedFuture`]"),
        "crate map must name FusedFuture next to CallHandle"
    );
    assert!(
        crate_src.contains("[`Identity`], [`ServerTls`]"),
        "crate map must name ServerTls next to Identity"
    );
    assert!(
        crate_src.contains("[`ServerTls`], [`ClientTls`]"),
        "crate map must name ClientTls next to ServerTls"
    );
    assert!(
        crate_src.contains("[`ClientTls`], [`PeerIdentity`]"),
        "crate map must name PeerIdentity next to ClientTls"
    );
    assert!(
        crate_src.contains("[`Streaming`], [`StreamSender`]"),
        "crate map must name StreamSender next to Streaming"
    );
    assert!(
        crate_src.contains("[`StreamSender`], [`Framed`]"),
        "crate map must name Framed next to StreamSender"
    );
    assert!(
        crate_src.contains("[`Framed`], [`Stream`]"),
        "crate map must name Stream next to Framed"
    );
    assert!(
        crate_src.contains("[`Stream`], [`FusedStream`]"),
        "crate map must name FusedStream next to Stream"
    );
    assert!(
        crate_src.contains("[`codec`], [`gzip`]"),
        "crate map must name gzip next to codec"
    );
    assert!(
        crate_src.contains("[`gzip`], [`timeout`]"),
        "crate map must name timeout next to gzip"
    );
    assert!(
        crate_src.contains(
            "Generated [`reflection`] aliases `grpc.reflection.v1alpha.ServerReflection` onto the v1 handler so a [`Router`] still answers older grpcurl. That is a path alias, not a second proto. Distinct from [`Server::new`], which already answers that path because it does not look up [`Service::NAME`]."
        ),
        "crate-map must Distinct reflection v1alpha path alias from a second proto and from Server::new"
    );
    assert!(
        crate_src
            .contains("[`gzip::decode_limited`]); opt-out [`ServerConfig::accept_compressed`]"),
        "crate threat table must name accept_compressed next to decode_limited"
    );
    assert!(
        crate_src
            .contains("[`ServerConfig::accept_compressed`] / [`ChannelConfig::accept_compressed`]"),
        "crate threat table must name ChannelConfig::accept_compressed next to ServerConfig"
    );
    assert!(
        crate_src.contains("[`Server::serve_tls`] / [`Channel::connect_tls`]"),
        "crate threat table must name connect_tls next to serve_tls"
    );
    assert!(
        crate_src.contains("[`ServerTls::mtls`]; verified client chain on [`Rpc::peer_identity`]"),
        "crate threat table must name peer_identity next to ServerTls::mtls"
    );
    assert!(
        crate_src.contains(
            "[`ServerConfig::max_connection_age`] / [`ServerConfig::max_connection_idle`]"
        ),
        "crate threat table must name ServerConfig::max_connection_idle next to max_connection_age"
    );
    assert!(
        crate_src.contains(
            "[`ServerConfig::max_connection_idle`] / [`ChannelConfig::max_connection_age`]"
        ),
        "crate threat table must name ChannelConfig::max_connection_age next to server idle"
    );
    assert!(
        crate_src.contains(
            "[`ChannelConfig::max_connection_age`] / [`ChannelConfig::max_connection_idle`]"
        ),
        "crate threat table must name ChannelConfig::max_connection_idle next to client age"
    );
    assert!(
        crate_src
            .contains("[`ChannelConfig::connect_timeout`] / [`ServerConfig::handshake_timeout`]"),
        "crate threat table must name handshake_timeout next to connect_timeout"
    );
    assert!(
        crate_src.contains("[`ServerConfig::tcp_keepalive`] / [`ChannelConfig::tcp_keepalive`]"),
        "crate threat table must name ChannelConfig::tcp_keepalive next to ServerConfig"
    );
    assert!(
        crate_src.contains("[`ChannelConfig::tcp_keepalive_interval`] is `TCP_KEEPINTVL` after idle [`ChannelConfig::tcp_keepalive`]. Distinct from [`ChannelConfig::keep_alive_interval`], which sends HTTP/2 PINGs. This crate-map interval does not turn `SO_KEEPALIVE` on by itself. Probe retry count is [`ChannelConfig::tcp_keepalive_retries`] (`TCP_KEEPCNT`)."),
        "crate-map must Distinct tcp_keepalive_interval TCP_KEEPINTVL from HTTP/2 PING"
    );
    assert!(
        crate_src.contains("[`ChannelConfig::tcp_keepalive_retries`] is `TCP_KEEPCNT` after idle [`ChannelConfig::tcp_keepalive`]. Distinct from [`ChannelConfig::tcp_keepalive_interval`] (`TCP_KEEPINTVL` time, not count). This crate-map retry count does not turn `SO_KEEPALIVE` on by itself."),
        "crate-map must Distinct tcp_keepalive_retries TCP_KEEPCNT from TCP_KEEPINTVL time"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::rate_limit`: that is tower `RateLimitLayer` (at most N RPCs per duration). This crate-map [`ChannelConfig::max_concurrent_rpcs`] is in-flight slots, not a token bucket. Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct max_concurrent_rpcs in-flight slots from tonic Endpoint::rate_limit"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::concurrency_limit`: that is tower `ConcurrencyLimitLayer` (wait when `poll_ready` is pending). This crate-map [`ChannelConfig::max_concurrent_rpcs`] already refuses extras as `RESOURCE_EXHAUSTED` (`try_acquire`, not wait). Distinct from `Endpoint::rate_limit` (token bucket). Distinct from tonic `Server::concurrency_limit_per_connection` (server per-connection wait layer). Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct max_concurrent_rpcs try_acquire refuse from tonic Endpoint::concurrency_limit"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::executor`: that is `SharedExec` on tonic's hyper stack. This crate-map [`ChannelConfig::connections`] `h2` driver is `tokio::spawn`ed on the current tokio runtime. Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct ChannelConfig::connections h2 driver spawn from tonic Endpoint::executor SharedExec"
    );
    assert!(
        crate_src.contains("There is no tonic `Server::executor`: that is `SharedExec` on tonic's hyper stack. This crate-map [`ServerConfig::max_concurrent_connections`] handshake task is `tokio::spawn`ed on the current tokio runtime. Distinct from tonic `Endpoint::executor` (client [`ChannelConfig::connections`]). Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct ServerConfig::max_concurrent_connections handshake spawn from tonic Server::executor SharedExec"
    );
    assert!(
        crate_src.contains("There is no grpc-go `NumStreamWorkers`: that is a worker pool for stream dispatch (0 means a goroutine per stream). This crate-map [`ServerConfig::max_concurrent_rpcs`] is in-flight handler slots, not a worker count. Distinct from tonic `Server::executor` (`SharedExec`, which executor, not a worker pool)."),
        "crate-map must Distinct ServerConfig::max_concurrent_rpcs in-flight slots from grpc-go NumStreamWorkers"
    );
    assert!(
        crate_src.contains("There is no tonic `Server::concurrency_limit_per_connection`: that is tower `ConcurrencyLimitLayer` on each spawned connection. This crate-map [`ServerConfig::max_concurrent_rpcs`] is process-wide handler slots, not a per-connection tower layer. Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct ServerConfig::max_concurrent_rpcs process-wide slots from tonic concurrency_limit_per_connection"
    );
    assert!(
        crate_src.contains("There is no grpc-go `UnknownServiceHandler`: that is a catch-all bidi handler for unregistered services. This crate-map [`Router`] answers `UNIMPLEMENTED` for an unmounted service, not a fallback [`Service`]. Distinct from [`Server`], which is one service. Distinct from [`Service::ALIASES`], which is a known path alias."),
        "crate-map must Distinct Router UNIMPLEMENTED from grpc-go UnknownServiceHandler catch-all"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WaitForHandlers`: grpc-go `Stop` can return before handlers exit. This crate-map [`Server::serve_with_shutdown`] drain always waits for in-flight RPCs. Distinct from [`ServerConfig::max_connection_age_grace`] (GOAWAY then force-close). Distinct from [`health::HealthReporter::shutdown`] (serving status, not drain)."),
        "crate-map must Distinct serve_with_shutdown drain wait from grpc-go WaitForHandlers"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithDisableHealthCheck`: that disables LB channel health checking for all SubConns. This crate-map [`health::HealthReporter`] is `grpc.health.v1` serving status; [`Channel`] does not run LB health probes. Distinct from [`health::HealthReporter::shutdown`] (serving status, not a DialOption). Distinct from [`Server::serve_with_shutdown`] (drain wait, not health probes). Distinct from [`Channel::connect`] (one duplex, no SubConns)."),
        "crate-map must Distinct HealthReporter grpc.health.v1 serving status from grpc-go WithDisableHealthCheck"
    );
    assert!(
        crate_src.contains("There is no tonic `Server::load_shed`: that is tower `LoadShedLayer` (fail when `poll_ready` is pending, instead of waiting). This crate-map [`ServerConfig::max_concurrent_rpcs`] already refuses extras as `RESOURCE_EXHAUSTED` (`try_acquire`, not wait). Distinct from tonic `Server::concurrency_limit_per_connection` (per-connection wait layer). Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct max_concurrent_rpcs try_acquire refuse from tonic Server::load_shed"
    );
    assert!(
        crate_src.contains("There is no grpc-go `SharedWriteBuffer`: that reuses a per-connection transport write buffer after flush. This crate-map [`ServerConfig::max_send_buffer_size`] is HTTP/2 write-byte backpressure per connection; buffers are not pooled across connections. Distinct from grpc-go `WriteBufferSize` / `ReadBufferSize` (socket byte buffers). Distinct from tonic `Endpoint::buffer_size` (tower `Buffer` request slots)."),
        "crate-map must Distinct ServerConfig::max_send_buffer_size from grpc-go SharedWriteBuffer reuse"
    );
    assert!(
        crate_src.contains("There is no tonic `Server::timeout` tower layer: that is `TimeoutLayer` wrapping every request handler. This crate-map [`ServerConfig::timeout`] is a gRPC deadline overlay when the client omits `grpc-timeout`. Distinct from [`ChannelConfig::timeout`] (client overlay). Distinct from [`ServerConfig::keep_alive_timeout`] (PING ACK). Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct ServerConfig::timeout gRPC deadline overlay from tonic Server::timeout TimeoutLayer"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::timeout` that omits `grpc-timeout`: that times out the client future without informing the server. This crate-map [`ChannelConfig::timeout`] writes `grpc-timeout` when the request omits one. Distinct from [`ServerConfig::timeout`] (server overlay). Distinct from [`ChannelConfig::connect_timeout`] (dial bound). Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct ChannelConfig::timeout grpc-timeout write from tonic Endpoint::timeout skip"
    );
    assert!(
        crate_src.contains("There is no grpc-go `ConnectionTimeout`: that is one deadline from accept through HTTP/2 handshake (default 120 s). This crate-map [`ServerConfig::handshake_timeout`] is 20 s on TLS accept (if any) and 20 s on the HTTP/2 preface, separately. Distinct from [`ChannelConfig::connect_timeout`] (client whole dial). Distinct from [`ServerConfig::timeout`] (RPC deadline overlay). Distinct from [`ServerConfig::keep_alive_timeout`] (PING ACK)."),
        "crate-map must Distinct ServerConfig::handshake_timeout sequential caps from grpc-go ConnectionTimeout"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::connect_with_connector`: that is a tower `Service<Uri>` that still dials. This crate-map [`Channel::from_io`] takes already-connected bytes; there is no connector and no URI. Distinct from [`Channel::connect_unix`] (filesystem path, not a connector). [`ChannelConfig::connect_timeout`] still bounds the HTTP/2 preface. Distinct from `tower` integration, which is protobuf-tonic keeping tonic."),
        "crate-map must Distinct Channel::from_io already-connected bytes from tonic Endpoint::connect_with_connector"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithBlock`: that is a DialOption that makes deprecated `Dial` wait until READY. This crate-map [`Channel::connect`] already waits for the TCP dial and HTTP/2 preface; there is no READY state. Distinct from [`Channel::connect_lazy`] (first RPC dials). Distinct from [`Channel::wait_for_ready`] (RPC queue, not Dial). Distinct from [`Channel::connected`] (live-socket snapshot). Distinct from gRPC `GetState` / `WaitForStateChange`. There is no `WithReturnConnectionError`: handshake failure is the returned [`Status`]."),
        "crate-map must Distinct Channel::connect handshake wait from grpc-go WithBlock READY"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithDisableRetry`: that disables service-config retries and does not impact transparent retries. This crate-map attaches `retryPolicy`/`hedgingPolicy` with [`Channel::service_config`]; omit the document (or the method's policy) for no policy retries, in which case application retries stay at the call site ([`Code::is_retryable`]). Transparent retry cannot be turned off. Distinct from [`Channel::from_io`] (no transparent retry)."),
        "crate-map must Distinct transparent retry from grpc-go WithDisableRetry"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithMaxCallAttempts`: that caps retries and hedging per call (default 5; values below 2 become 5). This crate-map reads `maxAttempts` from the method's `retryPolicy`/`hedgingPolicy` (values above 5 count as 5); transparent retry is at most once on top and cannot be raised. Distinct from [`Code::is_retryable`] (application retries at the call site, unbounded by this kernel)."),
        "crate-map must Distinct at-most-once transparent retry from grpc-go WithMaxCallAttempts"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithAuthority`: that sets `:authority` and the TLS authentication server name. This crate-map [`Channel::origin`] is `:authority` only. Distinct from [`ClientTls`] (SNI / certificate name). Distinct from tonic `Endpoint::origin` (Uri, also `:scheme`). There is no `CallAuthority`: interceptors cannot override `:authority` per call."),
        "crate-map must Distinct Channel::origin :authority-only overlay from grpc-go WithAuthority TLS server name"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithConnectParams`: that is exponential reconnect backoff plus `MinConnectTimeout` for creating and maintaining connections. This crate-map [`Channel::connect_with`] redials a dead slot on the next RPC with no channel-level reconnect backoff. There is no `WithBackoffMaxDelay` / `WithBackoffConfig` (deprecated aliases). Distinct from [`Channel::wait_for_ready`] (handshake retries at `[20, 40, 80, 160, 320, 640, 1000]` ms, not channel reconnect). Distinct from [`ChannelConfig::connect_timeout`] (max dial bound, default 20 s; not grpc-go `MinConnectTimeout`, also default 20 s). Distinct from transparent retry (one redial of the same RPC, not connect backoff)."),
        "crate-map must Distinct Channel::connect_with next-RPC redial from grpc-go WithConnectParams reconnect backoff"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithNoProxy`: grpc-go honors `HTTPS_PROXY` by default; that DialOption disables it. This crate-map consults `HTTPS_PROXY` / `NO_PROXY` on TCP dials and tunnels with HTTP CONNECT when the target is not bypassed; there is no per-channel proxy disable. Resolver-managed `dns:` dials connect to resolved IP literals, so host-suffix `NO_PROXY` rules only match before resolution. Distinct from [`Channel::from_io`] (already-connected bytes, not a proxy bypass). Distinct from [`Channel::connect_unix`] (filesystem path; this dialer is skipped). Distinct from [`ChannelConfig::local_address`] (source bind, not proxy)."),
        "crate-map must Distinct direct TCP dial from grpc-go WithNoProxy HTTPS_PROXY"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithInsecure`: modern grpc-go `NewClient` requires credentials (`insecure.NewCredentials()` or TLS). This crate-map [`Channel::connect`] is h2c by default; TLS is [`Channel::connect_tls`]. There is no `WithTransportCredentials` DialOption (TLS is [`Channel::connect_tls`] plus [`ClientTls`]). Distinct from a skip-verify constructor (there is none). Distinct from [`Channel::https_scheme`] (`from_io` label; it does not handshake)."),
        "crate-map must Distinct h2c-default Channel::connect from grpc-go WithInsecure credentials"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithUnaryInterceptor`: that is a DialOption for unary RPCs only. `WithStreamInterceptor` is the stream split. `WithChainUnaryInterceptor` / `WithChainStreamInterceptor` append DialOption lists. This crate-map [`ClientInterceptor`] is one hook for every call shape, attached with [`Channel::intercept`] after connect (not a DialOption). Calling intercept twice stacks; there is no chain DialOption. Distinct from [`Interceptor`] (inbound before the handler). Distinct from [`ResponseInterceptor`] (after Ok or after receive). Distinct from tonic `Interceptor` / `InterceptorLayer` (tower; this kernel has no tower)."),
        "crate-map must Distinct ClientInterceptor one hook for every call shape from grpc-go WithUnaryInterceptor DialOption split"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithDefaultCallOptions`: that is a DialOption bag of per-call options (`WaitForReady`, `MaxCallRecvMsgSize`, compressor, …) applied as channel defaults. This crate-map [`Channel`] clone overlays (`timeout`, `wait_for_ready`, `send_compressed`, message caps) are typed methods, not a `CallOption` list and not a DialOption. Distinct from grpc-go `WithDefaultServiceConfig` (JSON service config, not CallOptions). Distinct from [`ChannelConfig`] (handshake `Copy` fields). Distinct from [`Channel::intercept`] (per-RPC mutation after connect)."),
        "crate-map must Distinct Channel clone overlays from grpc-go WithDefaultCallOptions bag"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithCompressor`: that is a DialOption plugging a custom `encoding.Compressor` (deprecated; `encoding.RegisterCompressor` is global). This crate-map [`Channel::send_compressed`] is gzip on or off, not a compressor plugin. There is no `WithDecompressor` (deprecated inbound plugin). Distinct from encodings other than gzip (`UNIMPLEMENTED`, not a plugin). Distinct from [`Channel::gzip_compression_level`] (deflate effort, not a plugin). Distinct from grpc-go `UseCompressor` (a CallOption name, not this overlay)."),
        "crate-map must Distinct Channel::send_compressed gzip on/off from grpc-go WithCompressor plugin"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithContextDialer`: that is a DialOption plugging a custom `func(context.Context, string) (net.Conn, error)` that still dials. `WithDialer` is the deprecated context-less form. This crate-map [`Channel::connect_lazy`] still dials TCP `host:port` on the first RPC; there is no replacement hook. Distinct from tonic `Endpoint::connect_with_connector` (tower `Service<Uri>` that still dials). Distinct from [`Channel::from_io`] (already-connected bytes; it does not dial). Distinct from [`Channel::connect_unix`] (filesystem path, not a custom TCP dialer). Distinct from [`ChannelConfig::local_address`] (source bind, still this kernel's TCP dialer). Distinct from grpc-go `WithNoProxy` (proxy bypass, not a dial function). Distinct from grpc-go `WithBlock` (handshake wait, not a dial function)."),
        "crate-map must Distinct Channel::connect_lazy kernel TCP dial from grpc-go WithContextDialer"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithPerRPCCredentials`: that is a DialOption plugging `credentials.PerRPCCredentials` that add per-RPC metadata. This crate-map [`ClientTls`] is transport TLS, not call credentials. There is no `WithCredentialsBundle` (transport plus per-RPC credentials). Distinct from GCP-auth (a library, not this DialOption). Distinct from grpc-go `WithTransportCredentials` (transport; TLS is [`Channel::connect_tls`] plus [`ClientTls`]). Distinct from [`ClientInterceptor`] (user hook that can add metadata, not a credentials plugin). Distinct from [`Channel::intercept`] (attaches that hook after connect)."),
        "crate-map must Distinct ClientTls transport TLS from grpc-go WithPerRPCCredentials call credentials"
    );
    assert!(
        crate_src.contains("tonic `ServerTlsConfig::client_auth_optional` requests a client certificate but does not require one; the crate-map equivalent is [`ServerTls::optional_mtls`]. [`ServerTls::mtls`] always requires a client certificate issued by that CA. Distinct from [`ServerTls::new`] (clients are not asked). Distinct from a skip-verify constructor (there is none). Distinct from [`ClientTls::ca_mtls`] / [`ClientTls::webpki_mtls`] (client presents; this is the server require)."),
        "crate-map must Distinct ServerTls::mtls required client cert from tonic client_auth_optional"
    );
    assert!(
        crate_src.contains("There is no tonic `ServerTlsConfig::timeout`: that is a TLS-handshake-only timeout on the tonic acceptor. This crate-map [`ServerTls`] has no timeout setter; the bound is [`ServerConfig::handshake_timeout`] (20 s TLS accept and 20 s HTTP/2 preface, separately). Distinct from grpc-go `ConnectionTimeout` (one 120 s deadline covering both). Distinct from [`ChannelConfig::connect_timeout`] (client whole dial). Distinct from tonic `ClientTlsConfig::timeout` (client TLS handshake). Distinct from [`ServerConfig::timeout`] (RPC deadline overlay)."),
        "crate-map must Distinct ServerTls sequential handshake caps from tonic ServerTlsConfig::timeout TLS-only"
    );
    assert!(
        crate_src.contains("tonic `ServerTlsConfig::use_key_log` enables rustls `KeyLogFile` (`SSLKEYLOGFILE`); the crate-map equivalent is [`ServerTls::key_log_file`], and [`ClientTls::key_log_file`] for the client handshake. [`ServerTls::new`] alone does not enable key logging. Distinct from [`ServerTls::mtls`] (client cert require, not key log). Distinct from a skip-verify constructor (there is none)."),
        "crate-map must Distinct ServerTls::new no key log from tonic ServerTlsConfig::use_key_log"
    );
    assert!(
        crate_src.contains("There is no tonic `Server::trace_fn`: that intercepts inbound headers and installs a `tracing::Span` on each response future. This crate-map [`Server`] has no span installer. Distinct from [`Interceptor`] (envelope mutation, not a span). Distinct from grpc.stats `Handler` (Begin/End/payload). Distinct from binary logging (`grpc.binarylog.v1`). Distinct from OpenTelemetry. Distinct from tonic `Server::layer` (tower)."),
        "crate-map must Distinct Server no span installer from tonic Server::trace_fn"
    );
    assert!(
        crate_src.contains("There is no tonic `ClientTlsConfig::assume_http2`: that skips ALPN and still treats the socket as HTTP/2. This crate-map [`ClientTls::ca`] always requires ALPN `h2` after handshake. Distinct from [`Channel::connect`] (h2c, no TLS). Distinct from grpc-web / HTTP/1.1 (not prior-knowledge HTTP/2 on TLS). Distinct from [`ServerTls`] (server ALPN require; this is the client require). Distinct from a skip-verify constructor (there is none)."),
        "crate-map must Distinct ClientTls::ca required ALPN h2 from tonic ClientTlsConfig::assume_http2"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithDefaultServiceConfig`: that is JSON used when the name resolver does not provide a service config, or when `WithDisableServiceConfig` ignores the resolver. This crate-map [`ChannelConfig`] is typed `Copy` fields, not JSON; JSON service config attaches with [`Channel::service_config`] or arrives from resolver service config on [`Channel::connect_uri`]. Distinct from grpc-go `WithDisableRetry` (`retryPolicy` only). Distinct from [`ChannelConfig::timeout`] (kernel overlay, not methodConfig timeout). There is no `WithDisableServiceConfig`: omit [`Channel::service_config`] or avoid resolver service config instead."),
        "crate-map must Distinct ChannelConfig typed Copy fields from grpc-go WithDefaultServiceConfig JSON"
    );
    assert!(
        crate_src.contains("There is no grpc-go `WithIdleTimeout` idle mode: that shuts down the name resolver and load balancer after channel idle (default 30 min; zero disables). This crate-map [`ChannelConfig::max_connection_idle`] closes the socket when no RPCs are outstanding (unset by default; sub-millisecond values are raised to 1 ms, not disabled). Resolver-managed channels keep their resolver/LB handles until the channel is dropped. Distinct from [`ChannelConfig::max_connection_age`] (age, not idle). Distinct from [`ServerConfig::max_connection_idle`] (server GOAWAY)."),
        "crate-map must Distinct ChannelConfig::max_connection_idle socket close from grpc-go WithIdleTimeout idle mode"
    );
    assert!(
        crate_src.contains("tonic `Endpoint::tls_config_with_verifier` replaces WebPKI with a custom rustls `ServerCertVerifier`. [`ClientTls::webpki`] always verifies against Mozilla's CA set, and [`ClientTls::ca`] pins a CA. [`ClientTls::from_rustls`] retains a trusted application configuration and its verifier; callers own that policy's security, which this wrapper cannot certify. Disabling verification is unsupported."),
        "crate-map must Distinct ClientTls::webpki WebPKI verify from tonic tls_config_with_verifier"
    );
    assert!(
        crate_src.contains("There is no tonic `Endpoint::http2_adaptive_window`: that enables hyper adaptive flow control and overrides stream and connection windows. This crate-map [`ChannelConfig::initial_stream_window_size`] is a fixed SETTINGS window. Distinct from [`ChannelConfig::initial_connection_window_size`] (connection window, still fixed). Distinct from [`ChannelConfig::data_frame_budget`] (`h2 Auto` tiny-DATA budget, not window adaptation). Distinct from tonic `Server::http2_adaptive_window` (server adaptive override)."),
        "crate-map must Distinct ChannelConfig::initial_stream_window_size fixed SETTINGS from tonic http2_adaptive_window"
    );
    assert!(
        crate_src.contains(
            "[`DEFAULT_MAX_PENDING_ACCEPT_RESET_STREAMS`], override [`ServerConfig::max_pending_accept_reset_streams`]"
        ),
        "crate threat table must name max_pending_accept_reset_streams next to its default"
    );
    assert!(
        crate_src.contains(
            "[`DEFAULT_MAX_LOCAL_ERROR_RESET_STREAMS`], override [`ServerConfig::max_local_error_reset_streams`]"
        ),
        "crate threat table must name max_local_error_reset_streams next to its default"
    );
    assert!(
        crate_src.contains(
            "[`DEFAULT_MAX_CONCURRENT_RESET_STREAMS`], override [`ServerConfig::max_concurrent_reset_streams`]"
        ),
        "crate threat table must name max_concurrent_reset_streams next to its default"
    );
    assert!(
        crate_src.contains(
            "[`DEFAULT_DATA_FRAME_BUDGET`], override [`ServerConfig::data_frame_budget`]"
        ),
        "crate threat table must name data_frame_budget next to its default"
    );
    assert!(
        crate_src.contains("[`Streaming`] sees [`Code::Cancelled`]"),
        "crate threat table must name Code::Cancelled next to Streaming"
    );
    assert!(
        crate_src.contains("[`StreamSender::fail`]) | RST CANCEL; the [`Call`]"),
        "crate threat table must name Call next to StreamSender::fail"
    );
    assert!(
        crate_src.contains(
            "[`Call`] resolves with that status (client-streaming, or bidi before headers — not `UNAVAILABLE` from the reset); after bidi headers the received [`Streaming`]"
        ),
        "crate threat table must name Streaming next to Call"
    );
    assert!(
        crate_src.contains("[`ErrorDetails`], [`ErrorDetails::new`]"),
        "crate map must name ErrorDetails::new next to ErrorDetails"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::new`], [`ErrorDetails::with_error_info`]"),
        "crate map must name ErrorDetails::with_error_info next to ErrorDetails::new"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::with_error_info`], [`ErrorDetails::with_retry_info`]"),
        "crate map must name ErrorDetails::with_retry_info next to ErrorDetails::with_error_info"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::with_retry_info`], [`ErrorDetails::with_debug_info`]"),
        "crate map must name ErrorDetails::with_debug_info next to ErrorDetails::with_retry_info"
    );
    assert!(
        crate_src
            .contains("[`ErrorDetails::with_debug_info`], [`ErrorDetails::with_quota_failure`]"),
        "crate map must name ErrorDetails::with_quota_failure next to ErrorDetails::with_debug_info"
    );
    assert!(
        crate_src.contains(
            "[`ErrorDetails::with_quota_failure`], [`ErrorDetails::with_precondition_failure`]"
        ),
        "crate map must name ErrorDetails::with_precondition_failure next to ErrorDetails::with_quota_failure"
    );
    assert!(
        crate_src.contains(
            "[`ErrorDetails::with_precondition_failure`], [`ErrorDetails::with_bad_request`]"
        ),
        "crate map must name ErrorDetails::with_bad_request next to ErrorDetails::with_precondition_failure"
    );
    assert!(
        crate_src
            .contains("[`ErrorDetails::with_bad_request`], [`ErrorDetails::with_request_info`]"),
        "crate map must name ErrorDetails::with_request_info next to ErrorDetails::with_bad_request"
    );
    assert!(
        crate_src
            .contains("[`ErrorDetails::with_request_info`], [`ErrorDetails::with_resource_info`]"),
        "crate map must name ErrorDetails::with_resource_info next to ErrorDetails::with_request_info"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::with_resource_info`], [`ErrorDetails::with_help`]"),
        "crate map must name ErrorDetails::with_help next to ErrorDetails::with_resource_info"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::with_help`], [`ErrorDetails::with_localized_message`]"),
        "crate map must name ErrorDetails::with_localized_message next to ErrorDetails::with_help"
    );
    assert!(
        crate_src
            .contains("[`ErrorDetails::with_localized_message`], [`ErrorDetails::with_unknown`]"),
        "crate map must name ErrorDetails::with_unknown next to ErrorDetails::with_localized_message"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::with_unknown`], [`ErrorDetails::to_anys`]"),
        "crate map must name ErrorDetails::to_anys next to ErrorDetails::with_unknown"
    );
    assert!(
        crate_src.contains("[`pb`], [`Any::pack`]"),
        "crate map must name Any::pack next to pb"
    );
    assert!(
        crate_src.contains("[`Any::pack`], [`Any::pack_with`]"),
        "crate map must name Any::pack_with next to Any::pack"
    );
    assert!(
        crate_src.contains("[`Any::pack_with`], [`Any::is`]"),
        "crate map must name Any::is next to Any::pack_with"
    );
    assert!(
        crate_src.contains("[`Any::is`], [`Any::unpack`]"),
        "crate map must name Any::unpack next to Any::is"
    );
    assert!(
        crate_src.contains("[`Any::unpack`], [`ErrorDetails`]"),
        "crate map must name ErrorDetails next to Any::unpack"
    );
    assert!(
        crate_src.contains("[`ErrorDetails::to_anys`], [`ErrorDetails::from_rpc`]"),
        "crate map must name ErrorDetails::from_rpc next to to_anys"
    );
    assert!(
        crate_src.contains("[`Status::from_error_details`], [`Status::with_details`]"),
        "crate map must name Status::with_details next to the typed-bag constructor"
    );
    assert!(
        crate_src.contains("[`Status::with_details`], [`pb::Status::with_details`]"),
        "crate map must name pb::Status::with_details next to the raw-trailer constructor"
    );
    assert!(
        crate_src.contains("[`pb::Status::with_details`], [`Status::details`]"),
        "crate map must name Status::details next to pb::Status::with_details"
    );
    assert!(
        crate_src.contains("[`Status::details`], [`Status::rpc`]"),
        "crate map must name Status::rpc next to Status::details"
    );
    assert!(
        crate_src.contains("[`Status::from_error`], [`Status::with_cause`]"),
        "crate map must name Status::with_cause next to Status::from_error"
    );
    assert!(
        crate_src.contains("[`Status::with_cause`], [`Status::is_ok`]"),
        "crate map must name Status::is_ok next to Status::with_cause"
    );
    assert!(
        crate_src.contains("[`Status::is_ok`], [`Status::is_retryable`]"),
        "crate map must name Status::is_retryable next to Status::is_ok"
    );
    assert!(
        crate_src.contains("[`Status::is_retryable`], [`Status::retry_delay`]"),
        "crate map must name Status::retry_delay next to Status::is_retryable"
    );
    assert!(
        crate_src.contains("[`Status::retry_delay`], [`pb::Duration::from_std`]"),
        "crate map must name Duration::from_std next to Status::retry_delay"
    );
    assert!(
        crate_src.contains(
            "Unknown types stay in [`ErrorDetails::unknown`] so a custom detail is not dropped on a round-trip."
        ),
        "crate docs must name ErrorDetails::unknown so a custom detail is not dropped on a round-trip"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::user_agent_is_set`] is occupancy on this crate-map interceptor path, so a later interceptor can prefix only when unset."
        ),
        "crate docs must name Outgoing::user_agent_is_set occupancy next to ErrorDetails::unknown"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::wait_for_ready_is_set`] is occupancy on this crate-map interceptor path, so a later interceptor can fill wait-for-ready only when unset."
        ),
        "crate docs must name Outgoing::wait_for_ready_is_set occupancy next to user_agent occupancy"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::compress_is_set`] is occupancy on this crate-map interceptor path, so a later interceptor can fill compress only when unset."
        ),
        "crate docs must name Outgoing::compress_is_set occupancy next to wait_for_ready occupancy"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::clear_user_agent`] restores the channel user-agent after a crate-map interceptor prefix."
        ),
        "crate docs must name Outgoing::clear_user_agent next to compress occupancy"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::clear_wait_for_ready`] restores the channel wait-for-ready overlay after a crate-map interceptor choice."
        ),
        "crate docs must name Outgoing::clear_wait_for_ready next to clear_user_agent"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::clear_compress`] then [`Outgoing::set_compress`] from [`Outgoing::compresses_outbound`] reapplies channel gzip after a crate-map interceptor choice."
        ),
        "crate docs must name Outgoing::clear_compress reapply next to clear_wait_for_ready"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::clear_timeout`] opts out of the channel timeout after a crate-map interceptor choice."
        ),
        "crate docs must name Outgoing::clear_timeout next to clear_compress"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot next to clear_timeout"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map handler Err: that is after the handler ran; this crate-map interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map handler Err after the handler ran from this crate-map interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server intercept Err: that is trailers without reading the body; this crate-map interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map server intercept Err without reading the body from this crate-map interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ClientInterceptor`]: that runs on the outbound call before the stream opens; this crate-map [`Interceptor`] runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct ClientInterceptor outbound-before-stream from inbound Interceptor"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Interceptor`]: that runs on the inbound RPC before the handler; this crate-map [`ClientInterceptor`] runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct Interceptor inbound-before-handler from outbound ClientInterceptor"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this crate-map [`Interceptor`] runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct ResponseInterceptor after-Ok-or-receive from inbound Interceptor"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Interceptor`]: that runs on the inbound RPC before the handler; this crate-map [`ResponseInterceptor`] runs after the handler returns Ok or after a successful receive."
        ),
        "crate docs must Distinct Interceptor inbound-before-handler from crate-map ResponseInterceptor after-Ok-or-receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ClientInterceptor`]: that runs on the outbound call before the stream opens; this crate-map [`ResponseInterceptor`] runs after the handler returns Ok or after a successful receive."
        ),
        "crate docs must Distinct ClientInterceptor outbound-before-stream from crate-map ResponseInterceptor after-Ok-or-receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ResponseInterceptor`]: that runs after the handler returns Ok or after a successful receive; this crate-map [`ClientInterceptor`] runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct ResponseInterceptor after-Ok-or-receive from outbound ClientInterceptor"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Interceptor`]: that is the inbound hook; this crate-map [`Intercepted`] is the wrapper that runs it before the handler."
        ),
        "crate docs must Distinct Interceptor inbound hook from Intercepted wrapper"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ClientInterceptor`]: that is the outbound hook; this crate-map [`Intercepted`] is the wrapper that runs an inbound [`Interceptor`] before the handler."
        ),
        "crate docs must Distinct ClientInterceptor outbound hook from Intercepted wrapper"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`ResponseInterceptor`]: that is the after-Ok hook; this crate-map [`Intercepted`] runs before the handler and may hold that hook for after Ok."
        ),
        "crate docs must Distinct ResponseInterceptor after-Ok hook from Intercepted wrapper"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Server::intercept`]: that runs on the inbound RPC before the handler; this crate-map Channel intercept runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct Server inbound-before-handler from crate-map Channel intercept outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::on_response`]: that runs after a successful receive; this crate-map Channel intercept runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct crate-map Channel intercept from Channel on_response"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::intercept`]: that runs on the outbound call before the stream opens; this crate-map server intercept runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct Channel outbound-before-stream from crate-map server intercept inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Server::on_response`]: that runs after the handler returns Ok; this crate-map server intercept runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct crate-map server intercept from Server on_response"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map server intercept Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map server intercept Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map handler Err: that is after the handler ran; this crate-map server intercept Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map handler Err after the handler ran from this crate-map server intercept Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map server intercept Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map server intercept Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map server intercept Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map server intercept Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map interceptor Err: that is a local reject never opens a stream; this crate-map server intercept Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map interceptor Err local reject never opens a stream from this crate-map server intercept Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Health interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Health interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health handler Err: that is after the handler ran; this crate-map Health interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Health handler Err after the handler ran from this crate-map Health interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Health interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Health interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health client interceptor Err: that is a local reject never opens a stream; this crate-map Health interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Health client interceptor Err local reject never opens a stream from this crate-map Health interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Health interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Health interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health StreamSender fail: that is trailers after any messages already sent; this crate-map Health interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Health StreamSender fail after any messages already sent from this crate-map Health interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health client interceptor: that runs on the outbound call before the stream opens; this crate-map Health interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct Health client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Health handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Health handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor Err: that is trailers without reading the body; this crate-map Health handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Health interceptor Err without reading the body from this crate-map Health handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health client interceptor Err: that is a local reject never opens a stream; this crate-map Health handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Health client interceptor Err local reject never opens a stream from this crate-map Health handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Health handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Health handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Health handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Health handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health StreamSender fail: that is trailers after any messages already sent; this crate-map Health handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Health StreamSender fail after any messages already sent from this crate-map Health handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map Health client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map Health"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Health client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Health client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health handler Err: that is after the handler ran; this crate-map Health client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Health handler Err after the handler ran from this crate-map Health client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Health client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Health client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor Err: that is trailers without reading the body; this crate-map Health client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Health interceptor Err without reading the body from this crate-map Health client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health StreamSender fail: that is trailers after any messages already sent; this crate-map Health client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Health StreamSender fail after any messages already sent from this crate-map Health client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map Health client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map Health client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor: that runs on the inbound RPC before the handler; this crate-map Health client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct Health inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Health StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Health StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health handler Err: that is after the handler ran; this crate-map Health StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Health handler Err after the handler ran from this crate-map Health StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor Err: that is trailers without reading the body; this crate-map Health StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Health interceptor Err without reading the body from this crate-map Health StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Health StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Health StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health client interceptor Err: that is a local reject never opens a stream; this crate-map Health StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Health client interceptor Err local reject never opens a stream from this crate-map Health StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Health StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Health StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map reflection interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map reflection interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection handler Err: that is after the handler ran; this crate-map reflection interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map reflection handler Err after the handler ran from this crate-map reflection interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map reflection interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map reflection interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection client interceptor Err: that is a local reject never opens a stream; this crate-map reflection interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map reflection client interceptor Err local reject never opens a stream from this crate-map reflection interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map reflection interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map reflection interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection StreamSender fail: that is trailers after any messages already sent; this crate-map reflection interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map reflection StreamSender fail after any messages already sent from this crate-map reflection interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection client interceptor: that runs on the outbound call before the stream opens; this crate-map reflection interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct reflection client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map reflection handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map reflection handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor Err: that is trailers without reading the body; this crate-map reflection handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map reflection interceptor Err without reading the body from this crate-map reflection handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection client interceptor Err: that is a local reject never opens a stream; this crate-map reflection handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map reflection client interceptor Err local reject never opens a stream from this crate-map reflection handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map reflection handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map reflection handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map reflection handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map reflection handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection StreamSender fail: that is trailers after any messages already sent; this crate-map reflection handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map reflection StreamSender fail after any messages already sent from this crate-map reflection handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map reflection client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map reflection"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map reflection client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map reflection client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection handler Err: that is after the handler ran; this crate-map reflection client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map reflection handler Err after the handler ran from this crate-map reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map reflection client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor Err: that is trailers without reading the body; this crate-map reflection client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map reflection interceptor Err without reading the body from this crate-map reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection StreamSender fail: that is trailers after any messages already sent; this crate-map reflection client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map reflection StreamSender fail after any messages already sent from this crate-map reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map reflection client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map reflection client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor: that runs on the inbound RPC before the handler; this crate-map reflection client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct reflection inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map reflection StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map reflection StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection handler Err: that is after the handler ran; this crate-map reflection StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map reflection handler Err after the handler ran from this crate-map reflection StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor Err: that is trailers without reading the body; this crate-map reflection StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map reflection interceptor Err without reading the body from this crate-map reflection StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map reflection StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map reflection StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection client interceptor Err: that is a local reject never opens a stream; this crate-map reflection StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map reflection client interceptor Err local reject never opens a stream from this crate-map reflection StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map reflection StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map reflection StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Store interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Store interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store handler Err: that is after the handler ran; this crate-map Store interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Store handler Err after the handler ran from this crate-map Store interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Store interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Store interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store client interceptor Err: that is a local reject never opens a stream; this crate-map Store interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Store client interceptor Err local reject never opens a stream from this crate-map Store interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Store interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Store interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store StreamSender fail: that is trailers after any messages already sent; this crate-map Store interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Store StreamSender fail after any messages already sent from this crate-map Store interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store client interceptor: that runs on the outbound call before the stream opens; this crate-map Store interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct Store client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Store handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Store handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor Err: that is trailers without reading the body; this crate-map Store handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Store interceptor Err without reading the body from this crate-map Store handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store client interceptor Err: that is a local reject never opens a stream; this crate-map Store handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Store client interceptor Err local reject never opens a stream from this crate-map Store handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Store handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Store handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Store handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Store handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store StreamSender fail: that is trailers after any messages already sent; this crate-map Store handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Store StreamSender fail after any messages already sent from this crate-map Store handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map Store client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map Store"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Store client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Store client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store handler Err: that is after the handler ran; this crate-map Store client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Store handler Err after the handler ran from this crate-map Store client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Store client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Store client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor Err: that is trailers without reading the body; this crate-map Store client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Store interceptor Err without reading the body from this crate-map Store client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store StreamSender fail: that is trailers after any messages already sent; this crate-map Store client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Store StreamSender fail after any messages already sent from this crate-map Store client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map Store client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map Store client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor: that runs on the inbound RPC before the handler; this crate-map Store client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct Store inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Store StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Store StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store handler Err: that is after the handler ran; this crate-map Store StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Store handler Err after the handler ran from this crate-map Store StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor Err: that is trailers without reading the body; this crate-map Store StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Store interceptor Err without reading the body from this crate-map Store StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Store StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Store StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store client interceptor Err: that is a local reject never opens a stream; this crate-map Store StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Store client interceptor Err local reject never opens a stream from this crate-map Store StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Store StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Store StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map TestService interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map TestService interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService handler Err: that is after the handler ran; this crate-map TestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map TestService handler Err after the handler ran from this crate-map TestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map TestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map TestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService client interceptor Err: that is a local reject never opens a stream; this crate-map TestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map TestService client interceptor Err local reject never opens a stream from this crate-map TestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map TestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map TestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService StreamSender fail: that is trailers after any messages already sent; this crate-map TestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map TestService StreamSender fail after any messages already sent from this crate-map TestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService client interceptor: that runs on the outbound call before the stream opens; this crate-map TestService interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct TestService client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map TestService handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map TestService handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor Err: that is trailers without reading the body; this crate-map TestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map TestService interceptor Err without reading the body from this crate-map TestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService client interceptor Err: that is a local reject never opens a stream; this crate-map TestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map TestService client interceptor Err local reject never opens a stream from this crate-map TestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map TestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map TestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map TestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map TestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService StreamSender fail: that is trailers after any messages already sent; this crate-map TestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map TestService StreamSender fail after any messages already sent from this crate-map TestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map TestService client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map TestService"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map TestService client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map TestService client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService handler Err: that is after the handler ran; this crate-map TestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map TestService handler Err after the handler ran from this crate-map TestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map TestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map TestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor Err: that is trailers without reading the body; this crate-map TestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map TestService interceptor Err without reading the body from this crate-map TestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService StreamSender fail: that is trailers after any messages already sent; this crate-map TestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map TestService StreamSender fail after any messages already sent from this crate-map TestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map TestService client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map TestService client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor: that runs on the inbound RPC before the handler; this crate-map TestService client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct TestService inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map TestService StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map TestService StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService handler Err: that is after the handler ran; this crate-map TestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map TestService handler Err after the handler ran from this crate-map TestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor Err: that is trailers without reading the body; this crate-map TestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map TestService interceptor Err without reading the body from this crate-map TestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map TestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map TestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService client interceptor Err: that is a local reject never opens a stream; this crate-map TestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map TestService client interceptor Err local reject never opens a stream from this crate-map TestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map TestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map TestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Reverser interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Reverser interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser handler Err: that is after the handler ran; this crate-map Reverser interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Reverser handler Err after the handler ran from this crate-map Reverser interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Reverser interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Reverser interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser client interceptor Err: that is a local reject never opens a stream; this crate-map Reverser interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Reverser client interceptor Err local reject never opens a stream from this crate-map Reverser interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Reverser interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Reverser interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser StreamSender fail: that is trailers after any messages already sent; this crate-map Reverser interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Reverser StreamSender fail after any messages already sent from this crate-map Reverser interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser client interceptor: that runs on the outbound call before the stream opens; this crate-map Reverser interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct Reverser client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Reverser handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Reverser handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor Err: that is trailers without reading the body; this crate-map Reverser handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Reverser interceptor Err without reading the body from this crate-map Reverser handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser client interceptor Err: that is a local reject never opens a stream; this crate-map Reverser handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Reverser client interceptor Err local reject never opens a stream from this crate-map Reverser handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Reverser handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Reverser handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Reverser handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Reverser handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser StreamSender fail: that is trailers after any messages already sent; this crate-map Reverser handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Reverser StreamSender fail after any messages already sent from this crate-map Reverser handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map Reverser client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map Reverser"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Reverser client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Reverser client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser handler Err: that is after the handler ran; this crate-map Reverser client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Reverser handler Err after the handler ran from this crate-map Reverser client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Reverser client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Reverser client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor Err: that is trailers without reading the body; this crate-map Reverser client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Reverser interceptor Err without reading the body from this crate-map Reverser client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser StreamSender fail: that is trailers after any messages already sent; this crate-map Reverser client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Reverser StreamSender fail after any messages already sent from this crate-map Reverser client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map Reverser client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map Reverser client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor: that runs on the inbound RPC before the handler; this crate-map Reverser client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct Reverser inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Reverser StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Reverser StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser handler Err: that is after the handler ran; this crate-map Reverser StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Reverser handler Err after the handler ran from this crate-map Reverser StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor Err: that is trailers without reading the body; this crate-map Reverser StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Reverser interceptor Err without reading the body from this crate-map Reverser StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Reverser StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Reverser StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser client interceptor Err: that is a local reject never opens a stream; this crate-map Reverser StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Reverser client interceptor Err local reject never opens a stream from this crate-map Reverser StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map Reverser StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map Reverser StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map hello interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map hello interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello handler Err: that is after the handler ran; this crate-map hello interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map hello handler Err after the handler ran from this crate-map hello interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map hello interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map hello interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello client interceptor Err: that is a local reject never opens a stream; this crate-map hello interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map hello client interceptor Err local reject never opens a stream from this crate-map hello interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map hello interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map hello interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello StreamSender fail: that is trailers after any messages already sent; this crate-map hello interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map hello StreamSender fail after any messages already sent from this crate-map hello interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello client interceptor: that runs on the outbound call before the stream opens; this crate-map hello interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct hello client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map hello handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map hello handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor Err: that is trailers without reading the body; this crate-map hello handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map hello interceptor Err without reading the body from this crate-map hello handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello client interceptor Err: that is a local reject never opens a stream; this crate-map hello handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map hello client interceptor Err local reject never opens a stream from this crate-map hello handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map hello handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map hello handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map hello handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map hello handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello StreamSender fail: that is trailers after any messages already sent; this crate-map hello handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map hello StreamSender fail after any messages already sent from this crate-map hello handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map hello client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map hello"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map hello client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map hello client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello handler Err: that is after the handler ran; this crate-map hello client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map hello handler Err after the handler ran from this crate-map hello client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map hello client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map hello client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor Err: that is trailers without reading the body; this crate-map hello client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map hello interceptor Err without reading the body from this crate-map hello client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello StreamSender fail: that is trailers after any messages already sent; this crate-map hello client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map hello StreamSender fail after any messages already sent from this crate-map hello client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map hello client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map hello client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor: that runs on the inbound RPC before the handler; this crate-map hello client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct hello inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map hello StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map hello StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello handler Err: that is after the handler ran; this crate-map hello StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map hello handler Err after the handler ran from this crate-map hello StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor Err: that is trailers without reading the body; this crate-map hello StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map hello interceptor Err without reading the body from this crate-map hello StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map hello StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map hello StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello client interceptor Err: that is a local reject never opens a stream; this crate-map hello StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map hello client interceptor Err local reject never opens a stream from this crate-map hello StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map hello StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map hello StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map UnimplementedService interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map UnimplementedService interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService handler Err: that is after the handler ran; this crate-map UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map UnimplementedService handler Err after the handler ran from this crate-map UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService client interceptor Err: that is a local reject never opens a stream; this crate-map UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map UnimplementedService client interceptor Err local reject never opens a stream from this crate-map UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map UnimplementedService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map UnimplementedService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService client interceptor: that runs on the outbound call before the stream opens; this crate-map UnimplementedService interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct UnimplementedService client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map UnimplementedService handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map UnimplementedService handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService interceptor Err: that is trailers without reading the body; this crate-map UnimplementedService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map UnimplementedService interceptor Err without reading the body from this crate-map UnimplementedService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService client interceptor Err: that is a local reject never opens a stream; this crate-map UnimplementedService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map UnimplementedService client interceptor Err local reject never opens a stream from this crate-map UnimplementedService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map UnimplementedService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map UnimplementedService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map UnimplementedService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map UnimplementedService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map UnimplementedService client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map UnimplementedService"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map UnimplementedService client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map UnimplementedService client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService handler Err: that is after the handler ran; this crate-map UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map UnimplementedService handler Err after the handler ran from this crate-map UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService interceptor Err: that is trailers without reading the body; this crate-map UnimplementedService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map UnimplementedService interceptor Err without reading the body from this crate-map UnimplementedService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map UnimplementedService client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map UnimplementedService client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService interceptor: that runs on the inbound RPC before the handler; this crate-map UnimplementedService client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct UnimplementedService inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map InteropTestService interceptor Err; those trailers reach the client without reading the body."
        ),
        "crate docs must name from_error_details typed bag next to crate-map InteropTestService interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService handler Err: that is after the handler ran; this crate-map InteropTestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map InteropTestService handler Err after the handler ran from this crate-map InteropTestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map InteropTestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map InteropTestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService client interceptor Err: that is a local reject never opens a stream; this crate-map InteropTestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map InteropTestService client interceptor Err local reject never opens a stream from this crate-map InteropTestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map InteropTestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map InteropTestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService StreamSender fail: that is trailers after any messages already sent; this crate-map InteropTestService interceptor Err is trailers without reading the body."
        ),
        "crate docs must Distinct crate-map InteropTestService StreamSender fail after any messages already sent from this crate-map InteropTestService interceptor Err without reading the body"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService client interceptor: that runs on the outbound call before the stream opens; this crate-map InteropTestService interceptor runs on the inbound RPC before the handler."
        ),
        "crate docs must Distinct InteropTestService client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map InteropTestService handler Err; those trailers reach the client."
        ),
        "crate docs must name from_error_details typed bag next to crate-map InteropTestService handler Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor Err: that is trailers without reading the body; this crate-map InteropTestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map InteropTestService interceptor Err without reading the body from this crate-map InteropTestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService client interceptor Err: that is a local reject never opens a stream; this crate-map InteropTestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map InteropTestService client interceptor Err local reject never opens a stream from this crate-map InteropTestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map InteropTestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map InteropTestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map InteropTestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map InteropTestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService StreamSender fail: that is trailers after any messages already sent; this crate-map InteropTestService handler Err is after the handler ran."
        ),
        "crate docs must Distinct crate-map InteropTestService StreamSender fail after any messages already sent from this crate-map InteropTestService handler Err after the handler ran"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot on this crate-map InteropTestService client interceptor path ([`Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "crate docs must name Outgoing::connected live-socket snapshot on crate-map InteropTestService"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map InteropTestService client interceptor Err; a local reject never opens a stream."
        ),
        "crate docs must name from_error_details typed bag next to crate-map InteropTestService client interceptor Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService handler Err: that is after the handler ran; this crate-map InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map InteropTestService handler Err after the handler ran from this crate-map InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor Err: that is trailers without reading the body; this crate-map InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map InteropTestService interceptor Err without reading the body from this crate-map InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService StreamSender fail: that is trailers after any messages already sent; this crate-map InteropTestService client interceptor Err is a local reject never opens a stream."
        ),
        "crate docs must Distinct crate-map InteropTestService StreamSender fail after any messages already sent from this crate-map InteropTestService client interceptor Err local reject never opens a stream"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::max_concurrent_rpcs`]: that takes a slot when the [`Call`] is polled; this crate-map InteropTestService client interceptor already ran, so a local Err never consumes that budget."
        ),
        "crate docs must Distinct max_concurrent_rpcs slot grab after crate-map InteropTestService client intercept"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor: that runs on the inbound RPC before the handler; this crate-map InteropTestService client interceptor runs on the outbound call before the stream opens."
        ),
        "crate docs must Distinct InteropTestService inbound interceptor from client outbound-before-stream"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map InteropTestService StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "crate docs must name from_error_details typed bag next to crate-map InteropTestService StreamSender fail"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService handler Err: that is after the handler ran; this crate-map InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map InteropTestService handler Err after the handler ran from this crate-map InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor Err: that is trailers without reading the body; this crate-map InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map InteropTestService interceptor Err without reading the body from this crate-map InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService client interceptor Err: that is a local reject never opens a stream; this crate-map InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map InteropTestService client interceptor Err local reject never opens a stream from this crate-map InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map InteropTestService StreamSender fail is trailers after any messages already sent."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map InteropTestService StreamSender fail after any messages already sent"
    );
    assert!(
        crate_src.contains(
            "[`ResponseParts::compress_is_set`] is occupancy on this crate-map on_response path, so a later interceptor can fill compress only when unset."
        ),
        "crate docs must name ResponseParts::compress_is_set occupancy next to intercept clear_timeout"
    );
    assert!(
        crate_src.contains(
            "[`ResponseParts::clear_compress`] restores the server gzip overlay after Server on_response on this crate-map on_response path."
        ),
        "crate docs must name ResponseParts::clear_compress next to on_response occupancy"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "crate docs must name from_error_details typed bag next to crate-map server on_response Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map handler Err: that is after the handler ran; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map handler Err after the handler ran from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server intercept Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map server intercept Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Health interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Health StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map reflection interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map reflection StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Store interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Store StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map TestService interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map TestService StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Reverser interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Reverser StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map hello interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map hello StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map UnimplementedService interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor Err: that is trailers without reading the body; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map InteropTestService interceptor Err without reading the body from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService StreamSender fail: that is trailers after any messages already sent; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map InteropTestService StreamSender fail after any messages already sent from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Channel on_response Err: that fails the Call after a successful receive; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map Channel on_response Err Call fail after receive from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map interceptor Err: that is a local reject never opens a stream; this crate-map server on_response Err is trailers-only after handler Ok."
        ),
        "crate docs must Distinct crate-map interceptor Err local reject never opens a stream from this crate-map server on_response Err trailers-only after handler Ok"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Server::intercept`]: that runs on the inbound RPC before the handler; this crate-map server on_response runs after the handler returns Ok."
        ),
        "crate docs must Distinct crate-map server on_response from Server intercept"
    );
    assert!(
        crate_src.contains(
            "[`ResponseParts::clear_compress`] drops a compress choice after Channel on_response on this crate-map on_response path; a received reply has no server gzip overlay to restore."
        ),
        "crate docs must name ResponseParts::clear_compress receive-path next to Server restore"
    );
    assert!(
        crate_src.contains(
            "[`Status::from_error_details`] is the typed bag after this crate-map Channel on_response Err; a local reject fails the Call after a successful receive."
        ),
        "crate docs must name from_error_details typed bag next to crate-map Channel on_response Err"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map handler Err: that is after the handler ran; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map handler Err after the handler ran from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Health client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Health interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Health StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Health StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map reflection client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map reflection interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map reflection StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map reflection StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Store client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Store interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Store StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Store StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map TestService client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map TestService interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map TestService StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map TestService StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Reverser client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Reverser interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map Reverser StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map Reverser StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map hello client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map hello interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map hello StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map hello StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map UnimplementedService client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map UnimplementedService interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map UnimplementedService interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService client interceptor Err: that is a local reject never opens a stream; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map InteropTestService client interceptor Err local reject never opens a stream from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService interceptor Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map InteropTestService interceptor Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map InteropTestService StreamSender fail: that is trailers after any messages already sent; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map InteropTestService StreamSender fail after any messages already sent from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server intercept Err: that is trailers without reading the body; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map server intercept Err without reading the body from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from a crate-map server on_response Err: that is trailers-only after handler Ok; this crate-map Channel on_response Err fails the Call after a successful receive."
        ),
        "crate docs must Distinct crate-map server on_response Err trailers-only after handler Ok from this crate-map Channel on_response Err Call fail after receive"
    );
    assert!(
        crate_src.contains(
            "Distinct from [`Channel::intercept`]: that runs on the outbound call before the stream opens; this crate-map Channel on_response runs after a successful receive."
        ),
        "crate docs must Distinct crate-map Channel on_response from Channel intercept"
    );
    assert!(
        crate_src.contains(
            "[`Status::set_rpc`], [`Status::set_details`], [`Status::set_error_details`], [`Status::set_from_error_details`]"
        ),
        "crate map must name Status::set_details next to set_rpc and set_error_details"
    );
    assert!(
        crate_src.contains("[`Status::set_from_error_details`], [`Status::with_rpc`]"),
        "crate map must name Status::with_rpc next to set_from_error_details"
    );
    assert!(
        crate_src.contains("[`Status::with_rpc`], [`Status::from_error`]"),
        "crate map must name Status::from_error next to Status::with_rpc"
    );
    assert!(
        crate_src.contains("[`pb::Duration::from_std`], [`pb::Duration::try_to_std`]"),
        "crate map must name Duration::try_to_std next to Duration::from_std"
    );
    assert!(
        crate_src.contains("[`pb::Duration::try_to_std`], [`pb::RetryInfo::with_retry_delay`]"),
        "crate map must name RetryInfo::with_retry_delay next to Duration::try_to_std"
    );
    assert!(
        crate_src.contains("[`pb::RetryInfo::with_retry_delay`], [`Status::error_info`]"),
        "crate map must name Status::error_info next to RetryInfo::with_retry_delay"
    );
    assert!(
        crate_src.contains("[`Status::error_info`], [`pb::ErrorInfo::with_reason`]"),
        "crate map must name ErrorInfo::with_reason next to Status::error_info"
    );
    assert!(
        crate_src.contains("[`pb::ErrorInfo::with_reason`], [`pb::ErrorInfo::with_metadata`]"),
        "crate map must name ErrorInfo::with_metadata next to ErrorInfo::with_reason"
    );
    assert!(
        crate_src.contains("[`pb::ErrorInfo::with_metadata`], [`Status::bad_request`]"),
        "crate map must name Status::bad_request next to ErrorInfo::with_metadata"
    );
    assert!(
        crate_src.contains("[`Status::bad_request`], [`pb::BadRequest::with_field`]"),
        "crate map must name BadRequest::with_field next to Status::bad_request"
    );
    assert!(
        crate_src.contains("[`pb::BadRequest::with_field`], [`pb::BadRequest::with_field_entry`]"),
        "crate map must name BadRequest::with_field_entry next to BadRequest::with_field"
    );
    assert!(
        crate_src
            .contains("[`pb::BadRequest::with_field_entry`], [`pb::FieldViolation::with_field`]"),
        "crate map must name FieldViolation::with_field next to BadRequest::with_field_entry"
    );
    assert!(
        crate_src
            .contains("[`pb::FieldViolation::with_field`], [`pb::FieldViolation::with_reason`]"),
        "crate map must name FieldViolation::with_reason next to FieldViolation::with_field"
    );
    assert!(
        crate_src.contains(
            "[`pb::FieldViolation::with_reason`], [`pb::FieldViolation::with_localized_message`]"
        ),
        "crate map must name FieldViolation::with_localized_message next to FieldViolation::with_reason"
    );
    assert!(
        crate_src.contains("[`pb::FieldViolation::with_localized_message`], [`pb::bad_request`]"),
        "crate map must name pb::bad_request next to FieldViolation::with_localized_message"
    );
    assert!(
        crate_src.contains("[`pb::bad_request`], [`Status::quota_failure`]"),
        "crate map must name Status::quota_failure next to pb::bad_request"
    );
    assert!(
        crate_src.contains("[`Status::quota_failure`], [`pb::QuotaFailure::with_violation`]"),
        "crate map must name QuotaFailure::with_violation next to Status::quota_failure"
    );
    assert!(
        crate_src.contains(
            "[`pb::QuotaFailure::with_violation`], [`pb::QuotaFailure::with_violation_entry`]"
        ),
        "crate map must name QuotaFailure::with_violation_entry next to QuotaFailure::with_violation"
    );
    assert!(
        crate_src.contains("[`pb::QuotaFailure::with_violation_entry`], [`pb::quota_failure::Violation::with_subject`]"),
        "crate map must name quota_failure::Violation::with_subject next to QuotaFailure::with_violation_entry"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_subject`], [`pb::quota_failure::Violation::with_api_service`]"),
        "crate map must name quota_failure::Violation::with_api_service next to quota_failure::Violation::with_subject"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_api_service`], [`pb::quota_failure::Violation::with_quota_metric`]"),
        "crate map must name quota_failure::Violation::with_quota_metric next to quota_failure::Violation::with_api_service"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_quota_metric`], [`pb::quota_failure::Violation::with_quota_id`]"),
        "crate map must name quota_failure::Violation::with_quota_id next to quota_failure::Violation::with_quota_metric"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_quota_id`], [`pb::quota_failure::Violation::with_quota_dimension`]"),
        "crate map must name quota_failure::Violation::with_quota_dimension next to quota_failure::Violation::with_quota_id"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_quota_dimension`], [`pb::quota_failure::Violation::with_quota_value`]"),
        "crate map must name quota_failure::Violation::with_quota_value next to quota_failure::Violation::with_quota_dimension"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_quota_value`], [`pb::quota_failure::Violation::with_future_quota_value`]"),
        "crate map must name quota_failure::Violation::with_future_quota_value next to quota_failure::Violation::with_quota_value"
    );
    assert!(
        crate_src.contains(
            "[`pb::quota_failure::Violation::with_future_quota_value`], [`pb::quota_failure`]"
        ),
        "crate map must name pb::quota_failure next to quota_failure::Violation::with_future_quota_value"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure`], [`Status::precondition_failure`]"),
        "crate map must name Status::precondition_failure next to pb::quota_failure"
    );
    assert!(
        crate_src.contains(
            "[`Status::precondition_failure`], [`pb::PreconditionFailure::with_violation`]"
        ),
        "crate map must name PreconditionFailure::with_violation next to Status::precondition_failure"
    );
    assert!(
        crate_src.contains("[`pb::PreconditionFailure::with_violation`], [`pb::PreconditionFailure::with_violation_entry`]"),
        "crate map must name PreconditionFailure::with_violation_entry next to PreconditionFailure::with_violation"
    );
    assert!(
        crate_src.contains("[`pb::PreconditionFailure::with_violation_entry`], [`pb::precondition_failure::Violation::with_type`]"),
        "crate map must name precondition_failure::Violation::with_type next to PreconditionFailure::with_violation_entry"
    );
    assert!(
        crate_src.contains(
            "[`pb::precondition_failure::Violation::with_type`], [`pb::precondition_failure`]"
        ),
        "crate map must name pb::precondition_failure next to precondition_failure::Violation::with_type"
    );
    assert!(
        crate_src.contains("[`pb::precondition_failure`], [`Status::help`]"),
        "crate map must name Status::help next to pb::precondition_failure"
    );
    assert!(
        crate_src.contains("[`Status::help`], [`pb::Help::with_link`]"),
        "crate map must name Help::with_link next to Status::help"
    );
    assert!(
        crate_src.contains("[`pb::Help::with_link`], [`pb::Help::with_link_entry`]"),
        "crate map must name Help::with_link_entry next to Help::with_link"
    );
    assert!(
        crate_src.contains("[`pb::Help::with_link_entry`], [`pb::help::Link::with_url`]"),
        "crate map must name help::Link::with_url next to Help::with_link_entry"
    );
    assert!(
        crate_src.contains("[`pb::help::Link::with_url`], [`pb::help`]"),
        "crate map must name pb::help next to help::Link::with_url"
    );
    assert!(
        crate_src.contains("[`pb::help`], [`Status::localized_message`]"),
        "crate map must name Status::localized_message next to pb::help"
    );
    assert!(
        crate_src.contains("[`Status::localized_message`], [`pb::LocalizedMessage::with_locale`]"),
        "crate map must name LocalizedMessage::with_locale next to Status::localized_message"
    );
    assert!(
        crate_src.contains("[`pb::LocalizedMessage::with_locale`], [`Status::request_info`]"),
        "crate map must name Status::request_info next to LocalizedMessage::with_locale"
    );
    assert!(
        crate_src.contains("[`Status::request_info`], [`pb::RequestInfo::with_request_id`]"),
        "crate map must name RequestInfo::with_request_id next to Status::request_info"
    );
    assert!(
        crate_src.contains("[`pb::RequestInfo::with_request_id`], [`Status::resource_info`]"),
        "crate map must name Status::resource_info next to RequestInfo::with_request_id"
    );
    assert!(
        crate_src.contains("[`Status::resource_info`], [`pb::ResourceInfo::with_resource`]"),
        "crate map must name ResourceInfo::with_resource next to Status::resource_info"
    );
    assert!(
        crate_src.contains(
            "[`pb::ResourceInfo::with_resource`], [`pb::ResourceInfo::with_description`]"
        ),
        "crate map must name ResourceInfo::with_description next to ResourceInfo::with_resource"
    );
    assert!(
        crate_src.contains("[`pb::ResourceInfo::with_description`], [`Status::debug_info`]"),
        "crate map must name Status::debug_info next to ResourceInfo::with_description"
    );
    assert!(
        crate_src.contains("[`Status::debug_info`], [`pb::DebugInfo::with_stack`]"),
        "crate map must name DebugInfo::with_stack next to Status::debug_info"
    );
    assert!(
        crate_src.contains("[`pb::DebugInfo::with_stack`], [`pb::DebugInfo::with_stack_entry`]"),
        "crate map must name DebugInfo::with_stack_entry next to DebugInfo::with_stack"
    );
    assert!(
        crate_src.contains("[`pb::DebugInfo::with_stack_entry`], [`Status::metadata`]"),
        "crate map must name Status::metadata next to DebugInfo::with_stack_entry"
    );
    assert!(
        crate_src.contains("[`pb::RetryInfo::with_retry_delay`]"),
        "crate map must name RetryInfo::with_retry_delay"
    );
    assert!(
        crate_src.contains("[`pb::ErrorInfo::with_reason`]"),
        "crate map must name ErrorInfo::with_reason"
    );
    assert!(
        crate_src.contains("[`pb::ErrorInfo::with_metadata`]"),
        "crate map must name ErrorInfo::with_metadata"
    );
    assert!(
        crate_src.contains("[`Status::bad_request`]"),
        "crate map must name Status::bad_request"
    );
    assert!(
        crate_src.contains("[`pb::BadRequest::with_field`]"),
        "crate map must name BadRequest::with_field"
    );
    assert!(
        crate_src.contains("[`pb::FieldViolation::with_field`]"),
        "crate map must name FieldViolation::with_field next to BadRequest::with_field"
    );
    let status_src = include_str!("../src/status.rs");
    assert!(
        status_src.contains("A peer can send a protobuf whose code or message disagrees"),
        "Status::rpc must Distinct receive-path ASCII from a mismatched packed google.rpc.Status"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::error_details`]: that is the typed bag, not this packed `google.rpc.Status`."
        ),
        "Status::rpc must Distinct the typed bag from the packed google.rpc.Status"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_rpc`]: that encodes the trailer; this parses it."
        ),
        "Status::rpc must Distinct the encode constructor from this parse getter"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::details`]: that returns raw trailer bytes; this parses a packed `google.rpc.Status`."
        ),
        "Status::rpc must Distinct raw trailer bytes from this packed google.rpc.Status parse"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::code`]: that is the ASCII `grpc-status` code; this is the packed protobuf."
        ),
        "Status::rpc must Distinct the ASCII grpc-status code from this packed protobuf"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::message`]: that is the ASCII `grpc-message`; this is the packed protobuf."
        ),
        "Status::rpc must Distinct the ASCII grpc-message from this packed protobuf"
    );
    assert!(
        status_src.contains(
            "let status = Status::permission_denied(\"acl\");\n    /// assert!(status.details().is_empty());\n    /// let rpc = status.rpc()?;"
        ),
        "Status::rpc rustdoc must synthesize a packed google.rpc.Status when the trailer is absent"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::rpc`]: that is the packed `google.rpc.Status`, not this typed bag."
        ),
        "Status::error_details must Distinct the packed google.rpc.Status from the typed bag"
    );
    assert!(
        status_src.contains(
            "let status = Status::data_loss(\"truncated\");\n    /// assert!(status.details().is_empty());\n    /// let bag = status.error_details()?;"
        ),
        "Status::error_details rustdoc must yield an empty bag when the trailer is absent"
    );
    assert!(
        status_src
            .contains("Distinct from [`Self::rpc`]: that parses the trailer; this encodes it."),
        "Status::from_rpc must Distinct the parse getter from this encode constructor"
    );
    assert!(
        status_src.contains("let status = Status::from_rpc(&rpc)?;"),
        "Status::from_rpc rustdoc must encode a packed google.rpc.Status as the trailer"
    );
    assert!(
        status_src.contains("gRPC A6 default retryable set: [`Self::Unavailable`] only."),
        "Code::is_retryable must name the A6 default set"
    );
    assert!(
        status_src.contains("Distinct from a packed [`crate::pb::RetryInfo`] delay"),
        "Code::is_retryable must Distinct RetryInfo delay from A6 retryable"
    );
    assert!(
        status_src.contains("ResourceExhausted`] is not retryable"),
        "Code::is_retryable must Distinct RESOURCE_EXHAUSTED from A6 retryable"
    );
    assert!(
        status_src.contains(
            "Distinct from [`crate::Status::is_retryable`]: that is the same A6 set on a Status; this is the Code."
        ),
        "Code::is_retryable must Distinct the Status-level A6 check from this Code"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Code::is_retryable`]: that is the same A6 set on a Code; this is the Status."
        ),
        "Status::is_retryable must Distinct the Code-level A6 check from this Status"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::metadata_mut`]: that mutates this status trailers map; this borrows it."
        ),
        "Status::metadata must Distinct the mutator from this borrow"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::metadata`]: that borrows this status trailers map; this mutates it."
        ),
        "Status::metadata_mut must Distinct the borrow from this mutator"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Code::from_i32`]: that maps an unrecognised wire i32 to [`Code::Unknown`]; this rejects the string."
        ),
        "ParseCodeError must Distinct from_i32 Unknown mapping from this string reject"
    );
    assert!(
        status_src.contains("Distinct from [`Self::is_retryable`]: a delay is a wait hint, not"),
        "Status::retry_delay must Distinct wait hint from is_retryable"
    );
    assert!(
        status_src.contains("Build the payload with [`crate::pb::RetryInfo::with_retry_delay`]."),
        "Status::retry_delay must name RetryInfo::with_retry_delay as the builder"
    );
    assert!(
        status_src.contains(
            ".with_retry_info(RetryInfo::with_retry_delay(\n    ///     std::time::Duration::from_millis(1500),"
        ),
        "Status::retry_delay rustdoc must plant RetryInfo with with_retry_info"
    );
    assert!(
        status_src.contains("Packed `google.rpc.ErrorInfo`, if this status carries one."),
        "Status::error_info must name packed ErrorInfo"
    );
    assert!(
        status_src
            .contains("Distinct from [`Self::error_details`]: this is one typed message, not"),
        "Status::error_info must Distinct the bag"
    );
    assert!(
        status_src.contains("Distinct from [`Self::retry_delay`]: that is a wait hint."),
        "Status::error_info must Distinct retry_delay wait hint"
    );
    assert!(
        status_src.contains("Build the payload with [`crate::pb::ErrorInfo::with_reason`]."),
        "Status::error_info must name ErrorInfo::with_reason as the builder"
    );
    assert!(
        status_src.contains("Fill a metadata pair with [`crate::pb::ErrorInfo::with_metadata`]."),
        "Status::error_info must name ErrorInfo::with_metadata as the metadata builder"
    );
    assert!(
        status_src.contains(
            ".with_error_info(ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\"));\n    /// let status = Status::from_error_details(\n    ///     Code::FailedPrecondition,"
        ),
        "Status::error_info rustdoc must plant ErrorInfo with with_error_info"
    );
    assert!(
        status_src.contains("Packed `google.rpc.BadRequest`, if this status carries one."),
        "Status::bad_request must name packed BadRequest"
    );
    assert!(
        status_src.contains("Distinct from [`Self::error_info`]: that is reason and domain, not"),
        "Status::bad_request must Distinct error_info reason and domain"
    );
    assert!(
        status_src.contains("Distinct from [`Self::invalid_argument`], which is"),
        "Status::bad_request must Distinct ASCII invalid_argument"
    );
    assert!(
        status_src.contains(".with_bad_request(BadRequest::with_field(\"name\", \"required\"));"),
        "Status::bad_request rustdoc must plant BadRequest with with_bad_request"
    );
    let pb_src = include_str!("../src/pb.rs");
    assert!(
        pb_src.contains("unpack with [`crate::Status::error_info`]"),
        "ErrorInfo::with_reason must name Status::error_info unpack"
    );
    assert!(
        pb_src.contains(
            ".with_error_info(ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\"));\n    /// let status = Status::from_error_details(Code::FailedPrecondition, \"disabled\", &details)?;\n    /// let info = status.error_info().expect(\"ErrorInfo\");\n    /// assert_eq!(info.reason().to_str().unwrap_or(\"\"), \"API_DISABLED\");\n    /// assert_eq!(info.domain().to_str().unwrap_or(\"\"), \"example.com\");"
        ),
        "ErrorInfo::with_reason rustdoc must plant ErrorInfo with with_error_info"
    );
    assert!(
        pb_src.contains("ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\");\n    /// let any = Any::pack"),
        "Any::pack must build ErrorInfo with with_reason"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::with_error_details`]: that packs `Any` values onto a status; this packs one message into an `Any`."
        ),
        "Any::pack must Distinct packing Anys onto a status from packing one message"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::pack`]: that uses `type.googleapis.com/<FULL_NAME>`; this takes an explicit type URL."
        ),
        "Any::pack_with must Distinct the default type URL from an explicit type URL"
    );
    assert!(
        pb_src.contains("Any::pack_with(\"example.com/google.rpc.ErrorInfo\", &info)?"),
        "Any::pack_with rustdoc must pack ErrorInfo with an explicit type URL"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::is`]: that is a type-URL check; this decodes the payload."
        ),
        "Any::unpack must Distinct the type-URL check from decoding the payload"
    );
    assert!(
        pb_src.contains(
            "ErrorInfo::with_reason(\"WRONG_TYPE\", \"unpack.example.com\");\n    /// let any = Any::pack(&info)?;\n    /// let err = any.unpack::<RetryInfo>().expect_err(\"type\");\n    /// assert_eq!(err.code(), Code::InvalidArgument);"
        ),
        "Any::unpack rustdoc must reject a RetryInfo name as InvalidArgument"
    );
    assert!(
        pb_src.contains(
            "Any::pack(&ErrorInfo::with_reason(\"BAD_BYTES\", \"corrupt.example.com\"))?;\n    /// assert!(any.is::<ErrorInfo>());\n    /// any.set_value(vec![0xff]);\n    /// let err = any.unpack::<ErrorInfo>().expect_err(\"bytes\");"
        ),
        "Any::unpack rustdoc must reject corrupt ErrorInfo bytes as Internal"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::unpack`]: that decodes the payload; this is a type-URL check."
        ),
        "Any::is must Distinct decoding the payload from this type-URL check"
    );
    assert!(
        pb_src.contains(
            "ErrorInfo::with_reason(\"TYPE_CHECK\", \"types.example.com\");\n    /// let any = Any::pack_with(\"example.org/google.rpc.ErrorInfo\", &info)?;\n    /// assert!(any.is::<ErrorInfo>());\n    /// assert!(!any.is::<RetryInfo>());"
        ),
        "Any::is rustdoc must match ErrorInfo by type name without decoding RetryInfo"
    );
    assert!(
        pb_src.contains(
            ".with_error_info(ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\"));"
        ),
        "ErrorDetails rustdoc must plant ErrorInfo with with_error_info"
    );
    assert!(
        pb_src.contains("that is a wait hint, not a cause"),
        "ErrorInfo::with_reason must Distinct retry_delay wait hint"
    );
    assert!(
        pb_src.contains("that is a field path, not reason and domain"),
        "ErrorInfo::with_reason must Distinct field path from reason and domain"
    );
    assert!(
        pb_src.contains("which is the ASCII code with no packed reason"),
        "ErrorInfo::with_reason must Distinct ASCII failed_precondition"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_metadata`]: that is a metadata pair, not reason and domain."
        ),
        "ErrorInfo::with_reason must Distinct with_metadata pair from reason and domain"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_reason`]: that is reason and domain, not a metadata pair."
        ),
        "ErrorInfo::with_metadata must Distinct reason and domain from a metadata pair"
    );
    assert!(
        pb_src.contains(
            ".with_metadata(\"resource\", \"projects/123\");\n    /// let details = ErrorDetails::new().with_error_info(info);"
        ),
        "ErrorInfo::with_metadata rustdoc must plant ErrorInfo with with_error_info"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not the API service name."
        ),
        "quota_failure::Violation::with_api_service must Distinct subject and description from the API service name"
    );
    assert!(
        pb_src.contains(
            ".with_api_service(\"compute.googleapis.com\");\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_api_service rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not the quota metric name."
        ),
        "quota_failure::Violation::with_quota_metric must Distinct subject and description from the quota metric name"
    );
    assert!(
        pb_src.contains(
            ".with_quota_metric(\"compute.googleapis.com/cpus\");\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_quota_metric rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not the quota id."
        ),
        "quota_failure::Violation::with_quota_id must Distinct subject and description from the quota id"
    );
    assert!(
        pb_src.contains(
            ".with_quota_id(\"CPUS-PER-PROJECT\");\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_quota_id rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not a quota dimension pair."
        ),
        "quota_failure::Violation::with_quota_dimension must Distinct subject and description from a quota dimension pair"
    );
    assert!(
        pb_src.contains(
            ".with_quota_dimension(\"region\", \"us-central1\");\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_quota_dimension rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not the quota value."
        ),
        "quota_failure::Violation::with_quota_value must Distinct subject and description from the quota value"
    );
    assert!(
        pb_src.contains(
            ".with_quota_value(8);\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_quota_value rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_subject`]: that is subject and description, not the future quota value."
        ),
        "quota_failure::Violation::with_future_quota_value must Distinct subject and description from the future quota value"
    );
    assert!(
        pb_src.contains(
            ".with_future_quota_value(16);\n    /// let mut quota = QuotaFailure::new();\n    /// quota.set_violations([violation]);\n    /// let details = ErrorDetails::new().with_quota_failure(quota);"
        ),
        "quota_failure::Violation::with_future_quota_value rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::bad_request`]"),
        "BadRequest::with_field must name Status::bad_request unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_field`]: that is a request field path, not the field-violation reason."
        ),
        "FieldViolation::with_reason must Distinct a request field path from the field-violation reason"
    );
    assert!(
        pb_src.contains(
            ".with_reason(\"REQUIRED\");\n    /// let mut bad = BadRequest::new();\n    /// bad.set_field_violations([violation]);\n    /// let details = ErrorDetails::new().with_bad_request(bad);"
        ),
        "FieldViolation::with_reason rustdoc must plant BadRequest with with_bad_request"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_field`]: that is a request field path, not a field-violation localized message."
        ),
        "FieldViolation::with_localized_message must Distinct a request field path from a field-violation localized message"
    );
    assert!(
        pb_src.contains(
            ".with_localized_message(LocalizedMessage::with_locale(\"fr-FR\", \"requis\"));\n    /// let mut bad = BadRequest::new();\n    /// bad.set_field_violations([violation]);\n    /// let details = ErrorDetails::new().with_bad_request(bad);"
        ),
        "FieldViolation::with_localized_message rustdoc must plant BadRequest with with_bad_request"
    );
    assert!(
        pb_src.contains("Distinct from [`crate::Status::invalid_argument`], which"),
        "BadRequest::with_field must Distinct ASCII invalid_argument"
    );
    assert!(
        pb_src.contains(".with_bad_request(BadRequest::with_field(\"name\", \"required\"));"),
        "BadRequest::with_field rustdoc must plant BadRequest with with_bad_request"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_field`]: that is the first field path, not an extra field violation."
        ),
        "BadRequest::with_field_entry must Distinct the first field path from an extra field violation"
    );
    assert!(
        pb_src.contains(
            ".with_bad_request(\n    ///     BadRequest::with_field(\"name\", \"required\").with_field_entry(\"email\", \"invalid\"),"
        ),
        "BadRequest::with_field_entry rustdoc must plant BadRequest with with_bad_request"
    );
    assert!(
        crate_src.contains("[`Status::quota_failure`]"),
        "crate map must name Status::quota_failure"
    );
    assert!(
        crate_src.contains("[`pb::QuotaFailure::with_violation`]"),
        "crate map must name QuotaFailure::with_violation"
    );
    assert!(
        crate_src.contains("[`pb::quota_failure::Violation::with_subject`]"),
        "crate map must name quota_failure::Violation::with_subject next to QuotaFailure::with_violation"
    );
    assert!(
        status_src.contains("Packed `google.rpc.QuotaFailure`, if this status carries one."),
        "Status::quota_failure must name packed QuotaFailure"
    );
    assert!(
        status_src
            .contains("Distinct from [`Self::is_retryable`]: [`Code::ResourceExhausted`] is never"),
        "Status::quota_failure must Distinct RESOURCE_EXHAUSTED from A6 retryable"
    );
    assert!(
        status_src.contains("wait hint can sit next to quota"),
        "Status::quota_failure must Distinct retry_delay wait hint"
    );
    assert!(
        status_src
            .contains("Distinct from [`Self::bad_request`]: that is a field path, not a quota"),
        "Status::quota_failure must Distinct field path from quota subject"
    );
    assert!(
        status_src.contains("Distinct from [`Self::resource_exhausted`], which is"),
        "Status::quota_failure must Distinct ASCII resource_exhausted"
    );
    assert!(
        status_src.contains(
            ".with_quota_failure(QuotaFailure::with_violation(\"project:1\", \"tokens\"));"
        ),
        "Status::quota_failure rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::quota_failure`]"),
        "QuotaFailure::with_violation must name Status::quota_failure unpack"
    );
    assert!(
        pb_src.contains("never A6-retryable"),
        "QuotaFailure::with_violation must Distinct RESOURCE_EXHAUSTED from A6 retryable"
    );
    assert!(
        pb_src.contains("Distinct from [`crate::Status::bad_request`]: that is a field path"),
        "QuotaFailure::with_violation must Distinct field path from quota subject"
    );
    assert!(
        pb_src.contains(
            ".with_quota_failure(QuotaFailure::with_violation(\"project:1\", \"tokens\"));"
        ),
        "QuotaFailure::with_violation rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_violation`]: that is the first quota subject, not an extra quota violation."
        ),
        "QuotaFailure::with_violation_entry must Distinct the first quota subject from an extra quota violation"
    );
    assert!(
        pb_src.contains(
            ".with_quota_failure(\n    ///     QuotaFailure::with_violation(\"project:1\", \"tokens\")\n    ///         .with_violation_entry(\"client:9\", \"qps\"),"
        ),
        "QuotaFailure::with_violation_entry rustdoc must plant QuotaFailure with with_quota_failure"
    );
    assert!(
        crate_src.contains("[`Status::precondition_failure`]"),
        "crate map must name Status::precondition_failure"
    );
    assert!(
        crate_src.contains("[`pb::PreconditionFailure::with_violation`]"),
        "crate map must name PreconditionFailure::with_violation"
    );
    assert!(
        crate_src.contains("[`pb::precondition_failure::Violation::with_type`]"),
        "crate map must name precondition_failure::Violation::with_type next to PreconditionFailure::with_violation"
    );
    assert!(
        status_src.contains("Packed `google.rpc.PreconditionFailure`, if this status carries one."),
        "Status::precondition_failure must name packed PreconditionFailure"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::is_retryable`]: [`Code::FailedPrecondition`] is never"
        ),
        "Status::precondition_failure must Distinct FAILED_PRECONDITION from A6 retryable"
    );
    assert!(
        status_src.contains("wait hint can sit next to a precondition"),
        "Status::precondition_failure must Distinct retry_delay wait hint"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::quota_failure`]: that is a quota subject, not a precondition"
        ),
        "Status::precondition_failure must Distinct quota subject from precondition type"
    );
    assert!(
        status_src.contains("Distinct from [`Self::failed_precondition`], which is"),
        "Status::precondition_failure must Distinct ASCII failed_precondition"
    );
    assert!(
        status_src.contains(
            ".with_precondition_failure(\n    ///     PreconditionFailure::with_violation(\"TOS\", \"google.com/cloud\", \"unsigned\"),"
        ),
        "Status::precondition_failure rustdoc must plant PreconditionFailure with with_precondition_failure"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::precondition_failure`]"),
        "PreconditionFailure::with_violation must name Status::precondition_failure unpack"
    );
    assert!(
        pb_src.contains("Distinct from [`crate::Status::quota_failure`]: that is a quota subject"),
        "PreconditionFailure::with_violation must Distinct quota subject from precondition type"
    );
    assert!(
        pb_src.contains(
            ".with_precondition_failure(\n    ///     PreconditionFailure::with_violation(\"TOS\", \"google.com/cloud\", \"unsigned\"),"
        ),
        "PreconditionFailure::with_violation rustdoc must plant PreconditionFailure with with_precondition_failure"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_violation`]: that is the first precondition type, not an extra precondition violation."
        ),
        "PreconditionFailure::with_violation_entry must Distinct the first precondition type from an extra precondition violation"
    );
    assert!(
        pb_src.contains(
            ".with_precondition_failure(\n    ///     PreconditionFailure::with_violation(\"TOS\", \"google.com/cloud\", \"unsigned\")\n    ///         .with_violation_entry(\"googleapis.com/iam/resource\", \"user:9\", \"missing\"),"
        ),
        "PreconditionFailure::with_violation_entry rustdoc must plant PreconditionFailure with with_precondition_failure"
    );
    assert!(
        crate_src.contains("[`Status::help`]"),
        "crate map must name Status::help"
    );
    assert!(
        crate_src.contains("[`pb::Help::with_link`]"),
        "crate map must name Help::with_link"
    );
    assert!(
        crate_src.contains("[`pb::help::Link::with_url`]"),
        "crate map must name help::Link::with_url next to Help::with_link"
    );
    assert!(
        status_src.contains("Packed `google.rpc.Help`, if this status carries one."),
        "Status::help must name packed Help"
    );
    assert!(
        status_src
            .contains("documentation links can sit next to a retryable [`Code::Unavailable`]"),
        "Status::help must Distinct retryable UNAVAILABLE from failure classifications"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::precondition_failure`]: that is a type and subject, not a docs"
        ),
        "Status::help must Distinct precondition type from docs URL"
    );
    assert!(
        status_src.contains(
            ".with_help(Help::with_link(\"quota docs\", \"https://example.com/quota\"));"
        ),
        "Status::help rustdoc must plant Help with with_help"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::help`]"),
        "Help::with_link must name Status::help unpack"
    );
    assert!(
        pb_src.contains(
            "documentation links can sit next to a retryable [`crate::Code::Unavailable`]"
        ),
        "Help::with_link must Distinct retryable UNAVAILABLE from failure classifications"
    );
    assert!(
        pb_src.contains(
            ".with_help(Help::with_link(\"quota docs\", \"https://example.com/quota\"));\n    /// let status = Status::from_error_details(Code::Unavailable, \"backend\", &details)?;\n    /// assert!(status.is_retryable());\n    /// let help = status.help().expect(\"Help\");\n    /// assert_eq!(\n    ///     help.links().get(0).expect(\"link\").url().to_str().unwrap_or(\"\"),"
        ),
        "Help::with_link rustdoc must plant Help with with_help"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_link`]: that is the first docs URL, not an extra help link."
        ),
        "Help::with_link_entry must Distinct the first docs URL from an extra help link"
    );
    assert!(
        pb_src.contains(
            ".with_help(\n    ///         Help::with_link(\"quota docs\", \"https://example.com/quota\")\n    ///             .with_link_entry(\"retry\", \"https://example.com/retry\"),"
        ),
        "Help::with_link_entry rustdoc must plant Help with with_help"
    );
    assert!(
        crate_src.contains("[`Status::localized_message`]"),
        "crate map must name Status::localized_message"
    );
    assert!(
        crate_src.contains("[`pb::LocalizedMessage::with_locale`]"),
        "crate map must name LocalizedMessage::with_locale"
    );
    assert!(
        status_src.contains("Packed `google.rpc.LocalizedMessage`, if this status carries one."),
        "Status::localized_message must name packed LocalizedMessage"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::message`]: that is the ASCII `grpc-message`, not a locale."
        ),
        "Status::localized_message must Distinct ASCII grpc-message from locale"
    );
    assert!(
        status_src.contains("Distinct from [`Self::help`]: that is a docs URL, not a locale."),
        "Status::localized_message must Distinct Help docs URL from locale"
    );
    assert!(
        status_src.contains(
            ".with_localized_message(LocalizedMessage::with_locale(\"fr-FR\", \"introuvable\"));"
        ),
        "Status::localized_message rustdoc must plant LocalizedMessage with with_localized_message"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::localized_message`]"),
        "LocalizedMessage::with_locale must name Status::localized_message unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::message`]: that is the ASCII `grpc-message`, not a locale."
        ),
        "LocalizedMessage::with_locale must Distinct ASCII grpc-message from locale"
    );
    assert!(
        pb_src.contains(
            ".with_localized_message(LocalizedMessage::with_locale(\"fr-FR\", \"introuvable\"));\n    /// let status = Status::from_error_details(Code::NotFound, \"not found\", &details)?;\n    /// assert_eq!(status.message(), \"not found\");"
        ),
        "LocalizedMessage::with_locale rustdoc must plant LocalizedMessage with with_localized_message"
    );
    assert!(
        crate_src.contains("[`Status::request_info`]"),
        "crate map must name Status::request_info"
    );
    assert!(
        crate_src.contains("[`pb::RequestInfo::with_request_id`]"),
        "crate map must name RequestInfo::with_request_id"
    );
    assert!(
        status_src.contains("Packed `google.rpc.RequestInfo`, if this status carries one."),
        "Status::request_info must name packed RequestInfo"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::error_info`]: that is a metadata map, not a typed request_id."
        ),
        "Status::request_info must Distinct ErrorInfo metadata map from typed request_id"
    );
    assert!(
        status_src.contains("Distinct from [`Self::help`]: that is a docs URL, not a request_id."),
        "Status::request_info must Distinct Help docs URL from request_id"
    );
    assert!(
        status_src.contains(
            ".with_request_info(RequestInfo::with_request_id(\"req-9\", \"encrypted\"));"
        ),
        "Status::request_info rustdoc must plant RequestInfo with with_request_info"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::request_info`]"),
        "RequestInfo::with_request_id must name Status::request_info unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::error_info`]: that is a metadata map, not a typed request_id."
        ),
        "RequestInfo::with_request_id must Distinct ErrorInfo metadata map from typed request_id"
    );
    assert!(
        pb_src.contains(
            ".with_request_info(RequestInfo::with_request_id(\"req-9\", \"encrypted\"));\n    /// let status = Status::from_error_details(Code::Internal, \"boom\", &details)?;\n    /// let info = status.request_info().expect(\"RequestInfo\");\n    /// assert_eq!(info.request_id().to_str().unwrap_or(\"\"), \"req-9\");\n    /// assert_eq!(info.serving_data().to_str().unwrap_or(\"\"), \"encrypted\");"
        ),
        "RequestInfo::with_request_id rustdoc must plant RequestInfo with with_request_info"
    );
    assert!(
        crate_src.contains("[`Status::resource_info`]"),
        "crate map must name Status::resource_info"
    );
    assert!(
        crate_src.contains("[`pb::ResourceInfo::with_resource`]"),
        "crate map must name ResourceInfo::with_resource"
    );
    assert!(
        status_src.contains("Packed `google.rpc.ResourceInfo`, if this status carries one."),
        "Status::resource_info must name packed ResourceInfo"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::quota_failure`]: that is a quota subject, not a resource identity."
        ),
        "Status::resource_info must Distinct quota subject from resource identity"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::request_info`]: that is a request_id, not a resource."
        ),
        "Status::resource_info must Distinct request_id from resource"
    );
    assert!(
        status_src.contains(
            ".with_resource_info(ResourceInfo::with_resource(\n    ///     \"sqladmin.googleapis.com/Instance\","
        ),
        "Status::resource_info rustdoc must plant ResourceInfo with with_resource_info"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::resource_info`]"),
        "ResourceInfo::with_resource must name Status::resource_info unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::quota_failure`]: that is a quota subject, not a resource identity."
        ),
        "ResourceInfo::with_resource must Distinct quota subject from resource identity"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::request_info`]: that is a request_id, not a resource.\n    ///\n    /// ```\n    /// use pbrs_grpc::pb::{ErrorDetails, ResourceInfo};\n    /// use pbrs_grpc::{Code, Status};\n    ///\n    /// let details = ErrorDetails::new().with_resource_info(ResourceInfo::with_resource("
        ),
        "ResourceInfo::with_resource rustdoc must plant ResourceInfo with with_resource_info"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_resource`]: that is type, name, and owner, not a resource description."
        ),
        "ResourceInfo::with_description must Distinct type, name, and owner from a resource description"
    );
    assert!(
        pb_src.contains(
            "let details = ErrorDetails::new().with_resource_info(\n    ///     ResourceInfo::with_resource(\n    ///         \"sqladmin.googleapis.com/Instance\",\n    ///         \"projects/1/instances/a\",\n    ///         \"project:1\",\n    ///     )\n    ///     .with_description(\"Cloud SQL instance\"),"
        ),
        "ResourceInfo::with_description rustdoc must plant ResourceInfo with with_resource_info"
    );
    assert!(
        crate_src.contains("[`Status::debug_info`]"),
        "crate map must name Status::debug_info"
    );
    assert!(
        crate_src.contains("[`pb::DebugInfo::with_stack`]"),
        "crate map must name DebugInfo::with_stack"
    );
    assert!(
        crate_src.contains("[`pb::DebugInfo::with_stack_entry`], [`Status::metadata`]"),
        "crate map must name Status::metadata next to DebugInfo::with_stack_entry"
    );
    assert!(
        crate_src.contains("[`Status::metadata`], [`Status::metadata_mut`]"),
        "crate map must name Status::metadata_mut next to Status::metadata"
    );
    assert!(
        status_src.contains("Packed `google.rpc.DebugInfo`, if this status carries one."),
        "Status::debug_info must name packed DebugInfo"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::localized_message`]: that is a locale, not an operator stack."
        ),
        "Status::debug_info must Distinct locale from operator stack"
    );
    assert!(
        status_src
            .contains("Distinct from [`Self::help`]: that is a docs URL, not an operator stack."),
        "Status::debug_info must Distinct Help docs URL from operator stack"
    );
    assert!(
        status_src.contains(
            ".with_debug_info(DebugInfo::with_stack(\"handler.rs:9\", \"nil pointer\"));"
        ),
        "Status::debug_info rustdoc must plant DebugInfo with with_debug_info"
    );
    assert!(
        pb_src.contains("unpack with [`crate::Status::debug_info`]"),
        "DebugInfo::with_stack must name Status::debug_info unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::localized_message`]: that is a locale, not an operator stack."
        ),
        "DebugInfo::with_stack must Distinct locale from operator stack"
    );
    assert!(
        pb_src.contains(
            ".with_debug_info(DebugInfo::with_stack(\"handler.rs:9\", \"nil pointer\"));\n    /// let status = Status::from_error_details(Code::Internal, \"boom\", &details)?;\n    /// let debug = status.debug_info().expect(\"DebugInfo\");\n    /// assert_eq!(debug.detail().to_str().unwrap_or(\"\"), \"nil pointer\");"
        ),
        "DebugInfo::with_stack rustdoc must plant DebugInfo with with_debug_info"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::with_stack`]: that is the first frame and detail, not an extra stack frame."
        ),
        "DebugInfo::with_stack_entry must Distinct the first frame and detail from an extra stack frame"
    );
    assert!(
        pb_src.contains(
            "let details = ErrorDetails::new().with_debug_info(\n    ///     DebugInfo::with_stack(\"handler.rs:9\", \"nil pointer\").with_stack_entry(\"rpc.rs:4\"),"
        ),
        "DebugInfo::with_stack_entry rustdoc must plant DebugInfo with with_debug_info"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::from_rpc`]: that encodes a packed protobuf as the trailer; this unpacks the typed bag."
        ),
        "ErrorDetails::from_rpc must Distinct the Status encode constructor from this typed-bag unpack"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::error_details`]: that unpacks `grpc-status-details-bin` on a kernel Status; this unpacks the `Any` list on a packed `google.rpc.Status`."
        ),
        "ErrorDetails::from_rpc must Distinct the kernel Status trailer unpack from this google.rpc.Status Any list"
    );
    assert!(
        pb_src.contains("let bag = ErrorDetails::from_rpc(&rpc)?;"),
        "ErrorDetails::from_rpc rustdoc must unpack the Any list on a packed google.rpc.Status"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::from_error_details`]: that encodes the bag as a trailer; this returns the `Any` list."
        ),
        "ErrorDetails::to_anys must Distinct the typed-bag trailer constructor from this Any list"
    );
    assert!(
        pb_src.contains("let anys = details.to_anys()?;\n    /// assert_eq!(anys.len(), 1);"),
        "ErrorDetails::to_anys rustdoc must return the Any list from a typed bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::from_rpc`]: that unpacks the `Any` list on a packed `google.rpc.Status`; this is an empty bag."
        ),
        "ErrorDetails::new must Distinct the Any-list unpack from this empty bag"
    );
    assert!(
        pb_src.contains(
            "let details = ErrorDetails::new();\n    /// assert!(details.error_info.is_none());"
        ),
        "ErrorDetails::new rustdoc must start an empty bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`ErrorInfo::with_reason`]: that is reason and domain, not planting ErrorInfo on the bag."
        ),
        "ErrorDetails::with_error_info must Distinct reason and domain from planting ErrorInfo on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`RetryInfo::with_retry_delay`]: that is a wait hint, not planting RetryInfo on the bag."
        ),
        "ErrorDetails::with_retry_info must Distinct a wait hint from planting RetryInfo on the bag"
    );
    assert!(
        pb_src.contains(
            ".with_retry_info(RetryInfo::with_retry_delay(\n    ///     std::time::Duration::from_secs(3),"
        ),
        "RetryInfo::with_retry_delay rustdoc must plant RetryInfo with with_retry_info"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`DebugInfo::with_stack`]: that is the first frame and detail, not planting DebugInfo on the bag."
        ),
        "ErrorDetails::with_debug_info must Distinct the first frame and detail from planting DebugInfo on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`QuotaFailure::with_violation`]: that is the first quota subject, not planting QuotaFailure on the bag."
        ),
        "ErrorDetails::with_quota_failure must Distinct the first quota subject from planting QuotaFailure on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`PreconditionFailure::with_violation`]: that is the first precondition type, not planting PreconditionFailure on the bag."
        ),
        "ErrorDetails::with_precondition_failure must Distinct the first precondition type from planting PreconditionFailure on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`BadRequest::with_field`]: that is the first field path, not planting BadRequest on the bag."
        ),
        "ErrorDetails::with_bad_request must Distinct the first field path from planting BadRequest on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`RequestInfo::with_request_id`]: that is request_id and serving_data, not planting RequestInfo on the bag."
        ),
        "ErrorDetails::with_request_info must Distinct request_id and serving_data from planting RequestInfo on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`ResourceInfo::with_resource`]: that is type, name, and owner, not planting ResourceInfo on the bag."
        ),
        "ErrorDetails::with_resource_info must Distinct type, name, and owner from planting ResourceInfo on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Help::with_link`]: that is the first docs URL, not planting Help on the bag."
        ),
        "ErrorDetails::with_help must Distinct the first docs URL from planting Help on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`LocalizedMessage::with_locale`]: that is locale and message, not planting LocalizedMessage on the bag."
        ),
        "ErrorDetails::with_localized_message must Distinct locale and message from planting LocalizedMessage on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Any::pack`]: that packs one message into an Any, not planting it on the bag."
        ),
        "ErrorDetails::with_unknown must Distinct packing one message into an Any from planting it on the bag"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::try_to_std`]: that converts this protobuf to `std`; this builds the protobuf from `std`."
        ),
        "Duration::from_std must Distinct converting to std from building the protobuf"
    );
    assert!(
        pb_src.contains("Duration::from_std(std::time::Duration::from_secs(7))"),
        "Duration::from_std rustdoc must build the protobuf from std"
    );
    assert!(
        pb_src.contains(
            "Duration::from_std(std::time::Duration::from_secs(u64::MAX));\n    /// assert_eq!(proto.seconds(), i64::MAX);"
        ),
        "Duration::from_std rustdoc must saturate seconds at i64::MAX"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`Self::from_std`]: that builds the protobuf from `std`; this converts this protobuf to `std`."
        ),
        "Duration::try_to_std must Distinct building the protobuf from converting to std"
    );
    assert!(
        pb_src.contains(
            "proto.set_seconds(-1);\n    /// let err = proto.try_to_std().expect_err(\"negative\");"
        ),
        "Duration::try_to_std rustdoc must reject a negative protobuf duration"
    );
    assert!(
        pb_src.contains(
            "proto.set_nanos(1_000_000_000);\n    /// let err = proto.try_to_std().expect_err(\"nanos\");"
        ),
        "Duration::try_to_std rustdoc must reject nanos outside the protobuf range"
    );
    assert!(
        pb_src.contains(
            "proto.set_nanos(-1);\n    /// let err = proto.try_to_std().expect_err(\"neg-nanos\");"
        ),
        "Duration::try_to_std rustdoc must reject negative protobuf nanos"
    );
    assert!(
        pb_src.contains(
            "Distinct from [`crate::Status::with_details`]: that ships raw trailer bytes; this builds a packed `google.rpc.Status`."
        ),
        "pb::Status::with_details must Distinct raw trailer bytes from this packed google.rpc.Status"
    );
    assert!(
        pb_src.contains(
            "let rpc = Status::with_details(\n    ///     Code::Aborted,\n    ///     \"conflict\","
        ),
        "pb::Status::with_details rustdoc must build a packed google.rpc.Status"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::with_error_details`]: that packs `Any` values; this takes the typed bag."
        ),
        "Status::from_error_details must Distinct the Any packer from this typed-bag constructor"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::with_error_details`]: that packs `Any` values into a `google.rpc.Status`; this ships raw trailer bytes a proxy can forward without parsing."
        ),
        "Status::with_details must Distinct packing Anys from raw trailer bytes"
    );
    assert!(
        status_src
            .contains("let status = Status::with_details(Code::Unknown, \"opaque\", vec![0x0a]);"),
        "Status::with_details rustdoc must ship raw trailer bytes a proxy can forward"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_error_details`]: that packs `Any` values into a `google.rpc.Status`; this ships raw trailer bytes on an existing status."
        ),
        "Status::set_details must Distinct packing Anys from raw trailer bytes on an existing status"
    );
    assert!(
        status_src.contains(
            "status.set_details(vec![0xff]);\n    /// assert_eq!(status.details(), &[0xff]);"
        ),
        "Status::set_details rustdoc must ship raw trailer bytes on an existing status"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::rpc`]: that parses a packed `google.rpc.Status`; this returns raw trailer bytes."
        ),
        "Status::details must Distinct packed google.rpc.Status parse from raw trailer bytes"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::code`]: that is the ASCII `grpc-status` code; this returns raw trailer bytes."
        ),
        "Status::details must Distinct the ASCII grpc-status code from raw trailer bytes"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::message`]: that is the ASCII `grpc-message`; this returns raw trailer bytes."
        ),
        "Status::details must Distinct the ASCII grpc-message from raw trailer bytes"
    );
    assert!(
        status_src.contains(
            "let status = Status::with_details(Code::DataLoss, \"bitrot\", vec![0x1b]);\n    /// assert_eq!(status.details(), &[0x1b]);\n    /// assert!(status.metadata().get_bin(\"grpc-status-details-bin\").is_none());"
        ),
        "Status::details rustdoc must return raw trailer bytes that are not a metadata key"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_code`]: that is code-only; this takes a code and message."
        ),
        "Status::new must Distinct the code-only constructor from this code-and-message constructor"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::new`]: that takes a code and message; this is code-only."
        ),
        "Status::from_code must Distinct the code-and-message constructor from this code-only constructor"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::with_code`]: that is the builder; this mutates in place."
        ),
        "Status::set_code must Distinct the builder from this in-place mutation"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_code`]: that mutates in place; this is the builder."
        ),
        "Status::with_code must Distinct the in-place mutation from this builder"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::with_message`]: that is the builder; this mutates in place."
        ),
        "Status::set_message must Distinct the builder from this in-place mutation"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_message`]: that mutates in place; this is the builder."
        ),
        "Status::with_message must Distinct the in-place mutation from this builder"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::to_i32`]: that emits the wire i32; this interprets a wire i32."
        ),
        "Code::from_i32 must Distinct emitting the wire i32 from interpreting a wire i32"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_i32`]: that interprets a wire i32; this emits the wire i32."
        ),
        "Code::to_i32 must Distinct interpreting a wire i32 from emitting the wire i32"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::description`]: that is the one-line google.rpc.Code text; this is the canonical name."
        ),
        "Code::name must Distinct the one-line google.rpc.Code text from this canonical name"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::name`]: that is the canonical name; this is the one-line google.rpc.Code text."
        ),
        "Code::description must Distinct the canonical name from this one-line google.rpc.Code text"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::is_retryable`]: that is UNAVAILABLE only; this is Code::Ok."
        ),
        "Status::is_ok must Distinct A6 retryable from this success check"
    );
    assert!(
        status_src.contains(
            "assert!(Status::from_code(Code::Ok).is_ok());\n    /// assert!(!Status::from_code(Code::Ok).is_retryable());\n    /// let down = Status::unavailable(\"peer\");"
        ),
        "Status::is_ok rustdoc must Distinct Code::Ok from A6 retryable UNAVAILABLE"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::message`]: that is the ASCII `grpc-message`; this is the ASCII `grpc-status` code."
        ),
        "Status::code must Distinct the ASCII grpc-message from this ASCII grpc-status code"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::rpc`]: that is the packed protobuf; this is the ASCII `grpc-status` code."
        ),
        "Status::code must Distinct the packed protobuf from this ASCII grpc-status code"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::details`]: that returns raw trailer bytes; this is the ASCII `grpc-status` code."
        ),
        "Status::code must Distinct raw trailer bytes from this ASCII grpc-status code"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::code`]: that is the ASCII `grpc-status` code; this is the ASCII `grpc-message`."
        ),
        "Status::message must Distinct the ASCII grpc-status code from this ASCII grpc-message"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::rpc`]: that is the packed protobuf; this is the ASCII `grpc-message`."
        ),
        "Status::message must Distinct the packed protobuf from this ASCII grpc-message"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::details`]: that returns raw trailer bytes; this is the ASCII `grpc-message`."
        ),
        "Status::message must Distinct raw trailer bytes from this ASCII grpc-message"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_rpc`]: that encodes a packed `google.rpc.Status`; this encodes the typed bag."
        ),
        "Status::from_error_details must Distinct the packed protobuf constructor from this typed-bag constructor"
    );
    assert!(
        status_src.contains(
            "Status::from_error_details(Code::FailedPrecondition, \"typed-bag\", &details)"
        ),
        "Status::from_error_details must compile a typed-bag ErrorInfo example"
    );
    assert!(
        status_src.contains(
            ".with_error_info(ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\"));\n    /// let status = Status::from_error_details(Code::FailedPrecondition, \"typed-bag\", &details)"
        ),
        "Status::from_error_details rustdoc must plant ErrorInfo with with_error_info"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_error_details`]: that takes the typed bag, not packed `Any` values."
        ),
        "Status::with_error_details must Distinct the typed-bag constructor from this Any packer"
    );
    assert!(
        status_src
            .contains("let info = ErrorInfo::with_reason(\"API_DISABLED\", \"example.com\");"),
        "Status::with_error_details must build ErrorInfo with with_reason"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_from_error_details`]: that takes the typed bag, not packed `Any` values."
        ),
        "Status::set_error_details must Distinct the typed-bag setter from this Any packer"
    );
    assert!(
        status_src.contains("let info = ErrorInfo::with_reason(\"STOCKOUT\", \"example.com\");"),
        "Status::set_error_details must build ErrorInfo with with_reason"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_error_details`]: that packs `Any` values; this takes the typed bag."
        ),
        "Status::set_from_error_details must Distinct the Any packer from this typed-bag setter"
    );
    assert!(
        status_src.contains(
            "status.set_from_error_details(Code::Unavailable, \"backend died\", &details)?;"
        ),
        "Status::set_from_error_details rustdoc must plant the typed bag in place"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::set_error_details`]: that packs `Any` values; this encodes a packed `google.rpc.Status`."
        ),
        "Status::set_rpc must Distinct packing Anys from encoding a packed google.rpc.Status"
    );
    assert!(
        status_src.contains("status.set_rpc(&rpc)?;"),
        "Status::set_rpc rustdoc must encode a packed google.rpc.Status without dropping trailers"
    );
    assert!(
        status_src.contains(
            "Distinct from [`Self::from_rpc`]: that mints a fresh status with empty trailers; this keeps existing trailers."
        ),
        "Status::with_rpc must Distinct the fresh from_rpc constructor from this trailer-preserving builder"
    );
    assert!(
        status_src.contains("let status = status.with_rpc(&rpc)?;"),
        "Status::with_rpc rustdoc must encode a packed google.rpc.Status without dropping trailers"
    );
    assert!(
        status_src.contains(
            "[`Self::set_rpc`] / [`Self::set_error_details`] / [`Self::set_from_error_details`] replace the protobuf"
        ),
        "Status type rustdoc must name set_from_error_details next to the in-place Any packer"
    );
    assert!(
        status_src.contains("Distinct from [`Self::with_error_details`]: this is local wrapping,"),
        "Status::from_error must Distinct local wrapping from packed google.rpc.Status"
    );
    assert!(
        status_src.contains("this builds one. A peer trailer has no cause."),
        "Status::from_error must Distinct with_cause from building a status"
    );
    assert!(
        status_src.contains(
            "[`std::io::ErrorKind::InvalidData`] [`Code::Internal`], leftover\n    /// [`Code::Unknown`]). Anything else is"
        ),
        "Status::from_error rustdoc must name the From InvalidData Internal mapping"
    );
    assert!(
        status_src.contains(
            "connection failures [`Code::Unavailable`] (`ConnectionRefused`,\n    /// `ConnectionReset`, `ConnectionAborted`, `NotConnected`, `BrokenPipe`,\n    /// `UnexpectedEof`, `AddrNotAvailable`),"
        ),
        "Status::from_error rustdoc must name the From connection-failure kinds"
    );
    assert!(
        status_src.contains(
            "Status::internal(\"flush\").with_cause(std::io::Error::new(\n    ///     std::io::ErrorKind::Other,\n    ///     \"nvme\",\n    /// ));"
        ),
        "Status::with_cause rustdoc must attach Error::source without remapping the code"
    );
    assert!(
        status_src.contains(
            "std::io::ErrorKind::TimedOut,\n///     \"slow disk\",\n/// ));\n/// assert_eq!(status.code(), Code::DeadlineExceeded);"
        ),
        "Status From<io::Error> rustdoc must map a local timeout to DeadlineExceeded"
    );
    assert!(
        status_src.contains(
            "ErrorKind::InvalidData`] is\n/// [`Code::Internal`]. Everything else is [`Code::Unknown`]"
        ),
        "Status From<io::Error> rustdoc must Distinct InvalidData Internal from everything-else Unknown"
    );
    assert!(
        status_src.contains(
            "std::io::ErrorKind::InvalidData,\n///     \"truncated frame\",\n/// ));\n/// assert_eq!(status.code(), Code::Internal);"
        ),
        "Status From<io::Error> rustdoc must map InvalidData to Internal"
    );
    assert!(
        status_src.contains(
            "std::io::ErrorKind::Other,\n///     \"policy\",\n/// ));\n/// assert_eq!(status.code(), Code::Unknown);"
        ),
        "Status From<io::Error> rustdoc must map leftover local I/O to Unknown"
    );
    assert!(
        status_src.contains(
            "`NotConnected`, `BrokenPipe`, `UnexpectedEof`, `AddrNotAvailable`)\n/// become [`Code::Unavailable`]"
        ),
        "Status From<io::Error> rustdoc must name the connection-failure kinds that map to Unavailable"
    );
    assert!(
        status_src.contains(
            "std::io::ErrorKind::BrokenPipe,\n///     \"writer gone\",\n/// ));\n/// assert_eq!(status.code(), Code::Unavailable);"
        ),
        "Status From<io::Error> rustdoc must map BrokenPipe to retryable UNAVAILABLE"
    );
    assert!(
        crate_src.contains(
            "`ENHANCE_YOUR_CALM` and the accept loop still serves a well-behaved client."
        ),
        "crate docs must Distinct well-behaved pending-reset from a rapid-reset flood"
    );
    assert!(
        crate_src
            .contains("[`ChannelConfig::max_pending_accept_reset_streams`] is the client accept"),
        "crate docs must Distinct ChannelConfig pending-reset as the client queue"
    );
    assert!(
        crate_src.contains("more CONTINUATION frames than the header-list cap"),
        "crate docs must name the hostile CONTINUATION flood"
    );
    assert!(
        crate_src.contains("does not take the accept loop down."),
        "crate docs must Distinct unfinished HEADERS from taking the accept loop down"
    );
    assert!(
        crate_src.contains("HTTP/2 protocol-error RST flood"),
        "crate threat table must name protocol-error RST flood"
    );
    assert!(
        crate_src.contains("Distinct from a protocol-error RST flood: invalid frames force RSTs"),
        "crate docs must Distinct protocol-error RST flood from rapid reset"
    );
    assert!(
        crate_src.contains("h2's `None` disable is not exposed"),
        "crate docs must not expose h2's None disable for protocol-error RSTs"
    );
    assert!(
        crate_src.contains("so a finished [`Streaming`] is skipped by"),
        "crate docs must re-export FusedStream for a finished Streaming"
    );
    assert!(
        crate_src.contains("is deflate effort (default 1)"),
        "crate docs must name gzip_compression_level default 1"
    );
    assert!(
        crate_src.contains("Distinct from `send_compressed`, which is on or off"),
        "crate docs must Distinct gzip_compression_level from send_compressed"
    );
    assert!(
        crate_src.contains("[`Outgoing::gzip_level`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::gzip_level as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::compresses_outbound`]"),
        "crate docs must Distinct Outgoing::gzip_level from compresses_outbound"
    );
    assert!(
        crate_src.contains("[`Rpc::gzip_level`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::gzip_level as the server interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::compresses_outbound`]"),
        "crate docs must Distinct Rpc::gzip_level from compresses_outbound"
    );
    assert!(
        crate_src.contains(
            "[`Channel::gzip_level`] reads the deflate overlay without colliding with [`Channel::gzip_compression_level`]"
        ),
        "crate docs must name Channel::gzip_level as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::gzip_level`]"),
        "crate docs must Distinct Channel::gzip_level as the same overlay as Outgoing::gzip_level"
    );
    assert!(
        crate_src.contains(
            "[`Server::gzip_level`] reads the deflate overlay without colliding with [`Server::gzip_compression_level`]"
        ),
        "crate docs must name Server::gzip_level as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::gzip_level`]"),
        "crate docs must Distinct Server::gzip_level as the same overlay as Rpc::gzip_level"
    );
    assert!(
        crate_src
            .contains("[`Outgoing::compresses_outbound`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::compresses_outbound as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::compress`]"),
        "crate docs must Distinct Outgoing::compresses_outbound from per-RPC compress"
    );
    assert!(
        crate_src.contains("[`Rpc::compresses_outbound`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::compresses_outbound as the server interceptor overlay"
    );
    assert!(
        crate_src.contains(
            "[`Channel::compresses_outbound`] reads the outbound gzip overlay without colliding with [`Channel::send_compressed`]"
        ),
        "crate docs must name Channel::compresses_outbound as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::compresses_outbound`]"),
        "crate docs must Distinct Channel::compresses_outbound as the same overlay as Outgoing::compresses_outbound"
    );
    assert!(
        crate_src.contains(
            "[`Server::compresses_outbound`] reads the outbound gzip overlay without colliding with [`Server::send_compressed`]"
        ),
        "crate docs must name Server::compresses_outbound as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::compresses_outbound`]"),
        "crate docs must Distinct Server::compresses_outbound as the same overlay as Rpc::compresses_outbound"
    );
    assert!(
        crate_src
            .contains("[`Outgoing::accepts_compressed`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::accepts_compressed as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::gzip_level`]"),
        "crate docs must Distinct Outgoing::accepts_compressed from gzip_level"
    );
    assert!(
        crate_src.contains("[`Rpc::accepts_compressed`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::accepts_compressed as the server interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::accepts_gzip`]"),
        "crate docs must Distinct Rpc::accepts_compressed from peer accepts_gzip"
    );
    assert!(
        crate_src.contains(
            "[`Channel::accepts_compressed`] reads the inbound gzip overlay without colliding with [`Channel::accept_compressed`]"
        ),
        "crate docs must name Channel::accepts_compressed as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::accepts_compressed`]"),
        "crate docs must Distinct Channel::accepts_compressed as the same overlay as Outgoing::accepts_compressed"
    );
    assert!(
        crate_src.contains(
            "[`Server::accepts_compressed`] reads the inbound gzip overlay without colliding with [`Server::accept_compressed`]"
        ),
        "crate docs must name Server::accepts_compressed as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::accepts_compressed`]"),
        "crate docs must Distinct Server::accepts_compressed as the same overlay as Rpc::accepts_compressed"
    );
    assert!(
        crate_src
            .contains("[`Outgoing::concurrent_rpc_limit`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::concurrent_rpc_limit as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::waits_for_ready`]"),
        "crate docs must Distinct Outgoing::concurrent_rpc_limit from waits_for_ready"
    );
    assert!(
        crate_src.contains("[`Rpc::concurrent_rpc_limit`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::concurrent_rpc_limit as the server interceptor overlay"
    );
    assert!(
        crate_src.contains(
            "[`Channel::concurrent_rpc_limit`] reads the RPC-cap overlay without colliding with [`Channel::max_concurrent_rpcs`]"
        ),
        "crate docs must name Channel::concurrent_rpc_limit as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::concurrent_rpc_limit`]"),
        "crate docs must Distinct Channel::concurrent_rpc_limit as the same overlay as Outgoing::concurrent_rpc_limit"
    );
    assert!(
        crate_src.contains(
            "[`Server::concurrent_rpc_limit`] reads the RPC-cap overlay without colliding with [`Server::max_concurrent_rpcs`]"
        ),
        "crate docs must name Server::concurrent_rpc_limit as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::concurrent_rpc_limit`]"),
        "crate docs must Distinct Server::concurrent_rpc_limit as the same overlay as Rpc::concurrent_rpc_limit"
    );
    assert!(
        crate_src.contains("[`Outgoing::waits_for_ready`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::waits_for_ready as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::connected`]"),
        "crate docs must Distinct Outgoing::waits_for_ready from connected"
    );
    assert!(
        crate_src.contains(
            "[`Channel::waits_for_ready`] reads the wait-for-ready overlay without colliding with [`Channel::wait_for_ready`]"
        ),
        "crate docs must name Channel::waits_for_ready as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::waits_for_ready`]"),
        "crate docs must Distinct Channel::waits_for_ready as the same overlay as Outgoing::waits_for_ready"
    );
    assert!(
        crate_src.contains(
            "[`Outgoing::connected`] is the live-socket snapshot in a client interceptor"
        ),
        "crate docs must name Outgoing::connected as the live-socket snapshot"
    );
    assert!(
        crate_src.contains("[`Channel::connected`] is that same snapshot without an interceptor"),
        "crate docs must name Channel::connected as the same snapshot without an interceptor"
    );
    assert!(
        crate_src.contains(
            "[`GreeterClient::connected`] is the live-socket snapshot on a generated client"
        ),
        "crate docs must name GreeterClient::connected as the live-socket snapshot"
    );
    assert!(
        crate_src.contains("Same snapshot as [`Channel::connected`]"),
        "crate docs must Distinct GreeterClient::connected as the same snapshot as Channel::connected"
    );
    assert!(
        crate_src.contains("[`Outgoing::rpc_timeout`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::rpc_timeout as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::timeout`]"),
        "crate docs must Distinct Outgoing::rpc_timeout from per-RPC timeout"
    );
    assert!(
        crate_src.contains("[`Rpc::rpc_timeout`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::rpc_timeout as the server interceptor overlay"
    );
    assert!(
        crate_src.contains(
            "[`Channel::rpc_timeout`] reads the deadline overlay without colliding with [`Channel::timeout`]"
        ),
        "crate docs must name Channel::rpc_timeout as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::rpc_timeout`]"),
        "crate docs must Distinct Channel::rpc_timeout as the same overlay as Outgoing::rpc_timeout"
    );
    assert!(
        crate_src.contains(
            "[`Server::rpc_timeout`] reads the deadline overlay without colliding with [`Server::timeout`]"
        ),
        "crate docs must name Server::rpc_timeout as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::rpc_timeout`]"),
        "crate docs must Distinct Server::rpc_timeout as the same overlay as Rpc::rpc_timeout"
    );
    assert!(
        crate_src
            .contains("[`Outgoing::stream_buffer_size`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::stream_buffer_size as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::limits`]"),
        "crate docs must Distinct Outgoing::stream_buffer_size from limits"
    );
    assert!(
        crate_src.contains(
            "[`Channel::stream_buffer_size`] reads the stream-queue overlay without colliding with [`Channel::stream_buffer`]"
        ),
        "crate docs must name Channel::stream_buffer_size as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::stream_buffer_size`]"),
        "crate docs must Distinct Channel::stream_buffer_size as the same overlay as Outgoing::stream_buffer_size"
    );
    assert!(
        crate_src.contains("[`Outgoing::limits`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::limits as the interceptor overlay"
    );
    assert!(
        crate_src.contains("[`Rpc::limits`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::limits as the server interceptor overlay"
    );
    assert!(
        crate_src.contains(
            "[`Channel::limits`] reads the message-cap overlay without colliding with [`Channel::message_limits`]"
        ),
        "crate docs must name Channel::limits as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::limits`]"),
        "crate docs must Distinct Channel::limits as the same overlay as Outgoing::limits"
    );
    assert!(
        crate_src.contains(
            "[`Server::limits`] reads the message-cap overlay without colliding with [`Server::message_limits`]"
        ),
        "crate docs must name Server::limits as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::limits`]"),
        "crate docs must Distinct Server::limits as the same overlay as Rpc::limits"
    );
    assert!(
        crate_src.contains(
            "[`Channel::send_buffer_size`] reads the HTTP/2 send buffer overlay without colliding with [`Channel::max_send_buffer_size`]"
        ),
        "crate docs must name Channel::send_buffer_size as the live-clone overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Outgoing::send_buffer_size`]"),
        "crate docs must Distinct Channel::send_buffer_size as the same overlay as Outgoing::send_buffer_size"
    );
    assert!(
        crate_src.contains(
            "[`Server::send_buffer_size`] reads the HTTP/2 send buffer overlay without colliding with [`Server::max_send_buffer_size`]"
        ),
        "crate docs must name Server::send_buffer_size as the live-server overlay"
    );
    assert!(
        crate_src.contains("Same overlay as [`Rpc::send_buffer_size`]"),
        "crate docs must Distinct Server::send_buffer_size as the same overlay as Rpc::send_buffer_size"
    );
    assert!(
        crate_src
            .contains("[`Outgoing::send_buffer_size`] is that overlay in a client interceptor"),
        "crate docs must name Outgoing::send_buffer_size as the interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::stream_buffer_size`]"),
        "crate docs must Distinct Outgoing::send_buffer_size from stream_buffer_size"
    );
    assert!(
        crate_src.contains("[`Rpc::send_buffer_size`] is that overlay in a server interceptor"),
        "crate docs must name Rpc::send_buffer_size as the server interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::send_buffer_size`]"),
        "crate docs must Distinct Rpc::send_buffer_size from Outgoing::send_buffer_size"
    );
    assert!(
        crate_src
            .contains("[`Response::send_buffer_size`] is that overlay in a response interceptor"),
        "crate docs must name Response::send_buffer_size as the response interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Request::send_buffer_size`]"),
        "crate docs must Distinct Response::send_buffer_size from Request::send_buffer_size"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::send_buffer_size`]"),
        "crate docs must Distinct Response::send_buffer_size from Rpc::send_buffer_size"
    );
    assert!(
        crate_src.contains("[`Response::path`] is kernel-stamped after `Ok` / after receive"),
        "crate docs must name Response::path as kernel-stamped"
    );
    assert!(
        crate_src.contains("Distinct from [`Request::path`]"),
        "crate docs must Distinct Response::path from Request::path"
    );
    assert!(
        crate_src.contains("Distinct from [`Outgoing::path`]"),
        "crate docs must Distinct Response::path from Outgoing::path"
    );
    assert!(
        crate_src.contains("[`Response::gzip_level`] is that overlay in a response interceptor"),
        "crate docs must name Response::gzip_level as the response interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::compress`]"),
        "crate docs must Distinct Response::gzip_level from compress"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::gzip_level`]"),
        "crate docs must Distinct Response::gzip_level from Rpc::gzip_level"
    );
    assert!(
        crate_src.contains(
            "[`Response::compresses_outbound`] is that overlay in a response interceptor"
        ),
        "crate docs must name Response::compresses_outbound as the response interceptor overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::compress`], which is the per-RPC flag."),
        "crate docs must Distinct Response::compresses_outbound from per-RPC compress"
    );
    assert!(
        crate_src.contains(
            "[`Response::accepts_gzip`] is the peer advertisement in a response interceptor"
        ),
        "crate docs must name Response::accepts_gzip as the response interceptor advertisement"
    );
    assert!(
        crate_src
            .contains("Distinct from [`Response::encoding`], which is received `grpc-encoding`."),
        "crate docs must Distinct Response::accepts_gzip from received encoding"
    );
    assert!(
        crate_src.contains("[`Response::deadline`] is kernel-stamped after `Ok`, when writing"),
        "crate docs must name Response::deadline as kernel-stamped when writing"
    );
    assert!(
        crate_src.contains("Distinct from [`Request::deadline`]"),
        "crate docs must Distinct Response::deadline from Request::deadline"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::deadline`]"),
        "crate docs must Distinct Response::deadline from Rpc::deadline"
    );
    assert!(
        crate_src.contains(
            "[`Response::timeout`] is the duration stamped at dispatch, in a response interceptor"
        ),
        "crate docs must name Response::timeout as duration stamped at dispatch"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::deadline`]"),
        "crate docs must Distinct Response::timeout from Response::deadline"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::timeout`]"),
        "crate docs must Distinct Response::timeout from Rpc::timeout"
    );
    assert!(
        crate_src.contains("[`Response::limits`] is the encode cap in a response interceptor"),
        "crate docs must name Response::limits as the response interceptor encode cap"
    );
    assert!(
        crate_src.contains("Distinct from [`Request::limits`]"),
        "crate docs must Distinct Response::limits from Request::limits"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::limits`]"),
        "crate docs must Distinct Response::limits from Rpc::limits"
    );
    assert!(
        crate_src.contains(
            "[`Response::peer_timeout`] is the client's `grpc-timeout` in a response interceptor"
        ),
        "crate docs must name Response::peer_timeout as client grpc-timeout"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::timeout`]"),
        "crate docs must Distinct Response::peer_timeout from Response::timeout"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::peer_timeout`]"),
        "crate docs must Distinct Response::peer_timeout from Rpc::peer_timeout"
    );
    assert!(
        crate_src
            .contains("[`Response::rpc_timeout`] is the server overlay in a response interceptor"),
        "crate docs must name Response::rpc_timeout as the server overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::peer_timeout`]"),
        "crate docs must Distinct Response::rpc_timeout from Response::peer_timeout"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::rpc_timeout`]"),
        "crate docs must Distinct Response::rpc_timeout from Rpc::rpc_timeout"
    );
    assert!(
        crate_src.contains(
            "[`Response::accepts_compressed`] is the inbound overlay in a response interceptor"
        ),
        "crate docs must name Response::accepts_compressed as the inbound overlay"
    );
    assert!(
        crate_src.contains("Distinct from [`Response::accepts_gzip`]"),
        "crate docs must Distinct Response::accepts_compressed from Response::accepts_gzip"
    );
    assert!(
        crate_src.contains("Distinct from [`Rpc::accepts_compressed`]"),
        "crate docs must Distinct Response::accepts_compressed from Rpc::accepts_compressed"
    );
    assert!(
        crate_src.contains("HPACK dynamic table, default 4096"),
        "crate docs must name header_table_size default 4096"
    );
    assert!(
        crate_src.contains("Distinct from `max_header_list_size`, which caps uncompressed"),
        "crate docs must Distinct header_table_size from max_header_list_size"
    );
    assert!(
        crate_src.contains("HTTP/2 small-DATA flood"),
        "crate threat table must name small-DATA flood"
    );
    assert!(
        crate_src.contains("h2 Auto (half the window) is not exposed"),
        "crate docs must not expose h2 Auto small-DATA budget"
    );
    assert!(
        crate_src.contains("too_many_data_frames"),
        "crate docs must name the hostile small-DATA flood"
    );
    assert!(
        crate_src.contains("HTTP/2 locally-reset stream memory"),
        "crate threat table must name locally-reset stream memory"
    );
    assert!(
        crate_src.contains("oldest purged, not GOAWAY"),
        "crate threat table must Distinct locally-reset stream memory from GOAWAY"
    );
    assert!(
        crate_src.contains("exceeding that evicts the"),
        "crate docs must Distinct locally-reset stream memory eviction from GOAWAY floods"
    );
    assert!(
        crate_src.contains(
            "[`ChannelConfig::max_concurrent_reset_streams`] is the client handshake cap."
        ),
        "crate docs must Distinct ChannelConfig concurrent-reset memory as the client handshake cap"
    );
    assert!(
        crate_src.contains("that is how long an ID is remembered"),
        "crate docs must Distinct reset_stream_duration as time, not count"
    );
    assert!(
        crate_src.contains("[`ChannelConfig::reset_stream_duration`] is the"),
        "crate docs must Distinct ChannelConfig reset_stream_duration as the client handshake duration"
    );
}
