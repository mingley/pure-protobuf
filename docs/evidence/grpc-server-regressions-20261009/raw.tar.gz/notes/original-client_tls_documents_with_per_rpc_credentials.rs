fn client_tls_documents_with_per_rpc_credentials() {
    let src = include_str!("../src/tls.rs");
    assert!(
        src.contains(
            "There is no grpc-go `WithPerRPCCredentials`: that is a DialOption plugging\n/// `credentials.PerRPCCredentials` that add per-RPC metadata. This type is\n/// transport TLS, not call credentials. There is no `WithCredentialsBundle`\n/// (transport plus per-RPC credentials). Distinct from GCP-auth (a library,\n/// not this DialOption). Distinct from grpc-go `WithTransportCredentials`\n/// (transport; TLS is [`crate::Channel::connect_tls`] plus this type). Distinct\n/// from [`crate::ClientInterceptor`] (user hook that can add metadata, not a\n/// credentials plugin). Distinct from [`crate::Channel::intercept`] (attaches\n/// that hook after connect)."
        ),
        "ClientTls rustdoc must Distinct transport TLS from grpc-go WithPerRPCCredentials call credentials"
    );
    assert_eq!(
        src.matches("There is no grpc-go `WithPerRPCCredentials`")
            .count(),
        1,
        "ClientTls::webpki must not copy the WithPerRPCCredentials Distinct"
    );
}
