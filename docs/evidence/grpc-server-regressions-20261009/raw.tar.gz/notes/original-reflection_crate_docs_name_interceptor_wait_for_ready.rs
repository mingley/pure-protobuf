fn reflection_crate_docs_name_interceptor_wait_for_ready() {
    let src = include_str!("../src/reflection.rs");
    assert!(
        src.contains("wait-for-ready is set on the request, the client, or a client interceptor."),
        "reflection crate rustdoc must name interceptor-set wait-for-ready"
    );
    assert!(
        src.contains(
            "`Request::set_wait_for_ready(false)` and a client interceptor\n//! `set_wait_for_ready(false)` opt out of a client default. A waiting Call's\n//! deadline applies on those dialers."
        ),
        "reflection crate rustdoc must name wait-for-ready opt-out and deadline"
    );
    assert!(
        src.contains(
            "[`crate::StreamSender::fail`] after a streamed DATA frame on\n//! `ServerReflectionInfo` ships those trailers the same way."
        ),
        "reflection crate rustdoc must name typed Status after streamed DATA"
    );
    assert!(
        src.contains(
            "`file_containing_symbol` and `file_by_filename` return the\n//! registered `FileDescriptorProto` on that method, including over TLS, mTLS,\n//! Unix, and [`crate::Channel::from_io`]. A missing symbol is `NOT_FOUND` on\n//! the stream."
        ),
        "reflection crate rustdoc must name file lookups on every transport"
    );
    assert!(
        src.contains(
            "`file_containing_extension` and `all_extension_numbers_of_type`\n//! answer from the same method on those transports; a missing extension is\n//! `NOT_FOUND` on the stream."
        ),
        "reflection crate rustdoc must name extension lookups on every transport"
    );
    assert!(
        src.contains(
            "over the decoding cap fails the stream as `RESOURCE_EXHAUSTED` trailers\n//! (`StreamSender::fail`), not a quiet OK end, including over TLS, mTLS, Unix,\n//! and [`crate::Channel::from_io`]."
        ),
        "reflection crate rustdoc must name oversize RESOURCE_EXHAUSTED on every transport"
    );
    assert!(
        src.contains(
            "A [`ServerReflectionClient`]\n//! `max_encoding_message_size` / `max_decoding_message_size` is\n//! `RESOURCE_EXHAUSTED` on the one bidi method on those transports, distinct\n//! from the server decoding cap."
        ),
        "reflection crate rustdoc must name client message caps on every transport"
    );
    assert!(
        src.contains(
            "[`ServerReflectionClient::message_limits`]\n//! refuses the same oversize, distinct from those single-cap wrappers."
        ),
        "reflection crate rustdoc must name wrap message_limits on every transport"
    );
    assert!(
        src.contains(
            "`Router::message_limits` /\n//! [`ServerReflectionServer::message_limits`] refuse the same oversize as\n//! `RESOURCE_EXHAUSTED` trailers on that method, distinct from\n//! [`crate::Router::max_decoding_message_size`]."
        ),
        "reflection crate rustdoc must name combined-setter oversize on every transport"
    );
    assert!(
        src.contains(
            "[`ServerReflectionClient::connect_tls_with`] /\n//! [`ServerReflectionClient::connect_unix_with`] /\n//! [`ServerReflectionClient::from_io_with`] with\n//! [`crate::ChannelConfig::message_limits`] refuse the same oversize, distinct\n//! from wrapping a live client."
        ),
        "reflection crate rustdoc must name dial-time ChannelConfig message_limits on every transport"
    );
    assert!(
        src.contains(
            "[`ServerReflectionServer::max_header_list_size`]\n//! refuses oversize metadata on the one bidi method, including over TLS, mTLS,\n//! Unix, and [`crate::Server::serve_connection`]. Distinct from wrapping only a\n//! Greeter server."
        ),
        "reflection crate rustdoc must name header-list flood on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "[`ServerReflectionServer::max_frame_size`] still serves the\n//! one bidi method at the HTTP/2 16 KiB SETTINGS minimum, including over TLS,\n//! mTLS, Unix, and [`crate::Server::serve_connection`]. Distinct from wrapping\n//! only a Greeter server."
        ),
        "reflection crate rustdoc must name max_frame_size still-serves on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "[`ServerReflectionServer::max_pending_accept_reset_streams`]\n//! still serves the one bidi method at a pending-reset cap of 1, including over\n//! TLS, mTLS, Unix, and [`crate::Server::serve_connection`]. A well-behaved\n//! client never fills that queue. Distinct from wrapping only a Greeter server."
        ),
        "reflection crate rustdoc must name pending-reset still-serves on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "[`ServerReflectionServer::max_send_buffer_size`] still serves the one bidi\n//! method at a 16 KiB send buffer, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter\n//! server."
        ),
        "reflection crate rustdoc must name send-buffer still-serves on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "[`ServerReflectionServer::initial_stream_window_size`] /\n//! [`ServerReflectionServer::initial_connection_window_size`] still serve the\n//! one bidi method at a 64 KiB stream / 128 KiB connection window, including\n//! over TLS, mTLS, Unix, and [`crate::Server::serve_connection`]. Distinct from\n//! wrapping only a Greeter server."
        ),
        "reflection crate rustdoc must name HTTP/2 window still-serves on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "A [`ServerReflectionClient`] pool larger than\n//! [`ServerReflectionServer::max_concurrent_connections`] fails the whole dial\n//! as `UNAVAILABLE` on TLS, mTLS, and Unix.\n//! [`ServerReflectionClient::from_io_with`] cannot pool."
        ),
        "reflection crate rustdoc must name pool-vs-cap UNAVAILABLE on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection interceptor Err; those trailers reach the client without reading the body."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to interceptor Err"
    );
    assert!(
        src.contains(
            "Distinct from a reflection handler Err: that is after the handler ran; this reflection interceptor Err is trailers without reading the body."
        ),
        "reflection crate rustdoc must Distinct handler Err after the handler ran from this reflection interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a reflection server on_response Err: that is trailers-only after handler Ok; this reflection interceptor Err is trailers without reading the body."
        ),
        "reflection crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this reflection interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client interceptor Err: that is a local reject never opens a stream; this reflection interceptor Err is trailers without reading the body."
        ),
        "reflection crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this reflection interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client on_response Err: that fails the Call after a successful receive; this reflection interceptor Err is trailers without reading the body."
        ),
        "reflection crate rustdoc must Distinct client on_response Err Call fail after receive from this reflection interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a reflection StreamSender fail: that is trailers after any messages already sent; this reflection interceptor Err is trailers without reading the body."
        ),
        "reflection crate rustdoc must Distinct StreamSender fail after any messages already sent from this reflection interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client interceptor: that runs on the outbound call before the stream opens; this reflection interceptor runs on the inbound RPC before the handler."
        ),
        "reflection crate rustdoc must Distinct client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection handler Err; those trailers reach the client."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to handler Err"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor Err: that is trailers without reading the body; this reflection handler Err is after the handler ran."
        ),
        "reflection crate rustdoc must Distinct interceptor Err without reading the body from this reflection handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client interceptor Err: that is a local reject never opens a stream; this reflection handler Err is after the handler ran."
        ),
        "reflection crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this reflection handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a reflection server on_response Err: that is trailers-only after handler Ok; this reflection handler Err is after the handler ran."
        ),
        "reflection crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this reflection handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client on_response Err: that fails the Call after a successful receive; this reflection handler Err is after the handler ran."
        ),
        "reflection crate rustdoc must Distinct client on_response Err Call fail after receive from this reflection handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a reflection StreamSender fail: that is trailers after any messages already sent; this reflection handler Err is after the handler ran."
        ),
        "reflection crate rustdoc must Distinct StreamSender fail after any messages already sent from this reflection handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this reflection client interceptor path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "reflection crate rustdoc must name Outgoing::connected live-socket snapshot on ServerReflectionInfo"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection client interceptor Err; a local reject never opens a stream."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to client interceptor Err"
    );
    assert!(
        src.contains(
            "Distinct from a reflection handler Err: that is after the handler ran; this reflection client interceptor Err is a local reject never opens a stream."
        ),
        "reflection crate rustdoc must Distinct reflection handler Err after the handler ran from this reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client on_response Err: that fails the Call after a successful receive; this reflection client interceptor Err is a local reject never opens a stream."
        ),
        "reflection crate rustdoc must Distinct client on_response Err Call fail after receive from this reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor Err: that is trailers without reading the body; this reflection client interceptor Err is a local reject never opens a stream."
        ),
        "reflection crate rustdoc must Distinct interceptor Err without reading the body from this reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a reflection StreamSender fail: that is trailers after any messages already sent; this reflection client interceptor Err is a local reject never opens a stream."
        ),
        "reflection crate rustdoc must Distinct StreamSender fail after any messages already sent from this reflection client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this reflection client interceptor already ran, so a local Err never consumes that budget."
        ),
        "reflection crate rustdoc must Distinct max_concurrent_rpcs slot grab after client intercept"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor: that runs on the inbound RPC before the handler; this reflection client interceptor runs on the outbound call before the stream opens."
        ),
        "reflection crate rustdoc must Distinct inbound interceptor from client outbound-before-stream"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to StreamSender fail"
    );
    assert!(
        src.contains(
            "Distinct from a reflection handler Err: that is after the handler ran; this reflection StreamSender fail is trailers after any messages already sent."
        ),
        "reflection crate rustdoc must Distinct handler Err after the handler ran from this reflection StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor Err: that is trailers without reading the body; this reflection StreamSender fail is trailers after any messages already sent."
        ),
        "reflection crate rustdoc must Distinct interceptor Err without reading the body from this reflection StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a reflection server on_response Err: that is trailers-only after handler Ok; this reflection StreamSender fail is trailers after any messages already sent."
        ),
        "reflection crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this reflection StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client interceptor Err: that is a local reject never opens a stream; this reflection StreamSender fail is trailers after any messages already sent."
        ),
        "reflection crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this reflection StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client on_response Err: that fails the Call after a successful receive; this reflection StreamSender fail is trailers after any messages already sent."
        ),
        "reflection crate rustdoc must Distinct client on_response Err Call fail after receive from this reflection StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to reflection server on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a reflection handler Err: that is after the handler ran; this reflection server on_response Err is trailers-only after handler Ok."
        ),
        "reflection crate rustdoc must Distinct handler Err after the handler ran from this reflection server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor Err: that is trailers without reading the body; this reflection server on_response Err is trailers-only after handler Ok."
        ),
        "reflection crate rustdoc must Distinct interceptor Err without reading the body from this reflection server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client on_response Err: that fails the Call after a successful receive; this reflection server on_response Err is trailers-only after handler Ok."
        ),
        "reflection crate rustdoc must Distinct reflection client on_response Err Call fail after receive from this reflection server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a reflection StreamSender fail: that is trailers after any messages already sent; this reflection server on_response Err is trailers-only after handler Ok."
        ),
        "reflection crate rustdoc must Distinct StreamSender fail after any messages already sent from this reflection server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this reflection client on_response Err; a local reject fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must name from_error_details typed bag next to reflection client on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a reflection handler Err: that is after the handler ran; this reflection client on_response Err fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must Distinct handler Err after the handler ran from this reflection client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a reflection interceptor Err: that is trailers without reading the body; this reflection client on_response Err fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must Distinct interceptor Err without reading the body from this reflection client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a reflection client interceptor Err: that is a local reject never opens a stream; this reflection client on_response Err fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this reflection client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a reflection server on_response Err: that is trailers-only after handler Ok; this reflection client on_response Err fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must Distinct reflection server on_response Err trailers-only after handler Ok from this reflection client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a reflection StreamSender fail: that is trailers after any messages already sent; this reflection client on_response Err fails the Call after a successful receive."
        ),
        "reflection crate rustdoc must Distinct StreamSender fail after any messages already sent from this reflection client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "[`Builder::build_v1alpha`] and [`v1alpha_service`] mount\n//! `grpc.reflection.v1alpha.ServerReflection` as a distinct service, using the\n//! same wire-compatible message layout as v1."
        ),
        "reflection crate rustdoc must name first-class v1alpha service"
    );
    assert!(
        src.contains(
            "Mount v1 first and then v1alpha\n//! so the explicit v1alpha service replaces the legacy generated v1 alias in\n//! [`crate::Router`]. `list_services` still reports registered descriptor\n//! services, not either reflection service."
        ),
        "reflection crate rustdoc must explain v1alpha mount order and list_services"
    );
}
