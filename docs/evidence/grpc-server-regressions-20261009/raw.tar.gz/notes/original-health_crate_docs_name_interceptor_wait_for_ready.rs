fn health_crate_docs_name_interceptor_wait_for_ready() {
    let src = include_str!("../src/health.rs");
    assert!(
        src.contains("wait-for-ready is set on the request, the client, or a client interceptor."),
        "Health crate rustdoc must name interceptor-set wait-for-ready"
    );
    assert!(
        src.contains(
            "`Request::set_wait_for_ready(false)` and a client interceptor\n//! `set_wait_for_ready(false)` opt out of a client default. A waiting Call's\n//! deadline applies on those dialers."
        ),
        "Health crate rustdoc must name wait-for-ready opt-out and deadline"
    );
    assert!(
        src.contains(
            "Watch\n//! [`crate::StreamSender::fail`] after a streamed DATA frame ships those\n//! trailers the same way (Check is unary: no response DATA then trailers)."
        ),
        "Health crate rustdoc must name Watch typed Status after streamed DATA"
    );
    assert!(
        src.contains(
            "Check of a never-set name is [`crate::Code::NotFound`]. Watch\n//! of that name streams [`ServingStatus::ServiceUnknown`]. Watch streams later\n//! `set_not_serving` / [`HealthReporter::shutdown`] / [`HealthReporter::resume`]\n//! changes, including over TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "Health crate rustdoc must name Check/Watch protocol on every transport"
    );
    assert!(
        src.contains(
            "Dropping a Watch releases the subscription without waiting for a status\n//! change on those transports."
        ),
        "Health crate rustdoc must name Watch drop on every transport"
    );
    assert!(
        src.contains(
            "Check, List, and Watch are the proto methods. List is a snapshot of every\n//! known name (the process `\"\"` and names you set); unknown names are omitted,\n//! matching [`HealthReporter::names`]."
        ),
        "Health crate rustdoc must name List as a snapshot of known names"
    );
    assert!(
        src.contains(
            "decoding cap is `RESOURCE_EXHAUSTED` on both, including\n//! over TLS, mTLS, Unix, and [`crate::Channel::from_io`]."
        ),
        "Health crate rustdoc must name oversize RESOURCE_EXHAUSTED on every transport"
    );
    assert!(
        src.contains(
            "A [`HealthClient`]\n//! `max_encoding_message_size` / `max_decoding_message_size` is\n//! `RESOURCE_EXHAUSTED` on Check and Watch on those transports, distinct from\n//! the server decoding cap."
        ),
        "Health crate rustdoc must name client message caps on every transport"
    );
    assert!(
        src.contains(
            "[`HealthClient::message_limits`] refuses the same\n//! oversize, distinct from those single-cap wrappers."
        ),
        "Health crate rustdoc must name wrap message_limits on every transport"
    );
    assert!(
        src.contains(
            "`Router::message_limits` /\n//! [`HealthServer::message_limits`] refuse the same oversize as\n//! `RESOURCE_EXHAUSTED` on both, distinct from\n//! [`crate::Router::max_decoding_message_size`]."
        ),
        "Health crate rustdoc must name combined-setter oversize on every transport"
    );
    assert!(
        src.contains(
            "[`HealthClient::connect_tls_with`] / [`HealthClient::connect_unix_with`] /\n//! [`HealthClient::from_io_with`] with [`crate::ChannelConfig::message_limits`]\n//! refuse the same oversize, distinct from wrapping a live client."
        ),
        "Health crate rustdoc must name dial-time ChannelConfig message_limits on every transport"
    );
    assert!(
        src.contains(
            "[`HealthServer::max_header_list_size`] refuses oversize metadata on Check\n//! and Watch, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter\n//! server."
        ),
        "Health crate rustdoc must name header-list flood on Check and Watch"
    );
    assert!(
        src.contains(
            "[`HealthServer::max_frame_size`] still serves Check, List, and Watch at\n//! the HTTP/2 16 KiB SETTINGS minimum, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter\n//! server."
        ),
        "Health crate rustdoc must name max_frame_size still-serves on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "[`HealthServer::max_pending_accept_reset_streams`] still serves Check,\n//! List, and Watch at a pending-reset cap of 1, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. A well-behaved client never fills that\n//! queue. Distinct from wrapping only a Greeter server."
        ),
        "Health crate rustdoc must name pending-reset still-serves on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "[`HealthServer::max_send_buffer_size`] still serves Check, List, and Watch at a\n//! 16 KiB send buffer, including over TLS, mTLS, Unix, and\n//! [`crate::Server::serve_connection`]. Distinct from wrapping only a Greeter\n//! server."
        ),
        "Health crate rustdoc must name send-buffer still-serves on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "[`HealthServer::initial_stream_window_size`] /\n//! [`HealthServer::initial_connection_window_size`] still serve Check, List, and Watch\n//! at a 64 KiB stream / 128 KiB connection window, including over TLS, mTLS,\n//! Unix, and [`crate::Server::serve_connection`]. Distinct from wrapping only a\n//! Greeter server."
        ),
        "Health crate rustdoc must name HTTP/2 window still-serves on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "A [`HealthClient`] pool larger than\n//! [`HealthServer::max_concurrent_connections`] fails the whole dial as\n//! `UNAVAILABLE` on TLS, mTLS, and Unix. [`HealthClient::from_io_with`]\n//! cannot pool."
        ),
        "Health crate rustdoc must name pool-vs-cap UNAVAILABLE on TLS, mTLS, and Unix"
    );
    assert!(
        src.contains(
            "path / service / method / `:authority` / `:scheme` on Check, List, and Watch."
        ),
        "Health crate rustdoc must name client interceptor context on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "[`crate::Outgoing::connected`] is the live-socket snapshot on this health client interceptor path ([`crate::Channel::connected`]), taken when the interceptor runs. Distinct from wait-for-ready: a lazy first RPC sees `false` even when that overlay is on."
        ),
        "Health crate rustdoc must name Outgoing::connected live-socket snapshot on Check, List, and Watch"
    );
    assert!(
        src.contains("retry Check, List, and Watch until listen when"),
        "Health crate rustdoc must name wait-for-ready on Check, List, and Watch"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health interceptor Err; those trailers reach the client without reading the body."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to interceptor Err"
    );
    assert!(
        src.contains(
            "Distinct from a health handler Err: that is after the handler ran; this health interceptor Err is trailers without reading the body."
        ),
        "Health crate rustdoc must Distinct handler Err after the handler ran from this health interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a health server on_response Err: that is trailers-only after handler Ok; this health interceptor Err is trailers without reading the body."
        ),
        "Health crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this health interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a health client interceptor Err: that is a local reject never opens a stream; this health interceptor Err is trailers without reading the body."
        ),
        "Health crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this health interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a health client on_response Err: that fails the Call after a successful receive; this health interceptor Err is trailers without reading the body."
        ),
        "Health crate rustdoc must Distinct client on_response Err Call fail after receive from this health interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a health StreamSender fail: that is trailers after any messages already sent; this health interceptor Err is trailers without reading the body."
        ),
        "Health crate rustdoc must Distinct StreamSender fail after any messages already sent from this health interceptor Err without reading the body"
    );
    assert!(
        src.contains(
            "Distinct from a health client interceptor: that runs on the outbound call before the stream opens; this health interceptor runs on the inbound RPC before the handler."
        ),
        "Health crate rustdoc must Distinct client outbound-before-stream from inbound-before-handler"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health handler Err; those trailers reach the client."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to handler Err"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor Err: that is trailers without reading the body; this health handler Err is after the handler ran."
        ),
        "Health crate rustdoc must Distinct interceptor Err without reading the body from this health handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a health client interceptor Err: that is a local reject never opens a stream; this health handler Err is after the handler ran."
        ),
        "Health crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this health handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a health server on_response Err: that is trailers-only after handler Ok; this health handler Err is after the handler ran."
        ),
        "Health crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this health handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a health client on_response Err: that fails the Call after a successful receive; this health handler Err is after the handler ran."
        ),
        "Health crate rustdoc must Distinct client on_response Err Call fail after receive from this health handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "Distinct from a health StreamSender fail: that is trailers after any messages already sent; this health handler Err is after the handler ran."
        ),
        "Health crate rustdoc must Distinct StreamSender fail after any messages already sent from this health handler Err after the handler ran"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health client interceptor Err; a local reject never opens a stream."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to client interceptor Err"
    );
    assert!(
        src.contains(
            "Distinct from a health handler Err: that is after the handler ran; this health client interceptor Err is a local reject never opens a stream."
        ),
        "Health crate rustdoc must Distinct health handler Err after the handler ran from this health client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a health client on_response Err: that fails the Call after a successful receive; this health client interceptor Err is a local reject never opens a stream."
        ),
        "Health crate rustdoc must Distinct client on_response Err Call fail after receive from this health client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor Err: that is trailers without reading the body; this health client interceptor Err is a local reject never opens a stream."
        ),
        "Health crate rustdoc must Distinct interceptor Err without reading the body from this health client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from a health StreamSender fail: that is trailers after any messages already sent; this health client interceptor Err is a local reject never opens a stream."
        ),
        "Health crate rustdoc must Distinct StreamSender fail after any messages already sent from this health client interceptor Err local reject never opens a stream"
    );
    assert!(
        src.contains(
            "Distinct from [`crate::Channel::max_concurrent_rpcs`]: that takes a slot when the [`crate::Call`] is polled; this health client interceptor already ran, so a local Err never consumes that budget."
        ),
        "Health crate rustdoc must Distinct max_concurrent_rpcs slot grab after client intercept"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor: that runs on the inbound RPC before the handler; this health client interceptor runs on the outbound call before the stream opens."
        ),
        "Health crate rustdoc must Distinct inbound interceptor from client outbound-before-stream"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health StreamSender fail on a server response producer; those trailers ship after any messages already sent."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to StreamSender fail"
    );
    assert!(
        src.contains(
            "Distinct from a health handler Err: that is after the handler ran; this health StreamSender fail is trailers after any messages already sent."
        ),
        "Health crate rustdoc must Distinct handler Err after the handler ran from this health StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor Err: that is trailers without reading the body; this health StreamSender fail is trailers after any messages already sent."
        ),
        "Health crate rustdoc must Distinct interceptor Err without reading the body from this health StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a health server on_response Err: that is trailers-only after handler Ok; this health StreamSender fail is trailers after any messages already sent."
        ),
        "Health crate rustdoc must Distinct server on_response Err trailers-only after handler Ok from this health StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a health client interceptor Err: that is a local reject never opens a stream; this health StreamSender fail is trailers after any messages already sent."
        ),
        "Health crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this health StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "Distinct from a health client on_response Err: that fails the Call after a successful receive; this health StreamSender fail is trailers after any messages already sent."
        ),
        "Health crate rustdoc must Distinct client on_response Err Call fail after receive from this health StreamSender fail after any messages already sent"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health server on_response Err; a local reject is trailers-only after handler Ok."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to health server on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a health handler Err: that is after the handler ran; this health server on_response Err is trailers-only after handler Ok."
        ),
        "Health crate rustdoc must Distinct handler Err after the handler ran from this health server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor Err: that is trailers without reading the body; this health server on_response Err is trailers-only after handler Ok."
        ),
        "Health crate rustdoc must Distinct interceptor Err without reading the body from this health server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a health client on_response Err: that fails the Call after a successful receive; this health server on_response Err is trailers-only after handler Ok."
        ),
        "Health crate rustdoc must Distinct health client on_response Err Call fail after receive from this health server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "Distinct from a health StreamSender fail: that is trailers after any messages already sent; this health server on_response Err is trailers-only after handler Ok."
        ),
        "Health crate rustdoc must Distinct StreamSender fail after any messages already sent from this health server on_response Err trailers-only after handler Ok"
    );
    assert!(
        src.contains(
            "[`crate::Status::from_error_details`] is the typed bag after this health client on_response Err; a local reject fails the Call after a successful receive."
        ),
        "Health crate rustdoc must name from_error_details typed bag next to health client on_response Err"
    );
    assert!(
        src.contains(
            "Distinct from a health handler Err: that is after the handler ran; this health client on_response Err fails the Call after a successful receive."
        ),
        "Health crate rustdoc must Distinct handler Err after the handler ran from this health client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a health interceptor Err: that is trailers without reading the body; this health client on_response Err fails the Call after a successful receive."
        ),
        "Health crate rustdoc must Distinct interceptor Err without reading the body from this health client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a health client interceptor Err: that is a local reject never opens a stream; this health client on_response Err fails the Call after a successful receive."
        ),
        "Health crate rustdoc must Distinct client interceptor Err local reject never opens a stream from this health client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a health server on_response Err: that is trailers-only after handler Ok; this health client on_response Err fails the Call after a successful receive."
        ),
        "Health crate rustdoc must Distinct health server on_response Err trailers-only after handler Ok from this health client on_response Err Call fail after receive"
    );
    assert!(
        src.contains(
            "Distinct from a health StreamSender fail: that is trailers after any messages already sent; this health client on_response Err fails the Call after a successful receive."
        ),
        "Health crate rustdoc must Distinct StreamSender fail after any messages already sent from this health client on_response Err Call fail after receive"
    );
}
