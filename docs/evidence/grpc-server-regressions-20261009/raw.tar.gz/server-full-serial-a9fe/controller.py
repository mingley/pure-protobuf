import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');SOURCE=ROOT/'work/gates-candidate-05f5';OUT=ROOT/'work/server-full-serial-a9fe';OUT.mkdir(exist_ok=False);PIN='a9fe4c2d336710cea6f997b00277e6410eee672a'
BINARY=ROOT/'work/native-sequential-gates-a9fe/serving/failed-test';original=json.loads((ROOT/'work/native-sequential-gates-a9fe/results.json').read_text())['results'][0];assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==original['executable_sha256']
def clean():
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==PIN
 assert not subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=SOURCE,text=True)
clean();(OUT/'controller.py').write_bytes(Path(__file__).read_bytes());args=[str(BINARY),'--test-threads=1'];start=time.monotonic();report=dict(source=PIN,state='running',passed=False,qualified=False,command=args,compiler_selected_artifact=original['artifact'],executable_sha256=original['executable_sha256'],limits='all original server tests, original deadlines and assertions; one independent test case at a time')
(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
with (OUT/'stdout').open('w') as out,(OUT/'stderr').open('w') as err:
 try:p=subprocess.run(args,cwd=SOURCE,stdout=out,stderr=err,timeout=900);code=p.returncode
 except subprocess.TimeoutExpired:code='watchdog_expired'
clean();assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==report['executable_sha256'];report.update(state='finished',passed=code==0,exit_code=code,elapsed_seconds=time.monotonic()-start,source_unchanged=True,binary_unchanged=True);(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(code,flush=True)
