# Reconstruct a source

After extracting raw.tar.gz, run `python3 source/reconstruct.py /path/to/repo /tmp/round29-source VARIANT`. Choose VARIANT from source/manifest.json. This exports baseline 9287, restores the recorded test-only baseline overlay, applies candidate overlays, and verifies every hash. Compiler/toolchain installations, binaries and build caches are excluded. Consult build and measurement logs for flags and workloads.
