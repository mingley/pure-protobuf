"""Reconstruct and verify a round29 frozen source using the recorded Git baseline."""
import argparse,hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('repository',type=Path);p.add_argument('destination',type=Path);p.add_argument('variant');a=p.parse_args();repo=a.repository.resolve(strict=True);out=a.destination.resolve();src=Path(__file__).resolve().parent;manifest=json.loads((src/'manifest.json').read_text());assert not out.exists();out.mkdir(parents=True);base=manifest['baseline_files'];process=subprocess.Popen(['git','-C',str(repo),'archive','--format=tar',manifest['baseline_commit'],*sorted(base)],stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout,mode='r|') as tar:tar.extractall(out,filter='data')
assert process.wait()==0
links=[]
for name in base:
 f=out/name
 if f.is_symlink():
  assert f.resolve(strict=True).is_relative_to(out);b=f.read_bytes();f.unlink();f.write_bytes(b);links.append(name)
for name in manifest['baseline_overlays']:
 f=(src/'baseline-overlays'/name).resolve(strict=True);assert f.is_relative_to(src/'baseline-overlays');(out/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out/name)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(out/n)==v for n,v in base.items())
chain=[];label=a.variant
while label!='round-selected':
 assert label not in chain;chain.append(label);label=manifest['variants'][label]['parent']
for label in reversed(chain):
 for name in manifest['variants'][label]['changes']:
  f=(src/'overlays'/label/name).resolve(strict=True);assert f.is_relative_to(src/'overlays'/label);(out/name).parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(f,out/name)
expected=base if a.variant=='round-selected' else manifest['variants'][a.variant]['files'];actual={str(x.relative_to(out)):sha(x) for x in out.rglob('*') if x.is_file()};assert actual==expected,(set(actual)^set(expected),[n for n in actual.keys()&expected.keys() if actual[n]!=expected[n]][:5]);print(json.dumps({'variant':a.variant,'files':len(actual),'materialized_symlinks':sorted(links),'verified':True}))
