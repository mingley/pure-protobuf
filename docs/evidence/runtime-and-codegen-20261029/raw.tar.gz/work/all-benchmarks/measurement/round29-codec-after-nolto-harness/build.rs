use std::{env, fs, path::PathBuf};
fn main() {
    let root = PathBuf::from(env!("PBRS_BENCHMARK_ROOT"));
    let proto = root.join("proto/codec_cases.proto");
    let include = root.join("proto");
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    for name in ["pbrs", "prost"] {
        fs::create_dir_all(out.join(name)).unwrap();
    }
    pbrs::codegen::Config::new()
        .owned_message_fields(env::var_os("CARGO_FEATURE_OWNED_MESSAGES").is_some())
        .out_dir(out.join("pbrs"))
        .compile_protos(&[&proto], &[&include])
        .unwrap();
    prost_build::Config::new()
        .out_dir(out.join("prost"))
        .compile_protos(&[&proto], &[&include])
        .unwrap();
    println!("cargo:rerun-if-changed={}", proto.display());
}
