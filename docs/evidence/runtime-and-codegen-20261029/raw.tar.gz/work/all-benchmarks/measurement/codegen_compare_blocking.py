"""Matched CG19 cold/unchanged generation using frozen canonical CLIs.

Preserves the canonical corpora, commands and process-tree timer. It does not
measure consumer compilation, which remains a separate benchmark axis.
"""
import argparse,hashlib,importlib.util,itertools,json,os,platform,random,re,shutil,statistics,time
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def interval(values):
 return dict(median=statistics.median(values),range=[min(values),max(values)],pairs=values)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for label in ('baseline','candidate','prost'):p.add_argument('--'+label,required=True,type=Path)
 p.add_argument('--profile',choices=['debug','release'],required=True);p.add_argument('--output',required=True,type=Path)
 p.add_argument('--prepare',action='store_true');p.add_argument('--resume',action='store_true');p.add_argument('--capture-limit',type=int,default=12)
 a=p.parse_args();out=a.output.resolve();binaries={k:getattr(a,k).resolve(strict=True) for k in ('baseline','candidate','prost')};hashes={k:sha(v) for k,v in binaries.items()}
 if a.capture_limit<1:p.error('capture limit must be positive')
 spec=importlib.util.spec_from_file_location('canonical_codegen',BASE/'canonical_codegen_blocking.py');helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper);helper.ROOT=ROOT
 env=dict(os.environ);env.update(PROTOC=str(ROOT/'work/toolchain/protoc/bin/protoc'),LC_ALL='C')
 for name in list(env):
  if name.startswith(('PURE_PROTOBUF_','SB09_PBRS_')):del env[name]
 protoc=Path(env['PROTOC']).resolve(strict=True)
 timebin=Path(env.get('PBRS_CODEGEN_TIME','/usr/bin/time')).resolve(strict=True)
 plan=[];rng=random.Random(271228)
 for repeat in range(5):
  cases=list(helper.CORPORA);rng.shuffle(cases)
  for case in cases:
   versions=list(itertools.product(('before','after'),('pbrs','prost')));rng.shuffle(versions)
   plan.extend(dict(repeat=repeat,case=case,source=source,backend=backend) for source,backend in versions)
 static=dict(schema='pbrs.codegen-generation-comparison.v1',qualified=False,profile=a.profile,binary_sha256=hashes,binaries={k:str(v) for k,v in binaries.items()},helper_sha256=sha(BASE/'canonical_codegen_blocking.py'),controller_sha256=sha(Path(__file__)),protoc_sha256=sha(protoc),time_executable=str(timebin),time_executable_sha256=sha(timebin),plan=plan)
 manifest_path=out/'manifest.json'
 if a.resume:
  manifest=json.loads(manifest_path.read_text())
  for k,v in static.items():
   if manifest[k]!=v:raise ValueError('Resumed input changed: '+k)
  if manifest['state']=='complete':raise ValueError('Already complete')
 else:
  out.mkdir(parents=True,exist_ok=False)
  corpora={}
  for case in helper.CORPORA:
   names,metadata=helper.prepare_corpus(out/'corpora'/case,case,helper.DEFAULT_SEED,('pbrs','prost'));corpora[case]=dict(names=names,metadata=metadata)
  manifest=dict(static,state='prepared',captures=[],corpora=corpora,host=platform.uname()._asdict(),affinity=sorted(os.sched_getaffinity(0)),cgroup_cpu_max=Path('/sys/fs/cgroup/cpu.max').read_text(),scope='Canonical CG19 generation CLI wall time and RSS. Fresh generation clears outputs before each paired invocation; unchanged repeats the same command; output construction/validation outside measured calls.',limits=['Shared host; no independent qualification.','Canonical process-tree sampler and subprocess wait overhead remain present, especially for small cases.','Generator default reflection/JSON/text features remain enabled; generated APIs and output volumes differ from Prost.','Consumer cold/check/release-build and runtime costs are not measured by this generation-only campaign.','System-time CPU values may be zero or quantized for small cases; primary metric is canonical elapsed wall time.','Process-tree sampled RSS is a lower bound, not retained memory.'])
 def save():manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
 save()
 if a.prepare:
  print(json.dumps(dict(state=manifest['state'],captures=len(plan))),flush=True);return
 start=len(manifest['captures']);manifest['state']='running';save()
 try:
  for entry in plan[start:start+a.capture_limit]:
   index=len(manifest['captures']);key='prost' if entry['backend']=='prost' else ('baseline' if entry['source']=='before' else 'candidate');binary=binaries[key]
   corpus=manifest['corpora'][entry['case']];proto=out/'corpora'/entry['case']/'consumer/proto';generated=out/'outputs'/f'{index:03d}';generated.mkdir(parents=True,exist_ok=False)
   cmd=[str(binary),str(proto),str(generated)]+([str(protoc)] if key!='prost' else [])+corpus['names']
   phases={};snapshots={}
   for op in ('generation','generation_unchanged'):
    row=helper.timed_command(cmd,ROOT,env,out/'logs'/f'{index:03d}'/op,out,900,100)
    if row['exit_code']!=0:raise ValueError('Generator failed; logs retained')
    error=(out/row['stderr_log']).read_text()
    cpu={}
    for name,pattern in [('user_seconds',r'User time \(seconds\): ([0-9.]+)'),('system_seconds',r'System time \(seconds\): ([0-9.]+)')]:
     m=re.search(pattern,error)
     if m:cpu[name]=float(m.group(1))
    row['system_time_cpu']=cpu
    snapshots[op]={str(q.relative_to(generated)):dict(sha256=sha(q),bytes=q.stat().st_size,mtime_ns=q.stat().st_mtime_ns) for q in sorted(generated.rglob('*.rs'))}
    if not snapshots[op]:raise ValueError('Missing generated Rust')
    phases[op]=row
   old,new=(snapshots[k] for k in ('generation','generation_unchanged'))
   if {k:(v['sha256'],v['bytes']) for k,v in old.items()}!={k:(v['sha256'],v['bytes']) for k,v in new.items()}:raise ValueError('Unchanged generation changed bytes')
   preserved=sum(old[k]['mtime_ns']==new[k]['mtime_ns'] for k in old)
   if key!='prost' and preserved!=len(old):raise ValueError('pbrs rewrote unchanged Rust')
   signature=hashlib.sha256(json.dumps({k:(v['sha256'],v['bytes']) for k,v in old.items()},sort_keys=True).encode()).hexdigest()
   capture=dict(entry,index=index,binary=key,phases=phases,generated=old,output_tree_sha256=signature,rust_bytes=sum(v['bytes'] for v in old.values()),rust_files=len(old),unchanged_mtimes_preserved=preserved)
   (out/'logs'/f'{index:03d}'/'capture.json').write_text(json.dumps(capture,indent=2)+'\n')
   rep=out/'representative-generated'/key/entry['case']
   if not rep.exists():shutil.copytree(generated,rep)
   shutil.rmtree(generated)
   manifest['captures'].append(capture);save();print(f'{len(manifest["captures"])}/{len(plan)} codegen cells passed',flush=True)
  for key,path in binaries.items():
   if sha(path)!=hashes[key]:raise ValueError('Frozen binary changed')
  if len(manifest['captures'])<len(plan):manifest['state']='paused';save();return
  rows=[]
  for case,operation in itertools.product(helper.CORPORA,('generation','generation_unchanged')):
   matching=[r for r in manifest['captures'] if r['case']==case]
   values={(r['repeat'],r['source'],r['backend']):r['phases'][operation]['elapsed_ns'] for r in matching}
   medians={source:{backend:statistics.median(values[repeat,source,backend] for repeat in range(5)) for backend in ('pbrs','prost')} for source in ('before','after')}
   ratios={name:interval(vals) for name,vals in dict(after_over_before_pbrs=[values[i,'after','pbrs']/values[i,'before','pbrs'] for i in range(5)],after_pbrs_over_prost=[values[i,'after','pbrs']/values[i,'after','prost'] for i in range(5)],control_after_over_before=[values[i,'after','prost']/values[i,'before','prost'] for i in range(5)]).items()}
   rows.append(dict(case=case,operation=operation,profile=a.profile,elapsed_ns_medians=medians,ratios=ratios,generated_bytes={key:next(r['rust_bytes'] for r in matching if r['binary']==key) for key in ('baseline','candidate','prost')},baseline_candidate_output_identical=len({r['output_tree_sha256'] for r in matching if r['backend']=='pbrs'})==1))
  (out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');manifest['state']='complete';manifest['successful_processes']=len(plan)*2;save()
 except Exception as error:
  manifest.update(state='failed',error=str(error));save();raise
 print(json.dumps(dict(state=manifest['state'],captures=len(manifest['captures']))),flush=True)
if __name__=='__main__':main()
