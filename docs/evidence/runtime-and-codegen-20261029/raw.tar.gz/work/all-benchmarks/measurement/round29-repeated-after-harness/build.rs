use std::{env, fs, path::PathBuf};
fn main() {
 let out=PathBuf::from(env::var_os("OUT_DIR").unwrap());for x in ["pbrs","prost"] {fs::create_dir_all(out.join(x)).unwrap();}
 pbrs::codegen::Config::new().owned_message_fields(env::var_os("CARGO_FEATURE_OWNED_MESSAGES").is_some()).out_dir(out.join("pbrs")).compile_protos(&["proof.proto"], &["."]).unwrap();
 prost_build::Config::new().out_dir(out.join("prost")).compile_protos(&["proof.proto"], &["."]).unwrap();println!("cargo:rerun-if-changed=proof.proto");
}
