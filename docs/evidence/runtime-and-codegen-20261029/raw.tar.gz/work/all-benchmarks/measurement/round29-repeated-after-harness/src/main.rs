use pbrs::{Parse,Serialize};
use prost::Message;
use std::hint::black_box;
#[allow(dead_code,unused,nonstandard_style,clippy::all)] mod p {include!(concat!(env!("OUT_DIR"),"/pbrs/proof.rs"));}
#[allow(dead_code,clippy::all)] mod r {include!(concat!(env!("OUT_DIR"),"/prost/repeated_tag.rs"));}
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    pub static ENABLED: AtomicBool = AtomicBool::new(false);
    pub static CALLS: AtomicU64 = AtomicU64::new(0);
    pub static BYTES: AtomicU64 = AtomicU64::new(0);
    pub struct Alloc;
    unsafe impl GlobalAlloc for Alloc {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc_zeroed(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new: usize) -> *mut u8 {
            let result = unsafe { System.realloc(ptr, old, new) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(new as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC: count::Alloc = count::Alloc;

fn cpu_ns() -> u128 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: ts is a valid timespec out pointer and PROCESS_CPUTIME_ID is read-only.
    assert_eq!(
        unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) },
        0
    );
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}
fn put_var(out:&mut Vec<u8>, mut v:u64) {while v>=128 {out.push((v as u8)|128);v>>=7;}out.push(v as u8);}
fn wire(case:&str)->Vec<u8> {
 let mut out=Vec::new();let n=match case {"empty"=>0,"small"=>1,"strings_32"=>32,"strings_1024"|"numbers_1024"|"children_1024"|"bytes15_1024"=>1024,_=>64};if case=="group_64" {out.push(43);}
 for i in 0..n {let field=match case {"strings_64"|"strings_32"|"strings_1024"|"strings_suffix_64k"|"group_64"=>1,"numbers_64"|"numbers_1024"=>2,"children_64"|"children_1024"=>3,"bytes15_64"|"bytes15_1024"=>15,"bytes16_64"=>16,"mixed_64"|"small"=>[1,2,3,15,16][i%5],"empty"=>1,_=>panic!("unknown case")};put_var(&mut out,((field<<3)|if field==2 {0}else{2}) as u64);if field==2 {put_var(&mut out,(i%127) as u64);} else {let b:&[u8]=if field==3 {&[8,7]} else {b"abcdefg"};put_var(&mut out,b.len() as u64);out.extend_from_slice(b);}}
 if case=="group_64" {out.push(44);}if case=="strings_suffix_64k" {put_var(&mut out,322);put_var(&mut out,65536);out.extend(std::iter::repeat_n(0u8,65536));}out
}
fn hash(bytes:&[u8])->String {format!("{:016x}",bytes.iter().fold(0xcbf29ce484222325u64,|h,&b|(h^u64::from(b)).wrapping_mul(0x100000001b3)))}
fn main() {
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),6);let case=&args[1];let backend=&args[2];let op=&args[3];let iters:u64=args[4].parse().unwrap();let samples:usize=args[5].parse().unwrap();assert!((iters>0&&samples>0)||(iters==0&&samples==0));let input=wire(case);let pp=p::Runs::parse(&input).unwrap();let rr=r::Runs::decode(input.as_slice()).unwrap();let canonical=pp.serialize().unwrap();assert_eq!(r::Runs::decode(canonical.as_slice()).unwrap(),rr);let checksum=canonical.iter().fold(0u64,|a,b|a.wrapping_add(u64::from(*b)));if iters==0 {println!("{}",serde_json::json!({"case":case,"backend":backend,"operation":op,"wire_bytes":input.len(),"wire_fnv1a64":hash(&input),"checksum":checksum,"semantic_prechecks":true,"message_storage":if cfg!(feature="owned-messages"){"owned"}else{"lazy"},"allocation_instrumentation":cfg!(feature="allocations"),"samples":[]}));return;}
 let run=|| {if backend=="pbrs" {let m=p::Runs::parse(black_box(&input)).unwrap();if op=="roundtrip" {black_box(m.serialize().unwrap());}black_box(m);} else {let m=r::Runs::decode(black_box(input.as_slice())).unwrap();if op=="roundtrip" {black_box(m.encode_to_vec());}black_box(m);}};
 for _ in 0..(iters/10).max(1) {run();}let mut rows=Vec::new();for _ in 0..samples {#[cfg(feature="allocations")]count::start();let cpu=cpu_ns();let wall=std::time::Instant::now();for _ in 0..iters {run();}let wall=wall.elapsed().as_nanos();let cpu=cpu_ns()-cpu;#[cfg(feature="allocations")]let (allocations,bytes)=count::stop();#[cfg(not(feature="allocations"))]let (allocations,bytes)=(None::<u64>,None::<u64>);rows.push(serde_json::json!({"cpu_ns":cpu,"wall_ns":wall,"iterations":iters,"allocation_calls":allocations,"requested_bytes":bytes}));}
 println!("{}",serde_json::json!({"case":case,"backend":backend,"operation":op,"wire_bytes":input.len(),"wire_fnv1a64":hash(&input),"checksum":checksum,"semantic_prechecks":true,"message_storage":if cfg!(feature="owned-messages"){"owned"}else{"lazy"},"allocation_instrumentation":cfg!(feature="allocations"),"samples":rows}));
}
