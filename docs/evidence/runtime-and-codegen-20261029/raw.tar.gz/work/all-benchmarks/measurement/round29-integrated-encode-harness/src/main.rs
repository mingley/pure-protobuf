//! Partial-access holdout; visits only root and its first child in timing.
use pbrs::{Parse,Serialize};
use prost::Message;
use std::hint::black_box;
#[allow(dead_code, unused, nonstandard_style, clippy::all)]
mod p { include!(concat!(env!("OUT_DIR"),"/pbrs/partial-getter.rs")); }
#[allow(dead_code, clippy::all)]
mod r { include!(concat!(env!("OUT_DIR"),"/prost/partial.rs")); }
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    pub static ENABLED: AtomicBool = AtomicBool::new(false);
    pub static CALLS: AtomicU64 = AtomicU64::new(0);
    pub static BYTES: AtomicU64 = AtomicU64::new(0);
    pub struct Alloc;
    unsafe impl GlobalAlloc for Alloc {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc_zeroed(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new: usize) -> *mut u8 {
            let result = unsafe { System.realloc(ptr, old, new) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(new as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC: count::Alloc = count::Alloc;

fn cpu_ns() -> u128 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: ts is a valid timespec out pointer and PROCESS_CPUTIME_ID is read-only.
    assert_eq!(
        unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) },
        0
    );
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}


fn node(depth:i32)->r::Node { r::Node { n:depth,child:(depth>1).then(||Box::new(node(depth-1))) } }
fn hash(bytes:&[u8])->String { format!("{:016x}",bytes.iter().fold(0xcbf29ce484222325u64,|h,b|(h^u64::from(*b)).wrapping_mul(0x100000001b3))) }
trait Case: Sized {
 fn parse(data:&[u8])->Self;
 fn encode(&self)->Vec<u8>;
 fn mutate_child(&mut self,value:i32);
}
impl Case for p::Node {
 fn parse(data:&[u8])->Self { <Self as Parse>::parse(data).unwrap() }
 fn encode(&self)->Vec<u8> { self.serialize().unwrap() }
 fn mutate_child(&mut self,value:i32) { self.child_mut().set_n(value); }
}
impl Case for r::Node {
 fn parse(data:&[u8])->Self { <Self as Message>::decode(data).unwrap() }
 fn encode(&self)->Vec<u8> { self.encode_to_vec() }
 fn mutate_child(&mut self,value:i32) { self.child.as_mut().unwrap().n=value; }
}
fn sample<M:Case>(op:&str,wire:&[u8],iterations:u64)->serde_json::Value {
 let mut cpu=0;let mut wall=0;
 #[cfg(feature="allocations")] let mut total_allocations=0;
 #[cfg(feature="allocations")] let mut total_requested=0;
 if op=="fresh_encode" {
  // Bounded batches exclude parsing and input destruction from encoder CPU.
  // Every prepared input is encoded once; each output is dropped in timing.
  let mut remaining=iterations;
  while remaining>0 {
   let n=remaining.min(2000);let messages:Vec<M>=(0..n).map(|_|M::parse(wire)).collect();
   #[cfg(feature="allocations")] count::start();
   let start=cpu_ns();let elapsed=std::time::Instant::now();
   for message in &messages {black_box(message.encode());}
   wall+=elapsed.elapsed().as_nanos();cpu+=cpu_ns()-start;
   #[cfg(feature="allocations")] {let(a,b)=count::stop();total_allocations+=a;total_requested+=b;}
   drop(messages);remaining-=n;
  }
 } else {
  let mut prepared=M::parse(wire);
  if op=="mutate_encode" {prepared.mutate_child(1);}
  black_box(prepared.encode());
  #[cfg(feature="allocations")] count::start();
  let start=cpu_ns();let elapsed=std::time::Instant::now();
  for index in 0..iterations {
   if op=="parse_fresh_encode" {let message=M::parse(black_box(wire));black_box(message.encode());black_box(message);}
   else if op=="cached_encode" {black_box(prepared.encode());}
   else if op=="mutate_encode" {prepared.mutate_child((index&1) as i32);black_box(prepared.encode());}
   else {panic!("unknown operation");}
  }
  wall=elapsed.elapsed().as_nanos();cpu=cpu_ns()-start;
  #[cfg(feature="allocations")] {let(a,b)=count::stop();total_allocations=a;total_requested=b;}
 }
 #[cfg(feature="allocations")] let(allocations,requested)=(Some(total_allocations),Some(total_requested));
 #[cfg(not(feature="allocations"))] let(allocations,requested)=(None::<u64>,None::<u64>);
 serde_json::json!({"cpu_ns":cpu,"wall_ns":wall,"iterations":iterations,"allocation_calls":allocations,"requested_bytes":requested})
}
fn run<M:Case>(op:&str,wire:&[u8],iterations:u64,samples:usize)->Vec<serde_json::Value> {
 black_box(sample::<M>(op,wire,(iterations/10).max(1)));
 (0..samples).map(|_|sample::<M>(op,wire,iterations)).collect()
}
fn main() {
 let args:Vec<_>=std::env::args().collect();assert_eq!(args.len(),6);
 let depth=match args[1].as_str(){"nested_8"=>8,"nested_64"=>64,_=>panic!("unknown fixture")};
 let backend=args[2].as_str();assert!(backend=="pbrs"||backend=="prost");let op=args[3].as_str();
 assert!(["parse_fresh_encode","fresh_encode","cached_encode","mutate_encode"].contains(&op));
 let iterations:u64=args[4].parse().unwrap();let samples:usize=args[5].parse().unwrap();assert!(iterations>0&&samples>0);
 let reference=node(depth);let wire=reference.encode_to_vec();
 let mut native=<p::Node as Case>::parse(&wire);assert_eq!(r::Node::decode(Case::encode(&native).as_slice()).unwrap(),reference);
 for value in [0,1,127,128,i32::MAX] {native.mutate_child(value);let mut changed=reference.clone();changed.child.as_mut().unwrap().n=value;
 assert_eq!(r::Node::decode(Case::encode(&native).as_slice()).unwrap(),changed);}
 let values=if backend=="pbrs" {run::<p::Node>(op,&wire,iterations,samples)} else {run::<r::Node>(op,&wire,iterations,samples)};
 println!("{}",serde_json::json!({"schema":"node-encode-holdout/1","case":args[1],"backend":backend,"operation":op,
  "wire_bytes":wire.len(),"wire_fnv1a64":hash(&wire),"checksum":(depth*(depth+1)/2) as u64,
  "semantic_prechecks":true,"message_storage": if cfg!(feature="owned-messages") {"owned"} else {"lazy"},"allocation_instrumentation":cfg!(feature="allocations"),"samples":values,
  "fresh_encode_scope":"first encode of each of up to2000preparedinputs perboundedbatch; parsing and inputdrop outside timing; outputdropinside",
  "cached_encode_scope":"unchanged parsedinput; firstencode outside timing; fresh outputallocation/drop eachiteration",
  "mutate_encode_scope":"parsedinput with warmed childmaterialization and encodecache; alternate firstchild.n eachiteration thenencode",
  "parse_fresh_encode_scope":"parse,firstencode,outputdropandinputdrop eachiteration"}));
}
