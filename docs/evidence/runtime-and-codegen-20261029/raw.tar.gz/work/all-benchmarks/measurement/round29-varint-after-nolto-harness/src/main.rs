use std::hint::black_box;
fn cpu_ns() -> u64 { let mut t = std::mem::MaybeUninit::<libc::timespec>::uninit(); assert_eq!(unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, t.as_mut_ptr()) }, 0); let t = unsafe { t.assume_init() }; (t.tv_sec as u64)*1_000_000_000+(t.tv_nsec as u64) }
fn fixtures(case: &str) -> Vec<(Vec<u8>, Option<u64>, usize)> {
 let vals: Vec<(Vec<u8>, Option<u64>, usize)> = match case {
  "one" => vec![(vec![0x7f],Some(127),1)],
  "two" => vec![(vec![0xac,0x02],Some(300),2)],
  "mixed" => vec![(vec![0x00],Some(0),1),(vec![0x7f],Some(127),1),(vec![0x80,0x01],Some(128),2),(vec![0xac,0x02],Some(300),2)],
  "three_to_five" => vec![(vec![0x80,0x80,0x01],Some(16384),3),(vec![0x80,0x80,0x80,0x01],Some(2097152),4),(vec![0x80,0x80,0x80,0x80,0x01],Some(268435456),5)],
  "ten" => vec![(vec![0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0xff,0x01],Some(u64::MAX),10)],
  "truncated" => vec![(vec![0x80,0x80],None,2)],
  "overflow" => vec![(vec![0xff;10],None,10)],
  _=>panic!("unknown case")
 }; vals.into_iter().map(|(x,v,n)| {let mut data=vec![0x33,0x44,0x55]; data.extend(x);(data,v,n+3)}).collect()
}
fn main() {
 let args:Vec<String>=std::env::args().collect(); assert_eq!(args.len(),3);let case=&args[1];let iterations:u64=args[2].parse().unwrap();let fixtures=fixtures(case);
 for (buf,expected,end) in &fixtures {let mut pos=3;let result=pbrs::rt::decode_varint(buf,&mut pos).ok();assert_eq!(&result,expected);assert_eq!(&pos,end);}
 let execute=|n:u64| {let mut sum=0u64;for i in 0..n {let j=black_box(i as usize)%fixtures.len();let (buf,_,_)=black_box(&fixtures[j]);let mut pos=black_box(3usize);let v=black_box(pbrs::rt::decode_varint(black_box(buf),&mut pos));sum=sum.wrapping_add(black_box(v.unwrap_or(0))).wrapping_add(black_box(pos as u64));}black_box(sum)};
 if iterations==0 {println!("{}",serde_json::json!({"case":case,"semantic_prechecks":true,"iterations":0,"cases":fixtures.len()}));return;}
 black_box(execute((iterations/100).max(1)));let start=cpu_ns();let value=execute(iterations);let elapsed=cpu_ns()-start;println!("{}",serde_json::json!({"case":case,"semantic_prechecks":true,"iterations":iterations,"cpu_ns":elapsed,"checksum":value,"cases":fixtures.len()}));
}
