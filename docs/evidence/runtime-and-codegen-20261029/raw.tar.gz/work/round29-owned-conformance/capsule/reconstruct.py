#!/usr/bin/env python3
"""Reconstruct and verify the source used for the owned conformance testee."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile

if len(sys.argv) != 3:
    raise SystemExit('usage: reconstruct.py REPOSITORY NEW_DESTINATION')
repo = Path(sys.argv[1]).resolve()
dest = Path(sys.argv[2]).resolve()
if dest.exists():
    raise SystemExit('destination already exists')
here = Path(__file__).resolve().parent
selection = json.loads((here / 'source-selection-final.json').read_text())
commit = selection['selected_commit']
paths = selection['selected_paths']
dest.mkdir(parents=True)
with tempfile.TemporaryFile() as archive:
    subprocess.run(['git', '-C', str(repo), 'archive', '--format=tar', commit, *paths], stdout=archive, check=True)
    archive.seek(0)
    with tarfile.open(fileobj=archive) as stream:
        stream.extractall(dest, filter='data')

def verify(manifest):
    expected = json.loads((here / manifest).read_text())
    actual = {str(path.relative_to(dest)): {'sha256': hashlib.sha256(path.read_bytes()).hexdigest(), 'bytes': path.stat().st_size}
              for path in sorted(dest.rglob('*')) if path.is_file() and not path.is_symlink()}
    if expected != actual:
        raise SystemExit(f'{manifest} mismatch')
    print(f'{manifest}: {len(actual)} files match')

verify('source-prepared.json')
with (here / 'owned-generated.patch').open('rb') as patch:
    subprocess.run(['patch', '--batch', '-p1'], cwd=dest, stdin=patch, check=True, stdout=subprocess.DEVNULL)
verify('source-after.json')
