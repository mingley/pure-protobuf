# Receive staging screen

The bounded candidate is rejected and `pbrs-grpc/src/wire/frame_reader.rs` is restored to commit `9287d474`. The candidate source is preserved in `work/frame-reader-bounded-candidate.rs` (SHA-256 `68c331204bf987b4466c261f2e23a4cd5b25fde182227679a7d4e3eb6cac2191`).

## What was tested

The candidate staged incomplete identity frames as observed chunks and copied them into one exact-size frame after the last bytes arrived. It allowed a short validated header prefix, required each retained input to be uniquely owned, converted it to a `Vec` to expose actual backing capacity, rejected any backing larger than twice its visible length, and fell back after 1,024 chunks or an unsuitable chunk. The temporary staging allocation bound did not include the final output, final input, or pre-existing carry. A 1 MiB bidirectional TCP unary fixture with temporary instrumentation showed both frames entered and completed the candidate path (`work/receive-stage-dispatch-probe.log`). The instrumented run is a functional path check, not a performance measurement.

A standalone synthetic probe extracted the candidate and baseline frame-reader implementations and frame-pop code and linked the same optimized `bytes` 1.12.1. Fresh owned input chunks included their allocation and copy cost, with a nine-byte advanced prefix. Four fixed fragmentation patterns model 16 KiB, 64 KiB, and the two fragment patterns observed in the TCP fixture. The limits and status types were simplified; the probe did not execute full RPC or kernel I/O. `Vec::from(BytesMut)` can move visible bytes to the allocation start, including before rejecting an oversized backing; these copies were not covered by the existing carry-copy counter. The allocator probe's peak live value tracks net allocations and may miss transient `realloc` internals; it is not RSS.

## Result

The randomized five-pair screen and all 48 zero-iteration correctness preflights are in `results.json`. The candidate/baseline median thread-CPU ratios across patterns were 1.300–1.562 for 1 MiB and 1.739–1.863 for 8 MiB. Small 64-byte ratios ranged from 0.975 to 1.080. Large-message allocation calls rose to 1.583–1.971 times baseline, while requested bytes fell to 0.401–0.516 times baseline. Peak live tracked bytes were up to 1.307 times baseline. These are measurements of this synthetic screen, not endpoint or peer comparisons.

The focused frame-reader tests, a non-instrumented 1 MiB TCP request/response fixture, and `cargo clippy -p pbrs-grpc --lib --all-features -- -D warnings` passed before rejection. No claim is made that correctness alone justifies adoption. No full RPC timing or RSS comparison was run for this rejected candidate.

A separate `work/bytes-capacity-probe.rs` demonstrates why a unique `BytesMut::capacity()` check cannot bound its retained allocation: an 8 KiB tail view of an 8 MiB vector reports capacity 8 KiB, while conversion back to `Vec` recovers 8 MiB. Avoid retaining large numbers of input views without an actual backing bound.
