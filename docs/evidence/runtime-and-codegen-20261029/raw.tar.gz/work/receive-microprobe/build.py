from pathlib import Path
import subprocess
root = Path(__file__).resolve().parents[2]
out = Path(__file__).resolve().parent
codec = (root/'pbrs-grpc/src/codec.rs').read_text()
codec = codec[codec.index('pub fn pop_limited('):codec.index('#[cfg(test)]\nmod tests {')]
source = {'baseline': subprocess.check_output(['git','show','HEAD:pbrs-grpc/src/wire/frame_reader.rs'],cwd=root,text=True),
          'candidate': (root/'work/frame-reader-bounded-candidate.rs').read_text()}
template = (out/'probe.rs.in').read_text()
for name, contents in source.items():
    impl = contents[contents.index('pub(crate) struct FrameReader {'):contents.index('pub(crate) fn decode_frame<T: CodecMessage>(')]
    (out/(name+'.rs')).write_text(template.replace('@@CODEC@@',codec).replace('@@READER@@',impl))
