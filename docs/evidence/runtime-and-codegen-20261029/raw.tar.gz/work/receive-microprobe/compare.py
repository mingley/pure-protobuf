#!/usr/bin/env python3
"""Run paired, alternating measurements; only launch in a quiet window."""
import argparse, datetime, hashlib, json, random, statistics, subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SHAPES = ('16k', '64k', 'request', 'response')
SIZES = (64, 1048576, 8388608)
# Duration is deliberately bounded; exact counts are retained in the output.
CPU_ITERS = {64: 50000, 1048576: 150, 8388608: 16}
ALLOC_ITERS = {64: 5000, 1048576: 32, 8388608: 4}
PAIRS = 5
SEED = 9287
BINARIES = {f'{v}-{kind}': HERE/f'{v}-{kind}' for v in ('baseline', 'candidate') for kind in ('cpu', 'alloc')}
FROZEN = {
    'baseline.rs': '5ac7214d8f632567ad384cbe7bcc4f61261c6a386e2d10bbf9e9c35d33671bbc',
    'candidate.rs': '07e13b4dc417b677898f5cc366311faffd5807a7f5e8a880cd6b2b71102e20d0',
    'baseline-cpu': '430d13d371350b2826fd5a261e028f93a54306832baed2112da924885876ea22',
    'candidate-cpu': '3d49599b5595b983311cde1835ac24d5b914e4547f0e9f9a12a4b4337f0aa278',
    'baseline-alloc': '2e205e1e1bb5cbdb6f672e358bbf1d0760debc7c0732d453ffc795afef921ba5',
    'candidate-alloc': '8f0926a50a3fb9f84e46ebe5b4a576194a2da14ec747891d1097d626c91df9c6',
    'libbytes.rlib': '05db10599ca8e7ac01de12e9610765f5a0e00e0fce03049d9bf877c3dca4ee1e',
}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def invoke(path, size, shape, iterations):
    result = subprocess.run([str(path), str(size), shape, str(iterations)], check=True, text=True, capture_output=True)
    data = {}
    for token in result.stdout.strip().split():
        key, value = token.split('=', 1)
        data[key] = value if key == 'shape' else int(value)
    if (data['size'], data['shape'], data['iterations']) != (size, shape, iterations):
        raise ValueError(f'unexpected output {result.stdout!r}')
    return data

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    files = [HERE/'build.py', HERE/'probe.rs.in', HERE/'baseline.rs', HERE/'candidate.rs', HERE/'libbytes.rlib', *BINARIES.values()]
    git_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
    if git_head != '9287d474d3062911af3e9a65612a9d986d9be530':
        raise ValueError(f'baseline checkout changed: {git_head}')
    for name, expected in FROZEN.items():
        if sha(HERE/name) != expected:
            raise ValueError(f'frozen artifact changed: {name}')
    candidate = ROOT/'work/frame-reader-bounded-candidate.rs'
    if sha(candidate) != '68c331204bf987b4466c261f2e23a4cd5b25fde182227679a7d4e3eb6cac2191':
        raise ValueError('candidate source hash changed')
    output = {
        'utc_started': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseline_commit': git_head, 'candidate_sha256': sha(candidate),
        'rustc': subprocess.check_output(['rustc','--version'], text=True).strip(),
        'hashes': {str(f.relative_to(ROOT)): sha(f) for f in files},
        'seed': SEED, 'pairs': PAIRS, 'cpu_iterations': CPU_ITERS, 'allocation_iterations': ALLOC_ITERS,
        'limits': ['synthetic FrameReader/codec extraction, simplified unlimited limits and Status',
                   'input chunk allocation and copying included; source chunks uniquely owned with 9-byte advanced prefix',
                   'fixed fragmentation patterns from observed examples; not actual transport workload',
                   'allocation peak tracks net global-allocator live bytes and misses transient realloc internals',
                   'CPU binaries omit allocation instrumentation; alloc binaries incur atomic counting overhead',
                   'diagnostic screen only, not whole-RPC performance'],
        'preflight': [], 'samples': []}
    for size in SIZES:
        for shape in SHAPES:
            for key, binary in BINARIES.items():
                invoke(binary, size, shape, 0)
                output['preflight'].append({'size': size, 'shape': shape, 'binary': key, 'verified': True})
    rng = random.Random(SEED)
    cases = [(size, shape, kind, pair) for pair in range(PAIRS) for size in SIZES for shape in SHAPES for kind in ('cpu','alloc')]
    rng.shuffle(cases)
    for size, shape, kind, pair in cases:
        order = ['baseline', 'candidate']
        rng.shuffle(order)
        count = (CPU_ITERS if kind == 'cpu' else ALLOC_ITERS)[size]
        values = {v: invoke(BINARIES[f'{v}-{kind}'], size, shape, count) for v in order}
        output['samples'].append({'size':size, 'shape':shape, 'kind':kind, 'pair':pair, 'order':order, 'values':values})
    output['utc_finished'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    summaries = []
    for size in SIZES:
        for shape in SHAPES:
            rows = [s for s in output['samples'] if s['size']==size and s['shape']==shape]
            def median_ratio(kind, field):
                vals = [s['values']['candidate'][field] / s['values']['baseline'][field] for s in rows if s['kind']==kind and s['values']['baseline'][field] > 0]
                return statistics.median(vals) if vals else None
            summaries.append({'size':size, 'shape':shape, 'candidate_over_baseline':{
                'cpu_ns':median_ratio('cpu','cpu_ns'), 'allocs':median_ratio('alloc','allocs'),
                'requested':median_ratio('alloc','requested'), 'peak_live':median_ratio('alloc','peak_live')}})
    output['summary'] = summaries
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2)+'\n')
    print(json.dumps(summaries, indent=2))

if __name__ == '__main__':
    main()
