use bytes::{Buf, Bytes, BytesMut};
use std::{hint::black_box, sync::atomic::{AtomicBool, AtomicI64, AtomicU64, Ordering}, time::Instant};
#[derive(Debug)] struct Status;
impl Status { fn internal(_: impl AsRef<str>) -> Self { Self } }
#[derive(Clone,Copy)] struct MessageLimits;
impl MessageLimits { fn check_decode(&self, _:usize) -> Result<(),Status> { Ok(()) } }
mod copy_counts { pub fn note_carry(_:usize) {} pub fn note_chunk_slice(_:usize) {} }
mod codec {
    use super::{Status, MessageLimits};
    use bytes::{Buf, Bytes, BytesMut};
    pub const HEADER_LEN:usize = 5;
    #[derive(Debug)] pub struct Frame { pub compressed:bool, pub payload:Bytes }
    pub fn pop_limited(buf: &mut BytesMut, limits: MessageLimits) -> Result<Option<Frame>, Status> {
    let Some(header) = buf.get(..HEADER_LEN) else {
        return Ok(None);
    };
    let (flag, len_bytes) = header.split_at(1);
    let flag = flag.first().copied().unwrap_or_default();
    if flag > 1 {
        return Err(Status::internal(format!(
            "invalid gRPC compressed-flag {flag}"
        )));
    }
    let mut len_be = [0u8; 4];
    len_be.copy_from_slice(len_bytes);
    let len = usize::try_from(u32::from_be_bytes(len_be))
        .map_err(|_| Status::internal("message too large"))?;
    limits.check_decode(len)?;
    let total = HEADER_LEN
        .checked_add(len)
        .ok_or_else(|| Status::internal("message too large"))?;
    if buf.len() < total {
        return Ok(None);
    }
    drop(buf.split_to(HEADER_LEN));
    Ok(Some(Frame {
        compressed: flag == 1,
        payload: buf.split_to(len).freeze(),
    }))
}

/// Take one complete frame off the front of an immutable chunk.
///
/// Returns the frame plus the unconsumed remainder. This is the zero-copy
/// path: the payload is a slice of `chunk`, so a frame that arrived whole in
/// one HTTP/2 DATA frame is never copied into an intermediate buffer.
pub(crate) fn pop_from_chunk(
    chunk: &mut Bytes,
    limits: MessageLimits,
) -> Result<Option<Frame>, Status> {
    let Some(header) = chunk.get(..HEADER_LEN) else {
        return Ok(None);
    };
    let (flag, len_bytes) = header.split_at(1);
    let flag = flag.first().copied().unwrap_or_default();
    if flag > 1 {
        return Err(Status::internal(format!(
            "invalid gRPC compressed-flag {flag}"
        )));
    }
    let mut len_be = [0u8; 4];
    len_be.copy_from_slice(len_bytes);
    let len = usize::try_from(u32::from_be_bytes(len_be))
        .map_err(|_| Status::internal("message too large"))?;
    limits.check_decode(len)?;
    let total = HEADER_LEN
        .checked_add(len)
        .ok_or_else(|| Status::internal("message too large"))?;
    if chunk.len() < total {
        return Ok(None);
    }
    // The 5-byte header is discarded. `advance` moves the view; `split_to`
    // would clone the shared buffer just to drop those bytes.
    chunk.advance(HEADER_LEN);
    crate::copy_counts::note_chunk_slice(len);
    // A DATA frame that holds exactly one gRPC message is the whole chunk
    // after the header. Moving it avoids another shared-buffer clone.
    let payload = if chunk.len() == len {
        std::mem::take(chunk)
    } else {
        chunk.split_to(len)
    };
    Ok(Some(Frame {
        compressed: flag == 1,
        payload,
    }))
}


}
use codec::Frame;
pub(crate) struct FrameReader {
    pub(crate) chunk: Bytes,
    pub(crate) carry: BytesMut,
    staged: Option<Box<StagedFrame>>,
    pub(crate) limits: MessageLimits,
}

// Staging uniquely owned DATA chunks avoids geometric carry growth. Each
// backing is checked against its observed length and the part count is capped;
// shared, oversized or tiny chunks fall back to incremental copying.
const STAGE_MIN_CHUNK: usize = 8 * 1024;
const STAGE_MIN_FRAME: usize = 256 * 1024;
const STAGE_MAX_PREFIX: usize = 128;
const STAGE_MAX_CHUNKS: usize = 1024;

struct StagedFrame {
    parts: Vec<Bytes>,
    observed: usize,
    total: usize,
}

impl FrameReader {
    pub(crate) fn new(limits: MessageLimits) -> Self {
        Self {
            chunk: Bytes::new(),
            carry: BytesMut::new(),
            staged: None,
            limits,
        }
    }

    pub(crate) fn push(&mut self, next: Bytes) {
        if !self.chunk.is_empty() {
            // A caller may push twice without polling. Flatten only bytes
            // already received, retaining their original wire order.
            self.flatten_staged();
            // The first unconsumed DATA chunk has not entered carry yet.
            // Reserve before copying it: reserving a short suffix after a
            // full-size first chunk would already force Vec's doubling.
            if self.carry.is_empty() {
                if let Some(frame_len) = self.anticipated_frame_len(next.len()) {
                    if !self.carry.try_reclaim(frame_len) {
                        self.carry = BytesMut::with_capacity(frame_len);
                    }
                }
            }
            crate::copy_counts::note_carry(self.chunk.len());
            self.carry.extend_from_slice(&self.chunk);
        }
        self.chunk = next;
        // Identity keeps its original incremental allocation policy: header-
        // time reservation hurt throughput, and observed-half reservation
        // raised endpoint CPU. Only compressed frames anticipate validated
        // length after actual half-frame input has arrived.
    }

    // A rejected or incomplete header keeps the existing deferred error path.
    // No claimed capacity is allocated until half the complete frame has
    // actually arrived across the retained chunk and the next DATA chunk.
    fn anticipated_frame_len(&self, next_len: usize) -> Option<usize> {
        let flag = self.chunk.first().copied()?;
        if flag != 1 {
            return None;
        }
        let encoded = self.chunk.get(1..codec::HEADER_LEN)?;
        let mut length = [0u8; 4];
        length.copy_from_slice(encoded);
        let payload_len = usize::try_from(u32::from_be_bytes(length)).ok()?;
        self.limits.check_decode(payload_len).ok()?;
        let frame_len = codec::HEADER_LEN.checked_add(payload_len)?;
        if self.chunk.len() >= frame_len {
            return None;
        }
        let observed = self.chunk.len().saturating_add(next_len).min(frame_len);
        (frame_len - observed <= observed).then_some(frame_len)
    }

    pub(crate) fn next_frame(&mut self) -> Result<Option<Frame>, Status> {
        if self.staged.is_some() {
            if let Some(frame) = self.next_staged_frame()? {
                return Ok(Some(frame));
            }
            if self.staged.is_some() || self.chunk.is_empty() {
                return Ok(None);
            }
        }
        if self.carry.is_empty() {
            let frame = codec::pop_from_chunk(&mut self.chunk, self.limits)?;
            if frame.is_none() {
                self.stage_initial_chunk();
            }
            return Ok(frame);
        }
        // Complete and validate the header before copying any more payload.
        // No reservation based on a claimed length precedes this validation.
        if self.carry.len() < codec::HEADER_LEN {
            self.copy_chunk_prefix(codec::HEADER_LEN - self.carry.len());
        }
        if let Some(frame) = codec::pop_limited(&mut self.carry, self.limits)? {
            return Ok(Some(frame));
        }
        let Some(encoded_len) = self.carry.get(1..codec::HEADER_LEN) else {
            return Ok(None);
        };
        if self.chunk.is_empty() {
            return Ok(None);
        }
        let mut length = [0u8; 4];
        length.copy_from_slice(encoded_len);
        let payload_len = usize::try_from(u32::from_be_bytes(length))
            .map_err(|_| Status::internal("message too large"))?;
        let frame_len = codec::HEADER_LEN
            .checked_add(payload_len)
            .ok_or_else(|| Status::internal("message too large"))?;
        let needed = frame_len.saturating_sub(self.carry.len());
        let arriving = needed.min(self.chunk.len());
        let observed = self.carry.len() + arriving;
        if self.carry.first() == Some(&0)
            && self.carry.len() <= STAGE_MAX_PREFIX
            && frame_len >= STAGE_MIN_FRAME
            && self.chunk.len() >= STAGE_MIN_CHUNK
            && arriving < needed
        {
            if let Some(part) = self.take_bounded_chunk() {
                let prefix = Bytes::copy_from_slice(&self.carry);
                self.carry.clear();
                self.staged = Some(Box::new(StagedFrame {
                    parts: vec![prefix, part],
                    observed,
                    total: frame_len,
                }));
                return Ok(None);
            }
        }
        if self.carry.first() == Some(&1)
            && arriving > self.carry.capacity() - self.carry.len()
            && frame_len - observed <= observed
        {
            // Fragmented input must be contiguous before decoding. Once at
            // least half has actually arrived, grow to its validated length
            // rather than doubling just short of the final few wire bytes.
            // Keep early growth proportional to received bytes: a header
            // alone must not reserve its entire claim, even without a cap.
            // Whole-frame chunks still take the direct shared-byte path.
            self.carry.reserve(needed);
        }
        self.copy_chunk_prefix(needed);
        codec::pop_limited(&mut self.carry, self.limits)
    }

    fn stage_initial_chunk(&mut self) {
        if self.chunk.len() < STAGE_MIN_CHUNK || self.chunk.first() != Some(&0) {
            return;
        }
        // pop_from_chunk has already validated both header and length.
        let Some(encoded) = self.chunk.get(1..codec::HEADER_LEN) else {
            return;
        };
        let mut length = [0u8; 4];
        length.copy_from_slice(encoded);
        let Some(total) = usize::try_from(u32::from_be_bytes(length))
            .ok()
            .and_then(|n| n.checked_add(codec::HEADER_LEN))
        else {
            return;
        };
        if self.chunk.len() >= total || total < STAGE_MIN_FRAME {
            return;
        }
        let observed = self.chunk.len();
        let Some(part) = self.take_bounded_chunk() else {
            return;
        };
        let mut parts = Vec::with_capacity(8);
        parts.push(part);
        self.staged = Some(Box::new(StagedFrame {
            parts,
            observed,
            total,
        }));
    }

    // BytesMut::capacity describes only the current view; an advanced view
    // can retain a much larger allocation. Recover the unique Vec to check
    // its actual capacity. This may move its data to the allocation start.
    fn take_bounded_chunk(&mut self) -> Option<Bytes> {
        let chunk = std::mem::take(&mut self.chunk);
        let mutable = match chunk.try_into_mut() {
            Ok(mutable) => mutable,
            Err(chunk) => {
                self.chunk = chunk;
                return None;
            }
        };
        let owned = Vec::from(mutable);
        let bounded = owned.capacity() <= owned.len().saturating_mul(2);
        let chunk = Bytes::from(owned);
        if bounded {
            Some(chunk)
        } else {
            self.chunk = chunk;
            None
        }
    }

    fn flatten_staged(&mut self) {
        if let Some(staged) = self.staged.take() {
            // Reserve only the data that has actually arrived, never the
            // length claimed by the peer.
            self.carry.reserve(staged.observed);
            for part in staged.parts {
                crate::copy_counts::note_carry(part.len());
                self.carry.extend_from_slice(&part);
            }
        }
    }

    fn next_staged_frame(&mut self) -> Result<Option<Frame>, Status> {
        let Some(staged) = self.staged.as_mut() else {
            return Ok(None);
        };
        let needed = staged.total - staged.observed;
        if self.chunk.len() >= needed {
            let Some(staged) = self.staged.take() else {
                return Ok(None);
            };
            // All bytes have arrived; one exact allocation and one copy per
            // part replace the incremental buffer's geometric growth.
            if !self.carry.try_reclaim(staged.total) {
                self.carry = BytesMut::with_capacity(staged.total);
            }
            for part in staged.parts {
                crate::copy_counts::note_carry(part.len());
                self.carry.extend_from_slice(&part);
            }
            self.copy_chunk_prefix(needed);
            // The header was validated before staging, and the accumulated
            // bytes now contain exactly one complete frame.
            return codec::pop_limited(&mut self.carry, self.limits);
        }
        if self.chunk.is_empty() {
            return Ok(None);
        }
        if self.chunk.len() < STAGE_MIN_CHUNK || staged.parts.len() == STAGE_MAX_CHUNKS {
            self.flatten_staged();
            return Ok(None);
        }
        let chunk_len = self.chunk.len();
        if let Some(part) = self.take_bounded_chunk() {
            let Some(staged) = self.staged.as_mut() else {
                return Ok(None);
            };
            staged.observed += chunk_len;
            staged.parts.push(part);
        } else {
            self.flatten_staged();
        }
        Ok(None)
    }

    fn copy_chunk_prefix(&mut self, needed: usize) {
        let count = needed.min(self.chunk.len());
        if count != 0 {
            crate::copy_counts::note_carry(count);
            self.carry
                .extend_from_slice(self.chunk.get(..count).unwrap_or_default());
            self.chunk.advance(count);
        }
    }

    /// A stream that ended mid-frame is a protocol violation, not an
    /// empty message.
    pub(crate) fn finish(&self) -> Result<(), Status> {
        if self.chunk.is_empty() && self.carry.is_empty() && self.staged.is_none() {
            Ok(())
        } else {
            Err(Status::internal("truncated gRPC frame"))
        }
    }
}


#[cfg(alloc_track)]
mod allocation {
    use super::*;
    use std::alloc::{GlobalAlloc, Layout, System};
    pub struct Count;
    static ON:AtomicBool=AtomicBool::new(false);
    static NUM:AtomicU64=AtomicU64::new(0);
    static REQUESTED:AtomicU64=AtomicU64::new(0);
    static LIVE:AtomicI64=AtomicI64::new(0);
    static PEAK:AtomicI64=AtomicI64::new(0);
    fn add(n:i64) { let live=LIVE.fetch_add(n,Ordering::Relaxed)+n; PEAK.fetch_max(live,Ordering::Relaxed); }
    unsafe impl GlobalAlloc for Count {
        unsafe fn alloc(&self,l:Layout)->*mut u8 { let p=unsafe{System.alloc(l)}; if !p.is_null() && ON.load(Ordering::Relaxed) { NUM.fetch_add(1,Ordering::Relaxed);REQUESTED.fetch_add(l.size() as u64,Ordering::Relaxed);add(l.size() as i64); } p }
        unsafe fn dealloc(&self,p:*mut u8,l:Layout) { if ON.load(Ordering::Relaxed) { add(-(l.size() as i64)); } unsafe{System.dealloc(p,l)} }
        unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 { let q=unsafe{System.realloc(p,l,n)};if !q.is_null() && ON.load(Ordering::Relaxed) { NUM.fetch_add(1,Ordering::Relaxed);REQUESTED.fetch_add(n as u64,Ordering::Relaxed);add(n as i64-l.size() as i64); } q }
    }
    pub fn start() { NUM.store(0,Ordering::Relaxed); REQUESTED.store(0,Ordering::Relaxed); LIVE.store(0,Ordering::Relaxed);PEAK.store(0,Ordering::Relaxed);ON.store(true,Ordering::SeqCst); }
    pub fn stop()->(u64,u64,i64) { ON.store(false,Ordering::SeqCst);(NUM.load(Ordering::Relaxed), REQUESTED.load(Ordering::Relaxed), PEAK.load(Ordering::Relaxed)) }
}
#[cfg(alloc_track)] #[global_allocator] static A:allocation::Count=allocation::Count;
fn run(wire:&[u8], pattern:&[usize], validate:bool)->u8 {
    let mut reader=FrameReader::new(MessageLimits);
    let mut off=0; let mut index=0; let mut result=None;
    while off<wire.len() {
        let len=pattern[index.min(pattern.len()-1)].min(wire.len()-off);
        let mut part=BytesMut::with_capacity(len+9);
        part.extend_from_slice(&[0;9]);part.extend_from_slice(&wire[off..off+len]);part.advance(9);
        reader.push(part.freeze());
        if let Some(frame)=reader.next_frame().unwrap() { assert!(result.is_none()); result=Some(frame); }
        off+=len;index+=1;
    }
    let frame=result.expect("complete");assert!(!frame.compressed);assert_eq!(frame.payload.len(),wire.len()-5);
    if validate { assert_eq!(frame.payload.as_ref(),&wire[5..]); }
    reader.finish().unwrap();
    black_box(frame.payload[0])
}
#[repr(C)] struct Timespec { seconds:i64, nanos:i64 }
unsafe extern "C" { fn clock_gettime(clockid:i32, result:*mut Timespec)->i32; }
fn thread_cpu_ns()->u128 { let mut t=Timespec{seconds:0,nanos:0}; assert_eq!(unsafe { clock_gettime(3,&mut t) },0); t.seconds as u128*1_000_000_000+t.nanos as u128 }
fn main() {
    let args:Vec<_>=std::env::args().collect();
    let size:usize=args[1].parse().unwrap();let shape=&args[2];let iterations:usize=args[3].parse().unwrap();
    let pattern:Vec<usize>=match shape.as_str() { "16k"=>vec![16384], "64k"=>vec![65536], "request"=>vec![17,65518,131070], "response"=>vec![13,65522,65535], _=>panic!("shape") };
    let mut wire=Vec::with_capacity(size+5);wire.push(0);wire.extend_from_slice(&(size as u32).to_be_bytes());wire.extend((0..size).map(|i|(i%251) as u8));
    run(&wire,&pattern,true);
    #[cfg(alloc_track)] allocation::start();
    let cpu_start=thread_cpu_ns();let start=Instant::now();let mut sum=0u8;
    for _ in 0..iterations {sum^=run(black_box(&wire),black_box(&pattern),false);}
    let elapsed=start.elapsed(); let cpu=thread_cpu_ns()-cpu_start;
    #[cfg(alloc_track)] let counts=allocation::stop();
    #[cfg(alloc_track)] println!("size={size} shape={shape} iterations={iterations} elapsed_ns={} cpu_ns={cpu} allocs={} requested={} peak_live={} witness={sum}", elapsed.as_nanos(),counts.0,counts.1,counts.2);
    #[cfg(not(alloc_track))] println!("size={size} shape={shape} iterations={iterations} elapsed_ns={} cpu_ns={cpu} witness={sum}",elapsed.as_nanos());
}
