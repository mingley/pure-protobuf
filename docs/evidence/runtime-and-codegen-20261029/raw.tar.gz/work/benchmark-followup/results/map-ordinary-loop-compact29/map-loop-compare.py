"""Additional ordinary for-loop, surviving-first and cold-construction holdouts."""
from pathlib import Path
import sys
base=Path(__file__).resolve().parents[1]/'all-benchmarks/measurement';sys.path.insert(0,str(base))
import codec_compare
codec_compare.CASES={f'map_{n}_{mode}':max(2500,500_000//n) for n in (4,16,64,256) for mode in ('distinct','duplicate','firstsurvives')}
codec_compare.OPS=('iter_all','iter_first','cold_read')
codec_compare.SCHEMA='pbrs.typed-map-ordinary-loop-cold-comparison.v1'
codec_compare.FIXTURE_SCOPE='Typed i32/i32 maps, with ordinary for/next iteration. Duplicate fixtures include both shadowed and surviving first entry; full last-wins values, pbrs entry order and truthful size hints are checked. Cold-read builds the map from an entry list, iterates it and drops it within timing; this is not protobuf parsing.'
codec_compare.CPU_SCOPE='CLOCK_PROCESS_CPUTIME_ID; ordinary loop/first entry on a warmed map, or build/read/drop for cold_read; counters absent'
codec_compare.LIMITS=['Shared x86_64 VM; no dedicated-host qualification.','The prost-labelled control is std::collections::HashMap, not Prost decoding.','First-entry order need not agree across representations; complete values and pbrs last-occurrence order are checked.','Cold construction starts from an entry list; it is not a parse/read/drop result.','Separate allocation captures count requests, not RSS or retained memory.']
codec_compare.main()
