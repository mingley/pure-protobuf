"""Source-pinned, resumable validation; each attempt keeps its own log.

Usage: driver.py essential|full <full-commit-sha>
Run essential once on the selected commit; full resumes its successful gates.
"""
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
from pathlib import Path

root = Path(__file__).resolve().parents[2]
out = root / "work/round29-validation/results"
phase, expected = sys.argv[1:]
assert phase in ("essential", "full") and re.fullmatch(r"[0-9a-f]{40}", expected)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


paths = ["src", "pbrs-grpc", "protobuf-tonic", "rpc-bench", "tests", "scripts", "Cargo.toml", "Cargo.lock", "build.rs", "proto", "examples", ".cargo", ".github"]


def hashes(markdown=False):
    args = ["*.md"] if markdown else paths
    names = subprocess.check_output(["git", "ls-files", "-z", "--", *args], cwd=root).split(b"\0")
    result = {}
    for raw in names:
        if not raw:
            continue
        name = os.fsdecode(raw)
        if markdown != name.endswith(".md"):
            continue
        path = root / name
        if not path.is_file():
            raise SystemExit(f"tracked input missing: {name}")
        result[name] = hashlib.sha256(path.read_bytes()).hexdigest()
    return result


def verify(expected_hashes):
    if git("rev-parse", "HEAD") != expected or hashes() != expected_hashes:
        raise SystemExit("HEAD or tracked code/test inputs changed")
    extra = [p for p in git("ls-files", "--others", "--exclude-standard", "--", *paths).splitlines() if not p.endswith(".md")]
    if extra:
        raise SystemExit(f"untracked code/test inputs: {extra}")


before = hashes()
verify(before)
dirty = [p for p in git("diff", "HEAD", "--name-only", "--", *paths).splitlines() if not p.endswith(".md")]
if dirty:
    raise SystemExit(f"code/test inputs must be committed: {dirty}")
if phase == "essential" and not out.exists():
    out.mkdir(exist_ok=False)
    prior = "9287d474d3062911af3e9a65612a9d986d9be530"
    report = {"source": expected, "input_sha256": before, "prior_source": prior,
              "changed_since_prior": git("diff", "--name-only", prior, expected, "--", *paths).splitlines(),
              "checks": [], "complete": False, "essential_complete": False,
              "minimum_free_bytes": 768 * 1024 * 1024}
else:
    report = json.loads((out / "results.json").read_text())
    assert report["source"] == expected and report["input_sha256"] == before
    assert report["essential_complete"] if phase == "full" else not report["essential_complete"]

commands = [
    ("format", ["cargo", "fmt", "--all", "--check"], 0),
    ("wire-units", ["cargo", "test", "--locked", "-p", "pbrs", "--lib", "wire::tests"], 0),
    ("map-views", ["cargo", "test", "--locked", "-p", "pbrs", "--all-features", "--test", "map_views"], 0),
    ("shared-descriptors", ["cargo", "test", "--locked", "-p", "pbrs", "--test", "codegen_shared_descriptors"], 0),
    ("plugin", ["cargo", "test", "--locked", "-p", "pbrs", "--test", "plugin"], 0),
]
if "tests/proof/repeated_tag/Cargo.toml" in before:
    commands += [
        ("repeated-tag-execute", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/repeated_tag/Cargo.toml"], 0),
        ("repeated-tag-clippy", ["cargo", "clippy", "--locked", "--manifest-path", "tests/proof/repeated_tag/Cargo.toml", "--all-targets", "--", "-D", "warnings"], 0),
    ]
commands += [
    ("workspace", ["cargo", "test", "--locked", "--workspace", "--all-features"], 0),
    ("core-clippy", ["cargo", "clippy", "--locked", "-p", "pbrs", "--all-targets", "--all-features", "--", "-D", "warnings"], 0),
    ("transport-clippy", ["cargo", "clippy", "--locked", "--lib", "--all-features", "-p", "pbrs-grpc", "-p", "protobuf-tonic", "-p", "pbrs-grpc-example-greeter", "--", "-D", "warnings"], 0),
    ("owned-consumer", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/owned_messages/Cargo.toml"], 0),
    ("validated-lazy", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/validated_lazy/Cargo.toml"], 0),
    ("validated-lazy-clippy", ["cargo", "clippy", "--locked", "--manifest-path", "tests/proof/validated_lazy/Cargo.toml", "--", "-D", "warnings"], 0),
    ("owned-clippy", ["cargo", "clippy", "--locked", "--manifest-path", "tests/proof/owned_messages/Cargo.toml", "--", "-D", "warnings"], 0),
    ("message-presence", ["cargo", "test", "--locked", "--manifest-path", "tests/proof/tonic_parity/Cargo.toml", "--", "--nocapture"], 0),
    ("mixed-peers", ["cargo", "test", "--locked", "--manifest-path", "tests/interop/tonic/Cargo.toml", "--tests"], 0),
    ("prost-known", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml", "--", "--check-known-differences"], 0),
    ("prost-strict", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml"], 1),
    ("prost-tests", ["cargo", "test", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml"], 0),
    ("prost-owned-known", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml", "--features", "owned-messages", "--", "--check-known-differences"], 0),
    ("prost-owned-strict", ["cargo", "run", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml", "--features", "owned-messages"], 1),
    ("prost-owned-tests", ["cargo", "test", "--locked", "--manifest-path", "tests/proof/prost_parity/Cargo.toml", "--features", "owned-messages"], 0),
    ("codegen-proof", ["python3", "tests/proof/codegen_parity/run.py", "--output", str(out / "codegen")], 0),
    ("claim-checker", ["python3", "-B", "-m", "unittest", "tests.test_performance_claim", "-q"], 0),
    ("msrv-wire", ["cargo", "+1.85.0", "test", "--locked", "-p", "pbrs", "--lib", "wire::tests"], 0),
    ("msrv-native", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs-grpc", "--lib"], 0),
    ("msrv-tower", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs-grpc", "--features", "tower", "--lib"], 0),
    ("msrv-owned", ["cargo", "+1.85.0", "check", "--locked", "--manifest-path", "tests/proof/owned_messages/Cargo.toml"], 0),
    ("msrv-validated-lazy", ["cargo", "+1.85.0", "check", "--locked", "--manifest-path", "tests/proof/validated_lazy/Cargo.toml"], 0),
    ("conformance", ["./scripts/conformance.sh"], 0),
    ("pinned-descriptors", ["cargo", "test", "--locked", "-p", "pbrs", "--test", "onboarding", "adapter_descriptor_sets_match_pinned_protoc_and_generated_output", "--", "--exact", "--ignored"], 0),
    ("regenerate", ["./scripts/regen-generated.sh", "--check"], 0),
    ("docs", ["cargo", "test", "--locked", "--test", "documentation", "--", "--nocapture"], 0),
]


def save():
    (out / "results.json").write_text(json.dumps(report, indent=2) + "\n")


completed = {c["name"] for c in report["checks"] if c.get("passed")}
for name, cmd, expected_exit in commands:
    if name in completed:
        continue
    if phase == "essential" and name == "workspace":
        report["essential_complete"] = True
        save()
        print(json.dumps({"essential_complete": True, "source": expected}), flush=True)
        raise SystemExit(0)
    verify(before)
    env = dict(os.environ)
    if name.startswith("msrv-"):
        env.update(CARGO_TARGET_DIR=str(root / "work/msrv-target"), CARGO_BUILD_JOBS="1")
    docs_before = hashes(markdown=True) if name == "docs" else None
    free_before = shutil.disk_usage(root).free
    if free_before < report["minimum_free_bytes"]:
        save()
        raise SystemExit(f"not enough free disk before {name}: {free_before}")
    attempt = 1 + sum(c["name"] == name for c in report["checks"])
    log_name = f"{name}-{attempt}.log"
    if name == "conformance":
        env.update(CONFORMANCE_OUTPUT_DIR=str(out / f"conformance-{attempt}"), NPROC="2")
    if name == "codegen-proof":
        cmd = [*cmd[:-1], str(out / f"codegen-{attempt}")]
    start = time.monotonic()
    disk_abort = False
    with (out / log_name).open("w") as log:
        proc = subprocess.Popen(cmd, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        while True:
            try:
                code = proc.wait(timeout=5)
                break
            except subprocess.TimeoutExpired:
                if shutil.disk_usage(root).free < report["minimum_free_bytes"]:
                    disk_abort = True
                    os.killpg(proc.pid, signal.SIGTERM)
                    try:
                        code = proc.wait(timeout=10)
                    except subprocess.TimeoutExpired:
                        os.killpg(proc.pid, signal.SIGKILL)
                        code = proc.wait()
                    break
    row = {"name": name, "command": cmd, "source": expected, "exit_code": code,
           "expected_exit": expected_exit, "seconds": time.monotonic() - start,
           "log": log_name, "free_before": free_before, "free_after": shutil.disk_usage(root).free,
           "disk_abort": disk_abort, "passed": not disk_abort and code == expected_exit}
    if name == "conformance":
        row["output_dir"] = f"conformance-{attempt}"
    if row["passed"] and name.endswith("strict"):
        try:
            summary = json.loads(next(line for line in reversed((out / log_name).read_text().splitlines()) if line.startswith("{")))
            row["passed"] = summary["known_differences_match"] is True and summary["parity_equivalent"] is False
            row["known_differences_match"] = summary["known_differences_match"]
            row["parity_equivalent"] = summary["parity_equivalent"]
        except (StopIteration, KeyError, ValueError):
            row["passed"] = False
    if name == "docs":
        row["markdown_sha256"] = docs_before
        row["passed"] = row["passed"] and docs_before == hashes(markdown=True)
    report["checks"].append(row)
    save()
    print(json.dumps(row if name != "docs" else {k: v for k, v in row.items() if k != "markdown_sha256"}), flush=True)
    if not row["passed"]:
        print((out / log_name).read_text()[-15000:], flush=True)
        raise SystemExit(1)
    verify(before)

report.update(complete=True, inputs_unchanged=True)
workspace = next(c for c in reversed(report["checks"]) if c["name"] == "workspace" and c["passed"])
workspace_log = (out / workspace["log"]).read_text()
counts = [tuple(map(int, m)) for m in re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", workspace_log)]
if not counts:
    raise SystemExit("workspace test summaries missing")
report["workspace_test_counts"] = dict(zip(["passed", "failed", "ignored"], map(sum, zip(*counts))))
conformance = next(c for c in reversed(report["checks"]) if c["name"] == "conformance" and c["passed"])
report["conformance_summary"] = json.loads((out / conformance["output_dir"] / "summary.json").read_text())
assert report["conformance_summary"]["overall_passed"] is True
save()
