"""Build the compact round29 source, measurement, and validation capsule after selection."""
from pathlib import Path
import argparse,csv,hashlib,io,json,os,shutil,subprocess,tarfile,tempfile
from indexes import build_indexes
r=Path.cwd();m=r/'work/all-benchmarks/measurement';w=r/'work/bench-round-20261029';p=argparse.ArgumentParser();p.add_argument('--selected-label',required=True);p.add_argument('--validation',type=Path,required=True);p.add_argument('--draft',action='store_true');p.add_argument('--output',type=Path,default=r/'docs/evidence/runtime-and-codegen-20261029');a=p.parse_args();a.validation=a.validation.resolve(strict=True);out=a.output.resolve();sha=lambda x:hashlib.sha256(x).hexdigest();read=lambda p:json.loads(p.read_text());head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();validation=read(a.validation);assert validation['source']==head;assert validation['complete'] or (a.draft and out.is_relative_to(r/'work'));old=read(m/'round-selected-source-source.json');eq=read(w/'baseline-equivalence.json');assert eq['head']=='9287d474d3062911af3e9a65612a9d986d9be530';baseline=old['files'];assert len(baseline)==602
files={};overlays={};sources={};labels=['round29-descriptor-literal','round29-packed-map','round29-compact-map','round29-varint-shell','round29-repeated-tag','round29-repeated-reserve','round29-staged-frame'];
if a.selected_label!='round-selected' and a.selected_label not in labels:labels.append(a.selected_label)
for label in labels:
 p=m/(label+'-source-source.json');assert p.exists(),p;d=read(p);parent=d.get('baseline_label','round-selected');source=Path(d['source']);assert all(sha((source/n).read_bytes())==v for n,v in d['files'].items());sources[label]={'parent':parent,'files':d['files'],'changes':d['declared_changes']}
 for n,v in d['declared_changes'].items():
  raw=(source/n).read_bytes();assert sha(raw)==v['after'];files['source/overlays/'+label+'/'+n]=raw
with tempfile.TemporaryDirectory(prefix='round29-git-') as t:
 data=subprocess.check_output(['git','archive',eq['head'],*sorted(baseline)]);tarfile.open(fileobj=io.BytesIO(data)).extractall(t,filter='data');tree=Path(t);diff=[n for n,v in baseline.items() if sha((tree/n).read_bytes())!=v];assert diff==['tests/map_views.rs'],diff
 for n in diff:files['source/baseline-overlays/'+n]=(m/'round-selected-source'/n).read_bytes();assert sha(files['source/baseline-overlays/'+n])==baseline[n]
 # Final commit must match every measured shipping/build input; test-only changes are disclosed.
 selected=baseline if a.selected_label=='round-selected' else sources[a.selected_label]['files'];data=subprocess.check_output(['git','archive',head,*sorted(selected)]);final=Path(t)/'final';final.mkdir();tarfile.open(fileobj=io.BytesIO(data)).extractall(final,filter='data');mismatches={n:{'measured':v,'committed':sha((final/n).read_bytes())} for n,v in selected.items() if sha((final/n).read_bytes())!=v};assert all(n.startswith(('tests/','pbrs-grpc/tests/')) and not n.startswith('tests/proof/codec_benchmark/') for n in mismatches),mismatches
manifest={'schema':'pbrs.round29.source-manifest.v1','baseline_commit':eq['head'],'prior_measured_source_commit':eq['benchmark_source_commit'],'baseline_files':baseline,'baseline_overlays':diff,'variants':sources,'selected':a.selected_label,'selected_commit':head,'test_only_commit_differences':mismatches,'note':'Source scopes exclude arbitrary repository files outside the 602-file benchmark snapshot. Baseline test overlay reproduces the previous measured export; all shipping inputs match 9287.'};files['source/manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode();files['source/reconstruct.py']=(w/'reconstruct.py').read_bytes();files['source/reproduce.md']=b'# Reconstruct a source\n\nAfter extracting raw.tar.gz, run `python3 source/reconstruct.py /path/to/repo /tmp/round29-source VARIANT`. Choose VARIANT from source/manifest.json. This exports baseline 9287, restores the recorded test-only baseline overlay, applies candidate overlays, and verifies every hash. Compiler/toolchain installations, binaries and build caches are excluded. Consult build and measurement logs for flags and workloads.\n'
exts={'.json','.jsonl','.log','.stdout','.stderr','.rs','.proto','.toml','.lock','.py','.sh','.md','.asm','.patch','.diff','.txt','.csv','.sha256'}
def add(path):
 if not path.exists():return
 iterator=[path] if path.is_file() else (f for f in path.rglob('*') if f.is_file())
 for f in iterator:
  if f.is_symlink() or (f.suffix not in exts and f.name!='SHA256SUMS') or any(x in ('target','.git','__pycache__','representative-generated','outputs','sdk-source','sdk-target','generator-target','package-draft') for x in f.parts):continue
  if 'consumer-proof' in f.parts and 'candidate' in f.parts:continue
  if 'combined-generator-comparison' in f.parts and any(x in ('small','100','1000') for x in f.parts):continue
  raw=f.read_bytes()
  if not raw.startswith(b'\x7fELF'):files[str(f.relative_to(r))]=raw
add(w)
for p in sorted(m.glob('round29-*')):
 if p.is_dir() and p.name.endswith('-source'):continue
 add(p)
for n in ['codec_compare.py','map_compare.py','partial_compare.py','encode_compare.py','measure_phase2.py','build_probe.py','codegen_compare_blocking.py']:add(m/n)
for n in ['map-ordinary-loop-packed29','map-ordinary-loop-compact29']:
 add(r/'work/benchmark-followup/results'/n)
for n in ['map-packed-rejected.patch','map-packed-clippy.log','repeated-tag-proof.log','receive-stage-dispatch-probe.log','round29-docs-draft.md']:add(r/'work'/n)
for n in ['map-compact-20261029','receive-microprobe','repeated-reserve-20261029']:
 d=r/'work'/n
 if d.exists():
  for f in d.iterdir():
   if f.is_file():add(f)
owned=r/'work/round29-owned-conformance'
if owned.exists():
 add(owned/'capsule');add(owned/'source-selection-equivalence.json')
add(r/'tests/proof/repeated_tag');add(r/'work/round29-sdk-regen');add(r/'work/round29-validation');add(r/'work/benchmark-followup/preflight-integrated.json');add(r/'work/benchmark-followup/preflight-integrated.json');add(r/'work/all-benchmarks/codegen/build_round29_driver.py');add(a.validation.parent)
# The previous capsule contains the baseline binaries' full records and host details.
for n in ['round-selected-source-source.json','round-selected-map/source.json','round-selected-lazy/source.json','round-selected-owned/source.json'] :add(m/n)
add(r/'work/benchmark-followup/selected-binary-audit.json');add(r/'work/benchmark-followup/codegen-selected-release/source.json')
summaries={}
for p in sorted(m.glob('round29-*-comparison/summary.json')):summaries[str(p.relative_to(r))]=read(p)
for p in [w/'varint-results/summary.json',w/'codegen-descriptor-results/summary.json',w/'consumer-proof/consumer-measurements.json',w/'repeated-lazy-results/summary.json',w/'repeated-owned-results/summary.json',w/'varint-codec-nolto-results/summary.json',w/'integrated-codec-nolto-results/summary.json',w/'integrated-repeated-lazy-results/summary.json',w/'integrated-repeated-owned-results/summary.json',w/'integrated-codegen-results/summary.json',w/'consumer-proof/consumer-combined-check.json',r/'work/benchmark-followup/results/map-ordinary-loop-packed29/summary.json',r/'work/benchmark-followup/results/map-ordinary-loop-compact29/summary.json',r/'work/receive-microprobe/results.json',r/'work/round29-owned-conformance/capsule/passes/summary.json',r/'work/round29-owned-conformance/capsule/report.json']:
 if p.exists():summaries[str(p.relative_to(r))]=read(p)
companions=build_indexes(summaries)
result={'schema':'pbrs.round29.results.v1','draft':a.draft,'baseline_commit':eq['head'],'selected_commit':head,'selected_source':a.selected_label,'test_only_commit_differences':mismatches,'validation':validation,'source_manifest':manifest,'summaries':summaries,'world_ranking_established':False,'full_parity_established':False};out.mkdir(parents=True,exist_ok=True)
for name,data in companions.items():(out/name).write_bytes(data)
with tarfile.open(out/'raw.tar.gz','w:gz',compresslevel=6) as tar:
 for name,raw in sorted(files.items()):
  i=tarfile.TarInfo(name);i.size=len(raw);i.mode=0o644;i.mtime=0;tar.addfile(i,io.BytesIO(raw))
with tempfile.TemporaryDirectory(prefix='round29-proof-') as t:
 d=Path(t)
 with tarfile.open(out/'raw.tar.gz') as tar:
  for member in tar:
   if member.name.startswith(('source/','work/round29-owned-conformance/capsule/')):
    assert member.isfile() and '..' not in Path(member.name).parts;tar.extract(member,d,filter='data')
 proof=[]
 for label in ['round-selected',*sources]:
  target=d/('tree-'+label);proc=subprocess.run(['python3',str(d/'source/reconstruct.py'),str(r),str(target),label],text=True,capture_output=True);assert proc.returncode==0,(label,proc.stderr);proof.append(json.loads(proc.stdout));shutil.rmtree(target)
 result['reconstruction']={'complete':True,'variants':proof}
 owned_dir=d/'work/round29-owned-conformance/capsule'
 if owned_dir.exists():
  checks=subprocess.run(['sha256sum','-c','SHA256SUMS'],cwd=owned_dir,text=True,capture_output=True);assert checks.returncode==0,checks.stderr
  owned_tree=d/'owned-reconstructed';owned_proof=subprocess.run(['python3',str(owned_dir/'reconstruct.py'),str(r),str(owned_tree)],text=True,capture_output=True);assert owned_proof.returncode==0,owned_proof.stderr
  result['owned_conformance_reconstruction']={'complete':True,'checksum_inventory_sha256':sha((owned_dir/'SHA256SUMS').read_bytes()),'output':owned_proof.stdout};shutil.rmtree(owned_tree)
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n');catalog={'schema':'pbrs.evidence-manifest.v1','archive_sha256':sha((out/'raw.tar.gz').read_bytes()),'results_sha256':sha((out/'results.json').read_bytes()),'companion_files':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in companions.items()},'files':{n:{'bytes':len(v),'sha256':sha(v)} for n,v in sorted(files.items())}};(out/'manifest.json').write_text(json.dumps(catalog,indent=2)+'\n');shutil.copyfile(r/'docs/evidence/optimizations-20261028/check.py',out/'check.py');print(json.dumps({'files':len(files),'archive_bytes':(out/'raw.tar.gz').stat().st_size,'summaries':len(summaries),'variants':len(proof)}))
