#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
check() { python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'; }
source=work/all-benchmarks/measurement/round29-integrated-source
touch "$source/src/lib.rs" "$source/src/codegen/descriptors.rs" "$source/src/codegen/reflection.rs" "$source/src/codegen/parse.rs" "$source/src/wire.rs" "$source/tests/proof/codec_benchmark/src/main.rs"
for profile in lazy owned; do
 for mode in shipping allocations; do
  check;extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
  python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "$source/tests/proof/codec_benchmark/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/round29-integrated-$profile" --record-key "codec-$mode" "${extra[@]}"
 done
done
check
python3 work/all-benchmarks/measurement/prepare_holdouts.py "$source" round29-integrated
for kind in partial encode; do
 for profile in lazy owned; do
  for mode in shipping allocations; do
   check;extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
   binary=pbrs-encode-proof;if [ "$kind" = partial ]; then binary=pbrs-partial-getter-proof; fi
   touch "work/all-benchmarks/measurement/round29-integrated-$kind-harness/src/main.rs"
   python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "work/all-benchmarks/measurement/round29-integrated-$kind-harness/Cargo.toml" --binary-name "$binary" --mode "$mode" --output "work/all-benchmarks/measurement/round29-integrated-$kind-$profile" --record-key "codec-$mode" "${extra[@]}"
  done
 done
done
python3 work/bench-round-20261029/prepare-nolto.py round29-integrated "$source"
for mode in shipping allocations; do
 check;h=work/all-benchmarks/measurement/round29-integrated-nolto-harness;touch "$h/src/main.rs" "$h/build.rs"
 PBRS_BENCHMARK_ROOT="/workspace/pure-protobuf/$source" python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "$h/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output work/all-benchmarks/measurement/round29-integrated-codec-nolto --record-key "codec-$mode"
done
python3 - <<'PY'
from pathlib import Path
import shutil
m=Path('work/all-benchmarks/measurement').resolve();before=m/'round29-repeated-before-harness';p=m/'round29-repeated-integrated-harness';assert not p.exists();shutil.copytree(before,p);manifest=p/'Cargo.toml';s=manifest.read_text();src=str(m/'round-selected-source');assert s.count(src)==2;manifest.write_text(s.replace(src,str(m/'round29-integrated-source')))
PY
for profile in lazy owned; do
 for mode in shipping allocations; do
  check;extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
  touch work/all-benchmarks/measurement/round29-repeated-integrated-harness/src/main.rs work/all-benchmarks/measurement/round29-repeated-integrated-harness/build.rs
  python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest work/all-benchmarks/measurement/round29-repeated-integrated-harness/Cargo.toml --binary-name pbrs-round29-repeated-probe --mode "$mode" --output "work/all-benchmarks/measurement/round29-repeated-integrated-$profile" --record-key "codec-$mode" "${extra[@]}"
 done
done
check
python3 work/all-benchmarks/codegen/build_final_driver.py --source "$source" --peer pbrs --profile release --output work/bench-round-20261029/codegen-integrated-release
printf '%s\n' 'Integrated full codec, repeated, non-LTO and generator probes built; no timed work performed.'
