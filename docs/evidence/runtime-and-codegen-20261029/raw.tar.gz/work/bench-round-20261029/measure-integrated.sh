#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
w=work/bench-round-20261029
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
python3 "$w/preflight-integrated.py" > "$w/preflight-integrated.log" 2>&1
for kind in codec partial encode; do
 for profile in lazy owned; do
  python3 "$m/measure_phase2.py" "$kind" --storage "$profile" --candidate round29-integrated > "$w/integrated-$kind-$profile.log" 2>&1
 done
done
python3 "$m/codec_compare.py" --before-shipping "$m/round29-varint-before-codec-nolto/codec-shipping" --before-allocations "$m/round29-varint-before-codec-nolto/codec-allocations" --before-record "$m/round29-varint-before-codec-nolto/source.json" --after-shipping "$m/round29-integrated-codec-nolto/codec-shipping" --after-allocations "$m/round29-integrated-codec-nolto/codec-allocations" --after-record "$m/round29-integrated-codec-nolto/source.json" --storage lazy --output "$w/integrated-codec-nolto-results" > "$w/integrated-codec-nolto.log" 2>&1
for profile in lazy owned; do
 python3 "$w/measure-repeated.py" --before-shipping "$m/round29-repeated-before-$profile/codec-shipping" --before-allocations "$m/round29-repeated-before-$profile/codec-allocations" --before-record "$m/round29-repeated-before-$profile/source.json" --after-shipping "$m/round29-repeated-integrated-$profile/codec-shipping" --after-allocations "$m/round29-repeated-integrated-$profile/codec-allocations" --after-record "$m/round29-repeated-integrated-$profile/source.json" --storage "$profile" --output "$w/integrated-repeated-$profile-results" > "$w/integrated-repeated-$profile.log" 2>&1
done
for part in 1 2 3 4 5; do
 resume=();if [ "$part" -gt 1 ];then resume=(--resume);fi
 python3 "$m/codegen_compare_blocking.py" --baseline work/benchmark-followup/codegen-selected-release/driver --candidate "$w/codegen-integrated-release/driver" --prost work/all-benchmarks/codegen/final-prost-release/driver --profile release --output "$w/integrated-codegen-results" --capture-limit 12 "${resume[@]}" > "$w/integrated-codegen-$part.log" 2>&1
done
printf '%s\n' 'Integrated codec, partial, encode, non-LTO, repeated and generator comparisons completed.'
