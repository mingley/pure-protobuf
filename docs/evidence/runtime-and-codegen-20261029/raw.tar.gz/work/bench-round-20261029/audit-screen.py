"""Reject stale/wrong-harness artifacts before any round29 measurement."""
from pathlib import Path
import hashlib,json
r=Path.cwd();m=r/'work/all-benchmarks/measurement';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();rows=[]
groups=[('round29-packed-loop',('shipping','allocations')),('round29-packed-map-map',('shipping','allocations')),('round29-packed-map-lazy',('shipping','allocations')),('round29-packed-map-owned',('shipping','allocations'))]
groups += [(f'round29-varint-{s}-{p}',('shipping',)) for s in ('before','after') for p in ('thin','nolto')]
for name,modes in groups:
 d=m/name;a=json.loads((d/'source.json').read_text())
 for mode in modes:
  k='codec-'+mode;b=d/k;v=a['binaries'][k];j=json.loads((d/v['build_record']).read_text());assert sha(b)==v['sha256']==j['binary_sha256'];assert j['source_unchanged'] and j['harness_unchanged'] and j['exit_code']==0
  artifacts=[json.loads(x) for x in (d/(k+'.jsonl')).read_text().splitlines()];match=[x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('executable')==j['build_executable']];assert len(match)==1 and match[0]['fresh'] is False and match[0]['profile']['opt_level']=='3',(name,mode,'stale');assert ('allocations' in j['features'])==(mode=='allocations');rows.append({'group':name,'mode':mode,'sha256':sha(b),'harness':j['harness_files'].get('src/main.rs'),'features':j['features']})
by={}
for x in rows:by.setdefault(x['sha256'],set()).add(x['harness'])
assert all(len(s)==1 for s in by.values()),'cross-harness executable collision'
for profile in ('thin','nolto'):
 a=json.loads((m/f'round29-varint-before-{profile}/codec-shipping-build.json').read_text());b=json.loads((m/f'round29-varint-after-{profile}/codec-shipping-build.json').read_text());assert a['cargo_lock_sha256']==b['cargo_lock_sha256'] and a['harness_files']['src/main.rs']==b['harness_files']['src/main.rs']
p=r/'work/bench-round-20261029/codegen-descriptor-release';d=json.loads((p/'source.json').read_text());before=json.loads((r/'work/benchmark-followup/codegen-selected-release/source.json').read_text());assert sha(p/'driver')==d['executable_sha256'] and not d['cargo_artifact']['fresh'];assert d['lock_sha256']==before['lock_sha256'] and d['driver_source_sha256']==before['driver_source_sha256'];assert all(d['source_sha256'][n]==v for n,v in json.loads((m/'round29-descriptor-literal-source-source.json').read_text())['files'].items());rows.append({'group':'codegen-descriptor-release','sha256':sha(p/'driver'),'fresh':False})
for n in ('round29-packed-map','round29-varint-shell','round29-descriptor-literal'):
 d=json.loads((m/(n+'-source-source.json')).read_text());source=Path(d['source']);assert all(sha(source/k)==v for k,v in d['files'].items())
for n,count in [('varint-preflight.json',28),('preflight-packed-map.json',144)]:
 d=json.loads((r/'work/bench-round-20261029'/n).read_text());assert d['complete'] and d['captures']==count and d['timed_iterations']==0
report={'complete':True,'baseline_head':'9287d474d3062911af3e9a65612a9d986d9be530','artifacts':rows};(r/'work/bench-round-20261029/screen-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'complete':True,'artifacts':len(rows)}))
