import argparse, hashlib, importlib.util, json, os, random, re, shutil, subprocess, sys, time, threading
from pathlib import Path
root=Path('/workspace/pure-protobuf');proof=root/'work/bench-round-20261029/consumer-proof';target=proof/'target';manifest=json.loads((proof/'prepared-combined.json').read_text())
spec=importlib.util.spec_from_file_location('cg19',root/'work/all-benchmarks/measurement/canonical_codegen_blocking.py');cg=importlib.util.module_from_spec(spec);spec.loader.exec_module(cg)
p=argparse.ArgumentParser();p.add_argument('--cases',nargs='+',choices=cg.CORPORA,default=['small','100']);p.add_argument('--repeats',type=int,default=3);p.add_argument('--cpu',type=int,required=True);p.add_argument('--modes',nargs='+',choices=['check','release'],default=['check','release']);p.add_argument('--output',default='consumer-combined-check.json');p.add_argument('--resume',action='store_true');args=p.parse_args()
cargo=root/'work/cargo/bin/cargo';env={**os.environ,'CARGO_HOME':str(root/'work/cargo'),'RUSTUP_HOME':str(root/'work/rustup'),'PATH':str(root/'work/cargo/bin')+':'+os.environ['PATH'],'CARGO_TARGET_DIR':str(target),'CARGO_BUILD_JOBS':'1','CARGO_INCREMENTAL':'0','CARGO_PROFILE_DEV_DEBUG':'0'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[];rng=random.Random(20261029);plan=[]
for rep in range(args.repeats):
 for case in args.cases:
  for mode in args.modes:
   variants=['before','candidate','prost'];rng.shuffle(variants)
   plan.extend((rep,case,mode,variant) for variant in variants)
results=proof/args.output
if args.resume:
 data=json.loads(results.read_text());assert data['plan']==[list(entry) for entry in plan] and data['cpu']==args.cpu
 rows=data['rows'];data['state']='running'
else:
 assert not results.exists(),results
 data={'scope':'dependency-warm consumer only; cargo clean -p consumer between every build; generation and file copies excluded','cpu':args.cpu,'plan':plan,'rows':rows,'state':'running'}
def save():results.write_text(json.dumps(data,indent=2)+'\n')
def guard():
 if shutil.disk_usage(root).free<750*1024**2:raise RuntimeError('free disk below 750 MiB guard')
save()
try:
 for rep,case,mode,variant in plan[len(rows):]:
  guard();backend='prost' if variant=='prost' else 'pbrs';project=Path(manifest['projects'][backend]['path']);record=manifest['cases'][case][variant];source=Path(record['path']);generated=project/'generated'
  assert sha(project/'Cargo.toml')==manifest['projects'][backend]['manifest_sha256'] and sha(project/'Cargo.lock')==manifest['projects'][backend]['lock_sha256']
  for file,info in record['files'].items():assert sha(source/file)==info['sha256']
  shutil.rmtree(generated);shutil.copytree(source,generated)
  consumer=cg.render_consumer_prost(cg.CORPORA[case][0],0) if backend=='prost' else cg.render_consumer(cg.CORPORA[case][0],0)
  (project/'src/main.rs').write_text(consumer)
  clean=[str(cargo),'clean','--offline','--locked','--manifest-path',str(project/'Cargo.toml'),'-p','consumer']
  cleanresult=subprocess.run(clean,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True);assert cleanresult.returncode==0,cleanresult.stderr
  command=[str(cargo),('check' if mode=='check' else 'build'),'--offline','--locked','--manifest-path',str(project/'Cargo.toml')]
  if mode=='release':command.append('--release')
  log=proof/'logs-combined-check'/f'{rep}-{case}-{mode}-{variant}';log.mkdir(parents=True,exist_ok=True)
  full=['taskset','-c',str(args.cpu),*command]
  with (log/'stdout').open('wb') as out,(log/'stderr').open('wb') as err:
   begin=time.monotonic_ns();proc=subprocess.Popen(full,env=env,stdout=out,stderr=err)
   stop=threading.Event(); monitor_error=[]
   def monitor():
    while not stop.wait(.5):
     try:
      guard()
      if time.monotonic_ns()-begin>900*10**9:raise RuntimeError('timeout')
     except BaseException as error:
      monitor_error.append(error);proc.kill();return
   watcher=threading.Thread(target=monitor,daemon=True);watcher.start()
   try:
    proc.wait()
    elapsed=time.monotonic_ns()-begin
   finally:
    stop.set();watcher.join()
   if monitor_error:raise monitor_error[0]
  stderr=(log/'stderr').read_text();assert proc.returncode==0,stderr
  built=re.findall(r'^\s*(Checking|Compiling) ([^\s]+)',stderr,re.M)
  assert built==[(('Checking' if mode=='check' else 'Compiling'),'consumer')],f'unexpected work: {built}; {stderr}'
  binary=None
  if mode=='release':
   exe=target/'release/consumer';binary={'size':exe.stat().st_size,'sha256':sha(exe)}
   run=subprocess.run([str(exe)],capture_output=True,timeout=120);assert run.returncode==0 and run.stdout==b'0\n' and run.stderr==b'',(run.returncode,run.stdout,run.stderr)
  row={'repeat':rep,'case':case,'mode':mode,'variant':variant,'elapsed_ns':elapsed,'binary':binary,'clean_stderr':cleanresult.stderr,'command':full,'log':str(log)};rows.append(row);save();print(json.dumps(row),flush=True)
 data['state']='complete';save()
except BaseException as error:
 data['state']='failed';data['error']=repr(error);save();raise
