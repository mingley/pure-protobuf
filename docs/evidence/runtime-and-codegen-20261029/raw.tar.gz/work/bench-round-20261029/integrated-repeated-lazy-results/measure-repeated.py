"""Run repeated-tag workloads through the standard paired pbrs/Prost controller."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path('work/all-benchmarks/measurement').resolve()))
import codec_compare
codec_compare.CASES={'empty':100_000,'small':50_000,'strings_32':4_000,'strings_64':2_500,'strings_1024':120,'strings_suffix_64k':100,'numbers_64':2_500,'numbers_1024':120,'children_64':2_500,'children_1024':100,'bytes15_64':2_500,'bytes15_1024':120,'bytes16_64':2_500,'mixed_64':2_500,'group_64':2_500}
codec_compare.OPS=('parse_owned','roundtrip')
codec_compare.FIXTURE_SCOPE='Owned parse/drop and parse/serialize/drop, 1/32/64/1024 repeated values, mixed tags, field 15/16, group, and 64 KiB unrelated unknown suffix; semantic fixture equality checked before clocks.'
codec_compare.main()
