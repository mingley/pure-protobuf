#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
for side in before after; do
 source=work/all-benchmarks/measurement/round-selected-source
 if [ "$side" = after ]; then source=work/all-benchmarks/measurement/round29-repeated-tag-source; fi
 if [ "$side" = reserve ]; then source=work/all-benchmarks/measurement/round29-repeated-reserve-source; fi
 for profile in lazy owned; do
  for mode in shipping allocations; do
   python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'
   extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
   touch "work/all-benchmarks/measurement/round29-repeated-$side-harness/src/main.rs" "work/all-benchmarks/measurement/round29-repeated-$side-harness/build.rs"
   python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "work/all-benchmarks/measurement/round29-repeated-$side-harness/Cargo.toml" --binary-name pbrs-round29-repeated-probe --mode "$mode" --output "work/all-benchmarks/measurement/round29-repeated-$side-$profile" --record-key "codec-$mode" "${extra[@]}"
  done
 done
done
python3 work/bench-round-20261029/preflight-repeated.py
