#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
w=work/bench-round-20261029
for label in round29-varint-shell round29-repeated-tag; do
 for profile in lazy owned; do
  python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate "$label" > "$w/$label-codec-$profile.log" 2>&1
 done
done
python3 "$m/codec_compare.py" --before-shipping "$m/round29-varint-before-codec-nolto/codec-shipping" --before-allocations "$m/round29-varint-before-codec-nolto/codec-allocations" --before-record "$m/round29-varint-before-codec-nolto/source.json" --after-shipping "$m/round29-varint-after-codec-nolto/codec-shipping" --after-allocations "$m/round29-varint-after-codec-nolto/codec-allocations" --after-record "$m/round29-varint-after-codec-nolto/source.json" --storage lazy --output "$w/varint-codec-nolto-results" > "$w/varint-codec-nolto.log" 2>&1
bash "$w/measure-compact-map.sh" > "$w/compact-map-comparison.log" 2>&1
for profile in lazy owned; do
 python3 "$w/measure-repeated.py" --before-shipping "$m/round29-repeated-before-$profile/codec-shipping" --before-allocations "$m/round29-repeated-before-$profile/codec-allocations" --before-record "$m/round29-repeated-before-$profile/source.json" --after-shipping "$m/round29-repeated-after-$profile/codec-shipping" --after-allocations "$m/round29-repeated-after-$profile/codec-allocations" --after-record "$m/round29-repeated-after-$profile/source.json" --storage "$profile" --output "$w/repeated-$profile-results" > "$w/repeated-$profile.log" 2>&1
done
printf '%s\n' 'Whole-codec, compact-map, and repeated-run screening completed.'
