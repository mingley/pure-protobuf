"""Audit combined-source artifacts before performance captures."""
from pathlib import Path
import hashlib,json
r=Path.cwd();m=r/'work/all-benchmarks/measurement';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();manifest=json.loads((m/'round29-integrated-source-source.json').read_text());groups=[f'round29-integrated-{p}' for p in ('lazy','owned','partial-lazy','partial-owned','encode-lazy','encode-owned')]+['round29-integrated-codec-nolto']+[f'round29-repeated-integrated-{p}' for p in ('lazy','owned')];rows=[]
for name in groups:
 d=m/name;a=json.loads((d/'source.json').read_text())
 for mode in ('shipping','allocations'):
  k='codec-'+mode;b=d/k;v=a['binaries'][k];j=json.loads((d/v['build_record']).read_text());assert sha(b)==v['sha256']==j['binary_sha256'];assert j['exit_code']==0 and j['source_unchanged'] and j['harness_unchanged'];assert all(j['source_files'].get(n)==h for n,h in manifest['files'].items());messages=[json.loads(l) for l in (d/(k+'.jsonl')).read_text().splitlines()];art=[x for x in messages if x.get('reason')=='compiler-artifact' and x.get('executable')==j['build_executable']];assert len(art)==1 and not art[0]['fresh'] and art[0]['profile']['opt_level']=='3',(name,mode,'stale');assert ('allocations' in j['features'])==(mode=='allocations');rows.append({'group':name,'mode':mode,'sha256':sha(b),'harness':j['harness_files'].get('src/main.rs')})
by={}
for x in rows:by.setdefault(x['sha256'],set()).add(x['harness'])
assert all(len(v)==1 for v in by.values()),'cross-harness collision'
for profile in ('lazy','owned'):
 for mode in ('shipping','allocations'):
  a=json.loads((m/f'round29-repeated-before-{profile}'/f'codec-{mode}-build.json').read_text());b=json.loads((m/f'round29-repeated-integrated-{profile}'/f'codec-{mode}-build.json').read_text());assert a['cargo_lock_sha256']==b['cargo_lock_sha256'] and a['harness_files']['src/main.rs']==b['harness_files']['src/main.rs'] and a['harness_files']['proof.proto']==b['harness_files']['proof.proto']
a=json.loads((m/'round29-codec-before-nolto-harness/harness-provenance.json').read_text());b=json.loads((m/'round29-integrated-nolto-harness/harness-provenance.json').read_text());assert all(a[k]==b[k] for k in ('main_sha256','build_rs_sha256','lock_sha256','proto_sha256','profile'))
baseline=json.loads((r/'work/benchmark-followup/codegen-selected-release/source.json').read_text());
for name in ('codegen-integrated-release','codegen-integrated-early-release'):
 d=r/'work/bench-round-20261029'/name;j=json.loads((d/'source.json').read_text());assert sha(d/'driver')==j['executable_sha256'] and not j['cargo_artifact']['fresh'];assert j['lock_sha256']==baseline['lock_sha256'] and j['driver_source_sha256']==baseline['driver_source_sha256'];assert all(j['source_sha256'].get(n)==h for n,h in manifest['files'].items());rows.append({'group':name,'sha256':sha(d/'driver')})
p=r/'work/bench-round-20261029/integrated-repeated-preflight.json';j=json.loads(p.read_text());assert j['complete'] and j['captures']==480 and j['timed_iterations']==0
(r/'work/bench-round-20261029/integrated-audit.json').write_text(json.dumps({'complete':True,'source_manifest':str((m/'round29-integrated-source-source.json').relative_to(r)),'artifacts':rows},indent=2)+'\n');print(json.dumps({'complete':True,'artifacts':len(rows)}))
