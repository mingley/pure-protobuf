import argparse, hashlib, json, subprocess
from pathlib import Path
root=Path('/workspace/pure-protobuf')
proof=root/'work/bench-round-20261029/consumer-proof'
base=json.loads((proof/'prepared.json').read_text())
output=root/'work/bench-round-20261029/combined-generator-comparison'
p=argparse.ArgumentParser();p.add_argument('--binary',type=Path,required=True);p.add_argument('--binary-sha256',required=True);args=p.parse_args();binary=args.binary.resolve(strict=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(binary)==args.binary_sha256
output.mkdir(exist_ok=False)
proto_base=root/'work/benchmark-followup/results/codegen-selected-release/corpora'
protoc=root/'work/toolchain/protoc/bin/protoc';assert sha(protoc)==base['generators']['protoc']['sha256']
manifest={'combined_binary':str(binary),'combined_sha256':sha(binary),'descriptor_only_binary':base['generators']['candidate'],'protoc':base['generators']['protoc'],'cases':{}}
for case,files in [('small',2),('100',5),('1000',20)]:
 proto=proto_base/case/'consumer/proto';out=output/case;out.mkdir();names=[f'part_{i:02d}.proto' for i in range(files)];cmd=[str(binary),str(proto),str(out),str(protoc),*names]
 run=subprocess.run(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE);(output/f'{case}.stdout').write_bytes(run.stdout);(output/f'{case}.stderr').write_bytes(run.stderr);assert run.returncode==0,(case,run.stderr.decode(errors='replace'))
 before=Path(base['cases'][case]['candidate']['path']);before_entries=base['cases'][case]['candidate']['files'];new={p.relative_to(out).as_posix():p for p in sorted(out.rglob('*.rs'))};assert set(before_entries)==set(new)
 diffs=[];records={};desc_count=0
 for name,newp in new.items():
  prev=before/name;assert sha(prev)==before_entries[name]['sha256'];b=prev.read_bytes();a=newp.read_bytes()
  if a!=b:diffs.append(name)
  marker=b'pub const FILE_DESCRIPTOR_SET: &[u8] = b"'
  if marker in b:
   assert a.count(marker)==b.count(marker)==1
   def extract(x):
    start=x.index(marker)+len(marker);end=x.index(b'";',start);return bytes.fromhex(x[start:end].decode('ascii').replace('\\x',''))
   assert extract(a)==extract(b),name;desc_count+=1
  else:assert marker not in a,name
  records[name]={'before_sha256':hashlib.sha256(b).hexdigest(),'after_sha256':hashlib.sha256(a).hexdigest(),'before_bytes':len(b),'after_bytes':len(a),'equal':a==b}
 manifest['cases'][case]={'command':cmd,'output':str(out),'files':records,'changed_files':diffs,'descriptor_sets_compared':desc_count,'before_bytes':sum(v['before_bytes'] for v in records.values()),'after_bytes':sum(v['after_bytes'] for v in records.values())}
assert sha(binary)==args.binary_sha256
(output/'comparison.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:{z:v[z] for z in ('before_bytes','after_bytes','changed_files','descriptor_sets_compared')} for k,v in manifest['cases'].items()},indent=2))
