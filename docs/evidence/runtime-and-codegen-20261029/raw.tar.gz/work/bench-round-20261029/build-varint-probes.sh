#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
check() { python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'; }
python3 - <<'PY'
from pathlib import Path
import shutil
m=Path('work/all-benchmarks/measurement').resolve();template=Path('work/bench-round-20261029/varint-template').resolve()
for side in ('before','after'):
 for profile in ('thin','nolto'):
  h=m/f'round29-varint-{side}-{profile}-harness';assert not h.exists();shutil.copytree(template,h);core=m/('round-selected-source' if side=='before' else 'round29-varint-shell-source');p=h/'Cargo.toml';s=p.read_text().replace('FROZEN_CORE',str(core)).replace('PROFILE_LTO','"thin"' if profile=='thin' else 'false').replace('PROFILE_UNITS','1' if profile=='thin' else '16');p.write_text(s)
PY
cargo generate-lockfile --offline --manifest-path work/all-benchmarks/measurement/round29-varint-before-thin-harness/Cargo.toml
for side in before after; do
for profile in thin nolto; do
check
h="work/all-benchmarks/measurement/round29-varint-$side-$profile-harness"; cp work/all-benchmarks/measurement/round29-varint-before-thin-harness/Cargo.lock "$h/Cargo.lock.tmp"; mv "$h/Cargo.lock.tmp" "$h/Cargo.lock"; touch "$h/src/main.rs"
source=work/all-benchmarks/measurement/round-selected-source
if [ "$side" = after ]; then source=work/all-benchmarks/measurement/round29-varint-shell-source; fi
python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "$h/Cargo.toml" --binary-name pbrs-round29-varint-probe --mode shipping --output "work/all-benchmarks/measurement/round29-varint-$side-$profile" --record-key codec-shipping
done
done
python3 - <<'PY'
from pathlib import Path
import hashlib,itertools,json,subprocess
m=Path('work/all-benchmarks/measurement');rows=[]
for side,profile,case in itertools.product(('before','after'),('thin','nolto'),('one','two','mixed','three_to_five','ten','truncated','overflow')):
 p=m/f'round29-varint-{side}-{profile}/codec-shipping';d=json.loads((p.parent/'source.json').read_text());assert hashlib.sha256(p.read_bytes()).hexdigest()==d['binaries']['codec-shipping']['sha256'];r=subprocess.run([str(p),case,'0'],capture_output=True,text=True);assert r.returncode==0,(p,case,r.stderr);v=json.loads(r.stdout);assert v['semantic_prechecks'] and v['iterations']==0 and v['case']==case;rows.append({'side':side,'profile':profile,'case':case,'cases':v['cases']})
for profile,case in itertools.product(('thin','nolto'),('one','two','mixed','three_to_five','ten','truncated','overflow')):assert [x['cases'] for x in rows if x['profile']==profile and x['case']==case][0]==[x['cases'] for x in rows if x['profile']==profile and x['case']==case][1]
p=Path('work/bench-round-20261029/varint-preflight.json');p.write_text(json.dumps({'complete':True,'timed_iterations':0,'captures':len(rows),'rows':rows},indent=2)+'\n');print(json.dumps({'complete':True,'captures':len(rows),'timed_iterations':0}))
PY
