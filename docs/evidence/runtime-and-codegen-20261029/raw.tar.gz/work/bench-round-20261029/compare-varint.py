"""Paired public-varint diagnostics, with zero-iteration semantic checks."""
import hashlib,itertools,json,os,platform,random,statistics,subprocess
from pathlib import Path
root=Path.cwd();m=root/'work/all-benchmarks/measurement';out=root/'work/bench-round-20261029/varint-results';assert not out.exists();out.mkdir();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();cases=('one','two','mixed','three_to_five','ten','truncated','overflow');bins={};meta={}
for side,profile in itertools.product(('before','after'),('thin','nolto')):
 d=m/f'round29-varint-{side}-{profile}';b=d/'codec-shipping';j=json.loads((d/'source.json').read_text());assert sha(b)==j['binaries']['codec-shipping']['sha256'];bins[side,profile]=b;meta[f'{side}-{profile}']={'sha256':sha(b),'build':j}
affinity=sorted(os.sched_getaffinity(0));os.sched_setaffinity(0,{affinity[0]});rng=random.Random(291029);plan=[]
for pair in range(5):
 cells=list(itertools.product(('thin','nolto'),cases));rng.shuffle(cells)
 for profile,case in cells:
  order=['before','after'];rng.shuffle(order)
  for side in order:
   for sample in range(3):plan.append({'pair':pair,'profile':profile,'case':case,'side':side,'sample':sample})
manifest={'schema':'pbrs.round29.varint.v1','state':'running','iterations':2_000_000,'pairs':5,'samples':3,'seed':291029,'affinity_before':affinity,'cpu':affinity[0],'host':platform.uname()._asdict(),'binaries':meta,'plan':plan,'captures':[],'note':'Process CPU time; direct public runtime decoder diagnostic; no Prost control and not an end-to-end result.'};(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for e in plan:
 cmd=[str(bins[e['side'],e['profile']]),e['case'],str(manifest['iterations'])];p=subprocess.run(cmd,capture_output=True,text=True);row={**e,'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};manifest['captures'].append(row);(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');assert p.returncode==0,(e,p.stderr);v=json.loads(p.stdout);assert v['case']==e['case'] and v['semantic_prechecks'] and v['iterations']==manifest['iterations'] and v['cpu_ns']>0
rows=[]
for profile,case in itertools.product(('thin','nolto'),cases):
 v={(x['pair'],x['side'],x['sample']):json.loads(x['stdout']) for x in manifest['captures'] if x['profile']==profile and x['case']==case};before=[];after=[]
 for i in range(5):
  for side,dst in (('before',before),('after',after)):
   run=[v[i,side,k] for k in range(3)];assert len({x['checksum'] for x in run})==1;dst.append(statistics.median(x['cpu_ns']/x['iterations'] for x in run))
  assert v[i,'before',0]['checksum']==v[i,'after',0]['checksum'],(profile,case,i)
 ratios=[after[i]/before[i] for i in range(5)];rows.append({'profile':profile,'case':case,'before_ns':statistics.median(before),'after_ns':statistics.median(after),'paired_after_over_before':{'median':statistics.median(ratios),'range':[min(ratios),max(ratios)],'pairs':ratios}})
for k,p in bins.items():assert sha(p)==meta['-'.join(k)]['sha256']
(out/'summary.json').write_text(json.dumps(rows,indent=2)+'\n');manifest['state']='complete';(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'state':'complete','captures':len(plan),'rows':len(rows)}))
