"""Audit fresh candidate and control executables for the second screening."""
from pathlib import Path
import hashlib,json
r=Path.cwd();m=r/'work/all-benchmarks/measurement';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();groups=[]
for stem in ('round29-varint-shell','round29-repeated-tag','round29-compact-map'):
 for profile in ('lazy','owned'):groups.append(stem+'-'+profile)
groups += ['round29-compact-map-map','round29-compact-loop','round29-varint-before-codec-nolto','round29-varint-after-codec-nolto']
groups += [f'round29-repeated-{side}-{profile}' for side in ('before','after') for profile in ('lazy','owned')]
rows=[]
for name in groups:
 folder=m/name;agg=json.loads((folder/'source.json').read_text())
 for mode in ('shipping','allocations'):
  key='codec-'+mode;v=agg['binaries'][key];j=json.loads((folder/v['build_record']).read_text());binary=folder/key;assert sha(binary)==v['sha256']==j['binary_sha256'];assert j['exit_code']==0 and j['source_unchanged'] and j['harness_unchanged'];src=Path(j['source']);manifest=json.loads((m/(src.name+'-source.json')).read_text());assert all(j['source_files'].get(n)==h for n,h in manifest['files'].items()),name
  messages=[json.loads(l) for l in (folder/(key+'.jsonl')).read_text().splitlines()];a=[x for x in messages if x.get('reason')=='compiler-artifact' and x.get('executable')==j['build_executable']];assert len(a)==1 and not a[0]['fresh'] and a[0]['profile']['opt_level']=='3',(name,mode,'stale');assert ('allocations' in j['features'])==(mode=='allocations');rows.append({'group':name,'mode':mode,'sha256':sha(binary),'harness_main':j['harness_files'].get('src/main.rs'),'features':j['features']})
by={}
for x in rows:by.setdefault(x['sha256'],set()).add(x['harness_main'])
assert all(len(v)==1 for v in by.values()),'cross-harness executable collision'
for profile in ('lazy','owned'):
 for mode in ('shipping','allocations'):
  a=json.loads((m/f'round29-repeated-before-{profile}'/f'codec-{mode}-build.json').read_text());b=json.loads((m/f'round29-repeated-after-{profile}'/f'codec-{mode}-build.json').read_text());assert a['cargo_lock_sha256']==b['cargo_lock_sha256'] and a['harness_files']['src/main.rs']==b['harness_files']['src/main.rs'] and a['harness_files']['proof.proto']==b['harness_files']['proof.proto']
for side in ('before','after'):
 p=m/f'round29-codec-{side}-nolto-harness/harness-provenance.json';d=json.loads(p.read_text());assert d['profile']=={'opt-level':3,'lto':False,'codegen_units':16}
a=json.loads((m/'round29-codec-before-nolto-harness/harness-provenance.json').read_text());b=json.loads((m/'round29-codec-after-nolto-harness/harness-provenance.json').read_text());assert all(a[k]==b[k] for k in ('main_sha256','build_rs_sha256','lock_sha256','proto_sha256','profile'))
for n,count in [('preflight-compact-map.json',144),('repeated-preflight.json',480)]:
 d=json.loads((r/'work/bench-round-20261029'/n).read_text());assert d['complete'] and d['captures']==count and d['timed_iterations']==0
out=r/'work/bench-round-20261029/second-audit.json';out.write_text(json.dumps({'complete':True,'artifacts':rows},indent=2)+'\n');print(json.dumps({'complete':True,'artifacts':len(rows)}))
