#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
w=work/bench-round-20261029
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
python3 "$w/compare-varint.py" > "$w/varint-comparison.log" 2>&1
bash "$w/measure-packed-map.sh" > "$w/packed-map-comparison.log" 2>&1
PATH=/workspace/pure-protobuf/work/cargo/bin:$PATH RUSTUP_HOME=/workspace/pure-protobuf/work/rustup python3 work/receive-microprobe/compare.py --output work/receive-microprobe/results.json > "$w/receive-microprobe.log" 2>&1
for part in 1 2 3 4 5; do
 resume=();if [ "$part" -gt 1 ]; then resume=(--resume); fi
 python3 "$m/codegen_compare_blocking.py" --baseline work/benchmark-followup/codegen-selected-release/driver --candidate "$w/codegen-descriptor-release/driver" --prost work/all-benchmarks/codegen/final-prost-release/driver --profile release --output "$w/codegen-descriptor-results" --capture-limit 12 "${resume[@]}" > "$w/codegen-descriptor-$part.log" 2>&1
done
printf '%s\n' 'Varint, packed map, receiver microprobe and descriptor generator initial screens completed.'
