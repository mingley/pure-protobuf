#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
out=work/benchmark-followup/results
python3 - <<'PY'
import hashlib,json
from pathlib import Path
r=Path.cwd();m=r/'work/all-benchmarks/measurement/round29-packed-map-source-source.json';d=json.loads(m.read_text());f=r/'work/all-benchmarks/measurement/round29-packed-map-source/src/map.rs';assert hashlib.sha256(f.read_bytes()).hexdigest()==d['declared_changes']['src/map.rs']['after'];print(json.dumps({'packed_frozen_source_matches':True,'workspace_map_sha256':hashlib.sha256((r/'src/map.rs').read_bytes()).hexdigest()}),flush=True)
PY
for group in map-small map-large; do
python3 "$m/measure_phase2.py" "$group" --candidate round29-packed-map > "$out/round29-packed-map-$group.log" 2>&1
done
for profile in lazy owned; do
python3 "$m/measure_phase2.py" codec --storage "$profile" --candidate round29-packed-map > "$out/round29-packed-map-codec-$profile.log" 2>&1
done
python3 work/benchmark-followup/map-loop-compare.py --before-shipping "$m/round-loop-before/codec-shipping" --before-allocations "$m/round-loop-before/codec-allocations" --before-record "$m/round-loop-before/source.json" --after-shipping "$m/round29-packed-loop/codec-shipping" --after-allocations "$m/round29-packed-loop/codec-allocations" --after-record "$m/round29-packed-loop/source.json" --storage lazy --output "$out/map-ordinary-loop-packed29" > "$out/map-ordinary-loop-packed29.log" 2>&1
printf '%s\n' 'Packed map comparisons completed.'
