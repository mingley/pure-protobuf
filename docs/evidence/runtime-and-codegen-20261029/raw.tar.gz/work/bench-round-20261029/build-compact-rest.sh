#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
check() { python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'; }
python3 - <<'PY'
from pathlib import Path
import shutil
b=Path('work/all-benchmarks/measurement').resolve();h=b/'round29-compact-map-harness';assert not h.exists();shutil.copytree(b/'map-template',h);shutil.copyfile(b/'map-candidate-harness/Cargo.lock',h/'Cargo.lock');p=h/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(b/'round29-compact-map-source')));assert (h/'src/main.rs').read_bytes()==(b/'map-candidate-harness/src/main.rs').read_bytes()
PY
check
touch work/all-benchmarks/measurement/round29-compact-loop-harness/src/main.rs
python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round29-compact-map-source --manifest work/all-benchmarks/measurement/round29-compact-loop-harness/Cargo.toml --binary-name pbrs-map-iteration-proof --mode allocations --output work/all-benchmarks/measurement/round29-compact-loop --record-key codec-allocations
for mode in shipping allocations; do
 check;touch work/all-benchmarks/measurement/round29-compact-map-harness/src/main.rs
 python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round29-compact-map-source --manifest work/all-benchmarks/measurement/round29-compact-map-harness/Cargo.toml --binary-name pbrs-map-iteration-proof --mode "$mode" --output work/all-benchmarks/measurement/round29-compact-map-map --record-key "codec-$mode"
done
for profile in lazy owned; do
 for mode in shipping allocations; do
  check;extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
  python3 work/all-benchmarks/measurement/build_probe.py --source work/all-benchmarks/measurement/round29-compact-map-source --manifest work/all-benchmarks/measurement/round29-compact-map-source/tests/proof/codec_benchmark/Cargo.toml --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/round29-compact-map-$profile" --record-key "codec-$mode" "${extra[@]}"
 done
done
printf '%s\n' 'Compact-map remaining probes built; no timing.'
