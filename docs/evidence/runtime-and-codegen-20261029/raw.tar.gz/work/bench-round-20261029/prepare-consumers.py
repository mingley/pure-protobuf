import hashlib, importlib.util, json, os, re, subprocess
from pathlib import Path
root=Path('/workspace/pure-protobuf')
bench=root/'work/bench-round-20261029/consumer-proof'
bench.mkdir(exist_ok=True)
spec=importlib.util.spec_from_file_location('cg19', root/'work/all-benchmarks/measurement/canonical_codegen_blocking.py')
cg=importlib.util.module_from_spec(spec);spec.loader.exec_module(cg);cg.ROOT=root
old=root/'work/benchmark-followup/results/codegen-selected-release'
protoc=root/'work/toolchain/protoc/bin/protoc'
cmdroot=root/'work/bench-round-20261029/codegen-descriptor-release/driver'
manifest={'generators':{},'cases':{},'scope':'consumer only; dependencies prebuilt, cargo clean -p consumer before every timed invocation'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for label,path in {'before':root/'work/benchmark-followup/codegen-selected-release/driver','candidate':cmdroot,'prost':root/'work/all-benchmarks/codegen/final-prost-release/driver','protoc':protoc}.items():manifest['generators'][label]={'path':str(path),'sha256':sha(path)}
for case,(messages,files) in cg.CORPORA.items():
    proto=old/'corpora'/case/'consumer/proto'
    names=[f'part_{i:02d}.proto' for i in range(files)]
    output=bench/'candidate'/case
    output.mkdir(parents=True,exist_ok=True)
    subprocess.run([str(cmdroot),str(proto),str(output),str(protoc),*names],check=True)
    paths={'before':old/'representative-generated/candidate'/case,'candidate':output,'prost':old/'representative-generated/prost'/case}
    records={}
    for label,path in paths.items():
        rs={p.relative_to(path).as_posix():{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(path.rglob('*.rs'))}
        assert rs
        records[label]={'path':str(path),'files':rs,'bytes':sum(x['bytes'] for x in rs.values())}
    assert records['before']['files'].keys()==records['candidate']['files'].keys()
    for file in records['before']['files']:
        before=(paths['before']/file).read_text()
        after=(paths['candidate']/file).read_text()
        marker='pub const FILE_DESCRIPTOR_SET: &[u8] = '
        if marker not in before:
            assert before==after,file
            continue
        b0=before.index(marker)+len(marker);b1=before.index('];',b0)+2
        a0=after.index(marker)+len(marker);a1=after.index('";',a0)+2
        raw_before=bytes(int(h,16) for h in re.findall(r'0x([0-9a-f]{2})',before[b0:b1]))
        raw_after=bytes.fromhex(after[a0+2:a1-2].replace('\\x',''))
        assert raw_before==raw_after,file
        assert before[:b0]==after[:a0] and before[b1:]==after[a1:],file
    manifest['cases'][case]=records
for backend in ('pbrs','prost'):
    project=bench/'projects'/backend; (project/'src').mkdir(parents=True,exist_ok=True);(project/'generated').mkdir(exist_ok=True)
    if backend=='pbrs':
        man=cg.manifest('consumer').replace(str(root),str(root/'work/all-benchmarks/measurement/round29-descriptor-literal-source'))
    else:man=cg.peer_manifest('consumer','prost')
    (project/'Cargo.toml').write_text(man)
    (project/'src/main.rs').write_text('fn main() {}\n')
    subprocess.run([str(root/'work/cargo/bin/cargo'),'generate-lockfile','--offline','--manifest-path',str(project/'Cargo.toml')],check=True,env=os.environ)
    manifest.setdefault('projects',{})[backend]={'path':str(project),'manifest_sha256':sha(project/'Cargo.toml'),'lock_sha256':sha(project/'Cargo.lock')}
(bench/'prepared.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({case:{k:v['bytes'] for k,v in rec.items()} for case,rec in manifest['cases'].items()},indent=2))
