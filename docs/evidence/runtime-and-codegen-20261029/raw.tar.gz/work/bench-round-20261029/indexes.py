"""Create compact CSV indexes without changing the underlying paired records."""
import csv,io,statistics
from pathlib import Path
FIELDS=['source','suite','profile','case','operation','control','metric','before','after','control_after','after_over_before','prior_pair_min','prior_pair_max','after_over_control','pair_min','pair_max','control_after_over_before']
def build_indexes(summaries):
 timing=[];resources=[]
 def row(dst,**kw):dst.append({k:kw.get(k,'') for k in FIELDS})
 for source,data in summaries.items():
  if not isinstance(data,list):continue
  for x in data:
   if not isinstance(x,dict):continue
   q=x.get('ratios',{});a=q.get('after_over_before_pbrs');peer=q.get('after_pbrs_over_prost');
   if a and peer and ('cpu_ns_medians' in x or 'elapsed_ns_medians' in x):
    cpu='cpu_ns_medians' in x;med=x['cpu_ns_medians' if cpu else 'elapsed_ns_medians'];control='std HashMap' if '-map-small-comparison/' in source or '-map-large-comparison/' in source or 'ordinary-loop' in source else 'Prost 0.14.4'
    suite=('map-ordinary' if 'ordinary-loop' in source else 'map-warm-small' if '-map-small-comparison/' in source else 'map-warm-large' if '-map-large-comparison/' in source else 'repeated-fields' if '/repeated-' in source or '/integrated-repeated-' in source else 'partial-getter' if '-partial-' in source else 'encode' if '-encode-' in source else 'codec') if cpu else 'generator'
    profile=x.get('profile','') or ('lazy' if '-lazy-' in source else 'owned' if '-owned-' in source else 'non-LTO' if 'nolto' in source else '')
    common=dict(source=source,suite=suite,profile=profile,case=x['case'],operation=x['operation'],control=control)
    row(timing,**common,metric='process_cpu_ns_per_operation' if cpu else 'elapsed_ns',before=med['before']['pbrs'],after=med['after']['pbrs'],control_after=med['after']['prost'],after_over_before=a['median'],prior_pair_min=min(a['pairs']),prior_pair_max=max(a['pairs']),after_over_control=peer['median'],pair_min=min(peer['pairs']),pair_max=max(peer['pairs']),control_after_over_before=q.get('after_over_before_prost_control',q.get('control_after_over_before',{})).get('median',''))
    if 'allocations' in x:
     z=x['allocations']
     for k in ('requested_bytes','allocation_calls'):
      before=z['before-pbrs'][k];after=z['after-pbrs'][k];ref=z['after-prost'][k];row(resources,**common,metric=k+'_per_operation',before=before,after=after,control_after=ref,after_over_before=after/before if before else '',after_over_control=after/ref if ref else (1 if after==0 else ''))
    if 'generated_bytes' in x:
     z=x['generated_bytes'];row(resources,**common,metric='generated_rust_bytes',before=z['baseline'],after=z['candidate'],control_after=z['prost'],after_over_before=z['candidate']/z['baseline'],after_over_control=z['candidate']/z['prost'])
   elif 'paired_after_over_before' in x and 'before_ns' in x:
    q=x['paired_after_over_before'];row(timing,source=source,suite='public-varint-diagnostic',profile=x['profile'],case=x['case'],control='previous pbrs',metric='process_cpu_ns_per_operation',before=x['before_ns'],after=x['after_ns'],after_over_before=q['median'],prior_pair_min=min(q['pairs']),prior_pair_max=max(q['pairs']))
 for source,data in summaries.items():
  if not isinstance(data,dict):continue
  if source.endswith('receive-microprobe/results.json'):
   for z in data['summary']:
    for metric,kind in [('cpu_ns','cpu'),('requested','alloc'),('allocs','alloc'),('peak_live','alloc')]:
     samples=[x for x in data['samples'] if x['size']==z['size'] and x['shape']==z['shape'] and x['kind']==kind];ratios=[x['values']['candidate'][metric]/x['values']['baseline'][metric] for x in samples];before=statistics.median(x['values']['baseline'][metric] for x in samples);after=statistics.median(x['values']['candidate'][metric] for x in samples);row(timing if metric=='cpu_ns' else resources,source=source,suite='synthetic-frame-diagnostic',case=str(z['size']),operation=z['shape'],control='previous pbrs',metric=metric,before=before,after=after,after_over_before=statistics.median(ratios),prior_pair_min=min(ratios),prior_pair_max=max(ratios))
  if 'consumer-proof/consumer-' in source and data.get('state')=='complete':
   rows=data['rows']
   for case,mode in sorted({(x['case'],x['mode']) for x in rows}):
    selected=[x for x in rows if x['case']==case and x['mode']==mode];v={(x['repeat'],x['variant']):x['elapsed_ns'] for x in selected};repeats=sorted({x['repeat'] for x in selected});ratios=[v[i,'candidate']/v[i,'before'] for i in repeats];peers=[v[i,'candidate']/v[i,'prost'] for i in repeats];row(timing,source=source,suite='consumer-build',case=case,operation=mode,control='Prost 0.14.4',metric='elapsed_ns',before=statistics.median(v[i,'before'] for i in repeats),after=statistics.median(v[i,'candidate'] for i in repeats),control_after=statistics.median(v[i,'prost'] for i in repeats),after_over_before=statistics.median(ratios),prior_pair_min=min(ratios),prior_pair_max=max(ratios),after_over_control=statistics.median(peers),pair_min=min(peers),pair_max=max(peers))
 def make(rows):
  s=io.StringIO(newline='');c=csv.DictWriter(s,fieldnames=FIELDS);c.writeheader();c.writerows(rows);return s.getvalue().encode()
 return {'timing.csv':make(timing),'resources.csv':make(resources)}
