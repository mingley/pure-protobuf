#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo RUSTUP_HOME=/workspace/pure-protobuf/work/rustup PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
check() { python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'; }
for label in round29-varint-shell round29-repeated-tag; do
 source="work/all-benchmarks/measurement/$label-source";touch "$source/src/lib.rs" "$source/tests/proof/codec_benchmark/src/main.rs"
 for profile in lazy owned; do
  for mode in shipping allocations; do
   check
   extra=();if [ "$profile" = owned ]; then extra=(--owned); fi
   python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "$source/tests/proof/codec_benchmark/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/$label-$profile" --record-key "codec-$mode" "${extra[@]}"
  done
 done
done
for side in before after; do
 source=work/all-benchmarks/measurement/round-selected-source
 if [ "$side" = after ]; then source=work/all-benchmarks/measurement/round29-varint-shell-source; fi
 python3 work/bench-round-20261029/prepare-nolto.py "round29-codec-$side" "$source"
 for mode in shipping allocations; do
  check
  h="work/all-benchmarks/measurement/round29-codec-$side-nolto-harness"; touch "$h/src/main.rs" "$h/build.rs"
  PBRS_BENCHMARK_ROOT="/workspace/pure-protobuf/$source" python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "$h/Cargo.toml" --binary-name pbrs-codec-proof --mode "$mode" --output "work/all-benchmarks/measurement/round29-varint-$side-codec-nolto" --record-key "codec-$mode"
 done
done
printf '%s\n' 'Varint/repeated-tag codec candidates built; no timing performed.'
