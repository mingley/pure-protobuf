
work/all-benchmarks/measurement/round29-compact-loop/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002df00 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_>:
   2df00:	55                   	push   %rbp
   2df01:	41 57                	push   %r15
   2df03:	41 56                	push   %r14
   2df05:	41 55                	push   %r13
   2df07:	41 54                	push   %r12
   2df09:	53                   	push   %rbx
   2df0a:	48 83 ec 78          	sub    $0x78,%rsp
   2df0e:	48 8b 07             	mov    (%rdi),%rax
   2df11:	48 8b 00             	mov    (%rax),%rax
   2df14:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2df19:	75 10                	jne    2df2b <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x2b>
   2df1b:	48 8b 40 08          	mov    0x8(%rax),%rax
   2df1f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2df25:	0f 84 4b 03 00 00    	je     2e276 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2df2b:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2df2f:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2df34:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2df39:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2df3d:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2df41:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2df45:	48 83 f9 04          	cmp    $0x4,%rcx
   2df49:	0f 87 58 0b 00 00    	ja     2eaa7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba7>
   2df4f:	48 8b 40 08          	mov    0x8(%rax),%rax
   2df53:	48 8d 15 b6 b3 fd ff 	lea    -0x24c4a(%rip),%rdx        # 9310 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2df5a:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2df5e:	48 01 d1             	add    %rdx,%rcx
   2df61:	ff e1                	jmp    *%rcx
   2df63:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2df6a:	61 6c 6c 
   2df6d:	48 39 08             	cmp    %rcx,(%rax)
   2df70:	0f 85 31 0b 00 00    	jne    2eaa7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba7>
   2df76:	48 8b 4c 24 48       	mov    0x48(%rsp),%rcx
   2df7b:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2df7f:	48 85 c0             	test   %rax,%rax
   2df82:	0f 84 2a 03 00 00    	je     2e2b2 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2df88:	48 8b 09             	mov    (%rcx),%rcx
   2df8b:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2df8f:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2df93:	f7 d7                	not    %edi
   2df95:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2df99:	31 d2                	xor    %edx,%edx
   2df9b:	eb 36                	jmp    2dfd3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2df9d:	0f 1f 00             	nopl   (%rax)
   2dfa0:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2dfa4:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2dfa9:	41 21 f8             	and    %edi,%r8d
   2dfac:	41 c1 e1 03          	shl    $0x3,%r9d
   2dfb0:	48 89 cf             	mov    %rcx,%rdi
   2dfb3:	4c 29 cf             	sub    %r9,%rdi
   2dfb6:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2dfba:	49 89 d2             	mov    %rdx,%r10
   2dfbd:	4d 01 ca             	add    %r9,%r10
   2dfc0:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2dfc4:	4c 01 d2             	add    %r10,%rdx
   2dfc7:	44 89 c7             	mov    %r8d,%edi
   2dfca:	48 ff c8             	dec    %rax
   2dfcd:	0f 84 e1 02 00 00    	je     2e2b4 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2dfd3:	66 85 ff             	test   %di,%di
   2dfd6:	75 c8                	jne    2dfa0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dfd8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2dfdf:	00 
   2dfe0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dfe4:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2dfe8:	48 83 c6 10          	add    $0x10,%rsi
   2dfec:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dff0:	66 83 f7 ff          	xor    $0xffff,%di
   2dff4:	74 ea                	je     2dfe0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2dff6:	eb a8                	jmp    2dfa0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dff8:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2dfff:	66 69 72 
   2e002:	48 33 08             	xor    (%rax),%rcx
   2e005:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e009:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e00f:	48 09 c8             	or     %rcx,%rax
   2e012:	0f 85 8f 0a 00 00    	jne    2eaa7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba7>
   2e018:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2e01d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2e022:	0f 84 77 02 00 00    	je     2e29f <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2e028:	48 8b 00             	mov    (%rax),%rax
   2e02b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2e02f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2e033:	66 83 f1 ff          	xor    $0xffff,%cx
   2e037:	75 1d                	jne    2e056 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2e039:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2e03d:	0f 1f 00             	nopl   (%rax)
   2e040:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2e044:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2e048:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2e04c:	48 83 c2 10          	add    $0x10,%rdx
   2e050:	66 83 f1 ff          	xor    $0xffff,%cx
   2e054:	74 ea                	je     2e040 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2e056:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2e05a:	c1 e1 03             	shl    $0x3,%ecx
   2e05d:	48 29 c8             	sub    %rcx,%rax
   2e060:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2e064:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2e068:	e9 34 02 00 00       	jmp    2e2a1 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2e06d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e074:	72 65 61 
   2e077:	48 33 08             	xor    (%rax),%rcx
   2e07a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e07e:	48 83 f0 64          	xor    $0x64,%rax
   2e082:	48 09 c8             	or     %rcx,%rax
   2e085:	0f 85 1c 0a 00 00    	jne    2eaa7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba7>
   2e08b:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2e092:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2e097:	0f 85 23 0a 00 00    	jne    2eac0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbc0>
   2e09d:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2e0a1:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2e0a6:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2e0aa:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2e0ae:	0f 10 05 d3 26 04 00 	movups 0x426d3(%rip),%xmm0        # 70788 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f8>
   2e0b5:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2e0b9:	f3 0f 6f 05 d7 26 04 	movdqu 0x426d7(%rip),%xmm0        # 70798 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x508>
   2e0c0:	00 
   2e0c1:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2e0c7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2e0cc:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2e0d1:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e0d5:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2e0da:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2e0df:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2e0e4:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e0e8:	48 85 c9             	test   %rcx,%rcx
   2e0eb:	0f 84 cf 01 00 00    	je     2e2c0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2e0f1:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e0f5:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2e0f9:	48 89 e3             	mov    %rsp,%rbx
   2e0fc:	0f 1f 40 00          	nopl   0x0(%rax)
   2e100:	41 8b 36             	mov    (%r14),%esi
   2e103:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e107:	48 89 df             	mov    %rbx,%rdi
   2e10a:	e8 01 61 00 00       	call   34210 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e10f:	49 83 c6 08          	add    $0x8,%r14
   2e113:	4d 39 fe             	cmp    %r15,%r14
   2e116:	75 e8                	jne    2e100 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2e118:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e11c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e121:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2e126:	48 85 c9             	test   %rcx,%rcx
   2e129:	0f 84 a6 04 00 00    	je     2e5d5 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x6d5>
   2e12f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2e133:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e138:	41 f7 d1             	not    %r9d
   2e13b:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2e13f:	31 d2                	xor    %edx,%edx
   2e141:	49 89 f8             	mov    %rdi,%r8
   2e144:	eb 3d                	jmp    2e183 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2e146:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2e14d:	00 00 00 
   2e150:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2e154:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2e159:	45 21 ca             	and    %r9d,%r10d
   2e15c:	41 c1 e3 03          	shl    $0x3,%r11d
   2e160:	4d 89 c1             	mov    %r8,%r9
   2e163:	4d 29 d9             	sub    %r11,%r9
   2e166:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2e16a:	48 89 d3             	mov    %rdx,%rbx
   2e16d:	4c 01 db             	add    %r11,%rbx
   2e170:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2e174:	48 01 da             	add    %rbx,%rdx
   2e177:	45 89 d1             	mov    %r10d,%r9d
   2e17a:	48 ff c9             	dec    %rcx
   2e17d:	0f 84 54 04 00 00    	je     2e5d7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x6d7>
   2e183:	66 45 85 c9          	test   %r9w,%r9w
   2e187:	75 c7                	jne    2e150 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e189:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e190:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2e194:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2e198:	48 83 c6 10          	add    $0x10,%rsi
   2e19c:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e1a1:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2e1a6:	74 e8                	je     2e190 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2e1a8:	eb a6                	jmp    2e150 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e1aa:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e1b1:	63 6f 6c 
   2e1b4:	48 33 08             	xor    (%rax),%rcx
   2e1b7:	8b 40 08             	mov    0x8(%rax),%eax
   2e1ba:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e1c0:	48 09 c8             	or     %rcx,%rax
   2e1c3:	0f 85 de 08 00 00    	jne    2eaa7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba7>
   2e1c9:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2e1ce:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2e1d2:	48 85 c9             	test   %rcx,%rcx
   2e1d5:	0f 84 f8 00 00 00    	je     2e2d3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2e1db:	4c 8b 28             	mov    (%rax),%r13
   2e1de:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2e1e4:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e1e9:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2e1ed:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e1f2:	75 25                	jne    2e219 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2e1f4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e1fb:	00 00 00 00 00 
   2e200:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e205:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e209:	48 83 c5 10          	add    $0x10,%rbp
   2e20d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e212:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e217:	74 e7                	je     2e200 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2e219:	48 83 f9 05          	cmp    $0x5,%rcx
   2e21d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2e222:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e228:	4c 0f 43 f9          	cmovae %rcx,%r15
   2e22c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2e233:	00 
   2e234:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2e23b:	ff ff 1f 
   2e23e:	48 ff c0             	inc    %rax
   2e241:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2e246:	48 39 c1             	cmp    %rax,%rcx
   2e249:	0f 97 c0             	seta   %al
   2e24c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2e253:	ff ff 7f 
   2e256:	48 83 c1 0b          	add    $0xb,%rcx
   2e25a:	49 39 ce             	cmp    %rcx,%r14
   2e25d:	0f 97 c1             	seta   %cl
   2e260:	08 c1                	or     %al,%cl
   2e262:	0f 84 67 02 00 00    	je     2e4cf <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5cf>
   2e268:	31 db                	xor    %ebx,%ebx
   2e26a:	48 89 df             	mov    %rbx,%rdi
   2e26d:	4c 89 f6             	mov    %r14,%rsi
   2e270:	ff 15 e2 41 04 00    	call   *0x441e2(%rip)        # 72458 <_DYNAMIC+0x230>
   2e276:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2e27a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2e27f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   2e284:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2e289:	48 8b 30             	mov    (%rax),%rsi
   2e28c:	48 85 f6             	test   %rsi,%rsi
   2e28f:	74 4f                	je     2e2e0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2e291:	48 8b 56 08          	mov    0x8(%rsi),%rdx
   2e295:	48 8b 5e 10          	mov    0x10(%rsi),%rbx
   2e299:	48 83 c6 18          	add    $0x18,%rsi
   2e29d:	eb 45                	jmp    2e2e4 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x3e4>
   2e29f:	31 c9                	xor    %ecx,%ecx
   2e2a1:	48 89 0c 24          	mov    %rcx,(%rsp)
   2e2a5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e2aa:	48 89 e0             	mov    %rsp,%rax
   2e2ad:	e9 e2 07 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e2b2:	31 d2                	xor    %edx,%edx
   2e2b4:	48 89 14 24          	mov    %rdx,(%rsp)
   2e2b8:	48 89 e0             	mov    %rsp,%rax
   2e2bb:	e9 d4 07 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e2c0:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2e2c7:	00 00 
   2e2c9:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2e2ce:	e9 c1 07 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e2d3:	b8 04 00 00 00       	mov    $0x4,%eax
   2e2d8:	45 31 ff             	xor    %r15d,%r15d
   2e2db:	e9 44 05 00 00       	jmp    2e824 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x924>
   2e2e0:	31 f6                	xor    %esi,%esi
   2e2e2:	31 d2                	xor    %edx,%edx
   2e2e4:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2e2e8:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e2ec:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2e2f0:	48 83 f9 04          	cmp    $0x4,%rcx
   2e2f4:	0f 87 e1 07 00 00    	ja     2eadb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbdb>
   2e2fa:	48 8b 40 08          	mov    0x8(%rax),%rax
   2e2fe:	4c 8d 05 1f b0 fd ff 	lea    -0x24fe1(%rip),%r8        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2e305:	49 63 0c 88          	movslq (%r8,%rcx,4),%rcx
   2e309:	4c 01 c1             	add    %r8,%rcx
   2e30c:	ff e1                	jmp    *%rcx
   2e30e:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2e315:	61 6c 6c 
   2e318:	48 39 08             	cmp    %rcx,(%rax)
   2e31b:	0f 85 ba 07 00 00    	jne    2eadb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbdb>
   2e321:	48 85 d2             	test   %rdx,%rdx
   2e324:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e32a:	4c 0f 45 fa          	cmovne %rdx,%r15
   2e32e:	48 0f 44 da          	cmove  %rdx,%rbx
   2e332:	31 c0                	xor    %eax,%eax
   2e334:	48 85 db             	test   %rbx,%rbx
   2e337:	74 19                	je     2e352 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e339:	48 85 f6             	test   %rsi,%rsi
   2e33c:	74 14                	je     2e352 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e33e:	48 83 fb 10          	cmp    $0x10,%rbx
   2e342:	72 0e                	jb     2e352 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2e344:	8b 46 20             	mov    0x20(%rsi),%eax
   2e347:	85 c0                	test   %eax,%eax
   2e349:	0f 85 a5 07 00 00    	jne    2eaf4 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbf4>
   2e34f:	48 89 f0             	mov    %rsi,%rax
   2e352:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e359:	00 
   2e35a:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
   2e35f:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e364:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e369:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e36e:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e375:	00 00 
   2e377:	31 db                	xor    %ebx,%ebx
   2e379:	4c 8b 3d 98 44 04 00 	mov    0x44498(%rip),%r15        # 72818 <_DYNAMIC+0x5f0>
   2e380:	31 c0                	xor    %eax,%eax
   2e382:	eb 20                	jmp    2e3a4 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x4a4>
   2e384:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e389:	48 8d 50 04          	lea    0x4(%rax),%rdx
   2e38d:	8b 30                	mov    (%rax),%esi
   2e38f:	8b 0a                	mov    (%rdx),%ecx
   2e391:	48 8b 04 24          	mov    (%rsp),%rax
   2e395:	48 63 d6             	movslq %esi,%rdx
   2e398:	48 89 de             	mov    %rbx,%rsi
   2e39b:	48 01 d6             	add    %rdx,%rsi
   2e39e:	48 63 d9             	movslq %ecx,%rbx
   2e3a1:	48 01 f3             	add    %rsi,%rbx
   2e3a4:	48 83 f8 01          	cmp    $0x1,%rax
   2e3a8:	75 46                	jne    2e3f0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x4f0>
   2e3aa:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e3af:	48 3b 44 24 20       	cmp    0x20(%rsp),%rax
   2e3b4:	0f 83 ef 00 00 00    	jae    2e4a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5a9>
   2e3ba:	48 8b 54 24 18       	mov    0x18(%rsp),%rdx
   2e3bf:	48 8d 3c 40          	lea    (%rax,%rax,2),%rdi
   2e3c3:	44 8b 04 ba          	mov    (%rdx,%rdi,4),%r8d
   2e3c7:	8b 74 ba 04          	mov    0x4(%rdx,%rdi,4),%esi
   2e3cb:	8b 4c ba 08          	mov    0x8(%rdx,%rdi,4),%ecx
   2e3cf:	c7 04 ba 00 00 00 00 	movl   $0x0,(%rdx,%rdi,4)
   2e3d6:	48 ff c0             	inc    %rax
   2e3d9:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e3de:	b8 01 00 00 00       	mov    $0x1,%eax
   2e3e3:	41 83 f8 01          	cmp    $0x1,%r8d
   2e3e7:	74 ac                	je     2e395 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x495>
   2e3e9:	e9 bb 00 00 00       	jmp    2e4a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5a9>
   2e3ee:	66 90                	xchg   %ax,%ax
   2e3f0:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e3f5:	48 85 f6             	test   %rsi,%rsi
   2e3f8:	74 3b                	je     2e435 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x535>
   2e3fa:	48 8b 46 10          	mov    0x10(%rsi),%rax
   2e3fe:	48 3b 44 24 10       	cmp    0x10(%rsp),%rax
   2e403:	0f 85 91 00 00 00    	jne    2e49a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x59a>
   2e409:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e40e:	48 39 c1             	cmp    %rax,%rcx
   2e411:	0f 83 92 00 00 00    	jae    2e4a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5a9>
   2e417:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e41c:	48 8d 04 ca          	lea    (%rdx,%rcx,8),%rax
   2e420:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
   2e424:	48 83 c2 04          	add    $0x4,%rdx
   2e428:	48 ff c1             	inc    %rcx
   2e42b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e430:	e9 58 ff ff ff       	jmp    2e38d <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x48d>
   2e435:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   2e43a:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e43f:	48 39 d1             	cmp    %rdx,%rcx
   2e442:	73 65                	jae    2e4a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5a9>
   2e444:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e449:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   2e450:	00 
   2e451:	48 8d 3c ce          	lea    (%rsi,%rcx,8),%rdi
   2e455:	48 83 c7 08          	add    $0x8,%rdi
   2e459:	4c 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8
   2e460:	00 
   2e461:	49 29 c0             	sub    %rax,%r8
   2e464:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e468:	48 8d 04 ce          	lea    (%rsi,%rcx,8),%rax
   2e46c:	48 ff c1             	inc    %rcx
   2e46f:	48 39 d1             	cmp    %rdx,%rcx
   2e472:	0f 84 0c ff ff ff    	je     2e384 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x484>
   2e478:	44 8b 08             	mov    (%rax),%r9d
   2e47b:	45 31 d2             	xor    %r10d,%r10d
   2e47e:	66 90                	xchg   %ax,%ax
   2e480:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e484:	74 0e                	je     2e494 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x594>
   2e486:	49 83 c2 08          	add    $0x8,%r10
   2e48a:	4d 39 d0             	cmp    %r10,%r8
   2e48d:	75 f1                	jne    2e480 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x580>
   2e48f:	e9 f0 fe ff ff       	jmp    2e384 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x484>
   2e494:	48 83 c7 08          	add    $0x8,%rdi
   2e498:	eb ca                	jmp    2e464 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x564>
   2e49a:	4c 89 f7             	mov    %r14,%rdi
   2e49d:	41 ff d7             	call   *%r15
   2e4a0:	48 85 c0             	test   %rax,%rax
   2e4a3:	0f 85 e4 fe ff ff    	jne    2e38d <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x48d>
   2e4a9:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e4ae:	74 13                	je     2e4c3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5c3>
   2e4b0:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e4b6:	74 0b                	je     2e4c3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x5c3>
   2e4b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e4bd:	ff 15 5d 3f 04 00    	call   *0x43f5d(%rip)        # 72420 <free@GLIBC_2.2.5>
   2e4c3:	48 89 1c 24          	mov    %rbx,(%rsp)
   2e4c7:	48 89 e0             	mov    %rsp,%rax
   2e4ca:	e9 c5 05 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e4cf:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2e4d4:	c1 e0 03             	shl    $0x3,%eax
   2e4d7:	4c 89 e9             	mov    %r13,%rcx
   2e4da:	48 29 c1             	sub    %rax,%rcx
   2e4dd:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2e4e2:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   2e4e8:	4c 89 f7             	mov    %r14,%rdi
   2e4eb:	ff 15 1f 3f 04 00    	call   *0x43f1f(%rip)        # 72410 <malloc@GLIBC_2.2.5>
   2e4f1:	48 85 c0             	test   %rax,%rax
   2e4f4:	0f 84 70 fd ff ff    	je     2e26a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2e4fa:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e4ff:	48 89 cb             	mov    %rcx,%rbx
   2e502:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e508:	66 0f d6 00          	movq   %xmm0,(%rax)
   2e50c:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e510:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e515:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2e51c:	00 00 
   2e51e:	48 ff cb             	dec    %rbx
   2e521:	0f 84 fd 02 00 00    	je     2e824 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x924>
   2e527:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2e52c:	45 21 e7             	and    %r12d,%r15d
   2e52f:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e535:	49 89 e4             	mov    %rsp,%r12
   2e538:	eb 35                	jmp    2e56f <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x66f>
   2e53a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e540:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e545:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2e549:	44 21 f9             	and    %r15d,%ecx
   2e54c:	48 ff cb             	dec    %rbx
   2e54f:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e555:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2e55b:	49 ff c6             	inc    %r14
   2e55e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e563:	41 89 cf             	mov    %ecx,%r15d
   2e566:	48 85 db             	test   %rbx,%rbx
   2e569:	0f 84 a7 02 00 00    	je     2e816 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x916>
   2e56f:	66 45 85 ff          	test   %r15w,%r15w
   2e573:	75 24                	jne    2e599 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x699>
   2e575:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e57c:	00 00 00 00 
   2e580:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e585:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e589:	48 83 c5 10          	add    $0x10,%rbp
   2e58d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2e592:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2e597:	74 e7                	je     2e580 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x680>
   2e599:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2e59e:	c1 e1 03             	shl    $0x3,%ecx
   2e5a1:	4c 89 ea             	mov    %r13,%rdx
   2e5a4:	48 29 ca             	sub    %rcx,%rdx
   2e5a7:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2e5ac:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2e5b1:	4c 3b 34 24          	cmp    (%rsp),%r14
   2e5b5:	75 8e                	jne    2e545 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x645>
   2e5b7:	b9 04 00 00 00       	mov    $0x4,%ecx
   2e5bc:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2e5c2:	4c 89 e7             	mov    %r12,%rdi
   2e5c5:	4c 89 f6             	mov    %r14,%rsi
   2e5c8:	48 89 da             	mov    %rbx,%rdx
   2e5cb:	e8 d0 e8 ff ff       	call   2cea0 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e5d0:	e9 6b ff ff ff       	jmp    2e540 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x640>
   2e5d5:	31 d2                	xor    %edx,%edx
   2e5d7:	48 89 54 24 30       	mov    %rdx,0x30(%rsp)
   2e5dc:	48 8d 4c 24 30       	lea    0x30(%rsp),%rcx
   2e5e1:	48 85 c0             	test   %rax,%rax
   2e5e4:	0f 84 aa 04 00 00    	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e5ea:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e5f1:	00 
   2e5f2:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e5f6:	48 01 c8             	add    %rcx,%rax
   2e5f9:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e5fd:	0f 84 91 04 00 00    	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e603:	48 29 cf             	sub    %rcx,%rdi
   2e606:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e60a:	e9 36 02 00 00       	jmp    2e845 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x945>
   2e60f:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2e616:	66 69 72 
   2e619:	48 33 08             	xor    (%rax),%rcx
   2e61c:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e620:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e626:	48 09 c8             	or     %rcx,%rax
   2e629:	0f 85 ac 04 00 00    	jne    2eadb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbdb>
   2e62f:	48 85 d2             	test   %rdx,%rdx
   2e632:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2e638:	4c 0f 45 f2          	cmovne %rdx,%r14
   2e63c:	48 85 db             	test   %rbx,%rbx
   2e63f:	0f 84 92 03 00 00    	je     2e9d7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xad7>
   2e645:	48 85 d2             	test   %rdx,%rdx
   2e648:	0f 84 89 03 00 00    	je     2e9d7 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xad7>
   2e64e:	48 83 fb 10          	cmp    $0x10,%rbx
   2e652:	0f 92 c0             	setb   %al
   2e655:	48 85 f6             	test   %rsi,%rsi
   2e658:	0f 94 c1             	sete   %cl
   2e65b:	08 c1                	or     %al,%cl
   2e65d:	0f 84 98 03 00 00    	je     2e9fb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xafb>
   2e663:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e66a:	00 
   2e66b:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2e670:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e675:	48 8d 0c da          	lea    (%rdx,%rbx,8),%rcx
   2e679:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e67d:	f3 0f 7f 44 24 18    	movdqu %xmm0,0x18(%rsp)
   2e683:	31 d2                	xor    %edx,%edx
   2e685:	49 8d 04 d6          	lea    (%r14,%rdx,8),%rax
   2e689:	49 8d 34 d6          	lea    (%r14,%rdx,8),%rsi
   2e68d:	48 83 c6 08          	add    $0x8,%rsi
   2e691:	48 ff c2             	inc    %rdx
   2e694:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e69b:	00 00 00 00 00 
   2e6a0:	48 39 ce             	cmp    %rcx,%rsi
   2e6a3:	0f 84 95 03 00 00    	je     2ea3e <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb3e>
   2e6a9:	8b 3e                	mov    (%rsi),%edi
   2e6ab:	48 83 c6 08          	add    $0x8,%rsi
   2e6af:	3b 38                	cmp    (%rax),%edi
   2e6b1:	75 ed                	jne    2e6a0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x7a0>
   2e6b3:	48 39 da             	cmp    %rbx,%rdx
   2e6b6:	75 cd                	jne    2e685 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x785>
   2e6b8:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   2e6bd:	31 c9                	xor    %ecx,%ecx
   2e6bf:	e9 a6 03 00 00       	jmp    2ea6a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb6a>
   2e6c4:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e6cb:	72 65 61 
   2e6ce:	48 33 08             	xor    (%rax),%rcx
   2e6d1:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e6d5:	48 83 f0 64          	xor    $0x64,%rax
   2e6d9:	48 09 c8             	or     %rcx,%rax
   2e6dc:	0f 85 f9 03 00 00    	jne    2eadb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbdb>
   2e6e2:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2e6e9:	00 00 
   2e6eb:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e6ef:	48 89 04 24          	mov    %rax,(%rsp)
   2e6f3:	48 89 e0             	mov    %rsp,%rax
   2e6f6:	48 8b 04 24          	mov    (%rsp),%rax
   2e6fa:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e6fe:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e704:	48 85 c9             	test   %rcx,%rcx
   2e707:	0f 84 43 01 00 00    	je     2e850 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x950>
   2e70d:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e711:	4d 8d 24 ce          	lea    (%r14,%rcx,8),%r12
   2e715:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e71a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2e720:	41 8b 36             	mov    (%r14),%esi
   2e723:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e727:	48 89 df             	mov    %rbx,%rdi
   2e72a:	e8 41 70 00 00       	call   35770 <_RNvMso_NtCs32OFFUZglCs_4pbrs3mapINtB5_3MapllE10push_entryCsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e72f:	49 83 c6 08          	add    $0x8,%r14
   2e733:	4d 39 e6             	cmp    %r12,%r14
   2e736:	75 e8                	jne    2e720 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x820>
   2e738:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
   2e73d:	48 85 db             	test   %rbx,%rbx
   2e740:	0f 84 0a 01 00 00    	je     2e850 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x950>
   2e746:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
   2e74a:	4c 8b 63 10          	mov    0x10(%rbx),%r12
   2e74e:	4d 85 e4             	test   %r12,%r12
   2e751:	0f 84 f2 02 00 00    	je     2ea49 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb49>
   2e757:	49 83 fc 10          	cmp    $0x10,%r12
   2e75b:	0f 82 f4 00 00 00    	jb     2e855 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x955>
   2e761:	4c 8d 6b 18          	lea    0x18(%rbx),%r13
   2e765:	8b 43 38             	mov    0x38(%rbx),%eax
   2e768:	85 c0                	test   %eax,%eax
   2e76a:	0f 84 e8 00 00 00    	je     2e858 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x958>
   2e770:	4c 89 ef             	mov    %r13,%rdi
   2e773:	4c 89 fe             	mov    %r15,%rsi
   2e776:	4c 89 e2             	mov    %r12,%rdx
   2e779:	e8 55 ac ff ff       	call   293d3 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs32OFFUZglCs_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e77e:	e9 d5 00 00 00       	jmp    2e858 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x958>
   2e783:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e78a:	63 6f 6c 
   2e78d:	48 33 08             	xor    (%rax),%rcx
   2e790:	8b 40 08             	mov    0x8(%rax),%eax
   2e793:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e799:	48 09 c8             	or     %rcx,%rax
   2e79c:	0f 85 39 03 00 00    	jne    2eadb <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xbdb>
   2e7a2:	48 85 d2             	test   %rdx,%rdx
   2e7a5:	41 be 04 00 00 00    	mov    $0x4,%r14d
   2e7ab:	4c 0f 45 f2          	cmovne %rdx,%r14
   2e7af:	48 0f 44 da          	cmove  %rdx,%rbx
   2e7b3:	31 c0                	xor    %eax,%eax
   2e7b5:	48 85 db             	test   %rbx,%rbx
   2e7b8:	74 19                	je     2e7d3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x8d3>
   2e7ba:	48 85 f6             	test   %rsi,%rsi
   2e7bd:	74 14                	je     2e7d3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x8d3>
   2e7bf:	48 83 fb 10          	cmp    $0x10,%rbx
   2e7c3:	72 0e                	jb     2e7d3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x8d3>
   2e7c5:	8b 46 20             	mov    0x20(%rsi),%eax
   2e7c8:	85 c0                	test   %eax,%eax
   2e7ca:	0f 85 3d 03 00 00    	jne    2eb0d <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xc0d>
   2e7d0:	48 89 f0             	mov    %rsi,%rax
   2e7d3:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e7da:	00 
   2e7db:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   2e7e0:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e7e5:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e7ea:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e7f1:	00 00 
   2e7f3:	48 8d 5c 24 30       	lea    0x30(%rsp),%rbx
   2e7f8:	48 89 e6             	mov    %rsp,%rsi
   2e7fb:	48 89 df             	mov    %rbx,%rdi
   2e7fe:	e8 0d 74 00 00       	call   35c10 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCs32OFFUZglCs_4pbrs3map11MapViewIterllEE9from_iterCsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e803:	48 83 7c 24 30 00    	cmpq   $0x0,0x30(%rsp)
   2e809:	0f 84 85 02 00 00    	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e80f:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2e814:	eb 2f                	jmp    2e845 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x945>
   2e816:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e81a:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e81f:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e824:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e828:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e82d:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e832:	48 89 e0             	mov    %rsp,%rax
   2e835:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e83a:	0f 84 54 02 00 00    	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e840:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e845:	ff 15 d5 3b 04 00    	call   *0x43bd5(%rip)        # 72420 <free@GLIBC_2.2.5>
   2e84b:	e9 44 02 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e850:	45 31 e4             	xor    %r12d,%r12d
   2e853:	31 db                	xor    %ebx,%ebx
   2e855:	45 31 ed             	xor    %r13d,%r13d
   2e858:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e85f:	00 
   2e860:	4c 8d 74 24 08       	lea    0x8(%rsp),%r14
   2e865:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e86a:	4c 89 64 24 10       	mov    %r12,0x10(%rsp)
   2e86f:	4c 89 6c 24 18       	mov    %r13,0x18(%rsp)
   2e874:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e87b:	00 00 
   2e87d:	45 31 ff             	xor    %r15d,%r15d
   2e880:	4c 8b 25 91 3f 04 00 	mov    0x43f91(%rip),%r12        # 72818 <_DYNAMIC+0x5f0>
   2e887:	31 c0                	xor    %eax,%eax
   2e889:	eb 20                	jmp    2e8ab <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x9ab>
   2e88b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e890:	48 8d 50 04          	lea    0x4(%rax),%rdx
   2e894:	8b 08                	mov    (%rax),%ecx
   2e896:	8b 02                	mov    (%rdx),%eax
   2e898:	48 63 c9             	movslq %ecx,%rcx
   2e89b:	4c 89 fa             	mov    %r15,%rdx
   2e89e:	48 01 ca             	add    %rcx,%rdx
   2e8a1:	4c 63 f8             	movslq %eax,%r15
   2e8a4:	49 01 d7             	add    %rdx,%r15
   2e8a7:	48 8b 04 24          	mov    (%rsp),%rax
   2e8ab:	48 83 f8 01          	cmp    $0x1,%rax
   2e8af:	75 3f                	jne    2e8f0 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x9f0>
   2e8b1:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e8b6:	48 3b 54 24 20       	cmp    0x20(%rsp),%rdx
   2e8bb:	0f 83 e8 00 00 00    	jae    2e9a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e8c1:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e8c6:	48 8d 3c 52          	lea    (%rdx,%rdx,2),%rdi
   2e8ca:	44 8b 04 be          	mov    (%rsi,%rdi,4),%r8d
   2e8ce:	8b 4c be 04          	mov    0x4(%rsi,%rdi,4),%ecx
   2e8d2:	8b 44 be 08          	mov    0x8(%rsi,%rdi,4),%eax
   2e8d6:	c7 04 be 00 00 00 00 	movl   $0x0,(%rsi,%rdi,4)
   2e8dd:	48 ff c2             	inc    %rdx
   2e8e0:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2e8e5:	41 83 f8 01          	cmp    $0x1,%r8d
   2e8e9:	74 ad                	je     2e898 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x998>
   2e8eb:	e9 b9 00 00 00       	jmp    2e9a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e8f0:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e8f5:	48 85 f6             	test   %rsi,%rsi
   2e8f8:	74 3b                	je     2e935 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa35>
   2e8fa:	48 8b 46 10          	mov    0x10(%rsi),%rax
   2e8fe:	48 3b 44 24 10       	cmp    0x10(%rsp),%rax
   2e903:	0f 85 91 00 00 00    	jne    2e99a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa9a>
   2e909:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e90e:	48 39 c1             	cmp    %rax,%rcx
   2e911:	0f 83 92 00 00 00    	jae    2e9a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e917:	48 8b 54 24 08       	mov    0x8(%rsp),%rdx
   2e91c:	48 8d 04 ca          	lea    (%rdx,%rcx,8),%rax
   2e920:	48 8d 14 ca          	lea    (%rdx,%rcx,8),%rdx
   2e924:	48 83 c2 04          	add    $0x4,%rdx
   2e928:	48 ff c1             	inc    %rcx
   2e92b:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e930:	e9 5f ff ff ff       	jmp    2e894 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x994>
   2e935:	48 8b 54 24 10       	mov    0x10(%rsp),%rdx
   2e93a:	48 8b 4c 24 20       	mov    0x20(%rsp),%rcx
   2e93f:	48 39 d1             	cmp    %rdx,%rcx
   2e942:	73 65                	jae    2e9a9 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e944:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e949:	48 8d 04 cd 00 00 00 	lea    0x0(,%rcx,8),%rax
   2e950:	00 
   2e951:	48 8d 3c ce          	lea    (%rsi,%rcx,8),%rdi
   2e955:	48 83 c7 08          	add    $0x8,%rdi
   2e959:	4c 8d 04 d5 00 00 00 	lea    0x0(,%rdx,8),%r8
   2e960:	00 
   2e961:	49 29 c0             	sub    %rax,%r8
   2e964:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e968:	48 8d 04 ce          	lea    (%rsi,%rcx,8),%rax
   2e96c:	48 ff c1             	inc    %rcx
   2e96f:	48 39 d1             	cmp    %rdx,%rcx
   2e972:	0f 84 13 ff ff ff    	je     2e88b <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x98b>
   2e978:	44 8b 08             	mov    (%rax),%r9d
   2e97b:	45 31 d2             	xor    %r10d,%r10d
   2e97e:	66 90                	xchg   %ax,%ax
   2e980:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e984:	74 0e                	je     2e994 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa94>
   2e986:	49 83 c2 08          	add    $0x8,%r10
   2e98a:	4d 39 d0             	cmp    %r10,%r8
   2e98d:	75 f1                	jne    2e980 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa80>
   2e98f:	e9 f7 fe ff ff       	jmp    2e88b <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x98b>
   2e994:	48 83 c7 08          	add    $0x8,%rdi
   2e998:	eb ca                	jmp    2e964 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xa64>
   2e99a:	4c 89 f7             	mov    %r14,%rdi
   2e99d:	41 ff d4             	call   *%r12
   2e9a0:	48 85 c0             	test   %rax,%rax
   2e9a3:	0f 85 eb fe ff ff    	jne    2e894 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x994>
   2e9a9:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e9ae:	74 13                	je     2e9c3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xac3>
   2e9b0:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e9b6:	74 0b                	je     2e9c3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xac3>
   2e9b8:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e9bd:	ff 15 5d 3a 04 00    	call   *0x43a5d(%rip)        # 72420 <free@GLIBC_2.2.5>
   2e9c3:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e9c7:	48 89 e0             	mov    %rsp,%rax
   2e9ca:	48 89 df             	mov    %rbx,%rdi
   2e9cd:	e8 6e b8 ff ff       	call   2a240 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs32OFFUZglCs_4pbrs3map3MapllEECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2e9d2:	e9 bd 00 00 00       	jmp    2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2e9d7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e9de:	00 
   2e9df:	4c 89 74 24 08       	mov    %r14,0x8(%rsp)
   2e9e4:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e9e8:	f3 0f 7f 44 24 10    	movdqu %xmm0,0x10(%rsp)
   2e9ee:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e9f5:	00 00 
   2e9f7:	31 c9                	xor    %ecx,%ecx
   2e9f9:	eb 6f                	jmp    2ea6a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb6a>
   2e9fb:	8b 46 20             	mov    0x20(%rsi),%eax
   2e9fe:	85 c0                	test   %eax,%eax
   2ea00:	0f 85 20 01 00 00    	jne    2eb26 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xc26>
   2ea06:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2ea0d:	00 
   2ea0e:	48 89 54 24 08       	mov    %rdx,0x8(%rsp)
   2ea13:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2ea18:	48 89 74 24 18       	mov    %rsi,0x18(%rsp)
   2ea1d:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2ea24:	00 00 
   2ea26:	48 39 5e 10          	cmp    %rbx,0x10(%rsi)
   2ea2a:	75 25                	jne    2ea51 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb51>
   2ea2c:	48 83 c2 04          	add    $0x4,%rdx
   2ea30:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2ea37:	00 00 
   2ea39:	4c 89 f0             	mov    %r14,%rax
   2ea3c:	eb 23                	jmp    2ea61 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb61>
   2ea3e:	48 89 54 24 20       	mov    %rdx,0x20(%rsp)
   2ea43:	48 8d 50 04          	lea    0x4(%rax),%rdx
   2ea47:	eb 18                	jmp    2ea61 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb61>
   2ea49:	45 31 e4             	xor    %r12d,%r12d
   2ea4c:	e9 04 fe ff ff       	jmp    2e855 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x955>
   2ea51:	48 8d 7c 24 08       	lea    0x8(%rsp),%rdi
   2ea56:	ff 15 bc 3d 04 00    	call   *0x43dbc(%rip)        # 72818 <_DYNAMIC+0x5f0>
   2ea5c:	48 85 c0             	test   %rax,%rax
   2ea5f:	74 42                	je     2eaa3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xba3>
   2ea61:	8b 30                	mov    (%rax),%esi
   2ea63:	8b 02                	mov    (%rdx),%eax
   2ea65:	b9 01 00 00 00       	mov    $0x1,%ecx
   2ea6a:	89 4c 24 30          	mov    %ecx,0x30(%rsp)
   2ea6e:	89 74 24 34          	mov    %esi,0x34(%rsp)
   2ea72:	89 44 24 38          	mov    %eax,0x38(%rsp)
   2ea76:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2ea7b:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2ea80:	74 12                	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2ea82:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2ea88:	74 0a                	je     2ea94 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb94>
   2ea8a:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2ea8f:	e9 b1 fd ff ff       	jmp    2e845 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x945>
   2ea94:	48 83 c4 78          	add    $0x78,%rsp
   2ea98:	5b                   	pop    %rbx
   2ea99:	41 5c                	pop    %r12
   2ea9b:	41 5d                	pop    %r13
   2ea9d:	41 5e                	pop    %r14
   2ea9f:	41 5f                	pop    %r15
   2eaa1:	5d                   	pop    %rbp
   2eaa2:	c3                   	ret
   2eaa3:	31 c9                	xor    %ecx,%ecx
   2eaa5:	eb c3                	jmp    2ea6a <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb6a>
   2eaa7:	48 8d 3d c6 a8 fd ff 	lea    -0x2573a(%rip),%rdi        # 9374 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2eaae:	48 8d 15 13 1f 04 00 	lea    0x41f13(%rip),%rdx        # 709c8 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x738>
   2eab5:	be 28 00 00 00       	mov    $0x28,%esi
   2eaba:	ff 15 20 3b 04 00    	call   *0x43b20(%rip)        # 725e0 <_DYNAMIC+0x3b8>
   2eac0:	49 89 fe             	mov    %rdi,%r14
   2eac3:	ff 15 6f 3d 04 00    	call   *0x43d6f(%rip)        # 72838 <_DYNAMIC+0x610>
   2eac9:	4c 89 f7             	mov    %r14,%rdi
   2eacc:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2ead1:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2ead6:	e9 cb f5 ff ff       	jmp    2e0a6 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2eadb:	48 8d 3d 92 a8 fd ff 	lea    -0x2576e(%rip),%rdi        # 9374 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2eae2:	48 8d 15 f7 1e 04 00 	lea    0x41ef7(%rip),%rdx        # 709e0 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   2eae9:	be 28 00 00 00       	mov    $0x28,%esi
   2eaee:	ff 15 ec 3a 04 00    	call   *0x43aec(%rip)        # 725e0 <_DYNAMIC+0x3b8>
   2eaf4:	48 89 f7             	mov    %rsi,%rdi
   2eaf7:	49 89 f6             	mov    %rsi,%r14
   2eafa:	4c 89 fe             	mov    %r15,%rsi
   2eafd:	48 89 da             	mov    %rbx,%rdx
   2eb00:	e8 ce a8 ff ff       	call   293d3 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs32OFFUZglCs_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2eb05:	4c 89 f0             	mov    %r14,%rax
   2eb08:	e9 45 f8 ff ff       	jmp    2e352 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x452>
   2eb0d:	48 89 f7             	mov    %rsi,%rdi
   2eb10:	49 89 f7             	mov    %rsi,%r15
   2eb13:	4c 89 f6             	mov    %r14,%rsi
   2eb16:	48 89 da             	mov    %rbx,%rdx
   2eb19:	e8 b5 a8 ff ff       	call   293d3 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs32OFFUZglCs_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2eb1e:	4c 89 f8             	mov    %r15,%rax
   2eb21:	e9 ad fc ff ff       	jmp    2e7d3 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0x8d3>
   2eb26:	48 89 f7             	mov    %rsi,%rdi
   2eb29:	49 89 f7             	mov    %rsi,%r15
   2eb2c:	48 89 d6             	mov    %rdx,%rsi
   2eb2f:	49 89 d4             	mov    %rdx,%r12
   2eb32:	48 89 da             	mov    %rbx,%rdx
   2eb35:	e8 99 a8 ff ff       	call   293d3 <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCs32OFFUZglCs_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2eb3a:	4c 89 e2             	mov    %r12,%rdx
   2eb3d:	4c 89 fe             	mov    %r15,%rsi
   2eb40:	e9 c1 fe ff ff       	jmp    2ea06 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xb06>
   2eb45:	49 89 c6             	mov    %rax,%r14
   2eb48:	eb 6b                	jmp    2ebb5 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcb5>
   2eb4a:	eb 1f                	jmp    2eb6b <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xc6b>
   2eb4c:	49 89 c6             	mov    %rax,%r14
   2eb4f:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2eb54:	74 5f                	je     2ebb5 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcb5>
   2eb56:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2eb5c:	74 57                	je     2ebb5 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcb5>
   2eb5e:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2eb63:	ff 15 b7 38 04 00    	call   *0x438b7(%rip)        # 72420 <free@GLIBC_2.2.5>
   2eb69:	eb 4a                	jmp    2ebb5 <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcb5>
   2eb6b:	49 89 c6             	mov    %rax,%r14
   2eb6e:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2eb73:	74 48                	je     2ebbd <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcbd>
   2eb75:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2eb7b:	74 40                	je     2ebbd <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcbd>
   2eb7d:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2eb82:	ff 15 98 38 04 00    	call   *0x43898(%rip)        # 72420 <free@GLIBC_2.2.5>
   2eb88:	4c 89 f7             	mov    %r14,%rdi
   2eb8b:	e8 60 00 04 00       	call   6ebf0 <_Unwind_Resume@plt>
   2eb90:	49 89 c6             	mov    %rax,%r14
   2eb93:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2eb98:	74 23                	je     2ebbd <_RNCNvCsjJa5ahoXGFc_24pbrs_map_iteration_proof4mains1_0B3_+0xcbd>
   2eb9a:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2eb9f:	ff 15 7b 38 04 00    	call   *0x4387b(%rip)        # 72420 <free@GLIBC_2.2.5>
   2eba5:	4c 89 f7             	mov    %r14,%rdi
   2eba8:	e8 43 00 04 00       	call   6ebf0 <_Unwind_Resume@plt>
   2ebad:	49 89 c6             	mov    %rax,%r14
   2ebb0:	48 8b 5c 24 30       	mov    0x30(%rsp),%rbx
   2ebb5:	48 89 df             	mov    %rbx,%rdi
   2ebb8:	e8 83 b6 ff ff       	call   2a240 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCs32OFFUZglCs_4pbrs3map3MapllEECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2ebbd:	4c 89 f7             	mov    %r14,%rdi
   2ebc0:	e8 2b 00 04 00       	call   6ebf0 <_Unwind_Resume@plt>
   2ebc5:	ff 15 fd 38 04 00    	call   *0x438fd(%rip)        # 724c8 <_DYNAMIC+0x2a0>
   2ebcb:	49 89 c6             	mov    %rax,%r14
   2ebce:	48 8b 3c 24          	mov    (%rsp),%rdi
   2ebd2:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2ebd7:	e8 64 b8 ff ff       	call   2a440 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECsjJa5ahoXGFc_24pbrs_map_iteration_proof>
   2ebdc:	4c 89 f7             	mov    %r14,%rdi
   2ebdf:	e8 0c 00 04 00       	call   6ebf0 <_Unwind_Resume@plt>
