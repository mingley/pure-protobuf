import argparse,gzip,hashlib,importlib.util,itertools,json,os,platform,random,subprocess
from pathlib import Path
from types import SimpleNamespace
ROOT=Path('/workspace/pure-protobuf')
spec=importlib.util.spec_from_file_location('smoke',ROOT/'scripts/grpc-load-smoke.py')
smoke=importlib.util.module_from_spec(spec);spec.loader.exec_module(smoke)
p=argparse.ArgumentParser();p.add_argument('--count',type=int,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
binary=ROOT/'work/matrix-release-final/rpc-bench';build_path=binary.parent/'build.json'
build=smoke.verified_build(build_path,binary)
a.output=a.output.resolve();a.output.mkdir(exist_ok=False)
pairs=[['native','pbrs','tonic','prost'],['native','prost','tonic','prost'],['tonic','prost','native','pbrs'],['tonic','prost','native','prost'],['tonic','prost','tonic','prost']]
cells=[dict(pair=pair,shape=shape,payload_bytes=1024,tls=False,compression='identity',connections=1,in_flight=1,repeat=repeat) for pair,shape,repeat in itertools.product(pairs,smoke.SHAPES,range(3))]
random.Random(20261008).shuffle(cells)
valgrind=ROOT/'work/toolchain/valgrind/usr/bin/valgrind'
args=SimpleNamespace(binary=binary,duration=60,rpc_count=a.count,allocation_counts=True,callgrind=valgrind)
report=dict(schema='pbrs.load-smoke.v2',binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),head=build['source']['commit'],dirty=False,source_verified=True,build_record=build,host=platform.uname()._asdict(),clock_ticks_per_second=os.sysconf('SC_CLK_TCK'),cpu_affinity=sorted(os.sched_getaffinity(0)),seed=20261008,duration_per_cell_seconds=60,cells=cells,rpc_count=a.count,allocation_counts=True,callgrind=str(valgrind),tool_version=subprocess.check_output([str(valgrind),'--version'],text=True).strip(),qualification=dict(qualified=False,limits=['shared host; ptrace-free Callgrind instrumentation; no native CPU/RSS or wall-time claim','process startup/handshake included; N/2N differential requires paired captures','one KiB h2c identity at concurrency one; other matrix cells not run','task wakeups, context switches and syscalls not measured']),runs=[])
(a.output/'runner.py').write_bytes(Path(__file__).read_bytes())
(a.output/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
for i,cell in enumerate(cells):
    run=smoke.run_cell(args,cell,a.output/f'cell-{i:03d}')
    report['runs'].append(dict(path=f'cell-{i:03d}/run.json',passed=run['passed']))
    for profile in (a.output/f'cell-{i:03d}').glob('*.callgrind'):
        with profile.open('rb') as source, gzip.open(str(profile)+'.gz','wb') as target:
            target.write(source.read())
        profile.unlink()
    print(f'{i+1}/{len(cells)}: {"passed" if run["passed"] else run.get("error")}',flush=True)
report['binary_unchanged']=report['binary_sha256']==hashlib.sha256(binary.read_bytes()).hexdigest()
smoke.verified_build(build_path,binary)
report['source_unchanged']=True
report['passed']=report['binary_unchanged'] and all(r['passed'] for r in report['runs'])
(a.output/'report.json').write_text(json.dumps(report,indent=2)+'\n')
raise SystemExit(0 if report['passed'] else 1)
