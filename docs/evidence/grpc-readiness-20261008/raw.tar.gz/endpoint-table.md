| Side / codec | Shape | Instructions vs tonic | Allocations vs tonic | Requested bytes vs tonic |
|---|---|---:|---:|---:|
| client / pbrs | bidi | 1.097× | 1.003× | 0.779× |
| client / pbrs | bidi_pipelined | 0.947× | 0.984× | 0.864× |
| client / pbrs | client_stream | 1.118× | 0.538× | 0.856× |
| client / pbrs | server_stream | 1.049× | 0.646× | 0.768× |
| client / pbrs | unary | 0.973× | 0.463× | 0.733× |
| client / prost | bidi | 1.105× | 0.808× | 1.387× |
| client / prost | bidi_pipelined | 0.966× | 0.789× | 1.437× |
| client / prost | client_stream | 1.148× | 0.635× | 1.161× |
| client / prost | server_stream | 1.034× | 0.528× | 0.821× |
| client / prost | unary | 0.980× | 0.409× | 0.777× |
| server / pbrs | bidi | 1.278× | 1.177× | 2.073× |
| server / pbrs | bidi_pipelined | 1.343× | 1.168× | 2.157× |
| server / pbrs | client_stream | 1.502× | 0.807× | 1.267× |
| server / pbrs | server_stream | 1.518× | 0.934× | 1.814× |
| server / pbrs | unary | 1.474× | 0.704× | 1.213× |
| server / prost | bidi | invalid repeat | invalid repeat | invalid repeat |
| server / prost | bidi_pipelined | 1.226× | 0.893× | 1.599× |
| server / prost | client_stream | 1.363× | 0.677× | 1.123× |
| server / prost | server_stream | 1.418× | 0.845× | 1.637× |
| server / prost | unary | 1.366× | 0.624× | 1.175× |
