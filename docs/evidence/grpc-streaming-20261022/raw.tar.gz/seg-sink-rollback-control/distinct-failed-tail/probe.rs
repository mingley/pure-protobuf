
fn encode_message(sink: &mut SegSink, shared: bool, fail: bool) -> Result<(), ()> {
    let length = if shared { 34 } else { 8 };
    sink.put_slice(&[0, 0, 0, 0, length]);
    sink.put_slice(b"start");
    if shared {
        sink.put_shared(&Bytes::from_static(b"shared-one"));
        sink.put_slice(b"middle");
        sink.put_shared(&Bytes::from_static(b"shared-two"));
    }
    sink.put_slice(if fail { b"bad" } else { b"end" });
    if fail { Err(()) } else { Ok(()) }
}
fn expected_frame(shared: bool) -> Vec<u8> {
    let payload: &[u8] = if shared { b"startshared-onemiddleshared-twoend" } else { b"startend" };
    let mut bytes = vec![0];
    bytes.extend_from_slice(&u32::try_from(payload.len()).unwrap().to_be_bytes());
    bytes.extend_from_slice(payload);
    bytes
}
fn preserves_prior_frames(prior_shared: bool) {
    let mut sink = SegSink::new();
    encode_message(&mut sink, false, false).unwrap();
    encode_message(&mut sink, prior_shared, false).unwrap();
    let checkpoint = sink.checkpoint();
    assert!(encode_message(&mut sink, true, true).is_err());
    sink.rollback(&checkpoint);
    encode_message(&mut sink, false, false).unwrap();
    let frame = sink.finish();
    let mut actual = frame.first.to_vec();
    for part in &frame.rest { actual.extend_from_slice(part); }
    let mut expected = expected_frame(false);
    expected.extend(expected_frame(prior_shared));
    expected.extend(expected_frame(false));
    assert_eq!(actual, expected, "rollback must preserve prior frames before a later valid frame");
    assert_eq!(frame.total_len, actual.len());
}
#[test] fn preserves_prior_contiguous_frames() { preserves_prior_frames(false); }
#[test] fn preserves_prior_shared_frames() { preserves_prior_frames(true); }
