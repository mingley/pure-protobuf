pub(crate) struct SegSink {
    head: BytesMut,
    segs: Vec<Bytes>,
    total_len: usize,
    shared_len: usize,
}

/// Rollback point for a failed message encode inside a batch.
pub(crate) struct SinkCheckpoint {
    segs: usize,
    head: usize,
    total_len: usize,
    shared_len: usize,
}

impl SegSink {
    pub(crate) fn new() -> Self {
        Self {
            head: BytesMut::new(),
            segs: Vec::new(),
            total_len: 0,
            shared_len: 0,
        }
    }

    pub(crate) fn reserve(&mut self, n: usize) {
        self.head.reserve(n);
    }

    /// First buffer for a frame. An empty head has nothing to preserve, so
    /// this allocates the `Vec` directly instead of going through `reserve`.
    pub(crate) fn reserve_new(&mut self, n: usize) {
        if self.head.capacity() == 0 {
            self.head = BytesMut::with_capacity(n);
        } else {
            self.head.reserve(n);
        }
    }

    /// Total bytes sunk so far (copied + shared).
    pub(crate) fn len(&self) -> usize {
        self.total_len
    }

    pub(crate) fn is_empty(&self) -> bool {
        self.total_len == 0
    }

    /// Bytes retained as shared segments (never copied).
    pub(crate) fn shared_len(&self) -> usize {
        self.shared_len
    }

    /// New segments since a checkpoint, plus the live head tail.
    pub(crate) fn segments_since(
        &self,
        cp: &SinkCheckpoint,
    ) -> (impl Iterator<Item = &Bytes>, &[u8]) {
        let segs = self.segs.get(cp.segs..).unwrap_or(&[]);
        (segs.iter(), self.head.get(cp.head..).unwrap_or_default())
    }

    /// Direct access to the live head for the compressed path, which must
    /// patch its length prefix after encoding.
    pub(crate) fn head_mut(&mut self) -> &mut BytesMut {
        &mut self.head
    }

    /// Bytes appended straight to the head (compressed path bypass).
    pub(crate) fn note_head_wrote(&mut self, n: usize) {
        self.total_len += n;
    }

    pub(crate) fn checkpoint(&self) -> SinkCheckpoint {
        SinkCheckpoint {
            segs: self.segs.len(),
            head: self.head.len(),
            total_len: self.total_len,
            shared_len: self.shared_len,
        }
    }

    pub(crate) fn rollback(&mut self, cp: &SinkCheckpoint) {
        self.segs.truncate(cp.segs);
        self.head.truncate(cp.head);
        self.total_len = cp.total_len;
        self.shared_len = cp.shared_len;
    }

    fn freeze_head(&mut self) {
        if !self.head.is_empty() {
            self.segs.push(std::mem::take(&mut self.head).freeze());
        }
    }

    pub(crate) fn finish(mut self) -> SegFrame {
        if self.segs.is_empty() {
            // Fast path: nothing was ever shared, so the head is the whole
            // frame and no segment Vec was ever allocated.
            let first = std::mem::take(&mut self.head).freeze();
            let total_len = first.len();
            // `Vec::new` and `BytesMut::new` own no heap. Dropping them is a
            // kind check and a capacity check on every frame.
            if self.segs.capacity() == 0 {
                std::mem::forget(self);
            }
            return SegFrame {
                first,
                rest: Vec::new(),
                total_len,
            };
        }
        self.freeze_head();
        let mut segs = self.segs.into_iter();
        let first = segs.next().unwrap_or_default();
        let rest: Vec<Bytes> = segs.collect();
        let total_len = first.len() + rest.iter().map(Bytes::len).sum::<usize>();
        SegFrame {
            first,
            rest,
            total_len,
        }
    }
}

impl WireOut for SegSink {
    fn put_u8(&mut self, b: u8) {
        BufMut::put_u8(&mut self.head, b);
        self.total_len += 1;
    }

    fn put_slice(&mut self, data: &[u8]) {
        BufMut::put_slice(&mut self.head, data);
        self.total_len += data.len();
    }

    fn write_contiguous<R>(&mut self, write: impl FnOnce(&mut BytesMut) -> R) -> R {
        let before = self.head.len();
        let result = write(&mut self.head);
        self.total_len += self.head.len() - before;
        result
    }

    fn put_shared(&mut self, b: &Bytes) {
        crate::copy_counts::note_shared(b.len());
        self.freeze_head();
        self.total_len += b.len();
        self.shared_len += b.len();
        self.segs.push(b.clone());
    }

    fn supports_shared(&self) -> bool {
        true
    }
}

