#[derive(Clone, Debug)]
pub(crate) struct SegFrame {
    first: Bytes,
    rest: Vec<Bytes>,
    total_len: usize,
}
