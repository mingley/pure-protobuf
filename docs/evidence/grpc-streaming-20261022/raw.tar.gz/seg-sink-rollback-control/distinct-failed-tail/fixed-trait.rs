pub trait WireOut {
    fn put_u8(&mut self, b: u8);
    fn put_slice(&mut self, data: &[u8]);

    #[inline]
    fn push(&mut self, b: u8) {
        self.put_u8(b);
    }

    #[inline]
    fn extend_from_slice(&mut self, data: &[u8]) {
        self.put_slice(data);
    }

    /// Hand a large field buffer to the sink without copying. The default
    /// copies, so every existing sink (and old generated code, which never
    /// calls this) behaves exactly as before. Segmented sinks override it to
    /// retain `b` and emit it as its own segment (PK-11).
    #[inline]
    fn put_shared(&mut self, b: &Bytes) {
        self.put_slice(b);
    }

    /// Whether `put_shared` retains without copying. Sinks that override
    /// `put_shared` must override this to `true`; the default `false`
    /// keeps callers from paying for a shareable handle (e.g. a `Bytes`
    /// clone, which can promote a unique buffer) that would only be
    /// copied back out.
    #[inline]
    fn supports_shared(&self) -> bool {
        false
    }

    /// Run `write` against a contiguous buffer that becomes part of this sink.
    ///
    /// The default encodes into a temporary buffer and copies it in. Sinks
    /// that already have a `BytesMut` override this and skip that copy.
    #[inline]
    fn write_contiguous<R>(&mut self, write: impl FnOnce(&mut BytesMut) -> R) -> R {
        let mut buf = BytesMut::new();
        let result = write(&mut buf);
        self.put_slice(&buf);
        result
    }
}

