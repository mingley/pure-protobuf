# Handler cancellation probe controls

`normal.rs` contains the new pending handler, entry notification, and destruction guard. `retained-handler.rs` deliberately detaches a child task holding that guard. Dropping the RPC cannot destroy this retained child, so the destruction acknowledgement must time out.

To replay either fixture in the recorded checkout, copy it to `pbrs-grpc/tests/handler_liveness_control.rs` and run:

```sh
cargo test --locked -p pbrs-grpc --all-features --test handler_liveness_control -- --nocapture
```

Remove that temporary target afterward. The retained-handler run is expected to fail; the normal run is expected to pass all four call shapes with both Call drop and CallHandle cancellation over FromIo.

The shipped serving tests exercise the same fixture over TCP, TLS, mutual TLS, Unix sockets, and FromIo. A one-second startup watchdog bounds waiting for explicit handler entry. After entry, the existing 250 ms cancellation bound now requires actual destruction of the handler future. No production timeout or protocol behavior changes.

The earlier 40 ms timer inferred handler entry from elapsed time and the old finished counter inferred destruction from absence of completion after a 200 ms sleep. The new acknowledgements test both events directly. The two reported failures passed three quiet replays each against the frozen 8fe0f8ae binary, so these controls do not establish a production transport defect or a production latency result.

`source-positive.patch` matches the positive run’s recorded tracked diff. The intermediate `source-between-controls.patch` does not match the repaired negative run’s diff because agents changed tracked source concurrently. The negative fixture itself is exact and hash-recorded; replay it against a frozen final checkout for source-pinned release evidence.
