//! Lifecycle fixture control.
#![allow(
    clippy::expect_used,
    clippy::unwrap_used,
    clippy::panic,
    reason = "external negative control"
)]
use pbrs_grpc::hello::{GreeterClient, GreeterServer, HelloReply, HelloRequest};
use pbrs_grpc::{Call, Channel, Code, Request, Response, Status};
use std::sync::Arc;
use std::time::Duration;
fn req(_name: &str) -> HelloRequest {
    HelloRequest::new()
}
fn duplex_pair() -> (tokio::io::DuplexStream, tokio::io::DuplexStream) {
    tokio::io::duplex(65536)
}
/// A pending handler that reports both entry and destruction.
#[derive(Default)]
struct HangState {
    started: tokio::sync::Notify,
    dropped: tokio::sync::Notify,
}

struct Hang {
    state: Arc<HangState>,
}

struct HangGuard<'a>(&'a tokio::sync::Notify);

impl Drop for HangGuard<'_> {
    fn drop(&mut self) {
        self.0.notify_one();
    }
}

impl Hang {
    async fn hang(&self) {
        // Negative control: dropping a JoinHandle leaves the child alive.
        // Its handler guard must therefore outlive the cancelled RPC.
        let state = Arc::clone(&self.state);
        tokio::spawn(async move {
            let _guard = HangGuard(&state.dropped);
            state.started.notify_one();
            std::future::pending::<()>().await;
        })
        .await
        .expect("retained handler");
    }
}

impl pbrs_grpc::Greeter for Hang {
    async fn say_hello(
        &self,
        request: Request<HelloRequest>,
    ) -> Result<Response<HelloReply>, Status> {
        self.hang().await;
        let mut reply = HelloReply::new();
        reply.set_message(request.get_ref().name());
        Ok(Response::new(reply))
    }

    async fn client_hello(
        &self,
        _request: Request<pbrs_grpc::Streaming<HelloRequest>>,
    ) -> Result<Response<HelloReply>, Status> {
        self.hang().await;
        Err(Status::internal("handler should have been dropped"))
    }

    async fn server_hello(
        &self,
        _request: Request<HelloRequest>,
    ) -> Result<Response<pbrs_grpc::Streaming<HelloReply>>, Status> {
        self.hang().await;
        Err(Status::internal("handler should have been dropped"))
    }

    async fn stream_hello(
        &self,
        _request: Request<pbrs_grpc::Streaming<HelloRequest>>,
    ) -> Result<Response<pbrs_grpc::Streaming<HelloReply>>, Status> {
        self.hang().await;
        Err(Status::internal("handler should have been dropped"))
    }
}

#[tokio::test(flavor = "multi_thread", worker_threads = 2)]
async fn from_io_hanging_handler_drops_on_call_drop_and_reset() {
    let state = Arc::new(HangState::default());
    let (client_io, server_io) = duplex_pair();
    let hang = Hang {
        state: Arc::clone(&state),
    };
    let server = tokio::spawn(async move {
        GreeterServer::new(hang)
            .serve_connection(server_io)
            .await
            .ok();
    });
    let client = GreeterClient::new(
        Channel::from_io(client_io, "localhost")
            .await
            .expect("from_io"),
    );
    assert_hang_drop_and_reset_on_every_shape(&client, &state).await;
    server.abort();
}

async fn wait_for_hanging_handler<T>(call: &mut Call<T>, state: &HangState) {
    // Entry is a lifecycle event, not a promise that dispatch takes less than
    // 40ms while hundreds of integration tests share the machine. Keep driving
    // the lazy Call until the handler itself acknowledges that it is pending.
    tokio::select! {
        biased;
        _ = call => panic!("Hang returned before cancellation"),
        () = state.started.notified() => {},
        () = tokio::time::sleep(Duration::from_secs(1)) => {
            panic!("handler should have started");
        }
    }
}

async fn assert_drop_call_drops_handler<T>(mut call: Call<T>, state: &HangState) {
    wait_for_hanging_handler(&mut call, state).await;
    drop(call);
    tokio::time::timeout(Duration::from_millis(250), state.dropped.notified())
        .await
        .expect("dropping the Call should RST the stream and destroy the handler");
}

async fn assert_reset_drops_handler<T>(mut call: Call<T>, state: &HangState) {
    wait_for_hanging_handler(&mut call, state).await;
    call.handle().cancel();
    tokio::time::timeout(Duration::from_millis(250), async {
        let err = match call.await {
            Ok(_) => panic!("cancelled Call resolved Ok"),
            Err(status) => status,
        };
        assert_eq!(err.code(), Code::Cancelled, "{err}");
        state.dropped.notified().await;
    })
    .await
    .expect("CallHandle cancel should RST the stream and destroy the handler");
}

async fn assert_hang_drop_and_reset_on_every_shape(client: &GreeterClient, state: &HangState) {
    assert_drop_call_drops_handler(client.say_hello(Request::new(req("ada"))), state).await;
    assert_drop_call_drops_handler(client.server_hello(Request::new(req("ada"))), state).await;
    let (tx, call) = client.client_hello(Request::new(()));
    assert_drop_call_drops_handler(call, state).await;
    drop(tx);
    let (tx, call) = client.stream_hello(Request::new(()));
    assert_drop_call_drops_handler(call, state).await;
    drop(tx);

    assert_reset_drops_handler(client.say_hello(Request::new(req("ada"))), state).await;
    assert_reset_drops_handler(client.server_hello(Request::new(req("ada"))), state).await;
    let (tx, call) = client.client_hello(Request::new(()));
    assert_reset_drops_handler(call, state).await;
    drop(tx);
    let (tx, call) = client.stream_hello(Request::new(()));
    assert_reset_drops_handler(call, state).await;
    drop(tx);
}
