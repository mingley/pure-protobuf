pub(super) fn decode_limited(payload: &[u8], limits: MessageLimits) -> Result<Vec<u8>, Status> {
    let budget = limits.inflate_budget();
    let read_cap = budget.saturating_add(1);
    let mut out = Vec::new();
    let mut decoder = ruzstd::decoding::StreamingDecoder::new(payload)
        .map_err(|e| Status::internal(format!("zstd decode: {e}")))?;
    let mut buf = [0u8; 8192];
    loop {
        let remaining = read_cap.saturating_sub(out.len());
        if remaining == 0 {
            return Err(Status::resource_exhausted(format!(
                "decompressed message exceeds limit {budget}"
            )));
        }
        let want = remaining.min(buf.len());
        let chunk = buf
            .get_mut(..want)
            .ok_or_else(|| Status::internal("zstd decode: short buffer"))?;
        let n = decoder
            .read(chunk)
            .map_err(|e| Status::internal(format!("zstd decode: {e}")))?;
        if n == 0 {
            return Ok(out);
        }
        let decoded = buf
            .get(..n)
            .ok_or_else(|| Status::internal("zstd decode: short buffer"))?;
        out.extend_from_slice(decoded);
        if out.len() > budget {
            return Err(Status::resource_exhausted(format!(
                "decompressed message exceeds limit {budget}"
            )));
        }
    }
}
