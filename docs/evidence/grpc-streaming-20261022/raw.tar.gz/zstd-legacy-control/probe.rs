mod limits {
    #[derive(Clone,Copy)]
    pub struct MessageLimits(pub usize);
    impl MessageLimits {
        pub fn inflate_budget(self)->usize { self.0 }
    }
}
mod status {
    #[derive(Debug)]
    pub struct Status { pub code: &'static str, pub message: String }
    impl Status {
        pub fn internal(message:impl Into<String>)->Self {Self{code:"INTERNAL",message:message.into()}}
        pub fn resource_exhausted(message:impl Into<String>)->Self {Self{code:"RESOURCE_EXHAUSTED",message:message.into()}}
    }
}
mod legacy {
    use crate::limits::MessageLimits;
    use crate::status::Status;
    use std::io::Read;
    include!("legacy-function.rs");
}
fn raw_frame(size:u8)->Vec<u8> {
    vec![0x28,0xb5,0x2f,0xfd,0x20,size,0x29,0x00,0x00,b'h',b'e',b'l',b'l',b'o']
}
fn main() {
    // Independent RFC 8878 raw single-segment frame for "hello".
    // XXH64("hello",0) low32 = 0x889f6da3.
    let good=vec![0x28,0xb5,0x2f,0xfd,0x24,0x05,0x29,0x00,0x00,b'h',b'e',b'l',b'l',b'o',0xa3,0x6d,0x9f,0x88];
    let mut bad=good.clone(); *bad.last_mut().expect("checksum")^=1;
    let cases=[("valid_checksum_and_size",good),("forged_checksum",bad),("declared_size_zero_actual_five",raw_frame(0)),("declared_size_four_actual_five",raw_frame(4)),("declared_size_six_actual_five",raw_frame(6))];
    for (name,frame) in cases {
        match legacy::decode_limited(&frame,limits::MessageLimits(4*1024*1024)) {
            Ok(output)=>{
                assert_eq!(output,b"hello","unexpected fixture output");
                println!("{{\"case\":\"{name}\",\"legacy_accepted\":true,\"decoded_bytes\":{},\"qualified\":false}}",output.len());
            },
            Err(error)=> {
                println!("{{\"case\":\"{name}\",\"legacy_accepted\":false,\"code\":\"{}\",\"message\":{:?},\"qualified\":false}}",error.code,error.message);
                assert!(name!="valid_checksum_and_size" && name!="forged_checksum" && name!="declared_size_six_actual_five","negative control did not reproduce original acceptance");
            }
        }
    }
}
