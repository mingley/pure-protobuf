# Next performance measurements

The final source is `6cd91911afce24cceee6df3f60a945453e5b04da`. Commands are in
`callgrind-streaming-c3-measurement-plan.json`. The release build, expanded
native campaign and four-capture Callgrind pilot have completed. Larger
instruction scopes have not run.

The native expansion has 2,400 captures: zero-filled 1 KiB and 64 KiB messages, one connection with
one or sixteen concurrent calls, all five shapes, identity/gzip over h2c/TLS,
three repeats and paired 200/400-call runs. The 600-capture 1 KiB/one-call subset
matches the earlier corrected campaign. The earlier candidate needed 140 seconds
for 600 captures. The expanded matrix completed in 563.89 seconds: all 2,400
captures passed, and retained client reports recorded 720,000 completed and
successful RPCs with no failures/timeouts/overflows/unstarted/unfinished calls.
The recent release build took eight minutes. Native captures include process-lifetime
`getrusage` voluntary/involuntary context-switch diagnostics alongside allocations
and requested bytes. Those noisy scheduling counts do not establish a qualified
scheduling improvement. Instructions, syscalls and task wakes are absent from
the native phase.

The Callgrind pilot has four captures: both sources, 50/100 calls, gzip
bidirectional streaming with a native pbrs server and tonic/prost client. The
full targeted matrix would have 360 captures; it has not run. The pilot passed
all four captures in 41.51 seconds, recording 300 successful RPCs across both
sources. Extrapolation suggests roughly an hour for 360 captures at 50/100 calls,
or 24 minutes for the 144-capture server subset. These are runtime estimates,
not performance measurements. The full target adds
h2c unary and pipelined bidirectional cases, identity/gzip, all five matched
pairs and three repeats. Both endpoints are instrumented. Instructions and
allocations are diagnostics; profiler CPU/wall time does not establish native
latency or throughput. Within this Callgrind phase, syscalls, context switches
and task wakes remain unrun; native-phase context-switch diagnostics are separate.

## What the 7be4f29d measurements suggest

These are allocation diagnostics, not speed claims. Values are medians of
three repeats for h2c, 1 KiB, one connection and one concurrent RPC.

| Server bidirectional case | Before allocations/RPC | After | tonic/prost |
|---|---:|---:|---:|
| gzip, native transport + prost | 107.03 | 88.13 | 94.00 |
| gzip, native transport + pbrs | 122.09 | 107.15 | 94.00 |
| identity, native transport + pbrs | 57.95 | 57.98 | 50.00 |

The gzip transport allocation loss is removed with prost. The largest remaining
byte cost is uncompressed bidirectional streaming: native/prost server requests
46.94 kB/RPC versus tonic's 33.74 kB (+39%); native/pbrs requests 66.37 kB (+97%).
These numbers count cumulative requested allocation bytes, including reallocs;
they are not peak or retained memory.

Investigate the fixed 64-item pump buffers and unconditional four-message
small-frame reservation first. Ping-pong flushes after each ready message, so
reserving four messages can allocate unused space repeatedly. Allocation stacks
and the expanded pipelined/concurrent cases must test that hypothesis before
changing the policy. Preserve backpressure, cancellation, fairness and message
caps while measuring fewer reservations or smaller initial pump capacity.

The pbrs codec/server comparison also includes handler differences. Its full
interop service checks metadata/status/interval/compression behavior and builds
a response-plan Vec for every incoming bidirectional message. The native/prost
and tonic benchmark handlers iterate response parameters directly. Their
transport comparison is closer; pbrs before/after remains valid, but its delta
against prost does not isolate codec overhead. Match handler behavior or obtain
allocation stacks before changing generated layouts. The actual bidirectional
request is StreamingOutputCallRequest, whose response_parameters and payload
live in a generated cold allocation; the response uses LazyMsg<Payload>.

Lazy nested fields validate input and parse again when accessed. Cold placement,
nested boxing, response-plan materialization and repeated response construction
are candidates for read-all measurements, not reasons to remove validation or
special-case benchmark schema names.

## Compression workspace reuse: later design work

Measure uncompressed buffer waste first. The gzip counter currently requests
roughly 1.6 MB per four-message streaming RPC even after the allocation-count
improvement. Repeated compressor construction is a possible later target.

The locked flate2 1.1.10 exposes `Compress::reset()`, documented as equivalent
to dropping and reconstructing its compression state. Reusing workspace must
still produce an independent compressed member for every gRPC message: reset
the dictionary and input/output counters, write a fresh wrapper/header, and
compute fresh CRC and length (or the zlib checksum). Never carry compression
history from one message to another. The current `GzEncoder` wrapper does not
expose a reusable-member reset, so using `Compress` directly would require a
careful framing implementation or a separately validated wrapper. Compression
level and wrapper configuration must also match; resetting does not provide
a general change-level API for the selected backend.

Putting a large compressor workspace on every stream could reduce allocation
counters while multiplying retained RSS by the number of idle calls. Today
compression is synchronous: worker threads hold transient workspaces while
encoding, rather than every idle stream retaining one. A cache must preserve
that distinction. Consider a small, explicitly bounded worker cache or a
budgeted pool after measuring construction cost. Bound cache entries and bytes;
avoid an expanding cache keyed by every level/configuration. A per-thread cap
alone also needs an explicit thread-count assumption or a process-wide budget.

Keep cache ownership scoped to synchronous encoding. Do not hold worker-local
borrows across awaits, expose raw pointers across task migration, or hold a
cache lock across user callbacks. Reentrant encoding needs a safe fallback.
Failed/cancelled writes must not leave state that contaminates the next member.

Required evidence before adopting reuse:

- Each message decodes independently with an external decoder, including empty,
  random and highly compressible messages and mixed supported configurations.
- Corrupt headers/trailers/checksums remain errors; failed writes followed by
  another encode cannot reuse a partial member or stale dictionary.
- Allocation requests and CPU work improve across message sizes without hiding
  retained memory in setup subtraction.
- Peak and idle RSS stay bounded as idle-call count, concurrent workers and
  executor/thread counts change. Report cache bytes separately from queued
  transport permits and rerun recovery/resource campaigns with the same caps.

No workspace-cache implementation is part of this candidate.


## Final matched measurements (22 October 2026)

The candidate and the old source each completed 2,400 native captures and
720,000 actual successful RPCs, with zero failed, timed out, unfinished or
undispatched calls. The matched expanded summaries supersede the older
600-capture baseline for final Before tables. Both campaigns cover 1 KiB and
64 KiB zero-filled payloads, h2c/TLS, identity/gzip, concurrency 1/16, all five
RPC shapes and the five existing implementation pairings. Gzip level is 6 on
both implementations. Allocation counts and requested allocation bytes are
available on both sides for every capture. Raw getrusage context switches are
available, but some N/2N deltas are nonpositive and remain partial. Native
instructions, syscalls and task wakeups were not collected.

The focused instruction diagnostic completed all 144 captures, retained 288
Callgrind profiles and completed 5,400 actual successful calls. It uses small
N=25/50 and only h2c 1 KiB server bidirectional/pipelined streams. The full
360-capture instruction matrix was not run. Identity server instructions are
lower than tonic in this scope, while all 12 current gzip instruction repeats
lose under the existing 2% diagnostic band. Gzip allocation gains therefore do
not establish CPU gains. All these results remain qualified=false.

Final analysis artifacts:

- counter-streaming-c3-baseline-expanded-summary.json (original report)
- counter-streaming-c3-baseline-expanded-all-counters.json (all metrics)
- counter-streaming-c3-expanded-all-counters.json (candidate, all metrics)
- callgrind-streaming-c3-matched-expanded-ab.json (1,920 matched median rows)
- callgrind-streaming-c3-matched-primary-tables.json (selected table rows)
- callgrind-streaming-c3-server-small-summary.json (instruction ranges)

The old and current native campaigns ran sequentially. Tonic controls are
retained separately; these are counter diagnostics, not latency or throughput
claims. Source-disposition counts use the literal direction of medians and can
include negligible changes; they are not significance tests.

### Next priorities, without another runtime change in this candidate

1. Investigate the new 64 KiB gzip requested-byte regression first. For h2c,
   concurrency 1, server client-streaming, pbrs rises from 1,405,994 to
   1,555,148 B/RPC (+10.61%) and prost from 1,667,217 to 1,816,373 B/RPC
   (+8.95%), while tonic remains 1,219,185. The same direction appears with
   TLS and concurrency 16. Server bidirectional prost rises 3.40%, and pbrs
   2.61%. The bounded output-growth policy, output sizes slightly beyond 64 KiB,
   serialized-payload scratch retention and output ownership need allocation
   stacks or narrow isolated controls. The combined source experiment cannot
   attribute the change to a single helper. Keep actual capacity within the
   decode budget and preserve checksum, overflow and cancellation behavior.
2. Measure identity reserve/pump waste. The 1 KiB prost server bidi still
   requests 46,935 B/RPC versus tonic 33,740 (+39%). The pbrs server requests
   66,370 (+97%). At 64 KiB the prost identity bidi request-byte total is
   approximately tied with tonic, whereas pbrs remains about 1.95 times tonic.
   That size-dependent difference argues for measured capacity/ownership
   changes instead of a universal larger buffer or per-stream cache.
3. Match pbrs handler semantics and obtain codec allocation stacks before
   changing generated layouts. Its full interop handler does additional work,
   so a pbrs/prost transport table does not isolate codec overhead.
4. Profile gzip CPU work after output allocation is understood. The focused
   current server gzip instruction cost is about 2.2-2.4% above tonic and about
   0.7% above the old source. Consider bounded worker workspace reuse only with
   independent message framing and measured idle RSS; no stream-wide unbounded
   compressor retention.
5. Complete the missing instruction/client/shape/payload matrix, controlled
   native timing, syscall/wakeup evidence and the actual 24-hour resource run.
   Small counter campaigns and focused instruction diagnostics do not prove
   production readiness or broad superiority.
