#!/usr/bin/env python3
"""Retain ranges, missing counters and failures from a small-N profiler campaign."""
import argparse
import collections
import itertools
import json
from pathlib import Path
import statistics

METRICS = ['instructions', 'allocations', 'requested_bytes', 'context_switches', 'syscalls', 'task_wakeups']
ACCOUNTING = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']


def spread(values):
    values = [x for x in values if x is not None]
    return dict(available=len(values), minimum=min(values) if values else None,
                median=statistics.median(values) if values else None,
                maximum=max(values) if values else None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    directory = args.campaign.resolve(strict=True)
    campaign = json.loads((directory / 'campaign.json').read_text())
    source_comparison = json.loads((directory / 'source-comparison.json').read_text())
    total, per_version, availability, failed = collections.Counter(), {}, {}, []
    ledgers, source_dispositions, ab_dispositions = {}, {}, collections.defaultdict(collections.Counter)
    for name in ('baseline', 'candidate'):
        counts, errors, raw_counters = collections.Counter(), collections.Counter(), collections.defaultdict(collections.Counter)
        captures = list((directory / name).glob('n-*/cell-*/run.json'))
        for path in captures:
            result = json.loads(path.read_text())
            for key in ACCOUNTING:
                value = result.get('metrics', {}).get(key)
                if type(value) is int and value >= 0:
                    counts[key] += value
            errors.update(result.get('metrics', {}).get('status_errors', {}))
            for side in ('client', 'server'):
                for metric, section in [('instructions', 'instruction_totals'), ('allocations', 'allocation_totals'),
                                        ('requested_bytes', 'allocation_totals'), ('context_switches', 'context_switch_totals'),
                                        ('syscalls', 'syscall_totals')]:
                    value = result.get(section, {}).get(side)
                    if value is not None and (metric not in ('allocations', 'requested_bytes') or metric in value):
                        raw_counters[side][metric] += 1
            if result.get('passed') is not True:
                failed.append(dict(path=str(path.relative_to(directory)), error=result.get('error')))
        total.update(counts)
        per_version[name] = dict(captures=len(captures), actual_rpc_totals=dict(counts), status_errors=dict(errors))
        availability[name] = {side: {metric: raw_counters[side].get(metric, 0) for metric in METRICS}
                              for side in ('client', 'server')}
        ledgers[name] = json.loads((directory / name / 'ledger.json').read_text())['rows']
        dispositions = collections.defaultdict(collections.Counter)
        for row in ledgers[name]:
            dispositions[f"{row['side']}:{row['metric']}"][row['disposition']] += 1
        source_dispositions[name] = {key: dict(value) for key, value in dispositions.items()}
    for row in source_comparison['rows']:
        category = 'native_server' if row['native_side'] else 'tonic_server_reference' if row['side'] == 'server' else 'tonic_client_peer'
        ab_dispositions[f"{category}:{row['metric']}"][row['disposition']] += 1
    table = []
    for codec, compression, shape in itertools.product(('pbrs', 'prost'), ('identity', 'gzip'), ('bidi', 'bidi_pipelined')):
        matching = {}
        for name in ledgers:
            matching[name] = {row['repeat']: row for row in ledgers[name]
                              if row['metric'] == 'instructions' and row['side'] == 'server'
                              and row['cell']['pair'][3] == codec and row['cell']['compression'] == compression
                              and row['cell']['shape'] == shape}
        row = dict(codec=codec, compression=compression, shape=shape, repeats_expected=3, qualified=False)
        for name in matching:
            rows = list(matching[name].values())
            row[f'{name}_native_instructions_per_rpc'] = spread(x['native_per_rpc'] for x in rows)
            row[f'{name}_tonic_instructions_per_rpc'] = spread(x['tonic_per_rpc'] for x in rows)
            row[f'{name}_native_over_tonic'] = spread(x['ratio'] for x in rows)
            row[f'{name}_repeat_dispositions'] = {str(x['repeat']): x['disposition'] for x in rows}
            row[f'{name}_failed_captures'] = [x for item in rows for x in item['failed_captures']]
        ratios = []
        for repeat in set(matching['baseline']) & set(matching['candidate']):
            before, after = matching['baseline'][repeat]['native_per_rpc'], matching['candidate'][repeat]['native_per_rpc']
            ratios.append(after / before if before is not None and after is not None else None)
        row['candidate_over_baseline'] = spread(ratios)
        row['status'] = ('complete_diagnostic' if row['candidate_over_baseline']['available'] == 3
                         and row['candidate_native_over_tonic']['available'] == 3 else 'partial_or_failed_diagnostic')
        table.append(row)
    profile_count = len(list(directory.glob('*/n-*/cell-*/*.callgrind.gz')))
    raw_capture_count = sum(row['captures'] for row in per_version.values())
    expected_rpc_calls = len(campaign['cells']) * sum(campaign['rpc_counts']) * len(campaign['versions'])
    result = dict(qualified=False, scope=campaign['scope'], small_n=campaign['small_n'],
                  source_pins=campaign['versions'], rpc_counts=campaign['rpc_counts'],
                  captures=len(campaign['captures']), expected_captures=campaign['expected_captures'],
                  passed=(campaign['passed'] and not failed and raw_capture_count == campaign['expected_captures']
                          and profile_count == 2 * raw_capture_count
                          and total['successful_rpcs'] == total['completed_rpcs'] == expected_rpc_calls),
                  raw_capture_count=raw_capture_count, expected_rpc_calls=expected_rpc_calls,
                  actual_rpc_totals=dict(total),
                  per_version=per_version, raw_counter_availability=availability,
                  raw_profile_gzip_files=profile_count, failed_captures=failed,
                  source_ledger_dispositions=source_dispositions,
                  source_ab_dispositions={key: dict(value) for key, value in ab_dispositions.items()},
                  instruction_table=table, instruction_band=.02, full360_status='NOT_RUN; scope gap retained',
                  limits=campaign['limits'] + ['three-repeat ranges retained; no qualified native speed ranking',
                       'before/current native and both tonic reference ranges are distinct',
                       'all nonpositive differentials and missing/failed rows stay unavailable'])
    with args.output.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ['qualified', 'small_n', 'captures', 'passed', 'actual_rpc_totals', 'raw_profile_gzip_files']}))


if __name__ == '__main__':
    main()
