#!/usr/bin/env python3
"""Compare matched expanded native counter campaigns without dropping losses."""
import argparse
import collections
import json
from pathlib import Path

KEYS = ['payload_bytes', 'connections', 'in_flight', 'tls', 'compression', 'side', 'codec', 'shape', 'metric']


def identity(row):
    return tuple(row[key] for key in KEYS)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--baseline', type=Path, required=True)
    parser.add_argument('--candidate', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    baseline = json.loads(args.baseline.read_text())
    candidate = json.loads(args.candidate.read_text())
    if any(data.get('phase') != 'native' for data in (baseline, candidate)):
        raise ValueError('both inputs must be native counter summaries')
    before = {identity(row): row for row in baseline['medians']}
    after = {identity(row): row for row in candidate['medians']}
    if before.keys() != after.keys() or len(before) != len(baseline['medians']) or len(after) != len(candidate['medians']):
        raise ValueError('exact matched scope and unique rows are required')
    rows, dispositions = [], collections.defaultdict(collections.Counter)
    for key in sorted(before):
        first, last = before[key], after[key]
        row = dict(zip(KEYS, key), qualified=False,
                   baseline_native_per_rpc=first['native_per_rpc'], candidate_native_per_rpc=last['native_per_rpc'],
                   baseline_tonic_per_rpc=first['tonic_per_rpc'], candidate_tonic_per_rpc=last['tonic_per_rpc'],
                   baseline_native_over_tonic=first['ratio'], candidate_native_over_tonic=last['ratio'],
                   baseline_repeats_available=first['repeats_available'], candidate_repeats_available=last['repeats_available'],
                   baseline_status=first['status'], candidate_status=last['status'],
                   baseline_repeat_dispositions=first['repeat_dispositions'], candidate_repeat_dispositions=last['repeat_dispositions'],
                   source_native_ratio=None, source_tonic_ratio=None, ratio_of_relative_ratios=None)
        complete = first['status'] == last['status'] == 'complete_diagnostic'
        if first['native_per_rpc'] is not None and last['native_per_rpc'] is not None:
            row['source_native_ratio'] = last['native_per_rpc'] / first['native_per_rpc']
        if first['tonic_per_rpc'] is not None and last['tonic_per_rpc'] is not None:
            row['source_tonic_ratio'] = last['tonic_per_rpc'] / first['tonic_per_rpc']
        if first['ratio'] is not None and last['ratio'] is not None:
            row['ratio_of_relative_ratios'] = last['ratio'] / first['ratio']
        ratio = row['source_native_ratio']
        row['source_disposition'] = ('unavailable_or_partial' if not complete or ratio is None else
                                     'improvement' if ratio < 1 else 'regression' if ratio > 1 else 'tie')
        if row['metric'] == 'context_switches':
            row['interpretation'] = 'unqualified scheduling diagnostic; nonpositive or missing deltas stay partial'
        else:
            row['interpretation'] = 'unqualified allocation diagnostic' if row['metric'] in ('allocations', 'requested_bytes') else 'not collected by native phase'
        dispositions[f"{row['side']}:{row['metric']}"][row['source_disposition']] += 1
        rows.append(row)
    result = dict(qualified=False, baseline_source=baseline['source'], candidate_source=candidate['source'],
                  baseline_passed=baseline['passed'], candidate_passed=candidate['passed'],
                  baseline_actual_rpc_totals=baseline['actual_rpc_totals'], candidate_actual_rpc_totals=candidate['actual_rpc_totals'],
                  source_comparison_median_dispositions={key: dict(value) for key, value in dispositions.items()},
                  rows=rows, baseline_failed_captures=baseline['raw_failed_captures'], candidate_failed_captures=candidate['raw_failed_captures'],
                  limits=['matched payload/load/TLS/compression/shape/codec/side groups; three-repeat medians',
                          'whole native campaigns run sequentially, not randomized interleaved source captures',
                          'source-native ratios compare cumulative N/2N counters, not native latency or throughput',
                          'tonic controls retained separately to expose drift; partial/missing rows are not wins',
                          'all source changes are combined; allocation stacks or narrow controls are needed for attribution'])
    with args.output.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ['qualified', 'baseline_source', 'candidate_source', 'baseline_passed', 'candidate_passed']}))


if __name__ == '__main__':
    main()
