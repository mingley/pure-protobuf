# Zstd decision documentation correction

Target: `docs/decisions/compression.md`

Replace this exact text:

```text
Decompression stays bounded by the existing message limit: the implementation
uses `ruzstd::decoding::StreamingDecoder` and stops reading one byte past
`MessageLimits::inflate_budget()`. Crossing the cap maps to
`RESOURCE_EXHAUSTED`; it does not first inflate the whole message and then
check its length. The hostile-peer test `a_zstd_bomb_cannot_outgrow_the_cap`
sends a compressed 64 MiB zero payload whose frame length is below the 256 KiB
frame cap; the server rejects it at the uncompressed message limit.
```

With:

```text
Zstd decoding has separate limits for decoded output and decoder history.
`MessageLimits::with_max_decoding` caps the wire payload and decoded message.
`MessageLimits::with_max_zstd_window` caps the advertised history window at
8 MiB by default; larger windows fail with `RESOURCE_EXHAUSTED` before history
allocation. `MessageLimits::unlimited()` uses the backend's 100 MiB window cap.
Lifting only the decoded message cap preserves the configured window limit.

A declared content size above the message cap is rejected before decoding
blocks. For an unknown content size, the backend may buffer a history window
and block data before returning the first decoded byte. The output cap therefore
does not bound all decoder work or total memory. Account for decoder state,
block buffers, compressed input and allocator overhead separately. Decoded
lengths and content checksums are validated before accepting the message.
```
