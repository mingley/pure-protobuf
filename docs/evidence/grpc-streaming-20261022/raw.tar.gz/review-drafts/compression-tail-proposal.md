# Compression tail proposal

State: external draft, formatted and `git apply --check` passed. **Not compiled or tested.** No tracked source was changed. Base/source hashes are in `compression-tail-proposal-manifest.json`.

## Format policy

| Coding | Valid within one gRPC compressed payload | Invalid tail |
|---|---|---|
| gzip | All concatenated RFC 1952 members, with aggregate decoded bytes forming one protobuf message | Non-member bytes, including zero padding; malformed/truncated later members |
| deflate | Exactly one RFC 1950 zlib stream | Bytes after its Adler-32, including another zlib stream or zero padding |
| zstd | Concatenated RFC 8878 standard frames and skippable frames, with standard-frame decoded bytes forming one protobuf message | Non-frame bytes, incomplete magic/header/content, malformed later frames |

RFC 1952 section 2.2 describes members appearing directly in sequence without additional information before, between or after them. RFC 1950 section 2.2 says bytes after Adler-32 are not part of its zlib stream; they are consequently outside the coding carried by this one gRPC payload. RFC 8878 sections 3.1 and 3.1.2 define independent standard frames and skippable frames. Recognized Zstd skippable metadata is the legal form of non-output data here; arbitrary padding is not substituted for it.

The locked ruzstd 0.9.0 `decoding/streaming_decoder.rs:22` explicitly warns: its reader expects one frame although the specification permits multiple frames, and the caller must instantiate subsequent decoders and process skippable frames. This is caller work, not evidence that concatenation is disallowed by the coding.

Current native behavior consumes the entire declared gRPC byte boundary but returns decoded bytes only from the first gzip member/Zstd frame. A second valid member/frame can contain protobuf fields that are silently omitted. This is data loss within one message; it does not change HTTP/2 or gRPC message boundaries. Illegal garbage also goes unvalidated. Current code therefore does not prove complete RFC format compliance.

## Native implementation

- Gzip: replace `GzDecoder` with `MultiGzDecoder`; keep the existing aggregate bounded-output helper. Each member's CRC/ISIZE remains validated. Extra non-member data becomes `INTERNAL`.
- Deflate: borrow the existing slice `ZlibDecoder` through bounded reading; require its remaining slice to be empty afterward. Bytes past the stream become `INTERNAL`. Do not interpret concatenated zlib streams as an implicit new coding.
- Zstd: a private `Read` adapter walks standard and skippable frames. It feeds the existing bounded reader once, so there is one aggregate output buffer. It drops each frame's decoder/history before opening another. Every standard frame gets its own window admission, early known-size check against the remaining aggregate budget, final size check and checksum comparison. Skip lengths use checked arithmetic and slice bounds, without allocating skip contents. Preserve `RESOURCE_EXHAUSTED` for window/output failures despite the internal `Read` error interface.
- Zstd header reserved bit 3 is explicitly rejected. The underlying header parser currently ignores it; unused bit 4 remains ignored as required. This draft adds no dictionary negotiation or magicless-frame extension.

The output reservation bound and 8 MiB per-frame default history window remain separate. Sequential frame counts are bounded only by the finite compressed input length; neither this draft nor the current implementation promises a preemptible CPU bound inside synchronous decompression. No per-message history or output budget is raised.

## Tests in the draft

- Valid multi-member gzip, aggregate exact limit and one-over limit, malformed/truncated later data.
- Deflate rejects zero/garbage/second-stream tails.
- Zstd valid concatenation, skippable frames before/between/after, skip-only empty content, aggregate cap, second-frame size/checksum/window failures, invalid reserved bit, malformed/truncated tails and exact-limit empty frames.
- Existing missing-header negotiation matrix uses protobuf bytes split across gzip members. Four server request shapes and both client response readers must reconstruct the entire protobuf message; a first-member-only implementation fails the positive cases.
- Native gzip API characterization in `tonic_opaque_transport.rs` is updated to the new native policy. Historical evidence is preserved. Independent generated-tonic characterization is left intact.
- The buffered-wrapper differential oracle now uses the multi-member gzip wrapper and checks the zlib decoder's consumed count. Existing malformed/truncation/error-cap precedence coverage remains.

Still required before applying: compile and run targeted tests; add second-member corrupted CRC/ISIZE and every split point around member/frame transitions; raw-peer interoperability for concatenated Zstd; a bounded decoder-work/resource test; final native/default/all-feature/ASAN validation; matched single-member and multipart performance diagnostics. The draft itself establishes none of these results.

## Opaque tonic adapter gap

`tonic_server/gzip.rs` independently inflates only one gzip member, discards decoded scratch bytes, and replays the original encoded frame views. The generated tonic decoder then independently inflates only the first member. Changing the native public decoder does not fix this path. Merely making the guard validate all members would enforce an aggregate size cap while the handler still receives partial protobuf data.

A complete adapter fix must normalize multipart compressed messages before passing them to generated tonic. A useful design is to keep the single-member view-replay fast path, fully decode rare multipart payloads under the aggregate cap, and emit one **uncompressed-flag-zero** frame with the combined protobuf bytes. The existing `grpc-encoding: gzip` header may remain: per-message identity frames are valid under a named RPC encoding, so original metadata need not be rewritten. Arbitrary encoded junk must fail. Account for decoded buffers and original retained views, preserve the guard's input/output polling quota, and test fragmented member boundaries and cancellation before handing any message to the generated decoder.

This needs implementation and memory/flow-control evidence. Rejecting all multipart input is a possible explicit unsupported policy, but cannot be represented as complete gzip format support. Replaying it unchanged is the existing silent-partial-data defect. Independent upstream tonic tests should continue to record upstream behavior; transport adapter tests must require complete data or a clear rejection.

Do not claim complete compression spec compliance while this adapter path or the native format gaps remain open.
