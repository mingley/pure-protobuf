# Fault-proxy controls

The actual 24-hour campaign stopped after 17,748.40 seconds. Cycle 5,419
failed at the raw TCP bidirectional RST_CANCEL status assertion: expected
CANCELLED or UNAVAILABLE, received OK. This remains a failed day run.

The previous 5,418 completed cycles drained to 7 file descriptors and one Tokio
task; the peak completed-drain RSS was 22,212,608 bytes. These observations do
not establish a completed 24-hour qualification.

## Deterministic controls

Five tests failed with the original helper and passed with the repaired helper:

- Observe only accepted writes, including Pending and short writes.
- Finish a partial HTTP/2 frame before inserting RST_STREAM.
- Finish HEADERS/CONTINUATION blocks before inserting RST_STREAM.
- Forward the request HEADERS before delivering a server-side stream reset.
- Forward the server SETTINGS preface before an injected frame.

The original helper is identical at 8c1703af and 8fe0f8ae. The negative control
used frozen 8c1703af plus only the added tests; its exact patch is retained.
That worktree was restored after the runs. The fixed helper also serializes
the injection decision with the nonblocking inner read to close the window
where ready response bytes could overtake a queued reset.

The additional 256-case TCP bidirectional BodyStarted/RST_CANCEL replay passed
with BOTH helpers. It does not reproduce the exact old day-run status failure
or prove which helper defect caused it. Full integration and a new complete
soak remain separate gates. No resource thresholds or expected statuses changed.

## Records

- old.*: original helper, 0 passed / 5 failed deterministic controls.
- old-repeat.*: original helper, 256 raw TCP reset scenarios passed.
- fixed-build.*: repaired helper and current candidate runtime, both integration
  targets compiled.
- fixed-tests.*: repaired helper, 5 deterministic controls passed.
- fixed-repeat.*: repaired helper, 256 raw TCP reset scenarios passed.
- fixed.*: earlier compile attempt failed on an intermediate unrelated
  compression helper signature; no test execution or passing claim.
- binaries.json records the copied test executables used for the fixed runs.

The fixed build used the shared candidate tree while other agents finalized
unrelated runtime changes. It is targeted regression evidence, not a frozen
release qualification; final source-pinned integration must be run separately.
