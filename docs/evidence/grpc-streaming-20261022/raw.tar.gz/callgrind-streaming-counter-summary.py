#!/usr/bin/env python3
"""Summarize every counter, including missing data and failed captures."""
import argparse
import collections
import json
from pathlib import Path
import statistics

KEYS = ['payload_bytes', 'connections', 'in_flight', 'tls', 'compression']
METRICS = ['instructions', 'allocations', 'requested_bytes', 'context_switches', 'syscalls', 'task_wakeups']


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    directory = args.campaign.resolve(strict=True)
    campaign = json.loads((directory / 'campaign.json').read_text())
    groups = collections.defaultdict(list)
    dispositions = collections.defaultdict(collections.Counter)
    differential_availability = collections.defaultdict(collections.Counter)
    missing_ledgers = []
    raw_paths = list(directory.glob("group-*/n-*/cell-*/run.json"))
    captures = len(raw_paths)
    completed_batch_captures = 0
    for group in campaign.get('groups', []):
        for capture in group.get('captures', []):
            completed_batch_captures += capture['total']
        ledger_path = directory / group['path'] / 'ledger.json'
        if not ledger_path.exists():
            missing_ledgers.append(str(ledger_path.relative_to(directory)))
            continue
        ledger = json.loads(ledger_path.read_text())
        for row in ledger['rows']:
            side, metric, cell = row['side'], row['metric'], row['cell']
            if metric not in METRICS:
                raise ValueError(f'unexpected ledger metric: {metric}')
            dispositions[f'{side}:{metric}'][row['disposition']] += 1
            availability = differential_availability[f'{side}:{metric}']
            availability['rows'] += 1
            availability['native_delta_available'] += row['native_per_rpc'] is not None
            availability['tonic_delta_available'] += row['tonic_per_rpc'] is not None
            availability['ratio_available'] += row['ratio'] is not None
            codec = cell['pair'][1 if side == 'client' else 3]
            identity = (*[cell[field] for field in KEYS], side, codec, cell['shape'], metric)
            groups[identity].append(row)
    medians = []
    for identity, rows in sorted(groups.items()):
        record = dict(zip([*KEYS, 'side', 'codec', 'shape', 'metric'], identity))
        valid = [row for row in rows if row['ratio'] is not None and not row.get('failed_captures')]
        record.update(repeats_expected=campaign['repeats'], repeats_observed=len(rows),
                      repeats_available=len(valid), repeat_dispositions={str(row['repeat']): row['disposition'] for row in rows},
                      native_per_rpc=statistics.median(row['native_per_rpc'] for row in valid) if valid else None,
                      tonic_per_rpc=statistics.median(row['tonic_per_rpc'] for row in valid) if valid else None,
                      ratio=statistics.median(row['ratio'] for row in valid) if valid else None,
                      qualified=False)
        record['median_repeat_ratio'] = record['ratio']
        record['ratio'] = (record['native_per_rpc'] / record['tonic_per_rpc']
                           if record['tonic_per_rpc'] else None)
        if any(row.get('failed_captures') for row in rows):
            record['status'] = 'failed_capture'
        elif len(valid) == campaign['repeats'] == len(rows):
            record['status'] = 'complete_diagnostic'
        elif valid:
            record['status'] = 'partial_diagnostic'
        else:
            record['status'] = 'not_run'
        medians.append(record)
    # Include failed raw captures even when controller interruption prevented a ledger.
    raw_failures = []
    actual_rpc_totals = collections.Counter()
    raw_counter_availability = {side: collections.Counter() for side in ('client', 'server')}
    metrics_records = 0
    status_errors = collections.Counter()
    for path in raw_paths:
        result = json.loads(path.read_text())
        metrics = result.get('metrics')
        if isinstance(metrics, dict):
            metrics_records += 1
            for key in ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
                        'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']:
                value = metrics.get(key)
                if type(value) is int and value >= 0:
                    actual_rpc_totals[key] += value
            status_errors.update(metrics.get('status_errors', {}))
        for side in ('client', 'server'):
            for metric, section in [('allocations', 'allocation_totals'), ('requested_bytes', 'allocation_totals'),
                                    ('context_switches', 'context_switch_totals'), ('instructions', 'instruction_totals'),
                                    ('syscalls', 'syscall_totals')]:
                value = result.get(section, {}).get(side)
                if value is not None and (metric not in ('allocations', 'requested_bytes') or metric in value):
                    raw_counter_availability[side][metric] += 1
        if result.get('passed') is not True:
            raw_failures.append(dict(path=str(path.relative_to(directory)), error=result.get('error')))
    result = dict(source=campaign.get('source'), binary_sha256=campaign.get('binary_sha256'),
                  phase=campaign.get('phase'), state=campaign.get('state'), controller_passed=campaign.get('passed'),
                  passed=(campaign.get('passed') is True and not missing_ledgers and not raw_failures
                          and captures == campaign.get('expected_captures')),
                  captures=captures, completed_batch_captures=completed_batch_captures,
                  expected_captures=campaign.get('expected_captures'), qualified=False,
                  dispositions={key: dict(value) for key, value in dispositions.items()}, medians=medians,
                  differential_counter_availability={key: dict(value) for key, value in differential_availability.items()},
                  raw_failed_captures=raw_failures, missing_ledgers=missing_ledgers,
                  actual_rpc_totals=dict(actual_rpc_totals), metrics_records=metrics_records,
                  status_errors=dict(status_errors),
                  raw_counter_availability={side: {metric: counts.get(metric, 0) for metric in METRICS}
                                            for side, counts in raw_counter_availability.items()},
                  counters=dict(allocations='process-lifetime allocation requests including reallocations; N/2N differential',
                                requested_bytes='cumulative requested allocation bytes, not peak/RSS; N/2N differential',
                                context_switches='native phase only: process-lifetime getrusage_self, includes exited threads; noisy N/2N differential',
                                instructions='Callgrind phase only: instrumented process-lifetime Ir; N/2N differential',
                                syscalls='not collected in native/Callgrind phase', task_wakeups='not collected'),
                  limits=['all metrics and failed/missing rows retained',
                          'ratio is median native divided by median tonic; median repeat ratio is also retained',
                          'ledger win/loss labels on context-switch counts are unqualified scheduling diagnostics',
                          'partial medians explicitly retain available versus expected repeat counts',
                          'no broad performance or production qualification'])
    with args.output.open('x') as target:
        json.dump(result, target, indent=2)
        target.write('\n')
    print(json.dumps({key: result[key] for key in ['source', 'phase', 'state', 'passed', 'captures', 'expected_captures', 'qualified']}))


if __name__ == '__main__':
    main()
