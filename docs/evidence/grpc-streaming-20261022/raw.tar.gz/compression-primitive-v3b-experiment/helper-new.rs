fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(decoder: &mut impl std::io::Read, target: &mut [u8], coding: &str) -> Result<usize,Status> {
        loop {
            match decoder.read(target) {
                Ok(n)=>return Ok(n),
                Err(error) if error.kind()==std::io::ErrorKind::Interrupted=>continue,
                Err(error)=>return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    let mut first = [0u8;8192];
    let n = read_retry(&mut decoder,&mut first[..budget.saturating_add(1).min(8192)],coding)?;
    if n==0 {return Ok(Vec::new())}
    if n>budget {return Err(Status::resource_exhausted(format!("decompressed message exceeds limit {budget}")))}
    let mut out = Vec::new();
    let capacity=n.max(compressed_length.min(256*1024)).min(budget);
    out.try_reserve_exact(capacity).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
    out.resize(capacity,0);
    out[..n].copy_from_slice(&first[..n]);
    let mut used=n;
    loop {
        if used==out.len() {
            let n=read_retry(&mut decoder,&mut first[..1],coding)?;
            if n==0 {out.truncate(used);return Ok(out)}
            if used==budget {return Err(Status::resource_exhausted(format!("decompressed message exceeds limit {budget}")))}
            let capacity=out.len().saturating_mul(2).max(used.saturating_add(1)).min(budget);
            out.try_reserve_exact(capacity-out.len()).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
            out.resize(capacity,0);
            out[used]=first[0];
            used+=1;
        }
        let n=read_retry(&mut decoder,&mut out[used..],coding)?;
        if n==0 {out.truncate(used);return Ok(out)}
        used+=n;
    }
}
