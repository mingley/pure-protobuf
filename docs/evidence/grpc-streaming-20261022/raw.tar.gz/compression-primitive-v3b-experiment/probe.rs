use std::io::{Read,Write};
use flate2::bufread::GzDecoder;
use std::sync::atomic::{AtomicU64,Ordering};
struct Counting;
static ALLOCS: AtomicU64=AtomicU64::new(0);
static BYTES: AtomicU64=AtomicU64::new(0);
unsafe impl std::alloc::GlobalAlloc for Counting {
 unsafe fn alloc(&self,l:std::alloc::Layout)->*mut u8 { ALLOCS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);unsafe {std::alloc::System.alloc(l)} }
 unsafe fn dealloc(&self,p:*mut u8,l:std::alloc::Layout) {unsafe {std::alloc::System.dealloc(p,l)} }
 unsafe fn realloc(&self,p:*mut u8,l:std::alloc::Layout,n:usize)->*mut u8 {ALLOCS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n as u64,Ordering::Relaxed);unsafe{std::alloc::System.realloc(p,l,n)}}
}
#[global_allocator]static A:Counting=Counting;
#[derive(Debug)]struct Status(String);
impl Status {fn internal(s:impl Into<String>)->Self {Self(s.into())} fn resource_exhausted(s:impl Into<String>)->Self {Self(s.into())}}
fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    fn read_retry(decoder: &mut impl std::io::Read, target: &mut [u8], coding: &str) -> Result<usize,Status> {
        loop {
            match decoder.read(target) {
                Ok(n)=>return Ok(n),
                Err(error) if error.kind()==std::io::ErrorKind::Interrupted=>continue,
                Err(error)=>return Err(Status::internal(format!("{coding} decode: {error}"))),
            }
        }
    }
    let mut first = [0u8;8192];
    let n = read_retry(&mut decoder,&mut first[..budget.saturating_add(1).min(8192)],coding)?;
    if n==0 {return Ok(Vec::new())}
    if n>budget {return Err(Status::resource_exhausted(format!("decompressed message exceeds limit {budget}")))}
    let mut out = Vec::new();
    let capacity=n.max(compressed_length.min(256*1024)).min(budget);
    out.try_reserve_exact(capacity).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
    out.resize(capacity,0);
    out[..n].copy_from_slice(&first[..n]);
    let mut used=n;
    loop {
        if used==out.len() {
            let n=read_retry(&mut decoder,&mut first[..1],coding)?;
            if n==0 {out.truncate(used);return Ok(out)}
            if used==budget {return Err(Status::resource_exhausted(format!("decompressed message exceeds limit {budget}")))}
            let capacity=out.len().saturating_mul(2).max(used.saturating_add(1)).min(budget);
            out.try_reserve_exact(capacity-out.len()).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
            out.resize(capacity,0);
            out[used]=first[0];
            used+=1;
        }
        let n=read_retry(&mut decoder,&mut out[used..],coding)?;
        if n==0 {out.truncate(used);return Ok(out)}
        used+=n;
    }
}
fn decode_old(payload: &[u8], budget: usize) -> Result<Vec<u8>, Status> {
    // One byte past the cap distinguishes "fits exactly" from "overflows".
    let read_cap = u64::try_from(budget.saturating_add(1)).unwrap_or(u64::MAX);
    let guess = payload
        .len()
        .saturating_mul(4)
        .min((256 * 1024))
        .min(budget);
    let mut out = Vec::with_capacity(guess);
    // The frame payload already implements BufRead as a byte slice. Avoid
    // read::GzDecoder's extra 32 KiB input buffer and compressed-byte copy.
    GzDecoder::new(payload)
        .take(read_cap)
        .read_to_end(&mut out)
        .map_err(|e| Status::internal(format!("gzip decode: {e}")))?;
    if out.len() > budget {
        return Err(Status::resource_exhausted(format!(
            "decompressed message exceeds limit {budget}"
        )));
    }
    Ok(out)
}

fn decode_new(payload:&[u8],budget:usize)->Result<Vec<u8>,Status> {read_bounded(GzDecoder::new(payload),budget,payload.len(),"gzip")}
fn main() {
 let mut enc=flate2::write::GzEncoder::new(Vec::new(),flate2::Compression::fast());
 enc.write_all(&vec![0;1001]).unwrap(); let gz=enc.finish().unwrap();
 let old=decode_old(&gz,1001).unwrap();let new=decode_new(&gz,1001).unwrap();
 println!("{{\"kind\":\"capacity\",\"budget\":1001,\"old_capacity\":{},\"new_capacity\":{}}}",old.capacity(),new.capacity());
 for size in [1024,65536,1048576] {
  for noise in [false,true] {
   let mut state=0x5eeda5e5u64;
   let input:Vec<u8>=(0..size).map(|_| {if noise {state^=state<<13;state^=state>>7;state^=state<<17;state as u8} else {0}}).collect();
   let mut enc=flate2::write::GzEncoder::new(Vec::new(),flate2::Compression::fast());
   enc.write_all(&input).unwrap(); let encoded=enc.finish().unwrap();
   let rounds=if size==1024 {30000} else if size==65536 {1500} else {200};
   assert_eq!(decode_old(&encoded,size).unwrap(),input);
   assert_eq!(decode_new(&encoded,size).unwrap(),input);
   for repeat in 0..6 {
    let order=if repeat%2==0 {["old","new"]} else {["new","old"]};
    for implementation in order {
     let decode:fn(&[u8],usize)->Result<Vec<u8>,Status>=if implementation=="old" {decode_old} else {decode_new};
     for _ in 0..100 {std::hint::black_box(decode(std::hint::black_box(&encoded),size).unwrap());}
     let alloc_before=ALLOCS.load(Ordering::Relaxed);let bytes_before=BYTES.load(Ordering::Relaxed);
     let start=std::time::Instant::now();
     for _ in 0..rounds {let decoded=decode(std::hint::black_box(&encoded),size).unwrap();assert_eq!(decoded.len(),size);std::hint::black_box(decoded);}
     let nanos=start.elapsed().as_nanos();
     let allocs=ALLOCS.load(Ordering::Relaxed)-alloc_before;let bytes=BYTES.load(Ordering::Relaxed)-bytes_before;
     println!("{{\"size\":{},\"noise\":{},\"compressed_bytes\":{},\"repeat\":{},\"implementation\":\"{}\",\"rounds\":{},\"nanoseconds\":{},\"allocations\":{},\"requested_bytes\":{}}}",size,noise,encoded.len(),repeat,implementation,rounds,nanos,allocs,bytes);
    }
   }
  }
 }
}
