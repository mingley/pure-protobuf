#!/usr/bin/env python3
"""Package this attempt's records; never infer readiness from file integrity."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '6cd91911afce24cceee6df3f60a945453e5b04da'
DEST = ROOT / 'docs/evidence/grpc-streaming-20261022'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    prefixes = [
        'streaming-', 'counter-streaming-', 'rpc-build-streaming', 'rpc-build-route',
        'cancel-buffered-', 'stream-scratch-tests', 'continuation-contracts',
        'handler-liveness-', 'soak-proxy-controls',
        'compression-primitive', 'seg-sink-rollback-control', 'zstd-legacy-control',
        'callgrind-streaming', 'resource-streaming-preview', 'resource-streaming-c3-preview',
    ]
    paths = set()
    for path in Q.iterdir():
        if any(path.name.startswith(prefix) for prefix in prefixes):
            if path.is_file():
                paths.add(path)
            elif path.is_dir():
                paths.update(p for p in path.rglob('*') if p.is_file())
    files = []
    omitted = []
    for path in sorted(paths):
        data = path.read_bytes()
        entry = dict(path=str(path.relative_to(Q)), bytes=len(data), sha256=sha(data))
        if data.startswith(b'\x7fELF'):
            omitted.append(entry)
        else:
            files.append((entry, data))
    delivered = subprocess.check_output(['git', 'diff', '--name-only', 'de45b721', SOURCE], cwd=ROOT, text=True).splitlines()
    generated = {
        'source-intermediate/b059-to-final.patch': subprocess.check_output(['git', 'diff', 'b059de92', SOURCE], cwd=ROOT),
        'source-delivered/changes.patch': subprocess.check_output(['git', 'diff', 'de45b721', SOURCE], cwd=ROOT),
        'source-delivered/pin.json': (json.dumps({
            'commit': SOURCE,
            'tree': subprocess.check_output(['git', 'rev-parse', SOURCE + '^{tree}'], cwd=ROOT, text=True).strip(),
            'base': 'de45b72138bdba0ee70ebc235bc96d0d24cfd801',
            'qualified': False,
        }, indent=2) + '\n').encode(),
        'omitted-executables.json': (json.dumps({'executables': omitted}, indent=2) + '\n').encode(),
    }
    for name in delivered:
        generated['source-delivered/' + name] = subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=ROOT)
    for name in ['record.py', 'package-streaming-evidence.py', 'finalize-streaming-capsule.py', 'summarize-streaming.py', 'run-rust', 'run-streaming-followup-checks.py', 'run-streaming-c3-followup.py', 'run-quiet-streaming-counters.py', 'run-streaming-c3-day.py', 'publish-streaming-c3-day.py', 'test-streaming-c3-day-tools.py', 'streaming-c3-day-automation.md']:
        path = ROOT / 'work' / name
        if path.is_file():
            generated['controllers/' + name] = path.read_bytes()
    for name in ['compression-tail-proposal.patch', 'compression-tail-proposal.md', 'compression-tail-proposal-manifest.json', 'compression-doc-correction.md']:
        path = ROOT / 'work' / name
        if path.is_file():
            generated['review-drafts/' + name] = path.read_bytes()
    for name, data in sorted(generated.items()):
        files.append((dict(path=name, bytes=len(data), sha256=sha(data)), data))
    DEST.mkdir(parents=True, exist_ok=True)
    archive = DEST / 'raw.tar.gz'
    with archive.open('wb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', mtime=0, filename='') as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as tar:
                for entry, data in files:
                    member = tarfile.TarInfo(entry['path'])
                    member.mode = 0o644
                    member.size = len(data)
                    tar.addfile(member, io.BytesIO(data))
    manifest = dict(
        schema='pbrs.streaming-capsule.v1', source=SOURCE, qualified=False,
        archive=dict(name=archive.name, bytes=archive.stat().st_size, sha256=sha(archive.read_bytes())),
        logical_bytes=sum(entry['bytes'] for entry, _ in files),
        files=[entry for entry, _ in files],
    )
    (DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    shutil.copyfile(ROOT / 'docs/evidence/grpc-validation-20261022/check.py', DEST / 'check.py')
    subprocess.run(['python3', str(DEST / 'check.py')], check=True)
    print(json.dumps({'files': len(files), 'logical_bytes': manifest['logical_bytes'], 'archive_bytes': archive.stat().st_size}))


if __name__ == '__main__':
    main()
