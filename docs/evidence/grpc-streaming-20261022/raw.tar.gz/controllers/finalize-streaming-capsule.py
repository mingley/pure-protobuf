#!/usr/bin/env python3
"""Publish a snapshot of completed checks and the actual resource-run state."""
from pathlib import Path
import datetime
import json
import os

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
DEST = ROOT / 'docs/evidence/grpc-streaming-20261022'
SOURCE = '6cd91911afce24cceee6df3f60a945453e5b04da'


def main():
    data = json.loads((ROOT / 'work/streaming-evidence-results-draft.json').read_text())
    baseline = json.loads((Q / 'counter-streaming-c3-baseline-expanded/campaign.json').read_text())
    profiler = json.loads((Q / 'callgrind-streaming-c3-server-small-summary.json').read_text())
    assert baseline['state'] == 'finished' and baseline['passed']
    assert profiler['passed'] and profiler['captures'] == 144
    launch = json.loads((Q / 'streaming-c3-day-launch.json').read_text())
    assert launch['source'] == SOURCE and launch['requested_duration_seconds'] == 86400
    day = dict(source=SOURCE, qualified=False, launch_record='streaming-c3-day-launch.json',
               requested_seconds=86400, status='running_at_publication',
               started_utc=launch['started_utc'], pid=launch['pid'],
               supervisor_pid=launch['supervisor_pid'], limits=launch['readiness']['process_limits'])
    terminal = Q / 'streaming-c3-day-termination.json'
    if terminal.exists():
        day.update(status='terminated_at_publication', termination=json.loads(terminal.read_text()))
        report = Q / 'resource-streaming-c3-day/report.json'
        if report.exists():
            day['report'] = json.loads(report.read_text())
    else:
        os.kill(launch['pid'], 0)
        os.kill(launch['supervisor_pid'], 0)
    data['schema'] = 'pbrs.grpc-streaming-validation.v1'
    data.pop('draft', None)
    data.pop('replace_before_publication', None)
    data['soak_24h'] = day
    data['published_snapshot_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    manifest = json.loads((DEST / 'manifest.json').read_text())
    data['archive'] = {'path': 'raw.tar.gz', 'manifest': 'manifest.json',
                       'checker': 'check.py', 'status': 'packaged_and_integrity_checked',
                       'archive_sha256': manifest['archive']['sha256'],
                       'integrity_is_qualification': False}
    docs_record = Q / 'streaming-c3-final-docs.json'
    if docs_record.exists():
        docs = json.loads(docs_record.read_text())
        assert docs['exit_code'] == 0
        data['checks']['final_documentation'] = {
            'status': 'passed', 'record_prefix': 'streaming-c3-final-docs',
            'source_scope': '6cd91911 plus final documentation edits; dirty-state hashes retained',
            'exit_code': 0,
        }
    rendered = (ROOT / 'work/streaming-evidence-final-template.md').read_text()
    old = '| Actual 24-hour resource campaign | `6cd91911` | ROOT_FINALIZER: insert actual running/terminal snapshot |'
    assert old in rendered
    if day['status'] == 'running_at_publication':
        description = f"**Running at publication**; started {launch['started_utc']}; completion pending"
    else:
        description = '**Terminated at publication**; see `results.json` and the terminal evidence index entry'
    rendered = rendered.replace(old, f'| Actual 24-hour resource campaign | `6cd91911` | {description} |')
    rendered = rendered.replace('## Resource and protocol limits\n',
        '## Resource and protocol limits\n\nThe actual day uses the passing-preview source, original finite limits and recovery checks. '
        'Its durable supervisor retains the terminal result and attempts to publish it separately. '
        'A running snapshot is not a completed 24-hour pass.\n')
    forbidden = ['completion pending |\n\nCandidate', 'completion pending; update', 'queued after profiling',
                 'completion pending |\n\nThe native', 'completion pending; full', 'completion pending; replace']
    assert not any(value in rendered for value in forbidden)
    assert data['claims'] == {'production_readiness': False, 'complete_spec_compliance': False,
                              'broad_superiority_over_tonic_prost': False}
    DEST.mkdir(parents=True, exist_ok=True)
    (DEST / 'README.md').write_text(rendered)
    (DEST / 'results.json').write_text(json.dumps(data, indent=2) + '\n')
    print(json.dumps({'day': day['status'], 'snapshot': data['published_snapshot_utc']}))


if __name__ == '__main__':
    main()
