from pathlib import Path
import datetime,json,os,signal,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification'
group=9793
if (q/'streaming-workspace.stdout').stat().st_size:
 raise RuntimeError('workspace tests already started; do not pause deadline tests')
if Path('/proc/9793/comm').read_text().strip()!='cargo':
 raise RuntimeError('unexpected compilation process')
record={'compiler_process_group':group,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Compiler paused only during allocation capture; shared-host diagnostic, not timing qualification'}
try:
 os.killpg(group,signal.SIGSTOP)
 command=['work/run-rust','python3','scripts/grpc-counter-campaign.py','--source-checkout',str(root),'--binary',str(q/'rpc-build-streaming/rpc-bench'),'--build-record',str(q/'rpc-build-streaming/build.json'),'--output',str(q/'counter-streaming-candidate'),'--phase','native','--payloads','1024','--load-levels','1:1','--repeats','3']
 record['command']=command
 result=subprocess.run(['python3','work/record.py',str(q/'counter-streaming-candidate'),'600',*command],cwd=root)
 record['exit_code']=result.returncode
finally:
 try:os.killpg(group,signal.SIGCONT);record['compiler_resumed']=True
 except ProcessLookupError:record['compiler_resumed']='already exited'
 record['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (q/'streaming-compiler-pause.json').write_text(json.dumps(record,indent=2)+'\n')
