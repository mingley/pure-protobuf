from pathlib import Path
import json
import os
import subprocess
import time

root = Path('/workspace/pure-protobuf')
q = root / 'work/qualification'
source = '7be4f29d504c9cae92907eeaaedfa4846a581332'
while not (q / 'streaming-workspace.json').exists():
    time.sleep(2)
if subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=root, text=True).strip() != source:
    raise RuntimeError('source changed; do not attach follow-up checks to another revision')
environment = dict(os.environ, RUSTUP_TOOLCHAIN='stable',
                   CARGO_TARGET_DIR=str(root / 'work/stable-target'), CARGO_BUILD_JOBS='1')
checks = [
    ('streaming-clippy', 600, ['cargo', 'clippy', '--locked', '-p', 'pbrs-grpc', '--all-targets', '--all-features', '--', '-D', 'warnings'], {}),
    ('streaming-rustdoc', 600, ['cargo', 'doc', '--locked', '-p', 'pbrs-grpc', '--all-features', '--no-deps'], {'RUSTDOCFLAGS': '-D warnings'}),
    ('streaming-format', 60, ['cargo', 'fmt', '--check'], {}),
    ('streaming-contracts', 60, ['python3', '-B', '-m', 'unittest', 'tests.test_grpc_resource_campaign', 'tests.test_grpc_load_smoke', 'tests.test_dominance_ledger', 'tests.test_counter_campaign', 'tests.test_counter_capsule', '-q'], {}),
    ('streaming-plan-lint', 60, ['python3', 'scripts/plan-lint.py'], {}),
]
outcomes = []
for name, timeout, command, extra in checks:
    result = subprocess.run(['python3', 'work/record.py', str(q / name), str(timeout),
                             'work/run-rust', *command], cwd=root, env=dict(environment, **extra))
    outcomes.append(dict(name=name, exit_code=result.returncode))
(q / 'streaming-followup-checks.json').write_text(json.dumps(dict(
    source=source, state='finished', checks=outcomes, qualified=False), indent=2) + '\n')
