#!/usr/bin/env python3
"""Summarize retained counter ledgers without converting them to speed claims."""
import collections
import json
from pathlib import Path
import statistics
import sys


def summarize(path):
    path = Path(path)
    campaign = json.loads((path / 'campaign.json').read_text())
    buckets = collections.defaultdict(list)
    dispositions = collections.defaultdict(collections.Counter)
    for group in campaign['groups']:
        ledger_path = path / group['path'] / 'ledger.json'
        if not ledger_path.exists():
            continue
        for row in json.loads(ledger_path.read_text())['rows']:
            cell = row['cell']
            codec = cell['pair'][1 if row['side'] == 'client' else 3]
            key = (cell['payload_bytes'], cell['connections'], cell['in_flight'],
                   cell['tls'], cell['compression'], row['side'], codec,
                   cell['shape'], row['metric'])
            buckets[key].append(row)
            dispositions[row['side'] + ':' + row['metric']][row['disposition']] += 1
    medians = []
    for key, rows in sorted(buckets.items()):
        if any(row['native_per_rpc'] is None or row['tonic_per_rpc'] is None for row in rows):
            continue
        native = statistics.median(row['native_per_rpc'] for row in rows)
        tonic = statistics.median(row['tonic_per_rpc'] for row in rows)
        medians.append(dict(zip(
            ['payload_bytes', 'connections', 'in_flight', 'tls', 'compression',
             'side', 'codec', 'shape', 'metric'], key),
            native_per_rpc=native, tonic_per_rpc=tonic,
            ratio=native / tonic if tonic else None, repeats=len(rows)))
    return dict(source=campaign['source'], binary_sha256=campaign['binary_sha256'],
                state=campaign['state'], passed=campaign['passed'],
                captures=sum(capture['total'] for group in campaign['groups'] for capture in group['captures']),
                qualified=False,
                dispositions={key: dict(value) for key, value in dispositions.items()},
                medians=medians)


if __name__ == '__main__':
    for directory in sys.argv[1:]:
        result = summarize(directory)
        output = Path(directory).with_name(Path(directory).name + '-summary.json')
        output.write_text(json.dumps(result, indent=2) + '\n')
        print(json.dumps({'path': str(output), 'source': result['source'],
                          'captures': result['captures'], 'passed': result['passed']}))
