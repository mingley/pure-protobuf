# Streaming C3 day automation

Prepared only. These scripts do not start a campaign until `--launch` is invoked.
They are external workspace files; no tracked repository files are changed.

Pinned source: `6cd91911afce24cceee6df3f60a945453e5b04da`.

Prerequisites:

- `/workspace/pure-protobuf/work/validation-fixes` is clean and detached at that source. The launcher never checks it out or changes it.
- `/workspace/pure-protobuf/work/qualification/resource-streaming-c3-preview/report.json` records a passing release preview of at least 30 seconds at the same source.
- The attempt prefix and output directory do not already exist. Failed evidence is retained; the launcher refuses to overwrite an attempt.
- Start only after the planned quiet captures finish. Leave the frozen checkout unchanged while the day runs.

Read-only check (no process starts):

```sh
python3 /workspace/pure-protobuf/work/run-streaming-c3-day.py --check-ready
```

Detach the durable supervisor:

```sh
python3 /workspace/pure-protobuf/work/run-streaming-c3-day.py --launch
```

The launch command returns the actual supervisor pid. The supervisor records its
pid and the record wrapper pid, UTC start time, complete campaign argv, source,
preview hash, settings, resource limits, and immutable harness hashes in:

`/workspace/pure-protobuf/work/qualification/streaming-c3-day-launch.json`

The original pinned campaign controller runs in the frozen checkout with
`--source 6cd91911afce24cceee6df3f60a945453e5b04da`,
`--output /workspace/pure-protobuf/work/qualification/resource-streaming-c3-day`,
`--duration 86400`, and `--build-profile release`. The record wrapper timeout is
90,000 seconds. Cargo uses stable, one build job, and the existing stable target
cache. The original controller supplies its unchanged process limits and checks.
Launch metadata records day limits of 1 GiB address space, 128 file descriptors,
4,096 same-UID processes, and 86,430 CPU seconds (soft and hard). The preview's
separate 60-second CPU limit remains under `preview_process_limits`.

Immutable copies of both automation scripts, `record.py`, and `run-rust` are
stored under `work/qualification/streaming-c3-day-harness/` and used for the run.
The launcher detaches its supervisor with a new session and closed stdin; stdout
and stderr go to `streaming-c3-day-supervisor.log`. The record wrapper owns the
campaign process group and its timeout. A workspace/container shutdown can still
interrupt the run; an interrupted attempt is never counted as a completed day.

Terminal state is recorded in `streaming-c3-day-termination.json`. The publisher
then archives the terminal report, events, process samples, logs, preview,
launch/termination records, harness snapshots, and pinned controller/test source.
Executable content is omitted with hashes retained. The manifest checker verifies
all archived members before any commit. Earlier failed soak evidence is untouched.

Publication uses only a separate detached worktree:

`/workspace/pure-protobuf/work/streaming-c3-day-publication`

After fetching origin/main, the publisher verifies that the campaign source is
an ancestor of origin/main. It creates:

`docs/evidence/grpc-streaming-soak-20261022/`

It adds that capsule and an evidence-index link, commits, and pushes normally to
main. There are at most three push attempts. Concurrent main updates trigger a
fetch and rebase; conflicts trigger `rebase --abort` and a recorded failure. No
force push, reset, current-worktree checkout, or destructive cleanup is used.
The publication worktree and evidence commit remain available after any failure.

Final publication state, commit, and individual push results are retained in:

`/workspace/pure-protobuf/work/qualification/streaming-c3-day-publication.json`

A failed or incomplete report stays failed or incomplete. Even a passing full day
keeps `qualified: false`: other release and comparative performance gates remain
separate. The new terminal README derives its numbers and failures from the
report; it contains no hardcoded description of previous failures.

The frozen publisher can be invoked manually after a terminal record exists:

```sh
python3 /workspace/pure-protobuf/work/qualification/streaming-c3-day-harness/publish-streaming-c3-day.py
```

A previously published attempt returns its recorded outcome. An existing failed
publication worktree requires review; it is not silently overwritten.

Offline checks (no campaign, git mutation, or network):

```sh
python3 -m py_compile /workspace/pure-protobuf/work/run-streaming-c3-day.py /workspace/pure-protobuf/work/publish-streaming-c3-day.py
python3 /workspace/pure-protobuf/work/test-streaming-c3-day-tools.py
```

All 18 offline controls passed, including source/preview validation, detached
launch arguments, harness snapshots, correct pid records, terminal status rules,
source ancestry, bounded normal push retries, rebase abort, and archive tampering.
