from pathlib import Path
import json,os,subprocess,time
root=Path('/workspace/pure-protobuf'); q=root/'work/qualification'
source='6cd91911afce24cceee6df3f60a945453e5b04da'
while not (q/'streaming-c3-workspace.json').exists(): time.sleep(2)
if subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()!=source: raise RuntimeError('candidate changed')
if subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=root,text=True).strip(): raise RuntimeError('candidate dirty')
env=dict(os.environ,RUSTUP_TOOLCHAIN='stable',CARGO_TARGET_DIR=str(root/'work/stable-target'),CARGO_BUILD_JOBS='1')
checks=[
 ('streaming-c3-clippy',600,['cargo','clippy','--locked','-p','pbrs-grpc','--all-targets','--all-features','--','-D','warnings'],{}),
 ('streaming-c3-rustdoc',600,['cargo','doc','--locked','-p','pbrs-grpc','--all-features','--no-deps'],{'RUSTDOCFLAGS':'-D warnings'}),
 ('streaming-c3-format',60,['cargo','fmt','--check'],{}),
 ('streaming-c3-contracts',60,['python3','-B','-m','unittest','tests.test_grpc_resource_campaign','tests.test_grpc_load_smoke','tests.test_dominance_ledger','tests.test_counter_campaign','tests.test_counter_capsule','-q'],{}),
 ('streaming-c3-plan-lint',60,['python3','scripts/plan-lint.py'],{}),
 ('streaming-c3-rpc-build',1800,['python3','scripts/build-rpc-bench.py','--source',source,'--output',str(q/'rpc-build-streaming-c3')],{'CARGO_TARGET_DIR':str(root/'work/rpc-target')}),
]
records=[]
for name,timeout,command,extra in checks:
 result=subprocess.run(['python3','work/record.py',str(q/name),str(timeout),'work/run-rust',*command],cwd=root,env=dict(env,**extra))
 records.append(dict(name=name,exit_code=result.returncode))
frozen=root/'work/validation-fixes'
if subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=frozen,text=True).strip(): raise RuntimeError('frozen worktree dirty')
subprocess.run(['git','checkout','--detach',source],cwd=frozen,check=True)
result=subprocess.run(['python3',str(root/'work/record.py'),str(q/'streaming-c3-resource-preview'),str(1800),str(root/'work/run-rust'),'python3','scripts/grpc-resource-campaign.py','--source',source,'--output',str(q/'resource-streaming-c3-preview'),'--duration','30','--build-profile','release'],cwd=frozen,env=env)
records.append(dict(name='streaming-c3-resource-preview',exit_code=result.returncode))
(q/'streaming-c3-followup-checks.json').write_text(json.dumps(dict(source=source,state='finished',checks=records,qualified=False),indent=2)+'\n')
