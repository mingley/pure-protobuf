fn decode_old(payload: &[u8], budget: usize) -> Result<Vec<u8>, Status> {
    // One byte past the cap distinguishes "fits exactly" from "overflows".
    let read_cap = u64::try_from(budget.saturating_add(1)).unwrap_or(u64::MAX);
    let guess = payload
        .len()
        .saturating_mul(4)
        .min((256 * 1024))
        .min(budget);
    let mut out = Vec::with_capacity(guess);
    // The frame payload already implements BufRead as a byte slice. Avoid
    // read::GzDecoder's extra 32 KiB input buffer and compressed-byte copy.
    GzDecoder::new(payload)
        .take(read_cap)
        .read_to_end(&mut out)
        .map_err(|e| Status::internal(format!("gzip decode: {e}")))?;
    if out.len() > budget {
        return Err(Status::resource_exhausted(format!(
            "decompressed message exceeds limit {budget}"
        )));
    }
    Ok(out)
}
