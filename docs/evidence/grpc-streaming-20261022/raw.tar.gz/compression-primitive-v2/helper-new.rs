fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    let mut out = Vec::new();
    let mut chunk = [0u8; 8192];
    loop {
        let remaining = budget.saturating_sub(out.len());
        let want = remaining.saturating_add(1).min(chunk.len());
        let target = chunk
            .get_mut(..want)
            .ok_or_else(|| Status::internal("compression decode: short buffer"))?;
        let n = match decoder.read(target) {
            Ok(n) => n,
            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
            Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
        };
        if n == 0 {
            return Ok(out);
        }
        if n > remaining {
            return Err(Status::resource_exhausted(format!(
                "decompressed message exceeds limit {budget}"
            )));
        }
        let needed = out.len() + n;
        if needed > out.capacity() {
            let capacity = if out.is_empty() {
                needed.max(compressed_length.min(256 * 1024))
            } else {
                out.capacity().saturating_mul(2).max(needed)
            }
            .min(budget);
            out.try_reserve_exact(capacity - out.len()).map_err(|_| {
                Status::resource_exhausted("decompressed message allocation failed")
            })?;
        }
        out.extend_from_slice(
            target
                .get(..n)
                .ok_or_else(|| Status::internal("compression decode: invalid read length"))?,
        );
    }
}

