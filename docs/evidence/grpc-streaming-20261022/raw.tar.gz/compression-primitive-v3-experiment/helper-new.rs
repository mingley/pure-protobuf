fn read_bounded(
    mut decoder: impl std::io::Read,
    budget: usize,
    compressed_length: usize,
    coding: &str,
) -> Result<Vec<u8>, Status> {
    let mut out = Vec::new();
    let mut chunk = [0u8; 8192];
    loop {
        let old_len = out.len();
        if old_len == 0 || old_len == budget {
            let want = budget.saturating_sub(old_len).saturating_add(1).min(chunk.len());
            let n = match decoder.read(&mut chunk[..want]) {
                Ok(n) => n,
                Err(error) if error.kind() == std::io::ErrorKind::Interrupted => continue,
                Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
            };
            if n == 0 { return Ok(out); }
            if n > budget.saturating_sub(old_len) {
                return Err(Status::resource_exhausted(format!("decompressed message exceeds limit {budget}")));
            }
            let capacity = n.max(compressed_length.min(256 * 1024)).min(budget);
            out.try_reserve_exact(capacity).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
            out.extend_from_slice(&chunk[..n]);
            continue;
        }
        if old_len == out.capacity() {
            let capacity = out.capacity().saturating_mul(2).max(old_len.saturating_add(1)).min(budget);
            out.try_reserve_exact(capacity-old_len).map_err(|_|Status::resource_exhausted("decompressed message allocation failed"))?;
        }
        let target_len = out.capacity().min(budget);
        out.resize(target_len,0);
        match decoder.read(&mut out[old_len..]) {
            Ok(0) => {out.truncate(old_len);return Ok(out)},
            Ok(n) => out.truncate(old_len+n),
            Err(error) if error.kind() == std::io::ErrorKind::Interrupted => {out.truncate(old_len);continue},
            Err(error) => return Err(Status::internal(format!("{coding} decode: {error}"))),
        }
    }
}
