"""Collect source-pinned N/2N syscall diagnostics without changing the benchmark."""
import hashlib, importlib.util, itertools, json, os, platform, random, shutil, subprocess
from pathlib import Path
from types import SimpleNamespace

ROOT = Path('/workspace/pure-protobuf')
SOURCE = ROOT / 'work/matrix-candidate'
DRIVER = ROOT / 'work/driver-candidate'
BUILD = ROOT / 'work/matrix-v2-003/build'
OUTPUT = ROOT / 'work/syscall-counters-001'
SOURCE_PIN = '50ac70e5c9818fe870719b37acede99f12710fe9'
DRIVER_PIN = 'aced76ea'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def git(p, *args): return subprocess.check_output(['git', *args], cwd=p, text=True).strip()
def clean():
    assert git(SOURCE, 'rev-parse', 'HEAD') == SOURCE_PIN
    assert git(DRIVER, 'rev-parse', '--short=8', 'HEAD') == DRIVER_PIN
    assert not git(SOURCE, 'status', '--porcelain', '--untracked-files=all')
    assert not git(DRIVER, 'status', '--porcelain', '--untracked-files=all')
clean()
OUTPUT.mkdir(exist_ok=False)
shutil.copy2(__file__, OUTPUT / 'controller.py')
script = DRIVER / 'scripts/grpc-load-smoke.py'
spec = importlib.util.spec_from_file_location('smoke', script)
smoke = importlib.util.module_from_spec(spec); spec.loader.exec_module(smoke)
binary = BUILD / 'rpc-bench'
record = smoke.verified_build(BUILD / 'build.json', binary, SOURCE)
for p in BUILD.iterdir():
    if p.is_file() and p.name != 'rpc-bench': shutil.copy2(p, OUTPUT / ('build-' + p.name))
pairs = [['native','pbrs','tonic','prost'], ['native','prost','tonic','prost'],
         ['tonic','prost','native','pbrs'], ['tonic','prost','native','prost'], ['tonic','prost','tonic','prost']]
cells = [dict(pair=pair, shape=shape, payload_bytes=1024, tls=False, compression='identity',
              connections=1, in_flight=1, repeat=repeat)
         for pair,shape,repeat in itertools.product(pairs,smoke.SHAPES,range(3))]
random.Random(20261008).shuffle(cells)
state = dict(state='running', qualified=False, source=SOURCE_PIN, driver=git(DRIVER,'rev-parse','HEAD'))
def save(): (OUTPUT / 'controller-status.json').write_text(json.dumps(state,indent=2)+'\n')
for n in (200,400):
    state['state'] = f'strace-{n}'; save()
    directory = OUTPUT / state['state']; directory.mkdir()
    report = dict(schema='pbrs.load-smoke.v2', binary_sha256=sha(binary), head=SOURCE_PIN, dirty=False,
                  source_verified=True, build_record=record, harness_script_sha256=sha(script),
                  harness_head=git(DRIVER,'rev-parse','HEAD'), harness_dirty=False,
                  host=platform.uname()._asdict(),clock_ticks_per_second=os.sysconf('SC_CLK_TCK'),
                  cpu_affinity=sorted(os.sched_getaffinity(0)),seed=20261008,cells=cells,rpc_count=n,
                  duration_per_cell_seconds=60,allocation_counts=True,context_switches=False,callgrind=None,
                  strace='/usr/bin/strace',strace_version=subprocess.check_output(['/usr/bin/strace','--version'],text=True).splitlines()[0],
                  qualification=dict(qualified=False,limits=['shared host; optimized resource build may run concurrently',
                    'strace changes timing and scheduling; tracer CPU excluded; no timing conclusions',
                    'one KiB h2c identity, concurrency one; task wakeups and other profiles unmeasured',
                    'process-lifetime totals include setup; no measured noise or dedicated-host statistics']),runs=[])
    (directory/'harness.py').write_bytes(script.read_bytes())
    (directory/'source.patch').write_text('')
    (directory/'manifest.json').write_text(json.dumps(report,indent=2)+'\n')
    settings=SimpleNamespace(binary=binary,duration=60,rpc_count=n,allocation_counts=True,
                             context_switches=False,callgrind=None,strace=Path('/usr/bin/strace'),source_checkout=SOURCE)
    for i,cell in enumerate(cells):
        result=smoke.run_cell(settings,cell,directory/f'cell-{i:03d}')
        report['runs'].append(dict(path=f'cell-{i:03d}/run.json',passed=result['passed']))
        print(f'strace-{n}: {i+1}/{len(cells)} {result["passed"]}',flush=True)
    report['binary_unchanged']=report['binary_sha256']==sha(binary)
    try:
        clean(); smoke.verified_build(BUILD/'build.json',binary,SOURCE); report['source_unchanged']=True
    except (AssertionError,OSError,ValueError,subprocess.CalledProcessError) as error:
        report['source_unchanged']=False;report['source_error']=str(error)
    report['harness_script_unchanged']=report['harness_script_sha256']==sha(script)
    report['passed']=report['binary_unchanged'] and report['source_unchanged'] and report['harness_script_unchanged'] and all(r['passed'] for r in report['runs'])
    (directory/'report.json').write_text(json.dumps(report,indent=2)+'\n')
argv=['python3',str(DRIVER/'scripts/dominance-ledger.py'),'--small',str(OUTPUT/'strace-200'),'--large',str(OUTPUT/'strace-400'),'--allow-partial','--allow-failed-captures','--output',str(OUTPUT/'ledger.json')]
with (OUTPUT/'ledger.stdout').open('w') as out,(OUTPUT/'ledger.stderr').open('w') as err:
    result=subprocess.run(argv,cwd=DRIVER,stdout=out,stderr=err)
state.update(state='finished',ledger_command=argv,ledger_exit_code=result.returncode,
             controller_unchanged=sha(Path(__file__))==sha(OUTPUT/'controller.py'))
save()
