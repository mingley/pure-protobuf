# Sustained Prost cache diagnostic

Preparation record. Actual build, preview and day outcomes are separate records.
Runtime source: `beb4ecd9a9b2143c440892607d5b486318062b61`.

The diagnostic repeats the existing independent TCP/HTTP2 compressed-decode
fixture. Each completed cycle retains its ownership, malformed-input, limit,
cache-admission, 17-stream saturation, terminal cleanup and recovery assertions.
The copy adds one awaited peer-abort join and a bounded check that client file
descriptors return to the initial baseline. Retained-capacity counters and peaks
are never reset. A cycle event is written only after every assertion and cleanup
check succeeds.

Only `pbrs-grpc/tests/prost_cache_day.rs` is added in the detached
`work/architecture-c11-prost-day` checkout. No manifest or runtime file changes.
Every existing tracked file, except the sparse `docs/evidence/` exclusion, is
compared with its pinned Git blob. The original fixture, transformation, resulting
fixture, compiler tools, Cargo artifact features/profile and copied ELF are
recorded. The build uses release, all features and the existing `copy-counts`
diagnostic counters. It does not install an allocation-counting global allocator.

| Check | Preview | Day |
|---|---:|---:|
| Actual ELF duration | At least 30 s | At least 86,400 s |
| Address space | 1 GiB | 1 GiB |
| File descriptors | 128 | 128 |
| Processes for the same UID | 4,096 | 4,096 |
| CPU allowance | 60 s | 86,430 s |
| Outer wall guard | 120 s | 86,490 s |

Compilation is outside these process caps and duration measurements. The clock
starts inside the ELF test. Each whole fixture cycle has a 60-second outer guard;
the original per-operation guards and one-second RPC deadline remain unchanged.
Each cycle requires zero retained cache capacity/buffers, equal acquired/released
leases and descriptor recovery. RSS and process samples are retained; the fixed
address-space cap bounds the process. These checks do not establish a statistical
RSS leak slope or production memory requirements.

The controller supports these explicit phases:

```sh
python3 work/qualification/architecture-c11-prost-cache-build.py --prepare
python3 work/qualification/architecture-c11-prost-cache-build.py --build
python3 work/qualification/architecture-c11-prost-cache-controller.py --preview
python3 work/qualification/architecture-c11-prost-cache-controller.py --check-ready
python3 work/qualification/architecture-c11-prost-cache-controller.py --launch-day
```

The day requires a passing source/ELF-matched preview and a separate root grant
at `architecture-c11-prost-cache-day-grant.json` containing `source_pin`,
`root_granted: true` and `action: "launch-prost-cache-diagnostic-day"`.

All live build, preview, supervisor, sample, event and publication files use
`resource-architecture-c11-prost-cache-*` paths, outside the frozen packager glob.
Static fixture/controllers and write-once terminal snapshots use
`architecture-c11-prost-cache-*`. The day launcher freezes a private harness and
detaches its supervisor. The terminal publisher records pass, failure or incomplete
results in a separate evidence directory, using a dedicated publication worktree
and normal pushes to main. It preserves the existing C8 and C11 publishers.

A successful cycle repeats one existing fixture; cycles are not new distinct
production tests. A preview is not a completed day. This shared-host gzip/h2c
diagnostic does not exercise every transport/feature or a single stream held open
for a whole day, and does not prove overall production readiness or broad
performance superiority.
