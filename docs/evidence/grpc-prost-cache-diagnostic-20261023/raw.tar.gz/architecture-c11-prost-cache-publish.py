#!/usr/bin/env python3
"""Publish one terminal Prost-cache diagnostic; preparation never launches work."""
from pathlib import Path
import argparse
import datetime
import fcntl
import gzip
import hashlib
import io
import json
import math
import os
import shutil
import subprocess
import sys
import tarfile
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
OUTPUT = Q / 'resource-architecture-c11-prost-cache-day'
PREVIEW = Q / 'resource-architecture-c11-prost-cache-preview'
WORKTREE = ROOT / 'work/architecture-c11-prost-cache-publication'
EVIDENCE = Path('docs/evidence/grpc-prost-cache-diagnostic-20261023')
STATE = OUTPUT / 'publication.json'
SNAPSHOT = OUTPUT / 'publication-snapshot'
MARKER = '<!-- architecture-c11-prost-cache-terminal -->'
DIAGNOSTIC = 'repeated independent-peer compressed decode fixture'
LIMITS = {'address_space': 1073741824, 'file_descriptors': 128,
          'same_uid_processes': 4096, 'cpu_seconds': 86430}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def json_safe(value):
    if type(value) is float and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {key: json_safe(item) for key, item in value.items()}
    if isinstance(value, list):
        return [json_safe(item) for item in value]
    return value


def atomic(path, value):
    temporary = path.with_name(path.name + f'.tmp.{os.getpid()}')
    with temporary.open('x') as stream:
        json.dump(json_safe(value), stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    os.replace(temporary, path)


def git(*args, cwd=ROOT, check=True):
    return subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True, check=check)


def digest(path):
    checksum = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            checksum.update(block)
    return checksum.hexdigest()


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def reference_files(value, seen=None):
    seen = set() if seen is None else seen
    found = []
    if isinstance(value, dict):
        # Relative path/hash pairs in the runtime manifest identify Git files;
        # absolute path/hash pairs are immutable diagnostic artifact references.
        if (isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str)
                and Path(value['path']).is_absolute()):
            path = Path(value['path'])
            if path.is_symlink() or not path.resolve().is_relative_to(Q.resolve()):
                raise ValueError('diagnostic reference outside qualification directory: ' + str(path))
            if digest(path) != value['sha256'] or ('bytes' in value and path.stat().st_size != value['bytes']):
                raise ValueError('diagnostic reference hash/size mismatch: ' + str(path))
            if str(path) not in seen:
                seen.add(str(path))
                found.append(path)
                if path.suffix == '.json':
                    found.extend(reference_files(json.loads(path.read_text()), seen))
        for item in value.values():
            found.extend(reference_files(item, seen))
    elif isinstance(value, list):
        for item in value:
            found.extend(reference_files(item, seen))
    return found


def outcome(report, read_error=None, requested_seconds=86400):
    errors = []
    if report is None:
        return {'state': 'incomplete', 'report_available': False, 'qualified': False,
                'duration_actual_seconds': None, 'completed_cycles': None, 'exit_code': None,
                'failures': [read_error or 'No terminal diagnostic report was produced.']}
    declared = report.get('state')
    if declared not in ('passed', 'failed', 'incomplete'):
        errors.append('Report has no terminal disposition.')
    if report.get('source_pin') != SOURCE or report.get('qualified') is not False:
        errors.append('Report source or qualification disposition differs from the frozen diagnostic.')
    if report.get('diagnostic') != DIAGNOSTIC or report.get('requested_seconds') != requested_seconds:
        errors.append('Report diagnostic or requested duration differs from this day.')
    if report.get('runtime_source_equivalent') is not True:
        errors.append('The diagnostic overlay runtime equivalence was not verified.')
    expected_overlay = {'head': SOURCE, 'tracked_diff_sha256': hashlib.sha256(b'').hexdigest(),
                        'untracked_overlay': ['pbrs-grpc/tests/prost_cache_day.rs']}
    if report.get('source_before') != expected_overlay or report.get('source_after') != expected_overlay:
        errors.append('Diagnostic source snapshots differ from the test-only overlay contract.')
    if report.get('source_pin_verified_at_end') is not True:
        errors.append('The runtime source pin was not verified at termination.')
    expected_limits = LIMITS | {'cpu_seconds': requested_seconds + 30}
    if report.get('limits') != expected_limits:
        errors.append('Process limits differ from the fixed diagnostic caps.')
    duration = report.get('duration_actual_seconds')
    if not finite(duration):
        duration = None
        errors.append('Recorded duration is missing or invalid.')
    progress = report.get('final_progress', {})
    if not isinstance(progress, dict):
        progress = {}
        errors.append('Final progress is not an object.')
    cycles = report.get('completed_cycles')
    if type(cycles) is not int or cycles < 0:
        cycles = None
        errors.append('Completed cycle count is missing or invalid.')
    if declared == 'passed':
        expected_effective = {key: [value, value] for key, value in expected_limits.items()}
        if report.get('process_limits_verified') is not True or report.get('actual_process_limits') != expected_effective:
            errors.append('Effective process caps were not independently observed as requested.')
        if type(report.get('pid')) is not int or report['pid'] <= 0:
            errors.append('Successful diagnostic lacks a valid child PID.')
        if duration is None or duration < requested_seconds:
            errors.append('A short run cannot pass a requested day.')
        if progress.get('state') != 'completed' or not finite(progress.get('elapsed_seconds')) or progress['elapsed_seconds'] < requested_seconds:
            errors.append('Final progress does not record a completed day.')
        if cycles is None or cycles < 1 or progress.get('completed_cycles') != cycles:
            errors.append('Final progress and completed cycle counts disagree.')
        if report.get('exit_code') != 0 or report.get('supervisor_failure') or report.get('error'):
            errors.append('A reported pass has a child or supervisor failure.')
        for key in ('retained_capacity', 'retained_buffers'):
            if type(progress.get(key)) is not int or progress[key] != 0:
                errors.append('Retained cache did not return to zero: ' + key)
        for key in ('acquired', 'released', 'fd_count', 'rss_bytes'):
            if type(progress.get(key)) is not int or progress[key] < 0:
                errors.append('Missing or invalid final gauge: ' + key)
        if progress.get('acquired') != progress.get('released'):
            errors.append('Retained cache acquisition/release totals disagree.')
        if (type(progress.get('baseline_fd_count')) is not int
                or type(progress.get('fd_count')) is not int
                or not 0 < progress['fd_count'] <= progress['baseline_fd_count'] < LIMITS['file_descriptors']):
            errors.append('Final descriptor count did not return to its initial finite baseline.')
        if type(progress.get('fd_count')) is int and progress['fd_count'] > LIMITS['file_descriptors']:
            errors.append('Final descriptor count exceeds the diagnostic cap.')
        if type(progress.get('rss_bytes')) is int and not 0 < progress['rss_bytes'] < LIMITS['address_space']:
            errors.append('Final RSS exceeds the address-space cap.')
    reported = report.get('failures', [])
    if not isinstance(reported, list):
        reported = [str(reported)]
    if reported and declared == 'passed':
        errors.append('A reported pass retains failures.')
    state = 'failed' if declared == 'failed' else 'incomplete' if declared != 'passed' or errors else 'passed'
    return {'state': state, 'report_state': declared, 'report_available': True,
            'qualified': False, 'duration_actual_seconds': duration,
            'completed_cycles': cycles, 'exit_code': report.get('exit_code'),
            'final_progress': json_safe(progress), 'validation_errors': errors,
            'failures': [str(item) for item in reported] + errors}


def validate_events(report, directory, requested_seconds):
    """Validate completed-cycle order without treating cycles as distinct tests."""
    count, final, last_elapsed = 0, None, 0.0
    with (directory / 'events.jsonl').open() as stream:
        for line in stream:
            event = json.loads(line)
            if not isinstance(event, dict) or final is not None:
                raise ValueError('Unexpected event after terminal diagnostic event.')
            elapsed = event.get('elapsed_seconds')
            if not finite(elapsed) or elapsed < last_elapsed:
                raise ValueError('Diagnostic event time is invalid or goes backward.')
            last_elapsed = elapsed
            if event.get('requested_seconds') != requested_seconds or event.get('pid') != report.get('pid'):
                raise ValueError('Diagnostic event duration or child PID differs from its report.')
            if event.get('retained_capacity') != 0 or event.get('retained_buffers') != 0:
                raise ValueError('Cycle did not return retained cache gauges to zero.')
            if type(event.get('rss_bytes')) is not int or not 0 < event['rss_bytes'] < LIMITS['address_space']:
                raise ValueError('Cycle has missing or out-of-cap RSS.')
            if event.get('acquired') != event.get('released'):
                raise ValueError('Cycle acquisition/release totals differ.')
            if (type(event.get('fd_count')) is not int or type(event.get('baseline_fd_count')) is not int
                    or event['fd_count'] > event['baseline_fd_count']):
                raise ValueError('Cycle descriptors did not return to baseline.')
            peak = event.get('peak_retained_capacity')
            if type(peak) is not int or peak < 0 or peak > 16 * 1024 * 1024:
                raise ValueError('Cycle peak idle Vec capacity exceeds its fixed budget.')
            if event.get('event') == 'cycle_completed' and event.get('state') == 'running':
                count += 1
                if event.get('completed_cycles') != count:
                    raise ValueError('Diagnostic completed-cycle sequence is incomplete or duplicated.')
            elif event.get('event') == 'duration_completed' and event.get('state') == 'completed':
                if elapsed < requested_seconds or event.get('completed_cycles') != count or count < 1:
                    raise ValueError('Terminal event does not establish the requested diagnostic duration.')
                final = event
            else:
                raise ValueError('Unknown diagnostic event or state.')
    if final != report.get('final_progress') or count != report.get('completed_cycles'):
        raise ValueError('Terminal report and actual completed-cycle events disagree.')
    return {'completed_cycles': count, 'terminal_event_matches_report': True}


def snapshot_files(report):
    if SNAPSHOT.exists():
        raise ValueError('retained publication snapshot must not be overwritten')
    paths = []
    for directory in [OUTPUT, PREVIEW]:
        if directory.exists():
            paths += [path for path in directory.rglob('*') if path.is_file()]
    for path in Q.glob('architecture-c11-prost-cache-*'):
        if path.is_file():
            paths.append(path)
        elif path.is_dir() and not path.is_symlink():
            paths += [child for child in path.rglob('*') if child.is_file()]
    reference_errors, pinned = [], set()
    for key in ['build', 'provenance', 'preview']:
        if report is not None:
            try:
                refs = reference_files(report.get(key))
                if report.get('state') == 'passed' and not refs:
                    raise ValueError('passed report lacks pinned ' + key + ' references')
                paths += refs
                pinned.update(refs)
            except (OSError, ValueError) as error:
                reference_errors.append(str(error))
    SNAPSHOT.mkdir()
    selected, omitted = [], []
    for path in sorted(set(paths)):
        if path == STATE or path.name.startswith('.publication') or '.tmp.' in path.name:
            continue
        if path.is_symlink() or not path.resolve().is_relative_to(Q.resolve()):
            raise ValueError('unexpected evidence path: ' + str(path))
        relative = path.relative_to(Q)
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'
        if elf:
            omitted.append({'path': str(relative), 'bytes': path.stat().st_size, 'sha256': digest(path)})
            continue
        target = SNAPSHOT / 'files' / relative
        target.parent.mkdir(parents=True, exist_ok=True)
        before = path.stat()
        shutil.copyfile(path, target)
        after = path.stat()
        if path in pinned and digest(target) != digest(path):
            reference_errors.append('Pinned reference changed while snapshotting: ' + str(path))
        selected.append({'path': str(relative), 'bytes': target.stat().st_size, 'sha256': digest(target),
                         'source_size_before': before.st_size, 'source_size_after': after.st_size,
                         'source_mtime_ns_before': before.st_mtime_ns, 'source_mtime_ns_after': after.st_mtime_ns})
    description = {'source_pin': SOURCE, 'snapshot_utc': now(), 'qualified': False,
                   'scope': 'Immutable pack-time copies; live publisher/supervisor logs are finite snapshots.',
                   'files': selected, 'omitted_executables': omitted, 'reference_validation_errors': reference_errors}
    atomic(SNAPSHOT / 'snapshot.json', description)
    return description


def archive(dest, snapshot):
    files = []
    for entry in snapshot['files']:
        path = SNAPSHOT / 'files' / entry['path']
        if digest(path) != entry['sha256']:
            raise ValueError('publication snapshot changed: ' + str(path))
        files.append(({key: entry[key] for key in ['path', 'bytes', 'sha256']}, path))
    memory = {'publication-snapshot.json': (SNAPSHOT / 'snapshot.json').read_bytes()}
    for name in ['pbrs-grpc/tests/decode_workspace.rs', 'pbrs-grpc/src/workspace.rs',
                 'pbrs-grpc/src/codec/prost.rs', 'pbrs-grpc/src/compression/mod.rs',
                 'pbrs-grpc/src/wire/frame_reader.rs', 'Cargo.toml', 'Cargo.lock']:
        memory['runtime-source/' + name] = subprocess.check_output(['git', 'show', SOURCE + ':' + name], cwd=ROOT)
    for name, data in memory.items():
        files.append(({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, data))
    target = dest / 'raw.tar.gz'
    with target.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for entry, source in files:
                member = tarfile.TarInfo(entry['path'])
                member.size, member.mode = entry['bytes'], 0o644
                if isinstance(source, bytes):
                    tar.addfile(member, io.BytesIO(source))
                else:
                    with source.open('rb') as stream:
                        tar.addfile(member, stream)
    manifest = {'schema': 'pbrs.resource-capsule.v1', 'source': SOURCE, 'qualified': False,
                'archive': {'name': target.name, 'bytes': target.stat().st_size, 'sha256': digest(target)},
                'logical_bytes': sum(entry['bytes'] for entry, _ in files),
                'files': [entry for entry, _ in files]}
    (dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    checker = subprocess.check_output(['git', 'show', SOURCE + ':docs/evidence/grpc-validation-20261022/check.py'], cwd=ROOT)
    (dest / 'check.py').write_bytes(checker)
    subprocess.run([sys.executable, str(dest / 'check.py')], check=True)


def publish():
    if STATE.exists() and json.loads(STATE.read_text()).get('state') == 'published':
        print(STATE.read_text(), end='')
        return 0
    state = {'state': 'preparing', 'source_pin': SOURCE, 'qualified': False,
             'started_utc': now(), 'worktree': str(WORKTREE), 'push_attempts': []}
    atomic(STATE, state)
    try:
        report_path = OUTPUT / 'report.json'
        raw = report_path.read_bytes() if report_path.exists() else None
        read_error = None
        try:
            report = json.loads(raw) if raw is not None else None
            if report is not None and not isinstance(report, dict):
                raise ValueError('terminal report is not an object')
        except (ValueError, UnicodeError) as error:
            report, read_error = None, str(error)
        result = outcome(report, read_error)
        checkout = ROOT / 'work/architecture-c11'
        current_source = {'head': git('rev-parse', 'HEAD', cwd=checkout).stdout.strip(),
                          'status': git('status', '--porcelain', '--untracked-files=all', cwd=checkout).stdout.strip()}
        state['source_at_publication'] = current_source
        if current_source != {'head': SOURCE, 'status': ''}:
            result['state'] = 'incomplete'
            result['failures'].append('Frozen runtime source was not clean at publication.')
        if report is not None and report.get('state') == 'passed':
            try:
                for key in ['build', 'provenance']:
                    reference_files(report[key])
                build = json.loads(Path(report['build']['path']).read_text())
                provenance = json.loads(Path(report['provenance']['path']).read_text())
                if (build.get('source_pin') != SOURCE or build.get('profile') != 'release'
                        or build.get('all_features') is not True or build.get('copy_counts') is not True
                        or build.get('allocation_counter_allocator') is not False or build.get('exit_code') != 0
                        or provenance.get('source_pin') != SOURCE or provenance.get('runtime_source_equivalent') is not True
                        or provenance.get('build') != report['build']):
                    raise ValueError('Release build/feature/runtime provenance differs from the diagnostic contract.')
            except (OSError, ValueError, TypeError, KeyError) as error:
                result['validation_errors'] = result.get('validation_errors', []) + [str(error)]
                result['failures'].append(str(error))
                result['state'] = 'incomplete'
        preview_path = PREVIEW / 'report.json'
        try:
            preview_report = json.loads(preview_path.read_text())
            preview_outcome = outcome(preview_report, requested_seconds=30)
            if report is not None and report.get('state') == 'passed':
                if (report.get('build') != preview_report.get('build')
                        or report.get('provenance') != preview_report.get('provenance')
                        or not isinstance(report.get('preview'), dict)
                        or report['preview'].get('sha256') != digest(preview_path)):
                    raise ValueError('Day preview or build provenance differs from the retained successful preview.')
            if preview_outcome['state'] != 'passed':
                raise ValueError('Pinned preview has not passed all30-second diagnostic checks.')
        except (OSError, ValueError) as error:
            result['validation_errors'] = result.get('validation_errors', []) + [str(error)]
            result['failures'].append(str(error))
            if result['state'] == 'passed':
                result['state'] = 'incomplete'
        for candidate, directory, seconds in [(report, OUTPUT, 86400),
                                               (locals().get('preview_report'), PREVIEW, 30)]:
            if candidate is not None and candidate.get('state') == 'passed':
                try:
                    validate_events(candidate, directory, seconds)
                except (OSError, ValueError, TypeError, KeyError) as error:
                    result['validation_errors'] = result.get('validation_errors', []) + [str(error)]
                    result['failures'].append(str(error))
                    if result['state'] == 'passed':
                        result['state'] = 'incomplete'
        snapshot = snapshot_files(report)
        if snapshot['reference_validation_errors']:
            result['validation_errors'] = result.get('validation_errors', []) + snapshot['reference_validation_errors']
            result['failures'].extend(snapshot['reference_validation_errors'])
            if result['state'] == 'passed':
                result['state'] = 'incomplete'
        state.update(outcome=result, snapshot={'path': str(SNAPSHOT / 'snapshot.json'), 'sha256': digest(SNAPSHOT / 'snapshot.json')})
        atomic(STATE, state)
        if raw is not None and report_path.read_bytes() != raw:
            raise ValueError('terminal report changed while snapshotting')
        if WORKTREE.exists():
            raise ValueError('retained publication worktree requires review')
        git('fetch', 'origin', 'main')
        if git('merge-base', '--is-ancestor', SOURCE, 'origin/main', check=False).returncode:
            raise ValueError('runtime source is absent from origin/main')
        git('worktree', 'add', '--detach', str(WORKTREE), 'origin/main')
        dest = WORKTREE / EVIDENCE
        dest.mkdir(parents=True, exist_ok=False)
        archive(dest, snapshot)
        (dest / 'results.json').write_text(json.dumps({'source_pin': SOURCE, 'diagnostic': DIAGNOSTIC,
            'requested_seconds': 86400, **result, 'source_at_publication': current_source,
            'scope': 'Cycles repeat the same independent-peer fixture; they are not additional distinct production tests.'}, indent=2, allow_nan=False) + '\n')
        duration = result['duration_actual_seconds']
        elapsed = 'unavailable' if duration is None else f'{duration:,.2f} seconds ({duration / 3600:.2f} hours)'
        failures = '\n'.join('- ' + item.replace('\n', ' ') for item in result['failures']) or '- None reported.'
        (dest / 'README.md').write_text(f'''# Prost cache diagnostic, 2026-10-23

| Check | Result |
|---|---|
| Requested duration | 24 hours |
| Recorded duration | {elapsed} |
| Diagnostic status | {result['state']} |
| Completed fixture cycles | {result['completed_cycles']} |
| Child exit code | {result['exit_code']} |
| Production qualified | No |

Runtime source: `{SOURCE}`.

This shared-host diagnostic repeats the independent TCP/HTTP2 compressed-decode
fixture with Prost and retained-cache counters. Each cycle repeats the same
fixture; cycles are not additional distinct production tests. Preview completion
does not satisfy the requested day. This is separate from the C8 and C11 pbrs
resource campaigns and does not establish production readiness or broad speed
superiority. The archived provenance identifies the diagnostic test-only overlay,
unchanged runtime files, build profile, compiler tools and executable hashes.

Reported failures:

{failures}

The archive contains immutable pack-time copies of the day and preview records,
fixture/controllers, samples, progress and command/provenance records. ELF bytes
are omitted; their hashes and sizes are retained in publication-snapshot.json.

Verify archived members:

```sh
python3 {EVIDENCE}/check.py
```
''')
        index = WORKTREE / 'docs/evidence/README.md'
        link = (f'{MARKER}\nThe [Prost cache diagnostic, source `{SOURCE[:8]}`]({EVIDENCE.name}/README.md) '
                'has a terminal diagnostic outcome; its scope and qualification limits apply.\n\n')
        anchor = '## Benchmark coverage and campaign readiness'
        text = index.read_text()
        if MARKER in text:
            raise ValueError('terminal Prost diagnostic marker already exists')
        index.write_text(text.replace(anchor, link + anchor, 1) if anchor in text else text + '\n' + link)
        git('add', '--', str(EVIDENCE), 'docs/evidence/README.md', cwd=WORKTREE)
        git('commit', '-m', 'Record the Prost cache diagnostic outcome', cwd=WORKTREE)
        state['evidence_commit'] = git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip()
        atomic(STATE, state)
        for attempt in range(1, 4):
            pushed = git('push', '--porcelain', 'origin', 'HEAD:main', cwd=WORKTREE, check=False)
            state['push_attempts'].append({'attempt': attempt, 'returncode': pushed.returncode,
                                           'stdout': pushed.stdout, 'stderr': pushed.stderr})
            if pushed.returncode == 0:
                state.update(state='published', completed_utc=now(),
                             evidence_commit=git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip())
                atomic(STATE, state)
                print(json.dumps(state))
                return 0
            atomic(STATE, state)
            if attempt == 3:
                break
            git('fetch', 'origin', 'main', cwd=WORKTREE)
            old = state['evidence_commit']
            if git('cat-file', '-e', 'origin/main:' + str(EVIDENCE), cwd=WORKTREE, check=False).returncode == 0:
                raise ValueError('remote already has this owned evidence path')
            # Only this unique detached publication worktree is reset. Restore
            # our artifact onto fresh main; preserve all other evidence/index.
            git('reset', '--hard', 'origin/main', cwd=WORKTREE)
            git('checkout', old, '--', str(EVIDENCE), cwd=WORKTREE)
            text = index.read_text()
            if MARKER in text:
                raise ValueError('remote already has this diagnostic marker')
            index.write_text(text.replace(anchor, link + anchor, 1) if anchor in text else text + '\n' + link)
            git('add', '--', str(EVIDENCE), 'docs/evidence/README.md', cwd=WORKTREE)
            git('commit', '-m', 'Record the Prost cache diagnostic outcome', cwd=WORKTREE)
            state.setdefault('retained_attempt_commits', []).append(old)
            state['evidence_commit'] = git('rev-parse', 'HEAD', cwd=WORKTREE).stdout.strip()
        raise ValueError('normal push failed three times; evidence commits retained')
    except Exception as error:
        state.update(state='failed', error=str(error), completed_utc=now())
        atomic(STATE, state)
        traceback.print_exc()
        return 1


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'PREPARED_NOT_RUN', 'source_pin': SOURCE,
                          'output': str(OUTPUT), 'evidence': str(EVIDENCE), 'qualified': False}))
    else:
        if not OUTPUT.is_dir():
            raise SystemExit('terminal day output does not exist')
        with (OUTPUT / '.publication.lock').open('a') as lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            raise SystemExit(publish())
