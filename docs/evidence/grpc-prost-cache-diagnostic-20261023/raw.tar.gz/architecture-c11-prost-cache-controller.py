#!/usr/bin/env python3
"""Prepare, build and run the isolated sustained Prost decoded-cache diagnostic.

No action is implicit. Runtime source stays at the immutable C11 pin; only a new
integration test is added in its own worktree. All live files stay outside the
frozen evidence packager's architecture-c11* glob. This is a repeated independent
peer fixture, not an overall product or comparative-performance qualification.
"""

import argparse
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import signal
import subprocess
import sys
import time
import tomllib
import traceback


ROOT = Path("/workspace/pure-protobuf")
Q = ROOT / "work/qualification"
TREE = ROOT / "work/architecture-c11-prost-day"
PINS = Q / "architecture-c11-source-pins.json"
PREFIX = "architecture-c11-prost-cache"
FIXTURE = Q / (PREFIX + "-fixture.rs")
WRAPPER = Q / (PREFIX + "-wrapper.rs")
PROVENANCE = Q / (PREFIX + "-provenance.json")
EQUIVALENCE = Q / (PREFIX + "-source-equivalence.json")
PACKAGE = Q / (PREFIX + "-build")
OVERLAY = "pbrs-grpc/tests/prost_cache_day.rs"
ORIGINAL = "pbrs-grpc/tests/decode_workspace.rs"
SCRIPT = Path(__file__).resolve()
PUBLISHER = SCRIPT.with_name(PREFIX + "-publish.py")
EMPTY = hashlib.sha256(b"").hexdigest()
DIAGNOSTIC = "repeated independent-peer compressed decode fixture"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def load(path):
    return json.loads(path.read_text())


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(data)
    return h.hexdigest()


def ref(path):
    return {"path": str(path), "sha256": digest(path), "bytes": path.stat().st_size}


def verify(reference):
    assert ref(Path(reference["path"])) == reference, reference


def atomic(path, value):
    temporary = path.with_name(path.name + f".next.{os.getpid()}")
    with temporary.open("w") as stream:
        json.dump(value, stream, indent=2)
        stream.write("\n")
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def publish_once(path, value, staging):
    temporary = staging / (path.name + f".publish.{os.getpid()}")
    atomic(temporary, value)
    os.link(temporary, path)  # Exclusive, complete publication; never overwrite evidence.
    temporary.unlink()


def git(*arguments, cwd=TREE):
    return subprocess.check_output(["git", *arguments], cwd=cwd)


def pin():
    data = load(PINS)
    candidate = data["candidate_runtime"]
    assert candidate == "beb4ecd9a9b2143c440892607d5b486318062b61"
    return candidate


def generated_fixture():
    original = git("show", pin() + ":" + ORIGINAL, cwd=ROOT)
    attribute = b'#[tokio::test(flavor = "current_thread")]\n'
    ending = b"    assert_eq!(held_raw.0, first);\n}\n"
    assert original.count(attribute) == original.count(ending) == 1
    copied = original.replace(attribute, b"", 1).replace(
        ending, b"    assert_eq!(held_raw.0, first);\n    peer.prost_cache_shutdown().await;\n}\n", 1)
    expected = copied + WRAPPER.read_bytes()
    assert FIXTURE.read_bytes() == expected, "fixture differs from the reviewed transformation"
    return original, expected


def equivalence():
    candidate = pin()
    assert git("rev-parse", "HEAD").decode().strip() == candidate
    assert subprocess.run(["git", "symbolic-ref", "-q", "HEAD"], cwd=TREE, capture_output=True).returncode == 1
    assert git("diff", "HEAD", "--binary") == b"", "tracked source changed"
    untracked = git("ls-files", "--others", "--exclude-standard", "-z").decode().rstrip("\0").split("\0")
    assert untracked == [OVERLAY], untracked
    original, expected = generated_fixture()
    assert (TREE / OVERLAY).read_bytes() == expected
    files = []
    for entry in git("ls-tree", "-rz", candidate).split(b"\0"):
        if not entry:
            continue
        identity, name = entry.split(b"\t", 1)
        relative = os.fsdecode(name)
        if relative.startswith("docs/evidence/"):
            continue  # The sole sparse exclusion; no runtime source is excluded.
        mode, kind, object_id = identity.decode().split()
        assert kind == "blob", relative
        path = TREE / relative
        data = os.fsencode(os.readlink(path)) if mode == "120000" else path.read_bytes()
        actual_blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert actual_blob == object_id, relative
        files.append({"path": relative, "bytes": len(data), "git_blob": object_id,
                      "sha256": hashlib.sha256(data).hexdigest()})
    return {"source_pin": candidate, "runtime_source_equivalent": True,
            "source": {"head": candidate, "tracked_diff_sha256": EMPTY, "untracked_overlay": [OVERLAY]},
            "excluded_nonruntime_prefix": "docs/evidence/", "files": files,
            "original_fixture_sha256": hashlib.sha256(original).hexdigest(),
            "fixture": ref(FIXTURE), "wrapper": ref(WRAPPER),
            "test_only_changes": ["remove the original Tokio test attribute", "await peer abort/join at the helper end", "append sustained duration/resource wrapper"],
            "qualified": False}


def live(name):
    return Q / ("resource-" + PREFIX + "-" + name)


def prepare():
    assert not TREE.exists(), "do not overwrite an existing diagnostic worktree"
    _, fixture = generated_fixture()
    subprocess.run(["git", "worktree", "add", "--detach", "--no-checkout", str(TREE), pin()], cwd=ROOT, check=True)
    subprocess.run(["git", "sparse-checkout", "set", "--no-cone", "--stdin"], cwd=TREE,
                   input="/*\n!/docs/evidence/\n", text=True, check=True)
    subprocess.run(["git", "checkout", "--detach", pin()], cwd=TREE, check=True)
    with (TREE / OVERLAY).open("xb") as stream:
        stream.write(fixture)
    proof = equivalence()
    print(json.dumps({"state": "prepared", "source": proof["source"], "fixture": proof["fixture"]}))


def build():
    assert load(Q / "architecture-c11-pipeline-v2-state.json")["state"] == "passed"
    assert not PACKAGE.exists() and not PROVENANCE.exists() and not EQUIVALENCE.exists()
    before = equivalence()
    output = live("build")
    output.mkdir(exist_ok=False)
    env = os.environ.copy()
    for key in ["RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "ASAN_OPTIONS"]:
        env.pop(key, None)
    env.update(CARGO_TARGET_DIR=str(ROOT / "work/rpc-target"), CARGO_BUILD_JOBS="1", RUSTUP_TOOLCHAIN="stable")
    command = ["nice", "-n", "10", str(ROOT / "work/run-rust"), "cargo", "+stable", "test", "--locked", "-p", "pbrs-grpc", "--release", "--all-features", "--test", "prost_cache_day", "--no-run", "--message-format=json"]
    started = now()
    with (output / "build.stdout.jsonl").open("xb") as stdout, (output / "build.stderr.log").open("xb") as stderr:
        completed = subprocess.run(command, cwd=TREE, env=env, stdout=stdout, stderr=stderr, timeout=1800)
    assert completed.returncode == 0, "build failed; preserve live build logs"
    assert equivalence() == before
    artifacts = [message for line in (output / "build.stdout.jsonl").read_text().splitlines()
                 if (message := json.loads(line)).get("reason") == "compiler-artifact"
                 and message.get("target", {}).get("name") == "prost_cache_day" and message.get("executable")]
    assert len(artifacts) == 1
    executable = Path(artifacts[0]["executable"])
    with executable.open("rb") as stream:
        assert stream.read(4) == b"\x7fELF"
    staging = output / "immutable-build-package"
    staging.mkdir()
    shutil.copy2(executable, staging / "fixture-test")
    for name in ["build.stdout.jsonl", "build.stderr.log"]:
        shutil.copy2(output / name, staging / name)
    tools = {name: subprocess.check_output([str(ROOT / "work/run-rust"), name, "+stable", "--version"], env=env, text=True).strip() for name in ["rustc", "cargo"]}
    record = {"source_pin": pin(), "command": command, "exit_code": 0, "started_utc": started,
              "completed_utc": now(), "profile": "release", "all_features": True,
              "copy_counts": True, "allocation_counter_allocator": False, "tools": tools,
              "binary": {"path": str(PACKAGE / "fixture-test"), "sha256": digest(staging / "fixture-test"), "bytes": (staging / "fixture-test").stat().st_size},
              "logs": {name: {"path": str(PACKAGE / name), "sha256": digest(staging / name), "bytes": (staging / name).stat().st_size} for name in ["build.stdout.jsonl", "build.stderr.log"]},
              "source": before["source"], "fixture": ref(FIXTURE), "qualified": False}
    atomic(staging / "build.json", record)
    staging.rename(PACKAGE)
    publish_once(EQUIVALENCE, before, output)
    provenance = {"source_pin": pin(), "runtime_source_equivalent": True, "source_equivalence": ref(EQUIVALENCE),
                  "build": ref(PACKAGE / "build.json"), "binary": ref(PACKAGE / "fixture-test"),
                  "fixture": ref(FIXTURE), "wrapper": ref(WRAPPER), "pins": ref(PINS),
                  "build_driver": ref(SCRIPT), "tools": tools,
                  "original_fixture_sha256": before["original_fixture_sha256"],
                  "diagnostic": DIAGNOSTIC, "qualified": False}
    publish_once(PROVENANCE, provenance, output)
    print(json.dumps({"state": "built", "provenance": ref(PROVENANCE)}))


def readiness(day=False):
    proof = equivalence()
    provenance = load(PROVENANCE)
    assert provenance["source_pin"] == pin() and provenance["runtime_source_equivalent"] is True
    for key in ["source_equivalence", "build", "binary", "fixture", "wrapper", "pins", "build_driver"]:
        verify(provenance[key])
    assert load(EQUIVALENCE) == proof
    artifacts = [message for line in (PACKAGE / "build.stdout.jsonl").read_text().splitlines()
                 if (message := json.loads(line)).get("reason") == "compiler-artifact"
                 and message.get("target", {}).get("name") == "prost_cache_day" and message.get("executable")]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    expected_features = set(tomllib.loads((TREE / "pbrs-grpc/Cargo.toml").read_text())["features"])
    assert set(artifact["features"]) == expected_features
    assert {"prost", "copy-counts"} <= expected_features
    assert artifact["profile"]["opt_level"] == "3"
    assert artifact["profile"]["debug_assertions"] is False and artifact["profile"]["test"] is True
    result = {"build": ref(PACKAGE / "build.json"), "provenance": ref(PROVENANCE), "source": proof["source"],
              "cargo_artifact_attestation": {"profile": artifact["profile"], "features": artifact["features"], "target": artifact["target"]}}
    if day:
        preview_path = Q / (PREFIX + "-preview-terminal.json")
        preview = load(preview_path)
        assert preview["state"] == "passed" and preview["requested_seconds"] == 30
        assert preview["duration_actual_seconds"] >= 30 and preview["completed_cycles"] > 0
        assert preview["source_pin_verified_at_end"] is True
        assert preview["build"] == result["build"] and preview["provenance"] == result["provenance"]
        validate_progress(preview["final_progress"], 30)
        assert preview["process_limits_verified"] is True and preview["exit_code"] == 0
        result["preview"] = ref(preview_path)
    return result


def caps(seconds):
    return {"address_space": 1073741824, "file_descriptors": 128,
            "same_uid_processes": 4096, "cpu_seconds": seconds + 30}


def validate_progress(progress, seconds):
    assert progress["state"] == "completed" and progress["requested_seconds"] == seconds
    assert progress["elapsed_seconds"] >= seconds and progress["completed_cycles"] > 0
    assert progress["retained_capacity"] == progress["retained_buffers"] == 0
    assert progress["acquired"] == progress["released"]
    assert progress["fd_count"] <= progress["baseline_fd_count"] < 128
    assert 0 < progress["rss_bytes"] < 1073741824


def process_sample(pid):
    try:
        status = (Path("/proc") / str(pid) / "status").read_text()
        rss = next((int(line.split()[1]) * 1024 for line in status.splitlines() if line.startswith("VmRSS:")), None)
        return {"utc": now(), "pid": pid, "rss_bytes": rss,
                "fd_count": len(list((Path("/proc") / str(pid) / "fd").iterdir()))}
    except (FileNotFoundError, ProcessLookupError):
        return {"utc": now(), "pid": pid, "exited": True}


def experiment(name, reserved=False):
    seconds = 30 if name == "preview" else 86400
    ready = readiness(day=name == "day")
    output = live(name)
    if not reserved:
        output.mkdir(exist_ok=False)
    assert not any((output / item).exists() for item in ["report.json", "events.jsonl", "progress.json", "stdout.log", "stderr.log"])
    expected_limits = caps(seconds)
    limits = [(resource.RLIMIT_AS, "address_space"), (resource.RLIMIT_NOFILE, "file_descriptors"),
              (resource.RLIMIT_NPROC, "same_uid_processes"), (resource.RLIMIT_CPU, "cpu_seconds")]

    def limit_child():
        for number, key in limits:
            resource.setrlimit(number, (expected_limits[key], expected_limits[key]))

    env = os.environ.copy()
    env.update(PBRS_PROST_CACHE_SECONDS=str(seconds), PBRS_PROST_CACHE_OUTPUT=str(output))
    command = [str(PACKAGE / "fixture-test"), "--exact", "prost_cache_sustained", "--nocapture", "--test-threads=1"]
    report = {"state": "incomplete", "source_pin": pin(), "qualified": False, "diagnostic": DIAGNOSTIC,
              "requested_seconds": seconds, "started_utc": now(), "supervisor_pid": os.getpid(),
              "source_before": ready["source"], "build": ready["build"], "provenance": ready["provenance"],
              "cargo_artifact_attestation": ready["cargo_artifact_attestation"],
              "preview": ready.get("preview"), "limits": expected_limits, "command": command,
              "completed_cycles": 0, "exit_code": None, "failures": []}
    child = None
    started = time.monotonic()
    try:
        with (output / "stdout.log").open("xb") as stdout, (output / "stderr.log").open("xb") as stderr, (output / "samples.jsonl").open("x") as samples:
            child = subprocess.Popen(command, cwd=TREE, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, start_new_session=True,
                                     close_fds=True, preexec_fn=limit_child)
            report["pid"] = child.pid
            actual_limits = {key: resource.prlimit(child.pid, number) for number, key in limits}
            report["actual_process_limits"] = actual_limits
            assert all(actual_limits[key] == (value, value) for key, value in expected_limits.items())
            report["process_limits_verified"] = True
            atomic(output / "supervisor-state.json", {**report, "state": "running"})
            while child.poll() is None:
                samples.write(json.dumps(process_sample(child.pid)) + "\n")
                samples.flush()
                if time.monotonic() - started > seconds + 90:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                    raise TimeoutError("finite wall guard exceeded")
                time.sleep(1)
            report["exit_code"] = child.wait()
        progress = load(output / "progress.json")
        report["final_progress"] = progress
        report["duration_actual_seconds"] = progress.get("elapsed_seconds")
        report["completed_cycles"] = progress.get("completed_cycles", 0)
        report["source_after"] = equivalence()["source"]
        report["runtime_source_equivalent"] = True
        report["source_pin_verified_at_end"] = report["source_before"] == report["source_after"]
        assert report["exit_code"] == 0
        validate_progress(progress, seconds)
        events = [json.loads(line) for line in (output / "events.jsonl").read_text().splitlines()]
        cycles = [event for event in events if event["event"] == "cycle_completed"]
        assert [event["completed_cycles"] for event in cycles] == list(range(1, report["completed_cycles"] + 1))
        assert len(events) == len(cycles) + 1 and events[-1] == progress
        assert all(event["retained_capacity"] == event["retained_buffers"] == 0 and event["acquired"] == event["released"] for event in events)
        stdout = (output / "stdout.log").read_text()
        assert "test prost_cache_sustained ... ok" in stdout and "1 passed; 0 failed; 0 ignored;" in stdout
        assert report["source_pin_verified_at_end"] is True
        report["state"] = "passed"
    except BaseException as error:
        report["state"] = "failed" if child is not None else "incomplete"
        report["failures"].append(repr(error))
        traceback.print_exc()
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
        if child is not None:
            report["exit_code"] = child.wait()
        if (output / "progress.json").exists():
            report["final_progress"] = load(output / "progress.json")
            report["completed_cycles"] = report["final_progress"].get("completed_cycles", 0)
            report["duration_actual_seconds"] = report["final_progress"].get("elapsed_seconds")
        try:
            report["source_after"] = equivalence()["source"]
            report["runtime_source_equivalent"] = True
            report["source_pin_verified_at_end"] = report["source_before"] == report["source_after"]
        except Exception as source_error:
            report["source_pin_verified_at_end"] = False
            report["failures"].append("terminal source verification: " + repr(source_error))
    report.update(completed_utc=now(), supervisor_wall_seconds=time.monotonic() - started)
    atomic(output / "report.json", report)
    atomic(output / "supervisor-state.json", {"state": "terminal", "report": ref(output / "report.json")})
    snapshot = Q / (PREFIX + ("-preview-terminal.json" if name == "preview" else "-day-terminal.json"))
    publish_once(snapshot, report, output)
    return 0 if report["state"] == "passed" else 1


def launch_day(grant_path):
    ready = readiness(day=True)
    grant = load(grant_path)
    assert grant["root_granted"] is True and grant["source_pin"] == pin()
    assert grant["action"] == "launch-prost-cache-diagnostic-day"
    output = live("day")
    output.mkdir(exist_ok=False)
    harness = output / "harness"
    harness.mkdir()
    for path in [SCRIPT, PUBLISHER, FIXTURE, WRAPPER, PINS, PROVENANCE, grant_path]:
        shutil.copy2(path, harness / path.name)
    launch = {"state": "launching", "source_pin": pin(), "qualified": False,
              "requested_seconds": 86400, "started_utc": now(), "readiness": ready,
              "grant": ref(grant_path), "harness": {path.name: ref(path) for path in harness.iterdir()}}
    atomic(output / "launch.json", launch)
    with (output / "supervisor.log").open("xb") as log:
        child = subprocess.Popen([sys.executable, str(harness / SCRIPT.name), "--supervise-day"],
                                 cwd=ROOT, stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 close_fds=True, start_new_session=True)
    launch.update(state="running", supervisor_pid=child.pid)
    atomic(output / "launch.json", launch)
    publish_once(Q / (PREFIX + "-day-launch-snapshot.json"),
                 {"snapshot_utc": now(), "state": "running", "no_day_result": True,
                  "launch": launch, "live_output": str(output), "qualified": False}, output)
    print(json.dumps({"state": "running", "supervisor_pid": child.pid, "output": str(output)}))


def supervise_day():
    output = live("day")
    with (output / "supervisor.lock").open("x") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        outcome = 1
        try:
            try:
                launch = load(output / "launch.json")
                for reference in launch["harness"].values():
                    verify(reference)
                verify(launch["grant"])
                outcome = experiment("day", reserved=True)
            except BaseException as error:
                traceback.print_exc()
                if not (output / "report.json").exists():
                    atomic(output / "report.json", {
                        "state": "incomplete", "source_pin": pin(), "qualified": False,
                        "diagnostic": DIAGNOSTIC, "requested_seconds": 86400,
                        "duration_actual_seconds": None, "completed_cycles": 0,
                        "exit_code": None, "supervisor_failure": True,
                        "failures": [repr(error)], "completed_utc": now(),
                    })
        finally:
            # Attempt truthful publication even if creating the terminal report
            # itself failed. The publisher accepts missing reports as incomplete.
            publication = subprocess.run([sys.executable, str(PUBLISHER), "--execute"], cwd=ROOT)
        return publication.returncode or outcome


def main():
    assert __debug__, "run without Python -O"
    parser = argparse.ArgumentParser(description=__doc__)
    modes = parser.add_mutually_exclusive_group(required=True)
    for name in ["prepare", "build", "preview", "launch-day", "supervise-day", "check-ready"]:
        modes.add_argument("--" + name, action="store_true")
    parser.add_argument("--grant", type=Path, default=Q / (PREFIX + "-day-grant.json"))
    args = parser.parse_args()
    if args.prepare:
        prepare()
    elif args.build:
        build()
    elif args.preview:
        return experiment("preview")
    elif args.launch_day:
        launch_day(args.grant)
    elif args.supervise_day:
        return supervise_day()
    else:
        print(json.dumps(readiness(day=True), indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
