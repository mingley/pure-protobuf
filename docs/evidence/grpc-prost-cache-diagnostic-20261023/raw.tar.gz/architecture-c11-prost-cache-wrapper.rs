#[cfg(not(feature = "copy-counts"))]
compile_error!("the sustained Prost cache diagnostic requires copy-counts");

impl Peer {
    async fn prost_cache_shutdown(mut self) {
        self.task.abort();
        let stopped = (&mut self.task).await;
        assert!(
            stopped.is_err_and(|error| error.is_cancelled()),
            "the independent peer abort must complete before the next cycle"
        );
    }
}

fn prost_cache_process_sample() -> (usize, u64) {
    let fds = std::fs::read_dir("/proc/self/fd")
        .expect("process descriptors")
        .count();
    let status = std::fs::read_to_string("/proc/self/status").expect("process status");
    let rss_kib = status
        .lines()
        .find_map(|line| line.strip_prefix("VmRSS:"))
        .expect("resident memory measurement")
        .split_whitespace()
        .next()
        .expect("resident memory value")
        .parse::<u64>()
        .expect("resident memory number");
    (fds, rss_kib * 1024)
}

fn prost_cache_progress(path: &std::path::Path, event: &serde_json::Value) {
    use std::io::Write as _;
    let temporary = path.with_extension("json.next");
    let mut file = std::fs::File::create(&temporary).expect("progress temporary");
    serde_json::to_writer(&mut file, event).expect("progress JSON");
    file.write_all(b"\n").expect("progress newline");
    file.sync_all().expect("durable cycle progress");
    drop(file);
    std::fs::rename(temporary, path).expect("atomic progress replacement");
}

#[tokio::test(flavor = "current_thread")]
async fn prost_cache_sustained() {
    use std::io::Write as _;
    let start = std::time::Instant::now();
    let seconds = std::env::var("PBRS_PROST_CACHE_SECONDS")
        .expect("explicit diagnostic duration")
        .parse::<u64>()
        .expect("integer diagnostic duration");
    assert!((30..=86400).contains(&seconds));
    let directory = std::path::PathBuf::from(
        std::env::var_os("PBRS_PROST_CACHE_OUTPUT").expect("explicit diagnostic output"),
    );
    let progress = directory.join("progress.json");
    let mut events = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(directory.join("events.jsonl"))
        .expect("exclusive diagnostic event log");
    let (baseline_fds, _) = prost_cache_process_sample();
    let mut cycles = 0u64;
    while start.elapsed() < Duration::from_secs(seconds) {
        tokio::time::timeout(
            Duration::from_secs(60),
            decoded_storage_preserves_ownership_validation_and_cleanup(),
        )
        .await
        .expect("complete ownership/validation/lifecycle fixture cycle within 60 seconds");
        // The peer was actually joined in the helper. Give the native client
        // driver its close notification, then require descriptor recovery.
        bounded(async {
            loop {
                tokio::task::yield_now().await;
                if prost_cache_process_sample().0 <= baseline_fds {
                    break;
                }
            }
        })
        .await;
        let counts = pbrs_grpc::copy_counts::retained_decode_counts();
        assert_eq!(counts.retained_capacity, 0);
        assert_eq!(counts.retained_buffers, 0);
        assert_eq!(counts.acquired, counts.released);
        assert!(counts.peak_retained_capacity <= counts.capacity_limit);
        let (fd_count, rss_bytes) = prost_cache_process_sample();
        assert!(
            fd_count <= baseline_fds,
            "descriptors did not return to the initial count"
        );
        cycles += 1;
        let event = serde_json::json!({
            "event": "cycle_completed", "state": "running", "pid": std::process::id(),
            "completed_cycles": cycles, "elapsed_seconds": start.elapsed().as_secs_f64(),
            "requested_seconds": seconds, "fd_count": fd_count, "baseline_fd_count": baseline_fds,
            "rss_bytes": rss_bytes, "retained_capacity": counts.retained_capacity,
            "retained_buffers": counts.retained_buffers, "acquired": counts.acquired,
            "released": counts.released, "peak_retained_capacity": counts.peak_retained_capacity,
            "peak_retained_buffers": counts.peak_retained_buffers,
            "rejected_budget": counts.rejected_budget, "rejected_oversize": counts.rejected_oversize,
        });
        serde_json::to_writer(&mut events, &event).expect("completed cycle event");
        events.write_all(b"\n").expect("completed cycle newline");
        events.sync_data().expect("durable completed cycle event");
        prost_cache_progress(&progress, &event);
    }
    assert!(cycles > 0);
    let counts = pbrs_grpc::copy_counts::retained_decode_counts();
    let (fd_count, rss_bytes) = prost_cache_process_sample();
    let completed = serde_json::json!({
        "event": "duration_completed", "state": "completed", "pid": std::process::id(),
        "completed_cycles": cycles, "elapsed_seconds": start.elapsed().as_secs_f64(),
        "requested_seconds": seconds, "fd_count": fd_count, "baseline_fd_count": baseline_fds,
        "rss_bytes": rss_bytes, "retained_capacity": counts.retained_capacity,
        "retained_buffers": counts.retained_buffers, "acquired": counts.acquired,
        "released": counts.released, "peak_retained_capacity": counts.peak_retained_capacity,
        "peak_retained_buffers": counts.peak_retained_buffers,
    });
    serde_json::to_writer(&mut events, &completed).expect("completed duration event");
    events.write_all(b"\n").expect("completed duration newline");
    events.sync_all().expect("durable terminal event");
    prost_cache_progress(&progress, &completed);
}
