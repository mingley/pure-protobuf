from pathlib import Path
import json,hashlib,subprocess
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';tree=root/'work/architecture-c15-bytes-reuse'
# Apply only once, after the production candidate's focused controls are closed.
closed=json.loads((q/'architecture-c15-bytes-reuse-focused-results.json').read_text());assert closed['state']=='passed'
m=json.loads((q/'architecture-c15-bytes-reuse-candidate-v5-prepared.json').read_text());assert all(hashlib.sha256((tree/f).read_bytes()).hexdigest()==h for f,h in m['files'].items())
module=(q/'architecture-c15-bytes-probe-allocator.rs').read_text().replace('; 4]', '; 5]')
(tree/'pbrs-grpc/src/c15_encode_probe.rs').write_text(module)
p=tree/'pbrs-grpc/src/lib.rs';p.write_text(p.read_text()+'\n// Private C15 site diagnostic only, absent from the production candidate.\n#[cfg(test)]\n#[allow(unsafe_code)]\nmod c15_encode_probe;\n')
p=tree/'pbrs-grpc/src/wire/encode.rs';s=p.read_text();pairs=[('''        active.bytes.reserve(len);''','''        #[cfg(test)]
        let scope = crate::c15_encode_probe::enter(1);
        active.bytes.reserve(len);
        #[cfg(test)]
        drop(scope);'''),('''        let result = msg.encode_payload_bufmut(&mut active.bytes).and_then(|()| {''','''        let encoded = {
            #[cfg(test)]
            let _scope = crate::c15_encode_probe::enter(4);
            msg.encode_payload_bufmut(&mut active.bytes)
        };
        let result = encoded.and_then(|()| {'''),('''            head.reserve(codec::HEADER_LEN + body.len() / 2 + 32);''','''            #[cfg(test)]
            let scope = crate::c15_encode_probe::enter(2);
            head.reserve(codec::HEADER_LEN + body.len() / 2 + 32);
            #[cfg(test)]
            drop(scope);'''),('''                codec.encode_into(body, gzip_level, &mut writer)?;''','''                #[cfg(test)]
                let _scope = crate::c15_encode_probe::enter(3);
                codec.encode_into(body, gzip_level, &mut writer)?;''')]
for a,b in pairs:
 assert s.count(a)==1, a
 s=s.replace(a,b)
test=(q/'architecture-c15-bytes-probe-test.rs').read_text()
a='''                            assert!(scratch_caps.iter().all(|cap| *cap == 0));
                            assert_eq!(sites[1].0, messages as u64);''';b='''                            assert!(scratch_caps.iter().all(|cap| *cap == encoded_len));
                            assert_eq!(sites[1].0, 1);
                            assert_eq!(sites[4], (0, 0), "built-in Prost appends without a temporary");''';assert test.count(a)==1;test=test.replace(a,b)
custom=r'''
    // Existing custom encoders remain valid through the generic bridge. Measure
    // its cost explicitly rather than treating every CodecMessage as built-in.
    struct Legacy(Payload);
    impl CodecMessage for Legacy {
        fn encoded_len(&self) -> usize { ::prost::Message::encoded_len(&self.0) }
        fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.write_contiguous(|buf| ::prost::Message::encode(&self.0, buf).map_err(|error| Status::internal(error.to_string())))
        }
        fn decode_payload(bytes: Bytes) -> Result<Self, Status> {
            <Payload as ::prost::Message>::decode(bytes).map(Self).map_err(|error| Status::internal(error.to_string()))
        }
        fn empty() -> Self { Self(Payload::default()) }
    }
    #[test]
    fn legacy_contiguous_bridge_allocation_site_cost() {
        for size in [1024, 1048576] {
            let message = Legacy(Payload { body: vec![0; size] });
            let encoded_len = message.encoded_len();
            let mut scratch = EncodeScratch::new();
            let mut sink = SegSink::new();
            probe::reset();
            for _ in 0..4 {
                append_frame_with_ready(&mut sink, &mut scratch, &message, Some(CompressionAlgorithm::Gzip), MessageLimits::unlimited(), 6, 4).expect("legacy encode");
            }
            let sites = probe::snapshot();
            let frame = sink.finish();
            let wire_bytes = frame.total_len();
            let mut bytes = Bytes::from(frame.concat());
            let mut decoded = 0;
            while let Some(frame) = crate::codec::pop_from_chunk(&mut bytes, MessageLimits::unlimited()).expect("framing") {
                let raw = CompressionAlgorithm::Gzip.decode(&frame.payload).expect("gzip");
                let back = Legacy::decode_payload(Bytes::from(raw)).expect("prost");
                assert_eq!(back.0.body, message.0.body);
                decoded += 1;
            }
            assert_eq!(decoded, 4);
            assert_eq!(sites[1].0, 1, "canonical plaintext allocation reused");
            assert!(sites[4].0 >= 4, "legacy temporary bridge cost remains explicit");
            eprintln!("C15_ENCODE_CUSTOM size={size} encoded_len={encoded_len} messages=4 wire_bytes={wire_bytes} sites={sites:?}");
        }
    }
'''
pos=test.rfind('}');test=test[:pos]+custom+test[pos:]
s+=test;p.write_text(s)
(q/'architecture-c15-bytes-reuse-site-allocator.rs').write_text(module);(q/'architecture-c15-bytes-reuse-site-test.rs').write_text(test)
paths=[tree/'pbrs-grpc/src/lib.rs',tree/'pbrs-grpc/src/wire/encode.rs',tree/'pbrs-grpc/src/c15_encode_probe.rs']
record={'qualified':False,'state':'private_diagnostic_prepared_not_compiled','production_prepared_sha256':hashlib.sha256((q/'architecture-c15-bytes-reuse-candidate-v5-prepared.json').read_bytes()).hexdigest(),'shared_tags':'1scratchreserve,2initialoutputreserve,3compressorcall includingoutputgrowth retainbaseline meanings; added4serialization-onlycandidateextra tag detectsfallbacktemporary','cases':'same32builtinProstcases/80messages +2legacycustomcontiguouscases/8messages; actual results pending','files':{str(p.relative_to(tree)):hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}}
(q/'architecture-c15-bytes-reuse-site-prepared.json').write_text(json.dumps(record,indent=2)+'\n');print(record)
