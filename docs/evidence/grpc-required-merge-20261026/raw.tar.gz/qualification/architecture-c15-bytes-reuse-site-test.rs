
#[cfg(all(test, feature = "prost"))]
mod c15_allocation_site_tests {
    use super::*;
    use crate::c15_encode_probe as probe;
    #[derive(Clone, PartialEq, ::prost::Message)]
    struct Payload { #[prost(bytes = "vec", tag = "1")] body: Vec<u8> }
    fn noise(bytes: usize) -> Vec<u8> {
        let mut x = 0xd764_7a31_9e50_42cbu64;
        (0..bytes).map(|_| { x ^= x << 13; x ^= x >> 7; x ^= x << 17; x as u8 }).collect()
    }
    #[test]
    fn actual_compressed_encode_allocation_sites() {
        for size in [0, 1024, 65536, 1048576] {
            for entropy in [false, true] {
                for messages in [1, 4] {
                    for flush_each in [false, true] {
                        let message = crate::codec::prost::Message::new(Payload { body: if entropy { noise(size) } else { vec![0; size] } });
                        let encoded_len = message.encoded_len();
                        let mut scratch = EncodeScratch::new();
                        let mut sink = SegSink::new();
                        let mut frames = Vec::new();
                        let mut scratch_caps = Vec::new();
                        let mut output_caps = Vec::new();
                        probe::reset();
                        for _ in 0..messages {
                            append_frame_with_ready(&mut sink, &mut scratch, &message, Some(CompressionAlgorithm::Gzip), MessageLimits::unlimited(), 6, messages).expect("encode");
                            scratch_caps.push(scratch.bytes.capacity());
                            output_caps.push(sink.head.capacity());
                            if flush_each { frames.push(std::mem::replace(&mut sink, SegSink::new()).finish()); }
                        }
                        if !sink.is_empty() { frames.push(sink.finish()); }
                        let sites = probe::snapshot();
                        let mut decoded = 0;
                        let mut wire_bytes = 0;
                        for frame in frames {
                            wire_bytes += frame.total_len();
                            let mut bytes = Bytes::from(frame.concat());
                            while let Some(frame) = crate::codec::pop_from_chunk(&mut bytes, MessageLimits::unlimited()).expect("framing") {
                                assert!(frame.compressed);
                                let raw = CompressionAlgorithm::Gzip.decode(&frame.payload).expect("complete gzip");
                                let back = <crate::codec::prost::Message<Payload> as CodecMessage>::decode_payload(Bytes::from(raw)).expect("prost");
                                assert_eq!(back.0.body, message.0.body);
                                decoded += 1;
                            }
                            assert!(bytes.is_empty());
                        }
                        assert_eq!(decoded, messages);
                        if encoded_len > MAX_RETAINED_SCRATCH_BYTES {
                            assert!(scratch_caps.iter().all(|cap| *cap == encoded_len));
                            assert_eq!(sites[1].0, 1);
                            assert_eq!(sites[4], (0, 0), "built-in Prost appends without a temporary");
                        }
                        eprintln!("C15_ENCODE_SITE size={size} encoded_len={encoded_len} entropy={entropy} messages={messages} flush_each={flush_each} scratch_caps={scratch_caps:?} output_caps={output_caps:?} wire_bytes={wire_bytes} sites={sites:?}");
                    }
                }
            }
        }
    }

    // Existing custom encoders remain valid through the generic bridge. Measure
    // its cost explicitly rather than treating every CodecMessage as built-in.
    struct Legacy(Payload);
    impl CodecMessage for Legacy {
        fn encoded_len(&self) -> usize { ::prost::Message::encoded_len(&self.0) }
        fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.write_contiguous(|buf| ::prost::Message::encode(&self.0, buf).map_err(|error| Status::internal(error.to_string())))
        }
        fn decode_payload(bytes: Bytes) -> Result<Self, Status> {
            <Payload as ::prost::Message>::decode(bytes).map(Self).map_err(|error| Status::internal(error.to_string()))
        }
        fn empty() -> Self { Self(Payload::default()) }
    }
    #[test]
    fn legacy_contiguous_bridge_allocation_site_cost() {
        for size in [1024, 1048576] {
            let message = Legacy(Payload { body: vec![0; size] });
            let encoded_len = message.encoded_len();
            let mut scratch = EncodeScratch::new();
            let mut sink = SegSink::new();
            probe::reset();
            for _ in 0..4 {
                append_frame_with_ready(&mut sink, &mut scratch, &message, Some(CompressionAlgorithm::Gzip), MessageLimits::unlimited(), 6, 4).expect("legacy encode");
            }
            let sites = probe::snapshot();
            let frame = sink.finish();
            let wire_bytes = frame.total_len();
            let mut bytes = Bytes::from(frame.concat());
            let mut decoded = 0;
            while let Some(frame) = crate::codec::pop_from_chunk(&mut bytes, MessageLimits::unlimited()).expect("framing") {
                let raw = CompressionAlgorithm::Gzip.decode(&frame.payload).expect("gzip");
                let back = Legacy::decode_payload(Bytes::from(raw)).expect("prost");
                assert_eq!(back.0.body, message.0.body);
                decoded += 1;
            }
            assert_eq!(decoded, 4);
            assert_eq!(sites[1].0, 1, "canonical plaintext allocation reused");
            assert!(sites[4].0 >= 4, "legacy temporary bridge cost remains explicit");
            eprintln!("C15_ENCODE_CUSTOM size={size} encoded_len={encoded_len} messages=4 wire_bytes={wire_bytes} sites={sites:?}");
        }
    }
}
