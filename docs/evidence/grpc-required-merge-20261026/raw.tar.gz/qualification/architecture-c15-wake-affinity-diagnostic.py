#!/usr/bin/env python3
"""Eight raw-CPU-only affinity diagnostic captures; never default-policy proof."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
PRIMARY = Q / 'architecture-c15-wake-shipping-paired.py'
PRIMARY_SHA = '2f0e902cc10e288b28aa64ba258019b1a358ba4d9a375bae9814e41149c88e61'
COUNTS = 10000
PAIRS = (('tonic', 'prost', 'native', 'prost'), ('tonic', 'prost', 'tonic', 'prost'))
ACCOUNTING = ('offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs')


def ref(path):
    path = Path(path)
    return dict(path=str(path.resolve()), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as out:
        json.dump(value, out, indent=2, allow_nan=False)
        out.write('\n')
    temporary.replace(path)


def topology(cpus):
    rows = []
    for cpu in cpus:
        root = Path('/sys/devices/system/cpu') / f'cpu{cpu}' / 'topology'
        rows.append(dict(cpu=cpu, package=int((root / 'physical_package_id').read_text()),
                         physical_core=int((root / 'core_id').read_text())))
    assert len(rows) == 4 and len({r['package'] for r in rows}) == 1
    assert len({(r['package'], r['physical_core']) for r in rows}) == 4
    return rows


def schedule():
    # Each source's native/TT controls are adjacent. Repeat1 is a full reverse.
    return [(repeat, version, pair) for repeat in range(2)
            for version in (('baseline', 'candidate') if repeat == 0 else ('candidate', 'baseline'))
            for pair in (PAIRS if repeat == 0 else tuple(reversed(PAIRS)))]


def execute(args):
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
    assert ref(PRIMARY)['sha256'] == PRIMARY_SHA
    primary = module('c15_wake_primary', PRIMARY)
    config = args.sources.resolve(strict=True)
    config_ref = ref(config)
    sources = json.loads(config.read_text())
    assert set(sources) == {'baseline', 'candidate'}
    plan_path = args.plan.resolve(strict=True)
    assert ref(plan_path)['sha256'] == args.plan_sha256
    plan = json.loads(plan_path.read_text())
    assert plan['state'] == 'prepared_not_run' and plan['qualified'] is False
    cpus = plan['selected']['cpus']
    assert len(cpus) == 4 and len(set(cpus)) == 4
    affinity_before = sorted(os.sched_getaffinity(0))
    assert set(cpus) <= set(affinity_before)
    core_rows = topology(cpus)
    assert [row['physical_core'] for row in core_rows] == plan['selected']['physical_core_ids']
    assert all(row['package'] == plan['selected']['package'] for row in core_rows)
    smoke = primary.module('affinity_capture', primary.ADAPTER)
    contexts = {}
    for version, row in sources.items():
        tree, binary, record = [Path(row[key]).resolve(strict=True) for key in ('checkout', 'binary', 'build_record')]
        primary.verify_adapter(tree / 'scripts/grpc-load-smoke.py')
        build = smoke.verified_build(record, binary, tree)
        assert build['source']['commit'] == row['source']
        contexts[version] = dict(tree=tree, binary=binary, record=record, build=build, record_ref=ref(record))
    for key in ('tools', 'command', 'cargo_artifact_features', 'cargo_artifact_profile'):
        assert contexts['baseline']['build'][key] == contexts['candidate']['build'][key]
    attribution = primary.verify_attribution(sources, contexts)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    os.sched_setaffinity(0, cpus)
    assert sorted(os.sched_getaffinity(0)) == sorted(cpus)
    # A fresh child observes Linux fork/exec inheritance before any endpoint.
    inherited = json.loads(subprocess.check_output([sys.executable, '-c',
        'import json,os;print(json.dumps(sorted(os.sched_getaffinity(0))))'], text=True))
    assert inherited == sorted(cpus)
    state = dict(schema='pbrs.c15-wake-affinity-diagnostic.v1', state='running', qualified=False,
                 production_ready=False, passed=False, started_utc=now(), controller=ref(Path(__file__).resolve()),
                 primary_controller=ref(PRIMARY), adapter=ref(primary.ADAPTER), config=config_ref,
                 plan=ref(plan_path), attribution=attribution, worker_threads=2, allocation_counts=False,
                 initial_controller_affinity=affinity_before, pinned_controller_affinity=sorted(cpus),
                 child_inheritance_witness=inherited, sysfs_topology=core_rows, rpc_count=COUNTS,
                 expected_captures=8, expected_successful_rpcs=80000, completed=[],
                 actual_rpc_totals={name: {key: 0 for key in ACCOUNTING} for name in contexts},
                 limits=['Diagnostic process-affinity setting only; Root and sibling processes unchanged.',
                         'Same4 distinct physical-core IDs on one package as exposed by sysfs; not reserved/dedicated host cores.',
                         'Existing capture adapter unchanged. Linux fork/exec inherits controller affinity; no endpoint mask mutation.',
                         'Raw N10000 CPU/window/histograms retained; no N/2N slope or broad/default-policy performance claim.'])
    save(output / 'state.json', state)
    rows = []
    try:
        for index, (repeat, version, pair) in enumerate(schedule()):
            context = contexts[version]
            assert ref(config) == config_ref and sorted(os.sched_getaffinity(0)) == sorted(cpus)
            assert ref(context['record']) == context['record_ref']
            assert smoke.verified_build(context['record'], context['binary'], context['tree']) == context['build']
            cell = dict(pair=list(pair), shape='unary', payload_bytes=1024, compression='identity',
                        connections=1, in_flight=1, tls=False, repeat=repeat)
            settings = SimpleNamespace(binary=context['binary'], source_checkout=context['tree'], duration=60,
                                       rpc_count=COUNTS, allocation_counts=False, context_switches=False,
                                       callgrind=None, strace=None)
            run = smoke.run_cell(settings, cell, output / ('cell-' + str(index).zfill(3)))
            state['completed'].append(dict(index=index, source=version, repeat=repeat, pair=list(pair),
                                           passed=run['passed'], capture=ref(output / ('cell-' + str(index).zfill(3)) / 'run.json')))
            for key in ACCOUNTING:
                value = run.get('metrics', {}).get(key)
                if type(value) is int and value >= 0:
                    state['actual_rpc_totals'][version][key] += value
            save(output / 'state.json', state)
            assert run['passed'], 'failed affinity diagnostic capture retained'
            derived = primary.derived_capture(run, COUNTS, os.sysconf('SC_CLK_TCK'))
            rows.append(dict(version=version, repeat=repeat, **derived,
                             raw_cpu_us_per_rpc={side: derived[field] * 1e6 / COUNTS
                                 for side, field in (('client', 'client_lifetime_cpu_seconds'),
                                                    ('server', 'server_client_window_cpu_seconds'))}))
            assert ref(config) == config_ref and sorted(os.sched_getaffinity(0)) == sorted(cpus)
            assert smoke.verified_build(context['record'], context['binary'], context['tree']) == context['build']
        assert len(rows) == 8
        for values in state['actual_rpc_totals'].values():
            assert all(values[key] == 40000 for key in ACCOUNTING[:4])
            assert all(values[key] == 0 for key in ACCOUNTING[4:])
        result = dict(qualified=False, timing_qualified=False, rpc_count=COUNTS, captures=rows,
                      cpu_scope='Client lifetime including setup/reporting; server before-client to terminal-client window.',
                      rule='Raw single-count process CPU only. No slopes, subtraction of quantiles or default-policy superiority claim.',
                      controller_affinity=sorted(cpus), sysfs_topology=core_rows)
        save(output / 'summary.json', result)
        state.update(state='finished', passed=True, completed_utc=now(), summary=ref(output / 'summary.json'))
        save(output / 'state.json', state)
    except BaseException as error:
        state.update(state='failed', passed=False, completed_utc=now(), error=dict(type=type(error).__name__, message=str(error)))
        save(output / 'state.json', state)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--sources', type=Path)
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--plan-sha256')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(dict(state='prepared_not_run', qualified=False, captures=8, successful_rpcs=80000,
                              rpc_count=COUNTS, repetitions=2, affinity='Four sysfs-distinct cores on one package, newcontroller/children only.')))
        return
    assert all((args.sources, args.plan, args.plan_sha256, args.output))
    execute(args)


if __name__ == '__main__':
    main()
