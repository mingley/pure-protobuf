# C15 byte/CPU matrix V2 — premeasurement revision

The original unrun V1 proposal remains unchanged. Root reduced RPC counts before any byte capture to bound large-noise runtime. All eight workload configurations, three native/Tonic pairs, two sources and two balanced repeats remain. Baseline/candidate source commits are still null until Root freezes identical benchmarkV3 code on both runtime sources.

| Phase | N values | Captures | Successful RPCs |
|---|---|---:|---:|
| Allocation-instrumented release | 5 / 10 for every cell | 192 | 1,440 |
| Feature-off shipping,1KiB | 1,000 / 2,000 | 48 | 72,000 |
| Feature-off shipping,64KiB | 100 / 200 | 48 | 7,200 |
| Feature-off shipping,1MiB | 10 / 20 | 96 | 1,440 |
| Separate fresh-process shipping | 1 | 72 | 72 |

Shipping sums to192captures/80,640RPCs. All phases together are456captures/82,152RPCs; the three measurement scopes stay separate. The100Hz process tick gives slope quanta10µs,100µs and1,000µs perRPC for the three shipping size levels. These are reported limits, not significance or physicalCPU-isolation proof.

Large configurations are gzip1MiB zero/noise ×1/4messages. Legacy-boundary controls are gzip64KiB and1KiB zero/noise ×4messages. Fresh-process controls are gzip1MiB zero/noise ×1/4messages and identity1KiB zero/noise ×1message, with a new server/client process percapture. A one-message RPC alone is not a cold-process proof.

Keep raw histograms, all endpoint/source/Tonic controls, signed/nonpositive slopes and every higher-cost repeat. N5/10 allocator counters are exact recorded counts, but setup/packetization can make subtraction unstable; such groups remain unresolved and need a separately prepared followup rather than a forced win label. Rawcold CPU belowtickresolution remains unresolved. Never subtract quantiles or throughput across N/2N.

EntropyadapterV2 requires the exact benchmarkV3 pattern/seed/body-validation and request/response fixture bounds in both READY and client metrics. Full-byte comparisons and client one-time fixture creation remain in the declared CPU scopes; the server fixture is built before READY. All bodies and metadata are verified. Noise for pbrs messages remains unsupported explicitly. No source, feature, buffer, queue, worker, TLS or handler-work mismatch is allowed between the matched source builds.

This plan is prepared, not an actual build/capture/pass. It does not replace the source-bound allocation-site probe or claim production readiness/broad superiority.
