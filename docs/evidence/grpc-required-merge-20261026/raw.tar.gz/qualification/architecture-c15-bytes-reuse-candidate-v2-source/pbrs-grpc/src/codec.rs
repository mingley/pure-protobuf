//! gRPC length-prefixed framing.
//!
//! Every gRPC message travels as a 5-byte header followed by its payload:
//!
//! ```text
//! +-----------------+-------------------------+----------------+
//! | Compressed-Flag | Message-Length (u32 BE)  |    Payload     |
//! |     1 byte      |         4 bytes          |  Length bytes  |
//! +-----------------+-------------------------+----------------+
//! ```
//!
//! The length is validated against the inbound cap the moment the header is
//! complete, so an oversize claim is refused before any payload memory is
//! reserved.

use crate::limits::MessageLimits;
use crate::status::Status;
use bytes::{Buf, BufMut, Bytes, BytesMut};
use pbrs::{Parse, Serialize};

#[cfg(feature = "prost")]
pub mod prost;

/// Size of the gRPC length-prefix header.
pub const HEADER_LEN: usize = 5;

/// Message codec contract used by the native transport.
///
/// pbrs-generated messages implement this through the blanket implementation
/// below, which preserves the fast paths: direct encode into the framed sink,
/// `Bytes`-backed parsing, and shared outbound segments for large bytes fields.
/// Other message families can implement this trait without changing the
/// transport or the four RPC shapes.
pub trait CodecMessage: Sized {
    /// Return the uncompressed protobuf payload length.
    fn encoded_len(&self) -> usize;

    /// Encode the uncompressed protobuf payload into `out`.
    fn encode_payload<W: pbrs::WireOut>(&self, out: &mut W) -> Result<(), Status>;

    /// Encode into an append-only byte sink owned by the transport.
    ///
    /// The default preserves existing implementations. A custom encoder using
    /// `WireOut::write_contiguous` receives a separate temporary buffer, whose
    /// bytes are copied into this sink. Implement this method to avoid that
    /// temporary when the codec already supports generic [`bytes::BufMut`].
    /// The payload and error must match [`Self::encode_payload`]. On error the
    /// sink may contain a partial payload; the transport discards its scratch.
    fn encode_payload_bufmut<B: bytes::BufMut>(&self, out: &mut B) -> Result<(), Status> {
        self.encode_payload(out)
    }

    /// Materialize the same uncompressed protobuf payload as [`Self::encode_payload`].
    ///
    /// This allocating convenience is used by single-message sends. Streaming
    /// sends may call `encode_payload` directly into reusable scratch storage.
    fn encode_to_vec(&self) -> Result<Vec<u8>, Status> {
        let mut out = Vec::with_capacity(self.encoded_len());
        self.encode_payload(&mut out)?;
        Ok(out)
    }

    /// Decode one uncompressed protobuf payload.
    fn decode_payload(payload: Bytes) -> Result<Self, Status>;

    /// Decode a payload whose backing allocation may be reused by the transport.
    ///
    /// This must produce the same message and errors as [`Self::decode_payload`].
    /// The default transfers ownership of the bytes to that method. A codec
    /// that consumes a mutable cursor may override this method and leave the
    /// exhausted cursor in `payload`. The transport reclaims its storage only
    /// when decoding succeeds, the cursor is empty, and ownership is unique.
    /// Messages may retain shared bytes; that simply prevents reuse.
    fn decode_payload_reusable(payload: &mut Bytes) -> Result<Self, Status> {
        Self::decode_payload(std::mem::take(payload))
    }

    /// Empty unary bodies decode as the message default.
    fn empty() -> Self;
}

impl<T> CodecMessage for T
where
    T: Parse + Serialize + Default,
{
    fn encoded_len(&self) -> usize {
        Serialize::serialized_len(self)
    }

    fn encode_payload<W: pbrs::WireOut>(&self, out: &mut W) -> Result<(), Status> {
        Serialize::encode(self, out).map_err(|e| Status::internal(e.to_string()))
    }

    fn encode_to_vec(&self) -> Result<Vec<u8>, Status> {
        Serialize::serialize(self).map_err(|e| Status::internal(e.to_string()))
    }

    fn decode_payload(payload: Bytes) -> Result<Self, Status> {
        Parse::parse_bytes(payload).map_err(|e| Status::internal(e.to_string()))
    }

    fn empty() -> Self {
        Self::default()
    }
}

/// One length-prefixed frame lifted off the wire.
#[derive(Clone, Debug)]
pub struct Frame {
    /// Compressed-Flag: the payload uses the RPC's `grpc-encoding` coding.
    pub compressed: bool,
    /// Frame payload, still compressed if [`Self::compressed`] is set.
    pub payload: Bytes,
}

/// Frame `payload`, setting the Compressed-Flag to `compressed`.
///
/// ```
/// use pbrs_grpc::codec;
///
/// let frame = codec::encode(b"hi", false)?;
/// assert_eq!(&frame[..], &[0, 0, 0, 0, 2, b'h', b'i']);
/// # Ok::<(), pbrs_grpc::Status>(())
/// ```
pub fn encode(payload: &[u8], compressed: bool) -> Result<Bytes, Status> {
    let len = u32::try_from(payload.len()).map_err(|_| Status::internal("message too large"))?;
    let mut buf = BytesMut::with_capacity(HEADER_LEN + payload.len());
    buf.put_u8(u8::from(compressed));
    buf.put_u32(len);
    buf.extend_from_slice(payload);
    Ok(buf.freeze())
}

/// Take one complete frame off the front of `buf`.
///
/// `Ok(None)` means the frame is not fully buffered yet and `buf` was left
/// untouched.
///
/// ```
/// use bytes::BytesMut;
/// use pbrs_grpc::codec;
///
/// let wire = codec::encode(b"hi", false)?;
/// let mut buf = BytesMut::from(&wire[..4]);
/// assert!(codec::pop(&mut buf)?.is_none());
///
/// buf.extend_from_slice(&wire[4..]);
/// let frame = codec::pop(&mut buf)?.expect("complete");
/// assert_eq!(&frame.payload[..], b"hi");
/// # Ok::<(), pbrs_grpc::Status>(())
/// ```
pub fn pop(buf: &mut BytesMut) -> Result<Option<Frame>, Status> {
    pop_limited(buf, MessageLimits::unlimited())
}

/// [`pop`] with an inbound size cap.
///
/// The claimed length is checked against `limits` as soon as the 5-byte header
/// is present, so a hostile header cannot make the caller buffer more than the
/// cap allows. Oversize is
/// [`Code::ResourceExhausted`](crate::Code::ResourceExhausted).
pub fn pop_limited(buf: &mut BytesMut, limits: MessageLimits) -> Result<Option<Frame>, Status> {
    let Some(header) = buf.get(..HEADER_LEN) else {
        return Ok(None);
    };
    let (flag, len_bytes) = header.split_at(1);
    let flag = flag.first().copied().unwrap_or_default();
    if flag > 1 {
        return Err(Status::internal(format!(
            "invalid gRPC compressed-flag {flag}"
        )));
    }
    let mut len_be = [0u8; 4];
    len_be.copy_from_slice(len_bytes);
    let len = usize::try_from(u32::from_be_bytes(len_be))
        .map_err(|_| Status::internal("message too large"))?;
    limits.check_decode(len)?;
    let total = HEADER_LEN
        .checked_add(len)
        .ok_or_else(|| Status::internal("message too large"))?;
    if buf.len() < total {
        return Ok(None);
    }
    drop(buf.split_to(HEADER_LEN));
    Ok(Some(Frame {
        compressed: flag == 1,
        payload: buf.split_to(len).freeze(),
    }))
}

/// Take one complete frame off the front of an immutable chunk.
///
/// Returns the frame plus the unconsumed remainder. This is the zero-copy
/// path: the payload is a slice of `chunk`, so a frame that arrived whole in
/// one HTTP/2 DATA frame is never copied into an intermediate buffer.
pub(crate) fn pop_from_chunk(
    chunk: &mut Bytes,
    limits: MessageLimits,
) -> Result<Option<Frame>, Status> {
    let Some(header) = chunk.get(..HEADER_LEN) else {
        return Ok(None);
    };
    let (flag, len_bytes) = header.split_at(1);
    let flag = flag.first().copied().unwrap_or_default();
    if flag > 1 {
        return Err(Status::internal(format!(
            "invalid gRPC compressed-flag {flag}"
        )));
    }
    let mut len_be = [0u8; 4];
    len_be.copy_from_slice(len_bytes);
    let len = usize::try_from(u32::from_be_bytes(len_be))
        .map_err(|_| Status::internal("message too large"))?;
    limits.check_decode(len)?;
    let total = HEADER_LEN
        .checked_add(len)
        .ok_or_else(|| Status::internal("message too large"))?;
    if chunk.len() < total {
        return Ok(None);
    }
    // The 5-byte header is discarded. `advance` moves the view; `split_to`
    // would clone the shared buffer just to drop those bytes.
    chunk.advance(HEADER_LEN);
    crate::copy_counts::note_chunk_slice(len);
    // A DATA frame that holds exactly one gRPC message is the whole chunk
    // after the header. Moving it avoids another shared-buffer clone.
    let payload = if chunk.len() == len {
        std::mem::take(chunk)
    } else {
        chunk.split_to(len)
    };
    Ok(Some(Frame {
        compressed: flag == 1,
        payload,
    }))
}

#[cfg(test)]
mod tests {
    use super::{encode, pop, pop_from_chunk, pop_limited};
    use crate::limits::MessageLimits;
    use crate::status::Code;
    use bytes::BytesMut;

    #[test]
    fn roundtrip_empty_and_payload() {
        let empty = encode(&[], false).expect("encode");
        let mut buf = BytesMut::from(empty.as_ref());
        let got = pop(&mut buf).expect("pop").expect("frame");
        assert!(!got.compressed);
        assert!(got.payload.is_empty());
        assert!(buf.is_empty());

        let payload = b"hello";
        let framed = encode(payload, true).expect("encode");
        buf.extend_from_slice(&framed);
        let got = pop(&mut buf).expect("pop").expect("frame");
        assert!(got.compressed);
        assert_eq!(&got.payload[..], payload);
    }

    #[test]
    fn incomplete_waits_without_consuming() {
        let framed = encode(&[1, 2, 3], false).expect("encode");
        let mut buf = BytesMut::from(&framed[..4]);
        assert!(pop(&mut buf).expect("pop").is_none());
        assert_eq!(buf.len(), 4);
        buf.extend_from_slice(&framed[4..]);
        let got = pop(&mut buf).expect("pop").expect("frame");
        assert_eq!(&got.payload[..], &[1, 2, 3]);
    }

    #[test]
    fn oversize_is_rejected_from_the_header_alone() {
        let framed = encode(&[0u8; 16], false).expect("encode");
        let mut buf = BytesMut::from(&framed[..5]);
        let err = pop_limited(&mut buf, MessageLimits::unlimited().with_max_decoding(8))
            .expect_err("oversize");
        assert_eq!(err.code(), Code::ResourceExhausted);
    }

    #[test]
    fn reserved_compressed_flag_values_are_rejected() {
        let mut buf = BytesMut::from(&[2u8, 0, 0, 0, 0][..]);
        let err = pop(&mut buf).expect_err("bad flag");
        assert_eq!(err.code(), Code::Internal);
    }

    #[test]
    fn chunk_pop_slices_without_copying() {
        let a = encode(b"one", false).expect("encode");
        let b = encode(b"two", false).expect("encode");
        let mut joined = BytesMut::from(a.as_ref());
        joined.extend_from_slice(&b);
        let mut chunk = joined.freeze();

        let first = pop_from_chunk(&mut chunk, MessageLimits::unlimited())
            .expect("pop")
            .expect("frame");
        assert_eq!(&first.payload[..], b"one");
        let second = pop_from_chunk(&mut chunk, MessageLimits::unlimited())
            .expect("pop")
            .expect("frame");
        assert_eq!(&second.payload[..], b"two");
        assert!(
            pop_from_chunk(&mut chunk, MessageLimits::unlimited())
                .expect("pop")
                .is_none()
        );
        assert!(chunk.is_empty());
    }

    #[test]
    fn chunk_pop_leaves_partial_frames_intact() {
        let wire = encode(b"partial", false).expect("encode");
        let mut chunk = wire.slice(..6);
        assert!(
            pop_from_chunk(&mut chunk, MessageLimits::unlimited())
                .expect("pop")
                .is_none()
        );
        assert_eq!(chunk.len(), 6);
    }
}
