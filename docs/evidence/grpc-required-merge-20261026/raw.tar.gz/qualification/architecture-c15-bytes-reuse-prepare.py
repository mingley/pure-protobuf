from pathlib import Path
import subprocess,json,hashlib
root=Path('/workspace/pure-protobuf');tree=root/'work/architecture-c15-bytes-reuse';q=root/'work/qualification'
assert subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True)==''
p=tree/'pbrs-grpc/src/codec.rs';s=p.read_text();a='''    fn encode_payload<W: pbrs::WireOut>(&self, out: &mut W) -> Result<(), Status>;
''';b=a+'''
    /// Encode into an append-only byte sink owned by the transport.
    ///
    /// The default preserves existing implementations. A custom encoder using
    /// `WireOut::write_contiguous` receives a separate temporary buffer, whose
    /// bytes are copied into this sink. Implement this method to avoid that
    /// temporary when the codec already supports generic [`bytes::BufMut`].
    /// The payload and error must match [`Self::encode_payload`]. On error the
    /// sink may contain a partial payload; the transport discards its scratch.
    fn encode_payload_bufmut<B: bytes::BufMut>(&self, out: &mut B) -> Result<(), Status> {
        self.encode_payload(out)
    }
''';assert s.count(a)==1;p.write_text(s.replace(a,b))
p=tree/'pbrs-grpc/src/codec/prost.rs';s=p.read_text();a='''    fn encode_to_vec(&self) -> Result<Vec<u8>, Status> {''';b='''    fn encode_payload_bufmut<B: bytes::BufMut>(&self, out: &mut B) -> Result<(), Status> {
        self.0.encode(out).map_err(|e| Status::internal(e.to_string()))
    }

'''+a;assert s.count(a)==1;p.write_text(s.replace(a,b))
p=tree/'pbrs-grpc/src/workspace.rs';s=p.read_text();s=s.replace('use std::sync::atomic::{AtomicUsize, Ordering};','use std::sync::atomic::{AtomicUsize, Ordering};\nuse std::num::NonZeroUsize;')
a='''static RETAINED_DECODE_BUDGET: Budget =
    Budget::new(RETAINED_DECODE_CAPACITY, MAX_RETAINED_DECODE_BUFFER);
''';b=a+'''
// Separate from decoded output. This bounds only admitted LARGE encode scratch
// between messages, not active serialization or the legacy <=64KiB allowance.
const RETAINED_ENCODE_CAPACITY: usize = 16 * 1024 * 1024;
const MAX_RETAINED_ENCODE_BUFFER: usize = 4 * 1024 * 1024;
static RETAINED_ENCODE_BUDGET: Budget =
    Budget::new(RETAINED_ENCODE_CAPACITY, MAX_RETAINED_ENCODE_BUFFER);

/// Full canonical Vec capacity charged only between compressed messages.
/// Store the Vec before this lease so its storage is destroyed first.
#[derive(Debug)]
pub(crate) struct RetainedEncodeLease {
    capacity: NonZeroUsize,
}

impl RetainedEncodeLease {
    pub(crate) fn try_acquire(capacity: usize) -> Option<Self> {
        let capacity = NonZeroUsize::new(capacity)?;
        RETAINED_ENCODE_BUDGET.try_acquire(capacity.get()).then_some(Self { capacity })
    }

    #[cfg(test)]
    pub(crate) fn capacity(&self) -> usize {
        self.capacity.get()
    }
}

impl Drop for RetainedEncodeLease {
    fn drop(&mut self) {
        RETAINED_ENCODE_BUDGET.release(self.capacity.get());
    }
}
''';assert s.count(a)==1;s=s.replace(a,b)
a='''#[cfg(feature = "copy-counts")]
pub(crate) fn retained_decode_counts() -> RetainedDecodeCounts {
    RETAINED_DECODE_BUDGET.snapshot()
}
''';b=a+'''
/// Same counter shape as decode, for the independent large ENCODE ledger.
/// Legacy small encode scratch and active serialization are excluded.
#[cfg(any(test, feature = "copy-counts"))]
pub type RetainedEncodeCounts = RetainedDecodeCounts;

#[cfg(feature = "copy-counts")]
pub(crate) fn retained_encode_counts() -> RetainedEncodeCounts {
    RETAINED_ENCODE_BUDGET.snapshot()
}
''';assert s.count(a)==1;p.write_text(s.replace(a,b))
p=tree/'pbrs-grpc/src/copy_counts.rs';s=p.read_text();a='''pub use crate::workspace::RetainedDecodeCounts;''';b='''pub use crate::workspace::{RetainedDecodeCounts, RetainedEncodeCounts};''';assert s.count(a)==1;s=s.replace(a,b)
a='''pub fn retained_decode_counts() -> RetainedDecodeCounts {
    crate::workspace::retained_decode_counts()
}
''';b=a+'''
/// Read the independent large plaintext-encode idle-capacity ledger.
///
/// At most 4MiB per buffer and 16MiB aggregate can be admitted. The legacy
/// <=64KiB per-stream encode allowance and active encoding are excluded.
/// Decode uses its separate ledger; neither counter is a total memory cap.
#[cfg(feature = "copy-counts")]
pub fn retained_encode_counts() -> RetainedEncodeCounts {
    crate::workspace::retained_encode_counts()
}
''';assert s.count(a)==1;p.write_text(s.replace(a,b))
p=tree/'pbrs-grpc/src/wire/encode.rs';s=p.read_text();s=s.replace('use crate::status::Status;','use crate::status::Status;\nuse crate::workspace::RetainedEncodeLease;')
a=s.index('/// Reusable protobuf bytes for independently compressed stream messages.');b=s.index('/// One framed gRPC message as an ordered segment list',a)
s=s[:a]+'''/// Stream-owned plaintext for independently compressed messages.
///
/// Small buffers retain the existing per-stream allowance. Large canonical Vec
/// allocations need a separate finite idle-capacity lease. A codec only gets
/// append access, so it cannot replace/split/retain this allocation safely.
/// Field order frees the buffer before releasing its idle reservation.
pub(crate) struct EncodeScratch {
    bytes: Vec<u8>,
    lease: Option<RetainedEncodeLease>,
}

const MAX_RETAINED_SCRATCH_BYTES: usize = 64 * 1024;

impl EncodeScratch {
    pub(crate) fn new() -> Self {
        Self { bytes: Vec::new(), lease: None }
    }

    pub(crate) fn discard(&mut self) {
        self.bytes = Vec::new();
        self.lease = None;
    }

    fn with_payload<T: CodecMessage, R>(
        &mut self,
        msg: &T,
        len: usize,
        use_payload: impl FnOnce(&[u8]) -> Result<R, Status>,
    ) -> Result<R, Status> {
        // Leave self empty before entering arbitrary codec/compressor code.
        // If a caller catches its panic, unwinding has already destroyed the
        // active buffer. There is no unbudgeted allocation left in self.
        let mut active = std::mem::replace(self, Self::new());
        active.lease = None; // owned active output is not idle cache capacity
        active.bytes.clear();
        active.bytes.reserve(len);
        let result = msg.encode_payload_bufmut(&mut active.bytes).and_then(|()| {
            crate::copy_counts::note_serialize(active.bytes.len());
            use_payload(&active.bytes)
        });
        if result.is_ok() {
            let capacity = active.bytes.capacity();
            if capacity <= MAX_RETAINED_SCRATCH_BYTES {
                active.bytes.clear();
                *self = active;
            } else if let Some(lease) = RetainedEncodeLease::try_acquire(capacity) {
                active.bytes.clear();
                active.lease = Some(lease);
                *self = active;
            }
            // Oversize or exhausted retention is a cache miss. The local
            // active owner drops storage; the successful frame remains valid.
        }
        result
    }
}

'''+s[b:]
s=s.replace('// Reuse after both growth and a large-message allocation release.','// Reuse after growth and a large-to-small transition.')
a='''                assert!(scratch.bytes.capacity() <= MAX_RETAINED_SCRATCH_BYTES);''';b='''                assert!(
                    scratch.bytes.capacity() <= MAX_RETAINED_SCRATCH_BYTES
                        || scratch.lease.as_ref().is_some_and(|lease| lease.capacity() == scratch.bytes.capacity())
                );''';assert s.count(a)==1;s=s.replace(a,b);p.write_text(s)
p=tree/'pbrs-grpc/src/wire/out_batch.rs';s=p.read_text();a='''            self.sink.rollback(&checkpoint);
            return Err(status);''';b='''            self.sink.rollback(&checkpoint);
            // Limits can fail before with_payload enters its active owner.
            // Do not retain a previous message's idle scratch on that path.
            self.scratch.discard();
            return Err(status);''';assert s.count(a)==1;p.write_text(s.replace(a,b))
files=subprocess.check_output(['git','diff','--name-only'],cwd=tree,text=True).splitlines()
(q/'architecture-c15-bytes-reuse-production-prepared.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=tree))
m={'qualified':False,'state':'production_candidate_prepared_not_compiled','base':'ee5b345bd362b1742535e489e0575a00d674bb4c','files':{f:hashlib.sha256((tree/f).read_bytes()).hexdigest() for f in files},'source_model':str(q/'architecture-c15-bytes-candidate-model.md')}
(q/'architecture-c15-bytes-reuse-production-prepared.json').write_text(json.dumps(m,indent=2)+'\n');print(m)
