#!/usr/bin/env python3
"""Archive a closed C13 diagnostic; publish through three normal main pushes.

The checksum-bound common module owns terminal/source/generation validation.
Without --execute this file only describes the prepared publication.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import fcntl
import gzip
import hashlib
import importlib.util
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tarfile

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
SOURCE_FILE = Q / 'architecture-c13-soak-source.json'
COMMON = Path(__file__).resolve().with_name('architecture-c15-soak-common.py')
COMMON_SHA256 = 'ef75e7f52695345288176a3006b959b593171ae28dbcfdc42dab61aa0d0430b1'
PREPARED = True
SPLIT_THRESHOLD = 90 * 1024**2
PART_SIZE = 64 * 1024**2
GIT_FILE_LIMIT = 100 * 1024**2


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def sha(path):
    with Path(path).open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()


def save(path, value):
    temporary = path.with_name(path.name + '.next.' + str(os.getpid()))
    with temporary.open('xb') as stream:
        stream.write(encoded(value)); stream.flush(); os.fsync(stream.fileno())
    temporary.replace(path)


def safe_name(name):
    path = PurePosixPath(name)
    return (bool(name) and str(path) == name and not path.is_absolute()
            and not any(part in ('.', '..') for part in path.parts)
            and ':' not in name and chr(92) not in name)


def common():
    if not __debug__ or not PREPARED:
        raise ValueError('Publication requires finalized helpers and enabled Python assertions.')
    if COMMON.is_symlink() or sha(COMMON) != COMMON_SHA256:
        raise ValueError('Common validator checksum differs.')
    spec = importlib.util.spec_from_file_location('c13_terminal_publication_common', COMMON)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def identity(bundle, kind, source_sha256):
    if not re.fullmatch('[0-9a-f]{64}', source_sha256 or ''):
        raise ValueError('Explicit immutable source-record SHA256 required.')
    outcome, generation = bundle['outcome'], bundle['generation']
    if (bundle['source'] != SOURCE or bundle['kind'] != kind
            or outcome.get('state') not in ('passed', 'failed', 'incomplete')
            or outcome.get('qualified') is not False
            or not re.fullmatch('[a-z0-9][a-z0-9-]{11,63}', generation)):
        raise ValueError('Invalid terminal source, kind, outcome or generation.')
    launch = datetime.datetime.fromisoformat(bundle['launch_utc'].replace('Z', '+00:00'))
    if launch.utcoffset() != datetime.timedelta(0):
        raise ValueError('Launch timestamp must include UTC offset.')
    output = Q / ('resource-architecture-c15-' + ('day' if kind == 'resource' else 'deadline-day'))
    if Path(bundle['output']) != output or output.is_symlink() or output.resolve() != output:
        raise ValueError('Publication output differs from its owned diagnostic directory.')
    refs = bundle['files']
    if not isinstance(refs, list) or not refs:
        raise ValueError('No closed evidence references supplied.')
    pins = [row for row in refs if row.get('path') == str(SOURCE_FILE)]
    gates = [row for row in refs if row.get('path') == str(Q / 'architecture-c13-soak-gates.json')]
    if len(pins) != 1 or pins[0]['sha256'] != source_sha256 or len(gates) != 1:
        raise ValueError('Source/gate records are missing or differ from the explicit source pin.')
    suffix = f'{launch:%Y%m%d}-{SOURCE[:8]}-{generation[:12]}'
    return {'output': output, 'generation': generation,
            'evidence': Path(f'docs/evidence/grpc-{kind}-soak-c15-{suffix}'),
            'worktree': ROOT / f'work/architecture-c15-{kind}-publication-{generation}',
            'marker': f'<!-- architecture-c15-{kind}-{SOURCE[:8]}-{generation} -->'}


def reference(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def number(value):
    if type(value) is int and value >= 0: return f'{value:,}'
    if type(value) is float and math.isfinite(value) and value >= 0: return f'{value:,.2f}'
    return 'unavailable'


def member_name(path):
    if not path.is_absolute() or path.is_symlink() or path.resolve() != path:
        raise ValueError('Evidence path is not a regular absolute file: ' + str(path))
    if path.is_relative_to(Q):
        name = 'qualification/' + path.relative_to(Q).as_posix()
    elif path in {ROOT / 'work/run-rust', ROOT / 'work/record.py'}:
        name = 'helpers/' + path.name
    else:
        raise ValueError('Evidence is outside qualification files and the two allowed helpers.')
    if not safe_name(name):
        raise ValueError('Unsafe archive member name.')
    return name


def snapshot(bundle, context, source_sha256):
    root = context['output'] / 'publication-snapshot'
    root.mkdir(exist_ok=False)
    refs = list(bundle['files'])
    for path in [COMMON, Path(__file__).resolve()]:
        if not any(row['path'] == str(path) for row in refs):
            refs.append(reference(path))
    files, omitted, names = [], [], set()
    for row in refs:
        path = Path(row['path']); name = member_name(path)
        if name in names or path.name in ('publication.json', 'publication.log', '.publication.lock'):
            raise ValueError('Duplicate or active publication input: ' + str(path))
        names.add(name)
        target = root / name
        target.parent.mkdir(parents=True, exist_ok=True)
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'; stream.seek(0)
            digest, size = hashlib.sha256(), 0
            destination = None if elf else target.open('xb')
            try:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(chunk); size += len(chunk)
                    if destination is not None: destination.write(chunk)
            finally:
                if destination is not None: destination.close()
        if type(row['bytes']) is not int or size != row['bytes'] or digest.hexdigest() != row['sha256']:
            raise ValueError('Closed evidence checksum/size differs: ' + str(path))
        item = {'path': name, 'bytes': size, 'sha256': digest.hexdigest()}
        (omitted if elf else files).append(item)
    value = {'source': SOURCE, 'source_record_sha256': source_sha256, 'qualified': False,
             'common_sha256': COMMON_SHA256, 'terminal_inputs': bundle,
             'omitted_verified_elf_bytes': omitted,
             'recorded_omissions': bundle.get('recorded_omissions', [])}
    (root / 'inputs.json').write_bytes(encoded(value))
    files.append({'path': 'inputs.json', 'bytes': (root / 'inputs.json').stat().st_size,
                  'sha256': sha(root / 'inputs.json')})
    return root, sorted(files, key=lambda item: item['path'])


def archive_parts(dest, output):
    raw = dest / 'raw.tar.gz'
    archive = reference(raw); archive['name'] = raw.name; archive.pop('path')
    if archive['bytes'] > SPLIT_THRESHOLD:
        staging = output / 'publication-large-staging'; staging.mkdir(exist_ok=False)
        original = staging / raw.name; raw.rename(original)
        archive['retained_staging_path'] = str(original)
        archive['parts'] = []
        with original.open('rb') as source:
            remaining, ordinal = archive['bytes'], 1
            while remaining:
                name = f'raw.tar.gz.part-{ordinal:03d}'
                size, digest = min(PART_SIZE, remaining), hashlib.sha256()
                with (dest / name).open('xb') as target:
                    left = size
                    while left:
                        chunk = source.read(min(1024 * 1024, left))
                        if not chunk: raise ValueError('Staging archive ended early.')
                        target.write(chunk); digest.update(chunk); left -= len(chunk)
                archive['parts'].append({'name': name, 'bytes': size, 'sha256': digest.hexdigest()})
                remaining -= size; ordinal += 1
    return archive


def check_git_sizes(dest):
    if any(path.stat().st_size >= GIT_FILE_LIMIT for path in dest.rglob('*') if path.is_file()):
        raise ValueError('A publication artifact reaches the GitHub file-size limit.')


CHECKER = '''#!/usr/bin/env python3
"""Verify the capsule without extracting any archive member."""
from pathlib import Path, PurePosixPath
import contextlib,hashlib,json,tarfile,tempfile
def safe(name):
 p=PurePosixPath(name)
 return bool(name) and str(p)==name and not p.is_absolute() and not any(x in ('.','..') for x in p.parts) and ':' not in name and chr(92) not in name
def main():
 root=Path(__file__).resolve().parent; m=json.loads((root/'manifest.json').read_text())
 if m.get('schema')!='pbrs.c13-soak-capsule.v1' or m.get('qualified') is not False or m['archive']['name']!='raw.tar.gz': raise ValueError('invalid manifest')
 expected={x['path']:x for x in m['files']}; seen=set(); size=0
 if not expected or len(expected)!=len(m['files']) or not all(safe(x) for x in expected): raise ValueError('unsafe/duplicate inventory')
 with contextlib.ExitStack() as stack:
  parts=m['archive'].get('parts')
  if parts is None: archive=stack.enter_context((root/'raw.tar.gz').open('rb'))
  else:
   if not isinstance(parts,list) or len(parts)<2: raise ValueError('invalid archive parts')
   archive=stack.enter_context(tempfile.TemporaryFile())
   for index,part in enumerate(parts,1):
    if part['name']!=f'raw.tar.gz.part-{index:03d}' or type(part['bytes']) is not int or not 0<part['bytes']<=64*1024**2: raise ValueError('unsafe archive part')
    if (root/part['name']).stat().st_size!=part['bytes']: raise ValueError('archive part size differs')
    count=0; digest=hashlib.sha256()
    with (root/part['name']).open('rb') as source:
     for chunk in iter(lambda:source.read(1024*1024),b''): archive.write(chunk); digest.update(chunk); count+=len(chunk)
    if count!=part['bytes'] or digest.hexdigest()!=part['sha256']: raise ValueError('archive part checksum differs')
  archive.seek(0,2); total=archive.tell(); archive.seek(0)
  if total!=m['archive']['bytes'] or hashlib.file_digest(archive,'sha256').hexdigest()!=m['archive']['sha256']: raise ValueError('archive checksum differs')
  archive.seek(0)
  with tarfile.open(fileobj=archive,mode='r:gz') as tar:
   for item in tar:
    if not item.isfile() or not safe(item.name) or item.name in seen or item.name not in expected: raise ValueError('unsafe/unexpected archive member')
    row=expected[item.name]; stream=tar.extractfile(item)
    if item.size!=row['bytes'] or stream is None or hashlib.file_digest(stream,'sha256').hexdigest()!=row['sha256']: raise ValueError('member checksum differs')
    seen.add(item.name); size+=item.size
 if seen!=set(expected) or size!=m['logical_bytes']: raise ValueError('incomplete archive')
 print(f'verified {len(seen)} files; no production qualification')
if __name__=='__main__': main()
'''


def artifacts(bundle, context, source_sha256):
    root, files = snapshot(bundle, context, source_sha256)
    dest = context['output'] / 'publication-artifacts'; dest.mkdir(exist_ok=False)
    with (dest / 'raw.tar.gz').open('xb') as stream:
        with gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as tar:
                for item in files:
                    if sha(root / item['path']) != item['sha256']: raise ValueError('Snapshot changed.')
                    header = tarfile.TarInfo(item['path']); header.size = item['bytes']; header.mode = 0o644
                    with (root / item['path']).open('rb') as raw: tar.addfile(header, raw)
    archive = archive_parts(dest, context['output'])
    manifest = {'schema': 'pbrs.c13-soak-capsule.v1', 'source': SOURCE, 'qualified': False,
                'generation': context['generation'], 'archive': archive, 'files': files,
                'logical_bytes': sum(item['bytes'] for item in files)}
    (dest / 'manifest.json').write_bytes(encoded(manifest)); (dest / 'check.py').write_text(CHECKER)
    results = {**bundle['outcome'], 'source': SOURCE, 'kind': bundle['kind'], 'generation': bundle['generation'],
               'launch_utc': bundle['launch_utc'], 'qualified': False}
    (dest / 'results.json').write_bytes(encoded(results))
    reason = results.get('reason')
    reason = '' if not reason else '\nReason: ' + str(reason).replace('\n', ' ') + '\n'
    measurement = results.get('duration_measurement')
    measurement = '' if not measurement else '\nDuration measurement: ' + str(measurement).replace('\n', ' ') + '\n'
    last_cycle = results.get('last_completed_cycle_elapsed_seconds')
    if last_cycle is not None: measurement += '\nLast completed cycle: ' + number(last_cycle) + ' seconds.\n'
    (dest / 'README.md').write_text(f'''# C15 retry of source 933bf877 {bundle['kind']} diagnostic

| Check | Result |
|---|---|
| State | {results['state']} |
| Requested duration | 24 hours |
| Observed seconds | {number(results.get('duration_actual_seconds'))} |
| Completed cycles | {number(results.get('completed_cycles'))} |
| Production qualified | No |

Source: `{SOURCE}`. Generation: `{bundle['generation']}`.
{reason}
{measurement}

Closed records preserve the process generation, measured duration and terminal outcome.
Repeated cycles do not add distinct tests. This diagnostic does not establish broad
performance superiority or production readiness. ELF bytes are omitted; their
recorded hashes remain in the archive. Large archives use 64 MiB parts; the checker
joins them in a temporary file and verifies every hash without extracting members:

```sh
python3 {context['evidence']}/check.py
```
''')
    namespace = {'__file__': str(dest / 'check.py'), '__name__': 'retained_capsule_checker'}
    exec(compile(CHECKER, str(dest / 'check.py'), 'exec'), namespace); namespace['main']()
    check_git_sizes(dest)
    return dest


def git(*args, cwd=ROOT, check=True):
    return subprocess.run(['git', *args], cwd=cwd, text=True, capture_output=True, check=check)


def sparse_patterns(evidence):
    return ['/*', '!/docs/evidence/*', '/docs/evidence/README.md', '/' + evidence.as_posix() + '/']


def remote_matches(context, dest):
    path = str(context['evidence'])
    rows = git('ls-tree', '-r', 'origin/main', '--', path).stdout.splitlines()
    if not rows: return False
    expected = {file.name: git('hash-object', str(file)).stdout.strip() for file in dest.iterdir()}
    actual = {}
    for row in rows:
        fields, name = row.split('\t', 1); mode, kind, digest = fields.split()
        member = PurePosixPath(name).relative_to(PurePosixPath(path)).as_posix()
        if mode != '100644' or kind != 'blob' or member in actual: raise ValueError('Unexpected remote evidence.')
        actual[member] = digest
    if actual != expected or context['marker'] not in git('show', 'origin/main:docs/evidence/README.md').stdout:
        raise ValueError('Remote evidence path belongs to different bytes or has no index marker.')
    return True


def publish(bundle, context, source_sha256):
    state_path = context['output'] / 'publication.json'
    if state_path.exists():
        previous = json.loads(state_path.read_text())
        if (previous.get('state') == 'published' and previous.get('generation') == bundle['generation']
                and previous.get('source_record_sha256') == source_sha256): return previous
        raise ValueError('Preserve the prior publication attempt for review.')
    state = {'state': 'preparing', 'source': SOURCE, 'source_record_sha256': source_sha256,
             'generation': bundle['generation'], 'outcome': bundle['outcome'], 'qualified': False, 'push_attempts': []}
    save(state_path, state)
    try:
        dest = artifacts(bundle, context, source_sha256)
        check_git_sizes(dest)
        for attempt in range(1, 4):
            git('fetch', 'origin', 'main')
            if git('merge-base', '--is-ancestor', SOURCE, 'origin/main', check=False).returncode:
                raise ValueError('Diagnostic source is absent from origin/main.')
            if remote_matches(context, dest):
                state.update(evidence_commit=git('rev-parse', 'origin/main').stdout.strip(), remote_already_identical=True)
                break
            worktree = context['worktree'].with_name(context['worktree'].name + f'-attempt-{attempt}')
            if worktree.exists(): raise ValueError('Preserve the existing owned publication worktree.')
            base = git('rev-parse', 'origin/main').stdout.strip()
            git('worktree', 'add', '--detach', '--no-checkout', str(worktree), base)
            subprocess.run(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=worktree,
                           input='\n'.join(sparse_patterns(context['evidence'])) + '\n', text=True, capture_output=True, check=True)
            git('checkout', '--detach', base, cwd=worktree)
            target = worktree / context['evidence']; target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(dest, target)
            index = worktree / 'docs/evidence/README.md'; text = index.read_text()
            if context['marker'] in text: raise ValueError('Remote index already owns this marker.')
            link = f"\n{context['marker']}\n[C15 {bundle['kind']} terminal diagnostic]({context['evidence'].name}/README.md).\n"
            index.write_text(text + link)
            git('add', '--', str(context['evidence']), 'docs/evidence/README.md', cwd=worktree)
            git('commit', '-m', f"Record C15 {bundle['kind']} diagnostic {bundle['generation'][:12]}", cwd=worktree)
            commit = git('rev-parse', 'HEAD', cwd=worktree).stdout.strip()
            pushed = git('push', '--porcelain', 'origin', 'HEAD:main', cwd=worktree, check=False)
            state['push_attempts'].append({'attempt': attempt, 'base': base, 'commit': commit,
                                          'worktree': str(worktree), 'returncode': pushed.returncode,
                                          'stdout': pushed.stdout, 'stderr': pushed.stderr})
            save(state_path, state)
            if pushed.returncode == 0:
                state['evidence_commit'] = commit
                break
        else:
            git('fetch', 'origin', 'main')
            if not remote_matches(context, dest): raise ValueError('Three normal main pushes failed; all attempts retained.')
            state.update(evidence_commit=git('rev-parse', 'origin/main').stdout.strip(), remote_already_identical=True)
        state.update(state='published', completed_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
        save(state_path, state); return state
    except BaseException as error:
        state.update(state='failed', error=repr(error)); save(state_path, state); raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', choices=['resource', 'deadline'], required=True)
    parser.add_argument('--source-sha256', required=True)
    parser.add_argument('--execute', action='store_true'); args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_executed', 'source': SOURCE, 'qualified': False})); return
    bundle = common().publication_inputs(args.kind, args.source_sha256)
    context = identity(bundle, args.kind, args.source_sha256)
    with (context['output'] / '.publication.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        print(json.dumps(publish(bundle, context, args.source_sha256)))


if __name__ == '__main__': main()
