//! Queue/notification boundaries and real-parent callback ownership.
#![allow(clippy::expect_used, reason = "bounded controls fail closed")]

use super::{CLOSED, ReadyParent, Shared};
use atomic_waker::AtomicWaker;
use futures_util::stream::FuturesUnordered;
use std::future::Future;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex, Weak, mpsc};
use std::task::{Context, Poll, Wake, Waker};
use std::time::{Duration, Instant};

#[derive(Default)]
struct Count(AtomicUsize);
impl Wake for Count {
    fn wake(self: Arc<Self>) {
        self.wake_by_ref();
    }

    fn wake_by_ref(self: &Arc<Self>) {
        self.0.fetch_add(1, Ordering::Relaxed);
    }
}

fn parent() -> (Arc<Count>, Waker) {
    let count = Arc::new(Count::default());
    let waker = Waker::from(Arc::clone(&count));
    (count, waker)
}

#[derive(Default)]
struct Gate {
    ready: AtomicBool,
    polls: AtomicUsize,
    wake: AtomicWaker,
}

impl Gate {
    fn signal(&self) {
        self.ready.store(true, Ordering::Release);
        self.wake.wake();
    }
}

struct Handler(Arc<Gate>);
impl Future for Handler {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
        self.0.polls.fetch_add(1, Ordering::Relaxed);
        self.0.wake.register(cx.waker());
        if self.0.ready.load(Ordering::Acquire) {
            Poll::Ready(())
        } else {
            Poll::Pending
        }
    }
}

#[test]
fn consumed_queue_notification_does_not_forward_or_poll_unwoken_sibling() {
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let a = Arc::new(Gate::default());
    let b = Arc::new(Gate::default());
    let mut admitted = FuturesUnordered::new();
    admitted.push(Handler(Arc::clone(&a)));
    admitted.push(Handler(Arc::clone(&b)));
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_pending());
    assert_eq!(a.polls.load(Ordering::Relaxed), 1);
    assert_eq!(b.polls.load(Ordering::Relaxed), 1);
    a.signal();
    assert_eq!(count.0.load(Ordering::Relaxed), 0);
    assert!(ready.poll_admitted(&mut admitted).is_ready());
    assert!(ready.poll_admitted(&mut admitted).is_pending());
    assert_eq!(b.polls.load(Ordering::Relaxed), 1);
    drop(active);
    assert_eq!(count.0.load(Ordering::Relaxed), 0);
    b.signal();
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_ready());
    drop(active);
    assert!(admitted.is_empty());
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
}

#[test]
fn a_second_queued_completion_survives_the_first_completion() {
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let a = Arc::new(Gate::default());
    let b = Arc::new(Gate::default());
    let mut admitted = FuturesUnordered::new();
    admitted.push(Handler(Arc::clone(&a)));
    admitted.push(Handler(Arc::clone(&b)));
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_pending());
    a.signal();
    b.signal();
    assert!(ready.poll_admitted(&mut admitted).is_ready());
    assert!(ready.poll_admitted(&mut admitted).is_ready());
    assert!(admitted.is_empty());
    drop(active);
    assert_eq!(count.0.load(Ordering::Relaxed), 0);
}

#[test]
fn a_self_waking_pending_future_preserves_its_next_poll() {
    struct SelfWake {
        done: Arc<AtomicBool>,
        polls: Arc<AtomicUsize>,
    }
    impl Future for SelfWake {
        type Output = ();

        fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
            self.polls.fetch_add(1, Ordering::Relaxed);
            if self.done.load(Ordering::Acquire) {
                Poll::Ready(())
            } else {
                cx.waker().wake_by_ref();
                Poll::Pending
            }
        }
    }
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let done = Arc::new(AtomicBool::new(false));
    let polls = Arc::new(AtomicUsize::new(0));
    let mut admitted = FuturesUnordered::new();
    admitted.push(SelfWake {
        done: Arc::clone(&done),
        polls: Arc::clone(&polls),
    });
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_pending());
    assert!(polls.load(Ordering::Relaxed) > 0);
    assert_eq!(count.0.load(Ordering::Relaxed), 0);
    drop(active);
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
    done.store(true, Ordering::Release);
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_ready());
    drop(active);
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
}

#[tokio::test]
async fn tokio_cooperative_pending_preserves_its_retry() {
    // Spawn a task so this control runs within an actual finite Tokio task
    // budget, independently of block_on's treatment of its root future.
    tokio::spawn(async {
        let ready = ReadyParent::new();
        let (count, parent) = parent();
        let mut admitted = FuturesUnordered::new();
        admitted.push(async {
            for _ in 0..129 {
                tokio::task::coop::consume_budget().await;
            }
        });
        let active = ready.enter(&parent);
        assert!(ready.poll_admitted(&mut admitted).is_pending());
        // Tokio deferred the child wake until this executor turn ends. A
        // second empty FU poll can consume the immediate fairness notification
        // but must not prevent that deferred child wake from scheduling us.
        assert!(ready.poll_admitted(&mut admitted).is_pending());
        drop(active);
        assert_eq!(count.0.load(Ordering::Relaxed), 0);
        tokio::task::yield_now().await;
        assert_eq!(count.0.load(Ordering::Relaxed), 1);
        let active = ready.enter(&parent);
        assert!(ready.poll_admitted(&mut admitted).is_ready());
        drop(active);
        assert!(admitted.is_empty());
        assert_eq!(count.0.load(Ordering::Relaxed), 1);
    })
    .await
    .expect("cooperative control task completes");
}

#[test]
fn empty_ready_set_acknowledges_stale_notifications() {
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let mut admitted = FuturesUnordered::<std::future::Pending<()>>::new();
    for _ in 0..2 {
        let active = ready.enter(&parent);
        ready.waker.wake_by_ref();
        assert!(ready.poll_admitted(&mut admitted).is_pending());
        drop(active);
        assert_eq!(count.0.load(Ordering::Relaxed), 0);
    }
}

#[test]
fn stale_forward_after_a_later_ack_keeps_the_new_registration() {
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let mut admitted = FuturesUnordered::<std::future::Pending<()>>::new();
    let active = ready.enter(&parent);
    ready.waker.wake_by_ref();
    drop(active);
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
    let active = ready.enter(&parent);
    assert!(ready.poll_admitted(&mut admitted).is_pending());
    drop(active);
    // A previously selected forward can reach its slot lock after this whole
    // newer poll has acknowledged the notification and returned Pending.
    ready.shared.forward();
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
    // The stale continuation must also leave the fresh registration intact.
    ready.waker.wake_by_ref();
    assert_eq!(count.0.load(Ordering::Relaxed), 2);
}

#[test]
fn unconsumed_notifications_follow_the_replacement_parent() {
    let ready = ReadyParent::new();
    let (first, first_waker) = parent();
    let (second, second_waker) = parent();
    drop(ready.enter(&first_waker));
    let active = ready.enter(&second_waker);
    ready.waker.wake_by_ref();
    ready.waker.wake_by_ref();
    assert_eq!(first.0.load(Ordering::Relaxed), 0);
    assert_eq!(second.0.load(Ordering::Relaxed), 0);
    drop(active);
    assert_eq!(first.0.load(Ordering::Relaxed), 0);
    assert_eq!(second.0.load(Ordering::Relaxed), 1);
    ready.waker.wake_by_ref();
    assert_eq!(second.0.load(Ordering::Relaxed), 1);
}

#[test]
#[expect(clippy::panic, reason = "controlled unwind tests the active guard")]
fn unwind_forwards_an_unconsumed_notification() {
    let ready = ReadyParent::new();
    let (count, parent) = parent();
    let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        let _active = ready.enter(&parent);
        ready.waker.wake_by_ref();
        panic!("controlled ready-set poll unwind");
    }));
    assert!(result.is_err());
    assert_eq!(count.0.load(Ordering::Relaxed), 1);
    // The next guard proves ACTIVE was cleared while unwinding.
    drop(ready.enter(&parent));
}

#[test]
fn replacement_drops_the_previous_parent_outside_the_slot_mutex() {
    struct CloseOnDrop {
        shared: Weak<Shared>,
        drops: Arc<AtomicUsize>,
    }
    #[expect(
        clippy::manual_noop_waker,
        reason = "the reentrant destructor is tested"
    )]
    impl Wake for CloseOnDrop {
        fn wake(self: Arc<Self>) {}
    }
    impl Drop for CloseOnDrop {
        fn drop(&mut self) {
            let shared = self.shared.upgrade().expect("owner still alive");
            assert!(shared.parent.try_lock().is_ok());
            self.drops.fetch_add(1, Ordering::Relaxed);
            shared.close();
        }
    }
    let ready = ReadyParent::new();
    let drops = Arc::new(AtomicUsize::new(0));
    let old = Waker::from(Arc::new(CloseOnDrop {
        shared: Arc::downgrade(&ready.shared),
        drops: Arc::clone(&drops),
    }));
    drop(ready.enter(&old));
    drop(old);
    let (_, new) = parent();
    drop(ready.enter(&new));
    assert_eq!(drops.load(Ordering::Relaxed), 1);
    assert!(ready.shared.parent().is_none());
    assert_ne!(ready.shared.flags.load(Ordering::Acquire) & CLOSED, 0);
}

#[test]
fn wake_and_final_parent_drop_can_reenter_without_the_slot_mutex() {
    struct Reentrant {
        shared: Weak<Shared>,
        wakes: Arc<AtomicUsize>,
        drops: Arc<AtomicUsize>,
    }
    impl Wake for Reentrant {
        fn wake(self: Arc<Self>) {
            let shared = self.shared.upgrade().expect("owner alive during wake");
            assert!(shared.parent.try_lock().is_ok());
            self.wakes.fetch_add(1, Ordering::Relaxed);
            shared.notify();
        }
    }
    impl Drop for Reentrant {
        fn drop(&mut self) {
            let shared = self.shared.upgrade().expect("owner alive during drop");
            assert!(shared.parent.try_lock().is_ok());
            self.drops.fetch_add(1, Ordering::Relaxed);
            shared.close();
        }
    }
    let ready = ReadyParent::new();
    let wakes = Arc::new(AtomicUsize::new(0));
    let drops = Arc::new(AtomicUsize::new(0));
    let parent = Waker::from(Arc::new(Reentrant {
        shared: Arc::downgrade(&ready.shared),
        wakes: Arc::clone(&wakes),
        drops: Arc::clone(&drops),
    }));
    let active = ready.enter(&parent);
    drop(parent);
    ready.waker.wake_by_ref();
    drop(active);
    assert_eq!(wakes.load(Ordering::Relaxed), 1);
    assert_eq!(drops.load(Ordering::Relaxed), 1);
}

#[test]
fn close_releases_parent_even_when_a_proxy_waker_is_retained() {
    let ready = ReadyParent::new();
    let count = Arc::new(Count::default());
    let weak_parent = Arc::downgrade(&count);
    let parent = Waker::from(count);
    drop(ready.enter(&parent));
    drop(parent);
    let stale = ready.waker.clone();
    assert!(weak_parent.upgrade().is_some());
    drop(ready);
    assert!(weak_parent.upgrade().is_none());
    stale.wake_by_ref();
    assert!(weak_parent.upgrade().is_none());
}

#[test]
fn a_preclose_callback_claim_may_finish_after_close() {
    struct Blocking {
        entered: mpsc::Sender<()>,
        release: Mutex<mpsc::Receiver<()>>,
        wakes: Arc<AtomicUsize>,
    }
    impl Wake for Blocking {
        fn wake(self: Arc<Self>) {
            self.wakes.fetch_add(1, Ordering::Relaxed);
            self.entered.send(()).expect("observer alive");
            self.release
                .lock()
                .expect("release mutex healthy")
                .recv_timeout(Duration::from_secs(5))
                .expect("test releases claimed callback");
        }
    }
    let ready = ReadyParent::new();
    let wakes = Arc::new(AtomicUsize::new(0));
    let (entered_tx, entered_rx) = mpsc::channel();
    let (release_tx, release_rx) = mpsc::channel();
    let task = Arc::new(Blocking {
        entered: entered_tx,
        release: Mutex::new(release_rx),
        wakes: Arc::clone(&wakes),
    });
    let weak_parent = Arc::downgrade(&task);
    let parent = Waker::from(task);
    drop(ready.enter(&parent));
    drop(parent);
    let stale = ready.waker.clone();
    let worker_waker = stale.clone();
    let worker = std::thread::spawn(move || worker_waker.wake());
    entered_rx
        .recv_timeout(Duration::from_secs(5))
        .expect("inactive wake claims parent");
    drop(ready);
    assert!(weak_parent.upgrade().is_some());
    stale.wake_by_ref();
    assert_eq!(wakes.load(Ordering::Relaxed), 1);
    release_tx.send(()).expect("callback waiting");
    worker.join().expect("claimed callback completed");
    assert!(weak_parent.upgrade().is_none());
}

#[test]
fn close_wins_a_parent_registration_waiting_for_the_slot() {
    let ready = ReadyParent::new();
    let (_, parent) = parent();
    drop(ready.enter(&parent));
    let slot = ready.shared.parent();
    let closing = Arc::clone(&ready.shared);
    let close = std::thread::spawn(move || closing.close());
    let start = Instant::now();
    while ready.shared.flags.load(Ordering::Acquire) & CLOSED == 0 {
        assert!(start.elapsed() < Duration::from_secs(5));
        std::thread::yield_now();
    }
    let registration = Arc::clone(&ready.shared);
    let candidate = Arc::new(Count::default());
    let weak_parent = Arc::downgrade(&candidate);
    let replacement = Waker::from(candidate);
    let register = std::thread::spawn(move || registration.register(&replacement));
    drop(slot);
    close.join().expect("close completes");
    register.join().expect("racing registration completes");
    assert!(ready.shared.parent().is_none());
    assert!(weak_parent.upgrade().is_none());
}
