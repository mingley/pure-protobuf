# C15 measurement findings

The wakeup proxy remains experimental. The bounded encode-scratch candidate also remains experimental. Neither establishes production readiness or broad superiority over Tonic/Prost.

## Wakeup proxy

The default-policy comparison finished: 48 captures, 360,000 successful RPCs and no recorded RPC errors. Feature-off release binaries, benchmark code, tools and settings were matched. CPU results varied considerably, including large changes in the unchanged Tonic controls.

| Native server CPU | Baseline → candidate, repeat 1 | Repeat 2 |
|---|---:|---:|
| Unary, raw N=10,000 | 77 → 103 µs/RPC | 62 → 62 µs/RPC |
| Unary, N/2N slope | 78 → 154 µs/RPC | 60 → 64 µs/RPC |
| Bidi, raw N=10,000 | 587 → 191 µs/RPC | 215 → 203 µs/RPC |
| Bidi, N/2N slope | 840 → 162 µs/RPC | 164 → 206 µs/RPC |

These observations do not establish a consistent CPU benefit. The causal handler-poll check is separate: it proves the targeted polling/wakeup behavior, not shipping speed.

A separately prepared diagnostic requested eight unary captures, 80,000 RPCs, the same four distinct physical cores on one socket, and raw N=10,000 CPU only. Only the new controller and its children inherited that affinity; Root and sibling processes were not repinned. The actual attempt failed on its first server before READY:

```
Load server failed: Operation not permitted (os error 1)
```

The wrapper exited 1 after 1.176 seconds. There were zero completed captures, zero RPCs and no usable CPU result. The failed controller state, first-cell commands/stderr and execution receipt remain under `architecture-c15-wake-affinity-*`. This failure must not be reported as an affinity result, an application regression, or a successful replay.

## Encode scratch

The candidate passed 738 library tests with one existing ignore. Its private allocation-site probe passed 34 cases and independently decoded 88 frames. Built-in Prost avoids the compatibility bridge: four 1 MiB messages need one plaintext scratch allocation instead of four, saving 3,145,740 requested bytes at that site.

An old custom codec using `write_contiguous` takes a new temporary/copy path. Its four 1 MiB messages requested another 4,194,352 bytes in eight serialization allocations; four 1 KiB messages requested 4,140 bytes in eight allocations. These are actual tagged site counts, not whole-RPC allocation or CPU totals. The large bridge cost exceeds the scratch-site saving, so a blanket codec improvement would be incorrect.

Two clean experimental source commits are prepared:

| Variant | Commit |
|---|---|
| Baseline with the same benchmark | `eac85b04368ac3589f99fe96f693e52de83f39ce` |
| Encode-scratch candidate | `06ec9f23d1f1a40af4c6b4b4e1def2f4064dfcb2` |

Their benchmark subtree is identical. Their source difference is exactly six runtime files and one focused test file. The source-bound controller, four explicit build commands and phase plan are prepared, with synthetic checks for exact schedule counts and unresolved negative slopes.

| Prepared phase | Captures | RPCs |
|---|---:|---:|
| Allocation-instrumented release | 192 | 1,440 |
| Feature-off release | 192 | 80,640 |
| Fresh processes, one RPC | 72 | 72 |

None of those four release builds or 456 captures ran. Root paused them after the actual socket-listen denial. The controller preserves zero/noise corpora, both endpoint sides, native/Tonic controls, all repeats and nonpositive slopes. The next iteration needs a codec-compatible retention design and a runtime that permits the existing local endpoint workload before adoption can be assessed.
