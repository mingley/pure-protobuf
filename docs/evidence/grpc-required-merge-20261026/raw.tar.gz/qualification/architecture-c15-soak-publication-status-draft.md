# Current resource-day status

Source: `933bf8775b70d24d91fb46a7992eae343b60f0ea`. Observation: 2026-10-26 UTC.

Both C13 24-hour attempts are **interrupted and incomplete**. Their original
workers are absent and the environment has a different boot identity. No terminal
process result survives, so the exit cause is unavailable and an application
failure is not established.

| Prior attempt | Last preserved progress | Full 24-hour result |
|---|---:|---|
| General resources | 13,673 cancellation cycles | Incomplete; final measured duration unavailable |
| Deadline/reset | 43,781 cycles; 44,453.36 measured seconds | Incomplete |

Deadline cycles repeat the same 30 cases. Repeated cycles are not new distinct
tests. The last general-resource event has balanced started/ended calls and zero
active calls/byte tokens; that observation does not replace terminal cleanup or
a complete duration.

Fresh C15 retry grants are sealed for the same source, existing release binaries,
1 GiB address-space limit, 128 FDs, 4,096 same-UID processes and 86,430 CPU seconds.
**They are not launched yet:** Root is reserving a short physical CPU comparison
window first. Both existing readiness checks pass. Every new attempt must measure
its own full 86,400 seconds; old durations are never resumed or added.

A fresh retry cannot guarantee that this environment remains available for
24 hours. Production-readiness and performance qualification remain open.

The old evidence capsules remain unchanged. Their dated running snapshots record
what was observed at publication; living status and benchmark pages should link
the newer interruption observation instead of describing those old workers as
still running.
