from pathlib import Path
import hashlib,json,subprocess
root=Path('/workspace/pure-protobuf');tree=root/'work/architecture-c15-bytes';q=root/'work/qualification'
assert subprocess.check_output(['git','status','--porcelain'],cwd=tree,text=True)==''
module=r'''//! Test-only C15 allocation-site counters; never linked into shipping builds.
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;
use std::sync::atomic::{AtomicU64, Ordering};
thread_local! { static SITE: Cell<usize> = const { Cell::new(0) }; }
static CALLS: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
static BYTES: [AtomicU64; 4] = [const { AtomicU64::new(0) }; 4];
pub(crate) struct Scope(usize);
pub(crate) fn enter(site: usize) -> Scope { Scope(SITE.with(|value| value.replace(site))) }
impl Drop for Scope { fn drop(&mut self) { SITE.with(|value| value.set(self.0)); } }
fn note(bytes: usize) {
    let _ = SITE.try_with(|site| {
        let site = site.get();
        if site != 0 {
            CALLS[site].fetch_add(1, Ordering::Relaxed);
            BYTES[site].fetch_add(bytes as u64, Ordering::Relaxed);
        }
    });
}
pub(crate) fn snapshot() -> [(u64, u64); 4] {
    std::array::from_fn(|i| (CALLS[i].load(Ordering::Relaxed), BYTES[i].load(Ordering::Relaxed)))
}
pub(crate) fn reset() {
    for x in &CALLS { x.store(0, Ordering::Relaxed); }
    for x in &BYTES { x.store(0, Ordering::Relaxed); }
}
struct TaggedAllocator;
#[global_allocator]
static ALLOCATOR: TaggedAllocator = TaggedAllocator;
// SAFETY: original allocation contracts are forwarded to System unchanged;
// counters inspect no allocated memory and the const TLS Cell does not allocate.
unsafe impl GlobalAlloc for TaggedAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() { note(layout.size()); } p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() { note(layout.size()); } p
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let n = unsafe { System.realloc(p, layout, size) };
        if !n.is_null() { note(size); } n
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) { unsafe { System.dealloc(p, layout) } }
}
'''
new=tree/'pbrs-grpc/src/c15_encode_probe.rs';new.write_text(module)
p=tree/'pbrs-grpc/src/lib.rs';s=p.read_text();s+='\n// C15 diagnostic fixture only.\n#[cfg(test)]\n#[allow(unsafe_code)]\nmod c15_encode_probe;\n';p.write_text(s)
p=tree/'pbrs-grpc/src/wire/encode.rs';s=p.read_text()
pairs=[('''        self.bytes.reserve(len);''','''        #[cfg(test)]
        let scope = crate::c15_encode_probe::enter(1);
        self.bytes.reserve(len);
        #[cfg(test)]
        drop(scope);'''),('''            head.reserve(codec::HEADER_LEN + body.len() / 2 + 32);''','''            #[cfg(test)]
            let scope = crate::c15_encode_probe::enter(2);
            head.reserve(codec::HEADER_LEN + body.len() / 2 + 32);
            #[cfg(test)]
            drop(scope);'''),('''                codec.encode_into(body, gzip_level, &mut writer)?;''','''                #[cfg(test)]
                let _scope = crate::c15_encode_probe::enter(3);
                codec.encode_into(body, gzip_level, &mut writer)?;''')]
for a,b in pairs: assert s.count(a)==1;s=s.replace(a,b)
test=r'''
#[cfg(all(test, feature = "prost"))]
mod c15_allocation_site_tests {
    use super::*;
    use crate::c15_encode_probe as probe;
    #[derive(Clone, PartialEq, ::prost::Message)]
    struct Payload { #[prost(bytes = "vec", tag = "1")] body: Vec<u8> }
    fn noise(bytes: usize) -> Vec<u8> {
        let mut x = 0xd764_7a31_9e50_42cbu64;
        (0..bytes).map(|_| { x ^= x << 13; x ^= x >> 7; x ^= x << 17; x as u8 }).collect()
    }
    #[test]
    fn actual_compressed_encode_allocation_sites() {
        for size in [0, 1024, 65536, 1048576] {
            for entropy in [false, true] {
                for messages in [1, 4] {
                    for flush_each in [false, true] {
                        let message = crate::codec::prost::Message::new(Payload { body: if entropy { noise(size) } else { vec![0; size] } });
                        let encoded_len = message.encoded_len();
                        let mut scratch = EncodeScratch::new();
                        let mut sink = SegSink::new();
                        let mut frames = Vec::new();
                        let mut scratch_caps = Vec::new();
                        let mut output_caps = Vec::new();
                        probe::reset();
                        for _ in 0..messages {
                            append_frame_with_ready(&mut sink, &mut scratch, &message, Some(CompressionAlgorithm::Gzip), MessageLimits::unlimited(), 6, messages).expect("encode");
                            scratch_caps.push(scratch.bytes.capacity());
                            output_caps.push(sink.head.capacity());
                            if flush_each { frames.push(std::mem::replace(&mut sink, SegSink::new()).finish()); }
                        }
                        if !sink.is_empty() { frames.push(sink.finish()); }
                        let sites = probe::snapshot();
                        let mut decoded = 0;
                        let mut wire_bytes = 0;
                        for frame in frames {
                            wire_bytes += frame.total_len();
                            let mut bytes = Bytes::from(frame.concat());
                            while let Some(frame) = crate::codec::pop_from_chunk(&mut bytes, MessageLimits::unlimited()).expect("framing") {
                                assert!(frame.compressed);
                                let raw = CompressionAlgorithm::Gzip.decode(&frame.payload).expect("complete gzip");
                                let back = <crate::codec::prost::Message<Payload> as CodecMessage>::decode_payload(Bytes::from(raw)).expect("prost");
                                assert_eq!(back.0.body, message.0.body);
                                decoded += 1;
                            }
                            assert!(bytes.is_empty());
                        }
                        assert_eq!(decoded, messages);
                        if encoded_len > MAX_RETAINED_SCRATCH_BYTES {
                            assert!(scratch_caps.iter().all(|cap| *cap == 0));
                            assert_eq!(sites[1].0, messages as u64);
                        }
                        eprintln!("C15_ENCODE_SITE size={size} encoded_len={encoded_len} entropy={entropy} messages={messages} flush_each={flush_each} scratch_caps={scratch_caps:?} output_caps={output_caps:?} wire_bytes={wire_bytes} sites={sites:?}");
                    }
                }
            }
        }
    }
}
'''
s+=test;p.write_text(s)
(q/'architecture-c15-bytes-probe-tracked.patch').write_bytes(subprocess.check_output(['git','diff','--binary'],cwd=tree))
(q/'architecture-c15-bytes-probe-allocator.rs').write_text(module);(q/'architecture-c15-bytes-probe-test.rs').write_text(test)
m={'state':'prepared_not_compiled','qualified':False,'base':'ee5b345bd362b1742535e489e0575a00d674bb4c','scope':'Test-only allocator tags:1actualEncodeScratchreserve,2compressedoutputreserve,3compressorcallincludingoutputgrowth; requests count alloc/zeroed/realloc same as rpc-bench.64fixedProst+gzipcases, framing/decode assertionsoutside taggedscope. No shipping production patch.','files':{str(x.relative_to(tree)):hashlib.sha256(x.read_bytes()).hexdigest() for x in [tree/'pbrs-grpc/src/lib.rs',p,new]}}
(q/'architecture-c15-bytes-probe-prepared.json').write_text(json.dumps(m,indent=2)+'\n');print(m)
