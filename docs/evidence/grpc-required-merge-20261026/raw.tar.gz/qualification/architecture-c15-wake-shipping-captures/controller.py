#!/usr/bin/env python3
"""C15 FU-parent wake paired shipping CPU/latency/throughput diagnostic; prepared only.

48 captures, 360000 RPCs, no allocation counter or profiler. Shared-host timing
observations do not qualify shipping latency, throughput or broad superiority.
"""
import argparse
import ast
import datetime
import hashlib
import importlib.util
import itertools
import json
import math
import os
from pathlib import Path
import platform
import random
import re
import shutil
import statistics
import subprocess
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
BUILDER = Q / 'architecture-c13-build-shipping-rpc.py'
BUILDER_SHA = 'a7aa4c07cddf2bab7e2d7c316e7e59a0f85decc504efad22c3238da1b1016410'
ADAPTER = Q / 'architecture-c13-shipping-smoke.py'
ADAPTER_SHA = 'b3c9ed177c9a471c3aeb624b6dc26e4ced1408d03961d7d1890b1e7858affc7a'
HARNESS_SHA = '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b'
BASELINE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
DOCUMENTATION_BASE = 'ee5b345bd362b1742535e489e0575a00d674bb4c'
DOCUMENTATION_PATHS = ('README.md', 'TODO.md', 'docs/benchmarks.md', 'docs/decisions/grpc-execution.md', 'docs/evidence/README.md', 'docs/evidence/grpc-ownership-20261024/README.md', 'docs/evidence/grpc-ownership-20261024/check.py', 'docs/evidence/grpc-ownership-20261024/manifest.json', 'docs/evidence/grpc-ownership-20261024/raw.tar.gz', 'docs/evidence/grpc-ownership-20261024/results.json', 'docs/evidence/grpc-ready-set-20261024/README.md', 'docs/evidence/grpc-ready-set-20261024/check.py', 'docs/evidence/grpc-ready-set-20261024/manifest.json', 'docs/evidence/grpc-ready-set-20261024/raw.tar.gz', 'docs/evidence/grpc-ready-set-20261024/results.json', 'docs/status.md')
WAKE_FILES = {'pbrs-grpc/src/server/connection.rs': '8f22c003b2f79039661d4612cb13cf8a703779e416ec5c6aa61c544bd234b300', 'pbrs-grpc/src/server/connection/ready_wake.rs': 'a50d4f653795b1ade7be29888a1915a28849f2517ea0fc734986db7bbc7bd47f', 'pbrs-grpc/src/server/connection/ready_wake/tests.rs': 'ee3d6848df2b8a230f05c832c6557cae87ef14fa71b0ec844b16fb39b51cf91e', 'pbrs-grpc/tests/connection_wake.rs': 'e0a375fc8b5528da2132b7b70e6dabfc37ac2648862af1085c2c5d1c07841aaa'}
COUNTS = (5000, 10000)
VERSIONS = ('baseline', 'candidate')
ACCOUNTING = ('offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs')


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as out:
        json.dump(value, out, indent=2, allow_nan=False)
        out.write('\n')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def cells_for():
    pairs = [('native', 'prost', 'tonic', 'prost'),
             ('tonic', 'prost', 'native', 'prost'),
             ('tonic', 'prost', 'tonic', 'prost')]
    return [dict(pair=list(pair), shape=shape, payload_bytes=1024, tls=False,
                 compression='identity', connections=1, in_flight=1, repeat=repeat)
            for shape, pair, repeat in itertools.product(('unary', 'bidi'), pairs, range(2))]


def verify_adapter(original):
    assert digest(BUILDER) == BUILDER_SHA and digest(ADAPTER) == ADAPTER_SHA
    assert digest(original) == HARNESS_SHA
    def unchanged_body(path):
        tree = ast.parse(path.read_text())
        return [ast.dump(node, include_attributes=False) for node in tree.body
                if not isinstance(node, ast.FunctionDef) or node.name != 'verified_build']
    assert unchanged_body(original) == unchanged_body(ADAPTER), 'capture logic changed beyond build validation'


def ticks(record):
    assert all(type(record.get(key)) is int and record[key] >= 0 for key in ('user_ticks', 'system_ticks'))
    return record['user_ticks'] + record['system_ticks']


def derived_capture(run, count, hz):
    assert run['passed'] is True and run['client_exit_code'] == 0
    assert all(key not in run for key in ('allocation_totals', 'context_switch_totals', 'instruction_totals', 'syscall_totals'))
    sample = run['resource_samples'][-1]
    client_ticks = ticks(sample['client'])
    server_ticks = ticks(sample['server']) - ticks(run['server_cpu_before'])
    assert server_ticks >= 0
    assert run['client_lifetime_cpu_seconds'] == client_ticks / hz
    assert run['server_cpu_during_client_seconds'] == server_ticks / hz
    metrics = run['metrics']
    assert type(metrics['duration_nanos']) is int and metrics['duration_nanos'] > 0
    rate = metrics['throughput_qps']
    assert isinstance(rate, (int, float)) and math.isfinite(rate) and rate > 0
    assert math.isclose(rate, count * 1e9 / metrics['duration_nanos'], rel_tol=1e-12)
    for key in ('e2e_latency_nanos', 'service_latency_nanos'):
        distribution = metrics[key]
        assert distribution['unit'] == 'nanoseconds'
        assert distribution['histogram']['unit'] == 'nanoseconds'
        assert distribution['histogram']['total_count'] == count
        assert sum(bucket['count'] for bucket in distribution['histogram']['buckets']) == count
        values = [distribution[name] for name in ('min_nanos', 'p50_nanos', 'p90_nanos',
                                                 'p95_nanos', 'p99_nanos', 'max_nanos')]
        assert all(type(value) is int and value >= 0 for value in values)
        assert values == sorted(values)
        assert math.isfinite(distribution['mean_nanos'])
    return {'cell': run['cell'], 'rpc_count': count,
            'client_lifetime_user_ticks': sample['client']['user_ticks'],
            'client_lifetime_system_ticks': sample['client']['system_ticks'],
            'server_client_window_user_ticks': sample['server']['user_ticks'] - run['server_cpu_before']['user_ticks'],
            'server_client_window_system_ticks': sample['server']['system_ticks'] - run['server_cpu_before']['system_ticks'],
            'server_client_window_duration_ns': sample['server']['monotonic_ns'] - run['server_cpu_before']['monotonic_ns'],
            'client_lifetime_cpu_ticks': client_ticks, 'server_client_window_cpu_ticks': server_ticks,
            'client_lifetime_cpu_seconds': client_ticks / hz,
            'server_client_window_cpu_seconds': server_ticks / hz,
            'metrics': metrics}


def ranges(rows, key_names):
    groups = {}
    for row in rows:
        identity = tuple(json.dumps(row.get(key), sort_keys=True) for key in key_names)
        groups.setdefault(identity, []).append(row)
    result = []
    for values in groups.values():
        available = [row['ratio'] for row in values if row['ratio'] is not None]
        result.append({**{key: values[0].get(key) for key in key_names}, 'samples': values,
                       'available_repeats': len(available), 'unresolved_repeats': len(values) - len(available),
                       'ratio_min': min(available) if available else None,
                       'ratio_median': statistics.median(available) if available else None,
                       'ratio_max': max(available) if available else None})
    return result


def summarize(raw, cells, hz):
    slopes, source_cpu, tonic_cpu, source_timing = [], [], [], []
    by_slope = {}
    for version in VERSIONS:
        for index, cell in enumerate(cells):
            a, b = raw[(version, COUNTS[0], index)], raw[(version, COUNTS[1], index)]
            for side, field in [('client', 'client_lifetime_cpu_ticks'), ('server', 'server_client_window_cpu_ticks')]:
                delta = b[field] - a[field]
                slope = delta / hz / COUNTS[0]
                row = {'version': version, 'cell': cell, 'side': side,
                       'small_ticks': a[field], 'large_ticks': b[field], 'delta_ticks': delta,
                       'cpu_seconds_per_rpc_slope': slope,
                       'user_seconds_per_rpc_slope': (b[field.replace('_cpu_ticks', '_user_ticks')] - a[field.replace('_cpu_ticks', '_user_ticks')]) / hz / COUNTS[0],
                       'system_seconds_per_rpc_slope': (b[field.replace('_cpu_ticks', '_system_ticks')] - a[field.replace('_cpu_ticks', '_system_ticks')]) / hz / COUNTS[0],
                       'resolved_positive_slope': delta > 0}
                slopes.append(row)
                by_slope[(version, index, side)] = row
    lookup = {json.dumps(cell, sort_keys=True): index for index, cell in enumerate(cells)}
    for index, cell in enumerate(cells):
        scope = {key: value for key, value in cell.items() if key != 'repeat'}
        for side in ('client', 'server'):
            a, b = by_slope[('baseline', index, side)], by_slope[('candidate', index, side)]
            ratio = b['cpu_seconds_per_rpc_slope'] / a['cpu_seconds_per_rpc_slope'] if (
                a['resolved_positive_slope'] and b['resolved_positive_slope']) else None
            source_cpu.append(dict(scope=scope, repeat=cell['repeat'], side=side, ratio=ratio,
                                   baseline=a, candidate=b))
        native_side = 'client' if cell['pair'] == ['native', 'prost', 'tonic', 'prost'] else (
            'server' if cell['pair'] == ['tonic', 'prost', 'native', 'prost'] else None)
        if native_side:
            reference = dict(cell, pair=['tonic', 'prost', 'tonic', 'prost'])
            reference_index = lookup[json.dumps(reference, sort_keys=True)]
            for version in VERSIONS:
                native, tonic = by_slope[(version, index, native_side)], by_slope[(version, reference_index, native_side)]
                ratio = native['cpu_seconds_per_rpc_slope'] / tonic['cpu_seconds_per_rpc_slope'] if (
                    native['resolved_positive_slope'] and tonic['resolved_positive_slope']) else None
                tonic_cpu.append(dict(scope=scope, repeat=cell['repeat'], side=native_side,
                                      version=version, ratio=ratio, native=native, tonic=tonic))
        for count in COUNTS:
            a, b = raw[('baseline', count, index)]['metrics'], raw[('candidate', count, index)]['metrics']
            measures = [('throughput_qps', a['throughput_qps'], b['throughput_qps'])]
            for kind in ('e2e_latency_nanos', 'service_latency_nanos'):
                for quantile in ('p50_nanos', 'p90_nanos', 'p95_nanos', 'p99_nanos', 'p999_nanos', 'mean_nanos', 'max_nanos'):
                    measures.append((kind + '.' + quantile, a[kind][quantile], b[kind][quantile]))
            for metric, before, after in measures:
                source_timing.append(dict(scope=scope, repeat=cell['repeat'], rpc_count=count, metric=metric,
                                          baseline=before, candidate=after,
                                          ratio=after / before if before is not None and after is not None and before > 0 else None))
    return {'qualified': False, 'shipping_latency_throughput_qualified': False, 'ticks_per_second': hz,
            'cpu_tick_quantum_nanos': 1e9 / hz, 'derived_captures': [{'version': version, **capture} for (version, count, index), capture in sorted(raw.items())], 'cpu_slopes': slopes,
            'source_cpu_comparisons': ranges(source_cpu, ('scope', 'side')),
            'same_side_tonic_cpu_comparisons': ranges(tonic_cpu, ('scope', 'side', 'version')),
            'source_timing_comparisons': ranges(source_timing, ('scope', 'rpc_count', 'metric')),
            'latency_throughput_rule': 'Standalone matched-count observations; never subtract quantiles or rates across N/2N.',
            'cpu_slope_rule': 'Raw(2N ticks - N ticks)/HZ/N; nonpositive slopes retained and ratios unresolved. Setup subtraction assumes stable work and setup; it is not isolated RPC CPU proof.',
            'scope_rule': 'Client CPU is process lifetime including startup/reporting. Server CPU is a before-client to terminal-client observation window; windows differ and must not be treated as interchangeable.',
            'limits': ['Shared host, two repeats and coarse process ticks do not establish statistical or broad shipping superiority.',
                       'All increases, raw histograms, terminal counts and unresolved CPU slopes are retained.',
                       'No allocator-counter, Callgrind, syscall or context-switch measurements in this campaign.',
                       'The causal same-turn scheduling witness does not prove speed; zero, negative, mixed and higher-cost outcomes remain visible.']}


def verify_attribution(sources, contexts):
    tree = contexts['candidate']['tree']
    def git(*args):
        return subprocess.check_output(['git', *args], cwd=tree, text=True).strip()
    docs = git('diff', '--name-only', BASELINE, DOCUMENTATION_BASE).splitlines()
    assert docs == list(DOCUMENTATION_PATHS)
    assert all(path in ('README.md', 'TODO.md') or path.startswith('docs/') for path in docs)
    subprocess.run(['git', 'merge-base', '--is-ancestor', DOCUMENTATION_BASE,
                    sources['candidate']['source']], cwd=tree, check=True)
    changed = git('diff', '--name-only', DOCUMENTATION_BASE,
                  sources['candidate']['source']).splitlines()
    assert sorted(changed) == sorted(WAKE_FILES), 'C15 wake-only attribution changed'
    all_changed = git('diff', '--name-only', BASELINE,
                      sources['candidate']['source']).splitlines()
    assert set(all_changed) == set(docs) | set(WAKE_FILES)
    for path, expected in WAKE_FILES.items():
        assert digest(tree / path) == expected, 'reviewed wake source changed: ' + path
    return dict(baseline_runtime=BASELINE, documentation_base=DOCUMENTATION_BASE,
                documentation_only_paths=docs, wake_only_paths=changed,
                candidate_file_sha256=WAKE_FILES,
                rule='Baseline933 and ee5 differ only by pinned publication docs; ee5-to-candidate has exactly the reviewed wake source and controls. Same-turn/wake controls do not prove physical CPU speed.')


def execute(args):
    assert os.environ.get('PYTHONOPTIMIZE') == '0'
    config = args.sources.resolve(strict=True)
    config_ref = ref(config)
    sources = json.loads(config.read_text())
    assert set(sources) == set(VERSIONS)
    assert sources['baseline']['source'] == BASELINE
    assert all(re.fullmatch(r'[0-9a-f]{40}', sources[name]['source']) for name in VERSIONS)
    assert sources['candidate']['source'] != BASELINE
    controller = Path(__file__).resolve()
    controller_ref = ref(controller)
    smoke = module('shipping_capture_smoke', ADAPTER)
    contexts = {}
    for name in VERSIONS:
        row = sources[name]
        tree = Path(row['checkout']).resolve(strict=True)
        binary, record = Path(row['binary']).resolve(strict=True), Path(row['build_record']).resolve(strict=True)
        verify_adapter(tree / 'scripts/grpc-load-smoke.py')
        build = smoke.verified_build(record, binary, tree)
        assert build['source']['commit'] == row['source']
        bench_tree = subprocess.check_output(['git', 'rev-parse', row['source'] + ':rpc-bench'], cwd=tree, text=True).strip()
        contexts[name] = dict(tree=tree, binary=binary, record=record, build=build,
                              record_ref=ref(record), bench_tree=bench_tree)
    for field in ('tools', 'command'):
        assert len({json.dumps(c['build'][field], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c['build']['source']['locks'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({c['bench_tree'] for c in contexts.values()}) == 1, 'benchmark code/config changed between sources'
    attribution = verify_attribution(sources, contexts)
    hz = os.sysconf('SC_CLK_TCK')
    assert type(hz) is int and hz > 0
    cells = cells_for()
    assert len(cells) == 12
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for path, name in [(controller, 'controller.py'), (ADAPTER, 'capture-adapter.py'),
                       (BUILDER, 'shipping-build-validator.py'), (config, 'sources.json')]:
        shutil.copy2(path, output / name)
    state_path = output / 'state.json'
    state = dict(schema='pbrs.c15-wake-shipping-rpc-diagnostic.v1', qualified=False, production_ready=False,
                 state='running', started_utc=now(), allocation_counts=False, context_switches=False,
                 controller=controller_ref, adapter=ref(ADAPTER), build_validator=ref(BUILDER),
                 sources_input=config_ref, source_harness_sha256=HARNESS_SHA,
                 attribution=attribution,
                 rpc_counts=COUNTS, repeats=2, expected_captures=48, expected_successful_rpcs=360000,
                 ticks_per_second=hz, cpu_tick_quantum_nanos=1e9 / hz,
                 builds={name: c['build'] for name, c in contexts.items()}, completed=[],
                 actual_rpc_totals={name: {key: 0 for key in ACCOUNTING} for name in VERSIONS})
    save(state_path, state)
    reports, raw = {}, {}

    def verify_context(name):
        c = contexts[name]
        assert ref(config) == config_ref and ref(controller) == controller_ref
        verify_adapter(c['tree'] / 'scripts/grpc-load-smoke.py')
        assert ref(c['record']) == c['record_ref']
        assert smoke.verified_build(c['record'], c['binary'], c['tree']) == c['build']

    try:
        for name in VERSIONS:
            c = contexts[name]
            for count in COUNTS:
                directory = output / name / ('n-' + str(count))
                directory.mkdir(parents=True)
                report = dict(schema='pbrs.shipping-load-smoke.v1', binary_sha256=c['build']['binary_sha256'],
                              harness_script_sha256=ADAPTER_SHA, source_harness_sha256=HARNESS_SHA,
                              head=c['build']['source']['commit'], dirty=False, source_verified=True,
                              build_record=c['build'], host=platform.uname()._asdict(),
                              cpu_affinity=sorted(os.sched_getaffinity(0)), seed=20261026,
                              cells=cells, rpc_count=count, duration_per_cell_seconds=60,
                              allocation_counts=False, context_switches=False, callgrind=None, strace=None,
                              ticks_per_second=hz, qualification={'qualified': False}, runs=[])
                reports[(name, count)] = report
                save(directory / 'manifest.json', report)
        # Adjacent native/TT pair scopes; source/count order is a palindrome
        # across repeats: A5k,A10k,B5k,B10k | B10k,B5k,A10k,A5k.
        schedule = [shape * 6 + pair * 2 + repeat
                    for shape in range(2) for repeat in range(2)
                    for pair in (range(3) if repeat == 0 else reversed(range(3)))]
        assert sorted(schedule) == list(range(12))
        for index in schedule:
                cell = cells[index]
                names = VERSIONS if cell['repeat'] == 0 else tuple(reversed(VERSIONS))
                counts = COUNTS if cell['repeat'] == 0 else tuple(reversed(COUNTS))
                for name in names:
                    c = contexts[name]
                    for count in counts:
                        verify_context(name)
                        directory = output / name / ('n-' + str(count))
                        child = directory / ('cell-' + str(index).zfill(3))
                        settings = SimpleNamespace(binary=c['binary'], source_checkout=c['tree'], duration=60,
                                                   rpc_count=count, allocation_counts=False, context_switches=False,
                                                   callgrind=None, strace=None)
                        run = smoke.run_cell(settings, cell, child)
                        state['completed'].append(dict(source=name, rpc_count=count, cell=index,
                                                       path=str(child / 'run.json'), passed=run['passed']))
                        for key in ACCOUNTING:
                            value = run.get('metrics', {}).get(key)
                            if type(value) is int and value >= 0:
                                state['actual_rpc_totals'][name][key] += value
                        report = reports[(name, count)]
                        report['runs'].append(dict(path=child.name + '/run.json', passed=run['passed']))
                        save(directory / 'partial-report.json', report)
                        save(state_path, state)
                        verify_context(name)
                        assert run['cell'] == cell
                        assert [part for part in run['commands']['client'] if part.startswith('--stream-msgs=')] == ['--stream-msgs=4']
                        assert run['passed'], 'failed shipping capture retained: ' + str(child)
                        derived = derived_capture(run, count, hz)
                        derived['raw_capture'] = str(child / 'run.json')
                        raw[(name, count, index)] = derived
                        save(child / 'shipping-derived.json', derived)
        for name in VERSIONS:
            verify_context(name)
            for count in COUNTS:
                report = reports[(name, count)]
                assert len(report['runs']) == len(cells) and all(row['passed'] for row in report['runs'])
                report.update(binary_unchanged=True, source_unchanged=True,
                              harness_script_unchanged=True, passed=True)
                save(output / name / ('n-' + str(count)) / 'report.json', report)
            totals = state['actual_rpc_totals'][name]
            assert all(totals[key] == 180000 for key in ACCOUNTING[:4]), totals
            assert all(totals[key] == 0 for key in ACCOUNTING[4:]), totals
        assert len(state['completed']) == state['expected_captures']
        summary = summarize(raw, cells, hz)
        save(output / 'shipping-summary.json', summary)
        state.update(state='finished', passed=True, completed_utc=now(),
                     summary=ref(output / 'shipping-summary.json'))
        save(state_path, state)
    except BaseException as error:
        state.update(state='failed', passed=False, completed_utc=now(),
                     error={'type': type(error).__name__, 'message': str(error)})
        save(state_path, state)
        raise


def main():
    if not __debug__:
        raise RuntimeError('ordinary Python without -O required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'qualified': False,
                          'allocation_counts': False, 'rpc_counts': COUNTS,
                          'scopes': 6, 'repeats': 2, 'captures': 48, 'successful_rpcs': 360000,
                          'baseline_runtime': BASELINE}, indent=2))
        return
    assert args.sources is not None and args.output is not None
    execute(args)


if __name__ == '__main__':
    main()
