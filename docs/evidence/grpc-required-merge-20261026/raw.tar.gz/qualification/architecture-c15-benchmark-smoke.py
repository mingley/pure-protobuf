#!/usr/bin/env python3
"""Bounded correctness checks for prepared Prost payload-pattern benchmark code."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
SOURCE_FILES = ('rpc-bench/src/main.rs', 'rpc-bench/src/native_prost.rs', 'rpc-bench/src/payload.rs')
SEED = 20261026


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', required=True, type=Path)
    parser.add_argument('--source-checkout', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--payload-bytes', type=int, default=1024)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_executed', 'qualified': False, 'captures': 32}))
        return
    assert __debug__ and 0 < args.payload_bytes <= 64 * 1024 * 1024
    tree = args.source_checkout.resolve(strict=True)
    binary = args.binary.resolve(strict=True)
    pins = {name: digest(tree / name) for name in SOURCE_FILES}
    binary_sha = digest(binary)
    output = args.output.resolve()
    output.mkdir(exist_ok=False)
    cases = []
    for client in ('native', 'tonic'):
        for server in ('native', 'tonic'):
            for shape in ('unary', 'client_stream', 'server_stream', 'bidi', 'bidi_pipelined'):
                cases.append(dict(client=client, server=server, shape=shape,
                    messages=1 if shape == 'unary' else 4, negative=None))
            cases.append(dict(client=client, server=server, shape='bidi', messages=1, negative=None))
            cases.append(dict(client=client, server=server, shape='unary', messages=1, negative='zero_response'))
            cases.append(dict(client=client, server=server, shape='client_stream', messages=1, negative='seed_mismatch'))
    assert len(cases) == 32
    results = []
    environment = {**os.environ, "TOKIO_WORKER_THREADS": "2"}
    for number, case in enumerate(cases):
        assert {name: digest(tree / name) for name in SOURCE_FILES} == pins
        assert digest(binary) == binary_sha
        cell = output / f'cell-{number:03}'
        cell.mkdir()
        request_size = 0 if case['negative'] == 'zero_response' else args.payload_bytes
        count = 1 if case['negative'] else 2
        server_pattern = 'zero' if case['negative'] == 'zero_response' else 'noise'
        client_seed = SEED + 1 if case['negative'] == 'seed_mismatch' else SEED
        common = ['--codec=prost', '--compression=gzip', f'--req-bytes={request_size}',
                  f'--resp-bytes={args.payload_bytes}', '--max-message-size=67108864']
        server_args = [str(binary), 'load-server', '--port=0', f"--transport={case['server']}",
            f'--payload-pattern={server_pattern}', f'--payload-seed={SEED}', *common]
        server_log = cell / 'server.stdout'
        with server_log.open('xb') as stdout, (cell / 'server.stderr').open('xb') as stderr:
            peer = subprocess.Popen(server_args, cwd=tree, stdin=subprocess.DEVNULL,
                stdout=stdout, stderr=stderr, start_new_session=True, env=environment)
            try:
                started = time.monotonic()
                ready = None
                while time.monotonic() - started < 15:
                    lines = server_log.read_text().splitlines()
                    ready = next((line for line in lines if line.startswith('READY ')), None)
                    if ready is not None:
                        break
                    assert peer.poll() is None, 'server exited before READY'
                    time.sleep(0.02)
                assert ready is not None, 'server READY watchdog'
                fields = dict(item.split('=', 1) for item in ready.split()[1:])
                assert fields['transport'] == case['server'] and fields['compression'] == 'gzip'
                assert fields['payload_pattern'] == server_pattern
                assert int(fields['payload_seed']) == SEED
                assert int(fields['payload_request_bytes']) == request_size
                assert int(fields['payload_response_bytes']) == args.payload_bytes
                assert fields['payload_validation'] == ('full-body' if server_pattern == 'noise' else 'length-only')
                metrics_path = cell / 'metrics.json'
                client_args = [str(binary), 'load', f"--transport={case['client']}",
                    f"--shape={case['shape']}", f"--stream-msgs={case['messages']}",
                    '--payload-pattern=noise', f'--payload-seed={client_seed}',
                    f"--server_addr=127.0.0.1:{fields['port']}", '--distribution=closed',
                    '--max-in-flight=1', f'--rpc-count={count}', '--duration-secs=30',
                    f'--output={metrics_path}', *common]
                with (cell / 'client.stdout').open('xb') as client_stdout, (cell / 'client.stderr').open('xb') as client_stderr:
                    result = subprocess.run(client_args, cwd=tree, stdin=subprocess.DEVNULL,
                        stdout=client_stdout, stderr=client_stderr, timeout=45, env=environment)
                assert metrics_path.is_file(), 'client did not publish terminal metrics'
                metrics = json.loads(metrics_path.read_text())
                assert metrics['payload_pattern'] == 'noise' and metrics['payload_seed'] == client_seed
                assert metrics['payload_validation'] == 'full-body'
                assert metrics['payload_request_bytes'] == request_size
                assert metrics['payload_response_bytes'] == args.payload_bytes
                if case['negative']:
                    assert result.returncode != 0 and metrics['successful_rpcs'] == 0
                    assert metrics['failed_rpcs'] == count
                    errors = '\n'.join(metrics['status_errors'])
                    assert ('response payload differs' if case['negative'] == 'zero_response' else 'request payload differs') in errors
                else:
                    assert result.returncode == 0 and metrics['successful_rpcs'] == count
                    for key in ('failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs'):
                        assert metrics[key] == 0, (key, metrics[key])
                record = dict(case=case, rpc_count=count, server_command=server_args,
                    client_command=client_args, server_ready=ready, exit_code=result.returncode,
                    metrics=metrics, expected_negative=case['negative'] is not None)
                save(cell / 'result.json', record)
                results.append(record)
            finally:
                if peer.poll() is None:
                    peer.terminate()
                    try:
                        peer.wait(timeout=3)
                    except subprocess.TimeoutExpired:
                        peer.kill()
                        peer.wait(timeout=3)
    assert {name: digest(tree / name) for name in SOURCE_FILES} == pins
    assert digest(binary) == binary_sha
    report = dict(schema='pbrs.c15-benchmark-smoke.v1', state='passed', qualified=False,
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        source_files=pins, binary_sha256=binary_sha, payload_bytes=args.payload_bytes,
        environment={"TOKIO_WORKER_THREADS": "2"},
        captures=len(results), positive_captures=24, expected_negative_captures=8,
        successful_rpcs=48, expected_failed_rpcs=8, results=results,
        scope='Debug correctness of all five Prost shapes on all four native/tonic pairings; one/four-message bidi controls, full-body validation and deliberate mismatch negatives. Not a performance or production-readiness result.')
    save(output / 'report.json', report)
    print(json.dumps({'state': 'passed', 'captures': len(results), 'report': str(output / 'report.json'), 'qualified': False}))


if __name__ == '__main__':
    main()
