#!/usr/bin/env python3
"""Source-pinned C15 bytes experiment; allocation, shipping, cold are separate."""
import argparse
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
ADAPTER = Q / 'architecture-c15-entropy-smoke-v2.py'
ADAPTER_SHA = '0f6a306d668f1f81e3c9d852a8a6212bf775d2e83e11534a1eeb42c221ec66ef'
PLAN = Q / 'architecture-c15-bytes-matrix-plan-v2.json'
SOURCES = {'baseline': 'eac85b04368ac3589f99fe96f693e52de83f39ce',
           'candidate': '06ec9f23d1f1a40af4c6b4b4e1def2f4064dfcb2'}
FILES = ('pbrs-grpc/src/codec.rs', 'pbrs-grpc/src/codec/prost.rs',
         'pbrs-grpc/src/copy_counts.rs', 'pbrs-grpc/src/wire/encode.rs',
         'pbrs-grpc/src/wire/encode_retained_tests.rs', 'pbrs-grpc/src/wire/out_batch.rs',
         'pbrs-grpc/src/workspace.rs')
ACCOUNTING = ('offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs')


def ref(path):
    path = Path(path).resolve(strict=True)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
    temporary.replace(path)


def git(tree, *arguments):
    return subprocess.check_output(['git', *arguments], cwd=tree, text=True).strip()


def load_module(path):
    spec = importlib.util.spec_from_file_location('c15_entropy', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def identity(cell):
    return json.dumps(cell, sort_keys=True)


def schedule(cells, phase):
    order = sorted(range(len(cells)), key=lambda i: (
        cells[i]['payload_bytes'], cells[i]['payload_pattern'], cells[i]['stream_messages'],
        cells[i]['compression'], cells[i]['repeat'], cells[i]['pair']))
    for index in order:
        cell = cells[index]
        counts = cell.get('rpc_counts', [1])
        if phase == 'allocation_phase':
            counts = [5, 10]
        sources = ('baseline', 'candidate')
        if cell['repeat'] == 1:
            counts, sources = list(reversed(counts)), tuple(reversed(sources))
        for source in sources:
            for count in counts:
                yield index, source, count


def derive(run, count, hz):
    assert run['passed'] and run['client_exit_code'] == 0
    assert run['metrics']['successful_rpcs'] == count
    sample = run['resource_samples'][-1]
    before = run['server_cpu_before']
    result = dict(metrics=run['metrics'], rpc_count=count)
    for side in ('client', 'server'):
        ticks = {kind: sample[side][kind + '_ticks'] - (before[kind + '_ticks'] if side == 'server' else 0)
                 for kind in ('user', 'system')}
        assert min(ticks.values()) >= 0
        ticks['cpu'] = ticks['user'] + ticks['system']
        result[side] = {**{kind + '_ticks': value for kind, value in ticks.items()},
                        'cpu_seconds': ticks['cpu'] / hz,
                        'raw_cpu_us_per_rpc': ticks['cpu'] * 1e6 / hz / count,
                        'rss_bytes_terminal_sample': sample[side]['rss_bytes']}
        if 'allocation_totals' in run:
            result[side]['allocation_totals'] = run['allocation_totals'][side]
    result['server_client_window_duration_ns'] = sample['server']['monotonic_ns'] - before['monotonic_ns']
    return result


def summarize(rows, phase, hz):
    result = dict(qualified=False, phase=phase, raw=rows, slopes=[], source_ratios=[], tonic_ratios=[])
    if phase == 'cold_shipping_phase':
        result['limits'] = 'Fresh processes/one RPC. CPU quantized; no slope or superiority ratios. Metrics retain setup scope.'
        return result
    slopes = {}
    for source in SOURCES:
        cell_ids = sorted({row['cell_index'] for row in rows})
        for index in cell_ids:
            values = sorted([row for row in rows if row['source'] == source and row['cell_index'] == index],
                            key=lambda row: row['rpc_count'])
            assert len(values) == 2
            low, high = values
            delta = high['rpc_count'] - low['rpc_count']
            for side in ('client', 'server'):
                fields = ('allocations', 'requested_bytes') if phase == 'allocation_phase' else ('cpu_ticks', 'user_ticks', 'system_ticks')
                for field in fields:
                    a, b = (value[side]['allocation_totals'][field] if phase == 'allocation_phase' else value[side][field]
                            for value in values)
                    slope = (b - a) / delta / (hz if phase == 'shipping_phase' else 1)
                    row = dict(source=source, cell_index=index, cell=low['cell'], side=side, field=field,
                               low_count=low['rpc_count'], high_count=high['rpc_count'], low=a, high=b,
                               signed_per_rpc_slope=slope, resolved_positive=slope > 0)
                    result['slopes'].append(row)
                    slopes[(source, identity(low['cell']), side, field)] = row
    for row in result['slopes']:
        cell, source, side, field = row['cell'], row['source'], row['side'], row['field']
        if source == 'candidate':
            base = slopes[('baseline', identity(cell), side, field)]
            result['source_ratios'].append(dict(cell=cell, side=side, field=field, baseline=base, candidate=row,
                ratio=row['signed_per_rpc_slope'] / base['signed_per_rpc_slope'] if row['resolved_positive'] and base['resolved_positive'] else None))
        native_side = 'client' if cell['pair'][0] == 'native' else ('server' if cell['pair'][2] == 'native' else None)
        if native_side == side:
            control = dict(cell, pair=['tonic', 'prost', 'tonic', 'prost'])
            tonic = slopes[(source, identity(control), side, field)]
            result['tonic_ratios'].append(dict(source=source, cell=cell, side=side, field=field, native=row, tonic=tonic,
                ratio=row['signed_per_rpc_slope'] / tonic['signed_per_rpc_slope'] if row['resolved_positive'] and tonic['resolved_positive'] else None))
    result['limits'] = 'Signed/nonpositive and unstable repeats retained. No quantile/throughput subtraction or significance/broad-superiority claim.'
    return result


def execute(args):
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
    assert ref(ADAPTER)['sha256'] == ADAPTER_SHA
    plan_ref = ref(PLAN)
    plan = json.loads(PLAN.read_text())
    config_ref = ref(args.sources)
    config = json.loads(args.sources.read_text())
    assert set(config) == set(SOURCES)
    adapter = load_module(ADAPTER)
    mode = 'allocation' if args.phase == 'allocation_phase' else 'shipping'
    contexts = {}
    for source in SOURCES:
        item = config[source]
        tree = Path(item['checkout']).resolve(strict=True)
        assert git(tree, 'rev-parse', 'HEAD') == SOURCES[source] == item['source']
        assert not git(tree, 'status', '--porcelain', '--untracked-files=all')
        binary, record = (Path(item[mode][key]).resolve(strict=True) for key in ('binary', 'build_record'))
        build = adapter.verified_build(record, binary, tree)
        assert build['source']['commit'] == SOURCES[source]
        contexts[source] = dict(tree=tree, binary=binary, record=record, build=build, record_ref=ref(record))
    a, b = (contexts[source]['tree'] for source in SOURCES)
    changed = git(b, 'diff', '--name-only', SOURCES['baseline'], SOURCES['candidate']).splitlines()
    assert sorted(changed) == sorted(FILES)
    for path in ('rpc-bench', 'Cargo.lock', 'scripts/build-rpc-bench.py', 'scripts/grpc-load-smoke.py'):
        assert git(a, 'rev-parse', 'HEAD:' + path) == git(b, 'rev-parse', 'HEAD:' + path)
    for key in ('command', 'tools'):
        assert contexts['baseline']['build'][key] == contexts['candidate']['build'][key]
    assert contexts['baseline']['build']['source']['locks'] == contexts['candidate']['build']['source']['locks']
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for source_path, name in ((Path(__file__), 'controller.py'), (ADAPTER, 'adapter.py'), (PLAN, 'plan.json'), (args.sources, 'sources.json')):
        shutil.copy2(source_path, output / name)
    hz = os.sysconf('SC_CLK_TCK')
    phase = plan[args.phase]
    state = dict(schema='pbrs.c15-bytes-paired.v1', state='running', qualified=False, production_ready=False,
                 started_utc=now(), phase=args.phase, host=platform.uname()._asdict(), ticks_per_second=hz,
                 affinity=sorted(os.sched_getaffinity(0)), sources=ref(args.sources), plan=plan_ref,
                 controller=ref(__file__), adapter=ref(ADAPTER), changed_source_files=changed,
                 expected_captures=phase['captures'], expected_successful_rpcs=phase['successful_rpcs'],
                 completed=[], rpc_totals={source: {key: 0 for key in ACCOUNTING} for source in SOURCES})
    save(output / 'state.json', state)
    rows = []
    try:
        for sequence, (index, source, count) in enumerate(schedule(phase['cells'], args.phase)):
            context = contexts[source]
            assert ref(args.sources) == config_ref and ref(PLAN) == plan_ref
            assert adapter.verified_build(context['record'], context['binary'], context['tree']) == context['build']
            cell = {key: value for key, value in phase['cells'][index].items() if key != 'rpc_counts'}
            settings = SimpleNamespace(binary=context['binary'], source_checkout=context['tree'], duration=60,
                rpc_count=count, allocation_counts=mode == 'allocation', context_switches=False, callgrind=None, strace=None)
            directory = output / ('capture-' + str(sequence).zfill(3))
            run = adapter.run_cell(settings, cell, directory)
            state['completed'].append(dict(index=index, source=source, rpc_count=count, passed=run['passed'], raw=ref(directory / 'run.json')))
            for key in ACCOUNTING:
                value = run.get('metrics', {}).get(key)
                if type(value) is int and value >= 0:
                    state['rpc_totals'][source][key] += value
            save(output / 'state.json', state)
            assert run['passed'], 'Failed capture retained: ' + str(directory)
            rows.append(dict(source=source, cell_index=index, cell=cell, raw=ref(directory / 'run.json'), **derive(run, count, hz)))
            assert adapter.verified_build(context['record'], context['binary'], context['tree']) == context['build']
            print(f'{args.phase} {sequence + 1}/{phase["captures"]}', flush=True)
        assert len(rows) == phase['captures']
        assert sum(values['successful_rpcs'] for values in state['rpc_totals'].values()) == phase['successful_rpcs']
        for values in state['rpc_totals'].values():
            assert len({values[key] for key in ACCOUNTING[:4]}) == 1
            assert all(values[key] == 0 for key in ACCOUNTING[4:])
        result = summarize(rows, args.phase, hz)
        save(output / 'summary.json', result)
        state.update(state='finished', passed=True, completed_utc=now(), summary=ref(output / 'summary.json'))
        save(output / 'state.json', state)
    except BaseException as error:
        state.update(state='failed', passed=False, completed_utc=now(), error=dict(type=type(error).__name__, message=str(error)))
        save(output / 'state.json', state)
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--sources', type=Path)
    parser.add_argument('--phase', choices=('allocation_phase', 'shipping_phase', 'cold_shipping_phase'))
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps(dict(state='prepared_not_run', qualified=False, sources=SOURCES)))
        return
    assert args.sources and args.phase and args.output
    execute(args)


if __name__ == '__main__':
    main()
