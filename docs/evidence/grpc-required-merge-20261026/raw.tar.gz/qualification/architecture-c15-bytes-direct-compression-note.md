# Later experiment: serialize directly into compression

Design note only. No implementation, compiler or measurement. Separate from the
bounded encode-scratch reuse candidate and the compressed-output reserve hint.

The callsite probe observes four1MiB plaintext scratch allocations for four
compressed messages. Retaining a canonical Vec can amortize those allocations,
but still stores a full plaintext copy per admitted stream. A streaming serializer
could instead feed a bounded staging block into a fresh per-message compressor.
That could avoid the full plaintext intermediate without retaining1MiB per stream.
It does not eliminate the application's message storage or compressed wire output.

pbrs serializers can target a private WireOut with a bounded block and a Write
compressor. Prost needs generic BufMut. The additive BufMut method in the reuse
candidate would provide a useful seam, but a compressor-backed BufMut must uphold
chunk_mut/advance_mut initialization and remaining_mut contracts. That usually
requires an audited unsafe BufMut implementation; it must not be hidden in this
safe reuse patch or bypass the transport's module forbids.

BufMut/WireOut append operations do not return IO errors. The adapter must record
the first compressor/output failure, keep every buffer operation valid and return
the correct Status after serialization, or use a separately reviewed fallible
interface. Never turn a compression error into a successful partial message.

The compressed gRPC length prefix remains unknown until compression finishes.
Buffer compressed bytes or segments until that prefix is known; preserve prior
complete batch frames if the current message fails. Finish every independent gzip
member and validate unchanged output/decode behavior, limits, custom codec errors,
panic cleanup, rollback and terminal resource ownership.

Do not assume streaming wins: small fields can cause many tiny compressor writes,
a bounded block can add copies/branches, compressed output still grows, and custom
legacy contiguous encoders may still need their temporary. Compare cold/warm,
small/large, zero/noise/structured input, both message families and both endpoint
CPU/latency/throughput/allocations. Ownership proof and actual measurements must
precede any adoption.
