//! Forward only ready-set notifications that remain unconsumed by this poll.

use futures_util::stream::FuturesUnordered;
use std::future::Future;
use std::sync::atomic::{AtomicU8, Ordering};
use std::sync::{Arc, Mutex, MutexGuard, PoisonError};
use std::task::{Context, Poll, Wake, Waker};

const ACTIVE: u8 = 1;
const NOTIFIED: u8 = 2;
const CLOSED: u8 = 4;

/// One lazy connection owner. Child wakers may retain the shared proxy, but
/// closing this owner releases the actual parent task's waker.
pub(super) struct ReadyParent {
    shared: Arc<Shared>,
    waker: Waker,
}

struct Shared {
    flags: AtomicU8,
    parent: Mutex<Option<Waker>>,
}

pub(super) struct Active<'a> {
    shared: &'a Shared,
}

impl ReadyParent {
    pub(super) fn new() -> Self {
        let shared = Arc::new(Shared {
            flags: AtomicU8::new(0),
            parent: Mutex::new(None),
        });
        let waker = Waker::from(Arc::clone(&shared));
        Self { shared, waker }
    }

    pub(super) fn enter(&self, parent: &Waker) -> Active<'_> {
        let previous = self.shared.flags.fetch_or(ACTIVE, Ordering::AcqRel);
        // Construct the guard before arbitrary real-Waker clone/drop callbacks.
        let active = Active {
            shared: &self.shared,
        };
        debug_assert_eq!(previous & (ACTIVE | CLOSED), 0);
        self.shared.register(parent);
        active
    }

    pub(super) fn poll_admitted<F: Future<Output = ()>>(
        &self,
        admitted: &mut FuturesUnordered<F>,
    ) -> Poll<()> {
        // A child publishes its FU queue entry before notifying this proxy.
        // Acknowledge BEFORE polling: a wake during/after this poll, including
        // a cooperative/self-wake, must remain pending. Clear even when empty
        // so stale notifications cannot repeatedly schedule an empty ready set.
        self.shared.flags.fetch_and(!NOTIFIED, Ordering::AcqRel);
        if admitted.is_empty() {
            Poll::Pending
        } else {
            super::poll_admitted(admitted, &mut Context::from_waker(&self.waker))
        }
    }
}

impl Drop for ReadyParent {
    fn drop(&mut self) {
        self.shared.close();
    }
}

impl Shared {
    fn parent(&self) -> MutexGuard<'_, Option<Waker>> {
        self.parent.lock().unwrap_or_else(PoisonError::into_inner)
    }

    fn register(&self, parent: &Waker) {
        let needs_update = self
            .parent()
            .as_ref()
            .is_none_or(|previous| !previous.will_wake(parent));
        if needs_update {
            let replacement = parent.clone();
            let previous = {
                let mut slot = self.parent();
                // Check under the slot mutex: close must not clear the slot
                // only for a racing registration to retain the task afterward.
                if self.flags.load(Ordering::Acquire) & CLOSED != 0 {
                    Some(replacement)
                } else {
                    slot.replace(replacement)
                }
            };
            drop(previous);
        }
    }

    fn notify(&self) {
        let previous = self.flags.fetch_or(NOTIFIED, Ordering::AcqRel);
        if previous & (ACTIVE | CLOSED) == 0 {
            self.forward();
        }
    }

    fn forward(&self) {
        let parent = {
            let mut slot = self.parent();
            // A poll may have started since an inactive notifier observed the
            // state. It will acknowledge the queue or forward on guard exit.
            if self.flags.load(Ordering::Acquire) & (ACTIVE | CLOSED) == 0 {
                slot.take()
            } else {
                None
            }
        };
        if let Some(parent) = parent {
            parent.wake();
        }
    }

    fn close(&self) {
        self.flags.fetch_or(CLOSED, Ordering::AcqRel);
        let parent = self.parent().take();
        drop(parent);
    }
}

impl Wake for Shared {
    fn wake(self: Arc<Self>) {
        self.notify();
    }

    fn wake_by_ref(self: &Arc<Self>) {
        self.notify();
    }
}

impl Drop for Active<'_> {
    fn drop(&mut self) {
        let previous = self.shared.flags.fetch_and(!ACTIVE, Ordering::AcqRel);
        if previous & NOTIFIED != 0 && previous & CLOSED == 0 {
            self.shared.forward();
        }
    }
}

#[cfg(test)]
mod tests;
