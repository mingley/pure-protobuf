# Next encode-scratch design

Keep the canonical `Vec<u8>` retention model for codecs that explicitly support append-only serialization. Preserve the existing `BytesMut` encoding path for other codecs. Make the capability default off so existing implementations retain their current serialization behavior.

The current candidate is correct about ownership, but its compatibility adapter changes the cost of old `write_contiguous` encoders. The private probe recorded eight additional serialization allocation requests totaling 4,194,352 bytes for four 1 MiB messages. The built-in scratch reuse saved 3,145,740 requested bytes at a different tagged site. The bridge cost alone exceeds that saving. These are site counts, not a measured whole-RPC allocation delta or a shipping CPU result.

## Capability and fallback

Use an explicit capability to select canonical append-only storage versus the legacy mutable buffer. Existing custom codecs default to the legacy path. The built-in Prost wrapper can opt in because its generic `BufMut` encoder writes directly into transport-owned storage.

Do not opt the entire `T: Serialize` blanket implementation into canonical encoding merely because generated messages normally use primitive writes. A custom `Serialize::encode` implementation can call `WireOut::write_contiguous`. Its fallback would allocate and copy on every message. Supporting generated messages requires an explicit generated/trait capability with a legacy default, or retaining the legacy path until that contract exists. A codec changing its claim must also satisfy matching payload/error behavior.

A storage enum can hold either the canonical `Vec` plus lease or the legacy `BytesMut`. An approximately eight-byte size increase is a plausible layout cost on the current 64-bit target, not a guaranteed ABI or an executed size measurement. Measure the actual scratch, batch and connection layouts after implementation. A small fixed owner-size increase is preferable to adding a payload-sized allocation and copy for every legacy message, provided the endpoint measurements confirm the tradeoff.

## Ownership and budgeting

Canonical storage stays private. Append-only access prevents a codec from replacing the allocation, splitting it, or retaining a shared owner. The transport therefore knows which complete allocation it retains and can charge its actual capacity to the idle-capacity ledger.

Visible `BytesMut` pointer and capacity equality do not prove that complete ownership survives arbitrary codec calls. A codec can replace the buffer or split/retain backing storage, and a visible slice capacity need not describe the full allocation. Do not apply the canonical large-buffer budget using those observations as an ownership proof. Keep the legacy path's existing retention policy unless a separate sound ownership mechanism is established.

Preserve the reviewed lease rules: release idle claims before using a buffer actively; move active scratch out of the owner before calling arbitrary codec/compressor code; discard it on errors or panics; charge actual capacity only when admitting successful idle retention; deallocate storage before releasing its claim. Budget exhaustion remains a cache miss. Ready-but-still-held terminal pumps must release retained storage and claims. The encode ledger remains distinct from decode retention, active buffers and process RSS.

## Checks before adoption

Re-run the existing private zero/noise site corpus and the old custom-contiguous cases. Add checks that the default-off fallback avoids the new temporary serialization allocation, that an explicit direct codec uses canonical storage, and that errors, panics, budget rejection and terminal completion preserve the ownership rules. Keep the existing alias/replacement cases on the legacy path.

Then build matched feature-off and allocation variants using identical benchmark code. Run the prepared client/server/Tonic controls across small, boundary and large compressed payloads, including fresh processes and warm streams. Retain all regressions and unresolved CPU slopes. The current environment denies local socket listening, so these endpoint comparisons remain blocked. Neither this design note nor the current allocation-site result establishes shipping speed or production readiness.
