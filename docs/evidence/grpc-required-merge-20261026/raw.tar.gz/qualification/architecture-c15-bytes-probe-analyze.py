from pathlib import Path
import ast,hashlib,json,re
root=Path('/workspace/pure-protobuf');q=root/'work/qualification';tree=root/'work/architecture-c15-bytes'
log=q/'architecture-c15-bytes-probe-test.stderr'
pattern=re.compile(r'^C15_ENCODE_SITE size=(\d+) encoded_len=(\d+) entropy=(true|false) messages=(\d+) flush_each=(true|false) scratch_caps=(\[.*?\]) output_caps=(\[.*?\]) wire_bytes=(\d+) sites=(\[.*\])$')
rows=[]
for line in log.read_text().splitlines():
 if not line.startswith('C15_ENCODE_SITE'):continue
 m=pattern.fullmatch(line);assert m,line
 size,encoded,entropy,messages,flush,scratch,output,wire,sites=m.groups()
 row={'body_bytes':int(size),'protobuf_bytes':int(encoded),'entropy':'deterministic_noise' if entropy=='true' else 'zeros','messages':int(messages),'flush_each':flush=='true','scratch_capacity_after_each':ast.literal_eval(scratch),'output_capacity_after_each':ast.literal_eval(output),'wire_bytes':int(wire)}
 row['sites']={name:{'allocation_and_reallocation_requests':counts[0],'requested_bytes':counts[1]}for name,counts in zip(['untagged_not_counted','plaintext_scratch_reserve','initial_compressed_output_reserve','compressor_call_including_output_growth'],ast.literal_eval(sites))}
 rows.append(row)
assert len(rows)==32
assert sum(x['messages'] for x in rows)==80
held=json.loads((q/'architecture-c15-bytes-probe-held.json').read_text())
assert all(hashlib.sha256((tree/name).read_bytes()).hexdigest()==h for name,h in held['source'].items())
assert hashlib.sha256(Path(held['binary']['path']).read_bytes()).hexdigest()==held['binary']['sha256']
for x in rows:
 if x['body_bytes']>=65536:
  assert x['sites']['plaintext_scratch_reserve']['allocation_and_reallocation_requests']==x['messages']
  assert x['sites']['plaintext_scratch_reserve']['requested_bytes']==x['messages']*x['protobuf_bytes']
  assert all(v==0 for v in x['scratch_capacity_after_each'])
 if x['body_bytes']==1024:
  assert x['sites']['plaintext_scratch_reserve']['allocation_and_reallocation_requests']==1
  assert x['sites']['plaintext_scratch_reserve']['requested_bytes']==1027
  assert all(v==1027 for v in x['scratch_capacity_after_each'])
def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
out={'schema':'pbrs.c15-encode-site-attribution.v1','qualified':False,'production_applied':False,'baseline_runtime_source':'933bf8775b70d24d91fb46a7992eae343b60f0ea','baseline_repository':'ee5b345bd362b1742535e489e0575a00d674bb4c','profile':'test/debug allfeatures; allocator tags absent non-test builds','case_count':32,'messages_encoded_and_independently_decoded':80,'test':ref(q/'architecture-c15-bytes-probe-test.json'),'build':ref(q/'architecture-c15-bytes-probe-build.json'),'held_source_elf':ref(q/'architecture-c15-bytes-probe-held.json'),'raw':ref(log),'rows':rows,'conclusions':['Actual callsite shows four fresh1,048,580-byte allocations for four1MiB Prost messages under both zero/noise and burst/singletonflush controls. Scratch capacity is zero after each message.','Actual1KiB control requests1,027bytes once and reuses that capacity across fourmessages.','The initial output-reserve callsite requests1,572,981bytes for fourbatchedzero1MiB messages, or2,097,308bytes for fourfreshsinks, while wire output totals4,244bytes.','Compressor-call tags include state allocations AND any output-buffer growth caused by writes; they are not pure codec-state attribution.'],'limits':['This is a controlled privatecallsite fixture, not the full rpc-bench endpoint allocator and not a complete attribution of the tonic/prost gap.','Test profile and testonly allocator; no shipping CPU/latency/throughput or retained-memory proof.','Exact four-frame plaintext reuse would conditionally avoid3,145,740requestedbytes in this fixture; no candidate has been built or measured.','Original preparation prose said64cases; actual loop has32cases and80messages. Source was unchanged during build/run; this record corrects the prose without relabeling execution.']}
with (q/'architecture-c15-bytes-probe-analysis.json').open('x')as f:json.dump(out,f,indent=2);f.write('\n')
print({'cases':len(rows),'frames':sum(x['messages']for x in rows),'source_unchanged':True,'analysis':ref(q/'architecture-c15-bytes-probe-analysis.json')})
