#!/usr/bin/env python3
"""Independent upb initialization and final-map state controls; no shipping dependency."""
from pathlib import Path
import datetime
import hashlib
import json
import subprocess
import sys

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TARGET = ROOT / 'work/toolchain/reference-protobuf'
sys.path.insert(0, str(TARGET))
import google.protobuf
from google.protobuf import descriptor_pb2, descriptor_pool, message_factory
from google.protobuf.internal import api_implementation


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def classes(fds):
    descriptor = descriptor_pb2.FileDescriptorSet.FromString(fds)
    pool = descriptor_pool.DescriptorPool()
    for file in descriptor.file:
        pool.Add(file)
    return pool


def run(pool, message_name, rows, extended=False):
    cls = message_factory.GetMessageClass(pool.FindMessageTypeByName(message_name))
    results = []
    for row in rows:
        value = cls()
        wire = bytes.fromhex(row['input_hex'])
        try:
            value.ParseFromString(wire)
            parsed, error = True, None
        except google.protobuf.message.DecodeError as failure:
            parsed, error = False, str(failure)
        initialized = parsed and value.IsInitialized()
        result = dict(name=row['name'], message=message_name, input_hex=row['input_hex'],
                      wire_parsed=parsed, parse_error=error, initialized=initialized,
                      initialization_errors=value.FindInitializationErrors() if parsed else None,
                      text=str(value) if parsed else None,
                      partial_serialized_hex=value.SerializePartialToString().hex() if parsed else None,
                      cpp_wire_exit_code=row.get('exit_code', row.get('wire_parse_exit')),
                      cpp_stderr=row['stderr'])
        if extended and parsed:
            result['map_length'] = len(value.by_key)
            result['map_values'] = {str(key): dict(a=child.a, b=child.b,
                                                  has_a=child.HasField('a'), has_b=child.HasField('b'))
                                    for key, child in value.by_key.items()}
        results.append(result)
    return results


def main():
    assert google.protobuf.__version__ == '6.33.5'
    assert api_implementation.Type() == 'upb'
    assert Path(google.protobuf.__file__).is_relative_to(TARGET)
    original = json.loads((Q / 'architecture-c15-kernel-reference/reference.json').read_text())
    base_pool = classes((Q / 'architecture-c15-kernel-baseline-v2-consumer/schema.fds').read_bytes())
    base = []
    for row in original['cases']:
        result = run(base_pool, 'required_merge.' + row['message'], [row])[0]
        result['expected_initialized'] = row['expected_accept']
        base.append(result)
    extended_dir = Q / 'architecture-c15-kernel-map-group-reference'
    protoc = Q / 'kernel-unknown-group-official-tools-v2/protoc'
    fds = extended_dir / 'schema.fds'
    assert not fds.exists()
    command = [str(protoc), '--descriptor_set_out=' + str(fds),
               '--proto_path=' + str(extended_dir), str(extended_dir / 'required_extended.proto')]
    result = subprocess.run(command, capture_output=True)
    (extended_dir / 'descriptor.stdout').write_bytes(result.stdout)
    (extended_dir / 'descriptor.stderr').write_bytes(result.stderr)
    assert result.returncode == 0
    ext = json.loads((extended_dir / 'reference.json').read_text())
    extended = run(classes(fds.read_bytes()), 'required_merge.Parent', ext['cases'], True)
    wheel = ROOT / 'work/toolchain/reference-protobuf-wheels/protobuf-6.33.5-cp39-abi3-manylinux2014_x86_64.whl'
    record = dict(schema='pbrs.c15-required-merge-upb-reference.v1', qualified=False,
                  created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  version=google.protobuf.__version__, implementation=api_implementation.Type(),
                  package_path=str(google.protobuf.__file__), wheel=ref(wheel), helper=ref(Path(__file__)),
                  descriptor_command=command, descriptor=ref(fds), base_cases=base, extended_cases=extended,
                  limits=['Independent upb reference; local test tooling only, no shipped dependency.',
                          'C++ protoc partial parser reports required initialization warnings separately from wire parsing.',
                          'Map state and required initialization are observed on actual materialized upb map values.'])
    path = Q / 'architecture-c15-kernel-python-reference.json'
    with path.open('x') as output:
        json.dump(record, output, indent=2)
        output.write('\n')
    assert all(r['initialized'] == r['expected_initialized'] for r in base)
    print('Base reference:', len(base), 'matched initialization outcomes')
    print('Extended reference:', [(r['name'], r['initialized'], r.get('map_values')) for r in extended])


if __name__ == '__main__':
    main()
