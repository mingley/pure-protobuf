//! Test-only C15 allocation-site counters; never linked into shipping builds.
use std::alloc::{GlobalAlloc, Layout, System};
use std::cell::Cell;
use std::sync::atomic::{AtomicU64, Ordering};
thread_local! { static SITE: Cell<usize> = const { Cell::new(0) }; }
static CALLS: [AtomicU64; 5] = [const { AtomicU64::new(0) }; 5];
static BYTES: [AtomicU64; 5] = [const { AtomicU64::new(0) }; 5];
pub(crate) struct Scope(usize);
pub(crate) fn enter(site: usize) -> Scope { Scope(SITE.with(|value| value.replace(site))) }
impl Drop for Scope { fn drop(&mut self) { SITE.with(|value| value.set(self.0)); } }
fn note(bytes: usize) {
    let _ = SITE.try_with(|site| {
        let site = site.get();
        if site != 0 {
            CALLS[site].fetch_add(1, Ordering::Relaxed);
            BYTES[site].fetch_add(bytes as u64, Ordering::Relaxed);
        }
    });
}
pub(crate) fn snapshot() -> [(u64, u64); 5] {
    std::array::from_fn(|i| (CALLS[i].load(Ordering::Relaxed), BYTES[i].load(Ordering::Relaxed)))
}
pub(crate) fn reset() {
    for x in &CALLS { x.store(0, Ordering::Relaxed); }
    for x in &BYTES { x.store(0, Ordering::Relaxed); }
}
struct TaggedAllocator;
#[global_allocator]
static ALLOCATOR: TaggedAllocator = TaggedAllocator;
// SAFETY: original allocation contracts are forwarded to System unchanged;
// counters inspect no allocated memory and the const TLS Cell does not allocate.
unsafe impl GlobalAlloc for TaggedAllocator {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() { note(layout.size()); } p
    }
    unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc_zeroed(layout) };
        if !p.is_null() { note(layout.size()); } p
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let n = unsafe { System.realloc(p, layout, size) };
        if !n.is_null() { note(size); } n
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) { unsafe { System.dealloc(p, layout) } }
}
