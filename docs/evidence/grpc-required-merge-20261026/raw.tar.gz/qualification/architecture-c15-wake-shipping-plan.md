# C15 FU-parent wake comparison — prepared only

Compare the retained source933 feature-off release binary against the future clean C15 wake commit. The same-turn and callback/race controls do not establish a speed benefit. No build or capture has run through this generation.

## Contract

- Identity1KiB unary and four-message bidi; one connection, one in-flight RPC, unchanged two-worker policy.
- Native-Prost client/Tonic-Prost server, Tonic-Prost client/native-Prost server and Tonic/Tonic. Both endpoint CPU and timing remain visible.
- N5,000/10,000, two balanced repeats, two sources: **48 captures / 360,000 successful RPCs**, 180,000 per source.
- Adjacent pair scopes; reverse source/count/pair order across repeats. Keep full raw user/system ticks, signed slopes, histograms, errors and every higher cost.
- Unchanged shipping builder `a7aa4c07…`, adapter `b3c9ed17…`, benchmark subtree, locks, features/profile, queue/buffer/flush/worker settings.
- Source933→ee5 is exactly16 pinned publication-doc paths. ee5→candidate must be exactly the four reviewed wake production/control paths from prepared-v3. All four physical SHA256 values are embedded in the controller.
- Source registration, parent notifications and cooperative behavior differ only through the reviewed proxy. Shared-host process ticks and two repeats do not establish broad superiority or dedicated-host timing qualification.

The candidate commit/checkout stay null in `architecture-c15-wake-shipping-sources-template.json` until Root creates and freezes a clean commit. Any source or fixture correction after prepared-v3 needs a recorded new controller/preparation generation. Never overwrite captures.

## Build after Root freezes source and grants serial cache use

```sh
env PYTHONOPTIMIZE=0 RUSTUP_TOOLCHAIN=stable CARGO_BUILD_JOBS=1 \
  CARGO_TARGET_DIR=/workspace/pure-protobuf/work/rpc-target \
  /workspace/pure-protobuf/work/run-rust python3 \
  /workspace/pure-protobuf/work/qualification/architecture-c13-build-shipping-rpc.py \
  --source-checkout ACTUAL_CLEAN_C15_WAKE_CHECKOUT \
  --source ACTUAL_FULL_CANDIDATE_COMMIT \
  --output /workspace/pure-protobuf/work/qualification/architecture-c15-wake-shipping-candidate-build \
  --execute
```

Use a unique `resource-c15-wake-shipping-build-execution` receipt via `work/record.py`, cwd in the frozen candidate tree. The existing baseline is source933 in `work/architecture-c13-batch`; its retained build and ELF verify during preparation. No baseline rebuild is necessary for a documentation-only ee5 change.

## Capture after build validation and Root's quiet-window grant

Fill a new `architecture-c15-wake-shipping-sources.json`; preserve the null template. Record actual boot, CPU quota/HZ, known-workload scan and coverage limits before and after. Previews, compilers, traces, other benchmarks and new soak endpoints must be held during this small diagnostic. A readable empty known-process scan is not global quiescence proof.

```sh
env PYTHONOPTIMIZE=0 python3 \
  /workspace/pure-protobuf/work/qualification/architecture-c15-wake-shipping-paired.py \
  --sources /workspace/pure-protobuf/work/qualification/architecture-c15-wake-shipping-sources.json \
  --output /workspace/pure-protobuf/work/qualification/architecture-c15-wake-shipping-captures \
  --execute
```

Use a unique `resource-c15-wake-shipping-execution` receipt. Stop at the first failed source/tool/accounting check, preserving its state. Retain all raw costs and nonpositive CPU slopes; their ratios remain unresolved. Never subtract quantiles or throughput across N/2N. Client CPU includes process startup/reporting; server CPU covers before-client through terminal-client observation. Do not relabel those scopes as interchangeable or infer CPU speed from wake counts.

Preparation imports validators and reads only closed C14 samples for summary controls. It did not invoke Cargo, a server or a client. Capture/summary/main helpers remain AST-identical to the original C14 controller; only the source-attribution guard, result schema and metadata date changed.
