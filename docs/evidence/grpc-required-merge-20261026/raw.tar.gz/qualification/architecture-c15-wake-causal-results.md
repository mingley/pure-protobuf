# FU wake forwarding: causal probe

The isolated candidate passes 100 focused checks: one actual wire control, 13
private queue/race/callback/cooperative controls and 86 existing reset, deadline,
accounting, admission, lifecycle, drain and bidi checks. Root production is unchanged.

| Source | Target handler in the one DATA poll | Parent wakes | Actual result |
|---|---:|---:|---|
| Original runtime | 0 | 1 | Final progress assertion fails |
| Old ready-set recheck | 1 | 2 | Final redundant-wake assertion fails |
| FU-only proxy | 1 | 1 | Pass |

Each receives exactly 14 DATA bytes, leaves an unwoken sibling at one poll, and
finishes valid status/body plus same-connection recovery before detection. The
unchanged fixture, actual ELFs, commands and source hashes are retained.

One lazy Arc proxy forwards only FU parent notifications. It acknowledges before
FU polling, retains notifications during/after polling, and forwards leftovers on
Ready/Pending/unwind. Real IO/drain wakers stay direct. Real parent clone/drop/wake
callbacks run outside the parent-slot mutex; owner close clears the retained task.

Actual controls include a Tokio task exhausting its finite cooperative budget:
a second empty FU poll consumes immediate fairness notification, while the later
executor-deferred child wake still forwards once and permits completion.

No shipping CPU or cold connection benefit is established. Tokio can coalesce
same-turn notifications already; the extra Arc, mutex and fairness slice must be
measured. A prior claim can finish after close. This is not exhaustive weak-memory,
TSan, universal fairness or legacy-callback safety proof.

The first baseline launch guessed an ELF suffix and failed before test spawn;
corrected v2 uses the pinned actual ELF. The candidate's one-off aggregator omitted
one old inline-dispatch control and asserted 100 after 99 passing tests. A new
receipt runs that one missing control; earlier results and the postprocess failure
remain. No source/assertion changed to obtain these passes.
