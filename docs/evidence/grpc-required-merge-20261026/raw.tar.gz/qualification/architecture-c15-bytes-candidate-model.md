# Bounded stream encode scratch — candidate model

Prepared only. Baseline repository `ee5b345b`, runtime `933bf877`. No candidate
production patch or build has run. The independent callsite probe is closed:
32 cases, 80 encoded and decoded messages, all passing. Its actual four-message
1 MiB plaintext site requests 4 × 1,048,580 = 4,194,320 bytes, for both zero and
noise input, with zero retained scratch capacity after every message.

## One allocation with a restricted append interface

Add a default `CodecMessage::encode_payload_bufmut<B: bytes::BufMut>` method that
calls the existing `encode_payload`. Its buffer/error contract permits partial
output on error; the framework discards the private scratch. The existing method
and its behavior remain unchanged. The Prost wrapper overrides the new method
and calls Prost's generic encode directly. Generated pbrs uses the default
ordinary WireOut/BufMut path.

Use a canonical Vec as plaintext scratch. Safe generic BufMut append operations
cannot replace, split or retain its allocation. The old custom `write_contiguous`
callback receives a separate temporary BytesMut through the existing WireOut
bridge; it can retain/replace that temporary but never gets the canonical Vec.
That fallback may allocate/copy for custom contiguous encoders and needs an
explicit compatibility/cost control. No pointer-equality ownership claim,
per-message Box, raw pointer, shared origin keeper or allocation metadata cache.

## Capacity and lifetime policy

- Preserve legacy retention at capacity <= 64 KiB, outside the new aggregate
  budget. This remains at most 64 KiB per live stream, not a finite process-wide
  bound on every small scratch allocation.
- Above 64 KiB retain only full canonical Vec capacity <= 4 MiB, under a new
  separate 16 MiB process-wide ENCODE allowance. Existing DECODE limits remain
  4 MiB/buffer and 16 MiB/process and retain their current meaning.
- Across these two large-buffer allowances, up to 32 MiB can be admitted, plus
  legacy small encode storage, active unadmitted work, messages and wire output.
  None is an RSS/process-memory cap.
- The encode lease applies between messages. At the beginning of active encoding,
  release the previous idle lease before reserve/write. Active scratch is owned
  by the current call and existing per-message limits; it is not idle cache.
- After successful encode AND compression, inspect Vec.capacity. Small capacity
  clears and retains under the legacy policy. Large eligible capacity requires a
  fresh atomic reservation for the full actual capacity. Oversize/budget miss
  discards storage and never fails the RPC or changes wire bytes.
- Store `bytes: Vec<u8>` then `lease: Option<RetainedEncodeLease>` in that order.
  Use NonZeroUsize in the non-Clone lease if that keeps it one word naturally.
  On final Drop, bytes are destroyed before the reservation. Confirm actual
  layout; correctness takes priority over retaining the old 32-byte size.

## Panic/error guard

`with_payload` takes the scratch value out of `self` into a local active owner,
leaving self empty. The active value releases its old idle lease, then reserves,
serializes through append-only BufMut and calls compression. On panic, unwinding
drops the active owner (buffer before lease); a caller that catches the panic
cannot find an unbudgeted retained Vec in the original scratch. On Result::Err,
drop/discard the active owner and leave self empty. Only after successful
compression and admission move the retained value back into self.

OutBatch must also discard old scratch on append errors that occur before
with_payload (e.g. encode limit), without dropping earlier complete wire frames.
Cancellation/EOF/transport termination must drop owned scratch before the completed
future can remain retained; test actual pump/drain terminal owners as well as
ordinary scratch Drop. No detached cleanup task or early permit release.

## Deterministic controls without resetting global counters

Use local instances of the same reservation helper for exhaustion, exact capacity,
oversize, overflow and balanced release tests. Do not reset or saturate the global
budget in concurrent default-suite tests. The separate single-selected-test probe
ELF can exercise actual global reservations and retained ownership in a fresh
process, including two or more scratch values sharing its finite capacity.

Candidate source tests: zero/small/64 KiB boundary/large capacities; same-size
reuse, growth and large-to-small; encoded_len underestimation; Result errors and
caught encode/compress callback panic; custom temporary replacement/split/nonempty
and empty aliases; budget rejection fallback; Drop; preserved prior batch prefix
and following status. Independent gzip decode/CRC/ISIZE and Prost equality remain.

Before adoption compare actual tagged plaintext allocation sites against this
baseline, then equal-handler allocation AND feature-off CPU/timing cases for
zero/noise, cold 1-message and warm 4-message streams, both native endpoints and
fresh tonic controls. Preserve all regressions. Keep the compressed-output
reservation heuristic unchanged in this candidate; its measured excess is a
separate experiment.
