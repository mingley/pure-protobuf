//! Ownership and budget controls for stream-owned plaintext scratch.
#![allow(clippy::expect_used, clippy::panic, reason = "bounded test assertions")]

use super::*;
use crate::transport::{ClientBuilder as _, SendRequest as _};
use crate::workspace::{RetainedEncodeLease, retained_encode_counts};
use std::cell::RefCell;
use std::future::{Future, poll_fn};
use std::pin::Pin;
use std::task::Poll;

struct Fill(usize);
impl CodecMessage for Fill {
    fn encoded_len(&self) -> usize {
        self.0
    }
    fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
        let block = [0x42; 4096];
        let mut left = self.0;
        while left != 0 {
            let take = left.min(block.len());
            out.put_slice(block.get(..take).expect("block range"));
            left -= take;
        }
        Ok(())
    }
    fn decode_payload(_: Bytes) -> Result<Self, Status> {
        Ok(Self(0))
    }
    fn empty() -> Self {
        Self(0)
    }
}

#[test]
fn errors_and_caught_panics_leave_original_scratch_empty() {
    let mut scratch = EncodeScratch::new();
    scratch
        .with_payload(&Fill(1024), 1024, |_| Ok(()))
        .expect("warm small");
    assert_eq!(scratch.bytes.capacity(), 1024);
    let error = scratch
        .with_payload(&Fill(128 * 1024), 128 * 1024, |_| -> Result<(), Status> {
            Err(Status::internal("compressor failed"))
        })
        .expect_err("error");
    assert_eq!(error.code(), crate::Code::Internal);
    assert!(scratch.has_no_buffer());
    let panic = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
        scratch.with_payload(&Fill(128 * 1024), 128 * 1024, |_| -> Result<(), Status> {
            panic!("compressor panicked")
        })
    }));
    assert!(panic.is_err());
    assert!(scratch.has_no_buffer());

    struct Partial;
    impl CodecMessage for Partial {
        fn encoded_len(&self) -> usize {
            128 * 1024
        }
        fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.put_slice(b"partial");
            Err(Status::aborted("encoder failed"))
        }
        fn decode_payload(_: Bytes) -> Result<Self, Status> {
            Ok(Self)
        }
        fn empty() -> Self {
            Self
        }
    }
    assert!(
        scratch
            .with_payload(&Partial, Partial.encoded_len(), |_| Ok(()))
            .is_err()
    );
    assert!(scratch.has_no_buffer());

    struct Panic;
    impl CodecMessage for Panic {
        fn encoded_len(&self) -> usize {
            128 * 1024
        }
        fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.put_slice(b"partial");
            panic!("encoder panicked")
        }
        fn decode_payload(_: Bytes) -> Result<Self, Status> {
            Ok(Self)
        }
        fn empty() -> Self {
            Self
        }
    }
    assert!(
        std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
            scratch.with_payload(&Panic, Panic.encoded_len(), |_| Ok(()))
        }))
        .is_err()
    );
    assert!(scratch.has_no_buffer());
}

#[test]
fn canonical_capacity_handles_growth_and_retention_policy_boundaries() {
    let mut scratch = EncodeScratch::new();
    for size in [
        0,
        1024,
        65536,
        65537,
        1024,
        4 * 1024 * 1024,
        4 * 1024 * 1024 + 1,
    ] {
        // An underestimated hint must not hide actual backing capacity.
        scratch
            .with_payload(&Fill(size), 1, |body| {
                assert_eq!(body.len(), size);
                assert!(body.iter().all(|byte| *byte == 0x42));
                Ok(())
            })
            .expect("encode");
        let capacity = scratch.bytes.capacity();
        if capacity <= MAX_RETAINED_SCRATCH_BYTES {
            assert!(scratch.lease.is_none());
        } else {
            assert!(capacity <= 4 * 1024 * 1024);
            assert_eq!(
                scratch.lease.as_ref().map(RetainedEncodeLease::capacity),
                Some(capacity)
            );
        }
        if size > 4 * 1024 * 1024 {
            assert!(scratch.has_no_buffer());
        }
    }
}

#[test]
fn custom_contiguous_aliases_belong_to_temporary_not_canonical_scratch() {
    struct Custom<'a> {
        retained: &'a RefCell<Vec<Bytes>>,
        mode: u8,
    }
    impl CodecMessage for Custom<'_> {
        fn encoded_len(&self) -> usize {
            70 * 1024
        }
        fn encode_payload<W: WireOut>(&self, out: &mut W) -> Result<(), Status> {
            out.write_contiguous(|buf| {
                // This is the existing generic WireOut temporary, never the
                // canonical Vec. Replacing and splitting it may pin much more
                // application storage than the visible output window.
                assert!(buf.is_empty());
                *buf = BytesMut::with_capacity(2 * self.encoded_len());
                buf.resize(self.encoded_len(), 0x5a);
                match self.mode {
                    0 => {
                        buf.extend_from_slice(b"retained tail");
                        let tail = buf.split_off(self.encoded_len());
                        self.retained.borrow_mut().push(tail.freeze());
                    }
                    1 => self.retained.borrow_mut().push(buf.split_to(0).freeze()),
                    2 => {
                        let replacement = BytesMut::from(buf.as_ref());
                        self.retained
                            .borrow_mut()
                            .push(std::mem::replace(buf, replacement).freeze());
                    }
                    _ => {}
                }
                Ok(())
            })
        }
        fn decode_payload(_: Bytes) -> Result<Self, Status> {
            panic!("encode-only fixture")
        }
        fn empty() -> Self {
            panic!("encode-only fixture")
        }
    }
    for mode in 0..3 {
        let aliases = RefCell::new(Vec::new());
        let message = Custom {
            retained: &aliases,
            mode,
        };
        let mut scratch = EncodeScratch::new();
        for _ in 0..2 {
            scratch
                .with_payload(&message, message.encoded_len(), |body| {
                    assert_eq!(body.len(), message.encoded_len());
                    assert!(body.iter().all(|byte| *byte == 0x5a));
                    Ok(())
                })
                .expect("isolated temporary bridge");
            if let Some(lease) = &scratch.lease {
                assert_eq!(lease.capacity(), scratch.bytes.capacity());
                assert_eq!(lease.capacity(), message.encoded_len());
            } else {
                assert!(scratch.has_no_buffer());
            }
        }
        drop(scratch);
        assert_eq!(aliases.borrow().len(), 2);
        if mode == 0 {
            assert!(
                aliases
                    .borrow()
                    .iter()
                    .all(|alias| alias.as_ref() == b"retained tail")
            );
        }
    }
}

fn assert_no_large_scratch() {
    let counts = retained_encode_counts();
    assert_eq!(counts.retained_capacity, 0);
    assert_eq!(counts.retained_buffers, 0);
    assert_eq!(counts.acquired, counts.released);
}

async fn pending_once<F: Future>(mut future: Pin<&mut F>) {
    poll_fn(|cx| {
        assert!(future.as_mut().poll(cx).is_pending());
        Poll::Ready(())
    })
    .await;
}

async fn completed_kept_alive<F: Future>(mut future: Pin<&mut F>) -> F::Output {
    tokio::time::timeout(
        std::time::Duration::from_secs(2),
        poll_fn(|cx| future.as_mut().poll(cx)),
    )
    .await
    .expect("bounded terminal poll")
}

async fn local_send() -> (
    crate::transport::h2::SendStream,
    crate::transport::h2::ResponseFuture,
    crate::transport::h2::ClientConnection<tokio::io::DuplexStream>,
    tokio::io::DuplexStream,
) {
    // A complete compressed frame fits local credit and send buffering. Keep
    // both endpoints alive; these are cleanup controls, not wire-interop proof.
    let (io, peer) = tokio::io::duplex(65536);
    let (mut request, driver) = tokio::time::timeout(
        std::time::Duration::from_secs(2),
        crate::transport::h2::ClientBuilder::new().handshake(io),
    )
    .await
    .expect("bounded local handshake")
    .expect("h2 client");
    let (response, send) = request
        .send_request(
            http::Request::builder()
                .uri("http://localhost/encode/scratch")
                .body(())
                .expect("request"),
            false,
        )
        .expect("open stream");
    (send, response, driver, peer)
}

async fn actual_terminal_owners() {
    use crate::server::drain::{CancelFlag, drain_to_wire};
    use crate::telemetry::CallLabels;
    use crate::wire::send::{PumpEnd, pump_outbound};
    for end in [0u8, 1, 2, 3] {
        let (mut send, _response, _driver, _peer) = local_send().await;
        let (sender, stream) = crate::Streaming::channel(4);
        sender
            .send_compressed(Fill(1024 * 1024))
            .await
            .expect("message");
        let cancel = crate::rpc_cancel::RpcCancel::new();
        let signal = cancel.clone();
        let mut pump = Box::pin(pump_outbound(
            &mut send,
            stream,
            cancel,
            crate::ChannelConfig::new().wire(),
        ));
        pending_once(pump.as_mut()).await;
        assert_eq!(retained_encode_counts().retained_capacity, 1024 * 1024);
        match end {
            0 => {
                drop(sender);
                assert!(matches!(
                    completed_kept_alive(pump.as_mut()).await,
                    PumpEnd::HalfClosed
                ));
                assert_no_large_scratch(); // pump remains allocated after Ready
                drop(pump);
            }
            1 => {
                signal.signal();
                assert!(matches!(
                    completed_kept_alive(pump.as_mut()).await,
                    PumpEnd::Reset
                ));
                assert_no_large_scratch();
                drop(pump);
                drop(sender);
            }
            2 => {
                sender.fail(Status::aborted("producer failed")).await;
                match completed_kept_alive(pump.as_mut()).await {
                    PumpEnd::Failed(status) => assert_eq!(status.code(), crate::Code::Aborted),
                    _ => panic!("producer status"),
                }
                assert_no_large_scratch();
                drop(pump);
            }
            _ => {
                drop(pump);
                drop(sender);
            }
        }
        assert_no_large_scratch();
    }
    for end in [0u8, 1, 2] {
        let (mut send, _response, _driver, _peer) = local_send().await;
        let (sender, mut stream) = crate::Streaming::channel(4);
        sender
            .send_compressed(Fill(1024 * 1024))
            .await
            .expect("message");
        let mut wire = crate::ServerConfig::new().wire();
        wire.limits = wire.limits.with_max_encoding(1024 * 1024);
        let budget = crate::ByteBudgetTracker::unlimited();
        let call = CancelFlag::new();
        let labels = CallLabels::UNLABELED_SERVER;
        let mut drain = Box::pin(drain_to_wire(
            &mut stream,
            &mut send,
            wire,
            Some(true),
            true,
            true,
            false,
            #[cfg(feature = "zstd")]
            false,
            &budget,
            None,
            &labels,
            None,
            None,
            &call,
            false,
        ));
        pending_once(drain.as_mut()).await;
        assert_eq!(retained_encode_counts().retained_capacity, 1024 * 1024);
        match end {
            0 => {
                drop(sender);
                assert!(completed_kept_alive(drain.as_mut()).await.is_ok());
                assert_no_large_scratch(); // drain remains allocated after Ready
                drop(drain);
            }
            1 => {
                sender
                    .send_compressed(Fill(2 * 1024 * 1024))
                    .await
                    .expect("queued oversize for drain cap");
                assert!(completed_kept_alive(drain.as_mut()).await.is_err());
                assert_no_large_scratch();
                drop(drain);
                drop(sender);
            }
            _ => {
                drop(drain);
                drop(sender);
            }
        }
        assert_no_large_scratch();
        assert_eq!(budget.allocated(), 0);
        assert_eq!(budget.active_byte_permit_tokens(), 0);
    }
}

#[test]
fn actual_encode_budget_and_terminal_cleanup_use_a_fresh_process() {
    const CHILD: &str = "PBRS_TEST_ENCODE_SCRATCH_CHILD";
    if std::env::var_os(CHILD).is_none() {
        let module = module_path!().split_once("::").expect("crate module").1;
        let name =
            format!("{module}::actual_encode_budget_and_terminal_cleanup_use_a_fresh_process");
        let output = std::process::Command::new(std::env::current_exe().expect("test executable"))
            .arg("--exact")
            .arg(name)
            .arg("--nocapture")
            .arg("--test-threads=1")
            .env(CHILD, "1")
            .output()
            .expect("isolated budget child");
        assert!(
            output.status.success(),
            "child failed:\n{}\n{}",
            String::from_utf8_lossy(&output.stdout),
            String::from_utf8_lossy(&output.stderr)
        );
        assert!(
            String::from_utf8_lossy(&output.stderr).contains("C15_ENCODE_RESOURCE"),
            "the child must actually execute its filtered resource control"
        );
        eprint!("{}", String::from_utf8_lossy(&output.stderr));
        return;
    }
    assert_no_large_scratch();
    // Exercise the actual RAII wrapper, not only its counter helper. Rejected
    // leases must never release a charge that was not successfully acquired.
    assert!(RetainedEncodeLease::try_acquire(4 * 1024 * 1024 + 1).is_none());
    assert_no_large_scratch();
    let full: Vec<_> = (0..4)
        .map(|_| RetainedEncodeLease::try_acquire(4 * 1024 * 1024).expect("quarter budget"))
        .collect();
    assert_eq!(retained_encode_counts().retained_capacity, 16 * 1024 * 1024);
    assert!(RetainedEncodeLease::try_acquire(65537).is_none());
    assert_eq!(retained_encode_counts().retained_capacity, 16 * 1024 * 1024);
    let mut scratch = EncodeScratch::new();
    scratch
        .with_payload(&Fill(128 * 1024), 128 * 1024, |_| Ok(()))
        .expect("budget miss never fails encode");
    assert!(scratch.has_no_buffer());
    drop(full);
    assert_no_large_scratch();
    scratch
        .with_payload(&Fill(128 * 1024), 128 * 1024, |_| Ok(()))
        .expect("reuse available capacity");
    assert_eq!(retained_encode_counts().retained_capacity, 128 * 1024);
    assert_eq!(scratch.bytes.capacity(), 128 * 1024);
    scratch
        .with_payload(&Fill(128 * 1024), 128 * 1024, |_| {
            assert_eq!(
                retained_encode_counts().retained_capacity,
                0,
                "active work is not idle cache"
            );
            Ok(())
        })
        .expect("warm reuse");
    assert_eq!(retained_encode_counts().retained_capacity, 128 * 1024);
    drop(scratch);
    assert_no_large_scratch();
    let runtime = tokio::runtime::Builder::new_current_thread()
        .enable_all()
        .build()
        .expect("runtime");
    runtime.block_on(actual_terminal_owners());
    assert_no_large_scratch();
    let counts = retained_encode_counts();
    eprintln!(
        "C15_ENCODE_RESOURCE acquired={} released={} retained_capacity={} retained_buffers={} scratch_size={} batch_size={}",
        counts.acquired,
        counts.released,
        counts.retained_capacity,
        counts.retained_buffers,
        std::mem::size_of::<EncodeScratch>(),
        std::mem::size_of::<crate::wire::out_batch::OutBatch>()
    );
}
