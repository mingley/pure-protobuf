# Payload-pattern benchmark checks

Prepared source: `ee5b345b` plus the three V3 benchmark files. Root runtime files
are unchanged. This source has not been committed by this lane.

| Check | Actual result |
|---|---:|
| Selected payload/CLI unit tests | 5 passed, 0 failed |
| Positive endpoint captures | 24 passed; 48 successful RPCs |
| Deliberate invalid captures | 8 rejected as expected |
| Total endpoint captures | 32 |

The positive controls cover all five Prost call shapes and all four native/tonic
client/server pairings. Bidi includes one and four messages per RPC. Each capture
verifies exact READY/client metadata. Negative controls detect a zero response
substituted for noise and an upload request generated with the wrong seed.

The corpus is deterministic and prepared before load/READY. Noise supports Prost
TestService; unsupported pbrs and BenchmarkService modes fail early. The arrival
seed remains separate. No global fixture reset occurs in parallel unit tests.

These are 1 KiB gzip **debug correctness checks**, not performance evidence. New
zero/noise release/allocation comparisons require an identical benchmark subtree
on both source builds. Client process CPU includes corpus setup; server setup
precedes READY. Content validation contributes equal work on both transports.

V1/V2 preparations remain as history; V3 alone was compiled and executed. The
compiler and every owned peer process are closed. The serial compiler window
has been explicitly released to the kernel lane. No Root edits, commits or pushes
were performed.
