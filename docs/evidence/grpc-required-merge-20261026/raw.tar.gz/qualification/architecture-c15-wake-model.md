# FU-only wake forwarding: bounded experiment

State is ACTIVE | NOTIFIED | CLOSED. One connection owner is created lazily after
its first steady-path RPC is admitted; an empty connection allocates no proxy.
The parent slot is Mutex<Option<Waker>>. Real Waker clone, replaced/taken Waker
Drop, and wake execute outside that mutex. The mutex only compares will_wake
(pointer/vtable identity), swaps or takes owned values. No unsafe or thread-local
state and no equivalence inference between handler and driver wakers.

The FU gets the proxy Waker; protocol/IO/drain retain the real parent Waker.

1. Enter the steady poll closure with an RAII guard: set ACTIVE, register current
   real parent (clone outside lock; swap and drop outside). The owner cannot be
   concurrently polled. CLOSED prevents a post-close registration.
2. Clear NOTIFIED immediately BEFORE each FU poll, even if the FU is empty.
   This acknowledges only work already published to the FU ready queue. A child
   publishes that queue entry before invoking its parent proxy; a publication
   whose proxy call is delayed may cause a redundant wake, but never lost work.
3. Retain the original top-of-poll FU priority and Pending-branch drain priority.
   After protocol Pending and drain Pending, acknowledge and recheck FU once.
4. Any wake during/after an FU poll sets NOTIFIED again. Cooperative/yield,
   self-wake, and ready-queue Inconsistent notifications must survive. IO wakes
   cannot be mistaken for FU acknowledgement because they bypass the proxy.
5. Guard exit (Ready/Pending/unwind) clears ACTIVE. If NOTIFIED remains, take the
   real parent under the mutex and wake it after unlocking. A concurrent inactive
   wake either takes that registration itself or is covered by the claim already
   in flight. Keep NOTIFIED until acknowledgement in a later active poll.
6. Inactive wakes set NOTIFIED and take/wake the registered real parent outside
   the lock. After the first take the slot may be empty; the pending notification
   already schedules the parent, whose next poll registers before acknowledging.
7. Drop/transition out closes the owner, sets CLOSED and takes/drops the parent
   outside the lock. Late wakes after CLOSED make no new callback claims. A claim
   linearized before close may finish afterward. Retained stale FU child Wakers
   must not retain the completed root Task through this slot.

No broad correctness or performance claim follows from preparation. The extra
ready-set slice preserves C14's fairness limitation; noncooperative application
polls are not preempted. One extra Arc and parent-slot lock can hurt cold calls.

## Causal phases, unchanged peer and final semantic assertions

Prepared test-only fixture: architecture-c15-wake-fixture.rs, installed as
pbrs-grpc/tests/connection_wake.rs in the isolated ee5b345b source checkout.
All source production files remain unchanged; no compiler has run in this lane.

The exact peer DATA write, read gate, single manually counted parent poll,
unwoken parked sibling, valid response status/body and same-connection recovery
controls precede detecting assertions. Original runtime should show handler0 /
parent-wakes1 (fail progress); isolated old recheck should show handler1 / wakes2
(fail redundant notification); proposed FU-only deferral should handler1 / <=1.
These are one controlled scenario, not universal same-turn or wake-count claims.

Additional deterministic controls must cover pending-before-ack vs wake-during-
poll vs wake-after-ack, ACTIVE exit races, inactive registration/claim, parent
replacement, close and stale child Wakers, cooperative/self-waking Pending and
reentrant clone/drop/wake callbacks outside the parent slot mutex. The actual
wire fixture and existing cancellation/reset/drain/admission/lifecycle controls
remain necessary. Physical feature-off shipping CPU and cold connection cost
are required before adoption; two earlier source variants did not prove speed.
