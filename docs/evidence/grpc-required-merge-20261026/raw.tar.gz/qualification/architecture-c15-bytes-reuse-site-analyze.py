from pathlib import Path
import re,ast,json,hashlib
q=Path('/workspace/pure-protobuf/work/qualification')
base=json.loads((q/'architecture-c15-bytes-probe-analysis.json').read_text())
raw=(q/'architecture-c15-bytes-reuse-site-test-v1.stderr').read_text();rows=[];custom=[]
pattern=re.compile(r'^C15_ENCODE_SITE size=(\d+) encoded_len=(\d+) entropy=(true|false) messages=(\d+) flush_each=(true|false) scratch_caps=(\[.*?\]) output_caps=(\[.*?\]) wire_bytes=(\d+) sites=(\[.*\])$')
cp=re.compile(r'^C15_ENCODE_CUSTOM size=(\d+) encoded_len=(\d+) messages=(\d+) wire_bytes=(\d+) sites=(\[.*\])$')
for line in raw.splitlines():
 if line.startswith('C15_ENCODE_SITE'):
  m=pattern.fullmatch(line);assert m,line
  size,encoded,entropy,msgs,flush,scratch,out,wire,sites=m.groups();v=ast.literal_eval(sites)
  rows.append({'body_bytes':int(size),'protobuf_bytes':int(encoded),'entropy':'deterministic_noise'if entropy=='true'else'zeros','messages':int(msgs),'flush_each':flush=='true','scratch_capacity_after_each':ast.literal_eval(scratch),'output_capacity_after_each':ast.literal_eval(out),'wire_bytes':int(wire),'sites':{name:{'allocation_and_reallocation_requests':r[0],'requested_bytes':r[1]}for name,r in zip(['untagged_not_counted','plaintext_scratch_reserve','initial_compressed_output_reserve','compressor_call_including_output_growth','serialization_candidate_only'],v)}})
 elif line.startswith('C15_ENCODE_CUSTOM'):
  m=cp.fullmatch(line);assert m,line
  size,encoded,msgs,wire,sites=m.groups();v=ast.literal_eval(sites);custom.append({'body_bytes':int(size),'protobuf_bytes':int(encoded),'messages':int(msgs),'wire_bytes':int(wire),'sites':{name:{'allocation_and_reallocation_requests':r[0],'requested_bytes':r[1]}for name,r in zip(['untagged_not_counted','plaintext_scratch_reserve','initial_compressed_output_reserve','compressor_call_including_output_growth','serialization_candidate_only'],v)}})
assert len(rows)==32 and len(custom)==2
keys=('body_bytes','protobuf_bytes','entropy','messages','flush_each')
lookup={tuple(r[k]for k in keys):r for r in base['rows']};comparison=[]
for after in rows:
 before=lookup[tuple(after[k]for k in keys)]
 assert before['wire_bytes']==after['wire_bytes']
 assert before['output_capacity_after_each']==after['output_capacity_after_each']
 for site in ['initial_compressed_output_reserve','compressor_call_including_output_growth']:
  assert before['sites'][site]==after['sites'][site]
 assert after['sites']['serialization_candidate_only']=={'allocation_and_reallocation_requests':0,'requested_bytes':0}
 a=before['sites']['plaintext_scratch_reserve'];b=after['sites']['plaintext_scratch_reserve'];comparison.append({**{k:after[k]for k in keys},'before':a,'after':b,'saved_requested_bytes':a['requested_bytes']-b['requested_bytes'],'saved_requests':a['allocation_and_reallocation_requests']-b['allocation_and_reallocation_requests']})
 if after['messages']==4 and after['body_bytes']>=65536:
  assert b['allocation_and_reallocation_requests']==1
  assert a['allocation_and_reallocation_requests']==4
  assert a['requested_bytes']==4*b['requested_bytes']
for x in custom:assert x['sites']['serialization_candidate_only']['allocation_and_reallocation_requests']==8

def ref(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
r={'schema':'pbrs.c15-bounded-encode-site-comparison.v1','qualified':False,'production_adopted':False,'case_count':34,'builtin_case_count':32,'builtin_encoded_and_decoded_messages':80,'custom_case_count':2,'custom_encoded_and_decoded_messages':8,'baseline_analysis':ref(q/'architecture-c15-bytes-probe-analysis.json'),'candidate_actual_run':ref(q/'architecture-c15-bytes-reuse-site-test-v1.json'),'candidate_held_source_elf':ref(q/'architecture-c15-bytes-reuse-site-held.json'),'candidate_production_run':ref(q/'architecture-c15-bytes-reuse-focused-results.json'),'candidate_production_source_restored':ref(q/'architecture-c15-bytes-reuse-closed.json'),'baseline_matched_comparisons':comparison,'candidate_rows':rows,'legacy_custom_rows':custom,'conclusions':['At actual plaintext reservation site, four1MiB built-in Prost messages request4,194,320→1,048,580bytes:3,145,740fewerbytes/3fewerrequests/75%less, underbothentropy andflushpolicies.','All32builtinProstcaseshavezero allocation/reallocationrequests in newlytagged serialization scope; the saving didnotshift intoa temporary atthatcall.','All32builtinProstwire sizes, outputcapacities, initialoutputreservation andcompressor-call requests matchbaselineexactly.','1KiB builtinProst plaintextrequests remain1,027bytes/oneallocation; zero andsingle-message caseskeeptheir source-sitecounts.','Existing custom contiguous codec bridge incurs8 serialize-site requests/4,194,352bytes forfour1MiBmessages (4,140bytes forfour1KiB). This compatibility cost repeatspermessage; overridingthe additiveBufMutmethod avoidsit forsuchencoders.'],'limits':['Privatecallsite/test-profile counters are not whole-endpoint bytes, shippingCPU, latency, throughput or a broadtonic/prostcomparison.','BuiltinProstsource-site win depends onadmission; exhausted16MiBnewencodebudget declinesretention withoutfailingcalls. Small≤64KiBlegacyretention remainsoutsideencodeledger; decode4/16MiBpolicy unchanged.','Generic oldcustomcontiguousimplementation has a real newtemporary/copy cost. No blanketcodecperformanceclaim.','Directfour-messageappend noise cases stresshelper beyondproduction32KiBOutBatchflushthreshold; do notsubstitutehelperoutputcapacity foractualtransportgrouping.','Sourcev1uncompiled eagerthen_someleasebug wascaught andfixedbeforebuild; buildv1/v2fixturemissingtraitfailures preserved; v3candidatebuild+738unitchecks+privatecounterbuild/runpass.']}
with(q/'architecture-c15-bytes-reuse-site-analysis.json').open('x')as f:json.dump(r,f,indent=2);f.write('\n')
print(ref(q/'architecture-c15-bytes-reuse-site-analysis.json'))
