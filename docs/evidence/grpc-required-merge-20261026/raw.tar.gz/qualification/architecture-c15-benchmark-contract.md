# Payload patterns for matched transport comparisons

Prepared benchmark change only; no compiler or endpoint result is supplied by
this note. Baseline and candidate must contain the identical benchmark subtree.

`load` and `load-server` accept `--payload-pattern zero|noise` and a separate
`--payload-seed` (default 20261026). The arrival-schedule `--seed` is unchanged.
Noise requires `--codec=prost`, explicit `--req-bytes` and `--resp-bytes`, and
TestService. All five shapes support both native and tonic transport. Pbrs-codec
and BenchmarkService noise are explicitly rejected rather than mislabeled.

Noise uses a pinned SplitMix64 byte stream with independent request/response
salts. The process constructs immutable fixtures before serving or starting the
load generator. Requests/responses clone those same fixtures; no message calls a
PRNG. The request fixture is exact-size; response requests cannot exceed the
prepared response bound. Zero mode retains zero-filled allocations and existing
length checks. The new helper/validation branches mean this is not a claim of
bit-identical execution to the historical benchmark binary.

The new adapter must pass the same pattern, payload seed and size bounds to both
processes and verify those values in READY, not merely extract the port. READY and metrics also record `payload_request_bytes` and
`payload_response_bytes`; the adapter checks both declared bounds against the
cell. Metrics record pattern, payload seed and validation mode. Server-side request bodies
and client-side response bodies are compared in full in noise mode. The upload
response has no payload and keeps its exact aggregate-size check. A mismatched
body is an RPC error. Full comparisons contribute CPU on both transports.

Client process-lifetime CPU includes the one-time fixture construction. The load
generator clock starts later. Server construction occurs before READY, outside
the before-client/terminal-client CPU window. Native/tonic CPU windows and process
lifetime accounting remain separate. Corpus capacity is at most 64 MiB per
direction (128 MiB/process), separate from production transport cache limits.

`--stream-msgs=1` versus `4` measures messages per stream. It does not by itself
measure a cold process or cold connection. Cold-process RPC-count-one controls
must remain separate from repeated-RPC controls. Preserve all patterns, endpoint
controls, allocation requests, CPU/timing ranges and higher-cost results.
