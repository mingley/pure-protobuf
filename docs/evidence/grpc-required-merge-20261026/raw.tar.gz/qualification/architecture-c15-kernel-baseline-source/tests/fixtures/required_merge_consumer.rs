#![allow(
    clippy::unwrap_used,
    clippy::expect_used,
    reason = "bounded generated-code regression controls"
)]
mod generated {
    include!("required_merge.rs");
}

#[cfg(test)]
mod tests {
    use super::generated::{Child, Envelope, Parent};
    use pbrs::{Parse, Serialize};

    fn validate_parent(bytes: &[u8]) -> bool {
        let mut pos = 0;
        let result = Parent::validate_inner(&pbrs::rt::Wire::from_slice(bytes), &mut pos, 0);
        if result.is_ok() {
            assert_eq!(pos, bytes.len());
        }
        result.is_ok()
    }

    fn stable_parent(bytes: &[u8]) -> Parent {
        let value = Parent::parse(bytes).expect("valid final initialized tree");
        let encoded = value.serialize().unwrap();
        assert_eq!(
            Parent::parse(&encoded).unwrap().serialize().unwrap(),
            encoded
        );
        value
    }

    #[test]
    fn split_required_fields_merge_in_one_singular_child() {
        let bytes = [0x0a, 2, 8, 1, 0x0a, 2, 16, 2];
        let value = stable_parent(&bytes);
        assert_eq!((value.child().a(), value.child().b()), (1, 2));
    }

    #[test]
    fn validator_accepts_split_required_fields_after_merge() {
        assert!(validate_parent(&[0x0a, 2, 8, 1, 0x0a, 2, 16, 2]));
    }

    #[test]
    fn split_merge_survives_a_lazy_enclosing_message() {
        let bytes = [0x0a, 8, 0x0a, 2, 8, 1, 0x0a, 2, 16, 2];
        let value = Envelope::parse(&bytes).expect("valid nested final tree");
        assert_eq!(
            (value.inner().child().a(), value.inner().child().b()),
            (1, 2)
        );
    }

    #[test]
    fn split_merge_across_duplicate_ancestors_uses_the_final_tree() {
        let bytes = [0x0a, 4, 0x0a, 2, 8, 1, 0x0a, 4, 0x0a, 2, 16, 2];
        let value = Envelope::parse(&bytes).expect("duplicate ancestors merge");
        assert_eq!(
            (value.inner().child().a(), value.inner().child().b()),
            (1, 2)
        );
    }

    #[test]
    fn same_oneof_message_case_merges_required_fields() {
        let value = stable_parent(&[0x1a, 2, 8, 1, 0x1a, 2, 16, 2]);
        assert_eq!((value.selected().a(), value.selected().b()), (1, 2));
    }

    #[test]
    fn discarded_partial_oneof_message_is_not_a_live_required_failure() {
        let bytes = [0x1a, 2, 8, 1, 0x20, 7];
        assert_eq!(stable_parent(&bytes).other(), 7);
        assert!(validate_parent(&bytes));
    }

    #[test]
    fn switching_oneof_case_does_not_merge_discarded_required_fields() {
        let bytes = [0x1a, 2, 8, 1, 0x20, 7, 0x1a, 2, 16, 2];
        assert!(Parent::parse(&bytes).is_err());
        assert!(!validate_parent(&bytes));
    }

    #[test]
    fn separate_repeated_elements_cannot_complete_each_others_required_fields() {
        let bytes = [0x12, 2, 8, 1, 0x12, 2, 16, 2];
        assert!(Parent::parse(&bytes).is_err());
        assert!(!validate_parent(&bytes));
    }

    #[test]
    fn present_zero_fields_count_as_initialized_but_missing_fields_do_not() {
        assert!(Child::parse(&[8, 0, 16, 0]).is_ok());
        assert!(Child::parse(&[8, 0]).is_err());
        assert!(Parent::parse(&[0x0a, 2, 8, 0]).is_err());
        assert!(!validate_parent(&[0x0a, 2, 8, 0]));
        assert!(Parent::parse(&[]).is_ok());
    }

    #[test]
    fn initialized_elements_and_oneof_cases_keep_their_values() {
        let value = stable_parent(&[0x12, 4, 8, 1, 16, 2, 0x1a, 4, 8, 3, 16, 4]);
        assert_eq!(value.children().len(), 1);
        assert_eq!(
            (value.children().get(0).unwrap().a(), value.selected().b()),
            (1, 4)
        );
    }

    #[test]
    fn discarded_message_wire_must_still_be_structurally_valid() {
        let bytes = [0x1a, 2, 8, 0x80, 0x20, 7];
        assert!(Parent::parse(&bytes).is_err());
        assert!(!validate_parent(&bytes));
    }
}
