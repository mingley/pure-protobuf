#![cfg(feature = "codegen")]
#![allow(
    clippy::unwrap_used,
    clippy::expect_used,
    reason = "generated-code regression consumer"
)]

use std::path::{Path, PathBuf};
use std::process::Command;

fn field(
    name: &str,
    number: u64,
    label: u64,
    kind: u64,
    target: Option<&str>,
    oneof: bool,
) -> Vec<u8> {
    let mut out = Vec::new();
    pbrs::rt::encode_len_field(&mut out, 1, name.as_bytes());
    for (tag, value) in [(3, number), (4, label), (5, kind)] {
        pbrs::rt::encode_tag(&mut out, tag, pbrs::rt::WIRE_VARINT);
        pbrs::rt::encode_varint(&mut out, value);
    }
    if let Some(target) = target {
        pbrs::rt::encode_len_field(&mut out, 6, target.as_bytes());
    }
    if oneof {
        pbrs::rt::encode_tag(&mut out, 9, pbrs::rt::WIRE_VARINT);
        pbrs::rt::encode_varint(&mut out, 0);
    }
    out
}

fn descriptor() -> Vec<u8> {
    let mut child = Vec::new();
    pbrs::rt::encode_len_field(&mut child, 1, b"Child");
    for (name, n) in [("a", 1), ("b", 2)] {
        pbrs::rt::encode_len_field(&mut child, 2, &field(name, n, 2, 5, None, false));
    }
    let mut parent = Vec::new();
    pbrs::rt::encode_len_field(&mut parent, 1, b"Parent");
    for (name, n, label, kind, target, oneof) in [
        ("child", 1, 1, 11, Some(".required_merge.Child"), false),
        ("children", 2, 3, 11, Some(".required_merge.Child"), false),
        ("selected", 3, 1, 11, Some(".required_merge.Child"), true),
        ("other", 4, 1, 5, None, true),
    ] {
        pbrs::rt::encode_len_field(&mut parent, 2, &field(name, n, label, kind, target, oneof));
    }
    let mut oneof = Vec::new();
    pbrs::rt::encode_len_field(&mut oneof, 1, b"choice");
    pbrs::rt::encode_len_field(&mut parent, 8, &oneof);
    let mut envelope = Vec::new();
    pbrs::rt::encode_len_field(&mut envelope, 1, b"Envelope");
    pbrs::rt::encode_len_field(
        &mut envelope,
        2,
        &field("inner", 1, 1, 11, Some(".required_merge.Parent"), false),
    );
    let mut file = Vec::new();
    pbrs::rt::encode_len_field(&mut file, 1, b"required_merge.proto");
    pbrs::rt::encode_len_field(&mut file, 2, b"required_merge");
    for message in [child, parent, envelope] {
        pbrs::rt::encode_len_field(&mut file, 4, &message);
    }
    pbrs::rt::encode_len_field(&mut file, 12, b"proto2");
    let mut out = Vec::new();
    pbrs::rt::encode_len_field(&mut out, 1, &file);
    out
}

fn run_logged(command: &mut Command, root: &Path, label: &str) -> std::process::Output {
    let output = command.output().unwrap();
    std::fs::write(root.join(format!("{label}.stdout")), &output.stdout).unwrap();
    std::fs::write(root.join(format!("{label}.stderr")), &output.stderr).unwrap();
    output
}

#[test]
fn generated_required_fields_validate_after_singular_merge() {
    let repo = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let consumer = std::env::var_os("PBRS_REQUIRED_MERGE_CONSUMER_DIR").map_or_else(
        || {
            repo.join("target")
                .join(format!("required-merge-{}", std::process::id()))
        },
        PathBuf::from,
    );
    std::fs::create_dir_all(consumer.join("src")).unwrap();
    let descriptor = descriptor();
    std::fs::write(consumer.join("schema.fds"), &descriptor).unwrap();
    let generated = pbrs::codegen::generate_from_file_descriptor_set(
        &descriptor,
        &["required_merge.proto".into()],
    )
    .unwrap();
    let (_, source) = generated
        .into_iter()
        .find(|(name, _)| name == "required_merge.rs")
        .unwrap();
    std::fs::write(consumer.join("src/required_merge.rs"), source).unwrap();
    std::fs::write(
        consumer.join("src/lib.rs"),
        include_str!("fixtures/required_merge_consumer.rs"),
    )
    .unwrap();
    std::fs::write(consumer.join("Cargo.toml"), format!("[package]\nname=\"required-merge-consumer\"\nversion=\"0.0.0\"\nedition=\"2024\"\n[workspace]\n[dependencies]\npbrs={{path={:?}}}\n", repo.to_str().unwrap())).unwrap();
    std::fs::copy(
        repo.join("Cargo.lock"),
        consumer.join("provider.Cargo.lock"),
    )
    .unwrap();
    std::fs::copy(repo.join("Cargo.lock"), consumer.join("Cargo.lock")).unwrap();
    let mut metadata = Command::new("cargo");
    metadata
        .args(["metadata", "--offline", "--format-version=1"])
        .current_dir(&consumer);
    assert!(
        run_logged(&mut metadata, &consumer, "prepare-lock")
            .status
            .success(),
        "explicit offline child lock preparation"
    );
    let accepted = std::fs::read(consumer.join("Cargo.lock")).unwrap();
    std::fs::write(consumer.join("accepted.Cargo.lock"), &accepted).unwrap();
    let mut command = Command::new("cargo");
    command
        .args([
            "test",
            "--offline",
            "--locked",
            "--lib",
            "--",
            "--test-threads=1",
        ])
        .env("CARGO_BUILD_JOBS", "1")
        .current_dir(&consumer);
    let output = run_logged(&mut command, &consumer, "test");
    assert_eq!(
        std::fs::read(consumer.join("Cargo.lock")).unwrap(),
        accepted
    );
    assert!(
        output.status.success(),
        "fresh generated consumer failed:\n{}\n{}",
        String::from_utf8_lossy(&output.stdout),
        String::from_utf8_lossy(&output.stderr)
    );
}
