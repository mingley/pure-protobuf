# C15 FU-parent wake shipping observations

Source933 baseline versus experimental9235cb8. Counters and profilers off; identity1KiB, one connection/one in-flightRPC, two balanced repeats. Actual48captures/360,000successfulRPCs, zero failures/timeouts/unfinished calls;145.818seconds. This is not broad timing qualification.

The causal test reduces redundant forwarded notifications in its controlled poll, but **physical CPU improvement is not established**. Native unary-server raw CPU at10,000calls is77→103µs in repeat1 and62→62µs in repeat2. Slopes are78→154 and60→64µs/RPC. Native bidi-server raw CPU improves587→191 and215→203µs, but slopes840→162 and164→206 are mixed. Peer Tonic client cost also rises in both unary native-server comparisons.

Tonic controls vary greatly: unary-server slopes136→62 and56→112µs/RPC; bidi-server1342→244 and388→104. Native-client-only scopes also change despite the server-only implementation change. Do not attribute every source difference to the proxy or discard control variation. The known-process scans were empty around capture, but that is not dedicated-host/globalquiescence proof.

All12 source/control slope groups, all8 native/fresh-Tonic CPU groups, rawN10,000 user/systemCPU, allhistograms, signed/nonpositive components and every losing repeat remain in `architecture-c15-wake-shipping-analysis.json` and the originalsummary/captures. No instruction-to-CPU or wake-to-CPU inference is made. Root's adoption decision is separate.
