# Bounded encode scratch: candidate results

Candidate source remains isolated and uncommitted at
`work/architecture-c15-bytes-reuse`, based on `ee5b345b` (runtime `933bf877`).
No Root production files were edited. The production patch is
`architecture-c15-bytes-reuse-candidate-v5.patch`; private allocator probes are
removed and production source restored byte-for-byte to its frozen v5 snapshot.

Actual all-feature library: **738 passed / 0 failed / 1 existing ignore**.
The same-test fresh child validates actual lease rejection/exhaustion/reuse and
seven pump/drain terminal cases. It observes positive1MiB retention while Pending,
then zero while completed futures are still allocated, and after cancellation,
producer errors, encode-limit errors and abandonment. Its final counts are
**13 acquired / 13 released, zero bytes/buffers**. Small scratch remains outside
this large encode ledger. Decode has its own unchanged ledger.

Test-profile private layouts are **EncodeScratch32B / OutBatch192B**. These are
not machine stack-frame sizes or shipping CPU measurements.

The separate actual allocation-site run passes **2 tests / 34 cases / 88 encoded
and independently decoded messages**. Its32 builtin Prost cases exactly match
the baseline payloads/entropy/flush policies. For four1MiB messages the plaintext
reservation site changes **4,194,320→1,048,580 requested bytes (−75%)**, under zero
and noise and burst/flush-each controls. The new serialization-only tag observes
zero allocations for builtin Prost. Wire sizes and the two common compressed
output/compressor site counts match exactly. One-message and1KiB scratch-site
requests remain unchanged. This is callsite attribution, not total endpoint
allocation savings or a shipping CPU/throughput claim.

The legacy custom contiguous default bridge is a real tradeoff: for four1MiB
messages its serialization scope requests **4,194,352B / 8 allocations**, while
canonical scratch is reused once. Four1KiB custom messages request4,140B / 8
serialization allocations. This temporary happens on every such custom message;
it is not only a cold cost. Builtin Prost overrides the new generic BufMut method;
ordinary generated pbrs put methods use its append-only default. A custom encoder
can override that method to avoid the temporary. No universal codec win is claimed.

The new process allowance is **16MiB for large idle ENCODE scratch,4MiB per buffer**.
The existing4MiB/16MiB DECODE allowance is separate. Combined admitted allowance
can therefore reach32MiB plus legacy≤64KiB encode storage per stream, active
scratch, messages and wire output. A cache miss frees storage and never fails RPCs.
The active Vec is outside the idle ledger and remains call-owned. Existing C13
soaks observe decode counters only and do not qualify this new encode feature.

Development history is retained: the uncompiled v1 eager `then_some` RAII issue
was caught by independent review and fixed before execution. Build-v1 missed a
fixture `ClientBuilder` trait import; build-v2 then missed `SendRequest`. Both
original failed receipts remain. Build-v3 succeeds; all library and private site
controls succeed. No production test failure was relabeled or hidden.

Next gates are strict lint/docs, supported consumers/MSRV, independent current-
source retention/soak coverage and whole-endpoint allocation plus feature-off CPU
comparisons across short/cold/warm, zero/noise, concurrency and fresh tonic peers.
Compressed-output hint changes and direct serializer-to-compressor streaming are
separate future experiments.
