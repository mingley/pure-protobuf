#!/usr/bin/env python3
"""Package closed C15 evidence; retain failures and omit compiled executable bytes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import tarfile

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
OUT = ROOT / 'docs/evidence/grpc-required-merge-20261026'


def sha(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def ref(path, name=None):
    return {'path': name or str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    files = {}
    omitted = []
    for top in sorted(Q.glob('*c15*')):
        for path in ([top] if top.is_file() else sorted(top.rglob('*'))):
            if '__pycache__' in path.parts or path.suffix == '.pyc':
                continue
            if path.is_symlink():
                omitted.append({'path': str(path.relative_to(Q)), 'reason': 'symlink omitted'})
                continue
            if not path.is_file():
                continue
            with path.open('rb') as stream:
                head = stream.read(4)
            name = 'qualification/' + str(path.relative_to(Q))
            row = ref(path, name)
            if head == b'\x7fELF':
                omitted.append({**row, 'reason': 'ELF bytes omitted; actual executable/object hash retained'})
                continue
            if any(part in ('target', '.git') for part in path.relative_to(Q).parts):
                omitted.append({**row, 'reason': 'build-cache file omitted'})
                continue
            files[name] = (path, row)
    # Exact shared helpers used by the retained controllers, not all prior campaigns.
    dependencies = [
        'work/record.py', 'work/run-rust',
        'work/qualification/architecture-c13-build-shipping-rpc.py',
        'work/qualification/architecture-c13-shipping-smoke.py',
        'scripts/build-rpc-bench.py', 'scripts/grpc-load-smoke.py',
        'scripts/grpc-counter-campaign.py', 'scripts/regen-generated.sh', 'scripts/conformance.sh',
    ]
    for relative in dependencies:
        path = ROOT / relative
        if not path.is_file() or path.is_symlink():
            continue
        name = 'shared-helpers/' + relative
        files[name] = (path, ref(path, name))
    omissions = json.dumps({'schema': 'pbrs.c15-omitted-files.v1', 'files': omitted}, indent=2, sort_keys=True).encode() + b'\n'
    omissions_name = 'packaging/omitted-files.json'
    inventory = [row for _, row in files.values()]
    inventory.append({'path': omissions_name, 'bytes': len(omissions), 'sha256': hashlib.sha256(omissions).hexdigest()})
    archive = OUT / 'raw.tar.gz'
    with archive.open('wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w') as capsule:
                for name, (path, row) in sorted(files.items()):
                    # Reject an active/mutating source before and after archival read.
                    assert path.stat().st_size == row['bytes'] and sha(path) == row['sha256'], name
                    info = tarfile.TarInfo(name)
                    info.size = row['bytes']
                    info.mode = stat.S_IMODE(path.stat().st_mode) & 0o777
                    info.mtime = 0
                    with path.open('rb') as source:
                        capsule.addfile(info, source)
                    assert sha(path) == row['sha256'], 'source changed during package: ' + name
                info = tarfile.TarInfo(omissions_name)
                info.size = len(omissions)
                info.mode = 0o644
                capsule.addfile(info, io.BytesIO(omissions))
    result = {
        'schema': 'pbrs.c15-required-merge-publication.v1',
        'qualified': False, 'production_ready': False, 'broad_superiority': False,
        'adopted_kernel': 'af00f348', 'adopted_benchmark': 'eac85b04',
        'kernel': {'single_target': 30, 'parallel_imported': 3, 'root_core': 113,
                   'runtime': 26, 'mini_table_upb': 18,
                   'conformance': {'runs': 3, 'binary_json_per_run': 5631, 'text_per_run': 909,
                                   'runner': 'v35.1', 'max_edition': 2023},
                   'regenerated_outputs': 2, 'unchanged_outputs': 11,
                   'limits': ['Affected validation can allocate a final tree.',
                              'Consumer bindings must be regenerated.']},
        'benchmark_correctness': {'unit_tests': 5, 'positive_captures': 24,
                                 'successful_rpcs': 48, 'expected_negative_captures': 8,
                                 'profile': 'debug', 'performance_evidence': False},
        'wake_experiment': {'source': '9235cb825947a39527b860d1dac2333f4b94642f',
                            'adopted': False, 'focused_passes': 100,
                            'shipping_captures': 48, 'shipping_successful_rpcs': 360000,
                            'consistent_cpu_improvement': False,
                            'affinity_diagnostic': 'listener denied before RPCs; no CPU result'},
        'bytes_experiment': {'source': '06ec9f23d1f1a40af4c6b4b4e1def2f4064dfcb2',
                             'baseline': 'eac85b04368ac3589f99fe96f693e52de83f39ce',
                             'adopted': False, 'library_passes': 738, 'library_ignores': 1,
                             'site_cases': 34, 'decoded_messages': 88,
                             'scratch_requested_bytes_four_1mib': {'before': 4194320, 'candidate': 1048580},
                             'endpoint_matrix': 'not built or captured',
                             'custom_contiguous_bridge': 'temporary allocation and copy every message'},
        'resource_days': {'source': '933bf8775b70d24d91fb46a7992eae343b60f0ea',
                          'state': 'interrupted', 'pass': False,
                          'application_failure_established': False, 'exit_cause': 'unavailable',
                          'deadline_last_measured_seconds': 44453.35918689,
                          'deadline_cycles': 43781, 'general_cancelled_cycles': 13673,
                          'general_final_measured_seconds': None, 'retries_launched': False},
        'root_integration': {'runtime_source': 'af00f3484d1e79867bbd55ef002418d384f06b07',
                             'test_isolation_source': 'b20c413af657014cb5bf0b54b2dae8cebedb48e6',
                             'workspace_all_features_cargo_check': 'passed; no full workspace test run',
                             'address_sanitizer': {'passed': 190, 'executables': 5, 'detect_leaks': False},
                             'leak_sanitizer': {'process_exit': 1, 'core_tests_before_fatal': 113,
                                                'pass': False, 'precise_fatal_cause': 'unavailable',
                                                'diagnostic_hint': 'ptrace limitation; ptracing not independently established'}},
        'omitted_executable_files': sum(row.get('reason', '').startswith('ELF') for row in omitted),
        'limits': ['Earlier broad workspace and ASAN results belong to their recorded source.',
                   'Shipping endpoint performance, sustained resources and platform qualification remain open.',
                   'Raw absolute paths are original execution paths; patches and bundles retain source.',
                   'Prepared plans, gates and grants are not executed campaign outcomes.'],
    }
    # Preserve exact closed new-source integration records without recasting their scope.
    integration = Q / 'architecture-c15-root-kernel-proof.json'
    if integration.is_file():
        result['root_integration_proof'] = ref(integration, 'qualification/' + integration.name)
    write(OUT / 'results.json', result)
    write(OUT / 'manifest.json', {
        'schema': 'pbrs.c15-evidence-manifest.v1', 'qualified': False, 'production_ready': False,
        'archive': {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': sha(archive)},
        'logical_bytes': sum(row['bytes'] for row in inventory),
        'files': sorted(inventory, key=lambda row: row['path']),
        'publication_files': [ref(OUT / name, name) for name in ('README.md', 'results.json', 'check.py')],
    })
    print(json.dumps({'files': len(inventory), 'logical_bytes': sum(row['bytes'] for row in inventory),
                      'archive_bytes': archive.stat().st_size, 'archive_sha256': sha(archive),
                      'omitted_files': len(omitted)}, indent=2))


if __name__ == '__main__':
    main()
