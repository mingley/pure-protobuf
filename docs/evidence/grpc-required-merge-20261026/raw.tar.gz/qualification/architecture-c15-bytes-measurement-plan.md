# Bounded C15 byte/CPU comparison — proposed only

Compare new baseline benchmark-only source with new scratch-reuse source plus the **identical benchmark subtree**. Existing source933 executables cannot run the new noise corpus and are not substituted into this comparison. Root must create/freeze clean source commits before builds; current source placeholders remain null.

The proposed main matrix has eight corpus configurations: 1MiB gzip zero/noise with 1/4 stream messages, plus 1KiB and64KiB gzip zero/noise with four messages. These cover the measured worst large-message gap, legacy64KiB boundary and small-message cost. Each uses native-Prost→Tonic-Prost, Tonic-Prost→native-Prost and Tonic/Tonic, two balanced repeats, one connection/one in-flight RPC. Both endpoint measures and all peer controls remain visible.

| Phase | N values | Captures | Successful RPCs |
|---|---|---:|---:|
| Allocation-instrumented release | 25 / 50 | 192 | 7,200 |
| Feature-off shipping release | 50 / 100 | 192 | 14,400 |
| Separate fresh-process one-RPC shipping controls | 1 | 72 | 72 |

The cold configurations are 1MiB gzip zero/noise with1/4 stream messages and1KiB identity zero/noise with one message. Every capture starts fresh server/client processes. A one-message RPC is not by itself a cold-process proof. Server corpus preparation precedes READY/client CPU window; client lifetime CPU includes its one-time corpus creation. Latency distributions retain their actual timer/setup scope. Zero/coarse CPU readings are not converted into speed ratios.

This is a bounded proposal for Root review, not an instruction to run every phase before source/benchmark correctness controls pass. JSON lists every proposed cell and separate totals. Root may explicitly choose a smaller first phase while preserving the unrun proposal. No older/newer source counters are combined.

The entropy adapter requires pattern, independent payload seed and message count in every cell; passes explicit req/resp fixture bounds to both peers; rejects non-Prost entropy; verifies server READY pattern/seed/validation/transport/compression and client metadata. V3 additionally exposes exact fixture bounds; its adapter successor must pin/verify those labels before actual captures.

Allocation builds use unchanged source `scripts/build-rpc-bench.py` with `allocation-counts`; feature-off builds use unchanged Q `architecture-c13-build-shipping-rpc.py`. All four binaries need new source/build/log/ELF identities. Source configs remain null until Root freezes baseline benchmark-only commit and scratch-reuse+same-benchmark commit. The allocator and shipping records are different contracts; the adapter checks their actual Cargo artifact features/profile.

N/2N bytes/allocations/CPU slopes use raw process counts and retain signed/nonpositive observations. Raw single-count distributions are kept; quantiles and throughput are never subtracted. No wall-clock, CPU, allocation or instruction metric substitutes for another. Every control increase and mixed repeat remains visible, with no silent cutoff or discarded cell.
