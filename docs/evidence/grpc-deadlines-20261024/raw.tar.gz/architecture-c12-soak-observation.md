# Resource diagnostics observation

Observed UTC: 2026-10-24T02:55:15.088846+00:00. Read-only audit; no campaign was restarted, stopped or modified.

C8 source `9d6fb9c416fc32732450fd78d32ee16ff8b802de` completed its requested 86,400-second resource diagnostic: **86,406.432489 seconds**, **26,291 complete cycles**, child exit 0 and smoke PASS. Original effective caps remain AS 1 GiB, FD 128, same-UID processes 4096 and CPU 86,430 seconds.

The source validator returns no errors. All **52,582** cancelled/drain recovery events return client/server accounted bytes, byte tokens and active streaming calls to zero. Final started/ended streaming calls are **105,164 / 105,164**; active calls zero. Sampled RSS maximum is **24,879,104 bytes**, process VmHWM **25,862,144 bytes** and sampled FD maximum **14**. These are the recorded measurement scopes, not allocator or kernel-socket high-water attribution.

Its automatic publisher pushed `50fb3a3f18a92bb61510e7e98e097506ccbdd759` to main at 2026-10-24T02:52:31Z on the first attempt. The retained capsule independently verifies **34 files / 253,899,863 logical bytes**. Publication status remains `qualified:false`; the diagnostic does not close all QG-06 or product/performance gates.

C11 source `beb4ecd9` standard and Prost-cache diagnostics remain active. Their once-read progress and last complete events are embedded in the adjacent JSON. No immutable hash references point to mutable live metadata. C8 completion is not inherited by these newer-source campaigns. Readable process stat confirms non-zombie PIDs; managed permissions deny direct exe-selector access, so no new direct live ELF identity observation is claimed.
