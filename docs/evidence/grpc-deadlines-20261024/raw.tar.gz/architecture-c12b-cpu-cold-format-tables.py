#!/usr/bin/env python3
"""Format the retained C12b terminal analysis; no metrics or source changes."""
from pathlib import Path
import hashlib
import json

Q = Path('/workspace/pure-protobuf/work/qualification')
source = Q/'architecture-c12b-cpu-cold-tables.md'
analysis = Q/'architecture-c12b-cpu-cold-analysis.json'
v = json.loads(analysis.read_text())
assert not v['cpu']['every_native_higher_tonic_cost_group']
s = source.read_text()
start=s.index('## Remaining instruction losses versus tonic')
end=s.index('## Fresh process plus one RPC',start)
s=s[:start]+'''## What remains slower

No current instruction-median loss appears against tonic in these 22 equal-Prost
native endpoint groups. The identity server still regresses versus the old source:
**+6.80% instructions** and **+27.43% requested bytes** in the separate native campaign.
The large identity/bidi byte gaps and pbrs interop losses remain in the native tables.
Pbrs interop includes additional handler work; no pbrs instruction case ran here.
The JSON retains every source cost increase and all original repeat ranges.

'''+s[end:]
for a,b in [("{'win': 2}",'2 wins'),("{'improvement': 2}",'2 improve'),("{'tie': 2}",'2 within band'),("{'regression': 2}",'2 regress'),('at1/64KiB,10/20RPCbatches,two paired repeats','at 1/64 KiB, 10/20-RPC batches, two paired repeats'),('attached to40f','attached to `40f219fa`'),('only to40f','only to `40f219fa`'),('both1/2RPCprocess totals','both one/two-RPC process totals'),('1KiB','1 KiB'),('64KiB','64 KiB'),('0B','0 B')]:s=s.replace(a,b)
out=Q/'architecture-c12b-cpu-cold-tables-v2.md'
with out.open('x') as f:f.write(s)
metadata={'qualified':False,'command':['python3','work/qualification/architecture-c12b-cpu-cold-format-tables.py'],
 'scope':'Formatting only from retained terminal C12b CPU/cold analysis; removed empty loss table, explicit zero measured instruction losses versus tonic, preserved server source regression and native-byte gaps.',
 'source_analysis':{'path':str(analysis),'sha256':hashlib.sha256(analysis.read_bytes()).hexdigest()},
 'output':{'path':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}}
with (Q/'architecture-c12b-cpu-cold-tables-v2-format.json').open('x') as f:json.dump(metadata,f,indent=2);f.write('\n')
print(json.dumps(metadata))
