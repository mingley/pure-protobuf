#!/usr/bin/env python3
"""Create one immutable C12 evidence capsule after explicit root authorization.

All failed attempts remain selected. The archive contains source, commands,
logs, counters and profiles; executable bytes are represented by hashes only.
No archive is extracted, no old capsule is changed, and no result is qualified.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import runpy
import stat
import subprocess
import tarfile
import tempfile

SCRIPT = Path(__file__).resolve()
COMMON = SCRIPT.with_name('architecture-c12c-evidence-common-workspace-final.py')
C = runpy.run_path(str(COMMON))
ROOT, Q, DEFAULT_DEST = C['ROOT'], C['Q'], C['DEST']

CHECK_PY = '''#!/usr/bin/env python3
"""Verify this evidence capsule without extracting it."""
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile


def safe_name(name):
    path = PurePosixPath(name)
    return (bool(name) and not path.is_absolute() and str(path) == name
            and not any(part in (".", "..") for part in path.parts)
            and "\\\\" not in name and ":" not in name)


def digest(path):
    result = hashlib.sha256()
    with path.open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(data)
    return result.hexdigest()


def check(directory):
    manifest_path = directory / "manifest.json"
    if manifest_path.is_symlink() or not manifest_path.is_file():
        raise ValueError("manifest must be a regular local file")
    manifest = json.loads(manifest_path.read_text())
    if manifest.get("qualified") is not False:
        raise ValueError("unexpected qualification claim")
    archive_name = manifest["archive"]["name"]
    if not safe_name(archive_name) or len(PurePosixPath(archive_name).parts) != 1:
        raise ValueError("unsafe archive name")
    archive = directory / archive_name
    if archive.is_symlink() or not archive.is_file():
        raise ValueError("archive must be a regular local file")
    if archive.stat().st_size != manifest["archive"]["bytes"] or digest(archive) != manifest["archive"]["sha256"]:
        raise ValueError("archive size or checksum mismatch")
    expected = {row["path"]: row for row in manifest["files"]}
    if len(expected) != len(manifest["files"]) or not all(map(safe_name, expected)):
        raise ValueError("duplicate or unsafe manifest path")
    seen, total = set(), 0
    with tarfile.open(archive, "r:gz") as capsule:
        for member in capsule:
            if not member.isfile() or not safe_name(member.name) or member.name in seen or member.name not in expected:
                raise ValueError("unexpected member: " + member.name)
            row = expected[member.name]
            if row["bytes"] != member.size:
                raise ValueError("size mismatch: " + member.name)
            stream = capsule.extractfile(member)
            if stream is None:
                raise ValueError("missing content: " + member.name)
            h = hashlib.sha256()
            for data in iter(lambda: stream.read(1024 * 1024), b""):
                h.update(data)
            if h.hexdigest() != row["sha256"]:
                raise ValueError("checksum mismatch: " + member.name)
            seen.add(member.name)
            total += member.size
    if seen != set(expected) or total != manifest["logical_bytes"]:
        raise ValueError("incomplete archive inventory")
    print(f"verified {len(seen)} files, {total} bytes; no production qualification")


if __name__ == "__main__":
    check(Path(__file__).resolve().parent)
'''


def live_writers():
    """Best-effort observation; denied procfs selectors stay explicitly unknown."""
    writers, unavailable = {}, set()
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            for descriptor in (proc / 'fd').iterdir():
                try:
                    target = os.readlink(descriptor)
                    if not target.startswith(str(Q) + '/'):
                        continue
                    text = (proc / 'fdinfo' / descriptor.name).read_text()
                    flags = next(line.split()[1] for line in text.splitlines() if line.startswith('flags:'))
                    if int(flags, 8) & os.O_ACCMODE != os.O_RDONLY:
                        writers.setdefault(Path(target), []).append({'pid': int(proc.name), 'fd': descriptor.name})
                except (FileNotFoundError, ProcessLookupError):
                    continue
                except PermissionError:
                    unavailable.add(int(proc.name))
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            unavailable.add(int(proc.name))
    return writers, sorted(unavailable)


def selected_inputs(required, writers):
    paths, omissions = set(), []
    for path in required:
        if path.is_relative_to(Q) or path in (ROOT / 'work/run-rust', ROOT / 'work/record.py') or binary(path):
            paths.add(path)
        else:
            # Publication files are already frozen as generated archive bytes
            # under published-documents; do not archive their absolute paths.
            assert path in (ROOT / 'README.md', ROOT / 'TODO.md') or path.is_relative_to(ROOT / 'docs'), path
    for child in Q.glob('architecture-c12*'):
        assert not child.is_symlink(), child
        for path in child.rglob('*') if child.is_dir() else [child]:
            assert not path.is_symlink(), path
            if not path.is_file():
                continue
            if '__pycache__' in path.parts or path.suffix in ('.pyc', '.pyo'):
                omissions.append({'path': path.relative_to(Q).as_posix(), 'reason': 'Python bytecode cache'})
                continue
            paths.add(path.absolute())
    for path in paths:
        assert path not in writers, 'a selected output still has a live writer: ' + str(path)
    return paths, omissions


def archive_name(path):
    if path.is_relative_to(Q):
        return path.relative_to(Q).as_posix()
    assert path in (ROOT / 'work/run-rust', ROOT / 'work/record.py'), path
    return 'support/' + path.name


def binary(path):
    with path.open('rb') as stream:
        header = stream.read(64)
    return (header.startswith(b'\x7fELF') or header.startswith(b'MZ')
            or header[:4] in (b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe')
            or bool(path.stat().st_mode & (stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH))
            and b'\0' in header and not header.startswith(b'#!'))


def source_snapshot(pins):
    candidate = pins['candidate_runtime']
    changed = C['git']('diff', '--name-only', C['BASELINE'], candidate).decode().splitlines()
    generated, entries = {}, []
    for name in changed:
        assert C['safe_name'](name), name
        if name.startswith('docs/evidence/'):
            continue  # Older immutable capsules are linked, never duplicated or changed.
        present = {}
        for label, commit in [('source-delivered', candidate), ('baseline-source', C['BASELINE'])]:
            found = subprocess.run(['git', 'cat-file', '-e', commit + ':' + name], cwd=ROOT,
                                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            if found.returncode == 0:
                data = C['git']('show', commit + ':' + name)
                generated[label + '/' + name] = data
                present[label] = {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
        entries.append({'path': name, 'versions': present})
    generated['source-delivered/runtime.patch'] = C['git']('diff', '--binary', C['BASELINE'], candidate,
                                                         '--', 'pbrs-grpc', 'src')
    for name in pins['identical_harness']:
        generated['identical-benchmark/' + name] = C['git']('show', candidate + ':' + name)
    generated['source-delivered/pin.json'] = C['encoded']({
        'source': candidate, 'source_tree': pins['candidate_tree'], 'baseline_source': C['BASELINE'],
        'baseline_tree': C['git']('rev-parse', C['BASELINE'] + '^{tree}').decode().strip(),
        'qualified': False, 'changed_files': entries,
        'scope': 'Git object snapshots and complete runtime/test patch from the unchanged C11 baseline to the measured C12 commit.'})
    generated['identical-benchmark/equivalence.json'] = C['encoded']({
        'qualified': False, 'baseline_source': C['BASELINE'], 'candidate_source': candidate,
        'identical_files_sha256': pins['identical_harness'],
        'historical_controller_annotation': pins.get('historical_controller_annotation')})
    return generated


def publications(plan_path, dest, candidate, observed):
    plan = C['read_json'](plan_path, observed)
    assert plan['source'] == candidate and plan['finalized'] is True and plan['qualified'] is False
    generated, entries = {}, []
    for row in plan['files']:
        name = row['path']
        assert C['safe_name'](name)
        path = ROOT / name
        if path.parent == dest:
            assert path.name in ('README.md', 'results.json')
            archived = 'published-documents/capsule/' + path.name
        else:
            assert name in ('README.md', 'TODO.md', 'docs/evidence/README.md') or name.startswith('docs/')
            assert not name.startswith('docs/evidence/') or name == 'docs/evidence/README.md'
            archived = 'published-documents/' + name
        item = C['observe'](path, observed)
        assert item['sha256'] == row['sha256'] and archived not in generated
        generated[archived] = path.read_bytes()
        entries.append({'path': name, 'archive_path': archived, 'bytes': item['bytes'], 'sha256': item['sha256']})
    assert str((dest / 'results.json').relative_to(ROOT)) in {row['path'] for row in entries}
    assert str((dest / 'README.md').relative_to(ROOT)) in {row['path'] for row in entries}
    generated['packaging/publication-plan.json'] = C['encoded'](plan)
    return generated, entries


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--pins', type=Path, default=C['PINS'])
    parser.add_argument('--pins-sha256')
    parser.add_argument('--checkout', type=Path, default=C['TREE'])
    parser.add_argument('--phase-map', type=Path)
    parser.add_argument('--require-cold', action='store_true')
    parser.add_argument('--published-plan', type=Path)
    parser.add_argument('--destination', type=Path, default=DEFAULT_DEST)
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True,
                          'destination': str(args.destination), 'qualified': False}))
        return 0
    dest = args.destination.resolve()
    assert dest.parent == ROOT / 'docs/evidence' and dest.name.startswith('grpc-deadlines-20261024')
    assert dest.is_dir() and not dest.is_symlink()
    assert {path.name for path in dest.iterdir()} == {'README.md', 'results.json'}, 'never overwrite a capsule or partial prior publication'
    assert args.published_plan is not None, 'reviewed final README/results and living docs need an explicit SHA plan'
    value = C['validate_all'](args.pins, args.pins_sha256, args.checkout, args.phase_map, args.require_cold)
    observed, pins = value['observed'], value['pins']
    C['observe'](SCRIPT, observed)
    C['observe'](COMMON, observed)
    results = C['read_json'](dest / 'results.json', observed)
    assert results['source'] == pins['candidate_runtime'] and results['source_pins'] == C['ref'](args.pins)
    assert results['qualified'] is False and results['production_ready'] is False
    for item in results['validated_inputs']:
        C['verify_reference'](item, observed)
    assert results['validation']['phase_records'] == {name: C['ref'](value['phase_paths'][name]) for name in value['states']}
    repository = value['states']['workspace']['source']['head']
    assert repository == results['workspace_repository_source'] == C['WORKSPACE_REPOSITORY']
    assert results['runtime_source'] == pins['candidate_runtime']
    assert results['validation']['workspace']['source'] == repository
    assert results['validation']['workspace']['runtime_source'] == pins['candidate_runtime']
    assert not C['git']('diff', '--name-only', repository, '--', 'pbrs-grpc', 'src', 'Cargo.lock', 'rpc-bench', 'tonic-bench').strip(), 'root production/fixture source changed after the tested repository commit'
    publication_files, publication_entries = publications(args.published_plan, dest, pins['candidate_runtime'], observed)
    writers, unavailable = live_writers()
    paths, omissions = selected_inputs(observed, writers)
    generated = source_snapshot(pins) | publication_files
    generated['workspace-repository/pbrs-grpc/tests/service_config.rs'] = C['git']('show', repository + ':pbrs-grpc/tests/service_config.rs')
    generated['workspace-repository/fixture.patch'] = C['git']('diff', C['WORKSPACE_PRIOR'], repository, '--', C['WORKSPACE_FIXTURE'])
    generated['workspace-repository/source.json'] = C['encoded']({
        'qualified': False, 'runtime_source': pins['candidate_runtime'], 'workspace_repository_source': repository,
        'repository_tree': C['git']('rev-parse', repository + '^{tree}').decode().strip(),
        'equivalence_before': value['states']['workspace']['runtime_equivalence'],
        'equivalence_after': value['states']['workspace']['runtime_equivalence_after'],
        'scope': 'Actual final workspace fixture repository; measured runtime snapshots remain separate. Prior immutable evidence capsules are not duplicated.'})
    files, omitted_executables = {}, []
    for path in sorted(paths):
        item = C['observe'](path, observed)
        if binary(path):
            omitted_executables.append(item)
            continue
        name = archive_name(path)
        assert C['safe_name'](name) and name not in files and name not in generated
        files[name] = (item, path)
    metadata = {'created_utc': C['now'](), 'source': pins['candidate_runtime'], 'runtime_source': pins['candidate_runtime'],
                'workspace_repository_source': repository, 'baseline': C['BASELINE'],
                'qualified': False, 'omitted': omissions, 'omitted_executables': omitted_executables,
                'live_writer_observation': {str(path): users for path, users in writers.items()},
                'unavailable_procfs_pids': unavailable,
                'procfs_quiescence_proven': not unavailable,
                'publication_files': publication_entries,
                'scope': 'Only terminal selected phase records are required. Live resource-* trees are outside archive selection. Every selected regular file is rehashed after archive creation; unavailable process selectors are not a quiescence proof.'}
    generated['packaging/selection.json'] = C['encoded'](metadata)
    for name, data in generated.items():
        assert C['safe_name'](name) and name not in files
        files[name] = ({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, data)
    inventory = [{'path': name, 'bytes': item['bytes'], 'sha256': item['sha256']}
                 for name, (item, _) in sorted(files.items())]
    with tempfile.TemporaryDirectory(prefix='resource-c12-package-', dir=Q) as temporary:
        staging = Path(temporary)
        archive = staging / 'raw.tar.gz'
        with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as zipped:
            with tarfile.open(fileobj=zipped, mode='w|') as tar:
                for name, (item, content) in sorted(files.items()):
                    member = tarfile.TarInfo(name)
                    member.size, member.mode = item['bytes'], 0o644
                    if isinstance(content, bytes):
                        tar.addfile(member, io.BytesIO(content))
                    else:
                        with content.open('rb') as stream:
                            tar.addfile(member, stream)
        C['verify_observed'](observed)
        manifest = {'schema': 'pbrs.grpc-deadlines-evidence.v1', 'source': pins['candidate_runtime'],
                    'runtime_source': pins['candidate_runtime'], 'workspace_repository_source': repository,
                    'baseline': C['BASELINE'], 'qualified': False, 'production_ready': False,
                    'archive': {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': C['digest'](archive)},
                    'logical_bytes': sum(row['bytes'] for row in inventory), 'files': inventory,
                    'omitted_executables': omitted_executables}
        (staging / 'manifest.json').write_bytes(C['encoded'](manifest))
        (staging / 'check.py').write_text(CHECK_PY)
        subprocess.run([os.sys.executable, str(staging / 'check.py')], check=True)
        C['verify_observed'](observed)
        for name in ('raw.tar.gz', 'manifest.json', 'check.py'):
            os.link(staging / name, dest / name)  # exclusive final publication
    print(json.dumps({'source': pins['candidate_runtime'], 'qualified': False, 'files': len(inventory),
                      'logical_bytes': manifest['logical_bytes'], 'archive_bytes': manifest['archive']['bytes'],
                      'manifest': C['ref'](dest / 'manifest.json')}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
