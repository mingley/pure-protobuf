# Router allocation control summary — preparation only

No source controls or summary have run during this preparation. This helper is
separate from the eight canonical C12c phases. Planned control size is 16 captures
and 600 RPCs per source: 48 captures and 1,800 RPCs across Beb,40f and7c02.
Only validated actual records produce those totals.

The existing controller is unchanged:
`architecture-c12b-router-allocation-control.py`, SHA-256
`e14bd79194dd587293067b8b5b6aac90a3cd7c06e004752bb81cd4e08630e810`.
It records N25/N50, two repeats, unary/bidi1KiB identity, a tonic Prost client,
and native/tonic Prost servers. Default queue/send settings remain those of the
identical pinned harness. It is a small selected allocation-request control,
not a shipping CPU, latency, throughput, allocator-site or RSS measurement.

After root grants and all three source control directories finish successfully:

```sh
python3 work/qualification/architecture-c12c-router-causal-summary.py \
  --execute \
  --baseline work/qualification/architecture-c12c-router-control-baseline \
  --before work/qualification/architecture-c12c-router-control-before \
  --after work/qualification/architecture-c12c-router-control-after \
  --output /workspace/pure-protobuf/work/qualification/architecture-c12c-router-causal-summary.json
```

The three directory names above are proposed destinations, not existing results.
The helper accepts actual separately retained directories beneath Q whose first
component begins architecture-c12, so the final packager selects their full raw
history. Build/source/binary locations are pinned to the existing C11 stable,
C12b and C12c records; it does not build or run a server.

Validation checks all three committed clean source identities and matching build
records, ELF hashes/toolchains, exact harness/controller/ledger identities, every
workload/repeat/count, command settings, offered/dispatched/completed/successful
counts, zero terminal errors, raw metrics, and allocator stdout snapshots. The
unchanged dominance ledger is recomputed read-only and must match the saved
ledger. Each N2−N1 allocation delta must resolve. Host/affinity and N/2N settings
must match. All observed inputs are hashed and checked again before exclusive
output. No ELF bytes are placed in the summary.

Source comparisons retain Beb→40f, Beb→7c and40f→7c separately, including tonic
client/server controls and both endpoint sides. Same-side server tonic comparisons
retain all three versions. Every positive allocation/byte median change remains,
with both repeat values and directions; there is no 2% cutoff. The private
Router4288→544 layout proof remains separate from these actual allocator-request
numbers. Only40f→7c has the narrow Router runtime diff; Beb→7c includes the combined
runtime changes. The controls are three source runs, not an interleaved ABBA
cross-source experiment.

Root reviews actual values before granting the full matrix. Existing C12c
writer/validator/packager and all predecessor helper versions stay frozen.
Once actual causal records exist and pass, a separately retained writer successor
can require this summary and its validated-input hashes. Its 48/1,800 totals must
remain separate from the canonical native/CPU/cold totals, with no double count.
No current-source production or broad performance qualification follows.
