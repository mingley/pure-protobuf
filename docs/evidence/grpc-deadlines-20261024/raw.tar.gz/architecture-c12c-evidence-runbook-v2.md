# Final C12c evidence preparation

Prepared only. Root must grant actual writer/packager execution after final gates
and cache cleanup. No command below ran during preparation. Synthetic helper
guard checks are not runtime qualification.

Candidate `7c02eb387a6785d6e914146babe34f0902a6dd62`;
baseline `beb4ecd9a9b2143c440892607d5b486318062b61`.
All eight canonical phase names explicitly map to C12c states. Older failed or
superseded phases cannot fill a missing current-source gate.

All old C12/C12b helpers, preparation generations, synthetic red/green records,
failures and successful source-scoped captures remain unchanged. C12b's completed
1,448 captures/44,904 RPCs are predecessors, not C12c qualification. Its ASAN and
workspace were unrun before supersession, not failed. The Router private release
layout guard's actual0/1 red → 1/0 green is separate from four routed controls passing
before and after and final27 integration + one private focused passes. Layout is not
shipping allocator/CPU/time/RSS evidence; actual final counters remain required.

## Required order

1. Complete exact-source prechecks, release resource preview, benchmark build,
   native, CPU, cold-native, selected ASAN/leak checks and full workspace. The
   actual workspace command is all-feature/no-fail-fast; sanitizer selection
   includes both deadline targets plus terminal accounting. Require terminal
   success/source/hash reconciliation; preserve each failed attempt separately.
2. Complete authorized cache cleanup before writer. ASAN state executables whose
   original cache paths are absent remain attested by retained hashes/logs/state;
   do not mutate frozen states. Cross-check owned-cache inventory before unlink.
   If an executable exists at writer time, do not remove/change it before package:
   it becomes a validated input. Retain cleanup helpers/inventory/reclaim records.
   Readable same-UID command lines are not global exe/maps/fd quiescence proof.
3. Root grants writer execution, then run exactly:

```sh
python3 work/qualification/architecture-c12c-write-results-v2.py \
  --execute \
  --pins work/qualification/architecture-c12c-source-pins.json \
  --pins-sha256 4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af \
  --checkout work/architecture-c12c \
  --phase-map work/qualification/architecture-c12c-evidence-phase-map.json \
  --require-cold \
  --router-causal-summary work/qualification/architecture-c12c-router-causal-summary.json \
  --router-causal-summary-sha256 1a66eb3364d08c959cbf44d83d6e756f94f3e090d37dab98e0c706c75bb856f5
```

The new result is `docs/evidence/grpc-deadlines-20261024/results.json`; the
once-only by-value day snapshot is Q `architecture-c12c-evidence-day-snapshot.json`.
Old `f17aa991`,old40f,current7c and older Beb / C8 sources are explicitly distinct. Standard
current live report/progress are under resource-architecture-c12c-day/campaign/;
parent launch/supervisor/termination/publication stay one directory above.
Deadline report/progress are flat under resource-architecture-c12c-deadline-day/.
Static launch/terminal snapshots and older staged-only metadata stay separate.
No running or earlier-source day is inherited as a current 24-hour qualification.

4. Finalize the capsule README and living docs from actual final metrics. Drafts
   contain placeholders, including largest measured gains/losses. Keep all loss
   groups/ranges, independent source identities and separate pbrs-handler scope.
   Fresh-process totals include setup; no startup subtraction or cold-RPC claim.
   Create one new immutable Q publication plan with this shape:

```json
{
  "source": "7c02eb387a6785d6e914146babe34f0902a6dd62",
  "finalized": true,
  "qualified": false,
  "files": [
    {"path": "docs/evidence/grpc-deadlines-20261024/README.md", "sha256": "ACTUAL_SHA"},
    {"path": "docs/evidence/grpc-deadlines-20261024/results.json", "sha256": "ACTUAL_SHA"},
    {"path": "docs/benchmarks.md", "sha256": "ACTUAL_SHA"}
  ]
}
```

Include every finalized living doc. Keep evidence-guide auto-publisher markers;
other dated capsules are forbidden in the plan. Do not edit old capsules.

5. Root grants package execution, then run exactly:

```sh
python3 work/qualification/package-architecture-c12c-evidence.py \
  --execute \
  --pins work/qualification/architecture-c12c-source-pins.json \
  --pins-sha256 4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af \
  --checkout work/architecture-c12c \
  --phase-map work/qualification/architecture-c12c-evidence-phase-map.json \
  --require-cold \
  --published-plan work/qualification/architecture-c12c-final-publication-plan.json
```

The capsule must contain exactly README/results before package. Inputs are
revalidated and rehashed; executable bytes are omitted, preserving metadata.
All stable architecture-c12* histories/preparations/raws/profiles are included,
plus actual source snapshots and unchanged benchmark harness. Live resource-*
trees are excluded; once-read observations are embedded by value. Selected live
writers abort packaging; inaccessible process selectors remain disclosed unknowns.
The checker requires regular local manifest/archive files and safe regular tar
members, checks every checksum, and never extracts. Publication is exclusive;
existing/partial outputs abort rather than overwrite. Root owns commits/push.

Writer v2 requires the actual passing Router causal summary and all validated raw-input hashes. Its48captures/1800RPCs remain in router_causal_control, separate from canonical capture_accounting. The original writer, common validator, packager and phase map remain unchanged.
