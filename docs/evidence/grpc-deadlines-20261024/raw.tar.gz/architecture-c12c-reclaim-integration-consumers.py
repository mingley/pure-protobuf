#!/usr/bin/env python3
"""Narrow reviewed cache helper to the closed C12c integration-consumers cache.

Preparation only without --execute. Root must review, coordinate quiescence and
grant execution after the original workspace attempt terminates.
"""
import argparse
import hashlib
import json
from pathlib import Path
import re
import runpy
import sys

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
HELPER = Q / 'architecture-c12c-reclaim-closed-cache.py'
HELPER_SHA = '4989f4a7d5fc71ec6c0df5a139fd5dc6edfe4148b91580b52c3bf2d5fa3c6dd7'
CONTROLLER = Q / 'architecture-c12c-qualification.py'
CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
SOURCE = '7c02eb387a6785d6e914146babe34f0902a6dd62'
PINS_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
CACHE = ROOT / 'work/architecture-c12c/target/integration-consumers'


def main():
    assert __debug__, 'do not run with Python -O'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA
    assert hashlib.sha256(CONTROLLER.read_bytes()).hexdigest() == CONTROLLER_SHA
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True,
                          'cache': str(CACHE), 'helper_sha256': HELPER_SHA, 'qualified': False}))
        return
    d = runpy.run_path(str(HELPER), run_name='reviewed_c12c_cache_helper')
    c = d['C']
    assert c['digest'](c['PINS']) == PINS_SHA
    assert c['source']() == {'head': SOURCE, 'status': ''}
    c['load_pins']()
    oldpath = Q / 'architecture-c12c-workspace-state.json'
    old = json.loads(oldpath.read_text())
    assert old['mode'] == 'workspace' and old['state'] == 'failed'
    assert len(old['checks']) == 1
    check = old['checks'][0]
    assert check['name'] == 'workspace' and check['exit_code'] == 101 and check['totals']['failed'] == 1
    oldprefix = Q / 'architecture-c12c-workspace'
    record = json.loads(oldprefix.with_suffix('.json').read_text())
    assert record['exit_code'] == 101 and not record.get('timeout')
    text = oldprefix.with_suffix('.stdout').read_text()
    assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.MULTILINE)) == {'test_documentation_links_and_anchors_are_valid'}
    protected = [c['ref'](oldpath), c['ref'](Path(__file__).resolve()), c['ref'](HELPER), c['ref'](CONTROLLER)]
    protected.extend(c['ref'](oldprefix.with_suffix(s)) for s in ('.json', '.stdout', '.stderr'))
    assert not (Q / 'architecture-c12c-workspace-complete-state.json').exists()
    # In-place mutation changes only the new module instance's two allowlists.
    # The reviewed helper file and all frozen controller/pin bytes are untouched.
    d['CACHES'].clear()
    d['CACHES']['integration-consumers'] = CACHE
    d['REQUIRED'].clear()
    d['REQUIRED']['integration-consumers'] = ['prechecks', 'resource-preview', 'build-benchmark',
                                           'native', 'cpu', 'cold-native', 'asan']
    sys.argv = [str(HELPER), '--cache', 'integration-consumers', '--execute']
    d['main']()
    for expected in protected:
        assert c['ref'](Path(expected['path'])) == expected
    c['load_pins']()
    assert c['source']() == {'head': SOURCE, 'status': ''}


if __name__ == '__main__':
    main()
