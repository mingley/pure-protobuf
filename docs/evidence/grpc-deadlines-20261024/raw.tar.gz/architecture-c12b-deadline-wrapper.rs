#[cfg(not(all(feature = "copy-counts", feature = "grpc-web")))]
compile_error!("the repeated deadline diagnostic requires copy-counts and grpc-web");

fn sustained_process_sample() -> (usize, u64, usize) {
    let fds = std::fs::read_dir("/proc/self/fd")
        .expect("descriptor accounting")
        .count();
    let status = std::fs::read_to_string("/proc/self/status").expect("resident accounting");
    let rss = status
        .lines()
        .find_map(|line| line.strip_prefix("VmRSS:"))
        .expect("resident measurement")
        .split_whitespace()
        .next()
        .expect("resident value")
        .parse::<u64>()
        .expect("resident bytes")
        * 1024;
    let tasks = tokio::runtime::Handle::current().metrics().num_alive_tasks();
    (fds, rss, tasks)
}

fn sustained_progress(path: &std::path::Path, event: &serde_json::Value) {
    use std::io::Write as _;
    let temporary = path.with_extension("json.next");
    let mut file = std::fs::File::create(&temporary).expect("progress temporary");
    serde_json::to_writer(&mut file, event).expect("progress JSON");
    file.write_all(b"\n").expect("progress newline");
    file.sync_all().expect("durable progress");
    drop(file);
    std::fs::rename(temporary, path).expect("atomic progress publication");
}

#[tokio::test(start_paused = true)]
async fn deadline_sustained() {
    use std::io::Write as _;
    let started = std::time::Instant::now();
    let seconds = std::env::var("PBRS_DEADLINE_SECONDS")
        .expect("explicit real duration")
        .parse::<u64>()
        .expect("integer real duration");
    assert!((30..=86400).contains(&seconds));
    let directory = std::path::PathBuf::from(
        std::env::var_os("PBRS_DEADLINE_OUTPUT").expect("explicit diagnostic output"),
    );
    let mut events = std::fs::OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(directory.join("events.jsonl"))
        .expect("exclusive event log");
    let progress = directory.join("progress.json");
    let (baseline_fds, _, baseline_tasks) = sustained_process_sample();
    let mut cycles = 0u64;
    loop {
        original::run_sustained_cases().await;
        extended::run_sustained_cases().await;
        accounting::run_sustained_cases().await;
        // The original fixtures abort their owned peer tasks during Drop.
        // Require the runtime to finish that cleanup; an elapsed sleep is not
        // evidence that the tasks, descriptors or retained buffers are gone.
        let cleanup = std::time::Instant::now();
        loop {
            tokio::task::yield_now().await;
            let (fds, _, tasks) = sustained_process_sample();
            if fds <= baseline_fds && tasks <= baseline_tasks {
                break;
            }
            assert!(
                cleanup.elapsed() < std::time::Duration::from_secs(5),
                "peer cleanup must return to initial descriptor/task counts"
            );
        }
        let counts = pbrs_grpc::copy_counts::retained_decode_counts();
        assert_eq!(counts.retained_capacity, 0);
        assert_eq!(counts.retained_buffers, 0);
        assert_eq!(counts.acquired, counts.released);
        assert!(counts.peak_retained_capacity <= counts.capacity_limit);
        let (fds, rss, tasks) = sustained_process_sample();
        assert!(fds <= baseline_fds && baseline_fds < 128);
        assert!(tasks <= baseline_tasks);
        assert!(rss > 0 && rss < 1024 * 1024 * 1024);
        cycles += 1;
        let event = serde_json::json!({
            "event": "cycle_completed", "state": "running", "pid": std::process::id(),
            "completed_cycles": cycles, "fixture_cases_per_cycle": SUSTAINED_CASES,
            "elapsed_seconds": started.elapsed().as_secs_f64(), "requested_seconds": seconds,
            "fd_count": fds, "baseline_fd_count": baseline_fds,
            "alive_tasks": tasks, "baseline_alive_tasks": baseline_tasks, "rss_bytes": rss,
            "retained_capacity": counts.retained_capacity, "retained_buffers": counts.retained_buffers,
            "acquired": counts.acquired, "released": counts.released,
            "peak_retained_capacity": counts.peak_retained_capacity,
            "controlled_tokio_time": true,
        });
        serde_json::to_writer(&mut events, &event).expect("cycle event");
        events.write_all(b"\n").expect("cycle newline");
        events.sync_data().expect("durable completed cycle");
        sustained_progress(&progress, &event);
        if started.elapsed() >= std::time::Duration::from_secs(seconds) {
            let mut completed = event;
            completed["event"] = serde_json::json!("duration_completed");
            completed["state"] = serde_json::json!("completed");
            completed["elapsed_seconds"] = serde_json::json!(started.elapsed().as_secs_f64());
            serde_json::to_writer(&mut events, &completed).expect("terminal event");
            events.write_all(b"\n").expect("terminal newline");
            events.sync_all().expect("durable duration completion");
            sustained_progress(&progress, &completed);
            return;
        }
        // Rate-limit an already quiescent fixture. Tokio time stays under the
        // original tests' explicit control; std::Instant measures actual wall
        // duration. This is not a real-time timer or throughput qualification.
        std::thread::sleep(std::time::Duration::from_secs(1));
    }
}
