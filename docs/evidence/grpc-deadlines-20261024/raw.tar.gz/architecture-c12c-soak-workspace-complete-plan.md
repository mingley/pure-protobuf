# C12c days after the complete-checkout workspace run

Prepared launch metadata only. No day has started through these helpers.
The runtime source remains `7c02eb387a6785d6e914146babe34f0902a6dd62` and its pins
remain SHA256 `4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af`.

The original workspace attempt used a sparse checkout without tracked evidence
archives, so the documentation-link test could not resolve those files. Its
failed state and logs remain evidence. The separate workspace-complete attempt
materializes the same Git tree and runs the same full command, environment and
7,200-second timeout. No tests or requirements are removed.

The successor common helper requires only the explicit replacement
`architecture-c12c-workspace-complete-state.json` for the workspace gate. It
checks the preserved original failure, all closed log hashes, commands, timeout,
working directory, recorded environment, runner/controller hashes and passing
new results. It independently hashes every tracked file against the pinned Git
blobs, including evidence archives, and compares that inventory to
`architecture-c12c-workspace-complete-checkout.json`. A missing or failed
replacement never falls back to the earlier attempt. Every other phase keeps
its original state path and checks.

The existing tested 27-case fixture, release ELF, source proof, preview and build
provenance are reused byte for byte. The original build-driver/common references
still identify the helpers that actually performed that build. New launch-helper
references are recorded separately. This metadata change requires no rebuild or
new preview. The preview covered 30.791982326 actual wall seconds and 31 cycles
of the same 27 causal cases; it is not a 24-hour result.

The new controller accepts only `plan`, `check-ready`, `launch` and `supervise`.
Its build, worktree-creation and preview CLI modes are unavailable. Root must
still grant each day after every source-specific final gate passes.

```sh
pins_sha=4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af
python3 work/qualification/architecture-c12c-soaks-workspace-complete.py check-ready \
  --kind resource --pins-sha256 "$pins_sha"
python3 work/qualification/architecture-c12c-soaks-workspace-complete.py check-ready \
  --kind deadline --pins-sha256 "$pins_sha"
```

Separate root grant JSONs must bind the source and pins above, set
`root_granted: true`, and use action
`launch-c12c-workspace-complete-resource-day` or
`launch-c12c-workspace-complete-deadline-day`.

```sh
python3 work/qualification/architecture-c12c-soaks-workspace-complete.py launch \
  --kind resource --pins-sha256 "$pins_sha" --grant ROOT_RESOURCE_GRANT_JSON --execute
python3 work/qualification/architecture-c12c-soaks-workspace-complete.py launch \
  --kind deadline --pins-sha256 "$pins_sha" --grant ROOT_DEADLINE_GRANT_JSON --execute
```

| Item | Path below `work/qualification/` |
|---|---|
| Standard live outer state | `resource-architecture-c12c-workspace-complete-day/{launch,supervisor-state,termination,publication}.json` |
| Standard actual progress/report | `resource-architecture-c12c-workspace-complete-day/campaign/{progress,report}.json` |
| Deadline live state and progress | `resource-architecture-c12c-workspace-complete-deadline-day/{launch,supervisor-state,progress,report,termination,publication}.json` |
| Static standard launch snapshot | `architecture-c12c-workspace-complete-resource-day-launch-snapshot.json` |
| Static deadline launch snapshot | `architecture-c12c-workspace-complete-deadline-day-launch-snapshot.json` |
| Static deadline terminal | `architecture-c12c-workspace-complete-deadline-day-terminal.json` |
| Original deadline preview | `resource-architecture-c12c-deadline-preview/report.json` |
| Original copied release ELF | `architecture-c12c-deadline-build/fixture-test` |

Both days retain the original 1 GiB address-space, 128-descriptor, 4,096 same-UID
process and 86,430 CPU-second limits. The standard controller invokes the original
release resource campaign, seed 20261002. The repeated deadline day uses its
original controlled-Tokio-time cases and actual `std::Instant` wall duration,
strict initial descriptor/task baselines and zero idle decoded-cache capacity.
The same previewed ELF runs the deadline day. Neither workload establishes
universal production readiness or comparative speed by itself.

The standard launch still needs 2 GiB release-build entry headroom and its own
root compiler window. Deadline launch reuses the copied ELF. No cleanup or
compiler action belongs to this metadata preparation. The original C12c helpers,
all C12/C12b preparations, and every older soak remain untouched.
