# Workspace checkout history — observed recovery, complete repeat pending

Source `7c02eb387a6785d6e914146babe34f0902a6dd62`, tree
`6b264f0602fa1c90471cb54d7e17e35fb2199a11` and pins digest
`4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af`
remain unchanged.

The original workspace attempt finished **3,811 passed / 1 failed / 9 ignored**,
144 target summaries, exit101 after1,503.692615 seconds. The only failed test was
`test_documentation_links_and_anchors_are_valid`:85 links referenced tracked
files excluded by the sparse checkout. Every other target, including cold
consumers, passed. The original state/record/stdout/stderr stay unchanged as a
failed attempt; this was not a production source repair.

Root then reclaimed3,458 closed cache entries and ran `git sparse-checkout disable`.
Its before inventory observed2,057 missing tracked paths. Its after observation
verified all3,780 tracked blobs, modes and symlink targets,832,877,274bytes, against
the same Git tree. The independent successor runner repeated this verification
and stored Q/architecture-c12c-workspace-complete-checkout.json, SHA-256
`493d8174a57de2cfa75ad92291bb589acffea8d057a380da8e2f9612f8a3789d`.
Source/pins stayed clean; no test, assertion, command or timeout was weakened.

The new runner f357fa70... launched the same all-feature, no-fail-fast command,
same recorded Rust environment and7,200-second wrapper limit at08:15UTC. Its
new documentation target has passed. **The complete repeat is still running**;
partial success is not a whole-workspace pass. Its canonical mode/check name is
workspace, with output Q/architecture-c12c-workspace-complete-state.json.
Only explicit phase-map-v2 selects this successor. No final aggregate is stated.

Writer v3, when separately authorized after every gate passes, must retain both
attempts, actual successor totals, unchanged-command/environment/timeout checks,
the full checkout proof and root recovery observations. Its current-source day
registry separates original7c02 preparation/preview names from the new same-source
workspace-complete day namespaces. No day launch or24-hour result follows from
checkout recovery, the deadline preview or documentation target success.

Prepared writers/common/packager/phase maps remain separate versions; the first
history draft remains preserved. The six living documents continue to mark the
workspace pending until the actual successor terminal record is available.
