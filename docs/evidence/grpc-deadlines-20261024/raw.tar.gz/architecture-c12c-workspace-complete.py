#!/usr/bin/env python3
"""Separate complete-checkout workspace attempt; --execute needs a root grant.

Retains the failed sparse-checkout attempt. Imports the frozen C12c controller
without editing it. All output names are exclusive and no test is skipped.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import stat
import subprocess
import sys
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
CONTROLLER = Q / 'architecture-c12c-qualification.py'
CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
SOURCE = '7c02eb387a6785d6e914146babe34f0902a6dd62'
PINS_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
STATE = Q / 'architecture-c12c-workspace-complete-state.json'
PREFIX = Q / 'architecture-c12c-workspace-complete'
PROOF = Q / 'architecture-c12c-workspace-complete-checkout.json'


def complete_checkout(d):
    """Check actual working bytes against every pinned Git blob, not just HEAD."""
    tree = d['TREE']
    assert d['source']() == {'head': SOURCE, 'status': ''}
    sparse = subprocess.run(['git', 'config', '--bool', '--get', 'core.sparseCheckout'],
                            cwd=tree, capture_output=True, text=True)
    assert sparse.returncode in (0, 1) and sparse.stdout.strip() in ('', 'false'), sparse.stdout
    raw = subprocess.check_output(['git', 'ls-tree', '-r', '-z', 'HEAD'], cwd=tree)
    files = []
    for item in raw.split(b'\0'):
        if not item:
            continue
        meta, name = item.split(b'\t', 1)
        mode, kind, expected = meta.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755', '120000'), meta
        relative = os.fsdecode(name)
        path = tree / relative
        status = path.lstat()  # Missing tracked files fail here.
        if mode == '120000':
            assert stat.S_ISLNK(status.st_mode), relative
            data = os.fsencode(os.readlink(path))
        else:
            assert stat.S_ISREG(status.st_mode), relative
            assert bool(status.st_mode & 0o111) == (mode == '100755'), relative
            data = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        assert actual == expected, relative
        files.append({'path': relative, 'mode': mode, 'git_blob': actual, 'bytes': len(data)})
    assert files and any(row['path'] == 'docs/evidence/README.md' for row in files)
    return {'schema': 'pbrs.c12c-complete-checkout.v1', 'created_utc': d['now'](),
            'qualified': False, 'source': d['source'](), 'tree': d['git']('rev-parse', 'HEAD^{tree}'),
            'sparse_checkout': False, 'tracked_blob_count': len(files), 'tracked_blobs': files}


def execute(d):
    assert d['digest'](CONTROLLER) == CONTROLLER_SHA
    assert d['digest'](d['PINS']) == PINS_SHA
    pins = d['load_pins']()
    assert pins['candidate_runtime'] == SOURCE
    oldpath = Q / 'architecture-c12c-workspace-state.json'
    old = json.loads(oldpath.read_text())
    assert old['mode'] == 'workspace' and old['state'] == 'failed'
    assert len(old['checks']) == 1
    check = old['checks'][0]
    assert check['name'] == 'workspace' and check['exit_code'] == 101
    assert check['totals']['failed'] == 1
    oldprefix = Q / 'architecture-c12c-workspace'
    oldrecord = json.loads(oldprefix.with_suffix('.json').read_text())
    assert not oldrecord.get('timeout') and oldrecord['exit_code'] == 101
    output = oldprefix.with_suffix('.stdout').read_text()
    failures = set(re.findall(r'^test (\S+) \.\.\. FAILED$', output, re.MULTILINE))
    assert failures == {'test_documentation_links_and_anchors_are_valid'}, failures
    oldrefs = [d['ref'](oldpath)] + [d['ref'](oldprefix.with_suffix(s)) for s in ('.json', '.stdout', '.stderr')]
    assert not STATE.exists() and not PROOF.exists()
    assert not any(PREFIX.with_suffix(s).exists() for s in ('.json', '.stdout', '.stderr'))
    proof = complete_checkout(d)
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3, 'need 8GiB free before cold consumer/full-workspace tests'
    d['exclusive'](PROOF, proof)
    state = {'mode': 'workspace', 'state': 'running', 'qualified': False,
             'started_utc': d['now'](), 'supervisor_pid': os.getpid(),
             'source': d['source'](), 'pins': d['ref'](d['PINS']), 'checks': [],
             'free_bytes_before': shutil.disk_usage(ROOT).free,
             'attempt': 'complete_checkout_after_preserved_sparse_failure',
             'controller': d['ref'](CONTROLLER), 'runner': d['ref'](Path(__file__).resolve()),
             'previous_attempt': oldrefs, 'complete_checkout': d['ref'](PROOF), 'active': 'workspace'}
    d['exclusive'](STATE, state)
    try:
        command = [str(d['RUN']), 'nice', '-n', '10', 'cargo', '+stable', 'test', '--locked',
                   '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4']
        child = subprocess.run([sys.executable, str(d['RECORD']), str(PREFIX), '7200', *command],
                               cwd=d['TREE'], env=d['environment'](jobs=2))
        record = json.loads(PREFIX.with_suffix('.json').read_text())
        parsed = d['summaries'](PREFIX.with_suffix('.stdout'))
        entry = {'name': 'workspace', 'command': command, 'exit_code': record['exit_code'],
                 'duration_seconds': record['duration_seconds'], 'summaries': parsed,
                 'targets': len(parsed), 'totals': {key: sum(row[key] for row in parsed)
                     for key in ('passed', 'failed', 'ignored')},
                 'source_after': d['source'](),
                 'files': [d['ref'](PREFIX.with_suffix(s)) for s in ('.json', '.stdout', '.stderr')],
                 'free_bytes_after': shutil.disk_usage(ROOT).free}
        state['checks'].append(entry)
        d['atomic'](STATE, state)
        assert child.returncode == record['exit_code'] == 0 and not record.get('timeout'), entry
        assert record['source'] == {'head': SOURCE, 'diff_sha256': d['EMPTY'], 'untracked': {}}
        assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed), entry
        assert parsed and entry['totals']['passed'] > 0, entry
        assert d['digest'](CONTROLLER) == CONTROLLER_SHA and d['digest'](d['PINS']) == PINS_SHA
        d['load_pins']()
        for ref in oldrefs:
            assert d['ref'](Path(ref['path'])) == ref
        assert complete_checkout(d)['tracked_blobs'] == proof['tracked_blobs']
        state.update(state='passed', active=None, completed_utc=d['now'](),
                     source_after=d['source'](), free_bytes_after=shutil.disk_usage(ROOT).free)
        d['atomic'](STATE, state)
    except BaseException as error:
        state.update(state='failed', error=repr(error), completed_utc=d['now'](),
                     source_after=d['source'](), free_bytes_after=shutil.disk_usage(ROOT).free)
        d['atomic'](STATE, state)
        traceback.print_exc()
        return 1
    return 0


def main():
    assert __debug__, 'do not run with Python -O'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    assert hashlib.sha256(CONTROLLER.read_bytes()).hexdigest() == CONTROLLER_SHA
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True,
                          'mode': 'workspace', 'state_path': str(STATE), 'qualified': False}, indent=2))
        return 0
    return execute(runpy.run_path(str(CONTROLLER), run_name='c12c_frozen_controller'))


if __name__ == '__main__':
    raise SystemExit(main())
