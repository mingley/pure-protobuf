#!/usr/bin/env python3
"""Reclaim closed debug artifacts before the fresh sanitizer/workspace checks."""
import hashlib
from pathlib import Path
import runpy
import sys

if not __debug__:
    raise RuntimeError('Assertion gates require ordinary Python execution.')

ROOT = Path('/workspace/pure-protobuf')
HELPER = ROOT / 'work/qualification/architecture-c12c-reclaim-closed-cache.py'
EXPECTED = '4989f4a7d5fc71ec6c0df5a139fd5dc6edfe4148b91580b52c3bf2d5fa3c6dd7'
if hashlib.sha256(HELPER.read_bytes()).hexdigest() != EXPECTED:
    raise RuntimeError('Reviewed cache helper changed.')
scope = runpy.run_path(str(HELPER))
assert scope['main'].__globals__['CACHES'] is scope['CACHES']
scope['CACHES'].clear()
scope['CACHES']['stable-debug'] = ROOT / 'work/stable-target/debug'
scope['REQUIRED']['stable-debug'] = [
    'prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native',
]
if not (len(sys.argv) in (3, 4) and sys.argv[1:3] == ['--cache', 'stable-debug']
        and (len(sys.argv) == 3 or sys.argv[3] == '--execute')):
    raise RuntimeError('Use --cache stable-debug [--execute].')
raise SystemExit(scope['main']())
