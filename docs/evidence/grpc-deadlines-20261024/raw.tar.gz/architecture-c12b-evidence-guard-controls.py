#!/usr/bin/env python3
"""Bounded synthetic evidence-guard controls; not runtime qualification."""
import ast
import copy
import hashlib
import io
import json
from pathlib import Path
import runpy
import tarfile
import tempfile
from unittest.mock import patch

Q = Path('/workspace/pure-protobuf/work/qualification')
CANDIDATE = '40f219fa515034b556df7f39e3e3947e364a2ce1'
BASELINE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
C = runpy.run_path(str(Q / 'architecture-c12b-evidence-common.py'))
G = C['load_pins'].__globals__
rows = []


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def put(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(encoded(value))


def control(name, function, reject=False):
    try:
        function()
    except (AssertionError, FileNotFoundError, ValueError, KeyError) as error:
        if not reject:
            raise
        rows.append({'name': name, 'expected': 'reject', 'observed': 'rejected',
                     'error_type': type(error).__name__})
    else:
        assert not reject, 'failed to reject ' + name
        rows.append({'name': name, 'expected': 'accept', 'observed': 'accepted'})


with tempfile.TemporaryDirectory(prefix='resource-c12b-evidence-guards-', dir=Q) as directory:
    root = Path(directory)
    q = root / 'qualification'
    q.mkdir()
    baseline, checkout = root / 'baseline', root / 'candidate'
    baseline.mkdir(); checkout.mkdir()
    for tree in [baseline, checkout]:
        (tree / 'harness').write_bytes(b'identical harness\n')
    (q / 'baseline-bin').write_bytes(b'synthetic nonexecutable identity only')
    put(q / 'baseline-build.json', {'synthetic': True})
    pin_path = q / 'architecture-c12b-source-pins.json'
    tools = {'rustc': 'rustc 1.99.1 synthetic', 'cargo': 'cargo 1.99.1 synthetic'}
    with patch.dict(G, ROOT=root, Q=q, BASELINE_TREE=baseline):
        pins = {'schema': 'pbrs.c12b-source-pins.v1', 'qualified': False,
                'candidate_runtime': CANDIDATE, 'baseline_runtime': BASELINE,
                'candidate_tree': 'a' * 40, 'asan_extra_targets': ['server_deadline', 'server_deadline_extended', 'server_terminal_accounting'],
                'inputs': [], 'baseline_build': C['ref'](q / 'baseline-build.json'),
                'baseline_binary': C['ref'](q / 'baseline-bin'),
                'identical_harness': {'harness': C['digest'](checkout / 'harness')},
                'tools_required': tools}
        put(pin_path, pins)
        source = lambda tree: {'head': CANDIDATE if tree == checkout else BASELINE, 'status': ''}
        def git(*args, cwd=None):
            return ('a' * 40 + '\n').encode() if args[0] == 'rev-parse' else b'identical harness\n'
        def load():
            return C['load_pins'](pin_path, C['digest'](pin_path), checkout, {})
        with patch.dict(G, source=source, git=git):
            control('correct-source-pins-harness', load)
            control('wrong-pin-digest', lambda: C['load_pins'](pin_path, '0' * 64, checkout, {}), True)
            with patch.dict(G, source=lambda tree: {'head': 'f' * 40, 'status': ''}):
                control('wrong-source', load, True)
            changed = copy.deepcopy(pins); changed['candidate_runtime'] = 'f' * 40
            put(pin_path, changed); control('wrong-candidate-in-pin', load, True); put(pin_path, pins)
            changed = copy.deepcopy(pins); changed['asan_extra_targets'].pop()
            put(pin_path, changed); control('missing-terminal-accounting-asan-target', load, True); put(pin_path, pins)
            (checkout / 'harness').write_bytes(b'mismatch')
            control('harness-mismatch', load, True)
            (checkout / 'harness').write_bytes(b'identical harness\n')
        phase_map = q / 'phase-map.json'
        mapping = {'source': CANDIDATE, 'qualified': False,
                   'phases': {name: 'architecture-c12b-' + name + '-state.json' for name in C['REQUIRED']}}
        put(phase_map, mapping)
        control('complete-explicit-phase-map', lambda: C['phase_paths'](phase_map, CANDIDATE, {}))
        control('no-phase-map-no-fallback', lambda: C['phase_paths'](None, CANDIDATE, {}), True)
        changed = copy.deepcopy(mapping); changed['source'] = BASELINE
        put(phase_map, changed); control('wrong-phase-map-source', lambda: C['phase_paths'](phase_map, CANDIDATE, {}), True)
        changed = copy.deepcopy(mapping); changed['phases'].pop('cold-native')
        put(phase_map, changed); control('incomplete-phase-map', lambda: C['phase_paths'](phase_map, CANDIDATE, {}), True)
        changed = copy.deepcopy(mapping); changed['phases']['native'] = '../bad-state.json'
        put(phase_map, changed); control('phase-map-traversal', lambda: C['phase_paths'](phase_map, CANDIDATE, {}), True)
        put(phase_map, mapping)
        log = q / 'workspace.stdout'; log.write_text('test result: ok. 2 passed; 0 failed; 1 ignored;\n')
        record_path = q / 'workspace.json'
        args = ['cargo', 'test', '--workspace', '--all-features', '--no-fail-fast']
        record = {'command': args, 'exit_code': 0, 'duration_seconds': 1,
                  'source': {'head': CANDIDATE, 'diff_sha256': C['EMPTY'], 'untracked': {}}}
        put(record_path, record)
        summary = C['summaries'](log)
        state = {'state': 'passed', 'active': None, 'qualified': False, 'mode': 'workspace',
                 'source': source(checkout), 'source_after': source(checkout), 'pins': C['ref'](pin_path),
                 'checks': [{'name': 'workspace', 'command': args, 'exit_code': 0,
                             'source_after': source(checkout), 'files': [C['ref'](record_path), C['ref'](log)],
                             'summaries': summary, 'totals': C['totals'](summary), 'targets': 1}]}
        state_path = q / 'workspace-state.json'
        put(state_path, state)
        validate_phase = lambda: C['validate_phase']('workspace', state_path, pins, pin_path, {})
        control('terminal-successful-phase', validate_phase)
        for name, mutation in [('failed-phase', {'state': 'failed'}), ('incomplete-phase', {'active': 'workspace'}),
                               ('phase-source-mismatch', {'source_after': {'head': BASELINE, 'status': ''}}),
                               ('missing-required-check', {'checks': []})]:
            put(state_path, state | mutation); control(name, validate_phase, True)
        put(state_path, state)
        # Narrow sequencing test: mocks all unrelated gate validators. This proves
        # required-cold is requested even when its state path does not exist.
        called = []
        def phase_stub(name, *unused):
            called.append(name)
            if name == 'cold-native':
                raise FileNotFoundError('synthetic required cold state absent')
            return {}
        with patch.dict(G, load_pins=lambda *unused: pins, validate_phase=phase_stub):
            control('require-cold-does-not-skip-missing-state',
                    lambda: C['validate_all'](pin_path, '0' * 64, checkout, phase_map, True), True)
        assert called[-1] == 'cold-native'
        # Minimal complete native ledger: one workload, two repeats, two counts,
        # two sources. These counts are synthetic, not retained campaign results.
        cell = {'shape': 'unary', 'pair': 'native-prost-native-prost'}
        cells_path = q / 'architecture-c12b-native-cells.json'; put(cells_path, [cell])
        campaign_dir = q / 'synthetic-native'; campaign_dir.mkdir()
        expected_cells = [dict(cell, repeat=i) for i in range(2)]
        versions = {name: {'source': {'commit': commit}, 'build_record': {
            'source': {'commit': commit}, 'tools': tools, 'binary_sha256': sha}, 'binary_sha256': sha}
            for name, commit, sha in [('baseline', BASELINE, pins['baseline_binary']['sha256']), ('candidate', CANDIDATE, 'b' * 64)]}
        capture_rows = []
        actual = {v: {k: 0 for k in C['ACCOUNTING']} for v in versions}
        for version in versions:
            for count in [25, 50]:
                for i, current in enumerate(expected_cells):
                    name = f'{version}-{count}-{i}.json'
                    metrics = {k: count if n < 4 else 0 for n, k in enumerate(C['ACCOUNTING'])}
                    put(campaign_dir / name, {'passed': True, 'cell': current, 'metrics': metrics, 'client_exit_code': 0})
                    capture_rows.append({'path': name, 'passed': True, 'version': version, 'count': count})
                    for k, v in metrics.items(): actual[version][k] += v
        campaign = {'state': 'finished', 'passed': True, 'qualified': False, 'versions': versions,
                    'controller_sha256': 'c' * 64, 'expected_captures': 8, 'phase': 'native',
                    'abba': True, 'pilot': False, 'workloads_input': {'sha256': C['digest'](cells_path)},
                    'rpc_counts': [25, 50], 'cells': expected_cells, 'captures': capture_rows}
        campaign_path = campaign_dir / 'campaign.json'; put(campaign_path, campaign)
        summary_path = q / 'synthetic-native-summary.json'
        summary = {'state': 'finished', 'passed': True, 'controller_passed': True, 'qualified': False,
                   'source_pins': versions, 'controller_sha256': 'c' * 64, 'expected_captures': 8,
                   'retained_captures': 8, 'phase': 'native', 'actual_rpc_totals': actual,
                   'failed_captures': [], 'missing_keys': [], 'extra_keys': [], 'status_errors': []}
        put(summary_path, summary)
        validate_campaign = lambda: C['validate_campaign']('native', {'summary': C['ref'](summary_path)}, pins, 'b' * 64, {})
        control('balanced-complete-synthetic-capture-ledger', validate_campaign)
        changed = copy.deepcopy(campaign); changed['captures'].pop()
        put(campaign_path, changed); control('missing-capture', validate_campaign, True)
        changed = copy.deepcopy(campaign); changed['versions']['candidate']['build_record']['tools']['cargo'] = 'wrong'
        put(campaign_path, changed)
        changed_summary = copy.deepcopy(summary); changed_summary['source_pins'] = changed['versions']; put(summary_path, changed_summary)
        control('campaign-toolchain-mismatch', validate_campaign, True)
        put(campaign_path, campaign); put(summary_path, summary)
        run_path = campaign_dir / capture_rows[0]['path']; run = json.loads(run_path.read_text())
        changed_run = copy.deepcopy(run); changed_run['metrics']['successful_rpcs'] -= 1
        put(run_path, changed_run); control('per-capture-count-mismatch', validate_campaign, True); put(run_path, run)
        changed_summary = copy.deepcopy(summary); changed_summary['actual_rpc_totals']['baseline']['successful_rpcs'] += 1
        put(summary_path, changed_summary); control('aggregate-rpc-count-mismatch', validate_campaign, True); put(summary_path, summary)
        (cells_path).write_bytes(b'[]\n'); control('cell-file-sha-mismatch', validate_campaign, True)
    # Execute only the generated standalone checker in this synthetic directory.
    package_ast = ast.parse((Q / 'package-architecture-c12b-evidence.py').read_text())
    checker = next(n.value.value for n in package_ast.body if isinstance(n, ast.Assign)
                   and any(isinstance(t, ast.Name) and t.id == 'CHECK_PY' for t in n.targets))
    ns = {'__name__': 'synthetic_checker_control'}
    exec(compile(checker, 'synthetic-generated-checker', 'exec'), ns)
    capsule = root / 'capsule'; capsule.mkdir()
    def make_archive(name='record.txt', content=b'synthetic evidence', link=False):
        archive = capsule / 'raw.tar.gz'
        with tarfile.open(archive, 'w:gz') as stream:
            info = tarfile.TarInfo(name); info.size = len(content)
            if link: info.type = tarfile.SYMTYPE; info.linkname = 'elsewhere'; info.size = 0
            stream.addfile(info, None if link else io.BytesIO(content))
        manifest = {'qualified': False, 'archive': {'name': archive.name, 'bytes': archive.stat().st_size,
                     'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
                    'files': [{'path': name, 'bytes': len(content), 'sha256': hashlib.sha256(content).hexdigest()}],
                    'logical_bytes': len(content)}
        put(capsule / 'manifest.json', manifest)
    make_archive(); control('standalone-checker-valid-regular-capsule', lambda: ns['check'](capsule))
    manifest = json.loads((capsule / 'manifest.json').read_text()); manifest['archive']['name'] = '../raw.tar.gz'
    put(capsule / 'manifest.json', manifest)
    control('manifest-archive-link-traversal', lambda: ns['check'](capsule), True)
    make_archive(); (capsule / 'raw.tar.gz').write_bytes(b'tampered')
    control('archive-hash-tamper', lambda: ns['check'](capsule), True)
    make_archive(); manifest = json.loads((capsule / 'manifest.json').read_text()); manifest['files'][0]['sha256'] = '0' * 64
    put(capsule / 'manifest.json', manifest)
    control('manifest-member-hash-tamper', lambda: ns['check'](capsule), True)
    make_archive(link=True); control('tar-symlink-member-rejected', lambda: ns['check'](capsule), True)
    make_archive('../unsafe'); control('tar-parent-member-rejected', lambda: ns['check'](capsule), True)
result = {'state': 'passed', 'qualified': False, 'scope': 'Bounded synthetic evidence-guard controls only; temporary inputs, mocked Git/source and cold-gate sequencing; no runtime, compiler, profiler, real writer/packager publication or actual qualification.',
          'controls': rows, 'temporary_sandbox_removed': True,
          'helper_sources': {name: hashlib.sha256((Q / name).read_bytes()).hexdigest() for name in
             ['architecture-c12b-evidence-common.py', 'architecture-c12b-write-results.py', 'package-architecture-c12b-evidence.py']}}
output = Q / 'architecture-c12b-evidence-guard-controls.json'
with output.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps({'state': 'passed', 'controls': len(rows), 'scope': 'synthetic only', 'output': str(output)}))
