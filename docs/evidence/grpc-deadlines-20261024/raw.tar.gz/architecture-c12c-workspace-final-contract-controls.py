#!/usr/bin/env python3
"""Bounded mocked contract guards; no actual workspace/proof/gate execution."""
import copy
import hashlib
import json
from pathlib import Path
import runpy
import tempfile
from unittest.mock import patch

REALQ=Path('/workspace/pure-protobuf/work/qualification')
module=REALQ/'architecture-c12c-evidence-common-workspace-final.py'
C=runpy.run_path(str(module));G=C['workspace_final_contract'].__globals__
runtime='7c02eb387a6785d6e914146babe34f0902a6dd62';repo=C['WORKSPACE_REPOSITORY'];prior=C['WORKSPACE_PRIOR']
rows=[]

def test(name,call,reject=False):
    try:call()
    except (AssertionError,KeyError,FileNotFoundError) as error:
        assert reject,(name,error);rows.append({'name':name,'expected':'reject','observed':'rejected','error':type(error).__name__})
    else:
        assert not reject,name;rows.append({'name':name,'expected':'accept','observed':'accepted'})

with tempfile.TemporaryDirectory(prefix='resource-c12c-final-contract-',dir=REALQ) as temporary:
    root=Path(temporary);q=root/'qualification';q.mkdir();tree=root/'workspace-final';pin=q/'architecture-c12c-source-pins.json'
    clean={'head':repo,'status':''};runt={'head':runtime,'status':''}
    ref=lambda p:{'path':str(p),'bytes':1,'sha256':'f'*64}
    pinref=ref(pin)
    controller=ref(q/'architecture-c12c-qualification.py')
    runner=ref(q/'architecture-c12c-workspace-final.py');runner['sha256']='f70c4bdc2d86b62026dcec56a000adbfe9074cfcb98a3e593b8fc3899637dcda'
    inputsref=ref(q/'architecture-c12c-workspace-final-inputs.json');inputsref['sha256']='8d0a0b1eac7573bf124682e66163a60002ed1b317c991ce4e11446b2f3dd68e3'
    previous=[ref(q/(prefix+suffix)) for prefix in ['architecture-c12c-workspace','architecture-c12c-workspace-complete'] for suffix in ['-state.json','.json','.stdout','.stderr']]
    fixture=C['WORKSPACE_FIXTURE'];evidence=C['WORKSPACE_EVIDENCE'];allowed=C['WORKSPACE_ALLOWED']
    blob=lambda p,b:{'path':p,'mode':'100644','git_blob':b*40,'bytes':1}
    base={fixture:blob(fixture,'a'),'docs/evidence/README.md':blob('docs/evidence/README.md','a')}
    for i in range(3778):base[f'synthetic/{i:04d}']=blob(f'synthetic/{i:04d}','a')
    pmap=dict(base)
    for path in evidence:pmap[path]=blob(path,'b')
    fmap=dict(pmap);fmap[fixture]=blob(fixture,'c')
    maps={runtime:base,prior:pmap,repo:fmap}
    lists={k:sorted(v.values(),key=lambda r:r['path']) for k,v in maps.items()}
    pins={'candidate_runtime':runtime,'candidate_tree':'runtime-tree','inputs':[controller]}
    inputs={'schema':'pbrs.c12c-workspace-final-inputs.v1','qualified':False,'runtime_source':runtime,'repository_source':repo,'prior_repository_source':prior,
            'fixture_sha256':hashlib.sha256(b'synthetic corrected fixture').hexdigest(),'previous_attempts':previous,'fixture_evidence':[],'passed_phase_states':[]}
    proof={'schema':'pbrs.c12c-workspace-final-equivalence.v1','qualified':False,'runtime_source':runtime,'repository_source':clean,'prior_repository_source':prior,
           'runtime_tree':'runtime-tree','repository_tree':'repo-tree','prior_repository_tree':'prior-tree',
           'runtime_git_blobs':lists[runtime],'prior_repository_git_blobs':lists[prior],'repository_git_blobs':lists[repo],
           'allowed_runtime_differences':sorted(allowed),'fixture_diff_from_prior':{'path':fixture,'from_blob':base[fixture]['git_blob'],'to_blob':fmap[fixture]['git_blob']},
           'changed_entries':[{'path':p,'runtime':base.get(p),'prior_repository':pmap.get(p),'repository':fmap.get(p)} for p in sorted(allowed)],
           'complete_checkout':{'tracked_blob_count':3790,'total_tracked_bytes':3790,'tracked_blobs':lists[repo]},
           'source_before':clean,'source_after':clean,'fixture_evidence':[],'pins':pinref,'inputs':inputsref,'controller':controller,'runner':runner}
    before=dict(proof,physical_verification_phase='before');after=dict(proof,physical_verification_phase='after')
    bp=q/'architecture-c12c-workspace-final-equivalence.json';ap=q/'architecture-c12c-workspace-final-equivalence-after.json'
    state={'schema':'pbrs.c12c-workspace-final-state.v1','mode':'workspace','state':'passed','active':None,'qualified':False,
           'runtime_source':runtime,'source':clean,'source_after':clean,'checkout':str(tree),'free_bytes_before':8*1024**3,
           'pins':pinref,'runner':runner,'controller':controller,'inputs':inputsref,'previous_attempts':previous,
           'runtime_equivalence':ref(bp),'runtime_equivalence_after':ref(ap)}
    data={str(q/'architecture-c12c-workspace-final-inputs.json'):inputs,str(bp):before,str(ap):after}
    for prefix,failed in [('architecture-c12c-workspace','test_documentation_links_and_anchors_are_valid'),('architecture-c12c-workspace-complete','lb_selection_skips_unregistered_and_typed')]:
        data[str(q/(prefix+'-state.json'))]={'state':'failed','source':runt,'source_after':runt,'pins':pinref,'checks':[{'name':'workspace','exit_code':101,'targets':144,'totals':{'passed':3811,'failed':1,'ignored':9}}]}
        (q/(prefix+'.stdout')).write_text(f'test {failed} ... FAILED\n')
    for color,code in [('red',101),('green',0)]:data[str(q/('architecture-c12c-lb-snapshot-'+color+'.json'))]={'exit_code':code,'source':{'head':prior}}
    def summaries(path):
        name=Path(path).name
        counts=[(0,1,0)] if 'snapshot-red' in name else [(1,0,0),(29,0,0)] if 'snapshot-green' in name else [(3811,1,9)]
        return [{'passed':a,'failed':b,'ignored':c} for a,b,c in counts]
    def git(*args,cwd=None):
        if args[0]=='show':return b'synthetic corrected fixture'
        if args==('rev-parse',repo+'^'):return (prior+'\n').encode()
        if args[0]=='rev-parse' and ':pbrs-grpc/src' in args[1]:return b'identical-production-tree\n'
        return ({repo:'repo-tree',prior:'prior-tree',runtime:'runtime-tree'}[args[1].removesuffix('^{tree}') ]+'\n').encode()
    fake={'ROOT':root,'Q':q,'PINS':pin,'WORKSPACE_TREE':tree,'source':lambda tree:clean,'ref':ref,'read_json':lambda path,observed:data[str(path)],
          'verify_reference':lambda item,observed:None,'workspace_git_blobs':lambda commit:lists[commit],'git':git,'summaries':summaries}
    with patch.dict(G,fake):
        call=lambda:C['workspace_final_contract'](state,pins,{})
        test('consistent mocked distinct-repository contract',call)
        for name,key,value in [('runtime mislabeled as workspace','source',runt),('repository mislabeled as runtime','runtime_source',repo),('running state','state','running'),('qualified claim','qualified',True),('insufficient entry bytes','free_bytes_before',8*1024**3-1),('wrong checkout','checkout',str(root/'wrong'))]:
            old=state[key];state[key]=value;test(name,call,True);state[key]=old
        old=state['previous_attempts'];state['previous_attempts']=old[:-1];test('missing failed-attempt reference',call,True);state['previous_attempts']=old
        for name,key,value in [('proof wrong repository','repository_source',runt),('proof unsafe allowlist','allowed_runtime_differences',sorted(allowed|{'pbrs-grpc/src/lib.rs'})),('proof changed maps','repository_git_blobs',lists[prior]),('proof dirty after','source_after',dict(clean,status=' M source')),('proof wrong phase','physical_verification_phase','before')]:
            old=after[key];after[key]=value;test(name,call,True);after[key]=old
        old=after['complete_checkout'];after['complete_checkout']=dict(old,total_tracked_bytes=3791);test('wrong complete inventory size',call,True);after['complete_checkout']=old
        old=lists[repo];bad=dict(fmap);bad['synthetic/0000']=blob('synthetic/0000','d');lists[repo]=sorted(bad.values(),key=lambda r:r['path']);test('unallowed production blob difference',call,True);lists[repo]=old
        old=lists[repo];lists[repo]=lists[prior];test('missing corrected fixture blob',call,True);lists[repo]=old
        mapping={'schema':'pbrs.c12c-workspace-final-phase-map.v1','runtime_source':runtime,'workspace_repository_source':repo,'qualified':False,
                 'phases':{name:'architecture-c12c-'+('workspace-final' if name=='workspace' else name)+'-state.json' for name in C['REQUIRED']}}
        mp=q/'synthetic-map.json';data[str(mp)]=mapping
        test('explicit runtime and actual repository map',lambda:C['phase_paths'](mp,runtime,{}))
        old=mapping['workspace_repository_source'];mapping['workspace_repository_source']=runtime;test('map conflates repository with runtime',lambda:C['phase_paths'](mp,runtime,{}),True);mapping['workspace_repository_source']=old
        old=mapping['phases']['workspace'];mapping['phases']['workspace']='architecture-c12c-workspace-complete-state.json';test('map falls back to failed older attempt',lambda:C['phase_paths'](mp,runtime,{}),True);mapping['phases']['workspace']=old
result={'state':'passed','qualified':False,'scope':'Bounded mocked schema/allowlist guards only. Git metadata, source status, refs and proof inputs are synthetic; this is not an actual equivalence proof, workspace run, writer/packager or qualification.',
        'controls':rows,'temporary_sandbox_removed':True,'validator_source':{'path':str(module),'sha256':hashlib.sha256(module.read_bytes()).hexdigest()}}
with (REALQ/'architecture-c12c-workspace-final-contract-controls.json').open('x') as f:json.dump(result,f,indent=2);f.write('\n')
print(json.dumps({'state':'passed','synthetic_controls':len(rows),'qualified':False}))
