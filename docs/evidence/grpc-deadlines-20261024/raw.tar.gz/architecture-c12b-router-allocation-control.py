#!/usr/bin/env python3
"""Selected unchanged-harness N/2N allocation control; run only after capture release."""
import argparse
import hashlib
import importlib.util
import json
import os
import platform
from pathlib import Path
import random
import shutil
from types import SimpleNamespace


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    out = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(out)
    return out


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-checkout', required=True, type=Path)
    parser.add_argument('--binary', required=True, type=Path)
    parser.add_argument('--build-record', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    source = args.source_checkout.resolve(strict=True)
    binary = args.binary.resolve(strict=True)
    build_record = args.build_record.resolve(strict=True)
    harness = source / 'scripts/grpc-load-smoke.py'
    ledger_path = source / 'scripts/dominance-ledger.py'
    smoke = module('router_control_smoke', harness)
    ledger = module('router_control_ledger', ledger_path)
    build = smoke.verified_build(build_record, binary, source)
    pins = {'binary': sha(binary), 'harness': sha(harness), 'ledger': sha(ledger_path),
            'controller': sha(Path(__file__))}
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, output / 'controller.py')
    cells = [dict(pair=['tonic', 'prost', server, 'prost'], shape=shape,
                  payload_bytes=1024, tls=False, compression='identity',
                  connections=1, in_flight=1, repeat=repeat)
             for server in ('native', 'tonic') for shape in ('unary', 'bidi')
             for repeat in (0, 1)]
    random.Random(20261009).shuffle(cells)
    for count in (25, 50):
        directory = output / f'n-{count}'
        directory.mkdir()
        report = dict(schema='pbrs.load-smoke.v2', binary_sha256=pins['binary'],
                      harness_script_sha256=pins['harness'], head=build['source']['commit'],
                      dirty=False, source_verified=True, build_record=build,
                      host=platform.uname()._asdict(), cpu_affinity=sorted(os.sched_getaffinity(0)),
                      seed=20261009, cells=cells, rpc_count=count, duration_per_cell_seconds=60,
                      allocation_counts=True, context_switches=True, callgrind=None, strace=None,
                      strace_version=None, qualification={'qualified': False}, runs=[])
        save(directory / 'manifest.json', report)
        shutil.copy2(harness, directory / 'harness.py')
        settings = SimpleNamespace(binary=binary, source_checkout=source, duration=60,
                                   rpc_count=count, allocation_counts=True, context_switches=True,
                                   callgrind=None, strace=None)
        for index, cell in enumerate(cells):
            child = directory / f'cell-{index:03d}'
            result = smoke.run_cell(settings, cell, child)
            report['runs'].append(dict(path=f'{child.name}/run.json', passed=result['passed']))
            save(directory / 'partial-report.json', report)
        smoke.verified_build(build_record, binary, source)
        report.update(binary_unchanged=sha(binary) == pins['binary'], source_unchanged=True,
                      harness_script_unchanged=sha(harness) == pins['harness'],
                      controller_unchanged=sha(Path(__file__)) == pins['controller'],
                      ledger_unchanged=sha(ledger_path) == pins['ledger'])
        report['passed'] = all(report[k] for k in ('binary_unchanged', 'source_unchanged',
                                                  'harness_script_unchanged', 'controller_unchanged',
                                                  'ledger_unchanged')) and all(r['passed'] for r in report['runs'])
        save(directory / 'report.json', report)
        if not report['passed']:
            raise RuntimeError(f'failed fixed-count capture: {directory}')
    comparison = ledger.compare(output / 'n-25', output / 'n-50')
    save(output / 'ledger.json', comparison)
    save(output / 'control.json', dict(qualified=False, passed=True, source=build['source'],
                                      pins=pins, captures=16, ledger='ledger.json'))


if __name__ == '__main__':
    main()
