//! Service dispatch: [`Service`], [`DynService`], [`Dispatch`], [`Single`].

#[allow(unused_imports, reason = "intra-doc links resolve against these names")]
use super::accept::Server;
#[allow(unused_imports, reason = "intra-doc links resolve against these names")]
use super::router::Router;
use super::rpc::Rpc;
use crate::limits::ByteBudgetTracker;
use crate::telemetry::LifecycleObserver;
use std::future::Future;
use std::pin::Pin;
use std::sync::Arc;
use std::task::{Context, Poll};

/// A gRPC service that can be served.
///
/// `protoc-gen-pbrs` emits one implementation per `service` in your `.proto`,
/// so the usual path is to implement the generated trait (`Greeter`) and let
/// the generated type (`GreeterServer`) implement this.
///
/// Implementing it by hand takes a name and a `match` on
/// [`Rpc::method`]:
///
/// ```
/// use pbrs_grpc::{HelloReply, HelloRequest, Request, Response, Rpc, Service, Status};
///
/// struct Echo;
///
/// impl Service for Echo {
///     const NAME: &'static str = "demo.Echo";
///
///     async fn call(&self, rpc: Rpc) {
///         match rpc.method() {
///             "Ping" => {
///                 rpc.unary(|req: Request<HelloRequest>| async move {
///                     let mut reply = HelloReply::new();
///                     reply.set_message(req.get_ref().name());
///                     Ok::<_, Status>(Response::new(reply))
///                 })
///                 .await;
///             }
///             _ => rpc.unimplemented(),
///         }
///     }
/// }
/// ```
pub trait Service: Send + Sync + 'static {
    /// Fully qualified proto service name, e.g. `helloworld.Greeter`.
    ///
    /// [`Router`] keys on this, and it is the `<service>` half of the
    /// `/<service>/<method>` request path.
    const NAME: &'static str;

    /// Extra `/<service>/` prefixes [`Router`] also mounts this service at.
    ///
    /// Default is empty. Generated `grpc.reflection.v1.ServerReflection`
    /// aliases `grpc.reflection.v1alpha.ServerReflection` so older grpcurl
    /// that falls back to v1alpha hits the same handler. That is a path
    /// alias, not a second proto and not a second `ServerReflectionServer`.
    /// An interceptor on the v1alpha path sees
    /// [`Rpc::service`] `grpc.reflection.v1alpha.ServerReflection` — Distinct
    /// from the v1 name, which is the path the peer sent.
    /// [`Server`] does not look up [`Self::NAME`] or these aliases: a lone
    /// reflection server already answers a v1alpha path. Distinct from
    /// mounting the same handler twice. Distinct from grpc-web, which is a
    /// second protocol, not a path alias.
    /// A wrapping [`Service`] should forward these like [`Self::NAME`].
    const ALIASES: &'static [&'static str] = &[];

    /// Dispatch one RPC.
    ///
    /// Match on [`Rpc::method`] and consume the [`Rpc`] with the call shape
    /// the method declares. Returning without consuming it resets the stream.
    fn call(&self, rpc: Rpc) -> impl Future<Output = ()> + Send;

    /// Build the per-method future used by both server and router.
    ///
    /// The default boxes [`Self::call`]. Generated services select the method
    /// before boxing, so unrelated methods do not enlarge each RPC's future.
    fn call_boxed(&self, rpc: Rpc) -> Pin<Box<dyn Future<Output = ()> + Send + '_>> {
        Box::pin(self.call(rpc))
    }
}

/// Object-safe [`Service`], so [`Router`] can hold a heterogeneous map.
pub(crate) trait DynService: Send + Sync + 'static {
    fn dispatch<'a>(&'a self, rpc: Rpc) -> Pin<Box<dyn Future<Output = ()> + Send + 'a>>;
}

impl<S: Service> DynService for S {
    fn dispatch<'a>(&'a self, rpc: Rpc) -> Pin<Box<dyn Future<Output = ()> + Send + 'a>> {
        start_service_call(self, rpc)
    }
}

/// What the accept loop hands each stream. A [`Server`] selects its service
/// statically; a [`Router`] looks it up. Both use per-method boxed futures.
pub(crate) trait Dispatch: Send + Sync + 'static {
    fn dispatch(&self, rpc: Rpc) -> impl Future<Output = ()> + Send;
    fn byte_budget(&self) -> ByteBudgetTracker {
        ByteBudgetTracker::default()
    }
    fn observer(&self) -> Option<&Arc<dyn LifecycleObserver>> {
        None
    }
    /// Channelz server id for per-connection sockets and per-RPC
    /// counters. `None` disables server-side channelz attribution.
    fn channelz_server(&self) -> Option<crate::channelz::ServerId> {
        None
    }
}

/// Build the handler future inside this frame.
///
/// `inline(never)` keeps `Service::call`'s state machine out of the
/// connection task. Generated services override [`Service::call_boxed`] and
/// box a single method; the default boxes [`Service::call`].
#[inline(never)]
fn start_service_call<'a, S: Service>(
    service: &'a S,
    rpc: Rpc,
) -> Pin<Box<dyn Future<Output = ()> + Send + 'a>> {
    let call = Arc::clone(&rpc.call_cancel);
    let future = service.call_boxed(rpc);
    if call.deadline.expired() {
        // A synchronous custom future constructor can consume its budget.
        // Keep that future unpolled until the terminal owner destroys it.
        Box::pin(async move {
            let _keep = future;
            std::future::pending::<()>().await;
        })
    } else {
        future
    }
}

/// Newtype so the monomorphic path gets its own [`Dispatch`] impl.
pub(crate) struct Single<S> {
    pub(crate) service: Arc<S>,
    pub(crate) interceptor: Option<Arc<dyn crate::Interceptor>>,
    pub(crate) response_interceptor: Option<crate::interceptor::ResponseHook>,
    pub(crate) observer: Option<Arc<dyn LifecycleObserver>>,
    pub(crate) byte_budget: ByteBudgetTracker,
    pub(crate) binlog: Option<Arc<crate::binlog::BinaryLogger>>,
    /// Channelz server registration, held for the whole serve so the
    /// server (and its sockets) stays listed while serving.
    pub(crate) channelz: Option<crate::channelz::ServerHandle>,
}

/// Handler future for one [`Single`] dispatch.
///
/// [`Rpc`] is consumed before this exists, so the accepted-call state
/// machine does not reserve space for the call record. The handler itself
/// stays in the box from [`start_service_call`].
enum SingleDispatch<'a> {
    Done,
    Call(Pin<Box<dyn Future<Output = ()> + Send + 'a>>),
}

impl Future for SingleDispatch<'_> {
    type Output = ();

    fn poll(self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
        match self.get_mut() {
            SingleDispatch::Done => Poll::Ready(()),
            SingleDispatch::Call(fut) => Pin::new(fut).poll(cx),
        }
    }
}

impl<S: Service> Dispatch for Single<S> {
    fn dispatch(&self, mut rpc: Rpc) -> impl Future<Output = ()> + Send {
        rpc.response_interceptor = self.response_interceptor.clone();
        rpc.observer = self.observer.clone();
        if let Some(tap) = self
            .binlog
            .as_ref()
            .and_then(|binlog| binlog.start_call(rpc.path(), crate::binlog::Logger::Server))
        {
            if let Some(peer) = rpc.remote_addr() {
                tap.set_peer(peer);
            }
            tap.log_client_header(
                rpc.metadata(),
                rpc.path(),
                rpc.authority().unwrap_or(""),
                rpc.effective_timeout(),
            );
            rpc.binlog = Some(tap);
            if let Some(logger) = &rpc.binlog {
                rpc.call_cancel.deadline.set_binlog(logger);
            }
        }
        let _ = rpc.deadline();
        if let Some(interceptor) = &self.interceptor {
            if let Err(status) = interceptor.intercept(&mut rpc) {
                rpc.reject(status);
                return SingleDispatch::Done;
            }
        }
        if rpc
            .deadline()
            .is_some_and(|at| tokio::time::Instant::now() >= at)
        {
            rpc.reject(crate::Status::deadline_exceeded());
            return SingleDispatch::Done;
        }
        // Box one method future. Awaiting `Service::call` here would embed
        // every method's state in this connection-task future and copy it
        // onto the heap on each RPC.
        SingleDispatch::Call(start_service_call(self.service.as_ref(), rpc))
    }

    fn observer(&self) -> Option<&Arc<dyn LifecycleObserver>> {
        self.observer.as_ref()
    }

    fn byte_budget(&self) -> ByteBudgetTracker {
        self.byte_budget.clone()
    }

    fn channelz_server(&self) -> Option<crate::channelz::ServerId> {
        self.channelz.as_ref().map(|handle| handle.id())
    }
}
