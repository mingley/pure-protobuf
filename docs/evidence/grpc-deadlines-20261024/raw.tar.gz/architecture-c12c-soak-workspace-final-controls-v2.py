#!/usr/bin/env python3
"""Isolated synthetic final-gate controls. No actual final workspace/day result."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import re
import shutil
import subprocess
import sys
import tempfile
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
COMMON = Q / 'architecture-c12c-soak-common-workspace-final.py'
CONTROLLER = Q / 'architecture-c12c-soaks-workspace-final.py'
spec = importlib.util.spec_from_file_location('final_workspace_synthetic_common', COMMON)
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)
ROWS = []


def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def check(label, action, expected):
    try:
        action()
        accepted = True
    except (AssertionError, KeyError, TypeError, ValueError, FileNotFoundError, RuntimeError):
        accepted = False
    assert accepted == expected, label
    ROWS.append({'case': label, 'expected_accept': expected, 'actual_accept': accepted})


def main():
    inventories, entries, trees = M.expected_equivalence()  # Git objects only, no checkout or build.
    assert [len(rows) for rows in inventories] == [3780, 3790, 3790] and len(entries) == 12
    ROWS.append({'case': 'pinned Git objects prove exact 11 archived-doc differences plus one test-only difference',
                 'expected_accept': True, 'actual_accept': True})
    names = ['Q', 'TREE', 'PINS', 'FINAL_TREE', 'FINAL_STATE', 'FINAL_RUNNER', 'FINAL_INPUTS',
             'FINAL_INPUTS_SHA', 'FINAL_PROOFS', 'ORIGINAL_CONTROLLER', 'actual_final_checkout']
    original = {name: getattr(M, name) for name in names}
    with tempfile.TemporaryDirectory(prefix='resource-architecture-c12c-workspace-final-controls-', dir=Q) as tmp:
        M.Q = Path(tmp)
        M.TREE = M.Q / 'synthetic-runtime-not-a-worktree'
        M.FINAL_TREE = M.Q / 'synthetic-final-not-a-worktree'
        M.FINAL_TREE.mkdir()
        M.PINS = M.Q / 'architecture-c12c-source-pins.json'
        shutil.copy2(original['PINS'], M.PINS)
        M.FINAL_STATE = M.Q / 'architecture-c12c-workspace-final-state.json'
        M.FINAL_RUNNER = M.Q / 'architecture-c12c-workspace-final.py'
        M.FINAL_INPUTS = M.Q / 'architecture-c12c-workspace-final-inputs.json'
        M.FINAL_PROOFS = [M.Q / p.name for p in original['FINAL_PROOFS']]
        M.ORIGINAL_CONTROLLER = M.Q / original['ORIGINAL_CONTROLLER'].name
        shutil.copy2(original['FINAL_RUNNER'], M.FINAL_RUNNER)
        shutil.copy2(original['ORIGINAL_CONTROLLER'], M.ORIGINAL_CONTROLLER)
        physical_calls = []
        M.actual_final_checkout = lambda expected: physical_calls.append(len(expected))
        fixture = M.FINAL_TREE / M.FIXTURE_PATH
        fixture.parent.mkdir(parents=True)
        fixture.write_bytes(subprocess.check_output(['git', 'show', M.FINAL_SOURCE + ':' + M.FIXTURE_PATH], cwd=M.ROOT))
        clean_runtime = {'head': M.RUNTIME_SOURCE, 'status': ''}
        clean_final = {'head': M.FINAL_SOURCE, 'status': ''}
        previous = []
        for base in ['architecture-c12c-workspace', 'architecture-c12c-workspace-complete']:
            old = json.loads((Q / (base + '-state.json')).read_text())
            prefix = M.Q / base
            for suffix in ['.json', '.stdout', '.stderr']:
                shutil.copy2((Q / base).with_suffix(suffix), prefix.with_suffix(suffix))
            record = json.loads(prefix.with_suffix('.json').read_text())
            record['cwd'] = str(M.TREE)
            write(prefix.with_suffix('.json'), record)
            old['pins'] = M.ref(M.PINS)
            old['checks'][0]['files'] = [M.ref(prefix.with_suffix(s)) for s in ['.json', '.stdout', '.stderr']]
            state_path = M.Q / (base + '-state.json')
            write(state_path, old)
            previous += [M.ref(state_path)] + old['checks'][0]['files']
        inputs = json.loads(original['FINAL_INPUTS'].read_text())
        review = M.Q / 'synthetic-fixture-review.txt'
        review.write_text('Synthetic reference only; no real final gate result.\n')
        inputs['fixture_evidence'] = [M.ref(review)]
        inputs['previous_attempts'] = previous
        inputs['passed_phase_states'] = []
        for name in ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native', 'asan']:
            file = M.Q / ('architecture-c12c-' + name + '-state.json')
            shutil.copy2(Q / file.name, file)
            inputs['passed_phase_states'].append(M.ref(file))
        write(M.FINAL_INPUTS, inputs)
        M.FINAL_INPUTS_SHA = M.digest(M.FINAL_INPUTS)  # Explicit synthetic manifest substitution.
        prefix = M.Q / 'architecture-c12c-workspace-final'
        text = (Q / 'architecture-c12c-workspace-complete.stdout').read_text()
        text = text.replace('test lb_selection_skips_unregistered_and_typed ... FAILED',
                            'test lb_selection_skips_unregistered_and_typed ... ok')
        text = re.sub(r'test result: FAILED\. (\d+) passed; 1 failed;',
                      lambda match: 'test result: ok. ' + str(int(match.group(1)) + 1) + ' passed; 0 failed;', text)
        prefix.with_suffix('.stdout').write_text(text)
        prefix.with_suffix('.stderr').write_text('Synthetic completed output; not an actual run.\n')
        record = json.loads((Q / 'architecture-c12c-workspace-complete.json').read_text())
        record.update(cwd=str(M.FINAL_TREE), exit_code=0,
                      source={'head': M.FINAL_SOURCE, 'diff_sha256': M.EMPTY, 'untracked': {}})
        write(prefix.with_suffix('.json'), record)
        summaries = [{'status': status, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
                     for status, passed, failed, ignored in re.findall(
                         r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
        totals = {key: sum(row[key] for row in summaries) for key in ['passed', 'failed', 'ignored']}
        assert len(summaries) == 144 and totals == {'passed': 3812, 'failed': 0, 'ignored': 9}
        state = {'schema': 'pbrs.c12c-workspace-final-state.v1', 'mode': 'workspace', 'state': 'passed',
                 'qualified': False, 'active': None, 'runtime_source': M.RUNTIME_SOURCE,
                 'source': clean_final, 'source_after': clean_final, 'checkout': str(M.FINAL_TREE),
                 'pins': M.ref(M.PINS), 'runner': M.ref(M.FINAL_RUNNER), 'controller': M.ref(M.ORIGINAL_CONTROLLER),
                 'inputs': M.ref(M.FINAL_INPUTS), 'previous_attempts': previous, 'free_bytes_before': 9 * 1024**3,
                 'checks': [{'name': 'workspace', 'command': M.WORKSPACE_COMMAND, 'exit_code': 0,
                             'source_after': clean_final, 'files': [M.ref(prefix.with_suffix(s)) for s in ['.json', '.stdout', '.stderr']],
                             'summaries': summaries, 'targets': 144, 'totals': totals}]}
        for path, phase in zip(M.FINAL_PROOFS, ['before', 'after']):
            proof = {'schema': 'pbrs.c12c-workspace-final-equivalence.v1', 'qualified': False,
                     'runtime_source': M.RUNTIME_SOURCE, 'runtime_tree': trees[0],
                     'prior_repository_source': M.PRIOR_SOURCE, 'prior_repository_tree': trees[1],
                     'repository_source': clean_final, 'repository_tree': trees[2],
                     'runtime_git_blobs': inventories[0], 'prior_repository_git_blobs': inventories[1],
                     'repository_git_blobs': inventories[2], 'allowed_runtime_differences': sorted(M.DOC_PATHS + [M.FIXTURE_PATH]),
                     'changed_entries': entries, 'fixture_diff_from_prior': {
                         'path': M.FIXTURE_PATH,
                         'from_blob': next(row['git_blob'] for row in inventories[1] if row['path'] == M.FIXTURE_PATH),
                         'to_blob': next(row['git_blob'] for row in inventories[2] if row['path'] == M.FIXTURE_PATH)},
                     'physical_verification_phase': phase, 'source_before': clean_final, 'source_after': clean_final,
                     'complete_checkout': {'tracked_blob_count': len(inventories[2]),
                         'total_tracked_bytes': sum(row['bytes'] for row in inventories[2]), 'tracked_blobs': inventories[2]},
                     'fixture_evidence': inputs['fixture_evidence'], 'pins': M.ref(M.PINS), 'inputs': M.ref(M.FINAL_INPUTS),
                     'runner': M.ref(M.FINAL_RUNNER), 'controller': M.ref(M.ORIGINAL_CONTROLLER)}
            write(path, proof)
            state['runtime_equivalence' if phase == 'before' else 'runtime_equivalence_after'] = M.ref(path)
        write(M.FINAL_STATE, state)
        data = {'candidate_runtime': M.RUNTIME_SOURCE, 'candidate_tree': trees[0]}
        action = lambda: M.gate('workspace', data, M.digest(M.PINS))
        check('full synthetic final gate accepted only with both histories and separate identities', action, True)
        assert physical_calls == [3790]
        for label, path, value in [
            ('runtime mislabeled as repository rejected', ['source', 'head'], M.RUNTIME_SOURCE),
            ('repository mislabeled as runtime rejected', ['runtime_source'], M.FINAL_SOURCE),
            ('failed final state rejected', ['state'], 'failed'),
            ('running final state rejected', ['active'], 'workspace'),
            ('wrong final schema rejected', ['schema'], 'legacy'),
            ('wrong mode rejected', ['mode'], 'workspace-final'),
            ('wrong checkout rejected', ['checkout'], '/tmp'),
            ('qualified claim rejected', ['qualified'], True),
            ('changed runtime pins rejected', ['pins', 'sha256'], '0' * 64),
            ('missing prior attempt rejected', ['previous_attempts'], previous[:4]),
            ('changed prior attempt rejected', ['previous_attempts', 0, 'sha256'], '0' * 64),
            ('missing after proof rejected', ['runtime_equivalence_after'], {}),
            ('short timeout command rejected', ['checks', 0, 'command'], ['cargo', 'test']),
            ('skipped target rejected', ['checks', 0, 'targets'], 143),
            ('failed total rejected', ['checks', 0, 'totals', 'failed'], 1),
            ('changed log rejected', ['checks', 0, 'files', 0, 'sha256'], '0' * 64),
            ('insufficient entry headroom rejected', ['free_bytes_before'], 7 * 1024**3)]:
            changed = copy.deepcopy(state); target = changed
            for key in path[:-1]: target = target[key]
            target[path[-1]] = value
            write(M.FINAL_STATE, changed)
            check(label, action, False)
        write(M.FINAL_STATE, state)
        proof = json.loads(M.FINAL_PROOFS[0].read_text())
        for label, path, value in [
            ('wrong proof phase rejected', ['physical_verification_phase'], 'after'),
            ('extra allowed runtime path rejected', ['allowed_runtime_differences'], sorted(M.DOC_PATHS + [M.FIXTURE_PATH, 'Cargo.lock'])),
            ('different runtime Git mode rejected', ['runtime_git_blobs', 0, 'mode'], '100755'),
            ('different repository Git blob rejected', ['repository_git_blobs', 0, 'git_blob'], '0' * 40),
            ('missing physical tracked file rejected', ['complete_checkout', 'tracked_blob_count'], 3789),
            ('physical byte count differs rejected', ['complete_checkout', 'total_tracked_bytes'], 1),
            ('missing fixture evidence rejected', ['fixture_evidence'], []),
            ('wrong fixture baseline rejected', ['fixture_diff_from_prior', 'from_blob'], '0' * 40),
            ('dirty physical snapshot rejected', ['source_after', 'status'], ' M Cargo.lock')]:
            changed = copy.deepcopy(proof); target = changed
            for key in path[:-1]: target = target[key]
            target[path[-1]] = value
            check(label, lambda changed=changed: M.validate_equivalence(changed, 'before', inventories, entries, trees, inputs['fixture_evidence']), False)
        for label, key, value in [('wrong record source rejected', 'source', {'head': M.RUNTIME_SOURCE, 'diff_sha256': M.EMPTY, 'untracked': {}}),
                                  ('record timeout rejected', 'timeout', True),
                                  ('short record limit rejected', 'timeout_seconds', 7100),
                                  ('wrong record cwd rejected', 'cwd', str(M.TREE)),
                                  ('changed jobs rejected', 'environment', {**record['environment'], 'CARGO_BUILD_JOBS': '1'})]:
            changed = copy.deepcopy(record); changed[key] = value
            check(label, lambda changed=changed: M.validate_workspace_record(changed, M.FINAL_SOURCE, M.FINAL_TREE, 0), False)
        M.FINAL_STATE.unlink()
        check('missing final state never falls back to either prior failure', action, False)
        # Exercise the real streaming physical blob verifier against tiny local
        # fixtures. Git source/config reads are explicitly synthetic here.
        M.actual_final_checkout = original['actual_final_checkout']
        physical_root = M.Q / 'physical-fixtures-not-a-worktree'
        physical_root.mkdir()
        M.FINAL_TREE = physical_root
        previous_source, previous_run = M.source, M.subprocess.run
        M.source = lambda *args: {'head': M.FINAL_SOURCE, 'status': ''}
        def fake_git_status(command, **kwargs):
            if command[:3] == ['git', 'symbolic-ref', '-q']:
                return SimpleNamespace(returncode=1, stdout='')
            assert command[:2] == ['git', 'config']
            return SimpleNamespace(returncode=0, stdout='false\n')
        M.subprocess.run = fake_git_status
        sample = physical_root / 'sample'
        content = b'x' * (1024 * 1024 + 17)
        sample.write_bytes(content)
        sample.chmod(0o644)
        expected = [{'path': 'sample', 'mode': '100644', 'bytes': len(content),
                     'git_blob': hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest()}]
        check('real streaming physical verifier accepts complete regular blob', lambda: M.actual_final_checkout(expected), True)
        sample.write_bytes(content[:-1] + b'y')
        check('real physical verifier rejects same-size changed bytes', lambda: M.actual_final_checkout(expected), False)
        sample.write_bytes(content)
        sample.chmod(0o755)
        check('real physical verifier rejects changed executable mode', lambda: M.actual_final_checkout(expected), False)
        sample.chmod(0o644)
        sample.unlink()
        check('real physical verifier rejects missing tracked blob', lambda: M.actual_final_checkout(expected), False)
        sample.symlink_to('link-target')
        check('real physical verifier rejects regular file replaced by symlink', lambda: M.actual_final_checkout(expected), False)
        link = b'link-target'
        link_expected = [{'path': 'sample', 'mode': '120000', 'bytes': len(link),
                          'git_blob': hashlib.sha1(b'blob ' + str(len(link)).encode() + b'\0' + link).hexdigest()}]
        check('real physical verifier accepts exact symlink blob', lambda: M.actual_final_checkout(link_expected), True)
        M.source = lambda *args: {'head': M.FINAL_SOURCE, 'status': ' M Cargo.lock'}
        check('real physical verifier rejects dirty source snapshot', lambda: M.actual_final_checkout(link_expected), False)
        M.source, M.subprocess.run = previous_source, previous_run
    for name, value in original.items(): setattr(M, name, value)
    for script in [COMMON, CONTROLLER]:
        child = subprocess.run([sys.executable, '-O', str(script)], capture_output=True, text=True)
        assert child.returncode != 0 and 'require enabled Python assertions' in child.stderr
        ROWS.append({'case': script.name + ' blocks disabled assertions', 'expected_accept': False, 'actual_accept': False})
        ast.parse(script.read_text(), filename=str(script))
    result = {'state': 'passed', 'qualified': False, 'synthetic_controls': True, 'cases': ROWS,
              'physical_checkout_recheck_mocked_only_for_synthetic_gate_controls': True,
              'real_git_object_inventory_checked': True, 'actual_final_state_or_workspace_or_day_or_build_or_preview_or_network': False,
              'common_sha256': hashlib.sha256(COMMON.read_bytes()).hexdigest(),
              'controller_sha256': hashlib.sha256(CONTROLLER.read_bytes()).hexdigest(),
              'recipe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    with (Q / 'architecture-c12c-soak-workspace-final-controls-v2.json').open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({'state': 'passed', 'synthetic_controls': len(ROWS)}))


if __name__ == '__main__':
    main()
