#!/usr/bin/env python3
"""Pure synthetic publisher controls; no diagnostic or publication is run."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import ast
import copy
import datetime
import hashlib
import importlib.util
import json
import tempfile
import io
import tarfile

Q = Path(__file__).resolve().parent
PUBLISHER = Q / 'architecture-c12-publish-soak.py'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, default=Q / 'architecture-c12-soak-publisher-controls.json')
    args = parser.parse_args()
    assert not args.output.exists(), 'never replace prior controls'
    ast.parse(PUBLISHER.read_text())
    spec = importlib.util.spec_from_file_location('c12_soak_publisher_controlled', PUBLISHER)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    source = '1' * 40
    overlay = {'head': source, 'tracked_diff_sha256': module.EMPTY,
               'untracked_overlay': [module.OVERLAY]}
    context = SimpleNamespace(source=source, overlay_source=overlay)
    progress = {'event': 'duration_completed', 'state': 'completed', 'pid': 123,
                'requested_seconds': 86400, 'elapsed_seconds': 86400.1,
                'completed_cycles': 2, 'fixture_cases_per_cycle': 18,
                'controlled_tokio_time': True, 'retained_capacity': 0, 'retained_buffers': 0,
                'acquired': 20, 'released': 20, 'peak_retained_capacity': 0,
                'fd_count': 8, 'baseline_fd_count': 8, 'alive_tasks': 0,
                'baseline_alive_tasks': 0, 'rss_bytes': 67108864}
    caps = module.BASE_LIMITS | {'cpu_seconds': 86430}
    baseline = {'state': 'passed', 'qualified': False, 'source_pin': source,
                'diagnostic': module.DIAGNOSTIC, 'requested_seconds': 86400,
                'source_before': overlay, 'source_after': overlay,
                'runtime_source_equivalent': True, 'source_pin_verified_at_end': True,
                'duration_actual_seconds': 86400.1, 'supervisor_wall_seconds': 86400.5,
                'completed_cycles': 2, 'pid': 123, 'exit_code': 0,
                'process_limits_verified': True, 'limits': caps,
                'actual_process_limits': {key: [value, value] for key, value in caps.items()},
                'final_progress': progress, 'failures': []}
    results = []

    def outcome(label, value, expected):
        actual = module.deadline_outcome(value, context)['state']
        assert actual == expected, (label, actual, expected)
        results.append({'case': label, 'expected': expected, 'actual': actual})

    outcome('complete synthetic deadline record', baseline, 'passed')
    outcome('missing terminal deadline report', None, 'incomplete')
    mutations = [
        ('short child duration', ['duration_actual_seconds'], 30),
        ('short independent supervisor duration', ['supervisor_wall_seconds'], 30),
        ('child duration exceeds independent wall clock', ['duration_actual_seconds'], 86420),
        ('changed runtime source', ['source_after', 'head'], '2' * 40),
        ('unverified overlay', ['runtime_source_equivalent'], False),
        ('changed requested address cap', ['limits', 'address_space'], 2147483648),
        ('changed observed FD cap', ['actual_process_limits', 'file_descriptors'], [256, 256]),
        ('retained idle capacity', ['final_progress', 'retained_capacity'], 1),
        ('unbalanced lease counts', ['final_progress', 'released'], 19),
        ('FD not recovered', ['final_progress', 'fd_count'], 9),
        ('task not recovered', ['final_progress', 'alive_tasks'], 1),
        ('RSS beyond cap', ['final_progress', 'rss_bytes'], 2147483648),
        ('idle cache beyond budget', ['final_progress', 'peak_retained_capacity'], 16777217),
        ('missing controlled clock', ['final_progress', 'controlled_tokio_time'], False),
        ('incomplete case set', ['final_progress', 'fixture_cases_per_cycle'], 0),
        ('child failure', ['exit_code'], 101),
        ('retained failure message', ['failures'], ['synthetic fault']),
        ('running report cannot pass', ['state'], 'running'),
    ]
    for label, path, value in mutations:
        changed = copy.deepcopy(baseline)
        target = changed
        for key in path[:-1]:
            target = target[key]
        target[path[-1]] = value
        outcome(label, changed, 'incomplete')
    changed = copy.deepcopy(baseline)
    changed.update(state='failed', exit_code=101)
    outcome('failed deadline outcome stays failed', changed, 'failed')

    with tempfile.TemporaryDirectory(prefix='c12-soak-publisher-controls-', dir='/tmp') as directory:
        temporary = Path(directory)
        events = []
        for cycle in (1, 2):
            event = copy.deepcopy(progress)
            event.update(event='cycle_completed', state='running', elapsed_seconds=float(cycle), completed_cycles=cycle)
            events.append(event)
        events.append(progress)

        def event_case(label, rows, expected):
            (temporary / 'events.jsonl').write_text(''.join(json.dumps(item) + '\n' for item in rows))
            try:
                module.validate_deadline_events(baseline, temporary, 86400)
                actual = 'accepted'
            except ValueError:
                actual = 'rejected'
            assert actual == expected, (label, actual, expected)
            results.append({'case': label, 'expected': expected, 'actual': actual})

        event_case('ordered synthetic cycles', events, 'accepted')
        bad = copy.deepcopy(events); bad[1]['completed_cycles'] = 1
        event_case('duplicated cycle ordinal', bad, 'rejected')
        bad = copy.deepcopy(events); bad[1]['elapsed_seconds'] = 0.5
        event_case('event clock goes backward', bad, 'rejected')
        bad = copy.deepcopy(events); bad[1]['fixture_cases_per_cycle'] = 19
        event_case('case list changes between cycles', bad, 'rejected')
        bad = copy.deepcopy(events); bad[0]['alive_tasks'] = 1
        event_case('cycle task leak', bad, 'rejected')
        event_case('event after terminal record', events + [events[0]], 'rejected')

        # This stub tests publisher disposition branches only. It deliberately
        # does not pretend to execute the original resource campaign validator.
        tree = temporary / 'tree'
        validator = tree / 'scripts/grpc-resource-campaign.py'
        validator.parent.mkdir(parents=True)
        validator.write_text('def validate_report(report):\n    return report.get("synthetic_validator_errors", [])\n')
        old_tree = module.TREE
        module.TREE = tree
        resource_ctx = SimpleNamespace(source=source, pins={'identical_harness': {
            'scripts/grpc-resource-campaign.py': module.digest(validator)},
            'tools_required': {'rustc': 'synthetic rustc', 'cargo': 'synthetic cargo'}})
        resource = {'source': {'commit': source, 'dirty': False}, 'seed': 20261002,
                    'duration_requested_seconds': 86400, 'duration_actual_seconds': 86400.1,
                    'build': {'profile': 'release'}, 'smoke': {'status': 'passed', 'failures': []},
                    'tools': {'rustc': 'synthetic rustc', 'cargo': 'synthetic cargo'},
                    'qualification': {'soak_24h': {'status': 'completed'}}, 'exit_code': 0,
                    'events': [{'cycle': 3}], 'process_limits': {
                        key: {'soft': value, 'hard': value} for key, value in caps.items()},
                    'process_limits_requested': {
                        key: {'soft': value, 'hard': value} for key, value in caps.items()}}

        def resource_case(label, value, expected):
            actual = module.resource_outcome(value, {}, resource_ctx)['state']
            assert actual == expected, (label, actual, expected)
            results.append({'case': label, 'expected': expected, 'actual': actual,
                            'original_resource_validator_mocked': True})

        resource_case('synthetic resource shape with mocked validator', resource, 'passed')
        bad = copy.deepcopy(resource); bad['duration_actual_seconds'] = 30
        resource_case('short resource duration', bad, 'incomplete')
        bad = copy.deepcopy(resource); bad['synthetic_validator_errors'] = ['synthetic validator rejection']
        resource_case('resource validator rejection retained', bad, 'incomplete')
        bad = copy.deepcopy(resource); bad['smoke']['status'] = 'failed'; bad['exit_code'] = 101
        resource_case('failed resource outcome stays failed', bad, 'failed')
        resource_case('missing resource report', None, 'incomplete')
        bad = copy.deepcopy(resource); bad['smoke'] = None
        resource_case('malformed nested resource smoke', bad, 'incomplete')
        bad = copy.deepcopy(resource); bad['events'] = None
        resource_case('malformed resource events', bad, 'incomplete')
        module.TREE = old_tree

        checker_directory = temporary / 'checker'
        checker_directory.mkdir()
        namespace = {'__file__': str(checker_directory / 'check.py'), '__name__': 'synthetic_checker'}
        ast.parse(module.CHECKER)
        exec(compile(module.CHECKER, '<retained-checker>', 'exec'), namespace)

        def archive_case(label, names, expected):
            contents = b'synthetic bytes\n'
            archive = checker_directory / 'raw.tar.gz'
            with tarfile.open(archive, 'w:gz') as tar:
                for name in names:
                    entry = tarfile.TarInfo(name); entry.size = len(contents)
                    tar.addfile(entry, io.BytesIO(contents))
            unique = set(names)
            metadata = {'qualified': False, 'archive': {'name': 'raw.tar.gz',
                        'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
                        'logical_bytes': len(unique) * len(contents),
                        'files': [{'path': name, 'bytes': len(contents),
                                   'sha256': hashlib.sha256(contents).hexdigest()} for name in unique]}
            (checker_directory / 'manifest.json').write_text(json.dumps(metadata))
            try:
                namespace['main']()
                actual = 'accepted'
            except ValueError:
                actual = 'rejected'
            assert actual == expected, (label, actual, expected)
            results.append({'case': label, 'expected': expected, 'actual': actual,
                            'synthetic_archive_only': True})

        archive_case('safe synthetic capsule checker', ['safe/member.txt'], 'accepted')
        archive_case('path traversal member rejected without extraction', ['../escape'], 'rejected')
        archive_case('duplicate tar member rejected', ['safe/member.txt', 'safe/member.txt'], 'rejected')

    for name in ['../escape', '/absolute', 'a:b', 'a' + chr(92) + 'b', 'a//b', 'a/./b']:
        assert not module.safe_name(name), name
    assert module.safe_name('safe/member.json')
    sparse_ctx = SimpleNamespace(evidence=Path('docs/evidence/grpc-resource-soak-20261024'))
    assert module.publication_sparse_patterns(sparse_ctx) == [
        '/*', '!/docs/evidence/*', '/docs/evidence/README.md',
        '/docs/evidence/grpc-resource-soak-20261024/']
    results.append({'case': 'sparse publication pattern contract', 'expected': 'historical capsules omitted from materialization only',
                    'actual': 'historical capsules omitted from materialization only', 'git_commands_not_run': True})
    result = {'state': 'passed', 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'publisher_sha256': hashlib.sha256(PUBLISHER.read_bytes()).hexdigest(),
              'controller_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'qualified': False, 'synthetic_controls': True,
              'no_resource_tests_builds_worktrees_network_or_publication_run': True,
              'original_resource_validator_mocked_for_shape_controls': True,
              'cases': results, 'safe_archive_name_controls': 'passed'}
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'state': 'passed', 'synthetic_cases': len(results),
                      'qualified': False, 'output': str(args.output)}))


if __name__ == '__main__':
    main()
