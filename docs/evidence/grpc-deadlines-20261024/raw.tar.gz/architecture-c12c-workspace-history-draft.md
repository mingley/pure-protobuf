# Workspace checkout history — current draft

This is a preparation note, not a terminal workspace result.

Source stays `7c02eb387a6785d6e914146babe34f0902a6dd62`; source-pins digest stays
`4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af`.
The original all-feature workspace command uses `--no-fail-fast` and is still
running as of this note. Its documentation target has actually reported
24 passed / 1 failed. The root agent identified 85 missing links caused by the
frozen worktree's sparse exclusion of tracked docs/evidence files. Other targets
and cold consumers continue; no complete-workspace pass or final aggregate is
claimed. Preserve the original state/record/stdout/stderr unchanged.

The excluded evidence files exist in the same committed Git tree. The proposed
recovery is to materialize those exact tracked files, verify clean HEAD/tree/pins
and complete tracked checkout contents, then run the identical full-workspace
command under the original limits. Materialization and recovery have not been
performed by this preparer. Do not edit source/tests, skip the documentation test,
weaken its assertions or turn the original failure into a pass.

A new retained workspace-complete runner must publish
Q/architecture-c12c-workspace-complete-state.json with internal mode `workspace`,
check name `workspace`, the same source/pins, and the original all-feature,
no-fail-fast command/limits. The explicit phase-map-v2 changes only canonical
workspace to this new filename. All seven other selected outputs remain the same.
The original phase map and every frozen helper/writer version stay unchanged.
Existing safe-basename map validation supports this successor; no writer change
is required. Use `--phase-map work/qualification/architecture-c12c-evidence-phase-map-v2.json`
for later authorized writer/packager execution only after the new gate passes.

After actual terminal records exist, replace this draft with a separate retained
history record containing original final totals/exit/log hashes, checkout
materialization command and inventory, clean source/tree/pin verification, exact
successor command/limits, final successor totals/exit/log hashes, and scope. Keep
both results separately. Tracked living docs still correctly say workspace pending;
they must not claim successful recovery before the actual terminal result.
