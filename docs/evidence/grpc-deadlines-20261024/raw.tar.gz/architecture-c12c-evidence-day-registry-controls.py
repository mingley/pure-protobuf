#!/usr/bin/env python3
"""Synthetic isolated day-registry function controls; never invoke the writer."""
import ast
import hashlib
import json
from pathlib import Path
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
writer = Q/'architecture-c12c-write-results.py'
tree = ast.parse(writer.read_text())
function = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='days')
module = ast.Module(body=[function],type_ignores=[])
final='7c02eb387a6785d6e914146babe34f0902a6dd62'
old='40f219fa515034b556df7f39e3e3947e364a2ce1'
f17='f17aa99108ee73f76f5dbcd42ff54fa73840f68c'
baseline='beb4ecd9a9b2143c440892607d5b486318062b61'
with tempfile.TemporaryDirectory(prefix='resource-c12c-day-registry-',dir=Q) as temporary:
    root=Path(temporary);q=root/'qualification';seen=[]
    live=q/'resource-architecture-c12c-day'
    deadline=q/'resource-architecture-c12c-deadline-day'
    samples={live/'campaign/progress.json':{'state':'running','source_pin':final},
             live/'campaign/report.json':{'state':'synthetic_terminal','source':{'commit':final}},
             live/'termination.json':{'source_pin':final,'state':'terminated'},
             live/'publication.json':{'source_pin':final,'state':'not_qualified'},
             deadline/'progress.json':{'state':'running','source_pin':final},
             q/'architecture-c12-soaks-prepared.json':{'state':'prepared_not_run','source_pin':f17},
             q/'architecture-c12b-deadline-fixture-pinned.json':{'state':'staged_not_built','source_pin':old}}
    def snapshot(path):
        seen.append(path)
        return {'live_path_at_capture':str(path),'captured_utc':'synthetic-fixed-UTC','value_at_capture':samples[path]} if path in samples else None
    ns={'Q':q,'ROOT':root,'C':{'BASELINE':baseline,'now':lambda:'synthetic-fixed-UTC'},'snapshot':snapshot}
    # Execute only the isolated pure registry function with fake snapshot data.
    # No writer imports, CLI main, real live files or publication calls execute.
    exec(compile(module,'synthetic-isolated-day-registry','exec'),ns)
    result=ns['days'](final);attempts=result['attempts']
    assert attempts['earlier_C12_resource_day']['expected_runtime']==f17
    assert attempts['earlier_C12b_resource_day']['expected_runtime']==old
    assert attempts['current_C12c_resource_day']['expected_runtime']==final
    assert attempts['current_C12c_deadline_day']['expected_runtime']==final
    assert attempts['earlier_C11_terminal']['expected_runtime']==baseline
    assert attempts['earlier_C12_resource_day']['state']=='not_observed_at_snapshot'
    assert attempts['earlier_C12b_resource_day']['state']=='not_observed_at_snapshot'
    assert attempts['earlier_C12_preparation_only']['observations'][0]['value_at_capture']['source_pin']==f17
    assert attempts['earlier_C12b_preparation_only']['observations'][0]['value_at_capture']['source_pin']==old
    assert live/'campaign/progress.json' in seen and live/'campaign/report.json' in seen
    assert live/'progress.json' not in seen and live/'report.json' not in seen
    assert deadline/'progress.json' in seen and deadline/'report.json' in seen
    assert deadline/'campaign/progress.json' not in seen
    assert all(live/name in seen and deadline/name in seen for name in ['launch.json','supervisor-state.json','termination.json','publication.json'])
    assert all(q/('architecture-c12c-'+kind+'-day-launch-snapshot.json') in seen for kind in ['resource','deadline'])
    assert q/'architecture-c12c-deadline-day-terminal.json' in seen
    assert result['qualified'] is False and result['current_runtime_24_hour_qualification'] is False
    assert all(a['qualified'] is False for a in attempts.values())
    try:ns['days'](old)
    except AssertionError:pass
    else:raise AssertionError('predecessor was accepted as current')
record={'state':'passed','qualified':False,'scope':'Isolated days() AST function with temporary fake paths and in-memory snapshot provider only; no actual writer/packager/live read/extraction/qualification.',
        'checks':['exact f17/40f/7c02 labels','older source not inherited','prepared-only stays separate','nested resource/flat deadline paths','parent termination/publication paths','static launch/terminal paths','by-value metadata retained','wrong current candidate rejected','all qualification flags false'],
        'writer_source':{'path':str(writer),'sha256':hashlib.sha256(writer.read_bytes()).hexdigest()},'temporary_sandbox_removed':True}
with (Q/'architecture-c12c-evidence-day-registry-controls.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record))
