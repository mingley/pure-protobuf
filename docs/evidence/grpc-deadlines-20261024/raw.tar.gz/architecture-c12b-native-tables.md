# Native allocation results — terminal summary analysis

Current `40f219fa`; before `beb4ecd9`. **1,088 captures; 40,800 successful RPCs** (20,400/source).
Offered/dispatched/completed/successful counts reconcile in the terminal summary; failures, timeouts, overflow, unstarted and unfinished are zero.
This analysis checks terminal state/source/pin/summary identity; the final evidence validator will revalidate raw captures.

## Current versus tonic/prost

Equal-Prost on both endpoints. Requested bytes/RPC; lower is better. Worst two relative increases and largest absolute savings per side.

| Selection | Side | Workload | Current | tonic/prost | Difference | Paired repeats |
|---|---|---|---:|---:|---:|---|
| Loss | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 54.07 KiB | 40.11 KiB | +34.81% | loss:2 |
| Loss | client | bidi, 1 KiB, identity, TLS, 16 in flight | 70.13 KiB | 52.87 KiB | +32.66% | loss:2 |
| Saving | client | server_stream, 1 MiB, gzip, plaintext, 1 in flight | 9.97 MiB | 11.66 MiB | -14.49% | win:2 |
| Saving | client | unary, 1 MiB, gzip, plaintext, 1 in flight | 6.85 MiB | 8.44 MiB | -18.89% | win:2 |
| Loss | server | bidi, 1 KiB, identity, plaintext, 1 in flight | 47.24 KiB | 32.95 KiB | +43.38% | loss:2 |
| Loss | server | bidi, 1 KiB, identity, TLS, 16 in flight | 63.22 KiB | 47.62 KiB | +32.77% | loss:2 |
| Saving | server | unary, 1 MiB, gzip, plaintext, 1 in flight | 6.85 MiB | 8.44 MiB | -18.77% | win:2 |
| Saving | server | client_stream, 1 MiB, gzip, plaintext, 1 in flight | 7.48 MiB | 8.66 MiB | -13.69% | win:2 |

## Source changes

Requested bytes/RPC. Worst two relative increases and largest absolute savings per side.

| Selection | Side | Workload | Before | Current | Change | Paired repeats |
|---|---|---|---:|---:|---:|---|
| Largest increase | client | unary, 1 KiB, identity, plaintext, 1 in flight | 9.64 KiB | 9.70 KiB | +0.64% | regression:1, tie:1 |
| Largest increase | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 53.98 KiB | 54.07 KiB | +0.17% | improvement:1, regression:1 |
| Largest saving | client | bidi_pipelined, 1 MiB, gzip, plaintext, 1 in flight | 19.57 MiB | 19.40 MiB | -0.89% | improvement:2 |
| Largest saving | client | bidi_pipelined, 64 KiB, gzip, plaintext, 1 in flight | 2.66 MiB | 2.53 MiB | -4.75% | improvement:2 |
| Largest increase | server | unary, 1 KiB, identity, plaintext, 1 in flight | 14.51 KiB | 18.49 KiB | +27.43% | regression:2 |
| Largest increase | server | unary, 1 KiB, identity, TLS, 16 in flight | 19.60 KiB | 23.65 KiB | +20.65% | regression:2 |
| Largest saving | server | server_stream, 1 MiB, gzip, plaintext, 1 in flight | 14.93 MiB | 14.78 MiB | -1.01% | improvement:2 |
| Largest saving | server | server_stream, 64 KiB, gzip, plaintext, 1 in flight | 2.28 MiB | 2.15 MiB | -5.72% | improvement:2 |

## Allocation counts

Allocation requests/RPC. Worst relative increase and largest absolute saving per side in each comparison.

| Comparison | Selection | Side | Workload | Reference | Current | Change | Paired repeats |
|---|---|---|---|---:|---:|---:|---|
| source | Largest increase | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 37.94 | 38.36 | +1.11% | improvement:1, regression:1 |
| source | Largest saving | client | client_stream, 64 KiB, gzip, plaintext, 16 in flight | 62.12 | 56.56 | -8.95% | improvement:2 |
| source | Largest increase | server | bidi, 1 KiB, identity, plaintext, 1 in flight | 43.14 | 43.12 | -0.05% | regression:1, improvement:1 |
| source | Largest saving | server | bidi, 64 KiB, gzip, TLS, 16 in flight | 104.54 | 100.02 | -4.32% | improvement:2 |
| tonic | Largest increase | client | bidi, 64 KiB, gzip, TLS, 16 in flight | 112.24 | 100.14 | -10.78% | win:2 |
| tonic | Largest saving | client | unary, 64 KiB, gzip, plaintext, 1 in flight | 60.30 | 27.12 | -55.02% | win:2 |
| tonic | Largest increase | server | bidi, 64 KiB, gzip, plaintext, 16 in flight | 99.14 | 95.08 | -4.10% | win:2 |
| tonic | Largest saving | server | unary, 64 KiB, gzip, plaintext, 1 in flight | 56.06 | 38.92 | -30.57% | win:2 |

## Separate pbrs interop routes

| Side | Pair | Workload | Current | tonic/prost | Difference | Paired repeats |
|---|---|---|---:|---:|---:|---|
| server | tonic/prost/native/pbrs | bidi, 1 MiB, gzip, plaintext, 1 in flight | 43.38 MiB | 15.67 MiB | +176.90% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 1 KiB, identity, plaintext, 1 in flight | 68.97 KiB | 32.95 KiB | +109.32% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 1 KiB, identity, TLS, 16 in flight | 84.29 KiB | 47.62 KiB | +77.02% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 64 KiB, gzip, plaintext, 16 in flight | 4.00 MiB | 2.54 MiB | +57.60% | loss:2 |

Additional pbrs handler work and API differences prevent isolated codec or transport attribution. Keep separate from equal-Prost comparisons.

## Scope and limits

All **18 higher source-cost groups** and **46 higher tonic-cost groups** remain in the companion JSON with original ranges/dispositions, including increases below2%. Each group is an endpoint/cell/metric aggregate, not a per-repeat pass count.
Worst relative increase selection is not a significance test. Native context-switch diagnostics do not establish scheduling advantage.
Two paired repeats, 25/50 calls; shared host; rounded display but changes from unrounded endpoint medians.
Every original row retains paired-ratio min/median/max and per-repeat dispositions; mixed directions are not a stable improvement or regression claim.
The combined runtime patch does not attribute changes to individual owners. Tiny identity client changes are not gzip savings or causal evidence.
Requested bytes are cumulative requests, not retained memory/RSS. Allocations are request counts.
No instruction, shipping CPU, latency, throughput or syscall/wake result is supplied by native counters; CPU/cold campaigns are separate.

CPU and cold-process tables are pending their actual terminal summaries. No new performance result is inferred from source or test-profile type layout.
