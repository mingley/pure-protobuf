# Router allocation investigation

Status: source hypotheses and proposed controls only. No compiler, workload or tracked-source edit ran during the CPU captures.

## Observed counters

Pinned source comparison: `beb4ecd9` → `40f219fa`, equal Prost, Tonic client/native server, identity, 1 KiB request/response, one connection, one in-flight RPC. These are N=25/50 setup-subtracted diagnostics, not a speed claim.

| Server bytes/RPC | beb | 40f | Change |
|---|---:|---:|---:|
| Unary | 14,856.32 | 18,932.00 | +4,075.68 |
| Bidi | 44,517.08 | 48,376.12 | +3,859.04 |

Allocation counts remain about 20 unary / 43 bidi. Native pbrs-message server shows the same approximately 4 KiB increase; the unchanged Tonic server does not. Selected exact rows are in `architecture-c12b-router-allocation-selected.json`; the full immutable summary remains authoritative.

## Source findings

1. `rpc-bench/src/native_prost.rs::router` converts the generated service to Router. `main.rs::serve_load` uses that Router. The earlier 544-byte probe used `Single<LayoutService>` with all features in the test profile. It does not measure the production benchmark route, baseline, or its features.
2. `Router::dispatch` is still an async function with a by-value Rpc argument. Its initial generator contains the entire Rpc even though the selected method already has a box from `Service::call_boxed`.
3. `deadline::serve` puts the concrete dispatch future into ServiceState, captures that state in its returned async block, then moves the service into another async match/await. The admitted connection generator retains that returned future inline. Each generator has initial and suspended variants; these boundaries can retain repeated Rpc-sized fields. Layout must establish the actual overlap and multiplicity.
4. FuturesUnordered::push allocates `Arc<Task<Fut>>`, whose `future: UnsafeCell<Option<Fut>>` embeds the whole admitted future. Larger inline generator layout can therefore add bytes to the existing per-call allocation without adding allocation calls.
5. New Rpc accepted-origin/cancellation fields and Owner state contribute fixed size. The CallDeadline is inside the existing pooled cancellation allocation, so its modest record increase is not by itself a 4 KiB explanation. Pooling further limits its steady-state contribution. Timed calls additionally allocate one Sleep; the selected load config has no server rpc_timeout and ordinary benchmark requests do not explicitly set grpc-timeout. Inspect actual request metadata before assigning timer cost.
6. Unary Status-return changes cannot alone explain the matching bidi increase. Bidi still uses the streaming writer, which already returned Status before this successor. Successful unary still uses the pooled bare-OK trailer map; Status::ok does not allocate its empty fields.

## Proposed source change

`architecture-c12b-router-dispatch-proposed.patch` changes only Router dispatch construction: select/intercept/reject synchronously, then return Done or the existing selected boxed method future. It adds no per-call box. Owner remains constructed before Dispatch construction. Expiry is checked before and after the interceptor; start_service_call retains its post-constructor check so expired application futures are never first-polled. ServiceState still destroys the service before the terminal owner. Existing routing, metadata, hooks, observer/channelz and binlog paths remain present.

The patch is uncompiled and unapplied. It is a hypothesis, not an attributed improvement.

## Before/after layout control

`architecture-c12b-router-owner-layout-proposed.patch` adds one meaningful private unit control: construct an actual accepted raw-h2 RPC, create a routed driver, never poll it, then drop it. Assert one lifecycle start/end, zero application polls, cancellation observed by a retained flag, and actual peer CANCEL showing the terminal capability detached. It prints driver sizes for Router, Single and Single with a 16 KiB application future. A relative pointer-sized Router-vs-Single budget and equal small/large Single drivers guard accidental inline payload retention. The test is not a runtime performance measurement.

Run it first on 40f runtime plus diagnostic test patch only; preserve the actual sizes and any relative-budget failure. Then apply only the Router production patch and repeat with identical compiler, features and profile:

```
env CARGO_TARGET_DIR=/workspace/pure-protobuf/work/stable-target CARGO_BUILD_JOBS=2 \
  work/run-rust cargo +stable test --locked --release -p pbrs-grpc --features prost \
  --lib server::deadline::tests::unpolled_router_owner_drop_closes_lifecycle_and_terminal_capability \
  -- --exact --nocapture
```

For actual shipping benchmark monomorphs, in separate diagnostic checkouts of beb, 40f and proposed source, capture compiler type/variant/field layouts with the benchmark's release profile and exact `allocation-counts` feature set:

```
env RUSTC_BOOTSTRAP=1 CARGO_BUILD_JOBS=2 \
  work/run-rust cargo +stable rustc --locked --release --manifest-path rpc-bench/Cargo.toml \
  --features allocation-counts --bin rpc-bench -- -Zprint-type-sizes
```

Use a granted diagnostic target cache and preserve complete stdout/stderr/source/patch/tool hashes. This compiler-only flag is a diagnostic; no output from this build is a qualified shipping result. Extract actual Router dispatch, deadline::serve, admitted serve_io generator, FuturesUnordered Task/ArcInner, unary/bidi selected method, HoldCancel writer, InboundRpc, Prepared, CancelFlag and Owner layouts. Pair before/after fields rather than inferring bytes from source syntax. A hand-written large Service probe supplements the actual generated Prost instantiations; it does not replace them.

## Functional controls

`architecture-c12b-router-controls-proposed.patch` reuses the independent registry-h2 paused-clock fixture and adds routed pre-shape expiry/drop/same-connection recovery, synchronous handler-constructor overrun, synchronous interceptor overrun, and connection-abort exact-once completion. The private owner test covers a genuinely unpolled routed driver. Run these along with the unchanged 23 deadline/accounting tests and full appropriate checks. No status or time allowance is widened.

## Allocation control after captures finish

Use the existing source-verified release `allocation-counts` build and unchanged `scripts/grpc-load-smoke.py::run_cell`/`dominance-ledger.py::compare` harness, rather than hand-timed requests. Select exactly these cells from the existing ledger: pair `[tonic,prost,native,prost]`, shapes unary and bidi, identity, payload 1024, TLS false, connections/in-flight 1/1, stream messages 4, repeats 0/1. Run each at 25 and 50 calls on beb, 40f and proposed source. Include the identical `[tonic,prost,tonic,prost]` cells as unchanged peer controls. Preserve the normal readiness, deadline, 60-second bound, environment, teardown, binary/source verification and allocator settings. Record unique output prefixes and compare setup-subtracted server bytes and allocation calls. This is 16 captures/source including Tonic controls. No gzip or harness setting changes.

If compiler layout and bytes both improve after only Router construction changes, that is a causal source control for the combined Router/generator boundary. To apportion remaining bytes to specific allocations, use a separate diagnostic allocator build with fixed atomic allocation-size bins (record alloc/realloc separately, no allocation/logging inside allocator), then reconcile N/2N bin differences with the emitted Task and boxed-method layouts. A size match alone is not a unique call-site attribution. Keep this diagnostic out of shipping binaries and normal speed captures.

No production source, frozen checkout, source pin, controller or current workload was changed by this preparation.

The ready controller `architecture-c12b-router-allocation-control.py` selects those exact cells, imports the pinned existing harness and ledger, verifies the build before/after each count, and preserves per-cell/report/ledger outputs. Syntax parsed only; it has not executed a workload. Run it separately for beb,40f,proposed with `--source-checkout`, `--binary`, `--build-record`, and a fresh `--output` path.
