#!/usr/bin/env python3
"""Pure/temporary-fixture controller checks; no Rust or publication execution."""

from pathlib import Path
import contextlib
import copy
import hashlib
import importlib.util
import io
import json
import tempfile
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
SCRIPT = Q / 'architecture-c12-soaks.py'
spec = importlib.util.spec_from_file_location('c12_controlled_soaks', SCRIPT)
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)


def main():
    baseline = {'state': 'completed', 'event': 'duration_completed', 'requested_seconds': 30,
                'elapsed_seconds': 30.1, 'completed_cycles': 1, 'fixture_cases_per_cycle': 18,
                'controlled_tokio_time': True, 'retained_capacity': 0, 'retained_buffers': 0,
                'acquired': 0, 'released': 0, 'fd_count': 8, 'baseline_fd_count': 8,
                'alive_tasks': 0, 'baseline_alive_tasks': 0, 'rss_bytes': 16777216,
                'peak_retained_capacity': 0}
    cases = [('complete synthetic progress', baseline, True)]
    for label, key, value in [('short wall duration', 'elapsed_seconds', 29.9),
                              ('not completed', 'state', 'running'),
                              ('missing cases', 'fixture_cases_per_cycle', 17),
                              ('missing clock scope', 'controlled_tokio_time', False),
                              ('retained capacity', 'retained_capacity', 1),
                              ('retained buffer', 'retained_buffers', 1),
                              ('lease imbalance', 'acquired', 1),
                              ('descriptor leak', 'fd_count', 9),
                              ('task leak', 'alive_tasks', 1),
                              ('zero RSS', 'rss_bytes', 0),
                              ('over-cap RSS', 'rss_bytes', 1073741824),
                              ('over-cap cache', 'peak_retained_capacity', 16777217)]:
        record = copy.deepcopy(baseline)
        record[key] = value
        cases.append((label, record, False))
    rows = []
    for label, record, expected in cases:
        try:
            M.validate_progress(record, 30)
            accepted = True
        except (AssertionError, KeyError, TypeError):
            accepted = False
        assert accepted == expected, label
        rows.append({'case': label, 'input': record, 'expected_accept': expected,
                     'actual_accept': accepted})

    original_live, original_run = M.live, M.subprocess.run
    # These are disposable fake output directories, never a source/cache tree.
    with tempfile.TemporaryDirectory(prefix='resource-architecture-c12-soak-controls-', dir=Q) as temporary:
        root = Path(temporary)
        output = root / 'duplicate'
        output.mkdir()
        (output / 'supervisor.lock').write_text('prior exclusive reservation\n')
        (output / 'termination.json').write_text('{"state":"terminated","sentinel":true}\n')
        (output / 'report.json').write_text('{"state":"passed","sentinel":true}\n')
        before = {name: (output / name).read_bytes() for name in ['termination.json', 'report.json']}
        M.live = lambda *args: output
        called = []
        M.subprocess.run = lambda *args, **kwargs: called.append(args) or SimpleNamespace(returncode=0)
        try:
            M.supervise('0' * 64, 'deadline')
            raise AssertionError('duplicate supervisor was accepted')
        except FileExistsError:
            pass
        assert not called and all((output / name).read_bytes() == raw for name, raw in before.items())
        rows.append({'case': 'duplicate supervisor preserves terminal evidence', 'expected': 'reject before publication',
                     'actual': 'rejected with byte-identical prior report/termination'})

        for label, broken_publisher in [('early missing launch still publishes incomplete', False),
                                        ('publisher spawn failure is recorded', True)]:
            output = root / ('publisher-fails' if broken_publisher else 'missing-launch')
            output.mkdir()
            M.live = lambda *args, output=output: output
            called = []

            def fake_run(command, **kwargs):
                called.append(command)
                if broken_publisher:
                    raise OSError('synthetic publisher spawn failure')
                return SimpleNamespace(returncode=0)

            M.subprocess.run = fake_run
            with contextlib.redirect_stderr(io.StringIO()):
                result = M.supervise('0' * 64, 'deadline')
            termination = json.loads((output / 'termination.json').read_text())
            assert result == 1 and termination['state'] == 'supervisor_failed'
            assert termination['source_pin_verified_at_end'] is False and len(called) == 1
            assert called[0][-1] == '--execute' and '--pins-sha256' in called[0]
            if broken_publisher:
                publication = json.loads((output / 'publication.json').read_text())
                assert publication['state'] == 'failed' and 'synthetic' in publication['error']
            rows.append({'case': label, 'expected': 'incomplete/failed, never passed',
                         'actual': termination, 'resource_or_publication_executed': False})
    M.live, M.subprocess.run = original_live, original_run
    result = {'state': 'passed', 'qualified': False, 'synthetic_controls': True,
              'resource_or_compiler_or_network_or_publication_executed': False,
              'controller_sha256': hashlib.sha256(SCRIPT.read_bytes()).hexdigest(),
              'common_sha256': hashlib.sha256((Q / 'architecture-c12-soak-common.py').read_bytes()).hexdigest(),
              'recipe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), 'cases': rows}
    destination = Q / 'architecture-c12-soak-controller-controls-v2.json'
    with destination.open('x') as stream:
        json.dump(result, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'state': 'passed', 'synthetic_controls': len(rows),
                      'resource_or_publication_executed': False}))


if __name__ == '__main__':
    main()
