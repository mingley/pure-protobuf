# C12 qualification preparation

Prepared only. No compiler, test, capture, cleanup, source freeze or new day has
been run by this preparation task. Root must choose the completed source and
explicitly grant each action. Running C11 days and all old evidence stay intact.

## Sources and tools

Baseline runtime: `beb4ecd9a9b2143c440892607d5b486318062b61`.
The clean baseline checkout is `work/architecture-c11`; its retained allocator-
counter release ELF/build record are in
`work/qualification/architecture-c11-stable-rpc-build`. Rust and Cargo are 1.99.1.
The candidate has not been pinned; no performance result is predicted.

The preparation adds only these ignored Q files:

- `architecture-c12-qualification.py`
- `architecture-c12-cpu-cells.json`
- `architecture-c12-native-cells.json`
- this plan and its prepared-file hash record

Freeze creates a new detached `work/architecture-c12`, excluding only historical
`docs/evidence/` contents through sparse checkout. It requires a clean committed
candidate, unchanged benchmark harness/manifests/locks, and named ASAN regression
targets. It publishes `architecture-c12-source-pins.json` exclusively once. Never
edit the frozen pin file, selected cells or controllers after that point.

The counter driver and summary remain the **unchanged C11 scripts**. Their actual
CLI commits, source/build records and immutable hashes identify C11 versus C12.
One hardcoded explanatory limits sentence in the old driver still calls its
sources C8/C11. That stale annotation is not the C12 source identity.

## Diagnostic workload plan

| Phase | Scopes | Repeats | Call batches | Captures | Planned successful RPCs |
|---|---:|---:|---:|---:|---:|
| Selected instructions | 33 | 2 paired ABBA | 10/20 | 264 | 3,960 |
| Selected native counters | 136 | 2 paired ABBA | 25/50 | 1,088 | 40,800 |

These are plans. Actual offered/dispatched/completed/successful counts must agree
in every raw capture. Failures, timeouts, queue overflow, unstarted and unfinished
calls must remain visible. A terminal summary passes only after every expected
source/count/cell/repeat is present exactly once and reconciles.

Instruction cells retain the previous twelve 1/64 KiB upload/bidi cells and extend
them to all five benchmark shapes, with native-Prost client, native-Prost server
and fresh tonic-Prost controls. One-KiB identity unary cells are controls. Native
cells cover all five codec/endpoint pairs and benchmark shapes at 1/64 KiB gzip,
identity unary/bidi, empty gzip, selected TLS/load-16 streams and 1 MiB gzip.

Both endpoints are instrumented in the Callgrind phase. It uses the same release
binary with allocation counting enabled; it does not prove shipping CPU, latency
or throughput superiority. Native counters also do not establish those claims.
The old 2% instruction comparison band is a diagnostic convention, not a
significance test. All allocation/byte increases and repeats must remain recorded.

Both stacks use gzip level 6, four messages per streaming leg, 400 KiB server send
buffers and queue 16. Native accounting/channelz remain enabled. The harness uses
zero-filled application bytes. It does **not** qualify incompressible payload
performance, physical networks, all platforms or every feature configuration.
The pbrs interop route includes extra handler work; use the equal-Prost routes for
the canonical public API comparison. No source change is individually attributed
by a combined-source A/B result.

## Explicit root commands

Run from `/workspace/pure-protobuf`. Substitute the full final committed source
and the actual new independent deadline integration-test target. Multiple new
targets can be supplied with repeated `--asan-target` arguments.

```sh
python3 work/qualification/architecture-c12-qualification.py freeze \
  --candidate FULL_SOURCE_HASH --asan-target DEADLINE_TARGET --execute
python3 work/qualification/architecture-c12-qualification.py prechecks --execute
python3 work/qualification/architecture-c12-qualification.py build-benchmark --execute
python3 work/qualification/architecture-c12-qualification.py native --execute
python3 work/qualification/architecture-c12-qualification.py cpu --execute
```

The prechecks run formatting; all-feature gRPC tests; strict root/gRPC/adapter/
example Clippy; examples; both benchmark correctness suites; strict rustdoc;
default Rust 1.85 and optional-Zstd Rust 1.87. All stable checks explicitly reuse
`work/stable-target`. Bare default `work/run-rust` would create `work/target`, so
do not omit that explicit target cache in other root compiler commands.

The candidate benchmark build explicitly uses `work/rpc-target` and stable Rust.
It copies its final ELF and build logs into the Q build directory. Its tools must
match the baseline build metadata exactly before captures start. Compilers and
captures run separately, with no concurrent heavy work. Every step checks the
clean frozen source, pin file, harness and controller hashes.

After performance, run the selected fresh ASAN/LSan build and final full workspace
when root has established enough disk headroom:

```sh
python3 work/qualification/architecture-c12-qualification.py asan --execute
python3 work/qualification/architecture-c12-qualification.py workspace --execute
```

ASAN uses nightly-2025-06-26, build-std, leak detection, a fresh dedicated
`work/asan-c12-target`, the library, the existing decoded-workspace/duplex/retry/
pump targets, the new deadline target(s), and the lifecycle inbound-owner filter.
Counts derive from actual target summaries and executed ELF hashes. It is a
selected sanitizer scope, not an all-workspace sanitizer claim.

Each mode reserves an exclusive state record and never silently reruns failed
output. A changed production source needs a new immutable checkpoint. Prefix
reuse or rewriting pins cannot turn an earlier failed run into a pass.

## Disk and cache ownership

The workspace has four CPU cores and initially about 7 GiB free. The current
stable cache is about 12 GiB and must be reused. Prior full-workspace consumer
checks accumulated about 5.8 GiB allocated, plus temporary cold targets. The
workspace mode refuses to start below 8 GiB free. Do not solve a failure by
skipping cold consumer checks or weakening resource caps.

MSRV and ASAN caches remain in place after successful checks. Cleanup is a
separate, explicitly granted action, so unavailable procfs inspection cannot
relabel passing tests as failing. Optional cleanup commands are:

```sh
python3 work/qualification/architecture-c12-qualification.py cleanup-owned --owned-cache msrv --execute
python3 work/qualification/architecture-c12-qualification.py cleanup-owned --owned-cache msrv-zstd --execute
python3 work/qualification/architecture-c12-qualification.py cleanup-owned --owned-cache asan --execute
python3 work/qualification/architecture-c12-qualification.py cleanup-rpc --execute
```

Cleanup modes require the relevant terminal passes, inventory the exact cache,
check process users, and preserve source/pins/logs and Q-copied benchmark/soak
ELFs. They fail closed when a same-UID process cannot be inspected. In this resumed
managed session, older running Q-soak PIDs have readable status/cmdline but denied
maps; root has already identified this visibility limit. These cleanup commands
will therefore need a separate root decision, rather than escalation, bypass or
an implicit exemption. No cache has been deleted by this task.

The existing C11 resource and Prost-cache day binaries are Q-copied ELF files.
Do not stop them or modify their controllers, provenance, frozen source or live
outputs. Their eventual passes/failures remain evidence for their recorded source,
not C12. A new C12 day needs its own short preview, exact-source ELF, fixed process
limits and durable terminal publication; this prepared checker does not claim or
launch that future day.
