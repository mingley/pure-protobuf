# Service-config registry fixture repair

The WS2 failure is a test race, not an invalid policy selection. Runtime code is unchanged from7c02.

`lb::is_policy_registered` and `lb::select_lb_policy` each hold the registry mutex for their own operation. No lock spans both calls. `register_lb_policy_factory` inserts/replaces a factory by name; there is no unregister operation. Resolver-channel construction in `client/pool.rs::connect_uri_inner` registers the built-in policies through per-policy OnceLocks. The public `ensure_default_policies_registered` uses those same registrations.

The old test sampled `is_policy_registered("pick_first") == false`, then expected a later selection to be None. Another test can construct a channel and register pick_first between those reads. Returning Some at selection time is correct. A true snapshot can support the corresponding positive selection by name; a false snapshot cannot predict future absence.

The temporary independent integration target forces this precise transition with two barriers: the main thread first observes false, a worker registers defaults, the main thread observes true and exact Some(pick_first), and then the old false-branch assertion fails. It compiled successfully and failed only that final assertion. Record/source/actual ELF: `architecture-c12c-lb-snapshot-red*`. This is a deliberately failing causal diagnostic, not a shipped regression test.

The original test now verifies a unique unregistered policy returns None before and after explicit built-in initialization. An unknown-first, typed-pick_first-second document must select PickFirst with shuffle_address_list=true. A document without LB entries must still return None. These assertions catch an invalid false-Some result without relying on an obsolete global snapshot. Test name and total service_config test count remain unchanged.

With the same barrier interleaving, the fixed invariant passed. The complete service_config target passed29/29 with four test threads; the separate causal control passed1/1. No cases were skipped, no test-thread serialization or deadline widening was introduced. `architecture-c12c-lb-snapshot-green*` preserves both actual ELFs, source and logs. The temporary target was then removed from the root tree after verifying its archived bytes.

`architecture-c12c-lb-snapshot-green-source/manifest.json` records identical registry-source SHA256 values between red and green, identical HEAD/7c02 production runtime trees and a clean working-tree runtime diff. The only code/test change left in the root is the original service_config test. Six pre-existing root documentation changes were preserved. Frozen source trees, source pins, prior failures and performance evidence were not edited.

Relevant rustfmt passed. Strict all-feature/all-target grpc Clippy with -Dwarnings passed (exit0,114.84seconds). Its record is `architecture-c12c-lb-snapshot-clippy.json`; its terminal result is authoritative. Full workspace, ASAN and publication remain the parent's responsibility after the fixture-only checkpoint.
