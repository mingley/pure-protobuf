# In-flight terminal fixture ordering

Observed at 2026-10-24T03:36:21.385973+00:00.

The actual v2 library run retained **713 passed, one failed and one ignored**.
Only `deadline_response_partial_message_discards_inflight_tail_before_error_trailers`
failed, at its unchanged ten-second independent-exchange guard. Cargo stopped
before executing the integration targets in that command. The original command,
source/diff identities, stdout and stderr remain unchanged.

## Causal dependency

The test intentionally parks the server's IO `poll_flush` after a complete
4,096-byte HTTP/2 DATA frame, retaining the unencoded remainder of its larger
gRPC message in the codec. `Prioritize::buffer_pending` returns `CodecFull`
while a DATA frame occupies the codec. `Streams::poll_complete` then calls
`dst.poll_ready`, whose flush reaches the artificial IO gate. This occurs before
the `Complete`/`Idle` branch stores the connection task in `actions.task`.

The terminal owner can mark that tail for discard and queue trailers, but it
cannot make the artificial IO gate ready. The original test waited for the body
owner's destructor **before** releasing the only IO wake source. That ordering
creates a fixture cycle: cleanup needs codec progress, while codec progress waits
for the test's gate release. The peer's exhausted HTTP/2 receive window is a
separate limit and remains deliberately withheld.

## Test-only correction

Assert that the body owner is still live before and immediately after terminal
selection. Release only the artificial IO flush gate, then require the owner to
be destroyed outside both engine locks, followed by native `grpc-status: 4` and
same-connection recovery. Keep all ten-second exchange guards, the three-second
reentrant-callback hang guard, the actual 4,096-byte partial gRPC message, withheld
peer receive credit, status assertions and recovery unchanged. No backend runtime
change is included in this correction. The focused rerun is pending.

The original test is reconstructed byte-for-byte and its SHA256 matches the v2
recorder's untracked-source hash. The delivered patch contains only the fixture
order change and two ownership-phase assertions.

- Original test SHA256: `41c56bed5d4dd8044541435bafca0bca1bf9431cee3c91f4d059fcad9a63324e`
- Corrected test SHA256: `6807bba1e18cbb6da141a062d680bc6e51c98fbbc71f1173b9d5190e4a6b6e63`

```json
{
  "architecture-c12-first-check-v2.json": {
    "bytes": 1300,
    "sha256": "3f8d46fbef8b522669cc6d5ee398d817b493686540cd583903f60e3fd5ef3943"
  },
  "architecture-c12-first-check-v2.stdout": {
    "bytes": 55230,
    "sha256": "9b360e7a9c9d5a1906b12436524cb9dfd39d5ae40dcff49981e608a01cc114f1"
  },
  "architecture-c12-first-check-v2.stderr": {
    "bytes": 624,
    "sha256": "8510660b91a393545f5e632e841cf7076a38464ca32207bde0b7e7a1fce9d4f8"
  },
  "architecture-c12-inflight-fixture-before.rs": {
    "bytes": 15154,
    "sha256": "41c56bed5d4dd8044541435bafca0bca1bf9431cee3c91f4d059fcad9a63324e"
  },
  "architecture-c12-inflight-fixture-order.patch": {
    "bytes": 1278,
    "sha256": "69550dbd3ee58d7ccb2dc146c81f3b4048032363f363c66393a165d7f09346fa"
  }
}
```
