#!/usr/bin/env python3
"""Full workspace gate for a fixture-only repository successor of measured 7c02.

No checkout creation or execution without a separate root grant. All runtime,
harness, manifest, lockfile and codegen blobs must match the measured source.
Both earlier failed workspace attempts remain immutable evidence.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import stat
import subprocess
import sys
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c12c-workspace-final'
RUNTIME = '7c02eb387a6785d6e914146babe34f0902a6dd62'
REPOSITORY = '8144576f74bcf290951a65235e3bb50f24710b71'
PRIOR = '33eaf842d640dc2df3e0cc14db194adcc601e616'
CONTROLLER = Q / 'architecture-c12c-qualification.py'
CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
PINS_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
INPUTS = Q / 'architecture-c12c-workspace-final-inputs.json'
INPUTS_SHA = '8d0a0b1eac7573bf124682e66163a60002ed1b317c991ce4e11446b2f3dd68e3'
FIXTURE = 'pbrs-grpc/tests/service_config.rs'
FIXTURE_SHA = 'a2cca2774b42c6f4794b66df4b6dc3fdfaef3f5641a4eeeedd58de82c22f97e3'
STATE = Q / 'architecture-c12c-workspace-final-state.json'
PREFIX = Q / 'architecture-c12c-workspace-final'
PROOF = Q / 'architecture-c12c-workspace-final-equivalence.json'
AFTER_PROOF = Q / 'architecture-c12c-workspace-final-equivalence-after.json'
EVIDENCE_PATHS = ['docs/evidence/README.md'] + [
    'docs/evidence/' + folder + '/' + name
    for folder in ('grpc-decode-reuse-soak-20261023', 'grpc-prost-cache-diagnostic-20261023')
    for name in ('README.md', 'check.py', 'manifest.json', 'raw.tar.gz', 'results.json')]
ALLOWED_DIFFERENCES = sorted([FIXTURE, *EVIDENCE_PATHS])


def git(*args):
    return subprocess.check_output(['git', *args], cwd=TREE, text=True).strip()


def source():
    return {'head': git('rev-parse', 'HEAD'),
            'status': git('status', '--porcelain', '--untracked-files=all')}


def blob_map(commit):
    raw = subprocess.check_output(['git', 'ls-tree', '-r', '-l', '-z', commit], cwd=TREE)
    rows = []
    for entry in raw.split(b'\0'):
        if not entry:
            continue
        header, path = entry.split(b'\t', 1)
        mode, kind, oid, size = header.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755', '120000'), header
        rows.append({'path': os.fsdecode(path), 'mode': mode, 'git_blob': oid, 'bytes': int(size)})
    assert len({row['path'] for row in rows}) == len(rows)
    return sorted(rows, key=lambda row: row['path'])


def verify_physical(rows):
    assert TREE.is_dir() and not TREE.is_symlink() and TREE.resolve() == TREE
    sparse = subprocess.run(['git', 'config', '--bool', '--get', 'core.sparseCheckout'],
                            cwd=TREE, capture_output=True, text=True)
    assert sparse.returncode in (0, 1) and sparse.stdout.strip() in ('', 'false'), sparse.stdout
    actual = []
    for expected in rows:
        path = TREE / expected['path']
        status = path.lstat()
        h = hashlib.sha1(b'blob ' + str(expected['bytes']).encode() + b'\0')
        if expected['mode'] == '120000':
            assert stat.S_ISLNK(status.st_mode), str(path)
            data = os.fsencode(os.readlink(path))
            assert len(data) == expected['bytes'], str(path)
            h.update(data)
        else:
            assert stat.S_ISREG(status.st_mode), str(path)
            assert bool(status.st_mode & 0o111) == (expected['mode'] == '100755'), str(path)
            assert status.st_size == expected['bytes'], str(path)
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    h.update(chunk)
        assert h.hexdigest() == expected['git_blob'], str(path)
        actual.append(dict(expected))
    return {'tracked_blob_count': len(actual),
            'total_tracked_bytes': sum(row['bytes'] for row in actual), 'tracked_blobs': actual}


def verify_refs(d, refs):
    for item in refs:
        assert d['ref'](Path(item['path'])) == item, item


def verify_inputs(d):
    assert d['digest'](CONTROLLER) == CONTROLLER_SHA
    assert d['digest'](d['PINS']) == PINS_SHA
    assert d['digest'](INPUTS) == INPUTS_SHA
    pins = d['load_pins']()
    assert pins['candidate_runtime'] == RUNTIME
    inputs = json.loads(INPUTS.read_text())
    assert inputs['runtime_source'] == RUNTIME and inputs['repository_source'] == REPOSITORY
    assert inputs['prior_repository_source'] == PRIOR and inputs['fixture_sha256'] == FIXTURE_SHA
    for name in ('fixture_evidence', 'previous_attempts', 'passed_phase_states'):
        verify_refs(d, inputs[name])
    assert len(inputs['previous_attempts']) == 8
    for base, failure in [('architecture-c12c-workspace', 'test_documentation_links_and_anchors_are_valid'),
                          ('architecture-c12c-workspace-complete', 'lb_selection_skips_unregistered_and_typed')]:
        old = json.loads((Q / (base + '-state.json')).read_text())
        assert old['mode'] == 'workspace' and old['state'] == 'failed'
        assert old['source'] == old['source_after'] == {'head': RUNTIME, 'status': ''}
        assert old['pins'] == d['ref'](d['PINS']) and len(old['checks']) == 1
        check = old['checks'][0]
        assert check['name'] == 'workspace' and check['exit_code'] == 101 and check['targets'] == 144
        assert check['totals'] == {'passed': 3811, 'failed': 1, 'ignored': 9}
        output = (Q / (base + '.stdout')).read_text()
        assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', output, re.MULTILINE)) == {failure}
        record = json.loads((Q / (base + '.json')).read_text())
        assert record['exit_code'] == 101 and not record.get('timeout')
        assert record['source'] == {'head': RUNTIME, 'diff_sha256': d['EMPTY'], 'untracked': {}}
    expected_phases = ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native', 'asan']
    assert [Path(row['path']).name for row in inputs['passed_phase_states']] == [
        'architecture-c12c-' + name + '-state.json' for name in expected_phases]
    for item in inputs['passed_phase_states']:
        phase = json.loads(Path(item['path']).read_text())
        assert phase['state'] == 'passed' and phase['source'] == {'head': RUNTIME, 'status': ''}
        assert phase['pins'] == d['ref'](d['PINS'])
        for check in phase['checks']:
            assert check['exit_code'] == 0
            verify_refs(d, check['files'])
    for color, code, expected in [('red', 101, [(0, 1, 0)]), ('green', 0, [(1, 0, 0), (29, 0, 0)])]:
        base = Q / ('architecture-c12c-lb-snapshot-' + color)
        record = json.loads(base.with_suffix('.json').read_text())
        assert record['exit_code'] == code and not record.get('timeout')
        assert record['source']['head'] == PRIOR
        summaries = d['summaries'](base.with_suffix('.stdout'))
        assert [(row['passed'], row['failed'], row['ignored']) for row in summaries] == expected
    green = json.loads((Q / 'architecture-c12c-lb-snapshot-green.json').read_text())
    assert '--test-threads=4' in green['command'] and '--no-fail-fast' in green['command']
    lint = json.loads((Q / 'architecture-c12c-lb-snapshot-clippy.json').read_text())
    assert lint['exit_code'] == 0 and not lint.get('timeout')
    assert all(flag in lint['command'] for flag in ('--all-features', '--all-targets', '-D', 'warnings'))
    return pins, inputs, inputs['fixture_evidence']


def equivalence(d, fixture_evidence, phase):
    before = source()
    assert before == {'head': REPOSITORY, 'status': ''}
    runtime, prior, repository = blob_map(RUNTIME), blob_map(PRIOR), blob_map(REPOSITORY)
    assert len(runtime) == 3780 and len(prior) == len(repository) == 3790
    maps = [{row['path']: row for row in rows} for rows in (runtime, prior, repository)]
    rmap, pmap, fmap = maps
    paths = set(rmap) | set(pmap) | set(fmap)
    old_changed = {path for path in paths if rmap.get(path) != pmap.get(path)}
    fixture_changed = {path for path in paths if pmap.get(path) != fmap.get(path)}
    changed = {path for path in paths if rmap.get(path) != fmap.get(path)}
    assert old_changed == set(EVIDENCE_PATHS), old_changed
    assert fixture_changed == {FIXTURE}, fixture_changed
    assert changed == set(ALLOWED_DIFFERENCES), changed
    assert git('rev-parse', REPOSITORY + '^') == PRIOR
    assert git('rev-parse', RUNTIME + ':pbrs-grpc/src') == git('rev-parse', REPOSITORY + ':pbrs-grpc/src') == '9a5770b1a7a7f15032009aa525120069c9b26306'
    assert d['digest'](TREE / FIXTURE) == FIXTURE_SHA
    assert (TREE / FIXTURE).read_bytes() == (Q / 'architecture-c12c-lb-snapshot-green-source' / FIXTURE).read_bytes()
    physical = verify_physical(repository)
    assert source() == before
    return {'schema': 'pbrs.c12c-workspace-final-equivalence.v1', 'qualified': False,
            'created_utc': d['now'](), 'physical_verification_phase': phase,
            'runtime_source': RUNTIME, 'runtime_tree': git('rev-parse', RUNTIME + '^{tree}'),
            'repository_source': before, 'repository_tree': git('rev-parse', REPOSITORY + '^{tree}'),
            'prior_repository_source': PRIOR, 'prior_repository_tree': git('rev-parse', PRIOR + '^{tree}'),
            'runtime_git_blobs': runtime, 'prior_repository_git_blobs': prior, 'repository_git_blobs': repository,
            'allowed_runtime_differences': ALLOWED_DIFFERENCES,
            'fixture_diff_from_prior': {'path': FIXTURE, 'from_blob': pmap[FIXTURE]['git_blob'],
                                        'to_blob': fmap[FIXTURE]['git_blob']},
            'changed_entries': [{'path': path, 'runtime': rmap.get(path), 'prior_repository': pmap.get(path),
                                 'repository': fmap.get(path)} for path in sorted(changed)],
            'complete_checkout': physical, 'source_before': before, 'source_after': source(),
            'fixture_evidence': fixture_evidence, 'pins': d['ref'](d['PINS']),
            'inputs': d['ref'](INPUTS), 'controller': d['ref'](CONTROLLER),
            'runner': d['ref'](Path(__file__).resolve())}


def execute(d, args):
    assert os.environ.get('PYTHONOPTIMIZE') == '0', 'invoke ordinary Python with explicit PYTHONOPTIMIZE=0'
    _, inputs, fixture_evidence = verify_inputs(d)
    assert not any(path.exists() for path in (STATE, PROOF, AFTER_PROOF))
    assert not any(PREFIX.with_suffix(s).exists() for s in ('.json', '.stdout', '.stderr'))
    proof = equivalence(d, fixture_evidence, 'before')
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3, 'need 8GiB free before cold consumer/full-workspace tests'
    d['exclusive'](PROOF, proof)
    state = {'schema': 'pbrs.c12c-workspace-final-state.v1', 'mode': 'workspace', 'state': 'running',
             'qualified': False, 'started_utc': d['now'](), 'supervisor_pid': os.getpid(),
             'source': source(), 'runtime_source': RUNTIME, 'pins': d['ref'](d['PINS']),
             'checkout': str(TREE), 'runtime_equivalence': d['ref'](PROOF),
             'controller': d['ref'](CONTROLLER), 'runner': d['ref'](Path(__file__).resolve()),
             'inputs': d['ref'](INPUTS), 'previous_attempts': inputs['previous_attempts'],
             'checks': [], 'active': 'workspace', 'free_bytes_before': shutil.disk_usage(ROOT).free}
    d['exclusive'](STATE, state)
    try:
        command = [str(d['RUN']), 'nice', '-n', '10', 'cargo', '+stable', 'test', '--locked',
                   '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4']
        child = subprocess.run([sys.executable, str(d['RECORD']), str(PREFIX), '7200', *command],
                               cwd=TREE, env=d['environment'](jobs=2))
        record = json.loads(PREFIX.with_suffix('.json').read_text())
        parsed = d['summaries'](PREFIX.with_suffix('.stdout'))
        entry = {'name': 'workspace', 'command': command, 'exit_code': record['exit_code'],
                 'duration_seconds': record['duration_seconds'], 'summaries': parsed,
                 'targets': len(parsed), 'totals': {key: sum(row[key] for row in parsed)
                     for key in ('passed', 'failed', 'ignored')}, 'source_after': source(),
                 'files': [d['ref'](PREFIX.with_suffix(s)) for s in ('.json', '.stdout', '.stderr')],
                 'free_bytes_after': shutil.disk_usage(ROOT).free}
        state['checks'].append(entry)
        d['atomic'](STATE, state)
        assert child.returncode == record['exit_code'] == 0 and not record.get('timeout'), entry
        assert record['source'] == {'head': REPOSITORY, 'diff_sha256': d['EMPTY'], 'untracked': {}}
        assert record['cwd'] == str(TREE) and record['timeout_seconds'] == 7200
        assert entry['targets'] == 144 and entry['totals'] == {'passed': 3812, 'failed': 0, 'ignored': 9}, entry
        assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed), entry
        assert record['environment']['CARGO_BUILD_JOBS'] == '2'
        assert record['environment']['CARGO_TARGET_DIR'] == str(ROOT / 'work/stable-target')
        assert record['environment']['RUSTUP_TOOLCHAIN'] == 'stable'
        verify_inputs(d)
        assert d['ref'](PROOF) == state['runtime_equivalence']
        after = equivalence(d, fixture_evidence, 'after')
        for key in ('runtime_git_blobs', 'prior_repository_git_blobs', 'repository_git_blobs',
                    'complete_checkout', 'changed_entries', 'fixture_evidence'):
            assert after[key] == proof[key], key
        d['exclusive'](AFTER_PROOF, after)
        state.update(state='passed', active=None, completed_utc=d['now'](), source_after=source(),
                     free_bytes_after=shutil.disk_usage(ROOT).free,
                     runtime_equivalence_after=d['ref'](AFTER_PROOF))
        d['atomic'](STATE, state)
    except BaseException as error:
        state.update(state='failed', error=repr(error), completed_utc=d['now'](), source_after=source(),
                     free_bytes_after=shutil.disk_usage(ROOT).free)
        d['atomic'](STATE, state)
        traceback.print_exc()
        return 1
    return 0


def main():
    assert __debug__, 'do not run with Python -O'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    assert hashlib.sha256(CONTROLLER.read_bytes()).hexdigest() == CONTROLLER_SHA
    assert hashlib.sha256(INPUTS.read_bytes()).hexdigest() == INPUTS_SHA
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'qualified': False, 'execute_required': True,
                          'repository_source': REPOSITORY, 'runtime_source': RUNTIME,
                          'checkout': str(TREE), 'state_path': str(STATE)}, indent=2))
        return 0
    return execute(runpy.run_path(str(CONTROLLER), run_name='c12c_frozen_controller'), args)


if __name__ == '__main__':
    raise SystemExit(main())
