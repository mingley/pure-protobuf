//! Temporary causal replay of the original service_config fixture's two reads.
//! A fresh test process starts before any default policy is registered.
#![allow(
    clippy::disallowed_types,
    clippy::unwrap_used,
    reason = "two barriers establish the exact registry registration interleaving"
)]
use pbrs_grpc::ServiceConfig;
use pbrs_grpc::lb::{ensure_default_policies_registered, is_policy_registered, select_lb_policy};
use std::sync::{Arc, Barrier};

#[test]
fn fixed_invariant_survives_registration_between_reads() {
    let config = ServiceConfig::parse(
        r#"{"loadBalancingConfig":[{"pick_first":{"shuffleAddressList":true}}]}"#,
    )
    .unwrap();
    let unregistered = ServiceConfig::parse(
        r#"{"loadBalancingConfig":[{"service_config_selection_no_factory":{}}]}"#,
    )
    .unwrap();
    assert!(select_lb_policy(&unregistered).is_none());
    let start = Arc::new(Barrier::new(2));
    let finished = Arc::new(Barrier::new(2));
    let worker_start = Arc::clone(&start);
    let worker_finished = Arc::clone(&finished);
    let worker = std::thread::spawn(move || {
        worker_start.wait();
        // This public initializer calls the same per-policy OnceLock
        // registrations used by client::pool::connect_uri_inner.
        ensure_default_policies_registered();
        worker_finished.wait();
    });
    let before = is_policy_registered("pick_first");
    assert!(
        !before,
        "fresh-process control must observe the false branch"
    );
    start.wait();
    finished.wait();
    worker.join().unwrap();
    assert!(is_policy_registered("pick_first"));
    let selected = select_lb_policy(&config);
    assert_eq!(
        selected.as_ref().map(|policy| policy.name.as_str()),
        Some("pick_first")
    );
    // Fixed fixture invariant: the current registered policy is selected,
    // while a policy with no factory remains unselectable.
    assert!(matches!(
        selected.unwrap().policy,
        pbrs_grpc::LbPolicyConfig::PickFirst {
            shuffle_address_list: true
        }
    ));
    assert!(select_lb_policy(&unregistered).is_none());
    let bare = ServiceConfig::parse(r#"{"methodConfig":[]}"#).unwrap();
    assert!(select_lb_policy(&bare).is_none());
}
