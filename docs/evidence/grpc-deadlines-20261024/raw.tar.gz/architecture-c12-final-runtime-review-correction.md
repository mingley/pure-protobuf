# Correction to the f17 runtime review

Source: `f17aa99108ee73f76f5dbcd42ff54fa73840f68c`.
Time: `2026-10-24T04:18:55.719565+00:00`.
Reviewed `pbrs-grpc/src/tonic_server.rs` SHA-256: `2fc395b0c11d596c239dc09da10d2a691681ea9c601a793abc967a6e3cfdab39`.

**Withdraw finding 2 as a currently reachable production blocker.** The original `architecture-c12-final-runtime-review.md` is preserved unchanged. Its proposed configured-observer/Tonic route trigger overlooked `unsupported_policy`: the adapter explicitly rejects a lifecycle observer with FAILED_PRECONDITION before constructing `Accounting`, in both the ordinary and configured paths. That rejection uses `Rpc::reject`, which already shares the outer lifecycle transition. Consequently the original claimed start-without-end trigger cannot reach `Accounting::drop` under the current supported policy.

`Accounting::drop` does pass no observer, but that alone is not a defect while observer support is explicitly rejected. Adding support would be a separate feature with its own success/error/deadline lifecycle controls. No such feature is implemented here.

This correction was reported to root and the runtime implementer before any Tonic source edit, test creation, compiler invocation or policy change by this reviewer. No test failure or runtime leak is claimed for the withdrawn trigger. The unary post-commit status finding (finding 1) remains a distinct source finding and is not withdrawn by this guard.
