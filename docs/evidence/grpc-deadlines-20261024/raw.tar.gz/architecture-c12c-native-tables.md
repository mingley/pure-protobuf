# Native allocation results — terminal summary analysis

Current `7c02eb38`; before `beb4ecd9`. **1,088 captures; 40,800 successful RPCs** (20,400/source).
Offered/dispatched/completed/successful counts reconcile in the terminal summary; failures, timeouts, overflow, unstarted and unfinished are zero.
This analysis checks terminal state/source/pin/summary identity; the final evidence validator will revalidate raw captures.

## Current versus tonic/prost

Equal-Prost on both endpoints. Requested bytes/RPC; lower is better. Worst two relative increases and largest absolute savings per side.

| Selection | Side | Workload | Current | tonic/prost | Difference | Paired repeats |
|---|---|---|---:|---:|---:|---|
| Largest relative loss | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 54.23 KiB | 40.19 KiB | +34.92% | loss:2 |
| Largest relative loss | client | bidi, 1 KiB, identity, TLS, 16 in flight | 69.95 KiB | 56.92 KiB | +22.88% | loss:2 |
| Largest byte gap | client | bidi, 1 MiB, gzip, plaintext, 1 in flight | 19.41 MiB | 16.67 MiB | +16.40% | loss:2 |
| Saving | client | server_stream, 1 MiB, gzip, plaintext, 1 in flight | 9.97 MiB | 11.66 MiB | -14.49% | win:2 |
| Saving | client | unary, 1 MiB, gzip, plaintext, 1 in flight | 6.85 MiB | 8.44 MiB | -18.89% | win:2 |
| Largest relative loss | server | bidi, 1 KiB, identity, plaintext, 1 in flight | 43.58 KiB | 32.95 KiB | +32.26% | loss:2 |
| Largest relative loss | server | bidi, 1 KiB, identity, TLS, 16 in flight | 60.95 KiB | 49.99 KiB | +21.93% | loss:2 |
| Largest byte gap | server | bidi, 1 MiB, gzip, plaintext, 1 in flight | 18.40 MiB | 15.67 MiB | +17.43% | loss:2 |
| Saving | server | unary, 1 MiB, gzip, plaintext, 1 in flight | 6.85 MiB | 8.44 MiB | -18.82% | win:2 |
| Saving | server | client_stream, 1 MiB, gzip, plaintext, 1 in flight | 7.47 MiB | 8.66 MiB | -13.73% | win:2 |

## Source changes

Requested bytes/RPC. Worst two relative increases and largest absolute savings per side.

| Selection | Side | Workload | Before | Current | Change | Paired repeats |
|---|---|---|---:|---:|---:|---|
| Largest increase | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 54.02 KiB | 54.23 KiB | +0.39% | regression:2 |
| Largest increase | client | unary, 1 KiB, identity, plaintext, 1 in flight | 9.62 KiB | 9.62 KiB | +0.03% | improvement:1, regression:1 |
| Largest saving | client | bidi_pipelined, 1 MiB, gzip, plaintext, 1 in flight | 19.56 MiB | 19.42 MiB | -0.74% | improvement:2 |
| Largest saving | client | client_stream, 1 MiB, gzip, plaintext, 1 in flight | 11.89 MiB | 11.77 MiB | -1.05% | improvement:2 |
| Largest increase | server | unary, 1 KiB, identity, TLS, 16 in flight | 18.24 KiB | 19.17 KiB | +5.12% | regression:2 |
| Largest increase | server | unary, 1 KiB, identity, plaintext, 1 in flight | 14.51 KiB | 14.84 KiB | +2.29% | regression:2 |
| Largest saving | server | server_stream, 64 KiB, gzip, plaintext, 1 in flight | 2.30 MiB | 2.17 MiB | -5.69% | improvement:2 |
| Largest saving | server | server_stream, 64 KiB, gzip, plaintext, 16 in flight | 2.24 MiB | 2.12 MiB | -5.62% | improvement:2 |

## Allocation counts

Allocation requests/RPC. Worst positive relative increase (when observed) and largest absolute saving per side. No equal-Prost allocation-count median exceeds fresh tonic in these selected cells.

| Comparison | Selection | Side | Workload | Reference | Current | Change | Paired repeats |
|---|---|---|---|---:|---:|---:|---|
| source | Largest increase | client | bidi, 1 KiB, identity, plaintext, 1 in flight | 37.96 | 39.08 | +2.95% | regression:2 |
| source | Largest saving | client | bidi, 64 KiB, gzip, TLS, 16 in flight | 103.40 | 98.42 | -4.82% | improvement:2 |
| source | Largest increase | server | unary, 1 KiB, identity, TLS, 16 in flight | 25.78 | 26.16 | +1.47% | improvement:1, regression:1 |
| source | Largest saving | server | bidi, 64 KiB, gzip, plaintext, 16 in flight | 100.10 | 95.22 | -4.88% | improvement:2 |
| tonic | Largest saving | client | unary, 1 KiB, gzip, TLS, 1 in flight | 58.36 | 25.04 | -57.09% | win:2 |
| tonic | Largest saving | server | unary, 1 MiB, gzip, plaintext, 1 in flight | 60.00 | 42.96 | -28.40% | win:2 |

## Separate pbrs interop routes

| Side | Pair | Workload | Current | tonic/prost | Difference | Paired repeats |
|---|---|---|---:|---:|---:|---|
| server | tonic/prost/native/pbrs | bidi, 1 MiB, gzip, plaintext, 1 in flight | 43.37 MiB | 15.67 MiB | +176.88% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 1 KiB, identity, plaintext, 1 in flight | 65.29 KiB | 32.95 KiB | +98.15% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 1 KiB, identity, TLS, 16 in flight | 80.95 KiB | 49.99 KiB | +61.93% | loss:2 |
| server | tonic/prost/native/pbrs | bidi, 64 KiB, gzip, plaintext, 1 in flight | 4.00 MiB | 2.54 MiB | +57.45% | loss:2 |

Additional pbrs handler work and API differences prevent isolated codec or transport attribution. Keep separate from equal-Prost comparisons.

## Scope and limits

All **18 higher source-cost groups** and **48 higher tonic-cost groups** remain in the companion JSON with original ranges/dispositions, including increases below 2%. Each group is an endpoint/cell/metric aggregate, not a per-repeat pass count.
Worst relative increase selection is not a significance test. Native context-switch diagnostics do not establish scheduling advantage.
Two paired repeats, 25/50 calls; shared host; rounded display but changes from unrounded endpoint medians.
Every original row retains paired-ratio min/median/max and per-repeat dispositions; mixed directions are not a stable improvement or regression claim.
The combined runtime patch does not attribute changes to individual owners. Tiny identity client changes are not gzip savings or causal evidence.
Requested bytes are cumulative requests, not retained memory/RSS. Allocations are request counts.
No instruction, shipping CPU, latency, throughput or syscall/wake result is supplied by native counters; CPU/cold campaigns are separate.
Router causal48/1800 records are separate. This full-ledger analysis does not borrow40f measurements or causal-control medians.

CPU and cold-process tables are pending their actual terminal summaries. No new performance result is inferred from source or test-profile type layout.
