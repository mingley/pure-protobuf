# C12 runtime review: frozen f17

Reviewed commit: `f17aa99108ee73f76f5dbcd42ff54fa73840f68c`.
Parent: `fb336b6de2f14e635fcd8b58093b00ef20af1a6d`.
Review time: `2026-10-24T04:17:12.059982+00:00`.

Read-only source review. No compilers, tests, runtime captures, tracked edits or changes to frozen source/pins were performed by this reviewer. The source bytes listed below match the named commit exactly. Full prechecks, comparative performance, ASAN and workspace qualification remain separate and pending. This review is **not a clean production-readiness verdict**: the two source findings below are open at this pin and were sent to root immediately. Neither finding is claimed as an executed reproduction here.

## Open findings

1. **Unary lifecycle status can differ from the committed response.** `server/rpc.rs` chooses the unary and client-streaming `end_call` status by checking `deadline.expired()` after `send_unary_response(...).await` returns. The writer in `server/drain.rs` returns `()` and may already have queued valid OK trailers before its local response message is destroyed. A custom response `CodecMessage` destructor can consume the remaining budget after that commit: the peer still sees status 0 while end telemetry/channelz reports deadline 4. Logical END_STREAM must remain the outcome boundary, as the backend guard correctly enforces. Return/latch the actual writer outcome instead of recomputing it from a later clock read. The same `()` return also loses encoding/budget non-OK outcomes and lets the caller report OK; that part predates the new deadline repair and is not represented as newly reproduced.

2. **Tonic adapter accounting consumes observer completion without notifying it.** `deadline::serve` calls shared `start_call` with the configured observer. Both `tonic_server::Accounting` paths now reuse that call flag, but `Accounting::drop` invokes shared `end_call` with `None` observer/labels. This marks ENDED and prevents the outer owner from sending the matching observer completion. A configured observer on a native Tonic route can therefore receive a start with no end. Carry the existing observer/labels into accounting or keep observer terminal ownership separate; retain the single channelz transition. An observer-plus-Tonic route regression should assert one start and one end before closing this finding.

## Reviewed invariants and remaining limits

- The original peer timeout is stored separately from editable metadata. Effective cap inspection includes the already accepted deadline floor, so removing a shorter metadata cap cannot renew it. `Rpc::deadline` uses one accepted origin and checked addition. Unrepresentable durations add no representable cap; they do not erase an existing one.
- The ordinary `serve` constructor owns cancellation/lifecycle state before selected dispatch construction. The returned `ServiceState` declares service before owner, preserving application-before-owner destruction even if never polled. The driver checks expiration before polling service work and uses absolute sleeps; it no longer repolls arbitrary expired Service code to finish web output.
- Unary and streaming request handlers are checked both before and after synchronous handler construction, and after handler completion. Response hook and encoding work is followed by deadline checks before committing further headers, DATA or final status. Expired `before_commit` yields to the one outer terminal owner instead of renewing a phase timeout.
- The existing cancellation allocation is reused. Logical close detaches the terminal backend reference, logger and driver waker even when application Request/cancellation handles survive; the fixed Instant remains available. Pool reuse resets origin-dependent state, phase flags, carry and waker state only after unique ownership is established.
- Shared-state lock sections transfer ownership; driver waker/resource destruction occurs after unlocking. Registry end accounting is advanced before user end callbacks. Owner destruction closes started-but-unended call accounting; a second observer callback is deliberately skipped during panic unwinding. That is not a promise that panicking application observers receive every callback.
- Native terminal selection preserves already committed logical END_STREAM, sends valid trailers-only status before headers, and preserves pending initial response HEADERS when dropping unsent DATA before error trailers. In-flight HTTP/2 DATA must finish its advertised frame length before the unencoded tail is discarded. It cannot force progress through a blocked TCP sink.
- The new terminal cleanup path detaches discarded payloads and defers connection/current/sibling capacity wakes until engine locks are released. The gated-flush in-flight fixture now releases only its artificial IO wake gate before requiring unlocked owner destruction; HTTP/2 receive credit stays withheld. This review does **not** claim all pre-existing backend payload destruction or all ordinary wake paths are outside locks; the separate next-data-owner design retains that broader open work.
- gRPC-Web body framing is distinguished from native HTTP/2 trailers. Message and trailer-body sends mark in-progress state. A destroyed text writer returns at most two unencoded bytes to the surviving owner. At completed-message boundaries the intact ending DATA is appended without purging earlier body output; an unsafe unfinished body frame uses an explicit reset instead of appending a second frame into its payload. Web status DATA cannot bypass zero HTTP/2 flow-control credit.
- Tonic status/trailer behavior and header state have scoped independent tests in the root records. Exactly-once observer completion on the Tonic path still has finding 2 above. No benchmark superiority, broad feature/spec completeness or source-independent resource qualification follows from this review.

## Source identities

SHA-256 values of the changed Rust source and test files reviewed at this pin:

| File | SHA-256 |
|---|---|
| `pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs` | `c92755899ce6516e91d18dad075fe88aebdc79a5cecd443ed60c26c9f3c7da3d` |
| `pbrs-grpc/src/h2_backend/proto/streams/send.rs` | `3e30f32486fa90b5907a09585a184ff696597c3338dc7a007b69588457e9c603` |
| `pbrs-grpc/src/h2_backend/proto/streams/stream.rs` | `f39998bb2c3bb884235e8a9d1d33cfe1b04c09872d7f837416316152b4f25c49` |
| `pbrs-grpc/src/h2_backend/proto/streams/streams.rs` | `aa208f1ef47467a4e0fbad5e7724a49eb0fc89e88743780b391fda1a5399a1e0` |
| `pbrs-grpc/src/h2_backend/server.rs` | `99469f170d5fc64bb4274fe00c7afe8375215ddcc80ad22544f347db79147287` |
| `pbrs-grpc/src/request.rs` | `9ea3aed25c0b5f17435edba32fcca80e5edc6f0f122cd7c5b19964ccaf159074` |
| `pbrs-grpc/src/server.rs` | `75eae16bf59d8d7df051f81f210cd10c33992783eb5c9c6de2757cb1800907c8` |
| `pbrs-grpc/src/server/accept.rs` | `6bc95a0708183a1ba6171ee190cda6b3a4801597c4277e0544dadad5863f3561` |
| `pbrs-grpc/src/server/connection.rs` | `cf9ff4ed8759add18570206f42f9d8c47fbb5af138639f275fa8015344f75cd9` |
| `pbrs-grpc/src/server/deadline.rs` | `2c8c6b171081520d78e3805e5be26ab32f6952c82e7ba9d44644b43ce26ac273` |
| `pbrs-grpc/src/server/dispatch.rs` | `a8195f3b9100740be13e8b7cd48843672878d60554b25904b1def478708793d0` |
| `pbrs-grpc/src/server/drain.rs` | `8ff2d973b2df289bcad3d0aad4d304c47ae00ac11b75dc1e9aab017bb4e691bb` |
| `pbrs-grpc/src/server/router.rs` | `b6c96afeb93246deb43d1e6a291f3a7f2a6eb9a927d5963400e975c9b2cf0152` |
| `pbrs-grpc/src/server/rpc.rs` | `0dbbf95924792d604556db0e68ab6a4b5244828e31a3cbd991059aabc2f006ba` |
| `pbrs-grpc/src/tonic_server.rs` | `2fc395b0c11d596c239dc09da10d2a691681ea9c601a793abc967a6e3cfdab39` |
| `pbrs-grpc/src/transport/h2.rs` | `eaee25c25a2ded2eed171af97ee4b13e2825ea32f26616e2869eb7cf443f535d` |
| `pbrs-grpc/src/transport/h2/deadline_response_tests.rs` | `a84b2f65cb5ead3e825056f890db413adcc3c2644e749dbebfa0e9886d3569b5` |
| `pbrs-grpc/src/web/frame.rs` | `82886b71a4b17715489036fb04a1290001d09ac3e81eaf2ea65c5edd76e5adcd` |
| `pbrs-grpc/src/web/mod.rs` | `453fe26b824a1b6abc83aa4be3006f0f3169807dbc19dddc70c6c5117b2a6544` |
| `pbrs-grpc/src/wire.rs` | `6d295437832387bdedde0f91d25ce37e1c21650c1a5f337b3f84878f0be46a79` |
| `pbrs-grpc/src/wire/send.rs` | `70477fb3e933c94a69fe53daefafe2a3bc4cf574afe9fb59d6de77f561bc850b` |
| `pbrs-grpc/tests/server_deadline.rs` | `f96a690aa85a04cc7ca8654d0f24853533ee239b023b43dd3e1298c82cae3636` |
| `pbrs-grpc/tests/server_deadline_extended.rs` | `85475d6602179bd2e20ea0e2004e96d9973afac87f6e9c68cdbe2d46f020b481` |
