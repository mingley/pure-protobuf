# Unary terminal accounting successor review

Reviewed at `2026-10-24T04:34:24.531057+00:00`.
Base source: `f17aa99108ee73f76f5dbcd42ff54fa73840f68c`.
Observed HEAD during review: `f17aa99108ee73f76f5dbcd42ff54fa73840f68c`.
Production patch SHA-256 relative to that base: `3c733711a6ecaa1b3c4571e923e6acca1e6ec559f6c4969f39793225389d2370`.

**No material issue found in the narrow successor diff.** This is an independent read-only source and retained-record review; this reviewer ran no compiler, test, profiler or runtime capture and changed no tracked file. Final prechecks, full workspace, sanitizer, resource and comparative-performance qualification remain separate.

## Closed finding and causal evidence

The original f17 review remains unchanged. Its finding 1 is addressed by returning the actual `Status` from the native and web unary writers and passing that result directly to `end_call`. The status is selected when the writer commits a terminal result or encounters a serialization/send error; a later response-message destructor or clock read no longer changes that selection. Client-streaming uses the same corrected native writer. Streaming writers and Tonic adapter policy/accounting are unchanged by this successor.

The retained old-source record is an actual compiled runtime red: all five tests failed on otherwise unchanged f17 source with only the test overlay. Its failure markers distinguish committed wire OK versus deadline lifecycle status, encoding wire status 3 versus lifecycle OK, and budget wire status 8 versus lifecycle OK. No compilation failure is counted as a detecting control. The fixture's exact SHA is identical between old red and repaired green runs.

The repaired retained run passes **739 tests, zero failures and one existing ignore** across the library and three selected integration targets, including all five terminal-accounting cases. The web case covers all four binary/text content types, and the native cases cover unary and client-streaming responses. The strict all-feature, all-target Clippy record also exits zero. These are the root/runtime agent's executions, independently checked here from the closed records and log summaries; they are not extra executions by this reviewer.

The first review's finding 2 remains **withdrawn**, as explained in `architecture-c12-final-runtime-review-correction.md`: the supported Tonic adapter explicitly rejects a configured lifecycle observer before its accounting path. No observer feature was added to manufacture or bypass that guard.

## Reviewed behavior

- Native encoding and byte-admission errors return the original error when its trailers-only response is queued successfully. Serialization/header/DATA/trailer send errors return the corresponding send/helper error instead of reporting success.
- On successful native response completion, the empty-OK and custom-trailer branches return their actual committed status. Returning that value precedes local destruction semantically, so a message destructor that advances time after END_STREAM does not invent a second result or alter lifecycle classification.
- The web writer likewise returns its selected status after its complete body trailer is accepted. Existing message and trailer-body partial markers and the bounded text-carry Drop transfer remain intact. A failed partial body write still leaves the unsafe partial marker for reset handling; this patch does not append another status into an incomplete web frame.
- New checked trailers-only helpers retain the existing native content type and HTTP/2 status placement, or web body-encoded trailer framing and continuous padded text encoding. They prepare complete error responses synchronously and expose failures to the caller; they do not introduce another response owner, timer or pooled state.
- All previously reviewed changed Rust files outside the five production paths below still match f17 exactly at this review. In particular, deadline origin/cap state, service/owner destruction order, terminal backend cleanup, Tonic policy and streaming response paths were not altered by the narrow successor.
- The broader ordinary DATA-owner destruction issue remains a separate design item. This review does not claim every backend callback or payload destructor is outside every existing engine lock, complete specification coverage, production readiness or a performance ranking.

## Reviewed source identities

| Path | SHA-256 |
|---|---|
| `pbrs-grpc/src/server/drain.rs` | `125d494de23f286e7564666d5856e719c1ac2f6daf1eefcf45bcc74106bd784b` |
| `pbrs-grpc/src/server/rpc.rs` | `9f83e574b188e4cb75d207533f365c68fc0c1691116cca378fd3a8cde831ac3a` |
| `pbrs-grpc/src/web/frame.rs` | `a5329c3ad6a56415811c0c93f240da4bde5c49b482824774dfa97a8b1a7c6733` |
| `pbrs-grpc/src/web/mod.rs` | `786d2bfeb891b81c5a2a52719820601e727dd641b705ce16ea5256bc887e154a` |
| `pbrs-grpc/src/wire/send.rs` | `1acc5b4c5bb39899386bfb80df14fbb0295785cb8921675c2ed6be05f993c2ef` |
| `pbrs-grpc/tests/server_terminal_accounting.rs` | `331c7133e5bc45bfb6fbcbffaf36d120413ede87d7966d816923642a1c6f0b93` |

## Closed execution records checked

| Record | SHA-256 |
|---|---|
| `architecture-c12b-unary-red.json` | `c4c67952a5c1f502beb16d4e80e469d5a5b779b8a484f369f1d949e98660853e` |
| `architecture-c12b-unary-red.stdout` | `e04f70922cc78500a5f38e24fa0ccc52ee3902ba11b5b18e63db73662b5e73f7` |
| `architecture-c12b-unary-red.stderr` | `159f33878cb2f2f9fddfcefc9ebe3db1cde3f88964a268c1f6fbe1acb69b692b` |
| `architecture-c12b-fix.json` | `e8ba578b89f19b2475d79c39fd53374c97aad8fa8d62db3721450bc5524e01ad` |
| `architecture-c12b-fix.stdout` | `b91aee9e309d984135163142ae046e2764aa653c569e74a190cf09f26ae00f02` |
| `architecture-c12b-fix.stderr` | `f2ecf28364fe1d84ef54d2ee6f6ca2b58e028349eebe21b71eb89987b87aa6a3` |
| `architecture-c12b-fix-clippy.json` | `8d3379d88b2fb7eed379b4494f1e94964b3f7e53d84c0eaf9538afd56d82ab9a` |
| `architecture-c12b-fix-clippy.stdout` | `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855` |
| `architecture-c12b-fix-clippy.stderr` | `e163ae22574eadeca82eea95ab6dfee910a7ebe9ae71f7fe8d0a3c88f25b8d90` |
