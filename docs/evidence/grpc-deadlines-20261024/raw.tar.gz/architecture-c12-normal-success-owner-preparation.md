# Ordinary successful DATA: owner reentry fixture preparation

**Preparation only. No compilation or test execution.** The ordinary-completion
concern remains a source finding, not a reproduced failure. C12's deadline-path
qualification and frozen source are unchanged. No runtime fix is proposed here.

The base is commit `40f219fa515034b556df7f39e3e3947e364a2ce1` with a clean tracked
status. Exact input, fixture and patch hashes and future commands are in
`architecture-c12-normal-success-owner-preparation.json`.

## Reviewable fixture

`architecture-c12-normal-success-owner-fixture.rs` is an additive snippet for the
existing independent registry-h2 test module. The accompanying
`architecture-c12-normal-success-owner-test-only.patch` modifies only that test
file. It reuses its peer, artificial flush gate and ten-second exchange guards.
It does not call `deadline_response`, `finish`, reset, or server timeout
configuration. Only test watchdogs use timers; no RPC deadline is activated. The existing helper/type names merely
identify the containing test module.

| Test | DATA bytes including gRPC header | Intended phase |
|---|---:|---|
| `normal_success_owner_drop_unlocked_control` | 64 | Explicit owner destruction outside engine work; same live stream and read-only query |
| `normal_success_small_copied_owner_drop_reenters_unlocked` | 64 | Small copied DATA reclaimed during staging |
| `normal_success_large_chained_tail_drop_reenters_unlocked` | 16,384 | One fully consumed chained DATA frame retained behind artificial socket flush, then reclaimed |

A custom `Bytes::from_owner` backing owner synchronously asks an OS thread to call
ordinary `SendStream::capacity()` on the same stream. That accessor takes the
engine lock. It does not change the stream's terminal status. Main retains a send
handle until after exchange/recovery, so the worker's handle destruction cannot
reset or close the response.

The owner waits for at most three seconds, then returns even if its query is
blocked. This lets a held engine lock unlock and the worker finish; it avoids a
permanent self-deadlock. The worker's JoinHandle is retained, asynchronously
waited until `is_finished`, then joined outside the destructor. A watchdog result
is a detecting observation, not a throughput/latency threshold.

Each test requires one complete uncompressed gRPC DATA message, HTTP 200,
`grpc-status: 0`, exactly one owner destruction, worker completion and a second
successful RPC on the same connection. These assertions precede the final
reentry red/green assertion, and an explicit diagnostic records that distinction.
The positive control requires the same query to return during unlocked Drop.

## Intended next-iteration execution

Do not apply/run this during current qualification. In a fresh isolated checkout
at the base commit, use a new target directory and preserve the initial result.
Commands below are **instructions, not commands executed in this preparation**:

```sh
git worktree add --detach work/normal-owner-next 40f219fa515034b556df7f39e3e3947e364a2ce1
git -C work/normal-owner-next apply --check /workspace/pure-protobuf/work/qualification/architecture-c12-normal-success-owner-test-only.patch
git -C work/normal-owner-next apply /workspace/pure-protobuf/work/qualification/architecture-c12-normal-success-owner-test-only.patch
```

Run the three exact commands in the JSON in order, from that checkout with its
recorded environment. They execute the positive control first, then each source
path independently. Preserve stdout/stderr, exit status, source/patch and ELF
hashes; a compile failure or phase-witness failure is not the desired causal red.
Do not reuse C12 qualification evidence for this different source.

## Practical limits and risks

- This prepared source has only been formatted and inspected. Type correctness,
  actual path selection and observed output remain unproved until execution.
- Current `GatedIo` does not forward vectored-write support, so its threshold is
  1,024 bytes. With ample 65,535-byte credit and the default 16,384-byte maximum,
  the chosen lengths select the source's copied and single-frame chained paths.
  The artificial gate keeps writes enabled; it withholds only `poll_flush`.
- Phase assertions witness current ownership placement: copied owner retired
  before flush; chained owner still live after bytes arrive while flush is held.
  A future valid repair may retire owners earlier/later outside locks. Such a
  repair may need separately reviewed phase controls, preserving this original
  causal fixture and its initial results rather than silently weakening them.
- A slow or starved host could trip the three-second guard. Require the unlocked
  control and repeat with stage evidence before attributing a failure to locking.
  The callback also briefly serializes access through a test-owned mutex; main
  releases it before yielding to the engine, which is necessary to avoid a
  fixture-created contention cycle.
- This covers the standard backend's ordinary DATA completion only, with a
  deliberately application-controlled reentrant destructor. It proves neither
  remote exploitability nor memory corruption, and says nothing yet about
  unrelated reset/header/shutdown owners, production performance, or a remedy.
