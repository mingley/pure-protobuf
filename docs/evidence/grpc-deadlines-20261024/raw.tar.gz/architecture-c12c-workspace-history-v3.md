# Workspace history — two preserved failures, final repository checkpoint pending

Measured production runtime remains `7c02eb387a6785d6e914146babe34f0902a6dd62`,
tree `6b264f0602fa1c90471cb54d7e17e35fb2199a11`, source-pins digest
`4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af`.
No successful full-workspace result is established yet.

| Attempt | Actual repository source | Passed / failed / ignored | Target summaries | Exit | Result |
|---|---|---:|---:|---:|---|
| Original sparse checkout | `7c02eb38` | 3,811 / 1 / 9 | 144 | 101 | Documentation link test failed:85 references pointed into excluded tracked evidence files. All other targets passed. |
| Complete tracked checkout | `7c02eb38` | 3,811 / 1 / 9 | 144 | 101 | Documentation passed; `lb_selection_skips_unregistered_and_typed` alone failed at service_config.rs:740. |

The first run lasted1,503.692615seconds. Root then materialized2,057 missing
tracked paths and independently verified all3,780 blobs, modes and symlink targets,
832,877,274bytes, against the unchanged Git tree. The runner repeated the full
checkout proof before the second run. Its retained proof SHA is493d8174..., and
its second run lasted876.275081seconds. Source/pins stayed clean. The second failed
state SHA is eece76bea130aeef2173551a8f0990f1ef8abf351d782fa08665e43e2cfffe18.
Both failed states, commands, stdout/stderr and full actual outcomes remain intact.

The registry test separately observes `is_policy_registered("pick_first")` and
then selects a policy. A concurrent default-policy registration can invalidate
the test's earlier observation; production selection itself holds its lock.
A controlled barrier replay is being prepared by root/runtime agent; no causal
red/green result is claimed in this note before its actual execution.

Root's proposed repair changes only pbrs-grpc/tests/service_config.rs: use a unique
unknown-policy negative, explicitly register defaults, check typed pick-first
options positively, and retain the bare-config None case. The diagnostic fixture
must remain outside the final commit. No production/API/harness/manifest/lock
change is authorized by this checkpoint.

The final workspace repository commit is **not known yet**. It must be recorded
as its actual new commit, separately from runtime source7c02. A new complete
checkout and all-Git-blob equivalence proof must bind the final repository tree to
runtime7c02. Only the exact registry test fixture and prior automatically published
old-source soak records/index may differ. The final fixture commit versus prior
repository33eaf842 must change only that test file. Every other Git blob and mode
must match; production, benchmark and lock identity is not inferred from a label.

A separately retained workspace-final state must run the original all-feature,
no-fail-fast command with jobs2, workers4,7,200-second limit and8GiB entry guard.
The final result remains pending. Previous source-pinned measurements and ASAN
belong to runtime7c02 and may be reused only with explicit equivalence; this does
not relabel either failed workspace run or invent a final pass.
