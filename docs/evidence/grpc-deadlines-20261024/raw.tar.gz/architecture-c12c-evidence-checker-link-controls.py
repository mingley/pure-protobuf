#!/usr/bin/env python3
"""Retain a synthetic checker symlink red/green; no publication or extraction."""
import argparse
import ast
import hashlib
import io
import json
from pathlib import Path
import tarfile
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--expect', choices=['accept', 'reject'], required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
script = Q / 'package-architecture-c12c-evidence.py'
tree = ast.parse(script.read_text())
checker = next(n.value.value for n in tree.body if isinstance(n, ast.Assign)
               and any(isinstance(t, ast.Name) and t.id == 'CHECK_PY' for t in n.targets))
ns = {'__name__': 'synthetic_checker_link_control'}
exec(compile(checker, 'generated-checker-link-control', 'exec'), ns)
with tempfile.TemporaryDirectory(prefix='resource-c12b-checker-link-', dir=Q) as temporary:
    directory = Path(temporary)
    archive = directory / 'actual.tar.gz'
    payload = b'synthetic only'
    with tarfile.open(archive, 'w:gz') as stream:
        info = tarfile.TarInfo('record'); info.size = len(payload)
        stream.addfile(info, io.BytesIO(payload))
    (directory / 'linked.tar.gz').symlink_to(archive.name)
    manifest = {'qualified': False, 'archive': {'name': 'linked.tar.gz', 'bytes': archive.stat().st_size,
        'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
        'files': [{'path': 'record', 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}],
        'logical_bytes': len(payload)}
    (directory / 'manifest.json').write_text(json.dumps(manifest))
    try:
        ns['check'](directory)
    except ValueError as error:
        actual, detail = 'reject', str(error)
    else:
        actual, detail = 'accept', 'Archive symlink was followed after basename and hash checks.'
    assert actual == args.expect, (actual, args.expect)
result = {'qualified': False, 'scope': 'Synthetic local archive-symlink checker control only; no extraction or publication.',
          'expected': args.expect, 'observed': actual,
          'safety_guard_result': 'missing' if actual == 'accept' else 'enforced', 'detail': detail,
          'helper': {'path': str(script), 'sha256': hashlib.sha256(script.read_bytes()).hexdigest()},
          'command': ['python3', str(Path(__file__).resolve()), '--expect', args.expect, '--output', str(args.output)],
          'temporary_sandbox_removed': True}
with args.output.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
print(json.dumps(result))
