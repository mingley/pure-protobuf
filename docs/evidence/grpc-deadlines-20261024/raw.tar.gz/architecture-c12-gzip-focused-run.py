#!/usr/bin/env python3
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, subprocess, time
ROOT=Path('/workspace/pure-protobuf')
Q=ROOT/'work/qualification'
LIVE=Q/'resource-architecture-c12-gzip-focused'
LIVE.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
source=ROOT/'pbrs-grpc/src/compression/gzip.rs'
static=Q/'architecture-c12-gzip-focused-source.rs'; shutil.copy2(source,static)
patch=Q/'architecture-c12-gzip-focused-source.patch'
patch.write_bytes(subprocess.check_output(['git','diff','--binary','--','pbrs-grpc/src/compression/gzip.rs'],cwd=ROOT))
record={'started_utc':now(),'state':'running','qualified':False,'source_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'source':{'path':str(static),'sha256':sha(static)},'patch':{'path':str(patch),'sha256':sha(patch)},'checks':[]}
env=os.environ.copy(); env.update(CARGO_TARGET_DIR=str(ROOT/'work/stable-target'),CARGO_BUILD_JOBS='2',RUSTUP_TOOLCHAIN='stable')
commands=[('tests',[str(ROOT/'work/run-rust'),'cargo','+stable','test','--locked','-p','pbrs-grpc','--all-features','--lib','compression::gzip::tests','--','--test-threads=2']),('clippy-lib',[str(ROOT/'work/run-rust'),'cargo','+stable','clippy','--locked','-p','pbrs-grpc','--all-features','--lib','--','-D','warnings'])]
for name,cmd in commands:
 start=time.monotonic(); started=now()
 with (LIVE/(name+'.stdout')).open('xb') as out,(LIVE/(name+'.stderr')).open('xb') as err:
  result=subprocess.run(cmd,cwd=ROOT,env=env,stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=1800)
 logs={}
 for ending in ['stdout','stderr']:
  origin=LIVE/(name+'.'+ending); dest=Q/('architecture-c12-gzip-focused-'+name+'.'+ending);shutil.copy2(origin,dest);logs[ending]={'path':str(dest),'sha256':sha(dest),'bytes':dest.stat().st_size}
 counts=[{'passed':int(a),'failed':int(b),'ignored':int(c)} for a,b,c in re.findall(r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', (LIVE/(name+'.stdout')).read_text())]
 record['checks'].append({'name':name,'command':cmd,'started_utc':started,'duration_seconds':time.monotonic()-start,'exit_code':result.returncode,'logs':logs,'test_summaries':counts})
 if result.returncode:break
assert sha(source)==record['source']['sha256'],'owned source changed during compiler window'
record.update(state='passed' if len(record['checks'])==2 and all(c['exit_code']==0 for c in record['checks']) else 'failed',completed_utc=now(),source_unchanged=True,scope='Filtered gzip unit tests and strict runtime-library Clippy. Instrumentation/performance, all-target Clippy and full workspace qualification are separate.')
with (Q/'architecture-c12-gzip-focused-state.json').open('x') as out:json.dump(record,out,indent=2);out.write('\n')
print(json.dumps(record,indent=2))
