#!/usr/bin/env python3
"""Retain fresh-process N1 and N2 raw allocation totals, including setup.

This reads an actual completed counter campaign and its standard N/2N summary.
It does not execute endpoints, remove setup, infer isolated RPC cost, or qualify
shipping timing. The output is exclusively created and never overwrites history.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import statistics

ACCOUNTING = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']
METRICS = ['allocations', 'requested_bytes']


def reference(path):
    data = path.read_bytes()
    return {'path': str(path.resolve()), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def identity(cell, include_repeat=True):
    return json.dumps({key: value for key, value in cell.items() if include_repeat or key != 'repeat'}, sort_keys=True)


def ranges(values):
    assert len(values) == 4, 'four retained repeat totals required'
    return {'available': len(values), 'min': min(values), 'median': statistics.median(values),
            'max': max(values), 'values': values}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', required=True, type=Path)
    parser.add_argument('--n2n-summary', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    assert not args.output.exists(), 'retain prior cold records'
    campaign_path = args.campaign / 'campaign.json'
    campaign = json.loads(campaign_path.read_text())
    standard = json.loads(args.n2n_summary.read_text())
    assert campaign['state'] == 'finished' and campaign['passed'] is True
    assert campaign['qualified'] is False and campaign['phase'] == 'native'
    assert campaign['rpc_counts'] == [1, 2] and campaign['expected_captures'] == 96
    assert standard['passed'] is True and standard['qualified'] is False
    assert standard['retained_captures'] == 96 and standard['expected_rpc_calls_per_source'] == 72
    assert standard['source_pins'] == campaign['versions']
    assert standard['controller_sha256'] == campaign['controller_sha256']
    assert len(campaign['cells']) == 24
    scoped = collections.defaultdict(set)
    for cell in campaign['cells']:
        scoped[identity(cell, False)].add(cell['repeat'])
    assert len(scoped) == 6 and all(repeats == set(range(4)) for repeats in scoped.values())
    cells_path = Path(__file__).with_name('architecture-c12-cold-native-cells.json')
    expected_scopes = json.loads(cells_path.read_text())
    assert set(scoped) == {identity(cell) for cell in expected_scopes}
    assert campaign['workloads_input']['sha256'] == reference(cells_path)['sha256']
    expected = {(version, count, identity(cell)) for version in ['baseline', 'candidate']
                for count in [1, 2] for cell in campaign['cells']}
    observed, rows = set(), []
    totals = {version: collections.Counter({key: 0 for key in ACCOUNTING}) for version in ['baseline', 'candidate']}
    groups = collections.defaultdict(dict)
    for capture in campaign['captures']:
        path = args.campaign / capture['path']
        run = json.loads(path.read_text())
        version, count, cell = capture['version'], capture['count'], run['cell']
        key = (version, count, identity(cell))
        assert key in expected and key not in observed, key
        observed.add(key)
        assert capture['passed'] is True and run['passed'] is True
        accounting = run['metrics']
        assert all(type(accounting.get(name)) is int and accounting[name] == count for name in ACCOUNTING[:4])
        assert all(type(accounting.get(name)) is int and accounting[name] == 0 for name in ACCOUNTING[4:])
        assert not accounting.get('status_errors')
        for name in ACCOUNTING:
            totals[version][name] += accounting[name]
        for side in ['client', 'server']:
            allocation = run['allocation_totals'][side]
            assert allocation['scope'] == 'process_since_main' and allocation['includes_reallocations'] is True
            assert all(type(allocation.get(metric)) is int and allocation[metric] >= 0 for metric in METRICS)
            native_side = cell['pair'][0 if side == 'client' else 2] == 'native'
            row = {'version': version, 'count': count, 'cell': cell, 'side': side,
                   'native_side': native_side, 'scope': 'process_since_main_including_setup',
                   'allocations': allocation['allocations'], 'requested_bytes': allocation['requested_bytes'],
                   'includes_reallocations': True, 'capture': reference(path),
                   'actual_rpc_accounting': {name: accounting[name] for name in ACCOUNTING}}
            rows.append(row)
            for metric in METRICS:
                group = (identity(cell, False), count, side, metric, native_side)
                groups[group].setdefault(version, {})[cell['repeat']] = allocation[metric]
    assert observed == expected and len(campaign['captures']) == 96
    assert all(all(values[key] == 72 for key in ACCOUNTING[:4])
               and all(values[key] == 0 for key in ACCOUNTING[4:]) for values in totals.values())
    assert {version: dict(value) for version, value in totals.items()} == standard['actual_rpc_totals']
    comparisons = []
    for (cell, count, side, metric, native), versions in sorted(groups.items()):
        assert set(versions) == {'baseline', 'candidate'}
        assert all(set(repeats) == set(range(4)) for repeats in versions.values())
        before = ranges([versions['baseline'][repeat] for repeat in range(4)])
        after = ranges([versions['candidate'][repeat] for repeat in range(4)])
        comparisons.append({'cell': json.loads(cell), 'count': count, 'side': side,
                            'metric': metric, 'native_side': native, 'baseline_raw_total': before,
                            'candidate_raw_total': after,
                            'ratio_of_process_total_medians': after['median'] / before['median'] if before['median'] else None,
                            'scope': 'fresh_process_and_one_RPC_including_setup' if count == 1 else 'fresh_process_and_two_RPC_control_including_setup',
                            'qualified': False})
    result = {'schema': 'pbrs.c12-cold-process-raw.v1', 'state': 'passed', 'qualified': False,
              'captures': len(observed), 'n1_captures': sum(count == 1 for _, count, _ in observed),
              'n2_control_captures': sum(count == 2 for _, count, _ in observed),
              'successful_rpcs': 144, 'actual_rpc_totals': {version: dict(value) for version, value in totals.items()},
              'campaign': reference(campaign_path), 'standard_n2n_summary': reference(args.n2n_summary),
              'summary_script': reference(Path(__file__).resolve()), 'source_pins': campaign['versions'],
              'selected_cells': reference(cells_path),
              'scope': 'Fresh process plus one application RPC INCLUDING setup; N2 process totals are retained as controls.',
              'isolated_cold_RPC_cost': False, 'hardware_cold_cache_claim': False,
              'shipping_timing_qualification': False, 'setup_subtraction_performed': False,
              'raw_endpoint_totals': rows, 'source_process_total_ranges': comparisons,
              'limits': ['All totals retain process setup and initialization. They are not the incremental allocation cost of an isolated RPC.',
                         'Four repeats per source/count/scope; all raw endpoint totals and increases remain visible.',
                         'Both N1 and N2 runs start fresh processes; this does not flush host hardware or filesystem caches.',
                         'The separate standard N/2N summary subtracts setup for its own slopes; these raw totals do not.',
                         'Allocation-counting release diagnostics, shared host, synthetic application bytes, no shipping latency/CPU superiority claim.']}
    with args.output.open('x') as stream:
        json.dump(result, stream, indent=2, allow_nan=False)
        stream.write('\n')
    print(json.dumps({key: result[key] for key in ['state', 'qualified', 'captures', 'n1_captures', 'n2_control_captures', 'successful_rpcs']}))


if __name__ == '__main__':
    main()
