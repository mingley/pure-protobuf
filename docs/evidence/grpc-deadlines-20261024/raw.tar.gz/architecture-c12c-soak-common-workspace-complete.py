#!/usr/bin/env python3
"""Shared read-only pin and qualification checks for the C12c soak launchers."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import runpy
import stat
import subprocess

if not __debug__:
    raise RuntimeError('workspace-complete gates require enabled Python assertions')

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
PINS = Q / 'architecture-c12c-source-pins.json'
TREE = ROOT / 'work/architecture-c12c'
EMPTY = hashlib.sha256(b'').hexdigest()
DIAGNOSTIC = 'repeated independent-peer server deadline fixture'
OVERLAY = 'pbrs-grpc/tests/deadline_sustained.rs'
RESOURCE_PREVIEW = Q / 'architecture-c12c-resource-preview/report.json'
WORKSPACE_COMPLETE = Q / 'architecture-c12c-workspace-complete-state.json'
CHECKOUT_PROOF = Q / 'architecture-c12c-workspace-complete-checkout.json'
WORKSPACE_RUNNER = Q / 'architecture-c12c-workspace-complete.py'
WORKSPACE_RUNNER_SHA = 'f357fa70bb5711c79d34ae22d3cfcaf384ae21f6895e482ccde906f82b3a531d'
ORIGINAL_CONTROLLER = Q / 'architecture-c12c-qualification.py'
ORIGINAL_CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
WORKSPACE_COMMAND = [str(ROOT / 'work/run-rust'), 'nice', '-n', '10', 'cargo', '+stable',
                     'test', '--locked', '--workspace', '--all-features', '--no-fail-fast',
                     '--', '--test-threads=4']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def ref(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def verify(reference):
    path = Path(reference['path'])
    allowed = path.resolve().is_relative_to(Q.resolve()) or path.resolve() in {
        ROOT / 'work/run-rust', ROOT / 'work/record.py'}
    assert not path.is_symlink() and allowed, path
    assert ref(path) == reference, reference
    return path


def load(path):
    return json.loads(Path(path).read_text())


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.next.{os.getpid()}')
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def exclusive(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def publish_once(path, value, staging):
    temporary = Path(staging) / (Path(path).name + f'.publish.{os.getpid()}')
    atomic(temporary, value)
    os.link(temporary, path)
    temporary.unlink()


def git(*arguments, cwd=TREE):
    return subprocess.check_output(['git', *arguments], cwd=cwd, text=True).strip()


def source(cwd=TREE):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd)}


def pins(expected_sha):
    assert re.fullmatch(r'[0-9a-f]{64}', expected_sha or ''), 'explicit immutable pins SHA256 required'
    assert not PINS.is_symlink() and digest(PINS) == expected_sha, 'C12c source pins changed'
    data = load(PINS)
    assert data['schema'] == 'pbrs.c12c-source-pins.v1' and data['qualified'] is False
    assert re.fullmatch(r'[0-9a-f]{40}', data['candidate_runtime'])
    assert source() == {'head': data['candidate_runtime'], 'status': ''}
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=TREE,
                          capture_output=True).returncode == 1
    for item in data['inputs']:
        verify(item)
    for name, sha in data['identical_harness'].items():
        assert digest(TREE / name) == sha, name
    return data


def caps(seconds):
    return {'address_space': 1073741824, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': seconds + 30}


def validate_workspace_record(record, source_pin, exit_code):
    assert record['command'] == WORKSPACE_COMMAND
    assert record['cwd'] == str(TREE) and record['timeout_seconds'] == 7200
    assert record['exit_code'] == exit_code and not record.get('timeout')
    assert record['source'] == {'head': source_pin, 'diff_sha256': EMPTY, 'untracked': {}}
    env = record['environment']
    assert env['RUSTUP_TOOLCHAIN'] == 'stable' and env['CARGO_BUILD_JOBS'] == '2'
    assert env['CARGO_TARGET_DIR'] == str(ROOT / 'work/stable-target')
    assert not any(key in env for key in ['RUSTFLAGS', 'RUSTDOCFLAGS', 'ASAN_OPTIONS'])


def workspace_check(state, prefix, source_pin, exit_code):
    clean = {'head': source_pin, 'status': ''}
    assert state['mode'] == 'workspace' and state['qualified'] is False
    assert state['free_bytes_before'] >= 8 * 1024**3
    assert state['source'] == state['source_after'] == clean
    assert len(state['checks']) == 1
    check = state['checks'][0]
    assert check['name'] == 'workspace' and check['command'] == WORKSPACE_COMMAND
    assert check['exit_code'] == exit_code and check['source_after'] == clean
    expected = [ref(prefix.with_suffix(suffix)) for suffix in ['.json', '.stdout', '.stderr']]
    assert check['files'] == expected
    for item in expected:
        verify(item)
    record = load(prefix.with_suffix('.json'))
    validate_workspace_record(record, source_pin, exit_code)
    text = prefix.with_suffix('.stdout').read_text()
    parsed = [{'status': status, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
              for status, passed, failed, ignored in re.findall(
                  r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    assert parsed and check['summaries'] == parsed and check['targets'] == len(parsed)
    assert check['totals'] == {key: sum(row[key] for row in parsed) for key in ['passed', 'failed', 'ignored']}
    assert check['totals']['passed'] > 0
    if exit_code == 0:
        assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed)
    else:
        assert exit_code == 101 and check['totals']['failed'] == 1
        failures = set(re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.MULTILINE))
        assert failures == {'test_documentation_links_and_anchors_are_valid'}
    return record


def actual_complete_checkout(source_pin):
    assert source() == {'head': source_pin, 'status': ''}
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=TREE,
                          capture_output=True).returncode == 1
    sparse = subprocess.run(['git', 'config', '--bool', '--get', 'core.sparseCheckout'],
                            cwd=TREE, capture_output=True, text=True)
    assert sparse.returncode in (0, 1) and sparse.stdout.strip() in ('', 'false')
    files = []
    for item in subprocess.check_output(['git', 'ls-tree', '-rz', source_pin], cwd=TREE).split(b'\0'):
        if not item:
            continue
        meta, name = item.split(b'\t', 1)
        mode, kind, expected = meta.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755', '120000')
        relative = os.fsdecode(name)
        path = TREE / relative
        status = path.lstat()
        if mode == '120000':
            assert stat.S_ISLNK(status.st_mode), relative
            raw = os.fsencode(os.readlink(path))
        else:
            assert stat.S_ISREG(status.st_mode), relative
            assert bool(status.st_mode & 0o111) == (mode == '100755'), relative
            raw = path.read_bytes()
        actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        assert actual == expected, relative
        files.append({'path': relative, 'mode': mode, 'git_blob': actual, 'bytes': len(raw)})
    assert files and any(row['path'] == 'docs/evidence/README.md' for row in files)
    return files


def validate_complete_checkout(proof, source_pin, tree, files):
    assert proof['schema'] == 'pbrs.c12c-complete-checkout.v1' and proof['qualified'] is False
    assert proof['source'] == {'head': source_pin, 'status': ''} and proof['tree'] == tree
    assert proof['sparse_checkout'] is False and proof['tracked_blob_count'] == len(files)
    assert proof['tracked_blobs'] == files


def workspace_replacement(data, expected_sha):
    state = load(WORKSPACE_COMPLETE)
    assert state['state'] == 'passed' and state['active'] is None
    assert state['attempt'] == 'complete_checkout_after_preserved_sparse_failure'
    assert state['pins'] == ref(PINS) and state['pins']['sha256'] == expected_sha
    assert digest(ORIGINAL_CONTROLLER) == ORIGINAL_CONTROLLER_SHA
    assert digest(WORKSPACE_RUNNER) == WORKSPACE_RUNNER_SHA
    assert state['controller'] == ref(ORIGINAL_CONTROLLER) and state['runner'] == ref(WORKSPACE_RUNNER)
    oldpath = Q / 'architecture-c12c-workspace-state.json'
    oldprefix = Q / 'architecture-c12c-workspace'
    old = load(oldpath)
    assert old['state'] == 'failed' and old['pins'] == ref(PINS)
    expected_previous = [ref(oldpath)] + [ref(oldprefix.with_suffix(suffix))
                                        for suffix in ['.json', '.stdout', '.stderr']]
    assert state['previous_attempt'] == expected_previous
    for item in expected_previous:
        verify(item)
    oldrecord = workspace_check(old, oldprefix, data['candidate_runtime'], 101)
    record = workspace_check(state, Q / 'architecture-c12c-workspace-complete', data['candidate_runtime'], 0)
    assert oldrecord['command'] == record['command'] and oldrecord['environment'] == record['environment']
    assert oldrecord['timeout_seconds'] == record['timeout_seconds'] == 7200
    assert state['complete_checkout'] == ref(CHECKOUT_PROOF)
    verify(state['complete_checkout'])
    files = actual_complete_checkout(data['candidate_runtime'])
    validate_complete_checkout(load(CHECKOUT_PROOF), data['candidate_runtime'], data['candidate_tree'], files)
    assert git('rev-parse', 'HEAD^{tree}') == data['candidate_tree']
    return ref(WORKSPACE_COMPLETE)


def gate(name, data, expected_sha):
    if name == 'workspace':
        return workspace_replacement(data, expected_sha)
    path = Q / ('architecture-c12c-' + name + '-state.json')
    state = load(path)
    clean = {'head': data['candidate_runtime'], 'status': ''}
    assert state['state'] == 'passed' and state['active'] is None, path
    assert state['qualified'] is False and state['source'] == state['source_after'] == clean, path
    assert state['mode'] == name and state['pins'] == ref(PINS), path
    assert state['pins']['sha256'] == expected_sha
    assert state['checks'], path
    for check in state['checks']:
        assert check['exit_code'] == 0 and check['source_after'] == clean, check['name']
        assert check['totals']['failed'] == 0, check['name']
        for item in check['files']:
            verify(item)
        record = load(next(row['path'] for row in check['files'] if row['path'].endswith('.json')))
        assert record['exit_code'] == 0 and not record.get('timeout'), check['name']
        assert record['source'] == {'head': data['candidate_runtime'], 'diff_sha256': EMPTY, 'untracked': {}}
    # ASAN executable references may intentionally name a reclaimed compiler
    # cache. Their retained hashes/logs are evidence; they are not launch inputs.
    return ref(path)


def resource_preview(data):
    report = load(RESOURCE_PREVIEW)
    assert report['source']['commit'] == data['candidate_runtime'] and report['source']['dirty'] is False
    assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
    assert report['exit_code'] == 0 and report['smoke'] == {'status': 'passed', 'failures': []}
    assert report['build']['profile'] == 'release'
    limits = {key: {'soft': value, 'hard': value} for key, value in caps(30).items()}
    assert report['process_limits'] == report['process_limits_requested'] == limits
    assert report['tools']['rustc'].splitlines()[0] == data['tools_required']['rustc']
    assert report['tools']['cargo'] == data['tools_required']['cargo']
    validator = TREE / 'scripts/grpc-resource-campaign.py'
    assert not runpy.run_path(str(validator))['validate_report'](report)
    binary = Path(report['binary']['path'])
    assert binary.parent == RESOURCE_PREVIEW.parent and digest(binary) == report['binary']['sha256']
    return {'report': ref(RESOURCE_PREVIEW), 'binary': ref(binary),
            'validator': {'path': str(validator), 'sha256': digest(validator), 'bytes': validator.stat().st_size},
            'tools': report['tools'], 'duration_actual_seconds': report['duration_actual_seconds']}


def readiness(expected_sha, full=True):
    data = pins(expected_sha)
    names = ['prechecks']
    if full:
        names += ['resource-preview', 'build-benchmark', 'native', 'cpu', 'asan', 'workspace']
    gates = {name: gate(name, data, expected_sha) for name in names}
    optional = Q / 'architecture-c12c-cold-native-state.json'
    if full and optional.exists():
        gates['cold-native'] = gate('cold-native', data, expected_sha)
    return {'source_pin': data['candidate_runtime'], 'pins': ref(PINS), 'gates': gates,
            'resource_preview': resource_preview(data) if full else None,
            'qualified': False,
            'scope': 'Exact-source local checks only; these gates do not establish overall production readiness or speed superiority.'}
