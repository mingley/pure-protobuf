# Initialized gzip output scratch

Reviewed source head: `50fb3a3f18a92bb61510e7e98e097506ccbdd759` with the recorded gzip-only patch.
Current gzip file SHA-256: `5403acb8ef8982b4bcbcb6029f3c2b054f640b2c727357854d519b286d9e81ea`.
Recorded patch SHA-256: `3ff56f7a429e427fae2fe699d13ac0d8d6ff946f590c61cbee8a1b260940bc49`.
Written 2026-10-24T02:59:58.811218+00:00.

The encoder now reads from `flate2::bufread::GzEncoder<&[u8]>` into one initialized 8 KiB stack chunk and appends each compressed chunk with `Write::write_all`. It reads through encoder EOF, which includes the gzip CRC and ISIZE trailer. Each call constructs a fresh encoder; compression history and output scratch are not retained across messages. The configured level still clamps to 9. Incoming gzip member validation and all decoder code are unchanged.

The bounded chunk avoids the writer interface's separate 32 KiB output Vec and repeated initialization of its spare storage. Other compressor/header allocations remain. Eight KiB is an initial bounded policy, not a measured optimum: smaller chunks can reduce small-call initialization but increase read/write iterations on incompressible output; larger chunks use more stack and initialize more storage for short messages. The chunk exists in a synchronous encode call, not in an idle stream's async state. No unsafe or uninitialized storage was introduced.

The first permanent writer error or zero write terminates encoding immediately, with the original `INTERNAL` / `gzip encode: ...` status mapping. `write_all` retries Interrupted and short writes. The encoder does not flush the caller's sink. Unlike `flate2::write::GzEncoder`, dropping the read encoder after a sink error cannot call `try_finish` and write into the already-failed sink. The old Drop implementation's retry is a source-confirmed difference; this note does not claim that a separate old-source negative-control execution was run.

## Actual focused checks

- Seventeen filtered gzip unit tests passed, zero failures/ignores: 38.18 s including compilation, 1.37 s test phase. Four are new tests.
- Strict all-feature runtime-library Clippy passed in 17.01 s. Test-target/all-target Clippy remains a separate check.
- New cases use flate2's single-member buffered-reader decoder as a distinct I/O wrapper oracle, with CRC/ISIZE and complete compressed-input consumption. This uses the same miniz backend, not a second independent DEFLATE implementation.
- Boundaries cover empty, tiny, 1 KiB, 8 KiB, 32 KiB, 64 KiB and 1 MiB payloads, compressible and deterministic noise, levels 0/1/6/9 and clamped 99. Other cases check prefix append, independent messages, short/Interrupted writes, and failures within headers/body/trailers with no later writes.

Commands, compiler output, source and patch bytes are preserved by `architecture-c12-gzip-focused-state.json` and its referenced files. The warmed `work/stable-target` was used with two Cargo jobs. This is a dirty-source focused check, not a clean final-workspace or sanitizer qualification. No performance capture or speed claim was made. Matched per-side instructions, allocation count/requested bytes and later shipping latency/throughput checks must decide the performance result, including large/incompressible payloads and any costs added by the separately developed deadline repair.
