#!/usr/bin/env python3
"""Small C12b terminal CPU/cold summary analysis, retained before supersession."""
import datetime
import hashlib
import json
import math
from pathlib import Path

Q = Path('/workspace/pure-protobuf/work/qualification')
SOURCE = '40f219fa515034b556df7f39e3e3947e364a2ce1'
BASELINE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
PINS_SHA = '12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1'
ACCOUNT = ['offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs','failed_rpcs','timeouts','queue_overflows','unstarted_rpcs','unfinished_rpcs']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
ref = lambda p: {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
pin_path = Q/'architecture-c12b-source-pins.json'
assert sha(pin_path)==PINS_SHA
inputs=[ref(pin_path)]
summaries={}
for mode, filename, captures, calls in [('native','architecture-c12b-counter-ab-summary.json',1088,20400),('cpu','architecture-c12b-cpu-ab-summary.json',264,1980),('cold-native','architecture-c12b-cold-native-ab-summary.json',96,72)]:
    sp=Q/f'architecture-c12b-{mode}-state.json';state=json.loads(sp.read_text())
    path=Q/filename;s=json.loads(path.read_text())
    assert state['state']=='passed' and state['active'] is None and state['source']==state['source_after']=={'head':SOURCE,'status':''}
    assert state['summary']==ref(path) and state['pins']==ref(pin_path)
    assert s['passed'] and s['controller_passed'] and s['state']=='finished' and s['qualified'] is False
    assert s['retained_captures']==s['expected_captures']==captures
    assert not any(s[k] for k in ['failed_captures','missing_keys','extra_keys','status_errors'])
    for version,commit in [('baseline',BASELINE),('candidate',SOURCE)]:
        assert s['source_pins'][version]['source']['commit']==commit
        assert all(s['actual_rpc_totals'][version][k]==calls for k in ACCOUNT[:4])
        assert all(s['actual_rpc_totals'][version][k]==0 for k in ACCOUNT[4:])
    inputs.extend([ref(sp),ref(path)]);summaries[mode]=s
raw_path=Q/'architecture-c12b-cold-native-raw-summary.json';raw=json.loads(raw_path.read_text())
state=json.loads((Q/'architecture-c12b-cold-native-state.json').read_text())
assert state['raw_process_totals_summary']==ref(raw_path)
assert raw['state']=='passed' and raw['qualified'] is False and raw['captures']==96 and raw['successful_rpcs']==144
assert not raw['isolated_cold_RPC_cost'] and not raw['setup_subtraction_performed'] and not raw['hardware_cold_cache_claim'] and not raw['shipping_timing_qualification']
inputs.append(ref(raw_path))


def native(r):return r['cell']['pair'][0 if r['side']=='client' else 2]=='native'
def equal_prost(r):return r['cell']['pair'][1]==r['cell']['pair'][3]=='prost'
def percent(a,b):return (b/a-1)*100 if type(a) in (float,int) and type(b) in (float,int) and a>0 and math.isfinite(a+b) else None

def endpoint_rows(s,basis):
    selected=[]
    for r in s['source_ranges' if basis=='source' else 'same_side_tonic_ranges']:
        if r['metric'] not in ['instructions','allocations','requested_bytes'] or not native(r) or basis=='tonic' and r['version']!='candidate':continue
        b=r['baseline' if basis=='source' else 'tonic']['median'];a=r['candidate' if basis=='source' else 'native']['median']
        selected.append(dict(r,before=b,current=a,change_percent=percent(b,a),basis=basis))
    return selected


def positive(rows):return [r for r in rows if r['change_percent'] is not None and r['change_percent']>0]

cpu_source=endpoint_rows(summaries['cpu'],'source');cpu_tonic=endpoint_rows(summaries['cpu'],'tonic')
gzip_ir=[r for r in cpu_tonic if r['metric']=='instructions' and equal_prost(r) and r['cell']['compression']=='gzip']
assert len(gzip_ir)==20 and all(r['change_percent']<0 and r['dispositions']=={'win':2} for r in gzip_ir)
source_ir=[r for r in cpu_source if r['metric']=='instructions']
upload=next(r for r in source_ir if r['side']=='client' and equal_prost(r) and r['cell']['shape']=='client_stream' and r['cell']['compression']=='gzip' and r['cell']['payload_bytes']==1024)
upload_tonic=next(r for r in gzip_ir if r['side']=='client' and r['cell']==upload['cell'])
raw_native=[]
for r in raw['source_process_total_ranges']:
    if not r['native_side']:continue
    b=r['baseline_raw_total']['median'];a=r['candidate_raw_total']['median']
    raw_native.append(dict(r,before=b,current=a,change_percent=percent(b,a)))

result={'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified':False,
 'source':SOURCE,'baseline_source':BASELINE,'analysis_script':ref(Path(__file__).resolve()),'inputs':inputs,
 'scope':'Small terminal summaries and phase/source/pin/hash/accounting checks only; no raw capture revalidation or production qualification.',
 'campaigns':{k:{'captures':s['retained_captures'],'successful_rpcs_both_sources':sum(a['successful_rpcs'] for a in s['actual_rpc_totals'].values()),'actual_rpc_totals':s['actual_rpc_totals']} for k,s in summaries.items()},
 'total_captures':sum(s['retained_captures'] for s in summaries.values()),
 'total_successful_rpcs_both_sources':sum(a['successful_rpcs'] for s in summaries.values() for a in s['actual_rpc_totals'].values()),
 'cpu':{'all_native_instruction_source_groups':source_ir,'all_native_instruction_current_vs_tonic_groups':[r for r in cpu_tonic if r['metric']=='instructions'],
        'all20_equal_prost_gzip_instruction_groups':gzip_ir,
        'tonic_saving_percent_range':[min(-r['change_percent'] for r in gzip_ir),max(-r['change_percent'] for r in gzip_ir)],
        'former_1KiB_gzip_upload_client_source':upload,'former_1KiB_gzip_upload_client_tonic':upload_tonic,
        'every_native_higher_source_cost_group':positive(cpu_source),'every_native_higher_tonic_cost_group':positive(cpu_tonic),
        'higher_cost_cutoff_percent':0,'raw_counter_availability':summaries['cpu']['raw_counter_availability']},
 'cold':{'scope':raw['scope'],'isolated_cold_RPC_cost':False,'setup_subtraction_performed':False,'hardware_cold_cache_claim':False,'shipping_timing_qualification':False,
         'n1_captures':raw['n1_captures'],'n2_control_captures':raw['n2_control_captures'],
         'all_native_process_total_ranges':raw_native,'every_native_higher_process_total_group':positive(raw_native),
         'all_control_and_native_process_ranges_record':ref(raw_path),
         'every_native_higher_n2n_summary_source_group':positive(endpoint_rows(summaries['cold-native'],'source')),
         'every_native_higher_n2n_summary_tonic_group':positive(endpoint_rows(summaries['cold-native'],'tonic')),
         'n2n_scope':'Standard N2-N1 endpoint diagnostic retained separately. The primary cold table is raw process plus application RPC including setup; no cold-RPC isolation or startup subtraction claim.',
         'limits':raw['limits']},
 'qualification_status':{'candidate':'Superseded before promotion; actual server identity-byte and instruction regressions are being repaired in a separate candidate.',
                         'asan':'not_run_on_C12b; superseded before execution, not failed',
                         'workspace':'not_run_on_C12b; superseded before execution, not failed',
                         'production_ready':False,'broad_speed_superiority':False,'world_fastest':False,'shipping_CPU_latency_throughput_qualification':False},
 'limits':['Callgrind uses release binaries with allocation counting enabled. Instructions are not shipping CPU or latency/throughput.',
           'Both endpoints are separate scopes. Full pbrs interop includes extra handler work; preserve its losses separately from equal-Prost.',
           'All group rows retain original paired ratios/dispositions or all four raw process values. No cutoff hides a positive median cost change.',
           'A 2% CPU classification band is a reporting convention; a 1.60% increase classified tie is still retained.',
           'All three campaigns belong only to40f. Their results do not qualify a future C12c candidate.',
           'Combined source changes do not isolate each mechanism; current source concerns and future repairs are not measurements.']}
assert result['total_captures']==1448 and result['total_successful_rpcs_both_sources']==44904
output=Q/'architecture-c12b-cpu-cold-analysis.json'
with output.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')


def work(r):
    c=r['cell'];n=c['payload_bytes'];size='0B' if n==0 else f'{n//1024}KiB'
    return f"{c['shape']}, {size}, {c['compression']}"


def irrow(r):
    return f'| {r["side"]} | {work(r)} | {r["before"]/1e6:.5f} | {r["current"]/1e6:.5f} | {r["change_percent"]:+.2f}% | {r["dispositions"]} |'

lines=['# C12b instruction and fresh-process results','',f'Current `{SOURCE[:8]}`; before `{BASELINE[:8]}`. **1,448 captures /44,904 successful RPCs** across all three terminal campaigns.','',
'| Campaign | Captures | Successful RPCs, both sources |','|---|---:|---:|']
for name,item in result['campaigns'].items():lines.append(f'| {name} | {item["captures"]:,} | {item["successful_rpcs_both_sources"]:,} |')
lines += ['', '**Superseded before promotion.** C12b ASAN and full workspace were not run; neither is a failure. The server identity byte/instruction regression is being repaired in a separate candidate. These results remain attached to40f.', '',
'## Instrumented instructions','',f'All **20 measured equal-Prost gzip native endpoint groups use {min(-r["change_percent"] for r in gzip_ir):.2f}–{max(-r["change_percent"] for r in gzip_ir):.2f}% fewer instructions than fresh same-side tonic**; both paired repeats win in every group.',
'Plaintext, one connection/one in flight, all five shapes at1/64KiB,10/20RPCbatches,two paired repeats. This is the measured subset, not a shipping CPU/latency/throughput result.','',
'Million instructions/RPC. Reference is tonic/prost.','',
'| Side | Workload | tonic/prost | Current | Difference | Repeats |','|---|---|---:|---:|---:|---|']
for r in [upload_tonic,min(gzip_ir,key=lambda r:r['change_percent']),max(gzip_ir,key=lambda r:r['change_percent'])]:lines.append(irrow(r))
lines += ['', 'Million instructions/RPC. Reference is the old Beb source. All source instruction increases remain visible, including the CPU-band tie.', '',
'| Side | Workload | Before | Current | Change | Repeats |','|---|---|---:|---:|---:|---|',irrow(upload)]
for r in positive(source_ir):lines.append(irrow(r))
loss_ir=[r for r in cpu_tonic if r['metric']=='instructions' and r['change_percent'] is not None and r['change_percent']>0]
lines += ['', '## Remaining instruction losses versus tonic','', '| Side | Pair | Workload | Current M/RPC | tonic M/RPC | Difference |','|---|---|---|---:|---:|---:|']
for r in sorted(loss_ir,key=lambda r:r['change_percent'],reverse=True):
    lines.append(f'| {r["side"]} | {"/".join(r["cell"]["pair"])} | {work(r)} | {r["current"]/1e6:.5f} | {r["before"]/1e6:.5f} | {r["change_percent"]:+.2f}% |')
lines += ['', 'Pbrs interop has additional handler work and API differences; it is not an isolated codec/transport comparison. The JSON retains all original repeat ranges, tiny increases and byte/allocation losses as well.', '',
'## Fresh process plus one RPC','', '**Includes setup.** No startup subtraction, isolated cold-RPC cost, hardware-cold-cache or shipping-timing claim. Four repeats; the two-RPC control remains in raw records.', '',
'Requested process bytes, KiB. These totals are cumulative allocation requests since main, not RSS.','',
'| Side | Workload | Before | Current | Change | Current min–max |','|---|---|---:|---:|---:|---:|']
for r in raw_native:
    if r['count']==1 and r['metric']=='requested_bytes':
        a=r['candidate_raw_total'];lines.append(f'| {r["side"]} | {work(r)} | {r["before"]/1024:.2f} | {r["current"]/1024:.2f} | {r["change_percent"]:+.2f}% | {a["min"]/1024:.2f}–{a["max"]/1024:.2f} |')
lines += ['', f'All **{len(positive(cpu_source))} CPU-capture source cost increases**, **{len(positive(cpu_tonic))} CPU-capture tonic cost increases** and **{len(positive(raw_native))} fresh-process cost increases** remain in the JSON without a cutoff. Counts are cell/side/metric groups; they are not additional captures or test passes.',
'Cold raw ranges retain all four values and both1/2RPCprocess totals; standard N2−N1 summaries are separate diagnostics.', '', *result['limits']]
with (Q/'architecture-c12b-cpu-cold-tables.md').open('x') as f:f.write('\n'.join(lines)+'\n')
print(json.dumps({'state':'completed','qualified':False,'captures':1448,'successful_rpcs':44904,'gzip_instruction_native_groups':20,
 'higher_cpu_source_cost_groups':len(positive(cpu_source)),'higher_cpu_tonic_cost_groups':len(positive(cpu_tonic)),
 'higher_fresh_process_cost_groups':len(positive(raw_native)),'summary_analysis':str(output),'tables':str(Q/'architecture-c12b-cpu-cold-tables.md')}))
