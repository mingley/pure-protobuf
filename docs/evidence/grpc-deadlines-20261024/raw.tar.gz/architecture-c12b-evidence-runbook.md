# Final evidence preparation

Prepared only. Do not run the writer or packager until root grants execution
following actual final gates and cache cleanup. None of the following commands
has run as part of preparation. The temporary synthetic guard controls do not
qualify the runtime.

Candidate `40f219fa515034b556df7f39e3e3947e364a2ce1`; baseline
`beb4ecd9a9b2143c440892607d5b486318062b61`. All eight canonical phase names map
explicitly to C12b records. A missing/failed/active phase cannot be substituted
with f17's failed C12 state. `--require-cold` requires actual cold-native records;
those fresh-process totals include setup.

Old helpers remain byte-for-byte at their declared SHA versions. The successor
fixes two actual incompatibilities: old pin validation required the literal C12
filename prefix, and cell selection was hardcoded to old C12 files. The new
helper requires the exact C12b schema, candidate, complete phase map, pinned
C12b cells and all three new sanitizer targets. The unchanged C11 driver and
summary remain the authoritative pinned benchmark inputs.

The original C12b packager before checker hardening is retained under
`architecture-c12b-evidence-preparation-v1/`. A synthetic local archive-symlink
control showed the checker followed that link. The hardened generated checker
requires regular local manifest/archive files. Both exact-helper red/green
records and 29 synthetic negative/positive guard controls are retained.

## Required order

1. Finish actual clean final-source prechecks, resource preview, build, native,
   CPU, cold-native, selected ASAN/leak checks and full workspace. Final workspace
   is all-feature/no-fail-fast. Preserve original failures as failures.
2. Complete authorized cache cleanup before writer. Retain Q copies/provenance of
   ELFs and their hashes; executable bytes are omitted from the capsule. If an
   ASAN ELF exists at writer time, do not remove/change it before packaging:
   it becomes a validated input. Retain cleanup scripts/inventories/reclaim
   records; observed readable same-UID command lines do not prove global
   exe/maps/fd quiescence. Never stop old-source soaks for archive preparation.
3. Root grants writer execution, then run exactly:

```sh
python3 work/qualification/architecture-c12b-write-results.py \
  --execute \
  --pins work/qualification/architecture-c12b-source-pins.json \
  --pins-sha256 12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1 \
  --checkout work/architecture-c12b \
  --phase-map work/qualification/architecture-c12b-evidence-phase-map.json \
  --require-cold
```

The result destination is `docs/evidence/grpc-deadlines-20261024/results.json`.
The once-only by-value day snapshot is Q `architecture-c12b-evidence-day-snapshot.json`.
Existing outputs abort; never delete a failure or output to retry under the same
name. An authorized separately retained successor needs explicit new identities.

4. Fill the capsule README and living docs from actual results. The 103-line
   benchmark draft and living-doc outline contain placeholders only. Review exact
   source, units, medians, all losses, scope and day state. Create a new immutable
   Q `architecture-c12b-final-publication-plan.json` with this shape:

```json
{
  "source": "40f219fa515034b556df7f39e3e3947e364a2ce1",
  "finalized": true,
  "qualified": false,
  "files": [
    {"path": "docs/evidence/grpc-deadlines-20261024/README.md", "sha256": "ACTUAL_SHA"},
    {"path": "docs/evidence/grpc-deadlines-20261024/results.json", "sha256": "ACTUAL_SHA"},
    {"path": "docs/benchmarks.md", "sha256": "ACTUAL_SHA"}
  ]
}
```

Include every finalized living doc in this plan. Other dated capsules are
prohibited. Preserve evidence-guide publisher markers.

5. Root grants package execution, then run exactly:

```sh
python3 work/qualification/package-architecture-c12b-evidence.py \
  --execute \
  --pins work/qualification/architecture-c12b-source-pins.json \
  --pins-sha256 12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1 \
  --checkout work/architecture-c12b \
  --phase-map work/qualification/architecture-c12b-evidence-phase-map.json \
  --require-cold \
  --published-plan work/qualification/architecture-c12b-final-publication-plan.json
```

The capsule must contain exactly README/results before packaging. Both scripts
revalidate source, phase state, command/log identities, harnesses, toolchains,
ELF hashes and actual successful-RPC ledgers. The packager includes all stable
architecture-c12* histories/preparations/raw counters/profiles and both source
snapshots; live resource-* trees are excluded. Selected live writers abort the
package; unreadable process selectors remain disclosed unknowns.

The standalone generated `check.py` checks member hashes and safe names without
extracting. The packager runs it before exclusive publication. Root owns tracked
document edits, commits and direct-main push.
