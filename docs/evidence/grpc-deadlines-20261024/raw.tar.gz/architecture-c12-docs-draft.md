# C12 publication draft — preparation only

No final source, aggregate counts or performance numbers are filled in yet.
Use actual terminal records; do not turn planned captures into results. Keep the
main benchmark page near 110 lines. The capsule can explain mechanisms and history.

## Main benchmark page

Lead with the largest observed current loss and a measured source improvement,
if the final captures establish one. Say whether the instruction change is a gain,
a regression or within the stated diagnostic band. A passing test suite alone
does not answer that question.

Use plain labels: **Before**, **Current**, **tonic/prost**, **Change**. Define the
two actual commits once. Use KiB/MiB per RPC for allocation requests and millions
of instructions per RPC for Callgrind. Round the displayed values; calculate
percentages from the unrounded medians. Avoid C11/C12 shorthand on the front page.

Suggested tables:

1. Current requested allocation bytes versus fresh tonic: the worst equal-Prost
   client and server scopes, including identity and large gzip streams. A compact
   pbrs interop note must retain its additional handler-work caveat.
2. Source changes: useful savings and every material increase, with a link to the
   complete ledger. Do not hide small increases behind a 2% allocation cutoff.
3. Instrumented instructions: client upload, server upload, the worst new loss,
   and enough remaining cells to make the scope clear. Explain that the ±2% band
   is a reporting convention, not a significance result.
4. Completed campaign scopes/counts derived from actual capture ledgers.

The optional cold-process records retain fresh process plus one RPC **including
setup** and the two-RPC control. They do not isolate cold-RPC cost, subtract startup
or establish hardware-cold behavior. Keep their full totals/ranges in the capsule;
mention a material cold-process increase on the front page if one is observed.

Short scope paragraph: same harness, gzip level 6, four messages per streaming leg,
zero-filled application bytes, 400 KiB server send buffers and queue 16. Native
accounting/channelz remain enabled. The combined-source comparison does not isolate
the individual effects of gzip, deadlines, lifecycle ownership or backend changes.
Incompressible inputs have correctness tests; this harness does not measure their
performance. Both endpoint directions matter.

End with the reproducible comparison command, raw evidence link and a short list
of unqualified metrics: shipping CPU, latency, throughput, physical networks,
full field-access/entropy/lifecycle coverage and required platforms/releases.

Use the actual source-specific day state at publication. C8's completed day and
the C11 days are older-source records. They never qualify the new runtime. An
active new day is pending, even after a passing preview.

## Capsule README outline

Title: **Server deadlines and gzip encoding**.

Opening: identify the exact final runtime and baseline commit. Explain that the
server now spends one accepted deadline across service waits and call phases;
compressed output uses a bounded initialized read buffer. Describe the actual
measured result only after the final comparison passes.

### Deadline behavior

- The three pre-fix independent h2 controls observed a surviving pre-shape owner,
  a moving deadline getter and a delayed bidi handler starting after expiry.
  Their source snapshot also includes the unrelated gzip edit; the deadline
  runtime files match the old baseline. Keep the actual source identity.
- One cooperative outer owner uses the accepted absolute deadline. Late caps only
  tighten it; handler/service construction and response commitment recheck expiry.
  A timer cannot preempt synchronous user code.
- Native termination preserves initial HTTP/2 headers and the current HTTP/2
  frame length, drops unencoded queued tails safely, and emits one ending.
  A queued completed result is not replaced by later timer observation.
- Web status is a body frame. Safe completed-message boundaries preserve base64
  carry; partial messages or partial status bodies cannot be repaired by inserting
  another status frame. Document the deliberate transport-reset fallback there.
  Status DATA can still wait for peer credit; no implementation can force it
  through a blocked peer. Do not promise native and Web wire endings are identical.
- Payload destruction and registered waker callbacks happen outside engine locks
  on the new terminal path. Pool reset clears call-specific ownership; retained
  Request/RequestParts do not keep the terminal capability alive after the owner.

### Gzip behavior

Fresh compressor state per message; one initialized 8 KiB output chunk; original
compression level/clamp, complete member output, CRC/ISIZE and writer error mapping.
No cross-message compressor retention. The reader and writer use the same miniz
backend; correctness or a source model is not a measured CPU advantage.

### Validation table

Derive actual counts for clean final workspace, selected ASAN/LSan, strict lint and
rustdoc, minimum-version profiles, benchmark correctness, release resource preview,
native/instruction/cold-process captures and any current-source day. Focused counts
overlap broad checks and must not be added to their totals. Sanitizer selection is
not an all-workspace sanitizer pass.

### Measurements

Use the final summaries for all source changes and same-side tonic comparisons.
The new writer records every higher-cost allocation/byte/instruction group without
a cutoff. The raw summaries keep every cell and unavailable metric. Clearly mark
the current selected matrix, rather than presenting the old expanded matrix as
an execution of the new source. Keep full-interop pbrs work separate from equal
Prost API comparisons.

### Failed attempts

Keep the original outcomes separate:

- Pre-fix causal controls compiled and failed all three assertions.
- The first combined attempt failed compilation before running tests.
- The second library execution passed 713 tests, failed one new partial-write
  control and retained one existing ignore. The artificial flush gate prevented
  the codec ownership transition the fixture was waiting for; the corrected
  fixture retains zero peer credit, exact status/drop checks and the same guards.
- Executing the already-built second-snapshot integration binaries passed the
  original three controls and passed 12 of 14 extended controls. The pre-shape
  abort exposed missing lifecycle-start accounting. The partial Web status case
  had already committed OK under the default queue limit; a new bounded queue
  forces a genuinely pending write, while a separate test retains the committed-OK
  invariant. Later passes do not erase either original observation.
- Any later failed checks stay in raw history with their actual source and scope.

Close with source-specific day observations, remaining feature/platform/release
gaps, the results/manifest/raw/checker links and the explicit statement that
production readiness and broad superiority remain unproved.

## Living docs

- Root README: one concise link to the new source-scoped capsule; keep preview
  support boundaries.
- TODO: record completed deadline/encoding repairs and the actual worst remaining
  costs. Preserve concrete xDS, credential, telemetry, codec and release work.
- Implementation status: update only the current-source summary/table and day state.
- Architecture decision: explain the accepted-deadline/terminal-owner design and
  physical Web framing limit. Link detailed history instead of repeating it.
- Evidence guide: add the new row and preserve both automatic day-publisher markers.

## Prepared root commands

After the candidate is committed, frozen and all required phase states pass:

```sh
python3 work/qualification/architecture-c12-write-results.py \
  --execute --pins-sha256 FINAL_IMMUTABLE_PINS_SHA --require-cold
```

This creates `results.json` and one exclusive day snapshot. It does not publish a
day or qualify an active attempt. Finalize the README and living docs, then create
an immutable Q publication plan:

```json
{
  "source": "FULL_FINAL_RUNTIME_COMMIT",
  "finalized": true,
  "qualified": false,
  "files": [
    {"path": "docs/evidence/grpc-deadlines-20261024/README.md", "sha256": "..."},
    {"path": "docs/evidence/grpc-deadlines-20261024/results.json", "sha256": "..."},
    {"path": "docs/benchmarks.md", "sha256": "..."}
  ]
}
```

Select every reviewed final living doc as well. The evidence guide is allowed;
other dated capsules are not. Then:

```sh
python3 work/qualification/package-architecture-c12-evidence.py \
  --execute --pins-sha256 FINAL_IMMUTABLE_PINS_SHA --require-cold \
  --published-plan work/qualification/architecture-c12-final-publication-plan.json
```

Both scripts default to `docs/evidence/grpc-deadlines-20261024`. They refuse
overwrite. Optional `--phase-map` selects explicitly retained successor phase
states for the same final source; it cannot turn a failing state into a pass.
`--pins` and `--checkout` can name a separately frozen successor; never overwrite
an earlier pin/worktree. A selected live writer aborts packaging; active days
must put mutable outputs under `resource-*` and provide once-only snapshot files.
