# C12c instruction and fresh-process results

Current `7c02eb38`; before `beb4ecd9`. **1,448 captures /44,904 successful RPCs** across all three terminal campaigns.

| Campaign | Captures | Successful RPCs, both sources |
|---|---:|---:|
| native | 1,088 | 40,800 |
| cpu | 264 | 3,960 |
| cold-native | 96 | 144 |

**Qualification pending.** Current7c02 ASAN and full workspace have not run as of this analysis; neither is a failure. Current-source sustained diagnostics remain unqualified. The separate actual Router control48/1800 is not folded into canonical totals.

## Instrumented instructions

All **20 measured equal-Prost gzip native endpoint groups use 3.19–16.52% fewer instructions than fresh same-side tonic**; both paired repeats win in every group.
Plaintext, one connection/one in flight, all five shapes at1/64KiB,10/20RPCbatches,two paired repeats. This is the measured subset, not a shipping CPU/latency/throughput result.

Million instructions/RPC. Reference is tonic/prost.

| Side | Workload | tonic/prost | Current | Difference | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1KiB, gzip | 2.23726 | 2.02151 | -9.64% | {'win': 2} |
| client | server_stream, 1KiB, gzip | 1.23546 | 1.03140 | -16.52% | {'win': 2} |
| server | unary, 64KiB, gzip | 3.00746 | 2.91142 | -3.19% | {'win': 2} |

Million instructions/RPC. Reference is the old Beb source. All source instruction increases remain visible, including the CPU-band tie.

| Side | Workload | Before | Current | Change | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1KiB, gzip | 2.38422 | 2.02151 | -15.21% | {'improvement': 2} |
| server | unary, 1KiB, identity | 0.03443 | 0.03998 | +16.14% | {'regression': 2} |

## All22 measured native instruction groups versus tonic

| Side | Pair | Workload | Current M/RPC | tonic M/RPC | Difference |
|---|---|---|---:|---:|---:|
| client | native/prost/tonic/prost | bidi, 1KiB, gzip | 2.46802 | 2.78490 | -11.38% |
| client | native/prost/tonic/prost | bidi_pipelined, 1KiB, gzip | 2.44591 | 2.75259 | -11.14% |
| client | native/prost/tonic/prost | client_stream, 1KiB, gzip | 2.02151 | 2.23726 | -9.64% |
| client | native/prost/tonic/prost | server_stream, 1KiB, gzip | 1.03140 | 1.23546 | -16.52% |
| client | native/prost/tonic/prost | unary, 1KiB, gzip | 0.62420 | 0.73845 | -15.47% |
| client | native/prost/tonic/prost | bidi, 64KiB, gzip | 11.56154 | 12.16869 | -4.99% |
| client | native/prost/tonic/prost | bidi_pipelined, 64KiB, gzip | 11.60359 | 12.11216 | -4.20% |
| client | native/prost/tonic/prost | client_stream, 64KiB, gzip | 10.22561 | 10.70793 | -4.50% |
| client | native/prost/tonic/prost | server_stream, 64KiB, gzip | 3.99439 | 4.22858 | -5.54% |
| client | native/prost/tonic/prost | unary, 64KiB, gzip | 2.89694 | 3.03330 | -4.50% |
| client | native/prost/tonic/prost | unary, 1KiB, identity | 0.02871 | 0.06553 | -56.18% |
| server | tonic/prost/native/prost | bidi, 1KiB, gzip | 2.47412 | 2.77362 | -10.80% |
| server | tonic/prost/native/prost | bidi_pipelined, 1KiB, gzip | 2.44596 | 2.73952 | -10.72% |
| server | tonic/prost/native/prost | client_stream, 1KiB, gzip | 0.97615 | 1.16269 | -16.04% |
| server | tonic/prost/native/prost | server_stream, 1KiB, gzip | 2.04738 | 2.23764 | -8.50% |
| server | tonic/prost/native/prost | unary, 1KiB, gzip | 0.63736 | 0.72741 | -12.38% |
| server | tonic/prost/native/prost | bidi, 64KiB, gzip | 11.49992 | 12.06216 | -4.66% |
| server | tonic/prost/native/prost | bidi_pipelined, 64KiB, gzip | 11.47767 | 12.02873 | -4.58% |
| server | tonic/prost/native/prost | client_stream, 64KiB, gzip | 1.85255 | 2.03688 | -9.05% |
| server | tonic/prost/native/prost | server_stream, 64KiB, gzip | 10.40473 | 10.81482 | -3.79% |
| server | tonic/prost/native/prost | unary, 64KiB, gzip | 2.91142 | 3.00746 | -3.19% |
| server | tonic/prost/native/prost | unary, 1KiB, identity | 0.03998 | 0.05533 | -27.73% |

All22 current native instruction groups win against fresh same-side tonic in both repeats:20gzip and2identity. These are equal-Prost selected scopes only; no pbrs instruction case ran. Pbrs interop byte losses with extra handler work remain separately in native tables. All original repeat ranges, source increases and byte/allocation losses remain in JSON.

## Fresh process plus one RPC

**Includes setup.** No startup subtraction, isolated cold-RPC cost, hardware-cold-cache or shipping-timing claim. Four repeats; the two-RPC control remains in raw records.

Requested process bytes, KiB. These totals are cumulative allocation requests since main, not RSS.

| RPCs/process | Side | Workload | Before | Current | Change | Before min–max | Current min–max |
|---:|---|---|---:|---:|---:|---:|---:|
| 1 | client | unary, 0B, gzip | 471.11 | 439.10 | -6.79% | 471.11–471.11 | 439.09–439.11 |
| 2 | client | unary, 0B, gzip | 868.60 | 804.54 | -7.38% | 868.56–868.65 | 804.43–804.63 |
| 1 | server | unary, 0B, gzip | 468.41 | 436.84 | -6.74% | 468.39–468.42 | 436.82–436.84 |
| 2 | server | unary, 0B, gzip | 869.55 | 806.25 | -7.28% | 869.51–869.58 | 806.25–806.43 |
| 1 | client | unary, 1KiB, identity | 87.98 | 87.98 | +0.00% | 87.97–87.98 | 87.97–87.98 |
| 2 | client | unary, 1KiB, identity | 101.79 | 101.79 | -0.00% | 101.71–105.86 | 101.72–105.71 |
| 1 | server | unary, 1KiB, identity | 84.64 | 85.05 | +0.49% | 84.64–84.92 | 85.05–85.05 |
| 2 | server | unary, 1KiB, identity | 102.21 | 103.12 | +0.90% | 102.21–102.28 | 102.94–103.12 |

All **2 CPU-capture source cost increases**, **0 CPU-capture tonic cost increases** and **5 fresh-process cost increases** remain in the JSON without a cutoff. Counts are cell/side/metric groups; they are not additional captures or test passes.
Cold raw ranges retain all four values and both1/2RPCprocess totals; standard N2−N1 summaries are separate diagnostics.

Callgrind uses release binaries with allocation counting enabled. Instructions are not shipping CPU or latency/throughput.
Both endpoints are separate scopes. Full pbrs interop includes extra handler work; preserve its losses separately from equal-Prost.
All group rows retain original paired ratios/dispositions or all four raw process values. No cutoff hides a positive median cost change.
A 2% CPU classification band is a reporting convention; a 1.60% increase classified tie is still retained.
All three campaigns belong only to7c02. They do not qualify other sources; final ASAN/workspace/resource-day gates remain open.
The separate actual Router causal control48/1800 is not folded into canonical1448/44904 totals.
Combined source changes do not isolate each mechanism; current source concerns and future repairs are not measurements.
