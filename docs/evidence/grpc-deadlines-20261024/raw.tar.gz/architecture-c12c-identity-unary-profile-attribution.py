"""Read only the eight selected native-server identity unary Callgrind profiles."""
from pathlib import Path
from collections import Counter
import gzip, json, re, hashlib
ROOT = Path(__file__).resolve().parent
BASE = ROOT / 'architecture-c12c-cpu-ab'

def read(path):
    text = gzip.open(path, 'rt').read()
    names = {}
    objects, function_objects = {}, {}
    current_object = None
    own, inclusive, calls = Counter(), Counter(), Counter()
    fn = target = None
    edge = False
    summary = totals = None
    for line in text.splitlines():
        if line.startswith('totals: '):
            totals = int(line.split()[1])
        if line.startswith('summary: '):
            summary = int(line.split()[1])
        obj = re.match(r'(c?ob)=\((\d+)\)(?: (.*))?$', line)
        if obj:
            kind, index, name = obj.groups()
            if kind == "ob":
                current_object = index
            if name is not None:
                objects[index] = name
            continue
        match = re.match(r'(c?fn)=\((\d+)\)(?: (.*))?$', line)
        if match:
            kind, index, name = match.groups()
            if name is not None:
                names[index] = name
            if kind == 'fn':
                fn = index
                function_objects[index] = current_object
                edge = False
            else:
                target = index
            continue
        if line.startswith('calls='):
            calls[(fn, target)] += int(line.split()[0].split('=')[1])
            edge = True
            continue
        if re.match(r'^[0-9*+\-]+ ', line):
            value = int(line.split()[1])
            if edge:
                inclusive[(fn, target)] += value
                edge = False
            else:
                own[fn] += value
    def label(index):
        return names.get(index, f'<unresolved ID {index}>')
    mapped = Counter()
    for index, value in own.items():
        mapped[label(index)] += value
    edges = Counter()
    ncalls = Counter()
    for pair, value in inclusive.items():
        edges[(label(pair[0]), label(pair[1]))] += value
    for pair, value in calls.items():
        ncalls[(label(pair[0]), label(pair[1]))] += value
    assert sum(mapped.values()) == totals, (path, totals, sum(mapped.values()))
    object_self = Counter()
    fn_objects = {}
    for index, value in own.items():
        object_name = objects.get(function_objects.get(index), "<unknown object>")
        object_self[object_name] += value
        fn_objects.setdefault(label(index), set()).add(object_name)
    return mapped, edges, ncalls, summary, totals, object_self, {k:sorted(v) for k,v in fn_objects.items()}

profiles, differential = {}, {}
for source in ('baseline', 'candidate'):
    for repeat, cell in ((0, 54), (1, 47)):
        rows = {}
        for n in (10, 20):
            directory = BASE / source / f'n-{n}' / f'cell-{cell:03d}'
            run = json.loads((directory / 'run.json').read_text())
            c = run['cell']
            assert c == dict(pair=['tonic','prost','native','prost'], shape='unary',
                             payload_bytes=1024,tls=False,compression='identity',
                             connections=1,in_flight=1,repeat=repeat)
            assert run['passed'] is True
            path = directory / 'server.callgrind.gz'
            own, edges, calls, summary, totals, object_self, fn_objects = read(path)
            rows[n] = own, edges, calls, object_self
            profiles[f'{source}:{repeat}:{n}'] = dict(path=str(path), summary_Ir=summary, totals_Ir=totals,
                self_Ir=sum(own.values()), object_self_Ir=dict(object_self), function_objects=fn_objects, compressed_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
        metrics = []
        for index in range(4):
            a, b = rows[10][index], rows[20][index]
            metrics.append(Counter({key:(b[key]-a[key])/10 for key in a.keys()|b.keys()}))
        differential[(source, repeat)] = metrics

functions = []
keys=set().union(*(row[0].keys() for row in differential.values()))
for name in keys:
    base=[differential[('baseline',r)][0][name] for r in (0,1)]
    cand=[differential[('candidate',r)][0][name] for r in (0,1)]
    delta=[cand[r]-base[r] for r in (0,1)]
    functions.append(dict(function=name, baseline_self_Ir_per_rpc=base,
                          candidate_self_Ir_per_rpc=cand, delta_per_repeat=delta,
                          delta_mean=sum(delta)/2))
functions.sort(key=lambda r:abs(r['delta_mean']), reverse=True)
edges=[]
keys=set().union(*(row[1].keys() for row in differential.values()))
for caller,callee in keys:
    base=[differential[('baseline',r)][1][(caller,callee)] for r in (0,1)]
    cand=[differential[('candidate',r)][1][(caller,callee)] for r in (0,1)]
    calls_base=[differential[('baseline',r)][2][(caller,callee)] for r in (0,1)]
    calls_cand=[differential[('candidate',r)][2][(caller,callee)] for r in (0,1)]
    edges.append(dict(caller=caller,callee=callee,baseline_inclusive_Ir_per_rpc=base,
                      candidate_inclusive_Ir_per_rpc=cand,delta_mean=(sum(cand)-sum(base))/2,
                      baseline_calls_per_rpc=calls_base,candidate_calls_per_rpc=calls_cand))
edges.sort(key=lambda r:abs(r['delta_mean']),reverse=True)
result=dict(qualified=False,scope='only equal-Prost native server identity unary1KiB 1/1 repeats0,1 N10/20',
            profiles=profiles,functions=functions,edges=edges,
            total_self_Ir_per_rpc={f'{s}:{r}':sum(differential[(s,r)][0].values()) for s in ('baseline','candidate') for r in (0,1)},
            limits=['Inclusive edge costs overlap and must not be summed.',
                    'Functions may be renamed or folded across builds; unmatched symbols are not causal additions.',
                    'Profile source positions are stripped; symbol attribution does not prove source-line attribution.',
                    'N/2N subtraction can leave negative function-level scheduling/setup deltas.'])
summary = json.loads((ROOT/'architecture-c12c-cpu-ab-summary.json').read_text())
result['source_pins'] = {source:{'source':row['source'],'binary_sha256':row['binary_sha256']} for source,row in summary['source_pins'].items()}
assert all(row['totals_Ir']-row['summary_Ir'] == 168 for row in profiles.values())
result['parser_validation'] = 'Function self Ir equals each profile totals; totals-summary is168 for all8 profiles, so N/2N subtraction matches the harness summary differential exactly.'
(ROOT/'architecture-c12c-identity-unary-profile-attribution.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result['total_self_Ir_per_rpc']))
for row in functions[:22]:
    print(round(row['delta_mean'],2),row['baseline_self_Ir_per_rpc'],row['candidate_self_Ir_per_rpc'],row['function'][:190])
