# C12b resource and deadline diagnostics

Prepared controllers only. No compiler, Rust fixture, resource test, network,
publication or cache cleanup has run through this preparation. Static validation
includes Python parsing, Rust syntax parsing and synthetic controller decisions.
Those checks are not production tests or a completed duration run.

The pinned source is `40f219fa515034b556df7f39e3e3947e364a2ce1`.
The immutable `architecture-c12b-source-pins.json` SHA256 is
`12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1`.
The controllers read and verify that file; they do not rewrite it.

## Two separate workloads

| Diagnostic | What runs | What it does not prove |
|---|---|---|
| General resources | The unchanged pinned `scripts/grpc-resource-campaign.py`, seed 20261002, release profile, 86,400 requested seconds | Every custom-service deadline case, all platforms, shipping performance, or overall production readiness |
| Repeated deadline fixture | The three original, fifteen extended and five terminal-accounting independent-peer cases, sequentially in one process, for 86,400 actual wall seconds | Real-time timer scheduling, real TCP/TLS coverage, new distinct tests per cycle, or an inferred RPC count |

Both day processes use the original fixed limits: address space 1 GiB, 128 file
descriptors, 4,096 same-UID processes and 86,430 CPU seconds. The deadline preview
uses 30 requested actual seconds and a 60-second CPU limit. Limits apply to the
test ELF, not its compiler.

The deadline cases retain their original controlled Tokio clock and their raw
peer, status, ownership, cancellation and recovery assertions. A separate
`std::Instant` measures real elapsed duration. Each cycle must return descriptors
and live Tokio tasks to the counts measured before the first cycle; no warmup
baseline reset hides a growing count. The copied cases also exercise their own
service/producer Drop and lifecycle assertions.

The wrapper samples RSS and the existing idle decoded-buffer gauges. Idle cache
must be zero, leases balanced, and reported peak capacity within the existing
16 MiB budget. These gauges do not represent all memory. RSS remains subject to
the address-space cap; no universal leak-free claim follows from a finite run.
One real second of quiet follows an already quiescent cycle to limit background
load. A separate supervisor rejects a 60-second gap without a completed cycle,
including a synchronous deadlock that an async watchdog cannot preempt.

## Test-only source overlay

The static staged fixture was generated from the pinned Git objects, not from a
mutable working tree. `architecture-c12b-deadline-fixture-pinned.json` records its
source hashes, all discovered case names, wrapper hash and exact 23-case count.
Only Tokio test attributes are removed; each source file is placed in a separate
module and all discovered cases are called from that module. Assertions, test
budgets and call shapes are retained.

The later prepare action creates a new detached
`work/architecture-c12b-deadline`. Every tracked file except historical
`docs/evidence/` contents is hashed against the candidate Git blobs. The only
addition is untracked `pbrs-grpc/tests/deadline_sustained.rs`. No runtime file,
manifest, lockfile or existing frozen checkout changes.

The release build copies its ELF and closed compiler logs into an immutable Q
package. It verifies all manifest features, `copy-counts`/`grpc-web`, optimization
level 3, disabled debug assertions, test profile, Rust/Cargo 1.99.1 and unchanged
runtime source. The same copied ELF runs its preview and day.

## Commands for the root agent

Run from `/workspace/pure-protobuf`. The static fixture is already staged under
the root's preparation grant. Worktree creation, builds and execution still need
their own root action; no command below has been run by this preparation.

```sh
pins_sha=12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1
python3 work/qualification/architecture-c12b-soaks.py prepare-deadline \
  --pins-sha256 "$pins_sha" --execute
python3 work/qualification/architecture-c12b-soaks.py build-deadline \
  --pins-sha256 "$pins_sha" --execute
python3 work/qualification/architecture-c12b-soaks.py preview-deadline \
  --pins-sha256 "$pins_sha" --execute
```

Build readiness requires clean C12b pins and the passing prechecks. Day readiness
additionally requires passing resource preview, benchmark build, native counters,
instruction counters, ASAN and full workspace records, including their pinned
closed logs. If the optional cold-native phase has a record, it must pass too.
Reclaimed ASAN compiler executables remain hash metadata; their absence does not
rewrite a successful test phase.

```sh
python3 work/qualification/architecture-c12b-soaks.py check-ready \
  --kind resource --pins-sha256 "$pins_sha"
python3 work/qualification/architecture-c12b-soaks.py check-ready \
  --kind deadline --pins-sha256 "$pins_sha"
```

Each day uses a separate root grant JSON with these required fields (substitute
`resource` or `deadline` in the action):

```json
{
  "source_pin": "40f219fa515034b556df7f39e3e3947e364a2ce1",
  "pins_sha256": "12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1",
  "root_granted": true,
  "action": "launch-c12b-resource-day"
}
```

```sh
python3 work/qualification/architecture-c12b-soaks.py launch --kind resource \
  --pins-sha256 "$pins_sha" --grant ROOT_RESOURCE_GRANT_JSON --execute
python3 work/qualification/architecture-c12b-soaks.py launch --kind deadline \
  --pins-sha256 "$pins_sha" --grant ROOT_DEADLINE_GRANT_JSON --execute
```

The resource day still invokes the original campaign's release build. Its
exclusive campaign directory is nested under the orchestration directory:
`resource-architecture-c12b-day/campaign/`. Its launch record names that path.
The repeated deadline day uses `resource-architecture-c12b-deadline-day/`.
All mutable output, supervisor state and publication state stay in these
`resource-*` directories, outside immutable evidence selection.

## Terminal publication

Supervisors are detached, copy and pin their harness, preserve exclusive attempt
ownership, and attempt publication after a pass, failure or incomplete run.
Duplicate supervisor invocation cannot overwrite prior terminal evidence.
Missing reports, changed source, short duration or failed validation cannot pass.
Publisher execution failures are retained explicitly.

The publisher creates immutable finite copies before archiving. ELF bytes and
Python bytecode are omitted, while executable hashes remain. Its three normal
main-push attempts use separate sparse publication worktrees, preserving all
other evidence in Git without checking out approximately 794 MB of historical
capsules per attempt. It never force-pushes, rebases or resets a working tree.

The older C8/C11 days and all held C12 preparation, their source pins, helpers, binaries, outputs and publishers
remain untouched. Their outcomes are separate evidence and cannot certify C12b.

## Disk and compiler window

No cache cleanup is part of these controllers. A measured sparse checkout of
source `40f219fa` contains 1,723 non-evidence tracked files and 38,959,223 logical
bytes, excluding 793,907,823 bytes of historical evidence. Worktree preparation
requires at least 100 MiB free; this covers source and proof overhead, not a build.

A deadline release build requires at least 2 GiB free at entry and an explicit
root compiler window. That is a conservative start gate, not a proven peak bound.
The existing shared `work/rpc-target` was about 1 GiB at preparation; exact extra
space depends on reusable Cargo artifacts. Root must account for the concurrent
qualification pipeline, retained ELF/log packages and old running diagnostics.
The standard resource-day controller still invokes the original release build;
keep equivalent headroom before that launch too. No compiler runs concurrently
with performance captures.

Static source inspection finds all five added accounting cases use paused Tokio
time and local accepted/before Instants, with no clock resume or crate-relative
self import that would change when wrapped. The generated 23-case fixture passes
Rust syntax parsing. Shared-process compatibility still needs its actual build
and 30-second preview; no duration qualification is claimed from this inspection.
