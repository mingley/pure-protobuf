#!/usr/bin/env python3
"""Read-only validation shared by the C12 results writer and packager.

Preparation runs no checks. Callers must supply the final immutable pin digest;
all source and execution identities come from the retained records, not labels.
"""
import collections
import datetime
import hashlib
import json
import math
from pathlib import Path, PurePosixPath
import re
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
PINS = Q / 'architecture-c12c-source-pins.json'
TREE = ROOT / 'work/architecture-c12c'
BASELINE_TREE = ROOT / 'work/architecture-c11'
BASELINE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
DEST = ROOT / 'docs/evidence/grpc-deadlines-20261024'
WORKSPACE_REPOSITORY = '8144576f74bcf290951a65235e3bb50f24710b71'
WORKSPACE_PRIOR = '33eaf842d640dc2df3e0cc14db194adcc601e616'
WORKSPACE_TREE = ROOT / 'work/architecture-c12c-workspace-final'
WORKSPACE_FIXTURE = 'pbrs-grpc/tests/service_config.rs'
WORKSPACE_EVIDENCE = {'docs/evidence/README.md'} | {
    'docs/evidence/' + folder + '/' + name
    for folder in ('grpc-decode-reuse-soak-20261023', 'grpc-prost-cache-diagnostic-20261023')
    for name in ('README.md', 'check.py', 'manifest.json', 'raw.tar.gz', 'results.json')}
WORKSPACE_ALLOWED = WORKSPACE_EVIDENCE | {WORKSPACE_FIXTURE}
ACCOUNTING = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']
EMPTY = hashlib.sha256(b'').hexdigest()
REQUIRED = {
    'prechecks': {'format', 'grpc-tests', 'clippy-root-alltargets', 'clippy-grpc-alltargets',
                  'clippy-adapter-example', 'examples', 'rpc-benchmark-correctness',
                  'tonic-benchmark-correctness', 'rustdoc', 'msrv', 'msrv-zstd'},
    'resource-preview': {'resource-preview-run'}, 'build-benchmark': {'rpc-build'},
    'native': {'native-captures', 'native-summary'}, 'cpu': {'cpu-captures', 'cpu-summary'},
    'cold-native': {'cold-native-captures', 'cold-native-summary', 'cold-native-raw-summary-run'},
    'asan': {'asan-selected', 'asan-inbound-owner'}, 'workspace': {'workspace'},
}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def encoded(value):
    return (json.dumps(value, indent=2, allow_nan=False) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(data)
    return h.hexdigest()


def safe_name(name):
    p = PurePosixPath(name)
    return (bool(name) and not p.is_absolute() and str(p) == name
            and not any(part in ('.', '..') for part in p.parts)
            and '\\' not in name and ':' not in name)


def checked_path(path):
    path = Path(path).absolute()
    assert not path.is_symlink() and path.is_file(), path
    assert path.resolve().is_relative_to(ROOT.resolve()), path
    return path


def ref(path):
    path = checked_path(path)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def observe(path, observed):
    item = ref(path)
    path = Path(item['path'])
    if path in observed:
        assert observed[path] == item, 'retained evidence changed: ' + str(path)
    observed[path] = item
    return item


def read_json(path, observed):
    item = observe(path, observed)
    data = Path(item['path']).read_bytes()
    assert hashlib.sha256(data).hexdigest() == item['sha256']
    return json.loads(data)


def verify_reference(item, observed):
    assert set(('path', 'bytes', 'sha256')) <= set(item), item
    assert observe(Path(item['path']), observed) == item, item


def verify_observed(observed):
    for path, item in observed.items():
        assert ref(path) == item, 'retained input changed: ' + str(path)


def git(*arguments, cwd=ROOT):
    return subprocess.check_output(['git', *arguments], cwd=cwd)


def source(cwd):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd).decode().strip(),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd).decode().strip()}


def summaries(path):
    return [{'status': state, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
            for state, passed, failed, ignored in re.findall(
                r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', Path(path).read_text())]


def totals(rows):
    return {key: sum(row[key] for row in rows) for key in ('passed', 'failed', 'ignored')}


def finite(value):
    return type(value) in (int, float) and math.isfinite(value)


def load_pins(pin_path, pin_sha, checkout, observed):
    assert re.fullmatch(r'[0-9a-f]{64}', pin_sha or ''), 'explicit immutable --pins-sha256 required'
    pin_path = Path(pin_path).resolve()
    assert pin_path.parent == Q and pin_path.name == 'architecture-c12c-source-pins.json', pin_path
    pins = read_json(pin_path, observed)
    assert observed[pin_path]['sha256'] == pin_sha
    assert pins['schema'] == 'pbrs.c12c-source-pins.v1'
    assert pins['candidate_runtime'] == '7c02eb387a6785d6e914146babe34f0902a6dd62'
    assert pins['baseline_runtime'] == BASELINE and pins['qualified'] is False
    candidate = pins['candidate_runtime']
    assert re.fullmatch(r'[0-9a-f]{40}', candidate) and candidate != BASELINE
    assert {'server_deadline', 'server_deadline_extended', 'server_terminal_accounting'} == set(pins['asan_extra_targets'])
    assert source(checkout) == {'head': candidate, 'status': ''}, 'final frozen checkout is not clean'
    assert source(BASELINE_TREE) == {'head': BASELINE, 'status': ''}
    assert git('rev-parse', 'HEAD^{tree}', cwd=checkout).decode().strip() == pins['candidate_tree']
    for item in pins['inputs'] + [pins['baseline_build'], pins['baseline_binary']]:
        verify_reference(item, observed)
    for name, sha in pins['identical_harness'].items():
        assert safe_name(name) and digest(checkout / name) == digest(BASELINE_TREE / name) == sha, name
        assert git('show', candidate + ':' + name) == (checkout / name).read_bytes()
        assert git('show', BASELINE + ':' + name) == (BASELINE_TREE / name).read_bytes()
    return pins


def phase_paths(mapping, candidate, observed):
    assert mapping is not None, 'C12c requires an explicit complete phase map; no fallback to older failed or superseded states'
    paths = {name: Q / ('architecture-c12-' + name + '-state.json') for name in REQUIRED}
    if mapping:
        value = read_json(mapping, observed)
        assert value['schema'] == 'pbrs.c12c-workspace-final-phase-map.v1'
        assert value['runtime_source'] == candidate and value['workspace_repository_source'] == WORKSPACE_REPOSITORY
        assert value['qualified'] is False
        assert set(value['phases']) == set(REQUIRED), 'every canonical phase must be mapped explicitly'
        for name, relative in value['phases'].items():
            assert safe_name(relative) and len(PurePosixPath(relative).parts) == 1
            assert relative.startswith('architecture-c12c-') and relative.endswith('-state.json')
            if name == 'workspace':
                assert relative == 'architecture-c12c-workspace-final-state.json'
            paths[name] = Q / relative
    return paths


def workspace_git_blobs(commit):
    rows = []
    for entry in git('ls-tree', '-r', '-l', '-z', commit).split(b'\0'):
        if entry:
            header, name = entry.split(b'\t', 1)
            mode, kind, blob, size = header.decode().split()
            assert kind == 'blob' and mode in ('100644', '100755', '120000')
            rows.append({'path': name.decode(), 'mode': mode, 'git_blob': blob, 'bytes': int(size)})
    return sorted(rows, key=lambda row: row['path'])


def workspace_final_contract(state, pins, observed):
    runtime = pins['candidate_runtime']
    clean = {'head': WORKSPACE_REPOSITORY, 'status': ''}
    assert state['schema'] == 'pbrs.c12c-workspace-final-state.v1'
    assert state['mode'] == 'workspace' and state['state'] == 'passed' and state['active'] is None and state['qualified'] is False
    assert state['pins'] == ref(PINS)
    assert state['runtime_source'] == runtime == '7c02eb387a6785d6e914146babe34f0902a6dd62'
    assert state['source'] == state['source_after'] == clean
    assert state['checkout'] == str(WORKSPACE_TREE) and source(WORKSPACE_TREE) == clean
    assert state['free_bytes_before'] >= 8 * 1024**3
    for name in ('runner', 'controller', 'inputs'):
        verify_reference(state[name], observed)
    assert state['runner']['path'] == str(Q / 'architecture-c12c-workspace-final.py')
    assert state['inputs']['path'] == str(Q / 'architecture-c12c-workspace-final-inputs.json')
    assert state['controller'] == next(i for i in pins['inputs'] if i['path'] == str(Q / 'architecture-c12c-qualification.py'))
    assert state['runner']['sha256'] == 'f70c4bdc2d86b62026dcec56a000adbfe9074cfcb98a3e593b8fc3899637dcda'
    assert state['inputs']['sha256'] == '8d0a0b1eac7573bf124682e66163a60002ed1b317c991ce4e11446b2f3dd68e3'
    inputs = read_json(Path(state['inputs']['path']), observed)
    assert inputs['schema'] == 'pbrs.c12c-workspace-final-inputs.v1' and inputs['qualified'] is False
    assert inputs['runtime_source'] == runtime and inputs['repository_source'] == WORKSPACE_REPOSITORY
    assert inputs['prior_repository_source'] == WORKSPACE_PRIOR
    assert inputs['fixture_sha256'] == hashlib.sha256(git('show', WORKSPACE_REPOSITORY + ':' + WORKSPACE_FIXTURE)).hexdigest()
    assert state['previous_attempts'] == inputs['previous_attempts'] and len(state['previous_attempts']) == 8
    for item in inputs['previous_attempts'] + inputs['fixture_evidence'] + inputs['passed_phase_states']:
        verify_reference(item, observed)
    expected_previous = {str(Q / (prefix + suffix))
        for prefix in ('architecture-c12c-workspace', 'architecture-c12c-workspace-complete')
        for suffix in ('-state.json', '.json', '.stdout', '.stderr')}
    assert {item['path'] for item in state['previous_attempts']} == expected_previous
    for prefix, failed_name in [('architecture-c12c-workspace', 'test_documentation_links_and_anchors_are_valid'),
                                ('architecture-c12c-workspace-complete', 'lb_selection_skips_unregistered_and_typed')]:
        old = read_json(Q / (prefix + '-state.json'), observed)
        assert old['state'] == 'failed' and old['source'] == old['source_after'] == {'head': runtime, 'status': ''}
        assert old['pins'] == ref(PINS) and len(old['checks']) == 1
        check = old['checks'][0]
        assert check['name'] == 'workspace' and check['exit_code'] == 101 and check['targets'] == 144
        assert check['totals'] == {'passed': 3811, 'failed': 1, 'ignored': 9}
        assert totals(summaries(Q / (prefix + '.stdout'))) == check['totals']
        assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', (Q / (prefix + '.stdout')).read_text(), re.MULTILINE)) == {failed_name}
    for color, code, expected in [('red', 101, [(0, 1, 0)]), ('green', 0, [(1, 0, 0), (29, 0, 0)])]:
        prefix = Q / ('architecture-c12c-lb-snapshot-' + color)
        record = read_json(prefix.with_suffix('.json'), observed)
        assert record['exit_code'] == code and not record.get('timeout') and record['source']['head'] == WORKSPACE_PRIOR
        assert [(r['passed'], r['failed'], r['ignored']) for r in summaries(prefix.with_suffix('.stdout'))] == expected
    blobs = {commit: workspace_git_blobs(commit) for commit in (runtime, WORKSPACE_PRIOR, WORKSPACE_REPOSITORY)}
    assert len(blobs[runtime]) == 3780 and len(blobs[WORKSPACE_PRIOR]) == len(blobs[WORKSPACE_REPOSITORY]) == 3790
    maps = {commit: {row['path']: row for row in rows} for commit, rows in blobs.items()}
    rmap, pmap, fmap = (maps[c] for c in (runtime, WORKSPACE_PRIOR, WORKSPACE_REPOSITORY))
    paths = set(rmap) | set(pmap) | set(fmap)
    assert {p for p in paths if rmap.get(p) != pmap.get(p)} == WORKSPACE_EVIDENCE
    assert {p for p in paths if pmap.get(p) != fmap.get(p)} == {WORKSPACE_FIXTURE}
    assert {p for p in paths if rmap.get(p) != fmap.get(p)} == WORKSPACE_ALLOWED
    assert git('rev-parse', WORKSPACE_REPOSITORY + '^').decode().strip() == WORKSPACE_PRIOR
    assert git('rev-parse', runtime + ':pbrs-grpc/src') == git('rev-parse', WORKSPACE_REPOSITORY + ':pbrs-grpc/src')
    proofs = []
    for key_name, phase, filename in [('runtime_equivalence', 'before', 'architecture-c12c-workspace-final-equivalence.json'),
                                     ('runtime_equivalence_after', 'after', 'architecture-c12c-workspace-final-equivalence-after.json')]:
        item = state[key_name]
        assert item['path'] == str(Q / filename)
        verify_reference(item, observed)
        proof = read_json(Path(item['path']), observed)
        assert proof['schema'] == 'pbrs.c12c-workspace-final-equivalence.v1' and proof['qualified'] is False
        assert proof['runtime_source'] == runtime and proof['repository_source'] == clean and proof['prior_repository_source'] == WORKSPACE_PRIOR
        assert proof['runtime_tree'] == pins['candidate_tree']
        assert proof['repository_tree'] == git('rev-parse', WORKSPACE_REPOSITORY + '^{tree}').decode().strip()
        assert proof['prior_repository_tree'] == git('rev-parse', WORKSPACE_PRIOR + '^{tree}').decode().strip()
        assert proof['source_before'] == proof['source_after'] == clean and proof['physical_verification_phase'] == phase
        for field, commit in [('runtime_git_blobs', runtime), ('prior_repository_git_blobs', WORKSPACE_PRIOR), ('repository_git_blobs', WORKSPACE_REPOSITORY)]:
            assert proof[field] == blobs[commit]
        assert proof['allowed_runtime_differences'] == sorted(WORKSPACE_ALLOWED)
        assert proof['fixture_diff_from_prior'] == {'path': WORKSPACE_FIXTURE, 'from_blob': pmap[WORKSPACE_FIXTURE]['git_blob'], 'to_blob': fmap[WORKSPACE_FIXTURE]['git_blob']}
        assert proof['changed_entries'] == [{'path': path, 'runtime': rmap.get(path), 'prior_repository': pmap.get(path), 'repository': fmap.get(path)} for path in sorted(WORKSPACE_ALLOWED)]
        assert proof['complete_checkout'] == {'tracked_blob_count': len(blobs[WORKSPACE_REPOSITORY]),
            'total_tracked_bytes': sum(row['bytes'] for row in blobs[WORKSPACE_REPOSITORY]), 'tracked_blobs': blobs[WORKSPACE_REPOSITORY]}
        assert proof['fixture_evidence'] == inputs['fixture_evidence']
        for name in ('pins', 'inputs', 'controller', 'runner'):
            assert proof[name] == state[name]
        proofs.append(proof)
    for field in ('runtime_git_blobs', 'prior_repository_git_blobs', 'repository_git_blobs', 'complete_checkout', 'changed_entries', 'fixture_evidence'):
        assert proofs[0][field] == proofs[1][field]
    return {'runtime_source': runtime, 'repository_source': WORKSPACE_REPOSITORY,
            'before': state['runtime_equivalence'], 'after': state['runtime_equivalence_after'],
            'allowed_changed_paths': sorted(WORKSPACE_ALLOWED), 'complete_checkout': proofs[1]['complete_checkout'],
            'scope': 'Actual workspace repository commit is distinct from measured runtime. Runner checked complete physical tracked bytes/modes/symlinks before and after; validator independently matches every Git blob/mode/size and exact allowed fixture/prior-publication differences.'}


def validate_phase(name, path, pins, pin_path, observed):
    state = read_json(path, observed)
    clean = {'head': WORKSPACE_REPOSITORY if name == 'workspace' else pins['candidate_runtime'], 'status': ''}
    assert state['state'] == 'passed' and state['active'] is None and state['qualified'] is False, path
    assert state['mode'] == name and state['source'] == state['source_after'] == clean, path
    assert state['pins'] == ref(pin_path), path
    if name == 'workspace':
        workspace_final_contract(state, pins, observed)
    checks = state['checks']
    names = [check['name'] for check in checks]
    assert len(names) == len(set(names)) and REQUIRED[name] <= set(names), names
    for check in checks:
        assert check['exit_code'] == 0 and check['source_after'] == clean, check['name']
        for item in check['files']:
            verify_reference(item, observed)
        records = [Path(row['path']) for row in check['files'] if row['path'].endswith('.json')]
        stdouts = [Path(row['path']) for row in check['files'] if row['path'].endswith('.stdout')]
        assert len(records) == len(stdouts) == 1
        record = read_json(records[0], observed)
        assert record['command'] == check['command'] and record['exit_code'] == 0
        assert record['source'] == {'head': clean['head'], 'diff_sha256': EMPTY, 'untracked': {}}
        assert not record.get('timeout') and finite(record['duration_seconds']) and record['duration_seconds'] >= 0
        parsed = summaries(stdouts[0])
        assert parsed == check['summaries'] and totals(parsed) == check['totals']
        assert len(parsed) == check['targets']
        assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed)
        if name in ('workspace', 'asan') or check['name'] in ('grpc-tests', 'rpc-benchmark-correctness', 'tonic-benchmark-correctness'):
            assert parsed and check['totals']['passed'] > 0
    if name == 'workspace':
        args = checks[0]['command']
        assert all(arg in args for arg in ('--workspace', '--all-features', '--no-fail-fast', '--test-threads=4'))
        assert record['timeout_seconds'] == 7200 and record['cwd'] == str(WORKSPACE_TREE)
        assert record['environment']['CARGO_BUILD_JOBS'] == '2'
        assert record['environment']['CARGO_TARGET_DIR'] == str(ROOT / 'work/stable-target')
        assert record['environment']['RUSTUP_TOOLCHAIN'] == 'stable'
    if name == 'asan':
        targets = {'decode_workspace', 'closed_upload_response', 'retry_safety', 'pump_panic', *pins['asan_extra_targets']}
        assert {Path(path).name.rsplit('-', 1)[0] for path in state['executables']} == {'pbrs_grpc', 'lifecycle', *targets}
        for exe, item in state['executables'].items():
            assert item['path'] == exe and re.fullmatch(r'[0-9a-f]{64}', item['sha256']) and item['bytes'] > 0
            if Path(exe).exists():
                verify_reference(item, observed)
        args = checks[0]['command']
        assert '+nightly-2025-06-26' in args and '-Zbuild-std' in args
    return state


def validate_build(pins, states, observed):
    build_path = Path(states['build-benchmark']['build']['path'])
    verify_reference(states['build-benchmark']['build'], observed)
    verify_reference(states['build-benchmark']['binary'], observed)
    build = read_json(build_path, observed)
    baseline = read_json(Path(pins['baseline_build']['path']), observed)
    assert build['source']['commit'] == pins['candidate_runtime'] and build['source']['tree'] == pins['candidate_tree']
    assert baseline['source']['commit'] == BASELINE
    assert build['exit_code'] == baseline['exit_code'] == 0
    assert build['tools'] == baseline['tools'] == pins['tools_required']
    assert all('1.99.1' in value for value in build['tools'].values())
    assert build['binary_sha256'] == states['build-benchmark']['binary']['sha256']
    for current_path, record in [(build_path, build), (Path(pins['baseline_build']['path']), baseline)]:
        for name, sha in record['files'].items():
            assert safe_name(name)
            item = observe(current_path.parent / name, observed)
            assert item['sha256'] == sha
    return build


def validate_preview(pins, state, checkout, observed):
    verify_reference(state['report'], observed)
    verify_reference(state['binary'], observed)
    report = read_json(Path(state['report']['path']), observed)
    assert report['source']['commit'] == pins['candidate_runtime'] and report['source']['dirty'] is False
    assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
    assert report['exit_code'] == 0 and report['smoke'] == {'status': 'passed', 'failures': []}
    assert report['build']['profile'] == 'release'
    assert report['binary']['sha256'] == state['binary']['sha256']
    limits = {key: {'soft': value, 'hard': value} for key, value in {
        'address_space': 1073741824, 'file_descriptors': 128,
        'same_uid_processes': 4096, 'cpu_seconds': 60}.items()}
    assert report['process_limits'] == report['process_limits_requested'] == limits
    # The unchanged source's validator remains the authority for the fixture's
    # full event/resource contract, rather than duplicating its evolving rules.
    import runpy
    errors = runpy.run_path(str(checkout / 'scripts/grpc-resource-campaign.py'))['validate_report'](report)
    assert not errors, errors
    return report


def identity(cell):
    return json.dumps(cell, sort_keys=True, separators=(',', ':'))


def validate_campaign(kind, state, pins, candidate_binary, observed):
    verify_reference(state['summary'], observed)
    summary_path = Path(state['summary']['path'])
    summary = read_json(summary_path, observed)
    directory = summary_path.with_name(summary_path.name.removesuffix('-summary.json'))
    campaign = read_json(directory / 'campaign.json', observed)
    assert campaign['state'] == 'finished' and campaign['passed'] is True and campaign['qualified'] is False
    assert summary['passed'] is True and summary['state'] == 'finished' and summary['controller_passed'] is True
    assert summary['qualified'] is False and summary['source_pins'] == campaign['versions']
    assert summary['controller_sha256'] == campaign['controller_sha256']
    assert not any(summary[key] for key in ('failed_captures', 'missing_keys', 'extra_keys', 'status_errors'))
    assert summary['retained_captures'] == summary['expected_captures'] == campaign['expected_captures']
    assert campaign['phase'] == summary['phase'] == ('callgrind' if kind == 'cpu' else 'native')
    assert campaign['abba'] is True and campaign['pilot'] is False
    for version, commit in [('baseline', BASELINE), ('candidate', pins['candidate_runtime'])]:
        value = campaign['versions'][version]
        assert value['source']['commit'] == value['build_record']['source']['commit'] == commit
        assert value['build_record']['tools'] == pins['tools_required']
        expected_binary = pins['baseline_binary']['sha256'] if version == 'baseline' else candidate_binary
        assert value['binary_sha256'] == value['build_record']['binary_sha256'] == expected_binary
    cell_file = Q / ('architecture-c12c-' + ('cold-native' if kind == 'cold-native' else 'cpu' if kind == 'cpu' else 'native') + '-cells.json')
    cell_input = observe(cell_file, observed)
    assert campaign['workloads_input']['sha256'] == cell_input['sha256']
    expected_cells = json.loads(cell_file.read_text())
    repeats = 4 if kind == 'cold-native' else 2
    counts = [1, 2] if kind == 'cold-native' else [10, 20] if kind == 'cpu' else [25, 50]
    assert campaign['rpc_counts'] == counts
    expected_cell_values = {identity(dict(cell, repeat=repeat)) for cell in expected_cells for repeat in range(repeats)}
    assert {identity(cell) for cell in campaign['cells']} == expected_cell_values
    assert len(campaign['cells']) == len(expected_cell_values)
    expected = {(version, count, cell) for version in ('baseline', 'candidate') for count in counts for cell in expected_cell_values}
    seen = set()
    accounting = {version: collections.Counter({key: 0 for key in ACCOUNTING}) for version in ('baseline', 'candidate')}
    for capture in campaign['captures']:
        assert safe_name(capture['path']) and capture['passed'] is True and not capture.get('error')
        run = read_json(directory / capture['path'], observed)
        key = (capture['version'], capture['count'], identity(run['cell']))
        assert key in expected and key not in seen and run['passed'] is True, key
        seen.add(key)
        count = capture['count']
        metrics = run['metrics']
        assert all(type(metrics[name]) is int and metrics[name] == count for name in ACCOUNTING[:4])
        assert all(type(metrics[name]) is int and metrics[name] == 0 for name in ACCOUNTING[4:])
        assert not metrics.get('status_errors') and run['client_exit_code'] == 0
        accounting[capture['version']].update({name: metrics[name] for name in ACCOUNTING})
    assert seen == expected and len(seen) == campaign['expected_captures']
    actual = {version: dict(value) for version, value in accounting.items()}
    assert actual == summary['actual_rpc_totals']
    return {'summary': summary, 'campaign': campaign, 'summary_path': summary_path,
            'directory': directory, 'actual_rpc_totals': actual, 'captures': len(seen)}


def validate_history(observed):
    required = {
        'architecture-c12-deadline-red': (101, {'passed': 0, 'failed': 3, 'ignored': 0}),
        'architecture-c12-first-check': (101, {'passed': 0, 'failed': 0, 'ignored': 0}),
        'architecture-c12-first-check-v2': (101, {'passed': 713, 'failed': 1, 'ignored': 1}),
        'architecture-c12-first-check-v3': (0, {'passed': 734, 'failed': 0, 'ignored': 1}),
        'architecture-c12-grpc-tests': (101, {'passed': 1738, 'failed': 1, 'ignored': 1}),
        'architecture-c12b-unary-red': (101, {'passed': 0, 'failed': 5, 'ignored': 0}),
        'architecture-c12b-fix': (0, {'passed': 739, 'failed': 0, 'ignored': 1}),
        'architecture-c12b-slow-writer-final-target': (0, {'passed': 25, 'failed': 0, 'ignored': 0}),
        'architecture-c12-v2-raw-original': (0, {'passed': 3, 'failed': 0, 'ignored': 0}),
        'architecture-c12-v2-raw-extended': (101, {'passed': 12, 'failed': 2, 'ignored': 0}),
    }
    rows = []
    for prefix, (code, expected) in required.items():
        path = Q / (prefix + '.json')
        record = read_json(path, observed)
        observe(Q / (prefix + '.stdout'), observed)
        observe(Q / (prefix + '.stderr'), observed)
        parsed = summaries(Q / (prefix + '.stdout'))
        assert record['exit_code'] == code and totals(parsed) == expected, prefix
        rows.append({'name': prefix, 'record': ref(path), 'actual_source': record['source'],
                     'exit_code': code, 'totals': expected,
                     'scope': 'compile failure before tests' if prefix == 'architecture-c12-first-check' else 'actual test execution; original disposition preserved'})
    for dirname in ('architecture-c12-deadline-red-source', 'architecture-c12-first-check-source', 'architecture-c12-first-check-v2-source'):
        path = Q / dirname / 'source.json'
        snapshot = read_json(path, observed)
        for item in snapshot['files']:
            assert safe_name(item['path'])
            actual = observe(path.parent / item['path'], observed)
            assert actual['sha256'] == item['sha256'] and actual['bytes'] == item['bytes']
    red = read_json(Q / 'architecture-c12-deadline-red-source/source.json', observed)
    assert red['deadline_runtime_changes_before_red'] is False and red['concurrent_gzip_change_present'] is True
    for item in red['files']:
        if item['path'].startswith(('pbrs-grpc/src/server/', 'pbrs-grpc/src/h2_backend/', 'pbrs-grpc/src/transport/')):
            assert hashlib.sha256(git('show', BASELINE + ':' + item['path'])).hexdigest() == item['sha256']
    failed = read_json(Q / 'architecture-c12-prechecks-state.json', observed)
    assert failed['state'] == 'failed' and failed['source'] == {
        'head': 'f17aa99108ee73f76f5dbcd42ff54fa73840f68c', 'status': ''}
    check = next(row for row in failed['checks'] if row['name'] == 'grpc-tests')
    assert check['exit_code'] == 101 and check['totals'] == {'passed': 1738, 'failed': 1, 'ignored': 1}
    for row in failed['checks']:
        for item in row['files']:
            verify_reference(item, observed)
    for name in ('architecture-c12-final-runtime-review.md',
                 'architecture-c12-final-runtime-review-correction.md',
                 'architecture-c12b-final-runtime-review.md'):
        observe(Q / name, observed)
    correction = (Q / 'architecture-c12-final-runtime-review-correction.md').read_text()
    assert 'Withdraw finding 2' in correction and 'unsupported_policy' in correction
    unary = read_json(Q / 'architecture-c12b-unary-red.json', observed)
    assert unary['source']['head'] == failed['source']['head']
    assert unary['source']['diff_sha256'] == EMPTY
    final_test = git('show', '40f219fa515034b556df7f39e3e3947e364a2ce1:pbrs-grpc/tests/server_terminal_accounting.rs')
    assert unary['source']['untracked'] == {
        'pbrs-grpc/tests/server_terminal_accounting.rs': hashlib.sha256(final_test).hexdigest()}
    slow = read_json(Q / 'architecture-c12b-slow-writer-summary.json', observed)
    assert slow['qualified'] is False and slow['original_cause_uniquely_reproduced'] is False
    assert slow['original_failure']['source'] == failed['source']['head']
    assert slow['original_failure']['observed_drips'] == 2 and slow['original_failure']['expected_drips'] == 3
    assert slow['original_failure']['successful_fast_rpcs'] == 32
    for item in slow['evidence']:
        verify_reference(item, observed)
    assert hashlib.sha256(git('show', '40f219fa515034b556df7f39e3e3947e364a2ce1:' + slow['final_fixture']['path'])).hexdigest() == slow['final_fixture']['sha256']
    layout = read_json(Q / 'architecture-c12-deadline-layout-summary.json', observed)
    assert layout['qualified'] is False and layout['driver_before_bytes'] == 2280 and layout['driver_after_bytes'] == 544
    for item in layout['records']:
        verify_reference(dict(item, path=str(ROOT / item['path'])), observed)
    rows.extend([
        {'name': 'f17-full-prechecks', 'state': 'failed', 'record': ref(Q / 'architecture-c12-prechecks-state.json'),
         'source': failed['source'], 'totals': check['totals'], 'superseded_result_relabelled': False},
        {'name': 'withdrawn-tonic-observer-finding', 'state': 'withdrawn',
         'record': ref(Q / 'architecture-c12-final-runtime-review-correction.md'),
         'reason': 'unsupported_policy rejects this trigger before Accounting; no actual runtime red claimed'},
        {'name': 'slow-writer-fixture', 'record': ref(Q / 'architecture-c12b-slow-writer-summary.json'),
         'original_cause_uniquely_reproduced': False,
         'scope': 'Controlled schedule mismatch; unchanged fast/probe/byte/recovery bounds. Original failure retained.'},
        {'name': 'test-profile-driver-layout', 'record': ref(Q / 'architecture-c12-deadline-layout-summary.json'),
         'before_bytes': 2280, 'after_bytes': 544, 'shipping_speed_gain': False,
         'scope': layout['scope']},
    ])
    predecessor = '40f219fa515034b556df7f39e3e3947e364a2ce1'
    predecessor_counts = {'native': (1088, 20400), 'cpu': (264, 1980), 'cold-native': (96, 72)}
    for mode, (captures, per_source) in predecessor_counts.items():
        path = Q / ('architecture-c12b-' + mode + '-state.json')
        state = read_json(path, observed)
        assert state['state'] == 'passed' and state['active'] is None
        assert state['source'] == state['source_after'] == {'head': predecessor, 'status': ''}
        verify_reference(state['pins'], observed)
        verify_reference(state['summary'], observed)
        summary = read_json(Path(state['summary']['path']), observed)
        assert summary['passed'] and summary['controller_passed'] and summary['state'] == 'finished' and summary['qualified'] is False
        assert summary['retained_captures'] == summary['expected_captures'] == captures
        assert not any(summary[k] for k in ('failed_captures', 'missing_keys', 'extra_keys', 'status_errors'))
        for version, commit in [('baseline', BASELINE), ('candidate', predecessor)]:
            assert summary['source_pins'][version]['source']['commit'] == commit
            assert all(summary['actual_rpc_totals'][version][k] == per_source for k in ACCOUNTING[:4])
            assert all(summary['actual_rpc_totals'][version][k] == 0 for k in ACCOUNTING[4:])
        for check in state['checks']:
            for item in check['files']:
                verify_reference(item, observed)
        rows.append({'name': 'superseded-C12b-' + mode, 'source': predecessor,
                     'record': ref(path), 'captures': captures, 'successful_rpcs_both_sources': per_source * 2,
                     'state': 'passed', 'qualified': False,
                     'scope': 'Actual predecessor captures. They do not qualify C12c; predecessor ASAN/workspace were not run before supersession, not failed.'})
    observe(Q / 'architecture-c12c-root-transition.json', observed)
    layout = read_json(Q / 'architecture-c12c-router-layout-summary.json', observed)
    assert layout['qualified'] is False and layout['base_head'] == predecessor
    assert [layout['before'][k] for k in ('Router', 'Single', 'Single_large_application_future')] == [4288, 544, 544]
    assert [layout['after'][k] for k in ('Router', 'Single', 'Single_large_application_future')] == [544, 544, 544]
    for label in ('before', 'after'):
        directory = Q / ('architecture-c12c-router-' + label + '-source')
        manifest = read_json(directory / 'manifest.json', observed)
        assert manifest['head'] == predecessor
        for name, expected_sha in manifest['files'].items():
            assert safe_name(name)
            assert observe(directory / name, observed)['sha256'] == expected_sha
        for name, expected_sha in layout['identical_fixture_sha256'].items():
            assert manifest['files'][name] == expected_sha
            assert hashlib.sha256(git('show', '7c02eb387a6785d6e914146babe34f0902a6dd62:' + name)).hexdigest() == expected_sha
        observe(directory / 'patch.diff', observed)
        observe(directory / 'tools.json', observed)
    old_router = read_json(Q / 'architecture-c12c-router-before-source/manifest.json', observed)['files']['pbrs-grpc/src/server/router.rs']
    new_router = read_json(Q / 'architecture-c12c-router-after-source/manifest.json', observed)['files']['pbrs-grpc/src/server/router.rs']
    assert old_router == hashlib.sha256(git('show', predecessor + ':pbrs-grpc/src/server/router.rs')).hexdigest()
    assert new_router == hashlib.sha256(git('show', '7c02eb387a6785d6e914146babe34f0902a6dd62:pbrs-grpc/src/server/router.rs')).hexdigest()
    changes = git('diff', '--name-only', predecessor, '7c02eb387a6785d6e914146babe34f0902a6dd62', '--', 'pbrs-grpc/src').decode().splitlines()
    assert set(changes) == {'pbrs-grpc/src/server/router.rs', 'pbrs-grpc/src/server/deadline.rs'}
    # deadline.rs adds a private proof, while router.rs is the sole runtime diff.
    for suffix, exit_code, expected in [
            ('before-layout', 101, {'passed': 0, 'failed': 1, 'ignored': 0}),
            ('after-layout', 0, {'passed': 1, 'failed': 0, 'ignored': 0}),
            ('before-raw', 0, {'passed': 4, 'failed': 0, 'ignored': 0}),
            ('after-raw', 0, {'passed': 4, 'failed': 0, 'ignored': 0}),
            ('focused-owner', 0, {'passed': 1, 'failed': 0, 'ignored': 0}),
            ('focused-raw', 0, {'passed': 27, 'failed': 0, 'ignored': 0})]:
        prefix = 'architecture-c12c-router-' + suffix
        record = read_json(Q / (prefix + '.json'), observed)
        observe(Q / (prefix + '.stdout'), observed)
        observe(Q / (prefix + '.stderr'), observed)
        assert record['source']['head'] == predecessor and record['exit_code'] == exit_code
        assert totals(summaries(Q / (prefix + '.stdout'))) == expected
        rows.append({'name': prefix, 'actual_source': record['source'], 'record': ref(Q / (prefix + '.json')),
                     'exit_code': exit_code, 'totals': expected, 'qualified': False,
                     'scope': 'Release layout guard and functional routed controls are distinct. Before-layout is an actual failed final relative-size guard after functional assertions; no speed claim.'})
    rows.append({'name': 'Router release-private-driver-layout', 'record': ref(Q / 'architecture-c12c-router-layout-summary.json'),
                 'before_bytes': 4288, 'after_bytes': 544, 'Single_bytes_both_sources': 544,
                 'shipping_speed_or_allocator_attribution': False, 'scope': layout['scope']})
    return rows


def validate_all(pin_path, pin_sha, checkout=TREE, phase_map=None, require_cold=False):
    observed = {}
    pins = load_pins(pin_path, pin_sha, checkout, observed)
    paths = phase_paths(phase_map, pins['candidate_runtime'], observed)
    names = ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'asan', 'workspace']
    if require_cold or paths['cold-native'].exists():
        names.append('cold-native')
    states = {name: validate_phase(name, paths[name], pins, Path(pin_path).resolve(), observed) for name in names}
    build = validate_build(pins, states, observed)
    preview = validate_preview(pins, states['resource-preview'], checkout, observed)
    candidate_binary = states['build-benchmark']['binary']['sha256']
    campaigns = {name: validate_campaign(name, states[name], pins, candidate_binary, observed) for name in ('native', 'cpu')}
    if 'cold-native' in states:
        campaigns['cold-native'] = validate_campaign('cold-native', states['cold-native'], pins, candidate_binary, observed)
        verify_reference(states['cold-native']['raw_process_totals_summary'], observed)
        cold = read_json(Path(states['cold-native']['raw_process_totals_summary']['path']), observed)
        assert cold['state'] == 'passed' and cold['qualified'] is False
        assert cold['isolated_cold_RPC_cost'] is False and cold['setup_subtraction_performed'] is False
        assert cold['captures'] == campaigns['cold-native']['captures']
    history = validate_history(observed)
    verify_observed(observed)
    return {'pins': pins, 'states': states, 'phase_paths': paths, 'build': build,
            'preview': preview, 'campaigns': campaigns, 'history': history, 'observed': observed}
