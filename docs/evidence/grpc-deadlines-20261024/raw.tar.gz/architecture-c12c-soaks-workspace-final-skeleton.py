#!/usr/bin/env python3
"""Prepare source-equivalent deadline stress and launch explicitly granted days.

Preparation never runs a compiler or a diagnostic. Every mutating mode requires
--execute and the SHA256 of the final immutable C12c pins. Live output is outside
the evidence packager's architecture-c12c* selection.
"""

from pathlib import Path
import argparse
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import resource
import shutil
import signal
import subprocess
import sys
import time
import tomllib
import traceback

SCRIPT = Path(__file__).resolve()
COMMON_PATH = SCRIPT.with_name('architecture-c12c-soak-common-workspace-final-skeleton.py')
spec = importlib.util.spec_from_file_location('c12c_soak_common', COMMON_PATH)
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)
ROOT, Q, PINS, TREE = C.ROOT, C.Q, C.PINS, C.TREE
PUBLISHER = SCRIPT.with_name('architecture-c12c-publish-soak-workspace-final.py')
WRAPPER = Q / 'architecture-c12c-deadline-wrapper.rs'
FIXTURE = Q / 'architecture-c12c-deadline-fixture.rs'
DIAGNOSTIC_TREE = ROOT / 'work/architecture-c12c-deadline'
BUILD = Q / 'architecture-c12c-deadline-build'
PROVENANCE = Q / 'architecture-c12c-deadline-provenance.json'
EQUIVALENCE = Q / 'architecture-c12c-deadline-source-equivalence.json'
ORIGINALS = [('original', 'pbrs-grpc/tests/server_deadline.rs'),
             ('extended', 'pbrs-grpc/tests/server_deadline_extended.rs'),
             ('accounting', 'pbrs-grpc/tests/server_terminal_accounting.rs')]
LIMITS = [(resource.RLIMIT_AS, 'address_space'), (resource.RLIMIT_NOFILE, 'file_descriptors'),
          (resource.RLIMIT_NPROC, 'same_uid_processes'), (resource.RLIMIT_CPU, 'cpu_seconds')]


def live(kind, phase='day'):
    prefix = 'resource-architecture-c12c-workspace-final-' if phase == 'day' else 'resource-architecture-c12c-'
    name = prefix + ('day' if kind == 'resource' else 'deadline-' + phase)
    return Q / name


def environment():
    env = os.environ.copy()
    for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'ASAN_OPTIONS', 'RUSTDOCFLAGS']:
        env.pop(key, None)
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_TARGET_DIR=str(ROOT / 'work/rpc-target'),
               CARGO_BUILD_JOBS='1')
    return env


def generated_fixture(data):
    modules, facts, total = [], [], 0
    pattern = re.compile(rb'(?m)^#\[tokio::test(?:\([^\n]*\))?\]\nasync fn ([A-Za-z_][A-Za-z0-9_]*)\(\)')
    for module, name in ORIGINALS:
        original = subprocess.check_output(['git', 'show', data['candidate_runtime'] + ':' + name], cwd=ROOT)
        names = [match.group(1).decode() for match in pattern.finditer(original)]
        assert names and len(names) == len(set(names)), name
        assert original.count(b'#[tokio::test') == len(names), 'unhandled test attribute: ' + name
        copied = re.sub(rb'(?m)^#\[tokio::test(?:\([^\n]*\))?\]\n', b'', original)
        calls = ''.join('        ' + test + '().await;\n' for test in names)
        module_bytes = (('mod ' + module + ' {\n').encode() + copied
                        + ('\n    pub(super) async fn run_sustained_cases() {\n' + calls + '    }\n}\n').encode())
        modules.append(module_bytes)
        facts.append({'source_path': name, 'source_sha256': hashlib.sha256(original).hexdigest(),
                      'module': module, 'fixture_case_names': names, 'fixture_cases': len(names)})
        total += len(names)
    assert [item['fixture_cases'] for item in facts] == [3, 19, 5] and total == 27, 'the intended deadline controls changed'
    fixture = (b'//! Repeated source-equivalent independent-peer deadline fixture.\n'
               + ('const SUSTAINED_CASES: usize = ' + str(total) + ';\n').encode()
               + b'\n'.join(modules) + WRAPPER.read_bytes())
    return fixture, facts, total


def equivalence(expected_sha):
    data = C.pins(expected_sha)
    clean = C.source(DIAGNOSTIC_TREE)
    assert clean['head'] == data['candidate_runtime']
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=DIAGNOSTIC_TREE,
                          capture_output=True).returncode == 1
    assert subprocess.check_output(['git', 'diff', 'HEAD', '--binary'], cwd=DIAGNOSTIC_TREE) == b''
    untracked = subprocess.check_output(['git', 'ls-files', '--others', '--exclude-standard', '-z'],
                                      cwd=DIAGNOSTIC_TREE).decode().rstrip('\0').split('\0')
    assert untracked == [C.OVERLAY], untracked
    expected, originals, total = generated_fixture(data)
    assert FIXTURE.read_bytes() == (DIAGNOSTIC_TREE / C.OVERLAY).read_bytes() == expected
    files = []
    for entry in subprocess.check_output(['git', 'ls-tree', '-rz', data['candidate_runtime']], cwd=ROOT).split(b'\0'):
        if not entry:
            continue
        identity, raw_name = entry.split(b'\t', 1)
        name = os.fsdecode(raw_name)
        if name.startswith('docs/evidence/'):
            continue
        mode, kind, object_id = identity.decode().split()
        assert kind == 'blob', name
        path = DIAGNOSTIC_TREE / name
        raw = os.fsencode(os.readlink(path)) if mode == '120000' else path.read_bytes()
        assert hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest() == object_id, name
        files.append({'path': name, 'git_blob': object_id, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()})
    return {'source_pin': data['candidate_runtime'], 'runtime_source_equivalent': True, 'qualified': False,
            'source': {'head': data['candidate_runtime'], 'tracked_diff_sha256': C.EMPTY,
                       'untracked_overlay': [C.OVERLAY]}, 'files': files,
            'excluded_nonruntime_prefix': 'docs/evidence/', 'fixture': C.ref(FIXTURE), 'wrapper': C.ref(WRAPPER),
            'originals': originals, 'fixture_cases_per_cycle': total,
            'test_only_transformation': ['remove Tokio test attributes', 'wrap originals in separate modules',
                'invoke all discovered cases sequentially', 'append actual-wall-duration/resource wrapper'],
            'limits': ['Tokio time remains controlled by the copied tests; this is not real-time timer qualification.',
                       'Repeated cycles are not additional distinct tests or measured RPC counts.']}


def prepare_deadline(expected_sha):
    data = C.pins(expected_sha)
    assert not DIAGNOSTIC_TREE.exists(), 'preserve prior attempts'
    assert shutil.disk_usage(ROOT).free >= 100 * 1024**2, 'need source/proof worktree headroom'
    fixture, originals, total = generated_fixture(data)
    assert FIXTURE.read_bytes() == fixture, 'stage the exact pinned fixture first'
    subprocess.run(['git', 'worktree', 'add', '--detach', '--no-checkout', str(DIAGNOSTIC_TREE),
                    data['candidate_runtime']], cwd=ROOT, check=True)
    subprocess.run(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=DIAGNOSTIC_TREE,
                   input='/*\n!/docs/evidence/\n', text=True, check=True)
    subprocess.run(['git', 'checkout', '--detach', data['candidate_runtime']], cwd=DIAGNOSTIC_TREE, check=True)
    with (DIAGNOSTIC_TREE / C.OVERLAY).open('xb') as stream:
        stream.write(fixture)
    proof = equivalence(expected_sha)
    C.exclusive(Q / 'architecture-c12c-deadline-prepared.json', {
        'state': 'prepared', 'source_pin': data['candidate_runtime'], 'pins': C.ref(PINS),
        'fixture': C.ref(FIXTURE), 'wrapper': C.ref(WRAPPER), 'originals': originals,
        'fixture_cases_per_cycle': total, 'runtime_source_equivalent': proof['runtime_source_equivalent'],
        'qualified': False, 'prepared_utc': C.now()})
    print(json.dumps({'state': 'prepared', 'fixture_cases_per_cycle': total, 'source': proof['source']}))


def stage_fixture(expected_sha):
    data = C.pins(expected_sha)
    assert not FIXTURE.exists(), 'preserve an earlier staged fixture'
    fixture, originals, total = generated_fixture(data)
    with FIXTURE.open('xb') as stream:
        stream.write(fixture)
    C.exclusive(Q / 'architecture-c12c-deadline-fixture-pinned.json', {
        'state': 'staged_not_built', 'source_pin': data['candidate_runtime'], 'pins': C.ref(PINS),
        'fixture': C.ref(FIXTURE), 'wrapper': C.ref(WRAPPER), 'originals': originals,
        'fixture_cases_per_cycle': total, 'qualified': False, 'staged_utc': C.now(),
        'worktree_or_compiler_or_fixture_execution': False})
    print(json.dumps({'state': 'staged_not_built', 'source_pin': data['candidate_runtime'],
                      'fixture_cases_per_cycle': total, 'fixture': C.ref(FIXTURE)}))


def build_deadline(expected_sha):
    C.readiness(expected_sha, full=False)
    assert shutil.disk_usage(ROOT).free >= 2 * 1024**3, 'need release compiler headroom'
    before = equivalence(expected_sha)
    assert not BUILD.exists() and not PROVENANCE.exists() and not EQUIVALENCE.exists()
    output = live('deadline', 'build')
    output.mkdir(exist_ok=False)
    command = ['nice', '-n', '10', str(ROOT / 'work/run-rust'), 'cargo', '+stable', 'test', '--locked',
               '-p', 'pbrs-grpc', '--release', '--all-features', '--test', 'deadline_sustained',
               '--no-run', '--message-format=json']
    started = C.now()
    with (output / 'build.stdout.jsonl').open('xb') as stdout, (output / 'build.stderr.log').open('xb') as stderr:
        child = subprocess.run(command, cwd=DIAGNOSTIC_TREE, env=environment(), stdout=stdout, stderr=stderr, timeout=2400)
    assert child.returncode == 0, 'preserve failed build logs; do not reuse this attempt'
    assert equivalence(expected_sha) == before
    artifacts = [entry for line in (output / 'build.stdout.jsonl').read_text().splitlines()
                 if (entry := json.loads(line)).get('reason') == 'compiler-artifact'
                 and entry.get('target', {}).get('name') == 'deadline_sustained' and entry.get('executable')]
    assert len(artifacts) == 1
    artifact = artifacts[0]
    features = set(tomllib.loads((DIAGNOSTIC_TREE / 'pbrs-grpc/Cargo.toml').read_text())['features'])
    assert set(artifact['features']) == features and {'copy-counts', 'grpc-web'} <= features
    assert artifact['profile']['opt_level'] == '3' and artifact['profile']['test'] is True
    assert artifact['profile']['debug_assertions'] is False
    executable = Path(artifact['executable'])
    assert executable.read_bytes()[:4] == b'\x7fELF'
    staged = output / 'immutable-build-package'
    staged.mkdir()
    shutil.copy2(executable, staged / 'fixture-test')
    for name in ['build.stdout.jsonl', 'build.stderr.log']:
        shutil.copy2(output / name, staged / name)
    tools = {name: subprocess.check_output([str(ROOT / 'work/run-rust'), name, '+stable', '--version'],
                                         env=environment(), text=True).strip() for name in ['rustc', 'cargo']}
    assert tools == C.pins(expected_sha)['tools_required']
    record = {'source_pin': before['source_pin'], 'profile': 'release', 'all_features': True,
              'copy_counts': True, 'allocation_counter_allocator': False, 'tools': tools,
              'command': command, 'exit_code': 0, 'started_utc': started, 'completed_utc': C.now(),
              'source': before['source'], 'fixture': C.ref(FIXTURE), 'wrapper': C.ref(WRAPPER),
              'cargo_artifact_attestation': {key: artifact[key] for key in ['profile', 'features', 'target']},
              'binary': {'path': str(BUILD / 'fixture-test'), 'bytes': (staged / 'fixture-test').stat().st_size,
                         'sha256': C.digest(staged / 'fixture-test')},
              'logs': {name: {'path': str(BUILD / name), 'bytes': (staged / name).stat().st_size,
                              'sha256': C.digest(staged / name)} for name in ['build.stdout.jsonl', 'build.stderr.log']},
              'qualified': False}
    C.atomic(staged / 'build.json', record)
    staged.rename(BUILD)
    C.publish_once(EQUIVALENCE, before, output)
    provenance = {'source_pin': before['source_pin'], 'runtime_source_equivalent': True,
                  'source_equivalence': C.ref(EQUIVALENCE), 'build': C.ref(BUILD / 'build.json'),
                  'binary': C.ref(BUILD / 'fixture-test'), 'fixture': C.ref(FIXTURE), 'wrapper': C.ref(WRAPPER),
                  'pins': C.ref(PINS), 'build_driver': C.ref(SCRIPT), 'common': C.ref(COMMON_PATH),
                  'diagnostic': C.DIAGNOSTIC, 'tools': tools, 'qualified': False}
    C.publish_once(PROVENANCE, provenance, output)
    print(json.dumps({'state': 'built', 'provenance': C.ref(PROVENANCE)}))


def deadline_readiness(expected_sha, day=False):
    proof = equivalence(expected_sha)
    provenance = C.load(PROVENANCE)
    assert provenance['source_pin'] == proof['source_pin'] and provenance['runtime_source_equivalent'] is True
    for key in ['source_equivalence', 'build', 'binary', 'fixture', 'wrapper', 'pins', 'build_driver', 'common']:
        C.verify(provenance[key])
    assert C.load(EQUIVALENCE) == proof
    build = C.load(BUILD / 'build.json')
    attestation = build['cargo_artifact_attestation']
    features = set(tomllib.loads((DIAGNOSTIC_TREE / 'pbrs-grpc/Cargo.toml').read_text())['features'])
    assert set(attestation['features']) == features and {'copy-counts', 'grpc-web'} <= features
    assert attestation['profile']['opt_level'] == '3' and attestation['profile']['test'] is True
    assert attestation['profile']['debug_assertions'] is False
    result = {'source_pin': proof['source_pin'], 'source': proof['source'], 'pins': C.ref(PINS),
              'build': C.ref(BUILD / 'build.json'), 'provenance': C.ref(PROVENANCE),
              'cargo_artifact_attestation': attestation}
    if day:
        result['qualification'] = C.readiness(expected_sha, full=True)
        preview = C.load(live('deadline', 'preview') / 'report.json')
        validate_progress(preview['final_progress'], 30)
        assert preview['state'] == 'passed' and preview['exit_code'] == 0
        assert preview['source_pin_verified_at_end'] is True and preview['process_limits_verified'] is True
        assert preview['build'] == result['build'] and preview['provenance'] == result['provenance']
        result['preview'] = C.ref(live('deadline', 'preview') / 'report.json')
    return result


def validate_progress(progress, seconds):
    assert progress['state'] == 'completed' and progress['requested_seconds'] == seconds
    assert progress['elapsed_seconds'] >= seconds and progress['completed_cycles'] > 0
    assert progress['fixture_cases_per_cycle'] == 27 and progress['controlled_tokio_time'] is True
    assert progress['retained_capacity'] == progress['retained_buffers'] == 0
    assert progress['acquired'] == progress['released']
    assert 0 < progress['fd_count'] <= progress['baseline_fd_count'] < 128
    assert 0 <= progress['alive_tasks'] <= progress['baseline_alive_tasks']
    assert 0 < progress['rss_bytes'] < 1073741824
    assert 0 <= progress['peak_retained_capacity'] <= 16 * 1024 * 1024


def process_sample(pid):
    try:
        directory = Path('/proc') / str(pid)
        text = (directory / 'status').read_text()
        rss = next((int(line.split()[1]) * 1024 for line in text.splitlines() if line.startswith('VmRSS:')), None)
        return {'utc': C.now(), 'pid': pid, 'rss_bytes': rss,
                'fd_count': len(list((directory / 'fd').iterdir()))}
    except (FileNotFoundError, ProcessLookupError):
        return {'utc': C.now(), 'pid': pid, 'exited': True}
    except PermissionError as error:
        return {'utc': C.now(), 'pid': pid, 'observation_unavailable': str(error)}


def deadline_experiment(expected_sha, phase='preview', reserved=False):
    seconds = 30 if phase == 'preview' else 86400
    ready = deadline_readiness(expected_sha, day=phase == 'day')
    output = live('deadline', phase)
    if not reserved:
        output.mkdir(exist_ok=False)
    assert not any((output / name).exists() for name in ['report.json', 'progress.json', 'events.jsonl', 'stdout.log', 'stderr.log'])
    wanted = C.caps(seconds)

    def limit_child():
        for number, key in LIMITS:
            resource.setrlimit(number, (wanted[key], wanted[key]))

    env = environment()
    env.update(PBRS_DEADLINE_SECONDS=str(seconds), PBRS_DEADLINE_OUTPUT=str(output))
    command = [str(BUILD / 'fixture-test'), '--exact', 'deadline_sustained', '--nocapture', '--test-threads=1']
    report = {'state': 'incomplete', 'source_pin': ready['source_pin'], 'qualified': False,
              'diagnostic': C.DIAGNOSTIC, 'requested_seconds': seconds, 'started_utc': C.now(),
              'supervisor_pid': os.getpid(), 'source_before': ready['source'], 'build': ready['build'],
              'provenance': ready['provenance'], 'preview': ready.get('preview'), 'pins': C.ref(PINS),
              'cargo_artifact_attestation': ready['cargo_artifact_attestation'],
              'limits': wanted, 'command': command, 'completed_cycles': 0, 'exit_code': None, 'failures': []}
    child = None
    started = time.monotonic()
    last_progress = started
    completed_cycles = 0
    report['progress_guard_seconds'] = 60
    try:
        with (output / 'stdout.log').open('xb') as stdout, (output / 'stderr.log').open('xb') as stderr, (output / 'samples.jsonl').open('x') as samples:
            child = subprocess.Popen(command, cwd=DIAGNOSTIC_TREE, env=env, stdin=subprocess.DEVNULL,
                                     stdout=stdout, stderr=stderr, close_fds=True, start_new_session=True,
                                     preexec_fn=limit_child)
            report['pid'] = child.pid
            actual = {key: list(resource.prlimit(child.pid, number)) for number, key in LIMITS}
            assert actual == {key: [value, value] for key, value in wanted.items()}
            report.update(actual_process_limits=actual, process_limits_verified=True)
            C.atomic(output / 'supervisor-state.json', {**report, 'state': 'running'})
            while child.poll() is None:
                samples.write(json.dumps(process_sample(child.pid)) + '\n')
                samples.flush()
                progress_path = output / 'progress.json'
                if progress_path.exists():
                    observed = C.load(progress_path)
                    assert observed['pid'] == child.pid and observed['completed_cycles'] >= completed_cycles
                    if observed['completed_cycles'] > completed_cycles:
                        completed_cycles = observed['completed_cycles']
                        last_progress = time.monotonic()
                if time.monotonic() - last_progress > 60:
                    raise TimeoutError('no completed fixture cycle for 60 real seconds')
                if time.monotonic() - started > seconds + 90:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                    raise TimeoutError('finite wall guard exceeded')
                time.sleep(1)
            report['exit_code'] = child.wait()
        progress = C.load(output / 'progress.json')
        report.update(final_progress=progress, completed_cycles=progress['completed_cycles'],
                      duration_actual_seconds=progress['elapsed_seconds'],
                      duration_measurement='Child std::Instant from diagnostic entry; compilation excluded.')
        after = equivalence(expected_sha)
        report.update(source_after=after['source'], runtime_source_equivalent=True,
                      source_pin_verified_at_end=after['source'] == ready['source'])
        assert report['exit_code'] == 0 and report['source_pin_verified_at_end'] is True
        validate_progress(progress, seconds)
        count, final, previous = 0, None, -1.0
        for line in (output / 'events.jsonl').read_text().splitlines():
            event = json.loads(line)
            assert final is None and event['elapsed_seconds'] >= previous
            previous = event['elapsed_seconds']
            assert event['pid'] == child.pid and event['requested_seconds'] == seconds
            assert event['retained_capacity'] == event['retained_buffers'] == 0
            assert event['acquired'] == event['released']
            assert event['fd_count'] <= event['baseline_fd_count'] < 128
            assert event['alive_tasks'] <= event['baseline_alive_tasks']
            if event['event'] == 'cycle_completed':
                count += 1
                assert event['completed_cycles'] == count and event['state'] == 'running'
            else:
                assert event['event'] == 'duration_completed' and event == progress
                final = event
        assert count == progress['completed_cycles'] and final == progress
        text = (output / 'stdout.log').read_text()
        assert 'test deadline_sustained ... ok' in text and '1 passed; 0 failed; 0 ignored;' in text
        report['state'] = 'passed'
    except BaseException as error:
        traceback.print_exc()
        report['state'] = 'failed' if child is not None else 'incomplete'
        report['failures'].append(repr(error))
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGKILL)
        if child is not None:
            report['exit_code'] = child.wait()
        if (output / 'progress.json').exists():
            report['final_progress'] = C.load(output / 'progress.json')
            report['completed_cycles'] = report['final_progress'].get('completed_cycles', 0)
            report['last_completed_cycle_elapsed_seconds'] = report['final_progress'].get('elapsed_seconds')
        report['duration_actual_seconds'] = time.monotonic() - started
        report['duration_measurement'] = 'Supervisor-observed process wall time after failure; not a completed workload-duration attestation.'
        try:
            report['source_after'] = equivalence(expected_sha)['source']
            report['runtime_source_equivalent'] = True
            report['source_pin_verified_at_end'] = report['source_before'] == report['source_after']
        except BaseException as verification_error:
            report['source_pin_verified_at_end'] = False
            report['failures'].append('terminal source check: ' + repr(verification_error))
    report.update(completed_utc=C.now(), supervisor_wall_seconds=time.monotonic() - started)
    C.atomic(output / 'report.json', report)
    C.atomic(output / 'supervisor-state.json', {'state': 'terminal', 'report': C.ref(output / 'report.json')})
    C.publish_once(Q / ('architecture-c12c-workspace-final-deadline-' + phase + '-terminal.json'), report, output)
    return 0 if report['state'] == 'passed' else 1


def launch(expected_sha, kind, grant_path):
    ready = C.readiness(expected_sha, full=True)
    if kind == 'resource':
        assert shutil.disk_usage(ROOT).free >= 2 * 1024**3, 'need original resource release-build headroom'
    if kind == 'deadline':
        ready['deadline'] = deadline_readiness(expected_sha, day=True)
    grant = C.load(grant_path)
    wanted_grant = {'source_pin': ready['source_pin'], 'pins_sha256': expected_sha,
                    'root_granted': True, 'action': 'launch-c12c-workspace-final-' + kind + '-day'}
    assert all(grant.get(key) == value for key, value in wanted_grant.items())
    output = live(kind)
    launch_snapshot = Q / ('architecture-c12c-workspace-final-' + kind + '-day-launch-snapshot.json')
    assert not launch_snapshot.exists(), 'preserve the existing launch observation'
    output.mkdir(exist_ok=False)
    harness = output / 'harness'
    harness.mkdir()
    paths = [SCRIPT, COMMON_PATH, PUBLISHER, PINS, grant_path, ROOT / 'work/run-rust', ROOT / 'work/record.py']
    if kind == 'deadline':
        paths += [FIXTURE, WRAPPER, PROVENANCE, EQUIVALENCE, BUILD / 'build.json']
    for path in paths:
        shutil.copy2(path, harness / path.name)
    shutil.copy2(TREE / 'scripts/grpc-resource-campaign.py', harness / 'resource-controller.py')
    preview = C.ref(C.RESOURCE_PREVIEW if kind == 'resource' else live('deadline', 'preview') / 'report.json')
    launch = {'state': 'launching', 'kind': kind, 'source_pin': ready['source_pin'], 'qualified': False,
              'requested_seconds': 86400, 'started_utc': C.now(), 'pins': C.ref(PINS), 'preview': preview,
              'readiness': ready, 'grant': C.ref(grant_path),
              'launch_helpers': {'controller': C.ref(SCRIPT), 'common': C.ref(COMMON_PATH), 'publisher': C.ref(PUBLISHER)},
              'original_deadline_build_helpers': ({key: C.load(PROVENANCE)[key] for key in ['build_driver', 'common']} if kind == 'deadline' else None),
              'harness': {path.name: C.ref(path) for path in sorted(harness.iterdir())}}
    if kind == 'resource':
        launch['campaign_output'] = str(output / 'campaign')
    C.atomic(output / 'launch.json', launch)
    with (output / 'supervisor.log').open('xb') as log:
        child = subprocess.Popen([sys.executable, str(harness / SCRIPT.name), 'supervise', '--kind', kind,
                                  '--pins-sha256', expected_sha, '--execute'], cwd=ROOT,
                                 stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT,
                                 close_fds=True, start_new_session=True)
    launch.update(state='running', supervisor_pid=child.pid)
    C.atomic(output / 'launch.json', launch)
    C.publish_once(launch_snapshot,
                   {'snapshot_utc': C.now(), 'launch': launch, 'no_day_result': True, 'qualified': False}, output)
    print(json.dumps({'state': 'running', 'kind': kind, 'supervisor_pid': child.pid, 'output': str(output)}))


def supervise(expected_sha, kind):
    output = live(kind)
    # Reserve the attempt before entering failure publication. A duplicate
    # supervisor must not rewrite a prior terminal report or termination record.
    lock = (output / 'supervisor.lock').open('x')
    termination = {'source_pin': None, 'kind': kind, 'state': 'supervisor_failed',
                   'qualified': False, 'exit_code': None, 'source_pin_verified_at_end': False,
                   'tool_metadata_matches_preview': False, 'supervisor_pid': os.getpid()}
    child = None
    result = 1
    try:
        with lock:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            launch = C.load(output / 'launch.json')
            termination['source_pin'] = launch['source_pin']
            assert launch['kind'] == kind and launch['requested_seconds'] == 86400
            for reference in launch['harness'].values():
                C.verify(reference)
            grant = C.load(C.verify(launch['grant']))
            assert grant.get('root_granted') is True
            assert grant.get('action') == 'launch-c12c-workspace-final-' + kind + '-day'
            assert grant.get('source_pin') == launch['source_pin']
            assert grant.get('pins_sha256') == expected_sha
            assert launch['pins']['sha256'] == expected_sha
            if kind == 'deadline':
                result = deadline_experiment(expected_sha, 'day', reserved=True)
                termination['exit_code'] = C.load(output / 'report.json').get('exit_code')
                termination['tool_metadata_matches_preview'] = (
                    C.load(live('deadline', 'preview') / 'report.json')['build']
                    == C.load(output / 'report.json')['build'])
                termination['source_pin_verified_at_end'] = C.load(output / 'report.json').get('source_pin_verified_at_end') is True
            else:
                ready = C.readiness(expected_sha, full=True)
                command = [sys.executable, str(output / 'harness/record.py'), str(output / 'resource-controller-run'),
                           '90000', str(output / 'harness/run-rust'), sys.executable,
                           'scripts/grpc-resource-campaign.py', '--source', ready['source_pin'], '--output', str(output / 'campaign'),
                           '--duration', '86400', '--build-profile', 'release', '--seed', '20261002',
                           '--memory-bytes', '1073741824', '--max-fds', '128', '--max-uid-processes', '4096']
                # The original campaign creates its output exclusively. Day
                # orchestration and publication state stay one directory above.
                with (output / 'controller.log').open('xb') as log:
                    child = subprocess.Popen(command, cwd=TREE, env=environment(), stdin=subprocess.DEVNULL,
                                             stdout=log, stderr=subprocess.STDOUT, close_fds=True)
                    C.atomic(output / 'supervisor-state.json', {'state': 'running', 'source_pin': ready['source_pin'],
                             'pid': child.pid, 'pid_role': 'record_wrapper', 'command': command, 'qualified': False,
                             'campaign_output': str(output / 'campaign'), 'started_utc': C.now()})
                    result = child.wait()
                termination['exit_code'] = result
                termination['source_pin_verified_at_end'] = C.source() == {'head': ready['source_pin'], 'status': ''}
                if (output / 'campaign/report.json').exists():
                    report = C.load(output / 'campaign/report.json')
                    termination['tool_metadata_matches_preview'] = report.get('tools') == ready['resource_preview']['tools']
            termination['state'] = 'terminated'
    except BaseException as error:
        termination['error'] = repr(error)
        traceback.print_exc()
        if child is not None and child.poll() is None:
            termination['exit_code'] = child.wait()
    finally:
        termination['completed_utc'] = C.now()
        try:
            C.atomic(output / 'termination.json', termination)
        finally:
            # A missing/incomplete report is still a terminal publication.
            publication_error = None
            try:
                publication = subprocess.run([sys.executable, str(PUBLISHER), '--kind', kind,
                                              '--pins-sha256', expected_sha, '--execute'], cwd=ROOT)
                publication_code = publication.returncode
            except BaseException as error:
                publication_error = repr(error)
                publication_code = 1
                traceback.print_exc()
            if publication_code:
                state_path = output / 'publication.json'
                previous = C.load(state_path) if state_path.exists() else {}
                if previous.get('state') not in ('published', 'failed'):
                    C.atomic(state_path, {'state': 'failed', 'source_pin': termination['source_pin'],
                             'kind': kind, 'qualified': False, 'completed_utc': C.now(),
                             'publisher_exit_code': publication_code,
                             'error': publication_error or 'Publisher exited without a terminal publication record.',
                             'previous_state': previous})
    return publication_code or result


def main():
    if not __debug__:
        raise RuntimeError('run workspace-final launchers without Python -O')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['plan', 'check-ready', 'launch', 'supervise'])
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--pins-sha256')
    parser.add_argument('--kind', choices=['resource', 'deadline'], default='resource')
    parser.add_argument('--grant', type=Path)
    args = parser.parse_args()
    if args.mode != 'plan':
        raise RuntimeError('workspace-final skeleton cannot execute before final validation contract is frozen')
    if args.mode == 'plan' or (not args.execute and args.mode != 'check-ready'):
        print(json.dumps({'state': 'prepared_not_run', 'qualified': False, 'pins': str(PINS),
                          'mode': args.mode, 'kind': args.kind, 'execute_required': True}))
        return 0
    if args.mode == 'stage-fixture':
        stage_fixture(args.pins_sha256)
    elif args.mode == 'prepare-deadline':
        prepare_deadline(args.pins_sha256)
    elif args.mode == 'build-deadline':
        build_deadline(args.pins_sha256)
    elif args.mode == 'preview-deadline':
        return deadline_experiment(args.pins_sha256)
    elif args.mode == 'check-ready':
        ready = C.readiness(args.pins_sha256, full=True)
        if args.kind == 'deadline':
            ready['deadline'] = deadline_readiness(args.pins_sha256, day=True)
        print(json.dumps(ready, indent=2))
    elif args.mode == 'launch':
        assert args.grant is not None, 'separate explicit root grant required'
        launch(args.pins_sha256, args.kind, args.grant)
    else:
        return supervise(args.pins_sha256, args.kind)
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
