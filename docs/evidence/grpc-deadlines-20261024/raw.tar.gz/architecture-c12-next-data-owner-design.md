# Normal DATA owner reclamation: next design

Reviewed at 2026-10-24T03:55:32.697495+00:00.
**Source finding only. No normal-completion reentrant-owner failure has been
executed, and no remedy below is implemented or measured.** This note does not
change the frozen C11 sources, existing soak processes or C12 qualification logs.

## Scope of the current repair

C12's terminal capability detaches deadline-discarded queue frames and defers
cancelled codec tails through `take_discarded_frame`. Their owners and affected
wakers run after the engine and send-buffer locks are released. Root's V3 run
passes the five targeted backend tests, including the corrected in-flight fixture
and a Tonic codec replay of its captured partial DATA and status-4 trailers.
Those tests establish the new terminal paths' behavior; they do not establish
that every existing backend destructor runs outside locks.

## Remaining source finding

`Streams::poll_complete` locks `Inner` around `Inner::buffer_pending`.
`Prioritize::buffer_pending` can stage several small DATA frames under that lock.
`FramedWrite::Encoder::buffer_data` copies payloads below the chaining threshold
into its output buffer and parks each consumed frame in `last_data_frame`.
The prioritizer immediately reclaims that frame before staging another one.
When `reclaim_frame_inner` finds no remaining payload, the frame and its generic
owner leave scope while the engine lock is still held. The post-flush path in
`Inner::reclaim_written_frame` similarly calls `reclaim_consumed` under that lock.
An exhausted `Bytes` cursor can still own its backing object.

A `Bytes::from_owner` destructor that synchronously reenters the same engine can
therefore encounter that held lock. This is an application-controlled destructor
scenario, not an observed remote exploit or a new memory-corruption finding.
Legacy reset/header paths have related ownership questions and remain separate;
fixing only normal DATA would not justify a blanket callback-safety claim.

## Why a small interception is insufficient

The existing codec has one `last_data_frame` slot. Deferring only its final
post-flush owner is a narrow partial improvement, but does not cover the many
small frames reclaimed inside one locked batching operation. Covering all of
them requires retaining multiple owners or changing the batching boundary:

| Option | Tradeoff to measure |
|---|---|
| Bounded stack batch of retired owners | No steady heap allocation; larger polling stack, initialization work and periodic unlock/relock when full. A reclaim boundary can preserve the encoded batch without forcing a socket flush. |
| Intrusive retirement queue using frame-slab nodes | Reuses node storage, but needs queue metadata and may raise slab high-water allocation. Bound retired owners and drain on every error/shutdown path without destroying them under either mutex. |
| Heap collection of retired owners | Simple explicit ownership; adds allocation/retained-capacity policy to normal output. |
| Unlock per frame or flush every small frame | Avoids retaining many owners, but adds hot locks or destroys batching/write efficiency. |
| Copy or always chain the payload | Changes allocation/copy or vectored-write costs and zero-copy behavior; requires separate codec/transport comparisons. |

These are design candidates, not predictions of savings. Opaque `Bytes` owners
can retain much more memory than their visible slices; a count of retired owners
or logical payload bytes is not an exact bound on backing allocations or RSS.
Do not add an unbounded thread-local destructor queue or defer arbitrary owners
to detached work without an explicit ownership and memory contract.

## First causal control and acceptance

Before changing runtime code, add an independent registry-h2 peer and exercise
**ordinary successful completion without activating a deadline**. Supply a
`Bytes::from_owner` payload whose last destructor queries a retained capability
for the same engine. Use an OS-thread reply with a finite watchdog so a held-lock
failure returns a detecting observation instead of permanently hanging the test.
The query capability may keep the stream slot alive; it must not terminate or
reset the successful response. Require one owner destruction, valid successful
wire output and same-connection recovery.

Force both a small copied DATA payload and a larger chained frame's final
consumed tail. Record actual phase witnesses and preserve the initial red. Then
compare the implementation against that exact fixture, test cancellation/error
and connection teardown, and run sanitizer/slot-ownership controls. Measure tiny
unary and streamed batches, multiple ready streams, slow readers, allocation
requests, retained memory, lock/wake work and shipping latency/throughput.
Any layout growth, added lock boundary, batch limit or syscall change needs its
own evidence; C12's terminal-path tests cannot qualify that future repair.

## Reviewed file hashes

```json
{
  "pbrs-grpc/src/h2_backend/codec/framed_write.rs": "23903e76fc23d02d6350b95278d27804c261aed60bdcfc36e3613e8d5c879d39",
  "pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs": "c92755899ce6516e91d18dad075fe88aebdc79a5cecd443ed60c26c9f3c7da3d",
  "pbrs-grpc/src/h2_backend/proto/streams/streams.rs": "aa208f1ef47467a4e0fbad5e7724a49eb0fc89e88743780b391fda1a5399a1e0",
  "pbrs-grpc/src/transport/h2/deadline_response_tests.rs": "3d1d3b6f82ed4b5f5202466aa7c21a9991c5e7b396104904cf8a0e6e837f9ab8"
}
```
