#!/usr/bin/env python3
"""Write source-pinned C12 results once, after every selected gate has passed.

Without --execute this only describes the prepared action. Results keep raw
counter scopes, all observed increases and older-source day identities separate.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import runpy
import tempfile

SCRIPT = Path(__file__).resolve()
COMMON = SCRIPT.with_name('architecture-c12c-evidence-common.py')
C = runpy.run_path(str(COMMON))
ROOT, Q, DEFAULT_DEST = C['ROOT'], C['Q'], C['DEST']


def publish_new(path, data):
    path.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(prefix='resource-c12-write-', dir=Q, delete=False) as stream:
        temporary = Path(stream.name)
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    try:
        os.link(temporary, path)  # complete, exclusive publication
    finally:
        temporary.unlink()


def snapshot(path):
    """Capture live atomic metadata by value; never retain a live hash reference."""
    if not path.is_file():
        return None
    assert not path.is_symlink()
    data = path.read_bytes()
    try:
        value = json.loads(data)
    except (ValueError, UnicodeError) as error:
        value = {'capture_error': str(error)}
    return {'live_path_at_capture': str(path), 'captured_utc': C['now'](),
            'captured_bytes': len(data), 'captured_bytes_sha256': hashlib.sha256(data).hexdigest(),
            'value_at_capture': value,
            'scope': 'Once-read metadata snapshot. This is not an immutable reference to the live path or a terminal-day verdict.'}


def days(candidate):
    """Capture known controller paths by value with explicit source expectations.

    This is an observation, not terminal validation. A namespace's prepared
    source expectation never replaces the source retained inside its metadata.
    """
    assert candidate == '7c02eb387a6785d6e914146babe34f0902a6dd62'
    old_c12 = 'f17aa99108ee73f76f5dbcd42ff54fa73840f68c'
    registry = {
        'earlier_C12b_preparation_only': ('40f219fa515034b556df7f39e3e3947e364a2ce1',
            [Q / 'architecture-c12b-soaks-prepared.json',
             Q / 'architecture-c12b-deadline-fixture-pinned.json']),
        'earlier_C11_terminal': (C['BASELINE'],
            [ROOT / 'docs/evidence/grpc-decode-reuse-soak-20261023/results.json']),
        'earlier_C12_preparation_only': (old_c12,
            [Q / 'architecture-c12-soaks-prepared.json',
             Q / 'architecture-c12-deadline-fixture-pinned.json']),
        'earlier_C8_terminal': ('9d6fb9c416fc32732450fd78d32ee16ff8b802de',
            [ROOT / 'docs/evidence/grpc-architecture-soak-20261023/results.json']),
        'earlier_C11_standard': (C['BASELINE'],
            [Q / 'resource-architecture-c11-day/progress.json',
             Q / 'resource-architecture-c11-day/report.json',
             Q / 'resource-architecture-c11-day/termination.json',
             Q / 'resource-architecture-c11-day/publication.json',
             Q / 'architecture-c11-day-termination.json', Q / 'architecture-c11-day-publication.json']),
        'earlier_C11_cache': (C['BASELINE'],
            [Q / 'resource-architecture-c11-prost-cache-day/progress.json',
             Q / 'resource-architecture-c11-prost-cache-day/report.json',
             Q / 'resource-architecture-c11-prost-cache-day/termination.json',
             Q / 'resource-architecture-c11-prost-cache-day/publication.json']),
    }
    for prefix, expected, label in [('architecture-c12', old_c12, 'earlier_C12'),
                                     ('architecture-c12b', '40f219fa515034b556df7f39e3e3947e364a2ce1', 'earlier_C12b'),
                                     ('architecture-c12c', candidate, 'current_C12c')]:
        for kind in ('resource', 'deadline'):
            live = Q / ('resource-' + prefix + ('-day' if kind == 'resource' else '-deadline-day'))
            # Both declared controllers give the unchanged resource campaign its
            # own exclusive child directory. Deadline supervisor writes at root.
            data = live / 'campaign' if kind == 'resource' else live
            paths = [data / 'progress.json', data / 'report.json', live / 'launch.json',
                     live / 'supervisor-state.json', live / 'termination.json', live / 'publication.json',
                     Q / (prefix + '-' + kind + '-day-launch-snapshot.json')]
            if kind == 'deadline':
                paths.append(Q / (prefix + '-deadline-day-terminal.json'))
            registry[label + '_' + kind + '_day'] = (expected, paths)
    attempts = {}
    for name, (expected, paths) in registry.items():
        captured = [item for path in paths if (item := snapshot(path)) is not None]
        attempts[name] = {
            'expected_runtime': expected,
            'source_expectation_basis': 'Exact recorded older source or prepared source pin for this named controller; inspect captured original metadata for actual source.',
            'state': 'metadata_captured; interpret each original source/outcome' if captured else 'not_observed_at_snapshot',
            'record_scope': 'Preparation/staged fixture only; no build or launch is implied.' if name.endswith('_preparation_only') else 'Once-observed named day metadata; terminal outcome not validated here.',
            'qualified': False, 'observations': captured}
    return {'snapshot_utc': C['now'](), 'qualified': False, 'attempts': attempts,
            'scope': 'Older days and f17/40f preparations never qualify final7c02 C12c. Metadata is captured by value and never relabelled. Running metadata does not establish completion; missing paths mean not observed, not proof that no alternate-named attempt exists.',
            'current_runtime_24_hour_qualification': False}


def comparisons(value):
    summary = value['summary']
    source_rows = []
    for row in summary['source_ranges']:
        ratio = row['ratio_of_medians']
        source_rows.append({**row, 'source_change_percent': (ratio - 1) * 100 if C['finite'](ratio) else None,
                            'basis': 'candidate endpoint median / baseline endpoint median', 'qualified': False})
    tonic_rows = []
    for row in summary['same_side_tonic_ranges']:
        if row['version'] != 'candidate':
            continue
        before, after = row['tonic']['median'], row['native']['median']
        ratio = after / before if C['finite'](before) and C['finite'](after) and before != 0 else None
        side_index = 0 if row['side'] == 'client' else 2
        tonic_rows.append({**row, 'native_side': row['cell']['pair'][side_index] == 'native',
                           'ratio_of_endpoint_medians': ratio,
                           'difference_percent': (ratio - 1) * 100 if ratio is not None else None,
                           'basis': 'current endpoint median / fresh same-side tonic endpoint median',
                           'qualified': False})
    costs = {'allocations', 'requested_bytes', 'instructions'}
    higher_source = [row for row in source_rows if row['native_side'] and row['metric'] in costs
                     and row['source_change_percent'] is not None and row['source_change_percent'] > 0]
    higher_tonic = [row for row in tonic_rows if row['native_side'] and row['metric'] in costs
                    and row['difference_percent'] is not None and row['difference_percent'] > 0]
    return {'summary': C['ref'](value['summary_path']), 'passed': True, 'qualified': False,
            'phase': summary['phase'], 'captures': value['captures'],
            'actual_rpc_totals_by_source': value['actual_rpc_totals'],
            'raw_counter_availability': summary['raw_counter_availability'],
            'source_comparison_dispositions': summary['source_comparison_dispositions'],
            'same_side_tonic_dispositions': summary['same_side_tonic_dispositions'],
            'source_comparisons': source_rows, 'current_vs_fresh_tonic': tonic_rows,
            'every_native_higher_source_cost_group': higher_source,
            'every_native_higher_tonic_cost_group': higher_tonic,
            'higher_cost_group_cutoff_percent': 0,
            'interpretation': 'Observed counter differences, including tiny/noisy increases, are retained. They are not significance tests or shipping-speed verdicts.',
            'limits': summary['limits']}


def router_causal(path, expected_sha, pins, observed):
    assert expected_sha == '1a66eb3364d08c959cbf44d83d6e756f94f3e090d37dab98e0c706c75bb856f5', 'explicit actual causal-summary SHA required'
    assert Path(path).resolve() == Q / 'architecture-c12c-router-causal-summary.json'
    value = C['read_json'](path, observed)
    assert C['ref'](path)['sha256'] == expected_sha
    assert value['schema'] == 'pbrs.router-causal-summary.v1' and value['state'] == 'passed' and value['qualified'] is False
    assert value['sources'] == {'baseline': C['BASELINE'], 'before': '40f219fa515034b556df7f39e3e3947e364a2ce1', 'after': pins['candidate_runtime']}
    assert value['source_pins'] == C['ref'](Q / 'architecture-c12c-source-pins.json')
    assert value['captures'] == 48 and value['successful_rpcs'] == 1800 and value['captures_per_source'] == 16
    assert value['higher_cost_cutoff_percent'] == 0 and value['canonical_campaign_totals_modified'] is False
    for item in value['validated_inputs']:
        C['verify_reference'](item, observed)
    assert value['summary_script']['sha256'] == 'f244dc2522d7f6b47498401d05a44432faa8d1b3ffd26cc369638a822d4aa2fb'
    assert value['controller']['sha256'] == 'e14bd79194dd587293067b8b5b6aac90a3cd7c06e004752bb81cd4e08630e810'
    for name, control in value['controls'].items():
        assert control['captures'] == 16
        assert all(control['actual_rpc_totals'][key] == 600 for key in C['ACCOUNTING'][:4])
        assert all(control['actual_rpc_totals'][key] == 0 for key in C['ACCOUNTING'][4:])
    execution_path = Q / 'architecture-c12c-router-causal-summary-execution.json'
    execution = C['read_json'](execution_path, observed)
    assert execution['exit_code'] == 0 and not execution.get('timeout')
    command = execution['command']
    assert command[:3] == ['python3', value['summary_script']['path'], '--execute']
    assert command[-2:] == ['--output', str(Path(path).resolve())]
    for name, control in value['controls'].items():
        assert command[command.index('--' + name) + 1] == str(Path(control['control']['path']).parent)
    stdout_path = execution_path.with_suffix('.stdout')
    stdout = C['read_json'](stdout_path, observed)
    assert stdout['state'] == 'passed' and stdout['captures'] == 48 and stdout['successful_rpcs'] == 1800
    assert stdout['output'] == C['ref'](path)
    C['observe'](execution_path.with_suffix('.stderr'), observed)
    review_path = Q / 'architecture-c12c-router-final-source-review.json'
    review = C['read_json'](review_path, observed)
    router = C['git']('show', pins['candidate_runtime'] + ':pbrs-grpc/src/server/router.rs')
    assert hashlib.sha256(router).hexdigest() == review['reviewed_production_source']['sha256']
    diff = C['git']('diff', value['sources']['before'], value['sources']['after'], '--', 'pbrs-grpc/src/server/router.rs')
    assert hashlib.sha256(diff).hexdigest() == review['production_diff']['sha256']
    return {'record': C['ref'](path), 'execution': C['ref'](execution_path), 'source_review': C['ref'](review_path),
            'qualified': False, 'captures': 48, 'successful_rpcs': 1800,
            'separate_from_canonical_capture_accounting': True, 'sources': value['sources'],
            'source_rows': value['source_rows'], 'same_side_tonic_rows': value['same_side_tonic_rows'],
            'every_higher_source_cost_group': value['every_higher_source_cost_group'],
            'every_higher_tonic_cost_group': value['every_higher_tonic_cost_group'],
            'higher_cost_cutoff_percent': 0, 'scope': value['scope'], 'limits': value['limits'],
            'shipping_speed_qualification': False, 'allocator_site_sampling_performed': False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--pins', type=Path, default=C['PINS'])
    parser.add_argument('--pins-sha256')
    parser.add_argument('--checkout', type=Path, default=C['TREE'])
    parser.add_argument('--phase-map', type=Path)
    parser.add_argument('--require-cold', action='store_true')
    parser.add_argument('--destination', type=Path, default=DEFAULT_DEST)
    parser.add_argument('--router-causal-summary', type=Path, default=Q / 'architecture-c12c-router-causal-summary.json')
    parser.add_argument('--router-causal-summary-sha256')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True,
                          'destination': str(args.destination), 'qualified': False}))
        return 0
    assert args.router_causal_summary_sha256 == '1a66eb3364d08c959cbf44d83d6e756f94f3e090d37dab98e0c706c75bb856f5', 'explicit actual causal-summary SHA required'
    assert args.router_causal_summary.resolve() == Q / 'architecture-c12c-router-causal-summary.json'
    dest = args.destination.resolve()
    assert dest.parent == ROOT / 'docs/evidence' and dest.name.startswith('grpc-deadlines-20261024')
    assert not dest.is_symlink() and not (dest / 'results.json').exists()
    snapshot_path = Q / 'architecture-c12c-evidence-day-snapshot.json'
    assert not snapshot_path.exists(), 'never overwrite an earlier publication snapshot'
    validated = C['validate_all'](args.pins, args.pins_sha256, args.checkout, args.phase_map, args.require_cold)
    pins, states, observed = validated['pins'], validated['states'], validated['observed']
    C['observe'](SCRIPT, observed)
    C['observe'](COMMON, observed)
    causal = router_causal(args.router_causal_summary, args.router_causal_summary_sha256, pins, observed)
    performance = {name: comparisons(value) for name, value in validated['campaigns'].items()}
    accounting = {key: 0 for key in C['ACCOUNTING']}
    for value in performance.values():
        for group in value['actual_rpc_totals_by_source'].values():
            for key in accounting:
                accounting[key] += group[key]
    snapshot_value = days(pins['candidate_runtime'])
    cold = {'state': 'not_run_at_publication', 'qualified': False}
    if 'cold-native' in states:
        path = Path(states['cold-native']['raw_process_totals_summary']['path'])
        raw = C['read_json'](path, observed)
        cold = {'state': 'passed', 'record': C['ref'](path), 'qualified': False,
                'captures': raw['captures'], 'successful_rpcs': raw['successful_rpcs'],
                'scope': raw['scope'], 'isolated_cold_RPC_cost': False,
                'setup_subtraction_performed': False, 'hardware_cold_cache_claim': False,
                'all_raw_endpoint_totals': raw['raw_endpoint_totals'],
                'all_process_total_ranges': raw['source_process_total_ranges']}
    result = {
        'schema': 'pbrs.grpc-deadlines-results.v1', 'created_utc': C['now'](),
        'source': pins['candidate_runtime'], 'source_tree': pins['candidate_tree'],
        'baseline_source': C['BASELINE'], 'source_pins': C['ref'](args.pins),
        'qualified': False, 'production_ready': False, 'broad_speed_superiority': False,
        'world_fastest': False, 'spec_complete': False, 'all_important_cases_beat_tonic_prost': False,
        'writer': C['ref'](SCRIPT), 'validator': C['ref'](COMMON),
        'implementation': {
            'deadline_scope': 'One accepted absolute deadline and cooperative service owner, including pre-shape waits, late tightening, handler construction and response commitment.',
            'unary_accounting_scope': 'Native unary, client-streaming and Web unary lifecycle accounting uses the actual committed writer Status, including codec and byte-admission errors; later Drop or clock changes do not replace it.',
            'native_terminal_scope': 'One terminal result; native error trailers may discard unsent DATA while preserving initial HTTP/2 headers and the current frame length.',
            'web_terminal_scope': 'Safe completed-message boundaries preserve base64 carry and status-body framing. An unfinished partial Web BODY frame requires a transport reset; a new body status cannot overwrite missing payload.',
            'router_scope': 'Routing selects the existing boxed service future synchronously under the accepted owner, retaining one selected future instead of the full Rpc across an initial Router async state; post-logging and interceptor expiry checks remain explicit.',
            'router_layout_limit': 'Private release proof Router4288->544bytes with Single544bytes unchanged; layout is not shipping allocator, CPU, latency, throughput or RSS evidence.',
            'compression_scope': 'Fresh gzip encoder per message with one bounded initialized output chunk; level clamp, complete member/trailer validation and writer error handling remain explicit.',
            'limits': ['Timers cannot preempt synchronous user or codec polls.',
                       'No protocol can force output through a blocked TCP socket; Web status DATA also requires peer flow-control credit.',
                       'Private pooled records and queued transport bytes are not a universal process-RSS bound.'],
        },
        'validation': {
            'phase_records': {name: C['ref'](validated['phase_paths'][name]) for name in states},
            'checks': {name: [{key: check[key] for key in ('name', 'exit_code', 'duration_seconds', 'targets', 'totals')}
                              for check in state['checks']] for name, state in states.items()},
            'workspace': {'source': pins['candidate_runtime'], 'counts': C['totals']([row for check in states['workspace']['checks'] for row in check['summaries']]),
                          'targets': sum(check['targets'] for check in states['workspace']['checks'])},
            'sanitizer': {'source': pins['candidate_runtime'], 'counts': C['totals']([row for check in states['asan']['checks'] for row in check['summaries']]),
                          'executables': states['asan']['executables'],
                          'scope': 'Selected nightly build-std AddressSanitizer/leak-detection targets, including both independent deadline targets and terminal accounting; not an all-workspace sanitizer claim.'},
            'resource_preview': {'source': pins['candidate_runtime'], 'report': states['resource-preview']['report'],
                                 'actual_seconds': validated['preview']['duration_actual_seconds'],
                                 'settings': validated['preview']['settings'],
                                 'process_limits': validated['preview']['process_limits'], 'qualified': False},
            'build': states['build-benchmark']['build'], 'binary': states['build-benchmark']['binary'],
        },
        'performance': performance, 'cold_process_diagnostic': cold,
        'router_causal_control': causal,
        'capture_accounting': {'captures_by_campaign': {name: value['captures'] for name, value in performance.items()},
                               'total_captures': sum(value['captures'] for value in performance.values()),
                               'actual_rpc_totals_all_sources': accounting,
                               'scope': 'Actual retained per-capture counts from both revisions; no projected or inferred successful RPC totals.'},
        'history': {'required_original_records': validated['history'],
                    'preserved': True,
                    'scope': 'Original causal reds, compile failures, test failures, fixture diagnosis and later positives keep their actual source and outcome. Later results do not relabel or erase them.'},
        'resource_days': {'snapshot_archive_path': snapshot_path.name, 'snapshot_utc': snapshot_value['snapshot_utc'],
                          'older_source_results_inherited': False, 'current_runtime_24_hour_qualification': False},
        'open_qualification': ['Actual complete current-runtime resource duration and broader resource attribution.',
                               'Shipping CPU, latency and throughput comparisons on dedicated hosts.',
                               'Complete per-side payload/entropy/field-access/lifecycle matrix and platforms.',
                               'Remaining feature, telemetry, interop, security and release gates.',
                               'Ordinary successful DATA-owner destruction under backend locks: source concern remains open and not runtime-reproduced.'],
        'validated_inputs': [item for _, item in sorted(observed.items(), key=lambda item: str(item[0]))],
    }
    C['verify_observed'](observed)
    result_bytes = C['encoded'](result)
    snapshot_bytes = C['encoded'](snapshot_value)
    publish_new(snapshot_path, snapshot_bytes)
    publish_new(dest / 'results.json', result_bytes)
    print(json.dumps({'source': pins['candidate_runtime'], 'qualified': False,
                      'workspace': result['validation']['workspace']['counts'],
                      'sanitizer': result['validation']['sanitizer']['counts'],
                      'captures': result['capture_accounting']['total_captures'],
                      'rpc_totals': accounting, 'results': C['ref'](dest / 'results.json'),
                      'day_snapshot': C['ref'](snapshot_path)}))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
