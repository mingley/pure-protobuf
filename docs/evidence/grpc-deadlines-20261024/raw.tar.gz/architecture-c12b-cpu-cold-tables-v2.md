# C12b instruction and fresh-process results

Current `40f219fa`; before `beb4ecd9`. **1,448 captures /44,904 successful RPCs** across all three terminal campaigns.

| Campaign | Captures | Successful RPCs, both sources |
|---|---:|---:|
| native | 1,088 | 40,800 |
| cpu | 264 | 3,960 |
| cold-native | 96 | 144 |

**Superseded before promotion.** C12b ASAN and full workspace were not run; neither is a failure. The server identity byte/instruction regression is being repaired in a separate candidate. These results remain attached to `40f219fa`.

## Instrumented instructions

All **20 measured equal-Prost gzip native endpoint groups use 3.18–16.53% fewer instructions than fresh same-side tonic**; both paired repeats win in every group.
Plaintext, one connection/one in flight, all five shapes at 1/64 KiB, 10/20-RPC batches, two paired repeats. This is the measured subset, not a shipping CPU/latency/throughput result.

Million instructions/RPC. Reference is tonic/prost.

| Side | Workload | tonic/prost | Current | Difference | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1 KiB, gzip | 2.23728 | 2.02170 | -9.64% | 2 wins |
| client | server_stream, 1 KiB, gzip | 1.23714 | 1.03261 | -16.53% | 2 wins |
| server | unary, 64 KiB, gzip | 3.00834 | 2.91253 | -3.18% | 2 wins |

Million instructions/RPC. Reference is the old Beb source. All source instruction increases remain visible, including the CPU-band tie.

| Side | Workload | Before | Current | Change | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1 KiB, gzip | 2.38477 | 2.02170 | -15.22% | 2 improve |
| client | unary, 1 KiB, identity | 0.02763 | 0.02807 | +1.60% | 2 within band |
| server | unary, 1 KiB, identity | 0.03722 | 0.03975 | +6.80% | 2 regress |

## What remains slower

No current instruction-median loss appears against tonic in these 22 equal-Prost
native endpoint groups. The identity server still regresses versus the old source:
**+6.80% instructions** and **+27.43% requested bytes** in the separate native campaign.
The large identity/bidi byte gaps and pbrs interop losses remain in the native tables.
Pbrs interop includes additional handler work; no pbrs instruction case ran here.
The JSON retains every source cost increase and all original repeat ranges.

## Fresh process plus one RPC

**Includes setup.** No startup subtraction, isolated cold-RPC cost, hardware-cold-cache or shipping-timing claim. Four repeats; the two-RPC control remains in raw records.

Requested process bytes, KiB. These totals are cumulative allocation requests since main, not RSS.

| Side | Workload | Before | Current | Change | Current min–max |
|---|---|---:|---:|---:|---:|
| client | unary, 0 B, gzip | 471.10 | 439.11 | -6.79% | 439.11–439.11 |
| server | unary, 0 B, gzip | 468.42 | 444.15 | -5.18% | 444.13–444.42 |
| client | unary, 1 KiB, identity | 87.98 | 87.97 | -0.02% | 87.95–87.98 |
| server | unary, 1 KiB, identity | 84.64 | 92.37 | +9.13% | 92.34–92.37 |

All **7 CPU-capture source cost increases**, **0 CPU-capture tonic cost increases** and **2 fresh-process cost increases** remain in the JSON without a cutoff. Counts are cell/side/metric groups; they are not additional captures or test passes.
Cold raw ranges retain all four values and both one/two-RPC process totals; standard N2−N1 summaries are separate diagnostics.

Callgrind uses release binaries with allocation counting enabled. Instructions are not shipping CPU or latency/throughput.
Both endpoints are separate scopes. Full pbrs interop includes extra handler work; preserve its losses separately from equal-Prost.
All group rows retain original paired ratios/dispositions or all four raw process values. No cutoff hides a positive median cost change.
A 2% CPU classification band is a reporting convention; a 1.60% increase classified tie is still retained.
All three campaigns belong only to `40f219fa`. Their results do not qualify a future C12c candidate.
Combined source changes do not isolate each mechanism; current source concerns and future repairs are not measurements.
