#!/usr/bin/env python3
"""Unlink obsolete generated test programs after final prechecks; retain libraries."""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c12b'
CACHE = ROOT / 'work/stable-target/debug/deps'
PINS = Q / 'architecture-c12b-source-pins.json'


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def source():
    return {k: subprocess.check_output(['git', *args], cwd=TREE, text=True).strip()
            for k, args in [('head', ['rev-parse', 'HEAD']),
                            ('status', ['status', '--porcelain', '--untracked-files=all'])]}


def processes():
    blocked, unavailable = [], []
    cache_program_names = {p.name for p in CACHE.iterdir()
                           if not p.is_symlink() and p.is_file() and not p.suffix
                           and os.access(p, os.X_OK)}
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal() or int(proc.name) == os.getpid():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            argv = (proc / 'cmdline').read_bytes().split(b'\0')
            if not argv or not argv[0]:
                continue
            program = Path(os.fsdecode(argv[0])).name
            if (program in ['cargo', 'rustc', 'rustdoc', 'clippy-driver']
                    or program in cache_program_names or os.fsencode(CACHE) in argv[0]):
                blocked.append({'pid': int(proc.name), 'argv': [os.fsdecode(x) for x in argv if x]})
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            unavailable.append(int(proc.name))
    assert not blocked and not unavailable, {'active_build_or_test': blocked, 'unavailable_cmdline': unavailable}
    return {'active_build_or_test': [], 'unavailable_cmdline': [],
            'scope': 'Readable same-UID command lines only. Protected exe/maps/cwd/fd selectors are not inspected; this is not a global mapping or descriptor-quiescence claim.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    state_path = Q / 'architecture-c12b-prechecks-state.json'
    state = json.loads(state_path.read_text())
    assert state['state'] == 'passed', 'Wait until every final precheck has passed.'
    assert source() == state['source'] and state['source']['status'] == ''
    assert sha(PINS) == state['pins']['sha256']
    assert CACHE.is_dir() and not CACHE.is_symlink()
    assert CACHE.resolve() == CACHE
    before = processes()
    cutoff = datetime.datetime.fromisoformat(state['started_utc']).timestamp()
    used = set()
    logs = []
    for check in state['checks']:
        assert check['exit_code'] == 0
        for record in check['files']:
            path = Path(record['path'])
            assert sha(path) == record['sha256']
            if path.suffix in ['.stdout', '.stderr']:
                logs.append(record)
                for found in re.findall(r'^\s*Running .*?\(([^()]+)\)\s*$', path.read_text(), re.MULTILINE):
                    p = Path(found)
                    used.add(str((p if p.is_absolute() else TREE / p).resolve()))
    files, keep = [], []
    for path in sorted(CACHE.iterdir()):
        if path.is_symlink() or not path.is_file() or path.suffix or not os.access(path, os.X_OK):
            continue
        with path.open('rb') as stream:
            if stream.read(4) != b'\x7fELF':
                continue
        st = path.stat()
        why = 'Executed by final prechecks' if str(path) in used else 'Created or changed during final prechecks' if st.st_mtime >= cutoff else None
        row = {'path': str(path), 'bytes': st.st_size, 'device': st.st_dev,
               'inode': st.st_ino, 'mtime_ns': st.st_mtime_ns, 'sha256': sha(path)}
        if why:
            keep.append(dict(row, reason=why))
        else:
            files.append(row)
    inventory = {'qualified': False, 'source': source(), 'pins_sha256': sha(PINS),
                 'prechecks_state_sha256': sha(state_path), 'logs': logs,
                 'command_scan': before, 'cache': str(CACHE), 'keep': keep, 'unlink': files,
                 'free_bytes_before': shutil.disk_usage(ROOT).free,
                 'limits': 'Only obsolete regular executable ELF directory entries are unlinked. No truncation, sources, shared libraries, rlibs, metadata, current test programs, copied evidence ELFs or live soak binaries. Linux open/mapped file contents remain intact after unlink. Generated programs are rebuildable.'}
    if not args.execute:
        print(json.dumps({'state': 'plan', 'unlink_files': len(files), 'logical_bytes': sum(x['bytes'] for x in files), 'kept_programs': len(keep)}))
        return
    inventory_path = Q / 'architecture-c12b-stale-test-programs-inventory.json'
    result_path = Q / 'architecture-c12b-stale-test-programs-reclaim.json'
    assert not inventory_path.exists() and not result_path.exists()
    assert source() == state['source'] and sha(PINS) == state['pins']['sha256']
    processes()
    for row in files:
        st = Path(row['path']).stat()
        assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) == (row['device'], row['inode'], row['bytes'], row['mtime_ns'])
    with inventory_path.open('x') as out:
        json.dump(inventory, out, indent=2); out.write('\n')
    for row in files:
        path = Path(row['path'])
        assert path.parent == CACHE and not path.is_symlink()
        st = path.stat()
        assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) == (row['device'], row['inode'], row['bytes'], row['mtime_ns'])
        path.unlink()
    assert source() == state['source'] and sha(PINS) == state['pins']['sha256']
    assert all(Path(row['path']).is_file() and sha(Path(row['path'])) == row['sha256'] for row in keep)
    result = {'state': 'completed', 'qualified': False, 'unlinked_programs': len(files),
              'inventory_sha256': sha(inventory_path), 'logical_unlinked_bytes': sum(x['bytes'] for x in files),
              'free_bytes_after': shutil.disk_usage(ROOT).free, 'source_after': source(),
              'scope': inventory['limits'], 'command_scan_after': processes()}
    with result_path.open('x') as out:
        json.dump(result, out, indent=2); out.write('\n')
    print(json.dumps(result))


if __name__ == '__main__':
    main()
