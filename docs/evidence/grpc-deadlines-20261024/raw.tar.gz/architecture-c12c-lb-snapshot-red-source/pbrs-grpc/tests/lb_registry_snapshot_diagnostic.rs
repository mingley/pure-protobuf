//! Temporary causal replay of the original service_config fixture's two reads.
//! A fresh test process starts before any default policy is registered.
#![allow(
    clippy::disallowed_types,
    clippy::unwrap_used,
    reason = "two barriers establish the exact registry registration interleaving"
)]
use pbrs_grpc::ServiceConfig;
use pbrs_grpc::lb::{ensure_default_policies_registered, is_policy_registered, select_lb_policy};
use std::sync::{Arc, Barrier};

#[test]
fn original_false_snapshot_assertion_fails_after_default_registration() {
    let config = ServiceConfig::parse(
        r#"{"loadBalancingConfig":[{"pick_first":{"shuffleAddressList":true}}]}"#,
    )
    .unwrap();
    let start = Arc::new(Barrier::new(2));
    let finished = Arc::new(Barrier::new(2));
    let worker_start = Arc::clone(&start);
    let worker_finished = Arc::clone(&finished);
    let worker = std::thread::spawn(move || {
        worker_start.wait();
        // This public initializer calls the same per-policy OnceLock
        // registrations used by client::pool::connect_uri_inner.
        ensure_default_policies_registered();
        worker_finished.wait();
    });
    let before = is_policy_registered("pick_first");
    assert!(
        !before,
        "fresh-process control must observe the false branch"
    );
    start.wait();
    finished.wait();
    worker.join().unwrap();
    assert!(is_policy_registered("pick_first"));
    let selected = select_lb_policy(&config);
    assert_eq!(
        selected.as_ref().map(|policy| policy.name.as_str()),
        Some("pick_first")
    );
    // Exact old fixture assertion, using the earlier false snapshot.
    if !before {
        assert!(selected.is_none(), "original false-snapshot expectation");
    }
}
