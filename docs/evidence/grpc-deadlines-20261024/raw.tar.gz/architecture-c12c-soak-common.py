#!/usr/bin/env python3
"""Shared read-only pin and qualification checks for the C12c soak launchers."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import runpy
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
PINS = Q / 'architecture-c12c-source-pins.json'
TREE = ROOT / 'work/architecture-c12c'
EMPTY = hashlib.sha256(b'').hexdigest()
DIAGNOSTIC = 'repeated independent-peer server deadline fixture'
OVERLAY = 'pbrs-grpc/tests/deadline_sustained.rs'
RESOURCE_PREVIEW = Q / 'architecture-c12c-resource-preview/report.json'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def ref(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def verify(reference):
    path = Path(reference['path'])
    allowed = path.resolve().is_relative_to(Q.resolve()) or path.resolve() in {
        ROOT / 'work/run-rust', ROOT / 'work/record.py'}
    assert not path.is_symlink() and allowed, path
    assert ref(path) == reference, reference
    return path


def load(path):
    return json.loads(Path(path).read_text())


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.next.{os.getpid()}')
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def exclusive(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def publish_once(path, value, staging):
    temporary = Path(staging) / (Path(path).name + f'.publish.{os.getpid()}')
    atomic(temporary, value)
    os.link(temporary, path)
    temporary.unlink()


def git(*arguments, cwd=TREE):
    return subprocess.check_output(['git', *arguments], cwd=cwd, text=True).strip()


def source(cwd=TREE):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd)}


def pins(expected_sha):
    assert re.fullmatch(r'[0-9a-f]{64}', expected_sha or ''), 'explicit immutable pins SHA256 required'
    assert not PINS.is_symlink() and digest(PINS) == expected_sha, 'C12c source pins changed'
    data = load(PINS)
    assert data['schema'] == 'pbrs.c12c-source-pins.v1' and data['qualified'] is False
    assert re.fullmatch(r'[0-9a-f]{40}', data['candidate_runtime'])
    assert source() == {'head': data['candidate_runtime'], 'status': ''}
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=TREE,
                          capture_output=True).returncode == 1
    for item in data['inputs']:
        verify(item)
    for name, sha in data['identical_harness'].items():
        assert digest(TREE / name) == sha, name
    return data


def caps(seconds):
    return {'address_space': 1073741824, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': seconds + 30}


def gate(name, data, expected_sha):
    path = Q / ('architecture-c12c-' + name + '-state.json')
    state = load(path)
    clean = {'head': data['candidate_runtime'], 'status': ''}
    assert state['state'] == 'passed' and state['active'] is None, path
    assert state['qualified'] is False and state['source'] == state['source_after'] == clean, path
    assert state['mode'] == name and state['pins'] == ref(PINS), path
    assert state['pins']['sha256'] == expected_sha
    assert state['checks'], path
    for check in state['checks']:
        assert check['exit_code'] == 0 and check['source_after'] == clean, check['name']
        assert check['totals']['failed'] == 0, check['name']
        for item in check['files']:
            verify(item)
        record = load(next(row['path'] for row in check['files'] if row['path'].endswith('.json')))
        assert record['exit_code'] == 0 and not record.get('timeout'), check['name']
        assert record['source'] == {'head': data['candidate_runtime'], 'diff_sha256': EMPTY, 'untracked': {}}
    # ASAN executable references may intentionally name a reclaimed compiler
    # cache. Their retained hashes/logs are evidence; they are not launch inputs.
    return ref(path)


def resource_preview(data):
    report = load(RESOURCE_PREVIEW)
    assert report['source']['commit'] == data['candidate_runtime'] and report['source']['dirty'] is False
    assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
    assert report['exit_code'] == 0 and report['smoke'] == {'status': 'passed', 'failures': []}
    assert report['build']['profile'] == 'release'
    limits = {key: {'soft': value, 'hard': value} for key, value in caps(30).items()}
    assert report['process_limits'] == report['process_limits_requested'] == limits
    assert report['tools']['rustc'].splitlines()[0] == data['tools_required']['rustc']
    assert report['tools']['cargo'] == data['tools_required']['cargo']
    validator = TREE / 'scripts/grpc-resource-campaign.py'
    assert not runpy.run_path(str(validator))['validate_report'](report)
    binary = Path(report['binary']['path'])
    assert binary.parent == RESOURCE_PREVIEW.parent and digest(binary) == report['binary']['sha256']
    return {'report': ref(RESOURCE_PREVIEW), 'binary': ref(binary),
            'validator': {'path': str(validator), 'sha256': digest(validator), 'bytes': validator.stat().st_size},
            'tools': report['tools'], 'duration_actual_seconds': report['duration_actual_seconds']}


def readiness(expected_sha, full=True):
    data = pins(expected_sha)
    names = ['prechecks']
    if full:
        names += ['resource-preview', 'build-benchmark', 'native', 'cpu', 'asan', 'workspace']
    gates = {name: gate(name, data, expected_sha) for name in names}
    optional = Q / 'architecture-c12c-cold-native-state.json'
    if full and optional.exists():
        gates['cold-native'] = gate('cold-native', data, expected_sha)
    return {'source_pin': data['candidate_runtime'], 'pins': ref(PINS), 'gates': gates,
            'resource_preview': resource_preview(data) if full else None,
            'qualified': False,
            'scope': 'Exact-source local checks only; these gates do not establish overall production readiness or speed superiority.'}
