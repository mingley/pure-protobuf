# C12 resource and deadline diagnostics

Prepared controllers only. No compiler, Rust fixture, resource test, network,
publication or cache cleanup has run through this preparation. Static validation
includes Python parsing, Rust syntax parsing and synthetic controller decisions.
Those checks are not production tests or a completed duration run.

The pinned source is `f17aa99108ee73f76f5dbcd42ff54fa73840f68c`.
The immutable `architecture-c12-source-pins.json` SHA256 is
`91b28758adc7110e68dd6b4e2f0b7c14620a39a6bfa568c7fa198a1559e49f2c`.
The controllers read and verify that file; they do not rewrite it.

## Two separate workloads

| Diagnostic | What runs | What it does not prove |
|---|---|---|
| General resources | The unchanged pinned `scripts/grpc-resource-campaign.py`, seed 20261002, release profile, 86,400 requested seconds | Every custom-service deadline case, all platforms, shipping performance, or overall production readiness |
| Repeated deadline fixture | The three original and fifteen extended independent-peer cases, sequentially in one process, for 86,400 actual wall seconds | Real-time timer scheduling, real TCP/TLS coverage, eighteen new distinct tests per cycle, or an inferred RPC count |

Both day processes use the original fixed limits: address space 1 GiB, 128 file
descriptors, 4,096 same-UID processes and 86,430 CPU seconds. The deadline preview
uses 30 requested actual seconds and a 60-second CPU limit. Limits apply to the
test ELF, not its compiler.

The deadline cases retain their original controlled Tokio clock and their raw
peer, status, ownership, cancellation and recovery assertions. A separate
`std::Instant` measures real elapsed duration. Each cycle must return descriptors
and live Tokio tasks to the counts measured before the first cycle; no warmup
baseline reset hides a growing count. The copied cases also exercise their own
service/producer Drop and lifecycle assertions.

The wrapper samples RSS and the existing idle decoded-buffer gauges. Idle cache
must be zero, leases balanced, and reported peak capacity within the existing
16 MiB budget. These gauges do not represent all memory. RSS remains subject to
the address-space cap; no universal leak-free claim follows from a finite run.
One real second of quiet follows an already quiescent cycle to limit background
load. A separate supervisor rejects a 60-second gap without a completed cycle,
including a synchronous deadlock that an async watchdog cannot preempt.

## Test-only source overlay

The static staged fixture was generated from the pinned Git objects, not from a
mutable working tree. `architecture-c12-deadline-fixture-pinned.json` records its
source hashes, all discovered case names, wrapper hash and exact 18-case count.
Only Tokio test attributes are removed; each source file is placed in a separate
module and all discovered cases are called from that module. Assertions, test
budgets and call shapes are retained.

The later prepare action creates a new detached
`work/architecture-c12-deadline`. Every tracked file except historical
`docs/evidence/` contents is hashed against the candidate Git blobs. The only
addition is untracked `pbrs-grpc/tests/deadline_sustained.rs`. No runtime file,
manifest, lockfile or existing frozen checkout changes.

The release build copies its ELF and closed compiler logs into an immutable Q
package. It verifies all manifest features, `copy-counts`/`grpc-web`, optimization
level 3, disabled debug assertions, test profile, Rust/Cargo 1.99.1 and unchanged
runtime source. The same copied ELF runs its preview and day.

## Commands for the root agent

Run from `/workspace/pure-protobuf`. The static fixture is already staged under
the root's preparation grant. Worktree creation, builds and execution still need
their own root action; no command below has been run by this preparation.

```sh
pins_sha=91b28758adc7110e68dd6b4e2f0b7c14620a39a6bfa568c7fa198a1559e49f2c
python3 work/qualification/architecture-c12-soaks.py prepare-deadline \
  --pins-sha256 "$pins_sha" --execute
python3 work/qualification/architecture-c12-soaks.py build-deadline \
  --pins-sha256 "$pins_sha" --execute
python3 work/qualification/architecture-c12-soaks.py preview-deadline \
  --pins-sha256 "$pins_sha" --execute
```

Build readiness requires clean C12 pins and the passing prechecks. Day readiness
additionally requires passing resource preview, benchmark build, native counters,
instruction counters, ASAN and full workspace records, including their pinned
closed logs. If the optional cold-native phase has a record, it must pass too.
Reclaimed ASAN compiler executables remain hash metadata; their absence does not
rewrite a successful test phase.

```sh
python3 work/qualification/architecture-c12-soaks.py check-ready \
  --kind resource --pins-sha256 "$pins_sha"
python3 work/qualification/architecture-c12-soaks.py check-ready \
  --kind deadline --pins-sha256 "$pins_sha"
```

Each day uses a separate root grant JSON with these required fields (substitute
`resource` or `deadline` in the action):

```json
{
  "source_pin": "f17aa99108ee73f76f5dbcd42ff54fa73840f68c",
  "pins_sha256": "91b28758adc7110e68dd6b4e2f0b7c14620a39a6bfa568c7fa198a1559e49f2c",
  "root_granted": true,
  "action": "launch-c12-resource-day"
}
```

```sh
python3 work/qualification/architecture-c12-soaks.py launch --kind resource \
  --pins-sha256 "$pins_sha" --grant ROOT_RESOURCE_GRANT_JSON --execute
python3 work/qualification/architecture-c12-soaks.py launch --kind deadline \
  --pins-sha256 "$pins_sha" --grant ROOT_DEADLINE_GRANT_JSON --execute
```

The resource day still invokes the original campaign's release build. Its
exclusive campaign directory is nested under the orchestration directory:
`resource-architecture-c12-day/campaign/`. Its launch record names that path.
The repeated deadline day uses `resource-architecture-c12-deadline-day/`.
All mutable output, supervisor state and publication state stay in these
`resource-*` directories, outside immutable evidence selection.

## Terminal publication

Supervisors are detached, copy and pin their harness, preserve exclusive attempt
ownership, and attempt publication after a pass, failure or incomplete run.
Duplicate supervisor invocation cannot overwrite prior terminal evidence.
Missing reports, changed source, short duration or failed validation cannot pass.
Publisher execution failures are retained explicitly.

The publisher creates immutable finite copies before archiving. ELF bytes and
Python bytecode are omitted, while executable hashes remain. Its three normal
main-push attempts use separate sparse publication worktrees, preserving all
other evidence in Git without checking out approximately 794 MB of historical
capsules per attempt. It never force-pushes, rebases or resets a working tree.

The older C8/C11 days, their source pins, helpers, binaries, outputs and publishers
remain untouched. Their outcomes are separate evidence and cannot certify C12.
