# Final repository validation and C12c day diagnostics

Prepared launch helpers only. No final workspace result or day run is claimed
by this preparation.

| Identity | Commit / SHA256 |
|---|---|
| Measured runtime and day worker source | `7c02eb387a6785d6e914146babe34f0902a6dd62` |
| Original runtime pins | `4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af` |
| Final repository workspace validation | `8144576f74bcf290951a65235e3bb50f24710b71` |
| Tested 27-case fixture | `337ba8b2f01307bcafecc60949eb3560d4610f19cd4ae1d9dd3a0c90e2372a38` |
| Copied release worker ELF | `4db2faf363b801e930b2b8942de366afe3d4cc519b578459d4d97cab25c83876` |

The final repository changes one integration-test fixture after a registry race
and includes previously published soak archives. All other Git blobs and modes
match the measured runtime. The final gate checks the exact twelve changed paths:
one test, one evidence index and ten files in the two older soak capsules.
Relative to parent `33eaf842d640dc2df3e0cc14db194adcc601e616`, only
`pbrs-grpc/tests/service_config.rs` changes.

The workspace gate requires the actual final repository commit in
`architecture-c12c-workspace-final-state.json`. It separately records runtime
source `7c02`. It must pass the unchanged full workspace command, 144 target
summaries, 3,812 passed, zero failed and nine ignored. The recorded environment,
two build jobs, four test workers, 7,200-second timeout and 8 GiB entry gate are
verified. Both earlier failed workspace attempts and all eight state/log
references remain immutable evidence; a missing or failed final result cannot
fall back to either attempt.

The checker verifies the frozen final runner and evidence-input manifest,
compares all three complete Git inventories, verifies before/after proof hashes,
and independently rehashes every physical final-checkout file, mode and symlink.
It requires the exact test-only difference and all pinned causal-review evidence.
Other qualification phases continue to use their original runtime-pinned gates.

The original 27-case worker, build provenance, preview and runtime source proof
remain unchanged. Their original build-helper references remain accurate.
Successor launch-helper references are recorded separately. The source-equivalent
worker needs no rebuild or repeated preview for the integration-test repair.
The existing deadline preview passed 30.791982326 actual wall seconds, with 31
cycles of the same 27 causal cases. It is not a 24-hour result.

## Root actions after the actual final workspace pass

The new controller accepts only `plan`, `check-ready`, `launch` and `supervise`.
All commands below still require root scheduling; none has run in preparation.

```sh
pins_sha=4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af
python3 work/qualification/architecture-c12c-soaks-workspace-final.py check-ready \
  --kind resource --pins-sha256 "$pins_sha"
python3 work/qualification/architecture-c12c-soaks-workspace-final.py check-ready \
  --kind deadline --pins-sha256 "$pins_sha"
```

Each separate day grant must contain:

```json
{
  "source_pin": "7c02eb387a6785d6e914146babe34f0902a6dd62",
  "repository_source_pin": "8144576f74bcf290951a65235e3bb50f24710b71",
  "pins_sha256": "4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af",
  "root_granted": true,
  "action": "launch-c12c-workspace-final-resource-day"
}
```

Use `launch-c12c-workspace-final-deadline-day` for the deadline grant.

```sh
python3 work/qualification/architecture-c12c-soaks-workspace-final.py launch \
  --kind resource --pins-sha256 "$pins_sha" --grant ROOT_RESOURCE_GRANT_JSON --execute
python3 work/qualification/architecture-c12c-soaks-workspace-final.py launch \
  --kind deadline --pins-sha256 "$pins_sha" --grant ROOT_DEADLINE_GRANT_JSON --execute
```

| Output | Path below `work/qualification/` |
|---|---|
| Standard outer state | `resource-architecture-c12c-workspace-final-day/{launch,supervisor-state,termination,publication}.json` |
| Standard actual progress/report | `resource-architecture-c12c-workspace-final-day/campaign/{progress,report}.json` |
| Deadline state/progress/report | `resource-architecture-c12c-workspace-final-deadline-day/{launch,supervisor-state,progress,report,termination,publication}.json` |
| Static launch snapshots | `architecture-c12c-workspace-final-{resource,deadline}-day-launch-snapshot.json` |
| Static deadline terminal | `architecture-c12c-workspace-final-deadline-day-terminal.json` |
| Original deadline preview | `resource-architecture-c12c-deadline-preview/report.json` |
| Final workspace proofs | `architecture-c12c-workspace-final-equivalence{,-after}.json` |

Both days request 86,400 actual seconds under the original 1 GiB address-space,
128-descriptor, 4,096 same-UID process and 86,430 CPU-second limits. The standard
resource campaign keeps seed 20261002 and needs its own release compiler window
and 2 GiB entry headroom. The deadline day reuses the copied ELF. Its controlled
Tokio clock and real `std::Instant` duration, initial task/FD baselines, decoded
cache checks and supervisor watchdog stay unchanged.

Terminal publishers use separate workspace-final evidence paths and normal main
push retries. They retain both runtime and repository source identities, the
original failures, complete equivalence proofs and both source fixtures. No
runtime, fixture-worker, compiler, cache-cleanup or publication action is part of
this metadata preparation. All previous helper generations remain untouched.
