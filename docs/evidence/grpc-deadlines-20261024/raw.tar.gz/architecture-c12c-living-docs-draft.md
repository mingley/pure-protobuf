# Living documentation update — draft only

No tracked edit is authorized by this draft. Source `7c02eb387a6785d6e914146babe34f0902a6dd62`
is frozen; broad final checks and performance captures are still pending. Replace
all metric placeholders with actual terminal records before publication. Keep old
capsules unchanged, including their contemporaneous pending statements.

## README opening

Keep the existing description and support-policy boundary. Replace the stale
current-results paragraph after gates with:

> The [server deadlines and gzip results](docs/evidence/grpc-deadlines-20261024/README.md)
> describe fixed service deadlines, terminal response ownership, unary status
> accounting, selected routed dispatch and bounded gzip output reads at `7c02eb38`. The record includes
> actual validation, source-paired costs and remaining losses. The
> [benchmark tables](docs/benchmarks.md) give the current comparison.
> The gRPC crates remain previews; production readiness and broad superiority
> over tonic/prost remain unproved.

Preserve the protobuf/codegen feature list and Edition boundaries. Do not add a
language-purity selling point or a world-fastest claim.

## docs/benchmarks.md

Use architecture-c12c-benchmarks-draft.md (~100 lines) as the layout. It is an
unfilled publication template, not a results page. Lead with the measured worst
remaining loss and a measured gain if established. Use Before/Current/tonic/prost,
KiB or MiB per RPC, million instructions per RPC, percentages from unrounded
medians. Keep every losing cell in results.json/raw summaries. Fresh-process
numbers include setup. Do not call counter savings latency or throughput wins.

## docs/status.md opening

Replace its current-source preamble/table, retaining later feature inventory:

> Source `7c02eb38` uses one accepted absolute deadline across cooperative service
> waits and RPC shapes. The response owner preserves a committed ending and
> accounts native unary/client-streaming and Web unary with the writer's actual
> status. Native unsent DATA and safe Web message boundaries have explicit
> terminal cleanup. Gzip encoding reads through one initialized 8 KiB chunk.
> [Exact-source validation and measurements](evidence/grpc-deadlines-20261024/README.md)
> retain the limits and original failures.

| Check | Source | Actual result to insert |
|---|---|---|
| Full workspace, all features | `7c02eb38`, clean | {{PASS/FAIL/IGNORE/TARGETS}} |
| Selected ASAN + leak detection | `7c02eb38` | {{COUNTS}}; library, lifecycle filter and seven integration targets, including both deadline targets and terminal accounting; verify actual selection |
| Prechecks | `7c02eb38` | {{ACTUAL}}; strict lint/docs, examples, benchmark correctness and both minimum-version profiles |
| Release resource preview | `7c02eb38` | {{SECONDS/CYCLES/RESOURCES/EFFECTIVE_CAPS}} |
| Source-paired endpoint diagnostics | `7c02eb38` vs `beb4ecd9` | {{ACTUAL_COUNTS}} and losses |
| Current-source sustained resources | {{EXACT_SOURCE}} | {{ACTUAL_STATE}}, no inheritance from older days |

Focused 739/0/1 and resource_bounds25/0/0 runs are historical overlapping scopes,
not extra full-workspace passes. f17's failed full prechecks remain failed.
Timers cannot preempt synchronous work; Web status DATA needs peer credit.
Required features/platforms/releases and broad performance qualification remain open.

## TODO current priorities

Mark fixed deadline origin, full cooperative owner, terminal status accounting and
gzip output initialization as implemented at `7c02eb38`. Insert actual comparative result;
do not retain their old 'not implemented/no reproduction' statements.

1. Investigate the ordinary successful DATA-owner destruction path. Source review
   finds a possible user Drop under a backend lock. It is **open and unreproduced**;
   do not present it as an established runtime deadlock or a repaired path.
2. Address the actual largest measured endpoint loss from final native/CPU records.
   Attribute work before choosing pooling, scheduling or a backend rewrite.
3. Complete a same-source generic day and separate bounded cache/deadline duration
   checks. A passed older day or preview does not qualify `7c02eb38`.
4. Extend the client/server matrix to shipping CPU, latency, throughput, field
   access, realistic entropy, short/cold and overloaded streams, required platforms
   and real networks. Retain all losing cells and failed captures.
5. Continue finite-admission handler-isolation experiments, owned encode scratch,
   first-frame reservations, codegen/read-all decode, xDS/discovery, credentials,
   typed extensions, telemetry and release/consumer gates.

Retain task-card identities/acceptance criteria and established decode idle budgets.
Move old numeric examples below an explicit beb4ecd9 heading if retained.

## docs/decisions/grpc-execution.md

Keep first-principles cost model (setup/message/byte/queue work), resource owners,
and synchronous handler-isolation limits. Replace the current-gap section with:

- One local header-acceptance absolute deadline; all waits use remaining budget.
- Existing CancelFlag shared ownership carries state instead of another allocation.
- The outer owner begins lifecycle accounting before shape selection, drops the
  application future before ending owner, and clears pooled call ownership.
- Committed native/Web terminal results stay immutable. Unary accounting uses
  the actual writer-selected status; Drop/late clock reads cannot rewrite it.
- Preserve current HTTP2 frame length/headers; drop unsent native tails safely.
  Safe Web boundaries preserve padded text carry. A genuinely partial Web body
  cannot accept a second status frame; reset is the defined fallback.
- New terminal-path user drops/wakers occur outside engine locks. The broader
  ordinary-success DATA-owner source concern remains open/unreproduced.
- Gzip encoder keeps independent message state and CRC/ISIZE/error behavior,
  using an initialized8KiB read chunk. No CPU advantage follows from this model.
- Compiler test-profile Single<LayoutService> driver size2280→544bytes is layout
  evidence only; it proves no shipping CPU, allocation, latency or RSS advantage.

Link the capsule for causal reds, compile/test failures, fixture repairs and review
correction. Do not repeat full history on the architecture page.

## docs/evidence/README.md

Add one leading dated row for the new capsule with exact `7c02eb38` source and actual
validation/capture counts. Describe scope/losses and qualification limits. Keep
auto-publisher markers and old rows intact. A short new source-scoped sentence may
state actual older terminal days, but never revise an older immutable capsule.

## Evidence history paragraph

Retain original deadline3reds, compile failure before tests, v2library713/1/1,
v2raw3/0/0 plus12/2/0, v3library716/0/1 plus3 and15, and f17full1738/1/1.
The slow-writer run observed2/3drips with all32fast RPCs successful. Same f17 ELF
isolated and target controls later pass. Controlled gate shows relative-sleep lag;
unique original cause was not reproduced. The correction uses a common origin and
absolute15/30/45msdrips;32fast success,3drips,p99<200ms,queue<100ms,byte bounds,
exact replies,quiescence,recovery are retained. Preserve source/commands/trace.

The unary five-test red genuinely compiles and fails on f17 with unchanged runtime
and only the identical test overlay. Repaired focused739/0/1 is separate from
final broad checks. The Tonic observer finding is withdrawn: unsupported_policy
rejects this route before Accounting. Keep original review and correction.

Cleanup scripts/inventory/reclaim records belong in raw evidence. State actual
selected paths, ownership and readable command-line scope. Denied exe/maps/fd
selectors remain unknown; no full process quiescence or source equivalence follows
from unreadable selectors. Never include ELF bytes in the archive.

## Router successor and source history

Current `7c02eb38` selects the routed service future synchronously under its
existing outer owner, avoiding retention of the complete Rpc in the initial
Router async state. Post-logging and interceptor expiry checks remain in place.
It adds no second dispatch box. Source review identifies only router.rs as the
production behavior change versus `40f219fa`; the other two changed files add controls.

Private release proof: Router 4,288 bytes before, 544 after; Single544bothbefore and after,
including a large application future. Same proof fixture; before functional
assertions pass and its final relative-size guard fails (0passed/1failed). After
passes1/0. Four routed raw-peer controls pass before and after; all-feature27
integration controls plus one private owner control pass. These scopes overlap
later broad checks. Keep all source snapshots/commands/ELF provenance. The layout
proof is not shipping allocation, CPU, latency, throughput, RSS or allocator-site
attribution. Final7c source-paired metrics are still placeholders.

Old `40f219fa` captures:1,448 passed,44,904 successful RPCs, with actual server identity
unary +27.43% requested bytes and +6.80% diagnostic instructions versus Beb.
All 20 selected equal-Prost gzip endpoint instruction groups beat fresh tonic,
but broad superiority was not established. These measurements prompted the
Router successor. ASAN / full workspace were **not run because source superseded**;
do not label them failed or qualified. Keep all 18 source / 46 tonic native positive
cost groups and all CPU/cold losses in their actual source-specific records.

The old Beb standard resource day completed86,405.461 seconds and was published
at `5c8d5146` in grpc-decode-reuse-soak-20261023. It qualifies only its exact recorded
resource scope/source, never7c. Use actual publication-time cache/day snapshots;
all 7c days remain unrun until explicit launches and their own terminal records.
Old `f17aa991` and40f deadline soak preparations were staged/source checked only, never
compiled or launched. Preserve those metadata as preparation, not attempts.
