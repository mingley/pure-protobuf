# Router allocation control — actual results

Baseline `beb4ecd9`; before `40f219fa`; after `7c02eb38`. **48 captures / 1,800 successful RPCs**, separate from the canonical campaigns.
All source/binary/harness/controller/tool/settings/accounting checks pass. N25/N50, two repeats, unary/bidi, 1 KiB identity, plaintext, one connection/one in flight, tonic Prost client, native/tonic Prost servers.

## Server requested bytes per RPC

| Shape | Beb | 40f | 7c02 | Fresh tonic at 7c | 7c vs 40f | 7c vs Beb | 7c vs tonic |
|---|---:|---:|---:|---:|---:|---:|---:|
| unary | 14,854.88 | 18,928.18 | 15,188.00 | 25,029.36 | -19.76% | +2.24% | -39.32% |
| bidi | 44,514.20 | 48,376.42 | 44,639.76 | 33,737.04 | -7.72% | +0.28% | +32.32% |

## Server allocation requests per RPC

| Shape | Beb | 40f | 7c02 | Fresh tonic at 7c | 7c vs 40f | Paired directions |
|---|---:|---:|---:|---:|---:|---|
| unary | 20.04 | 19.96 | 20.00 | 37.06 | +0.20% | -0.200%, +0.604% |
| bidi | 43.10 | 43.14 | 43.20 | 49.92 | +0.14% | +0.186%, +0.093% |

## Ranges across the two repeats

| Source | Shape | Native bytes/RPC min–max | Tonic bytes/RPC min–max | Native allocations/RPC min–max | Tonic allocations/RPC min–max |
|---|---|---:|---:|---:|---:|
| baseline | unary | 14,852.00–14,857.76 | 25,028.00–25,028.00 | 20.00–20.08 | 37.00–37.00 |
| baseline | bidi | 44,507.00–44,521.40 | 33,740.00–33,740.00 | 43.00–43.20 | 50.00–50.00 |
| before | unary | 18,917.32–18,939.04 | 25,025.88–25,028.00 | 19.88–20.04 | 36.92–37.00 |
| before | bidi | 48,362.04–48,390.80 | 33,739.40–33,739.40 | 43.04–43.24 | 49.96–49.96 |
| after | unary | 15,188.00–15,188.00 | 25,028.60–25,030.12 | 20.00–20.00 | 37.04–37.08 |
| after | bidi | 44,625.68–44,653.84 | 33,734.68–33,739.40 | 43.12–43.28 | 49.88–49.96 |

Only router.rs changes production behavior from 40f to 7c; the other changed files add test controls. The independent source review and exact source snapshots retain that scope. The same pinned benchmark/handlers/allocator settings, real stdout counters and unchanged ledger were used at all three committed sources.
Actual byte reductions are 19.76% unary and 7.72% bidi versus 40f, with both repeats in the same direction. This is separate from the private Router 4,288→544 byte layout proof; no allocation stack/site sampling was performed.
Unary still requests 2.24% more bytes than Beb; bidi 0.28% more and 32.32% more than tonic. Allocation-count increases remain: +0.20% unary (mixed repeat directions), +0.14% bidi (both slightly higher).
All 23 higher source-cost groups, including client/tonic controls, and 3 higher same-side tonic-cost groups remain in the summary with actual values and both repeat directions. No cutoff removes small increases.
These are three separate source runs, not an interleaved ABBA cross-source experiment. Requested bytes are cumulative requests, not RSS or retained memory. No CPU, latency, throughput, broad superiority or production qualification claim follows.

Raw summary: architecture-c12c-router-causal-summary.json. Execution: architecture-c12c-router-causal-summary-execution.{json,stdout,stderr}.
