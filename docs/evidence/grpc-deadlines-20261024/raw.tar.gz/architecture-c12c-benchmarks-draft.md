# Benchmarks

Draft only: fill from terminal7c02 captures. Prior40f results remain historical;
its 1,448 captures and 44,904 RPCs do not qualify this source.

{{ONE_SENTENCE_LARGEST_MEASURED_GAIN_AND_ONE_SENTENCE_WORST_REMAINING_LOSS}}
Production readiness and broad superiority over tonic/prost remain unproved.

Measured source: `7c02eb38`; before: `beb4ecd9`. Linux x86_64, Rust 1.99.1,
shared host. {{ACTUAL_CAPTURE_UTC_DATE}}. Earlier revisions have separate records.

## Allocation requests

**Requested bytes per RPC. Lower is better.** Matched Prost handlers.
These are cumulative allocation requests, not retained memory or RSS.

| Side | Workload | Current | tonic/prost | Difference |
|---|---|---:|---:|---:|
| {{WORST_CLIENT_SIDE}} | {{WORKLOAD_AND_SIZE}} | {{KiB_OR_MiB}} | {{KiB_OR_MiB}} | {{PERCENT}} |
| {{WORST_SERVER_SIDE}} | {{WORKLOAD_AND_SIZE}} | {{KiB_OR_MiB}} | {{KiB_OR_MiB}} | {{PERCENT}} |
| {{IDENTITY_SIDE}} | {{WORKLOAD_AND_SIZE}} | {{KiB_OR_MiB}} | {{KiB_OR_MiB}} | {{PERCENT}} |
| {{LARGE_GZIP_SIDE}} | {{WORKLOAD_AND_SIZE}} | {{KiB_OR_MiB}} | {{KiB_OR_MiB}} | {{PERCENT}} |

The pbrs interop route {{ACTUAL_WORST_VALUE_AND_COMPARISON}}. It includes
additional handler work, so it does not isolate codec or transport cost.

## Source changes

**Before versus current.** Values use matched source-paired endpoint medians.

| Side | Workload | Metric | Before | Current | Change |
|---|---|---|---:|---:|---:|
| {{MEASURED_GAIN_SIDE}} | {{WORKLOAD}} | {{UNIT_PER_RPC}} | {{VALUE}} | {{VALUE}} | {{PERCENT}} |
| {{MEASURED_GAIN_SIDE}} | {{WORKLOAD}} | {{UNIT_PER_RPC}} | {{VALUE}} | {{VALUE}} | {{PERCENT}} |
| {{MEASURED_LOSS_SIDE}} | {{WORKLOAD}} | {{UNIT_PER_RPC}} | {{VALUE}} | {{VALUE}} | {{PERCENT}} |

{{DESCRIBE_ANY_REMAINING_SOURCE_COST_INCREASES_AND_REPEAT_RANGES}}
All observed increases remain in the full ledger, including those below 2%.
Percentages use unrounded medians; display bytes to one decimal and allocations
to suitable precision. The combined patch does not isolate each change's effect.

## Instruction diagnostics

**Million instructions per RPC. Lower is better.** Both endpoints run under
Callgrind with allocation counting enabled. These are not shipping CPU,
latency or throughput results.

| Side | Workload | Current | tonic/prost | Difference |
|---|---|---:|---:|---:|
| Client | Upload, 1 KiB gzip | {{VALUE}} | {{VALUE}} | {{PERCENT}} |
| Server | Upload, 64 KiB gzip | {{VALUE}} | {{VALUE}} | {{PERCENT}} |
| {{WORST_SIDE}} | {{WORST_WORKLOAD}} | {{VALUE}} | {{VALUE}} | {{PERCENT}} |
| {{GAIN_SIDE}} | {{GAIN_WORKLOAD}} | {{VALUE}} | {{VALUE}} | {{PERCENT}} |

{{SOURCE_INSTRUCTION_CHANGES_AND_OTHER_TONIC_LOSSES}}
The ±2% reporting band is a convention, not a significance test. Raw profiles
and every endpoint result remain in the capsule.

## Scope

| Completed current-source campaign | Captures | Successful RPCs |
|---|---:|---:|
| Native counters | {{ACTUAL}} | {{ACTUAL_BOTH_SOURCES}} |
| Instructions | {{ACTUAL}} | {{ACTUAL_BOTH_SOURCES}} |
| Fresh-process diagnostic | {{ACTUAL}} | {{ACTUAL_BOTH_SOURCES}} |

{{ACTUAL_OFFERED_DISPATCHED_COMPLETED_SUCCESS_FAILURE_TIMEOUT_RECONCILIATION}}
Native: 25/50 calls, two paired repeats. Instructions: 10/20, two repeats.
Fresh process: 1/2 calls, four repeats; **includes setup**. It does not isolate
cold RPC cost, subtract startup or establish hardware-cold behavior.
{{MATERIAL_FRESH_PROCESS_COST_INCREASE_IF_OBSERVED}}

Selected scopes: {{ACTUAL_SHAPES_CODECS_COMPRESSION_SIZES_LOAD_AND_TLS}}.
Gzip level 6; zero-filled application payloads; four messages per streaming leg;
400 KiB server send buffers; queues 16. Native accounting/channelz stay enabled.
Incompressible inputs have correctness tests; their performance is unmeasured.
Client and server costs are reported separately. Payload size differs from wire size.

The current source adds a fixed accepted deadline across service/handler waits,
terminal response ownership, committed unary status accounting, compact routed
dispatch and bounded gzip output reads. Functional checks do not establish comparative speed.

[Full results and raw captures](evidence/grpc-deadlines-20261024/README.md)
· [Benchmark contract](benchmark-contract.md)

## Reproduce

Build both pinned revisions with the same toolchain and run the archived
source-paired driver with its pinned cell files. The capsule contains the exact
commands, source snapshots, executable hashes, counter records and profiles.
For a single-source native counter run, use:

```sh
python3 scripts/build-rpc-bench.py --source SOURCE --output /tmp/pbrs-build
python3 scripts/grpc-counter-campaign.py \
  --source-checkout "$PWD" --binary /tmp/pbrs-build/rpc-bench \
  --build-record /tmp/pbrs-build/build.json --output /tmp/pbrs-counters \
  --phase native --payloads 1024,65536 --load-levels 1:1,1:16 --repeats 3
```

{{ACTUAL_CURRENT_SOURCE_RESOURCE_PREVIEW_AND_DAY_STATE_WITH_EXPLICIT_SOURCE}}
Older resource days belong to their recorded source and do not qualify this one.
Shipping CPU, latency, throughput, physical networks, syscall/wake attribution,
field access, entropy, overload, required platforms and release checks remain open.
[Earlier results](evidence/grpc-decode-reuse-20261023/README.md)
· [Current priorities](../TODO.md#current-priorities)
