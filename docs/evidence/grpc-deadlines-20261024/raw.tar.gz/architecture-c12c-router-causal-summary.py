#!/usr/bin/env python3
"""Validate three small Router controls and summarize actual allocation requests.

Preparation only unless --execute is supplied. This separate 48-capture diagnostic
never changes canonical campaign totals or establishes shipping-speed advantage.
"""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import runpy
import statistics
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT/'work/qualification'
PINS = Q/'architecture-c12c-source-pins.json'
PINS_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
CONTROLLER = Q/'architecture-c12b-router-allocation-control.py'
CONTROLLER_SHA = 'e14bd79194dd587293067b8b5b6aac90a3cd7c06e004752bb81cd4e08630e810'
SOURCES = {'baseline':'beb4ecd9a9b2143c440892607d5b486318062b61',
           'before':'40f219fa515034b556df7f39e3e3947e364a2ce1',
           'after':'7c02eb387a6785d6e914146babe34f0902a6dd62'}
TREES = {k:ROOT/('work/architecture-'+v) for k,v in [('baseline','c11'),('before','c12b'),('after','c12c')]}
BUILDS = {k:Q/('architecture-'+v+'-rpc-build') for k,v in [('baseline','c11-stable'),('before','c12b'),('after','c12c')]}
ACCOUNTING = ['offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs',
              'failed_rpcs','timeouts','queue_overflows','unstarted_rpcs','unfinished_rpcs']
COSTS = ['allocations','requested_bytes']
OBSERVED = {}


def sha(path):
    value=hashlib.sha256()
    with path.open('rb') as stream:
        for data in iter(lambda:stream.read(1024*1024),b''):value.update(data)
    return value.hexdigest()


def observe(path):
    path=Path(path).absolute()
    assert not path.is_symlink() and path.is_file() and path.resolve().is_relative_to(ROOT.resolve()),path
    value={'path':str(path),'bytes':path.stat().st_size,'sha256':sha(path)}
    if path in OBSERVED:assert OBSERVED[path]==value,('input changed',path)
    OBSERVED[path]=value
    return value


def read(path):
    before=observe(path);data=path.read_bytes()
    assert hashlib.sha256(data).hexdigest()==before['sha256']
    return json.loads(data)


def git(tree,*args):return subprocess.check_output(['git',*args],cwd=tree)
def key(cell):return json.dumps(cell,sort_keys=True,separators=(',',':'))
def scope(cell):return {k:v for k,v in cell.items() if k!='repeat'}
def rng(values):return {'min':min(values),'median':statistics.median(values),'max':max(values),'values':values}
def pct(before,after):return (after/before-1)*100 if before>0 else None


def validate(version,directory,pins):
    directory=directory.resolve(strict=True)
    assert directory.is_relative_to(Q) and directory.relative_to(Q).parts[0].startswith('architecture-c12'),directory
    tree=TREES[version];commit=SOURCES[version];build_dir=BUILDS[version]
    assert git(tree,'rev-parse','HEAD').decode().strip()==commit
    assert not git(tree,'status','--porcelain','--untracked-files=all').strip()
    build=read(build_dir/'build.json');binary=observe(build_dir/'rpc-bench')
    assert build['source']['commit']==commit and build['exit_code']==0 and build['tools']==pins['tools_required']
    assert build['source']['tree']==git(tree,'rev-parse','HEAD^{tree}').decode().strip()
    assert build['binary_sha256']==binary['sha256']
    if version=='baseline':assert observe(build_dir/'build.json')==pins['baseline_build'] and binary==pins['baseline_binary']
    for name,expected in pins['identical_harness'].items():
        assert sha(tree/name)==expected and hashlib.sha256(git(tree,'show',commit+':'+name)).hexdigest()==expected
    controller=read(directory/'control.json')
    assert controller['qualified'] is False and controller['passed'] is True and controller['captures']==16
    assert controller['source']==build['source'] and controller['ledger']=='ledger.json'
    assert controller['pins']=={'binary':binary['sha256'],'harness':pins['identical_harness']['scripts/grpc-load-smoke.py'],
                               'ledger':pins['identical_harness']['scripts/dominance-ledger.py'],'controller':CONTROLLER_SHA}
    assert observe(directory/'controller.py')['sha256']==CONTROLLER_SHA
    expected={key(dict(pair=['tonic','prost',server,'prost'],shape=shape,payload_bytes=1024,tls=False,
                       compression='identity',connections=1,in_flight=1,repeat=repeat))
              for server in ('native','tonic') for shape in ('unary','bidi') for repeat in (0,1)}
    runs={};total=collections.Counter({k:0 for k in ACCOUNTING});reports=[]
    for count in (25,50):
        base=directory/f'n-{count}';report=read(base/'report.json');reports.append(report)
        assert report['schema']=='pbrs.load-smoke.v2' and report['head']==commit and report['dirty'] is False
        assert report['source_verified'] is True and report['build_record']==build
        assert report['binary_sha256']==binary['sha256'] and report['harness_script_sha256']==controller['pins']['harness']
        assert all(report[k] is True for k in ['passed','binary_unchanged','source_unchanged','harness_script_unchanged','controller_unchanged','ledger_unchanged'])
        assert report['rpc_count']==count and report['seed']==20261009 and report['duration_per_cell_seconds']==60
        assert report['allocation_counts'] is True and report['context_switches'] is True
        assert report['callgrind'] is None and report['strace'] is None and report['strace_version'] is None
        assert report['qualification']=={'qualified':False}
        assert len(report['cells'])==len(report['runs'])==8 and {key(c) for c in report['cells']}==expected
        assert observe(base/'harness.py')['sha256']==controller['pins']['harness']
        for item in report['runs']:
            relative=Path(item['path']);assert not relative.is_absolute() and '..' not in relative.parts and item['passed'] is True
            path=base/relative;assert path.resolve().is_relative_to(base.resolve())
            run=read(path);identity=key(run['cell']);assert identity in expected and (count,identity) not in runs
            assert run['passed'] is True and run['client_exit_code']==0 and not run.get('error')
            assert run['metrics']['status_errors']=={} and run['environment']=={'TOKIO_WORKER_THREADS':'2'}
            assert all(type(run['metrics'][k]) is int and run['metrics'][k]==count for k in ACCOUNTING[:4])
            assert all(type(run['metrics'][k]) is int and run['metrics'][k]==0 for k in ACCOUNTING[4:])
            assert read(path.parent/'metrics.json')==run['metrics']
            cell=run['cell'];commands=run['commands'];pair=cell['pair']
            for side,index,command in [('client',0,'load'),('server',2,'load-server')]:
                argv=commands[side]
                assert argv[:2]==[str(build_dir/'rpc-bench'),command]
                assert f'--transport={pair[index]}' in argv and '--codec=prost' in argv and '--compression=identity' in argv
                assert not any(a.startswith('--tls-') for a in argv)
                allocation=run['allocation_totals'][side]
                assert allocation['scope']=='process_since_main' and allocation['includes_reallocations'] is True
                assert all(type(allocation[k]) is int and allocation[k]>=0 for k in COSTS)
                data=observe(path.parent/f'{side}.stdout')
                snapshots=[json.loads(line[len('ALLOCATIONS '):]) for line in Path(data['path']).read_text().splitlines() if line.startswith('ALLOCATIONS ')]
                assert snapshots==[allocation]
            assert all(flag in commands['client'] for flag in [f'--shape={cell["shape"]}','--req-bytes=1024','--resp-bytes=1024','--stream-msgs=4','--connections=1','--max-in-flight=1','--duration-secs=60',f'--rpc-count={count}'])
            runs[count,identity]=run;total.update({k:run['metrics'][k] for k in ACCOUNTING})
    for name in ['binary_sha256','head','dirty','callgrind','allocation_counts','context_switches','strace','strace_version','harness_script_sha256','host','cpu_affinity','cells']:
        assert reports[0][name]==reports[1][name],name
    assert set(runs)=={(n,c) for n in (25,50) for c in expected} and total['successful_rpcs']==600
    ledger=read(directory/'ledger.json')
    # Execute only the unchanged pure comparison over the validated retained files.
    authority=runpy.run_path(str(tree/'scripts/dominance-ledger.py'))['compare'](directory/'n-25',directory/'n-50')
    assert ledger==authority
    endpoints={}
    for identity in sorted(expected):
        small,large=runs[25,identity],runs[50,identity]
        for side in ('client','server'):
            for metric in COSTS:
                before=small['allocation_totals'][side][metric];after=large['allocation_totals'][side][metric]
                assert after>before,('unresolved allocation delta',version,identity,side,metric)
                endpoints[identity,side,metric]=(after-before)/25
    return {'control':observe(directory/'control.json'),'binary':binary,'build':observe(build_dir/'build.json'),
            'host':reports[0]['host'],'cpu_affinity':reports[0]['cpu_affinity'],'actual_rpc_totals':dict(total),'captures':len(runs),
            'endpoints':endpoints,'cells':{identity:json.loads(identity) for identity in expected},'ledger':observe(directory/'ledger.json')}


def summarize(controls):
    source_rows=[];tonic_rows=[]
    groups=sorted({(key(scope(c)),side,metric) for c in controls['after']['cells'].values() for side in ('client','server') for metric in COSTS})
    for previous,current in [('baseline','before'),('baseline','after'),('before','after')]:
        for cellkey,side,metric in groups:
            cell=json.loads(cellkey);values=[]
            for version in (previous,current):
                values.append([controls[version]['endpoints'][key(dict(cell,repeat=r)),side,metric] for r in (0,1)])
            a,b=map(rng,values);paired=[pct(x,y) for x,y in zip(*values)]
            source_rows.append({'from':previous,'to':current,'cell':cell,'side':side,'metric':metric,
                                'native_side':cell['pair'][0 if side=='client' else 2]=='native',
                                'before':a,'current':b,'change_percent':pct(a['median'],b['median']),
                                'paired_repeat_percent':paired,'source':SOURCES[current],'baseline_source':SOURCES[previous]})
    for version,control in controls.items():
        for shape in ('unary','bidi'):
            for metric in COSTS:
                values=[]
                for server in ('tonic','native'):
                    cell=dict(pair=['tonic','prost',server,'prost'],shape=shape,payload_bytes=1024,tls=False,compression='identity',connections=1,in_flight=1)
                    values.append([control['endpoints'][key(dict(cell,repeat=r)),'server',metric] for r in (0,1)])
                a,b=map(rng,values)
                tonic_rows.append({'version':version,'source':SOURCES[version],'side':'server','shape':shape,'metric':metric,
                                   'tonic':a,'native':b,'change_percent':pct(a['median'],b['median']),
                                   'paired_repeat_percent':[pct(x,y) for x,y in zip(*values)]})
    return source_rows,tonic_rows


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute',action='store_true')
    for name in SOURCES:parser.add_argument('--'+name,type=Path)
    parser.add_argument('--output',type=Path)
    args=parser.parse_args()
    if not args.execute:
        print(json.dumps({'state':'prepared_not_run','qualified':False,'planned_captures':48,'planned_successful_rpcs':1800}));return
    assert all(getattr(args,k) is not None for k in [*SOURCES,'output'])
    output=args.output.absolute();assert output.parent==Q and output.name.startswith('architecture-c12c-') and not output.exists()
    assert observe(PINS)['sha256']==PINS_SHA and observe(CONTROLLER)['sha256']==CONTROLLER_SHA
    pins=read(PINS);assert pins['candidate_runtime']==SOURCES['after'] and pins['baseline_runtime']==SOURCES['baseline']
    controls={name:validate(name,getattr(args,name),pins) for name in SOURCES}
    assert all(c['host']==controls['baseline']['host'] and c['cpu_affinity']==controls['baseline']['cpu_affinity'] for c in controls.values())
    source_rows,tonic_rows=summarize(controls)
    captures=sum(c['captures'] for c in controls.values());calls=sum(c['actual_rpc_totals']['successful_rpcs'] for c in controls.values())
    assert captures==48 and calls==1800
    result={'schema':'pbrs.router-causal-summary.v1','qualified':False,'state':'passed','sources':SOURCES,
            'summary_script':observe(Path(__file__).resolve()),'source_pins':observe(PINS),'controller':observe(CONTROLLER),
            'captures':captures,'successful_rpcs':calls,'captures_per_source':16,
            'controls':{k:{n:v for n,v in c.items() if n not in ('endpoints','cells')} for k,c in controls.items()},
            'source_rows':source_rows,'same_side_tonic_rows':tonic_rows,
            'every_higher_source_cost_group':[r for r in source_rows if r['change_percent'] is not None and r['change_percent']>0],
            'every_higher_tonic_cost_group':[r for r in tonic_rows if r['change_percent'] is not None and r['change_percent']>0],
            'higher_cost_cutoff_percent':0,'canonical_campaign_totals_modified':False,
            'scope':'Separate unchanged-harness N25/N50 Router control, two repeats, unary/bidi 1 KiB identity, one connection/in-flight, tonic client with native and tonic Prost servers; allocation requests, not allocator-site samples or shipping CPU/time/RSS.',
            'limits':['Three independent source control runs; this controller is not an interleaved ABBA cross-source schedule.',
                      'Same pinned harness/handlers/default queue and send settings; combined Beb->after changes do not isolate Router, while 40f->7c runtime diff is Router only.',
                      'Actual requests/counters establish this selected scope only; no broad superiority, production, latency/throughput or global memory claim.',
                      'Native server is the measured change; tonic client/server controls retain noise and repeat directions.'],
            'validated_inputs':list(OBSERVED.values())}
    for item in list(OBSERVED.values()):assert observe(Path(item['path']))==item
    with output.open('x') as stream:json.dump(result,stream,indent=2,allow_nan=False);stream.write('\n')
    print(json.dumps({'state':'passed','qualified':False,'captures':48,'successful_rpcs':1800,
                     'higher_source_groups':len(result['every_higher_source_cost_group']),'higher_tonic_groups':len(result['every_higher_tonic_cost_group']),
                     'output':observe(output)}))


if __name__=='__main__':main()
