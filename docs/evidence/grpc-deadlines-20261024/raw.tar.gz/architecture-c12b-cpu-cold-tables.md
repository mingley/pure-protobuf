# C12b instruction and fresh-process results

Current `40f219fa`; before `beb4ecd9`. **1,448 captures /44,904 successful RPCs** across all three terminal campaigns.

| Campaign | Captures | Successful RPCs, both sources |
|---|---:|---:|
| native | 1,088 | 40,800 |
| cpu | 264 | 3,960 |
| cold-native | 96 | 144 |

**Superseded before promotion.** C12b ASAN and full workspace were not run; neither is a failure. The server identity byte/instruction regression is being repaired in a separate candidate. These results remain attached to40f.

## Instrumented instructions

All **20 measured equal-Prost gzip native endpoint groups use 3.18–16.53% fewer instructions than fresh same-side tonic**; both paired repeats win in every group.
Plaintext, one connection/one in flight, all five shapes at1/64KiB,10/20RPCbatches,two paired repeats. This is the measured subset, not a shipping CPU/latency/throughput result.

Million instructions/RPC. Reference is tonic/prost.

| Side | Workload | tonic/prost | Current | Difference | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1KiB, gzip | 2.23728 | 2.02170 | -9.64% | {'win': 2} |
| client | server_stream, 1KiB, gzip | 1.23714 | 1.03261 | -16.53% | {'win': 2} |
| server | unary, 64KiB, gzip | 3.00834 | 2.91253 | -3.18% | {'win': 2} |

Million instructions/RPC. Reference is the old Beb source. All source instruction increases remain visible, including the CPU-band tie.

| Side | Workload | Before | Current | Change | Repeats |
|---|---|---:|---:|---:|---|
| client | client_stream, 1KiB, gzip | 2.38477 | 2.02170 | -15.22% | {'improvement': 2} |
| client | unary, 1KiB, identity | 0.02763 | 0.02807 | +1.60% | {'tie': 2} |
| server | unary, 1KiB, identity | 0.03722 | 0.03975 | +6.80% | {'regression': 2} |

## Remaining instruction losses versus tonic

| Side | Pair | Workload | Current M/RPC | tonic M/RPC | Difference |
|---|---|---|---:|---:|---:|

Pbrs interop has additional handler work and API differences; it is not an isolated codec/transport comparison. The JSON retains all original repeat ranges, tiny increases and byte/allocation losses as well.

## Fresh process plus one RPC

**Includes setup.** No startup subtraction, isolated cold-RPC cost, hardware-cold-cache or shipping-timing claim. Four repeats; the two-RPC control remains in raw records.

Requested process bytes, KiB. These totals are cumulative allocation requests since main, not RSS.

| Side | Workload | Before | Current | Change | Current min–max |
|---|---|---:|---:|---:|---:|
| client | unary, 0B, gzip | 471.10 | 439.11 | -6.79% | 439.11–439.11 |
| server | unary, 0B, gzip | 468.42 | 444.15 | -5.18% | 444.13–444.42 |
| client | unary, 1KiB, identity | 87.98 | 87.97 | -0.02% | 87.95–87.98 |
| server | unary, 1KiB, identity | 84.64 | 92.37 | +9.13% | 92.34–92.37 |

All **7 CPU-capture source cost increases**, **0 CPU-capture tonic cost increases** and **2 fresh-process cost increases** remain in the JSON without a cutoff. Counts are cell/side/metric groups; they are not additional captures or test passes.
Cold raw ranges retain all four values and both1/2RPCprocess totals; standard N2−N1 summaries are separate diagnostics.

Callgrind uses release binaries with allocation counting enabled. Instructions are not shipping CPU or latency/throughput.
Both endpoints are separate scopes. Full pbrs interop includes extra handler work; preserve its losses separately from equal-Prost.
All group rows retain original paired ratios/dispositions or all four raw process values. No cutoff hides a positive median cost change.
A 2% CPU classification band is a reporting convention; a 1.60% increase classified tie is still retained.
All three campaigns belong only to40f. Their results do not qualify a future C12c candidate.
Combined source changes do not isolate each mechanism; current source concerns and future repairs are not measurements.
