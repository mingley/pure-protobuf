#!/usr/bin/env python3
"""Explicit, source-pinned C12b checks and diagnostics. Preparation does no work.

Each mutating mode needs --execute. A mode has one exclusive state file; failures
are retained rather than overwritten. There is deliberately no unattended 'all'
mode: root schedules compilers, captures and reclamation separately.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil
import subprocess
import sys
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c12b'
BASELINE_TREE = ROOT / 'work/architecture-c11'
BASELINE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
BASELINE_BUILD = Q / 'architecture-c11-stable-rpc-build'
BUILD = Q / 'architecture-c12b-rpc-build'
PINS = Q / 'architecture-c12b-source-pins.json'
SCRIPT = Path(__file__).resolve()
DRIVER = Q / 'architecture-c11-counter-ab-driver.py'
SUMMARY = Q / 'architecture-c11-ab-summary.py'
COLD_SUMMARY = Q / 'architecture-c12b-cold-summary.py'
RUN = ROOT / 'work/run-rust'
RECORD = ROOT / 'work/record.py'
EMPTY = hashlib.sha256(b'').hexdigest()
HARNESS = ['scripts/grpc-load-smoke.py', 'scripts/dominance-ledger.py',
           'scripts/build-rpc-bench.py', 'scripts/grpc-counter-campaign.py',
           'scripts/grpc-resource-campaign.py',
           'rpc-bench/src/main.rs', 'rpc-bench/Cargo.toml', 'rpc-bench/Cargo.lock',
           'Cargo.lock']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def exclusive(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')


def atomic(path, value):
    temporary = path.with_name(path.name + '.next.' + str(os.getpid()))
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()


def source(cwd=TREE):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd)}


def immutable_inputs():
    return [SCRIPT, DRIVER, SUMMARY, RUN, RECORD,
            Q / 'architecture-c12b-cpu-cells.json', Q / 'architecture-c12b-native-cells.json',
            Q / 'architecture-c12b-cold-native-cells.json', COLD_SUMMARY]


def freeze(args):
    assert re.fullmatch(r'[0-9a-f]{40}', args.candidate or ''), 'full candidate hash required'
    assert source(ROOT) == {'head': args.candidate, 'status': ''}, 'commit source before freezing'
    assert source(BASELINE_TREE) == {'head': BASELINE, 'status': ''}
    assert not TREE.exists() and not PINS.exists(), 'never replace a frozen attempt'
    assert args.asan_target, 'record the new independent deadline target(s) at freeze'
    assert len(set(args.asan_target)) == len(args.asan_target)
    for target in args.asan_target:
        assert re.fullmatch(r'[a-zA-Z0-9_]+', target), target
        assert (ROOT / 'pbrs-grpc/tests' / (target + '.rs')).is_file(), target
    subprocess.run(['git', 'merge-base', '--is-ancestor', BASELINE, args.candidate], cwd=ROOT, check=True)
    subprocess.run(['git', 'worktree', 'add', '--detach', '--no-checkout', str(TREE), args.candidate], cwd=ROOT, check=True)
    subprocess.run(['git', 'sparse-checkout', 'set', '--no-cone', '--stdin'], cwd=TREE,
                   input='/*\n!/docs/evidence/\n', text=True, check=True)
    subprocess.run(['git', 'checkout', '--detach', args.candidate], cwd=TREE, check=True)
    assert source() == {'head': args.candidate, 'status': ''}
    identical = {}
    for name in HARNESS:
        assert (TREE / name).read_bytes() == (BASELINE_TREE / name).read_bytes(), name
        identical[name] = digest(TREE / name)
    baseline_build = json.loads((BASELINE_BUILD / 'build.json').read_text())
    assert baseline_build['source']['commit'] == BASELINE
    assert baseline_build['binary_sha256'] == digest(BASELINE_BUILD / 'rpc-bench')
    assert all('1.99.1' in v for v in baseline_build['tools'].values()), baseline_build['tools']
    pins = {'schema': 'pbrs.c12b-source-pins.v1', 'created_utc': now(), 'qualified': False,
            'candidate_runtime': args.candidate, 'baseline_runtime': BASELINE,
            'candidate_tree': git('rev-parse', 'HEAD^{tree}'),
            'baseline_build': ref(BASELINE_BUILD / 'build.json'),
            'baseline_binary': ref(BASELINE_BUILD / 'rpc-bench'),
            'tools_required': baseline_build['tools'], 'identical_harness': identical,
            'inputs': [ref(p) for p in immutable_inputs()],
            'changed_files': git('diff', '--name-only', BASELINE, args.candidate).splitlines(),
            'asan_extra_targets': args.asan_target,
            'historical_controller_annotation': 'The unchanged C11 driver contains a stale C8/C11 explanatory limits sentence. Explicit CLI commits, build records, unchanged harness attestations and this record identify the actual C11/C12b comparison.',
            'limits': ['Diagnostic allocation counters and Callgrind are not shipping CPU, latency or throughput qualification.',
                       'Synthetic zero-filled application payloads; incompressible inputs need separate correctness coverage.',
                       'All source changes are combined; these captures do not isolate individual-change causation.',
                       'Running C11 soaks belong to their own source; they do not qualify C12b.']}
    exclusive(PINS, pins)
    print(json.dumps({'state': 'frozen', 'pins': ref(PINS), 'source': source()}))


def load_pins():
    pins = json.loads(PINS.read_text())
    assert pins['baseline_runtime'] == BASELINE and pins['qualified'] is False
    assert source() == {'head': pins['candidate_runtime'], 'status': ''}
    assert source(BASELINE_TREE) == {'head': BASELINE, 'status': ''}
    for item in pins['inputs'] + [pins['baseline_build'], pins['baseline_binary']]:
        assert ref(Path(item['path'])) == item, item
    for name, sha in pins['identical_harness'].items():
        assert digest(TREE / name) == digest(BASELINE_TREE / name) == sha, name
    return pins


def summaries(path):
    return [{'status': state, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
            for state, passed, failed, ignored in re.findall(
                r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', path.read_text())]


def environment(cache=None, jobs=1, **extra):
    env = os.environ.copy()
    for key in ['RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'ASAN_OPTIONS', 'RUSTDOCFLAGS']:
        env.pop(key, None)
    env.update(RUSTUP_TOOLCHAIN='stable', CARGO_BUILD_JOBS=str(jobs),
               CARGO_TARGET_DIR=str(cache or ROOT / 'work/stable-target'),
               PBRS_CODEGEN_TIME=str(Q / 'architecture-c6-time-dependency/root/usr/bin/time'))
    env.update(extra)
    return env


def run_record(state, statepath, name, command, timeout, env, require_tests=False):
    pin_before = ref(PINS)
    pins = load_pins()
    prefix = Q / ('architecture-c12b-' + name)
    assert not any(prefix.with_suffix(suffix).exists() for suffix in ['.json', '.stdout', '.stderr'])
    state['active'] = name
    atomic(statepath, state)
    argv = [sys.executable, str(RECORD), str(prefix), str(timeout), *command]
    child = subprocess.run(argv, cwd=TREE, env=env)
    record = json.loads(prefix.with_suffix('.json').read_text())
    parsed = summaries(prefix.with_suffix('.stdout'))
    entry = {'name': name, 'command': command, 'exit_code': record['exit_code'],
             'duration_seconds': record['duration_seconds'], 'summaries': parsed,
             'targets': len(parsed), 'totals': {key: sum(row[key] for row in parsed) for key in ['passed', 'failed', 'ignored']},
             'source_after': source(), 'files': [ref(prefix.with_suffix(suffix)) for suffix in ['.json', '.stdout', '.stderr']],
             'free_bytes_after': shutil.disk_usage(ROOT).free}
    state['checks'].append(entry)
    atomic(statepath, state)
    assert child.returncode == record['exit_code'] == 0 and not record.get('timeout'), entry
    assert record['source'] == {'head': pins['candidate_runtime'], 'diff_sha256': EMPTY, 'untracked': {}}
    assert ref(PINS) == pin_before
    load_pins()
    assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed), entry
    if require_tests:
        assert parsed and entry['totals']['passed'] > 0, entry
    return entry


def begin(mode):
    pins = load_pins()
    path = Q / ('architecture-c12b-' + mode + '-state.json')
    state = {'mode': mode, 'state': 'running', 'qualified': False, 'started_utc': now(),
             'supervisor_pid': os.getpid(), 'source': source(), 'pins': ref(PINS),
             'checks': [], 'free_bytes_before': shutil.disk_usage(ROOT).free}
    exclusive(path, state)
    return pins, state, path


def users(cache):
    active, inaccessible = [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            if re.search(r'^State:\s+Z\b', (proc / 'status').read_text(), re.MULTILINE):
                continue
            if str(cache) in (proc / 'maps').read_text() or os.fsencode(cache) in (proc / 'cmdline').read_bytes():
                active.append({'pid': int(proc.name), 'reason': 'cache mapping or command reference'})
            for fd in (proc / 'fd').iterdir():
                try:
                    name = os.readlink(fd)
                    if name == str(cache) or name.startswith(str(cache) + '/'):
                        active.append({'pid': int(proc.name), 'reason': 'cache descriptor', 'fd': fd.name})
                except (FileNotFoundError, ProcessLookupError):
                    pass
        except (FileNotFoundError, ProcessLookupError):
            pass
        except PermissionError:
            inaccessible.append(int(proc.name))
    assert not active and not inaccessible, {'active': active, 'inaccessible': inaccessible}
    return {'active_cache_users': active, 'inaccessible_same_uid_processes': inaccessible}


def reclaim(cache, name, preserved):
    assert cache.parent == ROOT / 'work' and not cache.is_symlink() and cache.is_dir(), cache
    assert cache.name in ['rpc-target', 'asan-c12b-target']
    inputs_before = [ref(p) for p in preserved]
    source_before, pins_before = source(), ref(PINS)
    initial_users = users(cache)
    inventory = []
    for p in sorted(cache.rglob('*')):
        if p.is_symlink():
            inventory.append({'path': str(p.relative_to(cache)), 'symlink': os.readlink(p)})
        elif p.is_file():
            inventory.append({'path': str(p.relative_to(cache)), 'bytes': p.stat().st_size, 'sha256': digest(p)})
    proof = Q / ('architecture-c12b-' + name + '-cache-inventory.json')
    exclusive(proof, {'cache': str(cache), 'source': source_before, 'files': inventory, 'preserved': inputs_before,
                      'users_before': initial_users, 'users_after_inventory': users(cache), 'qualified': False})
    assert [ref(p) for p in preserved] == inputs_before and source() == source_before and ref(PINS) == pins_before
    shutil.rmtree(cache)
    assert not cache.exists()
    assert [ref(p) for p in preserved] == inputs_before and source() == source_before and ref(PINS) == pins_before
    return {'inventory': ref(proof), 'cache_reclaimed': True, 'free_bytes': shutil.disk_usage(ROOT).free}


def command_for(pins, phase, cold=False):
    cpu = phase == 'callgrind'
    assert not cold or not cpu
    campaign = 'cold-native-ab' if cold else 'cpu-ab' if cpu else 'counter-ab'
    cells = 'cold-native' if cold else 'cpu' if cpu else 'native'
    return [sys.executable, str(DRIVER), '--baseline-checkout', str(BASELINE_TREE),
            '--baseline-binary', str(BASELINE_BUILD / 'rpc-bench'), '--baseline-build-record', str(BASELINE_BUILD / 'build.json'),
            '--candidate-checkout', str(TREE), '--candidate-binary', str(BUILD / 'rpc-bench'),
            '--candidate-build-record', str(BUILD / 'build.json'), '--baseline-commit', BASELINE,
            '--candidate-commit', pins['candidate_runtime'], '--output', str(Q / ('architecture-c12b-' + campaign)),
            '--phase', phase, '--scope', 'selected', '--cells-file', str(Q / ('architecture-c12b-' + cells + '-cells.json')),
            '--count', '1' if cold else '10' if cpu else '25', '--repeats', '4' if cold else '2', '--abba', '--seed', '20261024',
            *(['--valgrind', str(ROOT / 'work/toolchain/valgrind/usr/bin/valgrind'), '--valgrind-lib',
               str(ROOT / 'work/toolchain/valgrind/usr/libexec/valgrind')] if cpu else [])]


def execute(mode, args):
    state_mode = mode + ('-' + args.owned_cache if mode == 'cleanup-owned' else '')
    pins, state, statepath = begin(state_mode)
    try:
        if mode == 'prechecks':
            phases = [
                ('format', 120, ['cargo', '+stable', 'fmt', '--all', '--', '--check'], {}, False),
                ('grpc-tests', 1800, ['cargo', '+stable', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', '--', '--test-threads=4'], {}, True),
                ('clippy-root-alltargets', 900, ['cargo', '+stable', 'clippy', '--locked', '--all-targets', '--all-features', '--', '-D', 'warnings'], {}, False),
                ('clippy-grpc-alltargets', 900, ['cargo', '+stable', 'clippy', '--locked', '-p', 'pbrs-grpc', '--all-targets', '--all-features', '--', '-D', 'warnings'], {}, False),
                ('clippy-adapter-example', 900, ['cargo', '+stable', 'clippy', '--locked', '--lib', '--all-features', '-p', 'pbrs-grpc', '-p', 'protobuf-tonic', '-p', 'pbrs-grpc-example-greeter', '--', '-D', 'warnings'], {}, False),
                ('examples', 900, ['cargo', '+stable', 'build', '--locked', '--workspace', '--examples'], {}, False),
                ('rpc-benchmark-correctness', 1200, ['cargo', '+stable', 'test', '--locked', '--manifest-path', 'rpc-bench/Cargo.toml', '--bin', 'rpc-bench', '--test', 'worker', '--test', 'fairness', '--test', 'tonic_fairness', '--', '--test-threads=4'], {}, True),
                ('tonic-benchmark-correctness', 900, ['cargo', '+stable', 'test', '--locked', '--manifest-path', 'tonic-bench/Cargo.toml', '--bin', 'tonic-bench', '--', '--test-threads=4'], {'PURE_PROTOBUF_CHECKED_V4': '1'}, True),
                ('rustdoc', 900, ['cargo', '+stable', 'doc', '--locked', '--workspace', '--all-features', '--no-deps'], {'RUSTDOCFLAGS': '-D warnings'}, False),
                ('msrv', 900, ['cargo', '+1.85.0', 'check', '--locked', '-p', 'pbrs', '-p', 'pbrs-grpc', '--lib'], {}, False),
                ('msrv-zstd', 900, ['cargo', '+1.87.0', 'check', '--locked', '-p', 'pbrs-grpc', '--lib', '--features', 'zstd'], {}, False)]
            for name, limit, phase_args, extra, test in phases:
                run_record(state, statepath, name, [str(RUN), 'nice', '-n', '10', *phase_args], limit, environment(**extra), test)
        elif mode == 'build-benchmark':
            assert json.loads((Q / 'architecture-c12b-prechecks-state.json').read_text())['state'] == 'passed'
            assert not BUILD.exists()
            run_record(state, statepath, 'rpc-build', [str(RUN), sys.executable, 'scripts/build-rpc-bench.py',
                       '--source', pins['candidate_runtime'], '--output', str(BUILD)], 2400,
                       environment(cache=ROOT / 'work/rpc-target'))
            build = json.loads((BUILD / 'build.json').read_text())
            assert build['tools'] == pins['tools_required'] and build['binary_sha256'] == digest(BUILD / 'rpc-bench')
            state['build'] = ref(BUILD / 'build.json')
            state['binary'] = ref(BUILD / 'rpc-bench')
        elif mode == 'resource-preview':
            assert json.loads((Q / 'architecture-c12b-prechecks-state.json').read_text())['state'] == 'passed'
            output = Q / 'architecture-c12b-resource-preview'
            assert not output.exists(), 'never overwrite an actual resource attempt'
            command = [str(RUN), sys.executable, 'scripts/grpc-resource-campaign.py',
                       '--source', pins['candidate_runtime'], '--output', str(output),
                       '--duration', '30', '--build-profile', 'release', '--seed', '20261002',
                       '--memory-bytes', '1073741824', '--max-fds', '128', '--max-uid-processes', '4096']
            run_record(state, statepath, 'resource-preview-run', command, 2400,
                       environment(cache=ROOT / 'work/rpc-target'))
            report = json.loads((output / 'report.json').read_text())
            validate_report = runpy.run_path(str(TREE / 'scripts/grpc-resource-campaign.py'))['validate_report']
            failures = validate_report(report)
            assert not failures, failures
            assert report['source']['commit'] == pins['candidate_runtime'] and report['source']['dirty'] is False
            assert report['build']['profile'] == 'release' and report['exit_code'] == 0
            assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
            assert report['smoke'] == {'status': 'passed', 'failures': []}
            caps = {key: {'soft': value, 'hard': value} for key, value in {
                'address_space': 1073741824, 'file_descriptors': 128,
                'same_uid_processes': 4096, 'cpu_seconds': 60}.items()}
            assert report['process_limits'] == report['process_limits_requested'] == caps
            assert report['tools']['rustc'].splitlines()[0] == pins['tools_required']['rustc']
            assert report['tools']['cargo'] == pins['tools_required']['cargo']
            executable = Path(report['binary']['path'])
            assert executable.parent == output and digest(executable) == report['binary']['sha256']
            state['report'] = ref(output / 'report.json')
            state['binary'] = ref(executable)
            state['duration_actual_seconds'] = report['duration_actual_seconds']
            state['effective_process_limits'] = caps
            state['smoke'] = report['smoke']
            state['scope'] = 'Actual release preview at the original finite limits; this is not a 24-hour pass or a comparative-speed result.'
        elif mode in ['native', 'cpu', 'cold-native']:
            assert json.loads((Q / 'architecture-c12b-build-benchmark-state.json').read_text())['state'] == 'passed'
            assert json.loads((Q / 'architecture-c12b-resource-preview-state.json').read_text())['state'] == 'passed'
            phase = 'callgrind' if mode == 'cpu' else 'native'
            run_record(state, statepath, mode + '-captures', command_for(pins, phase, cold=mode == 'cold-native'), 5400, environment())
            campaign = Q / ('architecture-c12b-' + ('cold-native-ab' if mode == 'cold-native' else 'cpu-ab' if mode == 'cpu' else 'counter-ab'))
            summary = Q / (campaign.name + '-summary.json')
            run_record(state, statepath, mode + '-summary', [sys.executable, str(SUMMARY), '--campaign', str(campaign), '--output', str(summary)], 300, environment())
            data = json.loads(summary.read_text())
            assert data['passed'] is True and data['qualified'] is False
            state['summary'] = ref(summary)
            if mode == 'cold-native':
                raw_summary = Q / 'architecture-c12b-cold-native-raw-summary.json'
                run_record(state, statepath, 'cold-native-raw-summary-run', [sys.executable, str(COLD_SUMMARY),
                           '--campaign', str(campaign), '--n2n-summary', str(summary), '--output', str(raw_summary)],
                           300, environment())
                raw = json.loads(raw_summary.read_text())
                assert raw['state'] == 'passed' and raw['captures'] == 96 and raw['successful_rpcs'] == 144
                assert raw['isolated_cold_RPC_cost'] is False and raw['setup_subtraction_performed'] is False
                state['raw_process_totals_summary'] = ref(raw_summary)
        elif mode == 'cleanup-rpc':
            for name in ['native', 'cpu']:
                assert json.loads((Q / ('architecture-c12b-' + name + '-state.json')).read_text())['state'] == 'passed'
            keep = [PINS, BUILD / 'rpc-bench', BUILD / 'build.json', Q / 'architecture-c12b-resource-preview/resource-test']
            for path in [BASELINE_BUILD / 'rpc-bench', Q / 'resource-architecture-c8-day/resource-test',
                         Q / 'resource-architecture-c11-day/resource-test', Q / 'architecture-c11-prost-cache-build/fixture-test']:
                if path.exists():
                    keep.append(path)
            state['cleanup'] = reclaim(ROOT / 'work/rpc-target', 'rpc', keep)
        elif mode == 'cleanup-owned':
            label = args.owned_cache
            assert label == 'asan', 'the fresh ASAN cache is the only owned cache'
            prerequisite = Q / 'architecture-c12b-asan-state.json'
            previous = json.loads(prerequisite.read_text())
            assert previous['state'] == 'passed'
            keep = [PINS, prerequisite, *[Path(row['path']) for check in previous['checks'] for row in check['files']]]
            state['cleanup'] = reclaim(ROOT / 'work/asan-c12b-target', label, keep)
        elif mode == 'asan':
            cache = ROOT / 'work/asan-c12b-target'
            assert not cache.exists() and not cache.is_symlink()
            assert shutil.disk_usage(ROOT).free >= 3 * 1024**3, 'free space for a fresh ASAN build required'
            targets = list(dict.fromkeys(['decode_workspace', 'closed_upload_response', 'retry_safety', 'pump_panic', *pins['asan_extra_targets']]))
            selected = ['--lib', *[arg for name in targets for arg in ['--test', name]]]
            env = environment(cache=cache, RUSTFLAGS='-Zsanitizer=address', ASAN_OPTIONS='detect_leaks=1')
            for name, args, filters in [('asan-selected', selected, []), ('asan-inbound-owner', ['--test', 'lifecycle'], ['inbound_owner_'])]:
                run_record(state, statepath, name, [str(RUN), 'nice', '-n', '10', 'cargo', '+nightly-2025-06-26', 'test', '--locked', '-p', 'pbrs-grpc', '--all-features', *args, '--target', 'x86_64-unknown-linux-gnu', '-Zbuild-std', *filters, '--', '--test-threads=4'], 2400, env, True)
            executables = {}
            for check in state['checks']:
                stderr = Path(next(row['path'] for row in check['files'] if row['path'].endswith('.stderr')))
                for found in re.findall(r'^\s*Running .*?\(([^()]+)\)\s*$', stderr.read_text(), re.MULTILINE):
                    path = Path(found)
                    path = (path if path.is_absolute() else TREE / path).resolve()
                    assert path.is_relative_to(cache.resolve())
                    with path.open('rb') as stream:
                        assert stream.read(4) == b'\x7fELF'
                    executables[str(path)] = ref(path)
            assert {Path(path).name.rsplit('-', 1)[0] for path in executables} == {'pbrs_grpc', 'lifecycle', *targets}
            state['executables'] = executables
            state['owned_cache_left_in_place'] = str(cache)
        elif mode == 'workspace':
            assert shutil.disk_usage(ROOT).free >= 8 * 1024**3, 'need 8GiB free before cold consumer/full-workspace tests'
            run_record(state, statepath, 'workspace', [str(RUN), 'nice', '-n', '10', 'cargo', '+stable', 'test', '--locked', '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4'], 7200, environment(jobs=2), True)
        else:
            raise AssertionError(mode)
        load_pins()
        state.update(state='passed', active=None, completed_utc=now(), source_after=source(), free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(statepath, state)
    except BaseException as error:
        state.update(state='failed', error=repr(error), completed_utc=now(), source_after=source(), free_bytes_after=shutil.disk_usage(ROOT).free)
        atomic(statepath, state)
        traceback.print_exc()
        return 1
    return 0


def main():
    assert __debug__, 'do not run with Python -O'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('mode', choices=['plan', 'freeze', 'prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native', 'cleanup-rpc', 'cleanup-owned', 'asan', 'workspace'])
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--candidate')
    parser.add_argument('--asan-target', action='append', default=[])
    parser.add_argument('--owned-cache', choices=['asan'])
    args = parser.parse_args()
    if not args.execute or args.mode == 'plan':
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True,
                          'mode': args.mode, 'candidate': args.candidate,
                          'cpu': {'scopes': 33, 'captures': 264, 'planned_rpcs': 3960},
                          'native': {'scopes': 136, 'captures': 1088, 'planned_rpcs': 40800},
                          'optional_cold_native': {'scopes': 6, 'captures': 96, 'planned_rpcs': 144, 'raw_N1_totals_include_setup': True},
                          'qualified': False}, indent=2))
        return 0
    if args.mode == 'freeze':
        freeze(args)
        return 0
    assert args.mode != 'cleanup-owned' or args.owned_cache is not None, '--owned-cache required'
    return execute(args.mode, args)


if __name__ == '__main__':
    raise SystemExit(main())
