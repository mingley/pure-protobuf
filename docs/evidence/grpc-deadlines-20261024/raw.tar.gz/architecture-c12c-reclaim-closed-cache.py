#!/usr/bin/env python3
"""Inventory and unlink an allowlisted generated cache after its owners finish."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import shutil

if not __debug__:
    raise RuntimeError('Run without Python optimization; assertion gates are required.')

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
C = runpy.run_path(str(Q / 'architecture-c12c-qualification.py'))
PINS = Q / 'architecture-c12c-source-pins.json'
CACHES = {'caller-rustls': ROOT / 'work/stable-target/caller-rustls',
          'asan': ROOT / 'work/asan-c12c-target',
          'rpc': ROOT / 'work/rpc-target'}
REQUIRED = {'caller-rustls': ['prechecks'], 'asan': ['asan'],
            'rpc': ['native', 'cpu', 'cold-native']}


def digest(path):
    return C['digest'](path)


def scan(cache, names):
    active, unavailable = [], []
    for proc in Path('/proc').iterdir():
        if not proc.name.isdecimal() or int(proc.name) == os.getpid():
            continue
        try:
            if proc.stat().st_uid != os.getuid():
                continue
            argv = (proc / 'cmdline').read_bytes().split(b'\0')
            if not argv or not argv[0]:
                continue
            program = Path(os.fsdecode(argv[0])).name
            if (program in ['cargo', 'rustc', 'rustdoc', 'clippy-driver'] or program in names
                    or any(os.fsencode(cache) in arg for arg in argv)):
                active.append({'pid': int(proc.name), 'argv': [os.fsdecode(x) for x in argv if x]})
        except (FileNotFoundError, ProcessLookupError):
            continue
        except PermissionError:
            unavailable.append(int(proc.name))
    assert not active and not unavailable, {'active': active, 'unavailable_cmdline': unavailable}
    return {'active_build_or_cache_programs': [], 'unavailable_same_uid_cmdlines': [],
            'scope': 'Readable same-UID command lines and cache executable basenames. Protected maps/exe/cwd/fd selectors are not inspected. This is not global mapping/descriptor quiescence.'}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--cache', choices=sorted(CACHES), required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    pins = C['load_pins']()
    cache = CACHES[args.cache]
    assert cache.is_dir() and not cache.is_symlink() and cache.resolve() == cache
    states, protected = {}, [PINS]
    for name in REQUIRED[args.cache]:
        p = Q / ('architecture-c12c-' + name + '-state.json')
        state = json.loads(p.read_text())
        assert state['state'] == 'passed' and state['source'] == C['source']()
        assert state['pins'] == C['ref'](PINS)
        states[name] = state
        protected.append(p)
        for check in state['checks']:
            assert check['exit_code'] == 0
            for item in check['files']:
                p = Path(item['path'])
                assert C['ref'](p) == item
                protected.append(p)
    for p in [Q / 'architecture-c11-stable-rpc-build/rpc-bench',
              Q / 'architecture-c12c-rpc-build/rpc-bench',
              Q / 'architecture-c12c-resource-preview/resource-test',
              Q / 'resource-architecture-c8-day/resource-test',
              Q / 'resource-architecture-c11-day/resource-test',
              Q / 'architecture-c11-prost-cache-build/fixture-test']:
        if p.is_file():
            protected.append(p)
    protected = sorted(set(protected))
    assert all(not p.is_relative_to(cache) for p in protected)
    preserved = [C['ref'](p) for p in protected]
    all_files = sorted(cache.rglob('*'))
    program_names = {p.name for p in all_files if p.is_file() and not p.is_symlink()
                     and not p.suffix and os.access(p, os.X_OK)}
    before_scan = scan(cache, program_names)
    inventory = []
    for p in all_files:
        if p.is_symlink():
            inventory.append({'path': str(p.relative_to(cache)), 'symlink': os.readlink(p)})
        elif p.is_file():
            st = p.stat()
            inventory.append({'path': str(p.relative_to(cache)), 'bytes': st.st_size,
                              'device': st.st_dev, 'inode': st.st_ino,
                              'mtime_ns': st.st_mtime_ns, 'sha256': digest(p)})
    if args.cache == 'asan':
        by_path = {str(cache / item['path']): item for item in inventory if 'sha256' in item}
        for exe, expected in states['asan']['executables'].items():
            actual = by_path[exe]
            assert actual['sha256'] == expected['sha256'] and actual['bytes'] == expected['bytes']
    plan = {'qualified': False, 'cache': str(cache), 'source': C['source'](),
            'pins': C['ref'](PINS), 'preserved': preserved, 'files': inventory,
            'command_scan': before_scan, 'free_bytes_before': shutil.disk_usage(ROOT).free,
            'limits': 'Generated cache only; unlink directory entries without truncating file contents. Existing Linux open/mapped images survive unlink. No source/evidence/copied soak ELF removal, no protected-procfs bypass, no global quiescence claim. Root coordinates absence of compiler/cache writers.'}
    if not args.execute:
        print(json.dumps({'state': 'plan', 'cache': str(cache), 'entries': len(inventory),
                          'logical_bytes': sum(x.get('bytes', 0) for x in inventory)}))
        return
    prefix = Q / ('architecture-c12c-closed-' + args.cache + '-cache')
    ipath = prefix.with_name(prefix.name + '-inventory.json')
    rpath = prefix.with_name(prefix.name + '-reclaim.json')
    assert not ipath.exists() and not rpath.exists()
    scan(cache, program_names)
    assert [C['ref'](p) for p in protected] == preserved
    C['load_pins']()
    for item in inventory:
        p = cache / item['path']
        if 'symlink' in item:
            assert p.is_symlink() and os.readlink(p) == item['symlink']
        else:
            st = p.stat()
            assert (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns) == (item['device'], item['inode'], item['bytes'], item['mtime_ns'])
    with ipath.open('x') as out:
        json.dump(plan, out, indent=2); out.write('\n')
    shutil.rmtree(cache)
    assert not cache.exists()
    assert [C['ref'](p) for p in protected] == preserved
    C['load_pins']()
    result = {'state': 'completed', 'qualified': False, 'cache': str(cache),
              'inventory': C['ref'](ipath), 'free_bytes_after': shutil.disk_usage(ROOT).free,
              'source_after': C['source'](), 'preserved': preserved,
              'command_scan_after': scan(cache, program_names), 'limits': plan['limits']}
    with rpath.open('x') as out:
        json.dump(result, out, indent=2); out.write('\n')
    print(json.dumps({'state': result['state'], 'cache': str(cache),
                      'entries': len(inventory), 'free_bytes_after': result['free_bytes_after'],
                      'report': str(rpath)}))


if __name__ == '__main__':
    main()
