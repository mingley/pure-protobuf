#!/usr/bin/env python3
"""Archive one terminal C12 diagnostic and publish it through normal main pushes.

Preparation does not run a diagnostic or contact Git. The explicit execute mode
only publishes a completed supervisor attempt, including failed/incomplete ones.
"""
from pathlib import Path, PurePosixPath
import argparse
import datetime
import fcntl
import gzip
import hashlib
import io
import json
import math
import os
import re
import runpy
import shutil
import subprocess
import sys
import tarfile
import tomllib
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c12'
PINS = Q / 'architecture-c12-source-pins.json'
EMPTY = hashlib.sha256(b'').hexdigest()
DIAGNOSTIC = 'repeated independent-peer server deadline fixture'
OVERLAY = 'pbrs-grpc/tests/deadline_sustained.rs'
BASE_LIMITS = {'address_space': 1073741824, 'file_descriptors': 128,
               'same_uid_processes': 4096}
GATES = ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'asan', 'workspace']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def safe(value):
    if type(value) is float and not math.isfinite(value):
        return None
    if isinstance(value, dict):
        return {key: safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [safe(item) for item in value]
    return value


def encoded(value):
    return (json.dumps(safe(value), indent=2, allow_nan=False) + '\n').encode()


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.next.' + str(os.getpid()))
    with temporary.open('xb') as stream:
        stream.write(encoded(value))
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def git(*arguments, cwd=ROOT, check=True):
    return subprocess.run(['git', *arguments], cwd=cwd, text=True,
                          capture_output=True, check=check)


def finite(value):
    return type(value) in (int, float) and math.isfinite(value) and value >= 0


def safe_name(name):
    value = PurePosixPath(name)
    return (bool(name) and not value.is_absolute() and str(value) == name
            and not any(part in ('.', '..') for part in value.parts)
            and chr(92) not in name and ':' not in name)


class Context:
    def __init__(self, kind, pins_sha256):
        if kind not in ('resource', 'deadline') or not re.fullmatch(r'[0-9a-f]{64}', pins_sha256):
            raise ValueError('a diagnostic kind and explicit immutable pins SHA256 are required')
        self.kind, self.pins_sha256 = kind, pins_sha256
        self.output = Q / ('resource-architecture-c12-day' if kind == 'resource'
                           else 'resource-architecture-c12-deadline-day')
        self.preview = Q / ('architecture-c12-resource-preview' if kind == 'resource'
                            else 'resource-architecture-c12-deadline-preview')
        self.report_path = self.output / ('campaign/report.json' if kind == 'resource' else 'report.json')
        self.state = self.output / 'publication.json'
        self.snapshot = self.output / 'publication-snapshot'
        self.artifacts = self.output / 'publication-artifacts'
        self.worktree = ROOT / ('work/architecture-c12-' + kind + '-publication')
        self.evidence = Path('docs/evidence/grpc-' + kind + '-soak-20261024')
        self.marker = '<!-- architecture-c12-' + kind + '-day-terminal -->'
        self.pin_error = None
        pin_path = PINS
        if not pin_path.is_file() or pin_path.is_symlink() or digest(pin_path) != pins_sha256:
            self.pin_error = 'Original pins file differs from the launch-pinned copy.'
            pin_path = self.output / 'harness' / PINS.name
        if not pin_path.is_file() or pin_path.is_symlink() or digest(pin_path) != pins_sha256:
            raise ValueError('no intact launch-pinned C12 source pins are available')
        self.pin_path = pin_path
        self.pins = json.loads(pin_path.read_text())
        self.source = self.pins.get('candidate_runtime')
        if (self.pins.get('schema') != 'pbrs.c12-source-pins.v1'
                or self.pins.get('qualified') is not False
                or not re.fullmatch(r'[0-9a-f]{40}', self.source or '')):
            raise ValueError('source pins do not identify one unqualified C12 candidate')

    @property
    def clean(self):
        return {'head': self.source, 'status': ''}

    @property
    def overlay_source(self):
        return {'head': self.source, 'tracked_diff_sha256': EMPTY,
                'untracked_overlay': [OVERLAY]}


def verify_ref(reference, ctx):
    """Return a retained file, or an explicit external-compiler omission."""
    path = Path(reference['path'])
    if not path.is_absolute() or path.is_symlink():
        raise ValueError('invalid artifact reference: ' + str(path))
    location = path.resolve()
    ordinary = location.is_relative_to(Q.resolve())
    helper = location in {ROOT / 'work/run-rust', ROOT / 'work/record.py'}
    tracked = False
    if location.is_relative_to(TREE.resolve()):
        relative = location.relative_to(TREE.resolve()).as_posix()
        tracked = (safe_name(relative) and git('cat-file', '-e', ctx.source + ':' + relative,
                                             check=False).returncode == 0)
    if not (ordinary or helper or tracked):
        # Sanitizer/cache executables are intentionally reclaimable after their
        # recorded successful checks. Preserve their attested identity, without
        # claiming to verify bytes that no longer exist.
        cache = ROOT / 'work/asan-c12-target'
        if location.is_relative_to(cache):
            return None, {'reference': reference, 'reason': 'Recorded compiler-cache executable; bytes are not a publication input.'}
        raise ValueError('reference is outside retained artifacts and tracked source: ' + str(path))
    if not path.is_file() or digest(path) != reference['sha256']:
        raise ValueError('artifact checksum differs: ' + str(path))
    if 'bytes' in reference and path.stat().st_size != reference['bytes']:
        raise ValueError('artifact size differs: ' + str(path))
    return path, None


def references(value, ctx, found=None, omissions=None, seen=None):
    found = set() if found is None else found
    omissions = [] if omissions is None else omissions
    seen = set() if seen is None else seen
    if isinstance(value, dict):
        if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str) and Path(value['path']).is_absolute():
            name = value['path']
            if name not in seen:
                seen.add(name)
                path, omitted = verify_ref(value, ctx)
                if omitted:
                    omissions.append(omitted)
                elif path is not None:
                    found.add(path)
                    if path.suffix == '.json':
                        references(json.loads(path.read_text()), ctx, found, omissions, seen)
        for item in value.values():
            references(item, ctx, found, omissions, seen)
    elif isinstance(value, list):
        for item in value:
            references(item, ctx, found, omissions, seen)
    return found, omissions


def source_now(ctx):
    return {'head': git('rev-parse', 'HEAD', cwd=TREE).stdout.strip(),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=TREE).stdout.strip()}


def validate_gates(ctx):
    paths = []
    names = list(GATES)
    if (Q / 'architecture-c12-cold-native-state.json').exists():
        names.append('cold-native')
    for name in names:
        path = Q / ('architecture-c12-' + name + '-state.json')
        state = json.loads(path.read_text())
        if (state.get('state') != 'passed' or state.get('active') is not None
                or state.get('mode') != name or state.get('qualified') is not False
                or state.get('source') != ctx.clean or state.get('source_after') != ctx.clean
                or state.get('pins', {}).get('sha256') != ctx.pins_sha256
                or not state.get('checks')):
            raise ValueError('qualification gate is not a passing clean C12 result: ' + name)
        for check in state['checks']:
            if check.get('exit_code') != 0 or check.get('source_after') != ctx.clean or check.get('totals', {}).get('failed') != 0:
                raise ValueError('qualification command failed or changed source: ' + name)
            for item in check['files']:
                verify_ref(item, ctx)
            record = json.loads(Path(next(item['path'] for item in check['files'] if item['path'].endswith('.json'))).read_text())
            if (record.get('exit_code') != 0 or record.get('timeout')
                    or record.get('source') != {'head': ctx.source, 'diff_sha256': EMPTY, 'untracked': {}}):
                raise ValueError('gate command record has a failed execution or different source: ' + name)
        paths.append(path)
    return paths


def read_object(path):
    if not path.is_file():
        return None, 'No terminal report was produced.'
    try:
        value = json.loads(path.read_text())
        if not isinstance(value, dict):
            raise ValueError('record is not an object')
        return value, None
    except (ValueError, UnicodeError) as error:
        return None, str(error)


def deadline_progress(progress, seconds, pid=None, terminal=True):
    errors = []
    if not isinstance(progress, dict):
        return ['Missing final progress object.']
    if terminal and (progress.get('state') != 'completed' or progress.get('event') != 'duration_completed'):
        errors.append('Final progress does not record completion.')
    if (progress.get('requested_seconds') != seconds or not finite(progress.get('elapsed_seconds'))
            or terminal and progress['elapsed_seconds'] < seconds):
        errors.append('Final progress does not cover the requested wall duration.')
    if type(progress.get('completed_cycles')) is not int or progress['completed_cycles'] < 1:
        errors.append('No completed fixture cycle is recorded.')
    if (type(progress.get('fixture_cases_per_cycle')) is not int
            or progress['fixture_cases_per_cycle'] < 18
            or progress.get('controlled_tokio_time') is not True):
        errors.append('The repeated fixture set or controlled-clock attestation is missing.')
    if pid is not None and progress.get('pid') != pid:
        errors.append('Final progress child PID differs from the terminal report.')
    for key in ('retained_capacity', 'retained_buffers'):
        if type(progress.get(key)) is not int or progress[key] != 0:
            errors.append('Retained cache did not return to zero: ' + key)
    if (type(progress.get('acquired')) is not int or type(progress.get('released')) is not int
            or not 0 <= progress['acquired'] == progress['released']):
        errors.append('Lease acquisitions and releases disagree.')
    if (type(progress.get('fd_count')) is not int or type(progress.get('baseline_fd_count')) is not int
            or not 0 < progress['fd_count'] <= progress['baseline_fd_count'] < 128):
        errors.append('Descriptors did not return to the initial finite baseline.')
    if (type(progress.get('alive_tasks')) is not int or type(progress.get('baseline_alive_tasks')) is not int
            or not 0 <= progress['alive_tasks'] <= progress['baseline_alive_tasks']):
        errors.append('Tasks did not return to the initial baseline.')
    if type(progress.get('rss_bytes')) is not int or not 0 < progress['rss_bytes'] < BASE_LIMITS['address_space']:
        errors.append('Final resident memory is missing or outside the process cap.')
    if type(progress.get('peak_retained_capacity')) is not int or not 0 <= progress['peak_retained_capacity'] <= 16 * 1024 * 1024:
        errors.append('Idle retained capacity exceeds its fixed limit.')
    return errors


def deadline_outcome(report, ctx, seconds=86400, read_error=None):
    if report is None:
        return {'state': 'incomplete', 'report_available': False, 'qualified': False,
                'duration_actual_seconds': None, 'completed_cycles': None, 'exit_code': None,
                'validation_errors': [], 'failures': [read_error or 'No terminal diagnostic report was produced.']}
    errors = []
    declared = report.get('state')
    if declared not in ('passed', 'failed', 'incomplete'):
        errors.append('Report has no terminal disposition.')
    if (report.get('source_pin') != ctx.source or report.get('qualified') is not False
            or report.get('diagnostic') != DIAGNOSTIC or report.get('requested_seconds') != seconds):
        errors.append('Report source, duration, diagnostic or qualification disposition differs.')
    if (report.get('source_before') != ctx.overlay_source or report.get('source_after') != ctx.overlay_source
            or report.get('runtime_source_equivalent') is not True
            or report.get('source_pin_verified_at_end') is not True):
        errors.append('The unchanged runtime/test-only overlay was not verified at both ends.')
    duration = report.get('duration_actual_seconds')
    duration = duration if finite(duration) else None
    cycles = report.get('completed_cycles')
    cycles = cycles if type(cycles) is int and cycles >= 0 else None
    limits = BASE_LIMITS | {'cpu_seconds': seconds + 30}
    if report.get('limits') != limits:
        errors.append('Requested process caps differ from the original limits.')
    if declared == 'passed':
        if (report.get('process_limits_verified') is not True
                or report.get('actual_process_limits') != {key: [value, value] for key, value in limits.items()}):
            errors.append('Effective process limits were not observed as requested.')
        if type(report.get('pid')) is not int or report['pid'] <= 0:
            errors.append('Successful diagnostic has no valid child PID.')
        if duration is None or duration < seconds:
            errors.append('A short diagnostic cannot pass the requested duration.')
        wall = report.get('supervisor_wall_seconds')
        if not finite(wall) or wall < seconds or duration is not None and duration > wall + 1:
            errors.append('Independent supervisor wall duration does not cover the child duration.')
        if report.get('exit_code') != 0 or report.get('supervisor_failure') or report.get('error'):
            errors.append('Successful diagnostic records a child/supervisor failure.')
        progress = report.get('final_progress')
        errors += deadline_progress(progress, seconds, report.get('pid'))
        if not isinstance(progress, dict) or progress.get('completed_cycles') != cycles:
            errors.append('Terminal progress and cycle totals disagree.')
    failures = report.get('failures', [])
    failures = failures if isinstance(failures, list) else [str(failures)]
    if failures and declared == 'passed':
        errors.append('Reported pass retains failures.')
    state = 'failed' if declared == 'failed' else 'passed' if declared == 'passed' and not errors else 'incomplete'
    return {'state': state, 'report_state': declared, 'report_available': True, 'qualified': False,
            'duration_actual_seconds': duration, 'completed_cycles': cycles,
            'exit_code': report.get('exit_code'), 'final_progress': safe(report.get('final_progress')),
            'validation_errors': errors, 'failures': [str(item) for item in failures] + errors}


def validate_deadline_events(report, directory, seconds):
    count, last_elapsed, final = 0, 0.0, None
    cases = None
    with (directory / 'events.jsonl').open() as stream:
        for line in stream:
            event = json.loads(line)
            if not isinstance(event, dict) or final is not None:
                raise ValueError('Unexpected event after diagnostic completion.')
            elapsed = event.get('elapsed_seconds')
            if not finite(elapsed) or elapsed < last_elapsed:
                raise ValueError('Event time is invalid or moves backward.')
            last_elapsed = elapsed
            if event.get('requested_seconds') != seconds or event.get('pid') != report.get('pid'):
                raise ValueError('Event duration/child PID differs from the terminal report.')
            if deadline_progress(event, seconds, report.get('pid'), terminal=False):
                raise ValueError('Cycle resource gauges do not satisfy their fixed bounds.')
            if type(event.get('fixture_cases_per_cycle')) is not int or event['fixture_cases_per_cycle'] < 1:
                raise ValueError('Invalid or missing repeated fixture case count.')
            if cases is None:
                cases = event['fixture_cases_per_cycle']
            elif event['fixture_cases_per_cycle'] != cases:
                raise ValueError('Repeated fixture case count changed during the run.')
            if event.get('event') == 'cycle_completed' and event.get('state') == 'running':
                count += 1
                if event.get('completed_cycles') != count:
                    raise ValueError('Completed fixture cycle sequence has gaps or duplicates.')
            elif event.get('event') == 'duration_completed' and event.get('state') == 'completed':
                if elapsed < seconds or event.get('completed_cycles') != count or count < 1:
                    raise ValueError('Terminal event does not establish the requested duration.')
                final = event
            else:
                raise ValueError('Unknown fixture event/state.')
    if final != report.get('final_progress') or count != report.get('completed_cycles'):
        raise ValueError('Actual events and final report disagree.')
    return {'completed_cycles': count, 'fixture_cases_per_cycle': cases,
            'terminal_event_matches_report': True}


def resource_outcome(report, termination, ctx, seconds=86400, read_error=None):
    if report is None:
        return {'state': 'incomplete', 'report_available': False, 'qualified': False,
                'duration_actual_seconds': None, 'completed_cycles': None,
                'exit_code': termination.get('exit_code'), 'validation_errors': [],
                'failures': [read_error or 'No terminal resource report was produced.']}
    errors = []
    smoke = report.get('smoke') if isinstance(report.get('smoke'), dict) else {}
    qualification = report.get('qualification') if isinstance(report.get('qualification'), dict) else {}
    day = qualification.get('soak_24h') if isinstance(qualification.get('soak_24h'), dict) else {}
    reported = day.get('status')
    declared = 'passed' if smoke.get('status') == 'passed' else 'failed' if smoke.get('status') == 'failed' else 'incomplete'
    source = report.get('source') if isinstance(report.get('source'), dict) else {}
    build = report.get('build') if isinstance(report.get('build'), dict) else {}
    if (source.get('commit') != ctx.source or source.get('dirty') is not False
            or report.get('duration_requested_seconds') != seconds
            or build.get('profile') != 'release'
            or report.get('seed') != 20261002):
        errors.append('Resource source/profile/seed/requested duration differs from the frozen campaign.')
    tools = report.get('tools') if isinstance(report.get('tools'), dict) else {}
    required = ctx.pins.get('tools_required', {})
    if (str(tools.get('rustc', '')).splitlines()[:1] != [required.get('rustc')]
            or tools.get('cargo') != required.get('cargo')):
        errors.append('Resource compiler/Cargo metadata differs from the qualified candidate.')
    limits = {key: {'soft': value, 'hard': value}
              for key, value in (BASE_LIMITS | {'cpu_seconds': seconds + 30}).items()}
    if report.get('process_limits') != limits or report.get('process_limits_requested') != limits:
        errors.append('Observed/requested resource process limits differ from the original caps.')
    duration = report.get('duration_actual_seconds')
    duration = duration if finite(duration) else None
    if declared == 'passed':
        if report.get('exit_code') != 0 or duration is None or duration < seconds:
            errors.append('A reported pass lacks successful complete wall duration.')
        if seconds == 86400 and reported != 'completed':
            errors.append('The original controller did not report a completed day.')
    validator = TREE / 'scripts/grpc-resource-campaign.py'
    expected = ctx.pins.get('identical_harness', {}).get('scripts/grpc-resource-campaign.py')
    if expected is None or not validator.is_file() or digest(validator) != expected:
        errors.append('Resource validator differs from the frozen harness.')
    else:
        try:
            errors += ['Report validation: ' + str(item) for item in runpy.run_path(str(validator))['validate_report'](report)]
        except (ValueError, TypeError, KeyError, AttributeError) as failure:
            errors.append('Original resource validator could not validate the report: ' + str(failure))
    failures = smoke.get('failures', [])
    failures = failures if isinstance(failures, list) else [str(failures)]
    state = 'failed' if declared == 'failed' else 'passed' if declared == 'passed' and not errors else 'incomplete'
    events = report.get('events')
    if not isinstance(events, list):
        events = []
        if state == 'passed':
            state = 'incomplete'
        errors.append('Resource event log is missing or is not a list.')
    cycles = max((item.get('cycle', 0) for item in events if isinstance(item, dict)), default=0)
    return {'state': state, 'report_state': declared, 'report_day_status': reported,
            'report_available': True, 'qualified': False, 'duration_actual_seconds': duration,
            'completed_cycles': cycles, 'exit_code': report.get('exit_code'),
            'validation_errors': errors, 'failures': [str(item) for item in failures] + errors}


def archive_name(path):
    location = path.resolve()
    if location.is_relative_to(Q.resolve()):
        return location.relative_to(Q.resolve()).as_posix()
    if location in {ROOT / 'work/run-rust', ROOT / 'work/record.py'}:
        return 'supporting-files/work/' + location.name
    if location.is_relative_to(TREE.resolve()):
        return 'supporting-files/runtime/' + location.relative_to(TREE.resolve()).as_posix()
    raise ValueError('No safe archive name for ' + str(path))


def snapshot_files(ctx, report, launch, gate_paths):
    if ctx.snapshot.exists():
        raise ValueError('retained publication snapshot must not be overwritten')
    paths = {ctx.pin_path, *gate_paths}
    for directory in [ctx.output, ctx.preview]:
        if directory.exists():
            paths.update(path for path in directory.rglob('*') if path.is_file())
    for pattern in ['architecture-c12-soak-*', 'architecture-c12-soaks.py',
                    'architecture-c12-publish-soak.py', 'architecture-c12-deadline-*']:
        for path in Q.glob(pattern):
            if path.is_file():
                paths.add(path)
            elif path.is_dir() and not path.is_symlink():
                paths.update(child for child in path.rglob('*') if child.is_file())
    errors, omissions, pinned = [], [], set()
    for value in [ctx.pins, launch, report or {}, *[json.loads(path.read_text()) for path in gate_paths]]:
        try:
            retained, missing = references(value, ctx)
            paths.update(retained)
            pinned.update(retained)
            omissions.extend(missing)
        except (OSError, ValueError, TypeError, KeyError) as error:
            errors.append(str(error))
    ctx.snapshot.mkdir()
    entries, omitted = [], []
    names = set()
    for path in sorted(paths):
        if (path == ctx.state or path.name.startswith('.publication') or path.suffix == '.lock'
                or path.name in ('publication.log', 'supervisor.log')
                or '.next.' in path.name or '.tmp.' in path.name or '__pycache__' in path.parts
                or path.suffix in ('.pyc', '.pyo', '.next', '.tmp')):
            continue
        if path.is_symlink() or not path.is_file():
            raise ValueError('unexpected snapshot path: ' + str(path))
        name = archive_name(path)
        if not safe_name(name) or name in names:
            raise ValueError('unsafe or duplicate snapshot name: ' + name)
        names.add(name)
        with path.open('rb') as stream:
            elf = stream.read(4) == b'\x7fELF'
        if elf:
            omitted.append({'path': name, 'bytes': path.stat().st_size, 'sha256': digest(path)})
            continue
        target = ctx.snapshot / 'files' / name
        target.parent.mkdir(parents=True, exist_ok=True)
        before = path.stat()
        shutil.copyfile(path, target)
        after = path.stat()
        if path in pinned and digest(target) != digest(path):
            errors.append('Pinned input changed during snapshot: ' + str(path))
        entries.append({'path': name, 'bytes': target.stat().st_size, 'sha256': digest(target),
                        'original_path': str(path), 'source_size_before': before.st_size,
                        'source_size_after': after.st_size, 'source_mtime_ns_before': before.st_mtime_ns,
                        'source_mtime_ns_after': after.st_mtime_ns})
    metadata = {'source_pin': ctx.source, 'kind': ctx.kind, 'snapshot_utc': now(), 'qualified': False,
                'files': entries, 'omitted_executables': omitted,
                'recorded_external_compiler_references': omissions,
                'reference_validation_errors': errors,
                'scope': 'Immutable copies of one terminal day and preview. Active publication/supervisor logs are omitted; recorded compiler-cache ELF references do not assert current file availability.'}
    atomic(ctx.snapshot / 'snapshot.json', metadata)
    return metadata


CHECKER = r'''#!/usr/bin/env python3
"""Verify every retained file without extracting the archive."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import tarfile

def name_ok(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and str(p) == name and not any(x in ('.','..') for x in p.parts) and chr(92) not in name and ':' not in name

def main():
    root = Path(__file__).resolve().parent
    m = json.loads((root/'manifest.json').read_text())
    if m.get('qualified') is not False or m['archive']['name'] != 'raw.tar.gz':
        raise ValueError('invalid manifest scope or archive name')
    archive = root/'raw.tar.gz'
    if archive.stat().st_size != m['archive']['bytes'] or hashlib.sha256(archive.read_bytes()).hexdigest() != m['archive']['sha256']:
        raise ValueError('archive checksum/size differs')
    expected = {x['path']:x for x in m['files']}
    if len(expected) != len(m['files']) or not all(name_ok(x) for x in expected):
        raise ValueError('unsafe or duplicate manifest path')
    seen = set(); total = 0
    with tarfile.open(archive,'r:gz') as tar:
        for member in tar:
            if not member.isfile() or not name_ok(member.name) or member.name in seen or member.name not in expected:
                raise ValueError('unexpected archive member')
            entry = expected[member.name]
            if member.size != entry['bytes']: raise ValueError('member size differs')
            stream = tar.extractfile(member)
            if stream is None: raise ValueError('member bytes missing')
            h = hashlib.sha256()
            for block in iter(lambda:stream.read(1048576),b''): h.update(block)
            if h.hexdigest() != entry['sha256']: raise ValueError('member checksum differs')
            seen.add(member.name); total += member.size
    if seen != set(expected) or total != m['logical_bytes']: raise ValueError('archive inventory differs')
    print(f'verified {len(seen)} files, {total} bytes; no production qualification')

if __name__ == '__main__': main()
'''


def make_archive(ctx, snapshot, dest):
    files = []
    for item in snapshot['files']:
        path = ctx.snapshot / 'files' / item['path']
        if digest(path) != item['sha256']:
            raise ValueError('immutable publication snapshot changed: ' + item['path'])
        files.append(({key: item[key] for key in ('path', 'bytes', 'sha256')}, path))
    memory = {'publication-snapshot.json': (ctx.snapshot / 'snapshot.json').read_bytes()}
    source_names = {'Cargo.toml', 'Cargo.lock', 'pbrs-grpc/Cargo.toml', 'scripts/grpc-resource-campaign.py',
                    'pbrs-grpc/tests/resource_qualification.rs', 'pbrs-grpc/tests/common/mod.rs',
                    'pbrs-grpc/tests/server_deadline.rs', 'pbrs-grpc/tests/server_deadline_extended.rs'}
    for name in ctx.pins.get('changed_files', []):
        if name.startswith('pbrs-grpc/') and not name.startswith('pbrs-grpc/target/'):
            source_names.add(name)
    for name in sorted(source_names):
        if not safe_name(name):
            raise ValueError('unsafe source name')
        memory['runtime-source/' + name] = subprocess.check_output(['git', 'show', ctx.source + ':' + name], cwd=ROOT)
    for name, data in memory.items():
        files.append(({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}, data))
    if len({entry['path'] for entry, _ in files}) != len(files):
        raise ValueError('duplicate archive member')
    target = dest / 'raw.tar.gz'
    with target.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|') as tar:
            for entry, value in files:
                member = tarfile.TarInfo(entry['path'])
                member.size, member.mode = entry['bytes'], 0o644
                if isinstance(value, bytes):
                    tar.addfile(member, io.BytesIO(value))
                else:
                    with value.open('rb') as stream:
                        tar.addfile(member, stream)
    manifest = {'schema': 'pbrs.resource-capsule.v1', 'source': ctx.source, 'kind': ctx.kind, 'qualified': False,
                'archive': {'name': 'raw.tar.gz', 'bytes': target.stat().st_size, 'sha256': digest(target)},
                'logical_bytes': sum(item['bytes'] for item, _ in files), 'files': [item for item, _ in files]}
    (dest / 'manifest.json').write_bytes(encoded(manifest))
    (dest / 'check.py').write_text(CHECKER)
    subprocess.run([sys.executable, str(dest / 'check.py')], check=True)


def terminal_validation(ctx, report, termination, launch):
    extra = []
    if ctx.pin_error:
        extra.append(ctx.pin_error)
    try:
        current = source_now(ctx)
    except (OSError, subprocess.SubprocessError) as error:
        current = {'error': str(error)}
    if current != ctx.clean:
        extra.append('The frozen candidate checkout was not clean at publication.')
    try:
        gates = validate_gates(ctx)
    except (OSError, ValueError, KeyError, TypeError) as error:
        gates = []
        extra.append('Qualification gate validation: ' + str(error))
    if (termination.get('state') != 'terminated' or termination.get('exit_code') != 0
            or termination.get('source_pin_verified_at_end') is not True
            or termination.get('tool_metadata_matches_preview') is not True):
        extra.append('Supervisor did not attest successful termination, source and preview tool equivalence.')
    launch_pins = launch.get('pins') if isinstance(launch.get('pins'), dict) else {}
    if (launch.get('source_pin') != ctx.source or launch.get('requested_seconds') != 86400
            or launch_pins.get('sha256') != ctx.pins_sha256):
        extra.append('Launch source/duration/pins differ from the terminal publisher inputs.')
    preview, error = read_object(ctx.preview / 'report.json')
    if ctx.kind == 'resource':
        result = resource_outcome(report, termination, ctx)
        preview_result = resource_outcome(preview, {}, ctx, 30, error)
        if preview is not None and report is not None and preview.get('tools') != report.get('tools'):
            extra.append('Day tools differ from the successful preview.')
        preview_binary = preview.get('binary') if preview is not None and isinstance(preview.get('binary'), dict) else {}
        report_binary = report.get('binary') if report is not None and isinstance(report.get('binary'), dict) else {}
        if preview is not None and report is not None and preview_binary.get('sha256') != report_binary.get('sha256'):
            extra.append('Day executable differs from the release preview executable.')
    else:
        result = deadline_outcome(report, ctx)
        preview_result = deadline_outcome(preview, ctx, 30, error)
        if report is not None:
            if (report.get('build') != (preview or {}).get('build')
                    or report.get('provenance') != (preview or {}).get('provenance')):
                extra.append('Day build/provenance differs from its preview.')
            if report.get('state') == 'passed':
                try:
                    build_path, omitted = verify_ref(report['build'], ctx)
                    provenance_path, omitted_provenance = verify_ref(report['provenance'], ctx)
                    if omitted or omitted_provenance or build_path is None or provenance_path is None:
                        raise ValueError('Build/provenance are not retained JSON inputs.')
                    build = json.loads(build_path.read_text())
                    provenance = json.loads(provenance_path.read_text())
                    if (build.get('source_pin') != ctx.source or build.get('profile') != 'release'
                            or build.get('all_features') is not True or build.get('copy_counts') is not True
                            or build.get('allocation_counter_allocator') is not False or build.get('exit_code') != 0
                            or build.get('tools') != ctx.pins.get('tools_required')
                            or provenance.get('source_pin') != ctx.source
                            or provenance.get('runtime_source_equivalent') is not True
                            or provenance.get('build') != report['build']):
                        raise ValueError('Release feature/tool/runtime provenance differs from the launch contract.')
                    source_path, source_omitted = verify_ref(provenance['source_equivalence'], ctx)
                    if source_omitted or source_path is None:
                        raise ValueError('Source equivalence proof is not retained.')
                    proof = json.loads(source_path.read_text())
                    if proof.get('runtime_source_equivalent') is not True or proof.get('source') != ctx.overlay_source:
                        raise ValueError('Build source proof differs from the test-only overlay contract.')
                    fixture_cases = proof.get('fixture_cases_per_cycle')
                    originals = proof.get('originals', [])
                    if (type(fixture_cases) is not int or fixture_cases < 18
                            or sum(len(item['fixture_case_names']) for item in originals) != fixture_cases
                            or any(len(set(item['fixture_case_names'])) != len(item['fixture_case_names']) for item in originals)
                            or report.get('final_progress', {}).get('fixture_cases_per_cycle') != fixture_cases):
                        raise ValueError('Repeated case count differs from the source-discovered fixture set.')
                    artifact = report['cargo_artifact_attestation']
                    features = set(tomllib.loads((TREE / 'pbrs-grpc/Cargo.toml').read_text())['features'])
                    if (set(artifact['features']) != features or not {'prost', 'copy-counts'} <= features
                            or artifact['profile'].get('opt_level') != '3'
                            or artifact['profile'].get('debug_assertions') is not False
                            or artifact['profile'].get('test') is not True):
                        raise ValueError('Actual Cargo artifact does not attest release/all-feature test code.')
                except (OSError, ValueError, KeyError, TypeError) as failure:
                    extra.append('Diagnostic build validation: ' + str(failure))
            for value, directory, seconds in [(report, ctx.output, 86400), (preview, ctx.preview, 30)]:
                if value is not None and value.get('state') == 'passed':
                    try:
                        validate_deadline_events(value, directory, seconds)
                    except (OSError, ValueError, KeyError, TypeError) as failure:
                        extra.append('Completed-cycle validation: ' + str(failure))
    if preview_result['state'] != 'passed':
        extra.append('The actual 30-second preview did not pass its full diagnostic validation.')
    preview_ref = launch.get('preview', {})
    preview_path = ctx.preview / 'report.json'
    if (not preview_path.is_file() or not isinstance(preview_ref, dict)
            or preview_ref.get('sha256') != digest(preview_path)):
        extra.append('Preview bytes differ from the launch-pinned report.')
    if extra:
        result['validation_errors'].extend(extra)
        result['failures'].extend(extra)
        if result['state'] == 'passed':
            result['state'] = 'incomplete'
    return result, current, gates


def build_artifacts(ctx, result, current, snapshot):
    ctx.artifacts.mkdir()
    make_archive(ctx, snapshot, ctx.artifacts)
    metadata = {'source_pin': ctx.source, 'kind': ctx.kind, 'requested_seconds': 86400,
                **result, 'source_at_publication': current,
                'scope': 'Exact-source shared-host diagnostic only. Repeated cycles are not additional distinct production tests.'}
    (ctx.artifacts / 'results.json').write_bytes(encoded(metadata))
    duration = result['duration_actual_seconds']
    elapsed = 'unavailable' if duration is None else f'{duration:,.2f} seconds ({duration / 3600:.2f} hours)'
    failures = '\n'.join('- ' + str(item).replace('\n', ' ') for item in result['failures']) or '- None reported.'
    name = 'Resource' if ctx.kind == 'resource' else 'Server deadline'
    scope = ('The original gRPC resource fixture covers sustained progress, cancellation and recovery.'
             if ctx.kind == 'resource' else 'The test-only overlay repeats the independent-peer server deadline cases on the unchanged runtime. Cycles repeat the same cases and are not additional distinct tests.')
    (ctx.artifacts / 'README.md').write_text(f'''# {name} diagnostic, 2026-10-24 (UTC)

| Check | Result |
|---|---|
| Requested duration | 24 hours |
| Recorded duration | {elapsed} |
| Diagnostic status | {result['state']} |
| Completed cycles | {result['completed_cycles']} |
| Child exit code | {result['exit_code']} |
| Production qualified | No |

Runtime source: `{ctx.source}`.

{scope} The 30-second preview does not satisfy the requested day.
This record does not establish production readiness, complete specification
coverage or broad performance superiority. Other source revisions and diagnostics
remain separate evidence.

Reported failures:

{failures}

The archive contains immutable copies of terminal and preview records, source,
controllers, event/resource samples and build/command provenance. Executable bytes
are omitted; recorded hashes and sizes remain in `publication-snapshot.json`.
Reclaimed compiler-cache executable references describe their original checks,
not current file availability. Verify every archived member without extraction:

```sh
python3 {ctx.evidence}/check.py
```
''')


def artifact_entries(ctx):
    return {path.name: git('hash-object', str(path)).stdout.strip()
            for path in ctx.artifacts.iterdir() if path.is_file()}


def remote_matches(ctx):
    response = git('ls-tree', 'origin/main', '--', str(ctx.evidence))
    if not response.stdout.strip():
        return False
    actual = {}
    for line in git('ls-tree', '-r', 'origin/main', '--', str(ctx.evidence)).stdout.splitlines():
        identity, path = line.split('\t', 1)
        mode, kind, object_id = identity.split()
        relative = PurePosixPath(path).relative_to(PurePosixPath(str(ctx.evidence)))
        if mode != '100644' or kind != 'blob' or len(relative.parts) != 1:
            raise ValueError('Remote evidence contains unexpected files or modes.')
        actual[str(relative)] = object_id
    if actual != artifact_entries(ctx):
        raise ValueError('Remote already owns a different artifact at this evidence path.')
    if ctx.marker not in git('show', 'origin/main:docs/evidence/README.md').stdout:
        raise ValueError('Remote evidence has no matching terminal index marker.')
    return True


def publish(ctx):
    if ctx.state.exists() and json.loads(ctx.state.read_text()).get('state') == 'published':
        print(ctx.state.read_text(), end='')
        return 0
    state = {'state': 'preparing', 'source_pin': ctx.source, 'kind': ctx.kind,
             'pins_sha256': ctx.pins_sha256, 'qualified': False, 'started_utc': now(),
             'push_attempts': []}
    atomic(ctx.state, state)
    try:
        report_path = ctx.report_path
        raw = report_path.read_bytes() if report_path.exists() else None
        report, report_error = read_object(report_path)
        termination, error = read_object(ctx.output / 'termination.json')
        termination = termination or {'state': 'supervisor_failed', 'error': error}
        launch, error = read_object(ctx.output / 'launch.json')
        launch = launch or {'error': error}
        result, current, gate_paths = terminal_validation(ctx, report, termination, launch)
        if report_error and not result['report_available']:
            result['failures'].append(report_error)
        snapshot = snapshot_files(ctx, report, launch, gate_paths)
        if snapshot['reference_validation_errors']:
            result['validation_errors'].extend(snapshot['reference_validation_errors'])
            result['failures'].extend(snapshot['reference_validation_errors'])
            if result['state'] == 'passed':
                result['state'] = 'incomplete'
        if raw is not None and report_path.read_bytes() != raw:
            raise ValueError('Terminal report changed while it was snapshotted.')
        build_artifacts(ctx, result, current, snapshot)
        state.update(outcome=result, source_at_publication=current,
                     snapshot={'path': str(ctx.snapshot / 'snapshot.json'), 'sha256': digest(ctx.snapshot / 'snapshot.json')})
        atomic(ctx.state, state)
        title = 'Record the C12 ' + ctx.kind + ' diagnostic outcome'
        anchor = '## Benchmark coverage and campaign readiness'
        link = (f'{ctx.marker}\nThe [C12 {ctx.kind} diagnostic, source `{ctx.source[:8]}`]'
                f'({ctx.evidence.name}/README.md) has a terminal outcome; its exact-source scope and qualification limits apply.\n\n')
        for attempt in range(1, 4):
            git('fetch', 'origin', 'main')
            if git('merge-base', '--is-ancestor', ctx.source, 'origin/main', check=False).returncode:
                raise ValueError('Candidate source is absent from origin/main.')
            if remote_matches(ctx):
                state.update(state='published', completed_utc=now(),
                             evidence_commit=git('rev-parse', 'origin/main').stdout.strip(),
                             remote_already_had_identical_evidence=True)
                atomic(ctx.state, state)
                return 0
            worktree = ctx.worktree if attempt == 1 else ctx.worktree.with_name(ctx.worktree.name + '-attempt-' + str(attempt))
            if worktree.exists():
                raise ValueError('Owned publication worktree already exists; retained evidence requires review.')
            git('worktree', 'add', '--detach', str(worktree), 'origin/main')
            dest = worktree / ctx.evidence
            dest.parent.mkdir(parents=True, exist_ok=True)
            shutil.copytree(ctx.artifacts, dest)
            index = worktree / 'docs/evidence/README.md'
            text = index.read_text()
            if ctx.marker in text:
                raise ValueError('Remote index already owns this terminal marker.')
            index.write_text(text.replace(anchor, link + anchor, 1) if anchor in text else text + '\n' + link)
            git('add', '--', str(ctx.evidence), 'docs/evidence/README.md', cwd=worktree)
            git('commit', '-m', title, cwd=worktree)
            commit = git('rev-parse', 'HEAD', cwd=worktree).stdout.strip()
            pushed = git('push', '--porcelain', 'origin', 'HEAD:main', cwd=worktree, check=False)
            state['push_attempts'].append({'attempt': attempt, 'worktree': str(worktree),
                                           'commit': commit, 'returncode': pushed.returncode,
                                           'stdout': pushed.stdout, 'stderr': pushed.stderr})
            if pushed.returncode == 0:
                try:
                    remote = git('ls-remote', 'origin', 'refs/heads/main').stdout.split()[0]
                except (subprocess.SubprocessError, IndexError) as error:
                    remote = None
                    state['post_push_remote_observation_error'] = str(error)
                state.update(state='published', completed_utc=now(), evidence_commit=commit,
                             observed_remote_main=remote)
                atomic(ctx.state, state)
                print(json.dumps(state))
                return 0
            atomic(ctx.state, state)
        raise ValueError('Normal main push failed three times; all publication commits are retained.')
    except BaseException as error:
        state.update(state='failed', error=repr(error), completed_utc=now())
        atomic(ctx.state, state)
        traceback.print_exc()
        return 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--kind', choices=['resource', 'deadline'], required=True)
    parser.add_argument('--pins-sha256', required=True)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'kind': args.kind,
                          'pins_sha256': args.pins_sha256, 'qualified': False,
                          'execution_and_terminal_records_required': True}))
        return 0
    ctx = Context(args.kind, args.pins_sha256)
    if not ctx.output.is_dir():
        raise ValueError('There is no terminal diagnostic output directory.')
    with (ctx.output / '.publication.lock').open('a') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return publish(ctx)


if __name__ == '__main__':
    raise SystemExit(main())
