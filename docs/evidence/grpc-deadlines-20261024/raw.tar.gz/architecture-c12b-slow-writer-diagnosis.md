# Slow-writer fixture schedule correction

The original `f17aa991` full gRPC run failed its drip-count assertion: all 32 fast RPCs succeeded, but only two of three producer drips had been enqueued. The original record is unchanged. Executing the exact copied ELF later passed both the isolated test and all 25 resource cases with four test threads. **The original failure's unique execution cause is not reproduced.**

The source used different schedule models: the fast probes had fixed targets at 20, 22, …, 82 ms, while each of the three writer sleeps began 15 ms after the preceding task poll. A delayed producer poll therefore shifted all later drip targets. The slow writer also started before the competing connection setup completed, so its sends could occur before the claimed probe interval.

A temporary, archived diagnostic ran real RPCs and gated only the producer's second iteration until the 24th successful fast RPC. With sequential sleeps, that gate released at 67.710 ms, all 32 probes completed at 83.447 ms, and the remaining drips arrived at 84.569 and 99.830 ms. With absolute drip targets, the same gate released at 67.208 ms and both missed targets caught up at 67.223/67.225 ms, before the 83.229 ms probe completion. Both control cases completed all 32 fast calls with p99 around 2 ms. This artificial control demonstrates the timing premise; it is not the unique production cause. The existing 100 ms bound applies to **server queue delay**, not a formal producer scheduling allowance.

The published fixture now establishes the competing connection first, uses a shared origin for the unchanged 20..82 ms probe targets and 15/30/45 ms producer targets, and witnesses actual writer startup. Every drip-count, latency, server-delay, permit, byte-budget, final-message and recovery assertion remains. The temporary diagnostic is removed from the tracked test.

Final fixture SHA-256: `1b2af9941f6c2f83576487676e903c23991386cc1285801295a3bc5468271bb2`.

The final 25-case resource target passes with four test threads. Focused strict all-feature Clippy passes. Actual records, all source versions, the diagnostic trace and ELF provenance are listed in `architecture-c12b-slow-writer-summary.json`. ELF bytes are local provenance inputs, not performance claims. No runtime source, frozen worktree or older evidence was changed.
