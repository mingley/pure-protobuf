#!/usr/bin/env python3
"""Synthetic replacement-gate checks. No Git, compiler, diagnostic or publication."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import shutil
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
COMMON = Q / 'architecture-c12c-soak-common-workspace-complete.py'
spec = importlib.util.spec_from_file_location('workspace_complete_synthetic_common', COMMON)
M = importlib.util.module_from_spec(spec)
spec.loader.exec_module(M)
SOURCE = '7c02eb387a6785d6e914146babe34f0902a6dd62'
PIN_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
ROWS = []


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def check(label, action, expected):
    try:
        action()
        accepted = True
    except (AssertionError, KeyError, TypeError, ValueError, FileNotFoundError):
        accepted = False
    assert accepted == expected, label
    ROWS.append({'case': label, 'expected_accept': expected, 'actual_accept': accepted})


def main():
    originals = {name: getattr(M, name) for name in ['Q', 'PINS', 'TREE', 'WORKSPACE_COMPLETE', 'CHECKOUT_PROOF',
                 'WORKSPACE_RUNNER', 'ORIGINAL_CONTROLLER', 'actual_complete_checkout', 'git']}
    with tempfile.TemporaryDirectory(prefix='resource-architecture-c12c-workspace-complete-controls-', dir=Q) as tmp:
        base = Path(tmp)
        M.Q = base
        M.TREE = base / 'synthetic-source-not-a-worktree'
        M.PINS = base / 'architecture-c12c-source-pins.json'
        shutil.copy2(originals['PINS'], M.PINS)
        M.WORKSPACE_COMPLETE = base / 'architecture-c12c-workspace-complete-state.json'
        M.CHECKOUT_PROOF = base / 'architecture-c12c-workspace-complete-checkout.json'
        M.WORKSPACE_RUNNER = base / 'architecture-c12c-workspace-complete.py'
        M.ORIGINAL_CONTROLLER = base / 'architecture-c12c-qualification.py'
        shutil.copy2(originals['WORKSPACE_RUNNER'], M.WORKSPACE_RUNNER)
        shutil.copy2(originals['ORIGINAL_CONTROLLER'], M.ORIGINAL_CONTROLLER)
        files = [{'path': 'docs/evidence/README.md', 'mode': '100644', 'git_blob': 'a' * 40, 'bytes': 42}]
        tree = 'b' * 40
        M.actual_complete_checkout = lambda pin: copy.deepcopy(files)
        M.git = lambda *args, **kwargs: tree
        data = {'candidate_runtime': SOURCE, 'candidate_tree': tree}
        clean = {'head': SOURCE, 'status': ''}
        environment = {'RUSTUP_TOOLCHAIN': 'stable', 'CARGO_BUILD_JOBS': '2',
                       'CARGO_TARGET_DIR': str(M.ROOT / 'work/stable-target')}
        oldpath = base / 'architecture-c12c-workspace-state.json'

        def attempt(prefix, failure):
            record = {'command': M.WORKSPACE_COMMAND, 'cwd': str(M.TREE), 'timeout_seconds': 7200.0,
                      'exit_code': 101 if failure else 0, 'source': {'head': SOURCE, 'diff_sha256': M.EMPTY, 'untracked': {}},
                      'environment': copy.deepcopy(environment)}
            write(prefix.with_suffix('.json'), record)
            prefix.with_suffix('.stdout').write_text(
                'test test_documentation_links_and_anchors_are_valid ... FAILED\n'
                'test result: FAILED. 24 passed; 1 failed; 0 ignored;\n' if failure else
                'test result: ok. 25 passed; 0 failed; 0 ignored;\n')
            prefix.with_suffix('.stderr').write_text('synthetic fixture only\n')
            summary = {'status': 'FAILED' if failure else 'ok', 'passed': 24 if failure else 25,
                       'failed': 1 if failure else 0, 'ignored': 0}
            state = {'mode': 'workspace', 'state': 'failed' if failure else 'passed', 'active': 'workspace' if failure else None,
                     'qualified': False, 'source': clean, 'source_after': clean, 'pins': M.ref(M.PINS),
                     'free_bytes_before': 9 * 1024**3, 'checks': [{'name': 'workspace', 'command': M.WORKSPACE_COMMAND,
                         'exit_code': record['exit_code'], 'source_after': clean,
                         'summaries': [summary], 'targets': 1, 'totals': {k: summary[k] for k in ['passed', 'failed', 'ignored']},
                         'files': [M.ref(prefix.with_suffix(s)) for s in ['.json', '.stdout', '.stderr']]}]}
            return state

        old = attempt(base / 'architecture-c12c-workspace', True)
        write(oldpath, old)
        state = attempt(base / 'architecture-c12c-workspace-complete', False)
        proof = {'schema': 'pbrs.c12c-complete-checkout.v1', 'qualified': False, 'source': clean,
                 'tree': tree, 'sparse_checkout': False, 'tracked_blob_count': 1, 'tracked_blobs': files}
        write(M.CHECKOUT_PROOF, proof)
        state.update(attempt='complete_checkout_after_preserved_sparse_failure', controller=M.ref(M.ORIGINAL_CONTROLLER),
                     runner=M.ref(M.WORKSPACE_RUNNER), complete_checkout=M.ref(M.CHECKOUT_PROOF),
                     previous_attempt=[M.ref(oldpath)] + [M.ref((base / 'architecture-c12c-workspace').with_suffix(s))
                                                        for s in ['.json', '.stdout', '.stderr']])
        write(M.WORKSPACE_COMPLETE, state)
        check('complete synthetic replacement accepted', lambda: M.gate('workspace', data, PIN_SHA), True)
        for label, path, value in [
            ('running replacement rejected', ['state'], 'running'),
            ('failed replacement rejected', ['state'], 'failed'),
            ('wrong mode rejected', ['mode'], 'workspace-complete'),
            ('active replacement rejected', ['active'], 'workspace'),
            ('changed source rejected', ['source_after', 'head'], 'c' * 40),
            ('qualified claim rejected', ['qualified'], True),
            ('wrong attempt rejected', ['attempt'], 'sparse'),
            ('changed pins rejected', ['pins', 'sha256'], '0' * 64),
            ('runner reference changed rejected', ['runner', 'sha256'], '0' * 64),
            ('controller reference changed rejected', ['controller', 'sha256'], '0' * 64),
            ('previous attempt hash changed rejected', ['previous_attempt', 0, 'sha256'], '0' * 64),
            ('proof reference changed rejected', ['complete_checkout', 'sha256'], '0' * 64),
            ('wrong full command rejected', ['checks', 0, 'command'], ['cargo', 'test']),
            ('nonzero exit rejected', ['checks', 0, 'exit_code'], 101),
            ('test totals altered rejected', ['checks', 0, 'totals', 'passed'], 26),
            ('missing log hash rejected', ['checks', 0, 'files', 2, 'sha256'], '0' * 64),
            ('insufficient entry headroom rejected', ['free_bytes_before'], 7 * 1024**3)]:
            changed = copy.deepcopy(state)
            target = changed
            for key in path[:-1]: target = target[key]
            target[path[-1]] = value
            write(M.WORKSPACE_COMPLETE, changed)
            check(label, lambda: M.gate('workspace', data, PIN_SHA), False)
        write(M.WORKSPACE_COMPLETE, state)
        for label, key, value in [('wrong proof schema rejected', 'schema', 'unknown'),
                                  ('sparse proof rejected', 'sparse_checkout', True),
                                  ('missing tracked blob rejected', 'tracked_blobs', []),
                                  ('wrong blob count rejected', 'tracked_blob_count', 2),
                                  ('wrong tree rejected', 'tree', 'c' * 40)]:
            changed = copy.deepcopy(proof); changed[key] = value
            check(label, lambda changed=changed: M.validate_complete_checkout(changed, SOURCE, tree, files), False)
        record = json.loads((base / 'architecture-c12c-workspace-complete.json').read_text())
        for label, key, value in [('changed record command rejected', 'command', ['cargo', 'test']),
                                  ('changed timeout rejected', 'timeout_seconds', 7100),
                                  ('timeout rejected', 'timeout', True),
                                  ('wrong record cwd rejected', 'cwd', '/tmp'),
                                  ('changed build jobs rejected', 'environment', {**environment, 'CARGO_BUILD_JOBS': '3'}),
                                  ('extra RUSTFLAGS rejected', 'environment', {**environment, 'RUSTFLAGS': '-Ctarget-cpu=native'})]:
            changed = copy.deepcopy(record); changed[key] = value
            check(label, lambda changed=changed: M.validate_workspace_record(changed, SOURCE, 0), False)
        M.WORKSPACE_COMPLETE.unlink()
        check('missing replacement never falls back to old attempt', lambda: M.gate('workspace', data, PIN_SHA), False)
        for name, value in originals.items(): setattr(M, name, value)

    # AST proves original driver references remain literal inputs; no rebuild mode.
    controller = Q / 'architecture-c12c-soaks-workspace-complete.py'
    parsed = ast.parse(controller.read_text())
    assert "choices=['plan', 'check-ready', 'launch', 'supervise']" in controller.read_text()
    assert "'original_deadline_build_helpers'" in controller.read_text()
    ROWS.append({'case': 'successor CLI excludes build/prepare/preview; original build helpers separately retained',
                 'expected_accept': True, 'actual_accept': True})
    result = {'state': 'passed', 'qualified': False, 'synthetic_controls': True,
              'cases': ROWS, 'common_sha256': hashlib.sha256(COMMON.read_bytes()).hexdigest(),
              'controller_sha256': hashlib.sha256(controller.read_bytes()).hexdigest(),
              'recipe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'actual_git_or_compiler_or_fixture_or_network_or_publication_execution': False}
    with (Q / 'architecture-c12c-soak-workspace-complete-controls.json').open('x') as stream:
        json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({'state': 'passed', 'synthetic_controls': len(ROWS)}))


if __name__ == '__main__':
    main()
