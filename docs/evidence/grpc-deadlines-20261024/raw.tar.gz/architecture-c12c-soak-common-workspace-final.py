#!/usr/bin/env python3
"""Shared read-only pin and qualification checks for the C12c soak launchers."""

from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import runpy
import subprocess
import stat

if not __debug__:
    raise RuntimeError('workspace-final gates require enabled Python assertions')

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
PINS = Q / 'architecture-c12c-source-pins.json'
TREE = ROOT / 'work/architecture-c12c'
EMPTY = hashlib.sha256(b'').hexdigest()
DIAGNOSTIC = 'repeated independent-peer server deadline fixture'
OVERLAY = 'pbrs-grpc/tests/deadline_sustained.rs'
RESOURCE_PREVIEW = Q / 'architecture-c12c-resource-preview/report.json'
RUNTIME_SOURCE = '7c02eb387a6785d6e914146babe34f0902a6dd62'
FINAL_SOURCE = '8144576f74bcf290951a65235e3bb50f24710b71'
PRIOR_SOURCE = '33eaf842d640dc2df3e0cc14db194adcc601e616'
FINAL_TREE = ROOT / 'work/architecture-c12c-workspace-final'
FINAL_STATE = Q / 'architecture-c12c-workspace-final-state.json'
FINAL_RUNNER = Q / 'architecture-c12c-workspace-final.py'
FINAL_INPUTS = Q / 'architecture-c12c-workspace-final-inputs.json'
FINAL_RUNNER_SHA = 'f70c4bdc2d86b62026dcec56a000adbfe9074cfcb98a3e593b8fc3899637dcda'
FINAL_INPUTS_SHA = '8d0a0b1eac7573bf124682e66163a60002ed1b317c991ce4e11446b2f3dd68e3'
ORIGINAL_CONTROLLER = Q / 'architecture-c12c-qualification.py'
ORIGINAL_CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
FIXTURE_SHA = 'a2cca2774b42c6f4794b66df4b6dc3fdfaef3f5641a4eeeedd58de82c22f97e3'
FINAL_PROOFS = [Q / 'architecture-c12c-workspace-final-equivalence.json',
                Q / 'architecture-c12c-workspace-final-equivalence-after.json']
FIXTURE_PATH = 'pbrs-grpc/tests/service_config.rs'
DOC_PATHS = ['docs/evidence/README.md'] + [
    'docs/evidence/' + folder + '/' + filename
    for folder in ['grpc-decode-reuse-soak-20261023', 'grpc-prost-cache-diagnostic-20261023']
    for filename in ['README.md', 'check.py', 'manifest.json', 'raw.tar.gz', 'results.json']]
WORKSPACE_COMMAND = [str(ROOT / 'work/run-rust'), 'nice', '-n', '10', 'cargo', '+stable',
                     'test', '--locked', '--workspace', '--all-features', '--no-fail-fast',
                     '--', '--test-threads=4']


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def ref(path):
    path = Path(path).resolve()
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def verify(reference):
    path = Path(reference['path'])
    allowed = path.resolve().is_relative_to(Q.resolve()) or path.resolve() in {
        ROOT / 'work/run-rust', ROOT / 'work/record.py'}
    assert not path.is_symlink() and allowed, path
    assert ref(path) == reference, reference
    return path


def load(path):
    return json.loads(Path(path).read_text())


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + f'.next.{os.getpid()}')
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def exclusive(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def publish_once(path, value, staging):
    temporary = Path(staging) / (Path(path).name + f'.publish.{os.getpid()}')
    atomic(temporary, value)
    os.link(temporary, path)
    temporary.unlink()


def git(*arguments, cwd=TREE):
    return subprocess.check_output(['git', *arguments], cwd=cwd, text=True).strip()


def source(cwd=TREE):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd)}


def pins(expected_sha):
    assert re.fullmatch(r'[0-9a-f]{64}', expected_sha or ''), 'explicit immutable pins SHA256 required'
    assert not PINS.is_symlink() and digest(PINS) == expected_sha, 'C12c source pins changed'
    data = load(PINS)
    assert data['schema'] == 'pbrs.c12c-source-pins.v1' and data['qualified'] is False
    assert re.fullmatch(r'[0-9a-f]{40}', data['candidate_runtime'])
    assert source() == {'head': data['candidate_runtime'], 'status': ''}
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=TREE,
                          capture_output=True).returncode == 1
    for item in data['inputs']:
        verify(item)
    for name, sha in data['identical_harness'].items():
        assert digest(TREE / name) == sha, name
    return data


def caps(seconds):
    return {'address_space': 1073741824, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': seconds + 30}


def git_inventory(commit):
    rows = []
    for item in subprocess.check_output(['git', 'ls-tree', '-rlz', commit], cwd=ROOT).split(b'\0'):
        if not item:
            continue
        meta, raw_path = item.split(b'\t', 1)
        mode, kind, blob, size = meta.decode().split()
        assert kind == 'blob' and mode in ('100644', '100755', '120000')
        rows.append({'path': os.fsdecode(raw_path), 'mode': mode, 'git_blob': blob, 'bytes': int(size)})
    assert len({row['path'] for row in rows}) == len(rows)
    return sorted(rows, key=lambda row: row['path'])


def expected_equivalence():
    inventories = [git_inventory(commit) for commit in [RUNTIME_SOURCE, PRIOR_SOURCE, FINAL_SOURCE]]
    runtime, prior, final = [{row['path']: row for row in rows} for rows in inventories]
    changed = lambda a, b: sorted(name for name in a.keys() | b.keys() if a.get(name) != b.get(name))
    assert changed(runtime, prior) == sorted(DOC_PATHS)
    assert changed(prior, final) == [FIXTURE_PATH]
    assert changed(runtime, final) == sorted(DOC_PATHS + [FIXTURE_PATH])
    assert subprocess.check_output(['git', 'rev-parse', FINAL_SOURCE + '^'], cwd=ROOT, text=True).strip() == PRIOR_SOURCE
    entries = [{'path': name, 'runtime': runtime.get(name), 'prior_repository': prior.get(name),
                'repository': final.get(name)} for name in sorted(DOC_PATHS + [FIXTURE_PATH])]
    trees = [subprocess.check_output(['git', 'rev-parse', commit + '^{tree}'], cwd=ROOT, text=True).strip()
             for commit in [RUNTIME_SOURCE, PRIOR_SOURCE, FINAL_SOURCE]]
    return inventories, entries, trees


def actual_final_checkout(expected):
    assert FINAL_TREE.is_dir() and not FINAL_TREE.is_symlink() and FINAL_TREE.resolve() == FINAL_TREE
    clean = {'head': FINAL_SOURCE, 'status': ''}
    assert source(FINAL_TREE) == clean
    assert subprocess.run(['git', 'symbolic-ref', '-q', 'HEAD'], cwd=FINAL_TREE,
                          capture_output=True).returncode == 1
    sparse = subprocess.run(['git', 'config', '--bool', '--get', 'core.sparseCheckout'],
                            cwd=FINAL_TREE, capture_output=True, text=True)
    assert sparse.returncode in (0, 1) and sparse.stdout.strip() in ('', 'false')
    for row in expected:
        path = FINAL_TREE / row['path']
        status = path.lstat()
        if row['mode'] == '120000':
            assert stat.S_ISLNK(status.st_mode), row['path']
            raw = os.fsencode(os.readlink(path))
            assert len(raw) == row['bytes'], row['path']
            actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
        else:
            assert stat.S_ISREG(status.st_mode), row['path']
            assert bool(status.st_mode & 0o111) == (row['mode'] == '100755'), row['path']
            assert status.st_size == row['bytes'], row['path']
            hasher = hashlib.sha1(b'blob ' + str(row['bytes']).encode() + b'\0')
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    hasher.update(chunk)
            actual = hasher.hexdigest()
        assert actual == row['git_blob'], row['path']
    assert source(FINAL_TREE) == clean


def validate_equivalence(proof, phase, inventories, entries, trees, evidence):
    assert proof['schema'] == 'pbrs.c12c-workspace-final-equivalence.v1' and proof['qualified'] is False
    clean = {'head': FINAL_SOURCE, 'status': ''}
    assert proof['runtime_source'] == RUNTIME_SOURCE and proof['runtime_tree'] == trees[0]
    assert proof['prior_repository_source'] == PRIOR_SOURCE and proof['prior_repository_tree'] == trees[1]
    assert proof['repository_source'] == clean and proof['repository_tree'] == trees[2]
    assert proof['runtime_git_blobs'] == inventories[0]
    assert proof['prior_repository_git_blobs'] == inventories[1]
    assert proof['repository_git_blobs'] == inventories[2]
    assert proof['allowed_runtime_differences'] == sorted(DOC_PATHS + [FIXTURE_PATH])
    assert proof['changed_entries'] == entries
    prior = {row['path']: row for row in inventories[1]}
    final = {row['path']: row for row in inventories[2]}
    assert proof['fixture_diff_from_prior'] == {'path': FIXTURE_PATH,
        'from_blob': prior[FIXTURE_PATH]['git_blob'], 'to_blob': final[FIXTURE_PATH]['git_blob']}
    assert proof['physical_verification_phase'] == phase
    assert proof['source_before'] == proof['source_after'] == clean
    assert proof['complete_checkout'] == {'tracked_blob_count': len(inventories[2]),
        'total_tracked_bytes': sum(row['bytes'] for row in inventories[2]), 'tracked_blobs': inventories[2]}
    assert proof['fixture_evidence'] == evidence
    assert proof['pins'] == ref(PINS) and proof['inputs'] == ref(FINAL_INPUTS)
    assert proof['controller'] == ref(ORIGINAL_CONTROLLER) and proof['runner'] == ref(FINAL_RUNNER)


def validate_workspace_record(record, source_pin, cwd, exit_code):
    assert record['command'] == WORKSPACE_COMMAND and record['cwd'] == str(cwd)
    assert record['timeout_seconds'] == 7200 and record['exit_code'] == exit_code and not record.get('timeout')
    assert record['source'] == {'head': source_pin, 'diff_sha256': EMPTY, 'untracked': {}}
    env = record['environment']
    assert env['RUSTUP_TOOLCHAIN'] == 'stable' and env['CARGO_BUILD_JOBS'] == '2'
    assert env['CARGO_TARGET_DIR'] == str(ROOT / 'work/stable-target')
    assert not any(key in env for key in ['RUSTFLAGS', 'RUSTDOCFLAGS', 'ASAN_OPTIONS'])


def workspace_check(state, prefix, source_pin, cwd, failure=None):
    clean = {'head': source_pin, 'status': ''}
    assert state['mode'] == 'workspace' and state['qualified'] is False
    assert state['source'] == state['source_after'] == clean
    assert state['free_bytes_before'] >= 8 * 1024**3 and len(state['checks']) == 1
    check = state['checks'][0]
    exit_code = 101 if failure else 0
    assert check['name'] == 'workspace' and check['command'] == WORKSPACE_COMMAND
    assert check['exit_code'] == exit_code and check['source_after'] == clean
    expected = [ref(prefix.with_suffix(suffix)) for suffix in ['.json', '.stdout', '.stderr']]
    assert check['files'] == expected
    for item in expected:
        verify(item)
    record = load(prefix.with_suffix('.json'))
    validate_workspace_record(record, source_pin, cwd, exit_code)
    text = prefix.with_suffix('.stdout').read_text()
    parsed = [{'status': status, 'passed': int(passed), 'failed': int(failed), 'ignored': int(ignored)}
              for status, passed, failed, ignored in re.findall(
                  r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', text)]
    assert parsed and check['summaries'] == parsed and check['targets'] == len(parsed)
    assert check['totals'] == {key: sum(row[key] for row in parsed) for key in ['passed', 'failed', 'ignored']}
    assert check['totals']['passed'] > 0
    if failure:
        assert state['state'] == 'failed' and check['totals']['failed'] == 1
        assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.MULTILINE)) == {failure}
    else:
        assert state['state'] == 'passed' and state['active'] is None
        assert all(row['status'] == 'ok' and row['failed'] == 0 for row in parsed)
    return record


def workspace_final(data, expected_sha):
    assert data['candidate_runtime'] == RUNTIME_SOURCE
    assert digest(FINAL_RUNNER) == FINAL_RUNNER_SHA and digest(FINAL_INPUTS) == FINAL_INPUTS_SHA
    assert digest(ORIGINAL_CONTROLLER) == ORIGINAL_CONTROLLER_SHA
    for path in [FINAL_RUNNER, FINAL_INPUTS, ORIGINAL_CONTROLLER]:
        verify(ref(path))
    inputs = load(FINAL_INPUTS)
    assert inputs['schema'] == 'pbrs.c12c-workspace-final-inputs.v1' and inputs['qualified'] is False
    assert inputs['runtime_source'] == RUNTIME_SOURCE and inputs['repository_source'] == FINAL_SOURCE
    assert inputs['prior_repository_source'] == PRIOR_SOURCE and inputs['fixture_sha256'] == FIXTURE_SHA
    for key in ['fixture_evidence', 'previous_attempts', 'passed_phase_states']:
        for reference in inputs[key]:
            verify(reference)
    phases = ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native', 'asan']
    assert inputs['passed_phase_states'] == [ref(Q / ('architecture-c12c-' + name + '-state.json')) for name in phases]
    state = load(FINAL_STATE)
    assert state['schema'] == 'pbrs.c12c-workspace-final-state.v1' and state['state'] == 'passed'
    assert state['mode'] == 'workspace' and state['active'] is None and state['qualified'] is False
    assert state['runtime_source'] == RUNTIME_SOURCE and state['checkout'] == str(FINAL_TREE)
    assert state['pins'] == ref(PINS) and state['pins']['sha256'] == expected_sha
    assert state['controller'] == ref(ORIGINAL_CONTROLLER) and state['runner'] == ref(FINAL_RUNNER)
    assert state['inputs'] == ref(FINAL_INPUTS)
    assert state['previous_attempts'] == inputs['previous_attempts'] and len(state['previous_attempts']) == 8
    old_records = []
    expected_previous = []
    for name, failure in [('architecture-c12c-workspace', 'test_documentation_links_and_anchors_are_valid'),
                          ('architecture-c12c-workspace-complete', 'lb_selection_skips_unregistered_and_typed')]:
        path, prefix = Q / (name + '-state.json'), Q / name
        expected_previous += [ref(path)] + [ref(prefix.with_suffix(suffix)) for suffix in ['.json', '.stdout', '.stderr']]
        old = load(path)
        assert old['pins'] == ref(PINS)
        record = workspace_check(old, prefix, RUNTIME_SOURCE, TREE, failure)
        assert old['checks'][0]['targets'] == 144
        assert old['checks'][0]['totals'] == {'passed': 3811, 'failed': 1, 'ignored': 9}
        old_records.append(record)
    assert inputs['previous_attempts'] == expected_previous
    record = workspace_check(state, Q / 'architecture-c12c-workspace-final', FINAL_SOURCE, FINAL_TREE)
    assert state['checks'][0]['targets'] == 144
    assert state['checks'][0]['totals'] == {'passed': 3812, 'failed': 0, 'ignored': 9}
    assert all(old['environment'] == record['environment'] for old in old_records)
    inventories, entries, trees = expected_equivalence()
    assert trees[0] == data['candidate_tree']
    before, after = [], []
    for key, path, phase in zip(['runtime_equivalence', 'runtime_equivalence_after'], FINAL_PROOFS, ['before', 'after']):
        assert state[key] == ref(path)
        verify(state[key])
        proof = load(path)
        evidence = proof['fixture_evidence']
        assert evidence == inputs['fixture_evidence']
        for reference in evidence:
            verify(reference)
        validate_equivalence(proof, phase, inventories, entries, trees, evidence)
        if phase == 'before':
            before = proof
        else:
            after = proof
    for key in ['runtime_git_blobs', 'prior_repository_git_blobs', 'repository_git_blobs',
                'complete_checkout', 'changed_entries', 'fixture_evidence']:
        assert before[key] == after[key]
    actual_final_checkout(inventories[2])
    assert digest(FINAL_TREE / FIXTURE_PATH) == FIXTURE_SHA
    return ref(FINAL_STATE)


def gate(name, data, expected_sha):
    if name == 'workspace':
        return workspace_final(data, expected_sha)
    path = Q / ('architecture-c12c-' + name + '-state.json')
    state = load(path)
    clean = {'head': data['candidate_runtime'], 'status': ''}
    assert state['state'] == 'passed' and state['active'] is None, path
    assert state['qualified'] is False and state['source'] == state['source_after'] == clean, path
    assert state['mode'] == name and state['pins'] == ref(PINS), path
    assert state['pins']['sha256'] == expected_sha
    assert state['checks'], path
    for check in state['checks']:
        assert check['exit_code'] == 0 and check['source_after'] == clean, check['name']
        assert check['totals']['failed'] == 0, check['name']
        for item in check['files']:
            verify(item)
        record = load(next(row['path'] for row in check['files'] if row['path'].endswith('.json')))
        assert record['exit_code'] == 0 and not record.get('timeout'), check['name']
        assert record['source'] == {'head': data['candidate_runtime'], 'diff_sha256': EMPTY, 'untracked': {}}
    # ASAN executable references may intentionally name a reclaimed compiler
    # cache. Their retained hashes/logs are evidence; they are not launch inputs.
    return ref(path)


def resource_preview(data):
    report = load(RESOURCE_PREVIEW)
    assert report['source']['commit'] == data['candidate_runtime'] and report['source']['dirty'] is False
    assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
    assert report['exit_code'] == 0 and report['smoke'] == {'status': 'passed', 'failures': []}
    assert report['build']['profile'] == 'release'
    limits = {key: {'soft': value, 'hard': value} for key, value in caps(30).items()}
    assert report['process_limits'] == report['process_limits_requested'] == limits
    assert report['tools']['rustc'].splitlines()[0] == data['tools_required']['rustc']
    assert report['tools']['cargo'] == data['tools_required']['cargo']
    validator = TREE / 'scripts/grpc-resource-campaign.py'
    assert not runpy.run_path(str(validator))['validate_report'](report)
    binary = Path(report['binary']['path'])
    assert binary.parent == RESOURCE_PREVIEW.parent and digest(binary) == report['binary']['sha256']
    return {'report': ref(RESOURCE_PREVIEW), 'binary': ref(binary),
            'validator': {'path': str(validator), 'sha256': digest(validator), 'bytes': validator.stat().st_size},
            'tools': report['tools'], 'duration_actual_seconds': report['duration_actual_seconds']}


def readiness(expected_sha, full=True):
    data = pins(expected_sha)
    names = ['prechecks']
    if full:
        names += ['resource-preview', 'build-benchmark', 'native', 'cpu', 'asan', 'workspace']
    gates = {name: gate(name, data, expected_sha) for name in names}
    optional = Q / 'architecture-c12c-cold-native-state.json'
    if full and optional.exists():
        gates['cold-native'] = gate('cold-native', data, expected_sha)
    return {'source_pin': data['candidate_runtime'], 'pins': ref(PINS), 'gates': gates,
            'repository_validation': ({'source_pin': FINAL_SOURCE, 'runtime_source_pin': RUNTIME_SOURCE,
                                       'state': ref(FINAL_STATE)} if full else None),
            'resource_preview': resource_preview(data) if full else None,
            'qualified': False,
            'scope': 'Exact-source local checks only; these gates do not establish overall production readiness or speed superiority.'}
