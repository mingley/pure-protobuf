#!/usr/bin/env python3
"""Reclaim exactly six closed generated fixture/build directories when granted.

These directories include unpacked/generated source files as well as Cargo
artifacts. Original Git-tracked templates and all Q evidence remain outside the
allowlist. The reviewed generic helper inventories every removed entry first.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import stat
import subprocess
import sys
import traceback

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c12c'
HELPER = Q / 'architecture-c12c-reclaim-closed-cache.py'
HELPER_SHA = '4989f4a7d5fc71ec6c0df5a139fd5dc6edfe4148b91580b52c3bf2d5fa3c6dd7'
CONTROLLER = Q / 'architecture-c12c-qualification.py'
CONTROLLER_SHA = 'ba40e7e92580df9018020fa4f605a9a41eb8d9965d51da4a384496e944e55d9c'
INPUTS = Q / 'architecture-c12c-workspace-final-inputs.json'
INPUTS_SHA = '8d0a0b1eac7573bf124682e66163a60002ed1b317c991ce4e11446b2f3dd68e3'
PINS_SHA = '4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af'
RUNTIME = '7c02eb387a6785d6e914146babe34f0902a6dd62'
PHASES = ['prechecks', 'resource-preview', 'build-benchmark', 'native', 'cpu', 'cold-native', 'asan']
CACHES = {
    'final-integration-consumers': TREE / 'target/integration-consumers',
    'final-cold-packed-525057': TREE / 'target/pbrs-onboarding-cold-packed-525057-2',
    'final-adapters-noprotoc-525057': TREE / 'target/pbrs-onboarding-adapters-noprotoc-525057-0',
    'final-cold-packed-545355': TREE / 'target/pbrs-onboarding-cold-packed-545355-2',
    'final-adapters-noprotoc-545355': TREE / 'target/pbrs-onboarding-adapters-noprotoc-545355-0',
    'final-stable-release': ROOT / 'work/stable-target/release',
}
STATE = Q / 'architecture-c12c-final-workspace-cache-bundle-state.json'


def gates(c):
    assert c['digest'](INPUTS) == INPUTS_SHA and c['digest'](c['PINS']) == PINS_SHA
    c['load_pins']()
    assert c['source']() == {'head': RUNTIME, 'status': ''}
    inputs = json.loads(INPUTS.read_text())
    protected = [c['ref'](INPUTS), c['ref'](HELPER), c['ref'](CONTROLLER),
                 c['ref'](Path(__file__).resolve()), *inputs['previous_attempts'],
                 *inputs['fixture_evidence'], *inputs['passed_phase_states']]
    for item in protected:
        assert c['ref'](Path(item['path'])) == item
    for base, failure in [('architecture-c12c-workspace', 'test_documentation_links_and_anchors_are_valid'),
                          ('architecture-c12c-workspace-complete', 'lb_selection_skips_unregistered_and_typed')]:
        state = json.loads((Q / (base + '-state.json')).read_text())
        assert state['mode'] == 'workspace' and state['state'] == 'failed'
        assert state['source'] == state['source_after'] == {'head': RUNTIME, 'status': ''}
        assert state['pins'] == c['ref'](c['PINS']) and len(state['checks']) == 1
        check = state['checks'][0]
        assert check['exit_code'] == 101 and check['targets'] == 144
        assert check['totals'] == {'passed': 3811, 'failed': 1, 'ignored': 9}
        record = json.loads((Q / (base + '.json')).read_text())
        assert record['exit_code'] == 101 and not record.get('timeout')
        text = (Q / (base + '.stdout')).read_text()
        assert set(re.findall(r'^test (\S+) \.\.\. FAILED$', text, re.MULTILINE)) == {failure}
    for phase in PHASES:
        state = json.loads((Q / ('architecture-c12c-' + phase + '-state.json')).read_text())
        assert state['state'] == 'passed' and state['source'] == {'head': RUNTIME, 'status': ''}
        assert state['pins'] == c['ref'](c['PINS'])
    assert not (Q / 'architecture-c12c-workspace-final-state.json').exists()
    for pid in (525057, 545355):
        path = Path('/proc') / str(pid)
        if path.exists():
            assert re.search(r'^State:\s+Z\b', (path / 'status').read_text(), re.MULTILINE), pid
    for cache in CACHES.values():
        assert cache.is_dir() and not cache.is_symlink() and cache.resolve() == cache
        assert not Q.is_relative_to(cache) and not cache.is_relative_to(Q)
        for parent in cache.parents:
            if parent == ROOT:
                break
            assert not parent.is_symlink(), str(parent)
        for repo in (ROOT, TREE):
            if cache.is_relative_to(repo):
                tracked = subprocess.check_output(['git', 'ls-files', '-z', '--', str(cache.relative_to(repo))], cwd=repo)
                assert not tracked, str(cache)
        for path in cache.rglob('*'):
            mode = path.lstat().st_mode
            assert stat.S_ISREG(mode) or stat.S_ISDIR(mode) or stat.S_ISLNK(mode), str(path)
        assert all(not Path(item['path']).is_relative_to(cache) for item in protected)
    return protected


def main():
    assert __debug__, 'do not run with Python -O'
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    assert hashlib.sha256(HELPER.read_bytes()).hexdigest() == HELPER_SHA
    assert hashlib.sha256(CONTROLLER.read_bytes()).hexdigest() == CONTROLLER_SHA
    assert hashlib.sha256(INPUTS.read_bytes()).hexdigest() == INPUTS_SHA
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True, 'qualified': False,
                          'caches': {key: str(value) for key, value in CACHES.items()}}, indent=2))
        return
    assert os.environ.get('PYTHONOPTIMIZE') == '0', 'invoke ordinary Python with explicit PYTHONOPTIMIZE=0'
    d = runpy.run_path(str(HELPER), run_name='reviewed_c12c_closed_cache_helper')
    c = d['C']
    protected = gates(c)
    assert not STATE.exists()
    for key in CACHES:
        for suffix in ('inventory.json', 'reclaim.json'):
            assert not (Q / ('architecture-c12c-closed-' + key + '-cache-' + suffix)).exists()
    state = {'schema': 'pbrs.c12c-final-workspace-cache-bundle.v1', 'state': 'running',
             'qualified': False, 'started_utc': c['now'](), 'runtime_source': RUNTIME,
             'pins': c['ref'](c['PINS']), 'helper': c['ref'](HELPER),
             'runner': c['ref'](Path(__file__).resolve()), 'inputs': c['ref'](INPUTS),
             'caches': {key: str(value) for key, value in CACHES.items()},
             'protected': protected, 'completed': [],
             'limits': 'Removes closed generated fixture projects (including copied/generated source) and build artifacts. Original Git-tracked templates, Q sources/ELFs/logs, pinned runtime trees and debug cache are excluded. Generic helper records per-entry inventories and readable same-UID compiler/cache command scans; no global procfs mapping claim.'}
    c['exclusive'](STATE, state)
    try:
        d['CACHES'].clear(); d['CACHES'].update(CACHES)
        d['REQUIRED'].clear(); d['REQUIRED'].update({name: PHASES for name in CACHES})
        for name in CACHES:
            # The unchanged reviewed helper performs inventory, quiescence,
            # source/pin/ref checks and exclusive per-cache records each time.
            sys.argv = [str(HELPER), '--cache', name, '--execute']
            d['main']()
            for expected in protected:
                assert c['ref'](Path(expected['path'])) == expected
            state['completed'].append(c['ref'](Q / ('architecture-c12c-closed-' + name + '-cache-reclaim.json')))
            c['atomic'](STATE, state)
        c['load_pins']()
        state.update(state='completed', completed_utc=c['now'](), source_after=c['source']())
        c['atomic'](STATE, state)
    except BaseException as error:
        state.update(state='failed', error=repr(error), completed_utc=c['now'](), source_after=c['source']())
        c['atomic'](STATE, state)
        traceback.print_exc()
        raise


if __name__ == '__main__':
    main()
