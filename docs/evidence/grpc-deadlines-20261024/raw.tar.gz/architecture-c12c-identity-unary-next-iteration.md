# Identity unary instruction investigation

Read-only analysis of eight retained profiles; no compiler, workload, production edit, ELF read/rehash or debugger ran. Runtime checkpoint7c02 and publication pins are unchanged. Analysis script/result: `architecture-c12c-identity-unary-profile-attribution.{py,json}`.

## Evidence

Scope: equal-Prost Tonic client/native server, identity, 1 KiB request/response, one connection, one in-flight call. Profiles are only `architecture-c12c-cpu-ab/{baseline,candidate}/n-{10,20}/cell-{054,047}/server.callgrind.gz` (repeat0=054, repeat1=047), eight compressed files of approximately30KiB each. The JSON records their compressed hashes and exact source/binary pins from the existing summary.

| Instructions/RPC | Repeat0 | Repeat1 | Mean |
|---|---:|---:|---:|
| beb | 35,371.1 | 33,485.8 | 34,428.45 |
| 7c02 | 39,750.5 | 40,217.9 | 39,984.20 |
| Change | +4,379.4 | +6,732.1 | +5,555.75 |

Function self-cost parsing reconciles exactly to each Callgrind `totals:` value. Every file has totals minus header summary=168 instructions, which cancels in N/2N subtraction; the resulting deltas exactly reproduce the harness summary. Inclusive call edges overlap and must never be summed as independent costs. Profiles have stripped source positions (`???`); function symbols can be mapped to source functions, not uniquely to source lines. Code folding/inlining also changes symbol labels across builds.

## Source-backed repeated inspection

In both repeats the current Rpc::deadline is called4times/RPC: once from admission, twice from synchronous Router dispatch, and once from InboundRpc::from_rpc. Rpc::effective_timeout is called once by each of those four getters and once directly by from_rpc:5times/RPC. All5 perform a grpc-timeout HeaderMap lookup/hash even though this cell has no peer deadline.

| Current symbol/path | Calls/RPC in both repeats | Ir/RPC |
|---|---:|---:|
| effective_timeout subtree, including get/hash | 5 | 975 inclusive |
| Rpc::deadline own body | 4 | 108 self |
| HeaderMap::get own body, already inside975 | 5 | 310 self |
| hash_elem_using own body, already inside975 | 5 | 430 self |

Source: `server/rpc.rs::effective_timeout/deadline` recompute the editable header duration; `server/router.rs::dispatch` calls deadline before/after interception; `server/connection.rs` arms the accepted call; `InboundRpc::from_rpc` calls effective_timeout and then deadline while discarding the timeout already returned by request_facts. In beb, from_rpc used request_facts' timeout directly and Router did not invoke these getters. The current975+108 instruction path is directly witnessed; it is not a complete causal partition of the5555.75 combined-source delta because baseline work can be inlined under different symbols.

## Other measured paths and limits

CallDeadline::poll_at runs3.2/3.4times per RPC, with127.8/135.6 self instructions. Source registers the outer AtomicWaker before service polling and again after each Pending. One task-waker clone/RPC is visible. Registration for initially untimed calls is necessary for a later Rpc::set_timeout to wake the owner; removing that contract is not an optimization.

CallDeadline::close runs1.9/2.0times per RPC: one from Owner drop, approximately one from cancellation-record pool reset. Its inclusive costs are128.5/135.0Ir/RPC. Source clears owned capability/logger/waker resources even with retained application handles, then resets a uniquely owned pooled record for reuse. Any fast path must preserve detachment, cancellation visibility, retained deadline and reset behavior. These measured costs are modest beside the full delta.

The complete newly named deadline-module self-cost cluster is678.2/698.4Ir/RPC, including driver, poll_at, close, expiry and drop functions. This excludes the separately listed Rpc getters/header lookups. It is a current path subtotal, not a unique causal delta; the new driver also owns work previously reached through a differently labelled Router future.

Tokio worker::run own cost rises1624.3/1509.0→1977.2/2155.4; parking, readiness, timer maintenance and clock paths also rise. Admitted-driver poll counts are2.0/1.5→2.1/2.2 per RPC. These small-N scheduling differences do not establish that the deadline code caused every additional scheduler instruction.

An unnamed libc.so.6 routine at offset0x162b40 rises5279.5/5282.7→5759.6/5755.4 selfIr/RPC; aggregate incoming calls rise76.9/77.0→83.0/82.9. Caller labels shift substantially between old read_unary and current unary as code is inlined. No symbolization or byte-copy/allocation attribution is claimed. The binary object's differential rises24,813.1/22,869.5→28,519.9/29,391.7; libc increases are660.1/147.4 and libm12.5/62.5Ir/RPC. No inference from heap bytes to instruction savings is justified.

The remaining approximately4.5k instructions after the specifically identified inspection/getter subtree remain unresolved across combined-source changes. The reduced Router future size does not prove lower CPU cost.

## Next iteration only: parsed-header timeout cache control

After this checkpoint is published, make one isolated candidate that caches only the parsed editable grpc-timeout duration. Keep original accepted peer_timeout immutable and continue recomputing the effective minimum with server/interceptor caps and the shared monotonic absolute floor. Do not cache the combined effective timeout across set_timeout calls, change acceptance origin, alter Metadata mutation behavior, or skip expiry/commit checks.

Invalidate the parsed-header cache whenever Rpc::metadata_mut is requested, even if the caller ultimately makes no change. Whole Metadata replacement through that mutable reference must invalidate too. Cache only after parsing the current metadata. Review internal direct metadata assignments and any borrowed metadata path; a stale cache is a correctness bug. Reuse request_facts' parsed timeout when it is known to describe that exact current metadata generation, without discarding the accepted floor.

A candidate representation is an inline OnceLock<Option<Duration>>, cleared by metadata_mut's existing exclusive mutable borrow. This avoids assuming that adding Cell leaves Rpc auto traits unchanged and needs no new public method. It is an unimplemented design option: measure actual size, initializer/getter cost and Send/Sync equivalence before choosing it. Do not assume it is free because it adds no explicit Arc; extra Rpc bytes can enlarge selected boxed method futures and the admitted node. An alternative dirty/cache record must receive the same measurements. No extra public metadata restrictions or changed mutability semantics are allowed.

Functional controls must preserve accepted peer inspection, late initially-untimed caps, repeated set_timeout, metadata replacement/deletion/enlargement, original deadline anchoring, overflow policy, and Request/Response inspection. Include a mutable-access-without-edit case and repeated getters before/after mutation. Existing27 independent-peer cases plus the private ownership/layout guard remain required. A diagnostic parse counter may confirm cache hit/invalidation behavior, but must remain outside shipping code.

Use the unchanged selected identity-unary and Tonic-reference harness cells, N10/20, both repeats with paired ABBA ordering, same server/client settings and source-verified release profiles. Measure server/client Ir and N/2N requested bytes/allocation calls together. Preserve Rpc, cancellation record, Router/Single driver, generated selected unary future and admitted-node layouts before/after. Adopt only if actual instructions improve without an unacceptable size/byte regression; retained existing captures do not establish the new candidate's result.

A second independent control could investigate avoiding an unchanged outer-waker registration after a Pending service poll. This is not a blanket replacement of poll_at with at: AtomicWaker::wake consumes its registration, so a cap installed during the service poll can require re-registration before a later tightening. Preserve the initial registration and prove concurrent late-cap/tightening races before adopting any conditional fast path. Keep it separate from the header-cache experiment so effects remain attributable. No production changes are authorized by this note.
