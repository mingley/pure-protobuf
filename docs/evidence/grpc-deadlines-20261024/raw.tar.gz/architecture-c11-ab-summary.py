#!/usr/bin/env python3
"""Summarize every retained A/B diagnostic, including missing counters and losses."""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import statistics

METRICS = ['instructions', 'allocations', 'requested_bytes', 'context_switches', 'syscalls', 'task_wakeups']
ACCOUNTING = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']


def identity(cell):
    return json.dumps(cell, sort_keys=True)


def scope(cell):
    return {key: value for key, value in cell.items() if key != 'repeat'}


def ranges(values):
    values = [value for value in values if value is not None]
    return dict(available=len(values), min=min(values) if values else None,
                median=statistics.median(values) if values else None,
                max=max(values) if values else None)


def raw_counter(run, side, metric):
    if metric in ('allocations', 'requested_bytes'):
        return run.get('allocation_totals', {}).get(side, {}).get(metric)
    if metric == 'instructions':
        return run.get('instruction_totals', {}).get(side)
    if metric == 'context_switches':
        return run.get('context_switch_totals', {}).get(side, {}).get('total')
    return None


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--campaign', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    campaign = json.loads((args.campaign / 'campaign.json').read_text())
    comparisons = json.loads((args.campaign / 'source-comparison.json').read_text())
    accounting = {name: collections.Counter({key: 0 for key in ACCOUNTING}) for name in ('baseline', 'candidate')}
    availability = {name: {side: collections.Counter({metric: 0 for metric in METRICS})
                          for side in ('client', 'server')} for name in accounting}
    status_errors, failed, missing, runs = [], [], [], {}
    for capture in campaign['captures']:
        path = args.campaign / capture['path']
        if not path.is_file():
            missing.append(str(path))
            continue
        run = json.loads(path.read_text())
        version = capture['version']
        key = (version, capture['count'], identity(run['cell']))
        if key in runs:
            raise ValueError('duplicate source/count/workload/repeat capture')
        runs[key] = run
        if not run.get('passed'):
            failed.append(dict(path=str(path), error=run.get('error'), version=version))
        metrics = run.get('metrics', {})
        for name in ACCOUNTING:
            value = metrics.get(name)
            if type(value) is int and value >= 0:
                accounting[version][name] += value
            else:
                missing.append(f'{path}: metrics.{name}')
        if metrics.get('status_errors'):
            status_errors.append(dict(path=str(path), errors=metrics['status_errors']))
        for side in ('client', 'server'):
            for metric in METRICS:
                value = raw_counter(run, side, metric)
                if type(value) is int and value >= 0:
                    availability[version][side][metric] += 1
    expected_keys = {(version, count, identity(cell)) for version in accounting
                     for count in campaign['rpc_counts'] for cell in campaign['cells']}
    missing_keys = sorted(expected_keys - runs.keys())
    extra_keys = sorted(runs.keys() - expected_keys)
    grouped, dispositions = collections.defaultdict(list), collections.defaultdict(collections.Counter)
    for row in comparisons['rows']:
        group = (identity(scope(row['cell'])), row['side'], row['metric'], row['native_side'])
        grouped[group].append(row)
        dispositions[f"{row['side']}:{row['metric']}:{'native' if row['native_side'] else 'tonic_control'}"][row['disposition']] += 1
    source_ranges = []
    for (cell, side, metric, native), rows in sorted(grouped.items()):
        baseline = ranges([row['baseline_per_rpc'] for row in rows])
        candidate = ranges([row['candidate_per_rpc'] for row in rows])
        source_ranges.append(dict(cell=json.loads(cell), side=side, metric=metric, native_side=native,
                                  expected_repeats=len(rows), baseline=baseline, candidate=candidate,
                                  paired_source_ratios=ranges([row['ratio'] for row in rows]),
                                  ratio_of_medians=(candidate['median'] / baseline['median']
                                                    if baseline['median'] and candidate['median'] else None),
                                  dispositions=dict(collections.Counter(row['disposition'] for row in rows)),
                                  failed_captures=[failure for row in rows for failure in row['failed_captures']]))
    tonic_ranges, tonic_dispositions = [], {}
    for version in accounting:
        path = args.campaign / version / 'ledger.json'
        if not path.is_file():
            tonic_dispositions[version] = dict(state='NOT_RUN', reason='pilot has no same-side tonic reference')
            continue
        ledger = json.loads(path.read_text())
        groups, counts = collections.defaultdict(list), collections.defaultdict(collections.Counter)
        for row in ledger['rows']:
            groups[(identity(scope(row['cell'])), row['side'], row['metric'])].append(row)
            counts[f"{row['side']}:{row['metric']}"][row['disposition']] += 1
        tonic_dispositions[version] = {key: dict(value) for key, value in counts.items()}
        for (cell, side, metric), rows in sorted(groups.items()):
            tonic_ranges.append(dict(version=version, cell=json.loads(cell), side=side, metric=metric,
                                     expected_repeats=len(rows), native=ranges([row['native_per_rpc'] for row in rows]),
                                     tonic=ranges([row['tonic_per_rpc'] for row in rows]),
                                     native_over_tonic=ranges([row['ratio'] for row in rows]),
                                     dispositions=dict(collections.Counter(row['disposition'] for row in rows))))
    cpu_rows = []
    if campaign.get('phase') == 'native':
        first, last = campaign['rpc_counts']
        for cell in campaign['cells']:
            for side in ('client', 'server'):
                field = 'client_lifetime_cpu_seconds' if side == 'client' else 'server_cpu_during_client_seconds'
                row = dict(cell=cell, side=side, metric='coarse_cpu_seconds_per_rpc', qualified=False)
                for version in accounting:
                    entries = [runs.get((version, count, identity(cell)), {}) for count in (first, last)]
                    values = [run.get(field) for run in entries]
                    valid = (all(run.get('passed') for run in entries)
                             and all(type(value) in (int, float) and math.isfinite(value) for value in values))
                    delta = values[1] - values[0] if valid else None
                    row[version] = delta / (last - first) if delta is not None and delta > 0 else None
                row['candidate_over_baseline'] = row['candidate'] / row['baseline'] if row['baseline'] and row['candidate'] else None
                cpu_rows.append(row)
    expected_rpc_calls = len(campaign['cells']) * 3 * campaign['rpc_counts'][0]
    actual_ok = all(all(values[key] == expected_rpc_calls for key in ACCOUNTING[:4])
                    and all(values[key] == 0 for key in ACCOUNTING[4:]) for values in accounting.values())
    result = dict(qualified=False, phase=campaign.get('phase', 'callgrind'), state=campaign['state'],
                  controller_passed=campaign['passed'],
                  passed=(campaign['passed'] and not failed and not missing and not missing_keys and not extra_keys
                          and len(campaign['captures']) == campaign['expected_captures'] and actual_ok and not status_errors),
                  expected_captures=campaign['expected_captures'], retained_captures=len(runs),
                  expected_rpc_calls_per_source=expected_rpc_calls,
                  actual_rpc_totals={key: dict(value) for key, value in accounting.items()},
                  raw_counter_availability=availability, source_comparison_dispositions=dispositions,
                  same_side_tonic_dispositions=tonic_dispositions, source_ranges=source_ranges,
                  same_side_tonic_ranges=tonic_ranges, coarse_cpu_diagnostics=cpu_rows,
                  failed_captures=failed, missing_data=missing, missing_keys=missing_keys, extra_keys=extra_keys,
                  status_errors=status_errors, source_pins=campaign['versions'],
                  controller_sha256=campaign['controller_sha256'],
                  summary_script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
                  limits=campaign['limits'] + ['CPU tick N/2N deltas are coarse; nonpositive deltas stay unavailable',
                                               'paired-ratio medians and ratios of medians are distinct and labelled separately',
                                               'all source changes are combined; these counters do not establish individual causation'])
    with args.output.open('x') as output:
        json.dump(result, output, indent=2)
        output.write('\n')
    print(json.dumps({key: result[key] for key in ['qualified', 'phase', 'passed', 'retained_captures', 'actual_rpc_totals']}))


if __name__ == '__main__':
    main()
