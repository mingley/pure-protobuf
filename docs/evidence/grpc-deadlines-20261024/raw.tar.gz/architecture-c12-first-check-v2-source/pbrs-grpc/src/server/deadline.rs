//! One accepted deadline and terminal owner for the entire service future.

use super::dispatch::Dispatch;
use super::drain::{CancelFlag, CancelOnDrop};
use super::rpc::{Rpc, end_call, start_call};
use crate::metadata::Metadata;
use crate::rt::Runtime;
use crate::status::Status;
use crate::telemetry::{
    CallLabels, CallRole, CancellationEvent, CancellationReason, LifecycleObserver, OwnedCallLabels,
};
use crate::transport::h2::{DeadlineEnding, DeadlineResponse, SendResponse};
use atomic_waker::AtomicWaker;
use std::future::{Future, poll_fn};
use std::sync::Arc;
#[allow(
    clippy::disallowed_types,
    reason = "brief call-state transfers, no callbacks or await under lock"
)]
use std::sync::Mutex;
use std::sync::atomic::{AtomicU8, Ordering};
use std::task::{Context, Poll};
use tokio::time::Instant;

/// Reuses the call's cancellation allocation. Unlimited calls do not retain a
/// backend response capability or allocate a timer.
pub(crate) struct CallDeadline {
    flags: AtomicU8,
    wake: AtomicWaker,
    inner: Mutex<DeadlineState>,
}

struct DeadlineState {
    at: Option<Instant>,
    response: Option<DeadlineResponse>,
    binlog: Option<crate::binlog::CallLogger>,
    web_carry: ([u8; 2], usize),
}

impl CallDeadline {
    const ACTIVE: u8 = 1;
    const STARTED: u8 = 2;
    const ENDED: u8 = 4;
    const CLOSED: u8 = 8;
    const WEB_PARTIAL: u8 = 16;
    const CANCELLATION: u8 = 32;

    pub(crate) fn new() -> Self {
        Self {
            flags: AtomicU8::new(0),
            wake: AtomicWaker::new(),
            inner: Mutex::new(DeadlineState {
                at: None,
                response: None,
                binlog: None,
                web_carry: ([0; 2], 0),
            }),
        }
    }

    /// Reset only when the cancellation allocation is uniquely owned.
    pub(crate) fn reset(&self) {
        self.close();
        self.inner.lock().unwrap_or_else(|p| p.into_inner()).at = None;
        self.flags.store(0, Ordering::Release);
    }

    pub(crate) fn at(&self) -> Option<Instant> {
        if self.flags.load(Ordering::Acquire) & Self::ACTIVE == 0 {
            return None;
        }
        self.inner.lock().unwrap_or_else(|p| p.into_inner()).at
    }

    pub(crate) fn tighten(&self, at: Option<Instant>, respond: &SendResponse) -> Option<Instant> {
        let Some(at) = at else { return self.at() };
        let flags = self.flags.load(Ordering::Acquire);
        if flags & Self::CLOSED != 0 {
            return self.at();
        }
        if self.at().is_some_and(|previous| previous <= at) {
            return self.at();
        }
        // Cloning/dropping a backend capability can acquire engine locks, so
        // neither operation belongs inside the call-state lock.
        let mut capability = (flags & Self::ACTIVE == 0)
            .then(|| respond.deadline_response())
            .flatten();
        let result = {
            let mut state = self.inner.lock().unwrap_or_else(|p| p.into_inner());
            if self.flags.load(Ordering::Acquire) & Self::CLOSED == 0 {
                state.at = Some(state.at.map_or(at, |previous| previous.min(at)));
                if state.response.is_none() {
                    state.response = capability.take();
                }
                self.flags.fetch_or(Self::ACTIVE, Ordering::Release);
            }
            state.at
        };
        drop(capability);
        self.wake.wake();
        result
    }

    fn poll_at(&self, cx: &Context<'_>) -> Option<Instant> {
        self.wake.register(cx.waker());
        self.at()
    }

    pub(crate) fn start(&self) -> bool {
        self.flags.fetch_or(Self::STARTED, Ordering::AcqRel) & Self::STARTED == 0
    }

    pub(crate) fn end(&self) -> bool {
        self.flags.fetch_or(Self::ENDED, Ordering::AcqRel) & Self::ENDED == 0
    }

    fn started(&self) -> bool {
        self.flags.load(Ordering::Acquire) & Self::STARTED != 0
    }

    fn ended(&self) -> bool {
        self.flags.load(Ordering::Acquire) & Self::ENDED != 0
    }

    pub(crate) fn set_binlog(&self, logger: &crate::binlog::CallLogger) {
        let previous = {
            let mut state = self.inner.lock().unwrap_or_else(|p| p.into_inner());
            if self.flags.load(Ordering::Acquire) & Self::CLOSED == 0 {
                state.binlog.replace(logger.clone())
            } else {
                None
            }
        };
        drop(previous);
    }

    pub(crate) fn record_cancellation(&self) -> bool {
        self.flags.fetch_or(Self::CANCELLATION, Ordering::AcqRel) & Self::CANCELLATION == 0
    }

    pub(crate) fn expired(&self) -> bool {
        self.at().is_some_and(|at| Instant::now() >= at)
    }

    pub(crate) fn web_frame_started(&self) {
        self.flags.fetch_or(Self::WEB_PARTIAL, Ordering::Release);
    }

    pub(crate) fn web_frame_finished(&self) {
        self.flags.fetch_and(!Self::WEB_PARTIAL, Ordering::Release);
    }

    #[cfg(feature = "grpc-web")]
    pub(crate) fn save_web_carry(&self, carry: ([u8; 2], usize)) {
        self.inner
            .lock()
            .unwrap_or_else(|p| p.into_inner())
            .web_carry = carry;
    }

    /// Detach resources even when an application retains Request/cancel handles.
    pub(crate) fn close(&self) {
        let resources = {
            let mut state = self.inner.lock().unwrap_or_else(|p| p.into_inner());
            self.flags.fetch_or(Self::CLOSED, Ordering::AcqRel);
            state.web_carry = ([0; 2], 0);
            (state.response.take(), state.binlog.take())
        };
        drop(self.wake.take());
        drop(resources);
    }

    fn take_terminal(
        &self,
    ) -> (
        Option<DeadlineResponse>,
        Option<crate::binlog::CallLogger>,
        ([u8; 2], usize),
        bool,
    ) {
        let mut state = self.inner.lock().unwrap_or_else(|p| p.into_inner());
        (
            state.response.take(),
            state.binlog.take(),
            state.web_carry,
            self.flags.load(Ordering::Acquire) & Self::WEB_PARTIAL != 0,
        )
    }
}

struct Owner {
    cancel: CancelOnDrop,
    observer: Option<Arc<dyn LifecycleObserver>>,
    labels: Option<OwnedCallLabels>,
    channelz_server: Option<crate::channelz::ServerId>,
    channelz_socket: Option<crate::channelz::SocketId>,
    accepted_at: Instant,
}

/// An encoding/interceptor may consume the remaining budget in one synchronous
/// poll. Yield to the terminal owner before committing more response bytes.
pub(crate) async fn before_commit(call: &CancelFlag) {
    if call.deadline.expired() {
        std::future::pending::<()>().await;
    }
}

impl Drop for Owner {
    fn drop(&mut self) {
        self.cancel.flag().deadline.close();
        if self.cancel.flag().deadline.started() && !self.cancel.flag().deadline.ended() {
            // Preserve registry accounting on connection abort and panic. A
            // second user callback panic during unwinding could abort the process.
            let observer = if std::thread::panicking() {
                None
            } else {
                self.observer.as_deref()
            };
            let labels = self.labels.as_ref().map(|labels| labels.as_borrowed());
            end_call(
                self.cancel.flag(),
                observer,
                labels.as_ref(),
                self.channelz_server,
                self.channelz_socket,
                &Status::cancelled(),
                self.accepted_at.elapsed(),
            );
        }
    }
}

pub(crate) async fn serve<R: Runtime, D: Dispatch>(dispatch: Arc<D>, rpc: Rpc) {
    let observer = dispatch.observer().cloned();
    let labels = observer
        .as_ref()
        .map(|_| CallLabels::new(rpc.path(), rpc.authority(), CallRole::Server).to_owned());
    let channelz_server = rpc.channelz_server;
    let channelz_socket = rpc.channelz_socket;
    let accepted_at = rpc.accepted_at;
    let owner = Owner {
        cancel: CancelOnDrop::new(Arc::clone(&rpc.call_cancel)),
        observer,
        labels,
        channelz_server,
        channelz_socket,
        accepted_at,
    };
    let flag = owner.cancel.flag();
    #[cfg(feature = "grpc-web")]
    let web = rpc.web;
    let expired = {
        // Dispatch construction includes synchronous interceptors and service
        // future construction. Keep it inside the checked first poll.
        let service = async { dispatch.dispatch(rpc).await };
        tokio::pin!(service);
        let mut sleep = None;
        poll_fn(|cx| {
            let at = flag.deadline.poll_at(cx);
            if at.is_some_and(|at| R::now() >= at) {
                flag.signal();
                return Poll::Ready(true);
            }
            if service.as_mut().poll(cx).is_ready() {
                return Poll::Ready(false);
            }
            if let Some(at) = flag.deadline.poll_at(cx) {
                if sleep.as_ref().is_none_or(|(previous, _)| *previous != at) {
                    sleep = Some((at, Box::pin(R::sleep_until(at))));
                }
                if let Some((_, sleep)) = &mut sleep {
                    if sleep.as_mut().poll(cx).is_ready() {
                        flag.signal();
                        return Poll::Ready(true);
                    }
                }
            }
            Poll::Pending
        })
        .await
    }; // Destroy service state before recovering/sending its terminal response.
    if expired {
        let status = Status::deadline_exceeded();
        let (capability, logger, carry, partial_web_frame) = flag.deadline.take_terminal();
        let labels = owner.labels.as_ref().map(|labels| labels.as_borrowed());
        let observer = owner.observer.as_deref();
        if !flag.deadline.ended() {
            start_call(
                flag,
                observer,
                labels.as_ref(),
                channelz_server,
                channelz_socket,
            );
        }
        if !flag.deadline.ended() && flag.deadline.record_cancellation() {
            if let (Some(observer), Some(labels)) = (observer, labels.as_ref()) {
                observer.on_cancellation(&CancellationEvent {
                    call: *labels,
                    reason: CancellationReason::DeadlineExceeded,
                });
            }
        }
        if !flag.deadline.ended() {
            if let Some(logger) = logger {
                logger.log_trailer(&Metadata::new(), &status);
            }
        }
        if let Some(mut capability) = capability {
            #[cfg(feature = "grpc-web")]
            let terminal = match web {
                Some(mode) => crate::web::deadline_response(mode, &status, &carry.0[..carry.1]),
                None => native_terminal(&status),
            };
            #[cfg(not(feature = "grpc-web"))]
            let terminal = native_terminal(&status);
            if let Ok((response, trailers, body)) = terminal {
                let ending = if body.is_some() {
                    if partial_web_frame {
                        DeadlineEnding::Reset
                    } else {
                        DeadlineEnding::Data
                    }
                } else {
                    DeadlineEnding::Trailers
                };
                capability.finish(response, trailers, body, ending).ok();
            }
        }
        end_call(
            flag,
            observer,
            labels.as_ref(),
            channelz_server,
            channelz_socket,
            &status,
            accepted_at.elapsed(),
        );
    }
}

fn native_terminal(
    status: &Status,
) -> Result<(http::Response<()>, http::HeaderMap, Option<bytes::Bytes>), Status> {
    let trailers = crate::wire::grpc_trailers(status)?;
    let mut response = http::Response::new(());
    response.headers_mut().insert(
        http::header::CONTENT_TYPE,
        http::HeaderValue::from_static("application/grpc"),
    );
    response.headers_mut().extend(trailers.clone());
    Ok((response, trailers, None))
}
