#!/usr/bin/env python3
"""Small terminal-summary analysis only; no qualification, raw scan or profiler."""
import datetime
import hashlib
import json
import math
from pathlib import Path

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '40f219fa515034b556df7f39e3e3947e364a2ce1'
BASELINE = 'beb4ecd9a9b2143c440892607d5b486318062b61'
PINS_SHA = '12166d2fe5c7495096f95bb779bb0202a7feeff6076075c1ef0ad56e1b0ad8c1'
summary_path = Q / 'architecture-c12b-counter-ab-summary.json'
state_path = Q / 'architecture-c12b-native-state.json'
pin_path = Q / 'architecture-c12b-source-pins.json'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
ref = lambda path: {'path': str(path), 'bytes': path.stat().st_size, 'sha256': sha(path)}
state = json.loads(state_path.read_text())
summary = json.loads(summary_path.read_text())
assert state['state'] == 'passed' and state['active'] is None and state['source'] == state['source_after'] == {'head': SOURCE, 'status': ''}
assert sha(pin_path) == PINS_SHA and state['pins'] == ref(pin_path) and state['summary'] == ref(summary_path)
assert summary['state'] == 'finished' and summary['passed'] and summary['controller_passed'] and summary['qualified'] is False
assert summary['retained_captures'] == summary['expected_captures'] == 1088
assert not any(summary[k] for k in ['failed_captures', 'missing_keys', 'extra_keys', 'status_errors'])
for version, commit in [('baseline', BASELINE), ('candidate', SOURCE)]:
    assert summary['source_pins'][version]['source']['commit'] == commit
    actual = summary['actual_rpc_totals'][version]
    assert all(actual[k] == 20400 for k in ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs'])
    assert all(actual[k] == 0 for k in ['failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs'])


def native(row):
    return row['cell']['pair'][0 if row['side'] == 'client' else 2] == 'native'


def equal_prost(row):
    return row['cell']['pair'][1] == row['cell']['pair'][3] == 'prost'


def delta(before, after):
    if type(before) not in (int, float) or type(after) not in (int, float) or before <= 0 or not math.isfinite(before + after):
        return None
    return (after / before - 1) * 100


def augment(row, basis):
    before = row['baseline' if basis == 'source' else 'tonic']['median']
    after = row['candidate' if basis == 'source' else 'native']['median']
    return dict(row, comparison_basis=basis, before=before, current=after,
                change_percent=delta(before, after), saved_per_rpc=before-after if before is not None and after is not None else None)


source = [augment(row, 'source') for row in summary['source_ranges'] if row['native_side'] and row['metric'] in ['allocations', 'requested_bytes']]
tonic = [augment(row, 'tonic') for row in summary['same_side_tonic_ranges'] if row['version'] == 'candidate' and native(row) and row['metric'] in ['allocations', 'requested_bytes']]
higher = lambda rows: [r for r in rows if r['change_percent'] is not None and r['change_percent'] > 0]
selections = {}
for basis, rows in [('source', source), ('tonic', tonic)]:
    for metric in ['requested_bytes', 'allocations']:
        selected = []
        for side in ['client', 'server']:
            eligible = [r for r in rows if equal_prost(r) and r['side'] == side and r['metric'] == metric and r['change_percent'] is not None]
            selections[f'{basis}:{metric}:{side}'] = {
                'worst_relative_increase': sorted(eligible, key=lambda r:r['change_percent'], reverse=True)[:2],
                'largest_absolute_savings': sorted([r for r in eligible if r['saved_per_rpc'] > 0], key=lambda r:r['saved_per_rpc'], reverse=True)[:2],
                'largest_relative_savings': sorted([r for r in eligible if r['change_percent'] < 0], key=lambda r:r['change_percent'])[:2],
            }
interop = [r for r in tonic if not equal_prost(r) and r['metric'] == 'requested_bytes']
interop = sorted(interop, key=lambda r:r['change_percent'] if r['change_percent'] is not None else -math.inf, reverse=True)
result = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'state': 'terminal_native_summary_analysis',
          'qualified': False, 'source': SOURCE, 'baseline_source': BASELINE,
          'scope': 'Read-only terminal native summary and phase/pin identity checks only. No raw capture revalidation, writer/packager execution, compiler, cleanup or production qualification.',
          'inputs': [ref(summary_path), ref(state_path), ref(pin_path)],
          'captures': 1088, 'successful_rpcs_both_sources': 40800,
          'actual_rpc_totals': summary['actual_rpc_totals'],
          'selection_rules': 'Equal-Prost requires Prost on both endpoints and a native measured endpoint. Worst ranks percentage increase; gains separately rank absolute and relative savings. Every native higher-cost group is retained below without a cutoff.',
          'selections': selections,
          'every_native_higher_source_cost_group': higher(source),
          'every_native_higher_current_vs_tonic_cost_group': higher(tonic),
          'higher_cost_cutoff_percent': 0,
          'interop_largest_relative_byte_gaps': interop[:4],
          'interop_scope': 'Additional pbrs handler work and API differences prevent isolated codec or transport attribution. Keep separate from equal-Prost comparisons.',
          'raw_counter_availability': summary['raw_counter_availability'],
          'source_comparison_dispositions': summary['source_comparison_dispositions'],
          'same_side_tonic_dispositions': summary['same_side_tonic_dispositions'],
          'limits': ['Two paired repeats, 25/50 calls; shared host; rounded display but changes from unrounded endpoint medians.',
                     'Every original row retains paired-ratio min/median/max and per-repeat dispositions; mixed directions are not a stable improvement or regression claim.',
                     'The combined runtime patch does not attribute changes to individual owners. Tiny identity client changes are not gzip savings or causal evidence.',
                     'Requested bytes are cumulative requests, not retained memory/RSS. Allocations are request counts.',
                     'No instruction, shipping CPU, latency, throughput or syscall/wake result is supplied by native counters; CPU/cold campaigns are separate.']}
output = Q / 'architecture-c12b-native-analysis.json'
with output.open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')


def workload(row):
    c = row['cell']; size = c['payload_bytes']
    label = '0 B' if size == 0 else f'{size//1048576} MiB' if size % 1048576 == 0 else f'{size//1024} KiB'
    return f"{c['shape']}, {label}, {c['compression']}, {'TLS' if c['tls'] else 'plaintext'}, {c['in_flight']} in flight"


def values(row):
    b, a = row['before'], row['current']
    if row['metric'] == 'allocations': return f'{b:,.2f}', f'{a:,.2f}'
    scale, unit = (1048576, 'MiB') if max(b, a) >= 1048576 else (1024, 'KiB')
    return f'{b/scale:,.2f} {unit}', f'{a/scale:,.2f} {unit}'


def directions(row):
    return ', '.join(f'{key}:{value}' for key, value in row['dispositions'].items())


lines = ['# Native allocation results — terminal summary analysis', '',
         f'Current `{SOURCE[:8]}`; before `{BASELINE[:8]}`. **1,088 captures; 40,800 successful RPCs** (20,400/source).',
         'Offered/dispatched/completed/successful counts reconcile in the terminal summary; failures, timeouts, overflow, unstarted and unfinished are zero.',
         'This analysis checks terminal state/source/pin/summary identity; the final evidence validator will revalidate raw captures.', '',
         '## Current versus tonic/prost', '',
         'Equal-Prost on both endpoints. Requested bytes/RPC; lower is better. Worst two relative increases and largest absolute savings per side.', '',
         '| Selection | Side | Workload | Current | tonic/prost | Difference | Paired repeats |',
         '|---|---|---|---:|---:|---:|---|']
for side in ['client','server']:
    group = selections[f'tonic:requested_bytes:{side}']
    for key, label in [('worst_relative_increase','Loss'),('largest_absolute_savings','Saving')]:
        for row in group[key]:
            before, after = values(row)
            lines.append(f'| {label} | {side} | {workload(row)} | {after} | {before} | {row["change_percent"]:+.2f}% | {directions(row)} |')
lines += ['', '## Source changes', '', 'Requested bytes/RPC. Worst two relative increases and largest absolute savings per side.', '',
          '| Selection | Side | Workload | Before | Current | Change | Paired repeats |', '|---|---|---|---:|---:|---:|---|']
for side in ['client','server']:
    group = selections[f'source:requested_bytes:{side}']
    for key,label in [('worst_relative_increase','Largest increase'),('largest_absolute_savings','Largest saving')]:
        for row in group[key]:
            before, after = values(row)
            lines.append(f'| {label} | {side} | {workload(row)} | {before} | {after} | {row["change_percent"]:+.2f}% | {directions(row)} |')
lines += ['', '## Allocation counts', '', 'Allocation requests/RPC. Worst relative increase and largest absolute saving per side in each comparison.', '',
          '| Comparison | Selection | Side | Workload | Reference | Current | Change | Paired repeats |', '|---|---|---|---|---:|---:|---:|---|']
for basis in ['source','tonic']:
    for side in ['client','server']:
        group=selections[f'{basis}:allocations:{side}']
        for key,label in [('worst_relative_increase','Largest increase'),('largest_absolute_savings','Largest saving')]:
            for row in group[key][:1]:
                before,after=values(row)
                lines.append(f'| {basis} | {label} | {side} | {workload(row)} | {before} | {after} | {row["change_percent"]:+.2f}% | {directions(row)} |')
lines += ['', '## Separate pbrs interop routes', '', '| Side | Pair | Workload | Current | tonic/prost | Difference | Paired repeats |', '|---|---|---|---:|---:|---:|---|']
for row in interop[:4]:
    before,after=values(row)
    lines.append(f'| {row["side"]} | {"/".join(row["cell"]["pair"])} | {workload(row)} | {after} | {before} | {row["change_percent"]:+.2f}% | {directions(row)} |')
lines += ['', result['interop_scope'], '', '## Scope and limits', '',
          f'All **{len(higher(source))} higher source-cost groups** and **{len(higher(tonic))} higher tonic-cost groups** remain in the companion JSON with original ranges/dispositions, including increases below2%. Each group is an endpoint/cell/metric aggregate, not a per-repeat pass count.',
          'Worst relative increase selection is not a significance test. Native context-switch diagnostics do not establish scheduling advantage.',
          *result['limits'], '', 'CPU and cold-process tables are pending their actual terminal summaries. No new performance result is inferred from source or test-profile type layout.']
with (Q / 'architecture-c12b-native-tables.md').open('x') as stream: stream.write('\n'.join(lines)+'\n')
print(json.dumps({'state': 'completed', 'qualified': False, 'captures':1088, 'successful_rpcs':40800,
                 'higher_source_groups':len(higher(source)), 'higher_tonic_groups':len(higher(tonic)),
                 'json':str(output), 'tables':str(Q/'architecture-c12b-native-tables.md')}))
