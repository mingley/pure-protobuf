# Workspace final repository checkpoint — actual fixture correction, gate pending

Production/measurement source remains `7c02eb387a6785d6e914146babe34f0902a6dd62`.
The actual final workspace repository is `8144576f74bcf290951a65235e3bb50f24710b71`,
tree `2a1613b82a8bdaf6c96c004d0bfd262bca37bf20`. They are distinct commits.
Original pins remain4eaac994...; runtime production src tree remains9a5770b1....
No final workspace pass is claimed in this preparation note.

Both old runtime-source workspace attempts remain FAILED, each3,811 passed,
1 failed,9 ignored,144 summaries. The first failed the documentation link target
because sparse checkout excluded tracked evidence. Complete materialization fixed
that setup issue without changing source. The second passed documentation but
failed `lb_selection_skips_unregistered_and_typed` because the test observed the
registry and selected a policy in separate operations around concurrent default
registration. Production selection itself was correctly locked.

The controlled registry replay actually compiled and failed0/1 on the stale
observation assertion. The repaired diagnostic passed1/0, and the full corrected
service_config target passed29/0 with four threads; strict all-feature/all-target
Clippy and formatting passed. Source/ELF manifests, logs and independent review
are preserved in the31 pinned fixture references. This is a detecting fixture-race
control, not a reproduced production locking defect.

Commit8144576f changes only pbrs-grpc/tests/service_config.rs versus prior
repository33eaf842. The corrected test checks a unique unknown policy negatively,
explicitly ensures defaults, checks typed pick-first options positively, and keeps
the bare-config None case. The final test SHA-256 is
a2cca2774b42c6f4794b66df4b6dc3fdfaef3f5641a4eeeedd58de82c22f97e3.
No diagnostic target was committed. The six living-document edits were excluded.

Compared with measured runtime7c02, exactly12 Git paths differ: this fixture,
the evidence index and ten files of the two prior automatically published old-Beb
soak capsules. Every other Git blob, mode and size matches, including production,
codegen, benchmarks, manifests and locks. Final runner f70c4bdc... and inputs8d0a0b...
are separately prepared; their full physical checkout verification before/after
and final command result must become actual records before qualification.

The final command/limits remain unchanged: all workspace/features, no-fail-fast,
jobs2, test threads4,7,200-second limit and8GiB entry guard. A new final state labels
actual repository8144 and runtime7c02 separately and preserves all eight references
to the two failed attempts. Only the new runtime/repository phase-map schema may
select it. Existing counters/ASAN remain source7c02 and are reused through explicit
all-Git-blob equivalence; no source label is rewritten to pretend they ran at8144.
The workspace-final soak generation likewise distinguishes both source pins and
reuses the actual original27-case deadline worker/build/preview. No day result is
established by this checkpoint.
