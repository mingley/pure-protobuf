# Final repository evidence — preparation only

Measured runtime: `7c02eb387a6785d6e914146babe34f0902a6dd62`.
Final workspace repository: `8144576f74bcf290951a65235e3bb50f24710b71`.
The second value is the actual test-fixture-only repository checkpoint; it must
never be relabeled as the measured runtime. Their full Git blob/mode/size maps
must agree except the registry test fixture and eleven already published old-soak
files/index changes. Production, codegen, benchmarks, manifests and locks match.

Neither the final workspace, writer nor packager was executed by this preparer.
No new complete-workspace pass is claimed. Both earlier failed attempts remain
immutable: 3,811/1/9 each, first documentation setup, then registry fixture race.
The detecting registry red 0/1, corrected diagnostic 1 + full target 29, strict lint,
source snapshots and independent review are retained in the 31 pinned references.

The root-granted final runner checks the complete physical tracked checkout
before and after the identical full workspace command. It requires jobs 2,
workers 4, 7,200-second limit and 8 GiB entry headroom. Final state/proofs identify
actual repository 8144, runtime 7c02 and original pins 4ea separately. The canonical
seven measured phase states remain 7c02. No ASAN/performance rerun is inferred or
needed to establish identical production blobs; reuse is explicitly scoped.

## After the actual final workspace pass

Keep every failed state/log, both final equivalence proofs, all fixture evidence,
Q build/binary copies and cleanup inventories. Complete authorized cache cleanup
before writer; a file observed as present at writer time must stay unchanged
through packaging. Inaccessible process selectors never establish global quiescence.
Use the new final phase map; older failed workspace state names cannot substitute.
Then root may separately grant this writer command:

```sh
python3 work/qualification/architecture-c12c-write-results-v4.py \
  --execute \
  --pins work/qualification/architecture-c12c-source-pins.json \
  --pins-sha256 4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af \
  --checkout work/architecture-c12c \
  --phase-map work/qualification/architecture-c12c-evidence-phase-map-workspace-final.json \
  --require-cold \
  --router-causal-summary work/qualification/architecture-c12c-router-causal-summary.json \
  --router-causal-summary-sha256 1a66eb3364d08c959cbf44d83d6e756f94f3e090d37dab98e0c706c75bb856f5
```

`--checkout` names the measured runtime checkout. Actual workspace qualification
uses work/architecture-c12c-workspace-final from the validated state/proofs. The
new result labels these sources separately and derives workspace counts from the
actual passed final record. Canonical 1,448/44,904 remains separate from the actual
Router control 48 / 1,800; no stale or projected counts replace actual records.
Destination remains docs/evidence/grpc-deadlines-20261024/results.json.
Existing output or day-snapshot names abort rather than overwrite.

## Documentation and package

Only after root grants, finalize the six living documents and new capsule README
from actual final counts/day observations. Make an immutable publication plan with
runtime source 7c02, finalized true, qualified false, and exact hashes of all
reviewed docs plus capsule README/results. Preserve every old capsule/marker.
This result's source remains measured runtime 7c02; its workspace repository field
is actual 8144. The raw archive adds the actual final fixture/patch and repository
metadata separately from original measured runtime snapshots.

```sh
python3 work/qualification/package-architecture-c12c-evidence-workspace-final.py \
  --execute \
  --pins work/qualification/architecture-c12c-source-pins.json \
  --pins-sha256 4eaac994f6ec4712491254a9162e6ae4ed78d8f710816a5d052cba142b0ff4af \
  --checkout work/architecture-c12c \
  --phase-map work/qualification/architecture-c12c-evidence-phase-map-workspace-final.json \
  --require-cold \
  --published-plan work/qualification/architecture-c12c-final-publication-plan.json
```

The packager independently revalidates final workspace equivalence and every
result input, and checks the root production/fixture bytes against the tested
repository 8144. Reviewed root docs may differ. It includes stable Q architecture-c12*
source/commands/logs/profiles/counters/preparations; live resource-* trees remain
outside selection. ELF bytes are omitted, retaining hashes/provenance. The checker
requires regular local manifest/archive files and safe regular tar members;
it checks hashes without extraction. Root owns commits/push.

Current days use the exact workspace-final namespaces confirmed by soak_prepare:
resource-architecture-c12c-workspace-final-day/campaign/{progress,report}.json,
and flat resource-architecture-c12c-workspace-final-deadline-day/{progress,report}.json.
Their launch/supervisor-state/termination/publication remain at each live parent.
Static launch snapshots and deadline terminal are captured under the corresponding
architecture-c12c-workspace-final prefix. Runtime7c02 and repository 8144 remain
separate launch metadata. Original 7c02 preparation/preview and failed workspace-
complete preparation are retained separately. No current day has launched yet.
