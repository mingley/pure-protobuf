//! Opt-in GN-03 source descriptor sharing; defaults and flat includes stay stable.
#![cfg(feature = "codegen")]
#![allow(
    clippy::disallowed_methods,
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::panic,
    clippy::too_many_lines,
    unreachable_pub,
    reason = "synchronous generated-consumer regression tests"
)]

use std::collections::BTreeMap;
use std::path::PathBuf;
use std::process::Command;

const HELPER: &str = "__pbrs_shared_descriptors.rs";

fn varint(out: &mut Vec<u8>, mut value: u64) {
    while value >= 128 {
        out.push(u8::try_from(value & 127).unwrap() | 128);
        value >>= 7;
    }
    out.push(u8::try_from(value).unwrap());
}

fn field_bytes(out: &mut Vec<u8>, number: u32, value: &[u8]) {
    varint(out, (u64::from(number) << 3) | 2);
    varint(out, u64::try_from(value.len()).unwrap());
    out.extend_from_slice(value);
}

fn field_string(out: &mut Vec<u8>, number: u32, value: &str) {
    field_bytes(out, number, value.as_bytes());
}

fn field_number(out: &mut Vec<u8>, number: u32, value: u64) {
    varint(out, u64::from(number) << 3);
    varint(out, value);
}

fn schema(name: &str, package: &str, message: &str, field: &str, kind: u64) -> Vec<u8> {
    let mut f = Vec::new();
    field_string(&mut f, 1, field);
    field_number(&mut f, 3, 1);
    field_number(&mut f, 4, 1);
    field_number(&mut f, 5, kind);
    let mut m = Vec::new();
    field_string(&mut m, 1, message);
    field_bytes(&mut m, 2, &f);
    let mut file = Vec::new();
    field_string(&mut file, 1, name);
    field_string(&mut file, 2, package);
    field_bytes(&mut file, 4, &m);
    field_string(&mut file, 12, "proto3");
    file
}

fn fixture() -> Vec<Vec<u8>> {
    vec![
        schema("first.proto", "first", "First", "id", 5),
        schema("second.proto", "second", "Second", "label", 9),
    ]
}

fn generate(files: &[Vec<u8>], targets: &[&str], options: &str) -> Result<BTreeMap<String, String>, pbrs::codegen::CodegenError> {
    let mut request = Vec::new();
    for target in targets { field_string(&mut request, 1, target); }
    if !options.is_empty() { field_string(&mut request, 2, options); }
    for file in files { field_bytes(&mut request, 15, file); }
    pbrs::codegen::generate_from_code_generator_request(&request).map(|files| files.into_iter().collect())
}

fn compile(name: &str, generated: &BTreeMap<String, String>, source: &str, features: &[&str], succeeds: bool) -> String {
    let root = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let out = root.join("target/gn03-tests").join(name);
    if let Err(error) = std::fs::remove_dir_all(&out) {
        assert_eq!(error.kind(), std::io::ErrorKind::NotFound, "{error}");
    }
    std::fs::create_dir_all(out.join("src")).unwrap();
    for (name, value) in generated {
        let path = out.join(name);
        std::fs::create_dir_all(path.parent().unwrap()).unwrap();
        std::fs::write(path, value).unwrap();
    }
    std::fs::write(out.join("Cargo.toml"), format!(
        "[package]\nname = \"gn03-{name}\"\nversion = \"0.0.0\"\nedition = \"2021\"\n[workspace]\n[dependencies]\nrenamed_pbrs = {{ package = \"pbrs\", path = {root:?}, default-features = false, features = {features:?} }}\n"
    )).unwrap();
    std::fs::write(out.join("src/main.rs"), source).unwrap();
    let result = Command::new("cargo")
        .args(["run", "--offline", "--quiet"])
        .current_dir(&out)
        .env("CARGO_TARGET_DIR", root.join("target/integration-consumers"))
        .env("CARGO_BUILD_JOBS", "1")
        .output().unwrap();
    let stderr = String::from_utf8_lossy(&result.stderr).into_owned();
    assert_eq!(result.status.success(), succeeds, "{stderr}");
    stderr
}

#[test]
fn opt_in_embeds_one_literal_and_default_single_output_remain_exact() {
    let files = fixture();
    let targets = ["first.proto", "second.proto"];
    let default = generate(&files, &targets, "stubs=none").unwrap();
    assert_eq!(default.values().map(|s| s.matches("pub const FILE_DESCRIPTOR_SET: &[u8] = &[").count()).sum::<usize>(), 2);
    let before = PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("target/gn03-tests/default-output");
    std::fs::create_dir_all(&before).unwrap();
    for (name, source) in &default {
        std::fs::write(before.join(name), source).unwrap();
    }
    let shared = generate(&files, &targets, "stubs=none,shared_descriptor_set=true").unwrap();
    assert_eq!(shared.values().map(|s| s.matches("pub const FILE_DESCRIPTOR_SET: &[u8] = &[").count()).sum::<usize>(), 1);
    assert!(shared.contains_key(HELPER));
    assert!(shared["mod.rs"].contains("mod __pbrs_shared_descriptors"));
    for target in ["first.rs", "second.rs"] {
        assert!(shared[target].contains("crate::__pbrs_shared_descriptors::FILE_DESCRIPTOR_SET"));
        assert!(shared[target].contains("crate::__pbrs_shared_descriptors::generated_pool()"));
    }
    assert_eq!(default, generate(&files, &targets, "stubs=none,shared_descriptor_set=false").unwrap());
    assert_eq!(
        generate(&files, &["first.proto"], "stubs=none").unwrap(),
        generate(&files, &["first.proto"], "stubs=none,shared_descriptor_set=true").unwrap()
    );
}

#[test]
fn shared_pool_is_lazy_and_reflection_json_text_and_binary_are_unchanged() {
    let generated = generate(&fixture(), &["first.proto", "second.proto"], "stubs=none,shared_descriptor_set=true,runtime_crate=renamed_pbrs").unwrap();
    compile("runtime", &generated, r#"
include!("../mod.rs");
fn main() {
    use renamed_pbrs::{Parse, Serialize};
    assert!(__pbrs_shared_descriptors::POOL.get().is_none());
    let mut first = first::First::new();
    first.set_id(41);
    let wire = first.serialize().unwrap();
    assert_eq!(first::First::parse(&wire).unwrap().id(), 41);
    assert!(__pbrs_shared_descriptors::POOL.get().is_none());
    assert_eq!(first.to_json().unwrap(), "{\"id\":41}");
    assert_eq!(first::First::from_json("{\"id\":41}").unwrap().id(), 41);
    let text = first.to_text().unwrap();
    assert_eq!(first::First::from_text(&text).unwrap().id(), 41);
    let pool = __pbrs_shared_descriptors::POOL.get().unwrap();
    assert!(pool.get_message("first.First").is_some());
    assert!(pool.get_message("second.Second").is_some());
    assert!(std::sync::Arc::ptr_eq(pool, &__pbrs_shared_descriptors::generated_pool()));
    assert!(std::ptr::eq(first::FILE_DESCRIPTOR_SET, second::FILE_DESCRIPTOR_SET));
    assert!(std::ptr::eq(first::FILE_DESCRIPTOR_SET, __pbrs_shared_descriptors::FILE_DESCRIPTOR_SET));
    let parsed = renamed_pbrs::DescriptorPool::from_file_descriptor_set(first::FILE_DESCRIPTOR_SET).unwrap();
    assert!(parsed.get_message("second.Second").is_some());
    let mut second = second::Second::new();
    second.set_label("payload");
    assert_eq!(second::Second::from_json(&second.to_json().unwrap()).unwrap().label(), "payload");
    assert_eq!(second::Second::from_text(&second.to_text().unwrap()).unwrap().label(), "payload");
}
"#, &["reflect", "json", "text"], true);
    let stderr = compile("flat-missing-registry", &generated, "mod first { include!(\"../first.rs\"); } fn main() {}", &["reflect", "json", "text"], false);
    assert!(stderr.contains("__pbrs_shared_descriptors"), "{stderr}");
}

#[test]
fn reflection_free_and_single_flat_consumers_do_not_require_shared_metadata() {
    let generated = generate(&fixture(), &["first.proto", "second.proto"], "stubs=none,no_reflect=true,shared_descriptor_set=true,runtime_crate=renamed_pbrs").unwrap();
    assert!(!generated.contains_key(HELPER));
    for source in generated.values() {
        assert!(!source.contains("FILE_DESCRIPTOR_SET"));
        assert!(!source.contains("generated_pool"));
        assert!(!source.contains("DescriptorPool"));
    }
    compile("no-reflect", &generated, r#"
mod first { include!("../first.rs"); }
fn main() {
    use renamed_pbrs::{Parse, Serialize};
    let mut m = first::First::new(); m.set_id(43);
    assert_eq!(first::First::parse(&m.serialize().unwrap()).unwrap().id(), 43);
}
"#, &[], true);
    let single = generate(&fixture(), &["first.proto"], "stubs=none,shared_descriptor_set=true,runtime_crate=renamed_pbrs").unwrap();
    compile("single-flat", &single, r#"
mod first { include!("../first.rs"); }
fn main() { let mut m = first::First::new(); m.set_id(47); assert_eq!(m.id(), 47); }
"#, &["reflect", "json", "text"], true);
}

#[test]
fn reserved_outputs_packages_and_shared_pool_conflicts_fail_explicitly() {
    let files = fixture();
    for option in ["shared_pool=true", "include_file=__pbrs_shared_descriptors.rs", "include_file=./__pbrs_shared_descriptors.rs"] {
        let error = generate(&files, &["first.proto", "second.proto"], &format!("stubs=none,shared_descriptor_set=true,{option}")).unwrap_err();
        assert!(error.to_string().contains("shared_descriptor_set"), "{error}");
    }
    for (name,package) in [
        ("__pbrs_shared_descriptors.proto", "collision"),
        ("nested/__pbrs_shared_descriptors.proto", "collision"),
        ("first.proto", "__pbrs_shared_descriptors.child"),
    ] {
        let colliding = vec![schema(name, package, "First", "id", 5), files[1].clone()];
        let error = generate(&colliding, &[name, "second.proto"], "stubs=none,shared_descriptor_set=true").unwrap_err();
        assert!(error.to_string().contains("shared_descriptor_set"), "{error}");
    }
}
