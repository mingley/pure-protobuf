"""Freeze a counters-off release benchmark, separately from allocator builds."""
import argparse
import hashlib
import importlib.util
import json
from pathlib import Path
import shutil
import subprocess


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    source = args.source.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    spec = importlib.util.spec_from_file_location("shipping_builder", source / "scripts/build-rpc-bench.py")
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    pin = helper.source_pin()
    command = ["cargo", "build", "--locked", "--release", "--manifest-path", "rpc-bench/Cargo.toml", "--message-format=json"]
    with (output / "build.stdout.jsonl").open("w") as stdout, (output / "build.stderr.log").open("w") as stderr:
        result = subprocess.run(command, cwd=source, stdout=stdout, stderr=stderr)
    assert result.returncode == 0, "build failed; logs retained"
    assert pin == helper.source_pin(), "source changed during build"
    messages = [json.loads(line) for line in (output / "build.stdout.jsonl").read_text().splitlines()]
    executable = helper.artifact(messages)
    shutil.copy2(executable, output / "rpc-bench")
    record = dict(schema="pbrs.rpc-bench-shipping-build.v1", source=pin, command=command,
                  allocation_counts=False, exit_code=result.returncode,
                  binary_sha256=digest(output / "rpc-bench"), build_executable=str(executable),
                  tools={tool: subprocess.check_output([tool, "--version"], text=True).strip() for tool in ["cargo", "rustc"]},
                  files={name: digest(output / name) for name in ["build.stdout.jsonl", "build.stderr.log"]})
    (output / "build.json").write_text(json.dumps(record, indent=2) + "\n")
    print(output / "build.json", flush=True)


if __name__ == "__main__":
    main()
