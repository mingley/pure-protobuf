#!/usr/bin/env python3
"""Pure synthetic C13 publication controls; no real gates, Git or diagnostics."""
from pathlib import Path
from types import SimpleNamespace
import argparse
import ast
import copy
import datetime
import hashlib
import importlib.util
import io
import json
import tarfile
import tempfile

Q = Path(__file__).resolve().parent
PUBLISHER = Q / 'architecture-c13-publish-soak.py'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True); args = parser.parse_args()
    if args.output.exists(): raise ValueError('Preserve earlier controls.')
    code = PUBLISHER.read_text(); tree = ast.parse(code)
    spec = importlib.util.spec_from_file_location('c13_publisher_synthetic', PUBLISHER)
    m = importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
    actual_common, actual_binding = m.COMMON, m.COMMON_SHA256
    results = []
    def case(label, action, expected='accepted'):
        try: action(); actual = 'accepted'
        except (ValueError, KeyError, TypeError, OSError): actual = 'rejected'
        assert actual == expected, (label, actual, expected)
        results.append({'case': label, 'expected': expected, 'actual': actual})
    with tempfile.TemporaryDirectory(prefix='c13-publisher-synthetic-', dir='/tmp') as folder:
        root = Path(folder); m.ROOT = root; m.Q = root / 'qualification'; m.Q.mkdir()
        m.SOURCE_FILE = m.Q / 'architecture-c13-soak-source.json'
        m.SOURCE_FILE.write_text('{"synthetic": "source"}\n')
        gates = m.Q / 'architecture-c13-soak-gates.json'; gates.write_text('{"synthetic": "gates"}\n')
        report = m.Q / 'report.json'; report.write_text('{"synthetic": "closed report"}\n')
        elf = m.Q / 'worker'; elf.write_bytes(b'\x7fELFsynthetic executable bytes')
        m.COMMON = m.Q / 'architecture-c13-soak-common.py'; m.COMMON.write_text('# synthetic helper\n')
        publisher_copy = m.Q / PUBLISHER.name; publisher_copy.write_text(code); m.__file__ = str(publisher_copy)
        source_sha = m.sha(m.SOURCE_FILE)
        output = m.Q / 'resource-architecture-c13-day'; output.mkdir()
        bundle = {'source': m.SOURCE, 'kind': 'resource', 'generation': 'synthetic-generation-20261025',
                  'launch_utc': '2026-10-25T00:00:00+00:00', 'output': str(output),
                  'outcome': {'state': 'passed', 'qualified': False, 'duration_actual_seconds': 86400.1,
                              'completed_cycles': 10},
                  'files': [m.reference(path) for path in [m.SOURCE_FILE, gates, report, elf]]}
        case('source-bound closed terminal bundle', lambda: m.identity(bundle, 'resource', source_sha))
        for label, patch in [
            ('wrong runtime source', {'source': '0' * 40}),
            ('wrong workload kind', {'kind': 'deadline'}),
            ('unsafe generation', {'generation': '../unsafe-generation'}),
            ('short generation', {'generation': 'short'}),
            ('naive launch time', {'launch_utc': '2026-10-25T00:00:00'}),
            ('wrong owned output', {'output': str(root / 'elsewhere')}),
            ('running record is not terminal', {'outcome': {'state': 'running', 'qualified': False}}),
            ('qualified claim rejected', {'outcome': {'state': 'passed', 'qualified': True}}),
            ('missing gate record', {'files': [m.reference(m.SOURCE_FILE)]}),
        ]:
            case(label, lambda patch=patch: m.identity(bundle | patch, 'resource', source_sha), 'rejected')
        case('changed source pin', lambda: m.identity(bundle, 'resource', '0' * 64), 'rejected')
        for state in ['failed', 'incomplete']:
            case(state + ' record remains publishable evidence',
                 lambda state=state: m.identity(bundle | {'outcome': {'state': state, 'qualified': False}}, 'resource', source_sha))
        context = m.identity(bundle, 'resource', source_sha)
        assert context['evidence'].name.endswith('20261025-933bf877-synthetic-ge')
        assert m.sparse_patterns(context['evidence'])[:3] == ['/*', '!/docs/evidence/*', '/docs/evidence/README.md']

        case('unsafe archive traversal', lambda: m.member_name(m.Q / '../outside'), 'rejected')
        case('outside archive root', lambda: m.member_name(root / 'private'), 'rejected')
        symlink = m.Q / 'symlink'; symlink.symlink_to(report)
        case('symlink input rejected', lambda: m.member_name(symlink), 'rejected')
        helper = root / 'work/run-rust'; helper.parent.mkdir(); helper.write_text('synthetic helper')
        assert m.member_name(helper) == 'helpers/run-rust'
        old_prepared = m.PREPARED
        m.PREPARED = False
        case('unfinalized helper cannot execute', lambda: m.common(), 'rejected')
        m.PREPARED = True; m.COMMON_SHA256 = '0' * 64
        case('changed common checksum rejected', lambda: m.common(), 'rejected')
        m.PREPARED, m.COMMON_SHA256 = old_prepared, actual_binding

        dest = m.artifacts(bundle, context, source_sha)
        inputs = json.loads((output / 'publication-snapshot/inputs.json').read_text())
        assert inputs['omitted_verified_elf_bytes'][0]['sha256'] == m.sha(elf)
        assert not (output / 'publication-snapshot/qualification/worker').exists()
        assert json.loads((dest / 'results.json').read_text())['state'] == 'passed'
        results.append({'case': 'synthetic immutable capsule omits verified ELF bytes', 'expected': 'accepted', 'actual': 'accepted'})
        assert '86,400.10' in (dest / 'README.md').read_text()
        for state, reason in [('failed', 'synthetic assertion failed'), ('incomplete', 'interrupted')]:
            own = root / ('terminal-' + state); own.mkdir()
            terminal = bundle | {'outcome': {'state': state, 'qualified': False, 'reason': reason}}
            if state == 'failed':
                terminal['outcome'].update(duration_actual_seconds=91.5, last_completed_cycle_elapsed_seconds=30.25,
                                           duration_measurement='Supervisor process wall after failure; not completed workload duration.')
            terminal_dest = m.artifacts(terminal, context | {'output': own}, source_sha)
            assert json.loads((terminal_dest / 'results.json').read_text())['state'] == state
            assert 'Reason: ' + reason in (terminal_dest / 'README.md').read_text()
            if state == 'failed':
                readme = (terminal_dest / 'README.md').read_text()
                assert '91.50' in readme and 'Last completed cycle: 30.25 seconds.' in readme
                assert terminal['outcome']['duration_measurement'] in readme
            results.append({'case': state + ' reason retained in capsule and readable summary',
                            'expected': 'accepted', 'actual': 'accepted'})
        bad_context = context | {'output': root / 'bad-snapshot'}; bad_context['output'].mkdir()
        bad = copy.deepcopy(bundle); bad['files'][0]['sha256'] = '0' * 64
        case('changed closed input rejected', lambda: m.snapshot(bad, bad_context, source_sha), 'rejected')
        duplicate_context = context | {'output': root / 'duplicate-snapshot'}; duplicate_context['output'].mkdir()
        case('duplicate evidence references rejected', lambda: m.snapshot(bundle | {'files': bundle['files'] * 2}, duplicate_context, source_sha), 'rejected')

        check_root = root / 'checker'; check_root.mkdir()
        namespace = {'__file__': str(check_root / 'check.py'), '__name__': 'synthetic_checker'}
        exec(compile(m.CHECKER, '<synthetic-checker>', 'exec'), namespace)
        def archive(names):
            target = check_root / 'raw.tar.gz'; raw = b'synthetic member'
            with tarfile.open(target, 'w:gz') as stream:
                for name in names:
                    info = tarfile.TarInfo(name); info.size = len(raw); stream.addfile(info, io.BytesIO(raw))
            entries = [{'path': name, 'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()} for name in set(names)]
            manifest = {'schema': 'pbrs.c13-soak-capsule.v1', 'qualified': False,
                        'archive': {'name': 'raw.tar.gz', 'bytes': target.stat().st_size, 'sha256': m.sha(target)},
                        'files': entries, 'logical_bytes': sum(row['bytes'] for row in entries)}
            (check_root / 'manifest.json').write_text(json.dumps(manifest)); namespace['main']()
        case('safe standalone checker', lambda: archive(['safe/member']))
        case('checker rejects traversal without extraction', lambda: archive(['../escape']), 'rejected')
        case('checker rejects duplicate tar member', lambda: archive(['safe/member', 'safe/member']), 'rejected')

        # Tiny thresholds exercise the production split/checker path without
        # generating a large file or using its production 64 MiB part size.
        threshold, part_size = m.SPLIT_THRESHOLD, m.PART_SIZE
        m.SPLIT_THRESHOLD, m.PART_SIZE = 2048, 1024
        try:
            own = root / 'split-capsule'; own.mkdir()
            split = m.artifacts(bundle, context | {'output': own}, source_sha)
            manifest = json.loads((split / 'manifest.json').read_text())
            parts = manifest['archive']['parts']
            assert len(parts) > 1 and all(row['bytes'] <= 1024 for row in parts)
            assert not (split / 'raw.tar.gz').exists()
            staged = Path(manifest['archive']['retained_staging_path'])
            assert staged.exists() and m.sha(staged) == manifest['archive']['sha256']
            results.append({'case': 'tiny split archive preserves staging and verifies parts plus overall hash',
                            'expected': 'accepted', 'actual': 'accepted'})
            checker = {'__file__': str(split / 'check.py'), '__name__': 'synthetic_split_checker'}
            exec(compile(m.CHECKER, '<synthetic-split-checker>', 'exec'), checker)
            first = split / parts[0]['name']; original = first.read_bytes(); first.write_bytes(original + b'bad')
            case('changed split part rejected without extraction', checker['main'], 'rejected')
            first.write_bytes(original)
            bad = copy.deepcopy(manifest); bad['archive']['parts'][0]['name'] = '../escape'
            (split / 'manifest.json').write_text(json.dumps(bad))
            case('split part path traversal rejected', checker['main'], 'rejected')
            (split / 'manifest.json').write_text(json.dumps(manifest))
            bad = copy.deepcopy(manifest); bad['archive']['sha256'] = '0' * 64
            (split / 'manifest.json').write_text(json.dumps(bad))
            case('split overall hash mismatch rejected', checker['main'], 'rejected')
        finally:
            m.SPLIT_THRESHOLD, m.PART_SIZE = threshold, part_size
        cap = root / 'synthetic-github-cap'; cap.mkdir(); (cap / 'file').write_bytes(b'x' * 1024)
        limit = m.GIT_FILE_LIMIT; m.GIT_FILE_LIMIT = 1024
        try: case('artifact reaching GitHub cap rejected before Git', lambda: m.check_git_sizes(cap), 'rejected')
        finally: m.GIT_FILE_LIMIT = limit

        git_function = m.git
        rows = []
        for file in dest.iterdir():
            raw = file.read_bytes()
            digest = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
            rows.append(f"100644 blob {digest}\t{context['evidence']}/{file.name}")
        remote = {'rows': '\n'.join(rows), 'index': context['marker']}
        def remote_git(*argv, **kwargs):
            if argv[0] == 'ls-tree': value = remote['rows']
            elif argv[0] == 'show': value = remote['index']
            else:
                assert argv[0] == 'hash-object'
                raw = Path(argv[1]).read_bytes()
                value = hashlib.sha1(f'blob {len(raw)}\0'.encode() + raw).hexdigest()
            return SimpleNamespace(stdout=value)
        m.git = remote_git
        try:
            assert m.remote_matches(context, dest)
            results.append({'case': 'identical remote capsule and marker recognized', 'expected': 'accepted', 'actual': 'accepted'})
            remote['index'] = 'other publisher marker'
            case('remote capsule missing own marker rejected', lambda: m.remote_matches(context, dest), 'rejected')
            remote['index'] = context['marker']; remote['rows'] = remote['rows'].replace('100644 blob ', '120000 blob ', 1)
            case('remote conflicting file mode rejected', lambda: m.remote_matches(context, dest), 'rejected')
        finally:
            m.git = git_function

        # Git and sparse checkout are wholly mocked. Assert bounded normal pushes
        # and retained separate attempts; no actual Git/worktree/network runs.
        m.artifacts = lambda *args: dest
        m.remote_matches = lambda *args: False
        actual_run = m.subprocess.run
        git_calls = []
        def fake_run(argv, **kwargs):
            assert argv[:3] == ['git', 'sparse-checkout', 'set']
            return SimpleNamespace(returncode=0, stdout='', stderr='')
        m.subprocess.run = fake_run
        def retry_case(label, codes, expected, absent_source=False):
            own = root / label; own.mkdir()
            ctx = context | {'output': own, 'worktree': root / (label + '-worktree')}
            pushes, call_start = [], len(git_calls)
            def fake_git(*args, **kwargs):
                git_calls.append(args)
                if args[0] == 'merge-base' and absent_source:
                    return SimpleNamespace(returncode=1, stdout='', stderr='')
                if args[:2] == ('worktree', 'add'): Path(args[-2]).mkdir()
                if args[:2] == ('checkout', '--detach'):
                    index = Path(kwargs['cwd']) / 'docs/evidence/README.md'; index.parent.mkdir(parents=True); index.write_text('other publisher evidence\n')
                if args[0] == 'push':
                    code = codes[len(pushes)]; pushes.append(code)
                    return SimpleNamespace(returncode=code, stdout='synthetic push', stderr='')
                return SimpleNamespace(returncode=0, stdout='1' * 40 + '\n', stderr='')
            m.git = fake_git
            case(label, lambda: m.publish(bundle, ctx, source_sha), expected)
            state = json.loads((own / 'publication.json').read_text())
            assert len(pushes) == len(codes) and len(state['push_attempts']) == len(codes)
            assert state['state'] == ('published' if expected == 'accepted' else 'failed')
            commands = git_calls[call_start:]
            assert not any('--force' in command or 'reset' in command or 'rebase' in command for command in commands)
            assert all(Path(row['worktree']).exists() for row in state['push_attempts'])
            for row in state['push_attempts']:
                assert 'other publisher evidence' in (Path(row['worktree']) / 'docs/evidence/README.md').read_text()
        try:
            retry_case('first-normal-push-pass', [0], 'accepted')
            retry_case('three-normal-push-retries', [1, 1, 0], 'accepted')
            retry_case('three-normal-push-failures-preserved', [1, 1, 1], 'rejected')
            retry_case('source-absent-from-main-prevents-push', [], 'rejected', absent_source=True)
        finally:
            m.subprocess.run = actual_run
    loader = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == 'common')
    namespace = {}
    exec(compile(ast.Module(body=[loader], type_ignores=[]), '<optimized-synthetic-loader>', 'exec', optimize=1), namespace)
    case('optimized Python rejects before file access', namespace['common'], 'rejected')
    if m.PREPARED:
        assert m.sha(actual_common) == actual_binding
        ast.parse(actual_common.read_text())
        results.append({'case': 'frozen common binding verified by static hash only',
                        'expected': 'accepted', 'actual': 'accepted'})
    result = {'state': 'passed', 'qualified': False, 'synthetic_controls': True,
              'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'publisher_sha256': hashlib.sha256(PUBLISHER.read_bytes()).hexdigest(),
              'recipe_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'cases': results, 'common_terminal_policy_not_executed': True,
              'git_and_sparse_checkout_mocked': True, 'no_actual_build_gate_worktree_network_or_diagnostic': True}
    with args.output.open('x') as stream: json.dump(result, stream, indent=2); stream.write('\n')
    print(json.dumps({'state': 'passed', 'synthetic_cases': len(results), 'output': str(args.output)}))


if __name__ == '__main__': main()
