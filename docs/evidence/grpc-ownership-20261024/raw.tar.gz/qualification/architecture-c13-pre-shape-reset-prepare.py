from pathlib import Path
import difflib,hashlib,json
root=Path('/workspace/pure-protobuf'); out=root/'work/qualification/architecture-c13-pre-shape-reset-prepared';out.mkdir(exist_ok=False)
files={}
def replace(s,a,b):
 assert a in s,a[:120]
 return s.replace(a,b,1)
p='pbrs-grpc/src/server/deadline.rs'; old=(root/p).read_text();s=old
s=replace(s,'/// Reuses the call\'s cancellation allocation. Unlimited calls do not retain a\n/// backend response capability or allocate a timer.','/// Reuses the call\'s cancellation allocation. The service owner holds the\n/// backend response capability; only finite deadlines allocate a timer.')
s=replace(s,'    response: Option<DeadlineResponse>,\n','')
s=replace(s,'            response: None,\n','')
s=replace(s,'    pub(crate) fn tighten(&self, at: Option<Instant>, respond: &SendResponse) -> Option<Instant> {','    pub(crate) fn tighten(&self, at: Option<Instant>) -> Option<Instant> {')
s=replace(s,'''        // Cloning/dropping a backend capability can acquire engine locks, so
        // neither operation belongs inside the call-state lock.
        let mut capability = (flags & Self::ACTIVE == 0)
            .then(|| respond.deadline_response())
            .flatten();
''','')
s=replace(s,'''                if state.response.is_none() {
                    state.response = capability.take();
                }
''','')
s=replace(s,'        drop(capability);\n','')
s=replace(s,'            (state.response.take(), state.binlog.take())','            state.binlog.take()')
s=replace(s,'''        Option<DeadlineResponse>,
        Option<crate::binlog::CallLogger>,''','''        Option<crate::binlog::CallLogger>,''')
s=replace(s,'            state.response.take(),\n','')
s=replace(s,'struct Owner {\n    cancel: CancelOnDrop,','struct Owner {\n    cancel: CancelOnDrop,\n    response: Option<DeadlineResponse>,')
s=replace(s,'        self.cancel.flag().deadline.close();\n','        self.cancel.flag().deadline.close();\n        // Backend reference destruction belongs outside the call-state lock and\n        // before the cancellation allocation can return to its reuse slot.\n        drop(self.response.take());\n')
s=replace(s,'        cancel: CancelOnDrop::new(Arc::clone(&rpc.call_cancel)),\n','        cancel: CancelOnDrop::new(Arc::clone(&rpc.call_cancel)),\n        response: rpc.respond.deadline_response(),\n')
s=replace(s,'        let ServiceState { owner, service } = state;','        let ServiceState { mut owner, service } = state;')
s=replace(s,'        let expired = {','        let terminal = {')
s=replace(s,'                    return Poll::Ready(true);','                    return Poll::Ready(Some(CancellationReason::DeadlineExceeded));')
s=replace(s,'                    return Poll::Ready(false);','                    return Poll::Ready(None);')
s=replace(s,'                            return Poll::Ready(true);','                            return Poll::Ready(Some(CancellationReason::DeadlineExceeded));')
s=replace(s,'''                Poll::Pending
            })
            .await
        }; // Destroy service state before recovering/sending its terminal response.
        if expired {
            let status = Status::deadline_exceeded();
            let (capability, logger, carry, partial_web_frame) = flag.deadline.take_terminal();''','''                // Shape helpers get the first opportunity to observe a reset and
                // poll cancellation-aware handlers. A custom Service parked before
                // those helpers still needs a reset owner of its own.
                if let Some(response) = owner.response.as_mut() {
                    if let Poll::Ready(reset) = response.poll_reset(cx) {
                        flag.signal();
                        let reason = if reset.is_ok() {
                            CancellationReason::PeerReset
                        } else {
                            CancellationReason::TransportReset
                        };
                        return Poll::Ready(Some(reason));
                    }
                }
                Poll::Pending
            })
            .await
        }; // Destroy service state before recovering/sending its terminal response.
        if let Some(reason) = terminal {
            let expired = reason == CancellationReason::DeadlineExceeded;
            let status = if expired {
                Status::deadline_exceeded()
            } else {
                Status::cancelled()
            };
            let (logger, carry, partial_web_frame) = flag.deadline.take_terminal();''')
s=replace(s,'                        reason: CancellationReason::DeadlineExceeded,','                        reason,')
s=replace(s,'                    logger.log_trailer(&Metadata::new(), &status);','                    if expired {\n                        logger.log_trailer(&Metadata::new(), &status);\n                    } else {\n                        logger.log_cancel();\n                    }')
s=replace(s,'            if let Some(mut capability) = capability {','            if let (true, Some(capability)) = (expired, owner.response.as_mut()) {')
s=replace(s,'            cancel: CancelOnDrop::new(Arc::clone(&flag)),\n','            cancel: CancelOnDrop::new(Arc::clone(&flag)),\n            response: rpc.respond.deadline_response(),\n')
s=replace(s,'use crate::transport::h2::{DeadlineEnding, DeadlineResponse, SendResponse};','use crate::transport::h2::{DeadlineEnding, DeadlineResponse};')
files[p]=(old,s)
p='pbrs-grpc/src/server/rpc.rs';old=(root/p).read_text();s=replace(old,'                .and_then(|d| self.accepted_at.checked_add(d)),\n            &self.respond,','                .and_then(|d| self.accepted_at.checked_add(d)),');files[p]=(old,s)
p='pbrs-grpc/src/h2_backend/server.rs';old=(root/p).read_text();s=replace(old,'impl<B: Buf> DeadlineResponse<B> {\n','''impl<B: Buf> DeadlineResponse<B> {
    /// Observe stream cancellation before or after response headers, without
    /// taking ownership of the application's response writer.
    pub(crate) fn poll_reset(
        &mut self,
        cx: &mut Context,
    ) -> Poll<Result<Reason, crate::h2_backend::Error>> {
        self.inner.poll_reset(cx, proto::PollReset::Streaming)
    }

''');files[p]=(old,s)
p='pbrs-grpc/src/transport/h2.rs';old=(root/p).read_text();s=replace(old,'/// Surviving ownership used only after a finite call deadline is installed.','/// Service-owned response capability for peer reset and finite deadlines.')
s=replace(s,'impl DeadlineResponse {\n','''impl DeadlineResponse {
    pub(crate) fn poll_reset(&mut self, cx: &mut Context<'_>) -> Poll<Result<Reason, Error>> {
        self.0.poll_reset(cx).map(|result| result.map(Reason).map_err(Error))
    }

''');files[p]=(old,s)
patch=''
for p,(old,s) in files.items():
 dest=out/p;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_text(s)
 patch+=''.join(difflib.unified_diff(old.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/'+p,tofile='b/'+p))
(out/'production.patch').write_text(patch)
meta={'qualified':False,'state':'prepared_not_applied_or_compiled','files':[{'path':p,'before_sha256':hashlib.sha256(a.encode()).hexdigest(),'prepared_sha256':hashlib.sha256(b.encode()).hexdigest()} for p,(a,b) in files.items()]}
(out/'preparation.json').write_text(json.dumps(meta,indent=2)+'\n')
print(out)
