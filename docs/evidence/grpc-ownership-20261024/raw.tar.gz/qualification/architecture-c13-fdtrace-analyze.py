#!/usr/bin/env python3
"""Read-only analysis of the eight completed own-child fd-aware captures."""
import collections
import datetime
import hashlib
import json
from pathlib import Path
import re

Q=Path('/workspace/pure-protobuf/work/qualification')
P=Q/'architecture-c13-shipping-unary-fdtrace-captures'
START=re.compile(r'^(\d+)\s+(\d+\.\d+)\s+(\w+)\((.*)')
RESUME=re.compile(r'^(\d+)\s+(\d+\.\d+)\s+<\.\.\. (\w+) resumed>(.*)')

def ref(p):
    p=Path(p)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def analyze(p, summary):
    lines=p.read_text().splitlines()
    header=next(i for i,line in enumerate(lines) if line.startswith('% time'))
    events=[]
    pending={}
    for line_no,line in enumerate(lines[:header],1):
        m=START.match(line)
        if m:
            pid,stamp,name,args=m.groups()
            assert pid not in pending, (p,line_no,pending.get(pid))
            e=dict(thread_id=int(pid),syscall=name,start_line=line_no,args=args)
            events.append(e)
            if '<unfinished ...>' in line:pending[pid]=e
            else:e.update(end_line=line_no,result=line.rsplit(' = ',1)[-1])
        else:
            m=RESUME.match(line)
            if m:
                pid,stamp,name,rest=m.groups()
                assert pid in pending and pending[pid]['syscall']==name,(p,line_no,line)
                pending.pop(pid).update(end_line=line_no,result=rest.rsplit(' = ',1)[-1])
    entered=collections.Counter(e['syscall'] for e in events)
    terminal_unknown=collections.Counter()
    errors=collections.Counter()
    op=collections.Counter()
    fd=collections.Counter()
    futex_words={}
    per_thread=collections.defaultdict(collections.Counter)
    tcp_last=None
    tcp_switches=0
    for e in events:
        name=e['syscall'];args=e['args'];result=e.get('result')
        per_thread[str(e['thread_id'])][name]+=1
        if result is None or result.strip()=='?':
            terminal_unknown[name]+=1
            e['result_scope']='unresolved_at_termination'
        elif result.startswith('-1 ') or result.startswith('? ERESTART'):
            errors[name]+=1
            e['result_scope']='error_return_including_restart'
        else:e['result_scope']='returned'
        if name=='futex':
            m=re.match(r'([^,]+),\s*([^,]+),\s*([^,\s)]+)',args)
            assert m,(p,e)
            address,operation,expected=m.groups()
            op[operation]+=1
            e.update(futex_address=address,futex_operation=operation,futex_expected=expected)
            group=futex_words.setdefault(address,dict(operations=collections.Counter(),expected_values=collections.Counter(),threads=collections.Counter(),example_lines=[]))
            group['operations'][operation]+=1
            group['expected_values'][expected]+=1
            group['threads'][str(e['thread_id'])]+=1
            if len(group['example_lines'])<4:group['example_lines'].append(e['start_line'])
        if name in ('write','writev','sendto','recvfrom','epoll_wait','epoll_pwait','epoll_pwait2'):
            first=args.split('>,',1)[0]
            kind=('eventfd' if 'eventfd-' in first else 'tcp' if '<TCP' in first
                  else 'eventpoll' if 'anon_inode:[eventpoll]' in first
                  else 'file' if '</' in first else 'unavailable_or_other')
            fd[name+':'+kind]+=1
            e['fd_class']=kind
            if kind=='tcp':
                if tcp_last is not None and tcp_last!=e['thread_id']:tcp_switches+=1
                tcp_last=e['thread_id']
        e.pop('args')
    # Full trace includes two server calls interrupted without a determinate
    # return during ordinary endpoint teardown. Keep those separately from -C.
    names=set(entered)|set(summary['syscall_counts'])
    deltas={n:entered[n]-terminal_unknown[n]-summary['syscall_counts'].get(n,{}).get('calls',0) for n in names}
    assert all(v==0 for v in deltas.values()),(p,deltas)
    expected_errors={n:summary['syscall_counts'].get(n,{}).get('errors',0) for n in names}
    assert all(errors[n]==expected_errors[n] for n in names),(p,dict(errors),expected_errors)
    return dict(trace=ref(p),line_count=len(lines),entered_calls=entered,
        completed_summary=summary,terminal_unknown=terminal_unknown,
        reconciliation='entered minus unresolved-at-termination equals -C calls; parsed errors equal -C errors',
        futex_operations=op,futex_words=futex_words,fd_calls=fd,per_thread_entered_calls=per_thread,
        adjacent_tcp_operation_thread_changes=tcp_switches,
        events=events)


def main():
    state=json.loads((P/'state.json').read_text())
    assert state['passed'] and len(state['completed'])==8
    captures=[]
    for c in state['completed']:
        run_path=Path(c['run']['path'])
        run=json.loads(run_path.read_text())
        assert run['passed']
        captures.append(dict(repeat=c['repeat'],server_transport=c['pair'][2],rpc_count=c['rpc_count'],
            run=ref(run_path),endpoints={side:analyze(run_path.parent/(side+'.strace'),run['syscall_totals'][side]) for side in ('client','server')}))
    result=dict(schema='pbrs.c13-fdtrace-analysis.v1',qualified=False,timing_qualified=False,
        created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),helper=ref(Path(__file__).resolve()),
        state=ref(P/'state.json'),launch=ref(Q/'resource-c13-unary-fdtrace-launch.json'),
        captures=captures,limits=['Read-only parsing of standard strace annotations on newly launched own children.',
        'No alternate descriptor, protected maps, debugger or permission access.',
        'Selected syscall entries, thread changes and futex operations do not directly count task wakes or migrations.',
        'Tracing perturbs scheduling; no shipping timing or complete causal attribution.'])
    out=Q/'architecture-c13-fdtrace-analysis.json'
    with out.open('x') as f:json.dump(result,f,indent=2);f.write('\n')
    print(json.dumps(ref(out)))
    for c in captures:
        a=c['endpoints']['server']
        print(c['repeat'],c['server_transport'],c['rpc_count'],dict(a['futex_operations']),dict(a['fd_calls']),a['adjacent_tcp_operation_thread_changes'])

if __name__=='__main__':main()
