# Fresh C13 day diagnostics

Preparation only. No C13 source is assumed frozen and no diagnostic is launched.

The C12c attempts remain interrupted observations. Their saved data contains
3,245 completed resource cycles and 10,363 repeated deadline cycles; the last
deadline measurement is 10,515.024708209 monotonic seconds. They have no terminal
report, exit cause or 24-hour result. Preserve all original outputs and the
separate interruption capsule. Do not resume them, add their durations to a new
run, or change their source labels.

1. Freeze the final C13 Git source and record its release tools, features,
   harness hashes and executable hashes. Finish its source-specific correctness,
   sanitizers, full workspace checks and performance captures first. The full
   workspace checkout must include its tracked evidence archives.
2. Use a host or job runner that retains the process generation for the whole
   day. A detached supervisor in this replaced environment was insufficient.
   Record host boot ID, namespace, PID/start ticks and monotonic/epoch clock pair.
   Keep an observer outside the worker environment so disappearance can become
   an interrupted result even when the worker and its supervisor both vanish.
3. Reuse the reviewed resource campaign and repeated-causal-case pattern with
   new C13 source identities and unique output directories. Generate copied
   deadline cases from the frozen Git objects; preserve their assertions and
   paused-clock scope. Compile once, preserve the ELF, then run actual 30-second
   previews. Do not change the process caps or count cycles as new distinct tests.
4. After the final gates pass, root grants each fresh 86,400-second run. The
   resource campaign gets its exclusive release compiler window; the repeated
   deadline worker can use its already previewed ELF. Retain the original
   1 GiB AS, 128 FD, 4,096 same-UID process and 86,430 CPU-second day caps.
5. Verify actual child PIDs, boot/start identities, effective limits, executable
   metadata and completed cycles. Preserve one active snapshot by value. During
   the run, compare identity and advancing progress; stale `running` JSON alone
   never establishes a live worker.
6. Accept a day only from a zero-exit terminal report with the requested
   monotonic duration, passing assertions, source/ELF agreement and complete
   terminal event sequence. Publish terminal PASS, FAIL or interrupted/incomplete
   evidence through normal main pushes. Epoch age cannot substitute for measured
   duration. After host replacement or missing processes, retain the attempt as
   interrupted with unavailable cause and start a separately identified attempt.

Keep the implementation small: reuse the tested worker/caps/validators, add
process-generation identity and an external liveness check, and create one fresh
source-bound attempt per workload. No new general orchestration framework is
needed. C12c data cannot qualify a changed C13 runtime.
