# C13 instrumented instruction counters

Sources: baseline `7c02eb38`, safety `ca4ef720`, batch `933bf877`.

**540 captures /8100 successful RPCs**,2700 per source. All terminal accounting errors are zero.

Instruction values are N/2N differences per RPC. They do not establish shipping CPU speed.

| Stage | Side | Workload | Reference IR/RPC | Current IR/RPC | Change | Repeat range |
|---|---|---|---:|---:|---:|---:|
| baseline->safety | client | bidi_pipelined 1KiB identity plain / 1 in flight | 65,563 | 63,824 | -2.65% | -5.31% to +0.05% |
| baseline->safety | client | bidi 1KiB identity plain / 1 in flight | 82,950 | 86,304 | +4.04% | +3.69% to +4.40% |
| baseline->safety | server | client_stream 1KiB gzip plain / 1 in flight | 976,119 | 974,196 | -0.20% | -0.43% to +0.03% |
| baseline->safety | server | unary 1KiB identity plain / 1 in flight | 34,508 | 41,017 | +18.86% | +2.02% to +40.20% |
| safety->batch | client | bidi 1KiB identity plain / 1 in flight | 86,304 | 85,601 | -0.82% | -2.62% to +1.00% |
| safety->batch | client | bidi_pipelined 1KiB identity plain / 1 in flight | 63,824 | 65,973 | +3.37% | +3.20% to +3.54% |
| safety->batch | server | bidi_pipelined 1KiB identity plain / 1 in flight | 69,757 | 66,847 | -4.17% | -16.53% to +10.38% |
| safety->batch | server | client_stream 1KiB identity plain / 1 in flight | 41,406 | 44,221 | +6.80% | +0.72% to +12.98% |
| baseline->batch | client | server_stream 64KiB gzip plain / 1 in flight | 3,984,258 | 3,969,908 | -0.36% | -0.66% to -0.06% |
| baseline->batch | client | client_stream 1KiB identity plain / 1 in flight | 28,723 | 30,153 | +4.98% | +3.63% to +6.38% |
| baseline->batch | server | bidi 1KiB identity plain / 1 in flight | 95,618 | 94,817 | -0.84% | -4.76% to +3.75% |
| baseline->batch | server | client_stream 1KiB identity plain / 1 in flight | 37,584 | 44,221 | +17.66% | +10.16% to +25.40% |
| batch->tonic | client | client_stream 1KiB identity plain / 1 in flight | 68,168 | 30,153 | -55.77% | -56.37% to -55.15% |
| batch->tonic | server | unary 1KiB identity plain / 1 in flight | 56,289 | 40,401 | -28.22% | -29.51% to -26.94% |

All instruction, allocation and requested-byte values/ranges remain in JSON, including every increase in either repeat.

540 captures/8100 actual successful RPCs, N10/20, two paired repeats per source/workload, shared host.
Callgrind counts instrumented user-space instructions, not hardware cycles or shipping process CPU.
Every source/control and tonic row, small increase, mixed repeat and unresolved metric is retained.
Allocation bytes count cumulative requests, not retained memory. Native/shipping/bulk totals remain separate.
No broad superiority, complete matrix, production or24h qualification is established.
