#!/usr/bin/env python3
"""Sixteen adjacent same-source shipping unary controls; shared-host observations."""
import argparse
import ast
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
SOURCE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
ADAPTER = Q / 'architecture-c13-shipping-smoke.py'
ADAPTER_SHA = 'b3c9ed177c9a471c3aeb624b6dc26e4ced1408d03961d7d1890b1e7858affc7a'
BUILDER = Q / 'architecture-c13-build-shipping-rpc.py'
BUILDER_SHA = 'a7aa4c07cddf2bab7e2d7c316e7e59a0f85decc504efad22c3238da1b1016410'
HARNESS_SHA = '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b'
ACCOUNTING = ('offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs',
              'failed_rpcs','timeouts','queue_overflows','unstarted_rpcs','unfinished_rpcs')
COUNTS = (5000, 10000)
PAIRS = (('tonic','prost','native','prost'), ('tonic','prost','tonic','prost'))


def ref(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, obj):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as f:
        json.dump(obj, f, indent=2, allow_nan=False)
        f.write('\n')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_adapter(original):
    assert ref(ADAPTER)['sha256'] == ADAPTER_SHA
    assert ref(BUILDER)['sha256'] == BUILDER_SHA
    assert ref(original)['sha256'] == HARNESS_SHA
    def body(path):
        return [ast.dump(n, include_attributes=False) for n in ast.parse(path.read_text()).body
                if not isinstance(n, ast.FunctionDef) or n.name != 'verified_build']
    assert body(original) == body(ADAPTER), 'capture logic must be unchanged'


def summarize(raw):
    captures=[]
    slopes=[]
    for repeat in range(4):
        for pair in PAIRS:
            for n in COUNTS:
                r=raw[(repeat,pair,n)]
                last=r['resource_samples'][-1]
                before=r['server_cpu_before']
                endpoints={}
                for side in ('client','server'):
                    baseline=before if side=='server' else {}
                    endpoints[side]={part+'_ticks':last[side][part+'_ticks']-baseline.get(part+'_ticks',0)
                                     for part in ('user','system')}
                    endpoints[side]['total_ticks']=sum(endpoints[side].values())
                    endpoints[side]['cpu_us_per_rpc_including_setup']=endpoints[side]['total_ticks']*10000/n
                captures.append(dict(repeat=repeat,pair=list(pair),rpc_count=n,endpoints=endpoints,
                    server_window_ns=last['server']['monotonic_ns']-before['monotonic_ns'],metrics=r['metrics']))
            a,b=[next(r for r in captures if r['repeat']==repeat and r['pair']==list(pair) and r['rpc_count']==n) for n in COUNTS]
            for side in ('client','server'):
                parts={part+'_us_per_rpc_slope':(b['endpoints'][side][part+'_ticks']-a['endpoints'][side][part+'_ticks'])*2
                       for part in ('user','system','total')}
                slopes.append(dict(repeat=repeat,pair=list(pair),side=side,**parts))
    comparisons=[]
    for repeat in range(4):
        native,tonic=[next(r for r in slopes if r['repeat']==repeat and r['pair']==list(pair) and r['side']=='server') for pair in PAIRS]
        a,b=native['total_us_per_rpc_slope'],tonic['total_us_per_rpc_slope']
        comparisons.append(dict(repeat=repeat,native_server=native,tonic_server=tonic,
            ratio=a/b if a>0 and b>0 else None,resolved_positive_slopes=a>0 and b>0))
    return dict(qualified=False,timing_qualified=False,ticks_per_second=100,cpu_tick_quantum_ns=10000000,
        captures=captures,cpu_component_slopes=slopes,native_over_tonic_server_cpu_slopes=comparisons,
        scope='Client lifetime including setup/reporting; server before-client to terminal-client window.',
        rule='All raw process ticks, distributions and signed slopes retained. Never subtract quantiles or throughput. Shared-host observations do not establish broad superiority.')


def execute(args):
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
    config = args.sources.resolve(strict=True)
    config_ref = ref(config)
    sources = json.loads(config.read_text())
    assert set(sources) == {'baseline','candidate'}
    row = sources['candidate']
    assert row['source'] == SOURCE
    tree = Path(row['checkout']).resolve(strict=True)
    binary = Path(row['binary']).resolve(strict=True)
    record = Path(row['build_record']).resolve(strict=True)
    verify_adapter(tree / 'scripts/grpc-load-smoke.py')
    smoke = module('c13_shipping_syscall_capture', ADAPTER)
    build = smoke.verified_build(record, binary, tree)
    assert build['source']['commit'] == SOURCE
    assert os.sysconf('SC_CLK_TCK') == 100
    pins = dict(controller=ref(Path(__file__).resolve()), adapter=ref(ADAPTER),
                builder=ref(BUILDER), config=config_ref, build_record=ref(record))
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for src, name in [(Path(__file__).resolve(),'controller.py'),(ADAPTER,'capture-adapter.py'),
                      (BUILDER,'shipping-build-validator.py'),(config,'sources.json')]:
        shutil.copy2(src,output/name)
    state_path = output / 'state.json'
    state = dict(schema='pbrs.shipping-unary-adjacent-replay.v1', state='running', passed=False,
        qualified=False, timing_qualified=False, started_utc=now(), pins=pins,
        build=build, allocation_counts=False, context_switches=False, strace=None,
        source=SOURCE, rpc_counts=COUNTS, expected_captures=16, expected_successful_rpcs=120000,
        completed=[], actual_rpc_totals={k:0 for k in ACCOUNTING},
        background=['Only launch after Root grants a quiet capture window; record actual known quiescence limits separately.'],
        limits=['Unchanged feature-off shipping capture adapter; no profiler or syscall tracer.',
                'Shared-host observations, not dedicated-host or broad shipping superiority qualification.',
                'No feature, TLS, worker, policy, queue, buffer or flushing setting changes.',
                'First failure retained; no retry, escalation, permission workaround or fallback.'])
    save(state_path,state)
    raw = {}
    def verify():
        assert ref(config) == pins['config'] and ref(Path(__file__).resolve()) == pins['controller']
        assert ref(record) == pins['build_record']
        verify_adapter(tree / 'scripts/grpc-load-smoke.py')
        assert smoke.verified_build(record,binary,tree) == build
    try:
        for repeat in range(4):
            pairs = PAIRS if repeat % 2 == 0 else tuple(reversed(PAIRS))
            counts = COUNTS if repeat % 2 == 0 else tuple(reversed(COUNTS))
            for pair in pairs:
                for n in counts:
                    verify()
                    cell = dict(pair=list(pair),shape='unary',payload_bytes=1024,tls=False,
                                compression='identity',connections=1,in_flight=1,repeat=repeat)
                    child = output / ('capture-'+str(len(state['completed'])).zfill(3))
                    settings = SimpleNamespace(binary=binary,source_checkout=tree,duration=60,
                        rpc_count=n,allocation_counts=False,context_switches=False,callgrind=None,strace=None)
                    result = smoke.run_cell(settings,cell,child)
                    state['completed'].append(dict(repeat=repeat,pair=list(pair),rpc_count=n,
                        run=ref(child/'run.json'),passed=result['passed']))
                    for key in ACCOUNTING:
                        value = result.get('metrics',{}).get(key)
                        if type(value) is int and value >= 0: state['actual_rpc_totals'][key] += value
                    save(state_path,state)
                    assert result['passed'], 'first failed capture retained: '+str(child)
                    assert result['cell'] == cell and result['client_exit_code'] == 0
                    assert not any(k in result for k in ('allocation_totals','context_switch_totals','instruction_totals','syscall_totals'))
                    assert result['metrics']['successful_rpcs'] == n
                    raw[(repeat,pair,n)] = result
                    verify()
        assert len(state['completed']) == 16
        assert all(state['actual_rpc_totals'][k] == 120000 for k in ACCOUNTING[:4])
        assert all(state['actual_rpc_totals'][k] == 0 for k in ACCOUNTING[4:])
        summary = output/'shipping-replay-summary.json'
        save(summary,summarize(raw))
        state.update(state='finished',passed=True,completed_utc=now(),summary=ref(summary))
        save(state_path,state)
    except BaseException as error:
        state.update(state='failed',passed=False,completed_utc=now(),
                     error=dict(type=type(error).__name__,message=str(error)))
        save(state_path,state)
        raise


def main():
    if not __debug__: raise RuntimeError('ordinary Python without -O required')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sources',type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--execute',action='store_true')
    args=p.parse_args()
    if not args.execute:
        print(json.dumps(dict(state='prepared_not_run',captures=16,rpc_counts=COUNTS,
            successful_rpcs=120000,source=SOURCE,qualified=False),indent=2))
    else:
        assert args.sources is not None and args.output is not None
        execute(args)


if __name__ == '__main__': main()
