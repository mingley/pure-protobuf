from pathlib import Path
import datetime,hashlib,json,re,statistics

ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification'
D=Q/'architecture-c13-doc-drafts';D.mkdir()
CURRENT='933bf8775b70d24d91fb46a7992eae343b60f0ea'
BASE='7c02eb387a6785d6e914146babe34f0902a6dd62'
SAFETY='ca4ef720f8a90134334101e0106a8a68808fc19f'
CAP='docs/evidence/grpc-ownership-20261024'
paths=['README.md','TODO.md','docs/status.md','docs/benchmarks.md','docs/decisions/grpc-execution.md','docs/evidence/README.md']
originals={p:(ROOT/p).read_text() for p in paths}
def read(n):return json.loads((Q/n).read_text())
def ref(n):
 p=Q/n;return {'path':str(p.relative_to(ROOT)),'archive_path':'qualification/'+str(p.relative_to(Q)),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
native=read('architecture-c13-native-analysis.json');cpu=read('architecture-c13-callgrind-analysis.json');bulk=read('architecture-c13-bulk-completion.json')
workspace=read('architecture-c13-workspace.json');asan=read('architecture-c13-asan-summary.json')
assert workspace['source']==CURRENT and workspace['state']=='passed' and workspace['counts']=={'passed':3840,'failed':0,'ignored':9}
assert workspace['targets']==145 and asan['source']['head']==CURRENT and asan['totals']=={'passed':961,'failed':0,'ignored':1}
assert native['sources']==cpu['sources']=={'baseline':BASE,'safety':SAFETY,'batch':CURRENT}
assert native['actual_captures']==576 and native['actual_successful_rpcs']==21600 and cpu['actual_captures']==540 and cpu['actual_successful_rpcs']==8100
for name in ['architecture-c13-final-rustdoc.json','architecture-c13-final-msrv.json','architecture-c13-final-msrv-zstd.json']:
 v=read(name);assert v['source']['head']==CURRENT and v['exit_code']==0 and not v.get('timeout')

def pick(data,kind,comparison,side,metric,shape,size=1024,tls=False,load=1,compression='identity'):
 rows=[r for r in data[kind] if r['comparison']==comparison and r['side']==side and r['metric']==metric and r['native_endpoint'] and r['cell']['shape']==shape and r['cell']['payload_bytes']==size and r['cell']['tls']==tls and r['cell']['in_flight']==load and r['cell']['compression']==compression]
 assert len(rows)==1,(comparison,side,metric,shape,size,tls,load,compression)
 return rows[0]
byte_cases=[('Client','Bidi, 1 KiB identity',pick(native,'same_side_tonic_groups','batch->tonic','client','requested_bytes','bidi')),
 ('Server','Bidi, 1 KiB identity',pick(native,'same_side_tonic_groups','batch->tonic','server','requested_bytes','bidi')),
 ('Client','Bidi, 1 MiB gzip',pick(native,'same_side_tonic_groups','batch->tonic','client','requested_bytes','bidi',1048576,compression='gzip')),
 ('Server','Bidi, 1 MiB gzip',pick(native,'same_side_tonic_groups','batch->tonic','server','requested_bytes','bidi',1048576,compression='gzip'))]
ir=[r for r in cpu['same_side_tonic_groups'] if r['comparison']=='batch->tonic' and r['metric']=='instructions']
assert len(ir)==30 and all(r['directions']=={'lower':2} for r in ir)
source_costs=[pick(cpu,'source_groups','baseline->batch','server','instructions','unary'),pick(cpu,'source_groups','baseline->batch','server','instructions','client_stream'),pick(native,'source_groups','safety->batch','client','allocations','bidi_pipelined',65536)]
bulk_rows=[r for r in bulk['native_endpoint_comparisons'] if r['stream_messages']==64 and r['cell']['shape']=='bidi_pipelined' and r['side']=='server'];assert len(bulk_rows)==2
bb=statistics.median(r['safety_per_rpc']['requested_bytes'] for r in bulk_rows);ba=statistics.median(r['batch_per_rpc']['requested_bytes'] for r in bulk_rows);bp=(ba/bb-1)*100
br=[(r['batch_over_safety']['requested_bytes']-1)*100 for r in bulk_rows]

checks={'workspace':{'result':workspace['counts'],'targets':145,'seconds':workspace['duration_seconds'],'state':ref('architecture-c13-workspace.json'),'physical_before':ref('architecture-c13-workspace-source-before.json'),'physical_after':ref('architecture-c13-workspace-source-after.json'),'tracked_blobs':3797,'tracked_bytes':910511102},
 'asan':{'result':asan['totals'],'selected_elfs':13,'summary':ref('architecture-c13-asan-summary.json'),'state':ref('architecture-c13-asan-state.json')},
 'precommit_source_equivalence':ref('architecture-c13-precommit-source-equivalence.json'),
 'warning_strict_rustdoc':ref('architecture-c13-final-rustdoc.json'),'rust185_core':ref('architecture-c13-final-msrv.json'),'rust187_zstd':ref('architecture-c13-final-msrv-zstd.json'),
 'precommit_clippy':ref('architecture-c13-single-ready-clippy.json'),'precommit_fmt':ref('architecture-c13-single-ready-fmt.json'),
 'kernel':ref('kernel-unknown-group-focused-qualification.json'),'regeneration':ref('kernel-unknown-group-original-regen-check.json')}
conformance={}
for key in ['required_1','required_2','recommended']:
 r=read('kernel-unknown-group-conformance-'+key+'.json');assert r['exit_code']==0
 conformance[key]={'maximum_edition':2023,'binary_json_successes':5631,'text_successes':909,'skipped':0,'expected_failures':0,'unexpected_failures':0,'record':ref('kernel-unknown-group-conformance-'+key+'.json')}
checks['official_conformance']=conformance
phases={'native':{'captures':576,'successful_rpcs':21600,'source_count':3,'scope':'Allocation-instrumented N25/50; two paired repeats; 48 workload/pair scopes.','state':'postprocessing_recovered','original_controller_exit_code':1,'original_controller':ref('resource-c13-native-execution.json'),'original_state':ref('architecture-c13-native-captures/state.json'),'recovered_state':ref('architecture-c13-native-recovered/state.json'),'complete_analysis':ref('architecture-c13-native-analysis.json')},
 'callgrind':{'captures':540,'successful_rpcs':8100,'source_count':3,'scope':'Allocation-instrumented N10/20; two paired repeats; 45 workload/pair scopes.','state':ref('architecture-c13-callgrind-captures/state.json'),'execution':ref('resource-c13-callgrind-execution.json'),'complete_analysis':ref('architecture-c13-callgrind-analysis.json')},
 'bulk':{'captures':240,'successful_rpcs':9000,'source_count':2,'scope':'Safety->batch, separate partitions for 1/2/3/4/64 messages per leg.','complete_record':ref('architecture-c13-bulk-completion.json')},
 'shipping':{'captures':48,'successful_rpcs':360000,'source_count':2,'scope':'Feature-off release binaries, N5000/10000, two paired repeats, identity1KiB unary/bidi. Timing remains unqualified.','complete_record':ref('architecture-c13-shipping-completion.json'),'complete_summary':ref('architecture-c13-shipping-captures/shipping-summary.json'),'cpu_investigation':ref('architecture-c13-shipping-unary-server-investigation.md')},
 'selected_syscalls':{'captures':8,'successful_rpcs':12000,'source':CURRENT,'scope':'Tracing diagnostic, not timing.','complete_record':ref('architecture-c13-shipping-unary-syscalls-completion.json')},
 'fd_trace':{'captures':8,'successful_rpcs':600,'source':CURRENT,'scope':'Own-child fd-aware traces; four native-server traces. Tracing/background effects apply.','complete_record':ref('architecture-c13-shipping-unary-fdtrace-completion.json'),'complete_analysis':ref('architecture-c13-fdtrace-analysis.json'),'findings':ref('architecture-c13-shipping-unary-fdtrace-findings.md')}}
results={'schema':'pbrs.grpc-ownership-evidence.v1','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'qualified':False,'production_ready':False,'broad_superiority_proven':False,
 'sources':{'baseline':BASE,'safety':SAFETY,'current':CURRENT,'current_tree':'6188eaf5c9d3342afd221b10c7a133968a27e6e7'},'source_roles':{'baseline':'Previous measured runtime.','safety':'Completed DATA owner retirement, pre-shape reset ownership and structural protobuf group validation.','current':'Safety source plus single-ready batch reservation changes.'},
 'validation':checks,'phases':phases,'canonical_counter_totals':{'captures':1116,'successful_rpcs':29700,'includes':['native','callgrind'],'excludes':['bulk','shipping','selected_syscalls','fd_trace']},
 'measurements':{'byte_table':[dict(side=side,workload=label,data=row) for side,label,row in byte_cases],'instruction_groups':ir,'source_cost_examples':source_costs,'bulk_server64':{'rows':bulk_rows,'before_median_bytes':bb,'after_median_bytes':ba,'median_change_percent':bp,'paired_change_percent':br},
 'shipping_unary_server':{'scope':'Identity1KiB, one connection/one in-flight call, two Tokio workers, N5000/10000, feature-off binaries, shared host.','raw_cpu_microseconds_per_rpc_at_10000':{'native':[51,51],'tonic':[31,33],'native_over_tonic':[51/31,51/33]},'cpu_slope_microseconds_per_rpc':{'native':[52,50],'tonic':[18,24],'native_over_tonic':[52/18,50/24]},'native_throughput_lower_percent_at_10000':[13.6,18.3],'timing_qualified':False,'controls_shifted':True},
 'full_group_counts':{'native_source':864,'native_tonic':576,'cpu_source':810,'cpu_tonic':540},'all_increases_retained':True,'cost_cutoff_percent':0,'capacity_model_and_observed_isolate':native['capacity_models']},
 'history':{'ordinary_owner_drop':ref('architecture-c13-owner-summary.md'),'kernel_causal':ref('kernel-unknown-group-focused-qualification.json'),'native_postprocess_failure_preserved':True,'c12_days_interrupted':ref('architecture-c13-c12c-day-interruption-20261024/report.json'),'older_capsules_unchanged':True},
 'resource_days':{'source':CURRENT,'state':'prepared_not_started','preview_state':'not_started','day_pass':False,'prepared_generation':ref('architecture-c13-soaks-prepared.json'),'prior_source_day_attempts':'7c02 days interrupted without terminal reports; exit cause unavailable, no application failure established.'},
 'remaining':['Current-source previews and full 24-hour days.','Unary-server shipping CPU/throughput loss and scheduling attribution.','Remaining identity/gzip byte losses and bulk tradeoffs.','Current-source cold-process, entropy, read-all, overload, physical-network and full client/server coverage.','Required features, credentials, telemetry, typed extensions, platform/consumer/release qualification.'],
 'limits':['Source/runtime/phase scopes are explicit; no instruction-count to shipping-CPU inference.','All source/control increases, losing cells, unresolved metrics and repeat ranges remain in hash-linked full records.','Requested bytes are cumulative allocation requests, not RSS or retained capacity.','Historical source-only capacity arithmetic is conditional, not an allocation-site attribution proof.','Tracing distinguishes eventfd/TCP and wait operation signatures; it does not prove task wakes/migrations or the complete CPU cause.','Old failed/prepared/in-progress records are retained chronologically; later records never relabel them as passed.','ELF bytes are omitted from the publication archive; build/source/tool hashes and raw command logs remain.']}

# Living docs preserve existing code fences and historical sections.
new=dict(originals)
old='The [server deadlines and gzip results](docs/evidence/grpc-deadlines-20261024/README.md)'
a=new['README.md'].index(old);b=new['README.md'].index('For contributors,',a)
new['README.md']=new['README.md'][:a]+'''The [ownership and batching record](docs/evidence/grpc-ownership-20261024/README.md)
records completed DATA-owner destruction outside backend locks, reset ownership,
protobuf group validation and batch reservations at source `933bf877`.
The full workspace passes 3,840 tests. The [benchmark tables](docs/benchmarks.md)
show remaining CPU, byte and bulk losses alongside lower instruction counts.
See [implementation status](docs/status.md) for checks and unfinished qualification.
'''+new['README.md'][b:]
current='''## Current priorities

Source `933bf877` fixes completed DATA-owner retirement, pre-shape reset ownership
and malformed unknown-group acceptance, then adjusts singleton/bulk reservations.
[The current record](docs/evidence/grpc-ownership-20261024/README.md) keeps detecting
failures, source snapshots and every measured loss.

The full all-feature workspace passes **3,840 tests**, zero failures and nine
existing ignores across 145 target summaries. ASAN/leak checks pass **961 tests**
(one existing ignore) across 13 selected ELFs. Three official conformance passes
through Edition 2023 each pass 5,631 binary/JSON and 909 text cases. Strict lint,
formatting, warning-strict docs and the recorded Rust 1.85 / 1.87 profiles pass.
Native/instruction counters complete 1,116 captures / 29,700 successful RPCs;
bulk, shipping-build and tracing controls remain separate.

The [benchmarks](docs/benchmarks.md) identify the next costs. Unary-server shipping
CPU still loses to tonic; raw CPU per call at 10,000 calls is 1.55–1.65 times
higher. Identity bidi client bytes remain 5.70% higher; 1 MiB gzip bidi bytes are
16.40% higher on the client / 17.43% on the server. The 64-message pipelined server
byte changes are +1.15% and +26.75% versus the safety source. All 30 instrumented
instruction groups use fewer instructions than tonic in both repeats; 22 of 30
instruction medians rise versus `7c02eb38`. These metrics answer different questions.

| Work | Next result | Completion criterion |
|---|---|---|
| Unary-server CPU and scheduling | Test the post-protocol ready-set recheck with a bounded causal control, then compare unchanged shipping/tracing settings. | Stable adjacent peer controls; lower measured redundant work; preserve status, flow control, cancellation, deadlines and owner destruction. Current traces identify eventfd/worker handoff, not an engine-lock cause. |
| Identity/gzip bytes and bulk | Attribute remaining buffers and copies, including the 64-message pipeline loss. | Keep cold/bulk tradeoffs, finite retention budgets and every losing cell; capacity arithmetic is separate from measured allocation sites. |
| QG-06: sustained resources | Build/validate current-source previews and run the prepared general/deadline days. | Actual terminal 24-hour records at `933bf877`, finite limits, balanced ownership and recovery. Both previews/days are currently unstarted. |
| Remaining backend destruction | Audit generic current-frame panic, queue-clear, reset and EOF owners beyond the repaired retired DATA frames. | Independent bounded controls before broader safety claims; no hidden work detached from resource ownership. |
| PK-27, PK-29: owned read-all decode | Compare one checked singular merge with lazy access on equal sparse/read-all corpora. | Preserve required/merge/oneof/extensions/unknown/recursion semantics and retention; repeated Query children already parse eagerly. |
| Handler isolation and SB-27 | Complete per-side shipping CPU, latency, throughput, entropy, field-access, overload and physical-network comparisons. | Keep inline/task handoff costs, sibling fairness, actual concurrency and all losing scopes. |
| CH-12, credentials and telemetry | Finish discovery/xDS, async OAuth2/JWT, typed extensions and remaining instruments. | Supported external consumers, bounded refresh/cancellation/labels and wire-compatible behavior. |
| Platforms and release | Complete required feature/platform/consumer profiles and dedicated-host headroom/statistics. | Exact-source release checks and claimed workload scopes pass. |

The earlier `7c02eb38` day attempts are **interrupted**, with no terminal resource
outcome or application failure established. Preserved progress and the newer boot
indicate an environment discontinuity; the exit cause is unavailable. They are
not running and cannot qualify `933bf877`. Older `beb4ecd9` general/cache days passed
only their recorded source and scope. The [execution decision](docs/decisions/grpc-execution.md)
explains ownership and comparison boundaries; [the benchmark contract](docs/benchmark-contract.md)
sets performance requirements. Production readiness, full specification coverage
and broad superiority remain open.

'''
a=new['TODO.md'].index('## Current priorities');b=new['TODO.md'].index('<a id="dominance-program">',a)
new['TODO.md']=new['TODO.md'][:a]+current+new['TODO.md'][b:]
status='''# Implementation status

Source `933bf877` repairs completed DATA-owner retirement, pre-shape reset ownership
and malformed unknown-group validation, and changes singleton/bulk reservations.
[The current record](evidence/grpc-ownership-20261024/README.md) retains actual
sources, detecting failures, checks and [endpoint costs](benchmarks.md).

| Check | Actual source/scope | Result |
|---|---|---|
| Full all-feature workspace | Clean `933bf877` | **3,840 passed, zero failed, nine existing ignores**, 145 summaries; 1,350.798 seconds |
| ASAN with leak detection | `933bf877`, 13 selected ELFs | **961 passed, zero failed, one existing ignore** |
| Official protobuf conformance | Pinned upstream v35.1; maximum Edition 2023 | Required twice and recommended once: each **5,631 binary/JSON + 909 text**, zero skipped/expected/unexpected failures |
| Lint, formatting and docs | Source-bound precommit snapshots; clean final rustdoc | Strict workspace Clippy/fmt and warning-strict rustdoc pass; equivalence proof binds tested batch/kernel files to final Git blobs |
| Minimum Rust profiles | Clean `933bf877` | Rust **1.85** core and **1.87** optional Zstd pass |
| Native / Callgrind counters | `7c02eb38` → safety `ca4ef720` → current `933bf877` | **576 / 540 captures**, 21,600 / 8,100 successful RPCs; all accounting errors zero |
| Separate bulk / shipping controls | Explicit source/feature scopes | **240 / 48 captures**, 9,000 / 360,000 successful RPCs; CPU/byte losses remain |
| Separate syscall / fd traces | Own-child tracing, timing unqualified | **8 / 8 captures**, 12,000 / 600 successful RPCs; raw errors and unresolved teardown calls retained |

Before/after workspace proofs match all **3,797 physical Git blobs, modes and
sizes: 910,511,102 bytes**. The original native counter controller exited 1 after
all captures when sparse checkouts lacked plan files. Exact Git materialization
and a separate postprocessing recovery preserve that failure and reuse all raw
captures; no failed process is relabeled as passed.

The native unary server still loses shipping CPU and throughput in the measured
shared-host run. Identity bidi client bytes exceed tonic by 5.70%; 1 MiB gzip bidi
bytes exceed it by 16.40% client / 17.43% server. All 30 native instruction groups
are lower in both repeats, while 22 medians rise against the previous runtime.
The benchmark page separates those results and keeps every source/control increase.

Current-source resource previews and days are **prepared, not started**.
The earlier `7c02eb38` general/deadline attempts are interrupted with no terminal
report, no 24-hour pass and no established application failure; the exit cause is
unavailable. Earlier `beb4ecd9` general/cache days passed only their own source.

Stream decode reuse keeps the 4 MiB per-buffer / 16 MiB process idle-capacity limit.
Retained Bytes/lazy pbrs input keeps ownership. Active decoding, application
messages, codec scratch and RSS remain separate. Complete compressed members,
streams and frames retain output/history/work limits.

Sustained resources, remaining features/specification coverage, required platforms,
releases and the complete per-side performance matrix remain open. These checks
are not a production certification; broad superiority remains unproved.

'''
a=new['docs/status.md'].index('Use this page to distinguish')
new['docs/status.md']=status+new['docs/status.md'][a:]

# Simple complete instruction table, with the existing reproduction example.
reproduce=re.search(r'```sh\n.*?```',originals['docs/benchmarks.md'],re.S).group(0)
lines=['# Benchmarks','','The native unary server still uses more CPU than tonic in the measured shipping build.','Some allocation and instruction counts are lower; remaining losses are listed first.','',
 '**Current `933bf877` · safety `ca4ef720` · before `7c02eb38`** · 2026-10-24 UTC · Linux x86_64 · Rust 1.99.1 · shared host.','',
 '## Shipping-build loss','', 'Identity unary, 1 KiB, one connection / one in-flight call, two Tokio workers. Allocation counters and profilers are off.','',
 '| Server CPU | Native | tonic/prost | Native / tonic |','|---|---:|---:|---:|','| Raw CPU/call, 10,000 calls | 51 µs | 31–33 µs | 1.55–1.65× |','| N/2N CPU slope | 50–52 µs/RPC | 18–24 µs/RPC | 2.08–2.89× |','',
 'At 10,000 calls native throughput is 13.6–18.3% lower. Tonic controls also shift substantially across processes; these timing results need controlled replay.','',
 '## Requested allocation bytes','', '**Bytes/RPC, lower is better.** Equal Prost work, plaintext, one in flight. These are cumulative allocation requests, not RSS.','',
 '| Side | Workload | Current | tonic/prost | Change |','|---|---|---:|---:|---:|']
for side,label,r in byte_cases:
 scale=1048576 if r['cell']['payload_bytes']==1048576 else 1024;unit='MiB' if scale==1048576 else 'KiB'
 lines.append(f"| {side} | {label} | {r['after']['median']/scale:.2f} {unit} | {r['before']['median']/scale:.2f} {unit} | {r['percent_of_medians']:+.2f}% |")
lines += ['', 'Singleton identity bidi improves versus Safety: client −21.28%, server −27.92%. The conditional capacity model is separate from measured allocation-site proof.','',
 '## Costs versus earlier source','', '| Comparison | Side / workload | Metric/RPC | Before → current | Change; paired range |','|---|---|---|---:|---:|']
for r in source_costs:
 sh={'unary':'unary 1 KiB identity','client_stream':'upload 1 KiB identity','bidi_pipelined':'pipelined bidi 64 KiB identity'}[r['cell']['shape']]
 metric='k instructions' if r['metric']=='instructions' else 'allocations';scale=1000 if r['metric']=='instructions' else 1
 comp='Before → current' if r['comparison']=='baseline->batch' else 'Safety → current'
 lines.append(f"| {comp} | {r['side']}, {sh} | {metric} | {r['before']['median']/scale:.2f} → {r['after']['median']/scale:.2f} | {r['percent_of_medians']:+.2f}%; {r['paired_percent']['min']:+.2f}..{r['paired_percent']['max']:+.2f}% |")
lines += [f'| Safety → current | server, pipelined bidi 64 × 1 KiB | KiB requested | {bb/1024:.2f} → {ba/1024:.2f} | {bp:+.2f}%; {min(br):+.2f}..{max(br):+.2f}% |','',
 'The bulk server repeats lose +26.90% / +15.67% bytes versus fresh tonic. All increases, mixed repeats and control endpoints remain in the full ledgers.','',
 '## Instructions','', '**Million instructions/RPC: current / tonic (change).** All 30 scopes are lower in both repeats; medians are 3.24–55.77% lower.','Callgrind and allocation counting are enabled. Both endpoints use Prost, plaintext and one in-flight call. These counts do not establish shipping CPU speed.','',
 '| Workload | Client | Server |','|---|---:|---:|']
shape={'unary':'Unary','client_stream':'Upload','server_stream':'Server stream','bidi':'Bidi','bidi_pipelined':'Pipelined bidi'}
for comp,size in [('identity',1024),('gzip',1024),('gzip',65536)]:
 for sh,label in shape.items():
  pair=[pick(cpu,'same_side_tonic_groups','batch->tonic',side,'instructions',sh,size,compression=comp) for side in ['client','server']]
  vals=[f"{r['after']['median']/1e6:.4f} / {r['before']['median']/1e6:.4f} ({r['percent_of_medians']:+.1f}%)" for r in pair]
  lines.append(f'| {label}, {size//1024} KiB {comp} | {vals[0]} | {vals[1]} |')
lines += ['', 'Against before, 22 of 30 instruction medians rise. The ±2% ledger band is not a significance test; every smaller increase and repeat range is retained.','',
 '## Scope and records','', '| Campaign | Captures | Successful RPCs |','|---|---:|---:|','| Native counters, three sources | 576 | 21,600 |','| Callgrind, three sources | 540 | 8,100 |','| Separate bulk, Safety/current | 240 | 9,000 |','| Separate shipping builds | 48 | 360,000 |','| Separate selected syscall / fd traces | 8 / 8 | 12,000 / 600 |','',
 'Native N=25/50; Callgrind N=10/20; two paired repeats. The native controller failed after capture on missing plan files; separate recovery rebuilt reports without recapture.','Gzip level 6, zero-filled payloads, four streaming messages, 400 KiB server send buffers, queues 16. Bulk partitions use 1/2/3/4/64 messages.','Current-source cold-process, entropy/read-all, overload, physical networks and broader platform/feature coverage remain open; older C12 cold results are not inherited.','',
 '[Results, dated source and raw captures](evidence/grpc-ownership-20261024/README.md) · [Benchmark contract](benchmark-contract.md)','',
 '## Reproduce','', 'Use a clean checkout and keep outputs outside it. Exact paired commands, profiles and source pins are in the record.','',reproduce,'',
 '**Validation:** 3,840 workspace tests pass (nine existing ignores); selected ASAN/leak checks pass 961 (one existing ignore). Current resource previews/days are prepared and unstarted.','Older `7c02eb38` days are interrupted, with no terminal outcome or known exit cause. Production readiness and broad superiority remain unproved. [Next work](../TODO.md#current-priorities)']
new['docs/benchmarks.md']='\n'.join(lines)+'\n'

s=new['docs/decisions/grpc-execution.md'];a=s.index('Source `7c02eb38`');b=s.index('## Measure the work',a)
s=s[:a]+'''Source `933bf877` retires completed DATA owners outside backend locks, preserves
pre-shape reset ownership and adjusts singleton/bulk reservations. The
[current record](../evidence/grpc-ownership-20261024/README.md) retains detecting
failures, source snapshots and actual endpoint costs. Full workspace validation
passes 3,840 tests; source-bound sanitizers, conformance and toolchain checks pass.

Unary-server shipping CPU still loses to tonic. Lower allocation and Callgrind
instruction counts describe other costs. The next scheduling hypothesis needs a
bounded causal control and the same endpoint settings before any source change.

'''+s[b:]
s=s.replace('New terminal-path payload destruction and waker callbacks run outside engine\nlocks. The broader ordinary-success DATA-owner destruction concern is a separate,\nopen source finding; its bounded runtime reproduction has not run. These deadline\nrepairs do not preempt synchronous work or replace handler-isolation experiments.', '''Completed DATA frames now move to a fixed retirement batch declared outside
engine and send-buffer lock guards. Fully consumed owners drop after unlocking;
partial payloads retain their unsent tails and final EOS intent. A full retirement
batch unlocks and destroys owners before staging continues; it does not force IO.
Controls cover normal reclaim, explicit post-flush reclaim, retired-owner unwind,
credit/EOS, reentry and IO error. Generic Buf operations still run under staging
locks; current-frame panic and other queue/EOF owner paths need separate review.

Pre-shape response ownership also retains the selected reset cause through
cancellation and unwind. These repairs do not preempt synchronous application
work or replace handler-isolation measurements.''')
s=s.replace('use `7c02eb38`, retaining endpoint losses and every observed source cost increase.', 'use `933bf877` against `7c02eb38`, retaining losses and every source cost increase.')
anchor='## Keep one deadline and terminal owner'
s=s.replace(anchor,'''The shipping trace diagnostic finds eventfd notifications and frequent changes
of thread between adjacent TCP operations. Four native-server traces contain
WAIT_BITSET_PRIVATE waits and no WAIT_PRIVATE engine-lock acquisition signature.
Do not retune the engine lock from an aggregate futex count. A ready-set recheck
after protocol input returns Pending is a source hypothesis, not an established
CPU cause or implemented scheduling optimization. Tracing affects scheduling.

'''+anchor)
s=s.replace('Correctness, remaining features/spec coverage, platform/release qualification,\nshipping CPU/latency/throughput coverage and an actual final-source 24-hour soak\nremain open.', 'Remaining destructor/merge/specification coverage, features, platform/release\nqualification, shipping CPU/latency/throughput and an actual final-source\n24-hour soak remain open.')
new['docs/decisions/grpc-execution.md']=s
s=new['docs/evidence/README.md'];marker='| [Server deadlines and gzip, 2026-10-24 UTC]'
row='| [Ownership, batching and current costs, 2026-10-24 UTC](grpc-ownership-20261024/README.md) | Source `933bf877`; 3,840 workspace tests, 961 selected sanitizer tests and three official conformance passes; complete source-bound native/Callgrind, separate bulk/shipping/tracing records | Unary-server shipping CPU, identity/gzip bytes, source instruction costs and bulk tradeoffs remain. All 30 instrumented instruction groups are lower than tonic; current days are prepared and unstarted. |\n'
pos=s.index(marker);s=s[:pos]+row+s[pos:]
s=s.replace('Both current resource days are running with results pending in the 09:27 UTC snapshot.', 'Both days were running in the 09:27 UTC snapshot; later observation records interruption without a terminal result or known exit cause.')
s=s.replace('the actual resource day is running, with its result pending', 'the resource day was running at publication; its terminal result is linked above')
new['docs/evidence/README.md']=s

capsule=f'''# Ownership, batching and current costs

Current source: `{CURRENT}`. Safety-only source: `{SAFETY}`.
Before: `{BASE}`. Linux x86_64, Rust 1.99.1, shared host.

The repair moves completed DATA owners outside backend locks, preserves reset
ownership before response-shape selection and rejects malformed protobuf group
ends. Batching reduces singleton reservations. Current shipping unary-server CPU,
large gzip bytes and some bulk/source costs still lose. These results do not prove
production readiness or broad superiority.

## Validation

| Check | Actual result |
|---|---|
| Full all-feature workspace, clean `933bf877` | **3,840 passed / 0 failed / 9 existing ignores**, 145 summaries; 1,350.798 seconds |
| ASAN/leak detection, 13 selected ELFs | **961 passed / 0 failed / 1 existing ignore** |
| Official v35.1 conformance, maximum Edition 2023 | Required twice and recommended once: each **5,631 binary/JSON + 909 text successes**, zero skipped/expected/unexpected failures |
| Strict lint/fmt | Precommit source snapshots pass; final Git-blob equivalence retains their actual source labels |
| Warning-strict rustdoc | Clean current source passes in 79.402 seconds |
| Rust 1.85 core / 1.87 optional Zstd | Clean current source passes in 174.605 / 94.340 seconds |

Workspace before/after proofs match **3,797 physical tracked blobs, modes and
sizes, 910,511,102 bytes**. A separate equivalence record binds all five tested
batch files and twenty kernel/generated files to final Git blobs; it does not
rename dirty precommit executions as clean committed runs. Test scopes overlap.
Selected sanitizer tests do not add distinct full-workspace test counts.

## Current costs

[The benchmark tables](../../benchmarks.md) give all thirty instruction scopes and
selected gains/losses. Bytes below are allocation requests/RPC, not RSS.

| Side | Workload | Current | Fresh tonic/prost | Difference |
|---|---|---:|---:|---:|
| Client | Bidi 1 KiB identity | 42.40 KiB | 40.11 KiB | +5.70% |
| Server | Bidi 1 KiB identity | 31.32 KiB | 32.95 KiB | −4.94% |
| Client | Bidi 1 MiB gzip | 19.41 MiB | 16.67 MiB | +16.40% |
| Server | Bidi 1 MiB gzip | 18.40 MiB | 15.67 MiB | +17.43% |

Safety→current singleton bidi saves **21.28% client / 27.92% server** requested
bytes. The conditional four-singleton model predicts 12,480 / 12,420 bytes per
RPC only if each message flushes individually. Actual paired reductions are
11,395.76–12,080.36 client / 12,415.52–12,433.76 server; no exact allocation-site
attribution follows.

Bulk has tradeoffs: 64-message pipelined server bytes increase **1.15% / 26.75%**
in the two repeats versus Safety, and **15.67% / 26.90%** versus fresh tonic.
Those are repeat ranges for one server scope, not client/server percentages.
Source instruction medians rise in 22 of 30 scopes versus before; unary server
rises 17.08% and client-stream server 17.66%. Every increase and mixed repeat stays
in the complete ledgers, including values below the 2% instruction band.

All thirty current native instruction groups are lower than fresh tonic in both
repeats, with median savings of 3.24–55.77%. **Shipping CPU remains a loss:** unary
server raw CPU/call at N=10,000 is 1.55–1.65 times tonic; N/2N slopes are
2.08–2.89 times. Native throughput is 13.6–18.3% lower at N=10,000. Tonic controls
also shift across processes. Shared-host timing remains unqualified; instruction
and allocation counters do not resolve the physical CPU result.

## Measurement scopes

| Phase | Captures | Successful RPCs | Scope |
|---|---:|---:|---|
| Native counters | 576 | 21,600 | Three sources, N25/50, two paired repeats |
| Callgrind | 540 | 8,100 | Three sources, N10/20, two paired repeats |
| Separate bulk | 240 | 9,000 | Safety/current; 1/2/3/4/64-message partitions |
| Separate shipping builds | 48 | 360,000 | Counters/profilers off; N5000/10000 |
| Separate selected syscalls | 8 | 12,000 | Traced, timing unqualified |
| Separate fd-aware traces | 8 | 600 | Own-child traces, timing unqualified |

Native plus Callgrind total **1,116 captures / 29,700 RPCs**. Other phases stay
separate. Actual offered/dispatched/completed/successful counts reconcile with
zero RPC failures, timeouts, overflow, unstarted or unfinished calls. Tracing
errors/restarts and unresolved calls at SIGTERM teardown are separate from RPC
accounting and remain in the raw traces.

Both endpoints use Prost for these transport comparisons. Gzip uses level 6,
zero-filled payloads and four streaming messages; server send buffers are
400 KiB, queues 16. The older pbrs interop results include different handler work
and are not substituted into this comparison. Current cold-process, entropy,
read-all, overload, physical-network and broader platform coverage remain open.

## What the repairs establish

The owner baseline receives valid output/status and recovers on the same
connection, but its copied and chained DATA owners cannot reenter the engine
during Drop. The repair retains original retired frames in a fixed outer batch;
locks exit before owners are destroyed, including the tested staging-unwind and
IO-error paths. Credit/EOS, partial tails, exactly-once Drop and many-frame controls
remain. A full retirement batch does not itself force a socket write or flush.
Generic current-frame Buf operations/panic owners and other legacy queues remain
separate audit work. The private scratch value sizes are layout diagnostics,
not heap requests, machine stack-frame size, RSS or measured speed.

Reset guards retain the selected peer/local cause through pre-shape cancellation
and unwind. Protobuf validation now passes decoded field numbers into a bounded,
allocation-free unknown-group skipper. Its five baseline structural failures
become nine passing root controls; valid nested groups, opaque unknown LEN bytes,
max field numbers and the shared recursion limit remain covered. Legacy numberless
low-level skip APIs keep their historical behavior. Required split-merge and eager
owned read-all design remain separate work.

## Failures and chronology

The raw record retains original reset/owner failures, stronger-owner compile and
fixture-EOF failures, then their explicit successors. The kernel's first test
attempt has 3 passes/6 failures: one opaque-LEN control accidentally used known
field 99. Corrected test-only tags produce 4 passes/5 real failures before the
repair and 9 passes after it. No earlier outcome is relabeled as passed.

The native controller captured all 576 successful rows, then exited **1** because
sparse source checkouts omitted plan files needed for ledger owner annotations.
Root materialized the exact Git blobs. A separate recovery validates all raw
counts/stdout/build pins, preserves four existing reports, reconstructs only two
missing reports and recomputes three ledgers. Its state is explicitly recovered,
with original_controller_passed=false. All 3,486 original input refs remain unchanged.

## Scheduling trace and remaining CPU question

Four native-server fd traces contain WAIT_BITSET_PRIVATE waits and zero
WAIT_PRIVATE entries matching the engine-lock acquisition path. Extra writes
resolve to eventfd notifications. TCP operation counts stay near two/RPC on both
peers; adjacent TCP operations change threads more often on native. These are
observations under tracing/background work, not task-wake/migration counts or a
complete CPU cause. The post-protocol ready-set recheck is a source hypothesis
requiring a causal control and fresh source-bound measurements.

## Resource days

Fresh `933bf877` general/deadline previews and days are **prepared, not started**.
The new deadline fixture has 30 cases; its shared-process compatibility and actual
preview/full duration are not supplied by preparation alone.

Earlier `7c02eb38` workers and publishers are absent. Preserved progress stopped
before the currently observed boot, giving strong environment-discontinuity
evidence. Exit cause is unavailable; no application failure or 24-hour pass is
established. No attempt is resumed or treated as running from a stale JSON state.
The older `beb4ecd9` completed days qualify only their own source/scopes.

## Reproduce and verify

[Results](results.json) link exact source/build/tool hashes, commands, complete
ledgers, profiles, failures, physical-checkout proofs and tracing records. The raw
archive omits ELF bytes and duplicate old C12 capture trees; retained build/ELF
hashes identify them. Source snapshots and helper generations remain distinct.

```sh
python3 check.py
```

[Manifest](manifest.json) · [Raw sources, commands, logs, counters and profiles](raw.tar.gz)
· [Execution decision](../../decisions/grpc-execution.md)

The checker verifies regular archive members and hashes without extracting files.
Complete current-source sustained resources, CPU/byte/bulk improvements, remaining
features/specification coverage, platforms/consumers/releases and controlled
per-side statistics before claiming production readiness or an overall ranking.
'''

for p,text in new.items():
 assert re.findall(r'```[^\n]*\n.*?```',text,re.S)==re.findall(r'```[^\n]*\n.*?```',originals[p],re.S),p
 if p=='docs/evidence/README.md':assert re.findall(r'<!--.*?-->',text,re.S)==re.findall(r'<!--.*?-->',originals[p],re.S)
 target=D/p;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
for name,text in [('README.md',capsule),('results.json',json.dumps(results,indent=2,allow_nan=False)+'\n')]:
 target=D/CAP/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(text)
metadata={'scope':'Q draft copies; tracked edit authorized but not yet applied by this writer','current':CURRENT,'source_inputs':{p:hashlib.sha256(t.encode()).hexdigest() for p,t in originals.items()},'outputs':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in D.rglob('*') if p.is_file()},'capsule_path':CAP,'benchmark_lines':len(new['docs/benchmarks.md'].splitlines()),'capsule_lines':len(capsule.splitlines())}
(Q/'architecture-c13-doc-drafts-prepared.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps({'draft_root':str(D),'benchmark_lines':metadata['benchmark_lines'],'capsule_lines':metadata['capsule_lines'],'files':len(metadata['outputs']),'tracked_edits':False}))
