use crate::h2_backend::codec::UserError;
use crate::h2_backend::codec::UserError::*;
use crate::h2_backend::frame::{self, Frame, FrameSize};
use crate::h2_backend::hpack;

use bytes::{Buf, BufMut, BytesMut};
use std::pin::Pin;
use std::task::{Context, Poll};
use tokio::io::{AsyncRead, AsyncWrite, ReadBuf};
use tokio_util::io::poll_write_buf;

use std::io::{self, Cursor, IoSlice};

// A macro to get around a method needing to borrow &mut self
macro_rules! limited_write_buf {
    ($self:expr) => {{
        let limit = $self.max_frame_size() + frame::HEADER_LEN;
        $self.buf.get_mut().limit(limit)
    }};
}

#[derive(Debug)]
pub struct FramedWrite<T, B> {
    /// Upstream `AsyncWrite`
    inner: T,
    final_flush_done: bool,
    /// Set when a frame is buffered. Cleared after `poll_flush` succeeds.
    /// An empty, already-flushed codec does not touch the socket again.
    needs_flush: bool,

    encoder: Encoder<B>,
}

#[derive(Debug)]
struct Encoder<B> {
    /// HPACK encoder
    hpack: hpack::Encoder,

    /// Write buffer
    ///
    /// TODO: Should this be a ring buffer?
    buf: Cursor<BytesMut>,

    /// Next frame to encode
    next: Option<Next<B>>,

    /// Last data frame
    last_data_frame: Option<frame::Data<B>>,

    /// Max frame size, this is specified by the peer
    max_frame_size: FrameSize,

    /// Chain payloads bigger than this.
    chain_threshold: usize,

    /// Min buffer required to attempt to write a frame
    min_buffer_capacity: usize,
}

#[derive(Debug)]
enum Next<B> {
    Data(frame::Data<B>),
    Continuation(frame::Continuation),
}

/// Initialize the connection with this amount of write buffer.
///
/// The minimum MAX_FRAME_SIZE is 16kb, so always be able to send a HEADERS
/// frame that big.
const DEFAULT_BUFFER_CAPACITY: usize = 16 * 1_024;

/// Chain payloads bigger than this when vectored I/O is enabled. The remote
/// will never advertise a max frame size less than this (well, the spec says
/// the max frame size can't be less than 16kb, so not even close).
const CHAIN_THRESHOLD: usize = 256;

/// Chain payloads bigger than this when vectored I/O is **not** enabled.
/// A larger value in this scenario will reduce the number of small and
/// fragmented data being sent, and hereby improve the throughput.
const CHAIN_THRESHOLD_WITHOUT_VECTORED_IO: usize = 1024;

// TODO: Make generic
impl<T, B> FramedWrite<T, B>
where
    T: AsyncWrite + Unpin,
    B: Buf,
{
    pub fn new(inner: T) -> FramedWrite<T, B> {
        let chain_threshold = if inner.is_write_vectored() {
            CHAIN_THRESHOLD
        } else {
            CHAIN_THRESHOLD_WITHOUT_VECTORED_IO
        };
        FramedWrite {
            inner,
            final_flush_done: false,
            needs_flush: false,
            encoder: Encoder {
                hpack: hpack::Encoder::default(),
                buf: Cursor::new(BytesMut::with_capacity(DEFAULT_BUFFER_CAPACITY)),
                next: None,
                last_data_frame: None,
                max_frame_size: frame::DEFAULT_MAX_FRAME_SIZE,
                chain_threshold,
                min_buffer_capacity: chain_threshold + frame::HEADER_LEN,
            },
        }
    }

    /// Returns `Ready` when `send` is able to accept a frame
    ///
    /// Calling this function may result in the current contents of the buffer
    /// to be flushed to `T`.
    pub fn poll_ready(&mut self, cx: &mut Context) -> Poll<io::Result<()>> {
        if !self.encoder.has_capacity() {
            // Try flushing
            ready!(self.flush(cx))?;

            if !self.encoder.has_capacity() {
                return Poll::Pending;
            }
        }

        Poll::Ready(Ok(()))
    }

    /// Returns whether a frame can be buffered without first flushing the
    /// underlying I/O object.
    pub(crate) fn has_capacity(&self) -> bool {
        self.encoder.has_capacity()
    }

    /// A previous `buffer` has not been flushed yet.
    #[inline]
    pub(crate) fn has_pending_flush(&self) -> bool {
        self.needs_flush
    }

    /// Buffer a frame.
    ///
    /// `poll_ready` must be called first to ensure that a frame may be
    /// accepted.
    pub fn buffer(&mut self, item: Frame<B>) -> Result<(), UserError> {
        self.needs_flush = true;
        self.encoder.buffer(item)
    }

    /// Buffer a DATA frame the caller already matched.
    pub(crate) fn buffer_data(&mut self, item: frame::Data<B>) -> Result<(), UserError> {
        self.needs_flush = true;
        self.encoder.buffer_data(item)
    }

    /// One frame, at least `chain_threshold` bytes. The head is stored and
    /// the body stays beside it for `writev`, so this does not take the
    /// small-frame copy path.
    #[inline(always)]
    pub(crate) fn wants_chain(&self, len: usize) -> bool {
        len >= self.encoder.chain_threshold && len <= self.max_frame_size()
    }

    /// Same bytes `buffer_data` would write for a chained payload. Inlined
    /// so the frame is stored into `next` once.
    #[inline(always)]
    pub(crate) fn buffer_chained_data(&mut self, mut v: frame::Data<B>) {
        self.needs_flush = true;
        let len = v.payload().remaining();
        debug_assert!(self.wants_chain(len));
        let head = v.head();
        head.encode_spare(len, self.encoder.buf.get_mut());
        if self.encoder.buf.get_ref().remaining() < self.encoder.chain_threshold
            && v.payload().chunk().len() < v.payload().remaining()
        {
            let extra_bytes = self.encoder.chain_threshold - self.encoder.buf.remaining();
            self.encoder.buf.get_mut().put(v.payload_mut().take(extra_bytes));
        }
        self.encoder.next = Some(Next::Data(v));
    }

    /// Buffer a HEADERS frame the caller already matched.
    pub(crate) fn buffer_headers(&mut self, item: Box<frame::Headers>) -> Result<(), UserError> {
        self.needs_flush = true;
        self.encoder.buffer_headers(item)
    }

    /// Flush buffered data to the wire
    pub fn flush(&mut self, cx: &mut Context) -> Poll<io::Result<()>> {
        if !self.needs_flush {
            return Poll::Ready(Ok(()));
        }
        loop {
            while !self.encoder.is_empty() {
                let n = match self.encoder.next {
                    Some(Next::Data(ref mut frame)) => {
                        // One contiguous payload is two slices: the encoded
                        // head and the body. Building those directly skips the
                        // cursor chain and its 64-slot vectored scratch.
                        let pos = self.encoder.buf.position() as usize;
                        let head_len = self.encoder.buf.get_ref().len().saturating_sub(pos);
                        let body_all =
                            frame.payload().chunk().len() == frame.payload().remaining();
                        if body_all && self.inner.is_write_vectored() {
                            let n = {
                                let head = &self.encoder.buf.get_ref()[pos..pos + head_len];
                                let body = frame.payload().chunk();
                                if head.is_empty() {
                                    ready!(Pin::new(&mut self.inner).poll_write(cx, body))?
                                } else if body.is_empty() {
                                    ready!(Pin::new(&mut self.inner).poll_write(cx, head))?
                                } else {
                                    let bufs = [IoSlice::new(head), IoSlice::new(body)];
                                    ready!(Pin::new(&mut self.inner).poll_write_vectored(
                                        cx, &bufs
                                    ))?
                                }
                            };
                            let head_wrote = n.min(head_len);
                            if head_wrote > 0 {
                                self.encoder.buf.set_position((pos + head_wrote) as u64);
                            }
                            let body_wrote = n - head_wrote;
                            if body_wrote > 0 {
                                frame.payload_mut().advance(body_wrote);
                            }
                            n
                        } else {
                            let mut buf = (&mut self.encoder.buf).chain(frame.payload_mut());
                            ready!(poll_write_buf(Pin::new(&mut self.inner), cx, &mut buf))?
                        }
                    }
                    _ => {
                        let pos = self.encoder.buf.position() as usize;
                        let n = {
                            let rest = &self.encoder.buf.get_ref()[pos..];
                            if rest.is_empty() {
                                0
                            } else {
                                ready!(Pin::new(&mut self.inner).poll_write(cx, rest))?
                            }
                        };
                        if n > 0 {
                            self.encoder.buf.set_position((pos + n) as u64);
                        }
                        n
                    }
                };
                if n == 0 {
                    // No progress is possible; retrying would busy-loop.
                    return Poll::Ready(Err(io::ErrorKind::WriteZero.into()));
                }
            }

            match self.encoder.unset_frame() {
                ControlFlow::Continue => (),
                ControlFlow::Break => break,
            }
        }

        // Flush the upstream
        ready!(Pin::new(&mut self.inner).poll_flush(cx))?;
        self.needs_flush = false;

        Poll::Ready(Ok(()))
    }

    /// Close the codec
    pub fn shutdown(&mut self, cx: &mut Context) -> Poll<io::Result<()>> {
        if !self.final_flush_done {
            ready!(self.flush(cx))?;
            self.final_flush_done = true;
        }
        Pin::new(&mut self.inner).poll_shutdown(cx)
    }
}

#[must_use]
enum ControlFlow {
    Continue,
    Break,
}

impl<B> Encoder<B>
where
    B: Buf,
{
    /// Clear the bytes just written. A finished DATA frame is parked for
    /// reclaim; a header write leaves `next` empty. Continuation is the only
    /// arm that encodes again, so it stays out of this call.
    #[inline]
    fn unset_frame(&mut self) -> ControlFlow {
        self.buf.set_position(0);
        self.buf.get_mut().clear();

        match self.next.take() {
            Some(Next::Data(frame)) => {
                self.last_data_frame = Some(frame);
                debug_assert!(self.is_empty());
                ControlFlow::Break
            }
            Some(Next::Continuation(frame)) => self.queue_continuation(frame),
            None => ControlFlow::Break,
        }
    }

    #[cold]
    #[inline(never)]
    fn queue_continuation(&mut self, frame: frame::Continuation) -> ControlFlow {
        let mut buf = limited_write_buf!(self);
        if let Some(continuation) = frame.encode(&mut buf) {
            self.next = Some(Next::Continuation(continuation));
        }
        ControlFlow::Continue
    }

    fn buffer(&mut self, item: Frame<B>) -> Result<(), UserError> {
        // The caller already checked. Release builds do not repeat it.
        debug_assert!(self.has_capacity());

        match item {
            Frame::Data(v) => self.buffer_data(v)?,
            Frame::Headers(v) => self.buffer_headers(v)?,
            Frame::PushPromise(v) => {
                let mut buf = limited_write_buf!(self);
                if let Some(continuation) = (*v).encode(&mut self.hpack, &mut buf) {
                    self.next = Some(Next::Continuation(continuation));
                }
            }
            Frame::Settings(v) => {
                v.encode(self.buf.get_mut());
                tracing::trace!(rem = self.buf.remaining(), "encoded settings");
            }
            Frame::GoAway(v) => {
                v.encode(self.buf.get_mut());
                tracing::trace!(rem = self.buf.remaining(), "encoded go_away");
            }
            Frame::Ping(v) => {
                v.encode(self.buf.get_mut());
                tracing::trace!(rem = self.buf.remaining(), "encoded ping");
            }
            Frame::WindowUpdate(v) => {
                v.encode(self.buf.get_mut());
                tracing::trace!(rem = self.buf.remaining(), "encoded window_update");
            }

            Frame::Priority(_) => {
                /*
                v.encode(self.buf.get_mut());
                tracing::trace!("encoded priority; rem={:?}", self.buf.remaining());
                */
                unimplemented!();
            }
            Frame::Reset(v) => {
                v.encode(self.buf.get_mut());
                tracing::trace!(rem = self.buf.remaining(), "encoded reset");
            }
        }

        Ok(())
    }

    fn buffer_data(&mut self, mut v: frame::Data<B>) -> Result<(), UserError> {
        // Ensure that the payload is not greater than the max frame.
        let len = v.payload().remaining();

        if len > self.max_frame_size() {
            return Err(PayloadTooBig);
        }

        if len >= self.chain_threshold {
            let head = v.head();

            // Room for this head was proved by `has_capacity`.
            head.encode_spare(len, self.buf.get_mut());

            // A short header is padded up to `chain_threshold` only when
            // the payload is several pieces. One contiguous payload is
            // already a single writev vector beside the header, so
            // copying its prefix into the header buffer does not
            // change the number of vectors.
            if self.buf.get_ref().remaining() < self.chain_threshold
                && v.payload().chunk().len() < v.payload().remaining()
            {
                let extra_bytes = self.chain_threshold - self.buf.remaining();
                self.buf.get_mut().put(v.payload_mut().take(extra_bytes));
            }

            // Save the data frame
            self.next = Some(Next::Data(v));
        } else {
            v.encode_chunk(self.buf.get_mut());

            // The chunk has been fully encoded, so there is no need to
            // keep it around
            assert_eq!(v.payload().remaining(), 0, "chunk not fully encoded");

            // Save off the last frame...
            self.last_data_frame = Some(v);
        }
        Ok(())
    }

    fn buffer_headers(&mut self, v: Box<frame::Headers>) -> Result<(), UserError> {
        let mut buf = limited_write_buf!(self);
        if let Some(continuation) = frame::Headers::encode_box(v, &mut self.hpack, &mut buf) {
            self.next = Some(Next::Continuation(continuation));
        }
        Ok(())
    }

    fn has_capacity(&self) -> bool {
        self.next.is_none()
            && (self.buf.get_ref().capacity() - self.buf.get_ref().len()
                >= self.min_buffer_capacity)
    }

    fn is_empty(&self) -> bool {
        match self.next {
            Some(Next::Data(ref frame)) => !frame.payload().has_remaining(),
            _ => !self.buf.has_remaining(),
        }
    }
}

impl<B> Encoder<B> {
    fn max_frame_size(&self) -> usize {
        self.max_frame_size as usize
    }
}

impl<T, B> FramedWrite<T, B> {
    /// Returns the max frame size that can be sent
    pub fn max_frame_size(&self) -> usize {
        self.encoder.max_frame_size()
    }

    /// Set the peer's max frame size.
    pub fn set_max_frame_size(&mut self, val: usize) {
        assert!(val <= frame::MAX_MAX_FRAME_SIZE as usize);
        self.encoder.max_frame_size = val as FrameSize;
    }

    /// Set the peer's header table size.
    pub fn set_header_table_size(&mut self, val: usize) {
        self.encoder.hpack.update_max_size(val);
    }

    /// Retrieve the last data frame that has been sent
    pub fn take_last_data_frame(&mut self) -> Option<frame::Data<B>> {
        self.encoder.last_data_frame.take()
    }

    /// Whether flush left a data frame for the prioritizer to reclaim.
    pub fn has_last_data_frame(&self) -> bool {
        self.encoder.last_data_frame.is_some()
    }

    pub fn get_mut(&mut self) -> &mut T {
        &mut self.inner
    }
}

impl<T: AsyncRead + Unpin, B> AsyncRead for FramedWrite<T, B> {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.inner).poll_read(cx, buf)
    }
}

// We never project the Pin to `B`.
impl<T: Unpin, B> Unpin for FramedWrite<T, B> {}

#[cfg(any())]
mod unstable {
    use super::*;

    impl<T, B> FramedWrite<T, B> {
        pub fn get_ref(&self) -> &T {
            &self.inner
        }
    }
}
