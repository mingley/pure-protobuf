# Fresh C13 resource and deadline diagnostics

Prepared only. No worktree, compiler, preview or day has run through these helpers.

| Input | Value |
|---|---|
| Source | `933bf8775b70d24d91fb46a7992eae343b60f0ea` |
| Source record | `architecture-c13-soak-source.json` |
| Source-record SHA256 | `ef6daae4144cbe3bb1696d5be8e06aef805cd8e6efa3b4989b5eb5bc94ec4342` |
| Repeated cases | 30: 3 original, 19 extended, 5 accounting, 3 pre-shape reset |
| Preview duration | 30 measured seconds each |
| Day duration | 86,400 measured seconds each |
| Test-process limits | 1 GiB AS; 128 FDs; 4,096 same-UID processes; CPU duration + 30 seconds |

The resource workload uses the unchanged pinned resource campaign, release
profile and seed 20261002. The repeated fixture copies all thirty cases from Git,
removes only test attributes, and calls them sequentially in separate modules.
All assertions remain. Its outer Tokio clock is paused; a separate `std::Instant`
measures duration. The three reset cases originally use ordinary Tokio tests.
Their compatibility in this process is unproved until the actual preview passes.
Repeated cycles are not new distinct tests or inferred RPC counts.

The wrapper retains strict initial FD/task baselines, zero idle decoded-cache
capacity, balanced leases, the existing cache budget and a one-second quiet
interval after cleanup. It records boot ID, PID start ticks, generation ID and
UTC/epoch metadata. Duration acceptance uses monotonic time, never epoch age.

## Root commands

Builds and previews need their own root compiler/execution window. They require
only the frozen source, so they can run while the full workspace check finishes.
The release compiler uses `work/rpc-target`, one job and nice 10; the workspace
runner uses its separate `work/stable-target`. Limits apply to test ELFs, not
compilers. Worktree preparation needs 100 MiB free; builds need 2 GiB at entry.

```sh
source_sha=ef6daae4144cbe3bb1696d5be8e06aef805cd8e6efa3b4989b5eb5bc94ec4342
helper=work/qualification/architecture-c13-soaks.py
python3 "$helper" prepare-deadline --source-sha256 "$source_sha" --execute
python3 "$helper" build-deadline --source-sha256 "$source_sha" --execute
python3 "$helper" preview-resource --source-sha256 "$source_sha" --execute
python3 "$helper" preview-deadline --source-sha256 "$source_sha" --execute
```

The deadline preparation creates a fresh detached source-equivalent worktree,
with only an untracked integration fixture added. It does not edit runtime,
manifest or lock files. The build preserves the release ELF, tools/features,
source hashes and closed compiler logs. That same copied ELF runs preview/day.

Day readiness additionally requires `architecture-c13-soak-gates.json`:

```json
{
  "schema": "pbrs.c13-soak-gates.v1",
  "source_pin": "933bf8775b70d24d91fb46a7992eae343b60f0ea",
  "root_reviewed": true,
  "qualified": false,
  "gates": {
    "asan": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []},
    "workspace": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []},
    "native": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []},
    "cpu": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []},
    "bulk": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []},
    "shipping": {"state": {"path": "ABSOLUTE", "bytes": 0, "sha256": "..."}, "files": []}
  }
}
```

This is a shape example, not a passing manifest. Root fills actual hashes and
nonempty closed proof/log references only after reviewing terminal phases.
Workspace verification checks the complete before/after physical Git inventories
and the unchanged full command/environment. ASAN checks actual phase/log records.
CPU/bulk/shipping use their actual `finished` plus `passed` schema and candidate
build identities. Native accepts only the explicit, reviewed postprocessing
recovery: the original controller still failed with exit 1; its successful raw
captures and recovery history are preserved. An arbitrary recovered file or the
old failed state cannot pass.

```sh
python3 "$helper" check-ready --kind resource --source-sha256 "$source_sha"
python3 "$helper" check-ready --kind deadline --source-sha256 "$source_sha"
```

Each separate root day grant binds exactly source_pin, source_sha256,
gates_sha256, root_granted:true and action `launch-c13-resource-day` or
`launch-c13-deadline-day`. Then:

```sh
python3 "$helper" launch --kind resource --source-sha256 "$source_sha" --grant ROOT_RESOURCE_GRANT --execute
python3 "$helper" launch --kind deadline --source-sha256 "$source_sha" --grant ROOT_DEADLINE_GRANT --execute
python3 "$helper" status --kind resource
python3 "$helper" status --kind deadline
```

| Output | Path below `work/qualification/` |
|---|---|
| Resource preview | `architecture-c13-resource-preview/report.json` |
| Deadline preview | `resource-architecture-c13-deadline-preview/report.json` |
| Resource day actual progress/report | `resource-architecture-c13-day/campaign/{progress,report}.json` |
| Resource outer state | `resource-architecture-c13-day/{launch,supervisor-state,report,termination,publication}.json` |
| Deadline day | `resource-architecture-c13-deadline-day/{launch,supervisor-state,progress,report,termination,publication}.json` |

## Process loss and terminal publication

`status` checks the recorded boot, PID namespace/start ticks and fresh supervisor
heartbeat. A saved `running` file alone is insufficient. A different generation
is interrupted; it is never resumed. Explicit `reconcile --kind ...
--source-sha256 ... --execute` may record an incomplete interruption only when
no original live or unobservable child can be affected. It preserves progress,
records an unavailable exit cause, and makes no application-failure claim.

Supervisors attempt terminal publication after normal pass/fail/incomplete
outcomes. A supervisor cannot survive disappearance of its environment; no host
retention or scheduler guarantee is made. A later explicit reconciliation and
publisher invocation can retain that interruption honestly. Old C12 attempts and
snapshots remain untouched and cannot contribute time to these fresh runs.

The compact publisher omits ELF bytes while retaining identities, archives finite
closed evidence and retries three normal sparse-main pushes. Compressed archives
above 90 MiB are split into parts no larger than 64 MiB; no Git artifact may reach
100 MiB. The checker verifies hashes and tar members without extraction. These
finite workloads do not independently establish overall production readiness or
broad comparative speed superiority.
