#!/usr/bin/env python3
"""Inventory C13 evidence; --package is used only after root's closed-preview grant."""
import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import subprocess
import tarfile

if not __debug__:
    raise RuntimeError('Run ordinary Python; assertion gates are required.')
ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
DEST = ROOT / 'docs/evidence/grpc-ownership-20261024'
BASE = '7c02eb387a6785d6e914146babe34f0902a6dd62'
FINAL = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
SCRIPT = Path(__file__).resolve()
CHECKER = Q / 'architecture-c13-capsule-check.py'
PREVIEWS = ('architecture-c13-resource-preview', 'resource-architecture-c13-deadline-preview')
PUBLICATIONS = ['README.md', 'TODO.md', 'docs/benchmarks.md', 'docs/decisions/grpc-execution.md',
                'docs/evidence/README.md', 'docs/status.md', 'docs/evidence/grpc-ownership-20261024/README.md',
                'docs/evidence/grpc-ownership-20261024/results.json']
PREFIXES = ('architecture-c13', 'kernel-unknown-group', 'architecture-c12c-single-ready-',
            'resource-c13', 'resource-architecture-c13')
MAGICS = (b'\x7fELF', b'MZ', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe')


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def reference(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def safe(name):
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and str(p) == name and not any(x in ('.', '..') for x in p.parts) and '\\' not in name and ':' not in name


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def code_paths():
    names = git('diff', '--name-only', BASE, FINAL).decode().splitlines()
    return [n for n in names if not n.startswith('docs/') and n not in ('README.md', 'TODO.md')]


def generated():
    paths = code_paths()
    out = {'qualification/source-final/compiled-code.patch': git('diff', '--binary', BASE, FINAL, '--', *paths)}
    inventory = []
    for name in paths:
        assert safe(name)
        data = git('show', FINAL + ':' + name)
        key = 'qualification/source-final/' + name
        out[key] = data
        inventory.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
    harness = ['Cargo.toml', 'Cargo.lock', 'pbrs-grpc/Cargo.toml', 'rpc-bench/Cargo.toml', 'rpc-bench/Cargo.lock',
               'rpc-bench/src/main.rs', 'scripts/grpc-counter-campaign.py', 'scripts/grpc-resource-campaign.py',
               'scripts/build-rpc-bench.py', 'scripts/grpc-load-smoke.py', 'scripts/dominance-ledger.py']
    for name in harness:
        out['qualification/source-final/harness/' + name] = git('show', FINAL + ':' + name)
    out['qualification/source-final/source.json'] = encoded({'qualified': False, 'baseline': BASE, 'current': FINAL,
        'current_tree': git('rev-parse', FINAL + '^{tree}').decode().strip(), 'changed_code_paths': inventory,
        'scope': 'Git object source snapshots and exact compiled-code/test patch. Documentation and older capsules excluded.'})
    for name in PUBLICATIONS:
        out['qualification/publication-context/' + name] = (ROOT / name).read_bytes()
    out['qualification/publication-context/capsule-check.py'] = CHECKER.read_bytes()
    return out


def preview_closed(name):
    p = Q / name / 'report.json'
    if not p.is_file() or p.is_symlink():
        return False
    r = json.loads(p.read_text())
    progress = Q / name / 'progress.json'
    if not progress.is_file() or progress.is_symlink():
        return False
    ended = json.loads(progress.read_text())
    if name == PREVIEWS[0]:
        return (r.get('schema') == 'pbrs.resource-campaign.v5'
                and r.get('source', {}).get('commit') == FINAL
                and r.get('smoke') == {'status': 'passed', 'failures': []}
                and r.get('exit_code') == 0 and r.get('duration_requested_seconds') == 30
                and r.get('duration_actual_seconds', 0) >= 30 and r.get('source', {}).get('dirty') is False
                and ended.get('state') == 'passed')
    return (r.get('state') == 'passed' and r.get('source_pin') == FINAL
            and r.get('exit_code') == 0 and r.get('qualified') is False
            and r.get('duration_actual_seconds', 0) >= 30 and r.get('requested_seconds') == 30
            and r.get('failures') == [] and r.get('runtime_source_equivalent') is True
            and r.get('source_pin_verified_at_end') is True and ended.get('state') == 'completed')


def paths_and_omissions():
    paths, omitted = [], []
    for child in sorted(Q.iterdir()):
        if not child.name.startswith(PREFIXES):
            continue
        name = child.name
        if name.startswith('architecture-c13-package-') or 'c14' in name.lower():
            continue
        if name in PREVIEWS and not preview_closed(name):
            omitted.append({'path': name, 'reason': 'preview tree not terminal; no live tree walked'})
            continue
        # Resource directory traversal is closed and explicitly allowlisted.
        if child.is_dir() and name.startswith('resource-') and name not in (PREVIEWS[1], 'resource-architecture-c13-deadline-build'):
            omitted.append({'path': name, 'reason': 'resource/live/soak tree outside closed allowlist'})
            continue
        if name.startswith(('architecture-c13-soak-resource-preview-execution', 'architecture-c13-soak-deadline-preview-execution')):
            base = name.rsplit('.', 1)[0]
            receipt = Q / (base + '.json')
            if not receipt.is_file() or json.loads(receipt.read_text()).get('exit_code') != 0:
                omitted.append({'path': name, 'reason': 'preview execution receipt not terminal'})
                continue
        if child.is_symlink():
            omitted.append({'path': name, 'reason': 'symlink not followed', 'target': os.readlink(child)})
            continue
        if child.is_dir():
            for directory, dirs, files in os.walk(child, followlinks=False):
                for n in list(dirs):
                    p = Path(directory) / n
                    if p.is_symlink() or n in ('__pycache__', '.git', 'target') or 'c14' in n.lower():
                        dirs.remove(n)
                        omitted.append({'path': p.relative_to(Q).as_posix(), 'reason': 'symlink/cache/C14 subtree not followed'})
                paths.extend(Path(directory) / n for n in files)
        else:
            paths.append(child)
    paths.extend([SCRIPT, ROOT / 'work/run-rust', ROOT / 'work/record.py'])
    return sorted(set(paths)), omitted


def inventory(closure_receipt=None):
    assert git('rev-parse', 'HEAD').decode().strip() == FINAL
    changed = set(git('diff', '--name-only', FINAL).decode().splitlines())
    assert changed <= set(PUBLICATIONS), 'tracked runtime/harness source changed: ' + str(changed - set(PUBLICATIONS))
    untracked = git('ls-files', '--others', '--exclude-standard').decode().splitlines()
    assert all(n.startswith('docs/evidence/grpc-ownership-20261024/') for n in untracked), untracked
    if closure_receipt is not None:
        assert closure_receipt.parent.resolve() == Q and closure_receipt.is_file() and not closure_receipt.is_symlink()
        closure = json.loads(closure_receipt.read_text())
        assert closure['source'] == FINAL and closure['qualified'] is False
        assert closure['c13_preview_processes_finished'] is True and closure['selected_writers_excluded'] is True
    files, aliases, omitted, inodes = [], [], [], {}
    paths, omitted = paths_and_omissions()
    if closure_receipt is not None and closure_receipt not in paths:
        paths.append(closure_receipt)
        paths.sort()
    for path in paths:
        rel = path.relative_to(Q).as_posix() if path.is_relative_to(Q) else 'support/' + path.name
        name = 'qualification/' + rel
        assert safe(name)
        st = path.lstat()
        if stat.S_ISLNK(st.st_mode):
            omitted.append({'path': name, 'reason': 'symlink not followed', 'target': os.readlink(path)})
            continue
        if not stat.S_ISREG(st.st_mode) or path.suffix in ('.pyc', '.pyo'):
            omitted.append({'path': name, 'reason': 'nonregular/bytecode'})
            continue
        with path.open('rb') as f:
            header = f.read(64)
        if header.startswith(MAGICS):
            omitted.append(dict(reference(path), path=name, reason='executable/library bytes omitted by magic; provenance retained'))
            continue
        row = dict(reference(path), path=name, source_path=str(path), device=st.st_dev, inode=st.st_ino, mtime_ns=st.st_mtime_ns)
        assert (path.stat().st_dev, path.stat().st_ino, path.stat().st_size, path.stat().st_mtime_ns) == (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns)
        key = (st.st_dev, st.st_ino)
        if key in inodes:
            original = inodes[key]
            assert (row['bytes'], row['sha256']) == (original['bytes'], original['sha256'])
            aliases.append({'path': name, 'canonical': original['path'], 'bytes': row['bytes'], 'sha256': row['sha256'], 'reason': 'same actual filesystem inode; bytes archived once'})
        else:
            inodes[key] = row
            files.append(row)
    generated_files = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(generated().items())]
    assert len({r['path'] for r in files + generated_files}) == len(files) + len(generated_files)
    return {'schema': 'pbrs.c13-package-plan.v1', 'qualified': False, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'baseline': BASE, 'source': FINAL, 'files': files, 'generated_files': generated_files, 'hardlink_aliases': aliases, 'omissions': omitted,
        'closure_receipt': reference(closure_receipt) if closure_receipt else None,
        'logical_bytes': sum(r['bytes'] for r in files + generated_files), 'preview_closed': {n: preview_closed(n) for n in PREVIEWS},
        'limits': 'Regular unique tar members only; executable bytes omitted by magic. No active resource/day/soak tree, C14, tar links or extraction. Root coordinates writer exclusion; this is not global procfs quiescence proof.'}


def package(plan_path, expected):
    assert expected and digest(plan_path) == expected
    plan = json.loads(plan_path.read_text())
    assert plan['schema'] == 'pbrs.c13-package-plan.v1' and plan['qualified'] is False and plan['source'] == FINAL
    assert all(plan['preview_closed'].values()), 'both actual C13 previews must finish before final freeze/package'
    assert plan['closure_receipt'] is not None, 'root-coordinated closed-process/writer receipt required'
    closure_path = Path(plan['closure_receipt']['path'])
    assert reference(closure_path) == plan['closure_receipt']
    current = inventory(closure_path)
    for key in ('files', 'generated_files', 'hardlink_aliases', 'omissions', 'preview_closed'):
        assert current[key] == plan[key], 'selected input changed after freeze: ' + key
    assert DEST.is_dir() and not DEST.is_symlink()
    assert {p.name for p in DEST.iterdir()} == {'README.md', 'results.json'}, 'never replace a final or partial capsule'
    generated_files = generated()
    rows = [{k: r[k] for k in ('path', 'bytes', 'sha256')} for r in plan['files'] + plan['generated_files']]
    frozen = encoded(plan)
    generated_files['qualification/packaging/frozen-inventory.json'] = frozen
    rows.append({'path': 'qualification/packaging/frozen-inventory.json', 'bytes': len(frozen), 'sha256': hashlib.sha256(frozen).hexdigest()})
    with (DEST / 'raw.tar.gz').open('xb') as output:
        with gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as tf:
                sources = {r['path']: Path(r['source_path']) for r in plan['files']}
                for row in sorted(rows, key=lambda r: r['path']):
                    member = tarfile.TarInfo(row['path']); member.size = row['bytes']; member.mode = 0o644; member.mtime = 0
                    if row['path'] in generated_files:
                        tf.addfile(member, io.BytesIO(generated_files[row['path']]))
                    else:
                        with sources[row['path']].open('rb') as f:
                            tf.addfile(member, f)
    # Ensure no selected input changed during streaming. No mutation of old evidence.
    after = inventory(closure_path)
    for key in ('files', 'generated_files', 'hardlink_aliases', 'omissions', 'preview_closed'):
        assert after[key] == plan[key], 'selected input changed during packaging: ' + key
    with (DEST / 'check.py').open('xb') as f:
        f.write(CHECKER.read_bytes())
    publication = [dict(reference(DEST / n), path=n) for n in ('README.md', 'results.json', 'check.py')]
    manifest = {'schema': 'pbrs.c13-capsule-manifest.v1', 'qualified': False, 'source': FINAL, 'baseline': BASE,
        'archive': dict(reference(DEST / 'raw.tar.gz'), name='raw.tar.gz'), 'files': sorted(rows, key=lambda r:r['path']),
        'logical_bytes': sum(r['bytes'] for r in rows), 'hardlink_aliases': plan['hardlink_aliases'], 'omissions': plan['omissions'],
        'publication_files': publication, 'frozen_plan': reference(plan_path), 'scope': plan['limits']}
    with (DEST / 'manifest.json').open('xb') as f:
        f.write(encoded(manifest))
    subprocess.run([os.sys.executable, str(DEST / 'check.py')], check=True)
    print(json.dumps({'state':'packaged', 'qualified':False, 'archive':reference(DEST/'raw.tar.gz'), 'manifest':reference(DEST/'manifest.json')}))


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--plan', type=Path)
    p.add_argument('--package', type=Path)
    p.add_argument('--expected-plan-sha256')
    p.add_argument('--closure-receipt', type=Path)
    args = p.parse_args()
    if args.package:
        assert not args.plan
        return package(args.package, args.expected_plan_sha256)
    assert args.plan, 'prepare with --plan NEW_Q_PATH; final packaging requires separate root grant'
    assert args.plan.parent.resolve() == Q and args.plan.name.startswith('architecture-c13-package-')
    value = inventory(args.closure_receipt)
    with args.plan.open('xb') as f:
        f.write(encoded(value))
    print(json.dumps({'state':'planned_not_packaged', 'qualified':False, 'plan':reference(args.plan), 'files':len(value['files'])+len(value['generated_files']),
        'logical_bytes':value['logical_bytes'], 'aliases':len(value['hardlink_aliases']), 'omissions':len(value['omissions']), 'preview_closed':value['preview_closed']}))


if __name__ == '__main__':
    main()
