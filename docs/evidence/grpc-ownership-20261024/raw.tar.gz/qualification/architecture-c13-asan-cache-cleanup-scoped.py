"""One-off authorized closed C13 cache trim, retaining reported ELFs in place."""
from pathlib import Path
import datetime, hashlib, json, os, re, shutil, stat, subprocess
ROOT=Path('/workspace/pure-protobuf');Q=ROOT/'work/qualification';CACHE=ROOT/'work/asan-c13-target'
INV=Q/'architecture-c13-asan-cache-inventory.json';RESULT=Q/'architecture-c13-asan-cache-cleanup.json'
assert not INV.exists() and not RESULT.exists(), 'immutable cleanup evidence already exists'
assert CACHE.is_dir() and not CACHE.is_symlink() and CACHE.resolve()==CACHE

def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for block in iter(lambda:f.read(1024*1024),b''):h.update(block)
 return h.hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def users():
 active=[];unreadable=[]
 for proc in Path('/proc').iterdir():
  if not proc.name.isdecimal():continue
  try:
   if proc.stat().st_uid!=os.getuid():continue
   raw=(proc/'stat').read_text();state=raw[raw.rfind(')')+2:].split()[0]
   if state=='Z':continue
   hits=[]
   for key in ['cwd','exe']:
    try:
     value=os.readlink(proc/key)
     if str(CACHE) in value:hits.append(key+':'+value)
    except FileNotFoundError:pass
   for fd in (proc/'fd').iterdir():
    try:
     value=os.readlink(fd)
     if str(CACHE) in value:hits.append('fd:'+value)
    except FileNotFoundError:pass
   if str(CACHE) in (proc/'maps').read_text():hits.append('mapped cache file')
   if hits:active.append(dict(pid=int(proc.name),references=hits))
  except (FileNotFoundError,ProcessLookupError):pass
  except PermissionError:unreadable.append(int(proc.name))
 return dict(active=active,unreadable=unreadable)
state_path=Q/'architecture-c13-asan-state.json';s=json.loads(state_path.read_text())
assert s['state']=='passed' and s['source_before']==s['source_after'] and len(s['executables'])==13
keep={Path(p) for p in s['executables']};reasons={str(p):['reported ASAN ELF'] for p in keep}
for path,item in s['executables'].items():
 p=Path(path);assert p.is_relative_to(CACHE) and stat.S_ISREG(p.lstat().st_mode)
 assert p.stat().st_size==item['bytes'] and sha(p)==item['sha256'],p
ldd_path=Q/'architecture-c13-asan-cache-ldd.json';ldd=json.loads(ldd_path.read_text());assert len(ldd)==13
assert {r['path'] for r in ldd}==set(s['executables'])
dependencies=[]
for row in ldd:
 assert row['exit_code']==0 and not row['stderr'].strip(),row
 for line in row['stdout'].splitlines():
  line=line.strip()
  if not line:continue
  if re.fullmatch(r'linux-vdso\.so\.1 \(0x[0-9a-fA-F]+\)',line):continue
  match=re.fullmatch(r'(?:\S+ => )?(/\S+) \(0x[0-9a-fA-F]+\)',line)
  assert match,('unknown ldd result',line)
  path=Path(match.group(1));assert path.exists(),path
  dependencies.append(dict(elf=row['path'],path=str(path),resolved=str(path.resolve())))
  seen=set()
  while path.is_relative_to(CACHE):
   assert path not in seen,'library symlink cycle';seen.add(path)
   info=path.lstat();keep.add(path);reasons.setdefault(str(path),[]).append('runtime dependency of '+row['path'])
   if stat.S_ISLNK(info.st_mode):
    target=os.readlink(path);path=Path(os.path.normpath(target if os.path.isabs(target) else str(path.parent/target)))
   else:assert stat.S_ISREG(info.st_mode);break
before_users=users();assert not before_users['active'],before_users
entry_free=shutil.disk_usage(ROOT).free;rows=[];directories=[]
for directory,dirs,files in os.walk(CACHE,followlinks=False):
 base=Path(directory);directories.append(base)
 for name in list(dirs):
  path=base/name
  if path.is_symlink():dirs.remove(name);files.append(name)
 for name in files:
  path=base/name;info=path.lstat();kind='symlink' if stat.S_ISLNK(info.st_mode) else 'file'
  assert kind=='symlink' or stat.S_ISREG(info.st_mode),path
  target=os.readlink(path) if kind=='symlink' else None
  digest=hashlib.sha256(os.fsencode(target)).hexdigest() if kind=='symlink' else sha(path)
  rows.append(dict(path=str(path.relative_to(CACHE)),kind=kind,bytes=info.st_size,sha256=digest,
   link_target=target,device=info.st_dev,inode=info.st_ino,mode=info.st_mode,mtime_ns=info.st_mtime_ns,
   retained=path in keep))
assert {CACHE/r['path'] for r in rows if r['retained']}==keep
inventory=dict(utc=now(),cache=str(CACHE),asan_state_sha256=sha(state_path),ldd_sha256=sha(ldd_path),
 source=s['source_after'],reported_ELFs=s['executables'],runtime_dependencies=dependencies,
 keep_reasons=reasons,users_before=before_users,entry_free_bytes=entry_free,
 files=rows,directories=[str(p.relative_to(CACHE)) for p in directories])
with INV.open('x') as out:json.dump(inventory,out,indent=2);out.write('\n')
assert not users()['active'],'new cache user after inventory'
removed=0;logical=0
for row in rows:
 path=CACHE/row['path']
 if row['retained']:continue
 info=path.lstat();assert (info.st_dev,info.st_ino,info.st_mode,info.st_size,info.st_mtime_ns)==(row['device'],row['inode'],row['mode'],row['bytes'],row['mtime_ns']),('cache changed',path)
 path.unlink();removed+=1;logical+=row['bytes']
parents={CACHE}
for path in keep:parents.update(path.parents)
for path in sorted(directories,key=lambda p:len(p.parts),reverse=True):
 if path not in parents:path.rmdir()
retained={}
for path in keep:
 info=path.lstat();digest=hashlib.sha256(os.fsencode(os.readlink(path))).hexdigest() if stat.S_ISLNK(info.st_mode) else sha(path)
 row=next(r for r in rows if CACHE/r['path']==path);assert digest==row['sha256']
 retained[str(path)]=dict(bytes=info.st_size,sha256=digest)
for p,item in s['executables'].items():assert retained[p]==dict(bytes=item['bytes'],sha256=item['sha256'])
remaining=[]
for directory,dirs,files in os.walk(CACHE,followlinks=False):
 for name in list(dirs):
  if (Path(directory)/name).is_symlink():dirs.remove(name);files.append(name)
 remaining.extend(Path(directory)/name for name in files)
assert set(remaining)==keep,remaining
free=shutil.disk_usage(ROOT).free
result=dict(state='passed',utc=now(),cache=str(CACHE),inventory=str(INV),inventory_sha256=sha(INV),
 source=s['source_after'],removed_files=removed,unlinked_logical_bytes=logical,
 entry_free_bytes=entry_free,free_bytes_after=free,observed_free_delta=free-entry_free,
 retained_files=retained,reported_ELFs_retained=13,runtime_cache_dependencies=len(keep)-13,
 users_before=before_users,ownership_basis='Root confirms monitored C13 Cargo/test groups terminal; only this generation generated cache artifacts are unlinked',
 source_after_cleanup=dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),status=subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True).strip()),
 limits=['Observed filesystem free delta can include concurrent work; logical unlinked sizes are separate.','Only owned closed ASAN cache generated artifacts removed; reported ELFs remain at original paths.','Some unrelated infrastructure /proc selectors are unavailable; this is not a claim of full-host quiescence.'])
with RESULT.open('x') as out:json.dump(result,out,indent=2);out.write('\n')
print(json.dumps({k:result[k] for k in ['state','removed_files','unlinked_logical_bytes','observed_free_delta','free_bytes_after','reported_ELFs_retained','runtime_cache_dependencies']}))
