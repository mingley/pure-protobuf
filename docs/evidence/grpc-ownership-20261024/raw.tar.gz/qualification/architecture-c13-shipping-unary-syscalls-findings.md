# Unary server syscall control

Eight captures completed successfully: 12,000 offered/dispatched/completed/successful RPCs, zero failed, timed out, overflowed, unstarted, or unfinished RPCs. Actual duration: 10.573 seconds. Source 933bf8775b70d24d91fb46a7992eae343b60f0ea, existing shipping binary, allocation counters off. Strace traced only the controller's own endpoint children. Callgrind and workspace compilation ran concurrently as approved.

These are syscall counts, not timing results. Strace changes scheduling and can create or amplify contention. The measured scheduling difference is a concrete lead; it does not yet prove the untraced CPU loss has the same cause.

## Server syscall slopes

Calls per RPC from signed (2,000-call total − 1,000-call total)/1,000. Both repeats shown; no threshold omissions.

| Syscall | Native | Tonic |
| --- | ---: | ---: |
| All syscalls | 13.429 / 13.277 | 6.503 / 4.868 |
| futex | 4.379 / 4.227 | 0 / 0 |
| epoll_wait | 3.683 / 3.638 | 2.510 / 1.784 |
| recvfrom | 2.356 / 2.436 | 1.993 / 1.084 |
| write | 1.012 / 0.978 | 0 / 0.001 |
| writev | 1 / 1 | 2 / 1.999 |
| sendto | 0.999 / 0.999 | 0 / 0 |

The main repeatable excess is futex activity, accompanied by more reactor waits and write calls. Aggregate write rows lack file descriptors: they cannot distinguish a reactor notification fd from a socket. Native sendto + writev is about two calls/RPC, similar to Tonic's two writev calls/RPC. Do not describe this capture as proof of three native socket writes or poor response coalescing.

## Client controls

The same Tonic client also varies by peer and repeat:

| Syscall | Tonic client / native server | Tonic client / Tonic server |
| --- | ---: | ---: |
| All syscalls | 11.057 / 13.429 | 12.858 / 15.240 |
| futex | 2.192 / 3.870 | 2.583 / 2.962 |
| epoll_wait | 3.236 / 3.307 | 3.683 / 4.525 |
| recvfrom | 1.157 / 1.053 | 1.630 / 2.114 |
| write | 1.472 / 2.199 | 1.965 / 2.639 |
| writev | 3 / 3.001 | 2.999 / 3.001 |

This reinforces the need to retain scheduling/control variation. Server and client lifetimes are different scopes. Counts are whole endpoint lifetimes, including connection/setup/reporting/teardown.

## Errors remain visible

No RPC failed. Syscall error returns are a separate measure and can include nonblocking readiness races. Server raw error totals at N/2N were native 31/47 and 53/54, Tonic 3/3 and 3/4. Server signed total-error slopes are native 0.016/0.001 and Tonic 0/0.001 per RPC. Negative component slopes remain in the full JSON; for example, native recvfrom errors fall by 0.006/RPC in repeat 1. The summary retains every syscall row, raw count and error count for both endpoints; the -c format does not record individual errno identities.

## First-principles next step

Native's steady server polls admitted handlers and the h2 driver on the same connection task. `h2_backend/proto/streams/prioritize.rs::queue_frame` consumes and wakes the registered connection waker after queueing work. `streams.rs::poll_complete` later registers it again. This can schedule the already-running connection task, but the code alone does not establish actual extra task polls, worker migrations, lock contention, or wake counts.

Investigate that connection-owned wake path before changing allocation policy or introducing a flush delay. A safe candidate must retain external producer notifications and idle-driver wakes while avoiding only a proven redundant current-task wake. A wake under the engine mutex can also bring another worker into a contended path; these aggregate futex counts do not identify which mutex or operation.

The approved next quiet replay proposal remains 16 untraced same-source captures / 120,000 RPCs, adjacent native-server and Tonic/Tonic controls with balanced N=5,000/10,000 ordering. It has not run. If fd attribution is needed first, propose a separate bounded own-child trace with fd decoding and selected futex/readiness/write calls; that would require another explicit grant and separate output namespace. Do not silently extend this completed eight-capture scope.

## Evidence

- Completion: `architecture-c13-shipping-unary-syscalls-completion.json`, SHA256 7ff2c54c12b5c065300b32869a1b2262bca12d5910144daa6515b93b298207e0. All 70 artifacts referenced.
- State: `architecture-c13-shipping-unary-syscalls-captures/state.json`, SHA256 5c931f966103b8df6ebe029a6f842b5e3018d2ed6c216e2e6b9f7e49d5f6e7ab.
- Full rows and signed slopes: `architecture-c13-shipping-unary-syscalls-captures/syscall-summary.json`, SHA256 f3d25f30ee6b234549573c95377b58d5f20cd3c4c71b62f386fdbf1a2fef3226.
- Execution: `resource-c13-unary-syscalls-execution.json`, unchanged controller SHA256 76b3c301ff07a4cb83863debad280568dd5d4999e59c94faa3fbd081202a4628.

No source edit, compiler, retry, permissions workaround, or additional workload ran in this control.
