from pathlib import Path
import difflib,hashlib,json
root=Path('/workspace/pure-protobuf');p=root/'pbrs-grpc/src/server/deadline.rs';old=p.read_text();s=old
start=s.index('    async fn unpolled_router_owner_drop_closes_lifecycle_and_terminal_capability() {')
end=s.index('    #[test]\n    fn pooled_call_does_not_carry',start)
section=s[start:end]
section=section.replace('''        struct Counts {
''','''        #[derive(Clone, Copy, Debug)]
        enum DropMode {
            NeverPolled,
            Pending,
            Panic,
        }
        struct Counts {
''',1)
section=section.replace('''            dropped_before_owner: AtomicUsize,
''','''            dropped_before_owner: AtomicUsize,
            panic_when_polled: bool,
''',1)
section=section.replace('''                assert_eq!(status.code(), crate::Code::Cancelled);
''','''                assert!(!std::thread::panicking(), "user callbacks stay outside unwinding");
                assert_eq!(status.code(), crate::Code::Cancelled);
''',1)
section=section.replace('''                    self.0.polls.fetch_add(1, Ordering::SeqCst);
                    std::future::pending::<()>().await;
''','''                    self.0.polls.fetch_add(1, Ordering::SeqCst);
                    assert!(!self.0.panic_when_polled, "intentional service-poll unwind control");
                    std::future::pending::<()>().await;
''',1)
body_start=section.index('        let counts = Arc::new(Counts {')
body_end=section.index('        let router_size =',body_start)
body=section[body_start:body_end]
body=body.replace('''            dropped_before_owner: AtomicUsize::new(0),
''','''            dropped_before_owner: AtomicUsize::new(0),
            panic_when_polled: matches!(mode, DropMode::Panic),
''',1)
body=body.replace('''        let driver = super::serve::<crate::rt::TokioRuntime, _>(&router, rpc);
        assert_eq!(counts.starts.load(Ordering::SeqCst), 1);
        assert_eq!(counts.polls.load(Ordering::SeqCst), 0);
        drop(driver); // Deliberately never polled.
        assert_eq!(counts.polls.load(Ordering::SeqCst), 0);
        assert_eq!(counts.ends.load(Ordering::SeqCst), 1);
''','''        let mut driver = Box::pin(super::serve::<crate::rt::TokioRuntime, _>(&router, rpc));
        assert_eq!(counts.starts.load(Ordering::SeqCst), 1);
        assert_eq!(counts.polls.load(Ordering::SeqCst), 0);
        match mode {
            DropMode::NeverPolled => {},
            DropMode::Pending => {
                let mut cx = Context::from_waker(Waker::noop());
                assert!(driver.as_mut().poll(&mut cx).is_pending());
                assert_eq!(counts.drops.load(Ordering::SeqCst), 0);
                assert_eq!(counts.ends.load(Ordering::SeqCst), 0);
            },
            DropMode::Panic => {
                let mut cx = Context::from_waker(Waker::noop());
                let result = std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| {
                    driver.as_mut().poll(&mut cx)
                }));
                assert!(result.is_err(), "the actual driver poll must unwind");
            },
        }
        drop(driver);
        assert_eq!(counts.polls.load(Ordering::SeqCst), usize::from(!matches!(mode, DropMode::NeverPolled)));
        assert_eq!(counts.drops.load(Ordering::SeqCst), 1);
        assert_eq!(counts.dropped_before_owner.load(Ordering::SeqCst), 1);
        if matches!(mode, DropMode::Panic) {
            assert!(counts.ends.load(Ordering::SeqCst) <= 1, "never duplicate user lifecycle callbacks");
        } else {
            assert_eq!(counts.ends.load(Ordering::SeqCst), 1);
        }
        eprintln!("actual driver drop control: mode={mode:?} polls={} drops={} before_owner={} observer_ends={}", counts.polls.load(Ordering::SeqCst), counts.drops.load(Ordering::SeqCst), counts.dropped_before_owner.load(Ordering::SeqCst), counts.ends.load(Ordering::SeqCst));
''',1)
assert 'Deliberately never polled.' not in body
wrapped='        async fn scenario(mode: DropMode) {\n'+''.join('    '+line if line.strip() else line for line in body.splitlines(keepends=True))+'        }\n        scenario(DropMode::NeverPolled).await;\n        scenario(DropMode::Pending).await;\n        scenario(DropMode::Panic).await;\n'
section=section[:body_start]+wrapped+section[body_end:]
s=s[:start]+section+s[end:]
out=root/'work/qualification/architecture-c13-reset-unwind-prepared';out.mkdir(exist_ok=False);(out/'deadline.rs').write_text(s)
patch=''.join(difflib.unified_diff(old.splitlines(keepends=True),s.splitlines(keepends=True),fromfile='a/pbrs-grpc/src/server/deadline.rs',tofile='b/pbrs-grpc/src/server/deadline.rs'))
(out/'test-only.patch').write_text(patch)
(out/'manifest.json').write_text(json.dumps({'qualified':False,'state':'prepared_not_applied_or_compiled','scope':'Actual returned driver never-polled, once-pending and caught-poll-panic drop order, with real native RPC/reset cleanup; does not claim whole-server panic recovery.','before_sha256':hashlib.sha256(old.encode()).hexdigest(),'prepared_sha256':hashlib.sha256(s.encode()).hexdigest(),'patch_sha256':hashlib.sha256(patch.encode()).hexdigest()},indent=2)+'\n')
print(out)
