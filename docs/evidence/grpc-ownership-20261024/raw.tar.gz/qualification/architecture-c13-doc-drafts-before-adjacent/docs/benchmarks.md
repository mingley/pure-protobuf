# Benchmarks

The native unary server still uses more CPU than tonic in the measured shipping build.
Some allocation and instruction counts are lower; remaining losses are listed first.

**Current `933bf877` · safety `ca4ef720` · before `7c02eb38`** · 2026-10-24 UTC · Linux x86_64 · Rust 1.99.1 · shared host.

## Shipping-build loss

Identity unary, 1 KiB, one connection / one in-flight call, two Tokio workers. Allocation counters and profilers are off.

| Server CPU | Native | tonic/prost | Native / tonic |
|---|---:|---:|---:|
| Raw CPU/call, 10,000 calls | 51 µs | 31–33 µs | 1.55–1.65× |
| N/2N CPU slope | 50–52 µs/RPC | 18–24 µs/RPC | 2.08–2.89× |

At 10,000 calls native throughput is 13.6–18.3% lower. Tonic controls also shift substantially across processes; these timing results need controlled replay.

## Requested allocation bytes

**Bytes/RPC, lower is better.** Equal Prost work, plaintext, one in flight. These are cumulative allocation requests, not RSS.

| Side | Workload | Current | tonic/prost | Change |
|---|---|---:|---:|---:|
| Client | Bidi, 1 KiB identity | 42.40 KiB | 40.11 KiB | +5.70% |
| Server | Bidi, 1 KiB identity | 31.32 KiB | 32.95 KiB | -4.94% |
| Client | Bidi, 1 MiB gzip | 19.41 MiB | 16.67 MiB | +16.40% |
| Server | Bidi, 1 MiB gzip | 18.40 MiB | 15.67 MiB | +17.43% |

Singleton identity bidi improves versus Safety: client −21.28%, server −27.92%. The conditional capacity model is separate from measured allocation-site proof.

## Costs versus earlier source

| Comparison | Side / workload | Metric/RPC | Before → current | Change; paired range |
|---|---|---|---:|---:|
| Before → current | server, unary 1 KiB identity | k instructions | 34.51 → 40.40 | +17.08%; +2.88..+35.07% |
| Before → current | server, upload 1 KiB identity | k instructions | 37.58 → 44.22 | +17.66%; +10.16..+25.40% |
| Safety → current | client, pipelined bidi 64 KiB identity | allocations | 45.18 → 49.06 | +8.59%; +2.24..+15.30% |
| Safety → current | server, pipelined bidi 64 × 1 KiB | KiB requested | 319.34 → 359.10 | +12.45%; +1.15..+26.75% |

The bulk server repeats lose +26.90% / +15.67% bytes versus fresh tonic. All increases, mixed repeats and control endpoints remain in the full ledgers.

## Instructions

**Million instructions/RPC: current / tonic (change).** All 30 scopes are lower in both repeats; medians are 3.24–55.77% lower.
Callgrind and allocation counting are enabled. Both endpoints use Prost, plaintext and one in-flight call. These counts do not establish shipping CPU speed.

| Workload | Client | Server |
|---|---:|---:|
| Unary, 1 KiB identity | 0.0294 / 0.0652 (-55.0%) | 0.0404 / 0.0563 (-28.2%) |
| Upload, 1 KiB identity | 0.0302 / 0.0682 (-55.8%) | 0.0442 / 0.0565 (-21.8%) |
| Server stream, 1 KiB identity | 0.0446 / 0.0719 (-38.0%) | 0.0551 / 0.0683 (-19.4%) |
| Bidi, 1 KiB identity | 0.0856 / 0.1300 (-34.2%) | 0.0948 / 0.1248 (-24.0%) |
| Pipelined bidi, 1 KiB identity | 0.0660 / 0.0968 (-31.9%) | 0.0668 / 0.0897 (-25.5%) |
| Unary, 1 KiB gzip | 0.6244 / 0.7386 (-15.5%) | 0.6372 / 0.7272 (-12.4%) |
| Upload, 1 KiB gzip | 2.0226 / 2.2368 (-9.6%) | 0.9748 / 1.1634 (-16.2%) |
| Server stream, 1 KiB gzip | 1.0323 / 1.2352 (-16.4%) | 2.0465 / 2.2369 (-8.5%) |
| Bidi, 1 KiB gzip | 2.4706 / 2.7862 (-11.3%) | 2.4787 / 2.7757 (-10.7%) |
| Pipelined bidi, 1 KiB gzip | 2.4491 / 2.7496 (-10.9%) | 2.4469 / 2.7379 (-10.6%) |
| Unary, 64 KiB gzip | 2.8975 / 3.0383 (-4.6%) | 2.9117 / 3.0091 (-3.2%) |
| Upload, 64 KiB gzip | 10.2525 / 10.7110 (-4.3%) | 1.8509 / 2.0370 (-9.1%) |
| Server stream, 64 KiB gzip | 3.9699 / 4.2263 (-6.1%) | 10.4035 / 10.8157 (-3.8%) |
| Bidi, 64 KiB gzip | 11.5608 / 12.1304 (-4.7%) | 11.5009 / 12.0580 (-4.6%) |
| Pipelined bidi, 64 KiB gzip | 11.6042 / 12.1126 (-4.2%) | 11.4817 / 12.0310 (-4.6%) |

Against before, 22 of 30 instruction medians rise. The ±2% ledger band is not a significance test; every smaller increase and repeat range is retained.

## Scope and records

| Campaign | Captures | Successful RPCs |
|---|---:|---:|
| Native counters, three sources | 576 | 21,600 |
| Callgrind, three sources | 540 | 8,100 |
| Separate bulk, Safety/current | 240 | 9,000 |
| Separate shipping builds | 48 | 360,000 |
| Separate selected syscall / fd traces | 8 / 8 | 12,000 / 600 |

Native N=25/50; Callgrind N=10/20; two paired repeats. The native controller failed after capture on missing plan files; separate recovery rebuilt reports without recapture.
Gzip level 6, zero-filled payloads, four streaming messages, 400 KiB server send buffers, queues 16. Bulk partitions use 1/2/3/4/64 messages.
Current-source cold-process, entropy/read-all, overload, physical networks and broader platform/feature coverage remain open; older C12 cold results are not inherited.

[Results, dated source and raw captures](evidence/grpc-ownership-20261024/README.md) · [Benchmark contract](benchmark-contract.md)

## Reproduce

Use a clean checkout and keep outputs outside it. Exact paired commands, profiles and source pins are in the record.

```sh
source_commit=$(git rev-parse HEAD)
bench_output=$(mktemp -d)
python3 scripts/build-rpc-bench.py \
  --source "$source_commit" --output "$bench_output/build"
python3 scripts/grpc-counter-campaign.py \
  --source-checkout "$PWD" \
  --binary "$bench_output/build/rpc-bench" \
  --build-record "$bench_output/build/build.json" \
  --output "$bench_output/counters" --phase native \
  --payloads 1024,65536 --load-levels 1:1,1:16 --repeats 3
```

**Validation:** 3,840 workspace tests pass (nine existing ignores); selected ASAN/leak checks pass 961 (one existing ignore). Current resource previews/days are prepared and unstarted.
Older `7c02eb38` days are interrupted, with no terminal outcome or known exit cause. Production readiness and broad superiority remain unproved. [Next work](../TODO.md#current-priorities)
