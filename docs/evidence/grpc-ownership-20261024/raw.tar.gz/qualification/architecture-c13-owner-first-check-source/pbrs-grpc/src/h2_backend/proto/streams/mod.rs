mod buffer;
mod counts;
mod flow_control;
#[cfg(target_os = "linux")]
mod lock;
#[cfg(not(target_os = "linux"))]
#[path = "lock/fallback.rs"]
mod lock;
mod prioritize;
mod recv;
mod send;
mod state;
mod store;
mod stream;
#[allow(clippy::module_inception)]
mod streams;

pub(crate) use self::prioritize::Prioritized;
pub(crate) use self::recv::Open;
pub(crate) use self::send::PollReset;
pub(crate) use self::streams::{DynStreams, OpaqueStreamRef, StreamRef, Streams};

use self::buffer::Buffer;
use self::counts::Counts;
use self::flow_control::FlowControl;
use self::prioritize::{Prioritize, RetiredData};
use self::recv::Recv;
use self::send::Send;
use self::state::State;
use self::store::Store;
use self::stream::Stream;

use crate::h2_backend::frame::{StreamId, StreamIdOverflow};
use crate::h2_backend::proto::*;

use bytes::Bytes;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Duration;

/// A queued frame or window update is visible to the connection task.
///
/// The load is the cheap case: the flag is already clear while data is in
/// flight. The store happens only on the idle-to-queued edge.
#[inline]
pub(super) fn clear_buffer_idle(flag: &AtomicBool) {
    if flag.load(Ordering::Acquire) {
        flag.store(false, Ordering::Release);
    }
}

#[derive(Debug, Eq, PartialEq)]
pub(super) enum BufferStatus {
    /// Frames were staged, or a partial write may still need reclaiming.
    Complete,
    /// The codec cannot accept another frame until it is flushed.
    CodecFull,
    /// Release a bounded owner batch before continuing the same encoded batch.
    RetiredFull,
    /// No window update, no queued frame, and nothing in flight.
    Idle,
}

#[derive(Debug)]
pub struct Config {
    /// Initial maximum number of locally initiated streams.
    /// After receiving a Settings frame from the remote peer,
    /// the connection will overwrite this value with the
    /// MAX_CONCURRENT_STREAMS specified in the frame.
    pub initial_max_send_streams: usize,

    /// Max amount of DATA bytes to buffer per stream.
    pub local_max_buffer_size: usize,

    /// The stream ID to start the next local stream with
    pub local_next_stream_id: StreamId,

    /// If the local peer is willing to receive push promises
    pub local_push_enabled: bool,

    /// If extended connect protocol is enabled.
    pub extended_connect_protocol_enabled: bool,

    /// How long a locally reset stream should ignore frames
    pub local_reset_duration: Duration,

    /// Maximum number of locally reset streams to keep at a time
    pub local_reset_max: usize,

    /// Maximum number of remotely reset "pending accept" streams to keep at a
    /// time. Going over this number results in a connection error.
    pub remote_reset_max: usize,

    /// Initial window size of remote initiated streams
    pub remote_init_window_sz: WindowSize,

    /// Maximum number of remote initiated streams
    pub remote_max_initiated: Option<usize>,

    /// Maximum number of locally reset streams due to protocol error across
    /// the lifetime of the connection.
    ///
    /// When this gets exceeded, we issue GOAWAYs.
    pub local_max_error_reset_streams: Option<usize>,

    /// connection-level budget (in bytes) for DATA framing overhead.
    ///
    /// Default 25600 bytes
    pub data_frame_budget: usize,
}

trait DebugStructExt<'a, 'b> {
    // h2_ prefixes to protect against possible future name collisions
    fn h2_field_if(&mut self, name: &str, val: &bool) -> &mut std::fmt::DebugStruct<'a, 'b>;

    fn h2_field_if_then<T: std::fmt::Debug>(
        &mut self,
        name: &str,
        cond: bool,
        val: &T,
    ) -> &mut std::fmt::DebugStruct<'a, 'b>;

    fn h2_field_some<T: std::fmt::Debug>(
        &mut self,
        name: &str,
        val: &Option<T>,
    ) -> &mut std::fmt::DebugStruct<'a, 'b>;
}

impl<'a, 'b> DebugStructExt<'a, 'b> for std::fmt::DebugStruct<'a, 'b> {
    fn h2_field_if(&mut self, name: &str, val: &bool) -> &mut std::fmt::DebugStruct<'a, 'b> {
        if *val { self.field(name, val) } else { self }
    }

    fn h2_field_if_then<T: std::fmt::Debug>(
        &mut self,
        name: &str,
        cond: bool,
        val: &T,
    ) -> &mut std::fmt::DebugStruct<'a, 'b> {
        if cond { self.field(name, val) } else { self }
    }

    fn h2_field_some<T: std::fmt::Debug>(
        &mut self,
        name: &str,
        val: &Option<T>,
    ) -> &mut std::fmt::DebugStruct<'a, 'b> {
        if val.is_some() {
            self.field(name, val)
        } else {
            self
        }
    }
}
