#!/usr/bin/env python3
"""Eight own-child fd-aware traces, feature-off unary server; no timing proof."""
import argparse
import ast
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
SOURCE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
ADAPTER = Q / 'architecture-c13-shipping-fdtrace-smoke.py'
ADAPTER_SHA = '5d09059a62671052be49f3d096ba28a88a51d85a282d40ae394c73cf20f5576c'
BUILDER = Q / 'architecture-c13-build-shipping-rpc.py'
BUILDER_SHA = 'a7aa4c07cddf2bab7e2d7c316e7e59a0f85decc504efad22c3238da1b1016410'
HARNESS_SHA = '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b'
STRACE = Path('/usr/bin/strace')
STRACE_SHA = '69f88291a4e47f258b8e32b089c919a247509f063ef3d6afe5389939051102b3'
ACCOUNTING = ('offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs',
              'failed_rpcs','timeouts','queue_overflows','unstarted_rpcs','unfinished_rpcs')
COUNTS = (50, 100)
PAIRS = (('tonic','prost','native','prost'), ('tonic','prost','tonic','prost'))


def ref(path):
    path = Path(path)
    return dict(path=str(path), bytes=path.stat().st_size,
                sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save(path, obj):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as f:
        json.dump(obj, f, indent=2, allow_nan=False)
        f.write('\n')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def verify_adapter(original):
    assert ref(ADAPTER)['sha256'] == ADAPTER_SHA
    assert ref(BUILDER)['sha256'] == BUILDER_SHA
    assert ref(original)['sha256'] == HARNESS_SHA
    shipping = Q / 'architecture-c13-shipping-smoke.py'
    old_controller = Q / 'architecture-c13-shipping-unary-syscalls.py'
    assert ref(shipping)['sha256'] == 'b3c9ed177c9a471c3aeb624b6dc26e4ced1408d03961d7d1890b1e7858affc7a'
    assert ref(old_controller)['sha256'] == '76b3c301ff07a4cb83863debad280568dd5d4999e59c94faa3fbd081202a4628'
    module('reviewed_shipping_syscall_controller', old_controller).verify_adapter(original)
    before = 'prefix = [str(args.strace), "-D", "-f", "-c", "-o"]'
    after = 'prefix = [str(args.strace), "-D", "-f", "-C", "-ttt", "-T", "-yy", "--always-show-pid", "-e", "trace=futex,write,writev,sendto,recvfrom,epoll_wait,epoll_pwait,epoll_pwait2,eventfd2", "-o"]'
    parser_before = 'def strace_syscalls(path):\n    rows = {}\n    total = None\n    for line in path.read_text().splitlines():'
    parser_after = 'def strace_syscalls(path):\n    rows = {}\n    total = None\n    # -C keeps the fd-aware full trace before its selected-syscall summary.\n    lines = path.read_text().splitlines()\n    headers = [i for i, line in enumerate(lines) if line.startswith("% time")]\n    if len(headers) != 1:\n        raise ValueError("full trace must have exactly one completed summary")\n    for line in lines[headers[0]:]:'
    text = shipping.read_text()
    assert text.count(before) == 1 and text.count(parser_before) == 1
    assert text.replace(before, after).replace(parser_before, parser_after) == ADAPTER.read_text()


def summarize(raw):
    rows = []
    for repeat in range(2):
        for pair in PAIRS:
            for side in ('client', 'server'):
                a, b = [raw[(repeat, pair, n)]['syscall_totals'][side] for n in COUNTS]
                calls = {}
                for name in sorted(set(a['syscall_counts']) | set(b['syscall_counts'])):
                    small = a['syscall_counts'].get(name, dict(calls=0, errors=0))
                    large = b['syscall_counts'].get(name, dict(calls=0, errors=0))
                    calls[name] = dict(small=small, large=large,
                        calls_per_rpc_slope=(large['calls']-small['calls'])/50,
                        errors_per_rpc_slope=(large['errors']-small['errors'])/50)
                rows.append(dict(repeat=repeat, pair=list(pair), side=side,
                    total_calls_per_rpc_slope=(b['calls']-a['calls'])/50,
                    total_errors_per_rpc_slope=(b['errors']-a['errors'])/50,
                    syscall_counts=calls))
    return dict(qualified=False, timing_qualified=False, rows=rows,
        scope='Explicitly selected syscalls over traced endpoint lifetime including startup/connection/reporting/teardown; all endpoint threads.',
        rule='Raw N and 2N counts and signed slopes retained; tracing changes scheduling. No timing or CPU claims.')


def execute(args):
    assert __debug__ and os.environ.get('PYTHONOPTIMIZE') == '0'
    config = args.sources.resolve(strict=True)
    config_ref = ref(config)
    sources = json.loads(config.read_text())
    assert set(sources) == {'baseline','candidate'}
    row = sources['candidate']
    assert row['source'] == SOURCE
    tree = Path(row['checkout']).resolve(strict=True)
    binary = Path(row['binary']).resolve(strict=True)
    record = Path(row['build_record']).resolve(strict=True)
    verify_adapter(tree / 'scripts/grpc-load-smoke.py')
    smoke = module('c13_shipping_syscall_capture', ADAPTER)
    build = smoke.verified_build(record, binary, tree)
    assert build['source']['commit'] == SOURCE
    assert ref(STRACE)['sha256'] == STRACE_SHA
    version = subprocess.check_output([str(STRACE),'--version'], text=True).splitlines()[0]
    assert version == 'strace -- version 6.13'
    pins = dict(controller=ref(Path(__file__).resolve()), adapter=ref(ADAPTER),
                builder=ref(BUILDER), config=config_ref, build_record=ref(record), strace=ref(STRACE))
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for src, name in [(Path(__file__).resolve(),'controller.py'),(ADAPTER,'capture-adapter.py'),
                      (BUILDER,'shipping-build-validator.py'),(config,'sources.json')]:
        shutil.copy2(src,output/name)
    state_path = output / 'state.json'
    state = dict(schema='pbrs.shipping-unary-fdtrace.v1', state='running', passed=False,
        qualified=False, timing_qualified=False, started_utc=now(), pins=pins,
        build=build, strace_version=version, allocation_counts=False, context_switches=False,
        source=SOURCE, rpc_counts=COUNTS, expected_captures=8, expected_successful_rpcs=600,
        completed=[], actual_rpc_totals={k:0 for k in ACCOUNTING},
        background=['Root-authorized concurrent Callgrind phase and full-workspace compilation jobs=2.'],
        limits=['Trace only controller-launched own children with explicitly derived -D -f -C fd-aware harness support.',
                'No timing/CPU/latency/throughput claim from traced captures.',
                'Full raw traces retained; -C summary counts only the explicit syscall selection.',
                'Full traces retain fd decoding, thread IDs, timestamps, futex operations and return values.',
                'No feature, TLS, worker, policy, queue, buffer or flushing setting changes.',
                'First failure retained; no retry, escalation, permission workaround or fallback.'])
    save(state_path,state)
    raw = {}
    def verify():
        assert ref(config) == pins['config'] and ref(Path(__file__).resolve()) == pins['controller']
        assert ref(record) == pins['build_record'] and ref(STRACE) == pins['strace']
        verify_adapter(tree / 'scripts/grpc-load-smoke.py')
        assert smoke.verified_build(record,binary,tree) == build
    try:
        for repeat in range(2):
            pairs = PAIRS if repeat == 0 else tuple(reversed(PAIRS))
            counts = COUNTS if repeat == 0 else tuple(reversed(COUNTS))
            for pair in pairs:
                for n in counts:
                    verify()
                    cell = dict(pair=list(pair),shape='unary',payload_bytes=1024,tls=False,
                                compression='identity',connections=1,in_flight=1,repeat=repeat)
                    child = output / ('capture-'+str(len(state['completed'])).zfill(3))
                    settings = SimpleNamespace(binary=binary,source_checkout=tree,duration=60,
                        rpc_count=n,allocation_counts=False,context_switches=False,callgrind=None,strace=STRACE)
                    result = smoke.run_cell(settings,cell,child)
                    state['completed'].append(dict(repeat=repeat,pair=list(pair),rpc_count=n,
                        run=ref(child/'run.json'),passed=result['passed']))
                    for key in ACCOUNTING:
                        value = result.get('metrics',{}).get(key)
                        if type(value) is int and value >= 0: state['actual_rpc_totals'][key] += value
                    save(state_path,state)
                    assert result['passed'], 'first failed capture retained: '+str(child)
                    assert result['cell'] == cell and result['client_exit_code'] == 0
                    assert not any(k in result for k in ('allocation_totals','context_switch_totals','instruction_totals'))
                    for side in ('client','server'):
                        assert result['commands'][side][:12] == [str(STRACE),'-D','-f','-C','-ttt','-T','-yy','--always-show-pid','-e','trace=futex,write,writev,sendto,recvfrom,epoll_wait,epoll_pwait,epoll_pwait2,eventfd2','-o',str(child/(side+'.strace'))]
                        totals = result['syscall_totals'][side]
                        assert totals == smoke.strace_syscalls(child/(side+'.strace'))
                    raw[(repeat,pair,n)] = result
                    verify()
        assert len(state['completed']) == 8
        assert all(state['actual_rpc_totals'][k] == 600 for k in ACCOUNTING[:4])
        assert all(state['actual_rpc_totals'][k] == 0 for k in ACCOUNTING[4:])
        summary = output/'fdtrace-summary.json'
        save(summary,summarize(raw))
        state.update(state='finished',passed=True,completed_utc=now(),summary=ref(summary))
        save(state_path,state)
    except BaseException as error:
        state.update(state='failed',passed=False,completed_utc=now(),
                     error=dict(type=type(error).__name__,message=str(error)))
        save(state_path,state)
        raise


def main():
    if not __debug__: raise RuntimeError('ordinary Python without -O required')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--sources',type=Path)
    p.add_argument('--output',type=Path)
    p.add_argument('--execute',action='store_true')
    args=p.parse_args()
    if not args.execute:
        print(json.dumps(dict(state='prepared_not_run',captures=8,rpc_counts=COUNTS,
            successful_rpcs=600,source=SOURCE,qualified=False),indent=2))
    else:
        assert args.sources is not None and args.output is not None
        execute(args)


if __name__ == '__main__': main()
