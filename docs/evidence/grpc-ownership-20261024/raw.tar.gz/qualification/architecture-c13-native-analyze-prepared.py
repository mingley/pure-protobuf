#!/usr/bin/env python3
"""Describe verified C13 native counters; retain every row and cost increase."""
import argparse
from collections import Counter, defaultdict
import datetime
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
RECOVERY_SHA = '009f3e4a898192956d27f172b9a072273ab69d0976de0f7381d6911d4d529665'
HELPER_SHA = '9405cd735ae296b0b57be197fcf29b7294fe5cb7f2a5311eeee83651dcf803d9'
COSTS = ['allocations', 'requested_bytes']
MEASURED = COSTS + ['context_switches']
STAGES = [('baseline', 'safety'), ('safety', 'batch'), ('baseline', 'batch')]


def digest(path):
    assert path.is_file() and not path.is_symlink(), path
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''): h.update(block)
    return h.hexdigest()


def ref(path):
    return {'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size}


def read(path):
    digest(path)
    return json.loads(path.read_text())


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def summary(values):
    valid = [x for x in values if x is not None]
    complete = len(valid) == len(values) and bool(values)
    return {'values': values, 'complete': complete, 'min': min(valid) if complete else None,
            'median': statistics.median(valid) if complete else None, 'max': max(valid) if complete else None}


def percent(before, after):
    return (after / before - 1) * 100 if before is not None and after is not None and before > 0 else None


def grouped(rows):
    groups = defaultdict(list)
    for row in rows:
        cell = {k: v for k, v in row['cell'].items() if k != 'repeat'}
        key = json.dumps([row['comparison'], cell, row['side'], row['metric']], sort_keys=True)
        groups[key].append(row)
    result = []
    for values in groups.values():
        values.sort(key=lambda r: r['cell']['repeat'])
        assert [r['cell']['repeat'] for r in values] == [0, 1]
        first = values[0]; before = summary([r['before'] for r in values]); after = summary([r['after'] for r in values])
        paired = summary([percent(r['before'], r['after']) for r in values])
        change = percent(before['median'], after['median'])
        result.append({'comparison': first['comparison'], 'cell': {k: v for k, v in first['cell'].items() if k != 'repeat'},
            'side': first['side'], 'metric': first['metric'], 'native_endpoint': first['cell']['pair'][0 if first['side'] == 'client' else 2] == 'native',
            'before': before, 'after': after, 'percent_of_medians': change, 'paired_percent': paired,
            'paired_saved': summary([r['before'] - r['after'] if r['before'] is not None and r['after'] is not None else None for r in values]),
            'directions': dict(Counter('unresolved' if p is None else 'higher' if p > 0 else 'lower' if p < 0 else 'equal' for p in paired['values'])),
            'any_positive_cost_repeat': first['metric'] in COSTS and any(p is not None and p > 0 for p in paired['values']),
            'positive_cost_median': first['metric'] in COSTS and change is not None and change > 0,
            'repeats': values})
    return result


def label(row):
    c = row['cell']; size = c['payload_bytes']; unit = f'{size // 1048576}MiB' if size >= 1048576 else f'{size // 1024}KiB'
    return f"{c['shape']} {unit} {c['compression']} {'TLS' if c['tls'] else 'plain'} / {c['in_flight']} in flight"


def display(value, metric):
    if value is None: return 'unresolved'
    return f'{value / 1024:,.2f}KiB' if metric == 'requested_bytes' else f'{value:,.2f}'


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output-prefix', type=Path, default=Q / 'architecture-c13-native-analysis')
    args = parser.parse_args()
    if not __debug__ or not args.execute or os.environ.get('PYTHONDONTWRITEBYTECODE') != '1':
        parser.error('ordinary Python, PYTHONDONTWRITEBYTECODE=1 and --execute required')
    prefix = args.output_prefix.resolve(); assert prefix.parent == Q
    assert not prefix.with_suffix('.json').exists() and not prefix.with_suffix('.md').exists()
    state_path = Q / 'architecture-c13-native-recovered/state.json'
    helper_path = Q / 'architecture-c13-native-recovery-prepared-v2.py'
    assert digest(state_path) == RECOVERY_SHA and digest(helper_path) == HELPER_SHA
    state = read(state_path)
    assert state['schema'] == 'pbrs.c13-native-postprocess-recovery.v1' and state['state'] == 'recovered'
    assert state['recovery_kind'] == 'postprocessing_only' and state['original_controller_passed'] is False
    assert state['original_controller_exit_code'] == 1 and state['raw_capture_passed'] is True and state['postprocessing_passed'] is True
    assert state['qualified'] is False and state['production_ready'] is False
    assert all(ref(Path(r['path'])) == r for r in state['inputs'])
    helpers = module('c13_numeric_recovery', helper_path)
    original = Path(state['original_root']); recovered = state_path.parent
    sources = read(original / 'sources.json'); assert list(sources) == list(helpers.COMMITS)
    contexts = {}; costs = {}; ledgers = {}; accounting = {}; input_refs = [ref(state_path), ref(helper_path)]
    for role, cfg in sources.items():
        tree = Path(cfg['checkout']); binary = Path(cfg['binary'])
        for relative, pin in helpers.PINS.items(): assert digest(tree / relative) == pin
        smoke = module('c13_numeric_smoke_' + role, tree / 'scripts/grpc-load-smoke.py')
        ledger = module('c13_numeric_ledger_' + role, tree / 'scripts/dominance-ledger.py')
        build = smoke.verified_build(Path(cfg['build_record']), binary, tree)
        assert cfg['source'] == build['source']['commit'] == helpers.COMMITS[role]
        contexts[role] = (tree, binary, cfg, smoke, ledger, build)
        a, small = ledger.load(recovered / role / 'n-25'); b, large = ledger.load(recovered / role / 'n-50')
        assert a['rpc_count'] == 25 and b['rpc_count'] == 50 and set(small) == set(large) and len(small) == 96
        totals = dict.fromkeys(helpers.COUNTERS, 0)
        costs[role] = {}
        for count in [25, 50]:
            for index, cell in enumerate(a['cells']):
                old = original / role / f'n-{count}' / f'cell-{index:03d}'
                new = recovered / role / f'n-{count}' / f'cell-{index:03d}'
                for path in old.iterdir(): assert os.path.samefile(path, new / path.name)
                metrics, _ = helpers.validate_capture(old, cell, count, smoke, binary, tree)
                for key in totals: totals[key] += metrics[key]
        assert totals == state['actual_rpc_totals'][role]
        accounting[role] = totals
        for identity, row in small.items():
            costs[role][identity] = {(side, metric): ledger.differential(row, large[identity], side, metric, 25)
                for side in ['client', 'server'] for metric in MEASURED}
        result = ledger.compare(recovered / role / 'n-25', recovered / role / 'n-50')
        ledger_path = recovered / role / 'ledger.json'; assert result == read(ledger_path)
        ledgers[role] = result; input_refs.append(ref(ledger_path))
    source_rows = []; tonic_rows = []
    for before, after in STAGES:
        assert set(costs[before]) == set(costs[after])
        for identity, first in costs[before].items():
            for (side, metric), value in first.items():
                source_rows.append({'comparison': before + '->' + after, 'cell': next(r['cell'] for r in ledger.load(recovered / before / 'n-25')[1].values() if ledger.key(r['cell']) == identity),
                    'side': side, 'metric': metric, 'before': value, 'after': costs[after][identity][side, metric]})
    for role, ledger_result in ledgers.items():
        for row in ledger_result['rows']:
            tonic_rows.append({'comparison': role + '->tonic', 'cell': row['cell'], 'side': row['side'], 'metric': row['metric'],
                'before': row['tonic_per_rpc'], 'after': row['native_per_rpc'], 'ledger_disposition': row['disposition']})
    source_groups = grouped(source_rows); tonic_groups = grouped(tonic_rows)
    assert all(ref(Path(r['path'])) == r for r in state['inputs'])
    for tree, binary, cfg, smoke, _, build in contexts.values(): assert smoke.verified_build(Path(cfg['build_record']), binary, tree) == build
    assert digest(state_path) == RECOVERY_SHA
    result = {'schema': 'pbrs.c13-native-numeric-analysis.v1', 'phase': 'native', 'qualified': False, 'production_ready': False,
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sources': helpers.COMMITS,
        'actual_captures': state['actual_captures'], 'actual_successful_rpcs': sum(v['successful_rpcs'] for v in accounting.values()),
        'actual_rpc_totals': accounting, 'original_controller_passed': False, 'recovery_state': ref(state_path),
        'analysis_helper': ref(Path(__file__).resolve()), 'inputs': input_refs,
        'source_groups': source_groups, 'same_side_tonic_groups': tonic_groups,
        'all_source_positive_cost_changes': [r for r in source_groups if r['any_positive_cost_repeat']],
        'all_tonic_positive_cost_changes': [r for r in tonic_groups if r['any_positive_cost_repeat']],
        'positive_cost_cutoff_percent': 0, 'missing_metrics': {k: v['missing_metrics'] for k, v in ledgers.items()},
        'capacity_models': {'source_only_bytes': [12480, 12420], 'measured_savings_claim': False,
            'scope': 'Source reservation arithmetic; observed safety->batch per-RPC byte deltas are retained separately. No exact model match or allocation-site attribution is asserted.'},
        'limits': ['576 raw captures, 25/50 calls, two paired repeats per workload/source; shared host.',
            'All endpoint source changes include tonic control endpoints; front selections use native endpoints only.',
            'Every increase in either repeat is retained, including positive changes below instruction tie bands and mixed directions.',
            'Requested bytes count allocation requests, not retained memory/RSS. Context switches are process scheduling events, not task wakeups.',
            'No shipping CPU, latency, throughput or broad superiority follows from native allocator counters.',
            'Original controller exited1 during postprocessing; separate recovery passed without recapture.']}
    with prefix.with_suffix('.json').open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    lines = ['# C13 native counters', '', 'Sources: ' + ', '.join(k + ' `' + v[:8] + '`' for k, v in helpers.COMMITS.items()) + '.',
        '', '**576 captures / 21,600 successful RPCs**; 7,200 per source. All terminal accounting errors are zero.',
        'Original controller failed in postprocessing; the separate recovery preserved every original artifact and performed no new captures.', '',
        'Lower is better. Values are medians of two N/2N differences per RPC; ranges below are the two paired percentage changes.', '']
    for comparison, groups in [('baseline->safety', source_groups), ('safety->batch', source_groups), ('baseline->batch', source_groups), ('batch->tonic', tonic_groups)]:
        lines += ['## ' + comparison, '', '| Metric | Side | Selection | Workload | Reference | Current | Change | Repeat range |', '|---|---|---|---|---:|---:|---:|---:|']
        for metric in COSTS:
            for side in ['client', 'server']:
                rows = [r for r in groups if r['comparison'] == comparison and r['metric'] == metric and r['side'] == side and r['native_endpoint'] and r['percent_of_medians'] is not None]
                chosen = [('Largest decrease', min(rows, key=lambda r: r['percent_of_medians'])), ('Largest increase', max(rows, key=lambda r: r['percent_of_medians']))]
                for name, row in chosen:
                    lines.append(f"| {metric} | {side} | {name} | {label(row)} | {display(row['before']['median'], metric)} | {display(row['after']['median'], metric)} | {row['percent_of_medians']:+.2f}% | {row['paired_percent']['min']:+.2f}% to {row['paired_percent']['max']:+.2f}% |")
    lines += ['', 'Every source/tonic row and every cost increase in either repeat remains in the JSON, including control endpoints, small increases and mixed directions.',
        'The 12,480/12,420B source-capacity models are not measured per-RPC savings or an exact allocation-site attribution.', '', *result['limits']]
    with prefix.with_suffix('.md').open('x') as stream: stream.write('\n'.join(lines) + '\n')
    print(json.dumps({'phase': 'native', 'qualified': False, 'captures': result['actual_captures'], 'successful_rpcs': result['actual_successful_rpcs'],
        'source_groups': len(source_groups), 'tonic_groups': len(tonic_groups), 'all_source_positive_groups': len(result['all_source_positive_cost_changes']), 'all_tonic_positive_groups': len(result['all_tonic_positive_cost_changes'])}))


if __name__ == '__main__':
    main()
