# Adjacent shipping unary replay

All 16 captures passed: 120,000 offered/dispatched/completed/successful RPCs, zero failures or unfinished calls. Actual duration: 14.466 seconds. Both pairs use the same existing 933bf feature-off shipping binary: Tonic client/native server and Tonic/Tonic, identity 1 KiB, one connection, one in-flight RPC, two workers. Four repeats balance pair and count order.

The native server CPU loss persists with adjacent controls. The earlier 2.08–2.89× N/2N slope magnitude did not repeat, so retain that original observation alongside this refreshed result. Do not promote either into a broad shipping superiority claim.

## Server CPU at 10,000 RPCs

Microseconds of observed server-window CPU per completed RPC, including the before-client to terminal-client window.

| Repeat | Native user + system = total | Tonic user + system = total | Native / Tonic |
| --- | ---: | ---: | ---: |
| 1 | 21 + 36 = 57 | 24 + 17 = 41 | 1.39× |
| 2 | 21 + 39 = 60 | 18 + 23 = 41 | 1.46× |
| 3 | 23 + 30 = 53 | 23 + 22 = 45 | 1.18× |
| 4 | 24 + 30 = 54 | 18 + 22 = 40 | 1.35× |

Kernel CPU accounts for most of the observed difference in every repeat. Native user CPU is sometimes lower or equal. This aligns with the separate scheduling/eventfd trace lead, but does not prove a particular wake or code path caused the untraced gap.

## Server N/2N slopes

| Repeat | Native user + system = total | Tonic user + system = total | Native / Tonic |
| --- | ---: | ---: | ---: |
| 1 | 22 + 40 = 62 | 30 + 10 = 40 | 1.55× |
| 2 | 20 + 48 = 68 | 8 + 30 = 38 | 1.79× |
| 3 | 22 + 24 = 46 | 26 + 20 = 46 | 1.00× |
| 4 | 30 + 22 = 52 | 4 + 34 = 38 | 1.37× |

All component and combined slopes were positive in this replay. One server total slope is equal; it is retained. Tonic-client CPU slopes are mixed across peers: 84/84/76/64 microseconds against native server versus 76/78/94/76 against Tonic. Full distributions, both endpoint raw counters, both N counts and every repeat are in the summary.

## Matched 10,000-call timing observations

Ratios are native-server pair / Tonic pair; higher throughput is better, lower latency is better. Quantiles and rates are never subtracted across N/2N.

| Repeat | Throughput ratio | Median latency ratio | p99 latency ratio |
| --- | ---: | ---: | ---: |
| 1 | 0.914 | 1.085 | 0.954 |
| 2 | 0.892 | 1.073 | 1.339 |
| 3 | 1.063 | 0.896 | 1.072 |
| 4 | 1.051 | 0.967 | 0.886 |

Timing observations remain mixed. Root held other known performance/compilation work during this capture window. Readable known-process scans before and after found no active matching compiler, benchmark endpoint or profiler; old zombies were excluded. Actual quota is four CPUs and process-clock resolution is 10 ms. This is not a dedicated-host or global-quiescence guarantee. Client lifetime CPU and server client-window CPU have different setup/reporting scopes.

Completion: `architecture-c13-shipping-unary-adjacent-completion.json`, SHA256 afc5c0251d297ddf16c0b086413d9a9d7ba7c7eb59803af40ac35d74c005ae55. All 102 capture artifacts referenced. Full summary SHA256 f0a6bf28cf5efe0d63e9085873124f408042302cfbfc433e2f585efde878a442.

No source edit, rebuild, profiler, retry, buffer/worker/policy change or additional endpoint run occurred in this replay.
