#!/usr/bin/env python3
"""Synthetic no-extraction checker controls; no real capsule/publication touched."""
from pathlib import Path
import hashlib
import io
import json
import runpy
import tarfile
import tempfile
Q = Path('/workspace/pure-protobuf/work/qualification')
CHECK = Q / 'architecture-c13-capsule-check.py'
check = runpy.run_path(str(CHECK))['check']
rows = []
for case in ['regular', 'alias', 'symlink', 'hardlink', 'traversal', 'duplicate', 'extra', 'wrong_hash', 'bad_alias', 'bad_results_ref']:
    with tempfile.TemporaryDirectory(dir=Q, prefix='architecture-c13-package-control-') as temp:
        d = Path(temp); payload = b'one'; sha = hashlib.sha256(payload).hexdigest()
        name = '../one' if case == 'traversal' else 'qualification/one'
        with tarfile.open(d/'raw.tar.gz', 'w:gz') as out:
            m = tarfile.TarInfo(name); m.size = len(payload)
            if case in ('symlink', 'hardlink'):
                m.type = tarfile.SYMTYPE if case == 'symlink' else tarfile.LNKTYPE
                m.linkname = '../escape'; m.size = 0
                out.addfile(m)
            else:
                out.addfile(m, io.BytesIO(payload))
                if case == 'duplicate':out.addfile(m, io.BytesIO(payload))
                if case == 'extra':
                    m = tarfile.TarInfo('qualification/extra'); m.size = 1
                    out.addfile(m, io.BytesIO(b'x'))
        raw=(d/'raw.tar.gz').read_bytes()
        manifest={'qualified':False,'archive':{'name':'raw.tar.gz','bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()},
                  'files':[{'path':name,'bytes':len(payload),'sha256':'0'*64 if case=='wrong_hash' else sha}],
                  'logical_bytes':len(payload),'hardlink_aliases':[]}
        result={}
        if case in ('alias','bad_alias'):
            manifest['hardlink_aliases']=[{'path':'qualification/two','canonical':'qualification/one' if case=='alias' else 'qualification/missing','bytes':3,'sha256':sha}]
            result={'path':'work/qualification/two','archive_path':'qualification/two','bytes':3,'sha256':sha}
        if case=='bad_results_ref':
            result={'path':'work/qualification/one','archive_path':'qualification/one','bytes':3,'sha256':'0'*64}
        (d/'results.json').write_text(json.dumps(result))
        (d/'manifest.json').write_text(json.dumps(manifest))
        failure=None
        try:check(d)
        except ValueError as e:failure=str(e)
        expected=case in ('regular','alias')
        assert (failure is None)==expected,(case,failure)
        rows.append({'case':case,'accepted':failure is None,'expected_accept':expected,'rejection':failure})
record={'state':'passed','qualified':False,'scope':'Ten bounded synthetic tar/checker controls only; no runtime or actual final capsule execution.',
        'checker_sha256':hashlib.sha256(CHECK.read_bytes()).hexdigest(),'controls':rows}
with (Q/'architecture-c13-capsule-check-controls.json').open('x') as f:
    json.dump(record,f,indent=2);f.write('\n')
print(json.dumps({'state':'passed','controls':len(rows)}))
