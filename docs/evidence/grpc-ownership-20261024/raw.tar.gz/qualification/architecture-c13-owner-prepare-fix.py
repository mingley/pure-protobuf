from pathlib import Path
import difflib
root=Path('/workspace/pure-protobuf')
files={name:(root/name).read_text() for name in [
'pbrs-grpc/src/h2_backend/proto/streams/mod.rs',
'pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs',
'pbrs-grpc/src/h2_backend/proto/streams/send.rs',
'pbrs-grpc/src/h2_backend/proto/streams/streams.rs']}
new=dict(files)
p='pbrs-grpc/src/h2_backend/proto/streams/mod.rs'
s=new[p].replace('use self::prioritize::Prioritize;','use self::prioritize::{Prioritize, RetiredData};').replace('    CodecFull,','    CodecFull,\n    /// Release a bounded owner batch before continuing the same encoded batch.\n    RetiredFull,',1);new[p]=s
p='pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs';s=new[p]
pos=s.index('// ===== impl Prioritize =====')
s=s[:pos]+'''// Scratch ownership for one staging pass, never stored in the engine. Visible
// bytes do not bound an opaque backing owner's size; bound the owner count.
const RETIRED_DATA_LIMIT: usize = 16;

pub(super) struct RetiredData<B> {
    frames: [Option<frame::Data<Prioritized<B>>>; RETIRED_DATA_LIMIT],
    len: usize,
}

impl<B> RetiredData<B> {
    pub(super) fn new() -> Self {
        Self { frames: [const { None }; RETIRED_DATA_LIMIT], len: 0 }
    }

    pub(super) fn is_full(&self) -> bool { self.len == RETIRED_DATA_LIMIT }

    fn push(&mut self, frame: frame::Data<Prioritized<B>>) {
        let slot = self.frames.get_mut(self.len).expect("retirement capacity checked before taking frame");
        debug_assert!(slot.is_none());
        *slot = Some(frame);
        self.len += 1;
    }

    fn last(&self) -> &frame::Data<Prioritized<B>> {
        self.frames.get(self.len.checked_sub(1).expect("retired frame present"))
            .and_then(Option::as_ref).expect("occupied retirement slot")
    }

    fn pop(&mut self) -> frame::Data<Prioritized<B>> {
        self.len = self.len.checked_sub(1).expect("retired frame present");
        self.frames.get_mut(self.len).and_then(Option::take).expect("occupied retirement slot")
    }

    pub(super) fn has_tail(&self) -> bool where B: Buf {
        self.last().payload().inner.has_remaining()
    }
}

'''+s[pos:]
# Only touch the contiguous reclaim/staging helper region.
start=s.index('    pub fn buffer_pending<T, B>(');end=s.index('    /// Push the frame to the front',start);part=s[start:end]
part=part.replace('        dst: &mut Codec<T, Prioritized<B>>,\n', '        dst: &mut Codec<T, Prioritized<B>>,\n        retired: &mut RetiredData<B>,\n')
part=part.replace('self.reclaim_frame(buffer, store, dst)', 'self.reclaim_frame(buffer, store, dst, retired)')
part=part.replace('''        loop {
            if !dst.has_send_capacity()''','''        loop {
            if retired.is_full() {
                return Ok(BufferStatus::RetiredFull);
            }
            if !dst.has_send_capacity()''',1)
part=part.replace('pub(super) fn reclaim_consumed<B>(&mut self, frame: frame::Data<Prioritized<B>>)','pub(super) fn reclaim_consumed<B>(&mut self, frame: &frame::Data<Prioritized<B>>)')
# Partial entry already belongs to the outer retirement batch.
part=part.replace('''        frame: frame::Data<Prioritized<B>>,
    ) -> bool''','''        retired: &mut RetiredData<B>,
    ) -> bool''')
part=part.replace('self.reclaim_frame_inner(buffer, store, frame)', 'self.reclaim_frame_inner(buffer, store, retired)')
part=part.replace('''        if let Some(frame) = dst.take_last_data_frame() {
            self.reclaim_frame_inner''','''        if let Some(frame) = dst.take_last_data_frame() {
            retired.push(frame);
            self.reclaim_frame_inner''')
# Inspect while still retained: panics cannot destroy a previously retired owner under locks.
part=part.replace('''        let mut eos = false;
        let key = frame.payload().stream;''','''        let frame = retired.last();
        let key = frame.payload().stream;
        let eos = frame.payload().end_of_stream;''')
old='''        let mut frame = frame.map(|prioritized| {
            // TODO: Ensure fully written
            eos = prioritized.end_of_stream;
            prioritized.inner
        });

        if frame.payload().has_remaining() {
            let mut stream = store.resolve(key);

            if eos {
                frame.set_end_stream(true);
            }

            self.push_back_frame(frame.into(), buffer, &mut stream);

            return true;
        }

        false'''
replacement='''        if !retired.has_tail() {
            return false;
        }
        // Resolve before removing the frame from the outer owner batch.
        let mut stream = store.resolve(key);
        let mut frame = retired.pop().map(|prioritized| prioritized.inner);
        if eos {
            frame.set_end_stream(true);
        }
        self.push_back_frame(frame.into(), buffer, &mut stream);
        true'''
assert old in part;part=part.replace(old,replacement)
s=s[:start]+part+s[end:];new[p]=s
p='pbrs-grpc/src/h2_backend/proto/streams/send.rs';s=new[p];start=s.index('    pub fn buffer_pending<T, B>(');end=s.index('    /// Request capacity to send data',start);part=s[start:end]
part=part.replace('        dst: &mut Codec<T, Prioritized<B>>,\n','        dst: &mut Codec<T, Prioritized<B>>,\n        retired: &mut RetiredData<B>,\n').replace('self.prioritize.buffer_pending(buffer, store, counts, dst)','self.prioritize.buffer_pending(buffer, store, counts, dst, retired)').replace('self.prioritize.reclaim_written_frame(buffer, store, dst)','self.prioritize.reclaim_written_frame(buffer, store, dst, retired)').replace('pub(super) fn reclaim_consumed<B>(&mut self, frame: frame::Data<Prioritized<B>>)','pub(super) fn reclaim_consumed<B>(&mut self, retired: &RetiredData<B>)').replace('self.prioritize.reclaim_consumed(frame);','self.prioritize.reclaim_consumed(retired.last());').replace('        frame: frame::Data<Prioritized<B>>,\n','        retired: &mut RetiredData<B>,\n').replace('self.prioritize.reclaim_partial(buffer, store, frame)','self.prioritize.reclaim_partial(buffer, store, retired)')
s=s[:start]+part+s[end:];new[p]=s
# RetiredData last is needed by Send's forwarding layer.
p='pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs';new[p]=new[p].replace('    fn last(&self)', '    pub(super) fn last(&self)')
p='pbrs-grpc/src/h2_backend/proto/streams/streams.rs';s=new[p]
s=s.replace('''                BufferStatus::CodecFull => ready!(dst.poll_ready(cx))?,''','''                BufferStatus::CodecFull => ready!(dst.poll_ready(cx))?,
                BufferStatus::RetiredFull => unreachable!("receive-only buffering retires no DATA"),''',1)
start=s.index('            // Declare the owner outside the lock scope');end=s.index('            match status {',start)
part=s[start:end]
part=part.replace('''            let discarded;
            let status = {''','''            let status = loop {
                let mut retired = RetiredData::new();
                let discarded;
                let status = {''',1)
part=part.replace('me.buffer_pending(&self.send_buffer, dst)?','me.buffer_pending(&self.send_buffer, dst, &mut retired)?')
part=part.replace('''            drop(discarded);

''','''                drop(discarded);
                drop(retired);
                if status == BufferStatus::RetiredFull {
                    // Preserve the existing codec batch: owners need an unlock,
                    // not a socket flush or another poll_ready call.
                    continue;
                }
                break status;
            };

''',1)
s=s[:start]+part+s[end:]
s=s.replace('''                BufferStatus::CodecFull => continue,''','''                BufferStatus::CodecFull => continue,
                BufferStatus::RetiredFull => unreachable!("retirement batches drained before IO"),''',1)
s=s.replace('''            let discarded;
            let reclaimed = {''','''            let mut retired = RetiredData::new();
            let discarded;
            let reclaimed = {''',1).replace('me.reclaim_written_frame(&self.send_buffer, dst)','me.reclaim_written_frame(&self.send_buffer, dst, &mut retired)',1)
s=s.replace('''            drop(discarded);

            if !reclaimed''','''            drop(discarded);
            drop(retired);

            if !reclaimed''',1)
start=s.index('    fn buffer_pending<T, B>(');end=s.index('    fn send_reset<B>(',start);part=s[start:end]
part=part.replace('        dst: &mut Codec<T, Prioritized<B>>,\n','        dst: &mut Codec<T, Prioritized<B>>,\n        retired: &mut RetiredData<B>,\n')
part=part.replace('''            dst,
        )?;''','''            dst,
            retired,
        )?;''',1)
part=part.replace('''        if send_status == BufferStatus::CodecFull {
            return Ok(BufferStatus::CodecFull);
        }''','''        if matches!(send_status, BufferStatus::CodecFull | BufferStatus::RetiredFull) {
            return Ok(send_status);
        }''')
part=part.replace('''        if !frame.payload().has_remaining() {
            self.actions.send.reclaim_consumed(frame);''','''        retired.push(frame);
        if !retired.has_tail() {
            self.actions.send.reclaim_consumed(retired);''')
part=part.replace('.reclaim_partial(send_buffer, &mut self.store, frame)', '.reclaim_partial(send_buffer, &mut self.store, retired)')
s=s[:start]+part+s[end:];new[p]=s
# Push is used by post-flush reclaim in the sibling module too.
p='pbrs-grpc/src/h2_backend/proto/streams/prioritize.rs';new[p]=new[p].replace('    fn push(&mut self, frame:', '    pub(super) fn push(&mut self, frame:')
patch=''.join(''.join(difflib.unified_diff(files[p].splitlines(True),new[p].splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in files)
(root/'work/qualification/architecture-c13-owner-production-proposed.patch').write_text(patch)
