from pathlib import Path
import subprocess,json,hashlib,shutil,datetime,os
root=Path.cwd();q=root/'work/qualification';b=root/'target/conformance-build'
def sha(p):
    h=hashlib.sha256()
    with p.open('rb') as f:
        for c in iter(lambda:f.read(1<<20),b''):h.update(c)
    return h.hexdigest()
def run(*args):return subprocess.check_output(args,text=True).strip()
pin=(root/'vendor/google/PIN').read_text().strip();expected=(root/'vendor/google/SHA').read_text().strip()
build=json.loads((q/'kernel-unknown-group-cmake-build.json').read_text());assert build['exit_code']==0 and not build.get('timeout')
assert run('git','-C',str(root/'third_party/protobuf'),'rev-parse','HEAD')==expected
assert run('git','-C',str(root/'third_party/protobuf'),'status','--porcelain')==''
version=run(str(b/'protoc'),'--version');assert version=='libprotoc '+pin[1:]
retained=q/'kernel-unknown-group-official-tools-v2';retained.mkdir()
artifacts={}
for name in ['protoc','conformance_test_runner']:
    declared=b/name;source=declared.resolve(strict=True)
    assert source.parent==b.resolve() and source.is_file() and not source.is_symlink()
    dest=retained/name;assert not dest.exists();shutil.copyfile(source,dest);dest.chmod(0o700)
    assert sha(source)==sha(dest)
    artifacts[name]={'path':str(declared.relative_to(root)),'symlink':os.readlink(declared) if declared.is_symlink() else None,'resolved_target':str(source.relative_to(root)),'copy':str(dest.relative_to(root)),'bytes':dest.stat().st_size,'sha256':sha(dest)}
assert run(str(retained/'protoc'),'--version')==version
stamp=b/'.pbrs-protobuf-pin';assert not stamp.exists()
with stamp.open('x') as f:f.write(pin+' '+expected+'\n')
deps={}
for name in ['absl','jsoncpp']:
    path=b/'_deps'/f'{name}-src';deps[name]={'head':run('git','-C',str(path),'rev-parse','HEAD'),'status':run('git','-C',str(path),'status','--porcelain'),'origin':run('git','-C',str(path),'remote','get-url','origin')}
cmake=root/'work/toolchain/cmake/cmake/data/bin/cmake'
record={'scope':'actual pinned tool provisioning; no Rust qualification claim','observed_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'upstream_source':{'pin':pin,'head':expected,'status':''},'protoc_version':version,'artifacts':artifacts,'cmake':{'version':run(str(cmake),'--version'),'path':str(cmake.relative_to(root)),'sha256':sha(cmake)},'compiler':run('/usr/bin/c++','--version'),'make':run('/usr/bin/make','--version'),'cmake_cache_sha256':sha(b/'CMakeCache.txt'),'dependency_sources':deps,'build_record':{'path':'work/qualification/kernel-unknown-group-cmake-build.json','sha256':sha(q/'kernel-unknown-group-cmake-build.json'),'exit_code':build['exit_code'],'duration_seconds':build['duration_seconds']},'stamp':{'path':str(stamp.relative_to(root)),'contents':stamp.read_text(),'sha256':sha(stamp)},'rust_or_generator_execution_after_fix':False}
with (q/'kernel-unknown-group-official-tool-provenance-v2.json').open('x') as f:json.dump(record,f,indent=2);f.write('\n')
print(json.dumps(record,indent=2))
