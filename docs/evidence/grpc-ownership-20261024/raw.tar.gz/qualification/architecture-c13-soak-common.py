#!/usr/bin/env python3
"""Source, closed-gate and process-generation checks for the fresh C13 days."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import resource
import runpy
import subprocess
import time
import tomllib
import uuid

if not __debug__:
    raise RuntimeError('soak checks require enabled Python assertions')
ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
TREE = ROOT / 'work/architecture-c13-batch'
SOURCE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
PINS = Q / 'architecture-c13-soak-source.json'
GATES = Q / 'architecture-c13-soak-gates.json'
EMPTY = hashlib.sha256(b'').hexdigest()
OVERLAY = 'pbrs-grpc/tests/deadline_sustained.rs'
DIAGNOSTIC = 'repeated independent-peer deadline and pre-shape-reset fixture'
RESOURCE_PREVIEW = Q / 'architecture-c13-resource-preview/report.json'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def ref(path):
    p = Path(path).resolve()
    return {'path': str(p), 'bytes': p.stat().st_size, 'sha256': digest(p)}


def load(path):
    return json.loads(Path(path).read_text())


def verify(reference):
    p = Path(reference['path'])
    assert p.is_absolute() and not p.is_symlink()
    assert p.resolve().is_relative_to(Q) or p.resolve() in {ROOT / 'work/run-rust', ROOT / 'work/record.py'}
    assert digest(p) == reference['sha256']
    if 'bytes' in reference:
        assert p.stat().st_size == reference['bytes']
    return p


def atomic(path, value):
    path = Path(path)
    temporary = path.with_name(path.name + '.next.' + str(os.getpid()))
    with temporary.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())
    temporary.replace(path)


def exclusive(path, value):
    with Path(path).open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def publish_once(path, value, staging):
    temporary = Path(staging) / (Path(path).name + '.publish.' + str(os.getpid()))
    atomic(temporary, value)
    os.link(temporary, path)
    temporary.unlink()


def git(*args, cwd=TREE):
    return subprocess.check_output(['git', *args], cwd=cwd, text=True).strip()


def source(cwd=TREE):
    return {'head': git('rev-parse', 'HEAD', cwd=cwd),
            'status': git('status', '--porcelain', '--untracked-files=all', cwd=cwd)}


def pins(expected_sha):
    assert re.fullmatch(r'[0-9a-f]{64}', expected_sha or '')
    assert not PINS.is_symlink() and digest(PINS) == expected_sha
    data = load(PINS)
    assert data['schema'] == 'pbrs.c13-soak-source.v1' and data['qualified'] is False
    assert data['candidate_runtime'] == SOURCE and data['fixture_cases_per_cycle'] == 30
    assert source() == {'head': SOURCE, 'status': ''}
    assert git('rev-parse', 'HEAD^{tree}') == data['candidate_tree']
    for name, sha in data['harness'].items():
        assert digest(TREE / name) == sha
    verify(data['fixture'])
    verify(data['wrapper'])
    return data


def caps(seconds):
    return {'address_space': 1073741824, 'file_descriptors': 128,
            'same_uid_processes': 4096, 'cpu_seconds': seconds + 30}


def boot_id():
    return Path('/proc/sys/kernel/random/boot_id').read_text().strip()


def clock():
    return {'boot_id': boot_id(), 'utc': now(), 'epoch_seconds': time.time(),
            'monotonic_seconds': time.monotonic(), 'pid_namespace': os.readlink('/proc/self/ns/pid')}


def generation():
    return {'id': uuid.uuid4().hex, 'source_pin': SOURCE, **clock()}


def same_generation(gen):
    return gen['boot_id'] == boot_id() and gen['pid_namespace'] == os.readlink('/proc/self/ns/pid') and time.monotonic() >= gen['monotonic_seconds']


def process_identity(pid):
    directory = Path('/proc') / str(pid)
    try:
        raw = (directory / 'stat').read_text()
        fields = raw[raw.rfind(')') + 2:].split()
        if fields[0] == 'Z':
            return None
        return {'pid': int(pid), 'pid_start_ticks': int(fields[19]), 'boot_id': boot_id(),
                'ppid': int(fields[1]), 'process_group': int(fields[2]), 'session': int(fields[3]),
                'pid_namespace': os.readlink('/proc/self/ns/pid'),
                'state': fields[0], 'command': os.fsdecode((directory / 'cmdline').read_bytes()).rstrip('\0').split('\0')}
    except (FileNotFoundError, ProcessLookupError):
        return None
    except PermissionError as error:
        return {'pid': int(pid), 'unavailable': str(error)}


def identity_matches(expected):
    if not expected or expected.get('boot_id') != boot_id() or expected.get('pid_namespace') != os.readlink('/proc/self/ns/pid'):
        return False
    current = process_identity(expected['pid'])
    return bool(current and not current.get('unavailable') and
                current['pid_start_ticks'] == expected.get('pid_start_ticks'))


def health(output):
    output = Path(output)
    launch = load(output / 'launch.json')
    gen = launch['generation']
    assert launch['source_pin'] == gen['source_pin'] == SOURCE
    if (output / 'termination.json').exists():
        assert load(output / 'termination.json')['generation'] == gen
        return {'state': 'terminal', 'observed': clock()}
    if gen['boot_id'] != boot_id() or gen['pid_namespace'] != os.readlink('/proc/self/ns/pid') or time.monotonic() < gen['monotonic_seconds']:
        return {'state': 'interrupted', 'reason': 'boot or monotonic generation changed', 'observed': clock()}
    if not launch.get('supervisor_identity'):
        return {'state': 'unavailable', 'reason': 'launch identity is not recorded; no liveness claim', 'observed': clock()}
    supervisor = process_identity(launch['supervisor_identity']['pid'])
    if supervisor and supervisor.get('unavailable'):
        return {'state': 'unavailable', 'reason': supervisor['unavailable'], 'observed': clock()}
    if not identity_matches(launch.get('supervisor_identity')):
        return {'state': 'interrupted', 'reason': 'original supervisor is absent or replaced', 'observed': clock()}
    state_path = output / 'supervisor-state.json'
    state = load(state_path) if state_path.exists() else {}
    worker = state.get('worker_identity')
    if not worker:
        return {'state': 'starting', 'reason': 'no actual test-child identity recorded yet', 'observed': clock()}
    observed_worker = process_identity(worker['pid'])
    if observed_worker and observed_worker.get('unavailable'):
        return {'state': 'unavailable', 'reason': observed_worker['unavailable'], 'observed': clock()}
    if not identity_matches(worker):
        return {'state': 'finalizing_or_interrupted', 'reason': 'actual child is absent; no terminal result yet', 'observed': clock()}
    heartbeat = state.get('heartbeat', {})
    fresh = heartbeat.get('boot_id') == gen['boot_id'] and 0 <= time.monotonic() - heartbeat.get('monotonic_seconds', -1e9) <= 60
    return {'state': 'running' if fresh else 'unavailable', 'worker_identity': worker,
            'reason': 'matching boot/PID start identity and fresh supervisor heartbeat' if fresh else 'heartbeat is stale',
            'observed': clock()}


def reconciliation_safe(output):
    output = Path(output)
    launch = load(output / 'launch.json')
    if not same_generation(launch['generation']):
        return True
    state = load(output / 'supervisor-state.json') if (output / 'supervisor-state.json').exists() else {}
    for identity in [launch.get('supervisor_identity'), state.get('worker_identity'), state.get('wrapper_identity')]:
        if identity:
            observed = process_identity(identity['pid'])
            if observed and (observed.get('unavailable') or observed['pid_start_ticks'] == identity['pid_start_ticks']):
                return False
    return True


def inventory():
    rows = []
    for record in subprocess.check_output(['git', 'ls-tree', '-rlz', SOURCE], cwd=ROOT).split(b'\0'):
        if not record:
            continue
        fields, name = record.split(b'\t', 1)
        mode, kind, oid, size = fields.decode().split()
        assert kind == 'blob'
        rows.append({'path': os.fsdecode(name), 'mode': mode, 'git_blob': oid, 'bytes': int(size)})
    return rows


def validate_workspace(state, files, data):
    assert state['source'] == SOURCE and state['exit_code'] == 0 and state['abort_reason'] is None
    assert state['qualified'] is False and state['timeout_seconds'] == 7200
    assert state['free_bytes_before'] >= 8 * 1024**3
    assert state['environment']['CARGO_BUILD_JOBS'] == '2' and state['environment']['RUST_TEST_THREADS'] == '4'
    assert state['environment']['CARGO_TARGET_DIR'] == str(ROOT / 'work/stable-target')
    assert state['environment']['CARGO_INCREMENTAL'] == '0'
    assert state['command'] == [str(ROOT / 'work/run-rust'), 'cargo', '+stable', 'test', '--locked',
                                '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4']
    expected = inventory()
    proofs = []
    for name in ['source_before', 'source_after']:
        proof = load(verify(state[name]))
        assert proof['source'] == SOURCE and proof['tree'] == data['candidate_tree']
        assert proof['complete_physical_tracked_checkout'] is True and proof['files'] == expected
        assert proof['tracked_files'] == len(expected) and proof['tracked_bytes'] == sum(row['bytes'] for row in expected)
        proofs.append(proof)
    assert proofs[0]['files'] == proofs[1]['files']
    stdout = Q / 'architecture-c13-workspace.stdout'
    stderr = Q / 'architecture-c13-workspace.stderr'
    assert ref(stdout) in files and ref(stderr) in files
    parsed = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', stdout.read_text())
    assert parsed and all(status == 'ok' and int(failed) == 0 for status, _, failed, _ in parsed)
    assert state['targets'] == len(parsed)
    assert state['counts'] == {key: sum(int(row[index]) for row in parsed)
                              for key, index in [('passed', 1), ('failed', 2), ('ignored', 3)]}


def validate_asan(state):
    clean = {'head': SOURCE, 'tree': git('rev-parse', SOURCE + '^{tree}', cwd=ROOT), 'status': ''}
    assert state['mode'] == 'ASAN+LSan' and state['source_before'] == state['source_after'] == clean
    assert state['flags']['RUSTFLAGS'] == '-Zsanitizer=address'
    assert state['flags']['ASAN_OPTIONS'] == 'detect_leaks=1' and state['flags']['CARGO_BUILD_JOBS'] == '1'
    assert state['checks']
    for check in state['checks']:
        assert check['exit_code'] == 0 and check['aborted'] is None and not check['sanitizer_report']
        assert check['source_before'] == check['source_after'] == clean and check['totals']['failed'] == 0
        for path, fields in check['record_files'].items():
            verify({'path': path, **fields})


def validate_native_recovery(state, reference):
    assert Path(reference['path']) == Q / 'architecture-c13-native-recovered/state.json'
    assert state['schema'] == 'pbrs.c13-native-postprocess-recovery.v1'
    assert state['state'] == 'recovered' and state['phase'] == 'native'
    assert state['recovery_kind'] == 'postprocessing_only'
    assert state['passed'] is True and state['raw_capture_passed'] is True and state['postprocessing_passed'] is True
    assert state['qualified'] is False and state['production_ready'] is False
    assert state['original_controller_passed'] is False and state['original_controller_exit_code'] == 1
    assert state['actual_captures'] == 576
    assert state['source_commits'] == {'baseline': '7c02eb387a6785d6e914146babe34f0902a6dd62',
        'safety': 'ca4ef720f8a90134334101e0106a8a68808fc19f', 'batch': SOURCE}
    helper = verify(state['recovery_helper'])
    assert helper == Q / 'architecture-c13-native-recovery-prepared-v2.py'
    assert digest(helper) == '9405cd735ae296b0b57be197fcf29b7294fe5cb7f2a5311eeee83651dcf803d9'
    original = load(verify(state['original_controller_state']))
    receipt = load(verify(state['original_execution']))
    assert original['state'] == 'failed' and original['passed'] is False
    assert original['error'] == {'type': 'FileNotFoundError', 'message':
        "[Errno 2] No such file or directory: '/workspace/pure-protobuf/work/architecture-c13-safety/docs/plan/tasks.json'"}
    assert receipt['exit_code'] == 1 and not receipt.get('timeout')
    totals = state['actual_rpc_totals']
    for row in totals.values():
        assert row['offered_rpcs'] == row['dispatched_rpcs'] == row['completed_rpcs'] == row['successful_rpcs']
        assert all(row[key] == 0 for key in ['failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs'])
    assert state['actual_successful_rpcs'] == sum(row['successful_rpcs'] for row in totals.values())


def validate_performance_state(name, state, data):
    assert state['state'] == 'finished' and state['passed'] is True
    assert state['qualified'] is False and state['production_ready'] is False and not state.get('error')
    assert len(state['completed']) == state['expected_captures'] > 0
    assert all(row['passed'] is True for row in state['completed'])
    label = 'candidate' if name == 'shipping' else 'batch'
    assert state['builds'][label]['source']['commit'] == SOURCE
    assert state['builds'][label]['source']['tree'] == data['candidate_tree']
    if name == 'cpu':
        assert state['phase'] == 'callgrind' and state['rpc_counts'] == [10, 20]
        assert state['cells_per_source'] == 90 and state['expected_captures'] == 540
        assert state['controller_sha256'] == digest(Q / 'architecture-c13-paired-counters.py')
        assert state['sources_sha256'] == digest(Q / 'architecture-c13-counter-sources.json')
        assert load(Q / 'architecture-c13-counter-sources.json')['batch']['source'] == SOURCE
    else:
        schema = 'pbrs.shipping-rpc-diagnostic.v1' if name == 'shipping' else 'pbrs.single-ready-bulk-counters.v1'
        assert state['schema'] == schema
        expected_count, expected_rpcs = (48, 360000) if name == 'shipping' else (240, 9000)
        assert state['expected_captures'] == expected_count and state['expected_successful_rpcs'] == expected_rpcs
        verify(state['controller'])
        config = load(verify(state['sources_input']))
        assert config[label]['source'] == SOURCE
        totals = state['actual_rpc_totals']
        for row in totals.values():
            assert row['offered_rpcs'] == row['dispatched_rpcs'] == row['completed_rpcs'] == row['successful_rpcs']
            assert all(row[key] == 0 for key in ['failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs'])
        assert sum(row['successful_rpcs'] for row in totals.values()) == expected_rpcs


def gate_manifest(data):
    manifest = load(GATES)
    assert manifest['schema'] == 'pbrs.c13-soak-gates.v1' and manifest['source_pin'] == SOURCE
    assert manifest['root_reviewed'] is True and manifest['qualified'] is False
    assert set(manifest['gates']) == {'asan', 'workspace', 'native', 'cpu', 'bulk', 'shipping'}
    accepted = {}
    for name, entry in manifest['gates'].items():
        state = load(verify(entry['state']))
        if name == 'native':
            validate_native_recovery(state, entry['state'])
        elif name in ['cpu', 'bulk', 'shipping']:
            validate_performance_state(name, state, data)
        else:
            assert state['state'] == 'passed' and state.get('active') is None
            assert not state.get('error') and state.get('exit_code', 0) == 0
            assert state.get('passed', True) is not False
        assert entry['files']
        for item in entry['files']:
            verify(item)
        if name == 'asan':
            validate_asan(state)
        elif name == 'workspace':
            validate_workspace(state, entry['files'], data)
        accepted[name] = entry['state']
    return {'manifest': ref(GATES), 'states': accepted}


def resource_preview(data):
    report = load(RESOURCE_PREVIEW)
    assert report['source']['commit'] == SOURCE and report['source']['dirty'] is False
    assert report['duration_requested_seconds'] == 30 and report['duration_actual_seconds'] >= 30
    assert report['exit_code'] == 0 and report['smoke'] == {'status': 'passed', 'failures': []}
    assert report['build']['profile'] == 'release'
    limits = {key: {'soft': value, 'hard': value} for key, value in caps(30).items()}
    assert report['process_limits'] == report['process_limits_requested'] == limits
    assert report['tools']['rustc'].splitlines()[0] == data['tools_required']['rustc']
    assert report['tools']['cargo'] == data['tools_required']['cargo']
    assert not runpy.run_path(str(TREE / 'scripts/grpc-resource-campaign.py'))['validate_report'](report)
    binary = Path(report['binary']['path'])
    assert binary.parent == RESOURCE_PREVIEW.parent and digest(binary) == report['binary']['sha256']
    return {'report': ref(RESOURCE_PREVIEW), 'binary': ref(binary), 'tools': report['tools']}


def readiness(expected_sha, full=True):
    data = pins(expected_sha)
    return {'source_pin': SOURCE, 'source_manifest': ref(PINS), 'qualified': False,
            'gates': gate_manifest(data) if full else None,
            'resource_preview': resource_preview(data) if full else None,
            'scope': 'Exact-source finite checks; no overall production-readiness or speed-superiority claim.'}


def validate_pass(kind, report, launch):
    assert report['source_pin'] == SOURCE and report['generation'] == launch['generation']
    assert report['requested_seconds'] == 86400 and report['exit_code'] == 0
    if kind == 'resource':
        campaign = load(verify(report['campaign_report']))
        data = load(PINS)
        assert campaign['source']['commit'] == SOURCE and campaign['source']['dirty'] is False
        assert campaign['source']['tree'] == data['candidate_tree']
        assert campaign['tools']['rustc'].splitlines()[0] == data['tools_required']['rustc']
        assert campaign['tools']['cargo'] == data['tools_required']['cargo']
        assert campaign['binary']['sha256'] == load(RESOURCE_PREVIEW)['binary']['sha256']
        assert campaign['duration_requested_seconds'] == 86400 and campaign['duration_actual_seconds'] >= 86400
        assert campaign['exit_code'] == 0 and campaign['smoke'] == {'status': 'passed', 'failures': []}
        assert campaign['build']['profile'] == 'release'
        assert campaign['process_limits'] == campaign['process_limits_requested'] == {
            key: {'soft': value, 'hard': value} for key, value in caps(86400).items()}
        assert not runpy.run_path(str(TREE / 'scripts/grpc-resource-campaign.py'))['validate_report'](campaign)
        assert digest(Path(campaign['binary']['path'])) == campaign['binary']['sha256']
        assert report['worker_identity']['actual_process_limits'] == {key: [value, value] for key, value in caps(86400).items()}
        return campaign['duration_actual_seconds']
    progress = report['final_progress']
    gen = launch['generation']
    worker = report['worker_identity']
    assert report['duration_actual_seconds'] >= 86400 and progress['elapsed_seconds'] >= 86400
    assert progress['event'] == 'duration_completed' and progress['state'] == 'completed'
    assert progress['requested_seconds'] == 86400 and progress['fixture_cases_per_cycle'] == 30
    assert progress['generation'] == gen['id'] and progress['boot_id'] == gen['boot_id']
    assert progress['pid'] == worker['pid'] and progress['pid_start_ticks'] == worker['pid_start_ticks']
    assert worker['boot_id'] == gen['boot_id'] and progress['controlled_tokio_time'] is True
    assert progress['retained_capacity'] == progress['retained_buffers'] == 0
    assert progress['acquired'] == progress['released']
    assert 0 < progress['fd_count'] <= progress['baseline_fd_count'] < 128
    assert 0 <= progress['alive_tasks'] <= progress['baseline_alive_tasks']
    assert 0 < progress['rss_bytes'] < 1073741824 and progress['peak_retained_capacity'] <= 16 * 1024 * 1024
    assert report['actual_process_limits'] == {key: [value, value] for key, value in caps(86400).items()}
    assert report['source_pin_verified_at_end'] is True and report['runtime_source_equivalent'] is True
    build = load(verify(report['build']))
    assert build['source_pin'] == SOURCE and build['profile'] == 'release' and build['all_features'] is True
    assert build['copy_counts'] is True and build['allocation_counter_allocator'] is False
    assert build['tools'] == load(PINS)['tools_required']
    attestation = build['cargo_artifact_attestation']
    assert set(attestation['features']) == set(tomllib.loads((TREE / 'pbrs-grpc/Cargo.toml').read_text())['features'])
    assert {'copy-counts', 'grpc-web'} <= set(attestation['features'])
    assert attestation['profile']['opt_level'] == '3' and attestation['profile']['test'] is True
    assert attestation['profile']['debug_assertions'] is False
    provenance = load(verify(report['provenance']))
    assert provenance['source_pin'] == SOURCE and provenance['runtime_source_equivalent'] is True
    verify(provenance['source_equivalence'])
    verify(build['binary'])
    events = [json.loads(line) for line in (Path(launch['output']) / 'events.jsonl').read_text().splitlines()]
    assert len(events) == progress['completed_cycles'] + 1 and events[-1] == progress
    for index, event in enumerate(events[:-1], 1):
        assert event['event'] == 'cycle_completed' and event['completed_cycles'] == index
        assert event['generation'] == gen['id'] and event['boot_id'] == gen['boot_id']
        assert event['pid_start_ticks'] == worker['pid_start_ticks'] and event['fixture_cases_per_cycle'] == 30
        assert event['retained_capacity'] == event['retained_buffers'] == 0 and event['acquired'] == event['released']
        assert event['fd_count'] <= event['baseline_fd_count'] < 128 and event['alive_tasks'] <= event['baseline_alive_tasks']
    text = (Path(launch['output']) / 'stdout.log').read_text()
    assert 'test deadline_sustained ... ok' in text and '1 passed; 0 failed; 0 ignored;' in text
    return progress['elapsed_seconds']


def publication_inputs(kind, source_sha256):
    assert kind in ['resource', 'deadline']
    assert digest(PINS) == source_sha256
    output = Q / ('resource-architecture-c13-day' if kind == 'resource' else 'resource-architecture-c13-deadline-day')
    launch = load(output / 'launch.json')
    termination = load(output / 'termination.json')
    report = load(output / 'report.json')
    assert launch['source_pin'] == SOURCE and launch['kind'] == kind
    assert launch['source_manifest'] == ref(PINS) and launch['source_manifest']['sha256'] == source_sha256
    assert launch['gates'] == ref(GATES)
    grant = load(verify(launch['grant']))
    assert grant == {'source_pin': SOURCE, 'source_sha256': source_sha256, 'gates_sha256': digest(GATES),
                     'root_granted': True, 'action': 'launch-c13-' + kind + '-day'}
    for reference in launch['harness'].values():
        verify(reference)
    gen = launch['generation']
    assert re.fullmatch(r'[a-f0-9]{32}', gen['id']) and gen['source_pin'] == SOURCE
    assert report['source_pin'] == termination['source_pin'] == SOURCE
    assert report['generation'] == termination['generation'] == gen
    current_state = load(output / 'supervisor-state.json') if (output / 'supervisor-state.json').exists() else {}
    for identity in [report.get('worker_identity'), current_state.get('worker_identity'), current_state.get('wrapper_identity')]:
        if identity and identity.get('boot_id') == boot_id():
            current = process_identity(identity['pid'])
            assert not current or (not current.get('unavailable') and current['pid_start_ticks'] != identity['pid_start_ticks']), 'a terminal publication cannot archive a live worker'
    declared = report['state']
    assert declared in ['passed', 'failed', 'incomplete']
    outcome = {'state': declared, 'qualified': False, 'validation_errors': [], 'exit_code': report.get('exit_code'),
               'duration_actual_seconds': report.get('duration_actual_seconds'),
               'completed_cycles': report.get('completed_cycles'), 'reason': report.get('reason')}
    outcome.update({key: report[key] for key in ['duration_measurement', 'last_completed_cycle_elapsed_seconds',
                    'supervisor_wall_seconds'] if key in report})
    # A terminal archive does not turn a stale running file into a completed day.
    if declared == 'passed':
        try:
            assert termination['state'] == 'terminated' and termination['exit_code'] == 0
            pins(source_sha256)
            gate_manifest(load(PINS))
            outcome['duration_actual_seconds'] = validate_pass(kind, report, {**launch, 'output': str(output)})
        except (AssertionError, KeyError, TypeError, ValueError, OSError) as error:
            outcome['state'] = 'incomplete'
            outcome['validation_errors'].append(repr(error))
    if report.get('reason') == 'interrupted':
        assert termination['state'] == 'interrupted' and report['exit_cause'] == 'unavailable'
        assert report['application_failure_established'] is False
        outcome['state'] = 'incomplete'
        outcome['reason'] = 'interrupted; exit cause unavailable'
    files, omissions, seen = {}, [], set()

    def add(reference):
        path = Path(reference['path'])
        name = str(path)
        if name in seen:
            return
        seen.add(name)
        if not path.resolve().is_relative_to(Q) and path.resolve() not in {ROOT / 'work/run-rust', ROOT / 'work/record.py'}:
            omissions.append({'reference': reference, 'reason': 'External tracked source or reclaimable compiler cache; identity retained in records.'})
            return
        verify(reference)
        files[name] = ref(path)
        if path.suffix == '.json':
            walk(load(path))

    def walk(value):
        if isinstance(value, dict):
            if isinstance(value.get('path'), str) and isinstance(value.get('sha256'), str) and Path(value['path']).is_absolute():
                add(value)
            for key, child in value.items():
                if isinstance(key, str) and key.startswith('/') and isinstance(child, dict) and 'sha256' in child:
                    add({'path': key, **child})
                else:
                    walk(child)
        elif isinstance(value, list):
            for child in value:
                walk(child)

    for file in sorted(output.rglob('*')):
        if not file.is_file() or file.is_symlink():
            continue
        relative = file.relative_to(output)
        if '__pycache__' in relative.parts or file.suffix in ['.pyc', '.pyo', '.tmp', '.next'] or '.next.' in file.name:
            continue
        if any(part.startswith('publication') for part in relative.parts) or file.name == 'supervisor.log':
            continue
        add(ref(file))
    for file in [PINS, GATES, Path(__file__).resolve(), ROOT / 'work/run-rust', ROOT / 'work/record.py']:
        add(ref(file))
    walk(load(GATES))
    return {'source': SOURCE, 'kind': kind, 'generation': gen['id'], 'launch_utc': gen['utc'],
            'output': str(output), 'outcome': outcome, 'files': list(files.values()),
            'recorded_omissions': omissions,
            'scope': 'Finite source-bound diagnostic; no host-retention, overall production-readiness or comparative-speed guarantee.'}
