# Unary connection ownership and trace predictions

Read-only source inspection at 933bf8775b70d24d91fb46a7992eae343b60f0ea. No production change or new trace has run for this note.

## Ownership

`rpc-bench/src/native_prost.rs::router` installs a generated native service around Interop. Its unary handler returns a newly constructed response immediately; its streaming producer spawns do not run for this unary case.

`pbrs-grpc/src/server/accept.rs` spawns the accepted connection once. `server/connection.rs::serve_io_in` owns the h2 connection and FuturesUnordered of admitted RPC futures. Each loop polls ready RPC children, then advances `ServerConnection::poll_accept` with the connection task context. The ordinary unary path does not spawn a separate handler task or a separate h2 driver task.

FuturesUnordered replaces the poll context for each admitted child. Its child waker marks the child queued, then forwards a wake through the ready queue's AtomicWaker to the parent connection task. The protocol driver receives the parent context. The child and driver are not necessarily `will_wake`-equal even though they run within one task. Body/reset readiness may enqueue the child while the parent is already advancing the protocol.

`h2_backend/proto/streams/streams.rs::poll_complete` registers the driver waker under the engine lock after buffering pending work. `prioritize.rs::queue_frame` consumes that waker and wakes it after queueing a frame. Only the first queue operation consumes a stored waker before the next registration. Header, DATA and trailer API calls do not imply three wakes or three socket writes.

## Scheduler qualification

The locked rpc-bench dependency is Tokio 1.53.1. Its multi-thread `schedule_local` uses a LIFO slot. A local wake can avoid waking another parked worker when the slot was empty. Notification of another worker occurs when the slot already held work, on yielding/overflow, or on a remote schedule. Therefore source-level self-wake is a hypothesis, not proof of four futex operations/RPC.

Tokio's thread parker uses a mutex/condition variable and its unpark path coordinates with the parker before notify_one. The I/O reactor also has an eventfd wake path. These are distinct from the native engine lock.

The engine lock is `pbrs-grpc/src/h2_backend/proto/streams/lock.rs`. Its slow acquisition waits via SYS_futex FUTEX_WAIT_PRIVATE with expected value 2 and null timeout; unlock wakes via FUTEX_WAKE_PRIVATE with count 1. It does not spin before parking. Other runtime or standard-library futexes can use WAIT_BITSET_PRIVATE and different expected counters. Operation and argument patterns are stronger clues than an address alone.

## Predictions to check in the separately prepared full trace

1. If engine contention dominates, recurring waits should match WAIT_PRIVATE(expected=2, timeout=NULL), with corresponding WAKE_PRIVATE(1) at the same word and cross-thread critical-section activity. A futex address alone is insufficient to name the lock.
2. If parked-worker handoff dominates, recurring waits should instead follow the thread-parker/condition-variable pattern, accompanied by decoded reactor notification writes or cross-thread wake operations. Exact operation/return/error patterns and per-thread sequences must be retained. They can support a parking explanation without proving which high-level wake caused it.
3. `write` calls decoded as anon_inode:[eventfd] would explain the extra write count as reactor notification. Socket-labelled writes would require a different transport explanation. The completed -c trace cannot distinguish them.
4. Network-oriented sendto+writev counts are already about two/RPC on native and Tonic. Do not change batching on the assumption that native has an extra network write.

The prepared full-trace scope is eight captures/600 RPCs: current feature-off source only, N=50/100, two pairs and two balanced repeats. It keeps full selected syscall traces, fd decoding, thread IDs, futex arguments, return values and selected-call summaries. It has not run at the time this note was written. Tracing and concurrent approved host work can change scheduling; traced timing is never a shipping performance result.

## Architecture candidate, conditional on evidence

If redundant internal wake/handoff is observed, preserve a single connection owner that drains protocol work and ready RPCs before parking. Notifications produced while that owner is actively draining can mark connection work pending instead of immediately scheduling its already-running parent. The transition from active draining to armed parking must close the race with an external producer: mark/check pending work and register the parent waker under a shared protocol/notification contract, and self-schedule if a poll budget is exhausted with work remaining.

This requires explicit per-connection ownership, not a thread-local marker or equality assumption between child and driver wakers. External producer tasks, different runtimes, driver handoff after handshake, reset notifications, and payload destructors must continue to wake a parked owner. Deferring a wake must not defer a response flush or lose readiness. Owner retirement must remain outside engine locks.

Do not implement this candidate before the causal trace identifies the dominant path. Do not change the custom lock's spinning/parking policy merely because futex totals are high. No worker-count, queue, buffer, timeout, TLS or wire-semantics change is part of this proposal.
