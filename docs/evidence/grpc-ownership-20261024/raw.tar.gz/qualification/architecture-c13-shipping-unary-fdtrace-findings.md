# Unary server fd-aware trace findings

All eight captures passed: 600 offered/dispatched/completed/successful RPCs, zero failures or unfinished calls. Actual duration: 2.174 seconds. Only newly launched own endpoints were traced, using the approved feature-off 933bf binary and standard strace annotations. Workspace tests were active; Callgrind had finished. The separate launch record documents this actual background and supersedes the frozen controller's earlier expected-background text.

Tracing changes scheduling. These counts identify a concrete path to investigate; they are not shipping CPU, latency, throughput, task-wake, or task-migration measurements.

## What the full traces identify

Raw entered-call counts include setup/teardown. Each cell lists N=50 / N=100, for the two repeats.

| Server observation | Native repeat 0 | Tonic repeat 0 | Native repeat 1 | Tonic repeat 1 |
| --- | ---: | ---: | ---: | ---: |
| FUTEX_WAIT_BITSET_PRIVATE | 119 / 213 | 4 / 4 | 111 / 214 | 4 / 5 |
| FUTEX_WAKE_PRIVATE | 117 / 212 | 2 / 2 | 110 / 212 | 2 / 4 |
| FUTEX_WAIT_PRIVATE | 0 / 0 | 0 / 0 | 0 / 0 | 0 / 0 |
| Writes decoded as eventfd | 57 / 111 | 1 / 2 | 55 / 106 | 1 / 1 |
| TCP sendto | 53 / 103 | 0 / 0 | 52 / 104 | 0 / 0 |
| TCP writev | 50 / 100 | 103 / 203 | 50 / 100 | 103 / 203 |
| Changes of thread between adjacent TCP operations | 121 / 149 | 1 / 2 | 62 / 152 | 1 / 1 |

The recurring native waits use BITSET with increasing expected counters. They do not match the custom engine lock's WAIT_PRIVATE(expected=2,NULL) acquisition signature. Do not change engine lock spinning/parking based on the prior aggregate futex count.

The extra write calls are eventfd notifications. Decoded TCP sendto+writev counts stay near two/RPC on both implementations. These observations point toward runtime notification and worker handoff, not an extra socket write caused by batching.

Native TCP reads and writes occur on both worker thread IDs throughout the capture. Tonic's TCP operations mostly stay on one worker after startup. The table counts adjacent observed TCP-operation thread changes; it does not prove how many Rust tasks moved or which exact wake caused movement. Strace and background work can affect that behavior.

## Reconciliation and limits

All 16 endpoint traces were parsed with initial/resumed syscall lines paired by thread and syscall. Entered calls minus unresolved-at-termination calls equal the -C summary counts for every syscall. Parsed error returns, including restart results, equal the summary errors. Each server has two calls without a determinate return at ordinary SIGTERM teardown; those remain separate rather than being silently counted as completed calls. Every original trace line is preserved, and parsed events retain start/end line references.

FD classifications use only strace's supplied annotations. No alternate descriptor queries, protected process maps, debugger, escalation, or permission workaround was used. Any unavailable annotation remains unavailable/other. All RPC accounting passed; syscall errors and restart events remain distinct from RPC failures.

## Smallest candidate

In `server/connection.rs`, the steady loop polls the admitted ready set before `ServerConnection::poll_accept`. The latter advances protocol input, which can wake an admitted RPC after DATA arrives. Its Pending branch currently returns Pending without checking that ready set again. A now-ready unary handler therefore needs another executor turn while the connection task was already running.

A narrow candidate is to poll the admitted ready set once more after the protocol accept poll returns Pending. If a unary handler completes, return Tick to the existing connection loop and flush its queued response within the same parent poll. FuturesUnordered still polls only queued children, preserving sleeping unrelated handlers. This keeps external wakers and engine notification contracts intact, adds no TLS marker or worker/buffer policy, and does not defer a flush. It cannot revoke a notification already sent to Tokio, so the actual syscall/CPU effect remains to be measured.

Before production changes, a causal split-HEADERS/DATA test should show whether a handler made ready by the protocol poll runs in that same outer poll. Preserve the before-source failure and after-source success. Then compare a fresh source-pinned release ELF with unchanged syscall and shipping settings. If ready-set rechecking is insufficient, the broader alternative is explicit per-connection active/draining/armed notification ownership with a proved external-wake race closure; do not begin with thread-local suppression or a global custom-lock change.

## Evidence

- Completion: `architecture-c13-shipping-unary-fdtrace-completion.json`, SHA256 e11b04dc7ecaed8b2c2ac70481d2e3dbc305f2976e3e4ca369cfd67d7c8cb5d6. All 70 capture artifacts referenced.
- Full parsed event/operation/fd analysis: `architecture-c13-fdtrace-analysis.json`, SHA256 58e8b784394ef2ed87d1439f6cc69d296ef71dc121539922dac83aaf848b96b2.
- State: `architecture-c13-shipping-unary-fdtrace-captures/state.json`, SHA256 b1275ab67f52fddd82d5f21ec0ac965337a3b052c8f3aa6907e7a0270d896f95.
- Signed selected-syscall slopes: `architecture-c13-shipping-unary-fdtrace-captures/fdtrace-summary.json`, SHA256 dcfcafeeebac38de88ca47b38e3590ece1dc9189debd8a669c0c5b8c143e9fd2.

No source change or further endpoint run was made after this completed control. The 16-capture untraced adjacent shipping replay is prepared separately and still requires Root's review and quiet-window grant.
