# Unary server shipping CPU investigation

The current native server costs more CPU than Tonic for identity unary RPCs. The loss is visible in both raw process CPU and N/2N slopes. It remains open.

These are existing shipping-build observations: allocation counters and profilers are off, one connection, one in-flight call, 1 KiB identity payload, two Tokio workers. No new workload ran during this investigation.

## What the measurements show

CPU is microseconds per RPC. Each cell lists the two repeats.

| Current server | N=5,000, total CPU/N | N=10,000, total CPU/N | N/2N CPU slope |
| --- | ---: | ---: | ---: |
| Native | 50 / 52 | 51 / 51 | 52 / 50 |
| Tonic | 44 / 42 | 31 / 33 | 18 / 24 |
| Native / Tonic | 1.14 / 1.24 | 1.65 / 1.55 | 2.89 / 2.08 |

The slope magnifies the loss because Tonic's 10,000-call processes are cheaper per call than its 5,000-call processes. The standalone loss still matters. Native's source change from 7c02 to 933bf does not resolve it: native server slopes remain 52/52 to 52/50 microseconds. Tonic server slopes change from 44/44 to 18/24 microseconds even though the benchmark source, dependency locks, and build settings match. A common benchmark source does not guarantee identical linked machine code or identical scheduling across separate processes.

| Current N/2N server slope | User CPU | System CPU | Total |
| --- | ---: | ---: | ---: |
| Native, repeat 0 | 24 | 28 | 52 |
| Tonic, repeat 0 | 4 | 14 | 18 |
| Native, repeat 1 | 18 | 32 | 50 |
| Tonic, repeat 1 | -2 | 26 | 24 |

Keep the negative user component. N and 2N use separate processes and 10 ms CPU ticks; subtraction does not produce a perfect isolated RPC cost. At N=10,000 without subtraction, native user/system CPU is 21/30 and 18/33 microseconds per RPC; Tonic is 13/18 and 13/20. Both user and kernel work need explanation.

Native's measured server window exceeds the client's reported load duration by 4.2–12.7 ms; Tonic's by 5.0–13.3 ms. The window includes client startup/reporting and the polling tail. That scope differs from exact service work, but its bounded wall-time tail cannot explain a 180–200 ms server CPU gap in the 10,000-call captures.

Tonic's median latency changes from 88.4–89.2 microseconds at 5,000 calls to 66.1–67.9 at 10,000. Calls below 100 microseconds increase from 67.1–71.2% to 88.7–89.6%. Native's medians remain 84.0–85.8. This is a distribution shift, not one first-call outlier. At 10,000 calls native throughput is 13.6–18.3% lower than Tonic; retain that loss along with the CPU loss.

The controller interleaves sources and counts within each scope. Tonic/Tonic and native-server scopes were captured tens of seconds apart. It does not establish simultaneous native/Tonic host conditions. A same-source replay with adjacent native/Tonic controls can test repeatability without changing the product.

## Allocation and existing profiles

The allocation-feature captures show native unary server near 15.05 KiB and 20 allocation calls per RPC, versus Tonic near 25.03 KiB and 37. Native has a substantial allocation advantage while shipping CPU loses. Context-switch slopes range 1.88–3.16 per RPC for the current native server and 1.36–1.84 for Tonic. These are process scheduling events; they do not count task wakes. Those captures include allocation instrumentation and different host conditions. Their parent phase has all 576 passed raw captures but a failed aggregation record awaiting Root's recovery; they are raw diagnostics, not a passed complete phase.

The older 7c02 Callgrind analysis measures about 39,984 native server user-space instructions/RPC. It identifies repeated timeout metadata inspection and scheduler costs, but does not measure kernel CPU. Current C13 Callgrind is still in progress. Neither older instruction wins nor lower allocation counts dismiss the shipping CPU result.

## Code paths and testable explanations

- `server/connection.rs:489–552` runs admitted RPCs on the connection task using FuturesUnordered. It polls ready handlers before advancing the h2 accept/connection driver. Child-ready bookkeeping and driver wake registration can affect task scheduling, but source inspection does not count wakes or prove extra scheduling.
- `server/drain.rs::send_unary_response` encodes a response and queues headers, DATA, and final trailers. Untimed `before_commit` checks are immediately ready. There is no unconditional yield to remove.
- `wire/send.rs::send_frame_if_ready` has a synchronous single-segment DATA fast path. The single-ready batch patch changes streaming OutBatch reservation; it does not change unary encode_msg or its flush behavior.
- `h2_backend/server.rs::poll_accept_with` advances the connection before returning an incoming stream. `proto/connection.rs::poll` flushes queued stream work when the read side becomes pending. `codec/framed_write.rs::flush` uses actual buffered contents and skips empty flushes. Separate header/DATA/trailer API calls do not prove separate socket writes.

The concrete next question is whether native performs more reads, writes, readiness waits, or cross-worker wake operations per unary RPC, and whether that persists once adjacent same-source Tonic controls stabilize. An optimization must reduce measured redundant transport work while preserving immediate completion, flow control, final status, cancellation, and ordinary owner destruction. Do not add delayed flushing, change worker counts, weaken response semantics, or retune buffers to manufacture a win.

## Small next diagnostic, not yet authorized to execute

1. Replay the existing feature-off 933bf shipping ELF with the unchanged shipping capture adapter. Only unary identity 1 KiB: tonic client/native server and Tonic/Tonic. Use N=5,000/10,000, four balanced repeats: 16 captures and 120,000 RPCs. Alternate pair order and reverse count order across adjacent repeats. Revalidate the source, ELF, helper, build features, tools, and settings before/after each capture. Keep full histograms, all terminal counts, raw user/system CPU ticks, exact process windows, host quota/HZ and readable quiescence observations. Report raw CPU/N as well as slopes. Do not subtract quantiles or throughput.
2. Separately use the unchanged adapter's existing `strace -D -f -c -o` support on both endpoints, same source/settings/pairs. N=1,000/2,000, two balanced repeats: 8 captures and 12,000 RPCs. Count syscall calls/errors per RPC and N/2N slopes, including read/recv*, write/writev/send*, epoll*, futex and eventfd-related calls. Preserve every syscall row and both endpoint ledgers. Traced timing and CPU are not performance results; tracing changes scheduling. Context switches or futex counts alone do not prove task-wake counts.
3. If tracing is denied, preserve the first failure and stop. No perf permission workaround, escalation, or policy change. If the replay is stable and syscall counts differ, inspect that path before choosing a code change. If counts match but system CPU still differs, syscall duration/scheduling and socket behavior remain separate hypotheses rather than a proven flushing issue.

`/usr/bin/strace --version` succeeds: 6.13, SHA256 69f88291a4e47f258b8e32b089c919a247509f063ef3d6afe5389939051102b3. Local Valgrind 3.24.0 also answers --version with its pinned VALGRIND_LIB. An earlier bare Valgrind probe failed because that library environment was absent; no workload or permission probe was attempted.

These are proposals only. Both require a new quiet-window grant. No compiler, endpoint, profiler workload, source edit, or cache cleanup ran here.

## Frozen evidence

- `architecture-c13-shipping-completion.json`: all 48 captures, 360,000 successful RPCs, 354 referenced artifacts, no failed/unfinished calls. SHA256 b2f60330cee3cd4326c41cf92b96a01f3f4322a23c1a00a271bf933a81593cea.
- `architecture-c13-shipping-captures/shipping-summary.json`: all source/Tonic CPU comparisons, raw ranges and timing observations. SHA256 3e4b982b378254620ee05df9f1212f0682483f74a281d858fd93307d36113037.
- `architecture-c13-shipping-unary-server-attribution.json`: all 48 capture histograms/windows, all 48 user/system/total slopes and 12 raw allocation/context-switch controls. SHA256 4e19fa7f3b3e2d515c93e01842d1b32620454b2cad0fb7d86e22b086ff1db024.
