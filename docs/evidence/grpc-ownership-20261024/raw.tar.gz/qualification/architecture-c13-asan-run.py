"""One-off C13 ASAN/LSan run; no cleanup, source edits or generated consumers."""
import datetime, hashlib, json, os, re, shutil, signal, subprocess, time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf')
Q=ROOT/'work/qualification'
CACHE=ROOT/'work/asan-c13-target'
EXPECTED='933bf8775b70d24d91fb46a7992eae343b60f0ea'
STATE=Q/'architecture-c13-asan-state.json'
MIN_FREE=3*1024**3

def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda:f.read(1024*1024),b''): h.update(block)
    return h.hexdigest()
def source():
    return dict(head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),
        tree=subprocess.check_output(['git','rev-parse','HEAD^{tree}'],cwd=ROOT,text=True).strip(),
        status=subprocess.check_output(['git','status','--porcelain','--untracked-files=all'],cwd=ROOT,text=True).strip())
def save(value):
    tmp=STATE.with_suffix('.json.tmp');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(STATE)
def stop(process):
    os.killpg(process.pid,signal.SIGTERM)
    try: process.wait(timeout=5)
    except subprocess.TimeoutExpired: os.killpg(process.pid,signal.SIGKILL);process.wait(timeout=5)

initial=source()
assert initial['head']==EXPECTED and not initial['status'], initial
assert not CACHE.exists(), 'fresh dedicated cache required; ask Root before any cleanup/reuse'
free=shutil.disk_usage(ROOT).free
assert free>=MIN_FREE, dict(free_bytes=free,minimum=MIN_FREE)
env=os.environ.copy();env.update(RUSTFLAGS='-Zsanitizer=address',ASAN_OPTIONS='detect_leaks=1',
 CARGO_TARGET_DIR=str(CACHE),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0')
state=dict(mode='ASAN+LSan',qualified=False,state='running',started_utc=now(),source_before=initial,
 free_bytes_before=free,min_free_bytes=MIN_FREE,checks=[],executables={},active=None,
 flags={k:env[k] for k in ['RUSTFLAGS','ASAN_OPTIONS','CARGO_TARGET_DIR','CARGO_BUILD_JOBS']},
 controller_sha256=sha(Path(__file__)),cache_left_in_place=str(CACHE))
save(state)
phases=[
 ('selected','pbrs-grpc',['--lib',*sum((['--test',name] for name in [
 'decode_workspace','closed_upload_response','retry_safety','pump_panic','server_deadline',
 'server_deadline_extended','server_terminal_accounting','pre_shape_reset']),[])],[],9,2400),
 ('inbound-owner','pbrs-grpc',['--test','lifecycle'],['inbound_owner_'],1,1200),
 ('kernel-lib','pbrs',['--lib'],[],1,1200),
 ('runtime-upb','pbrs',['--test','runtime','--test','upb_kernel'],[],2,1200),
]
try:
    for name,package,targets,filters,expected_targets,limit in phases:
        assert source()==initial,'source changed before phase'
        assert shutil.disk_usage(ROOT).free>=MIN_FREE,'disk guard before phase'
        prefix=Q/f'architecture-c13-asan-{name}'
        assert not any(prefix.with_suffix(s).exists() for s in ['.json','.stdout','.stderr']), 'preserve prior records'
        command=[str(ROOT/'work/run-rust'),'nice','-n','10','cargo','+nightly-2025-06-26','test',
         '--locked','-p',package,'--all-features',*targets,'--target','x86_64-unknown-linux-gnu',
         '-Zbuild-std',*filters,'--','--test-threads=4']
        started=now();began=time.monotonic();aborted=None
        state['active']=name;save(state)
        with prefix.with_suffix('.stdout').open('wb') as out,prefix.with_suffix('.stderr').open('wb') as err:
            process=subprocess.Popen(command,cwd=ROOT,env=env,stdout=out,stderr=err,start_new_session=True)
            while process.poll() is None:
                if shutil.disk_usage(ROOT).free<MIN_FREE: aborted='disk_guard';stop(process);break
                if time.monotonic()-began>limit: aborted='timeout';stop(process);break
                time.sleep(5)
        record=dict(command=command,cwd=str(ROOT),started_utc=started,duration_seconds=time.monotonic()-began,
         exit_code=process.returncode,aborted=aborted,source_before=initial,source_after=source(),
         environment=state['flags'],free_bytes_after=shutil.disk_usage(ROOT).free)
        stdout=prefix.with_suffix('.stdout').read_text();stderr=prefix.with_suffix('.stderr').read_text()
        record['summaries']=[dict(status=s,passed=int(p),failed=int(f),ignored=int(i)) for s,p,f,i in
         re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;',stdout)]
        record['totals']={k:sum(r[k] for r in record['summaries']) for k in ['passed','failed','ignored']}
        record['sanitizer_report']=bool(re.search(r'(ERROR|SUMMARY): (AddressSanitizer|LeakSanitizer)',stdout+'\n'+stderr))
        for path in re.findall(r'^\s*Running .*?\(([^()]+)\)\s*$',stderr,re.MULTILINE):
            elf=Path(path);elf=(elf if elf.is_absolute() else ROOT/elf).resolve()
            assert elf.is_relative_to(CACHE.resolve()),elf
            with elf.open('rb') as file: assert file.read(4)==b'\x7fELF',elf
            state['executables'][str(elf)]=dict(bytes=elf.stat().st_size,sha256=sha(elf),phase=name)
        prefix.with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
        record['record_files']={str(prefix.with_suffix(s)):dict(bytes=prefix.with_suffix(s).stat().st_size,sha256=sha(prefix.with_suffix(s))) for s in ['.json','.stdout','.stderr']}
        state['checks'].append(record);save(state)
        assert process.returncode==0 and aborted is None,record
        assert record['source_after']==initial,'source drift'
        assert not record['sanitizer_report'],record
        assert len(record['summaries'])==expected_targets and all(r['status']=='ok' and r['passed']>0 for r in record['summaries']),record
    state.update(state='passed',active=None,completed_utc=now(),source_after=source(),free_bytes_after=shutil.disk_usage(ROOT).free)
    save(state)
except BaseException as error:
    state.update(state='failed',error=repr(error),active=None,completed_utc=now(),source_after=source(),free_bytes_after=shutil.disk_usage(ROOT).free)
    save(state)
    raise
