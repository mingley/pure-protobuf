import datetime, hashlib, json, os, subprocess, sys, time
from pathlib import Path
prefix, limit, *command = sys.argv[1:]
prefix = Path(prefix)
head = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
diff = subprocess.check_output(["git", "diff", "HEAD", "--binary"])
untracked = subprocess.check_output(["git", "ls-files", "--others", "--exclude-standard", "-z"]).split(b"\0")
state = {os.fsdecode(path): hashlib.sha256(Path(os.fsdecode(path)).read_bytes()).hexdigest() for path in untracked if path and Path(os.fsdecode(path)).is_file()}
record = {"command": command, "cwd": os.getcwd(), "started_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "source": {"head": head, "diff_sha256": hashlib.sha256(diff).hexdigest(), "untracked": state}, "timeout_seconds": float(limit)}
record["environment"] = {key: os.environ[key] for key in ["RUSTFLAGS", "RUSTDOCFLAGS", "MIRIFLAGS", "ASAN_OPTIONS", "RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR", "CARGO_BUILD_JOBS"] if key in os.environ}
t0 = time.monotonic()
with prefix.with_suffix(".stdout").open("wb") as out, prefix.with_suffix(".stderr").open("wb") as err:
    process = subprocess.Popen(command, stdout=out, stderr=err, start_new_session=True)
    try:
        code = process.wait(timeout=float(limit))
    except subprocess.TimeoutExpired:
        import signal
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()
        record["timeout"] = True
        code = 124
record.update(exit_code=code, duration_seconds=time.monotonic()-t0)
prefix.with_suffix(".json").write_text(json.dumps(record, indent=2)+"\n")
print(json.dumps({"record": str(prefix.with_suffix(".json")), "exit_code": code, "duration_seconds": record["duration_seconds"]}))
sys.exit(code if code >= 0 else 128-code)
