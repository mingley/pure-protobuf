# C13 native counters

Sources: baseline `7c02eb38`, safety `ca4ef720`, batch `933bf877`.

**576 captures / 21,600 successful RPCs**; 7,200 per source. All terminal accounting errors are zero.
Original controller failed in postprocessing; the separate recovery preserved every original artifact and performed no new captures.

Lower is better. Values are medians of two N/2N differences per RPC; ranges below are the two paired percentage changes.

## baseline->safety

| Metric | Side | Selection | Workload | Reference | Current | Change | Repeat range |
|---|---|---|---|---:|---:|---:|---:|
| allocations | client | Largest decrease | bidi_pipelined 64KiB identity plain / 1 in flight | 48.94 | 45.18 | -7.68% | -8.80% to -6.47% |
| allocations | client | Largest increase | bidi_pipelined 1KiB identity TLS / 16 in flight | 47.16 | 47.86 | +1.48% | +0.35% to +2.58% |
| allocations | server | Largest decrease | server_stream 1KiB identity plain / 16 in flight | 33.34 | 31.82 | -4.56% | -16.61% to +8.50% |
| allocations | server | Largest increase | client_stream 1KiB identity plain / 16 in flight | 26.52 | 27.98 | +5.51% | -0.73% to +12.24% |
| requested_bytes | client | Largest decrease | bidi 1KiB identity plain / 16 in flight | 59.09KiB | 56.88KiB | -3.73% | -4.05% to -3.41% |
| requested_bytes | client | Largest increase | bidi 1KiB identity TLS / 16 in flight | 68.10KiB | 71.73KiB | +5.33% | +4.83% to +5.81% |
| requested_bytes | server | Largest decrease | bidi_pipelined 1KiB identity TLS / 16 in flight | 52.79KiB | 50.93KiB | -3.52% | -4.27% to -2.80% |
| requested_bytes | server | Largest increase | bidi 1KiB identity TLS / 16 in flight | 60.18KiB | 63.28KiB | +5.14% | +4.70% to +5.58% |
## safety->batch

| Metric | Side | Selection | Workload | Reference | Current | Change | Repeat range |
|---|---|---|---|---:|---:|---:|---:|
| allocations | client | Largest decrease | bidi 1KiB identity plain / 16 in flight | 42.64 | 39.42 | -7.55% | -7.60% to -7.50% |
| allocations | client | Largest increase | bidi_pipelined 64KiB identity plain / 1 in flight | 45.18 | 49.06 | +8.59% | +2.24% to +15.30% |
| allocations | server | Largest decrease | client_stream 1KiB identity plain / 16 in flight | 27.98 | 24.76 | -11.51% | -18.71% to -4.62% |
| allocations | server | Largest increase | server_stream 1KiB identity plain / 16 in flight | 31.82 | 33.74 | +6.03% | +2.88% to +9.82% |
| requested_bytes | client | Largest decrease | bidi 1KiB identity plain / 1 in flight | 53.86KiB | 42.40KiB | -21.28% | -21.86% to -20.70% |
| requested_bytes | client | Largest increase | server_stream 1KiB identity plain / 1 in flight | 11.37KiB | 11.45KiB | +0.69% | +0.08% to +1.30% |
| requested_bytes | server | Largest decrease | bidi 1KiB identity plain / 1 in flight | 43.46KiB | 31.32KiB | -27.92% | -27.94% to -27.90% |
| requested_bytes | server | Largest increase | bidi_pipelined 64KiB identity plain / 1 in flight | 1,070.29KiB | 1,086.21KiB | +1.49% | +0.99% to +1.99% |
## baseline->batch

| Metric | Side | Selection | Workload | Reference | Current | Change | Repeat range |
|---|---|---|---|---:|---:|---:|---:|
| allocations | client | Largest decrease | bidi 1KiB identity plain / 16 in flight | 45.20 | 39.42 | -12.79% | -13.44% to -12.12% |
| allocations | client | Largest increase | bidi_pipelined 1KiB identity plain / 16 in flight | 39.62 | 40.78 | +2.93% | +0.00% to +6.02% |
| allocations | server | Largest decrease | bidi 1KiB identity plain / 1 in flight | 43.24 | 39.32 | -9.07% | -9.48% to -8.65% |
| allocations | server | Largest increase | unary 1KiB identity TLS / 16 in flight | 25.70 | 26.54 | +3.27% | -8.70% to +14.85% |
| requested_bytes | client | Largest decrease | bidi 1KiB identity plain / 16 in flight | 59.09KiB | 45.19KiB | -23.53% | -23.70% to -23.35% |
| requested_bytes | client | Largest increase | bidi_pipelined 1KiB identity plain / 16 in flight | 48.67KiB | 49.17KiB | +1.04% | +0.66% to +1.43% |
| requested_bytes | server | Largest decrease | bidi 1KiB identity plain / 1 in flight | 43.61KiB | 31.32KiB | -28.17% | -28.23% to -28.11% |
| requested_bytes | server | Largest increase | bidi_pipelined 64KiB identity plain / 1 in flight | 1,075.76KiB | 1,086.21KiB | +0.97% | +0.97% to +0.98% |
## batch->tonic

| Metric | Side | Selection | Workload | Reference | Current | Change | Repeat range |
|---|---|---|---|---:|---:|---:|---:|
| allocations | client | Largest decrease | unary 1KiB identity plain / 1 in flight | 37.10 | 8.12 | -78.11% | -78.20% to -78.03% |
| allocations | server | Largest decrease | unary 1KiB identity plain / 1 in flight | 37.16 | 20.02 | -46.12% | -46.19% to -46.06% |
| requested_bytes | client | Largest decrease | unary 1KiB identity plain / 1 in flight | 26.33KiB | 9.62KiB | -63.46% | -63.51% to -63.41% |
| requested_bytes | client | Largest increase | bidi 1MiB gzip plain / 1 in flight | 17,071.73KiB | 19,871.16KiB | +16.40% | +16.40% to +16.40% |
| requested_bytes | server | Largest decrease | client_stream 1KiB identity plain / 1 in flight | 25.62KiB | 14.63KiB | -42.89% | -42.93% to -42.84% |
| requested_bytes | server | Largest increase | bidi 1MiB gzip plain / 1 in flight | 16,041.52KiB | 18,837.04KiB | +17.43% | +17.43% to +17.43% |

Every source/tonic row and every cost increase in either repeat remains in the JSON, including control endpoints, small increases and mixed directions.
The conditional four-singleton ping-pong model predicts12,480B client/12,420B server requested-capacity reduction per RPC only if all sends flush individually. Observed isolated-stage deltas and residuals remain separate in JSON; there is no allocation-site attribution proof.

576 raw captures, 25/50 calls, two paired repeats per workload/source; shared host.
All endpoint source changes include tonic control endpoints; front selections use native endpoints only.
Every increase in either repeat is retained, including positive changes below instruction tie bands and mixed directions.
Requested bytes count allocation requests, not retained memory/RSS. Context switches are process scheduling events, not task wakeups.
No shipping CPU, latency, throughput or broad superiority follows from native allocator counters.
Original controller exited1 during postprocessing; separate recovery passed without recapture.
