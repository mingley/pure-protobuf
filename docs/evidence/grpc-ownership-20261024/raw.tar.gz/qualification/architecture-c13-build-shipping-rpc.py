#!/usr/bin/env python3
"""Build/validate a copied release RPC benchmark with allocation-counts OFF.

Separate contract from scripts/build-rpc-bench.py. Preparation does no build;
--execute requires a separately granted serial compiler window.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ORIGINAL_BUILDER_SHA = '60d5c9e988a22181d9560060d7aa1445274155fc9c98ba5df31409aeebe2640f'
ORIGINAL_HARNESS_SHA = '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b'
COMMAND = ['cargo', 'build', '--locked', '--release', '--manifest-path',
           'rpc-bench/Cargo.toml', '--no-default-features', '--message-format=json']


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def original_builder(tree):
    path = tree / 'scripts/build-rpc-bench.py'
    assert digest(path) == ORIGINAL_BUILDER_SHA
    spec = importlib.util.spec_from_file_location('shipping_original_builder', path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def shipping_artifact(messages, tree, original):
    executable = original.artifact(messages)
    rows = [row for row in messages if row.get('reason') == 'compiler-artifact'
            and row.get('manifest_path') == str(tree / 'rpc-bench/Cargo.toml')
            and row.get('target', {}).get('name') == 'rpc-bench'
            and row.get('target', {}).get('kind') == ['bin'] and row.get('executable')]
    assert len(rows) == 1
    row = rows[0]
    assert row['features'] == [], 'allocation-counts or another package feature was enabled'
    assert row['profile']['opt_level'] == '3' and row['profile']['test'] is False
    assert row['profile']['debug_assertions'] is False
    return executable, row


def validate_record(path, binary, source_checkout):
    if not __debug__:
        raise RuntimeError('ordinary Python without -O required')
    tree = Path(source_checkout).resolve(strict=True)
    path, binary = Path(path).resolve(strict=True), Path(binary).resolve(strict=True)
    original = original_builder(tree)
    record = json.loads(path.read_text())
    assert record['schema'] == 'pbrs.rpc-bench-shipping-build.v1'
    assert record['source'] == original.source_pin()
    assert record['command'] == COMMAND and record['exit_code'] == 0
    assert record['allocation_counts'] is False and record['cargo_artifact_features'] == []
    assert record['shipping_builder_sha256'] == digest(Path(__file__).resolve())
    assert record['source_builder_sha256'] == ORIGINAL_BUILDER_SHA
    assert record['source_harness_sha256'] == digest(tree / 'scripts/grpc-load-smoke.py') == ORIGINAL_HARNESS_SHA
    assert record['benchmark_entrypoint_sha256'] == digest(tree / 'rpc-bench/src/main.rs')
    assert record['binary_sha256'] == digest(binary)
    assert set(record['tools']) == {'rustc', 'cargo'}
    assert all('1.99.1' in version for version in record['tools'].values())
    assert record['environment']['RUSTFLAGS'] in (None, '')
    assert record['environment']['CARGO_ENCODED_RUSTFLAGS'] in (None, '')
    assert record['environment']['CARGO_BUILD_JOBS'] == '1'
    for name in ('build.stdout.jsonl', 'build.stderr.log'):
        assert record['files'][name] == digest(path.parent / name)
    messages = [json.loads(line) for line in (path.parent / 'build.stdout.jsonl').read_text().splitlines()]
    executable, artifact = shipping_artifact(messages, tree, original)
    assert str(executable) == record['build_executable']
    assert artifact['profile'] == record['cargo_artifact_profile']
    return record


def main():
    if not __debug__:
        raise RuntimeError('ordinary Python without -O required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-checkout', type=Path)
    parser.add_argument('--source')
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'execute_required': True, 'qualified': False,
                          'allocation_counts': False, 'command': COMMAND}, indent=2))
        return
    assert os.environ.get('PYTHONOPTIMIZE') == '0'
    assert args.source_checkout is not None and args.output is not None
    assert re.fullmatch(r'[0-9a-f]{40}', args.source or '')
    tree = args.source_checkout.resolve(strict=True)
    original = original_builder(tree)
    pin = original.source_pin()
    assert pin['commit'] == args.source
    assert digest(tree / 'scripts/grpc-load-smoke.py') == ORIGINAL_HARNESS_SHA
    env = os.environ.copy()
    assert all(not value for key, value in env.items()
               if key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS')
               or (key.startswith('CARGO_TARGET_') and key.endswith('_RUSTFLAGS')))
    assert env.get('CARGO_BUILD_JOBS') == '1', 'root must grant a serial compiler window'
    assert env.get('CARGO_TARGET_DIR') and Path(env['CARGO_TARGET_DIR']).is_absolute(), 'explicit target cache required'
    env['RUSTUP_TOOLCHAIN'] = 'stable'
    tools = {tool: subprocess.check_output([tool, '--version'], cwd=tree, env=env, text=True).strip()
             for tool in ('rustc', 'cargo')}
    assert all('1.99.1' in version for version in tools.values()), tools
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    with (output / 'build.stdout.jsonl').open('xb') as stdout, (output / 'build.stderr.log').open('xb') as stderr:
        result = subprocess.run(COMMAND, cwd=tree, env=env, stdout=stdout, stderr=stderr)
    assert result.returncode == 0, 'shipping build failed; exclusive logs retained'
    assert original.source_pin() == pin, 'source changed during build'
    messages = [json.loads(line) for line in (output / 'build.stdout.jsonl').read_text().splitlines()]
    executable, artifact = shipping_artifact(messages, tree, original)
    binary = output / 'rpc-bench'
    shutil.copy2(executable, binary)
    assert digest(binary) == digest(executable)
    record = {'schema': 'pbrs.rpc-bench-shipping-build.v1', 'qualified': False,
              'source': pin, 'command': COMMAND, 'exit_code': result.returncode,
              'build_executable': str(executable), 'binary_sha256': digest(binary),
              'tools': tools, 'allocation_counts': False, 'cargo_artifact_features': artifact['features'],
              'cargo_artifact_profile': artifact['profile'],
              'shipping_builder_sha256': digest(Path(__file__).resolve()),
              'source_builder_sha256': ORIGINAL_BUILDER_SHA,
              'source_harness_sha256': ORIGINAL_HARNESS_SHA,
              'benchmark_entrypoint_sha256': digest(tree / 'rpc-bench/src/main.rs'),
              'environment': {key: env.get(key) for key in ('RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                              'RUSTUP_TOOLCHAIN', 'CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS')},
              'files': {name: digest(output / name) for name in ('build.stdout.jsonl', 'build.stderr.log')}}
    path = output / 'build.json'
    with path.open('x') as out:
        json.dump(record, out, indent=2)
        out.write('\n')
    validate_record(path, binary, tree)
    print(path)


if __name__ == '__main__':
    main()
