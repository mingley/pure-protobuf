#!/usr/bin/env python3
"""Analyze completed C13 Callgrind captures; instruction counts are not shipping CPU."""
import argparse
from collections import Counter
import datetime
import gzip
import importlib.util
import json
import os
from pathlib import Path
import random

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
NUMERIC_SHA = '65f1a43469cdb7476bc26649d17eea4f69aefde83ce3836d7cf221ba5fe8c2ee'
HELPER_SHA = '9405cd735ae296b0b57be197fcf29b7294fe5cb7f2a5311eeee83651dcf803d9'
MEASURED = ['instructions', 'allocations', 'requested_bytes']


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec); spec.loader.exec_module(result)
    return result


def instructions(path):
    events = []; totals = []
    with gzip.open(path, 'rt') as stream:
        for line in stream:
            if line.startswith('events:'): events.append(line.split()[1:])
            if line.startswith('summary:'): totals.append([int(x) for x in line.split()[1:]])
    assert len(events) == len(totals) == 1 and 'Ir' in events[0] and len(events[0]) == len(totals[0])
    value = totals[0][events[0].index('Ir')]; assert value > 0
    return value


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--state-sha256', required=True)
    parser.add_argument('--output-prefix', type=Path, default=Q / 'architecture-c13-callgrind-analysis')
    args = parser.parse_args()
    if not __debug__ or not args.execute or os.environ.get('PYTHONDONTWRITEBYTECODE') != '1':
        parser.error('ordinary Python, PYTHONDONTWRITEBYTECODE=1 and --execute required')
    import hashlib
    numeric_path = Q / 'architecture-c13-native-analyze-prepared-v2.py'
    helper_path = Q / 'architecture-c13-native-recovery-prepared-v2.py'
    assert hashlib.sha256(numeric_path.read_bytes()).hexdigest() == NUMERIC_SHA
    assert hashlib.sha256(helper_path.read_bytes()).hexdigest() == HELPER_SHA
    n = module('c13_cpu_numeric_functions', numeric_path)
    h = module('c13_cpu_validation_helpers', helper_path)
    prefix = args.output_prefix.resolve(); assert prefix.parent == Q
    assert not prefix.with_suffix('.json').exists() and not prefix.with_suffix('.md').exists()
    original = Q / 'architecture-c13-callgrind-captures'; state_path = original / 'state.json'
    assert n.digest(state_path) == args.state_sha256
    state = n.read(state_path)
    assert state['state'] == 'finished' and state['passed'] is True and state['phase'] == 'callgrind'
    assert state['qualified'] is False and state['production_ready'] is False
    assert state['rpc_counts'] == [10, 20] and state['cells_per_source'] == 90 and state['expected_captures'] == 540
    assert state['controller_sha256'] == n.digest(original / 'controller.py') == h.CONTROLLER_SHA
    assert state['sources_sha256'] == n.digest(original / 'sources.json') == h.SOURCES_SHA
    receipt_path = Q / 'resource-c13-callgrind-execution.json'; receipt = n.read(receipt_path)
    assert receipt['exit_code'] == 0 and not receipt.get('timeout') and receipt['cwd'] == str(ROOT)
    argv = receipt['command']; assert argv[0:2] == ['python3', 'work/qualification/architecture-c13-paired-counters.py']
    assert argv[argv.index('--phase') + 1] == 'callgrind'
    assert (ROOT / argv[argv.index('--output') + 1]).resolve() == original
    assert (ROOT / argv[argv.index('--sources') + 1]).resolve() == Q / 'architecture-c13-counter-sources.json'
    vg = state['valgrind']; assert n.digest(Path(vg['path'])) == vg['sha256']
    assert all(n.digest(Path(r['path'])) == r['sha256'] for r in vg['libraries'])
    controller = module('c13_cpu_controller', original / 'controller.py'); cells = controller.workloads('callgrind')
    assert len(cells) == 90
    sources = n.read(original / 'sources.json'); assert list(sources) == list(h.COMMITS)
    order = list(range(0, 90, 2)); random.Random(20261024).shuffle(order); expected = []
    for first in order:
        for index in [first, first + 1]:
            for role in (list(sources) if cells[index]['repeat'] == 0 else list(reversed(sources))):
                for count in ([10, 20] if cells[index]['repeat'] == 0 else [20, 10]):
                    expected.append({'source': role, 'count': count, 'cell': index, 'passed': True})
    assert state['completed'] == expected
    assert not any(p.is_symlink() for p in original.rglob('*'))
    inputs = [n.ref(p) for p in original.rglob('*') if p.is_file()]
    inputs += [n.ref(receipt_path), n.ref(receipt_path.with_suffix('.stdout')), n.ref(receipt_path.with_suffix('.stderr'))]
    contexts = {}; costs = {}; ledgers = {}; accounting = {}; cells_by_identity = {}; settings = set()
    for role, cfg in sources.items():
        tree = Path(cfg['checkout']); binary = Path(cfg['binary'])
        for relative, pin in h.PINS.items(): assert n.digest(tree / relative) == pin
        smoke = module('c13_cpu_smoke_' + role, tree / 'scripts/grpc-load-smoke.py')
        ledger = module('c13_cpu_ledger_' + role, tree / 'scripts/dominance-ledger.py')
        build = smoke.verified_build(Path(cfg['build_record']), binary, tree)
        assert cfg['source'] == build['source']['commit'] == h.COMMITS[role] and state['builds'][role] == build
        contexts[role] = (tree, binary, cfg, smoke, ledger, build)
        a, small = ledger.load(original / role / 'n-10'); b, large = ledger.load(original / role / 'n-20')
        assert a['rpc_count'] == 10 and b['rpc_count'] == 20 and set(small) == set(large) and len(small) == 90
        totals = dict.fromkeys(h.COUNTERS, 0); costs[role] = {}
        for count in [10, 20]:
            directory = original / role / f'n-{count}'; report = n.read(directory / 'report.json')
            assert report['cells'] == cells and report['head'] == h.COMMITS[role] and report['build_record'] == build
            assert report['binary_sha256'] == build['binary_sha256'] and report['harness_script_sha256'] == n.digest(directory / 'harness.py') == h.PINS['scripts/grpc-load-smoke.py']
            assert report['allocation_counts'] is True and report['context_switches'] is False and report['callgrind'] == vg['path'] and report['strace'] is None and report['seed'] == 20261024
            settings.add(json.dumps({k: report[k] for k in ['host', 'cpu_affinity']}, sort_keys=True))
            assert {p.name for p in directory.glob('cell-*')} == {f'cell-{i:03d}' for i in range(90)}
            for i, cell in enumerate(cells):
                path = directory / f'cell-{i:03d}'; row = n.read(path / 'run.json'); metrics = n.read(path / 'metrics.json')
                assert row['passed'] is True and row['cell'] == cell and row['metrics'] == metrics and 'error' not in row
                assert row['client_exit_code'] == 0 and row['server_exit_before_teardown'] is None
                assert row['environment'] == {'TOKIO_WORKER_THREADS': '2'} and 'context_switch_totals' not in row
                smoke.validate_metrics(metrics); assert metrics['attempted_rpcs'] == count and metrics['successful_rpcs'] == count
                ready = [line for line in (path / 'server.stdout').read_text().splitlines() if line.startswith('READY ')]
                assert len(ready) == 1
                address, = [w.split('=', 1)[1] for w in ready[0].split() if w.startswith('addr=')]
                commands = h.expected_commands(binary, tree, path, cell, count, address)
                for side in ['client', 'server']:
                    assert smoke.allocation_record(path / f'{side}.stdout') == row['allocation_totals'][side]
                    assert instructions(path / f'{side}.callgrind.gz') == row['instruction_totals'][side]
                    assert not (path / f'{side}.callgrind').exists()
                    commands[side] = [vg['path'], '--tool=callgrind', '--quiet', f'--callgrind-out-file={path / (side + ".callgrind")}', *commands[side]]
                assert row['commands'] == commands
                for key in totals: totals[key] += metrics[key]
        assert all(totals[k] == 2700 for k in h.COUNTERS[:4]) and all(totals[k] == 0 for k in h.COUNTERS[4:])
        accounting[role] = totals
        for identity, row in small.items():
            if identity in cells_by_identity: assert cells_by_identity[identity] == row['cell']
            cells_by_identity[identity] = row['cell']
            costs[role][identity] = {(side, metric): ledger.differential(row, large[identity], side, metric, 10) for side in ['client', 'server'] for metric in MEASURED}
        result = ledger.compare(original / role / 'n-10', original / role / 'n-20')
        assert result == n.read(original / role / 'ledger.json'); ledgers[role] = result
    assert len(settings) == 1
    assert len({json.dumps(c[5]['tools'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c[5]['source']['locks'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c[5]['command']) for c in contexts.values()}) == 1
    source_rows = []; tonic_rows = []
    for before, after in n.STAGES:
        assert set(costs[before]) == set(costs[after])
        for identity, first in costs[before].items():
            for (side, metric), value in first.items():
                source_rows.append({'comparison': before + '->' + after, 'cell': cells_by_identity[identity], 'side': side, 'metric': metric, 'before': value, 'after': costs[after][identity][side, metric]})
    for role, ledger_result in ledgers.items():
        for row in ledger_result['rows']:
            tonic_rows.append({'comparison': role + '->tonic', 'cell': row['cell'], 'side': row['side'], 'metric': row['metric'], 'before': row['tonic_per_rpc'], 'after': row['native_per_rpc'], 'ledger_disposition': row['disposition']})
    source_groups = n.grouped(source_rows); tonic_groups = n.grouped(tonic_rows)
    for r in source_groups + tonic_groups:
        r['any_positive_cost_repeat'] = r['metric'] in MEASURED and any(v is not None and v > 0 for v in r['paired_percent']['values'])
        r['positive_cost_median'] = r['metric'] in MEASURED and r['percent_of_medians'] is not None and r['percent_of_medians'] > 0
    assert all(n.ref(Path(r['path'])) == r for r in inputs)
    for tree, binary, cfg, smoke, _, build in contexts.values(): assert smoke.verified_build(Path(cfg['build_record']), binary, tree) == build
    assert n.digest(state_path) == args.state_sha256
    result = {'schema': 'pbrs.c13-callgrind-numeric-analysis.v1', 'phase': 'callgrind', 'qualified': False, 'production_ready': False,
        'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'sources': h.COMMITS, 'actual_captures': len(expected),
        'actual_successful_rpcs': sum(v['successful_rpcs'] for v in accounting.values()), 'actual_rpc_totals': accounting,
        'source_groups': source_groups, 'same_side_tonic_groups': tonic_groups, 'all_source_positive_cost_changes': [r for r in source_groups if r['any_positive_cost_repeat']],
        'all_tonic_positive_cost_changes': [r for r in tonic_groups if r['any_positive_cost_repeat']], 'positive_cost_cutoff_percent': 0,
        'missing_metrics': {k: v['missing_metrics'] for k, v in ledgers.items()}, 'inputs': inputs,
        'helpers': [n.ref(Path(__file__).resolve()), n.ref(numeric_path), n.ref(helper_path)],
        'limits': ['540 captures/8100 actual successful RPCs, N10/20, two paired repeats per source/workload, shared host.',
            'Callgrind counts instrumented user-space instructions, not hardware cycles or shipping process CPU.',
            'Every source/control and tonic row, small increase, mixed repeat and unresolved metric is retained.',
            'Allocation bytes count cumulative requests, not retained memory. Native/shipping/bulk totals remain separate.',
            'No broad superiority, complete matrix, production or24h qualification is established.']}
    with prefix.with_suffix('.json').open('x') as stream: json.dump(result, stream, indent=2, allow_nan=False); stream.write('\n')
    lines = ['# C13 instrumented instruction counters', '', 'Sources: ' + ', '.join(k + ' `' + v[:8] + '`' for k, v in h.COMMITS.items()) + '.',
        '', '**540 captures /8100 successful RPCs**,2700 per source. All terminal accounting errors are zero.', '',
        'Instruction values are N/2N differences per RPC. They do not establish shipping CPU speed.', '',
        '| Stage | Side | Workload | Reference IR/RPC | Current IR/RPC | Change | Repeat range |', '|---|---|---|---:|---:|---:|---:|']
    for comparison, groups in [(a + '->' + b, source_groups) for a,b in n.STAGES] + [('batch->tonic', tonic_groups)]:
        for side in ['client','server']:
            rows = [r for r in groups if r['comparison'] == comparison and r['side'] == side and r['native_endpoint'] and r['metric'] == 'instructions' and r['percent_of_medians'] is not None]
            lower = [r for r in rows if r['percent_of_medians'] < 0]; higher = [r for r in rows if r['percent_of_medians'] > 0]
            for row in ([min(lower, key=lambda r:r['percent_of_medians'])] if lower else []) + ([max(higher, key=lambda r:r['percent_of_medians'])] if higher else []):
                lines.append(f"| {comparison} | {side} | {n.label(row)} | {row['before']['median']:,.0f} | {row['after']['median']:,.0f} | {row['percent_of_medians']:+.2f}% | {row['paired_percent']['min']:+.2f}% to {row['paired_percent']['max']:+.2f}% |")
    lines += ['', 'All instruction, allocation and requested-byte values/ranges remain in JSON, including every increase in either repeat.', '', *result['limits']]
    with prefix.with_suffix('.md').open('x') as stream: stream.write('\n'.join(lines) + '\n')
    print(json.dumps({'phase':'callgrind','qualified':False,'actual_captures':len(expected),'successful_rpcs':result['actual_successful_rpcs'],
        'source_groups':len(source_groups),'tonic_groups':len(tonic_groups),'positive_source_groups':len(result['all_source_positive_cost_changes']),'positive_tonic_groups':len(result['all_tonic_positive_cost_changes'])}))


if __name__ == '__main__':
    main()
