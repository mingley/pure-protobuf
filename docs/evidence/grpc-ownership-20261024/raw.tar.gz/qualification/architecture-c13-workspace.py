#!/usr/bin/env python3
"""Run the complete final workspace with physical Git-source proofs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import stat
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
SOURCE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
PREFIX = Q / 'architecture-c13-workspace'


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def save(path, value, exclusive=False):
    if exclusive:
        with path.open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
    else:
        temporary = path.with_suffix('.next')
        with temporary.open('x') as stream:
            json.dump(value, stream, indent=2)
            stream.write('\n')
        temporary.replace(path)


def source_proof(label):
    assert git('rev-parse', 'HEAD').decode().strip() == SOURCE
    assert not git('status', '--porcelain', '--untracked-files=all')
    assert git('rev-parse', '--show-object-format').strip() == b'sha1'
    rows = []
    for record in git('ls-tree', '-rlz', SOURCE).split(b'\0'):
        if not record:
            continue
        fields, raw_name = record.split(b'\t', 1)
        mode, kind, oid, size = fields.decode().split()
        assert kind == 'blob', 'tracked submodule needs an explicit proof'
        name, size = os.fsdecode(raw_name), int(size)
        path = ROOT / name
        before = path.lstat()
        digest = hashlib.sha1(f'blob {size}\0'.encode())
        if mode == '120000':
            assert stat.S_ISLNK(before.st_mode)
            data = os.fsencode(os.readlink(path))
            assert len(data) == size
            digest.update(data)
        else:
            assert mode in ('100644', '100755') and stat.S_ISREG(before.st_mode)
            assert before.st_size == size
            assert bool(before.st_mode & 0o111) == (mode == '100755')
            with path.open('rb') as stream:
                for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                    digest.update(chunk)
        assert path.lstat().st_mtime_ns == before.st_mtime_ns
        assert digest.hexdigest() == oid, name
        rows.append(dict(path=name, mode=mode, git_blob=oid, bytes=size))
    value = dict(source=SOURCE, tree=git('rev-parse', 'HEAD^{tree}').decode().strip(),
                 complete_physical_tracked_checkout=True, files=rows,
                 tracked_files=len(rows), tracked_bytes=sum(row['bytes'] for row in rows))
    path = PREFIX.with_name(PREFIX.name + f'-source-{label}.json')
    save(path, value, True)
    return dict(path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                tracked_files=value['tracked_files'], tracked_bytes=value['tracked_bytes'])


def main():
    if not __debug__:
        raise RuntimeError('ordinary Python without -O required')
    assert os.sys.argv[1:] == ['--execute'], 'use --execute only after final source and 8GiB entry headroom'
    state_path = PREFIX.with_suffix('.json')
    assert not state_path.exists()
    assert shutil.disk_usage(ROOT).free >= 8 * 1024**3
    command = [str(ROOT / 'work/run-rust'), 'cargo', '+stable', 'test', '--locked',
               '--workspace', '--all-features', '--no-fail-fast', '--', '--test-threads=4']
    env = os.environ.copy()
    env.update(CARGO_TARGET_DIR=str(ROOT / 'work/stable-target'), CARGO_BUILD_JOBS='2',
               RUST_TEST_THREADS='4', CARGO_INCREMENTAL='0')
    state = dict(source=SOURCE, qualified=False, production_ready=False,
                 started_utc=now(), state='running', command=command,
                 timeout_seconds=7200, disk_floor_bytes=512 * 1024**2,
                 free_bytes_before=shutil.disk_usage(ROOT).free,
                 boot_id=Path('/proc/sys/kernel/random/boot_id').read_text().strip(),
                 environment={key: env[key] for key in ('CARGO_TARGET_DIR', 'CARGO_BUILD_JOBS',
                                                       'RUST_TEST_THREADS', 'CARGO_INCREMENTAL')})
    state['source_before'] = source_proof('before')
    save(state_path, state, True)
    start = time.monotonic()
    child = None
    try:
        with PREFIX.with_suffix('.stdout').open('xb') as out, PREFIX.with_suffix('.stderr').open('xb') as err:
            child = subprocess.Popen(command, cwd=ROOT, env=env, stdout=out, stderr=err,
                                     start_new_session=True)
            state['child_pid'] = child.pid
            save(state_path, state)
            abort_reason = None
            while child.poll() is None:
                if time.monotonic() - start > 7200:
                    abort_reason = 'timeout'
                if shutil.disk_usage(ROOT).free < state['disk_floor_bytes']:
                    abort_reason = 'disk_floor'
                if abort_reason:
                    os.killpg(child.pid, signal.SIGTERM)
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        os.killpg(child.pid, signal.SIGKILL)
                        child.wait()
                    break
                time.sleep(5)
            state.update(exit_code=child.returncode, abort_reason=abort_reason,
                         duration_seconds=time.monotonic() - start)
        state['source_after'] = source_proof('after')
        output = PREFIX.with_suffix('.stdout').read_text()
        counts = [list(map(int, row)) for row in re.findall(
            r'test result: (?:ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored;', output)]
        state.update(targets=len(counts), counts=dict(passed=sum(row[0] for row in counts),
                     failed=sum(row[1] for row in counts), ignored=sum(row[2] for row in counts)))
        assert state['exit_code'] == 0 and state['abort_reason'] is None
        assert counts and state['counts']['failed'] == 0
        assert state['source_before']['tracked_files'] == state['source_after']['tracked_files']
        state['state'] = 'passed'
    except BaseException as error:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            state['exit_code'] = child.returncode
        state.update(state='failed', error=dict(type=type(error).__name__, message=str(error)))
        raise
    finally:
        state.update(completed_utc=now(), free_bytes_after=shutil.disk_usage(ROOT).free)
        save(state_path, state)
    print(json.dumps({key: state[key] for key in ('source', 'state', 'targets', 'counts', 'duration_seconds')}))


if __name__ == '__main__':
    main()
