#!/usr/bin/env python3
"""Capture source-verified endpoint counters in paired ABBA order.

Sources JSON maps version names to checkout/build-record/binary paths. The
first source is the control. Native and Callgrind phases use unchanged harnesses;
all raw reports and N/2N ledgers are retained. Shared-host results are diagnostic.
"""
import argparse
import gzip
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import subprocess
from types import SimpleNamespace

ACTIVE_STATE_PATH = None


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def workloads(phase):
    shapes = ['unary', 'client_stream', 'server_stream', 'bidi', 'bidi_pipelined']
    groups = [(1024, False, 'identity', 1, shapes)]
    if phase == 'callgrind':
        groups += [(size, False, 'gzip', 1, shapes) for size in (1024, 65536)]
    if phase == 'native':
        groups += [
            (1024, False, 'identity', 16, shapes[1:]),
            (1024, True, 'identity', 16, ['unary', 'bidi', 'bidi_pipelined']),
            (65536, False, 'identity', 1, ['client_stream', 'server_stream', 'bidi_pipelined']),
            (1048576, False, 'gzip', 1, ['bidi']),
        ]
    pairs = [('native', 'prost', 'tonic', 'prost'),
             ('tonic', 'prost', 'native', 'prost'),
             ('tonic', 'prost', 'tonic', 'prost')]
    return [dict(pair=list(pair), shape=shape, payload_bytes=size, tls=tls,
                 compression=compression, connections=1, in_flight=load, repeat=repeat)
            for size, tls, compression, load, selected in groups
            for shape, pair, repeat in itertools.product(selected, pairs, range(2))]


def main():
    global ACTIVE_STATE_PATH
    if not __debug__:
        raise RuntimeError('run ordinary Python without -O: validation assertions are required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--phase', choices=['native', 'callgrind'], required=True)
    parser.add_argument('--valgrind', type=Path)
    parser.add_argument('--valgrind-lib', type=Path)
    args = parser.parse_args()
    if args.phase == 'callgrind' and (args.valgrind is None or args.valgrind_lib is None):
        parser.error('--valgrind and --valgrind-lib are required for Callgrind')
    if args.phase == 'native' and (args.valgrind is not None or args.valgrind_lib is not None):
        parser.error('native captures must not receive Valgrind arguments')
    sources = json.loads(args.sources.read_text())
    sources_sha = digest(args.sources)
    assert len(sources) == 3, 'this campaign requires baseline, safety, and safety+batch sources'
    cells = workloads(args.phase)
    counts = (25, 50) if args.phase == 'native' else (10, 20)
    # Keep concurrent cells fully populated at both N and 2N.
    assert all(cell['in_flight'] <= counts[0] for cell in cells)
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, output / 'controller.py')
    shutil.copy2(args.sources, output / 'sources.json')
    controller_sha = digest(__file__)
    state = dict(qualified=False, production_ready=False, phase=args.phase,
                 state='running', rpc_counts=counts, cells_per_source=len(cells),
                 expected_captures=len(cells) * len(counts) * len(sources),
                 controller_sha256=controller_sha, sources_sha256=sources_sha,
                 completed=[], builds={})
    ACTIVE_STATE_PATH = output / 'state.json'
    save(ACTIVE_STATE_PATH, state)
    if args.valgrind:
        executable = args.valgrind.resolve(strict=True)
        args.valgrind = executable
        library_dir = args.valgrind_lib.resolve(strict=True)
        os.environ['VALGRIND_LIB'] = str(library_dir)
        libraries = sorted(p for p in library_dir.glob('*amd64-linux*') if p.is_file())
        if not libraries or not (library_dir / 'callgrind-amd64-linux').is_file():
            raise RuntimeError('cannot identify Valgrind instrumentation libraries')
        state['valgrind'] = dict(path=str(executable), sha256=digest(executable),
                                 library_dir=str(library_dir),
                                 version=subprocess.check_output([str(executable), '--version'], text=True).strip(),
                                 libraries=[dict(path=str(p), sha256=digest(p)) for p in libraries if p.is_file()])
    contexts = {}
    for index, (name, row) in enumerate(sources.items()):
        tree = Path(row['checkout']).resolve()
        smoke = module(f'c13_smoke_{index}', tree / 'scripts/grpc-load-smoke.py')
        ledger = module(f'c13_ledger_{index}', tree / 'scripts/dominance-ledger.py')
        binary, record = Path(row['binary']).resolve(), Path(row['build_record']).resolve()
        build = smoke.verified_build(record, binary, tree)
        state['builds'][name] = build
        harness_sha = digest(tree / 'scripts/grpc-load-smoke.py')
        ledger_sha = digest(tree / 'scripts/dominance-ledger.py')
        contexts[name] = (tree, binary, record, build, smoke, ledger, harness_sha, ledger_sha)
        for count in counts:
            directory = output / name / f'n-{count}'
            directory.mkdir(parents=True)
            report = dict(schema='pbrs.load-smoke.v2', binary_sha256=digest(binary),
                          harness_script_sha256=harness_sha, head=build['source']['commit'],
                          dirty=False, source_verified=True, build_record=build,
                          host=platform.uname()._asdict(), cpu_affinity=sorted(os.sched_getaffinity(0)),
                          seed=20261024, cells=cells, rpc_count=count,
                          duration_per_cell_seconds=60, allocation_counts=True,
                          context_switches=args.phase == 'native',
                          callgrind=str(args.valgrind) if args.valgrind else None,
                          strace=None, strace_version=None, qualification={'qualified': False}, runs=[])
            save(directory / 'manifest.json', report)
            shutil.copy2(tree / 'scripts/grpc-load-smoke.py', directory / 'harness.py')
    assert len({(c[6], c[7]) for c in contexts.values()}) == 1, 'harnesses differ'
    assert len({json.dumps(c[3]['tools'], sort_keys=True) for c in contexts.values()}) == 1, 'build tools differ'
    assert len({json.dumps(c[3]['source']['locks'], sort_keys=True) for c in contexts.values()}) == 1, 'locks differ'
    assert len({json.dumps(c[3]['command']) for c in contexts.values()}) == 1, 'build profiles/features differ'
    assert len({c[3]['source']['commit'] for c in contexts.values()}) == 3, 'source labels repeat a commit'
    save(output / 'state.json', state)
    pairs = list(range(0, len(cells), 2))
    random.Random(20261024).shuffle(pairs)
    order = [index for first in pairs for index in (first, first + 1)]
    # Each repeated cell runs control->candidate then candidate->control.
    for index in order:
        cell = cells[index]
        names = list(sources)
        if cell['repeat'] % 2:
            names.reverse()
        for name in names:
            tree, binary, record, build, smoke, ledger, harness_sha, ledger_sha = contexts[name]
            for count in (counts if cell['repeat'] % 2 == 0 else tuple(reversed(counts))):
                directory = output / name / f'n-{count}'
                assert digest(args.sources) == sources_sha
                smoke.verified_build(record, binary, tree)
                assert digest(args.sources) == sources_sha
                assert digest(tree / 'scripts/grpc-load-smoke.py') == harness_sha
                assert digest(tree / 'scripts/dominance-ledger.py') == ledger_sha
                settings = SimpleNamespace(binary=binary, source_checkout=tree, duration=60,
                                           rpc_count=count, allocation_counts=True,
                                           context_switches=args.phase == 'native',
                                           callgrind=args.valgrind, strace=None)
                child = directory / f'cell-{index:03d}'
                result = smoke.run_cell(settings, cell, child)
                smoke.verified_build(record, binary, tree)
                assert digest(tree / 'scripts/grpc-load-smoke.py') == harness_sha
                assert digest(tree / 'scripts/dominance-ledger.py') == ledger_sha
                for profile in child.glob('*.callgrind'):
                    with profile.open('rb') as original, gzip.open(str(profile) + '.gz', 'wb') as zipped:
                        shutil.copyfileobj(original, zipped)
                    profile.unlink()
                state['completed'].append(dict(source=name, count=count, cell=index, passed=result['passed']))
                save(output / 'state.json', state)
                if not result['passed']:
                    raise RuntimeError(f'failed capture retained: {child}')
    for name, context in contexts.items():
        tree, binary, record, build, smoke, ledger, harness_sha, ledger_sha = context
        smoke.verified_build(record, binary, tree)
        assert digest(tree / 'scripts/grpc-load-smoke.py') == harness_sha
        assert digest(tree / 'scripts/dominance-ledger.py') == ledger_sha
        for count in counts:
            directory = output / name / f'n-{count}'
            report = json.loads((directory / 'manifest.json').read_text())
            report.update(runs=[dict(path=f'cell-{i:03d}/run.json', passed=True) for i in range(len(cells))],
                          binary_unchanged=True, source_unchanged=True,
                          harness_script_unchanged=True, passed=True)
            save(directory / 'report.json', report)
        comparison = ledger.compare(output / name / f'n-{counts[0]}', output / name / f'n-{counts[1]}')
        save(output / name / 'ledger.json', comparison)
    assert digest(__file__) == controller_sha
    assert digest(args.sources) == sources_sha
    if args.valgrind:
        assert digest(state['valgrind']['path']) == state['valgrind']['sha256']
        assert all(digest(row['path']) == row['sha256'] for row in state['valgrind']['libraries'])
    assert len(state['completed']) == state['expected_captures']
    state.update(state='finished', passed=True)
    save(output / 'state.json', state)
    print(json.dumps({k: state[k] for k in ('state', 'phase', 'expected_captures', 'qualified')}))


if __name__ == '__main__':
    try:
        main()
    except Exception as error:
        if ACTIVE_STATE_PATH is not None:
            state = json.loads(ACTIVE_STATE_PATH.read_text())
            state.update(state='failed', passed=False,
                         error=dict(type=type(error).__name__, message=str(error)))
            save(ACTIVE_STATE_PATH, state)
        raise
