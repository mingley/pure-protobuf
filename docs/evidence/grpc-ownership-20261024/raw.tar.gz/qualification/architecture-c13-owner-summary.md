# Ordinary successful DATA owner release

Current scope: normal completed DATA payload owners and already-retired owners during staging unwind/IO failure. Four private stream backend production files changed: mod.rs, prioritize.rs, send.rs and streams.rs. Codec code, public APIs and permanent engine fields did not change. Other concurrent safety/kernel changes are explicitly included in the green source snapshots, not attributed to this repair.

## Actual causal evidence

The original preparation was applied as test-only code to f36c5062. An independent registry-h2 peer received one complete uncompressed gRPC message, status0, exactly one owner destruction and successful same-connection recovery. An application-controlled Bytes::from_owner destructor asked an OS thread to query capacity on the same engine. Its wait was bounded3seconds, then the worker was joined outside Drop.

- Unlocked positive control: PASS, query returned during Drop.
- Copied64-byte DATA: valid output/recovery and worker completion, then final reentry assertion RED (bounded watchdog).
- Chained16KiB DATA: valid output/recovery and worker completion, then final reentry assertion RED (bounded watchdog).

Records: architecture-c13-owner-red-{control,small,large}.{json,stdout,stderr}. Exact source/patch and actual libtest ELF/hash are in architecture-c13-owner-red-{source,elf}. No baseline production file was changed before that ELF was copied.

The copied/chained phase witnesses identify codec ownership and flush gating. The original chain fixture does not uniquely identify the post-flush Inner helper: the top-of-loop reclaimer can also consume that frame after CodecFull. Stronger private controls below explicitly invoke that helper.

## Repair

A RetiredData scratch batch retains up to16 original frames. The batch is declared outside the engine lock scope, and the send-buffer guard is nested inside. Normal reclaim clears in-flight state under lock; fully consumed or discarded original frames stay in the outer batch. Partial original payloads are requeued with their original EOS intent. A full scratch batch returns RetiredFull, unlocks and drops owners, then continues staging the same encoded batch. It does not force socket writes or flushes.

Post-flush reclaim transfers the frame to the outer batch before inspection. Its tail check reads original inner.remaining, not Prioritized::remaining, which is capped by the exhausted per-HTTP2-frame limit. The explicit partial-helper control verifies that unsent bytes remain queued and only the final chunk restores EOS.

No B:Clone/Copy requirement, new payload-copy operation, detached destructor task, unbounded Vec/TLS queue or extra owner Arc was introduced. Frame metadata still moves; its instruction cost has not been measured. The fixed array contains original frame ownership. The count of opaque owners is bounded; their backing allocations and RSS are not bounded by visible slice size.

## Actual green controls

First mixed-source build: original3owner cases PASS. The previous5deadline/cancellation/credit/header controls also PASS from the copied first-green ELF. Records: architecture-c13-owner-first-check and architecture-c13-owner-existing-terminal, with source/actual ELF references.

Six stronger controls passed under architecture-c13-owner-strong-check-v3:

1.33small tracked owners acquire the actual engine and send-buffer locks during Drop. Encoded output contains33DATA frames with final EOS, one in-memory AsyncWrite call and one flush call; owner-retirement boundaries do not force IO in this control. These are not TCP syscall measurements.
2.A40-byte payload first emits16bytes without EOS or owner destruction; no more DATA appears before WINDOW_UPDATE. Remaining credit completes all40bytes, final EOS and one unlocked owner Drop.
3.Explicit post-flush consumed-frame reclaim retains its owner until after the engine guard exits.
4.Explicit post-flush partial-frame reclaim preserves the original unsent tail and EOS.
5.A controlled second-frame Buf::chunk panic occurs while staging after a first frame was retired. Catch-unwind occurs outside poll_complete. The first owner observes both real locks available during unwind and drops once. The second buffer's own Drop is inert; this does not claim arbitrary current-frame panic owners are unlocked.
6.Broken IO occurs after a copied owner was retired. It drops once unlocked; a still-chained codec owner drops once unlocked at explicit codec teardown. The test expects BrokenPipe and makes no successful-response/recovery claim for broken IO.

The private observer uses nonblocking try_lock on the actual engine and send-buffer locks. Linux uses the existing non-poisoning futex mutex; portable fallback handles poison as an acquired guard and clears it before fixture teardown. No proxy mutex model or unbounded deadlock is used.

Scratch value sizes observed in this all-feature test build: RetiredData<Bytes>=904bytes; RetiredData<controlled Body>=1032bytes. These are value-layout measurements, not exact machine stack-frame size, heap requests, RSS or performance results. Scratch size scales with private generic B; shipping transport uses Bytes. Reassess the bound if larger internal Buf types are introduced.

## Preserved fixture failures

The first stronger compile failed because backend Send shadowed std::marker::Send in the new test trait object. V2 qualified the trait, compiled and reached the ownership/framing assertions, but every bare internal Streams fixture then failed Counts::drop because it omitted the real connection driver's EOF cleanup. Those actual errors remain under architecture-c13-owner-strong-check and -v2, including the V2 ELF copy. V3 adds explicit recv_eof cleanup after observations; no status/credit/Drop/write-count assertion was widened. V3 records/source/test file and actual ELF copy/hash are preserved separately.

## Read-only source quality review

The retirement type and helpers are visible only within private stream backend modules. Checked slot access/expect calls assert private invariants: callers ensure spare capacity before taking a frame; last/pop operate on the just-retained frame. The many-frame test exercises multiple full batches. Original frame ownership is retained before reclaim assertions or tail inspection; locks are destroyed before outer retirement storage on errors and unwind. Partial resolve occurs before removing its frame from retirement storage. No permanent engine layout or public API changed.

The RetiredFull variant is private staging control. Receive-only buffering cannot produce it; poll_complete consumes it before the IO phase. It does not mark the buffer idle while pending work remains. Complete/Idle still register the driver waker under the observation lock before owners are dropped, so reentrant producers retain the existing wake/idle protocol.

## Limits and next validation

This does not claim that every backend callback or destructor is unlocked. Generic Buf remaining/chunk/advance still run under staging locks. Current-frame generic Buf panic destruction, legacy queue clears, resets, headers, recv_eof and unrelated waker paths remain separate source concerns. The new EOF in internal tests is fixture cleanup after all tracked-owner observations, not qualification of arbitrary queued EOF owners.

There is no production performance claim yet. Measure tiny unary, streamed batches, many ready streams, slow readers, instructions/lock boundaries, writes/syscalls, allocation requests and retained memory on the final source. Broader grpc, sanitizer, slot-ownership and production gates remain parent-controlled. Frozen source trees, active soaks and C12 archives were not changed.
