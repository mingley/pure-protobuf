#!/usr/bin/env python3
"""Bounded source and synthetic generation controls; no build or diagnostic run."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
def module(name):
    path=Q/name;spec=importlib.util.spec_from_file_location(name.replace('.','_'),path)
    value=importlib.util.module_from_spec(spec);spec.loader.exec_module(value);return value
C=module('architecture-c13-soak-common.py');M=module('architecture-c13-soaks.py');rows=[]
def check(name,action,wanted):
    try: action();accepted=True
    except (AssertionError,ValueError,KeyError,TypeError,FileNotFoundError,RuntimeError):accepted=False
    assert accepted==wanted,name
    rows.append({'case':name,'expected_accept':wanted,'actual_accept':accepted})
def write(path,value):path.write_text(json.dumps(value)+'\n')
def main():
    data=C.pins('ef6daae4144cbe3bb1696d5be8e06aef805cd8e6efa3b4989b5eb5bc94ec4342')
    fixture,facts,count=M.generated_fixture(data)
    assert count==30 and [row['fixture_cases'] for row in facts]==[3,19,5,3]
    assert fixture==(Q/'architecture-c13-deadline-fixture.rs').read_bytes()
    rows.append({'case':'exact30-case Git-object transformation matches staged fixture','expected_accept':True,'actual_accept':True})
    baseline={'state':'completed','requested_seconds':30,'elapsed_seconds':30.1,'completed_cycles':1,
              'fixture_cases_per_cycle':30,'controlled_tokio_time':True,'generation':'a'*32,'boot_id':'boot',
              'pid_start_ticks':42,'retained_capacity':0,'retained_buffers':0,'acquired':0,'released':0,
              'fd_count':8,'baseline_fd_count':8,'alive_tasks':0,'baseline_alive_tasks':0,
              'rss_bytes':4*1024**2,'peak_retained_capacity':0}
    check('complete synthetic progress accepted',lambda:M.validate_progress(baseline,30),True)
    for name,key,value in [('short duration','elapsed_seconds',29.9),('extra case','fixture_cases_per_cycle',31),
        ('missing case','fixture_cases_per_cycle',29),('clock scope absent','controlled_tokio_time',False),
        ('missing generation','generation',''),('zero PID start','pid_start_ticks',0),
        ('retained capacity','retained_capacity',1),('retained buffer','retained_buffers',1),
        ('lease imbalance','acquired',1),('FD leak','fd_count',9),('task leak','alive_tasks',1),
        ('over-cap RSS','rss_bytes',1073741824),('over-cap cache','peak_retained_capacity',16777217)]:
        changed=copy.deepcopy(baseline);changed[key]=value
        check(name,lambda changed=changed:M.validate_progress(changed,30),False)
    recovery=Q/'architecture-c13-native-recovered/state.json'
    actual=C.load(recovery);reference=C.ref(recovery)
    check('actual explicit native recovery metadata accepted without relabeling controller exit1',lambda:C.validate_native_recovery(actual,reference),True)
    for name,key,value in [('generic passed native rejected','state','passed'),('wrong recovery schema','schema','other'),
        ('missing raw success','raw_capture_passed',False),('rewritten original success','original_controller_passed',True),
        ('hidden original exit1','original_controller_exit_code',0),('wrong capture count','actual_captures',575),
        ('wrong recovery kind','recovery_kind','recapture')]:
        changed=copy.deepcopy(actual);changed[key]=value
        check(name,lambda changed=changed:C.validate_native_recovery(changed,reference),False)
    check('arbitrary recovered path rejected',lambda:C.validate_native_recovery(actual,{**reference,'path':str(Q/'other.json')}),False)
    for name,path in [('bulk','architecture-c13-bulk-captures/state.json'),('shipping','architecture-c13-shipping-captures/state.json')]:
        state=C.load(Q/path)
        check('actual closed '+name+' finished/passed schema accepted',lambda name=name,state=state:C.validate_performance_state(name,state,data),True)
        changed=copy.deepcopy(state);changed['builds']['candidate' if name=='shipping' else 'batch']['source']['commit']='7c02eb387a6785d6e914146babe34f0902a6dd62'
        check(name+' wrong candidate source rejected',lambda name=name,changed=changed:C.validate_performance_state(name,changed,data),False)
        changed=copy.deepcopy(state);changed['passed']=False
        check(name+' unfinished/failed flag rejected',lambda name=name,changed=changed:C.validate_performance_state(name,changed,data),False)
    cpu=C.load(Q/'architecture-c13-callgrind-captures/state.json')
    if cpu['state']=='running':
        check('running CPU captures cannot qualify',lambda:C.validate_performance_state('cpu',cpu,data),False)
    original_gate=C.gate_manifest
    C.gate_manifest=lambda *args:(_ for _ in ()).throw(AssertionError('full gate must not run before build/preview'))
    assert C.readiness('ef6daae4144cbe3bb1696d5be8e06aef805cd8e6efa3b4989b5eb5bc94ec4342',full=False)['gates'] is None
    C.gate_manifest=original_gate
    rows.append({'case':'source/build readiness has no final workspace/performance gate dependency','expected_accept':True,'actual_accept':True})
    identity=C.process_identity(os.getpid());assert C.identity_matches(identity)
    check('real self PID identity accepted',lambda:assert_identity(identity),True)
    check('reused PID start rejected',lambda:assert_identity({**identity,'pid_start_ticks':identity['pid_start_ticks']+1}),False)
    check('changed boot rejected',lambda:assert_identity({**identity,'boot_id':'different'}),False)
    original={name:getattr(C,name) for name in ['boot_id','process_identity','clock']};mono=C.time.monotonic
    with tempfile.TemporaryDirectory(prefix='resource-c13-generation-controls-',dir=Q) as tmp:
        output=Path(tmp);namespace=os.readlink('/proc/self/ns/pid')
        gen={'id':'a'*32,'source_pin':C.SOURCE,'boot_id':'boot','pid_namespace':namespace,'utc':'2026-10-25T00:00:00+00:00','monotonic_seconds':10.0}
        supervisor={'pid':100,'pid_start_ticks':11,'boot_id':'boot','pid_namespace':namespace}
        worker={'pid':200,'pid_start_ticks':22,'boot_id':'boot','pid_namespace':namespace}
        launch={'source_pin':C.SOURCE,'generation':gen,'supervisor_identity':supervisor}
        state={'worker_identity':worker,'heartbeat':{'boot_id':'boot','monotonic_seconds':99.0}}
        process={100:supervisor,200:worker}
        C.boot_id=lambda:'boot';C.process_identity=lambda pid:process.get(pid);C.clock=lambda:{'boot_id':C.boot_id(),'monotonic_seconds':C.time.monotonic()};C.time.monotonic=lambda:100.0
        def sample(expected):assert C.health(output)['state']==expected
        write(output/'launch.json',launch);write(output/'supervisor-state.json',state)
        check('fresh matching worker and supervisor is running',lambda:sample('running'),True)
        process.pop(100);check('missing supervisor is interrupted',lambda:sample('interrupted'),True);process[100]=supervisor
        process[100]={**supervisor,'pid_start_ticks':12};check('reused supervisor PID is interrupted',lambda:sample('interrupted'),True);process[100]=supervisor
        process.pop(200);check('absent raw child is not running',lambda:sample('finalizing_or_interrupted'),True);process[200]=worker
        process[100]={'pid':100,'unavailable':'permission denied'};check('denied observation is unavailable, not interruption',lambda:sample('unavailable'),True);process[100]=supervisor
        C.boot_id=lambda:'other';check('boot replacement is interrupted',lambda:sample('interrupted'),True);C.boot_id=lambda:'boot'
        C.time.monotonic=lambda:9.0;check('monotonic reversal is interrupted',lambda:sample('interrupted'),True);C.time.monotonic=lambda:100.0
        changed=copy.deepcopy(launch);changed['generation']['pid_namespace']='other';write(output/'launch.json',changed)
        check('changed PID namespace is interrupted',lambda:sample('interrupted'),True);write(output/'launch.json',launch)
        write(output/'supervisor-state.json',{**state,'heartbeat':{'boot_id':'boot','monotonic_seconds':1.0}})
        check('stale running JSON is not live proof',lambda:sample('unavailable'),True);write(output/'supervisor-state.json',state)
        write(output/'launch.json',{**launch,'supervisor_identity':None});check('unrecorded bootstrap identity is unavailable',lambda:sample('unavailable'),True);write(output/'launch.json',launch)
        def safe(expected):assert C.reconciliation_safe(output) is expected
        check('reconcile refuses live supervisor/worker',lambda:safe(False),True)
        process.pop(100);check('reconcile refuses live orphan worker',lambda:safe(False),True)
        process.pop(200);check('reconcile permits absent original generation',lambda:safe(True),True)
        process[200]={'pid':200,'unavailable':'permission denied'}
        check('reconcile refuses unobservable child',lambda:safe(False),True)
        process[100]=supervisor;process[200]=worker
        C.boot_id=lambda:'other';check('new boot permits interruption record without resuming',lambda:safe(True),True);C.boot_id=lambda:'boot'
        write(output/'termination.json',{'generation':gen});C.boot_id=lambda:'other'
        check('closed terminal evidence stays terminal after later host replacement',lambda:sample('terminal'),True)
    C.time.monotonic=mono
    for name,value in original.items():setattr(C,name,value)
    for path in [Q/'architecture-c13-soak-common.py',Q/'architecture-c13-soaks.py']:
        ast.parse(path.read_text(),filename=str(path))
        child=subprocess.run([sys.executable,'-O',str(path)],capture_output=True,text=True)
        assert child.returncode!=0 and 'require enabled Python assertions' in child.stderr
        rows.append({'case':path.name+' rejects -O before actions','expected_accept':False,'actual_accept':False})
    result={'state':'passed','qualified':False,'synthetic_controls':True,'cases':rows,
            'actual_native_recovery_record_read_only_check':True,'actual_soak_or_compiler_or_preview_or_day_or_network_or_cleanup':False,
            'source_manifest_sha256':C.digest(C.PINS),'controller_sha256':C.digest(Q/'architecture-c13-soaks.py'),
            'common_sha256':C.digest(Q/'architecture-c13-soak-common.py'),'recipe_sha256':C.digest(Path(__file__))}
    C.exclusive(Q/'architecture-c13-soak-controls-v3.json',result)
    print(json.dumps({'state':'passed','bounded_controls':len(rows)}))
def assert_identity(value):assert C.identity_matches(value)
if __name__=='__main__':main()
