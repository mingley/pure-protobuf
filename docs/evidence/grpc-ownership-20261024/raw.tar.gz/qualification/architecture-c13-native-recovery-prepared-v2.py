#!/usr/bin/env python3
"""Recover terminal reports from completed native captures; never recapture."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import shutil
import subprocess

ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
CONTROLLER_SHA = 'c85be18cb641566a770dcb5e2b44c2aaf5ebf327f8a191acdd4f3b8d172ccb02'
SOURCES_SHA = 'd602b12ba41d8ea3ef777bb034694f7e68588405a1eb72950812c873ea65d63f'
PINS = {'scripts/grpc-load-smoke.py': '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b',
        'scripts/dominance-ledger.py': 'f55686bc130825f692224080765804893c48abf9875691462f9f019eb11d506c',
        'scripts/build-rpc-bench.py': '60d5c9e988a22181d9560060d7aa1445274155fc9c98ba5df31409aeebe2640f'}
COMMITS = {'baseline': '7c02eb387a6785d6e914146babe34f0902a6dd62',
           'safety': 'ca4ef720f8a90134334101e0106a8a68808fc19f',
           'batch': '933bf8775b70d24d91fb46a7992eae343b60f0ea'}
COUNTERS = ['offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
            'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs']


def digest(path):
    assert path.is_file() and not path.is_symlink(), f'not a regular file: {path}'
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1 << 20), b''):
            h.update(block)
    return h.hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def read(path):
    digest(path)
    return json.loads(path.read_text())


def save(path, value):
    with path.open('x') as stream:
        json.dump(value, stream, indent=2, allow_nan=False)
        stream.write('\n')


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def expected_commands(binary, tree, directory, cell, count, address):
    ct, cc, st, sc = cell['pair']
    server = [str(binary), 'load-server', '--port=0', f'--transport={st}', f'--codec={sc}',
              f"--compression={cell['compression']}"]
    client = [str(binary), 'load', f'--transport={ct}', f'--codec={cc}',
              f"--shape={cell['shape']}", f"--req-bytes={cell['payload_bytes']}",
              f"--resp-bytes={cell['payload_bytes']}", '--stream-msgs=4', '--connections=1',
              f"--max-in-flight={cell['in_flight']}", '--duration-secs=60',
              f"--compression={cell['compression']}", f'--output={directory / "metrics.json"}']
    if cell['tls']:
        data = tree / 'pbrs-grpc/tests/tls_data'
        server += [f'--tls-cert={data / "server.crt"}', f'--tls-key={data / "server.key"}']
        client += [f'--tls-ca={data / "ca.crt"}', '--tls-server-name=localhost']
    client += [f'--rpc-count={count}', f'--server_addr={address}']
    return {'server': server, 'client': client}


def validate_capture(path, cell, count, smoke, binary, tree):
    row = read(path / 'run.json')
    assert row['cell'] == cell and row['passed'] is True and 'error' not in row
    assert row['client_exit_code'] == 0 and row['server_exit_before_teardown'] is None
    assert row['environment'] == {'TOKIO_WORKER_THREADS': '2'}
    metrics = read(path / 'metrics.json')
    assert row['metrics'] == metrics and metrics['attempted_rpcs'] == count
    smoke.validate_metrics(metrics)
    assert all(metrics[k] == count for k in COUNTERS[:4])
    assert 'instruction_totals' not in row and 'syscall_totals' not in row
    for side in ['client', 'server']:
        assert smoke.allocation_record(path / f'{side}.stdout') == row['allocation_totals'][side]
        assert smoke.context_switch_record(path / f'{side}.stdout') == row['context_switch_totals'][side]
    ready = [line for line in (path / 'server.stdout').read_text().splitlines() if line.startswith('READY ')]
    assert len(ready) == 1
    address, = [word.split('=', 1)[1] for word in ready[0].split() if word.startswith('addr=')]
    assert row['commands'] == expected_commands(binary, tree, path, cell, count, address)
    return metrics, row['server_teardown_exit_code']


def recover(args):
    original = (Q / 'architecture-c13-native-captures').resolve()
    output = args.output.resolve()
    assert output.parent == Q and output != original and not output.exists()
    state = read(original / 'state.json')
    assert state['state'] == 'failed' and state['passed'] is False and state['phase'] == 'native'
    assert state['qualified'] is False and state['production_ready'] is False
    assert state['error'] == {'type': 'FileNotFoundError', 'message':
        "[Errno 2] No such file or directory: '/workspace/pure-protobuf/work/architecture-c13-safety/docs/plan/tasks.json'"}
    assert state['rpc_counts'] == [25, 50] and state['cells_per_source'] == 96 and state['expected_captures'] == 576
    assert state['controller_sha256'] == digest(original / 'controller.py') == digest(Q / 'architecture-c13-paired-counters.py') == CONTROLLER_SHA
    assert state['sources_sha256'] == digest(original / 'sources.json') == digest(Q / 'architecture-c13-counter-sources.json') == SOURCES_SHA
    receipt_path = Q / 'resource-c13-native-execution.json'
    receipt = read(receipt_path)
    assert receipt['exit_code'] == 1 and not receipt.get('timeout') and receipt['cwd'] == str(ROOT)
    assert receipt['command'] == ['python3', 'work/qualification/architecture-c13-paired-counters.py',
        '--sources', 'work/qualification/architecture-c13-counter-sources.json', '--output',
        'work/qualification/architecture-c13-native-captures', '--phase', 'native']
    material_path = Q / 'architecture-c13-ledger-plan-materialization.json'
    material = read(material_path)
    sources = read(original / 'sources.json')
    assert list(sources) == list(COMMITS)
    controller = module('c13_recovery_controller', original / 'controller.py')
    cells = controller.workloads('native')
    assert len(cells) == 96 and len({json.dumps(c, sort_keys=True) for c in cells}) == 96
    order = list(range(0, len(cells), 2)); random.Random(20261024).shuffle(order)
    completed = []
    for first in order:
        for index in [first, first + 1]:
            names = list(sources) if cells[index]['repeat'] == 0 else list(reversed(sources))
            for name in names:
                for count in ([25, 50] if cells[index]['repeat'] == 0 else [50, 25]):
                    completed.append({'source': name, 'count': count, 'cell': index, 'passed': True})
    assert state['completed'] == completed
    inputs = [ref(p) for p in original.rglob('*') if p.is_file()]
    assert not any(p.is_symlink() for p in original.rglob('*'))
    inputs += [ref(receipt_path), ref(receipt_path.with_suffix('.stdout')),
               ref(receipt_path.with_suffix('.stderr')), ref(material_path)]
    contexts = {}; settings = set(); totals = {}; teardown = {}
    for name, source in sources.items():
        assert source['source'] == COMMITS[name]
        tree = Path(source['checkout']).resolve(); binary = Path(source['binary']).resolve()
        for relative, expected in PINS.items():
            assert digest(tree / relative) == expected
        smoke = module(f'c13_recovery_smoke_{name}', tree / 'scripts/grpc-load-smoke.py')
        ledger = module(f'c13_recovery_ledger_{name}', tree / 'scripts/dominance-ledger.py')
        build = smoke.verified_build(Path(source['build_record']), binary, tree)
        assert build['source']['commit'] == COMMITS[name] and state['builds'][name] == build
        contexts[name] = (tree, binary, source, build, smoke, ledger)
        totals[name] = dict.fromkeys(COUNTERS, 0)
        for count in [25, 50]:
            directory = original / name / f'n-{count}'
            manifest = read(directory / 'manifest.json')
            assert manifest['schema'] == 'pbrs.load-smoke.v2' and manifest['cells'] == cells
            assert manifest['rpc_count'] == count and manifest['duration_per_cell_seconds'] == 60 and manifest['seed'] == 20261024
            assert manifest['head'] == COMMITS[name] and manifest['dirty'] is False and manifest['source_verified'] is True
            assert manifest['binary_sha256'] == build['binary_sha256'] and manifest['build_record'] == build
            assert manifest['harness_script_sha256'] == digest(directory / 'harness.py') == PINS['scripts/grpc-load-smoke.py']
            assert manifest['allocation_counts'] is True and manifest['context_switches'] is True
            assert manifest['callgrind'] is None and manifest['strace'] is None and manifest['qualification']['qualified'] is False
            settings.add(json.dumps({k: manifest[k] for k in ['host', 'cpu_affinity']}, sort_keys=True))
            assert {p.name for p in directory.glob('cell-*')} == {f'cell-{i:03d}' for i in range(96)}
            for i, cell in enumerate(cells):
                metrics, code = validate_capture(directory / f'cell-{i:03d}', cell, count, smoke, binary, tree)
                for key in COUNTERS: totals[name][key] += metrics[key]
                teardown[str(code)] = teardown.get(str(code), 0) + 1
        inputs += [ref(binary), ref(Path(source['build_record']))]
    assert len(settings) == 1
    assert len({json.dumps(c[3]['tools'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c[3]['source']['locks'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c[3]['command']) for c in contexts.values()}) == 1
    assert {r['label'] for r in material['checkouts']} == {'safety', 'batch'}
    for row in material['checkouts']:
        name = row['label']; assert name in ['safety', 'batch'] and row['source'] == COMMITS[name] and row['tracked_source_clean'] is True
        tree = contexts[name][0]
        assert {i['path'] for i in row['materialized']} == {'docs/plan/tasks.json', 'docs/plan/world-class/tasks.json'}
        for item in row['materialized']:
            assert item['path'] in ['docs/plan/tasks.json', 'docs/plan/world-class/tasks.json']
            actual = ref(tree / item['path']); assert actual['bytes'] == item['bytes'] and actual['sha256'] == item['sha256']
            committed = subprocess.check_output(['git', 'show', f"{COMMITS[name]}:{item['path']}"], cwd=tree)
            assert hashlib.sha256(committed).hexdigest() == actual['sha256']
    assert all(all(v[k] == 7200 for k in COUNTERS[:4]) and all(v[k] == 0 for k in COUNTERS[4:]) for v in totals.values())
    output.mkdir()
    for name in ['controller.py', 'sources.json']:
        shutil.copyfile(original / name, output / name)
    shutil.copyfile(original / 'state.json', output / 'original-controller-state.json')
    for suffix in ['.json', '.stdout', '.stderr']:
        shutil.copyfile(receipt_path.with_suffix(suffix), output / ('original-execution' + suffix))
    shutil.copyfile(material_path, output / 'plan-materialization.json')
    reports = []
    for name, (tree, binary, source, build, smoke, ledger) in contexts.items():
        for count in [25, 50]:
            old = original / name / f'n-{count}'; new = output / name / f'n-{count}'; new.mkdir(parents=True)
            for filename in ['manifest.json', 'harness.py']: shutil.copyfile(old / filename, new / filename)
            for i in range(96): shutil.copytree(old / f'cell-{i:03d}', new / f'cell-{i:03d}', copy_function=os.link)
            report = read(old / 'manifest.json')
            report.update(runs=[{'path': f'cell-{i:03d}/run.json', 'passed': True} for i in range(96)],
                binary_unchanged=True, source_unchanged=True, harness_script_unchanged=True, passed=True)
            if (old / 'report.json').exists():
                assert read(old / 'report.json') == report
                shutil.copyfile(old / 'report.json', new / 'report.json'); disposition = 'preserved_existing_bytes'
            else:
                save(new / 'report.json', report); disposition = 'reconstructed_missing_terminal_report'
            reports.append({'path': str(new / 'report.json'), 'disposition': disposition})
        comparison = ledger.compare(output / name / 'n-25', output / name / 'n-50')
        if (original / name / 'ledger.json').exists():
            previous = read(original / name / 'ledger.json'); previous['capture_paths'] = comparison['capture_paths']; assert previous == comparison
        save(output / name / 'ledger.json', comparison)
        assert smoke.verified_build(Path(source['build_record']), binary, tree) == build
    assert all(ref(Path(r['path'])) == r for r in inputs), 'original input changed during recovery'
    result = {'schema': 'pbrs.c13-native-postprocess-recovery.v1', 'state': 'recovered', 'passed': True,
        'phase': 'native', 'qualified': False, 'production_ready': False, 'recovery_kind': 'postprocessing_only',
        'original_controller_passed': False, 'original_controller_exit_code': 1,
        'original_controller_state': ref(original / 'state.json'), 'original_execution': ref(receipt_path),
        'original_root': str(original), 'actual_captures': len(completed), 'actual_rpc_totals': totals,
        'actual_successful_rpcs': sum(v['successful_rpcs'] for v in totals.values()), 'server_teardown_codes': teardown,
        'raw_capture_passed': True, 'postprocessing_passed': True, 'source_commits': COMMITS,
        'controller_sha256': CONTROLLER_SHA, 'sources_sha256': SOURCES_SHA, 'inputs': inputs,
        'reports': reports, 'recovery_helper': ref(Path(__file__).resolve()),
        'limits': ['No new captures. Original failed controller and every original artifact are unchanged.',
                   'Hardlinked cell artifacts are immutable inputs; never rewrite either link.',
                   'Shared-host allocation diagnostics; no shipping speed or production qualification.']}
    save(output / 'state.json', result)
    print(json.dumps({k: result[k] for k in ['schema', 'state', 'actual_captures', 'actual_successful_rpcs', 'original_controller_passed', 'qualified']}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--output', type=Path, default=Q / 'architecture-c13-native-recovered')
    args = parser.parse_args()
    if not __debug__ or not args.execute: parser.error('ordinary Python and explicit --execute are required')
    recover(args)


if __name__ == '__main__':
    main()
