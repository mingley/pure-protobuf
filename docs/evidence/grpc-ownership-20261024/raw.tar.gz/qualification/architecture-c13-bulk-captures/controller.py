#!/usr/bin/env python3
"""Separate two-source bulk controls with explicit streaming message counts.

Prepared only unless --execute is supplied under a separate root grant. Every
message count has independent N/2N reports and ledgers: the unchanged ledger's
cell key does not contain stream_messages. This is not the canonical four-message
campaign and does not produce shipping CPU, latency or throughput qualification.
"""
import argparse
import datetime
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import re
import shutil
from types import SimpleNamespace

Q = Path('/workspace/pure-protobuf/work/qualification')
ADAPTER = Q / 'architecture-c12c-single-ready-smoke.py'
ADAPTER_SHA = '7193ef16bc7564d8c15c3da9a08afc97afbcff2a9aa8322db2ff243c96d47430'
SOURCE_HARNESS_SHA = '804880a6541cf3aee7dbdd15b3adf8ceb32bc4c79c3ffd3e536a006426109d8b'
MESSAGE_COUNTS = (1, 2, 3, 4, 64)
RPC_COUNTS = (25, 50)
VERSIONS = ('safety', 'batch')
ACCOUNTING = ('offered_rpcs', 'dispatched_rpcs', 'completed_rpcs', 'successful_rpcs',
              'failed_rpcs', 'timeouts', 'queue_overflows', 'unstarted_rpcs', 'unfinished_rpcs')
BATCH_FILES = {'pbrs-grpc/src/wire/encode.rs', 'pbrs-grpc/src/wire/out_batch.rs',
               'pbrs-grpc/src/client/streaming.rs', 'pbrs-grpc/src/server/drain.rs',
               'pbrs-grpc/src/wire/send.rs'}


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def save(path, value):
    temporary = path.with_name(path.name + '.next')
    with temporary.open('x') as out:
        json.dump(value, out, indent=2)
        out.write('\n')
    temporary.replace(path)


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def cells_for(messages):
    pairs = [('native', 'prost', 'tonic', 'prost'),
             ('tonic', 'prost', 'native', 'prost'),
             ('tonic', 'prost', 'tonic', 'prost')]
    return [dict(pair=list(pair), shape=shape, payload_bytes=1024, tls=False,
                 compression='identity', connections=1, in_flight=1,
                 stream_messages=messages, repeat=repeat)
            for shape, pair, repeat in itertools.product(
                ('bidi', 'bidi_pipelined'), pairs, range(2))]


def verify_adapter(original):
    assert digest(ADAPTER) == ADAPTER_SHA
    assert digest(original) == SOURCE_HARNESS_SHA
    text = original.read_text()
    before = '"--stream-msgs=4", f"--connections={cell.get(\'connections\', 1)}",'
    after = 'f"--stream-msgs={cell[\'stream_messages\']}", f"--connections={cell.get(\'connections\', 1)}",'
    assert text.count(before) == 1
    assert text.replace(before, after, 1) == ADAPTER.read_text()


def execute(args):
    import subprocess
    assert os.environ.get('PYTHONOPTIMIZE') == '0', 'explicit ordinary PYTHONOPTIMIZE=0 required'
    config = args.sources.resolve(strict=True)
    config_ref = ref(config)
    sources = json.loads(config.read_text())
    assert set(sources) == set(VERSIONS), 'sources must contain exactly safety and batch'
    assert all(re.fullmatch(r'[0-9a-f]{40}', sources[name]['source']) for name in VERSIONS)
    assert len({sources[name]['source'] for name in VERSIONS}) == 2
    controller = Path(__file__).resolve()
    controller_ref = ref(controller)
    smoke = module('single_ready_bulk_smoke', ADAPTER)
    contexts = {}
    for index, name in enumerate(VERSIONS):
        row = sources[name]
        tree = Path(row['checkout']).resolve(strict=True)
        binary = Path(row['binary']).resolve(strict=True)
        record = Path(row['build_record']).resolve(strict=True)
        verify_adapter(tree / 'scripts/grpc-load-smoke.py')
        ledger_path = tree / 'scripts/dominance-ledger.py'
        ledger = module('single_ready_bulk_ledger_' + str(index), ledger_path)
        build = smoke.verified_build(record, binary, tree)
        assert build['source']['commit'] == row['source']
        assert all('1.99.1' in version for version in build['tools'].values())
        contexts[name] = dict(tree=tree, binary=binary, record=record, build=build,
                              ledger=ledger, ledger_ref=ref(ledger_path), record_ref=ref(record))
    assert len({json.dumps(c['build']['tools'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c['build']['source']['locks'], sort_keys=True) for c in contexts.values()}) == 1
    assert len({json.dumps(c['build']['command']) for c in contexts.values()}) == 1
    assert len({c['ledger_ref']['sha256'] for c in contexts.values()}) == 1
    changed = subprocess.check_output(
        ['git', 'diff', '--name-only', sources['safety']['source'], sources['batch']['source']],
        cwd=contexts['batch']['tree'], text=True).splitlines()
    assert set(changed) == BATCH_FILES, 'batch attribution requires only the reviewed five-file change'
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(controller, output / 'controller.py')
    shutil.copy2(ADAPTER, output / 'capture-adapter.py')
    shutil.copy2(config, output / 'sources.json')
    state_path = output / 'state.json'
    state = dict(schema='pbrs.single-ready-bulk-counters.v1', qualified=False,
                 production_ready=False, state='running', started_utc=now(), phase='native',
                 controller=controller_ref, adapter=ref(ADAPTER), sources_input=config_ref,
                 source_harness_sha256=SOURCE_HARNESS_SHA,
                 streaming_message_counts=MESSAGE_COUNTS, rpc_counts=RPC_COUNTS,
                 expected_captures=240, expected_successful_rpcs=9000,
                 builds={name: c['build'] for name, c in contexts.items()}, completed=[],
                 actual_rpc_totals={name: {key: 0 for key in ACCOUNTING} for name in VERSIONS},
                 limits=['Separate adapter control; not canonical four-message evidence.',
                         'One message count per report/ledger namespace; no mixed-count ledger keys.',
                         'Shared-host cumulative allocation requests, not retained memory or shipping speed.',
                         'Fixed1KiB zero-filled application payload; two repeats are not independent host statistics.',
                         'Bidi/pipeline with64 total messages does not prove64 simultaneously ready messages; queue16/scheduling remain unchanged.',
                         'Direct prospective unit tests cover ready-count capacity traces; RPC controls cover API workloads.'])
    save(state_path, state)
    reports = {}

    def verify_context(name):
        context = contexts[name]
        assert ref(config) == config_ref and ref(controller) == controller_ref
        verify_adapter(context['tree'] / 'scripts/grpc-load-smoke.py')
        assert ref(context['record']) == context['record_ref']
        assert ref(Path(context['ledger_ref']['path'])) == context['ledger_ref']
        assert smoke.verified_build(context['record'], context['binary'], context['tree']) == context['build']

    try:
        for messages in MESSAGE_COUNTS:
            partition = output / ('stream-messages-' + str(messages))
            cells = cells_for(messages)
            assert len(cells) == 12 and all(cell['stream_messages'] == messages for cell in cells)
            for name in VERSIONS:
                context = contexts[name]
                for count in RPC_COUNTS:
                    directory = partition / name / ('n-' + str(count))
                    directory.mkdir(parents=True)
                    report = dict(schema='pbrs.load-smoke.v2', binary_sha256=context['build']['binary_sha256'],
                                  harness_script_sha256=ADAPTER_SHA, source_harness_sha256=SOURCE_HARNESS_SHA,
                                  capture_adapter=ref(ADAPTER), stream_messages=messages,
                                  head=context['build']['source']['commit'], dirty=False, source_verified=True,
                                  build_record=context['build'], host=platform.uname()._asdict(),
                                  cpu_affinity=sorted(os.sched_getaffinity(0)), seed=20261024,
                                  cells=cells, rpc_count=count, duration_per_cell_seconds=60,
                                  allocation_counts=True, context_switches=True, callgrind=None,
                                  strace=None, strace_version=None, qualification={'qualified': False}, runs=[])
                    reports[(messages, name, count)] = report
                    save(directory / 'manifest.json', report)
                    shutil.copy2(ADAPTER, directory / 'harness.py')
            scopes = list(range(0, len(cells), 2))
            random.Random(20261024 + messages).shuffle(scopes)
            for first in scopes:
                for index in (first, first + 1):
                    cell = cells[index]
                    names = VERSIONS if cell['repeat'] == 0 else tuple(reversed(VERSIONS))
                    counts = RPC_COUNTS if cell['repeat'] == 0 else tuple(reversed(RPC_COUNTS))
                    for name in names:
                        context = contexts[name]
                        for count in counts:
                            verify_context(name)
                            directory = partition / name / ('n-' + str(count))
                            child = directory / ('cell-' + str(index).zfill(3))
                            settings = SimpleNamespace(binary=context['binary'], source_checkout=context['tree'],
                                                       duration=60, rpc_count=count, allocation_counts=True,
                                                       context_switches=True, callgrind=None, strace=None)
                            result = smoke.run_cell(settings, cell, child)
                            state['completed'].append(dict(stream_messages=messages, source=name,
                                                            count=count, cell=index, path=str(child / 'run.json'),
                                                            passed=result['passed']))
                            for key in ACCOUNTING:
                                value = result.get('metrics', {}).get(key)
                                if type(value) is int and value >= 0:
                                    state['actual_rpc_totals'][name][key] += value
                            report = reports[(messages, name, count)]
                            report['runs'].append(dict(path=child.name + '/run.json', passed=result['passed']))
                            save(directory / 'partial-report.json', report)
                            save(state_path, state)
                            verify_context(name)
                            assert result['cell'] == cell
                            command = result['commands']['client']
                            assert [part for part in command if part.startswith('--stream-msgs=')] == [
                                '--stream-msgs=' + str(messages)]
                            if not result['passed']:
                                raise RuntimeError('failed capture retained: ' + str(child))
            for name in VERSIONS:
                verify_context(name)
                for count in RPC_COUNTS:
                    report = reports[(messages, name, count)]
                    assert len(report['runs']) == len(cells) and all(run['passed'] for run in report['runs'])
                    report.update(binary_unchanged=True, source_unchanged=True,
                                  harness_script_unchanged=True, passed=True)
                    directory = partition / name / ('n-' + str(count))
                    save(directory / 'report.json', report)
                comparison = contexts[name]['ledger'].compare(partition / name / 'n-25', partition / name / 'n-50')
                assert all(row['cell']['stream_messages'] == messages for row in comparison['rows'])
                save(partition / name / 'ledger.json', comparison)
        assert len(state['completed']) == state['expected_captures']
        for name in VERSIONS:
            verify_context(name)
            totals = state['actual_rpc_totals'][name]
            assert all(totals[key] == 4500 for key in ACCOUNTING[:4]), totals
            assert all(totals[key] == 0 for key in ACCOUNTING[4:]), totals
        state.update(state='finished', passed=True, completed_utc=now())
        save(state_path, state)
    except BaseException as error:
        state.update(state='failed', passed=False, completed_utc=now(),
                     error={'type': type(error).__name__, 'message': str(error)})
        save(state_path, state)
        raise


def main():
    if not __debug__:
        raise RuntimeError('ordinary Python without -O required')
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--sources', type=Path)
    parser.add_argument('--output', type=Path)
    parser.add_argument('--execute', action='store_true')
    args = parser.parse_args()
    if not args.execute:
        print(json.dumps({'state': 'prepared_not_run', 'qualified': False,
                          'sources': VERSIONS, 'streaming_message_counts': MESSAGE_COUNTS,
                          'scopes': 30, 'repeats': 2, 'rpc_counts': RPC_COUNTS,
                          'captures': 240, 'successful_rpcs': 9000,
                          'each_partition': {'scopes': 6, 'captures': 48, 'successful_rpcs': 1800}}, indent=2))
        return
    assert args.sources is not None and args.output is not None
    execute(args)


if __name__ == '__main__':
    main()
