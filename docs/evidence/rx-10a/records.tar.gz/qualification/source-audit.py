#!/usr/bin/env python3
"""Default-path/frozen-control structural audit, without Cargo or compilers."""
import json, pathlib, re, subprocess

ROOT = pathlib.Path(__file__).resolve().parents[2]
BASE = '10bee600737b8a207159e63581bebc01b07ec2d7'
BEFORE = '1308bd98e032b8b4c70e3599bb03f1bac1c253e9'
AFTER = 'f2638b90be0f7bf510df1fe40f82581aa92f2b9c'
def source(head, path):
    return subprocess.check_output(['git', 'show', f'{head}:{path}'], cwd=ROOT)

sites = ['pbrs-grpc/src/server/connection.rs', 'pbrs-grpc/src/client/pool.rs',
         'pbrs-grpc/src/client/streaming.rs', 'pbrs-grpc/src/wire/send.rs']
for path in sites:
    after = source(AFTER, path)
    stripped, removed = re.subn(rb'[ \t]*#\[cfg\(feature = "copy-counts"\)\]\n[ \t]*crate::copy_counts::note_spawn\(crate::copy_counts::SpawnSite::[A-Za-z]+\);\n', b'', after)
    assert removed == 1 and stripped == source(BASE, path), path
    assert source(BEFORE, path) == source(BASE, path), path
lib = source(AFTER, 'pbrs-grpc/src/lib.rs')
extra = b'#[cfg(feature = "copy-counts")]\npub use copy_counts::{SchedulerCounts, reset_scheduler_counts, scheduler_counts};\n'
assert lib.count(extra) == 1 and lib.replace(extra, b'') == source(BASE, 'pbrs-grpc/src/lib.rs')
marker = b'/// Snapshot of the process-wide copy counters.'
assert source(AFTER, 'pbrs-grpc/src/copy_counts.rs').split(marker, 1)[1] == source(BASE, 'pbrs-grpc/src/copy_counts.rs').split(marker, 1)[1]
main = source(AFTER, 'bench/devloop/src/main.rs')
assert main == source(BEFORE, 'bench/devloop/src/main.rs')
main = main.replace(b'mod scheduler_rpc;\n', b'').replace(b'        "scheduler-check" => scheduler_rpc::run(),\n', b'')
main = main.replace(b'     \\x20 devloop sizes\\n\\\n     \\x20 devloop scheduler-check\\n"', b'     \\x20 devloop sizes\\n"')
assert main == source(BASE, 'bench/devloop/src/main.rs'), 'Original control/worker/helper/comparator source changed'
changed = subprocess.check_output(['git', 'diff', '--name-only', BASE, AFTER], cwd=ROOT, text=True).splitlines()
assert not any(p.endswith('Cargo.toml') or p.endswith('Cargo.lock') for p in changed)
fixture_a = source(BEFORE, 'bench/devloop/src/scheduler_rpc.rs')
fixture_b = source(AFTER, 'bench/devloop/src/scheduler_rpc.rs')
for fixture in [fixture_a, fixture_b]:
    assert b'timeout(BOUND, Channel::from_io' in fixture
    assert b'timeout(BOUND, exercise(&channel, &state, shape, "echo"))' in fixture
print(json.dumps({'status': 'pass', 'baseline': BEFORE, 'candidate': AFTER,
                  'runtime_spawn_files_recovered_exactly': sites,
                  'existing_CopyCounts_and_all_note_paths_unchanged': True,
                  'original20_main_source_recovered_exactly': True,
                  'manifests_or_locks_changed': False,
                  'feature_off_symbol_audit': 'not_run',
                  'compiler_or_runtime_launched': False}, indent=2))
