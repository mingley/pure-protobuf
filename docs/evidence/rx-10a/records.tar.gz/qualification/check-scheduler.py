#!/usr/bin/env python3
"""Independent fixed RPC-input/event oracle; no timing, no original20 controls."""
import argparse,hashlib,json,pathlib
parser=argparse.ArgumentParser(); parser.add_argument('--baseline',type=pathlib.Path,required=True); parser.add_argument('--candidate',type=pathlib.Path,required=True); parser.add_argument('--out',type=pathlib.Path,required=True); args=parser.parse_args()
assert not args.out.exists(),'never overwrite independent result'
# Inputs are one alpha unary request; alpha/beta completed uploads; one alpha
# held upload for cancellation/early terminal. Streaming replies echo accepted
# requests plus the explicit beta second server response in the fixture.
oracle=[('unary','echo',1,1,0),('unary','terminal',1,0,0),('unary','cancel',1,0,0),
 ('server_stream','echo',1,2,1),('server_stream','terminal',1,1,1),('server_stream','cancel',1,1,1),
 ('client_stream','echo',2,1,0),('client_stream','terminal',2,0,0),('client_stream','cancel',1,0,0),('client_stream','early',1,1,0),
 ('bidi','echo',2,2,1),('bidi','terminal',1,1,1),('bidi','cancel',1,1,1),('bidi','early',1,1,1)]
keys=['client_connection_driver','client_bidi_upload','client_server_stream_cancel','server_rpc_dispatch']
inputs={}
for name,path in [('baseline',args.baseline),('candidate',args.candidate)]:
 data=path.read_bytes(); o=json.loads(data); inputs[name]={'path':str(path.resolve()),'sha256':hashlib.sha256(data).hexdigest()}
 assert o['schema']=='scheduler-spawns/1' and o['transport']=='duplex' and o['runtime']=='current_thread'
 assert o['warmup_calls']==4 and o['quiescent_alive_tasks']==0 and o['setup']['harness_connection_tasks']==1
 assert len(o['rows'])==len(oracle)
 for row,(shape,mode,bodies,replies,producers) in zip(o['rows'],oracle):
  assert (row['shape'],row['mode'])==(shape,mode)
  assert (row['body_messages'],row['reply_messages'],row['application_producer_spawns'])==(bodies,replies,producers)
  assert row['terminal']=={'terminal':'FAILED_PRECONDITION','cancel':'CANCELLED'}.get(mode,'OK')
  assert row['rpc_and_producer_completion_acknowledged'] is True and row['steady_alive_tasks']==2
  counts=row['library_spawns']
  if name=='baseline': assert counts['status']=='not_run'
  else:
   assert counts['status']=='measured'
   assert [counts[k] for k in keys]==[0,int(shape=='bidi'),int(shape=='server_stream'),1]
 setup=o['setup']['library_spawns']
 if name=='baseline': assert setup['status']=='not_run'
 else: assert setup['status']=='measured' and [setup[k] for k in keys]==[1,0,0,0]
 for missing in ['wakeups','channel_sends','cross_thread_handoffs','context_switches','instruction_attribution']:
  assert o[missing]['status']=='not_run'
report={'status':'pass','fixed_cases_per_binary':len(oracle),'inputs':inputs,'oracle':oracle,'semantics':'spawn expression invocation attempts; setup driver separated, warmups excluded, application producers separately counted','unmeasured':['wakeups','channel_sends','cross_thread_handoffs','context_switches','instructions','performance','parent_RX10_budget'],'checker_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
args.out.write_text(json.dumps(report,indent=2)+'\n'); print(json.dumps(report,indent=2))
