#!/usr/bin/env python3
"""Select an exact current-manifest Cargo artifact; never guess target paths."""
import argparse, hashlib, json, pathlib, shutil

parser = argparse.ArgumentParser()
parser.add_argument('--stream', type=pathlib.Path, required=True)
parser.add_argument('--manifest', type=pathlib.Path, required=True)
parser.add_argument('--name', required=True)
parser.add_argument('--kind', choices=['executable', 'rlib'], required=True)
parser.add_argument('--copy', type=pathlib.Path, required=True)
args = parser.parse_args()
selected = []
for line in args.stream.read_text().splitlines():
    try:
        item = json.loads(line)
    except json.JSONDecodeError:
        continue
    if item.get('reason') != 'compiler-artifact' or item['target']['name'] != args.name:
        continue
    if pathlib.Path(item['manifest_path']).resolve() != args.manifest.resolve():
        continue
    if args.kind == 'executable':
        paths = [item['executable']] if item.get('executable') else []
    else:
        paths = [p for p in item['filenames'] if p.endswith('.rlib')]
    selected += [(pathlib.Path(p), item) for p in paths]
assert len(selected) == 1, [(str(p), row['target']) for p, row in selected]
source, item = selected[0]
assert not args.copy.exists(), 'Never overwrite an immutable launch artifact'
digest = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
before = digest(source)
args.copy.parent.mkdir(parents=True, exist_ok=True)
shutil.copyfile(source, args.copy)
args.copy.chmod(0o755 if args.kind == 'executable' else 0o644)
assert digest(source) == digest(args.copy) == before
record = {'cargo_stream': str(args.stream.resolve()), 'stream_sha256': digest(args.stream),
          'source_path': str(source.resolve()), 'immutable_path': str(args.copy.resolve()),
          'sha256': before, 'bytes': source.stat().st_size, 'compiler_artifact': item}
args.copy.with_suffix(args.copy.suffix + '.selection.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
