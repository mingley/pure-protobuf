#!/usr/bin/env python3
"""Separate pre/post pinned-protobuf source guard; no claim of full C/Rust closure."""
import argparse,hashlib,json,os,pathlib,re,subprocess
PIN='35cd01f9fe9afbeea38cc7b979a3b6bfcde82c03'
UP=pathlib.Path('/workspace/pure-protobuf/third_party/protobuf')
WTS=[pathlib.Path('/workspace/scratch/work/rx10-baseline'),pathlib.Path('/workspace/scratch/work/rx10')]
BASE=pathlib.Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
parser=argparse.ArgumentParser(); parser.add_argument('--label',required=True); parser.add_argument('--phase',choices=['before','after'],required=True); args=parser.parse_args()
assert args.label.isidentifier()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=UP,text=True).strip()
status=subprocess.check_output(['git','status','--porcelain'],cwd=UP,text=True)
assert head==PIN and not status,(head,status)
links={}
for wt in WTS:
 p=wt/'third_party/protobuf'
 assert p.is_symlink() and p.resolve()==UP
 links[str(p)]={'text':os.readlink(p),'resolved':str(p.resolve())}
proto_paths=[os.fsdecode(p) for p in subprocess.check_output(['git','ls-files','-z','--','*.proto'],cwd=UP).split(b'\0') if p]
all_proto={p:sha(UP/p) for p in proto_paths}
# Exact direct protoc args of v4_tat/build.rs and prost_tat/build.rs. Build script
# bytes are pinned in each normal capture; transitively imported WKTs are explicit.
direct=['google/protobuf/test_messages_proto3.proto','google/protobuf/any.proto','google/protobuf/duration.proto','google/protobuf/timestamp.proto','google/protobuf/wrappers.proto','google/protobuf/struct.proto','google/protobuf/field_mask.proto','google/protobuf/empty.proto']
closure={}; pending=list(direct)
while pending:
 name=pending.pop()
 if name in closure: continue
 p=UP/'src'/name
 text=p.read_text()
 imports=re.findall(r'^\s*import\s+(?:(?:public|weak)\s+)?"([^"]+)"\s*;',text,re.M)
 closure[name]={'sha256':sha(p),'imports':imports}
 pending.extend(imports)
record={'provider':'pinned protobuf source, additional upstream input guard','root':str(UP),'head':head,'status':status,'links':links,'tracked_proto_hashes':all_proto,'tat_direct_protoc_inputs':direct,'tat_transitive_proto_imports':closure,'scope_limit':'All tracked upstream .proto bytes guarded. TAT direct/transitive imports explicit; ordinary snapshots separately guard local build.rs/protos. This is not a full C/Rust compiler/dependency-header closure claim.','helper_sha256':sha(pathlib.Path(__file__))}
out=BASE/'records'; out.mkdir(exist_ok=True)
p=out/(args.label+'.upstream-'+args.phase+'.json'); assert not p.exists(),'never overwrite first observation'
p.write_text(json.dumps(record,indent=2)+'\n')
unchanged=None
if args.phase=='after':
 before=json.loads((out/(args.label+'.upstream-before.json')).read_text())
 unchanged=before==record
 assert unchanged,'upstream source/link/proto drift'
print(json.dumps({'record':str(p),'sha256':sha(p),'head':head,'tracked_proto_count':len(all_proto),'tat_import_count':len(closure),'pre_post_unchanged':unchanged}))
