#!/usr/bin/env python3
"""Work-only helper tests: Python children, synthetic resources; no compiler probes."""
import datetime
import importlib.util
import json
import os
import pathlib
import signal
import sys
import threading
import unittest
from unittest import mock

HERE = pathlib.Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('rx10_capture', HERE / 'capture.py')
cap = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cap)
OUT = HERE / 'helper-tests' / datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
OUT.mkdir(parents=True)


def good(size=0, free=cap.CAP + 4096):
    return {'owned_cache_bytes': {'fake-cache': size}, 'owned_total': size,
            'global_free': free, 'owned_limit': cap.CAP, 'global_reserve': cap.CAP,
            'vanished_snapshot_paths': []}


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.root = OUT / self._testMethodName
        self.root.mkdir()
        self.prefix = self.root / 'capture'

    def run_child(self, code, sampler=lambda: good(), bound=.4, interval=.03):
        result = cap.run_guarded([sys.executable, '-c', code], self.root, os.environ.copy(),
                                 self.prefix, bound, sampler, interval)
        self.assertEqual(json.loads(self.prefix.with_suffix('.process.json').read_text()), result)
        if result.get('process_launched'):
            self.assertEqual(cap.live_group(result['pgid']), [])
        return result

    def test_success_raw_and_samples(self):
        result = self.run_child("import sys; print('out'); print('err', file=sys.stderr)")
        self.assertEqual(result['exit'], 0)
        self.assertEqual(result['raw_process_exit'], 0)
        self.assertEqual(self.prefix.with_suffix('.stdout.log').read_text(), 'out\n')
        self.assertEqual(self.prefix.with_suffix('.stderr.log').read_text(), 'err\n')
        self.assertGreaterEqual(result['resource_sample_count'], 2)

    def test_child_failure_is_not_hidden(self):
        result = self.run_child("raise SystemExit(7)")
        self.assertEqual(result['exit'], 7)
        self.assertEqual(result['raw_process_exit'], 7)

    def test_periodic_samples_and_observed_extrema(self):
        number = 0
        def sampler():
            nonlocal number
            number += 1
            return good(number, cap.CAP + 1000 - number)
        result = self.run_child('import time; time.sleep(.14)', sampler, bound=1)
        samples = [json.loads(line) for line in self.prefix.with_suffix('.resources.jsonl').read_text().splitlines()]
        self.assertGreaterEqual(len(samples), 4)
        self.assertEqual(result['observed_max_owned_total'], max(s['owned_total'] for s in samples))
        self.assertEqual(result['observed_min_global_free'], min(s['global_free'] for s in samples))
        self.assertEqual(result['resource_sample_count'], len(samples))
        self.assertIn('periodic', result['resource_observation_limit'])

    def test_timeout_stops_owned_descendants(self):
        result = self.run_child("import os,time; os.fork(); print(os.getpid(), flush=True); time.sleep(60)", bound=.12)
        self.assertEqual(result['exit'], 124)
        self.assertLess(result['raw_process_exit'], 0)
        self.assertIn('SIGTERM', result['cleanup']['signals'])
        self.assertEqual(result['cleanup']['live_after_cleanup'], [])

    def test_sampler_error_cleans_owned_group(self):
        calls = 0
        def sampler():
            nonlocal calls
            calls += 1
            if calls == 2:
                raise PermissionError('fake sampler failure')
            return good()
        result = self.run_child('import os,time; os.fork(); time.sleep(60)', sampler)
        self.assertEqual(result['exit'], 126)
        self.assertIn('PermissionError', result['helper_error'])
        self.assertIn('fake sampler failure', result['traceback'])
        self.assertEqual(result['resource_sample_count'], 2)

    def test_actual_sigint_cleans_owned_group(self):
        timer = threading.Timer(.08, lambda: os.kill(os.getpid(), signal.SIGINT))
        timer.start()
        try:
            result = self.run_child('import os,time; os.fork(); time.sleep(60)', bound=1)
        finally:
            timer.cancel()
            timer.join()
        self.assertEqual(result['exit'], 130)
        self.assertIn('KeyboardInterrupt', result['helper_error'])
        self.assertEqual(result['cleanup']['live_after_cleanup'], [])

    def test_prelaunch_resource_breach_no_child(self):
        result = self.run_child('raise AssertionError("must not launch")', lambda: good(cap.CAP + 1))
        self.assertFalse(result['process_launched'])
        self.assertEqual(result['exit'], 125)
        self.assertIsNone(result['raw_process_exit'])

    def test_after_resource_breach_preserves_raw_zero(self):
        calls = 0
        def sampler():
            nonlocal calls
            calls += 1
            return good(0 if calls == 1 else cap.CAP + 1)
        result = self.run_child('pass', sampler, interval=1)
        self.assertEqual(result['exit'], 125)
        self.assertEqual(result['raw_process_exit'], 0)

    def test_benign_vanishing_regular_file(self):
        cache = self.root / 'target'
        cache.mkdir()
        gone = cache / 'temporary'
        gone.write_bytes(b'abc')
        real = pathlib.Path.stat
        def fake_stat(path, *args, **kwargs):
            if path == gone:
                raise FileNotFoundError(str(path))
            return real(path, *args, **kwargs)
        with mock.patch.object(pathlib.Path, 'stat', fake_stat):
            state = cap.resource_state(self.root, [cache])
        self.assertEqual(state['owned_total'], 0)
        self.assertEqual(state['vanished_snapshot_paths'], [str(gone)])

    def test_resource_permission_error_is_not_benign(self):
        cache = self.root / 'target'
        cache.mkdir()
        file = cache / 'private'
        file.write_bytes(b'abc')
        real = pathlib.Path.stat
        def fake_stat(path, *args, **kwargs):
            if path == file:
                raise PermissionError('fake denied')
            return real(path, *args, **kwargs)
        with mock.patch.object(pathlib.Path, 'stat', fake_stat):
            with self.assertRaises(PermissionError):
                cap.resource_state(self.root, [cache])

    def base_env(self):
        return {'RUSTUP_HOME': str(cap.SDK / 'rustup'), 'CARGO_HOME': str(cap.SDK / 'cargo'),
                'PROTOC': '/workspace/pure-protobuf/target/conformance-build/protoc',
                'CARGO_PROFILE_DEV_DEBUG': '0', 'CARGO_PROFILE_TEST_DEBUG': '0', 'CARGO_BUILD_JOBS': '2'}

    def test_environment_guards_allow_frozen_debug_and_reject_overrides(self):
        argv = ['cargo', '+1.85.0', 'check', '--locked', '--offline']
        cap.guard_environment(self.base_env(), self.root, argv, '1.85.0')
        for key in ['RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER', 'RUSTFLAGS', 'CARGO_ENCODED_RUSTFLAGS',
                    'CARGO_BUILD_TARGET', 'CARGO_PROFILE_DEV_OPT_LEVEL',
                    'CARGO_TARGET_X86_64_UNKNOWN_LINUX_GNU_RUNNER', 'CARGO_BUILD_RUSTC', 'CC']:
            with self.subTest(key=key):
                with self.assertRaises(ValueError):
                    cap.guard_environment({**self.base_env(), key: 'unexpected'}, self.root, argv, '1.85.0')
        with self.assertRaises(ValueError):
            cap.guard_environment({**self.base_env(), 'CARGO_PROFILE_DEV_DEBUG': '1'}, self.root, argv, '1.85.0')

    def test_argv_guard_rejects_unbound_profiles_toolchains(self):
        base = ['cargo', '+1.85.0', 'check', '--locked', '--offline']
        for flags in [['--release'], ['--profile=other'], ['--target', 'other'], ['--config=other']]:
            with self.subTest(flags=flags):
                with self.assertRaises(ValueError):
                    cap.guard_environment(self.base_env(), self.root, base + flags, '1.85.0')
        with self.assertRaises(ValueError):
            cap.guard_environment(self.base_env(), self.root, ['cargo', '+stable', 'check', '--offline'], '1.85.0')

    def test_config_guard_retains_hash_and_rejects_compiler_injection(self):
        cargo = self.root / 'cargo-home'
        cargo.mkdir()
        config = cargo / 'config.toml'
        config.write_text('[net]\noffline = true\n')
        self.assertEqual(cap.config_inputs(self.root, {'CARGO_HOME': str(cargo)}).get(str(config)), cap.sha(config))
        config.write_text('[build]\nrustc-wrapper = "other"\n')
        with self.assertRaises(ValueError):
            cap.config_inputs(self.root, {'CARGO_HOME': str(cargo)})

    def test_fresh_probe_failure_retains_argv_exit_and_streams(self):
        probe = cap.Probes(self.prefix, 'before', os.environ.copy(), self.root)
        argv = [sys.executable, '-c', "import sys; print('stdout'); print('stderr',file=sys.stderr); raise SystemExit(9)"]
        with self.assertRaises(RuntimeError):
            probe.run(argv)
        record = json.loads(self.prefix.with_suffix('.probes.jsonl').read_text())
        self.assertEqual(record['argv'], argv)
        self.assertEqual(record['exit'], 9)
        self.assertEqual((self.root / record['stdout']).read_text(), 'stdout\n')
        self.assertEqual((self.root / record['stderr']).read_text(), 'stderr\n')

    def test_probe_launch_error_is_retained(self):
        probe = cap.Probes(self.prefix, 'before', os.environ.copy(), self.root)
        with self.assertRaises(RuntimeError):
            probe.run([str(self.root / 'does-not-exist')])
        record = json.loads(self.prefix.with_suffix('.probes.jsonl').read_text())
        self.assertIsNone(record['exit'])
        self.assertIn('FileNotFoundError', record['helper_error'])

    def test_failed_child_launch_is_invalid_and_retained(self):
        result = cap.run_guarded([str(self.root / 'does-not-exist')], self.root, os.environ.copy(),
                                 self.prefix, .2, lambda: good(), .03)
        self.assertEqual(result['exit'], 126)
        self.assertFalse(result['process_launched'])
        self.assertIn('FileNotFoundError', result['helper_error'])
        self.assertTrue(self.prefix.with_suffix('.process.json').is_file())


if __name__ == '__main__':
    print('Retained helper-only raw records:', OUT, flush=True)
    unittest.main(verbosity=2)
