#!/usr/bin/env python3
"""Work-only RX-10a capture. The coordinator must grant the ordinary lease."""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import shutil
import signal
import stat
import subprocess
import sys
import time
import tomllib
import traceback

BASE = pathlib.Path(__file__).resolve().parent
CAP = 2147483648
SDK = pathlib.Path('/workspace/pure-protobuf/work/toolchain')
OWNED = [pathlib.Path(p) for p in (
    '/workspace/pure-protobuf/work/gn13/target',
    '/workspace/scratch/work/cl07/target',
    '/workspace/scratch/work/deadline-admission-native/target',
    '/workspace/scratch/work/rx10/target',
    '/workspace/scratch/work/rx10-baseline/target',
)]
INPUTS = ['Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml', 'rustfmt.toml',
          'src', 'tests', 'pbrs-grpc', 'protobuf-tonic', 'proto', 'vendor/google',
          'bench/devloop', 'bench/corpora/otlp/protos', 'prost_tat', 'v4_tat', 'rpc-bench']
ENV_KEYS = ['RUSTUP_HOME', 'CARGO_HOME', 'PATH', 'CARGO_TARGET_DIR',
            'CARGO_BUILD_JOBS', 'CARGO_INCREMENTAL', 'CARGO_PROFILE_DEV_DEBUG',
            'CARGO_PROFILE_TEST_DEBUG', 'PROTOC']


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with pathlib.Path(path).open('rb') as file:
        for chunk in iter(lambda: file.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def resource_state(root, owned=None):
    sizes, vanished = {}, []
    def race(error):
        if isinstance(error, FileNotFoundError):
            vanished.append(str(error.filename))
        else:
            raise error
    for cache in OWNED if owned is None else owned:
        total = 0
        for parent, _, files in os.walk(cache, followlinks=False, onerror=race):
            for name in files:
                path = pathlib.Path(parent) / name
                try:
                    info = path.stat()
                except FileNotFoundError:
                    vanished.append(str(path))
                    continue
                if stat.S_ISREG(info.st_mode):
                    # Logical lengths count hardlink aliases conservatively.
                    total += info.st_size
        sizes[str(cache)] = total
    return {'owned_cache_bytes': sizes, 'owned_total': sum(sizes.values()),
            'global_free': shutil.disk_usage(root).free,
            'owned_limit': CAP, 'global_reserve': CAP,
            'vanished_snapshot_paths': vanished}


def resource_failure(state):
    if state['owned_total'] > CAP:
        return 'summed owned caches exceed 2147483648 bytes'
    if state['global_free'] < CAP:
        return 'global free disk below 2147483648 bytes'
    return None


def guard_environment(env, target, argv, toolchain):
    forbidden = {'RUSTUP_TOOLCHAIN', 'RUSTC', 'RUSTDOC', 'RUSTC_WRAPPER',
                 'RUSTC_WORKSPACE_WRAPPER', 'RUSTC_BOOTSTRAP', 'RUSTFLAGS',
                 'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTFLAGS', 'CARGO_ENCODED_RUSTDOCFLAGS',
                 'CC', 'CXX', 'AR', 'CFLAGS', 'CXXFLAGS', 'LDFLAGS'}
    bad = []
    for key, value in env.items():
        if key in forbidden or key.startswith(('CC_', 'CXX_', 'AR_', 'CFLAGS_', 'CXXFLAGS_', 'CARGO_ALIAS_')):
            bad.append(key)
        elif key.startswith('CARGO_PROFILE_') and not (
                key in ('CARGO_PROFILE_DEV_DEBUG', 'CARGO_PROFILE_TEST_DEBUG') and value == '0'):
            bad.append(key)
        elif key.startswith('CARGO_BUILD_') and key != 'CARGO_BUILD_JOBS':
            bad.append(key)
        elif key.startswith('CARGO_TARGET_') and key != 'CARGO_TARGET_DIR':
            bad.append(key)
    if bad:
        raise ValueError('unapproved compiler/environment override names: ' + ', '.join(sorted(bad)))
    for name, path in [('RUSTUP_HOME', SDK / 'rustup'), ('CARGO_HOME', SDK / 'cargo')]:
        if env.get(name) != str(path):
            raise ValueError(name + ' must bind the recorded SDK')
    if env.get('CARGO_TARGET_DIR') not in (None, str(target)):
        raise ValueError('incoming CARGO_TARGET_DIR differs from selected exclusive target')
    if env.get('PROTOC') != '/workspace/pure-protobuf/target/conformance-build/protoc':
        raise ValueError('PROTOC must bind the pinned existing protoc')
    if pathlib.Path(argv[0]).name == 'cargo':
        if len(argv) < 3 or argv[1] != '+' + toolchain:
            raise ValueError('Cargo argv must select the recorded toolchain explicitly')
        if '--locked' not in argv or '--offline' not in argv:
            raise ValueError('Cargo argv must retain --locked --offline')
        if any(arg == '--release' or arg.split('=')[0] in ('--profile', '--target', '--config') for arg in argv):
            raise ValueError('unapproved Cargo profile/target/config argv override')


def config_inputs(root, env):
    found = {}
    directories = [root, *root.parents]
    candidates = [d / '.cargo' / name for d in directories for name in ('config', 'config.toml')]
    candidates += [pathlib.Path(env['CARGO_HOME']) / name for name in ('config', 'config.toml')]
    for path in candidates:
        if not path.is_file():
            continue
        content = tomllib.loads(path.read_text())
        # Bind ordinary download/registry settings; reject compiler/command injection.
        if set(content) - {'net', 'http', 'registry', 'registries', 'source', 'term'}:
            raise ValueError('unapproved Cargo config compiler/command section: ' + str(path))
        found[str(path)] = sha(path)
    return found


class Probes:
    def __init__(self, prefix, phase, env, root):
        self.prefix, self.phase, self.env, self.root = prefix, phase, env, root
        self.records = []

    def run(self, argv):
        index = len(self.records)
        stem = self.prefix.parent / (self.prefix.name + f'.{self.phase}.probe-{index:02d}')
        failure = None
        try:
            command = subprocess.run(argv, cwd=self.root, env=self.env, capture_output=True, timeout=30)
            stdout, stderr, code = command.stdout, command.stderr, command.returncode
        except (subprocess.TimeoutExpired, OSError) as error:
            failure = error
            stdout, stderr, code = getattr(error, 'stdout', None) or b'', getattr(error, 'stderr', None) or b'', None
        stem.with_suffix(stem.suffix + '.stdout.log').write_bytes(stdout)
        stem.with_suffix(stem.suffix + '.stderr.log').write_bytes(stderr)
        record = {'argv': argv, 'cwd': str(self.root), 'exit': code,
                  'stdout_sha256': hashlib.sha256(stdout).hexdigest(),
                  'stderr_sha256': hashlib.sha256(stderr).hexdigest(),
                  'utc': utc(), 'stdout': stem.name + '.stdout.log', 'stderr': stem.name + '.stderr.log'}
        if failure is not None:
            record['helper_error'] = repr(failure)
        self.records.append(record)
        with self.prefix.with_suffix('.probes.jsonl').open('a') as stream:
            stream.write(json.dumps({'phase': self.phase, **record}) + '\n')
        if failure is not None or code:
            raise RuntimeError('fresh probe failed; raw disposition retained: ' + repr(argv))
        return stdout.decode().strip()


def snapshot(root, toolchain, argv, env, prefix, phase):
    probe = Probes(prefix, phase, env, root)
    paths = probe.run(['git', 'ls-files', '-z', '--', *INPUTS]).split('\0')
    files = {path: sha(root / path) for path in paths if path}
    tools = {'capture': {'path': str(BASE / 'capture.py'), 'sha256': sha(BASE / 'capture.py')}}
    tools['python'] = {'path': str(pathlib.Path(sys.executable).resolve()), 'sha256': sha(sys.executable),
                       'version': sys.version}
    for name in ['rustup', 'git']:
        path = pathlib.Path(shutil.which(name, path=env['PATH'])).resolve()
        if name == 'rustup' and path != (SDK / 'cargo/bin/rustup').resolve():
            raise ValueError('rustup probe must use the pinned SDK')
        tools[name] = {'path': str(path), 'sha256': sha(path)}
    names = ['rustc', 'cargo'] + (['clippy-driver', 'cargo-clippy'] if 'clippy' in argv else [])
    for name in names:
        path = probe.run(['rustup', 'which', '--toolchain', toolchain, name])
        item = {'path': path, 'sha256': sha(path)}
        # cargo-clippy --version can invoke Cargo; hash it without invoking it.
        if name != 'cargo-clippy':
            item['version'] = probe.run([path, '--version' if name == 'clippy-driver' else '-Vv'])
        tools[name] = item
    protoc = env['PROTOC']
    tools['protoc'] = {'path': protoc, 'sha256': sha(protoc), 'version': probe.run([protoc, '--version'])}
    launch = argv[0] if pathlib.Path(argv[0]).is_file() else shutil.which(argv[0], path=env['PATH'])
    if not launch:
        raise ValueError('launch executable not found')
    executable = pathlib.Path(launch).resolve()
    if pathlib.Path(argv[0]).name == 'cargo' and executable != (SDK / 'cargo/bin/rustup').resolve():
        raise ValueError('Cargo launch must be the pinned SDK rustup proxy')
    tools['launch'] = {'path': str(executable), 'sha256': sha(executable)}
    if executable.name == 'nm':
        tools['launch']['version'] = probe.run([str(executable), '--version'])
    return {'head': probe.run(['git', 'rev-parse', 'HEAD']),
            'status': probe.run(['git', 'status', '--porcelain']), 'files': files,
            'configs': config_inputs(root, env), 'tools': tools}


def live_group(pgid):
    members = []
    for proc in pathlib.Path('/proc').iterdir():
        if not proc.name.isdigit():
            continue
        try:
            fields = (proc / 'stat').read_text().rsplit(')', 1)[1].split()
            if int(fields[2]) == pgid and fields[0] != 'Z':
                members.append(int(proc.name))
        except (FileNotFoundError, ProcessLookupError):
            pass
    return members


def stop_group(child, grace=2):
    result = {'pgid': child.pid, 'live_before_cleanup': live_group(child.pid), 'signals': []}
    def send(sig):
        try:
            os.killpg(child.pid, sig)
            result['signals'].append(signal.Signals(sig).name)
        except ProcessLookupError:
            pass
    if result['live_before_cleanup']:
        send(signal.SIGTERM)
    until = time.monotonic() + grace
    while live_group(child.pid) and time.monotonic() < until:
        child.poll()
        time.sleep(.02)
    if live_group(child.pid):
        send(signal.SIGKILL)
    result['leader_exit'] = child.wait(timeout=5)
    until = time.monotonic() + 2
    while live_group(child.pid) and time.monotonic() < until:
        time.sleep(.02)
    result['live_after_cleanup'] = live_group(child.pid)
    if result['live_after_cleanup']:
        raise RuntimeError('owned process group survived cleanup: ' + repr(result))
    return result


def run_guarded(argv, root, env, prefix, bound, sampler, interval=2):
    result = {'process_launched': False, 'exit': 125, 'raw_process_exit': None,
              'stop_reason': None, 'utc_start': utc(), 'argv': argv, 'cwd': str(root),
              'bound_seconds': bound, 'sample_interval_seconds': interval}
    start, child, samples = time.monotonic(), None, []
    sample_file = prefix.with_suffix('.resources.jsonl')
    def sample(phase):
        state = sampler()
        record = {'phase': phase, 'utc': utc(), 'elapsed_seconds': time.monotonic() - start, **state}
        with sample_file.open('a') as stream:
            stream.write(json.dumps(record) + '\n')
        samples.append(record)
        return state
    with prefix.with_suffix('.stdout.log').open('wb') as stdout, prefix.with_suffix('.stderr.log').open('wb') as stderr:
        try:
            result['resources_before'] = sample('before')
            result['stop_reason'] = resource_failure(result['resources_before'])
            if result['stop_reason'] is None:
                child = subprocess.Popen(argv, cwd=root, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                result['process_launched'] = True
                result['pgid'] = child.pid
                while True:
                    try:
                        result['raw_process_exit'] = child.wait(timeout=min(interval, max(.001, bound - (time.monotonic() - start))))
                        result['exit'] = result['raw_process_exit']
                        break
                    except subprocess.TimeoutExpired:
                        state = sample('active')
                        result['stop_reason'] = resource_failure(state)
                        if result['stop_reason']:
                            result['exit'] = 125
                        elif time.monotonic() - start >= bound:
                            result['stop_reason'] = 'OS campaign timeout (individual test bounds unchanged)'
                            result['exit'] = 124
                        if result['stop_reason']:
                            break
        except BaseException as error:
            result.update(exit=130 if isinstance(error, KeyboardInterrupt) else 126,
                          stop_reason='invalid helper attempt; not a gate result',
                          helper_error=repr(error), traceback=traceback.format_exc())
        finally:
            if child is not None:
                # Entire child lifetime is protected, including sampler errors/Ctrl-C.
                try:
                    result['cleanup'] = stop_group(child)
                    result['raw_process_exit'] = result['cleanup']['leader_exit']
                    if result['exit'] == 0 and result['cleanup']['live_before_cleanup']:
                        result.update(exit=126, stop_reason='invalid: descendants remained after leader exit')
                except BaseException as error:
                    try:
                        os.killpg(child.pid, signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    result.update(exit=126, cleanup_error=repr(error), cleanup_traceback=traceback.format_exc())
                    try:
                        result['raw_process_exit'] = child.wait(timeout=5)
                    except BaseException as wait_error:
                        result['cleanup_wait_error'] = repr(wait_error)
            try:
                result['resources_after'] = sample('after_cleanup')
                if result['exit'] == 0 and resource_failure(result['resources_after']):
                    result.update(exit=125, stop_reason=resource_failure(result['resources_after']))
            except BaseException as error:
                result.update(exit=126, after_sample_error=repr(error), after_sample_traceback=traceback.format_exc())
    result.update(elapsed_seconds=time.monotonic() - start, utc_finish=utc(), resource_sample_count=len(samples),
                  observed_max_owned_total=max((s['owned_total'] for s in samples), default=None),
                  observed_min_global_free=min((s['global_free'] for s in samples), default=None),
                  resource_observation_limit='periodic samples, not an unsampled peak/minimum guarantee')
    result['stdout_sha256'], result['stderr_sha256'] = sha(prefix.with_suffix('.stdout.log')), sha(prefix.with_suffix('.stderr.log'))
    prefix.with_suffix('.process.json').write_text(json.dumps(result, indent=2) + '\n')
    return result


def main():
    parser = argparse.ArgumentParser()
    for name in ('root', 'expected-head', 'toolchain', 'target', 'label'):
        parser.add_argument('--' + name, required=True)
    parser.add_argument('--bound', type=int, required=True)
    parser.add_argument('argv', nargs=argparse.REMAINDER)
    args = parser.parse_args()
    if os.environ.get('RX10_ORDINARY_LEASE') != 'granted':
        raise SystemExit('No coordinator ordinary lease: no probe/build/process launched')
    argv = args.argv[1:] if args.argv[:1] == ['--'] else args.argv
    if not argv or not args.label.isidentifier() or args.bound <= 0:
        raise ValueError('argv/label/bound invalid')
    root, target = pathlib.Path(args.root).resolve(), pathlib.Path(args.target).resolve()
    if not target.is_relative_to(pathlib.Path('/workspace/scratch/work/rx10/target/qualification')):
        raise ValueError('target is outside approved owned qualification root')
    out = BASE / 'records'
    out.mkdir(exist_ok=True)
    prefix = out / args.label
    if list(out.glob(args.label + '.*')):
        raise ValueError('never overwrite any part of a first attempt')
    env = os.environ.copy()
    guard_environment(env, target, argv, args.toolchain)
    env.update(CARGO_TARGET_DIR=str(target), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
    meta = {'argv': argv, 'cwd': str(root), 'toolchain': args.toolchain, 'bound_seconds': args.bound,
            'env': {key: env.get(key) for key in ENV_KEYS}, 'process_launched': False}
    try:
        meta['before'] = snapshot(root, args.toolchain, argv, env, prefix, 'before')
        if meta['before']['head'] != args.expected_head or meta['before']['status']:
            raise ValueError('source HEAD/cleanliness does not match frozen source')
        meta.update(run_guarded(argv, root, env, prefix, args.bound, lambda: resource_state(root)))
        meta['after'] = snapshot(root, args.toolchain, argv, env, prefix, 'after')
        meta['pins_unchanged'] = meta['before'] == meta['after']
        if not meta['pins_unchanged']:
            meta.update(exit=126, source_tool_drift=True)
    except BaseException as error:
        meta.update(exit=130 if isinstance(error, KeyboardInterrupt) else 126,
                    classification='invalid helper attempt; not a gate result',
                    helper_error=repr(error), traceback=traceback.format_exc())
    prefix.with_suffix('.meta.json').write_text(json.dumps(meta, indent=2) + '\n')
    prefix.with_suffix('.exit').write_text(str(meta['exit']) + '\n')
    print(json.dumps({'label': args.label, 'exit': meta['exit'], 'pins_unchanged': meta.get('pins_unchanged'),
                      'stop_reason': meta.get('stop_reason'), 'helper_error': meta.get('helper_error')}), flush=True)
    return meta['exit']


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as error:
        out = BASE / 'records'
        out.mkdir(exist_ok=True)
        name = 'helper_invalid_' + datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
        record = {'argv': sys.argv, 'cwd': str(pathlib.Path.cwd()),
                  'classification': 'invalid capture helper preflight attempt; not a gate result',
                  'exception': repr(error), 'traceback': traceback.format_exc()}
        (out / (name + '.json')).write_text(json.dumps(record, indent=2) + '\n')
        (out / (name + '.stderr.log')).write_text(record['traceback'])
        raise
