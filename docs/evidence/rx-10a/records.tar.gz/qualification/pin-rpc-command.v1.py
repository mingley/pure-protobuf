#!/usr/bin/env python3
"""Guard the Cargo-selected command binary used by registered RPC test children."""
import argparse
import hashlib
import json
import pathlib

BASE = pathlib.Path(__file__).resolve().parent
parser = argparse.ArgumentParser()
parser.add_argument('--label', required=True)
parser.add_argument('--phase', choices=['before', 'after', 'unit-after-selection'], required=True)
args = parser.parse_args()
assert args.label.isidentifier()
selection_path = BASE / 'bin/native188-command.selection.json'
selection = json.loads(selection_path.read_text())
sha = lambda p: hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
paths = [selection['source_path'], selection['immutable_path']]
observed = {path: sha(path) for path in paths}
assert all(value == selection['sha256'] for value in observed.values()), observed
record = {'capture_label': args.label, 'phase': args.phase,
          'selection_record': str(selection_path), 'selection_sha256': sha(selection_path),
          'expected_sha256': selection['sha256'], 'observed': observed,
          'scope': 'Exact Cargo-selected normal command and immutable copy; separate from harness launch ELF'}
if args.phase == 'unit-after-selection':
    record['before_limit'] = ('Before unit launch is the immediately preceding selector record, which '
                              'hash-verified both paths around copying. This post-unit record does '
                              'not invent a separately executed pre-unit pin command.')
path = BASE / 'records' / (args.label + '.command-' + args.phase + '.json')
assert not path.exists()
path.write_text(json.dumps(record, indent=2) + '\n')
if args.phase == 'after':
    before = json.loads((BASE / 'records' / (args.label + '.command-before.json')).read_text())
    assert before['observed'] == observed
print(json.dumps({'capture_label': args.label, 'phase': args.phase, 'sha256': selection['sha256']}))
