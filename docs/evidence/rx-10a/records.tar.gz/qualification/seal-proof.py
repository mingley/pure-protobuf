#!/usr/bin/env python3
"""Seal ordinary RX-10a and completed historical-cache evidence; no execution."""
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/work/rx10')
Q = ROOT / 'work/qualification'
FLOOR = 2147483648


def sha(data):
    return hashlib.sha256(data).hexdigest()


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            value.update(chunk)
    return value.hexdigest()


def obj(data):
    return (json.dumps(data, indent=2, sort_keys=True) + '\n').encode()


def guard(size=0):
    info = os.statvfs('/workspace')
    assert info.f_bavail * info.f_frsize >= FLOOR + size + 16777216


class GuardedWriter:
    def __init__(self, path):
        self.file = path.open('xb')

    def write(self, data):
        guard(len(data))
        result = self.file.write(data)
        self.file.flush()
        guard()
        return result

    def flush(self):
        self.file.flush()

    def close(self):
        self.file.close()


def seal(directory, blobs, details):
    directory.mkdir(parents=True, exist_ok=False)
    members = {}
    writer = GuardedWriter(directory / 'records.tar.gz')
    try:
        with gzip.GzipFile(fileobj=writer, mode='wb', filename='', mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode='w|') as archive:
                for name, data in sorted(blobs.items()):
                    assert not Path(name).is_absolute() and '..' not in Path(name).parts
                    info = tarfile.TarInfo(name)
                    info.size, info.mode = len(data), 0o644
                    archive.addfile(info, io.BytesIO(data))
                    members[name] = {'bytes': len(data), 'sha256': sha(data)}
    finally:
        writer.close()
    index = {'schema': 'ordinary-proof-capsule/1', 'recorded_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
             'capsule': {'file': 'records.tar.gz', 'sha256': digest(directory / 'records.tar.gz'),
                         'bytes': (directory / 'records.tar.gz').stat().st_size},
             'members': members, **details}
    data = obj(index)
    guard(len(data))
    (directory / 'index.json').write_bytes(data)
    print(json.dumps({'sealed': str(directory), 'members': len(members), 'capsule': index['capsule']}))


def collect_tree(directory, prefix, exclude=None):
    result = {}
    for path in sorted(directory.rglob('*')):
        if not path.is_file() or path.is_symlink() or (exclude and exclude(path)):
            continue
        relative = str(path.relative_to(directory))
        result[prefix + relative] = path.read_bytes()
    return result


def main():
    commits = {
        'base': '10bee600737b8a207159e63581bebc01b07ec2d7',
        'baseline': '1308bd98e032b8b4c70e3599bb03f1bac1c253e9',
        'candidate': 'f2638b90be0f7bf510df1fe40f82581aa92f2b9c',
        'seven_edges': '08dfc57e267141f3470ba94da417a0f814791f6f',
        'inactive_h2_removed': 'bb171827a07b63082c48785bbc8403d61f80b953',
        'generated_owner': '98272ce645e3a1d5dd6ddf23040c404e9b661ebf',
        'format_only': '6d6678cf6f6be9f18ade57d2f2f9e4a094d3997b',
    }
    records = Q / 'records'
    captures = {}
    for path in sorted(records.glob('*.meta.json')):
        d = json.loads(path.read_text())
        label = path.name.removesuffix('.meta.json')
        assert d['before'] == d['after'] and d['pins_unchanged'] and not d['stop_reason']
        captures[label] = {'source': d['before']['head'], 'toolchain': d['toolchain'], 'exit': d['exit'],
                           'argv': d['argv'], 'seconds': d['elapsed_seconds']}
    assert captures['bench_final188_strict_002']['exit'] == 0
    assert len(captures) == 37, len(captures)
    tests = {}
    for label, capture in captures.items():
        text = (records / (label + '.stdout.log')).read_text()
        matches = re.findall(r'^test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;', text, re.M)
        if matches:
            assert len(matches) == 1 and matches[0][1:] == ('0', '0')
            tests[label] = {'passed': int(matches[0][0]), 'source': capture['source'], 'toolchain': capture['toolchain']}
    native185 = {k: v for k, v in tests.items() if k.startswith('native185_')}
    registered = {k: tests[k] for k in ('native188_rpc_unit_001', 'native188_worker_002', 'native188_fairness_002')}
    assert sum(v['passed'] for v in native185.values()) == 107
    assert sum(v['passed'] for v in registered.values()) == 172
    assert tests['bench_final_stable_units_001']['passed'] == 18
    failures = {k: v for k, v in captures.items() if v['exit'] != 0}
    assert len(failures) == 7 and all(v['exit'] == 101 for v in failures.values())
    binaries = []
    for path in sorted((Q / 'bin').iterdir()):
        if not path.is_file() or path.suffix in ('.json', '.jsonl', '.log'):
            continue
        binaries.append({'path': str(path), 'sha256': digest(path), 'bytes': path.stat().st_size,
                         'disposition': 'retained locally; hash indexed, not a Git blob'})
    summary = {'status': 'bounded_slice_qualified_parent_open', 'commits': commits, 'captures': captures,
               'native185_tests': native185, 'registered_rpc_tests': registered,
               'benchmark_stable_tests': tests['bench_final_stable_units_001'],
               'native185_executions': 107, 'registered_rpc_executions': 172, 'benchmark_unit_executions': 18,
               'baseline_scheduler_cases': 14, 'candidate_scheduler_cases': 14,
               'genuine_failed_captures': failures,
               'invalid_helper_attempts': ['baseline_build_002 no-overwrite preflight', 'native188_worker_001 no-overwrite preflight',
                                          'bench_retirement_001 missing-parent preflight', 'verify OFD fixture001 missing Python constant'],
               'unmeasured': ['wakeups', 'channel_sends', 'cross_thread_handoffs', 'context_switches', 'instruction_attribution',
                              'performance', 'RX10_parent_budgets'],
               'event_semantics': 'attempts immediately before unchanged spawn expressions, not successful scheduling or task completion',
               'provenance_limit': 'Source/tool/compiler-input hash records are direct capture guards. Registry cache bytes/full native header closure are not independently archived. Older test labels are not promoted to later source commits.'}
    blobs = collect_tree(Q, 'qualification/', lambda p: '__pycache__' in p.parts or p.suffix == '.pyc'
                         or ('bin' in p.relative_to(Q).parts and p.suffix not in ('.json', '.jsonl', '.log'))
                         or p.name.startswith('payload.tar.gz') or '-frozen-inputs' in str(p))
    blobs['qualification/final-summary.json'] = obj(summary)
    source_paths = ['Cargo.toml', 'Cargo.lock', 'pbrs-grpc/Cargo.toml', 'bench/devloop/Cargo.toml', 'bench/devloop/Cargo.lock',
                    'rpc-bench/Cargo.toml', 'rpc-bench/Cargo.lock', 'rpc-bench/src/main.rs', 'rpc-bench/tests/worker.rs',
                    'rpc-bench/src/generated_wkt.rs', 'bench/devloop/src/main.rs', 'bench/devloop/src/blob.rs',
                    'bench/devloop/src/scheduler_rpc.rs', 'pbrs-grpc/src/lib.rs', 'pbrs-grpc/src/copy_counts.rs',
                    'pbrs-grpc/src/server/connection.rs', 'pbrs-grpc/src/client/pool.rs', 'pbrs-grpc/src/client/streaming.rs',
                    'pbrs-grpc/src/wire/send.rs']
    for name, head in commits.items():
        for path in source_paths:
            proc = subprocess.run(['git', 'show', head + ':' + path], cwd=ROOT, capture_output=True)
            if proc.returncode == 0:
                blobs['sources/' + name + '/' + path] = proc.stdout
        blobs['sources/' + name + '.commit.txt'] = subprocess.check_output(['git', 'show', '-s', '--format=fuller', head], cwd=ROOT)
        if name != 'base':
            blobs['sources/' + name + '.patch'] = subprocess.check_output(['git', 'diff', '--binary', commits['base'], head], cwd=ROOT)
    root_audit = Path('/workspace/pure-protobuf/work/rpc-lock-normalization/root-audit.json')
    blobs['root-audits/rpc-lock-normalization.json'] = root_audit.read_bytes()
    blobs['root-audits/scheduler-semantic.json'] = (Q / 'root-scheduler-semantic-audit.json').read_bytes()
    stages = []
    for stage in ('bench_stable', 'native185', 'native188', 'bench_final'):
        directory = Q / 'retirements/campaign_002' / stage
        record = json.loads((directory / 'record.json').read_text())
        stages.append({'stage': stage, 'prefix': 'qualification/retirements/campaign_002/' + stage + '/',
                       'cache': record['cache'], 'payload_path': str(directory / 'payload.tar.gz'),
                       'payload_relative': stage + '/payload.tar.gz', 'archive': record['archive'],
                       'lock_scope': 'dedicated OFD plus flock' if stage in ('native188', 'bench_final') else 'flock; POSIX lock acquired but continuous hold not certified'})
    seal(ROOT / 'docs/evidence/rx-10a', blobs,
         {'sources': commits, 'summary_member': 'qualification/final-summary.json', 'captures': sorted(captures),
          'local_binaries': binaries, 'retirements': stages, 'owned_cap_and_global_floor': FLOOR,
          'limits': summary['unmeasured'] + [summary['provenance_limit']]})

    campaign = Path((Q / 'verify-retirement-campaign.txt').read_text().strip())
    historical = collect_tree(campaign, '', lambda p: p.name.startswith('payload.tar.gz') or p.suffix == '.pyc' or '__pycache__' in p.parts)
    stages = []
    for stage in ('verify_shared', 'verify_remaining'):
        directory = campaign / stage
        record = json.loads((directory / 'record.json').read_text())
        assert record['status'] == 'verified_retired' and record['exit'] == 0
        stages.append({'stage': stage, 'prefix': stage + '/', 'cache': record['cache'],
                       'payload_path': str(directory / 'payload.tar.gz'), 'payload_relative': stage + '/payload.tar.gz',
                       'archive': record['archive'], 'lock_scope': 'dedicated OFD plus flock'})
    seal(ROOT / 'docs/evidence/verify-cache-retirement-20261003', historical,
         {'retirements': stages, 'owned_cap_and_global_floor': FLOOR,
          'historical_source_context': 'de0bcdf2dd55fa7f436139813a87b967187c8f5d',
          'limits': ['Clean source context does not independently attribute every historical cached artifact.',
                     'Previously pruned 35 native and 20 other ELF paths remain unavailable.',
                     'External cache symlinks archived as metadata only; their shared targets untouched.',
                     'Process visibility denials and point-in-time limits retained.',
                     'Large payload archives local and hash-indexed; default checker does not reread them.']})


if __name__ == '__main__':
    main()
