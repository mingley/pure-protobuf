# RX-10a ordinary qualification runner (prepared, not run)

The coordinator's lease is required before running `capture.py`. No Cargo,
compiler, runtime diagnostic or performance tool has run for these source pins.
`plan.json` records the exact commands, bounds, toolchain stages and retirement
points. The full source/tool/raw capture wrapper requires
`RX10_ORDINARY_LEASE=granted`; this is a launch guard, not permission to grant a
lease locally.

Source identities: semantic baseline `1308bd98e032b8b4c70e3599bb03f1bac1c253e9`
in `/workspace/scratch/work/rx10-baseline`, candidate
`f2638b90be0f7bf510df1fe40f82581aa92f2b9c` in
`/workspace/scratch/work/rx10`. Original `ddb13711` and `2eaa7701` commits remain
reachable. All setup/warmup/case/producer-body/cleanup bounds remain identical
between the corrected sources.

After authorization, source `/workspace/pure-protobuf/work/toolchain/env.sh`,
set `CARGO_BUILD_JOBS=1`, `CARGO_INCREMENTAL=0`, and explicitly set
`PROTOC=/workspace/pure-protobuf/target/conformance-build/protoc`. Supply a fresh
exclusive namespace below `/workspace/scratch/work/rx10/target/qualification`.
The wrapper additionally fixes jobs=1/incremental=0. It leaves DEV/TEST debug=0
from the existing environment, and changes no release/profile/RUSTFLAGS/default
worker configuration. The diagnostic fixture itself is a separately labelled
current-thread duplex semantic test; it is not a replacement performance cell.

Example baseline build (only after lease):

```sh
python3 work/qualification/capture.py \
  --root /workspace/scratch/work/rx10-baseline \
  --expected-head 1308bd98e032b8b4c70e3599bb03f1bac1c253e9 \
  --toolchain stable --target /workspace/scratch/work/rx10/target/qualification/bench_stable \
  --label baseline_build --bound 900 -- \
  cargo +stable build --locked --offline --manifest-path bench/devloop/Cargo.toml \
  --bin devloop --message-format=json
```

Select the launch executable from that successful current-manifest artifact
stream with `select-artifact.py`; copy/hash it before the next candidate build.
Run the immutable copy with `scheduler-check` under a separate guarded45s
capture on the baseline source. Repeat the build/select/run on the candidate
source with unique labels; no guessed default paths, report overwrites, or
selection of a later favorable attempt. A source/lock/tool/launch hash drift
makes the capture invalid. Actual1.85 default `.rlib` selection uses the same
helper and an independent guarded `nm -a -C` launch; reject any named scheduler
counter/state/API symbols. Source audit is structural evidence, not a substitute
for that actual build.

Native relevant gates include the card's rpc+gaps entry point, original retry,
preface/admission, bidi terminal upload, streaming cancellation/drop and resource
regressions on the copy-counts build; default execution is the unchanged foundation rpc+gaps four-shape controls. Run only the existing copy-count
unit filter from the library ELF; do not repeat an unchanged5000-cycle soak.
Required rpc-bench tests are exactly the registered bin/worker/fairness targets.
Actual1.88 strict gates cover all native targets/features and benchmark targets.
Retain inherited lint/toolchain/locked-graph failures without altering them or
relabelling source. Stable benchmark tooling is separate from actual1.85 native
MSRV and actual1.88 Tonic-capable strict gates.

The fixed cache cap is the sum of all five owned target roots listed in the
wrapper, not just the active fresh namespace; logical hardlink alias lengths
are counted conservatively. Global free reserve is2147483648B. Both are checked
before launch and every2s while active; a breach stops only the owned process
group and retains raw exit/stop reason. The completed GN13 target is currently
~600.8MB, native-caller target~797.3MB, and CL07 target~1.5KB (logical aliases included). These old owned caches
sum to1398183047 bytes and must receive separate approved preservation/retirement before a fresh benchmark
target estimated1.0–1.5GiB fits. Stage estimates are planning bounds, not observed
results or permission to exceed2GiB.

Retirement proposal: verify advisory Cargo locks and no live compiler/process
uses each namespace; inventory every file/hash/link and source/build fingerprints,
preserve all ELF members regardless of executable bit (including `.so` and
objects), selected immutable executables/rlibs, full `.fingerprint` trees,
generated `build/*/out`, dep-info, Cargo/source manifests and capture logs. Verify
archive/copy hashes before removing only the completed approved namespace, then
verify preserved copies and free bytes afterward. Excluded payloads remain
explicitly hash-only; no already-deleted artifact can be recreated by this
proposal. No deletion/archive has been authorized or performed by this runner.

No counter results are claimed until raw14-case output passes independent
semantic/event checks. Spawn invocations are attempts before existing spawn
expressions, not scheduling successes. Wake/channel/context/migration/CPU
attribution and parentRX10 budgets remain `not_run`/open. No thresholds,
default20 cells, warmups, workers, fixed workloads or comparative timings change.

The final corrected work-only helper has16 passing Python-only fake-child tests in
`helper-tests/20261003T052050695111Z`, with v2 raw stdout/stderr/exit retained.
The earlier16-pass helper revision remains separately retained at
`helper-tests/20261003T051328940865Z`.
These cover actual SIGINT, sampler error, timeout and descendant cleanup,
regular-file removal races, post-exit resource breaches, invalid launches and
raw failed probes/environment controls. They do not run Rust/Cargo/protoc or
validate the RX fixture. Every periodic resource sample is written to JSONL;
summary extrema are explicitly observed samples rather than unsampled peaks.
Fresh before/after probes retain argv/stdout/stderr/exit independently from
compared source/tool identities. Compiler wrapper/flags/target/profile/config
overrides are rejected; only the two frozen debug=0 profile overrides are
accepted. See `../housekeeping/proposal.md` for the exact read-only retirement
scope, link/lock/process visibility and historical-source qualifications.
