from pathlib import Path
import re
import subprocess


def split_top(text):
    result = []
    depth = 0
    quoted = False
    escaped = False
    start = 0
    for at,ch in enumerate(text):
        if quoted:
            if escaped:
                escaped = False
            elif ch == '\\':
                escaped = True
            elif ch == '"':
                quoted = False
        elif ch == '"':
            quoted = True
        elif ch in '([{':
            depth += 1
        elif ch in ')]}':
            depth -= 1
        elif ch == ',' and depth == 0:
            if text[start:at].strip():
                result.append(text[start:at].strip())
            start = at + 1
    if text[start:].strip():
        result.append(text[start:].strip())
    return result


def calls(source, name):
    result = []
    for match in re.finditer(r'\b' + name + r'\(', source):
        if source[max(0,match.start()-3):match.start()] == 'fn ':
            continue
        depth = 0
        quoted = False
        escaped = False
        start = match.end()
        for at in range(start,len(source)):
            ch = source[at]
            if quoted:
                if escaped:
                    escaped = False
                elif ch == '\\':
                    escaped = True
                elif ch == '"':
                    quoted = False
            elif ch == '"':
                quoted = True
            elif ch in '([{':
                depth += 1
            elif ch == ')' and depth == 0:
                result.append(split_top(source[start:at]))
                break
            elif ch in ')]}':
                depth -= 1
    return result


def record(text):
    entries = split_top(text[text.index('{')+1:text.rindex('}')])
    return dict(entry.split(':',1) if ':' in entry else (entry,entry) for entry in entries)


def normalize(text):
    return re.sub(r'\s+', '',text)


def check(path, name, restore):
    old = subprocess.check_output(['git','show',f'30da0bad:{path}'],text=True)
    new = Path(path).read_text()
    before = calls(old,name)
    after = calls(new,name)
    assert len(before) == len(after),name
    for index,(original,args) in enumerate(zip(before,after)):
        restored = restore(args)
        assert list(map(normalize,original)) == list(map(normalize,restored)),(name,index,original,restored)
    print(f'{name}: all {len(before)} caller argument lists preserved')


def latency(args):
    context = record(args[0])
    return [context['scenario_id'],context['scenario_name'],args[1],args[2],context['transport'],args[3],context['host_info'],context['git_commit']]


def qps(args):
    context = record(args[0])
    round = record(args[1])
    return [context['scenario_id'],context['scenario_name'],context['transport'],*(round[key] for key in ['conc','conns','dur','round_idx','ok','err']),args[2],context['host_info'],context['git_commit']]


def streaming(args):
    context = record(args[0])
    return [context['scenario_id'],context['scenario_name'],args[1],context['transport'],args[2],args[3],args[4],context['host_info'],context['git_commit']]


def native(args):
    options = record(args[1])
    return [args[0],*(options[key] for key in ['tls_ca','tls_server_name','max_message_size','connections','window_mode','small_window_size','small_window_override'])]


def reference(args):
    options = record(args[2])
    return [args[0],args[1],*(options[key] for key in ['shape','req_bytes','resp_bytes','stream_msgs','max_message_size','connections','gzip','tls_ca','tls_name'])]


for name,restore in [('make_latency_run',latency),('make_qps_run',qps),('make_streaming_run',streaming)]:
    check('rpc-bench/src/process.rs',name,restore)
for name,restore in [('load_native_channel',native),('run_load_tonic',reference),('run_load_prost',reference)]:
    check('rpc-bench/src/main.rs',name,restore)
