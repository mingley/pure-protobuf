import json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');OUT=ROOT/'work/final-doc-gates-2c66-protoc';OUT.mkdir(exist_ok=False)
PIN='2c66a91ff81f44f896e9228e5e9d73bf038711ba'
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report={'source':PIN,'state':'waiting_for_native_suites','passed':False,'qualified':False,'results':[]}
def save(): (OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
report['state']='running'; report['retries']='documentation and Rustdoc only; prior formatting, plan, queue, Clippy passed';save()
os.environ['PATH']=str(ROOT/'work/toolchain/protoc/bin')+os.pathsep+os.environ['PATH']
os.environ['PROTOC']=str(ROOT/'work/toolchain/protoc/bin/protoc')
steps=[('documentation',['cargo','test','--locked','--test','documentation','--message-format=json'],{'PROTOC':os.environ['PROTOC'],'PATH':os.environ['PATH']}),('rustdoc',['cargo','doc','--locked','--no-deps','-p','pbrs','-p','pbrs-grpc','--all-features'],{'RUSTDOCFLAGS':'-D warnings'})]
for name,args,extra in steps:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PIN
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
 start=time.monotonic();directory=OUT/name;directory.mkdir()
 argv=[str(ROOT/'work/run-rust'),*args] if args[0]=='cargo' else args
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  p=subprocess.run(argv,cwd=ROOT,env={**os.environ,**extra},stdout=out,stderr=err)
 report['results'].append(dict(name=name,argv=argv,environment_overrides=extra,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start));save();print(name,p.returncode,flush=True)
 if p.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(steps) and all(r['exit_code']==0 for r in report['results']);save()
