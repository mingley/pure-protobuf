import json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');OUT=ROOT/'work/final-doc-gates-2c66';OUT.mkdir(exist_ok=False)
PIN='2c66a91ff81f44f896e9228e5e9d73bf038711ba'
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
report={'source':PIN,'state':'waiting_for_native_suites','passed':False,'qualified':False,'results':[]}
def save(): (OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
save()
while True:
 p=ROOT/'work/native-sequential-gates-2c66/results.json'
 try: native=json.loads(p.read_text())
 except (FileNotFoundError,json.JSONDecodeError):native={}
 if native.get('state')=='finished':break
 time.sleep(3)
report['native_suite_passed']=native.get('passed');report['state']='running';save()
steps=[('format',['cargo','fmt','--all','--','--check'],{}),('plan',['python3','scripts/plan-lint.py'],{}),('queue',['python3','-B','-m','unittest','tests.test_plan_status','tests.test_plan_lint','-q'],{}),('clippy',['cargo','clippy','--locked','--all-targets','--all-features','-p','pbrs','-p','pbrs-grpc','--','-D','warnings'],{}),('documentation',['cargo','test','--locked','--test','documentation','--message-format=json'],{}),('rustdoc',['cargo','doc','--locked','--no-deps','-p','pbrs','-p','pbrs-grpc','--all-features'],{'RUSTDOCFLAGS':'-D warnings'})]
for name,args,extra in steps:
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()==PIN
 assert not subprocess.check_output(['git','status','--porcelain'],cwd=ROOT,text=True)
 start=time.monotonic();directory=OUT/name;directory.mkdir()
 argv=[str(ROOT/'work/run-rust'),*args] if args[0]=='cargo' else args
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  p=subprocess.run(argv,cwd=ROOT,env={**os.environ,**extra},stdout=out,stderr=err)
 report['results'].append(dict(name=name,argv=argv,environment_overrides=extra,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start));save();print(name,p.returncode,flush=True)
 if p.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(steps) and all(r['exit_code']==0 for r in report['results']);save()
