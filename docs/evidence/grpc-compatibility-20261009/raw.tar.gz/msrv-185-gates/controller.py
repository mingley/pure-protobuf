import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf'); OUT=ROOT/'work/msrv-185-gates';OUT.mkdir(exist_ok=False)
FIXED=ROOT/'work/msrv-candidate-89ed'; BASE=ROOT/'work/resource-candidate-007'
steps=[('baseline_check',BASE,['check','--lib'],ROOT/'work/target-msrv-185-baseline'),('fixed_check',FIXED,['check','--lib'],ROOT/'work/target-msrv-185-fixed'),('fixed_unit',FIXED,['test','--lib'],ROOT/'work/target-msrv-185-fixed'),('fixed_early_upload',FIXED,['test','--test','early_upload_response'],ROOT/'work/target-msrv-185-fixed')]
env={**os.environ,'CARGO_HOME':str(ROOT/'work/toolchain/cargo'),'RUSTUP_HOME':str(ROOT/'work/toolchain/rustup'),'CARGO_BUILD_JOBS':'2'}
env['PATH']=str(ROOT/'work/toolchain/cargo/bin')+':'+env['PATH']
report={'qualified':False,'purpose':'native default feature MSRV and early-upload regression; expected old-source compiler rejection retained','steps':[]}
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
for name,cwd,args,target in steps:
 pin=subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)
 directory=OUT/name;directory.mkdir();argv=['cargo','+1.85.0',args[0],'--locked','-p','pbrs-grpc',*args[1:],'--target-dir',str(target),'--message-format=json']
 start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  p=subprocess.run(argv,cwd=cwd,env=env,stdout=out,stderr=err)
 row={'name':name,'source':pin,'source_directory':str(cwd),'argv':argv,'exit_code':p.returncode,'elapsed_seconds':time.monotonic()-start,'artifacts':[]}
 for line in (directory/'stdout').read_text().splitlines():
  try:message=json.loads(line)
  except json.JSONDecodeError:continue
  if message.get('reason')=='compiler-artifact' and message.get('manifest_path')==str(cwd/'pbrs-grpc/Cargo.toml'):
   item={'artifact':message}
   if message.get('executable'):
    path=Path(message['executable']);item['binary_sha256']=hashlib.sha256(path.read_bytes()).hexdigest();item['binary_bytes']=path.stat().st_size
   row['artifacts'].append(item)
 assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=cwd,text=True).strip()==pin and not subprocess.check_output(['git','status','--porcelain'],cwd=cwd,text=True)
 row['source_unchanged']=True;report['steps'].append(row);(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(name,p.returncode,flush=True)
 if name!='baseline_check' and p.returncode:break
report['state']='finished';report['passed']=len(report['steps'])==len(steps) and all(r['exit_code']==0 for r in report['steps'][1:]);(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
