#!/usr/bin/env python3
"""Focused standalone replay; creates only a temporary fixture, no cache/compiler."""
import hashlib, importlib.util, json, pathlib, sys, tempfile
helper=pathlib.Path(sys.argv[1])
spec=importlib.util.spec_from_file_location('retirement',helper)
h=importlib.util.module_from_spec(spec); spec.loader.exec_module(h)
with tempfile.TemporaryDirectory() as tmp:
 root=pathlib.Path(tmp); file=root/'tool'; file.write_bytes(b'fake tool bytes\n'); file.chmod(0o755)
 link=root/'python'; link.symlink_to('tool')
 value=h.tool_identity(link)
 assert value['symlink_target']=='tool' and value['resolved_path']==str(file)
 assert value['sha256']==hashlib.sha256(file.read_bytes()).hexdigest()
 source=h.source_input(link,None)
 assert source['kind']=='symlink' and source['link']=='tool' and source['resolved_sha256']==value['sha256']
 assert h.source_input(file,None)=={'kind':'regular','sha256':value['sha256']}
 try: h.file_sha(link)
 except RuntimeError: strict=True
 else: raise AssertionError('regular cache lstat/fstat check weakened')
print(json.dumps({'status':'pass','tool_and_source_symlink_cases':5,'cache_lstat_still_strict':strict,'helper_sha256':hashlib.sha256(helper.read_bytes()).hexdigest(),'compiler_invoked':False},indent=2))
