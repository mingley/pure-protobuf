# Completed-cache preservation and retirement proposal (read-only)

No archive or deletion has been performed or approved by this proposal. The
2026-10-03 05:15:57 UTC inventory reads filesystem metadata and four-byte ELF
magic, plus small source/manifest/log anchors. It does not hash cache payloads.
`inventory.json` holds every remaining regular path, inode/link/size/classification;
`summary.json`, `proc-locks.txt` and `visibility-errors-reviewed.json` hold the
inspection results and limitations. All source worktrees were clean.

## Ownership, historical results and accounting

| Namespace | Coordinator/owner | Source/result association | Unique allocated bytes | Logical bytes, aliases included |
| --- | --- | --- | ---: | ---: |
| `/workspace/pure-protobuf/target/semver-checks` | Root | Historical three final semver logs: each196 pass/58 skip/no update. Logs do not bind a historical provider commit; do not call these current-main acceptance. Six generated manifests/locks and three actual registry Cargo metadata graphs remain. | 2352930816 | 2648157280 |
| `/workspace/scratch/work/verify-main/target` | Root acceptance worktree, plus GN13-owned `shared-consumers` campaign | Clean detached `de0bcdf2dd55fa7f436139813a87b967187c8f5d`; multiple historical commands/campaigns share the cache. Preserve `main-gn11-remaining.log`, original retry red `main-tc30a-all-features.log` and both old executable-prune records. Current remaining contents cannot recreate previously deleted ELFs. | 5261049856 | 5856405881 |
| `/workspace/pure-protobuf/work/gn13/target` | GN13 | Clean current `1b050a3c399add82c5f85bd27ac528a8ca366dc9`; GN14/GN13 red/green/core/documentation/card logs remain in `work/logs`. This is a historical mixed consumer cache, not a current-main gate. | 544591872 | 600849338 |
| `/workspace/scratch/work/deadline-admission-native/target` | GN13 native caller | Clean docs tip `97d01c8e62b67b9cb55cadbedd966315908a34b0`; remaining `interop188` namespace was actually built with1.85 at `cc4db05383776ad39e8af34dee12a164b35ffcf2` (037 capture); `package-only-stable99` is the stable package capture at `d6c4ddde5b3079473c0ec431044c7de57c4c372d`. Namespace spelling does not establish toolchain. | 735670272 | 797332236 |
| `/workspace/scratch/work/cl07/target` | GN13 CL07/CL08 history | Clean `b073a5751b660494605334c9f8630525a1bb0e7a`; only two metadata files remain after previously recorded retirement. Immutable baseline/candidate binaries and historical evidence outside the target remain protected. | 8192 | 1473 |

Current root HEAD `613c25213025ca2a34c7303c6d49e7f739354481` is a context anchor,
not the historical semver compiler source. Source manifest/lock hashes for all
five namespaces are retained in `inventory.json/source_anchors`; preserve these
small files and the exact reachable source trees, with their source qualification
limits. Native remaining-cache raw provenance is in
`work/native-admission-gates/037-final-native-interop-build185.meta.json`
(SHA256 `d4eac183755865d0960587da1285d71b339e43cdea37a7d457ec8b11ca8d6b73`)
and `package-final-locked-stable99.meta.json`. Preserve existing native cleanup
records and final proof archives, not just the current cache.

The three actual registry metadata graph SHA256s are
`49b7abd7cd3d5d2eac4f70f1e17b8432d7b948311e1b237722bd20a4adad966b`
(grpc), `f4e23cf8d86ebe9aa42212d43b39be290882ea4aba49ac2386666f646074a69d`
(tonic), and `73e22998f3319fc33d059383b6ccc316a952b643f25bceea288d3de83382fedd`
(core). Their referenced registry build directories are not the three remaining
local build directories; record missing historical paths explicitly rather than
inventing an available baseline cache or source pin.

The RX runner sums regular-file logical lengths and conservatively counts
hardlink aliases. The three old owned nonempty roots therefore consume
1398183047 bytes, leaving749300601 bytes under the2147483648-byte cap, before
any fresh RX target. Earlier ~1.27GB `du` figures deduplicated hardlinks. Root's
semver and verify caches are not assigned to the RX owned-cache cap; they consume
the same global disk. No active RX cache exists. Live TC/other-agent targets,
shared SDK/Cargo registry, pinned protoc/conformance target, all work/bin ELF
copies, source worktrees, logs and committed evidence are excluded from retirement.

## Visibility and link constraints

All11 discovered `.cargo-lock` files were compared by device/inode with the
retained `/proc/locks` snapshot; none had a match. That is inspection, not an
exclusive retirement lock. Before mutation acquire all locks for the selected
namespace, retain them through verification/removal, and refresh process checks.
There are3 semver,4 verify,2 GN13 and2 native locks. Exact paths are in the report.

Visible non-inspector argv/cwd/exe/fd/maps matched none of the cache roots. The
first inspector saw301 permission errors:299 are zombie processes, and the other
two are root-owned dockerd/containerd. Their argv/state/UID records are retained;
unreadable root daemon fd/maps prevent a claim of universal process visibility.
Coordinator ownership confirmation and held locks are still necessary. No
cache-source compiler/consumer was visible. Inspection is point-in-time.

All hardlinks have all their reported aliases within their respective inventoried
cache; no unlocated external alias was found by comparing `st_nlink` with the
in-cache inode groups. Preserve hardlink topology and every alias path. Semver,
GN13 and native caches have no symlinks. Verify has exactly four external links:
`conformance-build` to the shared conformance directory and three
`custom-protoc-test-*/my-custom-protoc` links to shared protoc. Archive these as
symlinks without dereferencing. Removal unlinks only those cache entries; it must
never remove their targets. The cache-root paths themselves are real directories.

## Exact staged scope proposed for approval

1. Preserve semver first, then retire only
   `/workspace/pure-protobuf/target/semver-checks`, leaving the root `target/`
   and shared conformance build intact. Output would be a new uniquely named
   directory under `/workspace/pure-protobuf/work/cache-retirement/`.
   Preserve every ELF magic member regardless of mode/suffix, including objects
   and `.so`; every full `.fingerprint` tree, every full `build/` tree (including
   all generated `out`), every full `deps/` tree (rlib/rmeta included), dep-info,
   every JSON (including all semver rustdoc JSON and actual Cargo metadata),
   manifests/locks, cache top-level metadata and associated raw semver logs.
   This selection has4836 paths /1640200811 unique logical bytes before
   compression; category counts overlap. The remaining46 incremental/nonselected
   files must have exact hashes and explicit `hash_only` disposition, not be
   represented as archived payloads. Archive symlinks/hardlinks faithfully.
   If simpler, archiving all4882 remaining files is also faithful but its size
   must fit the same global reserve; do not assume a compression ratio.

2. Separately preserve and retire the old owned GN13 target and native caller
   target, in that order, before the RX benchmark build. Exact removable roots
   are `/workspace/pure-protobuf/work/gn13/target` and
   `/workspace/scratch/work/deadline-admission-native/target` only.
   Prefer full remaining-cache archives (1175 and1375 regular paths respectively)
   because these include generated consumer source and normalized packages.
   Retain current source/manifest/lock snapshots, all existing raw gates/ELFs/
   cleanup histories outside the targets, all full fingerprints/generated
   build/out/deps and every ELF object/shared library. Existing native proof
   archive/source labels remain unchanged. CL07's1473 logical bytes can remain
   accounted as historical metadata; no need to delete it for headroom.

3. Root may then preserve/retire only
   `/workspace/scratch/work/verify-main/target`, retaining its clean detached
   source worktree and every earlier raw/prune-history log. Preserve all10138
   remaining regular paths and four symlinks (full-cache archive is recommended
   here), including generated plugin/consumer source/manifests/locks, packaged
   payloads, build/out, full deps/fingerprints, doc output and all353 remaining
   ELF paths. State that35 native plus20 remaining earlier pruned ELFs listed in historical records
   are unavailable in this archive; neither a hash record nor this new archive
   recreates them. Do not dereference the shared links. This larger stage is
   optional for RX after the first two stages, depending on observed free disk.

For each authorized stage: hold locks and refreshed no-owner checks; compute a
complete path/link/hash manifest once, serialize the selected payloads with
bounded streaming compression, then independently re-read the archive and
compare every retained content/hash/link member against that manifest. Recheck
source/cache file hashes and absence of mutations before removal. Protect the
fixed2147483648-byte global reserve during hashing/compression by observing free
space periodically and bounding every write to remaining headroom. At05:15:57
free was3066724352 bytes: only919240704 bytes above reserve, not permission for
an unbounded intermediate tar or extracted validation copy. Validate by streaming
reads. Stop/retain a partial archive as an invalid preservation attempt if the
reserve cannot be maintained; delete nothing. Once verified, remove only the
approved cache namespace, verify preserved bytes afterward, and record before/
after free bytes and all lock/process/source dispositions. Compression sizes
and reclaim amounts are estimates until recorded, not promises.

No Cargo, compiler, benchmark, source edit or filesystem retirement was performed
by the housekeeping inspection. RX10 remains unqualified until the independent
baseline/candidate diagnostic and approved compiler gates run under a lease.
