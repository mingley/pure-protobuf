use bytes::Bytes;
use pbrs_grpc::{Channel,Code,HelloReply,HelloRequest,Request};
use std::time::Duration;

async fn rejected(status: Option<&'static str>, streaming: bool) -> pbrs_grpc::Status {
    tokio::time::timeout(Duration::from_secs(5), async {
        let listener=tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
        let address=listener.local_addr().unwrap();
        let server=tokio::spawn(async move {
            let (socket,_)=listener.accept().await.unwrap();
            let mut builder=h2::server::Builder::new();
            builder.initial_window_size(0);
            let mut connection=builder.handshake::<_,Bytes>(socket).await.unwrap();
            let (request,mut respond)=connection.accept().await.unwrap().unwrap();
            let mut response=http::Response::builder().status(200).header("content-type","application/grpc");
            if let Some(code)=status {response=response.header("grpc-status",code).header("grpc-message","busy").header("x-terminal","rejected");}
            let _send=respond.send_response(response.body(()).unwrap(),true).unwrap();
            drop(request);
            while let Some(r)=connection.accept().await {r.unwrap();}
        });
        let channel=Channel::connect(address).await.unwrap().max_send_buffer_size(16384);
        let mut message=HelloRequest::new();message.set_name("x".repeat(1048576));
        let mut request=Request::new(message);request.set_timeout(Duration::from_secs(3));
        let status=if streaming {channel.server_streaming::<_,HelloReply>("/helloworld.Greeter/ServerHello",request).await.unwrap_err()}
                   else {channel.unary::<_,HelloReply>("/helloworld.Greeter/SayHello",request).await.unwrap_err()};
        eprintln!("streaming={streaming}, peer={status:?}, cause={:?}",std::error::Error::source(&status));
        server.abort();status
    }).await.expect("rejection must not stall")
}
#[tokio::test]
async fn unary_preserves_early_overload() {assert_eq!(rejected(Some("8"),false).await.code(),Code::ResourceExhausted);}
#[tokio::test]
async fn server_stream_preserves_early_overload() {assert_eq!(rejected(Some("8"),true).await.code(),Code::ResourceExhausted);}
#[tokio::test]
async fn incomplete_upload_does_not_become_ok() {assert_eq!(rejected(Some("0"),false).await.code(),Code::Internal);}
#[tokio::test]
async fn missing_status_does_not_mask_upload_error() {assert_eq!(rejected(None,false).await.code(),Code::Internal);}
#[tokio::test]
async fn malformed_status_does_not_mask_upload_error() {assert_eq!(rejected(Some("broken"),false).await.code(),Code::Internal);}
