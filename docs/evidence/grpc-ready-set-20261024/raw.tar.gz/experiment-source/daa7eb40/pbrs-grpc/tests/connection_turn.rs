//! A DATA read should drive the RPC it wakes before parking the connection.
//!
//! Registry h2 is the peer. The native server future has no spawned driver:
//! every parent poll is explicit, including the one causal DATA-delivery poll.
#![allow(
    clippy::disallowed_types,
    clippy::expect_used,
    clippy::unwrap_used,
    clippy::panic,
    reason = "bounded independent-peer connection scheduling control"
)]

use bytes::Bytes;
use pbrs_grpc::{HelloReply, HelloRequest, Request, Response, Rpc, Server, Service, Status};
use std::future::{Future, pending, poll_fn};
use std::io;
use std::pin::Pin;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::sync::{Arc, Mutex};
use std::task::{Context, Poll, Wake, Waker};
use std::time::{Duration, Instant};
use tokio::io::{AsyncRead, AsyncWrite, DuplexStream, ReadBuf};

const WATCHDOG: Duration = Duration::from_secs(5);

#[derive(Default)]
struct Probe {
    target_entered: AtomicBool,
    target_handlers: AtomicUsize,
    recovery_handlers: AtomicUsize,
    parked_entered: AtomicBool,
    parked_polls: AtomicUsize,
}

struct SplitBody(Arc<Probe>);

impl Service for SplitBody {
    const NAME: &'static str = "turn.SplitBody";

    fn call(&self, rpc: Rpc) -> impl Future<Output = ()> + Send {
        let parked = rpc.method() == "Park";
        let recovery = rpc.method() == "Recovery";
        let probe = Arc::clone(&self.0);
        let polls = Arc::clone(&self.0);
        let work = async move {
            if parked {
                probe.parked_entered.store(true, Ordering::SeqCst);
                pending::<()>().await;
                drop(rpc);
            } else {
                if !recovery {
                    probe.target_entered.store(true, Ordering::SeqCst);
                }
                rpc.unary(move |_: Request<HelloRequest>| async move {
                    if recovery {
                        probe.recovery_handlers.fetch_add(1, Ordering::SeqCst);
                    } else {
                        probe.target_handlers.fetch_add(1, Ordering::SeqCst);
                    }
                    Ok::<_, Status>(Response::new(HelloReply::new()))
                })
                .await;
            }
        };
        async move {
            tokio::pin!(work);
            poll_fn(|cx| {
                if parked {
                    polls.parked_polls.fetch_add(1, Ordering::SeqCst);
                }
                work.as_mut().poll(cx)
            })
            .await;
        }
    }
}

struct ReadGate {
    io: DuplexStream,
    open: Arc<AtomicBool>,
    read_bytes: Arc<AtomicUsize>,
}

impl AsyncRead for ReadGate {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        if !self.open.load(Ordering::SeqCst) {
            return Poll::Pending;
        }
        let before = buf.filled().len();
        let result = Pin::new(&mut self.io).poll_read(cx, buf);
        self.read_bytes
            .fetch_add(buf.filled().len() - before, Ordering::SeqCst);
        result
    }
}

impl AsyncWrite for ReadGate {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        bytes: &[u8],
    ) -> Poll<io::Result<usize>> {
        Pin::new(&mut self.io).poll_write(cx, bytes)
    }

    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.io).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.io).poll_shutdown(cx)
    }

    fn is_write_vectored(&self) -> bool {
        self.io.is_write_vectored()
    }

    fn poll_write_vectored(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        bufs: &[io::IoSlice<'_>],
    ) -> Poll<io::Result<usize>> {
        Pin::new(&mut self.io).poll_write_vectored(cx, bufs)
    }
}

#[derive(Default)]
struct PeerWrites(Mutex<Vec<u8>>);

impl PeerWrites {
    fn append(&self, bytes: &[u8]) {
        let mut written = self.0.lock().unwrap();
        assert!(written.len() + bytes.len() <= 65536, "bounded wire witness");
        written.extend_from_slice(bytes);
    }

    fn complete_data_for(&self, wanted: u32) -> bool {
        let written = self.0.lock().unwrap();
        let mut at = 24; // The registry client writes the HTTP/2 preface first.
        while let Some(header) = written.get(at..at + 9) {
            let [hi, mid, lo, kind, _flags, id0, id1, id2, id3]: [u8; 9] =
                header.try_into().unwrap();
            let len = (usize::from(hi) << 16) | (usize::from(mid) << 8) | usize::from(lo);
            let end = at + 9 + len;
            if end > written.len() {
                return false;
            }
            let stream = u32::from_be_bytes([id0, id1, id2, id3]) & 0x7fff_ffff;
            if kind == 0 && stream == wanted {
                return true;
            }
            at = end;
        }
        false
    }
}

struct WriteWitness {
    io: DuplexStream,
    written: Arc<PeerWrites>,
}

impl AsyncRead for WriteWitness {
    fn poll_read(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        buf: &mut ReadBuf<'_>,
    ) -> Poll<io::Result<()>> {
        Pin::new(&mut self.io).poll_read(cx, buf)
    }
}

impl AsyncWrite for WriteWitness {
    fn poll_write(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        bytes: &[u8],
    ) -> Poll<io::Result<usize>> {
        let result = Pin::new(&mut self.io).poll_write(cx, bytes);
        if let Poll::Ready(Ok(n)) = result {
            self.written.append(bytes.get(..n).unwrap());
        }
        result
    }

    fn poll_flush(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.io).poll_flush(cx)
    }

    fn poll_shutdown(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<io::Result<()>> {
        Pin::new(&mut self.io).poll_shutdown(cx)
    }

    fn is_write_vectored(&self) -> bool {
        self.io.is_write_vectored()
    }

    fn poll_write_vectored(
        mut self: Pin<&mut Self>,
        cx: &mut Context<'_>,
        bufs: &[io::IoSlice<'_>],
    ) -> Poll<io::Result<usize>> {
        let result = Pin::new(&mut self.io).poll_write_vectored(cx, bufs);
        if let Poll::Ready(Ok(mut n)) = result {
            for buf in bufs {
                let take = n.min(buf.len());
                self.written.append(buf.get(..take).unwrap());
                n -= take;
                if n == 0 {
                    break;
                }
            }
        }
        result
    }
}

#[derive(Default)]
struct CountWake(AtomicUsize);

impl Wake for CountWake {
    fn wake(self: Arc<Self>) {
        self.0.fetch_add(1, Ordering::SeqCst);
    }

    fn wake_by_ref(self: &Arc<Self>) {
        self.0.fetch_add(1, Ordering::SeqCst);
    }
}

struct Driver<F> {
    future: Pin<Box<F>>,
    wake: Arc<CountWake>,
    polls: usize,
}

impl<F: Future<Output = Result<(), Status>>> Driver<F> {
    fn poll_once(&mut self) {
        self.polls += 1;
        let waker = Waker::from(Arc::clone(&self.wake));
        let mut cx = Context::from_waker(&waker);
        assert!(
            self.future.as_mut().poll(&mut cx).is_pending(),
            "the server must remain live while its parked sibling is admitted"
        );
    }

    async fn until(&mut self, condition: impl Fn() -> bool) {
        let started = Instant::now();
        while !condition() {
            assert!(started.elapsed() < WATCHDOG, "manual server watchdog");
            self.poll_once();
            tokio::task::yield_now().await;
        }
    }

    async fn drive<T>(&mut self, future: impl Future<Output = T>) -> T {
        tokio::pin!(future);
        let started = Instant::now();
        loop {
            assert!(started.elapsed() < WATCHDOG, "manual server watchdog");
            self.poll_once();
            if let Poll::Ready(value) = poll_fn(|cx| Poll::Ready(future.as_mut().poll(cx))).await {
                return value;
            }
            tokio::task::yield_now().await;
        }
    }
}

struct AbortOnDrop(tokio::task::JoinHandle<()>);

impl Drop for AbortOnDrop {
    fn drop(&mut self) {
        self.0.abort();
    }
}

async fn check_response<F: Future<Output = Result<(), Status>>>(
    driver: &mut Driver<F>,
    response: h2::client::ResponseFuture,
) {
    let response = driver.drive(response).await.unwrap();
    assert_eq!(response.status(), http::StatusCode::OK);
    let initial = response.headers().get("grpc-status").cloned();
    let mut body = response.into_body();
    let mut encoded = Vec::new();
    while let Some(bytes) = driver.drive(body.data()).await {
        let bytes = bytes.unwrap();
        encoded.extend_from_slice(&bytes);
        body.flow_control().release_capacity(bytes.len()).unwrap();
    }
    let trailers = driver.drive(body.trailers()).await.unwrap();
    let code = initial
        .or_else(|| trailers.and_then(|mut headers| headers.remove("grpc-status")))
        .expect("explicit grpc-status");
    assert_eq!(code, "0");
    assert_eq!(encoded, [0, 0, 0, 0, 0], "one complete empty HelloReply");
}

fn request(method: &str) -> http::Request<()> {
    http::Request::builder()
        .method("POST")
        .uri(format!("http://local/turn.SplitBody/{method}"))
        .header("content-type", "application/grpc")
        .header("te", "trailers")
        .body(())
        .unwrap()
}

#[tokio::test]
async fn data_read_drives_only_its_woken_rpc_in_the_same_parent_poll() {
    let probe = Arc::new(Probe::default());
    let gate = Arc::new(AtomicBool::new(true));
    let read_bytes = Arc::new(AtomicUsize::new(0));
    let written = Arc::new(PeerWrites::default());
    let (client_io, server_io) = tokio::io::duplex(4096);
    let server = Server::new(SplitBody(Arc::clone(&probe))).max_concurrent_rpcs(2);
    let mut driver = Driver {
        future: Box::pin(server.serve_connection(ReadGate {
            io: server_io,
            open: Arc::clone(&gate),
            read_bytes: Arc::clone(&read_bytes),
        })),
        wake: Arc::new(CountWake::default()),
        polls: 0,
    };
    let (mut send, connection) = driver
        .drive(h2::client::handshake(WriteWitness {
            io: client_io,
            written: Arc::clone(&written),
        }))
        .await
        .unwrap();
    let _client = AbortOnDrop(tokio::spawn(async move {
        let _closed = connection.await;
    }));

    send = driver.drive(send.ready()).await.unwrap();
    let (_park_response, _park_send) = send.send_request(request("Park"), true).unwrap();
    driver
        .until(|| probe.parked_entered.load(Ordering::SeqCst))
        .await;
    send = driver.drive(send.ready()).await.unwrap();
    let (response, mut body) = send.send_request(request("Target"), false).unwrap();
    driver
        .until(|| probe.target_entered.load(Ordering::SeqCst))
        .await;
    assert_eq!(probe.target_handlers.load(Ordering::SeqCst), 0);

    // Park with admitted HEADERS and an unread body. The registry client may
    // write DATA into the duplex buffer, but the native transport cannot read it.
    gate.store(false, Ordering::SeqCst);
    let target_stream = body.stream_id().as_u32();
    body.send_data(Bytes::from_static(&[0, 0, 0, 0, 0]), true)
        .unwrap();
    let started = Instant::now();
    while !written.complete_data_for(target_stream) {
        assert!(started.elapsed() < WATCHDOG, "peer DATA write watchdog");
        tokio::task::yield_now().await;
    }
    driver.poll_once();
    assert_eq!(probe.target_handlers.load(Ordering::SeqCst), 0);
    let parked_before = probe.parked_polls.load(Ordering::SeqCst);
    let reads_before = read_bytes.load(Ordering::SeqCst);
    let polls_before = driver.polls;
    let wakes_before = driver.wake.0.load(Ordering::SeqCst);

    gate.store(true, Ordering::SeqCst);
    driver.poll_once(); // The sole causal parent poll after exposing complete DATA.
    let same_turn = probe.target_handlers.load(Ordering::SeqCst);
    let parked_after = probe.parked_polls.load(Ordering::SeqCst);
    let read_delta = read_bytes.load(Ordering::SeqCst) - reads_before;
    let poll_delta = driver.polls - polls_before;
    let wake_delta = driver.wake.0.load(Ordering::SeqCst) - wakes_before;

    // Finish both successful exchanges before the final scheduling assertion.
    // A detecting baseline must still prove framing and same-connection recovery.
    check_response(&mut driver, response).await;
    send = driver.drive(send.ready()).await.unwrap();
    let (recovery, mut body) = send.send_request(request("Recovery"), false).unwrap();
    body.send_data(Bytes::from_static(&[0, 0, 0, 0, 0]), true)
        .unwrap();
    check_response(&mut driver, recovery).await;
    assert_eq!(probe.target_handlers.load(Ordering::SeqCst), 1);
    assert_eq!(probe.recovery_handlers.load(Ordering::SeqCst), 1);
    eprintln!(
        "connection turn witness: parent_polls={poll_delta} read_bytes={read_delta} parent_wakes={wake_delta} same_turn_handlers={same_turn} parked_polls={parked_before}->{parked_after} target_status=0 recovery_status=0"
    );
    assert_eq!(poll_delta, 1);
    assert!(
        read_delta >= 14,
        "the causal parent poll consumed the DATA frame"
    );
    assert_eq!(
        parked_after, parked_before,
        "an unwoken sibling stays asleep"
    );
    assert_eq!(
        same_turn, 1,
        "DATA must drive its newly woken RPC before parking"
    );
}
