#!/usr/bin/env python3
"""Read-only C14 shipping comparison; no capture, build or promotion action."""
import datetime
import hashlib
import json
from pathlib import Path
import statistics

Q=Path('/workspace/pure-protobuf/work/qualification')
P=Q/'architecture-c14-shipping-captures'

def ref(p):
    p=Path(p)
    return dict(path=str(p),bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())


def ranges(samples):
    return dict(min=min(samples),median=statistics.median(samples),max=max(samples),all_repeats=samples)


def main():
    state=json.loads((P/'state.json').read_text())
    summary=json.loads((P/'shipping-summary.json').read_text())
    execution=json.loads((Q/'resource-c14-shipping-execution.json').read_text())
    assert state['passed'] and len(state['completed'])==48 and execution['exit_code']==0
    assert all(t[k]==180000 for t in state['actual_rpc_totals'].values() for k in ('offered_rpcs','dispatched_rpcs','completed_rpcs','successful_rpcs'))
    assert all(t[k]==0 for t in state['actual_rpc_totals'].values() for k in ('failed_rpcs','timeouts','queue_overflows','unstarted_rpcs','unfinished_rpcs'))
    raw=[]
    for r in summary['derived_captures']:
        if r['rpc_count']!=10000:continue
        endpoints={}
        for side,prefix in [('client','client_lifetime'),('server','server_client_window')]:
            endpoints[side]={part+'_us_per_rpc':r[prefix+'_'+part+'_ticks']*10000/r['rpc_count'] for part in ('user','system','cpu')}
        raw.append(dict(version=r['version'],cell=r['cell'],rpc_count=10000,
            endpoints=endpoints,server_window_ns=r['server_client_window_duration_ns'],
            throughput_qps=r['metrics']['throughput_qps'],
            service_p50_ns=r['metrics']['service_latency_nanos']['p50_nanos'],
            service_p99_ns=r['metrics']['service_latency_nanos']['p99_nanos'],
            run=ref(r['raw_capture'])))
    assert len(raw)==24
    source_ranges=[]
    for g in summary['source_cpu_comparisons']:
        source_ranges.append(dict(scope=g['scope'],side=g['side'],
            baseline_cpu_us_per_rpc_slope=ranges([s['baseline']['cpu_seconds_per_rpc_slope']*1e6 for s in g['samples']]),
            candidate_cpu_us_per_rpc_slope=ranges([s['candidate']['cpu_seconds_per_rpc_slope']*1e6 for s in g['samples']]),
            ratios=dict(min=g['ratio_min'],median=g['ratio_median'],max=g['ratio_max'],all_repeats=[s['ratio'] for s in g['samples']]),
            resolved_repeats=g['available_repeats'],unresolved_repeats=g['unresolved_repeats']))
    assert len(source_ranges)==12
    negatives=[r for r in summary['cpu_slopes'] if r['user_seconds_per_rpc_slope']<0 or r['system_seconds_per_rpc_slope']<0]
    result=dict(schema='pbrs.c14-shipping-analysis.v1',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
        qualified=False,production_ready=False,timing_qualified=False,
        adoption_decision='DEFER: no consistent physical CPU benefit; experimental C14 remains unadopted, main runtime 933bf unchanged.',
        helper=ref(Path(__file__).resolve()),state=ref(P/'state.json'),summary=ref(P/'shipping-summary.json'),
        execution=ref(Q/'resource-c14-shipping-execution.json'),source_freeze=ref(Q/'architecture-c14-shipping-source-freeze.json'),
        host_before=ref(Q/'resource-c14-shipping-host-before.json'),host_after=ref(Q/'resource-c14-shipping-host-after.json'),
        actual_rpc_totals=state['actual_rpc_totals'],raw_n_10000=raw,all_source_cpu_ranges=source_ranges,
        all_cpu_slopes=summary['cpu_slopes'],all_same_side_tonic_cpu_comparisons=summary['same_side_tonic_cpu_comparisons'],
        negative_component_rows=negatives,nonpositive_total_rows=[r for r in summary['cpu_slopes'] if not r['resolved_positive_slope']],
        limits=['All endpoint/source/Tonic increases and both repeats retained without thresholds.',
                'Server client-window CPU and client process-lifetime CPU are distinct scopes including setup/reporting.',
                'N/2N subtraction assumes stable work; 10ms ticks and two repeats limit interpretation.',
                'Same-turn causal fixture success does not establish a CPU or task-wake reduction.',
                'Quiet known-process checks do not prove a dedicated host or broad production superiority.'])
    out=Q/'architecture-c14-shipping-analysis.json'
    with out.open('x') as f:json.dump(result,f,indent=2,allow_nan=False);f.write('\n')
    print(json.dumps(ref(out)))
    for g in source_ranges:
        print(g['scope']['shape'],g['scope']['pair'],g['side'],g['baseline_cpu_us_per_rpc_slope']['all_repeats'],g['candidate_cpu_us_per_rpc_slope']['all_repeats'],g['ratios']['all_repeats'])

if __name__=='__main__':main()
