# C14 shipping comparison — prepared only

Compare the frozen C13 933bf shipping binary with the future clean C14 drain-first V2 commit. No C14 worktree creation, build or capture is authorized by this preparation. Candidate source and checkout remain null in the template until Root commits and freezes them.

## Scope

- Feature-off release binary. Reuse the unchanged C13 builder/validator (SHA a7aa4c07...) and unchanged shipping capture adapter (SHA b3c9ed17...).
- Identity 1 KiB unary and four-message bidi; native-Prost client/Tonic-Prost server, Tonic-Prost client/native-Prost server, and Tonic/Tonic.
- N=5,000/10,000; two balanced repeats; two sources. **48 captures / 360,000 RPCs**, 180,000 per source.
- Adjacent pair controls within each shape/repeat. Pair order reverses on repeat 1. Source/count order is A5k,A10k,B5k,B10k then B10k,B5k,A10k,A5k.
- Same worker count, queues, buffers, compression, timeouts, connection/in-flight count and harness. No allocation counter or profiler. Syscall controls remain separate and need their own grant.

Both source builds must be clean, Rust/Cargo 1.99.1, identical feature-off command/profile, locks and benchmark subtree. Source comparison allows exactly `pbrs-grpc/src/server/connection.rs` and new `pbrs-grpc/tests/connection_turn.rs`. Candidate production SHA must be b405df0bf224567d887f7dbebb098a207f8d13a37d7b33cffe3677470daa8047; fixture SHA a05894aec2de529975096560c960a950297edce38ea0d0e57433edd13008b7dd. A later V2 revision needs a new preparation generation, not rewritten frozen evidence.

The same-turn RED→GREEN witness is not a speed result. Parent notifications can rise and already queued Tokio work may remain. Retain all zero, negative, mixed, and higher-cost CPU results. Do not claim an optimization without consistent actual CPU improvement. Deferred connection-wake forwarding would be a separate design with a separate correctness model.

## Existing baseline

- Source: 933bf8775b70d24d91fb46a7992eae343b60f0ea, clean `work/architecture-c13-batch`.
- Build record: `work/qualification/architecture-c13-shipping-batch-build/build.json`, SHA 552b1395823f109550b2b2f737f8310b633f33ce05af1580161df30fa8b35d3a.
- Copied ELF: same folder `rpc-bench`, SHA adc47ab79de96866d2a5bd62b66f7255c36cd1af56935035961a563eb1511b6f.

No baseline rebuild is planned. Actual baseline validator and adapter checks pass during preparation.

## Build command after Root freezes and grants

Substitute the actual clean candidate checkout and full commit; these placeholders deliberately prevent launching an unfrozen source.

```sh
env PYTHONOPTIMIZE=0 RUSTUP_TOOLCHAIN=stable \
  CARGO_TARGET_DIR=/workspace/pure-protobuf/work/rpc-target CARGO_BUILD_JOBS=1 \
  /workspace/pure-protobuf/work/run-rust python3 \
  /workspace/pure-protobuf/work/qualification/architecture-c13-build-shipping-rpc.py \
  --source-checkout ACTUAL_FROZEN_C14_CHECKOUT --source ACTUAL_FULL_C14_COMMIT \
  --output /workspace/pure-protobuf/work/qualification/architecture-c14-shipping-candidate-build \
  --execute
```

Use a unique `resource-c14-shipping-candidate-build-execution` receipt through `work/record.py`, exclusive build output, jobs=1, and the existing warm rpc-target cache. No cleanup or other compiler overlap unless Root grants it. `work/run-rust` executes its arguments directly; do not add a bare `stable` argument. The explicit environment selects the compiler.

## Capture command after build validation and a quiet-window grant

Create a new `architecture-c14-shipping-sources.json` from the preserved template with actual commit/checkout. Do not rewrite the template or prior results.

```sh
env PYTHONOPTIMIZE=0 python3 \
  /workspace/pure-protobuf/work/qualification/architecture-c14-shipping-paired.py \
  --sources /workspace/pure-protobuf/work/qualification/architecture-c14-shipping-sources.json \
  --output /workspace/pure-protobuf/work/qualification/architecture-c14-shipping-captures \
  --execute
```

Use unique `resource-c14-shipping-execution` receipt and before/after host metadata: actual CPU quota/HZ, readable known-process scan and its limits, actual background phase status. A quiet grant does not establish a dedicated host. Stop the first failed capture or source/tool/harness check and preserve its state and raw output. Never silently retry or overwrite.

## Analysis

Preserve all offered/dispatched/completed/successful/failed/timeout/overflow/unstarted/unfinished counts. Each source must finish exactly 180,000 successful RPCs with all failure counters zero.

Retain raw user/system process ticks, full latency histograms, server observation windows and client lifetime scopes. N/2N summaries expose total/user/system slopes; nonpositive combined slopes remain recorded and comparison ratios unresolved. The summary also keeps every derived capture. Standalone latency/rate observations are retained; never subtract quantiles or throughput across counts.

TT source controls remain visible. Compare actual source CPU and each native endpoint with its fresh same-side TT reference. A physical CPU result can disagree with instruction or wake-count results. No broad production-readiness or superiority claim follows from this small two-shape diagnostic.

## Preparation

`architecture-c14-shipping-prepared.json` pins the new controller, exact source diff, existing builder/adapter/baseline proofs and template. The prepared controller is SHA 299494a13f55dcd81c54e692f413a0553e40c35cc61385b2e0e18f7ab1e4e346. Synthetic summary validation used retained C13 records only: 48 cooked capture rows and 48 CPU slopes; a negative-slope control remains negative with comparison unresolved. No endpoint or Cargo invocation occurred.
