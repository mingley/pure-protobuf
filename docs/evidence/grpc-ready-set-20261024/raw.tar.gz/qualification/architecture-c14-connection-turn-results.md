# Connection turn experiment

Baseline: `933bf8775b70d24d91fb46a7992eae343b60f0ea`.
Final experimental source: `daa7eb4074d654849d4206473250933666994adb`.
Root committed only `pbrs-grpc/src/server/connection.rs` and the new
`pbrs-grpc/tests/connection_turn.rs` in the isolated checkout. No Root production
source was changed by this lane; no shipping performance claim is made.

| Actual phase | Result |
|---|---|
| Baseline causal fixture | **0 passed / 1 failed**, at the final same-parent-poll assertion only |
| First candidate | **87 passed / 0 failed**: one causal test plus 86 existing controls |
| Final drain-first candidate | **87 passed / 0 failed**, identical fixture and scopes |
| Final formatting / whitespace | Passed |

In the one causal parent poll, the baseline reads all **14 DATA-frame bytes** but
calls the target handler **zero** times. Both candidates call it **once**. The
unwoken parked sibling remains at **one poll**. Before the final detecting
assertion, every phase completes the target and same-connection recovery with
HTTP 200, explicit grpc-status 0, and exactly one complete empty HelloReply frame.
There was no gate, phase, wire or recovery failure in the actual baseline red.

The final candidate preserves the existing Pending-branch drain priority. It
rechecks the admitted ready set after HTTP/2 Pending and returns the existing Tick
on completion. Tracked-future destruction still owns permit release; sleeping
handlers are not scanned. Existing controls cover peer reset, deadlines, committed
status, inlet ownership, bidi completion, admission, readiness and graceful drain.
Full counts, commands, source snapshots, ELF hashes, before/after source checks,
formatting and logs are bound by `architecture-c14-connection-turn-results.json`.
Baseline and both candidate records remain separate; the repeated 87-test phases
must not be summed as 174 independent tests.

This changes only the steady branch. A self-waking Pending handler can be polled
again in another ready-set fairness slice, and open streaming output may still
require a later driver poll. Already queued task notifications can remain. The
critical-poll wake counts (baseline 1, candidates 2) cover different completed work
and establish no whole-RPC wake, syscall or CPU saving. Actual feature-off shipping
comparisons are separate work. No candidate full-workspace, sanitizer, platform,
resource-day, universal same-turn or broad-superiority qualification is claimed.
