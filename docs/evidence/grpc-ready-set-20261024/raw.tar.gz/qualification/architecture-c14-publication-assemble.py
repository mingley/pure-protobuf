import datetime
import hashlib
import json
from pathlib import Path

Q = Path('/workspace/pure-protobuf/work/qualification')
BASE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
CANDIDATE = 'daa7eb4074d654849d4206473250933666994adb'


def ref(name):
    path = Q / name
    return {'path': str(path), 'bytes': path.stat().st_size,
            'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}


def archived(name):
    row = ref(name)
    row.update(path='work/qualification/' + name, archive_path='qualification/' + name)
    return row


def save(name, value):
    with (Q / name).open('x') as output:
        json.dump(value, output, indent=2)
        output.write('\n')


prepared = json.loads((Q / 'architecture-c14-package-prepared-v2.json').read_text())
for row in prepared['files']:
    assert ref(Path(row['path']).relative_to(Q).as_posix()) == row

decision = json.loads((Q / 'architecture-c14-package-decision-template.json').read_text())
decision.update(
    root_decision='defer',
    root_decision_reason='The causal control passes, but the matched shipping comparison shows no consistent physical CPU benefit. Native server and Tonic control results vary; retain the experiment and keep the qualified runtime unchanged.',
    root_runtime_source=BASE,
    causal_results=ref('architecture-c14-connection-turn-results.json'),
    shipping_state=ref('architecture-c14-shipping-captures/state.json'),
    shipping_summary=ref('architecture-c14-shipping-captures/shipping-summary.json'),
    shipping_analysis=ref('architecture-c14-shipping-analysis.json'),
    shipping_completion=ref('architecture-c14-shipping-completion.json'),
    state='final_root_decision', root_reviewed=True,
    created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
save('architecture-c14-publication-decision.json', decision)
records = [
    'architecture-c14-publication-decision.json',
    'architecture-c14-connection-turn-results.json',
    'architecture-c14-shipping-analysis.json',
    'architecture-c14-shipping-completion.json',
    'architecture-c14-shipping-captures/state.json',
    'architecture-c14-shipping-captures/shipping-summary.json',
    'architecture-c14-shipping-findings.md',
    'architecture-c14-shipping-source-freeze.json',
    'architecture-c14-package-prepared-v2.json',
]
rows = [('unary', 1, 47, 49), ('unary', 2, 49, 43),
        ('bidi', 1, 108, 108), ('bidi', 2, 149, 162)]
results = {
    'schema': 'pbrs.grpc-ready-set-experiment.v1',
    'created_utc': decision['created_utc'],
    'qualified': False, 'production_ready': False, 'broad_superiority_proven': False,
    'baseline': BASE, 'candidate': CANDIDATE, 'root_runtime_source': BASE,
    'root_decision': 'defer', 'reason': decision['root_decision_reason'],
    'qualification': decision['source_qualification'],
    'causal': {
        'baseline_passed': 0, 'baseline_failed': 1,
        'v1_passed': 87, 'v2_passed': 87, 'v2_failed': 0,
        'witness': 'One parent poll reads complete DATA and executes its newly ready handler; an unwoken sibling remains parked. Wire output/status and same-connection recovery pass before detection.',
        'limits': [
            'Observed parent wakes rise from one to two; no notification-reduction proof.',
            'The extra ready-set poll restarts one fairness slice; no universal same-turn or noncooperative-handler guarantee.',
            'Drain priority preserved; nonsteady paths unchanged.',
        ],
    },
    'shipping': {
        'captures': 48, 'successful_rpcs': 360000, 'failed_rpcs': 0,
        'rpc_counts': [5000, 10000], 'repeats': 2,
        'allocation_counts': False, 'timing_qualified': False,
        'native_server_raw_cpu_us_per_rpc_at_10000': [
            {'shape': shape, 'repeat': repeat, 'baseline': before, 'candidate': after,
             'change_percent': (after / before - 1) * 100}
            for shape, repeat, before, after in rows
        ],
        'native_server_cpu_slopes_us_per_rpc': {
            'unary': {'baseline': [32, 62], 'candidate': [54, 44]},
            'bidi': {'baseline': [78, 138], 'candidate': [76, 168]},
        },
    },
    'limits': [
        'Full source/control comparisons, histograms, user/system components and signed slopes remain in the archived original summary.',
        'Shared host, two repeats and 10 ms process ticks limit interpretation.',
        'Server client-window CPU and client process-lifetime CPU have different setup/reporting scopes.',
        'No C14 syscall tracing; previous C13 traces cannot establish a C14 reduction.',
        'C13 workspace, sanitizer, conformance and resource qualification does not qualify this experimental source.',
        'ELF bytes omitted; build/source/tool hashes and command logs remain.',
    ],
    'records': {name: archived(name) for name in records},
}
save('architecture-c14-publication-results.json', results)
readme = '''# Ready-set experiment: adoption deferred

The recheck passes its scheduling control, but has **no consistent measured CPU
benefit**. It remains experimental. The qualified runtime stays at `933bf877`;
`daa7eb40` is the isolated candidate.

## What changed

After protocol input returns Pending, poll newly ready RPCs once before parking.
Keep the existing drain priority. A gated independent HTTP/2 peer proves that one
parent poll reads complete DATA and runs the target handler; an unwoken sibling
stays asleep. Valid status/body and same-connection recovery pass before detection.

The baseline fails that final assertion. Both candidate variants pass **87 focused
checks**; the final variant also passes formatting. Parent wakes rise from one to
two in the fixture. Same-turn progress does not prove fewer notifications or speed.

## Release-build CPU

**Microseconds/call, lower is better.** Identity 1 KiB, one connection / one call
in flight, two repeats, counters and profilers off. Raw process CPU at 10,000 calls:

| Native server | Repeat | Baseline | Candidate | Change |
|---|---:|---:|---:|---:|
| Unary | 1 | 47 µs | 49 µs | +4.26% |
| Unary | 2 | 49 µs | 43 µs | −12.24% |
| Bidi | 1 | 108 µs | 108 µs | 0.00% |
| Bidi | 2 | 149 µs | 162 µs | +8.72% |

The campaign completes **48 captures / 360,000 successful RPCs**, zero failures.
Unary-server N/2N slopes are 32→54 and 62→44 µs/RPC; bidi slopes are 78→76 and
138→168. Tonic controls also vary substantially. All endpoint/control results,
user/system components, histograms and higher costs remain in the raw record.
This shared-host comparison does not establish broad performance superiority.

## Decision and verification

Defer adoption. Any deferred wake-forwarding design needs its own race model,
correctness controls and physical CPU comparison. C13 qualification belongs to
[its recorded source](../grpc-ownership-20261024/README.md), not this candidate.

[Results and source pins](results.json) · [Manifest](manifest.json) ·
[Raw source, commands, controls and captures](raw.tar.gz)

Run `python3 check.py` to verify member/publication hashes without extraction.
ELF bytes are omitted; recorded build and executable hashes remain. These results
do not certify production readiness.
'''
with (Q / 'architecture-c14-publication-README.md').open('x') as output:
    output.write(readme)
print(json.dumps({name: ref(name) for name in (
    'architecture-c14-publication-decision.json',
    'architecture-c14-publication-results.json', 'architecture-c14-publication-README.md')}, indent=2))
