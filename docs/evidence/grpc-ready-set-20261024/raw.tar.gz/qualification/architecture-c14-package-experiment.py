#!/usr/bin/env python3
"""Prepare/freeze a C14 experiment inventory; package only after Root's grant."""
import argparse
import datetime
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import stat
import subprocess
import tarfile
import tempfile

if not __debug__:
    raise RuntimeError("ordinary Python required; assertion gates must remain enabled")
ROOT = Path('/workspace/pure-protobuf')
Q = ROOT / 'work/qualification'
DEST = ROOT / 'docs/evidence/grpc-ready-set-20261024'
BASE = '933bf8775b70d24d91fb46a7992eae343b60f0ea'
CANDIDATE = 'daa7eb4074d654849d4206473250933666994adb'
PRODUCTION = 'pbrs-grpc/src/server/connection.rs'
FIXTURE = 'pbrs-grpc/tests/connection_turn.rs'
PRODUCTION_SHA = 'b405df0bf224567d887f7dbebb098a207f8d13a37d7b33cffe3677470daa8047'
FIXTURE_SHA = 'a05894aec2de529975096560c960a950297edce38ea0d0e57433edd13008b7dd'
SCRIPT = Path(__file__).resolve()
CHECKER = Q / 'architecture-c14-package-check.py'
PREFIXES = ('architecture-c14', 'resource-c14')
OWN_PREFIXES = ('architecture-c14-package-', 'resource-c14-package-')
MAGICS = (b'\x7fELF', b'MZ', b'\xcf\xfa\xed\xfe', b'\xfe\xed\xfa\xcf', b'\xca\xfe\xba\xbe', b'!<arch>\n')
DEPENDENCIES = ('architecture-c13-build-shipping-rpc.py', 'architecture-c13-shipping-smoke.py',
                'architecture-c13-shipping-batch-build/build.json')


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True) + '\n').encode()


def digest(path):
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return value.hexdigest()


def ref(path):
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest(path)}


def regular(path):
    assert not path.is_symlink() and path.is_file(), path
    return path


def safe(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and str(path) == name and not any(part in ('.', '..') for part in path.parts) and '\\' not in name and ':' not in name


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def read_ref(row):
    path = Path(row['path']).absolute()
    assert path.is_relative_to(Q) and path.resolve(strict=True).is_relative_to(Q.resolve())
    regular(path)
    assert ref(path) == row, 'changed reference: ' + str(path)
    return json.loads(path.read_text())


def decision(path):
    regular(path)
    assert path.parent.resolve() == Q and path.name.startswith('architecture-c14-')
    value = json.loads(path.read_text())
    assert value['schema'] == 'pbrs.grpc-ready-set-decision.v1'
    assert value['qualified'] is False and value['production_ready'] is False
    assert value['baseline'] == BASE and value['candidate'] == CANDIDATE
    assert value['root_decision'] in ('adopt', 'reject', 'defer') and value['root_decision_reason'].strip()
    assert re.fullmatch('[0-9a-f]{40}', value['root_runtime_source'])
    assert value['source_qualification']['source'] == BASE
    assert value['source_qualification']['applies_to_candidate'] is False
    causal = read_ref(value['causal_results'])
    assert causal['source_base'] == BASE and causal['root_experimental_commit'] == CANDIDATE
    assert causal['qualified'] is False and causal['drain_priority_candidate']['scope_total_passed'] == 87
    state = read_ref(value['shipping_state'])
    assert state['state'] in ('finished', 'failed'), 'physical CPU campaign still active'
    assert state['qualified'] is False and state['production_ready'] is False
    assert state['builds']['baseline']['source']['commit'] == BASE
    assert state['builds']['candidate']['source']['commit'] == CANDIDATE
    if state['state'] == 'finished':
        assert state['passed'] is True and value['shipping_summary'] == state['summary']
    if value['shipping_summary'] is not None:
        summary = read_ref(value['shipping_summary'])
        assert summary['qualified'] is False
    return value


def terminal_receipt(path):
    try:
        value = json.loads(path.read_text())
        return isinstance(value, dict) and type(value.get('exit_code')) is int
    except (OSError, ValueError):
        return False


def closed_directory(path, value):
    name = path.name
    declared = value.get('closed_directories', {}).get(name)
    if declared is not None:
        return type(read_ref(declared).get('exit_code')) is int
    if 'captures' in name or (path / 'state.json').exists():
        try:
            state = json.loads((path / 'state.json').read_text())
            return state.get('state') in ('finished', 'failed', 'passed', 'completed')
        except (OSError, ValueError):
            return False
    if 'build' in name:
        return terminal_receipt(path / 'build.json') or terminal_receipt(path.with_suffix('.json'))
    if name.startswith('resource-'):
        return False
    return True


def selected(value):
    paths, omissions = [], []
    excludes = value.get('exclude_roots', {})
    for child in sorted(Q.iterdir()):
        name = child.name
        if not name.startswith(PREFIXES) or name.startswith(OWN_PREFIXES):
            continue
        if name in excludes:
            assert str(excludes[name]).strip()
            omissions.append({'path': name, 'reason': str(excludes[name])})
            continue
        if child.is_symlink():
            omissions.append({'path': name, 'reason': 'symlink not followed'})
            continue
        if child.is_dir():
            if not closed_directory(child, value):
                omissions.append({'path': name, 'reason': 'build/capture/resource tree has no terminal marker; not walked'})
                continue
            for directory, dirs, files in os.walk(child, followlinks=False):
                for part in list(dirs):
                    path = Path(directory) / part
                    if path.is_symlink() or part in ('.git', 'target', '__pycache__'):
                        dirs.remove(part)
                        omissions.append({'path': path.relative_to(Q).as_posix(), 'reason': 'symlink/cache subtree not walked'})
                paths.extend(Path(directory) / part for part in files)
        elif child.suffix in ('.stdout', '.stderr') and not terminal_receipt(child.with_suffix('.json')):
            omissions.append({'path': name, 'reason': 'loose output has no terminal execution receipt'})
        else:
            paths.append(child)
    paths.extend([SCRIPT, CHECKER, ROOT / 'work/run-rust', ROOT / 'work/record.py'])
    paths.extend(Q / name for name in DEPENDENCIES)
    for name in ('architecture-c14-package-controls.json', 'architecture-c14-package-prepared.json',
                 'architecture-c14-package-prepared-v2.json', 'architecture-c14-package-control-tests.py',
                 'architecture-c14-package-selection-controls.py', 'architecture-c14-package-selection-controls.json',
                 'architecture-c14-package-plan.md', 'architecture-c14-package-decision-template.json'):
        if (Q / name).is_file():
            paths.append(Q / name)
    initial = Q / 'architecture-c14-package-initial-preparation'
    if initial.is_dir() and not initial.is_symlink():
        paths.extend(path for path in initial.iterdir() if path.is_file() and not path.is_symlink())
    return sorted(set(paths)), omissions


def generated(value):
    changed = git('diff', '--name-only', BASE, CANDIDATE).decode().splitlines()
    assert changed == [PRODUCTION, FIXTURE]
    assert hashlib.sha256(git('show', CANDIDATE + ':' + PRODUCTION)).hexdigest() == PRODUCTION_SHA
    assert hashlib.sha256(git('show', CANDIDATE + ':' + FIXTURE)).hexdigest() == FIXTURE_SHA
    result = {'experiment-source/production-and-fixture.patch': git('diff', '--binary', BASE, CANDIDATE)}
    for source, names in ((BASE, [PRODUCTION]), (CANDIDATE, [PRODUCTION, FIXTURE])):
        for name in names:
            result['experiment-source/' + source[:8] + '/' + name] = git('show', source + ':' + name)
    for name in ('Cargo.toml', 'Cargo.lock', 'rpc-bench/Cargo.toml', 'rpc-bench/Cargo.lock',
                 'rpc-bench/src/main.rs', 'scripts/grpc-load-smoke.py'):
        result['experiment-source/unchanged-harness/' + name] = git('show', BASE + ':' + name)
    result['experiment-source/source-and-decision.json'] = encoded({
        'qualified': False, 'production_ready': False, 'baseline': BASE, 'candidate': CANDIDATE,
        'candidate_tree': git('rev-parse', CANDIDATE + '^{tree}').decode().strip(),
        'changed_paths': changed, 'root_decision': value['root_decision'],
        'root_decision_reason': value['root_decision_reason'], 'root_runtime_source': value['root_runtime_source'],
        'source_qualification': value['source_qualification'],
        'scope': 'C14 causal/physical CPU experiment. C13 source qualification remains separate and does not qualify this candidate.'})
    return result


def inventory(decision_path):
    value = decision(decision_path)
    assert DEST.is_dir() and not DEST.is_symlink()
    assert {path.name for path in DEST.iterdir()} == {'README.md', 'results.json'}, 'new capsule needs reviewed README/results only'
    public_result = json.loads((DEST / 'results.json').read_text())
    assert public_result['qualified'] is False and public_result['production_ready'] is False
    paths, omissions = selected(value)
    paths.extend(Path(value[name]['path']) for name in ('causal_results', 'shipping_state'))
    if value['shipping_summary'] is not None:
        paths.append(Path(value['shipping_summary']['path']))
    paths.append(decision_path)
    files = []
    for path in sorted(set(paths)):
        name = 'qualification/' + path.relative_to(Q).as_posix() if path.is_relative_to(Q) else 'support/' + path.name
        assert safe(name)
        meta = path.lstat()
        if not stat.S_ISREG(meta.st_mode) or path.suffix in ('.pyc', '.pyo', '.next'):
            omissions.append({'path': name, 'reason': 'nonregular/bytecode/temporary output omitted'})
            continue
        with path.open('rb') as stream:
            head = stream.read(64)
        if head.startswith(MAGICS):
            omissions.append({'path': name, 'bytes': meta.st_size,
                              'reason': 'executable/library bytes omitted by magic; execution/build hashes remain in their records'})
            continue
        row = dict(ref(path), path=name, source_path=str(path), mtime_ns=meta.st_mtime_ns)
        assert (path.stat().st_size, path.stat().st_mtime_ns) == (meta.st_size, meta.st_mtime_ns)
        files.append(row)
    source = generated(value)
    source_rows = [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in sorted(source.items())]
    assert len({row['path'] for row in files + source_rows}) == len(files) + len(source_rows)
    return {'schema': 'pbrs.c14-experiment-plan.v1', 'qualified': False, 'production_ready': False,
            'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'baseline': BASE, 'candidate': CANDIDATE, 'decision': ref(decision_path),
            'root_decision': value['root_decision'], 'root_runtime_source': value['root_runtime_source'],
            'source_qualification': value['source_qualification'], 'files': files, 'generated_files': source_rows,
            'omissions': omissions, 'publication_files': [dict(ref(DEST / name), path=name) for name in ('README.md', 'results.json')],
            'limits': 'Closed Root-coordinated inputs only; no global procfs quiescence proof. Executable bytes omitted, hashes retained in historical execution/build records. Experiment and Root decision do not inherit C13 qualification.'}


def comparable(value):
    return {key: item for key, item in value.items() if key != 'created_utc'}


def package(plan_path, expected):
    assert expected and digest(plan_path) == expected
    plan = json.loads(plan_path.read_text())
    assert plan['schema'] == 'pbrs.c14-experiment-plan.v1'
    decision_path = Path(plan['decision']['path'])
    assert comparable(inventory(decision_path)) == comparable(plan), 'closed input changed after plan freeze'
    value = decision(decision_path)
    source = generated(value)
    source['packaging/frozen-plan.json'] = plan_path.read_bytes()
    source['published/README.md'] = (DEST / 'README.md').read_bytes()
    source['published/results.json'] = (DEST / 'results.json').read_bytes()
    rows = [{key: row[key] for key in ('path', 'bytes', 'sha256')} for row in plan['files']]
    rows.extend({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in source.items())
    assert len({row['path'] for row in rows}) == len(rows)
    physical = {row['path']: Path(row['source_path']) for row in plan['files']}
    with tempfile.TemporaryDirectory(prefix='resource-c14-package-staging-', dir=Q) as temporary:
        stage = Path(temporary)
        archive = stage / 'raw.tar.gz'
        with archive.open('xb') as output, gzip.GzipFile(fileobj=output, mode='wb', filename='', mtime=0) as gz:
            with tarfile.open(fileobj=gz, mode='w|', format=tarfile.PAX_FORMAT) as capsule:
                for row in sorted(rows, key=lambda item: item['path']):
                    member = tarfile.TarInfo(row['path'])
                    member.size, member.mode, member.mtime = row['bytes'], 0o644, 0
                    if row['path'] in source:
                        capsule.addfile(member, io.BytesIO(source[row['path']]))
                    else:
                        with physical[row['path']].open('rb') as stream:
                            capsule.addfile(member, stream)
        assert comparable(inventory(decision_path)) == comparable(plan), 'closed input changed during archive streaming'
        for name in ('README.md', 'results.json'):
            shutil.copyfile(DEST / name, stage / name)
        shutil.copyfile(CHECKER, stage / 'check.py')
        publications = [dict(ref(stage / name), path=name) for name in ('README.md', 'results.json', 'check.py')]
        manifest = {'schema': 'pbrs.grpc-ready-set-capsule.v1', 'qualified': False, 'production_ready': False,
                    'baseline': BASE, 'candidate': CANDIDATE, 'root_decision': value['root_decision'],
                    'root_runtime_source': value['root_runtime_source'], 'source_qualification': value['source_qualification'],
                    'archive': {'name': 'raw.tar.gz', 'bytes': archive.stat().st_size, 'sha256': digest(archive)},
                    'files': sorted(rows, key=lambda item:item['path']),
                    'logical_bytes': sum(row['bytes'] for row in rows), 'publication_files': publications,
                    'omissions': plan['omissions'], 'frozen_plan': ref(plan_path), 'scope': plan['limits']}
        (stage / 'manifest.json').write_bytes(encoded(manifest))
        subprocess.run([os.sys.executable, str(stage / 'check.py')], check=True)
        assert comparable(inventory(decision_path)) == comparable(plan)
        for name in ('raw.tar.gz', 'manifest.json', 'check.py'):
            os.link(stage / name, DEST / name)  # exclusive; never replace a capsule
    print(json.dumps({'state': 'packaged_experiment', 'qualified': False,
                      'archive': ref(DEST / 'raw.tar.gz'), 'manifest': ref(DEST / 'manifest.json')}))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path)
    parser.add_argument('--decision', type=Path)
    parser.add_argument('--package', type=Path)
    parser.add_argument('--expected-plan-sha256')
    args = parser.parse_args()
    if args.package:
        assert args.plan is None and args.decision is None
        return package(args.package.absolute(), args.expected_plan_sha256)
    if args.plan:
        assert args.decision is not None
        path = args.plan.absolute()
        assert path.parent == Q and path.name.startswith('architecture-c14-package-plan-')
        value = inventory(args.decision.absolute())
        with path.open('xb') as stream:
            stream.write(encoded(value))
        print(json.dumps({'state': 'planned_not_packaged', 'qualified': False, 'plan': ref(path),
                          'files': len(value['files']) + len(value['generated_files'])}))
        return
    print(json.dumps({'state': 'prepared_not_run', 'qualified': False, 'destination': str(DEST),
                      'requires': 'terminal physical CPU state, Root decision, reviewed README/results; separate Root grant before plan/package'}))


if __name__ == '__main__':
    main()
