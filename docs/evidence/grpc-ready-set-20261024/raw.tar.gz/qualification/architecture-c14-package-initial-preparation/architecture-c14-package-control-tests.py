#!/usr/bin/env python3
"""Small synthetic capsule controls; no real inventory/build/endpoint is used."""
import copy
import hashlib
import io
import json
from pathlib import Path
import runpy
import tarfile
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
checker = runpy.run_path(str(Q / 'architecture-c14-package-check.py'), run_name='c14_synthetic_checker')
check = checker['check']
digest = checker['digest']
counts = {'valid': 0, 'rejected': 0}


def write_fixture(directory, members=None):
    directory.mkdir()
    for name, data in [('README.md', b'Experiment.\n'), ('results.json', b'{"qualified":false,"production_ready":false}\n'), ('check.py', b'# synthetic checker bytes\n')]:
        (directory / name).write_bytes(data)
    payload = b'closed raw record\n'
    if members is None:
        member = tarfile.TarInfo('qualification/record.txt')
        member.size = len(payload)
        members = [(member, payload)]
    with tarfile.open(directory / 'raw.tar.gz', 'w:gz') as archive:
        for member, data in members:
            archive.addfile(member, io.BytesIO(data) if data is not None else None)
    manifest = {'qualified': False, 'production_ready': False,
                'archive': {'name': 'raw.tar.gz', 'bytes': (directory / 'raw.tar.gz').stat().st_size,
                            'sha256': digest(directory / 'raw.tar.gz')},
                'files': [{'path': 'qualification/record.txt', 'bytes': len(payload), 'sha256': hashlib.sha256(payload).hexdigest()}],
                'logical_bytes': len(payload),
                'publication_files': [{'path': name, 'bytes': (directory / name).stat().st_size,
                                       'sha256': digest(directory / name)} for name in ('README.md', 'results.json', 'check.py')]}
    (directory / 'manifest.json').write_text(json.dumps(manifest))
    return manifest


def rejects(directory):
    try:
        check(directory)
    except (ValueError, OSError, KeyError, tarfile.TarError):
        counts['rejected'] += 1
        return
    raise AssertionError('synthetic invalid capsule accepted: ' + str(directory))


with tempfile.TemporaryDirectory(prefix='c14-package-check-controls-') as temporary:
    base = Path(temporary)
    valid = base / 'valid'
    write_fixture(valid)
    check(valid)
    counts['valid'] += 1
    modifications = {
        'qualified': lambda m: m.update(qualified=True),
        'production-ready': lambda m: m.update(production_ready=True),
        'unsafe-archive': lambda m: m['archive'].update(name='../raw.tar.gz'),
        'duplicate-manifest': lambda m: m['files'].append(copy.deepcopy(m['files'][0])),
        'unsafe-manifest': lambda m: m['files'][0].update(path='../escape'),
        'bad-content-hash': lambda m: m['files'][0].update(sha256='0'*64),
        'bad-size': lambda m: m['files'][0].update(bytes=999),
        'bad-total': lambda m: m.update(logical_bytes=999),
        'missing-publication': lambda m: m['publication_files'].pop(),
        'unsafe-publication': lambda m: m['publication_files'][0].update(path='../README.md'),
    }
    for name, mutation in modifications.items():
        directory = base / name
        value = write_fixture(directory)
        mutation(value)
        (directory / 'manifest.json').write_text(json.dumps(value))
        rejects(directory)
    for name in ('README.md', 'results.json', 'check.py', 'raw.tar.gz'):
        directory = base / ('tamper-' + name.replace('.', '-'))
        write_fixture(directory)
        with (directory / name).open('ab') as stream:
            stream.write(b'changed')
        rejects(directory)
    directory = base / 'archive-symlink'
    write_fixture(directory)
    archive = directory / 'raw.tar.gz'
    archive.rename(directory / 'other.tar.gz')
    archive.symlink_to('other.tar.gz')
    rejects(directory)
    directory = base / 'manifest-symlink'
    write_fixture(directory)
    (directory / 'manifest.json').rename(directory / 'other.json')
    (directory / 'manifest.json').symlink_to('other.json')
    rejects(directory)
    for name, path, kind in [('duplicate-tar', 'qualification/record.txt', tarfile.REGTYPE),
                             ('traversal-tar', '../escape', tarfile.REGTYPE),
                             ('absolute-tar', '/escape', tarfile.REGTYPE),
                             ('symlink-tar', 'qualification/record.txt', tarfile.SYMTYPE),
                             ('hardlink-tar', 'qualification/record.txt', tarfile.LNKTYPE)]:
        member = tarfile.TarInfo(path)
        member.type = kind
        member.linkname = 'qualification/other'
        member.size = 18 if kind == tarfile.REGTYPE else 0
        data = b'closed raw record\n' if kind == tarfile.REGTYPE else None
        items = [(member, data)]
        if name == 'duplicate-tar':
            items.append((copy.copy(member), data))
        directory = base / name
        write_fixture(directory, items)
        rejects(directory)
    # No check writes/extracts anything from the archive.
    assert not (base / 'escape').exists()
    for directory in base.iterdir():
        assert {p.name for p in directory.iterdir()} <= {'README.md', 'results.json', 'check.py', 'manifest.json', 'raw.tar.gz', 'other.tar.gz', 'other.json'}

value = {'state': 'synthetic_controls_passed', 'qualified': False, 'counts': counts,
         'scope': 'Only temporary tiny synthetic archives; no real Q inventory, publication, compiler, endpoint or performance measurement.',
         'checker_sha256': digest(Q / 'architecture-c14-package-check.py')}
output = Q / 'architecture-c14-package-controls.json'
with output.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(value))
