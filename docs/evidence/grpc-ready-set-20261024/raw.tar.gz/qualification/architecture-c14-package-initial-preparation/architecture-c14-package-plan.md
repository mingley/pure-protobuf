# C14 experiment package — prepared only

No final documents or capsule directory have been created. Do not run inventory
or packaging before the C13 archive closes, the C14 CPU phase is terminal, and
Root grants the next action. Preparation only reads/writes Q helper text; no
compiler, endpoint or real archive inventory is part of it.

The destination is `docs/evidence/grpc-ready-set-20261024`. It records the causal
experiment, physical CPU result and Root adoption decision separately from the
C13 qualification capsule. Baseline is `933bf877`; experimental candidate is
`daa7eb40`. Neither a causal pass nor one shared-host CPU campaign certifies
production readiness or broad superiority.

## Inputs after Root's grant

Fill a NEW `architecture-c14-publication-decision.json` from the preserved
`architecture-c14-package-decision-template.json`. Use actual final reference
objects `{path, bytes, sha256}` for the causal results, terminal shipping state,
and its summary. `root_decision` is `adopt`, `reject` or `defer`; record its reason
and actual Root runtime source. Keep `source_qualification.source=933bf877...`
and `applies_to_candidate=false`: earlier qualification is not inherited.
The summary may be null for a failed terminal campaign; preserve that failure.

Write/review the new capsule README and results only after Root's post-C13 grant.
The results must keep `qualified=false` and `production_ready=false`. Root owns
these documents, decision, all Git changes and the final grant.

The selector includes closed Q `architecture-c14*` and `resource-c14*` records.
A capture directory needs a terminal state; a build directory needs a terminal
build receipt. Loose stdout/stderr need their terminal execution receipt. Unknown
resource directories require an explicit `closed_directories` receipt reference,
or stay omitted. `exclude_roots` carries explicit reasons for other active trees.
No active tree is walked to guess quiescence, and no global procfs proof is made.
Executables/libraries are omitted by magic; their existing execution/build hashes
remain in archived provenance. Symlinks, cache trees and temporary files are not
archived. Actual C13 baseline builder, adapter and build record are dependencies,
not new C13 qualification claims. Git snapshots preserve the exact experiment
patch and unchanged benchmark harness.

## Validation and freeze

The checker is `architecture-c14-package-check.py`. It checks regular local
manifest/archive/publication files, unique safe regular tar members and every
size/hash without extracting files. Tiny adversarial controls are prepared in
`architecture-c14-package-control-tests.py`; do not execute even those during the
quiet CPU window. Their result is written exclusively after Root grants it.

After the actual CPU phase and final documents close, prepare a new inventory:

```sh
python3 work/qualification/architecture-c14-package-experiment.py \
  --decision work/qualification/architecture-c14-publication-decision.json \
  --plan work/qualification/architecture-c14-package-plan-v1.json
```

Root reviews its exact SHA. Packaging is a separate later action:

```sh
python3 work/qualification/architecture-c14-package-experiment.py \
  --package work/qualification/architecture-c14-package-plan-v1.json \
  --expected-plan-sha256 ACTUAL_FROZEN_PLAN_SHA256
```

Use a `resource-c14-package-*` execution receipt prefix so the packager never
selects its own live output. It rechecks all frozen inputs, stages/checks a small
archive, then exclusively publishes raw.tar.gz, manifest.json and check.py.
Existing or partial capsules are never replaced. Run the final checker and
repository documentation/link checks before Root commits/pushes.
