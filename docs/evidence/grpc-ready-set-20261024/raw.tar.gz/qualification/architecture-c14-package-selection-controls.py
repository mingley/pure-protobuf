#!/usr/bin/env python3
"""Validate tree/receipt selection in a tiny fake Q, without real inventory."""
import hashlib
import json
from pathlib import Path
import runpy
import tempfile

Q = Path('/workspace/pure-protobuf/work/qualification')
script = Q / 'architecture-c14-package-experiment.py'
module = runpy.run_path(str(script), run_name='c14_selection_controls')
selected = module['selected']
globals_ = selected.__globals__
passed = []

with tempfile.TemporaryDirectory(prefix='c14-selection-controls-') as temporary:
    fake = Path(temporary)
    globals_['Q'] = fake
    for name in ('architecture-c14-active-build', 'architecture-c14-closed-build',
                 'architecture-c14-active-captures', 'architecture-c14-closed-captures',
                 'resource-c14-unknown'):
        (fake / name).mkdir()
        (fake / name / 'payload.txt').write_text(name)
    (fake / 'architecture-c14-closed-build/build.json').write_text('{"exit_code":0}')
    (fake / 'architecture-c14-active-captures/state.json').write_text('{"state":"running"}')
    (fake / 'architecture-c14-closed-captures/state.json').write_text('{"state":"finished"}')
    (fake / 'resource-c14-active.stdout').write_text('live')
    (fake / 'resource-c14-closed.stdout').write_text('closed')
    (fake / 'resource-c14-closed.json').write_text('{"exit_code":0}')
    (fake / 'architecture-c14-package-live.stdout').write_text('own output')
    (fake / 'not-selected').mkdir()
    (fake / 'not-selected/secret.txt').write_text('must not follow')
    (fake / 'architecture-c14-symlink').symlink_to(fake / 'not-selected', target_is_directory=True)
    paths, omitted = selected({})
    names = {str(path.relative_to(fake)) for path in paths if path.is_relative_to(fake)}
    checks = {
        'active_build_not_walked': 'architecture-c14-active-build/payload.txt' not in names,
        'closed_build_included': 'architecture-c14-closed-build/payload.txt' in names,
        'active_capture_not_walked': 'architecture-c14-active-captures/payload.txt' not in names,
        'closed_capture_included': 'architecture-c14-closed-captures/payload.txt' in names,
        'active_loose_output_omitted': 'resource-c14-active.stdout' not in names,
        'closed_loose_output_included': 'resource-c14-closed.stdout' in names,
        'unknown_resource_not_walked': 'resource-c14-unknown/payload.txt' not in names,
        'own_live_output_omitted': 'architecture-c14-package-live.stdout' not in names,
        'symlink_not_followed': not any('secret.txt' in name for name in names),
    }
    assert all(checks.values()), checks
    passed.extend(checks)
    receipt = fake / 'resource-c14-closed.json'
    row = globals_['ref'](receipt)
    paths, omitted = selected({'closed_directories': {'resource-c14-unknown': row}})
    assert fake / 'resource-c14-unknown/payload.txt' in paths
    passed.append('explicit_closed_resource_receipt_included')
    paths, omitted = selected({'exclude_roots': {'architecture-c14-closed-build': 'explicit unrelated tree'}})
    assert fake / 'architecture-c14-closed-build/payload.txt' not in paths
    passed.append('explicit_exclusion_recorded')
    assert any(row['path'] == 'architecture-c14-closed-build' and row['reason'] == 'explicit unrelated tree' for row in omitted)
    passed.append('explicit_exclusion_reason_retained')

value = {'state': 'synthetic_selection_controls_passed', 'qualified': False, 'passed': passed,
         'packager_sha256': hashlib.sha256(script.read_bytes()).hexdigest(),
         'scope': 'Only a tiny temporary fake Q; no real inventory, docs, archive publication, compiler, endpoint or performance phase.'}
output = Q / 'architecture-c14-package-selection-controls.json'
with output.open('x') as stream:
    json.dump(value, stream, indent=2)
    stream.write('\n')
print(json.dumps(value))
