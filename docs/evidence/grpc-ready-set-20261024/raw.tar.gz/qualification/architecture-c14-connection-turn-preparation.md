# Connection turn control — preparation only

Base: `933bf8775b70d24d91fb46a7992eae343b60f0ea`.
No Root Rust source was edited, and this fixture/candidate has not been compiled
or run. `architecture-c14-connection-turn-preparation-v2.json` pins the current
formatted fixture and additive test patch. The earlier preparation JSON records
the first draft, before replacing direct slice indexing with checked access.

## Source hypothesis

The steady connection poll first polls the admitted ready set, then polls the
HTTP/2 driver through `poll_accept`. Reading DATA can wake an already admitted
RPC after that first ready-set poll. If the driver then returns Pending, the
current branch parks until another executor turn. This is a source hypothesis;
it does not establish a measured CPU saving or a mutex-contention cause.

The candidate patch adds one ready-set poll after driver Pending. A completed RPC
returns the existing Tick, letting the loop drive queued output. This does not
scan sleeping futures, change admission/buffering/deadlines, add tasks, or change
the underlying mutex. Both production code and evidence remain untouched.

## Causal fixture

`architecture-c14-connection-turn-fixture.rs` is intended as the new integration
target `pbrs-grpc/tests/connection_turn.rs`. The additive test-only patch adds
exactly that file. It uses the public native Server and an independent registry-h2
peer over duplex IO. Every native parent poll is explicit and uses a counter
waker; only the registry client connection is a spawned task.

1. Admit a parked sibling, then target HEADERS with request DATA withheld.
2. Observe the target service entering unary setup while its handler remains
   uncalled. The sibling's custom future records each actual poll.
3. Close the native read gate and send a complete empty request DATA frame with
   END_STREAM. The peer IO witness parses successfully written HTTP/2 frames to
   establish that complete DATA reached the duplex buffer.
4. Poll with the gate closed and require that the target handler remains uncalled.
5. Open the gate and manually poll the native server future exactly once. Save
   its read-byte delta, target-handler count, sibling-poll count and wake count.
6. Complete the target response and a second successful RPC on the same
   connection, requiring HTTP 200, explicit grpc-status 0, and exactly one empty
   HelloReply frame in each exchange.
7. Only then assert the causal DATA-read phase, exactly one parent poll, no poll
   of the unwoken sibling, and execution of the target handler in that same turn.

A detecting original result must reach the final scheduling assertion after
valid wire output and recovery. A compile failure, failed DATA-read witness,
parked-sibling change, or stalled exchange is a fixture/setup failure rather than
that causal result. Five-second wall-clock watchdogs only bound failed fixtures;
no latency or throughput claim uses them. Failed tests abort the registry driver
and drop the manually owned server future.

## Next execution, only after Root grant

Apply the additive test patch to a Root-selected source checkpoint. Pin the
actual source/fixture and compile a baseline ELF before applying the production
candidate. Copy/hash that executable and retain its full result. Then apply only
the candidate production patch, preserve both states, and rerun the identical
fixture plus relevant existing readiness/cancellation/flow-control controls.
No compiler command in this document has been executed by this preparer.

The parent owns compiler/cache/worktree coordination and all commits/pushes.

## Limits

Only the steady branch is changed; the lifetime/keepalive select branch is not
qualified by this fixture. A streaming handler can emit a response while remaining
Pending; the proposed recheck alone does not prove that such queued output flushes
in the same parent poll. Likewise, a ready-set poll that reaches an asynchronous
handler wait may legitimately remain Pending. Those cases need separate causal
controls and bounded progress/fairness design before broader claims.

Actual shipping CPU, syscall counts, worker handoffs, client-side effects, latency,
throughput, and platform behavior still need source-paired measurements. The test
is an ownership/scheduling control, not a benchmark or proof of superiority.
