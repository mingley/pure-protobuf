# C14 ready-set experiment: defer adoption

The experiment passed its same-turn causal fixture and focused correctness controls, but showed **no consistent physical CPU benefit**. Keep it experimental. Main runtime 933bf remains unchanged.

Actual shipping comparison: 48 captures, 360,000 successful RPCs, zero failures or unfinished calls; 67.153 seconds. Both source trees stayed clean. Baseline 933bf and candidate daa7eb differ only in the reviewed connection loop and new causal test. Same feature-off compiler/profile, benchmark subtree, payloads and transport settings.

## Raw native-server CPU at 10,000 RPCs

Microseconds per completed RPC, before subtracting setup. Each row is a matched repeat.

| Shape | Repeat | Baseline user + system = total | C14 user + system = total | Change |
| --- | ---: | ---: | ---: | ---: |
| unary | 1 | 20 + 27 = 47 | 19 + 30 = 49 | +4.26% |
| unary | 2 | 16 + 33 = 49 | 13 + 30 = 43 | -12.24% |
| bidi | 1 | 40 + 68 = 108 | 44 + 64 = 108 | +0.00% |
| bidi | 2 | 45 + 104 = 149 | 49 + 113 = 162 | +8.72% |

Unary-server raw CPU rises in one repeat and falls in the other. Its N/2N slopes are 32→54 microseconds (+68.75%) and 62→44 (−29.03%). Bidi-server slopes are also mixed: 78→76 (−2.56%) and 138→168 (+21.74%). Do not select the better repeat or promote the same-turn witness into a speed claim.

## All source CPU slope controls

Microseconds/RPC from N=5,000/10,000. Values are repeat 1 / repeat 2; ratio ranges retain both observations.

| Shape | Pair | Measured side | Baseline | C14 | C14 / baseline range |
| --- | --- | --- | ---: | ---: | ---: |
| unary | native → tonic | client | 38 / 22 | 16 / 16 | 0.421–0.727 |
| unary | native → tonic | server | 46 / 24 | 16 / 22 | 0.348–0.917 |
| unary | tonic → native | client | 66 / 72 | 82 / 78 | 1.083–1.242 |
| unary | tonic → native | server | 32 / 62 | 54 / 44 | 0.710–1.688 |
| unary | tonic → tonic | client | 72 / 58 | 70 / 74 | 0.972–1.276 |
| unary | tonic → tonic | server | 28 / 42 | 28 / 40 | 0.952–1.000 |
| bidi | native → tonic | client | 100 / 116 | 108 / 98 | 0.845–1.080 |
| bidi | native → tonic | server | 138 / 180 | 148 / 132 | 0.733–1.072 |
| bidi | tonic → native | client | 156 / 162 | 172 / 192 | 1.103–1.185 |
| bidi | tonic → native | server | 78 / 138 | 76 / 168 | 0.974–1.217 |
| bidi | tonic → tonic | client | 180 / 162 | 174 / 144 | 0.889–0.967 |
| bidi | tonic → tonic | server | 196 / 214 | 148 / 152 | 0.710–0.755 |

The Tonic client talking to the native server costs more in both repeats for both shapes. Native unary-client CPU improves even though that branch does not execute the changed native-server loop. Tonic/Tonic bidi-server control CPU falls 24–29%. These controls show substantial variation and prevent attributing every source difference to the six-line change.

The candidate native-server CPU slopes remain 1.93× / 1.10× fresh Tonic for unary and 0.51× / 1.11× for bidi. One candidate user-CPU component is negative (−2 microseconds on the remote Tonic server in the unary native-client pair); it is retained. All combined CPU slopes are positive. No thresholds or higher-cost groups were omitted.

## Interpretation

The causal test proves a child made ready by protocol input can run in the same parent poll after the recheck. It does not prove fewer notifications: observed parent wakes rose from one to two in that fixture, and already queued Tokio work can remain. No C14 syscall tracing ran, so the earlier baseline eventfd/futex observations cannot be relabelled as a measured C14 reduction.

Any deferred connection-wake forwarding design is separate. It needs its own atomic/waker race model, correctness fixtures and source-pinned physical CPU comparison. No thread, queue, buffer, policy, TLS, custom-lock or production source change follows from these mixed results.

The quiet window had empty readable known-workload scans before and after, with actual quota/HZ recorded. This does not prove a dedicated host. Server client-window CPU and client process-lifetime CPU include different setup/reporting scopes; 10 ms ticks and two repeats limit N/2N interpretation. Timing observations and all full histograms remain in the original summary; there is no broad superiority or production-readiness conclusion.

## Evidence

- Completion `architecture-c14-shipping-completion.json`: e6a750cce636cfb806285634474302e3465db7a934b3e328bb0087717a950016; all 354 artifacts referenced.
- Full summary `architecture-c14-shipping-captures/shipping-summary.json`: f04e5a226d3a48d545d5ef7cdd774151e72e758e162a285819aa8aa3368e5bfb.
- Numeric analysis `architecture-c14-shipping-analysis.json`: d19f9536db286618b8fb205295bad499f8e7242fc42f65041637894f37988697; all 12 source groups, all 8 fresh-Tonic groups, all raw 10,000-call endpoint CPU records and signed slopes.
- State `architecture-c14-shipping-captures/state.json`: 6810693fd8386f378e6272438ade550ba09c11fcbd63557aad623cd0cacccba7.

Both C13 day launches were released to soak_prepare immediately after the capture endpoints closed and the after-scan was recorded. No further workload, retry, source edit or production adoption was performed.
