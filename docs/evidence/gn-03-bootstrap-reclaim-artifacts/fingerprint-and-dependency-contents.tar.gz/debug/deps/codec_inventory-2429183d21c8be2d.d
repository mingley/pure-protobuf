/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-2429183d21c8be2d.d: src/bin/codec-inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-2429183d21c8be2d: src/bin/codec-inventory.rs

src/bin/codec-inventory.rs:
