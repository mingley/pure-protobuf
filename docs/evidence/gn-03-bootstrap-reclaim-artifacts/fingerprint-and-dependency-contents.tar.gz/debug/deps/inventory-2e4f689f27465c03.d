/workspace/scratch/work/gn11/target/base/debug/deps/inventory-2e4f689f27465c03.d: src/bin/inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/inventory-2e4f689f27465c03: src/bin/inventory.rs

src/bin/inventory.rs:
