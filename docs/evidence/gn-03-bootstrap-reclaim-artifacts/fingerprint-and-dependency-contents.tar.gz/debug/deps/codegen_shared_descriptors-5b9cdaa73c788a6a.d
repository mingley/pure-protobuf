/workspace/scratch/work/gn03/target/base/debug/deps/codegen_shared_descriptors-5b9cdaa73c788a6a.d: tests/codegen_shared_descriptors.rs

/workspace/scratch/work/gn03/target/base/debug/deps/codegen_shared_descriptors-5b9cdaa73c788a6a: tests/codegen_shared_descriptors.rs

tests/codegen_shared_descriptors.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
