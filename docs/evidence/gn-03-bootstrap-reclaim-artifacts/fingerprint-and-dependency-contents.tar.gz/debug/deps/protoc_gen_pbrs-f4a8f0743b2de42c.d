/workspace/scratch/work/gn03/target/base/debug/deps/protoc_gen_pbrs-f4a8f0743b2de42c.d: src/bin/protoc-gen-pbrs.rs

/workspace/scratch/work/gn03/target/base/debug/deps/protoc_gen_pbrs-f4a8f0743b2de42c: src/bin/protoc-gen-pbrs.rs

src/bin/protoc-gen-pbrs.rs:
