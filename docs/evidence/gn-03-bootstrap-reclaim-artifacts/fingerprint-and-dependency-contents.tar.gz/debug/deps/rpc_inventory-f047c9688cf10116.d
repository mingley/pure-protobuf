/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-f047c9688cf10116.d: /workspace/scratch/work/gn11/clippy.toml src/bin/rpc-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/librpc_inventory-f047c9688cf10116.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/rpc-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/rpc-inventory.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
