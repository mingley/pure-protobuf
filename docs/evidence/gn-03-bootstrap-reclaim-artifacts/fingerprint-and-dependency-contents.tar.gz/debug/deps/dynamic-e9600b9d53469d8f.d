/workspace/scratch/work/gn03/target/base/debug/deps/dynamic-e9600b9d53469d8f.d: tests/dynamic.rs /workspace/scratch/work/gn03/vendor/google/conformance_fds.bin

/workspace/scratch/work/gn03/target/base/debug/deps/dynamic-e9600b9d53469d8f: tests/dynamic.rs /workspace/scratch/work/gn03/vendor/google/conformance_fds.bin

tests/dynamic.rs:
/workspace/scratch/work/gn03/vendor/google/conformance_fds.bin:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
