/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-c507e5f00701355c.d: /workspace/scratch/work/gn11/clippy.toml src/bin/codec-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libcodec_inventory-c507e5f00701355c.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/codec-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/codec-inventory.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
