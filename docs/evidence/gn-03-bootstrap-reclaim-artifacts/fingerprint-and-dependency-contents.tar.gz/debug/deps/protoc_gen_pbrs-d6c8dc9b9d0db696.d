/workspace/scratch/work/gn11/target/base/debug/deps/protoc_gen_pbrs-d6c8dc9b9d0db696.d: /workspace/scratch/work/gn11/clippy.toml src/bin/protoc-gen-pbrs.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libprotoc_gen_pbrs-d6c8dc9b9d0db696.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/protoc-gen-pbrs.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/protoc-gen-pbrs.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
