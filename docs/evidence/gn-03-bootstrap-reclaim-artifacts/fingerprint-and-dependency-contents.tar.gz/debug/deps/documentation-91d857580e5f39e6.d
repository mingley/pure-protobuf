/workspace/scratch/work/gn03/target/base/debug/deps/documentation-91d857580e5f39e6.d: tests/documentation.rs tests/support/wkt_consumer.rs tests/../docs/codegen-layout.md

/workspace/scratch/work/gn03/target/base/debug/deps/documentation-91d857580e5f39e6: tests/documentation.rs tests/support/wkt_consumer.rs tests/../docs/codegen-layout.md

tests/documentation.rs:
tests/support/wkt_consumer.rs:
tests/../docs/codegen-layout.md:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
