/workspace/scratch/work/gn03/target/integration-consumers/debug/deps/cg19_generator-36f98c7d05599fad.d: src/main.rs

/workspace/scratch/work/gn03/target/integration-consumers/debug/deps/cg19_generator-36f98c7d05599fad: src/main.rs

src/main.rs:
