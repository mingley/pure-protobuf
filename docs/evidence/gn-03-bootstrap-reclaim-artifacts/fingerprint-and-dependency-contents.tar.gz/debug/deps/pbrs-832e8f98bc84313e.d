/workspace/scratch/work/gn03/target/integration-consumers/debug/deps/pbrs-832e8f98bc84313e.d: /workspace/scratch/work/gn03/src/lib.rs /workspace/scratch/work/gn03/src/prelude.rs /workspace/scratch/work/gn03/src/codegen.rs /workspace/scratch/work/gn03/src/codegen/compat_stubs.rs /workspace/scratch/work/gn03/src/codegen/config.rs /workspace/scratch/work/gn03/src/codegen/descriptors.rs /workspace/scratch/work/gn03/src/codegen/encode.rs /workspace/scratch/work/gn03/src/codegen/json.rs /workspace/scratch/work/gn03/src/codegen/messages.rs /workspace/scratch/work/gn03/src/codegen/naming.rs /workspace/scratch/work/gn03/src/codegen/native_stubs.rs /workspace/scratch/work/gn03/src/codegen/parse.rs /workspace/scratch/work/gn03/src/codegen/prost_stubs.rs /workspace/scratch/work/gn03/src/codegen/reflection.rs /workspace/scratch/work/gn03/src/codegen/text.rs /workspace/scratch/work/gn03/src/codegen/tonic_stubs.rs /workspace/scratch/work/gn03/src/copy_counts.rs /workspace/scratch/work/gn03/src/dynamic.rs /workspace/scratch/work/gn03/src/error.rs /workspace/scratch/work/gn03/src/gen_support.rs /workspace/scratch/work/gn03/src/gencode.rs /workspace/scratch/work/gn03/src/generated/mod.rs /workspace/scratch/work/gn03/src/internal.rs /workspace/scratch/work/gn03/src/json.rs /workspace/scratch/work/gn03/src/lazy.rs /workspace/scratch/work/gn03/src/map.rs /workspace/scratch/work/gn03/src/message.rs /workspace/scratch/work/gn03/src/packed.rs /workspace/scratch/work/gn03/src/proxied.rs /workspace/scratch/work/gn03/src/repeated.rs /workspace/scratch/work/gn03/src/rt.rs /workspace/scratch/work/gn03/src/runtime.rs /workspace/scratch/work/gn03/src/runtime/arena.rs /workspace/scratch/work/gn03/src/runtime/array.rs /workspace/scratch/work/gn03/src/runtime/decode.rs /workspace/scratch/work/gn03/src/runtime/encode.rs /workspace/scratch/work/gn03/src/runtime/extension.rs /workspace/scratch/work/gn03/src/runtime/layout.rs /workspace/scratch/work/gn03/src/runtime/map.rs /workspace/scratch/work/gn03/src/runtime/mini_table.rs /workspace/scratch/work/gn03/src/runtime/reflect.rs /workspace/scratch/work/gn03/src/string.rs /workspace/scratch/work/gn03/src/table.rs /workspace/scratch/work/gn03/src/testdata.rs /workspace/scratch/work/gn03/src/text.rs /workspace/scratch/work/gn03/src/wire.rs /workspace/scratch/work/gn03/target/integration-consumers/debug/build/pbrs-39df9b576add9f5a/out/conformance_fds.bin /workspace/scratch/work/gn03/src/generated/any.rs /workspace/scratch/work/gn03/src/generated/duration.rs /workspace/scratch/work/gn03/src/generated/empty.rs /workspace/scratch/work/gn03/src/generated/field_mask.rs /workspace/scratch/work/gn03/src/generated/struct.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition2023.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition_unstable.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2_editions.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3_editions.rs /workspace/scratch/work/gn03/src/generated/timestamp.rs /workspace/scratch/work/gn03/src/generated/wrappers.rs

/workspace/scratch/work/gn03/target/integration-consumers/debug/deps/libpbrs-832e8f98bc84313e.rlib: /workspace/scratch/work/gn03/src/lib.rs /workspace/scratch/work/gn03/src/prelude.rs /workspace/scratch/work/gn03/src/codegen.rs /workspace/scratch/work/gn03/src/codegen/compat_stubs.rs /workspace/scratch/work/gn03/src/codegen/config.rs /workspace/scratch/work/gn03/src/codegen/descriptors.rs /workspace/scratch/work/gn03/src/codegen/encode.rs /workspace/scratch/work/gn03/src/codegen/json.rs /workspace/scratch/work/gn03/src/codegen/messages.rs /workspace/scratch/work/gn03/src/codegen/naming.rs /workspace/scratch/work/gn03/src/codegen/native_stubs.rs /workspace/scratch/work/gn03/src/codegen/parse.rs /workspace/scratch/work/gn03/src/codegen/prost_stubs.rs /workspace/scratch/work/gn03/src/codegen/reflection.rs /workspace/scratch/work/gn03/src/codegen/text.rs /workspace/scratch/work/gn03/src/codegen/tonic_stubs.rs /workspace/scratch/work/gn03/src/copy_counts.rs /workspace/scratch/work/gn03/src/dynamic.rs /workspace/scratch/work/gn03/src/error.rs /workspace/scratch/work/gn03/src/gen_support.rs /workspace/scratch/work/gn03/src/gencode.rs /workspace/scratch/work/gn03/src/generated/mod.rs /workspace/scratch/work/gn03/src/internal.rs /workspace/scratch/work/gn03/src/json.rs /workspace/scratch/work/gn03/src/lazy.rs /workspace/scratch/work/gn03/src/map.rs /workspace/scratch/work/gn03/src/message.rs /workspace/scratch/work/gn03/src/packed.rs /workspace/scratch/work/gn03/src/proxied.rs /workspace/scratch/work/gn03/src/repeated.rs /workspace/scratch/work/gn03/src/rt.rs /workspace/scratch/work/gn03/src/runtime.rs /workspace/scratch/work/gn03/src/runtime/arena.rs /workspace/scratch/work/gn03/src/runtime/array.rs /workspace/scratch/work/gn03/src/runtime/decode.rs /workspace/scratch/work/gn03/src/runtime/encode.rs /workspace/scratch/work/gn03/src/runtime/extension.rs /workspace/scratch/work/gn03/src/runtime/layout.rs /workspace/scratch/work/gn03/src/runtime/map.rs /workspace/scratch/work/gn03/src/runtime/mini_table.rs /workspace/scratch/work/gn03/src/runtime/reflect.rs /workspace/scratch/work/gn03/src/string.rs /workspace/scratch/work/gn03/src/table.rs /workspace/scratch/work/gn03/src/testdata.rs /workspace/scratch/work/gn03/src/text.rs /workspace/scratch/work/gn03/src/wire.rs /workspace/scratch/work/gn03/target/integration-consumers/debug/build/pbrs-39df9b576add9f5a/out/conformance_fds.bin /workspace/scratch/work/gn03/src/generated/any.rs /workspace/scratch/work/gn03/src/generated/duration.rs /workspace/scratch/work/gn03/src/generated/empty.rs /workspace/scratch/work/gn03/src/generated/field_mask.rs /workspace/scratch/work/gn03/src/generated/struct.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition2023.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition_unstable.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2_editions.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3_editions.rs /workspace/scratch/work/gn03/src/generated/timestamp.rs /workspace/scratch/work/gn03/src/generated/wrappers.rs

/workspace/scratch/work/gn03/target/integration-consumers/debug/deps/libpbrs-832e8f98bc84313e.rmeta: /workspace/scratch/work/gn03/src/lib.rs /workspace/scratch/work/gn03/src/prelude.rs /workspace/scratch/work/gn03/src/codegen.rs /workspace/scratch/work/gn03/src/codegen/compat_stubs.rs /workspace/scratch/work/gn03/src/codegen/config.rs /workspace/scratch/work/gn03/src/codegen/descriptors.rs /workspace/scratch/work/gn03/src/codegen/encode.rs /workspace/scratch/work/gn03/src/codegen/json.rs /workspace/scratch/work/gn03/src/codegen/messages.rs /workspace/scratch/work/gn03/src/codegen/naming.rs /workspace/scratch/work/gn03/src/codegen/native_stubs.rs /workspace/scratch/work/gn03/src/codegen/parse.rs /workspace/scratch/work/gn03/src/codegen/prost_stubs.rs /workspace/scratch/work/gn03/src/codegen/reflection.rs /workspace/scratch/work/gn03/src/codegen/text.rs /workspace/scratch/work/gn03/src/codegen/tonic_stubs.rs /workspace/scratch/work/gn03/src/copy_counts.rs /workspace/scratch/work/gn03/src/dynamic.rs /workspace/scratch/work/gn03/src/error.rs /workspace/scratch/work/gn03/src/gen_support.rs /workspace/scratch/work/gn03/src/gencode.rs /workspace/scratch/work/gn03/src/generated/mod.rs /workspace/scratch/work/gn03/src/internal.rs /workspace/scratch/work/gn03/src/json.rs /workspace/scratch/work/gn03/src/lazy.rs /workspace/scratch/work/gn03/src/map.rs /workspace/scratch/work/gn03/src/message.rs /workspace/scratch/work/gn03/src/packed.rs /workspace/scratch/work/gn03/src/proxied.rs /workspace/scratch/work/gn03/src/repeated.rs /workspace/scratch/work/gn03/src/rt.rs /workspace/scratch/work/gn03/src/runtime.rs /workspace/scratch/work/gn03/src/runtime/arena.rs /workspace/scratch/work/gn03/src/runtime/array.rs /workspace/scratch/work/gn03/src/runtime/decode.rs /workspace/scratch/work/gn03/src/runtime/encode.rs /workspace/scratch/work/gn03/src/runtime/extension.rs /workspace/scratch/work/gn03/src/runtime/layout.rs /workspace/scratch/work/gn03/src/runtime/map.rs /workspace/scratch/work/gn03/src/runtime/mini_table.rs /workspace/scratch/work/gn03/src/runtime/reflect.rs /workspace/scratch/work/gn03/src/string.rs /workspace/scratch/work/gn03/src/table.rs /workspace/scratch/work/gn03/src/testdata.rs /workspace/scratch/work/gn03/src/text.rs /workspace/scratch/work/gn03/src/wire.rs /workspace/scratch/work/gn03/target/integration-consumers/debug/build/pbrs-39df9b576add9f5a/out/conformance_fds.bin /workspace/scratch/work/gn03/src/generated/any.rs /workspace/scratch/work/gn03/src/generated/duration.rs /workspace/scratch/work/gn03/src/generated/empty.rs /workspace/scratch/work/gn03/src/generated/field_mask.rs /workspace/scratch/work/gn03/src/generated/struct.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition2023.rs /workspace/scratch/work/gn03/src/generated/test_messages_edition_unstable.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto2_editions.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3.rs /workspace/scratch/work/gn03/src/generated/test_messages_proto3_editions.rs /workspace/scratch/work/gn03/src/generated/timestamp.rs /workspace/scratch/work/gn03/src/generated/wrappers.rs

/workspace/scratch/work/gn03/src/lib.rs:
/workspace/scratch/work/gn03/src/prelude.rs:
/workspace/scratch/work/gn03/src/codegen.rs:
/workspace/scratch/work/gn03/src/codegen/compat_stubs.rs:
/workspace/scratch/work/gn03/src/codegen/config.rs:
/workspace/scratch/work/gn03/src/codegen/descriptors.rs:
/workspace/scratch/work/gn03/src/codegen/encode.rs:
/workspace/scratch/work/gn03/src/codegen/json.rs:
/workspace/scratch/work/gn03/src/codegen/messages.rs:
/workspace/scratch/work/gn03/src/codegen/naming.rs:
/workspace/scratch/work/gn03/src/codegen/native_stubs.rs:
/workspace/scratch/work/gn03/src/codegen/parse.rs:
/workspace/scratch/work/gn03/src/codegen/prost_stubs.rs:
/workspace/scratch/work/gn03/src/codegen/reflection.rs:
/workspace/scratch/work/gn03/src/codegen/text.rs:
/workspace/scratch/work/gn03/src/codegen/tonic_stubs.rs:
/workspace/scratch/work/gn03/src/copy_counts.rs:
/workspace/scratch/work/gn03/src/dynamic.rs:
/workspace/scratch/work/gn03/src/error.rs:
/workspace/scratch/work/gn03/src/gen_support.rs:
/workspace/scratch/work/gn03/src/gencode.rs:
/workspace/scratch/work/gn03/src/generated/mod.rs:
/workspace/scratch/work/gn03/src/internal.rs:
/workspace/scratch/work/gn03/src/json.rs:
/workspace/scratch/work/gn03/src/lazy.rs:
/workspace/scratch/work/gn03/src/map.rs:
/workspace/scratch/work/gn03/src/message.rs:
/workspace/scratch/work/gn03/src/packed.rs:
/workspace/scratch/work/gn03/src/proxied.rs:
/workspace/scratch/work/gn03/src/repeated.rs:
/workspace/scratch/work/gn03/src/rt.rs:
/workspace/scratch/work/gn03/src/runtime.rs:
/workspace/scratch/work/gn03/src/runtime/arena.rs:
/workspace/scratch/work/gn03/src/runtime/array.rs:
/workspace/scratch/work/gn03/src/runtime/decode.rs:
/workspace/scratch/work/gn03/src/runtime/encode.rs:
/workspace/scratch/work/gn03/src/runtime/extension.rs:
/workspace/scratch/work/gn03/src/runtime/layout.rs:
/workspace/scratch/work/gn03/src/runtime/map.rs:
/workspace/scratch/work/gn03/src/runtime/mini_table.rs:
/workspace/scratch/work/gn03/src/runtime/reflect.rs:
/workspace/scratch/work/gn03/src/string.rs:
/workspace/scratch/work/gn03/src/table.rs:
/workspace/scratch/work/gn03/src/testdata.rs:
/workspace/scratch/work/gn03/src/text.rs:
/workspace/scratch/work/gn03/src/wire.rs:
/workspace/scratch/work/gn03/target/integration-consumers/debug/build/pbrs-39df9b576add9f5a/out/conformance_fds.bin:
/workspace/scratch/work/gn03/src/generated/any.rs:
/workspace/scratch/work/gn03/src/generated/duration.rs:
/workspace/scratch/work/gn03/src/generated/empty.rs:
/workspace/scratch/work/gn03/src/generated/field_mask.rs:
/workspace/scratch/work/gn03/src/generated/struct.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_edition2023.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_edition_unstable.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_proto2.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_proto2_editions.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_proto3.rs:
/workspace/scratch/work/gn03/src/generated/test_messages_proto3_editions.rs:
/workspace/scratch/work/gn03/src/generated/timestamp.rs:
/workspace/scratch/work/gn03/src/generated/wrappers.rs:

# env-dep:OUT_DIR=/workspace/scratch/work/gn03/target/integration-consumers/debug/build/pbrs-39df9b576add9f5a/out
