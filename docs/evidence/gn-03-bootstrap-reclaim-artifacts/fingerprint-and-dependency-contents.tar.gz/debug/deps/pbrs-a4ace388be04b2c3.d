/workspace/scratch/work/gn03/target/base/debug/deps/pbrs-a4ace388be04b2c3.d: src/lib.rs src/prelude.rs src/codegen.rs src/codegen/compat_stubs.rs src/codegen/config.rs src/codegen/descriptors.rs src/codegen/encode.rs src/codegen/json.rs src/codegen/messages.rs src/codegen/naming.rs src/codegen/native_stubs.rs src/codegen/parse.rs src/codegen/prost_stubs.rs src/codegen/reflection.rs src/codegen/text.rs src/codegen/tonic_stubs.rs src/copy_counts.rs src/dynamic.rs src/error.rs src/gen_support.rs src/internal.rs src/lazy.rs src/map.rs src/message.rs src/packed.rs src/proxied.rs src/repeated.rs src/rt.rs src/runtime.rs src/runtime/arena.rs src/runtime/array.rs src/runtime/decode.rs src/runtime/encode.rs src/runtime/extension.rs src/runtime/layout.rs src/runtime/map.rs src/runtime/mini_table.rs src/runtime/reflect.rs src/string.rs src/table.rs src/testdata.rs src/wire.rs

/workspace/scratch/work/gn03/target/base/debug/deps/libpbrs-a4ace388be04b2c3.rmeta: src/lib.rs src/prelude.rs src/codegen.rs src/codegen/compat_stubs.rs src/codegen/config.rs src/codegen/descriptors.rs src/codegen/encode.rs src/codegen/json.rs src/codegen/messages.rs src/codegen/naming.rs src/codegen/native_stubs.rs src/codegen/parse.rs src/codegen/prost_stubs.rs src/codegen/reflection.rs src/codegen/text.rs src/codegen/tonic_stubs.rs src/copy_counts.rs src/dynamic.rs src/error.rs src/gen_support.rs src/internal.rs src/lazy.rs src/map.rs src/message.rs src/packed.rs src/proxied.rs src/repeated.rs src/rt.rs src/runtime.rs src/runtime/arena.rs src/runtime/array.rs src/runtime/decode.rs src/runtime/encode.rs src/runtime/extension.rs src/runtime/layout.rs src/runtime/map.rs src/runtime/mini_table.rs src/runtime/reflect.rs src/string.rs src/table.rs src/testdata.rs src/wire.rs

src/lib.rs:
src/prelude.rs:
src/codegen.rs:
src/codegen/compat_stubs.rs:
src/codegen/config.rs:
src/codegen/descriptors.rs:
src/codegen/encode.rs:
src/codegen/json.rs:
src/codegen/messages.rs:
src/codegen/naming.rs:
src/codegen/native_stubs.rs:
src/codegen/parse.rs:
src/codegen/prost_stubs.rs:
src/codegen/reflection.rs:
src/codegen/text.rs:
src/codegen/tonic_stubs.rs:
src/copy_counts.rs:
src/dynamic.rs:
src/error.rs:
src/gen_support.rs:
src/internal.rs:
src/lazy.rs:
src/map.rs:
src/message.rs:
src/packed.rs:
src/proxied.rs:
src/repeated.rs:
src/rt.rs:
src/runtime.rs:
src/runtime/arena.rs:
src/runtime/array.rs:
src/runtime/decode.rs:
src/runtime/encode.rs:
src/runtime/extension.rs:
src/runtime/layout.rs:
src/runtime/map.rs:
src/runtime/mini_table.rs:
src/runtime/reflect.rs:
src/string.rs:
src/table.rs:
src/testdata.rs:
src/wire.rs:
