/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-ef4ae096433a90f1.d: src/bin/codec-inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-ef4ae096433a90f1: src/bin/codec-inventory.rs

src/bin/codec-inventory.rs:
