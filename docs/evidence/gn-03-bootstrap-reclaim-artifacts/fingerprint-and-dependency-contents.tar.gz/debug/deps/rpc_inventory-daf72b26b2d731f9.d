/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-daf72b26b2d731f9.d: src/bin/rpc-inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-daf72b26b2d731f9: src/bin/rpc-inventory.rs

src/bin/rpc-inventory.rs:
