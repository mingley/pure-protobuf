/workspace/scratch/work/gn11/target/base/debug/deps/pbrs-fec2967e1179ef25.d: /workspace/scratch/work/gn11/clippy.toml src/lib.rs src/prelude.rs src/codegen.rs src/codegen/compat_stubs.rs src/codegen/config.rs src/codegen/descriptors.rs src/codegen/encode.rs src/codegen/json.rs src/codegen/messages.rs src/codegen/naming.rs src/codegen/native_stubs.rs src/codegen/parse.rs src/codegen/prost_stubs.rs src/codegen/reflection.rs src/codegen/text.rs src/codegen/tonic_stubs.rs src/copy_counts.rs src/dynamic.rs src/error.rs src/gen_support.rs src/gencode.rs src/generated/mod.rs src/internal.rs src/json.rs src/lazy.rs src/map.rs src/message.rs src/packed.rs src/proxied.rs src/repeated.rs src/rt.rs src/runtime.rs src/runtime/arena.rs src/runtime/array.rs src/runtime/decode.rs src/runtime/encode.rs src/runtime/extension.rs src/runtime/layout.rs src/runtime/map.rs src/runtime/mini_table.rs src/runtime/reflect.rs src/string.rs src/table.rs src/testdata.rs src/text.rs src/wire.rs /workspace/scratch/work/gn11/target/base/debug/build/pbrs-25b6f36d4d5c97ad/out/conformance_fds.bin src/generated/any.rs src/generated/duration.rs src/generated/empty.rs src/generated/field_mask.rs src/generated/struct.rs src/generated/test_messages_edition2023.rs src/generated/test_messages_edition_unstable.rs src/generated/test_messages_proto2.rs src/generated/test_messages_proto2_editions.rs src/generated/test_messages_proto3.rs src/generated/test_messages_proto3_editions.rs src/generated/timestamp.rs src/generated/wrappers.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libpbrs-fec2967e1179ef25.rmeta: /workspace/scratch/work/gn11/clippy.toml src/lib.rs src/prelude.rs src/codegen.rs src/codegen/compat_stubs.rs src/codegen/config.rs src/codegen/descriptors.rs src/codegen/encode.rs src/codegen/json.rs src/codegen/messages.rs src/codegen/naming.rs src/codegen/native_stubs.rs src/codegen/parse.rs src/codegen/prost_stubs.rs src/codegen/reflection.rs src/codegen/text.rs src/codegen/tonic_stubs.rs src/copy_counts.rs src/dynamic.rs src/error.rs src/gen_support.rs src/gencode.rs src/generated/mod.rs src/internal.rs src/json.rs src/lazy.rs src/map.rs src/message.rs src/packed.rs src/proxied.rs src/repeated.rs src/rt.rs src/runtime.rs src/runtime/arena.rs src/runtime/array.rs src/runtime/decode.rs src/runtime/encode.rs src/runtime/extension.rs src/runtime/layout.rs src/runtime/map.rs src/runtime/mini_table.rs src/runtime/reflect.rs src/string.rs src/table.rs src/testdata.rs src/text.rs src/wire.rs /workspace/scratch/work/gn11/target/base/debug/build/pbrs-25b6f36d4d5c97ad/out/conformance_fds.bin src/generated/any.rs src/generated/duration.rs src/generated/empty.rs src/generated/field_mask.rs src/generated/struct.rs src/generated/test_messages_edition2023.rs src/generated/test_messages_edition_unstable.rs src/generated/test_messages_proto2.rs src/generated/test_messages_proto2_editions.rs src/generated/test_messages_proto3.rs src/generated/test_messages_proto3_editions.rs src/generated/timestamp.rs src/generated/wrappers.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/lib.rs:
src/prelude.rs:
src/codegen.rs:
src/codegen/compat_stubs.rs:
src/codegen/config.rs:
src/codegen/descriptors.rs:
src/codegen/encode.rs:
src/codegen/json.rs:
src/codegen/messages.rs:
src/codegen/naming.rs:
src/codegen/native_stubs.rs:
src/codegen/parse.rs:
src/codegen/prost_stubs.rs:
src/codegen/reflection.rs:
src/codegen/text.rs:
src/codegen/tonic_stubs.rs:
src/copy_counts.rs:
src/dynamic.rs:
src/error.rs:
src/gen_support.rs:
src/gencode.rs:
src/generated/mod.rs:
src/internal.rs:
src/json.rs:
src/lazy.rs:
src/map.rs:
src/message.rs:
src/packed.rs:
src/proxied.rs:
src/repeated.rs:
src/rt.rs:
src/runtime.rs:
src/runtime/arena.rs:
src/runtime/array.rs:
src/runtime/decode.rs:
src/runtime/encode.rs:
src/runtime/extension.rs:
src/runtime/layout.rs:
src/runtime/map.rs:
src/runtime/mini_table.rs:
src/runtime/reflect.rs:
src/string.rs:
src/table.rs:
src/testdata.rs:
src/text.rs:
src/wire.rs:
/workspace/scratch/work/gn11/target/base/debug/build/pbrs-25b6f36d4d5c97ad/out/conformance_fds.bin:
src/generated/any.rs:
src/generated/duration.rs:
src/generated/empty.rs:
src/generated/field_mask.rs:
src/generated/struct.rs:
src/generated/test_messages_edition2023.rs:
src/generated/test_messages_edition_unstable.rs:
src/generated/test_messages_proto2.rs:
src/generated/test_messages_proto2_editions.rs:
src/generated/test_messages_proto3.rs:
src/generated/test_messages_proto3_editions.rs:
src/generated/timestamp.rs:
src/generated/wrappers.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
# env-dep:OUT_DIR=/workspace/scratch/work/gn11/target/base/debug/build/pbrs-25b6f36d4d5c97ad/out
