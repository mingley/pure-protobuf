/workspace/scratch/work/gn03/target/base/debug/deps/pbrs_build-d1b288b0ebf3b597.d: tests/pbrs_build.rs

/workspace/scratch/work/gn03/target/base/debug/deps/pbrs_build-d1b288b0ebf3b597: tests/pbrs_build.rs

tests/pbrs_build.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
