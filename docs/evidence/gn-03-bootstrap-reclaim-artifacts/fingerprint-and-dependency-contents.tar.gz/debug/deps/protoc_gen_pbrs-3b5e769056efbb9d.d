/workspace/scratch/work/gn03/target/base/debug/deps/protoc_gen_pbrs-3b5e769056efbb9d.d: src/bin/protoc-gen-pbrs.rs

/workspace/scratch/work/gn03/target/base/debug/deps/protoc_gen_pbrs-3b5e769056efbb9d: src/bin/protoc-gen-pbrs.rs

src/bin/protoc-gen-pbrs.rs:
