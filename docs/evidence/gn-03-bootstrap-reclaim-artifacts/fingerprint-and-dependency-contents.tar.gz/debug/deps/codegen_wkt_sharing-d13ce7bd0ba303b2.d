/workspace/scratch/work/gn11/target/base/debug/deps/codegen_wkt_sharing-d13ce7bd0ba303b2.d: /workspace/scratch/work/gn11/clippy.toml tests/codegen_wkt_sharing.rs tests/support/wkt_consumer.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libcodegen_wkt_sharing-d13ce7bd0ba303b2.rmeta: /workspace/scratch/work/gn11/clippy.toml tests/codegen_wkt_sharing.rs tests/support/wkt_consumer.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
tests/codegen_wkt_sharing.rs:
tests/support/wkt_consumer.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn11
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
