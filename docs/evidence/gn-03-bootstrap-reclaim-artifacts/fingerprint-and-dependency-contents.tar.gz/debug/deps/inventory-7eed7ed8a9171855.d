/workspace/scratch/work/gn11/target/base/debug/deps/inventory-7eed7ed8a9171855.d: /workspace/scratch/work/gn11/clippy.toml src/bin/inventory.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libinventory-7eed7ed8a9171855.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/inventory.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/inventory.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
