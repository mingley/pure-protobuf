/workspace/scratch/work/gn03/target/base/debug/deps/codegen_shared_descriptors-69987e50093c53c2.d: /workspace/scratch/work/gn03/clippy.toml tests/codegen_shared_descriptors.rs Cargo.toml

/workspace/scratch/work/gn03/target/base/debug/deps/libcodegen_shared_descriptors-69987e50093c53c2.rmeta: /workspace/scratch/work/gn03/clippy.toml tests/codegen_shared_descriptors.rs Cargo.toml

/workspace/scratch/work/gn03/clippy.toml:
tests/codegen_shared_descriptors.rs:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
