/workspace/scratch/work/gn03/target/base/debug/deps/onboarding-b52752425d43f52d.d: tests/onboarding.rs tests/../protobuf-tonic/README.md

/workspace/scratch/work/gn03/target/base/debug/deps/onboarding-b52752425d43f52d: tests/onboarding.rs tests/../protobuf-tonic/README.md

tests/onboarding.rs:
tests/../protobuf-tonic/README.md:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
