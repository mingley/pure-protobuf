/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-852a6222cb16d995.d: /workspace/scratch/work/gn11/clippy.toml src/bin/rpc-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/librpc_inventory-852a6222cb16d995.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/rpc-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/rpc-inventory.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
