/workspace/scratch/work/gn11/target/base/debug/deps/documentation-8d65a7dcd7e49a96.d: tests/documentation.rs

/workspace/scratch/work/gn11/target/base/debug/deps/documentation-8d65a7dcd7e49a96: tests/documentation.rs

tests/documentation.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn11
