/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-2196b578f8845558.d: src/bin/rpc-inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/rpc_inventory-2196b578f8845558: src/bin/rpc-inventory.rs

src/bin/rpc-inventory.rs:
