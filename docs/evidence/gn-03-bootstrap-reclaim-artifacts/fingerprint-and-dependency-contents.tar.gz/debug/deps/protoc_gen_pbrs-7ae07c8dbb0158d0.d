/workspace/scratch/work/gn11/target/base/debug/deps/protoc_gen_pbrs-7ae07c8dbb0158d0.d: src/bin/protoc-gen-pbrs.rs

/workspace/scratch/work/gn11/target/base/debug/deps/protoc_gen_pbrs-7ae07c8dbb0158d0: src/bin/protoc-gen-pbrs.rs

src/bin/protoc-gen-pbrs.rs:
