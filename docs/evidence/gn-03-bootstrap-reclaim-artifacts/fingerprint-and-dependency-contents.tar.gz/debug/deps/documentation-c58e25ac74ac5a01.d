/workspace/scratch/work/gn11/target/base/debug/deps/documentation-c58e25ac74ac5a01.d: /workspace/scratch/work/gn11/clippy.toml tests/documentation.rs tests/support/wkt_consumer.rs tests/../docs/codegen-layout.md Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libdocumentation-c58e25ac74ac5a01.rmeta: /workspace/scratch/work/gn11/clippy.toml tests/documentation.rs tests/support/wkt_consumer.rs tests/../docs/codegen-layout.md Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
tests/documentation.rs:
tests/support/wkt_consumer.rs:
tests/../docs/codegen-layout.md:
Cargo.toml:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn11
# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
