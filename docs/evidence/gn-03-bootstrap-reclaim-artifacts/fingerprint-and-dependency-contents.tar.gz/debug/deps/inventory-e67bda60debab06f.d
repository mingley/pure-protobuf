/workspace/scratch/work/gn11/target/base/debug/deps/inventory-e67bda60debab06f.d: src/bin/inventory.rs

/workspace/scratch/work/gn11/target/base/debug/deps/inventory-e67bda60debab06f: src/bin/inventory.rs

src/bin/inventory.rs:
