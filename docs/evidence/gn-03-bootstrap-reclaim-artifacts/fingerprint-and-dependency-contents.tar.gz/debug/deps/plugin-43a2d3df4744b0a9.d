/workspace/scratch/work/gn03/target/base/debug/deps/plugin-43a2d3df4744b0a9.d: tests/plugin.rs tests/fixtures/edition2024/fds/cg14_preview.fds tests/fixtures/edition2024/fds/visibility.fds tests/fixtures/edition2024/fds/defaults.fds tests/fixtures/edition2024/fds/overrides.fds tests/fixtures/edition2024/fds/inheritance.fds tests/fixtures/edition2024/fds/extensions.fds tests/fixtures/edition2024/fds/closed_enum.fds

/workspace/scratch/work/gn03/target/base/debug/deps/plugin-43a2d3df4744b0a9: tests/plugin.rs tests/fixtures/edition2024/fds/cg14_preview.fds tests/fixtures/edition2024/fds/visibility.fds tests/fixtures/edition2024/fds/defaults.fds tests/fixtures/edition2024/fds/overrides.fds tests/fixtures/edition2024/fds/inheritance.fds tests/fixtures/edition2024/fds/extensions.fds tests/fixtures/edition2024/fds/closed_enum.fds

tests/plugin.rs:
tests/fixtures/edition2024/fds/cg14_preview.fds:
tests/fixtures/edition2024/fds/visibility.fds:
tests/fixtures/edition2024/fds/defaults.fds:
tests/fixtures/edition2024/fds/overrides.fds:
tests/fixtures/edition2024/fds/inheritance.fds:
tests/fixtures/edition2024/fds/extensions.fds:
tests/fixtures/edition2024/fds/closed_enum.fds:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn03
