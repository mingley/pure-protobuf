/workspace/scratch/work/gn11/target/base/debug/deps/codec_inventory-781122989391b52a.d: /workspace/scratch/work/gn11/clippy.toml src/bin/codec-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/target/base/debug/deps/libcodec_inventory-781122989391b52a.rmeta: /workspace/scratch/work/gn11/clippy.toml src/bin/codec-inventory.rs Cargo.toml

/workspace/scratch/work/gn11/clippy.toml:
src/bin/codec-inventory.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
