/workspace/scratch/work/gn03/target/base/debug/deps/protoc_gen_pbrs-9cead82ddb22869c.d: /workspace/scratch/work/gn03/clippy.toml src/bin/protoc-gen-pbrs.rs Cargo.toml

/workspace/scratch/work/gn03/target/base/debug/deps/libprotoc_gen_pbrs-9cead82ddb22869c.rmeta: /workspace/scratch/work/gn03/clippy.toml src/bin/protoc-gen-pbrs.rs Cargo.toml

/workspace/scratch/work/gn03/clippy.toml:
src/bin/protoc-gen-pbrs.rs:
Cargo.toml:

# env-dep:CLIPPY_ARGS=-D__CLIPPY_HACKERY__warnings__CLIPPY_HACKERY__
# env-dep:CLIPPY_CONF_DIR
