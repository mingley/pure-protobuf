/workspace/scratch/work/gn11/target/base/debug/deps/codegen_compat-783945308d94081f.d: tests/codegen_compat.rs tests/fixtures/codegen-compat/v1_generated.rs tests/fixtures/codegen-compat/v2_generated.rs

/workspace/scratch/work/gn11/target/base/debug/deps/codegen_compat-783945308d94081f: tests/codegen_compat.rs tests/fixtures/codegen-compat/v1_generated.rs tests/fixtures/codegen-compat/v2_generated.rs

tests/codegen_compat.rs:
tests/fixtures/codegen-compat/v1_generated.rs:
tests/fixtures/codegen-compat/v2_generated.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn11
