/workspace/scratch/work/gn11/target/base/debug/deps/codegen_wkt_sharing-0c51fd7b22c990f3.d: tests/codegen_wkt_sharing.rs tests/support/wkt_consumer.rs

/workspace/scratch/work/gn11/target/base/debug/deps/codegen_wkt_sharing-0c51fd7b22c990f3: tests/codegen_wkt_sharing.rs tests/support/wkt_consumer.rs

tests/codegen_wkt_sharing.rs:
tests/support/wkt_consumer.rs:

# env-dep:CARGO_MANIFEST_DIR=/workspace/scratch/work/gn11
