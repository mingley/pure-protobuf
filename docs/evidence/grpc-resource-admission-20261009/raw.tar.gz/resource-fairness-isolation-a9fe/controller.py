import hashlib,json,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');SOURCE=ROOT/'work/gates-candidate-05f5';OUT=ROOT/'work/resource-fairness-isolation-a9fe';OUT.mkdir(exist_ok=False)
PIN='a9fe4c2d336710cea6f997b00277e6410eee672a'
original=json.loads((ROOT/'work/native-sequential-gates-a9fe-continuation/results.json').read_text())['results'][-1]
BINARY=ROOT/'work/native-sequential-gates-a9fe-continuation/resource_bounds/failed-test'
assert hashlib.sha256(BINARY.read_bytes()).hexdigest()==original['executable_sha256']
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=SOURCE,text=True).strip()==PIN
report=dict(source=PIN,state='running',passed=False,qualified=False,compiler_selected_artifact=original['artifact'],executable_sha256=original['executable_sha256'],runs=[],limits='original mixed fairness test; unchanged workloads, budgets, deadlines and assertions')
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
for repeat in range(30):
 directory=OUT/f'{repeat:02d}';directory.mkdir();args=[str(BINARY),'--exact','test_mixed_bulk_slow_idle_reset_fairness','--test-threads=1'];start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  try:p=subprocess.run(args,cwd=SOURCE,stdout=out,stderr=err,timeout=15);code=p.returncode
  except subprocess.TimeoutExpired:code='watchdog_expired'
 report['runs'].append(dict(command=args,repeat=repeat,exit_code=code,elapsed_seconds=time.monotonic()-start));(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(repeat,code,flush=True)
report.update(state='finished',passed=all(row['exit_code']==0 for row in report['runs']));(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
