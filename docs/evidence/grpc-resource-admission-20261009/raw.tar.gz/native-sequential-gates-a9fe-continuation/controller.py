import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');SOURCE=ROOT/'work/gates-candidate-05f5';OUTPUT=ROOT/'work/native-sequential-gates-a9fe-continuation';OUTPUT.mkdir(exist_ok=False)
PIN='a9fe4c2d336710cea6f997b00277e6410eee672a'
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def clean():assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain','--untracked-files=all')
serial=json.loads((ROOT/'work/server-full-serial-a9fe/results.json').read_text())
assert serial['state']=='finished' and serial['passed']
clean();shutil.copy2(__file__,OUTPUT/'controller.py')
targets=['codegen','lib']+[p.stem for p in sorted((SOURCE/'pbrs-grpc/tests').glob('*.rs')) if p.stem not in ['caller_rustls','codegen']]+['caller_rustls']
completed=set()
prior_reports=['native-sequential-gates-2c66','native-sequential-gates-2c66-continuation','native-sequential-gates-05f5','native-sequential-gates-07e4','native-sequential-gates-a9fe']
for directory in prior_reports:
 prior=json.loads((ROOT/'work'/directory/'results.json').read_text())
 for row in prior['results']:
  if row['exit_code']==0 and 'artifact_error' not in row:
   completed.add('lib' if '--lib' in row['command'] else row['command'][row['command'].index('--test')+1])
completed.add('serving')
targets=[t for t in targets if t not in completed]
os.environ['PROTOC']=str(ROOT/'work/toolchain/protoc/bin/protoc')
os.environ['PATH']=str(ROOT/'work/toolchain/protoc/bin')+os.pathsep+os.environ['PATH']
report=dict(source=PIN,qualified=False,state='running',prior_reports=prior_reports,environment_overrides={'PROTOC':os.environ['PROTOC']},independent_test_threads=1,targets=targets,results=[],limits=['all native library and integration targets on a clean source; no timing or production qualification'])
for name in targets:
 args=['cargo','test','--locked','-p','pbrs-grpc','--all-features',*(['--lib'] if name=='lib' else ['--test',name]),'--message-format=json','--','--test-threads=1']
 directory=OUTPUT/name;directory.mkdir();start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  result=subprocess.run([str(ROOT/'work/run-rust'),*args],cwd=SOURCE,stdout=out,stderr=err)
 record=dict(command=args,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
 artifacts=[]
 for line in (directory/'stdout').read_text().splitlines():
  try:m=json.loads(line)
  except json.JSONDecodeError:continue
  if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(SOURCE/'pbrs-grpc/Cargo.toml') and m.get('target',{}).get('name')==('pbrs_grpc' if name=='lib' else name) and m.get('executable') and m.get('profile',{}).get('test') is True:artifacts.append(m)
 if len(artifacts)==1:
  artifact=artifacts[0];p=Path(artifact['executable']);record['artifact']=artifact
  record['executable_sha256']=sha(p);record['executable_bytes']=p.stat().st_size
  if result.returncode:
   shutil.copy2(p,directory/'failed-test')
  p.unlink();record['inactive_executable_cache_removed']=True
 else:record['artifact_error']='expected one compiler-selected test executable'
 clean();record['source_unchanged']=True
 if name!='lib':
  active=[]
  active_crates=set()
  for proc in Path('/proc').iterdir():
   if proc.name.isdigit():
    try:
     argv=(proc/'cmdline').read_bytes().split(b'\0')
     active.extend(a.decode().split('incremental=',1)[1] for a in argv if a.startswith(b'incremental='))
     if b'--crate-name' in argv:active_crates.add(argv[argv.index(b'--crate-name')+1].decode())
    except (OSError,IndexError,UnicodeDecodeError):pass
  record['inactive_incremental_caches_removed']=[]
  for p in (ROOT/'work/target/debug/incremental').glob(name+'-*'):
   if p.is_dir() and name not in active_crates and str(p) not in active:
    size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file());shutil.rmtree(p);record['inactive_incremental_caches_removed'].append(dict(path=str(p),bytes=size))
 report['results'].append(record);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(targets) and all(r['exit_code']==0 and 'artifact_error' not in r for r in report['results']);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
