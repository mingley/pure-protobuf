"""Validate selected transport source; bind unchanged core to prior complete checks."""
import hashlib,json,os,re,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2]
out=root/'work/all-benchmarks/final-validation';out.mkdir(exist_ok=False)
def git(*args):return subprocess.check_output(['git',*args],cwd=root,text=True).strip()
paths=['src','pbrs-grpc','protobuf-tonic','rpc-bench','tests','scripts','Cargo.toml','Cargo.lock','build.rs','proto','examples','.cargo','.github']
def inputs():
 files=subprocess.check_output(['git','ls-files','-z','--',*paths],cwd=root).split(b'\0')
 return {p.decode():hashlib.sha256((root/p.decode()).read_bytes()).hexdigest() for p in files if p and (root/p.decode()).is_file() and not p.decode().endswith('.md')}
before=inputs();source=git('rev-parse','HEAD')
assert not [p for p in git('diff','HEAD','--name-only','--',*paths).splitlines() if not p.endswith('.md')], 'commit implementation first'
prior=json.loads((root/'work/all-benchmarks/validation/results.json').read_text())
changed={p:dict(before=prior['input_sha256'].get(p),after=h) for p,h in before.items() if prior['input_sha256'].get(p)!=h}
expected={'pbrs-grpc/src/wire/frame_reader.rs','pbrs-grpc/src/wire/encode.rs','pbrs-grpc/src/wire/out_batch.rs','pbrs-grpc/tests/output_workspace.rs','.github/workflows/ci.yml'}
assert set(changed)==expected,changed
frozen=json.loads((root/'work/all-benchmarks/measurement/phase6-source-source.json').read_text())
assert all(before[p]==v['after'] for p,v in frozen['declared_changes'].items())
report=dict(source=source,input_sha256=before,changed_since_prior_validation=changed,prior_validation_source=prior['source'],unchanged_core_prior_validation='validation/results.json',exact_frozen_D_wire_source=True,checks=[],complete=False)
commands=[
 ('format',['cargo','fmt','--all','--check']),
 ('workspace',['cargo','test','--locked','--workspace','--all-features']),
 ('transport-clippy',['cargo','clippy','--locked','--all-features','-p','pbrs-grpc','--lib','--test','output_workspace','--','-D','warnings']),
 ('adapter-clippy',['cargo','clippy','--locked','--all-features','--lib','-p','protobuf-tonic','-p','pbrs-grpc-example-greeter','--','-D','warnings']),
 ('mixed-peers',['cargo','test','--locked','--manifest-path','tests/interop/tonic/Cargo.toml','--tests']),
 ('msrv-native',['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--lib']),
 ('msrv-tower',['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--features','tower','--lib']),
 ('conformance',['./scripts/conformance.sh']),
 ('regenerate',['./scripts/regen-generated.sh','--check']),
]
for name,cmd in commands:
 env=dict(os.environ)
 if name.startswith('msrv-'):env.update(CARGO_TARGET_DIR=str(root/'work/msrv-target'),CARGO_BUILD_JOBS='1')
 if name=='conformance':env.update(CONFORMANCE_OUTPUT_DIR=str(out/'conformance'),NPROC='2')
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exit_code=r.returncode,expected_exit=0,seconds=time.monotonic()-start,log=name+'.log')
 report['checks'].append(row);(out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:
  print((out/(name+'.log')).read_text()[-15000:],flush=True);raise SystemExit(1)
 assert inputs()==before,'production/test inputs changed during validation'
report.update(complete=True,inputs_unchanged=True)
text=(out/'workspace.log').read_text();counts=[tuple(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',text)]
report['workspace_test_counts']=dict(zip(['passed','failed','ignored'],map(sum,zip(*counts))))
(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
