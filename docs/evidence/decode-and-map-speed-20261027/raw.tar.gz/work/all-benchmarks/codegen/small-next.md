# Read-only small-generator follow-up

Source pin: `71422f008b4df06b7c68365a806327b0a4bdfa61`.
This investigation ran during global CPU quiet. No production source, build,
profiler or timed capture was changed or run.

## No unconditional WKT construction

`DescriptorPool::from_file_descriptor_set` (`src/dynamic.rs:1027`) parses only
its supplied FDS. `parse_pool_inner` (`:1038`) collects raw declarations from
those files, and `resolve_pool` (`:3664`) builds those declarations. It does
not insert bundled WKTs. The `pbrs::gencode::conformance_pool` occurrence at
`src/codegen/descriptors.rs:436` is text emitted into generated Rust, not a
call executed by the generator. Removing a supposed global WKT bootstrap
would therefore target work that is not happening.

## Bounded proposal: make the caller an emission participant

`src/codegen/descriptors.rs:736–788` starts `worker_count` scoped threads and
uses the caller only to join them. With the small corpus's two requested
files, that means two new threads plus an idle caller for six messages.
`small-next.patch` changes only this scheduling:

1. Keep the caller's existing configured TLS and immutable index references.
2. Spawn workers for chunks 1..N; run chunk zero on the caller.
3. Gather results in unchanged chunk/target order, joining every worker before
   propagating errors. Sorting/deduplication of output files remains unchanged.

Maximum active emission participants remains N, with N−1 newly spawned
threads. No schema-name, corpus-size, field-count or timing threshold is added.
The source-only prototype is `small-next.descriptors.rs`. It has not been
compiled or measured, so this is a testable proposal, not a demonstrated win.

TLS invariants: `generate_from_code_generator_request` already installs the
resolved configuration on the caller before parallel emission; `emit_one`
clears target-local path state on every target. New workers keep the existing
guard/configuration setup. The caller's outer `CodegenStateGuard` still clears
state on success/error/unwind. The existing sequential path already leaves
caller TLS populated until that guard exits. After parallel work, the only
remaining emitter is `emit_root_mod_rs` (`:1343`), whose module-name helpers do
not consult target-local identifiers or path caches.

Validation before acceptance should cover the existing deterministic/reversed
cross-file tests, WKT ownership and shared-descriptor cases, the independent
configured consumer, and full output hashes for all canonical corpora. Paired
small/100/1000 debug and release timings must preserve the existing 71422
measurements and show any large-schema regression. This proposal changes
scheduling rather than emitted Rust; any output difference is a blocker.

## Larger duplicate-work proposal

The ordinary compile path reads protoc's FDS in `config.rs:1980`, turns it
into a CodeGeneratorRequest in `descriptors.rs:1051–1100`, copies each proto
blob again at request parsing (`:46–52`), then serializes a sorted FDS again
(`:68–74`). A common internal generation core taking borrowed proto-file blobs
could eliminate this roundtrip and per-file copies. Public request and FDS
entrypoints would retain their own wire validation/error mapping. This is a
larger refactor and its small-schema payoff is unmeasured; preserve descriptor
ordering, malformed-input errors, require-files behavior and state guards.

The existing required-field graph builder already returns immediately when
no schema has required fields (`src/codegen/parse.rs:12–28`), so there is no
unconditional reverse-graph construction to remove either.
