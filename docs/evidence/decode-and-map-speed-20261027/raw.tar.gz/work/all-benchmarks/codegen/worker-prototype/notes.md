# Caller participation prototype, phase two

This is an unbuilt, unmeasured one-file overlay on
`71422f008b4df06b7c68365a806327b0a4bdfa61`. Production source remains unchanged.
`inputs.json` records the exact baseline/candidate/patch hashes. The earlier
`small-next.patch` proposal is superseded by this directory's `candidate.patch`,
which adds no `expect` or `unwrap`.

The caller retains the configured request TLS and emits chunk zero. Remaining
chunks use the existing worker guard, resolved configuration and immutable
Arc snapshot installation. The worker-count/chunk-size calculation is
unchanged; actual active emission participants stay bounded by N while new
worker spawns fall from the number of chunks to that number minus one.
There is no corpus-specific or schema-size threshold.

Results keep the exact old target offsets and order: chunk zero's vector,
then worker vectors in chunk order. No emission error is propagated before all
scope participants finish, matching the existing Result accumulation. A caller
chunk panic remains first in chunk order; the scoped join cleanup waits for
remaining workers during unwinding. A worker panic is rethrown from the same
ordered join loop. The internal panic hook naturally runs on whichever thread
executes the chunk; this prototype preserves payload/error precedence, not
thread identity in diagnostic backtraces.

The caller uses the configuration already applied before descriptor analysis.
Per-target `emit_one` resets CURRENT_TARGET and TYPE_PATHS and installs the
current local identifier map. No Rc name map crosses threads. The existing
outer CodegenStateGuard clears caller state on every return or unwind; the
sequential generator already uses that same caller-TLS lifetime. Subsequent
`emit_root_mod_rs` and `shared_descriptor_source` do not consult those local
identifier/path caches.

After global quiet ends, validation should occur entirely in a new isolated
snapshot and preserve the existing 71422 campaign:

- Compile focused codegen units and strict Clippy in the isolated snapshot.
- Compare full file-name/size/SHA output against 71422 for all six synthetic
  request corpora, including repeated requests, reversed target order,
  imported types and option switches.
- Run configured consumer/WKT/shared-descriptor checks to cover state and
  namespace invariants.
- Freeze immutable debug/release drivers and compare all canonical
  small/100/1000 generation/unchanged-output rows before adoption.

No build, test, formatter, profiler or timed run was performed while preparing
this source during global CPU quiet. Allocation/RSS/CPU improvements remain
unproven until these controls and measurements complete.


Follow-up after global quiet ended: the exact prepared descriptor source was
built as part of the phase2 snapshot in both canonical debug and matched
release profiles. All six full-output controls agree with 71422 by file names,
byte counts and SHA-256. Repeated request byte/file counts also agree. See
`../phase2-equivalence/results.json` and the two `../phase2-candidate-*/source.json`
records. Their diagnostic clocks overlapped compilation and are unusable for
shipping performance. `inputs-preparation.json` retains the original unbuilt
preparation stage; `inputs.json` records this follow-up. Production is still
71422 and adoption is pending the complete timed matrix.
