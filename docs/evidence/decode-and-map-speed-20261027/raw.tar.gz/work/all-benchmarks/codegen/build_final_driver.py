"""Build one immutable canonical generation driver from a frozen source.

Debug preserves CG-19's existing bootstrap profile. Release is a separate
matched shipping diagnostic: every peer uses opt3/thin LTO/one codegen unit.
"""
import argparse,hashlib,json,os,shutil,subprocess,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path);p.add_argument('--peer',choices=['pbrs','prost'],required=True);p.add_argument('--profile',choices=['debug','release'],required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
OUT=a.output.resolve();OUT.mkdir(parents=True,exist_ok=False);(OUT/'src').mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
if a.peer=='pbrs':
 assert a.source and a.source.is_dir()
 name='cg19-generator';code=ROOT/'bench/codegen/generator.rs';edition='2024'
 dependency='pbrs={path='+json.dumps(str(a.source.resolve()))+'}'
else:
 name='sb09-prost-driver';code=ROOT/'bench/codegen/prost_driver.rs';edition='2021';dependency='prost-build="=0.14.4"'
shutil.copyfile(code,OUT/'src/main.rs')
(OUT/'Cargo.toml').write_text('[package]\nname='+json.dumps(name)+'\nversion="0.0.0"\nedition='+json.dumps(edition)+'\n[workspace]\n[dependencies]\n'+dependency+'\n[profile.release]\nopt-level=3\nlto="thin"\ncodegen-units=1\n')
ENV=dict(os.environ);ENV.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_RELEASE_OPT_LEVEL='3',CARGO_PROFILE_RELEASE_LTO='thin',CARGO_PROFILE_RELEASE_CODEGEN_UNITS='1')
ENV['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
steps=[]
def run(label,cmd,artifact=False):
 t=time.monotonic()
 with (OUT/(label+'.stdout')).open('w') as stdout,(OUT/(label+'.stderr')).open('w') as stderr:r=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr)
 steps.append(dict(label=label,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-t))
 assert r.returncode==0,(OUT/(label+'.stderr')).read_text()[-8000:]
run('lock',['cargo','generate-lockfile','--offline','--manifest-path',str(OUT/'Cargo.toml')])
if a.peer=='pbrs':run('pin-json',['cargo','update','--offline','--manifest-path',str(OUT/'Cargo.toml'),'-p','serde_json','--precise','1.0.151'])
cmd=['cargo','build','--offline','--locked','--manifest-path',str(OUT/'Cargo.toml'),'--bin',name,'--message-format=json']
if a.profile=='release':cmd.append('--release')
run('build',cmd,True)
artifacts=[x for line in (OUT/'build.stdout').read_text().splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x.get('target',{}).get('name')==name and x.get('executable')]
assert len(artifacts)==1
artifact=artifacts[0];assert artifact['profile']['opt_level']==('0' if a.profile=='debug' else '3')
shutil.copy2(artifact['executable'],OUT/'driver')
sources={str(x.relative_to(a.source)):sha(x) for x in sorted(a.source.rglob('*')) if x.is_file()} if a.source else None
record=dict(peer=a.peer,profile=a.profile,steps=steps,source_path=str(a.source.resolve()) if a.source else None,source_sha256=sources,
 driver_source_sha256=sha(OUT/'src/main.rs'),driver_source_original=str(code),
 driver_source_original_sha256=sha(code),manifest_sha256=sha(OUT/'Cargo.toml'),lock_sha256=sha(OUT/'Cargo.lock'),
 executable=str(OUT/'driver'),executable_sha256=sha(OUT/'driver'),cargo_artifact=artifact,
 environment={k:ENV.get(k) for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_RELEASE_OPT_LEVEL','CARGO_PROFILE_RELEASE_LTO','CARGO_PROFILE_RELEASE_CODEGEN_UNITS','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','RUSTC_WRAPPER']},
 limitations=['debug preserves canonical CG-19 bootstrap opt0; debug information disabled consistently.',
 'Release generator timing is separate from historical debug results and uses matched shipping flags on every peer.',
 'Generation output includes pbrs default reflection/JSON/text; Prost emits its default derive-based surface.',
 'Build elapsed time is provenance, not a generation-speed result.'])
(OUT/'source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(ready=True,peer=a.peer,profile=a.profile,binary=str(OUT/'driver'),sha256=sha(OUT/'driver'))),flush=True)
