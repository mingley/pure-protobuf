"""Freeze exact name-cache source overlays and build the existing CG-19 drivers.

Timings are performed separately after the root grants global CPU quiet.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
BASE = ROOT / 'work/all-benchmarks/measurement/baseline-source'
CANDIDATE = OUT / 'candidate-source'
PATHS = ['src/codegen/naming.rs', 'src/codegen/config.rs', 'src/codegen/extensions.rs']
ENV = dict(os.environ)
ENV.update(CARGO_HOME=str(ROOT/'work/cargo'), RUSTUP_HOME=str(ROOT/'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT/'target'), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH'] = str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def files(base):
    return {str(p.relative_to(base)):sha(p) for p in sorted(base.rglob('*')) if p.is_file()}
def step(label, cmd):
    with (OUT/(label+'.log')).open('w') as log:
        r = subprocess.run(cmd, cwd=ROOT, env=ENV, stdout=log, stderr=subprocess.STDOUT)
    if r.returncode:
        print((OUT/(label+'.log')).read_text()[-8000:])
        raise SystemExit(r.returncode)

assert not CANDIDATE.exists(), 'Fresh output required'
shutil.copytree(BASE, CANDIDATE)
for path in PATHS:
    shutil.copyfile(ROOT/path, CANDIDATE/path)
before, after = files(BASE), files(CANDIDATE)
assert set(before) == set(after)
assert [p for p in before if before[p] != after[p]] == sorted(PATHS)
(OUT/'source.json').write_text(json.dumps(dict(baseline='0287879dcfe381424cf9aabc919d9fea700dbe39',
    baseline_path=str(BASE), candidate_path=str(CANDIDATE), baseline_sha256=before,
    candidate_sha256=after, changed=PATHS), indent=2)+'\n')
for path in PATHS:
    dest=OUT/'overlay'/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(ROOT/path,dest)

records=[]
for side, source, probe in [('baseline',BASE,'canonical'),('candidate',CANDIDATE,'canonical'),
                            ('prost',None,'canonical'),
                            ('baseline',BASE,'allocations'),('candidate',CANDIDATE,'allocations')]:
    dest=OUT/(side+'-'+probe)
    (dest/'src').mkdir(parents=True)
    if probe=='allocations':
        code=ROOT/'work/codegen_resolution/src/main.rs'
        name='codegen-resolution-probe'
        manifest=f'''[package]
name="{name}"
version="0.0.0"
edition="2024"
[workspace]
[dependencies]
pbrs={{path={json.dumps(str(source))}}}
[features]
default=["allocation-counts"]
allocation-counts=[]
'''
    elif side=='prost':
        code=ROOT/'bench/codegen/prost_driver.rs'
        name='sb09-prost-driver'
        manifest='''[package]
name="sb09-prost-driver"
version="0.0.0"
edition="2021"
[workspace]
[dependencies]
prost-build="=0.14.4"
'''
    else:
        code=ROOT/'bench/codegen/generator.rs'
        name='cg19-generator'
        manifest=f'''[package]
name="cg19-generator"
version="0.0.0"
edition="2024"
[workspace]
[dependencies]
pbrs={{path={json.dumps(str(source))}}}
[profile.release]
opt-level=3
lto="thin"
codegen-units=1
'''
    shutil.copyfile(code,dest/'src/main.rs')
    (dest/'Cargo.toml').write_text(manifest)
    step(side+'-'+probe+'-lock',['cargo','generate-lockfile','--offline','--manifest-path',str(dest/'Cargo.toml')])
    if side!='prost':
        step(side+'-'+probe+'-pin-json',['cargo','update','--offline','--manifest-path',str(dest/'Cargo.toml'),'-p','serde_json','--precise','1.0.151'])
    command=['cargo','build','--offline','--locked','--manifest-path',str(dest/'Cargo.toml'),'--bin',name,'--message-format=json']
    artifacts=dest/'build.jsonl'
    with artifacts.open('w') as stdout,(dest/'build.stderr').open('w') as stderr:
        result=subprocess.run(command,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr)
    assert result.returncode==0,(side,probe,(dest/'build.stderr').read_text()[-8000:])
    matches=[]
    for line in artifacts.read_text().splitlines():
        row=json.loads(line)
        if row.get('reason')=='compiler-artifact' and row.get('target',{}).get('name')==name and row.get('executable'):
            matches.append(row)
    assert len(matches)==1
    row=matches[0]
    assert row['profile']['opt_level']=='0'
    executable=Path(row['executable'])
    frozen=OUT/(side+'-'+probe+'-driver')
    shutil.copy2(executable,frozen)
    records.append(dict(side=side,probe=probe,command=command,
        lock_sha256=sha(dest/'Cargo.lock'),source_sha256=sha(dest/'src/main.rs'),
        binary=str(frozen),binary_sha256=sha(frozen),cargo_artifact=row,
        note='Existing CG-19 debug bootstrap profile, debug info disabled consistently for all three peers; no allocation counters in canonical drivers.'))
    print(json.dumps(dict(side=side,probe=probe,ready=True,binary=str(frozen))),flush=True)
(OUT/'builds.json').write_text(json.dumps(dict(records=records,environment={
    k:ENV[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_TARGET_DIR']},
    canonical_sources_unchanged=True),indent=2)+'\n')
assert (OUT/'baseline-canonical/Cargo.lock').read_bytes()==(OUT/'candidate-canonical/Cargo.lock').read_bytes()
assert (OUT/'baseline-allocations/Cargo.lock').read_bytes()==(OUT/'candidate-allocations/Cargo.lock').read_bytes()
print('All five drivers ready; no measurements were run.',flush=True)
