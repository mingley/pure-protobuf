# Generator spelling reuse

The generator's per-message field-name caches now hold `Rc<str>` spellings.
Emitters clone a thread-local pointer instead of allocating and copying the
same identifier/raw-name strings for every emitter lookup. A normal field's
raw and Rust identifiers share the same allocation when their spellings agree.
Scalar and map type names now use borrowed `Cow<'static, str>` values for fixed
spellings such as `i32` and `pbrs::rt::LazyStr`. Message paths remain owned when
they need formatting. Field storage spellings follow the same rule. This
removes temporary String allocation for type names used only by formatting.
Worker state stays thread-local; this introduces no atomics, cross-thread
borrows, global intern table, or generated-source dependency on `Rc`.

The public generator API and emitted spellings are unchanged. Three newly
reserved merge-helper names are a separate integration requirement: schemas
using those exact field names receive the established `_field` collision suffix.
An initial Rc-only build predates those reservations; it was never measured,
and its binaries/source overlays are retained separately as `*-rc-only`.
The current isolated Rc+Cow candidate includes the reservations. Standard
benchmark corpora contain none of those names.

`build_drivers.py` builds the exact existing CG-19 `generator.rs` and
`prost_driver.rs` sources without changing their timed work. The canonical
harness bootstraps debug drivers, not release drivers. All three frozen peers
use opt-level 0, disabled debug information, no incremental compilation and
one Cargo build job. Baseline and candidate locks match byte for byte, with
serde_json 1.0.151 pinned to the repository version; Prost is pinned to 0.14.4.
Cargo's JSON compiler artifact supplies each executable path, and copied
shipping binaries have recorded SHA-256 hashes. Two additional allocation
helpers use the earlier six-workload request corpus and a distinct counting
allocator build; those captures must not supply shipping CPU claims.

The candidate source snapshot differs from baseline `0287879d` in exactly
four generator files. Its source manifest derives the actual 599 file hashes.
It excludes concurrent decoder/map/transport changes, so output equivalence
and cost attribution remain scoped to spelling reuse. The isolated messages.rs
overlay excludes the parent agent's new lazy-merge macro call region. A final integrated
production comparison requires its own source binding.

No measurements were run during compilation. Timing and allocation captures
are delegated to the benchmark coordinator after global CPU quiet is granted.


The live focused codegen suite passes all 25 tests after both Rc and Cow
changes; strict core-library Clippy with all features and warnings denied also
passes. Logs are `unit-cow.log` and `clippy-cow.log`.

`build_final_driver.py` builds a fresh immutable CLI from the final integrated
source snapshot. It supports canonical debug drivers and a separate matched
release diagnostic (opt3, thin LTO, one codegen unit for all peers). Final
production timing must use those integrated binaries rather than claiming
this isolated spelling-only candidate includes unrelated decoder changes.
