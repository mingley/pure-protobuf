"""Untimed allocation/output-equivalence proof for the isolated spelling change."""
import hashlib,json,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
OUT=BASE/'allocation-equivalence';OUT.mkdir(exist_ok=False)
CASES=[('single_100_full',1,100,8,False,False),('twenty_1000_full',20,50,8,False,False),('twenty_1000_shared_lean',20,50,8,True,True),('hundred_1000_shared_lean',100,10,4,True,True),('hundred_1000_shared_full',100,10,4,True,False),('hundred_1000_full',100,10,4,False,False)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
for name,files,messages,fields,shared,lean in CASES:
 pair={}
 for side in ['baseline','candidate']:
  dest=OUT/name/side;dest.mkdir(parents=True)
  binary=BASE/(side+'-allocations-driver')
  cmd=[str(binary),str(files),str(messages),str(fields),str(shared).lower(),str(lean).lower(),str(dest),'2','true']
  r=subprocess.run(cmd,text=True,capture_output=True,timeout=180)
  (dest/'stdout.jsonl').write_text(r.stdout);(dest/'stderr.log').write_text(r.stderr)
  assert r.returncode==0,r.stderr
  samples=[json.loads(line) for line in r.stdout.splitlines()]
  assert len(samples)==2 and all(s['allocation_counts'] for s in samples)
  generated={str(p.relative_to(dest)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(dest.rglob('*.rs'))}
  row=dict(case=name,side=side,command=cmd,exit_code=r.returncode,binary_sha256=sha(binary),input_sha256=sha(dest/'request.bin'),samples=samples,generated=generated,
      timing_qualified=False,timing_usable=False,scope='Counter-instrumented allocation and output-equivalence proof; clocks retained but cannot supply shipping timing claims.')
  (dest/'capture.json').write_text(json.dumps(row,indent=2)+'\n');rows.append(row);pair[side]=row
  for p in dest.rglob('*.rs'):p.unlink()
 a,b=pair['baseline'],pair['candidate'];assert a['input_sha256']==b['input_sha256'] and a['generated']==b['generated']
 print(json.dumps(dict(case=name,byte_identical=True,baseline=a['samples'][1]['allocations'],candidate=b['samples'][1]['allocations'])),flush=True)
summary=[]
for name,*_ in CASES:
 a=next(r for r in rows if r['case']==name and r['side']=='baseline');b=next(r for r in rows if r['case']==name and r['side']=='candidate')
 summary.append(dict(case=name,byte_identical_output=True,input_sha256=a['input_sha256'],generated_files=len(a['generated']),generated_bytes=sum(x['bytes'] for x in a['generated'].values()),
     allocation={k:dict(before=a['samples'][1][k],after=b['samples'][1][k],percent=100*(b['samples'][1][k]/a['samples'][1][k]-1) if a['samples'][1][k] else None) for k in ['allocations','requested_bytes','peak_live_delta','retained_delta']}))
(OUT/'results.json').write_text(json.dumps(dict(complete=True,qualified=False,source_scope='Rc/Cow spelling-only isolation; final production decoder changes excluded',all_byte_identical=True,shipping_performance_claim=False,rows=rows,cases=summary,limitations=['Counter instrumentation and concurrent compilation make CPU/wall timings unusable.','One fresh process per side/case and two generations; sample0cold/sample1warm; not a statistically repeated allocation campaign.','Requested allocator bytes and peak requested-live bytes are not RSS.','Parallel worker overlap may vary peak-live counters; preserve all rows rather than claiming universal peak reduction.']),indent=2)+'\n')
