"""Add only mechanical Cow spelling changes to the isolated generator candidate."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];OUT=Path(__file__).resolve().parent
CAND=OUT/'candidate-source';BASE=ROOT/'work/all-benchmarks/measurement/baseline-source'
PATHS=['src/codegen/config.rs','src/codegen/extensions.rs','src/codegen/messages.rs','src/codegen/naming.rs']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
shutil.copyfile(OUT/'source.json',OUT/'source-rc-only.json')
shutil.copytree(OUT/'overlay',OUT/'overlay-rc-only')
old=json.loads((OUT/'builds.json').read_text())
for r in old['records']:
 if r['side']=='candidate':
  oldpath=Path(r['binary']);new=oldpath.with_name(oldpath.name+'-rc-only')
  shutil.copy2(oldpath,new);r['original_frozen_path']=str(oldpath);r['binary']=str(new)
(OUT/'builds-rc-only.json').write_text(json.dumps(old,indent=2)+'\n')
for p in PATHS:
 if not p.endswith('messages.rs'):shutil.copyfile(ROOT/p,CAND/p)
s=(BASE/'src/codegen/messages.rs').read_text().replace('use super::*;\n','use super::*;\nuse std::borrow::Cow;\n',1)
a=s.index('pub(crate) fn field_storage_ty(');b=s.index('\n}\n',a)+3
live=(ROOT/'src/codegen/messages.rs').read_text();la=live.index('pub(crate) fn field_storage_ty(');lb=live.index('\n}\n',la)+3
s=s[:a]+live[la:lb]+s[b:]
s=s.replace('enum_ty.as_deref().unwrap_or(t.as_str())','enum_ty.as_deref().unwrap_or(t.as_ref())',1)
s=s.replace('        format!("impl Into<{t}>")\n    } else {\n        t.clone()', '        format!("impl Into<{t}>").into()\n    } else {\n        t.clone()',1)
(CAND/'src/codegen/messages.rs').write_text(s)
ENV=dict(os.environ);ENV.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
subprocess.run(['rustfmt','--edition','2024',*[str(CAND/p) for p in PATHS]],cwd=ROOT,env=ENV,check=True)
before={str(p.relative_to(BASE)):sha(p) for p in sorted(BASE.rglob('*')) if p.is_file()}
after={str(p.relative_to(CAND)):sha(p) for p in sorted(CAND.rglob('*')) if p.is_file()}
assert set(before)==set(after)
assert [p for p in before if before[p]!=after[p]]==PATHS
(OUT/'source.json').write_text(json.dumps(dict(baseline='0287879dcfe381424cf9aabc919d9fea700dbe39',baseline_path=str(BASE),candidate_path=str(CAND),baseline_sha256=before,candidate_sha256=after,changed=PATHS,note='Rc field spellings and Cow static type/storage spellings; concurrent lazy merge/parser/runtime changes excluded.'),indent=2)+'\n')
for path in PATHS:
 dest=OUT/'overlay'/path;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(CAND/path,dest)
records=[r for r in old['records'] if r['side']!='candidate']
for probe,name in [('canonical','cg19-generator'),('allocations','codegen-resolution-probe')]:
 dest=OUT/('candidate-'+probe)
 cmd=['cargo','build','--offline','--locked','--manifest-path',str(dest/'Cargo.toml'),'--bin',name,'--message-format=json']
 with (dest/'build-cow.jsonl').open('w') as stdout,(dest/'build-cow.stderr').open('w') as stderr:r=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr)
 assert r.returncode==0,(dest/'build-cow.stderr').read_text()[-8000:]
 matches=[x for line in (dest/'build-cow.jsonl').read_text().splitlines() if (x:=json.loads(line)).get('reason')=='compiler-artifact' and x.get('target',{}).get('name')==name and x.get('executable')]
 assert len(matches)==1
 row=matches[0];assert row['profile']['opt_level']=='0'
 frozen=OUT/('candidate-'+probe+'-driver');shutil.copy2(row['executable'],frozen)
 records.append(dict(side='candidate',probe=probe,command=cmd,lock_sha256=sha(dest/'Cargo.lock'),source_sha256=sha(dest/'src/main.rs'),binary=str(frozen),binary_sha256=sha(frozen),cargo_artifact=row,note='Isolated Rc+Cow spelling change; debug opt0/debug0 consistently.'))
 print(json.dumps(dict(probe=probe,ready=True)),flush=True)
(OUT/'builds.json').write_text(json.dumps(dict(records=records,environment={k:ENV[k] for k in ['CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_TARGET_DIR']},canonical_sources_unchanged=True),indent=2)+'\n')
print('Updated isolated candidate ready; no measurements run.',flush=True)
