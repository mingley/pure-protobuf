"""Check complete generated output for all six request corpora, no timing claim."""
import hashlib,json,os,shutil,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];BASE=Path(__file__).resolve().parent
OUT=BASE/'phase2-equivalence';OUT.mkdir(exist_ok=False)
ENV=dict(os.environ);ENV.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+ENV['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
records={}
for side,source in [('before',ROOT/'work/all-benchmarks/measurement/candidate-source'),('after',ROOT/'work/all-benchmarks/measurement/phase2-source')]:
 dest=OUT/(side+'-helper');(dest/'src').mkdir(parents=True)
 shutil.copyfile(ROOT/'work/codegen_resolution/src/main.rs',dest/'src/main.rs')
 (dest/'Cargo.toml').write_text('[package]\nname="codegen-resolution-probe"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\npbrs={path='+json.dumps(str(source))+'}\n[features]\ndefault=[]\nallocation-counts=[]\n')
 commands=[['cargo','generate-lockfile','--offline','--manifest-path',str(dest/'Cargo.toml')],['cargo','update','--offline','--manifest-path',str(dest/'Cargo.toml'),'-p','serde_json','--precise','1.0.151'],['cargo','build','--offline','--locked','--manifest-path',str(dest/'Cargo.toml'),'--message-format=json']]
 for n,cmd in enumerate(commands):
  with (dest/f'step-{n}.stdout').open('w') as stdout,(dest/f'step-{n}.stderr').open('w') as stderr:r=subprocess.run(cmd,cwd=ROOT,env=ENV,stdout=stdout,stderr=stderr)
  assert r.returncode==0,(dest/f'step-{n}.stderr').read_text()[-8000:]
 artifacts=[r for l in (dest/'step-2.stdout').read_text().splitlines() if (r:=json.loads(l)).get('reason')=='compiler-artifact' and r.get('target',{}).get('name')=='codegen-resolution-probe' and r.get('executable')]
 assert len(artifacts)==1 and artifacts[0]['features']==['default']
 shutil.copy2(artifacts[0]['executable'],dest/'driver')
 records[side]=dict(source_path=str(source),commands=commands,artifact=artifacts[0],binary_sha256=sha(dest/'driver'),lock_sha256=sha(dest/'Cargo.lock'),helper_source_sha256=sha(dest/'src/main.rs'))
 print(json.dumps(dict(side=side,built=True)),flush=True)
assert (OUT/'before-helper/Cargo.lock').read_bytes()==(OUT/'after-helper/Cargo.lock').read_bytes()
CASES=[('single_100_full',1,100,8,False,False),('twenty_1000_full',20,50,8,False,False),('twenty_1000_shared_lean',20,50,8,True,True),('hundred_1000_shared_lean',100,10,4,True,True),('hundred_1000_shared_full',100,10,4,True,False),('hundred_1000_full',100,10,4,False,False)]
rows=[]
for name,n,m,f,shared,lean in CASES:
 pair={}
 for side in ['before','after']:
  dest=OUT/'captures'/name/side;dest.mkdir(parents=True)
  cmd=[str(OUT/(side+'-helper')/'driver'),str(n),str(m),str(f),str(shared).lower(),str(lean).lower(),str(dest),'2','true']
  r=subprocess.run(cmd,cwd=ROOT,env=ENV,capture_output=True,text=True,timeout=180)
  (dest/'stdout.jsonl').write_text(r.stdout);(dest/'stderr.log').write_text(r.stderr)
  assert r.returncode==0,r.stderr
  samples=[json.loads(l) for l in r.stdout.splitlines()];assert len(samples)==2 and all(not s['allocation_counts'] for s in samples)
  generated={str(p.relative_to(dest)):dict(bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(dest.rglob('*.rs'))}
  pair[side]=dict(case=name,side=side,command=cmd,exit_code=r.returncode,input_sha256=sha(dest/'request.bin'),samples=samples,generated=generated,timing_usable=False)
  (dest/'capture.json').write_text(json.dumps(pair[side],indent=2)+'\n')
  for p in dest.rglob('*.rs'):p.unlink()
 assert pair['before']['input_sha256']==pair['after']['input_sha256']
 assert pair['before']['generated']==pair['after']['generated'],name
 rows.append(dict(case=name,byte_identical_output=True,generated_files=len(pair['before']['generated']),generated_bytes=sum(f['bytes'] for f in pair['before']['generated'].values()),input_sha256=pair['before']['input_sha256'],captures=pair))
 print(json.dumps(dict(case=name,byte_identical_output=True)),flush=True)
result=dict(complete=True,all_byte_identical=True,baseline_commit='71422f008b4df06b7c68365a806327b0a4bdfa61',candidate_scope='71422 plus phase2 ReadyLazy small-map cache and caller-participation generator overlay',instrumented=False,timing_claim=False,records=records,cases=rows,limits=['Two generations per process exercise repeated request reset; one fresh process per side/case.','CPU/wall samples overlap compilation and are retained only as unusable diagnostics.','Canonical frontend/timing comparison is separate; this checks the full synthetic direct-request output.'])
(OUT/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print('All six corpora preserve byte-identical output.',flush=True)
