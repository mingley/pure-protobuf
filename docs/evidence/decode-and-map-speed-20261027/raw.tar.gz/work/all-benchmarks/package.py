"""Package adopted compressed-only D results and earlier source-scoped evidence.

Run only after CPU quiet, adoption and final validation have finished.
The older 71422 checks remain explicitly scoped to that revision.
"""
import csv
import hashlib
import io
import json
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/evidence/decode-and-map-speed-20261027'
BASELINE = '0287879dcfe381424cf9aabc919d9fea700dbe39'
CORE = '71422f008b4df06b7c68365a806327b0a4bdfa61'
TIMER_REF = 'd66e8d06'
SELECTED_PHASE = 'phase6'
SELECTED_TAG = 'd'
SELECTED_LABEL = 'compressed-only D'
# Root may update this one path when the independent D report is published.
SELECTED_REVIEW = 'work/all-benchmarks/review/output-retention/d-results.json'
SELECTED_PATHS = {
    'pbrs-grpc/src/wire/frame_reader.rs',
    'pbrs-grpc/src/wire/encode.rs',
    'pbrs-grpc/src/wire/out_batch.rs',
}
NOISE_TEST = 'pbrs-grpc/tests/output_workspace.rs'
CI = '.github/workflows/ci.yml'
PARITY_CI = '.github/workflows/parity.yml'
TIMER_PATHS = {'bench/codegen/run.py', 'bench/codegen/test_run.py'}
EXTENSIONS = {
    '.json', '.jsonl', '.log', '.rs', '.py', '.md', '.toml', '.lock',
    '.patch', '.diff', '.csv', '.c', '.stderr', '.stdout', '.proto',
    '.txt', '.sh', '.yml', '.yaml', '.callgrind', '.stack', '.trace',
}
SKIP_DIRS = {
    'target', '.git', '__pycache__', 'artifacts', 'generated', 'outputs',
    'representative-generated', 'time-package', 'apt', 'packages',
}


def read(path):
    return json.loads((ROOT / path).read_text())


def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2) + '\n').encode()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def excluded_directory(relative):
    # Compact overlays contain exact changed source, including src/generated.
    # They are not full checkouts or representative generator outputs. Keep
    # their generated SDK bindings while retaining actual cache exclusions.
    if 'source-overlays' in relative.parts:
        return any(part in {'target', '.git', '__pycache__'}
                   for part in relative.parts)
    return (
        any(part in SKIP_DIRS for part in relative.parts)
        or any(part.endswith('-source') or part.startswith('reconstructed-')
               for part in relative.parts)
        or relative.parts[:2] == ('owned-conformance', 'source')
    )


def safe_relative_name(name):
    path = PurePosixPath(name)
    return (bool(name) and not path.is_absolute() and str(path) == name
            and not any(part in ('.', '..') for part in path.parts)
            and '\\' not in name and ':' not in name)


def verify_overlay_members(files):
    prefix = 'work/all-benchmarks/measurement/source-overlays'
    manifest_name = prefix + '/manifest.json'
    require(manifest_name in files, 'Portable overlay manifest missing')
    manifest = json.loads(files[manifest_name])
    needed = {'baseline', 'candidate', 'phase2', 'phase3', 'phase4', 'phase5', SELECTED_PHASE}
    require(needed <= set(manifest['variants']), 'A required historical or selected overlay is missing')
    inventory = {}
    for variant, record in manifest['variants'].items():
        require(safe_relative_name(variant) and PurePosixPath(variant).name == variant,
                'Unsafe source variant name')
        for path in record['changed']:
            require(safe_relative_name(path), 'Unsafe overlay path: ' + path)
            member = prefix + '/' + variant + '/' + path
            require(member in files, 'Required source overlay omitted: ' + member)
            require(path in record['files'], 'Overlay has no declared hash: ' + member)
            require(sha(files[member]) == record['files'][path],
                    'Source overlay hash differs: ' + member)
        for path in record['removed']:
            require(safe_relative_name(path), 'Unsafe removed source path: ' + path)
            require(path not in record['files'], 'Removed source still declared: ' + path)
        inventory[variant] = dict(changed_files=len(record['changed']),
                                  removed_files=len(record['removed']),
                                  reconstructed_source_files=len(record['files']))
    return manifest, inventory


def verify_archived_overlays(archive_path, overlay_manifest):
    """Reconstruct every variant using actual archived overlay bytes, not disk copies."""
    prefix = 'work/all-benchmarks/measurement/'
    script_name = prefix + 'reconstruct_variant.py'
    results = []
    with tempfile.TemporaryDirectory(prefix='pbrs-capsule-overlays-') as temporary:
        temporary = Path(temporary)
        with tarfile.open(archive_path, 'r:gz') as archive:
            for member in archive:
                if member.name != script_name and not member.name.startswith(prefix + 'source-overlays/'):
                    continue
                require(member.isfile() and safe_relative_name(member.name),
                        'Unsafe archived source overlay')
                target = temporary / member.name
                target.parent.mkdir(parents=True, exist_ok=True)
                stream = archive.extractfile(member)
                require(stream is not None, 'Missing archived source content')
                target.write_bytes(stream.read())
        script = temporary / script_name
        require(script.is_file(), 'Archived reconstruction helper omitted')
        for variant in overlay_manifest['variants']:
            output = temporary / 'variants' / variant
            command = [sys.executable, str(script), str(ROOT), str(output), variant]
            done = subprocess.run(command, capture_output=True, text=True)
            results.append(dict(variant=variant, command=command,
                                exit_code=done.returncode,
                                stdout=done.stdout, stderr=done.stderr))
            require(done.returncode == 0, 'Archived source reconstruction failed: ' + variant)
            # Keep temporary disk use bounded to one full source tree at a time.
            shutil.rmtree(output)
    return dict(complete=True, archive_members_used=True,
                variant_count=len(results), variants=results)


def write_checker():
    template = (ROOT / 'docs/evidence/efficiency-20261027/check.py').read_text()
    marker = 'expected = manifest["files"]\n'
    require(template.count(marker) == 1, 'Historical checker template changed')
    companion_checks = '''# Optional standalone navigation files are part of this record too.
companion_files = manifest.get("companion_files", {})
require(isinstance(companion_files, dict), "Invalid companion inventory")
for name, record in companion_files.items():
    require(
        isinstance(name, str)
        and safe_name(name)
        and PurePosixPath(name).name == name,
        "Unsafe companion basename",
    )
    require(isinstance(record, dict), "Invalid companion record")
    path = root / name
    require(path.is_file() and not path.is_symlink(), "Missing or linked companion")
    data = path.read_bytes()
    require(len(data) == record["bytes"], "Companion size mismatch")
    require(digest(data) == record["sha256"], "Companion checksum mismatch")
'''
    (OUT / 'check.py').write_text(template.replace(marker, companion_checks + marker, 1))


def main():
    prior = read('work/all-benchmarks/validation/results.json')
    final = read('work/all-benchmarks/final-validation/results.json')
    owned = read('work/all-benchmarks/owned-conformance/results.json')
    performance = read(f'work/all-benchmarks/measurement/{SELECTED_PHASE}-results.json')
    phase1 = read('work/all-benchmarks/measurement/results.json')
    selected_source = read(f'work/all-benchmarks/measurement/{SELECTED_PHASE}-source-source.json')
    selected_review = read(SELECTED_REVIEW)
    historical_c = read('work/all-benchmarks/measurement/phase5-results.json')
    commit = git('rev-parse', 'HEAD').decode().strip()
    timer = git('rev-parse', TIMER_REF).decode().strip()

    require(prior['complete'] and prior['inputs_unchanged'], '71422 validation incomplete')
    require(prior['source'] == CORE, 'Earlier full validation source changed')
    require(owned['complete'] and owned['all_passed'], 'Earlier owned conformance incomplete')
    require(owned['source_commit'] == CORE, 'Owned conformance source is not 71422')
    require(final['complete'] and final['inputs_unchanged'], 'Final validation incomplete')
    require(final['source'] == commit, 'HEAD differs from final validated implementation')
    require(performance.get('complete') is True, 'Selected transport campaign incomplete')
    require(not selected_review['blocking_findings'], 'Selected transport review has a blocker')
    for ancestor in (CORE, timer):
        subprocess.check_call(['git', 'merge-base', '--is-ancestor', ancestor, commit], cwd=ROOT)

    # Never reassign the earlier full 26-gate/conformance source SHA to the final transport revision.
    changed = set(git('diff', '--name-only', CORE, commit).decode().splitlines())
    non_markdown = {path for path in changed if not path.endswith('.md')}
    allowed = SELECTED_PATHS | TIMER_PATHS | {NOISE_TEST, CI}
    require(non_markdown <= allowed, 'Unexpected post-71422 code changes: ' + str(non_markdown - allowed))
    require(SELECTED_PATHS | {NOISE_TEST, CI} <= non_markdown,
            'Selected wire files, permanent noise test or CI gate were not committed')
    final_hashes = final['input_sha256']
    for path, expected in final_hashes.items():
        require(sha((ROOT / path).read_bytes()) == expected, 'Final validated input changed: ' + path)

    declared = selected_source['declared_changes']
    require(set(declared) == SELECTED_PATHS, 'Selected transport overlay file set changed')
    selected_files = {}
    for path in sorted(SELECTED_PATHS):
        data = git('show', commit + ':' + path)
        require(sha(data) == declared[path]['after'], 'Final transport differs from frozen RPC source: ' + path)
        require(selected_review['source_sha256'][path] == declared[path]['after'], 'Selected review hash differs: ' + path)
        selected_files[path] = data
    noise_data = git('show', commit + ':' + NOISE_TEST)
    ci_files = {path: git('show', commit + ':' + path) for path in (CI, PARITY_CI)}
    timer_files = {path: git('show', commit + ':' + path) for path in sorted(TIMER_PATHS)}
    for path, data in timer_files.items():
        require(data == git('show', timer + ':' + path), 'Timer source changed after d66: ' + path)

    companions = {}
    companion_sources = {
        'timing.csv': f'{SELECTED_PHASE}-timing-ledger.csv',
        'resources.csv': f'{SELECTED_PHASE}-resource-ledger.csv',
        'all-win-gate.json': f'{SELECTED_PHASE}-all-win-gate.json',
    }
    measurement = ROOT / 'work/all-benchmarks/measurement'
    for name, source in companion_sources.items():
        companions[name] = (measurement / source).read_bytes()
    require(json.loads(companions['all-win-gate.json']) == performance['gate'],
            'Selected gate and results disagree')
    for name, key in [('timing.csv', 'timing_rows'), ('resources.csv', 'resource_rows')]:
        rows = list(csv.DictReader(io.StringIO(companions[name].decode())))
        require(len(rows) == len(performance[key]), 'Selected CSV row count differs: ' + name)

    files = {}
    base = ROOT / 'work/all-benchmarks'
    for directory, dirs, names in os.walk(base, followlinks=False):
        directory = Path(directory)
        relative_dir = directory.relative_to(base)
        dirs[:] = sorted(name for name in dirs
                         if not (directory / name).is_symlink()
                         and not excluded_directory(relative_dir / name))
        for name in sorted(names):
            path = directory / name
            if path == base / 'session-state.md':
                # Internal handoff state is not a measurement or repro input.
                continue
            if not path.is_file() or path.is_symlink() or path.suffix not in EXTENSIONS:
                continue
            data = path.read_bytes()
            if not data.startswith(b'\x7fELF'):
                files[str(path.relative_to(ROOT))] = data
    for name in ['all-benchmarks-cache-clean.log', 'all-benchmarks-lazy-check.log',
                 'all-benchmarks-lazy-check-bool.log', 'all-benchmarks-regenerate.log']:
        path = ROOT / 'work' / name
        if path.exists():
            files['work/' + name] = path.read_bytes()
    time_provenance = measurement / 'time-package/provenance.json'
    require(time_provenance.is_file(), 'Pinned GNU time package provenance missing')
    files[str(time_provenance.relative_to(ROOT))] = time_provenance.read_bytes()
    overlay_manifest, overlay_inventory = verify_overlay_members(files)

    # Both routes include d66 and both CI files. Exact selected overlays make their RPC
    # reconstruction independent of duplicate full checkout snapshots.
    files['source/implementation.patch'] = git('diff', '--binary', BASELINE, commit)
    files['source/core-implementation.patch'] = git('diff', '--binary', BASELINE, CORE)
    files['source/codegen-timer-fix.patch'] = git('diff', '--binary', CORE, timer)
    files[f'source/selected-{SELECTED_TAG}.patch'] = git('diff', '--binary', timer, commit)
    for path, data in selected_files.items():
        files[f'source/selected-{SELECTED_TAG}/' + path] = data
        overlay = f'work/all-benchmarks/measurement/source-overlays/{SELECTED_PHASE}/' + path
        require(overlay in files, 'Portable selected overlay missing: ' + overlay)
        require(sha(files[overlay]) == declared[path]['after'], 'Portable selected overlay differs: ' + path)
    files[f'source/selected-{SELECTED_TAG}/' + NOISE_TEST] = noise_data
    for path, data in timer_files.items():
        files['source/codegen-timer/' + path] = data
    for path, data in ci_files.items():
        files['source/ci/' + path] = data

    scopes = dict(
        baseline=BASELINE, core_implementation=CORE, timer_fix_commit=timer,
        final_implementation_commit=commit,
        prior_full_validation_source=prior['source'],
        prior_owned_conformance_source=owned['source_commit'],
        final_validation_source=final['source'],
        final_validated_input_sha256=final_hashes,
        selected_phase=SELECTED_PHASE, selected_transport=SELECTED_LABEL,
        selected_transport_sha256={path: sha(data) for path, data in selected_files.items()},
        permanent_noise_test=dict(path=NOISE_TEST, sha256=sha(noise_data)),
        timer_input_sha256={path: sha(data) for path, data in timer_files.items()},
        ci_sha256={path: sha(data) for path, data in ci_files.items()},
        post_core_changed_paths=sorted(changed),
        complete_overlay_inventory=overlay_inventory,
        limits=[
            'The earlier 26-gate validation and owned conformance bind 71422, not the final transport revision.',
            'Core/generator performance retains 028-to-71422 attribution; Selected RPC uses 71422 as its before source.',
            'Final validation binds the committed selected transport, permanent noise test and CI. Reused or omitted scopes remain explicit in its report.',
            'Independent transport reviews retain their own collection-time scope; functional review is not upgraded into a performance certificate.',
            'Corrected d66 codegen timings supersede polling-biased originals, which remain in historical raw campaigns.',
        ])
    files['source/provenance.json'] = encoded(scopes)
    files['source/reproduce.md'] = ('''# Reconstruct the comparisons

Start from baseline ''' + BASELINE + ''' in a disposable checkout. Either
apply source/implementation.patch once, or apply the ordered stage patches
core-implementation.patch, codegen-timer-fix.patch and selected-TRANSPORT_TAG.patch.
Do not apply both routes. The selected-TRANSPORT_TAG directory also contains all three
exact measured wire files and the committed permanent noise/budget test.
The ci directory retains both the standard and parity workflows.

Under work/all-benchmarks/measurement, reconstruct_variant.py and
source-overlays/manifest.json retain the Git export paths, exact overlays and
full input hashes for baseline,
71422, rejected phase2, framer A, unmeasured B, rejected identity-reserving C
and adopted compressed-only D snapshots.
Follow each frozen build record, lockfile and harness. A later source manifest
does not silently rebind an earlier campaign. Leave an installed third_party
SDK out of ordinary codec exports: its presence changes build.rs descriptor
inputs. Isolated official conformance explicitly uses the pinned upstream SDK.

The canonical generator uses debug builds; matched release is a separate
profile. Corrected d66 timing blocks for process completion with a watchdog
and stamps elapsed time before sampler teardown. Polling-biased originals,
counterfactuals and negative timer tests are retained but not selected.
Instrumented allocation clocks are not shipping timings. CPU and allocation
binaries are separate. Downstream consumer compilation is a separate axis.

Original low-count identity CPU records survive alongside the separate
higher-count resolution confirmation; confirmation does not replace them.
C identity reservations are rejected after their higher-count CPU loss. D
restores 71422 identity-framer growth while retaining compressed-only changes.
Aborted compressed campaigns, allocator-support setup failures, A/B/C/D
iterations and selected/rejected prototypes remain identifiable by path.
The rejected Wire-tag layout prototype was removed after null-Arc failures;
its exact original source was not snapshotted, so logs support the stated
cause rather than providing a portable isolated source replay. Selected code
retains the original Wire representation and an explicit lazy flag.

The old full 26-gate validation and owned conformance apply to71422. The final
validation report names the adopted compressed-only D source and states its exact checks and
reuse. Source provenance verifies unchanged core source and exact selected wire, timer,
CI and permanent-test hashes. Consult those scopes before combining rows.

Executables, tool installations, caches, duplicate full source snapshots and
representative generated-output copies are omitted. Manifests retain output
names, sizes and hashes; retained inputs/drivers regenerate them. Build elapsed
time alone is not a comparative generator benchmark.
''').replace('TRANSPORT_TAG', SELECTED_TAG).encode()

    matrices = {}
    for directory, dirs, names in os.walk(measurement, followlinks=False):
        directory = Path(directory)
        relative_dir = directory.relative_to(measurement)
        dirs[:] = sorted(name for name in dirs
                         if not (directory / name).is_symlink()
                         and not excluded_directory(relative_dir / name))
        if 'summary.json' in names:
            path = directory / 'summary.json'
            matrices[str(path.relative_to(measurement))] = json.loads(path.read_text())
    result = dict(
        schema='pbrs.decode-and-map-speed.v2', baseline=BASELINE,
        implementation_commit=commit, core_implementation_commit=CORE,
        qualified=False, full_tonic_prost_parity=False,
        world_performance_ranking_established=False,
        all_benchmarks_won=performance['all_benchmarks_won'],
        performance=performance, historical_phase1_performance=phase1,
        historical_phase5_C_performance=historical_c,
        matrices=matrices, validation=final, prior_core_validation=prior,
        complete_overlay_inventory=overlay_inventory,
        owned_conformance=owned, source_scopes=scopes,
        selection=dict(phase=SELECTED_PHASE, transport_variant=SELECTED_LABEL, final_commit=commit,
                       exact_measured_files_match=True,
                       note='Selection is bound by committed source identity; collection-time pending-review text in raw reports is retained.'),
        maps=read('work/all-benchmarks/maps/results.json'),
        codec=read('work/all-benchmarks/codec/results.json'),
        generator=read('work/all-benchmarks/codegen/results.json'),
        transport=read('work/all-benchmarks/transport/results.json'),
        core_review=read('work/all-benchmarks/review/results.json'),
        selected_transport_review=selected_review,
        navigation={name: dict(source='work/all-benchmarks/measurement/' + source)
                    for name, source in companion_sources.items()})

    adoption = read('work/all-benchmarks/measurement/' + SELECTED_PHASE + '-adoption.json')
    require(adoption['production_source_commit'] == commit, 'Adoption source differs')
    require(adoption['measurements']['results_sha256'] == sha((measurement / (SELECTED_PHASE + '-results.json')).read_bytes()), 'Adoption results differ')
    result['adoption_decision'] = adoption

    OUT.mkdir(exist_ok=True)
    for name, data in companions.items():
        (OUT / name).write_bytes(data)
    with tarfile.open(OUT / 'raw.tar.gz', 'w:gz', compresslevel=6) as archive:
        for name, data in sorted(files.items()):
            info = tarfile.TarInfo(name)
            info.size = len(data)
            info.mode = 0o644
            info.mtime = 0
            archive.addfile(info, io.BytesIO(data))
    result['archive_overlay_reconstruction'] = verify_archived_overlays(
        OUT / 'raw.tar.gz', overlay_manifest)
    (OUT / 'results.json').write_bytes(encoded(result))
    manifest = dict(
        schema='pbrs.evidence-manifest.v1',
        archive_sha256=sha((OUT / 'raw.tar.gz').read_bytes()),
        results_sha256=sha((OUT / 'results.json').read_bytes()),
        companion_files={name: dict(bytes=len(data), sha256=sha(data))
                         for name, data in sorted(companions.items())},
        files={name: dict(bytes=len(data), sha256=sha(data))
               for name, data in sorted(files.items())})
    (OUT / 'manifest.json').write_bytes(encoded(manifest))
    write_checker()
    print(json.dumps(dict(files=len(files), logical_bytes=sum(map(len, files.values())),
                         archive_bytes=(OUT / 'raw.tar.gz').stat().st_size,
                         final_source=commit, prior_full_source=CORE,
                         final_workspace=final.get('workspace_test_counts'),
                         prior_workspace=prior['workspace_test_counts'],
                         companions=sorted(companions))))


if __name__ == '__main__':
    main()
