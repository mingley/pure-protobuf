//! Map field storage and views.
use crate::internal::SealedInternal;
use crate::proxied::{AsMut, AsView, IntoMut, IntoProxied, IntoView, MutProxied, Proxied};
use crate::string::ProtoString;
use std::fmt;
use std::sync::OnceLock;

/// Entry count at which lookups, unique length and iteration switch from a
/// linear scan to the sorted last-wins index. Below this, reads never
/// allocate an index; at and above it, one build is amortized over all reads.
/// Measured with the PK-17 scratch bench (cold-index `parse+touch`,
/// `get-each`, `iter` at 4..256 entries, exact alloc counts plus wall time):
/// sizes 4-8 are identical-or-better (get/len shed the old node allocations),
/// size 16 matches the scans on time, and 64+ wins strictly on every path.
const INDEX_THRESHOLD: usize = 16;

/// Cached winner positions. Small maps use one bit per wire entry; large maps
/// retain their sorted unique key -> last position index. Small masks are
/// initialized by `len` or an explicit iterator hint request. Iteration reuses
/// a ready mask but preserves incremental scanning on a cold first-entry read.
///
/// The Small/Large enum may use Vec's niche without increasing this payload's
/// size; that is a hypothesis pending layout checks on the supported compilers.
enum LastWinsIndex<K> {
    Small(u16),
    Large(Vec<(K, usize)>),
}

type LastWins<K> = OnceLock<LastWinsIndex<K>>;

impl<K: MapKey> LastWinsIndex<K> {
    fn get<V>(&self, key: &K, entries: &[(K, V)]) -> Option<usize> {
        match self {
            Self::Small(_) => entries.iter().rposition(|(k, _)| k == key),
            Self::Large(pos) => pos
                .binary_search_by(|(k, _)| k.cmp(key))
                .ok()
                .map(|i| pos[i].1),
        }
    }

    fn is_last<V>(&self, key: &K, i: usize, entries: &[(K, V)]) -> bool {
        match self {
            Self::Small(mask) => i < INDEX_THRESHOLD && mask & (1 << i) != 0,
            Self::Large(_) => self.get(key, entries) == Some(i),
        }
    }

    fn len(&self) -> usize {
        match self {
            Self::Small(mask) => mask.count_ones() as usize,
            Self::Large(pos) => pos.len(),
        }
    }

    /// Update a cached index after appending a key already known to be new.
    /// Returns true when crossing the small-map boundary invalidates a mask.
    fn append_new(&mut self, key: &K, position: usize) -> bool {
        match self {
            Self::Small(mask) => {
                if position + 1 >= INDEX_THRESHOLD {
                    return true;
                }
                *mask |= 1 << position;
            }
            Self::Large(pos) => {
                let at = pos.partition_point(|(k, _)| k < key);
                pos.insert(at, (key.clone(), position));
            }
        }
        false
    }
}

fn build_index<K: MapKey, V>(entries: &[(K, V)]) -> LastWinsIndex<K> {
    let mut pos: Vec<(K, usize)> = entries
        .iter()
        .enumerate()
        .map(|(i, (k, _))| (k.clone(), i))
        .collect();
    // Key ascending, position descending: `dedup_by` keeps the first of each
    // run, which is the last wire position per key. Single allocation.
    pos.sort_by(|a, b| a.0.cmp(&b.0).then(b.1.cmp(&a.1)));
    pos.dedup_by(|a, b| a.0 == b.0);
    LastWinsIndex::Large(pos)
}

/// Returns the last-wins index when the map is large enough to amortize it.
/// Small maps always scan, so they never pay for an index build.
fn hot_index<'a, K: MapKey, V>(
    entries: &[(K, V)],
    index: Option<&'a LastWins<K>>,
) -> Option<&'a LastWinsIndex<K>> {
    let index = index?;
    if entries.len() < INDEX_THRESHOLD {
        // Reuse work already paid for by len; do not turn a cold next() into
        // a full-map duplicate scan merely to obtain an iteration cache.
        return index.get();
    }
    Some(index.get_or_init(|| build_index(entries)))
}

fn iter_index<'a, K: MapKey, V>(
    entries: &[(K, V)],
    index: Option<&'a LastWins<K>>,
) -> Option<MapIterIndex<'a, K>> {
    if entries.len() <= 1 {
        return None;
    }
    let index = index?;
    if entries.len() >= INDEX_THRESHOLD {
        return Some(MapIterIndex::Ready(index.get_or_init(|| build_index(entries))));
    }
    match index.get() {
        Some(ready) => Some(MapIterIndex::Ready(ready)),
        None => Some(MapIterIndex::Lazy(index)),
    }
}

fn small_winner_mask<K: MapKey, V>(entries: &[(K, V)]) -> u16 {
    debug_assert!(entries.len() < INDEX_THRESHOLD);
    let mut mask = 0;
    for (i, (key, _)) in entries.iter().enumerate() {
        if entries[i + 1..].iter().all(|(later, _)| later != key) {
            mask |= 1 << i;
        }
    }
    mask
}

fn scan_unique_len<K: MapKey, V>(v: &[(K, V)]) -> usize {
    let mut n = 0;
    for (i, (k, _)) in v.iter().enumerate() {
        if v.get(i + 1..)
            .is_some_and(|rest| rest.iter().all(|(k2, _)| k2 != k))
        {
            n += 1;
        }
    }
    n
}

fn unique_len<K: MapKey, V>(entries: &[(K, V)], index: Option<&LastWins<K>>) -> usize {
    if entries.len() <= 1 {
        return entries.len();
    }
    if entries.len() < INDEX_THRESHOLD {
        return match index {
            Some(index) => index
                .get_or_init(|| LastWinsIndex::Small(small_winner_mask(entries)))
                .len(),
            None => scan_unique_len(entries),
        };
    }
    match hot_index(entries, index) {
        Some(idx) => idx.len(),
        None => scan_unique_len(entries),
    }
}

fn last_wins_pos<K: MapKey, V>(
    entries: &[(K, V)],
    index: Option<&LastWins<K>>,
    key: &K,
) -> Option<usize> {
    if let Some(idx) = hot_index(entries, index) {
        return idx.get(key, entries);
    }
    entries.iter().rposition(|(k, _)| k == key)
}

fn last_wins_get<'a, K: MapKey, V>(
    entries: &'a [(K, V)],
    index: Option<&LastWins<K>>,
    key: &K,
) -> Option<&'a V> {
    let pos = last_wins_pos(entries, index, key)?;
    entries.get(pos).map(|(_, v)| v)
}

/// Types allowed as map keys.
pub trait MapKey: Clone + Ord + Eq + 'static {}
impl MapKey for i32 {}
impl MapKey for i64 {}
impl MapKey for u32 {}
impl MapKey for u64 {}
impl MapKey for bool {}
impl MapKey for ProtoString {}

/// Key argument for `MapView::get` / `MapMut::{get,insert,remove}`.
/// Accepts `K`, `&K`, `View<K>`, and `&str` for string keys.
pub trait MapQuery<K: MapKey> {
    fn eq_key(&self, k: &K) -> bool;
    fn to_owned_key(&self) -> K;
    fn key_bytes(&self) -> Vec<u8>;
}

impl MapQuery<i32> for i32 {
    fn eq_key(&self, k: &i32) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> i32 {
        *self
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.to_le_bytes().to_vec()
    }
}
impl MapQuery<i32> for &i32 {
    fn eq_key(&self, k: &i32) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> i32 {
        **self
    }
    fn key_bytes(&self) -> Vec<u8> {
        (**self).to_le_bytes().to_vec()
    }
}
impl MapQuery<i64> for i64 {
    fn eq_key(&self, k: &i64) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> i64 {
        *self
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.to_le_bytes().to_vec()
    }
}
impl MapQuery<i64> for &i64 {
    fn eq_key(&self, k: &i64) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> i64 {
        **self
    }
    fn key_bytes(&self) -> Vec<u8> {
        (**self).to_le_bytes().to_vec()
    }
}
impl MapQuery<u32> for u32 {
    fn eq_key(&self, k: &u32) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> u32 {
        *self
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.to_le_bytes().to_vec()
    }
}
impl MapQuery<u32> for &u32 {
    fn eq_key(&self, k: &u32) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> u32 {
        **self
    }
    fn key_bytes(&self) -> Vec<u8> {
        (**self).to_le_bytes().to_vec()
    }
}
impl MapQuery<u64> for u64 {
    fn eq_key(&self, k: &u64) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> u64 {
        *self
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.to_le_bytes().to_vec()
    }
}
impl MapQuery<u64> for &u64 {
    fn eq_key(&self, k: &u64) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> u64 {
        **self
    }
    fn key_bytes(&self) -> Vec<u8> {
        (**self).to_le_bytes().to_vec()
    }
}
impl MapQuery<bool> for bool {
    fn eq_key(&self, k: &bool) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> bool {
        *self
    }
    fn key_bytes(&self) -> Vec<u8> {
        vec![*self as u8]
    }
}
impl MapQuery<bool> for &bool {
    fn eq_key(&self, k: &bool) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> bool {
        **self
    }
    fn key_bytes(&self) -> Vec<u8> {
        vec![**self as u8]
    }
}
impl MapQuery<ProtoString> for ProtoString {
    fn eq_key(&self, k: &ProtoString) -> bool {
        self == k
    }
    fn to_owned_key(&self) -> ProtoString {
        self.clone()
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.as_bytes().to_vec()
    }
}
impl MapQuery<ProtoString> for &ProtoString {
    fn eq_key(&self, k: &ProtoString) -> bool {
        *self == k
    }
    fn to_owned_key(&self) -> ProtoString {
        (*self).clone()
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.as_bytes().to_vec()
    }
}
impl MapQuery<ProtoString> for &str {
    fn eq_key(&self, k: &ProtoString) -> bool {
        k.as_bytes() == self.as_bytes()
    }
    fn to_owned_key(&self) -> ProtoString {
        ProtoString::from(*self)
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.as_bytes().to_vec()
    }
}
impl MapQuery<ProtoString> for &crate::string::ProtoStr {
    fn eq_key(&self, k: &ProtoString) -> bool {
        k.as_bytes() == self.as_bytes()
    }
    fn to_owned_key(&self) -> ProtoString {
        ProtoString::from(*self)
    }
    fn key_bytes(&self) -> Vec<u8> {
        self.as_bytes().to_vec()
    }
}

/// Types allowed as map values.
pub trait MapValue: Clone + 'static {}
impl<T: Clone + 'static> MapValue for T {}

/// Empty is an 8-byte null. Parse appends to a `Vec` (last-wins). Lookup uses a lazy index.
#[derive(Clone)]
pub struct Map<K: MapKey, V: MapValue>(Option<Box<MapInner<K, V>>>);

struct MapInner<K: MapKey, V: MapValue> {
    entries: Vec<(K, V)>,
    index: LastWins<K>,
}

impl<K: MapKey, V: MapValue> Clone for MapInner<K, V> {
    fn clone(&self) -> Self {
        Self {
            entries: self.entries.clone(),
            index: OnceLock::new(),
        }
    }
}

impl<K: MapKey, V: MapValue> Default for Map<K, V> {
    #[inline]
    fn default() -> Self {
        Self(None)
    }
}

impl<K: MapKey, V: MapValue + PartialEq> PartialEq for Map<K, V> {
    fn eq(&self, other: &Self) -> bool {
        self.len() == other.len()
            && self.iter().all(|(k, v)| other.get(k) == Some(v))
            && other.iter().all(|(k, _)| self.get(k).is_some())
    }
}
impl<K: MapKey, V: MapValue + Eq> Eq for Map<K, V> {}

impl<K: MapKey, V: MapValue> Map<K, V> {
    #[inline]
    pub fn new() -> Self {
        Self(None)
    }

    pub fn as_view(&self) -> MapView<'_, K, V> {
        match self.0.as_deref() {
            Some(inner) => MapView {
                inner: Some(inner.entries.as_slice()),
                index: Some(&inner.index),
                raw: None,
                enum_codec: None,
            },
            None => MapView::empty(),
        }
    }

    pub fn as_mut(&mut self) -> MapMut<'_, K, V> {
        let inner = self.ensure();
        MapMut {
            inner: Some(&mut inner.entries),
            index: Some(&mut inner.index),
            raw: None,
            enum_codec: None,
            arena: None,
        }
    }

    #[inline]
    fn ensure(&mut self) -> &mut MapInner<K, V> {
        self.0.get_or_insert_with(|| {
            Box::new(MapInner {
                entries: Vec::new(),
                index: OnceLock::new(),
            })
        })
    }

    /// Append a parsed entry without scanning (protobuf last-wins).
    #[inline]
    pub fn push_entry(&mut self, key: K, value: V) {
        let inner = self.ensure();
        inner.entries.push((key, value));
        inner.index = OnceLock::new();
    }

    /// Returns `true` if the key was newly inserted.
    pub fn insert(&mut self, key: impl Into<K>, value: impl Into<V>) -> bool {
        let key = key.into();
        let value = value.into();
        let inner = self.ensure();
        // Reuse a built index, but never build one on a mutation path: a
        // build here would be discarded by the mutation itself.
        let existing = match inner.index.get() {
            Some(idx) => idx.get(&key, &inner.entries),
            None => inner.entries.iter().rposition(|(k, _)| k == &key),
        };
        if let Some(i) = existing {
            if let Some(e) = inner.entries.get_mut(i) {
                e.1 = value;
                return false;
            }
        }
        let pos = inner.entries.len();
        let invalidate = if let Some(idx) = inner.index.get_mut() {
            debug_assert!(
                idx.get(&key, &inner.entries).is_none(),
                "hot index disagrees with lookup"
            );
            idx.append_new(&key, pos)
        } else {
            false
        };
        if invalidate {
            inner.index = OnceLock::new();
        }
        inner.entries.push((key, value));
        true
    }

    pub fn get(&self, key: &K) -> Option<&V> {
        let inner = self.0.as_ref()?;
        last_wins_get(&inner.entries, Some(&inner.index), key)
    }

    pub fn remove(&mut self, key: &K) -> Option<V> {
        let inner = self.0.as_mut()?;
        // Same no-build rule as `insert`; the swap may move an entry and an
        // earlier duplicate may remain, so a built index is dropped and
        // rebuilt lazily on the next large-map read.
        let i = match inner.index.get() {
            Some(idx) => idx.get(key, &inner.entries),
            None => inner.entries.iter().rposition(|(k, _)| k == key),
        }?;
        let out = inner.entries.swap_remove(i).1;
        inner.index = OnceLock::new();
        if inner.entries.is_empty() {
            self.0 = None;
        }
        Some(out)
    }

    pub fn keys(&self) -> impl Iterator<Item = &K> {
        self.iter().map(|(k, _)| k)
    }

    pub fn values(&self) -> impl Iterator<Item = &V> {
        self.iter().map(|(_, v)| v)
    }

    #[inline]
    pub fn len(&self) -> usize {
        let Some(inner) = self.0.as_ref() else {
            return 0;
        };
        unique_len(&inner.entries, Some(&inner.index))
    }

    #[inline]
    pub fn is_empty(&self) -> bool {
        self.0.as_ref().is_none_or(|inner| inner.entries.is_empty())
    }

    pub fn clear(&mut self) {
        self.0 = None;
    }

    pub fn iter(&self) -> MapIter<'_, K, V> {
        match self.0.as_deref() {
            Some(inner) => {
                let items = inner.entries.as_slice();
                MapIter {
                    items,
                    index: iter_index(items, Some(&inner.index)),
                    i: 0,
                }
            }
            None => MapIter {
                items: &[],
                index: None,
                i: 0,
            },
        }
    }

    #[inline]
    pub fn pairs(&self) -> &[(K, V)] {
        self.0
            .as_deref()
            .map_or(&[], |inner| inner.entries.as_slice())
    }
}

impl<K: MapKey + fmt::Debug, V: MapValue + fmt::Debug> fmt::Debug for Map<K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_map().entries(self.iter()).finish()
    }
}

enum MapIterIndex<'msg, K> {
    // Already initialized cache references bypass Atomic ready-state probes.
    Ready(&'msg LastWinsIndex<K>),
    // Cold small maps keep the shared slot so an explicit size hint can seed
    // its mask, without constructing that mask on the first next() call.
    Lazy(&'msg LastWins<K>),
}

pub struct MapIter<'msg, K, V> {
    items: &'msg [(K, V)],
    index: Option<MapIterIndex<'msg, K>>,
    i: usize,
}

impl<'msg, K: MapKey, V> Iterator for MapIter<'msg, K, V> {
    type Item = (&'msg K, &'msg V);
    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        // A first-entry read does not build a complete small mask. Reuse only
        // a cache already initialized by len or an explicit hint request.
        let index = match self.index.as_ref() {
            Some(MapIterIndex::Ready(index)) => Some(*index),
            Some(MapIterIndex::Lazy(slot)) => {
                let ready = (*slot).get();
                if let Some(ready) = ready {
                    self.index = Some(MapIterIndex::Ready(ready));
                }
                ready
            }
            None => None,
        };
        if let Some(index) = index {
            if index.len() == self.items.len() {
                let (key, value) = self.items.get(self.i)?;
                self.i += 1;
                return Some((key, value));
            }
            if let LastWinsIndex::Small(mask) = index {
                let remaining = mask >> self.i;
                if remaining == 0 {
                    self.i = self.items.len();
                    return None;
                }
                self.i += remaining.trailing_zeros() as usize;
                let (key, value) = self.items.get(self.i)?;
                self.i += 1;
                return Some((key, value));
            }
            while self.i < self.items.len() {
                let (key, value) = &self.items[self.i];
                let i = self.i;
                self.i += 1;
                if index.is_last(key, i, self.items) {
                    return Some((key, value));
                }
            }
            return None;
        }
        while self.i < self.items.len() {
            let (key, value) = &self.items[self.i];
            self.i += 1;
            if self.items[self.i..].iter().all(|(later, _)| later != key) {
                return Some((key, value));
            }
        }
        None
    }

    fn size_hint(&self) -> (usize, Option<usize>) {
        if self.items.len() <= 1 {
            let remaining = self.items.len().saturating_sub(self.i);
            return (remaining, Some(remaining));
        }
        // Cache an explicit whole-collection count once, so next does not
        // repeat its duplicate scan. A next-only cold iterator stays lazy.
        let index = self.index.as_ref().map(|index| {
            match index {
                MapIterIndex::Ready(index) => *index,
                MapIterIndex::Lazy(slot) => {
                    if self.items.len() < INDEX_THRESHOLD {
                        (*slot).get_or_init(|| LastWinsIndex::Small(small_winner_mask(self.items)))
                    } else {
                        (*slot).get_or_init(|| build_index(self.items))
                    }
                }
            }
        });
        if let Some(LastWinsIndex::Small(mask)) = index {
            let remaining = (mask >> self.i).count_ones() as usize;
            return (remaining, Some(remaining));
        }
        let remaining = self.items.len().saturating_sub(self.i);
        let unique = self.items.len() <= 1
            || index.is_some_and(|index| index.len() == self.items.len());
        (if unique { remaining } else { 0 }, Some(remaining))
    }
}

pub struct MapView<'msg, K: MapKey, V: MapValue> {
    inner: Option<&'msg [(K, V)]>,
    index: Option<&'msg LastWins<K>>,
    raw: Option<crate::runtime::RawMap>,
    enum_codec: Option<crate::runtime::KernelEnumCodec<V>>,
}

impl<K: MapKey, V: MapValue> Clone for MapView<'_, K, V> {
    fn clone(&self) -> Self {
        *self
    }
}
impl<K: MapKey, V: MapValue> Copy for MapView<'_, K, V> {}

impl<'msg, K: MapKey, V: MapValue> MapView<'msg, K, V> {
    #[inline]
    pub fn empty() -> Self {
        Self {
            inner: None,
            index: None,
            raw: None,
            enum_codec: None,
        }
    }

    #[inline]
    pub fn from_slice(items: &'msg [(K, V)]) -> Self {
        if items.is_empty() {
            Self::empty()
        } else {
            Self {
                inner: Some(items),
                index: None,
                raw: None,
                enum_codec: None,
            }
        }
    }

    #[doc(hidden)]
    /// # Safety
    /// `raw` must point to a live map with keys `K` and values `V`, owned by an
    /// arena that outlives `'msg`. No mutation may invalidate its borrowed data
    /// while this view or any view derived from it is live.
    pub unsafe fn from_raw(_private: crate::internal::Private, raw: crate::runtime::RawMap) -> Self
    where
        V: crate::internal::EntityType,
        V::Tag: crate::runtime::KernelCollectionValue<V>,
    {
        Self {
            inner: None,
            index: None,
            raw: Some(raw),
            enum_codec: <V::Tag as crate::runtime::KernelCollectionValue<V>>::enum_codec(),
        }
    }

    #[doc(hidden)]
    /// # Safety
    /// The same typed storage and lifetime requirements as [`Self::from_raw`]
    /// apply.
    pub unsafe fn from_raw_ptr(raw: crate::runtime::RawMap) -> Self
    where
        V: crate::internal::EntityType,
        V::Tag: crate::runtime::KernelCollectionValue<V>,
    {
        // SAFETY: the caller supplies the same typed map/lifetime contract as
        // from_raw; this alias only supplies its internal marker.
        unsafe { Self::from_raw(crate::internal::Private, raw) }
    }

    pub fn get(self, key: impl MapQuery<K>) -> Option<crate::proxied::View<'msg, V>>
    where
        V: crate::proxied::Proxied + 'static,
    {
        if let Some(raw) = self.raw {
            let kb = key.key_bytes();
            return unsafe { crate::runtime::kernel_map_get_bytes::<V>(raw, &kb, self.enum_codec) };
        }
        let entries = self.inner?;
        if let Some(index @ LastWinsIndex::Large(_)) = hot_index(entries, self.index) {
            let owned = key.to_owned_key();
            return index
                .get(&owned, entries)
                .and_then(|pos| entries.get(pos))
                .map(|(_, value)| crate::proxied::AsView::as_view(value));
        }
        entries
            .iter()
            .rev()
            .find(|(k, _)| key.eq_key(k))
            .map(|(_, v)| crate::proxied::AsView::as_view(v))
    }

    pub fn len(self) -> usize {
        if let Some(raw) = self.raw {
            return crate::runtime::kernel_map_len(raw);
        }
        unique_len(self.inner.unwrap_or(&[]), self.index)
    }

    pub fn is_empty(self) -> bool {
        if self.raw.is_some() {
            return self.len() == 0;
        }
        self.inner.is_none_or(|v| v.is_empty())
    }

    pub fn keys(self) -> impl Iterator<Item = crate::proxied::View<'msg, K>> + 'msg
    where
        K: crate::proxied::Proxied + 'static,
        V: crate::proxied::Proxied + 'static,
    {
        self.iter().map(|(k, _)| k)
    }

    pub fn values(self) -> impl Iterator<Item = crate::proxied::View<'msg, V>> + 'msg
    where
        K: crate::proxied::Proxied + 'static,
        V: crate::proxied::Proxied + 'static,
    {
        self.iter().map(|(_, v)| v)
    }

    #[inline]
    pub fn iter(self) -> MapViewIter<'msg, K, V>
    where
        K: crate::proxied::Proxied + 'static,
        V: crate::proxied::Proxied + 'static,
    {
        MapViewIter::from_view(self)
    }
}

impl<K: MapKey + fmt::Debug, V: MapValue + fmt::Debug> fmt::Debug for MapView<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        f.debug_struct("MapView").field("len", &self.len()).finish()
    }
}

pub struct MapMut<'msg, K: MapKey, V: MapValue> {
    inner: Option<&'msg mut Vec<(K, V)>>,
    index: Option<&'msg mut LastWins<K>>,
    raw: Option<crate::runtime::RawMap>,
    enum_codec: Option<crate::runtime::KernelEnumCodec<V>>,
    arena: Option<&'msg crate::runtime::Arena>,
}

impl<'msg, K: MapKey, V: MapValue> MapMut<'msg, K, V> {
    pub fn from_vec(inner: &'msg mut Vec<(K, V)>) -> Self {
        Self {
            inner: Some(inner),
            index: None,
            raw: None,
            enum_codec: None,
            arena: None,
        }
    }

    #[doc(hidden)]
    /// # Safety
    /// `inner.raw` must be a live map with keys `K` and values `V`, owned by
    /// `inner.arena` for `'msg` and exclusively borrowed by this mutator.
    pub unsafe fn from_inner(
        _private: crate::internal::Private,
        inner: crate::runtime::InnerMapMut<'msg>,
    ) -> Self
    where
        V: crate::internal::EntityType,
        V::Tag: crate::runtime::KernelCollectionValue<V>,
    {
        Self {
            inner: None,
            index: None,
            raw: Some(inner.raw),
            enum_codec: <V::Tag as crate::runtime::KernelCollectionValue<V>>::enum_codec(),
            arena: Some(inner.arena),
        }
    }

    #[doc(hidden)]
    /// # Safety
    /// `raw` must be a live arena-owned map with keys `K` and values `V`.
    /// Its arena must outlive `'msg`; the map must be exclusively borrowed by
    /// this mutator, just as for [`Self::from_inner`].
    pub unsafe fn from_raw_inner(raw: crate::runtime::RawMap) -> Self
    where
        V: crate::internal::EntityType,
        V::Tag: crate::runtime::KernelCollectionValue<V>,
    {
        Self {
            inner: None,
            index: None,
            raw: Some(raw),
            enum_codec: <V::Tag as crate::runtime::KernelCollectionValue<V>>::enum_codec(),
            arena: None,
        }
    }

    fn drop_index(index: &mut Option<&mut LastWins<K>>) {
        if let Some(lock) = index.as_mut() {
            **lock = OnceLock::new();
        }
    }

    /// Returns `true` if the key was newly inserted.
    pub fn insert(
        &mut self,
        key: impl MapQuery<K>,
        value: impl crate::proxied::IntoProxied<V>,
    ) -> bool
    where
        V: 'static,
    {
        let key = key.to_owned_key();
        let value = crate::proxied::IntoProxied::into_proxied(value, crate::internal::Private);
        self.insert_owned(key, value)
    }

    fn insert_owned(&mut self, key: K, value: V) -> bool
    where
        V: 'static,
    {
        if let Some(v) = self.inner.as_mut() {
            // Reuse a built index, but never build one on a mutation path.
            let existing = match self.index.as_deref().and_then(|l| l.get()) {
                Some(idx) => idx.get(&key, v),
                None => v.iter().rposition(|(k, _)| k == &key),
            };
            if let Some(i) = existing {
                if let Some(e) = v.get_mut(i) {
                    e.1 = value;
                    return false;
                }
            }
            let pos = v.len();
            let invalidate = if let Some(idx) = self.index.as_deref_mut().and_then(|l| l.get_mut()) {
                debug_assert!(idx.get(&key, v).is_none(), "hot index disagrees with lookup");
                idx.append_new(&key, pos)
            } else {
                false
            };
            if invalidate {
                Self::drop_index(&mut self.index);
            }
            v.push((key, value));
            true
        } else if let Some(raw) = self.raw {
            crate::runtime::kernel_map_insert(raw, key, value, self.arena, self.enum_codec)
        } else {
            false
        }
    }

    pub fn get(&self, key: impl MapQuery<K>) -> Option<crate::proxied::View<'_, V>>
    where
        V: crate::proxied::Proxied + 'static,
    {
        self.as_view().get(key)
    }

    pub fn get_mut(&mut self, key: impl MapQuery<K>) -> Option<crate::proxied::Mut<'_, V>>
    where
        V: crate::message::Message + crate::proxied::MutProxied + 'static,
    {
        let owned = key.to_owned_key();
        if let Some(v) = self.inner.as_mut() {
            return last_wins_pos(v, self.index.as_deref(), &owned)
                .and_then(|i| v.get_mut(i))
                .map(|(_, val)| crate::proxied::AsMut::as_mut(val));
        }
        if let (Some(raw), Some(arena)) = (self.raw, self.arena) {
            let kb = key.key_bytes();
            unsafe {
                let entries = (*raw).entries.borrow();
                let fk = entries
                    .iter()
                    .rev()
                    .find(|(k, _)| k == &kb)
                    .map(|(_, v)| *v);
                drop(entries);
                if let Some(crate::runtime::FieldKind::Msg(p)) = fk {
                    return crate::runtime::kernel_msg_ptr_to_mut::<V>(p, arena);
                }
            }
        }
        None
    }

    pub fn remove(&mut self, key: impl MapQuery<K>) -> bool {
        let key = key.to_owned_key();
        if let Some(v) = self.inner.as_mut() {
            // Same no-build rule as `insert_owned`; the swap may move an
            // entry and an earlier duplicate may remain, so a built index is
            // dropped and rebuilt lazily on the next large-map read.
            let found = match self.index.as_deref().and_then(|l| l.get()) {
                Some(idx) => idx.get(&key, v),
                None => v.iter().rposition(|(k, _)| k == &key),
            };
            if let Some(i) = found {
                v.swap_remove(i);
                Self::drop_index(&mut self.index);
                return true;
            }
            false
        } else if let Some(raw) = self.raw {
            unsafe {
                let kb = crate::runtime::kernel_key_bytes(key.clone());
                let mut entries = (*raw).entries.borrow_mut();
                if let Some(i) = entries.iter().rposition(|(k, _)| k == &kb) {
                    let (_, old) = entries.swap_remove(i);
                    drop(entries);
                    crate::runtime::kernel_map_release_value(raw, old);
                    true
                } else {
                    false
                }
            }
        } else {
            false
        }
    }

    pub fn copy_from<'a>(
        &mut self,
        src: impl IntoIterator<Item = (impl MapQuery<K> + 'a, impl crate::proxied::IntoProxied<V>)>,
    ) where
        V: crate::proxied::Proxied + 'static,
    {
        self.clear();
        for (k, v) in src {
            self.insert(k, v);
        }
    }

    pub fn len(&self) -> usize {
        if let Some(raw) = self.raw {
            return crate::runtime::kernel_map_len(raw);
        }
        unique_len(
            self.inner.as_deref().map_or(&[], |v| v.as_slice()),
            self.index.as_deref(),
        )
    }

    pub fn is_empty(&self) -> bool {
        if self.raw.is_some() {
            return self.len() == 0;
        }
        self.inner.as_ref().is_none_or(|v| v.is_empty())
    }

    pub fn keys(&self) -> impl Iterator<Item = &K> {
        self.inner
            .as_ref()
            .map(|v| v.iter())
            .into_iter()
            .flatten()
            .map(|(k, _)| k)
    }

    pub fn values(&self) -> impl Iterator<Item = &V> {
        self.inner
            .as_ref()
            .map(|v| v.iter())
            .into_iter()
            .flatten()
            .map(|(_, v)| v)
    }

    pub fn clear(&mut self) {
        if let Some(v) = self.inner.as_mut() {
            v.clear();
            Self::drop_index(&mut self.index);
        } else if let Some(raw) = self.raw {
            unsafe {
                (*raw).entries.borrow_mut().clear();
                (*raw).strs.borrow_mut().clear();
            }
        }
    }
}

impl<K: MapKey + fmt::Debug, V: MapValue + fmt::Debug> fmt::Debug for MapMut<'_, K, V> {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match self.inner.as_ref() {
            Some(v) => f.debug_list().entries(v.iter()).finish(),
            None => f.debug_struct("MapMut").field("raw", &self.raw).finish(),
        }
    }
}

impl<K: MapKey, V: MapValue> SealedInternal for Map<K, V> {}
impl<K: MapKey, V: MapValue> Proxied for Map<K, V> {
    type View<'msg> = MapView<'msg, K, V>;
}
impl<K: MapKey, V: MapValue> MutProxied for Map<K, V> {
    type Mut<'msg> = MapMut<'msg, K, V>;
}
impl<K: MapKey, V: MapValue> AsView for Map<K, V> {
    type Proxied = Self;
    fn as_view(&self) -> MapView<'_, K, V> {
        Map::as_view(self)
    }
}
impl<K: MapKey, V: MapValue> AsMut for Map<K, V> {
    type MutProxied = Self;
    fn as_mut(&mut self) -> MapMut<'_, K, V> {
        Map::as_mut(self)
    }
}

impl<K: MapKey, V: MapValue> SealedInternal for MapView<'_, K, V> {}
impl<K: MapKey, V: MapValue> AsView for MapView<'_, K, V> {
    type Proxied = Map<K, V>;
    fn as_view(&self) -> MapView<'_, K, V> {
        *self
    }
}
impl<'msg, K: MapKey, V: MapValue> IntoView<'msg> for MapView<'msg, K, V> {
    fn into_view<'shorter>(self) -> MapView<'shorter, K, V>
    where
        'msg: 'shorter,
    {
        MapView {
            inner: self.inner,
            index: self.index,
            raw: self.raw,
            enum_codec: self.enum_codec,
        }
    }
}

impl<K: MapKey, V: MapValue> SealedInternal for MapMut<'_, K, V> {}
impl<K: MapKey, V: MapValue> AsView for MapMut<'_, K, V> {
    type Proxied = Map<K, V>;
    fn as_view(&self) -> MapView<'_, K, V> {
        MapView {
            inner: self.inner.as_ref().map(|v| v.as_slice()),
            index: self.index.as_deref(),
            raw: self.raw,
            enum_codec: self.enum_codec,
        }
    }
}
impl<K: MapKey, V: MapValue> AsMut for MapMut<'_, K, V> {
    type MutProxied = Map<K, V>;
    fn as_mut(&mut self) -> MapMut<'_, K, V> {
        MapMut {
            inner: self.inner.as_deref_mut(),
            index: self.index.as_deref_mut(),
            raw: self.raw,
            enum_codec: self.enum_codec,
            arena: self.arena,
        }
    }
}
impl<'msg, K: MapKey, V: MapValue> IntoView<'msg> for MapMut<'msg, K, V> {
    fn into_view<'shorter>(self) -> MapView<'shorter, K, V>
    where
        'msg: 'shorter,
    {
        MapView {
            inner: self.inner.map(|v| v.as_slice()),
            index: self.index.map(|i| &*i),
            raw: self.raw,
            enum_codec: self.enum_codec,
        }
    }
}
impl<'msg, K: MapKey, V: MapValue> IntoMut<'msg> for MapMut<'msg, K, V> {
    fn into_mut<'shorter>(self) -> MapMut<'shorter, K, V>
    where
        'msg: 'shorter,
    {
        MapMut {
            inner: self.inner,
            index: self.index,
            raw: self.raw,
            enum_codec: self.enum_codec,
            arena: self.arena,
        }
    }
}

impl<'msg, K: MapKey, V: MapValue> MapMut<'msg, K, V> {
    pub fn default_value(&self) -> V
    where
        V: Default,
    {
        V::default()
    }

    pub fn proto_put<KI: MapQuery<K>, VI: crate::proxied::IntoProxied<V>>(&mut self, pair: (KI, VI))
    where
        V: 'static,
    {
        self.insert(pair.0, pair.1);
    }
}

/// Iterator over map views in last-occurrence wire order.
///
/// Typed entries are borrowed and projected when yielded. Their size hint is
/// exact when winner positions are cached or every key is known to be unique.
/// Other duplicate-filtering paths use conservative bounds.
pub struct MapViewIter<
    'msg,
    K: MapKey + crate::proxied::Proxied,
    V: MapValue + crate::proxied::Proxied,
> {
    storage: MapViewIterStorage<'msg, K, V>,
}

enum MapViewIterStorage<
    'msg,
    K: MapKey + crate::proxied::Proxied,
    V: MapValue + crate::proxied::Proxied,
> {
    // Typed views already borrow stable entries. Project values only when
    // yielded, without allocating a second collection of those same views.
    Typed(MapIter<'msg, K, V>),
    // Arena storage keeps its established snapshot and lifetime handling.
    Raw {
        items: Vec<Option<(crate::proxied::View<'msg, K>, crate::proxied::View<'msg, V>)>>,
        i: usize,
    },
}

impl<
    'msg,
    K: MapKey + crate::proxied::Proxied + 'static,
    V: MapValue + crate::proxied::Proxied + 'static,
> MapViewIter<'msg, K, V>
{
    #[inline]
    fn from_view(view: MapView<'msg, K, V>) -> Self {
        if let Some(raw) = view.raw {
            return Self::from_raw_view(view, raw);
        }
        let items = view.inner.unwrap_or(&[]);
        Self {
            storage: MapViewIterStorage::Typed(MapIter {
                items,
                index: iter_index(items, view.index),
                i: 0,
            }),
        }
    }

    // Keep the raw projection loop out of the small borrowed constructor.
    #[inline(never)]
    fn from_raw_view(view: MapView<'msg, K, V>, raw: crate::runtime::RawMap) -> Self {
        let mut items = Vec::new();
        unsafe {
            let entries = (*raw).entries.borrow();
            for (i, (kb, fk)) in entries.iter().enumerate() {
                if entries[i + 1..].iter().any(|(k2, _)| k2 == kb) {
                    continue;
                }
                // SAFETY: raw map views borrow their arena-owned keys for 'msg;
                // safe callers cannot remove a key while a yielded view is live.
                let key_bytes: &'msg [u8] = std::slice::from_raw_parts(kb.as_ptr(), kb.len());
                let Some(k) = crate::runtime::kernel_bytes_to_view::<K>(key_bytes) else {
                    continue;
                };
                let Some(v) = crate::runtime::kernel_collection_value_to_view::<'msg, V>(
                    *fk,
                    view.enum_codec,
                ) else {
                    continue;
                };
                items.push(Some((k, v)));
            }
        }
        Self {
            storage: MapViewIterStorage::Raw { items, i: 0 },
        }
    }
}

impl<'msg, K, V> Iterator for MapViewIter<'msg, K, V>
where
    K: MapKey + crate::proxied::Proxied,
    V: MapValue + crate::proxied::Proxied,
{
    type Item = (crate::proxied::View<'msg, K>, crate::proxied::View<'msg, V>);
    #[inline]
    fn next(&mut self) -> Option<Self::Item> {
        match &mut self.storage {
            MapViewIterStorage::Typed(iter) => iter.next().map(|(k, v)| {
                (
                    crate::proxied::AsView::as_view(k),
                    crate::proxied::AsView::as_view(v),
                )
            }),
            MapViewIterStorage::Raw { items, i } => {
                let item = items.get_mut(*i)?.take();
                *i += 1;
                item
            }
        }
    }
    fn size_hint(&self) -> (usize, Option<usize>) {
        match &self.storage {
            MapViewIterStorage::Typed(iter) => iter.size_hint(),
            MapViewIterStorage::Raw { items, i } => {
                let remaining = items.len().saturating_sub(*i);
                (remaining, Some(remaining))
            }
        }
    }
}

impl<
    'msg,
    K: MapKey + crate::proxied::Proxied + 'static,
    V: MapValue + crate::proxied::Proxied + 'static,
> IntoIterator for MapView<'msg, K, V>
{
    type Item = (crate::proxied::View<'msg, K>, crate::proxied::View<'msg, V>);
    type IntoIter = MapViewIter<'msg, K, V>;
    #[inline]
    fn into_iter(self) -> Self::IntoIter {
        MapViewIter::from_view(self)
    }
}

impl<K: MapKey + crate::proxied::Proxied, V: MapValue + crate::proxied::Proxied>
    IntoProxied<Map<K, V>> for MapView<'_, K, V>
where
    for<'a> crate::proxied::View<'a, K>: Into<K>,
    for<'a> crate::proxied::View<'a, V>: crate::proxied::IntoProxied<V>,
{
    fn into_proxied(self, private: crate::internal::Private) -> Map<K, V> {
        let mut m = Map::new();
        for (k, v) in self {
            m.insert(
                k.into(),
                crate::proxied::IntoProxied::into_proxied(v, private),
            );
        }
        m
    }
}

impl<K: MapKey + crate::proxied::Proxied, V: MapValue + crate::proxied::Proxied>
    IntoProxied<Map<K, V>> for MapMut<'_, K, V>
where
    for<'a> crate::proxied::View<'a, K>: Into<K>,
    for<'a> crate::proxied::View<'a, V>: crate::proxied::IntoProxied<V>,
{
    fn into_proxied(self, private: crate::internal::Private) -> Map<K, V> {
        self.into_view().into_proxied(private)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn empty_eq_and_zeroed() {
        let z: Map<i32, i32> = unsafe { std::mem::zeroed() };
        assert!(z.is_empty());
        assert_eq!(z, Map::new());
        assert_eq!(
            std::mem::size_of::<Map<i32, i32>>(),
            std::mem::size_of::<usize>()
        );
        drop(z);
    }

    #[test]
    fn insert_remove() {
        let mut m = Map::new();
        assert!(m.insert(1, 2));
        assert!(!m.insert(1, 3));
        assert_eq!(m.get(&1), Some(&3));
        assert_eq!(m.remove(&1), Some(3)); // Map::remove still returns Option
        assert!(m.is_empty());
    }

    #[test]
    fn push_entry_last_wins_and_pairs_keep_wire_order() {
        let mut m = Map::new();
        m.push_entry(1, 10);
        m.push_entry(2, 20);
        m.push_entry(1, 11);
        assert_eq!(m.pairs().len(), 3);
        assert_eq!(m.len(), 2);
        assert_eq!(m.get(&1), Some(&11));
        assert_eq!(m.get(&2), Some(&20));
        assert_eq!(m.as_view().get(1), Some(11));
        assert_eq!(m.as_view().len(), 2);
        let mut it = m.iter();
        assert_eq!(it.next(), Some((&2, &20)));
        assert_eq!(it.next(), Some((&1, &11)));
        assert_eq!(it.next(), None);
    }

    #[test]
    fn index_invalidates_on_insert_remove_clear_push() {
        let mut m = Map::new();
        m.push_entry(1, 1);
        m.push_entry(2, 2);
        assert_eq!(m.get(&1), Some(&1));
        m.push_entry(1, 9);
        assert_eq!(m.get(&1), Some(&9));
        assert_eq!(m.len(), 2);
        assert!(!m.insert(2, 8));
        assert_eq!(m.get(&2), Some(&8));
        // remove drops the last-wins entry only; an earlier duplicate remains.
        assert_eq!(m.remove(&1), Some(9));
        assert_eq!(m.get(&1), Some(&1));
        assert_eq!(m.len(), 2);
        assert_eq!(m.remove(&1), Some(1));
        assert_eq!(m.get(&1), None);
        assert_eq!(m.len(), 1);
        m.clear();
        assert!(m.is_empty());
        assert_eq!(m.get(&2), None);
        assert_eq!(m.len(), 0);
    }

    #[test]
    fn map_mut_uses_index_and_from_slice_still_scans() {
        let mut m = Map::new();
        m.push_entry(1, 1);
        m.push_entry(1, 2);
        {
            let mut mm = m.as_mut();
            assert_eq!(mm.len(), 1);
            assert_eq!(mm.get(1), Some(2));
            assert!(mm.remove(1));
            assert_eq!(mm.get(1), Some(1));
            assert!(mm.remove(1));
            assert!(mm.is_empty());
        }
        let pairs = [(3, 30), (3, 31)];
        let view = MapView::from_slice(&pairs);
        assert_eq!(view.get(3), Some(31));
        assert_eq!(view.len(), 1);
    }

    #[test]
    fn arena_backed_map_iteration_does_not_leak_key_bytes() {
        let arena = crate::runtime::Arena::new();
        let raw = arena.alloc_map();
        // SAFETY: `raw` points to a map owned by `arena`; no view exists while inserting.
        unsafe {
            (*raw)
                .entries
                .borrow_mut()
                .push((b"alpha".to_vec(), crate::runtime::FieldKind::I32(7)));
        }
        // SAFETY: `arena` owns the map throughout the lifetime of this immutable view.
        let view: MapView<'_, ProtoString, i32> = unsafe { MapView::from_raw_ptr(raw) };
        let pairs: Vec<_> = view
            .iter()
            .map(|(key, value)| (key.as_bytes().to_vec(), value))
            .collect();
        assert_eq!(pairs, vec![(b"alpha".to_vec(), 7)]);
    }

    fn oracle_last_wins(wire: &[(i32, i32)]) -> (usize, Vec<(i32, i32)>) {
        use std::collections::HashMap;
        let mut last: HashMap<i32, i32> = HashMap::new();
        for (k, v) in wire {
            last.insert(*k, *v);
        }
        let mut order = Vec::new();
        for (i, (k, _)) in wire.iter().enumerate() {
            if wire[i + 1..].iter().all(|(k2, _)| k2 != k) {
                order.push((*k, last[k]));
            }
        }
        (last.len(), order)
    }

    #[test]
    fn hybrid_matches_scan_across_threshold() {
        // White-box boundary: below INDEX_THRESHOLD reads scan, at and above
        // they use the sorted index. Semantics must be identical.
        for n in [
            0,
            1,
            2,
            INDEX_THRESHOLD - 1,
            INDEX_THRESHOLD,
            INDEX_THRESHOLD + 1,
            64,
            100,
        ] {
            let wire: Vec<(i32, i32)> = (0..n as i32)
                .map(|i| ((i * 7 + 3) % ((n / 2 + 1) as i32).max(1), i))
                .collect();
            let mut m = Map::new();
            for (k, v) in &wire {
                m.push_entry(*k, *v);
            }
            let (unique, order) = oracle_last_wins(&wire);
            assert_eq!(m.pairs(), wire.as_slice(), "pairs keep wire order (n={n})");
            assert_eq!(m.len(), unique, "len (n={n})");
            assert_eq!(m.as_view().len(), unique, "view len (n={n})");
            for (k, v) in &order {
                assert_eq!(m.get(k), Some(v), "get {k} (n={n})");
                assert_eq!(m.as_view().get(*k), Some(*v), "view get {k} (n={n})");
            }
            assert_eq!(m.get(&i32::MIN), None, "missing key (n={n})");
            let got: Vec<(i32, i32)> = m.iter().map(|(k, v)| (*k, *v)).collect();
            assert_eq!(got, order, "iter order (n={n})");
            let vgot: Vec<(i32, i32)> = m.as_view().iter().collect();
            assert_eq!(vgot, order, "view iter order (n={n})");
        }
    }

    #[test]
    fn hybrid_hot_index_survives_insert_and_rebuilds_after_remove() {
        let n = INDEX_THRESHOLD + 8;
        let mut m = Map::new();
        for i in 0..n as i32 {
            m.push_entry(i, i * 10);
        }
        // Build the index, then mutate through both owned and view APIs.
        assert_eq!(m.get(&0), Some(&0));
        assert!(!m.insert(0, 1));
        assert!(m.insert(n as i32, -1));
        assert_eq!(m.get(&0), Some(&1));
        assert_eq!(m.get(&(n as i32)), Some(&-1));
        assert_eq!(m.len(), n + 1);
        {
            let mut mm = m.as_mut();
            assert!(!mm.insert(1, 11));
            assert!(mm.insert(n as i32 + 1, -2));
            assert_eq!(mm.get(1), Some(11));
            assert_eq!(mm.len(), n + 2);
            assert!(mm.remove(1));
            assert_eq!(mm.get(1), None);
            assert_eq!(mm.len(), n + 1);
        }
        // Duplicate-key remove drops only the last entry; the earlier one
        // resurfaces even after the index was dropped and rebuilt.
        m.push_entry(1000, 50);
        m.push_entry(1000, 51);
        assert_eq!(m.get(&1000), Some(&51));
        assert_eq!(m.remove(&1000), Some(51));
        assert_eq!(m.get(&1000), Some(&50));
        assert_eq!(m.remove(&1000), Some(50));
        assert_eq!(m.get(&1000), None);
        let (unique, order) = oracle_last_wins(m.pairs());
        assert_eq!(m.len(), unique);
        let got: Vec<(i32, i32)> = m.iter().map(|(k, v)| (*k, *v)).collect();
        assert_eq!(got, order);
    }

    #[test]
    fn arena_backed_map_values_are_reclaimed() {
        let arena = crate::runtime::Arena::new();
        let raw = arena.alloc_map();
        // SAFETY: raw is owned by arena and exclusively borrowed by map until
        // map is dropped before its backing arena.
        let mut map: MapMut<'_, ProtoString, ProtoString> = unsafe { MapMut::from_raw_inner(raw) };
        assert!(map.insert("alpha", "one"));
        assert!(!map.insert("alpha", "two"));
        assert_eq!(
            map.get("alpha").map(|v| v.as_bytes()),
            Some(b"two".as_slice())
        );
        assert!(map.remove("alpha"));
        assert!(map.is_empty());
    }
    #[test]
    #[allow(
        clippy::disallowed_macros,
        reason = "record prototype footprint when this dedicated test runs with nocapture"
    )]
    fn small_payload_uses_existing_space() {
        eprintln!(
            "prototype layouts: index={} slot={} inner={} iterator={} view_iterator={}",
            std::mem::size_of::<LastWinsIndex<i32>>(),
            std::mem::size_of::<OnceLock<LastWinsIndex<i32>>>(),
            std::mem::size_of::<MapInner<i32, i32>>(),
            std::mem::size_of::<MapIter<'static, i32, i32>>(),
            std::mem::size_of::<MapViewIter<'static, i32, i32>>()
        );
        assert_eq!(
            std::mem::size_of::<LastWinsIndex<i32>>(),
            std::mem::size_of::<Vec<(i32, usize)>>()
        );
        assert_eq!(
            std::mem::size_of::<OnceLock<LastWinsIndex<i32>>>(),
            std::mem::size_of::<OnceLock<Vec<(i32, usize)>>>()
        );
        #[cfg(target_pointer_width = "64")]
        {
            assert_eq!(std::mem::size_of::<MapInner<i32, i32>>(), 56);
            // Only iterator stack state grows by one pointer word. MapInner
            // remains the original56B heap allocation if the enum niche fits.
            assert_eq!(std::mem::size_of::<MapIter<'static, i32, i32>>(), 40);
            assert!(std::mem::size_of::<MapViewIter<'static, i32, i32>>() <= 48);
        }
    }

}
