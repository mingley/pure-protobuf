# Small-map cache prototype: Ready/Lazy iterator

Status: source-only preferred prototype. No compilation, formatting or timing
has run. Working production/tests stay at71422f00 while its campaign runs.
The initial one-slot-pointer variant is preserved in pointer-slot-original/.
Files map.rs and tests.rs are standalone copies for a later isolated variant.

Changes:

- Small(u16)/Large(Vec) index payload; Vec-niche footprint is a hypothesis.
- Cache a small last-winner mask at len() or explicit iterator.size_hint().
- Reuse bits for next and exact hints without repeating key comparisons.
- Preserve incremental cold-first next; no eager full-map mask construction.
- Iterator state distinguishes Ready(&Index) from Lazy(&OnceLock<Index>).
  Large constructors always initialize and retain Ready. A warm Small cache
  also resolves to Ready at construction. Their next/hint calls perform no
  atomic ready-state load. A cold Small Lazy can seed through &self hints;
  the following next promotes it to Ready once. Singleton/empty skip caching.
- Update/clear Small at owned/view insert, remove, push, clear and clone,
  including crossing threshold16.
- Keep borrowed small-map query comparisons allocation-free.

Expected64-bit footprint, not yet compiled:

| Object |71422 | Preferred prototype |
|---|---:|---:|
| Index payload |24B |24B hypothesis |
| OnceLock index slot |32B |32B hypothesis |
| MapInner heap container |56B |56B required |
| MapIter stack value |32B |40B expected |
| MapViewIter stack value |40B |at most48B required |

The larger iterator is an explicit stack/ABI tradeoff, not extra per-map heap
memory. Enum niches might keep the view iterator smaller; the dedicated
layout test prints actual sizes with --nocapture. Run on Rust1.85/current.

Proposed tests extend the nine baseline view tests with four checks covering
cached duplicate comparison/allocation counts, partial-iterator hint seeding,
cold-first comparison work, threshold transitions, and standard Send+Sync.
The private map module also contains one footprint gate (ten expected unit
tests in total). These are uncompiled tests, not passing results.

Open risks:

- The payload enum might grow on one compiler; reject until footprint gates
  pass. No Wire discriminants or generated outer Option<Box> change.
- The additional iterator word can affect returned-value ABI, sparse reads
  or inlining. All94mandatory codec/map/partial/encode rows must retain losses.
- Cold Small first next probes an uninitialized slot after constructor checked
  it, adding loads while preserving its key-comparison complexity.
- Referencing OnceLock strengthens exotic custom-key auto-trait requirements
  from Sync toSend+Sync; standard protobuf keys already satisfy both.
- Cold collect may repeat the already-yielded prefix once while building its
  complete mask; warm subsequent next calls use Ready and reuse the mask.
- This prototype does not optimize general large duplicate iteration.

No API or performance claim is made. Root must freeze an isolated source,
compile focused correctness/layout checks, and run unchanged before/after/
reference matrices before considering adoption.
