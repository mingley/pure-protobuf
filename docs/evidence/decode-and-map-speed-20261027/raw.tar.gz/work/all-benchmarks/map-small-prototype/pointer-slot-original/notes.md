# Small-map cache prototype

Status: source-only prototype. No compilation, formatting or measurement has
run. Working production and tests stay at71422f00 while its campaign runs.
Files map.rs and tests.rs are standalone copies for a later isolated variant.

Changes:

- Small(u16)/Large(Vec) index payload; a Vec-niche footprint is a hypothesis.
- Cache a small last-winner mask at len() or explicit iterator.size_hint().
- Reuse cached bits for next and exact hints without repeated key comparisons.
- Keep cold first-only next incremental; reuse the existing sorted large index.
- Update/clear small state at owned/view insert, remove, push, clear and clone,
  including crossing threshold16.
- Keep borrowed small-map query comparisons allocation-free.

Proposed tests extend the nine baseline map-view tests with cached duplicate
comparison/allocation counts, partial-iterator hint initialization, cold-first
comparison work, threshold transitions, and standard Send+Sync checks. The
private map module also contains a footprint test to run on1.85/current.
These are uncompiled tests, not passing results.

Open risks:

- The enum may grow on one compiler; reject until layout gates pass.
- A per-next OnceLock ready-state load may regress large unique loops.
- Referencing OnceLock strengthens exotic custom-key auto-trait requirements
  from Sync toSend+Sync; standard protobuf keys already satisfy both.
- Cold collect may repeat the already-yielded prefix's comparisons once when
  computing its complete cache. Full lifecycle/first-entry holdouts decide.
- The prototype does not optimize general large duplicate iteration.

See ../maps/next-design.md for complexity, scope and alternatives. Root must
freeze an isolated source and run the unchanged before/after/reference matrix
before considering adoption.
