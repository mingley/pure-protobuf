# Compressed fragment growth candidate

Baseline: 0287879dcfe381424cf9aabc919d9fea700dbe39.
Only production path changed: pbrs-grpc/src/wire/frame_reader.rs.

The carry buffer previously grew geometrically for every fragmented message.
An incompressible compressed message just over a power-of-two boundary can
therefore double again for its last few bytes. The candidate anticipates the
validated full frame length only when the next copy needs fresh capacity and
at least half the frame's bytes are already buffered or present in the next
DATA chunk. It does not reserve a full claim from the header alone, including
when message limits are explicitly unlimited. Header flag, limit and length
validation still precede this policy. Identity frames retain the earlier
incremental growth and whole-chunk shared-byte paths.

This is deliberately distinct from rejected PK-09's unconditional header-time
reservation, which hurt large identity RPC throughput. No new buffer, cache,
unsafe code, compression algorithm or codec behavior is introduced. The
existing bounded decompressor's 256 KiB input-size hint remains unchanged.

Three new focused controls exercise a power-of-two-plus-tail compressed frame
without a final allocation, a huge length claim with one observed body byte
under bounded and unlimited configurations, and a fragmented compressed frame
followed by an empty compressed frame and a whole identity frame while the
first payload is retained. Existing split hostile headers cover invalid flags;
existing codec/stream tests continue to check complete input and negotiated
compression. Tests use opaque frame payloads where decompression is outside
that framing unit's contract.

A shipping performance win is not yet established. Compare large gzip noise
and zero unary, upload and bidi traffic against the baseline and fresh Tonic
controls, keeping identity holdouts. Retain endpoint CPU and allocation results
separately; this structural change does not imply every RPC becomes faster.

## Validation and rejected adjacent prototype

The final framer source passes all 12 all-feature framer units, strict native
library Clippy and the independent negotiation (two tests) and decode-workspace
(one test) integration targets. The first negotiation run failed before any
RPC: a concurrent root WireInner-enum provenance prototype invalidated the
existing zeroed LazyStr layout. A Callgrind diagnostic with collection disabled
locates the null Arc drop in HelloRequest::set_name. Root restored the original
Wire layout and stores provenance in LazyInner instead; both integration
targets then pass. The initial failure, failed Memcheck startup (missing glibc
debug symbols), diagnostic stack and corrected run are retained separately.
These diagnostics are not benchmark measurements.

An outbound progress-aware reservation proposal was considered but not
implemented. Anticipating full plaintext-sized compressed output from a short
noisy prefix could overallocate severely when the remaining input compresses
well. Preserve current output-growth bounds and include prefix-noise/zero
holdouts before revisiting it. The shipping candidate remains framer-only.
