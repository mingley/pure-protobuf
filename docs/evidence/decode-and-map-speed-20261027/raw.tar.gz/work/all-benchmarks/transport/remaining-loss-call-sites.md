# Remaining transport allocation losses after C

This note is read-only source inspection during final CPU quiet. It introduces
no source variant, build, diagnostic run or shipping performance claim. The
matched C matrix remains authoritative; per-role cache-hit counts were not
instrumented in this inspection.

## Closed upload client

The benchmark native client queues four messages and closes its sender before
polling the Call: native_prost.rs ClientStream uses tokio::join!(send, call),
with the send future first. client/streaming.rs client_streaming_with_input
selects the no-deadline, producer-finished branch around line 1947.

write_closed_upload at client/streaming.rs:505 creates one OutBatch, encodes
all already-closed messages, and stores each taken SegFrame's Bytes in queued.
The transmission loop starts only after all messages have been compressed.
Thus earlier immutable output owners are necessarily alive while later output
is compressed. The C mutable tail cannot reclaim their backing. This is not
batch reconstruction or a false compressed-only gate; it is ownership imposed
by the pre-encode-entire-closed-stream path.

Bidi's measured fixture sends one request, reads its response, then sends the
next. The live pump's previous output can be consumed before its next encode,
which explains why the same cache is effective there.

Next target: interleave closed-stream encoding with network admission and stop
encoding when the send buffer blocks. Resume with a bounded combination of
already-encoded suffix and remaining unencoded messages. Preserve byte permits,
request order, half-close, cancellation, deadlines and early peer rejection,
including the existing RST_STREAM(NO_ERROR) repair. Merely queueing all frames
first or increasing the retention budget cannot remove these simultaneous
immutable owners.

## Server streaming download

server/drain.rs:966 constructs OutBatch once outside the producer loop.
Prost messages take the contiguous compressed path. The gate and lifetime of
the batch itself therefore do not explain the weak download-sender result.

The connection task also polls its admitted RPC writers: connection.rs:502
and the steady loop around 555 poll admitted futures before the H2 connection.
The download handler can prefill its response channel with four ready messages
(native_prost.rs:285), and drain_to_wire compresses ready items synchronously.

wire/send.rs send_bytes returns after the last suffix is accepted by
try_send_data, not after the socket consumes that suffix. With the default
one-megabyte send budget and a one-megabyte-plus-footer gzip frame, a small
queued tail can still own the complete previous output backing. The admitted
writer then compresses the next already-ready message in the same poll. Its H2
connection cannot flush that tail until the writer yields. A later BytesMut
reservation therefore sees a shared owner and allocates instead of reclaiming.
In the request/response-paced bidi shape, waiting for the next input gives the
connection driver an intervening opportunity to consume the tail.

This source-level explanation identifies the ownership/progress dependency;
exact counts of cache misses by sender shape still need a dedicated diagnostic.
Next target: a reliable large-frame write-progress handoff, pull-driven output,
or a tightly bounded second spare buffer under the same global budget. Avoid
unconditional yielding for small interactive streams, guessed completion, or
raising the sixteen-megabyte/four-megabyte cache ceilings.

## Eight-megabyte identity unary

The identity allocation gap is cold contiguous reassembly, not an output-cache
miss. read_one_message constructs a new FrameReader per call. Original large
allocation diagnostics located 31 MiB of carry requests (1+2+4+8+16 MiB) versus
about 10 MiB across Tonic incoming buffering. C's observed-half anticipation
removes the final 16 MiB request, but the earlier 1/2/4 MiB growth remains before
its exact eight-megabyte-plus-header allocation. That residual is consistent
with the roughly five-megabyte per-RPC requested-byte difference in the C
matrix. Identity output deliberately remains outside the compressed-only cache.

Next target: bounded staging of sufficiently large received chunks followed by
one exact contiguous copy after all payload bytes have arrived. Small-fragment
metadata must remain bounded, with a coalescing fallback, and existing header
limits, error precedence, whole-chunk sharing and retained-frame lifetimes must
remain intact. This avoids speculative allocation from an untrusted claim.
No segmented receive implementation is included in C.
