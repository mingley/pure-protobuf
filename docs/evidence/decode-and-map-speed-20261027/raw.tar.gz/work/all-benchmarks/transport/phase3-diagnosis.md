# Read-only allocation diagnosis on frozen71422

The original framer candidate has zero end-to-end allocation improvement in
matched gzip noise RPCs. Its sixteen-kilobyte fragmented unit exercised a
capacity boundary that the native default one-megabyte HTTP/2 DATA path skips.

## Why the original branch does not save the measured allocation

`config.rs` advertises one-megabyte maximum HTTP/2 DATA frames. For a gzip
message slightly larger than that, FrameReader first retains a full one-megabyte
DATA chunk. `push` copies that chunk into an empty carry with one-megabyte
capacity. Only afterward can `next_frame` see the final short chunk. Calling
BytesMut::reserve for the small suffix then uses Vec's amortized growth and
still doubles the existing allocation to two megabytes. Reserving before the
first copy is necessary; a later reservation cannot undo that first capacity.

The separate frame-prototype.rs validates the complete header and configured
cap, waits for at least half the frame to have actually arrived, and only then
allocates the exact full frame from an empty carry before the first copy.
It also applies observed-half growth to larger identity fragments. Whole frames
still use shared incoming Bytes directly. Four new controls cover real native
one-megabyte DATA plus footer, eight-megabyte identity plus a short tail,
deferred hostile flag/cap errors, and cold huge claims with almost no body.
All sixteen isolated71422+overlay framer unit tests pass; no production source
was edited for this prototype.

## Diagnostic call stacks, not performance evidence

The LD_PRELOAD tracer records only malloc/calloc/realloc requests at least
65,536 bytes, their sizes, and module-relative call stacks. It records no
payload contents, credentials or timing claims. Two/four-RPC gzip runs and
one/two-RPC identity runs use already-built frozen allocation binaries and
complete every requested call. Fixed binary/tracer hashes, commands, raw
allocation records, stack resolution and limitations are retained in allocdiag.
These instrumented runs overlap validation and cannot establish shipping CPU.
Their libc interception also does not cover every possible aligned path.

The large-request differences identify:

| Path | Native requested bytes/RPC | Tonic requested bytes/RPC |
|---|---:|---:|
| Four-message gzip noise: append_compressed including encoder state | about 9.52 MB | about 2.18 MB across compression and matching encoder-state sites |
| Four-message gzip noise: fragmented compressed carry | 3,145,728 | separate incoming-buffer category |
| Four-message gzip noise: cold decode workspace growth | about 2,883,592 | about 4,202,692 in decode_chunk |
| Eight-megabyte identity: carry push plus copies/growth | 32,505,856 (31 MiB) | about 10,485,770 across poll_frame/decode_chunk |

The owned compressed decode workspace does reclaim its buffer. Its cold
allocation sequence is 256 KiB, 512 KiB, 1 MiB and exact one-megabyte-plus-protobuf
output, once per four-message RPC. A failure to reuse all four messages is not
the observed source of the allocation gap. Its existing 256 KiB initial hint,
8 KiB EOF lookahead, CRC/member checks and per-message limits need not change.

The identity traffic difference is almost entirely the geometric contiguous
carry: one, two, four, eight and sixteen MiB allocations total31 MiB, compared
with about 10 MiB of Tonic incoming-buffer growth. Payload construction, Prost's
owned body copy, serialization and HTTP/2 read allocations are each about 8 MiB
on both endpoints. Observed-half anticipation should remove the final 16 MiB
request, but further gains would require avoiding early carry growth, such as
bounded staging of large received chunks and one exact coalescing copy only
after the complete payload has arrived. Small-fragment metadata must remain
bounded; no such segmented receive implementation is proposed for this batch.

## Separate outbound reuse prototype

OutBatch::take_frame and flush replace the entire SegSink with a new sink;
SegSink::finish consumes its head. Every large compressed message therefore
regrows output from 4 KiB. Tonic retains an empty BytesMut tail with
split_to(len).freeze and can reclaim that backing for the next message.
Native large-output-buffer traffic is about 8.39 MB over four messages before
counting requests smaller than 64 KiB, versus about 1.06 MB for Tonic; both use
about 1.13 MB of matching compressor-state allocations.

encode-prototype.rs and out-batch-prototype.rs are separate full-module source
copies, not production changes. They retain only contiguous heads larger than
64 KiB and use the existing shared 16 MiB encode-retention ledger and 4 MiB per-buffer
ceiling. Optional cache metadata is boxed so the ordinary small-output path
adds only one optional pointer to its sink. The full original backing capacity is charged before splitting; the
empty tail capacity alone is insufficient. Field order drops the tail before
its lease. The current conservative prototype reclaims only unique backing at
the next encode; a previous immutable frame remains valid on a cache miss.
Three new controls cover reclaim, held immutable output, and an oversized
backing containing only a short message. These sources remain uncompiled.

An early unique-only test may miss reuse when HTTP/2 still owns the previous
frame at encode start. Keeping a shared spare tail until BytesMut next grows
could permit later automatic reclaim while compression does useful work, but
its complete prior backing must remain conservatively charged. Explicitly
predicting final output from a short noisy prefix is rejected: a large later
zero suffix would make that reservation excessive. Preserve output-growth
bounds and test prefix-noise and zero holdouts before any capacity prediction.

## Superseding guarded variant C

Variant B was not selected: independent review found that custom identity
codecs could replace the head with a small suffix of an oversized allocation,
and a caught failure could leave an empty uncharged tail. No measured win is
claimed for B. Variant C requires entirely compressed batches; identity attempts
invalidate retention before any user callback and remain invalid across
rollback, including failing oversized-suffix identity encoders. A move-out
sink/scratch guard covers encoded_len, size limits, codecs, compression and
logging. Error or unwind preserves only prior nonempty complete output, drops
empty uncharged backing and discards scratch. Earlier immutable frames remain
unchanged. The same global sixteen-megabyte/four-megabyte-per-buffer encode
ledger charges complete backing, conservatively including prior full capacity.

The framer also tries to reclaim its unique empty carry before allocating a
new exact first-copy buffer. Variant A discarded that tail, causing streaming
regressions despite its unary gain; the C control checks real one-megabyte
DATA reuse and an earlier held frame that prevents reclaim.

The isolated C snapshot passes69 wire tests, strict all-feature library Clippy
and an independent noise-body lifecycle fixture covering mixed sizes, an
oversized cache miss, twenty concurrent streams under the unchanged global
budget, cancellation, deadlines and final zero retention gauges. Independent
review reports no remaining blocker and binds exact three-file source hashes.
All production source stays71422 until measured selection and root validation.
C still requires matched CPU/allocation and holdout results before adoption.
