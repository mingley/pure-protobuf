#define _GNU_SOURCE
#include <dlfcn.h>
#include <execinfo.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdatomic.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

/* Diagnostic only. No payload bytes, environment values or timing samples. */
extern void *__libc_malloc(size_t);
extern void *__libc_calloc(size_t, size_t);
extern void *__libc_realloc(void *, size_t);
static __thread int tracing __attribute__((tls_model("initial-exec")));
static atomic_int output = ATOMIC_VAR_INIT(-2);

static void record(const char *op, size_t size, size_t old_size) {
    if (tracing || size < 65536) return;
    tracing = 1;
    int descriptor = atomic_load(&output);
    if (descriptor == -2) {
        int expected = -2;
        if (!atomic_compare_exchange_strong(&output, &expected, -3)) {
            tracing = 0;
            return;
        }
        const char *directory = getenv("PBRS_ALLOC_TRACE_DIR");
        if (directory) {
            char filename[1024];
            snprintf(filename, sizeof(filename), "%s/trace.%ld.log", directory, (long)getpid());
            descriptor = open(filename, O_WRONLY | O_APPEND | O_CREAT | O_CLOEXEC, 0600);
        } else descriptor = -1;
        atomic_store(&output, descriptor);
    }
    if (descriptor >= 0) {
        void *frames[20];
        int count = backtrace(frames, 20);
        char line[4096];
        int used = snprintf(line, sizeof(line), "%s %zu %zu", op, size, old_size);
        for (int i = 2; i < count && used < (int)sizeof(line) - 128; ++i) {
            Dl_info info;
            if (dladdr(frames[i], &info) && info.dli_fname && info.dli_fbase) {
                const char *name = info.dli_fname;
                for (const char *p = name; *p; ++p) if (*p == '/') name = p + 1;
                used += snprintf(line + used, sizeof(line) - used, " %s+%zx", name,
                                 (uintptr_t)frames[i] - (uintptr_t)info.dli_fbase);
            }
        }
        if (used >= (int)sizeof(line)) used = sizeof(line) - 1;
        line[used++] = '\n';
        (void)write(descriptor, line, used);
    }
    tracing = 0;
}

void *malloc(size_t size) {
    void *pointer = __libc_malloc(size);
    if (pointer) record("malloc", size, 0);
    return pointer;
}

void *calloc(size_t count, size_t size) {
    void *pointer = __libc_calloc(count, size);
    if (pointer && (!count || size <= SIZE_MAX / count)) record("calloc", count * size, 0);
    return pointer;
}

void *realloc(void *old, size_t size) {
    void *pointer = __libc_realloc(old, size);
    if (pointer) record("realloc", size, 0);
    return pointer;
}
