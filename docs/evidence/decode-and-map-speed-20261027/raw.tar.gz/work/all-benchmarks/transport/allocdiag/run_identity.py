"""Trace large allocation callsites for matched8MiB identity RPCs; not timing."""
import hashlib, importlib.util, json, os
from pathlib import Path
from types import SimpleNamespace
ROOT=Path(__file__).resolve().parents[4];BASE=Path(__file__).resolve().parent
M=ROOT/'work/all-benchmarks/measurement'
spec=importlib.util.spec_from_file_location('rpc_diag_identity',M/'rpc_compressed_helper.py')
helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
binary=M/'candidate-rpc/rpc-allocations';out=BASE/'identity-captures';out.mkdir(exist_ok=False)
os.environ['LD_PRELOAD']=str(BASE/'trace.so')
report=dict(diagnostic=True,qualified=False,timing_claims=False,
    binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),runs=[])
for label,pair in [('native-client',['native','prost','tonic','prost']),
                   ('native-server',['tonic','prost','native','prost']),
                   ('tonic-control',['tonic','prost','tonic','prost'])]:
    for n in [1,2]:
        name=f'{label}-{n}';traces=out/(name+'-traces');traces.mkdir()
        os.environ['PBRS_ALLOC_TRACE_DIR']=str(traces)
        args=SimpleNamespace(binary=binary,source_checkout=M/'candidate-source',duration=45,
            rpc_count=n,allocation_counts=True,context_switches=False,callgrind=None,strace=None)
        cell=dict(pair=pair,shape='unary',payload_bytes=8388608,payload_pattern='zero',
                  stream_messages=4,tls=False,compression='identity',max_message_size=16777216)
        r=helper.run_cell(args,cell,out/name)
        row=dict(name=name,count=n,passed=r['passed']);report['runs'].append(row)
        (BASE/'identity-results.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps(row),flush=True)
        if not r['passed']:raise SystemExit(r.get('error','Diagnostic identity RPC failed'))
report['complete']=True
(BASE/'identity-results.json').write_text(json.dumps(report,indent=2)+'\n')
