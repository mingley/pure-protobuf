"""Diagnostic call sites from existing frozen binaries; no CPU claims."""
import hashlib, importlib.util, json, os
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[4]
BASE = Path(__file__).resolve().parent
M = ROOT/'work/all-benchmarks/measurement'
spec = importlib.util.spec_from_file_location('rpc_diagnostic_helper', M/'rpc_compressed_helper.py')
helper = importlib.util.module_from_spec(spec); spec.loader.exec_module(helper)
binary = M/'candidate-rpc/rpc-allocations'
out = BASE/'captures'; out.mkdir(exist_ok=False)
os.environ['LD_PRELOAD'] = str(BASE/'trace.so')
report = dict(qualified=False, diagnostic=True, timing_claims=False,
              source='71422f008b4df06b7c68365a806327b0a4bdfa61',
              binary_sha256=hashlib.sha256(binary.read_bytes()).hexdigest(),
              tracer_sha256=hashlib.sha256((BASE/'trace.c').read_bytes()).hexdigest(), runs=[])
for label, pair in [('native-client',['native','prost','tonic','prost']),
                    ('native-server',['tonic','prost','native','prost']),
                    ('tonic-control',['tonic','prost','tonic','prost'])]:
    for n in [2, 4]:
        name = f'{label}-{n}'
        traces = out/(name+'-traces'); traces.mkdir()
        os.environ['PBRS_ALLOC_TRACE_DIR'] = str(traces)
        args = SimpleNamespace(binary=binary, source_checkout=M/'candidate-source',
            duration=45, rpc_count=n, allocation_counts=True, context_switches=False,
            callgrind=None, strace=None)
        cell = dict(pair=pair, shape='bidi', payload_bytes=1048576,
                    payload_pattern='noise', stream_messages=4, tls=False, compression='gzip')
        r = helper.run_cell(args, cell, out/name)
        row = dict(name=name, count=n, passed=r['passed'], path=str((out/name).relative_to(BASE)))
        report['runs'].append(row)
        (BASE/'results.json').write_text(json.dumps(report, indent=2)+'\n')
        print(json.dumps(row), flush=True)
        if not r['passed']: raise SystemExit(r.get('error','Diagnostic RPC failed'))
report['complete'] = True
(BASE/'results.json').write_text(json.dumps(report,indent=2)+'\n')
