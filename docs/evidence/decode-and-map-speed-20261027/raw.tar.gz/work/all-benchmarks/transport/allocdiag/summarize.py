"""Resolve diagnostic libc allocation stacks, not performance results."""
import bisect, collections, json, re, subprocess, sys
from pathlib import Path
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[3]
binary=ROOT/'work/all-benchmarks/measurement/candidate-rpc/rpc-allocations'
symbols=[]
for line in subprocess.check_output(['nm','-n','--demangle',str(binary)],text=True).splitlines():
    m=re.match(r'([0-9a-f]+) [tTwW] (.*)',line)
    if m: symbols.append((int(m[1],16),m[2]))
symbols.sort(); positions=[p for p,_ in symbols]
def resolve(address):
    i=bisect.bisect_right(positions,int(address,16))-1
    return symbols[i][1] if i>=0 else '?'
def category(stack):
    for phrase in ['read_bounded_into','append_compressed','FrameReader','with_payload',
                   'decode_payload_reusable','decode_payload','miniz_oxide','flate2',
                   'h2_backend','tonic::codec','prost::encoding']:
        matches=[s for s in stack if phrase in s]
        if matches: return matches[0]
    return next((s for s in stack if 'rpc_bench' in s),stack[0] if stack else '?')
identity='--identity' in sys.argv
low,high=(1,2) if identity else (2,4)
CAPTURES=BASE/('identity-captures' if identity else 'captures')
allruns={}; traces={}
for label in ['native-client','native-server','tonic-control']:
    for count in [low,high]:
        name=f'{label}-{count}'; run=json.loads((CAPTURES/name/'run.json').read_text())
        roles={run['server_cpu_before']['pid']:'server',run['resource_samples'][0]['client']['pid']:'client'}
        totals={role:collections.Counter() for role in roles.values()}
        for path in (CAPTURES/(name+'-traces')).glob('*.log'):
            role=roles[int(path.stem.split('.')[1])]
            for line in path.read_text().splitlines():
                words=line.split(); size=int(words[1]); addresses=[s.split('+')[1] for s in words[3:] if s.startswith('rpc-allocations+')]
                stack=[resolve(a) for a in addresses]; key=category(stack)
                totals[role][key]+=size
                tracekey=(key,size)
                if tracekey not in traces:traces[tracekey]=dict(category=key,requested_bytes=size,addresses=addresses,stack=stack)
        allruns[name]={k:dict(v) for k,v in totals.items()}
slopes={}
for label in ['native-client','native-server','tonic-control']:
    slopes[label]={}
    for role in ['client','server']:
        a,b=allruns[f'{label}-{low}'][role],allruns[f'{label}-{high}'][role]
        slopes[label][role]={key:(b.get(key,0)-a.get(key,0))/(high-low) for key in sorted(set(a)|set(b))}
report=dict(diagnostic=True,qualified=False,timing_claims=False,minimum_traced_request=65536,
            limits=['libc malloc/calloc/realloc interception, not every possible aligned allocator path',
                    'backtrace instrumentation changes execution and these runs overlap other validation',
                    'two/four RPC differences classify allocation sources; they are not a qualified allocation campaign'],
            per_rpc_large_requested_byte_differences=slopes,raw_category_totals=allruns,
            example_stacks=list(traces.values()))
(BASE/('identity-summary.json' if identity else 'summary.json')).write_text(json.dumps(report,indent=2)+'\n')
for label,role in [('native-client','client'),('native-server','server'),('tonic-control','client'),('tonic-control','server')]:
    print(label,role)
    for key,value in sorted(slopes[label][role].items(),key=lambda x:-x[1])[:14]:print(round(value,1),key)
