"""Resume an immutable six-cell RPC plan with separate CPU/allocator binaries."""
import argparse,hashlib,importlib.util,itertools,json,platform,random,shutil,statistics
from pathlib import Path
from types import SimpleNamespace
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def interval(values):return dict(median=statistics.median(values),range=[min(values),max(values)],pairs=values)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for side in ('before','after'):
  for what in ('binary','record','checkout'):p.add_argument('--'+side+'-'+what,required=True,type=Path)
 p.add_argument('--mode',choices=['shipping','allocations'],required=True);p.add_argument('--output',required=True,type=Path);p.add_argument('--plan',type=Path,default=BASE/'rpc-compressed-plan-v2.json');p.add_argument('--capture-limit',type=int,default=12);p.add_argument('--resume',action='store_true');a=p.parse_args()
 if a.capture_limit<1:p.error('capture-limit must be positive')
 out=a.output.resolve();plan=json.loads(a.plan.read_text());repeats=plan['repetitions'][a.mode];binaries={s:getattr(a,s+'_binary').resolve(strict=True) for s in ('before','after')};records={s:json.loads(getattr(a,s+'_record').read_text()) for s in binaries};hashes={s:sha(b) for s,b in binaries.items()};key='rpc-'+a.mode
 for side in binaries:
  assert records[side]['binaries'][key]['sha256']==hashes[side]
  build=json.loads((getattr(a,side+'_record').parent/records[side]['binaries'][key]['build_record']).read_text())
  assert build['source_unchanged'] and build['harness_unchanged'] and build['exit_code']==0
  assert ('allocation-counts' in build['features'])==(a.mode=='allocations')
 helper_path=BASE/'rpc_compressed_helper.py';spec=importlib.util.spec_from_file_location('rpc_compressed_helper',helper_path);helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
 rng=random.Random(plan['seed']);groups=list(itertools.product(range(repeats),plan['cells']));rng.shuffle(groups);order=[]
 for repeat,cell in groups:
  pairs=list(itertools.product(plan['pairs'].items(),cell['counts']));rng.shuffle(pairs)
  for (name,pair),count in pairs:
   versions=['before','after'];rng.shuffle(versions)
   order.extend(dict(repeat=repeat,cell_name=cell['name'],cell=cell,pair_name=name,pair=pair,count=count,source=source) for source in versions)
 static=dict(schema='pbrs.compressed-rpc-comparison.v1',qualified=False,mode=a.mode,plan=plan,execution_order=order,binaries=hashes,build_records=records,helper_sha256=sha(helper_path),controller_sha256=sha(Path(__file__)))
 target=out/'manifest.json'
 if a.resume:
  manifest=json.loads(target.read_text())
  for k,v in static.items():
   if manifest[k]!=v:raise ValueError('Resume input changed: '+k)
  if manifest['state']=='complete':raise ValueError('Already complete')
 else:
  out.mkdir(parents=True,exist_ok=False);manifest=dict(static,state='running',passed=False,runs=[],host=platform.uname()._asdict())
 def save():target.write_text(json.dumps(manifest,indent=2)+'\n')
 save();shutil.copy2(__file__,out/'controller.py');shutil.copy2(helper_path,out/'helper.py');shutil.copy2(a.plan,out/'plan.json')
 start=len(manifest['runs'])
 try:
  for entry in order[start:start+a.capture_limit]:
   cell={k:v for k,v in entry['cell'].items() if k not in ('name','counts')};cell['pair']=entry['pair']
   settings=SimpleNamespace(binary=binaries[entry['source']],source_checkout=getattr(a,entry['source']+'_checkout').resolve(),duration=60,rpc_count=entry['count'],allocation_counts=a.mode=='allocations',context_switches=False,callgrind=None,strace=None)
   directory=out/f'capture-{len(manifest["runs"]):03d}';result=helper.run_cell(settings,cell,directory)
   row=dict(source=entry['source'],repeat=entry['repeat'],name=entry['cell_name'],pair=entry['pair_name'],count=entry['count'],path=str(directory.relative_to(out)/'run.json'),passed=result['passed']);manifest['runs'].append(row);save()
   if not result['passed']:raise ValueError(result.get('error','RPC failed'))
   if result['metrics']['payload_pattern']!=cell['payload_pattern']:raise ValueError('Worker did not validate requested payload pattern')
   print(f'{len(manifest["runs"])}/{len(order)} {a.mode} RPC captures passed',flush=True)
  for side,binary in binaries.items():
   if sha(binary)!=hashes[side]:raise ValueError('Frozen binary changed')
  if sha(helper_path)!=static['helper_sha256']:raise ValueError('RPC helper changed')
  if len(manifest['runs'])<len(order):manifest['state']='paused';save();return
  raw={(r['source'],r['repeat'],r['name'],r['pair'],r['count']):json.loads((out/r['path']).read_text()) for r in manifest['runs']};summaries=[]
  metrics=['cpu_seconds'] if a.mode=='shipping' else ['requested_bytes','allocations']
  for cell in plan['cells']:
   n,nn=cell['counts'];name=cell['name']
   for native_pair,side in [('native_client','client'),('native_server','server')]:
    for metric in metrics:
     slopes={s:{peer:[] for peer in ('native','tonic')} for s in binaries}
     def value(record):
      if a.mode=='allocations':return record['allocation_totals'][side][metric]
      return record['client_lifetime_cpu_seconds' if side=='client' else 'server_cpu_during_client_seconds']*1e6
     for source,repeat in itertools.product(binaries,range(repeats)):
      for peer,pair in [('native',native_pair),('tonic','control')]:slopes[source][peer].append((value(raw[source,repeat,name,pair,nn])-value(raw[source,repeat,name,pair,n]))/(nn-n))
     positive=all(x>0 for source in slopes.values() for values in source.values() for x in values)
     ratios=None
     if positive:
      ratios={k:interval(v) for k,v in dict(after_over_before_native=[a/b for a,b in zip(slopes['after']['native'],slopes['before']['native'])],after_native_over_tonic=[a/b for a,b in zip(slopes['after']['native'],slopes['after']['tonic'])],control_after_over_before=[a/b for a,b in zip(slopes['after']['tonic'],slopes['before']['tonic'])]).items()}
     summaries.append(dict(cell=name,endpoint=side,metric='cpu_us_per_rpc' if a.mode=='shipping' else metric+'_per_rpc',repeats=repeats,all_slopes_positive=positive,paired_slopes=slopes,medians={s:{p:statistics.median(v) for p,v in peers.items()} for s,peers in slopes.items()},ratios=ratios))
  (out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n');manifest.update(state='complete',passed=True,successful_rpcs=sum(r['count'] for r in manifest['runs']),captures=len(order));save()
 except Exception as error:manifest.update(state='failed',passed=False,error=str(error));save();raise
 print(json.dumps(dict(state=manifest['state'],captures=len(manifest['runs']))),flush=True)
if __name__=='__main__':main()
