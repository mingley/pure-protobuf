#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH="/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH"
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
export CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0
cargo test --locked --manifest-path work/all-benchmarks/measurement/phase2-source/Cargo.toml -p pbrs --lib map::tests > work/all-benchmarks/measurement/phase2-map-unit.log 2>&1
cargo test --locked --manifest-path work/all-benchmarks/measurement/phase2-source/Cargo.toml -p pbrs --test map_views > work/all-benchmarks/measurement/phase2-map-views.log 2>&1
cargo test --locked --manifest-path work/all-benchmarks/measurement/phase2-source/Cargo.toml -p pbrs --lib codegen::tests > work/all-benchmarks/measurement/phase2-codegen-unit.log 2>&1
cargo +1.85.0 check --locked --manifest-path work/all-benchmarks/measurement/phase2-source/Cargo.toml -p pbrs --no-default-features --lib > work/all-benchmarks/measurement/phase2-msrv.log 2>&1
python3 work/all-benchmarks/measurement/build_matrix.py work/all-benchmarks/measurement/phase2-source phase2 --map-harness work/all-benchmarks/measurement/phase2-map-harness > work/all-benchmarks/measurement/build-phase2.log 2>&1
python3 work/all-benchmarks/measurement/build_holdouts.py work/all-benchmarks/measurement/phase2-source phase2 > work/all-benchmarks/measurement/build-phase2-holdouts.log 2>&1
