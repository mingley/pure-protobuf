"""Interleave frozen before/after endpoint CPU captures and fresh tonic controls."""
import argparse
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
from datetime import datetime,timezone
from types import SimpleNamespace

ROOT=Path(__file__).resolve().parents[3]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def interval(values,seed):
 r=random.Random(seed);draws=sorted(statistics.median(r.choices(values,k=len(values))) for _ in range(20_000))
 return dict(median=statistics.median(values),range=[min(values),max(values)],diagnostic_bootstrap95=[draws[499],draws[19499]],pairs=values)
def main():
 p=argparse.ArgumentParser(description=__doc__)
 for source in ('before','after'):
  p.add_argument(f'--{source}-binary',required=True,type=Path)
  p.add_argument(f'--{source}-record',required=True,type=Path)
  p.add_argument(f'--{source}-checkout',required=True,type=Path)
 p.add_argument('--plan',type=Path,default=Path(__file__).with_name('rpc_plan.json'));p.add_argument('--output',required=True,type=Path)
 p.add_argument('--resume',action='store_true');p.add_argument('--capture-limit',type=int,default=24)
 args=p.parse_args();out=args.output.resolve()
 if args.capture_limit<1:p.error('capture-limit must be positive')
 if args.resume:
  if not out.is_dir():p.error('resume output does not exist')
 else:out.mkdir(parents=True,exist_ok=False)
 binaries={s:getattr(args,f'{s}_binary').resolve(strict=True) for s in ('before','after')}
 records={s:json.loads(getattr(args,f'{s}_record').read_text()) for s in binaries}
 hashes={s:sha(binaries[s]) for s in binaries}
 for s in binaries:
  if hashes[s]!=records[s]['binaries']['rpc-shipping']['sha256']:raise ValueError(f'{s} RPC binary differs from record')
 plan=json.loads(args.plan.read_text());rng=random.Random(plan['seed'])
 helper_path=ROOT/'work/encode_smoke.py';spec=importlib.util.spec_from_file_location('fix_rpc_helper',helper_path)
 helper=importlib.util.module_from_spec(spec);spec.loader.exec_module(helper)
 groups=list(itertools.product(range(plan['repeats']),plan['cells']));rng.shuffle(groups)
 order=[]
 for repeat,cell in groups:
  pairs=list(itertools.product(plan['pairs'].items(),cell['counts']));rng.shuffle(pairs)
  for (pair_name,pair),count in pairs:
   versions=['before','after'];rng.shuffle(versions)
   for source in versions:order.append(dict(repeat=repeat,cell_name=cell['name'],spec=cell,pair_name=pair_name,pair=pair,count=count,source=source))
 manifest=dict(schema='pbrs.rpc-fix-comparison.v1',qualified=False,passed=False,state='running',plan=plan,execution_order=order,
               binaries=hashes,build_records=records,helper_sha256=sha(helper_path),controller_sha256=sha(Path(__file__)),host=platform.uname()._asdict(),
               cgroup_before=Path('/sys/fs/cgroup/cpu.stat').read_text(),runs=[])
 target=out/'manifest.json'
 if args.resume:
  saved=json.loads(target.read_text())
  for key in ('plan','execution_order','binaries','build_records','helper_sha256','controller_sha256'):
   if saved[key]!=manifest[key]:raise ValueError('Resumed campaign inputs changed: '+key)
  if saved['state']=='complete':raise ValueError('Campaign already complete')
  manifest=saved
 phase_start=len(manifest['runs']);phase_started=datetime.now(timezone.utc).isoformat()
 manifest.update(state='running',passed=False)
 def save():target.write_text(json.dumps(manifest,indent=2)+'\n')
 save();shutil.copy2(__file__,out/'rpc_compare.py');shutil.copy2(helper_path,out/'helper.py');shutil.copy2(args.plan,out/'rpc_plan.json')
 for s in records:shutil.copy2(getattr(args,f'{s}_record'),out/f'{s}-build.json')
 try:
  for entry in order[phase_start:phase_start+args.capture_limit]:
   cell={k:v for k,v in entry['spec'].items() if k not in ('name','counts')};cell['pair']=entry['pair']
   options=SimpleNamespace(binary=binaries[entry['source']],source_checkout=getattr(args,f"{entry['source']}_checkout").resolve(),duration=60,
                           rpc_count=entry['count'],allocation_counts=False,context_switches=False,callgrind=None,strace=None)
   directory=out/f"capture-{len(manifest['runs']):03d}"
   result=helper.run_cell(options,cell,directory)
   manifest['runs'].append(dict(source=entry['source'],repeat=entry['repeat'],name=entry['cell_name'],pair=entry['pair_name'],
                                count=entry['count'],path=str(directory.relative_to(out)/'run.json'),passed=result['passed']))
   save()
   if not result['passed']:raise ValueError(result.get('error','RPC capture failed'))
   if len(manifest['runs'])%12==0:print(f"{len(manifest['runs'])}/{len(order)} captures passed",flush=True)
  for s in binaries:
   if sha(binaries[s])!=hashes[s]:raise ValueError('Frozen binary changed')
  if sha(helper_path)!=manifest['helper_sha256']:raise ValueError('Controller helper changed')
  if len(manifest['runs'])!=len(order):
   manifest.update(state='paused',passed=False)
   print(json.dumps(dict(state='paused',captures=len(manifest['runs']),total=len(order))),flush=True)
   return
  raw={}
  for row in manifest['runs']:
   result=json.loads((out/row['path']).read_text())
   raw[row['source'],row['repeat'],row['name'],row['pair'],row['count']]=result
  summaries=[]
  for cell in plan['cells']:
   n,nn=cell['counts'];name=cell['name']
   for pair,side,metric in [('native_client','client','client_lifetime_cpu_seconds'),('native_server','server','server_cpu_during_client_seconds')]:
    slopes={s:{'native':[],'tonic':[]} for s in binaries}
    for s,repeat in itertools.product(binaries,range(plan['repeats'])):
     for label,peer in [('native',pair),('tonic','control')]:
      slope=(raw[s,repeat,name,peer,nn][metric]-raw[s,repeat,name,peer,n][metric])/(nn-n)*1e6
      slopes[s][label].append(slope)
    positive=all(v>0 for s in slopes.values() for values in s.values() for v in values)
    ratios=None
    if positive:
     ratios={key:interval(values,plan['seed']) for key,values in {
       'after_over_before_native':[a/b for a,b in zip(slopes['after']['native'],slopes['before']['native'])],
       'after_native_over_tonic':[a/b for a,b in zip(slopes['after']['native'],slopes['after']['tonic'])],
       'before_native_over_tonic':[a/b for a,b in zip(slopes['before']['native'],slopes['before']['tonic'])],
       'after_over_before_tonic_control':[a/b for a,b in zip(slopes['after']['tonic'],slopes['before']['tonic'])]}.items()}
    summaries.append(dict(cell=name,endpoint=side,cpu_us_per_rpc_paired_slopes=slopes,
                          cpu_us_per_rpc_medians={s:{peer:statistics.median(v) for peer,v in values.items()} for s,values in slopes.items()},
                          all_slopes_positive=positive,ratios=ratios))
  (out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
  manifest.update(state='complete',passed=True,captures=len(order),successful_rpcs=sum(r['count'] for r in manifest['runs']))
 except Exception as error:
  manifest.update(state='failed',passed=False,error=str(error));raise
 finally:
  manifest.setdefault('phases',[]).append(dict(started=phase_started,ended=datetime.now(timezone.utc).isoformat(),runs_before=phase_start,runs_after=len(manifest['runs']),capture_limit=args.capture_limit))
  manifest['cgroup_after']=Path('/sys/fs/cgroup/cpu.stat').read_text();save()
 print(json.dumps({k:manifest[k] for k in ('state','captures','successful_rpcs')}),flush=True)
if __name__=='__main__':main()
