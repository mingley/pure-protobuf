"""Summarize raw D cgroup observation windows without modifying performance ratios."""
from pathlib import Path
from datetime import datetime
import json
BASE=Path(__file__).resolve().parent
report=json.loads((BASE/'phase6-host-observations.json').read_text());observations={r['note']:r for r in report['observations']}
def statistics(row,name):return {k:int(v) for k,v in (line.split() for line in row['files'][name].splitlines())}
windows=[]
for start,end in [('campaign-start','campaign-end'),('identity-confirmation-start','campaign-end')]:
 a,b=observations[start],observations[end];x,y=statistics(a,'/sys/fs/cgroup/cpu.stat'),statistics(b,'/sys/fs/cgroup/cpu.stat');mem_x,mem_y=statistics(a,'/sys/fs/cgroup/memory.events'),statistics(b,'/sys/fs/cgroup/memory.events')
 windows.append(dict(start_note=start,end_note=end,start_utc=a['timestamp_utc'],end_utc=b['timestamp_utc'],wall_seconds=(datetime.fromisoformat(b['timestamp_utc'])-datetime.fromisoformat(a['timestamp_utc'])).total_seconds(),cpu_stat_delta={k:y[k]-x[k] for k in x},memory_events_delta={k:mem_y[k]-mem_x[k] for k in mem_x},memory_current_start_bytes=int(a['files']['/sys/fs/cgroup/memory.current']),memory_current_end_bytes=int(b['files']['/sys/fs/cgroup/memory.current']),cpu_max=a['files']['/sys/fs/cgroup/cpu.max'],memory_max_bytes=int(a['files']['/sys/fs/cgroup/memory.max'])))
output=dict(schema='pbrs.host-observation-window-summary.v1',scope='Cgroup observations only; no normalization, exclusion or attribution of raw benchmark results',windows=windows)
(BASE/'phase6-host-window.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
