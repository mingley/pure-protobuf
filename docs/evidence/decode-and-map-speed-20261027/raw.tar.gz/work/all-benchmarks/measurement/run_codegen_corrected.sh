#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
for phase in 1 2; do
for profile in debug release; do
if [ "$phase" = 1 ]; then
if [ "$profile" = debug ]; then
before=work/all-benchmarks/codegen/baseline-canonical-driver
after=work/all-benchmarks/codegen/final-candidate-debug/driver
else
before=work/all-benchmarks/codegen/final-baseline-release/driver
after=work/all-benchmarks/codegen/final-candidate-release/driver
fi
else
before=work/all-benchmarks/codegen/final-candidate-$profile/driver
after=work/all-benchmarks/codegen/phase2-candidate-$profile/driver
fi
if [ "$profile" = debug ]; then
control=work/all-benchmarks/codegen/prost-canonical-driver
else
control=work/all-benchmarks/codegen/final-prost-release/driver
fi
for part in 1 2 3 4 5; do
python3 work/all-benchmarks/measurement/codegen_compare_blocking.py --baseline "$before" --candidate "$after" --prost "$control" --profile "$profile" --output work/all-benchmarks/measurement/codegen-corrected-phase$phase-$profile --resume --capture-limit 12 > work/all-benchmarks/measurement/measure-codegen-corrected-phase$phase-$profile-$part.log 2>&1
done
done
done
