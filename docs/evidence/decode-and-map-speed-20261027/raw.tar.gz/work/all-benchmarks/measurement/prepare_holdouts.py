"""Use the existing partial/encode loops; select storage and label output outside timing."""
from pathlib import Path
import argparse,difflib,hashlib,json,shutil
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
OLD=ROOT/'work/fix-performance-round/benchmark'
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('label');a=p.parse_args()
source=a.source.resolve()
for kind,template,binary in [('partial','partial-getter','pbrs-partial-getter-proof'),('encode','encode-holdout','pbrs-encode-proof')]:
 out=BASE/(a.label+'-'+kind+'-harness');shutil.copytree(OLD/template,out)
 shutil.copy2(OLD/'partial-getter.proto',out/'partial-getter.proto')
 cargo=(out/'Cargo.toml').read_text().replace('FROZEN_CORE',str(source)).replace('allocations = []','allocations = []\nowned-messages = []')
 (out/'Cargo.toml').write_text(cargo)
 build=(out/'build.rs').read_text().replace('pbrs::codegen::Config::new().out_dir','pbrs::codegen::Config::new().owned_message_fields(cfg!(feature = "owned-messages")).out_dir')
 (out/'build.rs').write_text(build)
 old=(out/'src/main.rs').read_text();needle='"semantic_prechecks":true'
 if needle not in old:needle='"semantic_prechecks": true'
 assert needle in old
 new=old.replace(needle,needle+',"message_storage": if cfg!(feature="owned-messages") {"owned"} else {"lazy"}')
 (out/'src/main.rs').write_text(new)
 lock=(OLD/'partial-before/Cargo.lock').read_text()
 if kind=='encode':lock=lock.replace('name = "pbrs-partial-getter-proof"','name = "pbrs-encode-proof"')
 (out/'Cargo.lock').write_text(lock)
 (BASE/(a.label+'-'+kind+'-metadata.diff')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=template+'/src/main.rs',tofile=out.name+'/src/main.rs')))
 record=dict(source=str(source),template=str(OLD/template),binary=binary,changes=['Feature selects existing Config owned_message_fields profile in build.rs','Untimed JSON adds message_storage; timed source unchanged'],files={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()})
 (BASE/(out.name+'-prepared.json')).write_text(json.dumps(record,indent=2)+'\n')
