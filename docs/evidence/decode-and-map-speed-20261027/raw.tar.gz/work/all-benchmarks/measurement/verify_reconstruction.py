"""Verify every compact source overlay using a temporary directory and Git history."""
from pathlib import Path
import json,subprocess,tempfile
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
results=[]
with tempfile.TemporaryDirectory(prefix='pbrs-all-benchmarks-reconstruct-') as temporary:
 for variant in ('baseline','candidate','phase2','phase3','phase4','phase5','phase6'):
  command=['python3',str(BASE/'reconstruct_variant.py'),str(ROOT),str(Path(temporary)/variant),variant]
  done=subprocess.run(command,capture_output=True,text=True)
  item=dict(variant=variant,exit_code=done.returncode,stdout=done.stdout,stderr=done.stderr)
  results.append(item)
  if done.returncode:break
report=dict(schema='pbrs.source-overlay-reconstruction-proof.v1',complete=len(results)==7 and all(r['exit_code']==0 for r in results),variants=results)
(BASE/'reconstruction-proof.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report));assert report['complete']
