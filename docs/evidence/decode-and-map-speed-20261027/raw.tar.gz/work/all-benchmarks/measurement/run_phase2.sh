#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
python3 work/all-benchmarks/measurement/measure_phase2.py codec --storage lazy > work/all-benchmarks/measurement/measure-phase2-codec-lazy.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py codec --storage owned > work/all-benchmarks/measurement/measure-phase2-codec-owned.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py map-small > work/all-benchmarks/measurement/measure-phase2-map-small.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py map-large > work/all-benchmarks/measurement/measure-phase2-map-large.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py partial --storage lazy > work/all-benchmarks/measurement/measure-phase2-partial-lazy.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py partial --storage owned > work/all-benchmarks/measurement/measure-phase2-partial-owned.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py encode --storage lazy > work/all-benchmarks/measurement/measure-phase2-encode-lazy.log 2>&1
python3 work/all-benchmarks/measurement/measure_phase2.py encode --storage owned > work/all-benchmarks/measurement/measure-phase2-encode-owned.log 2>&1
export PBRS_CODEGEN_TIME=/workspace/pure-protobuf/work/all-benchmarks/measurement/time-package/root/usr/bin/time
for part in 1 2 3 4 5; do
python3 work/all-benchmarks/measurement/codegen_compare.py --baseline work/all-benchmarks/codegen/final-candidate-debug/driver --candidate work/all-benchmarks/codegen/phase2-candidate-debug/driver --prost work/all-benchmarks/codegen/prost-canonical-driver --profile debug --output work/all-benchmarks/measurement/phase2-codegen-debug --resume --capture-limit 12 > work/all-benchmarks/measurement/measure-phase2-codegen-debug-$part.log 2>&1
done
for part in 1 2 3 4 5; do
python3 work/all-benchmarks/measurement/codegen_compare.py --baseline work/all-benchmarks/codegen/final-candidate-release/driver --candidate work/all-benchmarks/codegen/phase2-candidate-release/driver --prost work/all-benchmarks/codegen/final-prost-release/driver --profile release --output work/all-benchmarks/measurement/phase2-codegen-release --resume --capture-limit 12 > work/all-benchmarks/measurement/measure-phase2-codegen-release-$part.log 2>&1
done
