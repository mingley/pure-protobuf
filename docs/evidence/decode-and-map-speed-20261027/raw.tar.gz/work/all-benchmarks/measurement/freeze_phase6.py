"""Freeze71422 plus the reviewed compressed-only D overlays, never mutate C."""
from pathlib import Path
import argparse,hashlib,json,shutil
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--overlay-root',type=Path,required=True);p.add_argument('--expected-hashes',type=Path,required=True);a=p.parse_args()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
paths=('pbrs-grpc/src/wire/frame_reader.rs','pbrs-grpc/src/wire/encode.rs','pbrs-grpc/src/wire/out_batch.rs')
expected=json.loads(a.expected_hashes.read_text());assert set(expected)==set(paths)
baseline=json.loads((BASE/'candidate-source-source.json').read_text());old=json.loads((BASE/'phase5-source-source.json').read_text());target=BASE/'phase6-source';assert not target.exists()
assert all(sha(a.overlay_root/f)==expected[f] for f in paths)
assert all(expected[f]==old['files'][f] for f in paths if not f.endswith('/frame_reader.rs'))
shutil.copytree(BASE/'candidate-source',target)
changes={}
for f in paths:
 before=sha(target/f);shutil.copy2(a.overlay_root/f,target/f);changes[f]=dict(prototype=str((a.overlay_root/f).resolve()),before=before,after=sha(target/f))
files={str(f.relative_to(target)):sha(f) for f in target.rglob('*') if f.is_file()}
assert set(files)==set(baseline['files'])
assert {f for f in files if files[f]!=old['files'][f]}=={'pbrs-grpc/src/wire/frame_reader.rs'}
record=dict(baseline=baseline['commit'],source=str(target),variant='safe compressed-only D; identity reserve restored to71422',declared_changes=changes,files=files)
(BASE/'phase6-source-source.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(source=str(target),files=len(files),changed_from_C=['pbrs-grpc/src/wire/frame_reader.rs'],overlays=changes)))
