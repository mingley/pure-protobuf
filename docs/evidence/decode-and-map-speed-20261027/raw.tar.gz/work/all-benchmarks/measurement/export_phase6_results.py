"""Join unchanged 71422 core/generator rows with the exact safe-D RPC campaign.

This is a source-scoped ledger, not a claim that all domains were rebuilt from C.
Historical phase1 results are immutable and remain independently available.
"""
from pathlib import Path
import csv,hashlib,json
BASE=Path(__file__).resolve().parent
old=json.loads((BASE/'results.json').read_text())
rows=[dict(r,baseline_source=old['baseline'],candidate_source=old['candidate']) for r in old['timing_rows'] if not r['suite'].startswith('rpc-')]
resources=[dict(r,baseline_source=old['baseline'],candidate_source=old['candidate']) for r in old['resource_rows'] if not r['suite'].startswith('rpc-')]
matrices={k:v for k,v in old['matrices'].items() if not k.startswith('rpc-')}
counts={}
for name in ['phase6-rpc-default-comparison','phase6-rpc-shipping-comparison','phase6-rpc-allocation-comparison','phase6-rpc-identity-confirmation']:
 p=BASE/name/'summary.json';m=json.loads(p.with_name('manifest.json').read_text())
 assert m['state']=='complete' and m['passed'], name
 values=json.loads(p.read_text());matrices[name]=dict(path=str(p.relative_to(BASE)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=len(values))
 counts[name]=dict(captures=len(m['runs']),successful_rpcs=m['successful_rpcs'])
 for r in values:
  v=r.get('cpu_us_per_rpc_medians',r.get('medians'));q=r['ratios']['after_native_over_tonic'] if r.get('ratios') else None;z=r['ratios']['after_over_before_native'] if r.get('ratios') else None
  key=dict(suite='rpc-identity-confirmation' if 'identity-confirmation' in name else 'rpc-default' if 'default' in name else 'rpc-compressed',storage='',profile='',case=r['cell'],operation='',endpoint=r['endpoint'],control='Tonic0.14.6 with same Prost codec',baseline_source=old['candidate'],candidate_source='71422+safe-D-three-wire-files')
  row=dict(key,metric=r.get('metric','cpu_us_per_rpc'),before=v['before']['native'],after=v['after']['native'],control_after=v['after']['tonic'],paired_after_before=z['median'] if z else None,paired_after_control=q['median'] if q else None,pair_min=q['range'][0] if q else None,pair_max=q['range'][1] if q else None,all_repeat_win=max(q['pairs'])<1 if q else False,comparison=('win' if q['median']<1 else 'tie' if q['median']==1 else 'loss') if q else 'invalid_nonpositive_slope',source=matrices[name]['path'],before_after_pair_range=z['range'] if z else None,before_after_pairs=z['pairs'] if z else None,control_pairs=q['pairs'] if q else None)
  (resources if 'allocation' in name else rows).append(row)
fields=['suite','storage','profile','case','operation','endpoint','control','metric','before','after','control_after','paired_after_before','paired_after_control','pair_min','pair_max','all_repeat_win','comparison','source','baseline_source','candidate_source','before_after_pair_range','before_after_pairs','control_pairs']
for name,values in [('phase6-timing-ledger.csv',rows),('phase6-resource-ledger.csv',resources)]:
 with (BASE/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(values)
losses=[r for r in rows if r['comparison']!='win'];rlosses=[r for r in resources if r['comparison']!='win']
missing=old['gate']['missing_axes']
source=json.loads((BASE/'phase6-source-source.json').read_text())
gate=dict(schema='pbrs.source-scoped-all-win-gate.v1',qualified=False,world_ranking_established=False,all_benchmarks_won=not losses and not rlosses and not missing,all_covered_timing_medians_win=not losses,all_covered_timing_repeats_win=all(r['all_repeat_win'] for r in rows),timing_rows=len(rows),timing_losses_or_ties_or_invalid=len(losses),resource_rows=len(resources),resource_losses_or_ties_or_invalid=len(rlosses),missing_axes=missing,remaining_timing_losses=losses,remaining_resource_losses=rlosses)
report=dict(schema='pbrs.safe-D-source-scoped-results.v1',complete=True,qualified=False,world_ranking_established=False,all_benchmarks_won=gate['all_benchmarks_won'],selection='candidate pending parent performance review',source_scope=dict(core_and_generator='71422f008b4df06b7c68365a806327b0a4bdfa61',rpc='71422+exact three safe-D overlays',rpc_source_manifest='phase6-source-source.json',rpc_source_manifest_sha256=hashlib.sha256((BASE/'phase6-source-source.json').read_bytes()).hexdigest(),declared_rpc_changes=source['declared_changes'],timer='d66e8d06 blocking completion wait, excluded sampler teardown'),timing_rows=rows,resource_rows=resources,remaining_timing_losses=losses,remaining_resource_losses=rlosses,matrices=matrices,rpc=counts,total_rpc_successful=sum(v['successful_rpcs'] for v in counts.values()),gate=gate,historical_evidence=dict(phase1='results.json',phase2_rejected='phase2-results.json',framer_A_attribution_only='phase3-rpc-allocation-comparison',unsafe_B_unmeasured='phase4-rpc',C_rejected_identity_CPU_tradeoff='phase5-results.json',polling_timer_diagnostics='codegen-timer-audit.json'),limits=old['limits']+['Core and codegen retain 028-to-71422 attribution; RPC compares 71422 to the exact three safe-D wire overlays.','Rejecting a map or descriptor-worker prototype never removes its raw evidence.','CPU and allocator peers use independently frozen shipping and instrumented binaries.','The separately reported identity8MiB500/1000 confirmation retains the original10/20 rows and uses the exact same binaries and cell settings.'])
(BASE/'phase6-results.json').write_text(json.dumps(report,indent=2)+'\n');(BASE/'phase6-all-win-gate.json').write_text(json.dumps(gate,indent=2)+'\n')
print(json.dumps(dict(timing_rows=len(rows),timing_losses=len(losses),resource_rows=len(resources),resource_losses=len(rlosses),rpc_successful=report['total_rpc_successful'],all_benchmarks_won=report['all_benchmarks_won'])))
