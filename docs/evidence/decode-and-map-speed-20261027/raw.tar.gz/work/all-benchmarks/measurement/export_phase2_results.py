"""Export absolute values, paired ratios and every loss without metric mixing."""
from pathlib import Path
import csv,hashlib,json
BASE=Path(__file__).resolve().parent
rows=[];resources=[];matrices={}
def read(name):
 p=BASE/name/'summary.json';r=json.loads(p.read_text());matrices[name]=dict(path=str(p.relative_to(BASE)),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),rows=len(r));return r
for name,suite,storage in [('phase2-codec-lazy-comparison','codec','lazy'),('phase2-codec-owned-comparison','codec','owned'),('phase2-map-small-comparison','warm-map','lazy'),('phase2-map-large-comparison','warm-map','lazy'),('phase2-partial-lazy-comparison','partial','lazy'),('phase2-partial-owned-comparison','partial','owned'),('phase2-encode-lazy-comparison','encode','lazy'),('phase2-encode-owned-comparison','encode','owned')]:
 for r in read(name):
  q=r['ratios']['after_pbrs_over_prost'];z=r['ratios']['after_over_before_pbrs'];v=r['cpu_ns_medians'];key=dict(suite=suite,storage=storage,profile='',case=r['case'],operation=r['operation'],endpoint='',control='std::collections::HashMap' if suite=='warm-map' else 'Prost0.14.4')
  rows.append(dict(key,metric='process_cpu_ns_per_operation',before=v['before']['pbrs'],after=v['after']['pbrs'],control_after=v['after']['prost'],paired_after_before=z['median'],paired_after_control=q['median'],pair_min=q['range'][0],pair_max=q['range'][1],all_repeat_win=max(q['pairs'])<1,comparison='win' if q['median']<1 else 'tie' if q['median']==1 else 'loss',source=matrices[name]['path']))
  for metric in ['requested_bytes','allocation_calls']:
   a=r['allocations']['after-pbrs'][metric];c=r['allocations']['after-prost'][metric];b=r['allocations']['before-pbrs'][metric];ratio=None if c==0 else a/c
   resources.append(dict(key,metric=metric+'_per_operation',before=b,after=a,control_after=c,paired_after_before=None if b==0 else a/b,paired_after_control=ratio,pair_min=None,pair_max=None,all_repeat_win=None,comparison='win' if a<c else 'tie' if a==c else 'loss',source=matrices[name]['path']))
for profile in ['debug','release']:
 name='codegen-corrected-phase2-'+profile;manifest=json.loads((BASE/name/'manifest.json').read_text())
 for r in read(name):
  q=r['ratios']['after_pbrs_over_prost'];z=r['ratios']['after_over_before_pbrs'];v=r['elapsed_ns_medians'];key=dict(suite='codegen',storage='',profile=profile,case=r['case'],operation=r['operation'],endpoint='',control='prost-build0.14.4 canonicalCLI')
  rows.append(dict(key,metric='generation_elapsed_wall_ns',before=v['before']['pbrs'],after=v['after']['pbrs'],control_after=v['after']['prost'],paired_after_before=z['median'],paired_after_control=q['median'],pair_min=q['range'][0],pair_max=q['range'][1],all_repeat_win=max(q['pairs'])<1,comparison='win' if q['median']<1 else 'tie' if q['median']==1 else 'loss',source=matrices[name]['path']))
  resources.append(dict(key,metric='generated_rust_bytes',before=r['generated_bytes']['baseline'],after=r['generated_bytes']['candidate'],control_after=r['generated_bytes']['prost'],paired_after_before=r['generated_bytes']['candidate']/r['generated_bytes']['baseline'],paired_after_control=r['generated_bytes']['candidate']/r['generated_bytes']['prost'],pair_min=None,pair_max=None,all_repeat_win=None,comparison='win' if r['generated_bytes']['candidate']<r['generated_bytes']['prost'] else 'loss',source=matrices[name]['path']))
  cells=[c for c in manifest['captures'] if c['case']==r['case']];values={(c['repeat'],c['source'],c['backend']):c['phases'][r['operation']]['peak_rss_bytes'] for c in cells}
  import statistics
  ratios=[values[i,'after','pbrs']/values[i,'after','prost'] for i in range(5)];q=statistics.median(ratios)
  resources.append(dict(key,metric='process_tree_peak_rss_lower_bound_bytes',before=statistics.median(values[i,'before','pbrs'] for i in range(5)),after=statistics.median(values[i,'after','pbrs'] for i in range(5)),control_after=statistics.median(values[i,'after','prost'] for i in range(5)),paired_after_before=statistics.median(values[i,'after','pbrs']/values[i,'before','pbrs'] for i in range(5)),paired_after_control=q,pair_min=min(ratios),pair_max=max(ratios),all_repeat_win=max(ratios)<1,comparison='win' if q<1 else 'tie' if q==1 else 'loss',source=matrices[name]['path']))
for name in []:
 for r in read(name):
  v=r.get('cpu_us_per_rpc_medians',r.get('medians'));q=r['ratios']['after_native_over_tonic'] if r.get('ratios') else None;z=r['ratios']['after_over_before_native'] if r.get('ratios') else None
  key=dict(suite='rpc-default' if name=='rpc-default-comparison' else 'rpc-compressed',storage='',profile='',case=r['cell'],operation='',endpoint=r['endpoint'],control='Tonic0.14.6 with same Prost codec')
  row=dict(key,metric=r.get('metric','cpu_us_per_rpc'),before=v['before']['native'],after=v['after']['native'],control_after=v['after']['tonic'],paired_after_before=z['median'] if z else None,paired_after_control=q['median'] if q else None,pair_min=q['range'][0] if q else None,pair_max=q['range'][1] if q else None,all_repeat_win=max(q['pairs'])<1 if q else False,comparison=('win' if q['median']<1 else 'tie' if q['median']==1 else 'loss') if q else 'invalid_nonpositive_slope',source=matrices[name]['path'])
  (resources if 'allocation' in name else rows).append(row)
fields=['suite','storage','profile','case','operation','endpoint','control','metric','before','after','control_after','paired_after_before','paired_after_control','pair_min','pair_max','all_repeat_win','comparison','source']
for name,values in [('phase2-timing-ledger.csv',rows),('phase2-resource-ledger.csv',resources)]:
 with (BASE/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(values)
counts={}
for name in []:
 m=json.loads((BASE/name/'manifest.json').read_text());assert m['state']=='complete' and m['passed'];counts[name]=dict(captures=len(m['runs']),successful_rpcs=m['successful_rpcs'])
result=dict(schema='pbrs.all-benchmarks-final-results.v1',baseline='71422f008b4df06b7c68365a806327b0a4bdfa61',candidate='isolated phase2 map + descriptors overlay; not adopted',complete=True,qualified=False,all_benchmarks_won=False,world_ranking_established=False,core=dict(rows=94,shipping_processes=1880,cpu_samples=5640,separate_allocation_processes=376),generation=dict(rows=12,driver_cells=120,successful_invocations=240,consumer_build_costs_measured=False,wall_timing_status='corrected blockingwait before sampler teardown; originalpollingcampaigns retained'),rpc=counts,total_rpc_successful=sum(v['successful_rpcs'] for v in counts.values()),timing_rows=rows,resource_rows=resources,remaining_timing_losses=[r for r in rows if r['comparison']!='win'],remaining_resource_losses=[r for r in resources if r['comparison']!='win'],matrices=matrices,gate=dict(all_benchmarks_won=False,adoption='rejected',reason='Large-map unique iteration regresses5.9–8.2times; many small-map regressions',source_manifest='phase2-source-source.json'),aborted_attempts=[],limits=['All local shared-host diagnostics; missing axes and all losses remain explicit.','CPU/wall, allocation, generated source bytes and RSS remain separate metrics.','Five paired CPU/wall repeats; two RPCallocation pairs and one1000-operation instrumentedcapture percoreallocation row.','Baseline RPCallocation used exact pinned support-module harness after export omission; original failedbuild retained.'])
(BASE/'phase2-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(timing_rows=len(rows),timing_losses=len(result['remaining_timing_losses']),resource_rows=len(resources),resource_losses=len(result['remaining_resource_losses']),rpc_successful=result['total_rpc_successful'])))
