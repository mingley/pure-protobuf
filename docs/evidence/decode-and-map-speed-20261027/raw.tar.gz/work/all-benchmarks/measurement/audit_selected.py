"""Verify the selected frozen source, harness, feature and executable provenance."""
from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest={label:json.loads((BASE/(label+'-source-source.json')).read_text()) for label in ('baseline','candidate')}
report=dict(schema='pbrs.selected-artifact-audit.v1',complete=False,sources={},binaries={},harnesses={},baseline='0287879dcfe381424cf9aabc919d9fea700dbe39',candidate='71422f008b4df06b7c68365a806327b0a4bdfa61')
for label,source in manifest.items():
 root=BASE/(label+'-source');actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};assert actual==source['files'];report['sources'][label]=dict(files=len(actual),unchanged=True,manifest_sha256=sha(BASE/(label+'-source-source.json')))
for side in ('baseline','candidate'):
 for group in ('lazy','owned','map','partial-lazy','partial-owned','encode-lazy','encode-owned'):
  root=BASE/(side+'-'+group)
  for mode in ('shipping','allocations'):
   record=json.loads((root/('codec-'+mode+'-build.json')).read_text());binary=root/('codec-'+mode)
   assert record['exit_code']==0 and record['source_unchanged'] and record['harness_unchanged'];assert record['source_files']==manifest[side]['files'];assert sha(binary)==record['binary_sha256'];assert binary.read_bytes()[:4]==b'\x7fELF'
   expected=({'owned-messages'} if group.endswith('owned') else set())|({'allocations'} if mode=='allocations' else set());assert set(record['features'])==expected
   report['binaries'][side+'/'+group+'/'+mode]=dict(sha256=sha(binary),features=record['features'],source_files=len(record['source_files']))
for name in ('src/main.rs','Cargo.toml','Cargo.lock','build.rs','proto/cases.proto'):
 left=BASE/'baseline-source/tests/proof/codec_benchmark'/name;right=BASE/'candidate-source/tests/proof/codec_benchmark'/name
 if left.exists():assert left.read_bytes()==right.read_bytes();report['harnesses']['codec/'+name]=sha(left)
for kind in ('map','partial','encode'):
 a=BASE/(('map-baseline-harness') if kind=='map' else 'baseline-'+kind+'-harness');b=BASE/(('map-candidate-harness') if kind=='map' else 'candidate-'+kind+'-harness')
 for name in ('src/main.rs','build.rs','Cargo.lock','partial-getter.proto'):
  if (a/name).exists():assert (a/name).read_bytes()==(b/name).read_bytes();report['harnesses'][kind+'/'+name]=sha(a/name)
 before=(a/'Cargo.toml').read_text().replace(str(BASE/'baseline-source'),'FROZEN_CORE');after=(b/'Cargo.toml').read_text().replace(str(BASE/'candidate-source'),'FROZEN_CORE');assert before==after;report['harnesses'][kind+'/normalized-manifest-equal']=True
for side,mode,dirname in [('baseline','shipping','baseline-rpc'),('baseline','allocations','baseline-rpc-allocation-repaired'),('candidate','shipping','candidate-rpc'),('candidate','allocations','candidate-rpc')]:
 root=BASE/dirname;record=json.loads((root/('rpc-'+mode+'-build.json')).read_text());binary=root/('rpc-'+mode)
 assert record['source_unchanged'] and record['harness_unchanged'] and record['exit_code']==0;assert record['source_files']==manifest[side]['files'];assert sha(binary)==record['binary_sha256'];assert set(record['features'])==({'default'}|({'allocation-counts'} if mode=='allocations' else set()))
 report['binaries'][side+'/rpc/'+mode]=dict(sha256=sha(binary),features=record['features'],source_files=len(record['source_files']),auxiliary_harness=record.get('auxiliary_harness'))
repair=json.loads((BASE/'baseline-rpc-allocation-harness.json').read_text());root=BASE/'baseline-rpc-allocation-harness';assert all(sha(root/p)==h for p,h in repair['files'].items());assert repair['rpc_source_unchanged'] and repair['production_core_unchanged'];report['rpc_allocation_repair']=dict(manifest_sha256=sha(BASE/'baseline-rpc-allocation-harness.json'),files=len(repair['files']),allocator_identical_to_final=repair['allocator_identical_to_final'])
base,final=(manifest[x]['files'] for x in ('baseline','candidate'));report['source_changes']={p:dict(before=base.get(p),after=final.get(p)) for p in sorted(set(base)|set(final)) if base.get(p)!=final.get(p)}
assert set(final)-set(base)=={'bench/devloop/compression/src/allocator.rs'}
report['complete']=True;(BASE/'artifact-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,binaries=len(report['binaries']),source_changes=len(report['source_changes']))))
