#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
bash work/all-benchmarks/measurement/run_phase5_allocation.sh > work/all-benchmarks/measurement/phase5-allocation-driver.log 2>&1
bash work/all-benchmarks/measurement/run_phase5_shipping.sh > work/all-benchmarks/measurement/phase5-shipping-driver.log 2>&1
bash work/all-benchmarks/measurement/run_phase5_default.sh > work/all-benchmarks/measurement/phase5-default-driver.log 2>&1
