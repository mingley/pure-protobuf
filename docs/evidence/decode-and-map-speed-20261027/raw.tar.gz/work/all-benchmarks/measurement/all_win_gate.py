"""Recompute every fixed-row control comparison; never omit losses or missing axes."""
from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent
MATRICES={
 'candidate-codec-lazy-comparison':('codec','lazy',16),
 'candidate-codec-owned-comparison':('codec','owned',16),
 'candidate-map-small-comparison':('warm-map','lazy',24),
 'candidate-map-large-comparison':('warm-map','lazy',18),
 'candidate-partial-lazy-comparison':('partial','lazy',2),
 'candidate-partial-owned-comparison':('partial','owned',2),
 'candidate-encode-lazy-comparison':('encode','lazy',8),
 'candidate-encode-owned-comparison':('encode','owned',8),
}
def ratio(actual,control):
 if control==0:return dict(ratio=None,comparison='tie' if actual==0 else 'loss',reason='both zero' if actual==0 else 'control zero')
 value=actual/control
 return dict(ratio=value,comparison='win' if value<1 else 'tie' if value==1 else 'loss')
def main():
 rows=[];missing=[];inputs={};expected_cpu_rows=sum(v[2] for v in MATRICES.values())
 for directory,(suite,storage,count) in MATRICES.items():
  path=BASE/directory/'summary.json';manifest_path=path.with_name('manifest.json')
  if not path.exists():missing.append(dict(axis=directory,expected_cpu_rows=count,reason='No completed measurements'));continue
  manifest=json.loads(manifest_path.read_text())
  if manifest['state']!='complete':missing.append(dict(axis=directory,expected_cpu_rows=count,reason='Campaign incomplete'));continue
  values=json.loads(path.read_text());assert len(values)==count
  inputs[str(path.relative_to(BASE))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for value in values:
   cpu=value['ratios']['after_pbrs_over_prost'];alloc=value['allocations'];after=alloc['after-pbrs'];control=alloc['after-prost']
   rows.append(dict(suite=suite,storage=storage,case=value['case'],operation=value['operation'],control='std::collections::HashMap' if suite=='warm-map' else 'Prost0.14.4',source=str(path.relative_to(BASE)),cpu=dict(metric='process CPU ns/op',paired_median_ratio=cpu['median'],pair_range=cpu['range'],pairs=cpu['pairs'],median_comparison='win' if cpu['median']<1 else 'tie' if cpu['median']==1 else 'loss',all_repeat_win=max(cpu['pairs'])<1),allocation=dict(metric='successful allocation/reallocation requests per operation; separate instrumented binary',sampling='one independent1000-iteration capture per source/backend/row; no five-pair uncertainty claimed',actual=after,control=control,requested_bytes=ratio(after['requested_bytes'],control['requested_bytes']),allocation_calls=ratio(after['allocation_calls'],control['allocation_calls']))))
 for profile in ('debug','release'):
  path=BASE/('codegen-corrected-phase1-'+profile)/'summary.json'
  if not path.exists():missing.append(dict(axis='codegen-'+profile,expected_cpu_rows=6,reason='Generation timing not completed'));continue
  manifest=json.loads(path.with_name('manifest.json').read_text());assert manifest['state']=='complete'
  values=json.loads(path.read_text());assert len(values)==6;inputs[str(path.relative_to(BASE))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for value in values:
   cpu=value['ratios']['after_pbrs_over_prost'];rows.append(dict(suite='codegen',storage=None,case=value['case'],operation=value['operation'],profile=profile,control='prost-build0.14.4 canonicalCLI',source=str(path.relative_to(BASE)),cpu=dict(metric='blocking-wait generation command wall ns; process-start included, sampler teardown excluded',paired_median_ratio=cpu['median'],pair_range=cpu['range'],pairs=cpu['pairs'],median_comparison='win' if cpu['median']<1 else 'tie' if cpu['median']==1 else 'loss',all_repeat_win=max(cpu['pairs'])<1),generated_output_bytes=dict(actual=value['generated_bytes']['candidate'],control=value['generated_bytes']['prost'],**ratio(value['generated_bytes']['candidate'],value['generated_bytes']['prost'])),allocation=dict(status='missing Prost allocation-counter control; isolated pbrs allocation captures are not a peer comparison')))
 # RPC summaries are optional until their raw complete campaign is supplied.
 for name in ('rpc-default','rpc-compressed-shipping','rpc-compressed-allocation'):
  path=BASE/(name+'-comparison')/'summary.json'
  if not path.exists():missing.append(dict(axis=name,reason='No completed exact-source comparison'));continue
  values=json.loads(path.read_text());inputs[str(path.relative_to(BASE))]=hashlib.sha256(path.read_bytes()).hexdigest()
  for value in values:
   if value.get('all_slopes_positive') is False or not value.get('ratios'):
    rows.append(dict(suite=name,case=value['cell'],endpoint=value['endpoint'],cpu=dict(median_comparison='invalid',reason='Nonpositive N/2N slope; cannot divide or claim a win')));continue
   q=value['ratios']['after_native_over_tonic'];r=dict(suite=name,case=value['cell'],endpoint=value['endpoint'],control='Tonic0.14.6 with same Prost codec',source=str(path.relative_to(BASE)),cpu=dict(metric='endpoint processCPU N/2N slope' if 'allocation' not in name else 'allocator requests N/2N slope; instrumented CPU unusable',paired_median_ratio=q['median'],pair_range=q['range'],pairs=q['pairs'],median_comparison='win' if q['median']<1 else 'tie' if q['median']==1 else 'loss',all_repeat_win=max(q['pairs'])<1))
   if 'allocation' in name:r['allocation_metric']=value.get('metric','requested_bytes')
   rows.append(r)
 missing.extend([dict(axis='generator-consumer-cold-check',reason='Fresh consumer compilation not measured in generation-only campaigns'),dict(axis='generator-consumer-incremental-check',reason='Fresh consumer incremental cost not measured'),dict(axis='generator-consumer-release-build',reason='Fresh consumer release build cost not measured'),dict(axis='service-stub-generation-and-consumer-costs',reason='The message generation campaign does not measure the existing stub matrix'),dict(axis='generator-allocation-control',reason='Prost allocation-counter peer absent; no allocation superiority claim'),dict(axis='complete-tonic-bench-serialization-and-construction-survey',reason='The current nested holdouts and codec cases do not cover every existing standalone survey row'),dict(axis='realistic-codegen-corpora',reason='OTLP, Google APIs and Envoy existing corpora are outside the three synthetic generation cases'),dict(axis='RPC-TLS-and-varied-load',reason='These fixed comparisons are plaintext and one connection/one RPC in flight'),dict(axis='dedicated-host-qualified-performance',reason='All local campaigns run on a shared host')])
 resources=[]
 for r in rows:
  if 'allocation' in r['suite']:
   q=r.pop('cpu');r['allocator_comparison']=q;resources.append(dict(suite=r['suite'],case=r['case'],endpoint=r['endpoint'],metric=r['allocation_metric'],comparison=q['median_comparison'],paired_median_ratio=q.get('paired_median_ratio'),pair_range=q.get('pair_range'),pairs=q.get('pairs'),repeats=2,scope='Separate instrumented N/2N process pairs; not CPU evidence'))
  elif r.get('allocation',{}).get('requested_bytes'):
   for metric in ('requested_bytes','allocation_calls'):
    q=r['allocation'][metric];resources.append(dict(suite=r['suite'],storage=r.get('storage'),case=r['case'],operation=r['operation'],metric=metric,actual=r['allocation']['actual'][metric],control=r['allocation']['control'][metric],**q))
 cpu=[r for r in rows if 'allocation' not in r['suite']]
 runtime_cpu=[r for r in cpu if r['suite']!='codegen']
 generation_wall=[r for r in cpu if r['suite']=='codegen']
 losses=[r for r in cpu if r['cpu']['median_comparison']!='win']
 alloc=[r for r in rows if r.get('allocation',{}).get('requested_bytes')]
 report=dict(schema='pbrs.all-fixed-benchmarks-gate.v1',baseline='0287879dcfe381424cf9aabc919d9fea700dbe39',candidate='71422f008b4df06b7c68365a806327b0a4bdfa61',qualified=False,world_ranking_established=False,all_benchmarks_won=bool(cpu) and not missing and not losses,all_requested_axes_measured=not missing,covered_timing_rows=len(cpu),covered_runtime_cpu_rows=len(runtime_cpu),covered_generation_wall_rows=len(generation_wall),expected_core_cpu_rows=expected_cpu_rows,all_covered_timing_medians_win=bool(cpu) and not losses,all_covered_timing_repeats_win=bool(cpu) and all(r['cpu'].get('all_repeat_win',False) for r in cpu),all_covered_runtime_cpu_medians_win=bool(runtime_cpu) and all(r['cpu']['median_comparison']=='win' for r in runtime_cpu),all_covered_generation_wall_medians_win=bool(generation_wall) and all(r['cpu']['median_comparison']=='win' for r in generation_wall),all_covered_requested_byte_rows_win=bool(alloc) and all(r['allocation']['requested_bytes']['comparison']=='win' for r in alloc),all_covered_allocation_call_rows_win=bool(alloc) and all(r['allocation']['allocation_calls']['comparison']=='win' for r in alloc),timing_median_losses_or_ties=len(losses),allocation_byte_losses_or_ties=sum(r['allocation']['requested_bytes']['comparison']!='win' for r in alloc),allocation_call_losses_or_ties=sum(r['allocation']['allocation_calls']['comparison']!='win' for r in alloc),allocation_comparisons=resources,remaining_allocation_losses_or_ties=[r for r in resources if r['comparison']!='win'],remaining_timing_losses=losses,missing_axes=missing,input_sha256=inputs,rows=rows,interpretation=['Every fixed source/profile/case/operation is a separate row; choosing the fastest profile per row cannot establish a universal codec win.','CPU, wall time, allocation requests, generated output bytes, cold consumer costs and retained memory are distinct metrics.','A tie, nonpositive slope, missing axis or measured loss prevents a universal all-benchmark claim.','Five paired process medians and all-repeat outcomes are diagnostics, not controlled-host qualification.'])
 (BASE/'all-win-gate.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(rows=len(rows),missing_axes=len(missing),all_benchmarks_won=report['all_benchmarks_won'])))
if __name__=='__main__':main()
