"""Supply the omitted cfg-only allocator without changing the frozen baseline core.

The first allocation build failure remains in baseline-rpc. This isolated
harness keeps every RPC Rust/proto byte, and rewrites only dependency paths to
that existing baseline so shipping dependencies stay cache-reusable.
"""
from pathlib import Path
import hashlib,json,shutil,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2];SOURCE=BASE/'baseline-source';OUT=BASE/'baseline-rpc-allocation-harness'
OUT.mkdir(exist_ok=False)
shutil.copytree(SOURCE/'rpc-bench',OUT/'rpc-bench');shutil.copytree(SOURCE/'proto',OUT/'proto')
p=OUT/'rpc-bench/Cargo.toml';old=p.read_text();new=old.replace('path = ".."','path = '+json.dumps(str(SOURCE))).replace('path = "../pbrs-grpc"','path = '+json.dumps(str(SOURCE/'pbrs-grpc'))).replace('path = "../protobuf-tonic"','path = '+json.dumps(str(SOURCE/'protobuf-tonic')));p.write_text(new)
rel='bench/devloop/compression/src/allocator.rs';data=subprocess.check_output(['git','show','0287879dcfe381424cf9aabc919d9fea700dbe39:'+rel],cwd=ROOT)
assert data==(BASE/'candidate-source'/rel).read_bytes()
target=OUT/rel;target.parent.mkdir(parents=True);target.write_bytes(data)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for p in (SOURCE/'rpc-bench').rglob('*'):
 if p.is_file() and p.name!='Cargo.toml':assert p.read_bytes()==(OUT/p.relative_to(SOURCE)).read_bytes()
record=dict(baseline='0287879dcfe381424cf9aabc919d9fea700dbe39',baseline_source=str(SOURCE),reason='Frozen export excluded cfg-only allocation support; shipping and all14coreprobes remain immutable.',production_core_unchanged=True,rpc_source_unchanged=True,only_manifest_change='Three relative pbrs dependency paths resolve to identical absolute frozen core paths',manifest_before=old,manifest_after=new,allocator_identical_to_final=True,allocator_sha256=sha(target),files={str(p.relative_to(OUT)):sha(p) for p in sorted(OUT.rglob('*')) if p.is_file()})
(BASE/'baseline-rpc-allocation-harness.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(dict(prepared=True,files=len(record['files']))))
