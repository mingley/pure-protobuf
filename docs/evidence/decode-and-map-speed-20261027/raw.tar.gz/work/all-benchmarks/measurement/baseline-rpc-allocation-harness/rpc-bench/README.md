# `rpc-bench`: gRPC benchmark harness and QPS worker

`rpc-bench` provides a gRPC benchmark worker and separate-process load tools
for measuring throughput, latency, CPU, and memory. For a quick smoke run from the repo
root, use `./scripts/grpc-qps-interop.sh --scenario=protobuf_unary_ping_pong_empty --warmup=1 --duration=2`.
Read `target/qps-logs/<timestamp>_<pid>/summary.json` first, then inspect the
raw result and process logs when a cell fails or looks noisy.

It implements parts of the
[benchmark contract](../docs/benchmark-contract.md):

- **Tracks offered load.** Open-loop Poisson and constant-paced arrivals track
  scheduling lag; saturated generators are flagged. `load` reports
  schedule-relative end-to-end latency. The WorkerService histogram still
  reports dispatch-relative service time for upstream compatibility. Native
  `QPS_ACCOUNTING` log records separately export schedule-relative latency and
  atomic offered/dispatched/completed/rejected/timed-out/unfinished counters.
- **Separates endpoint resources.** Runs in separate processes can attribute
  client/server CPU and resident set size (RSS). The `load` report also carries
  queue/scheduling delay; not every upstream driver exports every metric.
- **Keeps histogram fidelity.** HDR latency histograms match upstream
  `grpc/support/histogram.c` exponential buckets.
- **Uses the real schema.** The harness consumes and emits official
  `grpc.testing` protobuf structures over gRPC. It does not hide unsupported
  fields behind adapters.

## Load runs

For a source-pinned release build, run from a clean checkout:

```sh
python3 scripts/build-rpc-bench.py --source "$(git rev-parse HEAD)" --output work/rpc-build
python3 scripts/grpc-load-smoke.py --binary work/rpc-build/rpc-bench \
  --build-record work/rpc-build/build.json --allocation-counts \
  --context-switches --rpc-count=20 --duration=60 --output work/rpc-matrix
```

The builder retains Cargo output and tool versions, checks the source and
lockfiles before and after compilation, and copies the executable out of the
build cache. The matrix checks that record before and after execution. A
prebuilt binary without a matching record remains `source_verified=false`.

On 64-bit Linux, `--context-switches` records voluntary and involuntary
switches with `getrusage(RUSAGE_SELF)` for each endpoint. Counts include all
threads, including exited threads, over the process lifetime. They include setup
and teardown work before the snapshot. Missing or unsupported counters fail
the capture. These OS events do not measure Tokio task wakeups or syscalls.
Scheduling affects the counts; a single N/2N pair supplies no noise estimate.

`--strace=/usr/bin/strace` records syscall counts for each endpoint through
exit, including worker threads that have exited. Error returns are included
in the call count. The runner checks each summary against its per-syscall
rows and rejects missing or inconsistent totals. Run strace and Callgrind
separately. Ptrace changes timing and scheduling, and the tracer's CPU is
outside the endpoint CPU window; these captures do not measure native latency.

A newer driver can use an existing frozen build with
`--source-checkout=/path/to/clean/benchmark-checkout` and its `--build-record`.
The checkout must still match the build's commit, tree, and lockfiles. Reports
record the benchmark source separately from the driver's commit, dirty state,
script hash, and saved script. Both the executable and driver are checked for
changes during the run.

`load-server` and `load` run separate endpoints. Both native and tonic support
pbrs and prost messages, all four RPC shapes, pipelined bidi, and identity or
gzip compression. The benchmark sets gzip level 6 to match tonic. TLS endpoints
use TLS 1.3 with AES-128-GCM and verify the CA and server name. Use the same codec to
compare transport costs, and tonic/prost to compare complete implementations.

`load` saves its metrics before returning exit code 1 for failed, timed-out,
rejected, unfinished, or empty runs. Exit code 2 means invalid CLI options.
Reports include offered, dispatched, completed, successful, failed,
unstarted, and unfinished counts. Timeouts are a subset of failures;
unfinished calls are included in failures but have not completed. Queue
rejections are included in unstarted calls. Invalid timing values fail
parsing instead of panicking.

The Linux matrix covers all native/tonic and pbrs/prost endpoint pairs,
five call shapes, four payload sizes, plaintext/TLS, and identity/gzip.
Use `--load-levels=1:1,1:16` to check both single-call and multiplexed loads.

The output contains endpoint logs, terminal accounting, CPU counters, sampled
RSS, commands, order seed, and a binary digest. It tests workload completion;
it leaves performance qualification false. CPU windows include connection
setup, and the client counter includes process startup. Per-side steady-state
instructions and allocations, higher concurrency, dedicated-host timing,
and the production soak remain separate checks.

## What is ready, and what is still missing

The [SB-10 records](../docs/evidence/qps-sb10.md) show official async scenarios
running against native, Go, and C++ workers. These are compatibility and local
performance diagnostics. The native worker rejects synchronous and generic
byte-buffer modes explicitly.

[SB-21](../docs/evidence/sb21-claims-scenarios.md) adds longer open-loop
scenario definitions, native worker accounting, and seeded per-repeat scenario
and peer order (`--repeats=5 --order-seed=210021`). `--claim-check` requires
independent accounting and schedule-relative histograms over the actual mark
window; reference clients without equivalent exports fail this check. A
qualified campaign still needs matched peer settings, controlled hosts, and
the full benchmark contract. QPS-only C++ driver output by itself cannot
establish a latency or CPU claim. See the
[scoreboard](../docs/scoreboard.md) before using a result as a ranking.

## 1. Pinned Upstream Specifications and Peers

All official scenarios, driver control protocols, and reference peers are pinned
to reviewed upstream releases:

| Component | Upstream Repository / Artifact | Pinned Commit / Version | Description |
|---|---|---|---|
| **Official C++ Peer & Driver** | [`grpc/grpc`](https://github.com/grpc/grpc) | [`d1487957db6658bc532b72871775148229836627`](https://github.com/grpc/grpc/tree/d1487957db6658bc532b72871775148229836627) (v1.84.0) | Official `qps_json_driver` and `qps_worker` |
| **Official Go Reference Peer** | [`google.golang.org/grpc`](https://github.com/grpc/grpc-go) | [`dd51b1c90aaf9b7ee0b07b1d14fa8e3a89132bef`](https://github.com/grpc/grpc-go/tree/dd51b1c90aaf9b7ee0b07b1d14fa8e3a89132bef) (v1.85.0-dev) | Official Go benchmark worker (`google.golang.org/grpc/benchmark/worker`) |
| **Native Rust Worker** | `pbrs-rpc-bench` | in-tree (`pure-protobuf`) | Native `WorkerService` and `BenchmarkService` |
| **Official Scenario Definitions** | [`rpc-bench/scenarios/official.json`](scenarios/official.json) | official gRPC `Scenario` schema | Pinned official QPS benchmark scenarios |

---

## 2. Official QPS Benchmark Scenarios (`scenarios/official.json`)

QPS means queries per second. The scenarios file
[`rpc-bench/scenarios/official.json`](scenarios/official.json) defines official
gRPC QPS scenarios conforming to `grpc.testing.Scenario` and
`grpc.testing.Scenarios` from `grpc/testing/control.proto`:

| Scenario Identifier | RPC Type | Payload | Concurrency | Load Model | Description |
|---|---|---|---|---|---|
| `protobuf_unary_ping_pong_empty` | `UNARY` | 0 B req / 0 B resp | 1 channel / 1 RPC | Closed-loop | Baseline unary framing and scheduling overhead |
| `protobuf_unary_ping_pong_1kb` | `UNARY` | 1 KiB req / 1 KiB resp | 1 channel / 1 RPC | Closed-loop | Typical microservice payload round-trip |
| `protobuf_unary_ping_pong_64kb` | `UNARY` | 64 KiB req / 64 KiB resp | 1 channel / 1 RPC | Closed-loop | Medium payload buffer chunking and transport flow |
| `protobuf_streaming_ping_pong_empty` | `STREAMING` | 0 B req / 0 B resp | 1 channel / 1 stream | Closed-loop | Bidi streaming lockstep ping-pong |
| `protobuf_streaming_ping_pong_1kb` | `STREAMING` | 1 KiB req / 1 KiB resp | 1 channel / 1 stream | Closed-loop | Bidi streaming 1 KiB payload message stream |
| `protobuf_unary_qps_unconstrained_100rpcs` | `UNARY` | 1 KiB req / 1 KiB resp | 1 channel / 100 RPCs | Closed-loop | Saturated channel multiplexing and pipeline concurrency |
| `protobuf_unary_poisson_5000qps` | `UNARY` | 1 KiB req / 1 KiB resp | 1 channel / 64 RPCs | Poisson (5,000 QPS) | Open-loop offered load verifying steady-state tail latency |
| `cpp_protobuf_async_unary_ping_pong_insecure` | `UNARY` | 0 B req / 0 B resp | 1 channel / 1 RPC | Closed-loop | Upstream C++ alias for unary ping-pong |
| `cpp_protobuf_async_streaming_ping_pong_insecure` | `STREAMING` | 0 B req / 0 B resp | 1 channel / 1 stream | Closed-loop | Upstream C++ alias for streaming ping-pong |
| `go_protobuf_sync_unary_ping_pong_insecure` | `UNARY` | 0 B req / 0 B resp | 1 channel / 1 RPC | Closed-loop | Upstream Go alias for synchronous unary ping-pong |
| `go_protobuf_sync_streaming_ping_pong_insecure` | `STREAMING` | 0 B req / 0 B resp | 1 channel / 1 stream | Closed-loop | Upstream Go alias for synchronous streaming ping-pong |

---

## 3. Local Reproducible Invocation

The runner script [`scripts/grpc-qps-interop.sh`](../scripts/grpc-qps-interop.sh)
starts workers, drives scenarios, and writes logs with process isolation and
error recovery.
It defaults to the shared repository `target/` cache with at most two Cargo
build jobs. Every non-`--skip-build` invocation runs Cargo's incremental
`--locked --release` build, even when a worker binary already exists, so a
stale executable is not labeled as current source. Override `CARGO_TARGET_DIR`
to use another existing cache; `CARGO_BUILD_JOBS=1` is respected and larger
values are capped at two. `--skip-build` is for diagnostic runs with an
existing binary: its summary records `native.source_sha: null` and
`native.source_verified: false` rather than attributing the prebuilt binary
to the checkout.

### Quick Start: Dry Run

Inspect the planned execution matrix, scenario configurations, and pinned
dependencies without spawning processes:
```bash
./scripts/grpc-qps-interop.sh --dry-run
```

### Fast Smoke Test

Run one official scenario with short warmup and benchmark durations:
```bash
./scripts/grpc-qps-interop.sh --scenario=protobuf_unary_ping_pong_empty --warmup=1 --duration=2
```

### Mixed-Peer Direction Execution

Run specific peer directions to evaluate client and server efficiency:

```bash
# 1. Native pair (Native Client -> Native Server):
./scripts/grpc-qps-interop.sh --mode=native_pair --scenario=protobuf_unary_ping_pong_empty

# 2. Native client against Reference Go server:
./scripts/grpc-qps-interop.sh --mode=native_client_to_ref_server --scenario=protobuf_unary_ping_pong_empty

# 3. Reference Go client against Native server:
./scripts/grpc-qps-interop.sh --mode=ref_client_to_native_server --scenario=protobuf_unary_ping_pong_empty
```

### Full Matrix Execution

Run the checked-in scenario suite across all three primary directions:
```bash
./scripts/grpc-qps-interop.sh
```

This includes the two synchronous Go aliases, which the native async worker
does not support. Their explicit failures make the full request incomplete;
select the supported async scenarios for a passing smoke check. Do not count
an unsupported scenario as a peer performance loss.

### Driving with Upstream C++ `qps_json_driver`
After `scripts/grpc-interop-cpp.sh` fetches and builds the pinned C++ interop
peer, build the upstream QPS target from that same checked-out commit:

```bash
cmake --build target/interop-cpp-build --parallel 4 --target qps_json_driver
./scripts/grpc-qps-interop.sh --driver=target/interop-cpp-build/qps_json_driver \
  --mode=all --ref-peer=go --scenario=protobuf_unary_ping_pong_empty --warmup=1 --duration=2
```

The upstream C++ driver accepts only its own `--scenarios_file` and
`--json_file_out` flags. The script writes a single-scenario copy with the
requested timing overrides, and fails if a selected scenario or peer fails.
That C++ version's `--json_file_out` contains **QPS only**, not a complete
`ScenarioResult`; its full reporter output is retained in `*-driver.log`.
The integrated Go driver instead emits the complete wire-compatible
`ScenarioResult` below and rejects unknown scenario options. Neither short
local smoke run establishes the paired, dedicated-host performance gate.

---

## 4. Architecture and Control Flow

```
                     +---------------------------------------+
                     |        Official QPS Driver            |
                     | (qps_json_driver / integrated driver) |
                     +---------------------------------------+
                           /                           \
         RunServer(ServerArgs)                       RunClient(ClientArgs)
         ServerStatus                                ClientStatus
         Mark(reset=true/false)                      Mark(reset=true/false)
                         /                               \
                        v                                 v
         +-----------------------------+   gRPC traffic   +-----------------------------+
         |     Server Worker           | <==============> |     Client Worker           |
         | (rpc-bench worker / go/cpp) |                  | (rpc-bench worker / go/cpp) |
         |   spawns BenchmarkService   |                  |    spawns LoadGenerator     |
         +-----------------------------+                  +-----------------------------+
```

### Key Components

- **`src/worker_server.rs`**: Implements `WorkerService.RunServer` and `CoreCount`. Handles `ServerConfig` setup on ephemeral ports, spawns an isolated benchmark server with graceful shutdown triggers, captures resource snapshots via `resources.rs`, and reports CPU/elapsed deltas on `Mark` signals.
- **`src/worker_client.rs`**: Implements `WorkerService.RunClient`. Connects to target servers, configures `LoadGenerator` under closed-loop or Poisson distributions, tracks latencies in exponential `Histogram` buckets, records status code distributions, and responds with `ClientStatus` on `Mark` requests.
- **`src/benchmark_service.rs`**: Implements `grpc.testing.BenchmarkService` procedures (`UnaryCall`, `StreamingCall`, `StreamingFromClient`, `StreamingFromServer`, `StreamingBothWays`).
- **`src/load.rs`**: High-performance load engine supporting bounded in-flight queuing, open-loop Poisson arrival intervals, and scheduling lag measurements.
- **`src/resources.rs`**: Cross-platform process resource inspection using `getrusage` and Mach on macOS, and `getrusage` plus `/proc` on Linux to record user/system CPU seconds and resident RSS (not virtual address-space `VmPeak`).

The native WorkerService enforces a local cap of 64 client channels, 256
configured in-flight RPCs, and 65,536 histogram buckets before it dials or
allocates work. Local Poisson admission rejections appear as
`RESOURCE_EXHAUSTED` result counts, not synthetic latency samples. Its
long-lived control stream uses bounded histogram/status counters rather than
retaining every raw load-generator sample. These policies preserve the
checked scenarios (at most one channel and 100 outstanding RPCs); see the
[worker contract](../docs/benchmark-contract.md) for limits and qualification
boundaries.

The QPS runner uses an explicitly labeled **overlaid pinned grpc-go benchmark
client** for Poisson reference-client cells. It offers one aggregate arrival
schedule at the scenario rate, with the native seed and configured slot cap,
and exports the same completion-mark counter and scheduled-send latency oracle.
Each streaming arrival opens a stream and exchanges one request/reply, matching
the native worker. Go reference servers and closed-loop clients use the original
pinned worker. The runner records source/overlay/binary hashes, passes the actual
prepared warmup/measurement durations to the driver and rejects mismatched
effective metadata. See [SB-21 evidence](../docs/evidence/sb21-claims-scenarios.md)
for historical failures and qualification limits.

### Async thread controls

`async_server_threads` / `async_client_threads` are honored as explicit
Tokio worker counts, not just accepted:

- `0` (or absent) runs the benchmark server / load generator inline on
  the shared worker runtime.
- A positive count up to 1024 spawns a dedicated multi-thread runtime
  with exactly that many workers (`qps-bench-server` /
  `qps-bench-client` threads); channel connects and the serve loop run
  there so I/O registers with the polling runtime. The control-plane
  stream stays on the shared runtime.
- Negative counts fail `INVALID_ARGUMENT`; counts above 1024 fail
  `RESOURCE_EXHAUSTED` — both before bind/dial.

The effective mapping is echoed to the worker log retained with every
run (`RunServer port=…: async_server_threads=2 -> dedicated 2-worker
Tokio runtime`). `SYNC_CLIENT` / `SYNC_SERVER` stay explicitly
unsupported, as do security params, core pinning, `threads_per_cq`,
channel args and the other controls the worker cannot faithfully
implement; they fail before bind/dial, never silently ignored.

---

## 5. RT-07 Mixed-Load Diagnostic

From the repository root, run the single supported native/native fairness
cell (the short smoke override changes duration, warmup and unary offered QPS):

```bash
CARGO_BUILD_JOBS=1 CARGO_TARGET_DIR="$PWD/target" \
  cargo run --manifest-path rpc-bench/Cargo.toml -- fairness \
  --scenario rpc-bench/scenarios/fairness.json --smoke \
  --output target/rt07-smoke.json
```

Omit `--smoke` to use the scenario's 15-second warmup and 60-second
measurement. `--require-qualified` writes the report and then exits nonzero
while any qualification field or peer comparison is unavailable; **neither
mode qualifies RT-07 today**. This command runs a separate native server
process with the configured connection, RPC and byte limits, and two client
classes on separate connections: repeating finite 64 × 64 KiB streams and
scheduled Poisson 128-byte unary probes. The report retains per-class raw
latency/scheduling samples, canonical status and queue-overflow counts, actual
client pool waits, client/server CPU and RSS, real sampled byte-budget
allocations, post-drain accounting and observed call overlap. A failed
resource capture or incomplete accounting fails the run, not a zero-filled
report. The configured request sizes are protobuf payload-body bytes; each
bulk request also carries 64 response-parameter entries. Peak RSS is a
process-lifetime high-water mark, including warmup.

`qualification.qualified` is always `false` for this diagnostic. The
`unsupported_metrics` map explains every required `null`: client pool wait
is not the entire outbound-to-TCP or server queue, the transport has no
public active-permit or exact byte-budget peak gauge (the sampled peaks are
**lower bounds**), and bulk calls use fixed concurrent workers rather than
scheduled arrivals. A successful post-drain probe is not a permit count.
Unstarted `QUEUE_OVERFLOW` lacks a valid latency sample, so the small-class
p99 is `null` if any overflow occurs; early non-timeout transport failures
also force per-class p99 to `null` rather than flattering a latency tail.
The other five `fairness.json` cells,
reference peers, dedicated hosts and randomized paired runs remain open.

---

## 6. Artifacts and Local Proof

The QPS runner saves each run in `target/qps-logs/<timestamp>_<pid>/`:

1. **`summary.json`**: Tabular benchmark execution results containing scenario name,
   peer direction, status and the metrics the selected driver actually exports.
   It records the driver's binary path, SHA-256, kind and pinned source revision,
   plus the native worker binary digest, source SHA and dirty-worktree marker.
   Mixed-peer runs also record the reference worker binary digest and pinned
   source; a cached Go worker with the wrong embedded grpc-go module is refused.
   Upstream C++ exports QPS only; its p50/p99 and CPU table cells are `N/A`,
   never inferred from QPS.
2. **`*-result.json`** (integrated Go driver only): Complete raw `grpc.testing.ScenarioResult` protobuf messages serialized to JSON via standard `protojson`. Contains:
   - Full HDR `latencies` histogram data (`bucket`, `min_seen`, `max_seen`, `sum`, `sum_of_squares`, `count`).
   - Server and client `ServerStats` and `ClientStats`.
   - `ScenarioResultSummary` (`qps`, `qps_per_server_core`, `latency_50`..`latency_999`, `server_user_time`, `client_user_time`, etc.).
   - Per-worker exit status and error code distributions (`request_results`).
   The upstream C++ driver's corresponding `*-driver-metrics.json` contains
   only `qps`; it must not be treated as a substitute for these raw metrics.
3. **`*-server.log` & `*-client.log`**: Standard output and error logs from each worker process.
4. **`*-driver.log`**: Driver control stream logs and step-by-step mark transitions.
5. **`execution-plan.json`**: Seed, repeat count and independently shuffled
   scenario/peer order for every repeat. Repeated runs use `repeat-N/` directories
   so their raw artifacts cannot overwrite each other.
6. **`*-accounting.json`**: Independent accounting proof for a native client,
   including service and scheduled-send histograms. Counters obey
   `offered = dispatched + rejected`,
   `incoming_in_flight + dispatched = completed + unfinished`, and
   `completed = successful + failed`; timeouts are a subset of failures.
   Marks retain carry-in across resets and have zero drain. Missing independent
   evidence is explicit for diagnostic reference runs and fails `--claim-check`.
   The proof always leaves `claim_eligible` false: accounting alone does not
   establish a benchmark-contract performance claim.

The worker and driver can run over loopback. Local adapter checks need no
cloud deployment, BigQuery credentials, or external uploads.

## Matched native and tonic load runs

`load` and `load-server` accept `--transport=native|tonic` and
`--codec=pbrs|prost`. Native prost uses the public generated stubs and codec,
with the same prost messages used by tonic. The five shapes are `unary`,
`server_stream`, `client_stream`, `bidi` (lockstep), and `bidi_pipelined`.
Both bidi shapes send the requested upload body. Load TLS uses TLS 1.3,
AES-128-GCM and h2 on both transports, with CA and server-name verification.

`--rpc-count=N` requires exactly N successful RPCs before the duration limit.
A partial run saves its metrics and exits with failure. Fixed counts let
instruction and allocation measurements subtract setup using N and 2N runs.

Build with `--features allocation-counts` to print allocation operations and
requested bytes since entry into `main`. Reallocation counts as an allocation
of the requested new size. These totals include setup and instrumentation;
they do not measure retained memory. On Unix, `SIGUSR1` prints a server
snapshot. The allocator is shared with the decoder benchmark and its Miri test.

The separate-process runner supports repeats, connection/concurrency levels,
allocator snapshots, and optional Callgrind on both endpoints:

```sh
cargo build --locked --release --manifest-path rpc-bench/Cargo.toml --features allocation-counts
python3 scripts/grpc-load-smoke.py --binary target/release/rpc-bench \
  --output target/load-matrix/run-001 --duration .25 \
  --load-levels 1:1,1:16 --repeats 3 --allocation-counts
```

Use `--rpc-count=64 --duration=60 --callgrind=/path/to/valgrind` for an
instruction capture, then repeat with twice the RPC count in a new output
directory. Callgrind CPU/RSS includes instrumentation and must not be compared
with native CPU/RSS. Retain every capture and compare each side against the
same peer. The runner reports diagnostic results; saturation, cold/idle
lifecycles, read-all corpora, wakeups, syscalls, and dedicated-host statistics
still need separate coverage.

`dominance-ledger.py` compares matched N/2N capture directories against the same
peer for each side. It retains losses with task IDs and marks missing or
nonpositive differentials unmeasured. Its default exit status is failure while
full coverage remains incomplete; `--allow-partial` explicitly selects a diagnostic.

```sh
python3 scripts/dominance-ledger.py --small target/load-N --large target/load-2N \
  --output target/dominance-diagnostic.json --allow-partial
```

Bidi clients send their first request before waiting for response headers.
This supports servers that read a request before returning a response stream.
A zero-message bidi call closes its request stream before waiting for headers.
