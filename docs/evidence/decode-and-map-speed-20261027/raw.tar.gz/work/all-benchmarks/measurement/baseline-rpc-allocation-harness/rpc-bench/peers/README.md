# RPC-Bench Peer Configuration and Launcher Registry

This directory defines the peers that `rpc-bench` can launch or compare. It is
for contributors adding a runtime, codec, or cross-language benchmark peer.
Every peer role must be explicit, pinned, and recorded so a partial
or mismatched matrix cannot look like a win.

## Registered Peers

| Peer ID | Implementation | Language | Runtime | Default Codec | Upstream Pin |
|---|---|---|---|---|---|
| `native` | `pbrs-grpc` | Rust | tokio + pbrs-grpc | `pbrs` | in-tree (pure-protobuf) |
| `tonic` | `tonic` | Rust | tokio + hyper + h2 | legacy mixed role; see explicit variants below | tonic 0.14; use each manifest/lockfile for the codec pin |
| `go` | `grpc-go` | Go | go runtime + net/http2 | `google.golang.org/protobuf` | commit `dd51b1c90aaf9b7ee0b07b1d14fa8e3a89132bef` (v1.85.0-dev) |
| `cpp` | `grpc-core` | C++ | grpc-core C++ event engine | `google::protobuf` (upb/C++) | commit `d1487957db6658bc532b72871775148229836627` (v1.84.0) |

## Optional Peers (SB-18)

The seven optional peer manifests are present, but their runnable interop
server harnesses are still missing in the 2026-09-29 audit. They currently
report `not_run`; registration is not evidence that a peer has been measured.

Optional peers are pinned and have launch specifications like required peers, but a peer
that cannot run reports `not_run` with a reason and never blocks the
required peers. All are server-only: no open-loop client driver exists
for their transports, so server cells use the native generator. Each
manifest's `transport_contract` repeats the SB-01 settings (16 MiB
windows, 1 MiB frames, 256 streams, no adaptive window, TCP_NODELAY)
its harness must implement; every cell records them in its `fairness`
block (see `bench/stack-matrix/peers/fairness.py`).

Read that block before comparing results. Existing required peers also have
reported gaps in matched settings or TLS-suite evidence; the presence of a
manifest does not prove its requested settings were observed on the wire.

| Peer ID | Implementation | Language | Runtime | Upstream Pin |
|---|---|---|---|---|
| `grpc-java` | `grpc-java` | Java | JVM + Netty | `io.grpc:grpc-netty` 1.84.0 |
| `grpc-dotnet` | `grpc-dotnet` | C# | .NET 9 + Kestrel | `Grpc.AspNetCore` 2.84.0, `net9.0` |
| `volo-grpc` | `volo-grpc` | Rust | tokio + volo-grpc | `volo-grpc` 0.12.2 |
| `connect-rust` | `connectrpc` | Rust | tokio + hyper | `connectrpc` 0.9.1 |
| `google-grpc` | `grpc` | Rust | tokio + hyper (preview) | `grpc` 0.9.0 (server `pub(crate)`: upstream-incapable) |
| `vertx` | `vertx-grpc` | Java | JVM + vert.x + Netty | `vertx-grpc-server` 4.4.4 + grpc 1.58.0 (grpc_bench@`48b6b95`) |
| `quarkus` | `quarkus-grpc` | Java | JVM + Quarkus | `quarkus-grpc` 3.1.2.Final (grpc_bench@`48b6b95`) |

## Matching Configuration (Apples-to-Apples)

Comparable cells must use the same network and payload parameters. This table
states the target contract, not a claim that every launcher already enforces it:

| Setting | Required value |
|---|---|
| TCP behavior | `TCP_NODELAY` enabled on client and server sockets |
| TLS cipher | `TLS_AES_128_GCM_SHA256` (TLS 1.3) when encryption is active |
| Standard unary/stream concurrency | 1 connection and 1 concurrent RPC |
| Concurrency scenarios | 4 connections and 16 streams |
| `empty_unary` payload | 0 request bytes, 0 response bytes |
| `large_unary` payload | 271,828 request bytes, 314,159 response bytes |
| `stream` payload | 1,024 byte payload messages |
| `ping_pong` payload | 0 byte payload messages in lockstep (256 pairs) |
| `upload` payload | 1,024 byte payload messages |

## Execution Matrix Roles

To isolate client vs. server performance:

| Question | How to run the matrix |
|---|---|
| Server efficiency | Hold the client fixed, for example `--client-peer=native`, and vary `--server-peer=native,tonic-pbrs,tonic-prost,go,cpp`. |
| Client efficiency | Hold the server fixed, for example `--server-peer=native`, and vary `--client-peer=native,tonic-pbrs,go,cpp`. |

## Tonic Codec Roles

The `tonic` transport ships in two codec variants so same-codec transport
deltas and end-to-end reference deltas are never conflated:

| Role | Transport | Codec | Load generator | Use |
|---|---|---|---|---|
| `tonic-pbrs` | tonic 0.14 (`rpc-bench --transport=tonic`) | pbrs | rpc-bench | Same-codec transport comparison vs `native` (client and server) |
| `tonic-prost` | tonic 0.14 (`tonic-interop`) | prost 0.14 | none | End-to-end reference, **server only** |
| `tonic` | legacy alias (deprecated for codec claims) | server prost, client pbrs | rpc-bench | Missing prost server fails; never substitutes another codec |

Rules enforced by `scripts/rpc-bench-matrix.py`:
- Requesting server `tonic-prost` without a built `tonic-interop` binary fails
  the cell (incomplete matrix) instead of silently substituting the pbrs codec.
- Requesting client `tonic-prost` fails the cell explicitly: no prost load
  generator exists. `--client-peer=all` excludes this known-invalid role,
  whereas explicitly requesting it still produces an incomplete matrix.
- Every run records `client_codec`, `server_codec`, `client_workload`
  (`rpc-bench` vs `interop-soak`), and both binary paths, so a soak-driven
  go/cpp client cell is never compared as equivalent to an rpc-bench cell.
- Go/C++ client cells require every requested soak iteration, zero failures and
  a distinct raw latency sample per iteration. Each client process has its own
  CPU accounting and retained stdout/stderr under `target/rpc-bench-logs/`;
  the report links those logs and records the integer-millisecond latency
  resolution. No missing histogram is replaced with an estimated p99.
- `matrix_complete` means requested cells executed, **not** that performance
  leadership or a server ceiling was proved. Quick runs, unmatched interop
  soak workloads, saturated generators, missing resource measurements, or
  scenarios shorter than 60 measured seconds receive an explicit
  `server_ceiling_reason` and are diagnostic only.
- A missing peer (or unsupported role) marks the report `matrix_complete: false`
  with explicit `failed_pairs`/`skipped_pairs`, prints an `[INCOMPLETE MATRIX]`
  banner, and exits 1: a partial table is never a comparison win.

## TLS (SB-11 stack-matrix cells)

Each manifest's `tls` section records whether the peer can serve a TLS
cell and what verifies it. Native serves `--tls-cert/--tls-key` (in-tree
test PKI); go/cpp serve their upstream test credentials (`-use_tls` /
`--use_tls=true`) verified by the native generator with the matching
test CA and `foo.test.google.fr` override. Tonic is explicitly
unsupported (tonic 0.14 TLS pulls a C crypto provider, vs QG-04), and
soak clients stay plaintext-only; both are recorded with reasons, never
silently plaintext. See `docs/evidence/stack-matrix-sb11.md`.

Optional peers (SB-18) serve the in-tree PEM test PKI once their
harnesses exist, verified by the native generator exactly like the
native peer; `google-grpc` has no TLS path while its server is
upstream-incapable. See each manifest's `tls` section and
`bench/stack-matrix/peers/__init__.py::tls_spec`.
