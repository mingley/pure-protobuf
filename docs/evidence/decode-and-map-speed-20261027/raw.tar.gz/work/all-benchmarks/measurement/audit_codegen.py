"""Verify each corrected campaign's frozen compiler-driver and tool bindings."""
from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent;CG=BASE.parent/'codegen'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
initial=json.loads((CG/'builds.json').read_text())
report=dict(schema='pbrs.codegen-artifact-audit.v1',complete=False,campaigns={})
for phase in ('phase1','phase2'):
 for profile in ('debug','release'):
  campaign='codegen-corrected-'+phase+'-'+profile;m=json.loads((BASE/campaign/'manifest.json').read_text());assert m['state']=='complete'
  binaries={}
  for side,path in m['binaries'].items():
   binary=Path(path);assert sha(binary)==m['binary_sha256'][side]
   if profile=='debug' and ((phase=='phase1' and side=='baseline') or side=='prost'):
    record=next(r for r in initial['records'] if r['side']==('baseline' if side=='baseline' else 'prost') and r['probe']=='canonical');assert record['binary_sha256']==sha(binary);artifact=record['cargo_artifact'];manifest=Path(record['command'][record['command'].index('--manifest-path')+1]);assert sha(manifest.with_name('Cargo.lock'))==record['lock_sha256'];assert sha(manifest.parent/'src/main.rs')==record['source_sha256'];record_path='codegen/builds.json'
   else:
    record=json.loads((binary.parent/'source.json').read_text());artifact=record['cargo_artifact'];assert record['executable_sha256']==sha(binary);assert sha(binary.parent/'Cargo.toml')==record['manifest_sha256'];assert sha(binary.parent/'Cargo.lock')==record['lock_sha256'];assert sha(binary.parent/'src/main.rs')==record['driver_source_sha256'];assert all(s['exit_code']==0 for s in record['steps']);record_path=str((binary.parent/'source.json').relative_to(BASE.parent))
    source_label='baseline' if phase=='phase1' and side=='baseline' else 'phase2' if phase=='phase2' and side=='candidate' else 'candidate'
    if side!='prost':assert record['source_sha256']==json.loads((BASE/(source_label+'-source-source.json')).read_text())['files']
   assert artifact['profile']['opt_level']==('0' if profile=='debug' else '3');assert artifact['profile']['debuginfo']==0;assert not artifact['profile']['test'];assert artifact['features']==[]
   binaries[side]=dict(sha256=sha(binary),record=record_path,cargo_profile=artifact['profile'],features=artifact['features'])
  assert sha(BASE/'canonical_codegen_blocking.py')==m['helper_sha256'];assert sha(BASE/'codegen_compare_blocking.py')==m['controller_sha256'];assert sha(Path(m['time_executable']))==m['time_executable_sha256']
  report['campaigns'][campaign]=dict(binaries=binaries,successful_processes=m['successful_processes'],timer_scope='Blocking completion wait; sampler teardown excluded')
report['complete']=True;(BASE/'codegen-artifact-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,campaigns=len(report['campaigns']))))
