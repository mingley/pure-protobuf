"""Reconstruct a measured source: python3 reconstruct_variant.py REPO OUTPUT baseline|candidate|phase2|phase3|phase4|phase5|phase6.

Use the checked-in Git history and source-overlays beside this script. This
recreates the recorded source files, not build caches or measured executables.
Probe/helper packages and their lockfiles are separate evidence members.
"""
import hashlib,io,json,posixpath,shutil,subprocess,sys,tarfile
from pathlib import Path

base=Path(__file__).resolve().parent/'source-overlays'
repo,out,variant=Path(sys.argv[1]),Path(sys.argv[2]),sys.argv[3]
manifest=json.loads((base/'manifest.json').read_text());selected=manifest['variants'][variant]
out.mkdir(parents=True,exist_ok=False)
baseline=manifest['baseline']
archive=subprocess.check_output(['git','archive',baseline['commit'],*baseline['files']],cwd=repo)
def flattened_link(path,depth=0):
    if depth>20:raise ValueError('Git symlink cycle')
    path=posixpath.normpath(path)
    if path.startswith('../') or path.startswith('/'):raise ValueError('Git symlink outside repository')
    entry=subprocess.check_output(['git','ls-tree',baseline['commit'],'--',path],cwd=repo).decode()
    data=subprocess.check_output(['git','show',baseline['commit']+':'+path],cwd=repo)
    if entry.startswith('120000 '):return flattened_link(posixpath.join(posixpath.dirname(path),data.decode()),depth+1)
    if not entry.startswith('100'):raise ValueError('Git link target is not regular file')
    return data
with tarfile.open(fileobj=io.BytesIO(archive),mode='r:') as tar:
    for member in tar.getmembers():
        path=Path(member.name)
        if path.is_absolute() or '..' in path.parts or not(member.isdir() or member.isfile() or member.issym()):raise ValueError(member.name)
        if member.isfile() or member.issym():
            target=out/path;target.parent.mkdir(parents=True,exist_ok=True)
            target.write_bytes(flattened_link(member.name) if member.issym() else tar.extractfile(member).read())
            target.chmod(member.mode)
for path in selected['removed']:(out/path).unlink()
for path in selected['changed']:
    target=out/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(base/variant/path,target)
actual={str(p.relative_to(out)):hashlib.sha256(p.read_bytes()).hexdigest() for p in out.rglob('*') if p.is_file()}
if actual!=selected['files']:raise ValueError('Reconstructed file set or hash differs')
print(json.dumps(dict(variant=variant,files=len(actual),verified=True)))
