"""Run one bounded phase only after root grants global CPU quiet."""
from pathlib import Path
import argparse,json,os,subprocess
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('phase',choices=['codec','partial','encode','map-small','map-large']);p.add_argument('--storage',choices=['lazy','owned'],default='lazy');p.add_argument('--candidate',default='candidate');a=p.parse_args()
if a.phase.startswith('map-'):
 group='map';driver=BASE/'map_compare.py';before=BASE/'baseline-map';after=BASE/(a.candidate+'-map');profile='lazy';suffix=a.phase
else:
 group=a.phase;driver=BASE/({'codec':'codec_compare.py','partial':'partial_compare.py','encode':'encode_compare.py'}[group]);middle='' if group=='codec' else group+'-';before=BASE/('baseline-'+middle+a.storage);after=BASE/(a.candidate+'-'+middle+a.storage);profile=a.storage;suffix=group+'-'+a.storage
cmd=['python3',str(driver),'--before-shipping',str(before/'codec-shipping'),'--before-allocations',str(before/'codec-allocations'),'--before-record',str(before/'source.json'),'--after-shipping',str(after/'codec-shipping'),'--after-allocations',str(after/'codec-allocations'),'--after-record',str(after/'source.json'),'--storage',profile,'--output',str(BASE/(a.candidate+'-'+suffix+'-comparison'))]
env=dict(os.environ)
if group=='map':env['MAP_GROUP']=a.phase.removeprefix('map-')
print(json.dumps(dict(command=cmd,phase=a.phase,storage=profile,MAP_GROUP=env.get('MAP_GROUP'))),flush=True)
raise SystemExit(subprocess.run(cmd,env=env).returncode)
