"""Export a small immutable benchmark source tree from one exact commit."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import tarfile

ROOT=Path(__file__).resolve().parents[3]
PATHS=['Cargo.toml','Cargo.lock','build.rs','src','proto','vendor','protobuf-tonic','pbrs-grpc','rpc-bench','examples','tests/proof/codec_benchmark','clippy.toml','rustfmt.toml','bench/devloop/compression/src/allocator.rs']
def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--commit',required=True)
 p.add_argument('--output',required=True,type=Path)
 p.add_argument('--patch',type=Path)
 args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 archive=subprocess.Popen(['git','archive','--format=tar',args.commit,*PATHS],cwd=ROOT,stdout=subprocess.PIPE)
 with tarfile.open(fileobj=archive.stdout,mode='r|') as stream:stream.extractall(out,filter='data')
 if archive.wait()!=0:raise ValueError('git archive failed')
 if args.patch:
  subprocess.run(['git','apply','--directory',str(out),str(args.patch.resolve())],cwd=ROOT,check=True)
 files={str(path.relative_to(out)):hashlib.sha256(path.read_bytes()).hexdigest() for path in sorted(out.rglob('*')) if path.is_file()}
 (out.parent/(out.name+'-source.json')).write_text(json.dumps(dict(commit=args.commit,patch_sha256=hashlib.sha256(args.patch.read_bytes()).hexdigest() if args.patch else None,files=files),indent=2)+'\n')
 print(json.dumps(dict(path=str(out),files=len(files),bytes=sum(path.stat().st_size for path in out.rglob('*') if path.is_file()))))
if __name__=='__main__':main()
