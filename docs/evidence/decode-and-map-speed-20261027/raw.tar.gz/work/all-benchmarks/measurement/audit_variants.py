"""Audit measured/rejected variant artifacts without changing historical records."""
from pathlib import Path
import hashlib,json
BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
report=dict(schema='pbrs.variant-artifact-audit.v1',complete=False,sources={},binaries={})
for label in ('phase2','phase3','phase4','phase5','phase6'):
 source=json.loads((BASE/(label+'-source-source.json')).read_text());root=BASE/(label+'-source')
 actual={str(p.relative_to(root)):sha(p) for p in root.rglob('*') if p.is_file()};assert actual==source['files'],label
 report['sources'][label]=dict(files=len(actual),manifest_sha256=sha(BASE/(label+'-source-source.json')),declared_changes=source.get('declared_changes'),selection={'phase2':'rejected map and descriptor-worker','phase3':'attribution-only framer A, not selected','phase4':'unsafe B, rejected and never measured','phase5':'safe C, rejected identity CPU tradeoff','phase6':'compressed-only safe D, pending parent performance review'}[label])
 groups=['lazy','owned','map','partial-lazy','partial-owned','encode-lazy','encode-owned'] if label=='phase2' else ['rpc']
 for group in groups:
  root=BASE/(label+'-'+group);prefix='codec' if group!='rpc' else 'rpc'
  for mode in ('shipping','allocations'):
   record=json.loads((root/(prefix+'-'+mode+'-build.json')).read_text());binary=root/(prefix+'-'+mode)
   assert record['exit_code']==0 and record['source_unchanged'] and record['harness_unchanged'];assert record['source_files']==source['files'];assert sha(binary)==record['binary_sha256'];assert binary.read_bytes()[:4]==b'\x7fELF'
   expected=({'default'} if group=='rpc' else {'owned-messages'} if group.endswith('owned') else set())|({'allocation-counts' if group=='rpc' else 'allocations'} if mode=='allocations' else set());assert set(record['features'])==expected,(label,group,record['features'],expected)
   report['binaries'][label+'/'+group+'/'+mode]=dict(sha256=sha(binary),features=record['features'],source_files=len(record['source_files']))
report['complete']=True;(BASE/'variant-artifact-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(complete=True,binaries=len(report['binaries']))))
