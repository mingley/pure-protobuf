import importlib.util,os,sys,unittest,json
from pathlib import Path
root=Path(__file__).resolve().parents[4]
spec=importlib.util.spec_from_file_location("run",Path(__file__).with_name("run.py"));old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old);sys.modules["run"]=old
spec=importlib.util.spec_from_file_location("timer_regression_tests",root/"bench/codegen/test_run.py");tests=importlib.util.module_from_spec(spec);spec.loader.exec_module(tests)
names={"test_command_elapsed_excludes_a_blocked_rss_sampler","test_timed_deadline_kills_descendants_and_reaps_the_direct_child"}
suite=unittest.TestSuite(cls(name) for cls in vars(tests).values() if isinstance(cls,type) and issubclass(cls,unittest.TestCase) for name in names if hasattr(cls,name))
result=unittest.TextTestRunner(verbosity=2).run(suite)
assert result.testsRun==2 and len(result.failures)==2 and not result.errors, (result.testsRun,result.failures,result.errors)
Path(__file__).with_name("results.json").write_text(json.dumps(dict(tested_old_commit="71422f008b4df06b7c68365a806327b0a4bdfa61",regressions_detect_old_bug=True,tests=2,expected_failures=2,errors=0),indent=2)+"\n")
