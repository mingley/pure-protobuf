"""Build separate frozen shipping/allocation RPC executables from one source."""
import argparse,json,os,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('label');a=p.parse_args();source=a.source.resolve()
env=dict(os.environ);env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'work/bench-target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0');env['PATH']=':'.join([str(ROOT/'work/cargo/bin'),str(ROOT/'work/toolchain/protoc/bin'),env['PATH']])
for mode in ('shipping','allocations'):
 cmd=['python3',str(BASE/'build_rpc_probe.py'),'--source',str(source),'--manifest',str(source/'rpc-bench/Cargo.toml'),'--binary-name','rpc-bench','--mode',mode,'--output',str(BASE/(a.label+'-rpc')),'--record-key','rpc-'+mode]
 print(json.dumps(dict(mode=mode,command=cmd)),flush=True)
 result=subprocess.run(cmd,cwd=ROOT,env=env)
 if result.returncode:raise SystemExit(result.returncode)
print(json.dumps(dict(state='complete',label=a.label,builds=2)),flush=True)
