#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
python3 work/all-benchmarks/measurement/capture_phase6_host_observations.py campaign-start
bash work/all-benchmarks/measurement/run_phase6_allocation.sh > work/all-benchmarks/measurement/phase6-allocation-driver.log 2>&1
bash work/all-benchmarks/measurement/run_phase6_shipping.sh > work/all-benchmarks/measurement/phase6-shipping-driver.log 2>&1
bash work/all-benchmarks/measurement/run_phase6_default.sh > work/all-benchmarks/measurement/phase6-default-driver.log 2>&1
python3 work/all-benchmarks/measurement/capture_phase6_host_observations.py identity-confirmation-start
bash work/all-benchmarks/measurement/run_phase6_identity_confirmation.sh > work/all-benchmarks/measurement/phase6-identity-confirmation-driver.log 2>&1
python3 work/all-benchmarks/measurement/capture_phase6_host_observations.py campaign-end
