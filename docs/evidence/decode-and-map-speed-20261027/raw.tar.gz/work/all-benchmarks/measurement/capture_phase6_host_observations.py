"""Append lightweight host/cgroup observations; never adjust measured ratios."""
from pathlib import Path
import datetime,json,os,subprocess,sys
BASE=Path(__file__).resolve().parent
path=BASE/'phase6-host-observations.json'
report=json.loads(path.read_text()) if path.exists() else dict(schema='pbrs.confirmation-host-observations.v1',scope='Read-only observations before and after D capture phases; diagnostics only, no normalization',observations=[])
files=['/proc/loadavg','/proc/pressure/cpu','/proc/pressure/memory','/proc/pressure/io','/sys/fs/cgroup/cpu.max','/sys/fs/cgroup/cpu.stat','/sys/fs/cgroup/cpu.pressure','/sys/fs/cgroup/memory.current','/sys/fs/cgroup/memory.max','/sys/fs/cgroup/memory.events','/sys/fs/cgroup/memory.pressure','/sys/fs/cgroup/cpuset.cpus.effective']
row=dict(note=' '.join(sys.argv[1:]),timestamp_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),observer_cpu_affinity=sorted(os.sched_getaffinity(0)),files={f:Path(f).read_text() for f in files if Path(f).exists()},processes=subprocess.check_output(['ps','-eo','pid,ppid,pcpu,pmem,comm','--sort=-pcpu'],text=True).splitlines()[:15])
row['meminfo']={a.split(':',1)[0]:a.split(':',1)[1].strip() for a in Path('/proc/meminfo').read_text().splitlines() if a.startswith(('MemTotal:','MemAvailable:','SwapTotal:','SwapFree:'))}
report['observations'].append(row);path.write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(dict(observations=len(report['observations']),latest=row['timestamp_utc'])))
