"""Freeze separate CPU/allocation binaries for both profiles' existing holdouts."""
from pathlib import Path
import argparse,json,os,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[2]
p=argparse.ArgumentParser();p.add_argument('source',type=Path);p.add_argument('label');a=p.parse_args();source=a.source.resolve()
env=dict(os.environ);env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'work/bench-target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0');env['PATH']=':'.join([str(ROOT/'work/cargo/bin'),str(ROOT/'work/toolchain/protoc/bin'),env['PATH']])
commands=[]
for kind,binary in [('partial','pbrs-partial-getter-proof'),('encode','pbrs-encode-proof')]:
 for profile in ('lazy','owned'):
  for mode in ('shipping','allocations'):
   cmd=['python3',str(BASE/'build_probe.py'),'--source',str(source),'--manifest',str(BASE/(a.label+'-'+kind+'-harness')/'Cargo.toml'),'--binary-name',binary,'--mode',mode,'--output',str(BASE/(a.label+'-'+kind+'-'+profile)),'--record-key','codec-'+mode]
   if profile=='owned':cmd+=['--owned']
   commands.append(cmd)
for i,cmd in enumerate(commands):
 print(json.dumps(dict(index=i,command=cmd)),flush=True)
 r=subprocess.run(cmd,cwd=ROOT,env=env)
 if r.returncode:raise SystemExit(r.returncode)
print(json.dumps(dict(state='complete',label=a.label,builds=len(commands))),flush=True)
