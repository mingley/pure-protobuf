"""Check published capsule and docs; keep checks outside the archive input tree."""
import hashlib,json,os,subprocess,time
from pathlib import Path
root=Path(__file__).resolve().parents[2];out=root/'work/all-benchmarks-final-checks';out.mkdir(exist_ok=False)
cap=root/'docs/evidence/decode-and-map-speed-20261027'
report=dict(source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),checks=[],complete=False)
for name,cmd in [('capsule',['python3',str(cap/'check.py')]),('docs',['cargo','test','--locked','--test','documentation','--','--nocapture']),('whitespace',['git','diff','--check'])]:
 start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 row=dict(name=name,command=cmd,exit_code=r.returncode,seconds=time.monotonic()-start);report['checks'].append(row)
 (out/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:print((out/(name+'.log')).read_text()[-10000:]);raise SystemExit(1)
m=json.loads((cap/'manifest.json').read_text())
for name,v in m.get('companion_files',{}).items():
 p=cap/name;assert hashlib.sha256(p.read_bytes()).hexdigest()==v['sha256'];assert p.stat().st_size==v['bytes']
report['complete']=True;(out/'results.json').write_text(json.dumps(report,indent=2)+'\n')
result=json.loads((cap/'results.json').read_text());result['publication_checks']=report
(cap/'results.json').write_text(json.dumps(result,indent=2)+'\n');m['results_sha256']=hashlib.sha256((cap/'results.json').read_bytes()).hexdigest();(cap/'manifest.json').write_text(json.dumps(m,indent=2)+'\n')
subprocess.run(['python3',str(cap/'check.py')],cwd=root,check=True)
