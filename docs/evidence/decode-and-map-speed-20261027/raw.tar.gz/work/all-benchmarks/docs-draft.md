# Documentation draft for the decode and map batch

Integration notes for the root agent: this file is a draft, not published
evidence. Replace every `PENDING` item with a completed final-source result
before copying it into repository documentation. Measurements below are
explicitly separated from work-count and allocation probes. Use the client
date, October 27, for this record even though the host commit timestamp is
October 28 UTC. Baseline is `0287879d`; implementation is `71422f00`.

## New capsule: docs/evidence/decode-and-map-speed-20261027/README.md

```markdown
# Nested decoding, map reads and generator costs, October 27

Implementation `71422f00` reuses validated child wire during lazy access,
avoids backing-buffer work for short map entries, and walks indexed unique
maps directly. It also reuses generator spellings and adjusts fragmented
compressed-frame growth. The comparison starts at `0287879d`.

[Results](results.json) · [Raw data](raw.tar.gz) · [Manifest](manifest.json)
· [Checksum checker](check.py) · [Benchmark guide](../../benchmarks.md)

## Results

PENDING: Summarize all final matrices here, including their losses. Do not
infer shipping CPU gains from instrumented validation or allocation probes.
Use fresh reference results and median paired ratios, not ratios of displayed
medians. State the number of rows and randomized pairs from their manifests.

| Work | Before | After | Reference | Median paired after/reference |
|---|---:|---:|---:|---:|
| Lazy depth-64 parse, read and drop | PENDING | PENDING | PENDING Prost | PENDING |
| Owned depth-64 parse, read and drop | PENDING | PENDING | PENDING Prost | PENDING |
| Lazy mixed message, parse/read/drop | PENDING | PENDING | PENDING Prost | PENDING |
| Owned mixed message, parse/read/drop | PENDING | PENDING | PENDING Prost | PENDING |
| Warm 256-entry unique map, iterate all | PENDING | PENDING | PENDING standard HashMap | PENDING |

PENDING: Explicitly name the remaining losing or inconclusive cases from the
full 32-row codec matrix, 42 warm-map rows, four partial-read rows, 16 encoding
rows, generator profiles and RPC results. Partial rows access only the first
child at depths eight and 64; encode rows separate parse/first-encode lifecycle,
first encode alone, cached encode, and first-child mutation plus encode. These are different operations;
passing one matrix does not establish a win in the others. The warm-map
reference labelled `prost` in the raw helper is standard `HashMap`, not a
Prost parse operation. Map construction and index warming are outside that
microbenchmark; the full codec matrix includes parsing and dropping messages.

## Lazy decoding without repeated validation

The public parser still validates nested wire before accepting a message.
New generated code records that result on a deferred singular child. When a
getter constructs the child, its decoder reuses the existing validation result
and decodes the immediate fields normally. It does not recursively validate
the same descendants again. This removes the repeated traversal that made a
full read of a nested chain quadratic in the earlier implementation.

Children remain lazy. A first getter constructs one immediate child instead
of constructing the entire subtree. Unread children remain deferred, and
untouched cached wire can still be reused for encoding. Fresh merges take the
ordinary checked path, including after reads or mutation. Collection helpers
and old generated or handwritten `MergeBytes` implementations can also use the
existing checked fallback.

Regenerate application bindings to enable the new generated path. Old bindings
remain functional through the checked fallback. Three generated merge-helper
names are now reserved; a schema field with one of those names receives the
existing `_field` collision suffix.

An independent instrumented consumer checks a 64-node chain against Prost:
the initial parse enters 63 child validators, and the later chain getters
enter none. It also checks malformed wire, UTF-8, recursion limits, fresh
merges, required fields, oneofs, collection children, clone/mutation isolation,
concurrent getters and shared-buffer lifetime. Its counters are absent from
shipping benchmark binaries. It records 22 ordinary collection fallback
validations rather than claiming that every collection path skips validation.

The validation flag has a cost. In this proof, each affected lazy allocation
requests eight more bytes: parse traffic is 432 rather than 424 bytes, and the
first getter requests 128 rather than 120 bytes. These are requested allocator
bytes for the proof fixture, not RSS or a claim about every message layout.
The original Wire representation and generated all-zero default layout stay
intact. The rejected Wire-layout prototype and its failures remain documented
in the evidence; it is not the selected implementation.

The explicit `owned_message_fields(true)` profile remains available. It
constructs singular children while parsing and has different partial-read,
allocation and encoding costs. Compare both profiles for the application's
workload rather than treating one as a universal winner.

## Maps

Map-entry decoding now uses bounded slices and offsets into the parent input.
Numeric and inline-string-only entries do not create an intermediate backing
wire or window. Longer strings and message values retain the established
sharing policy and correct offsets; decoded views still outlive the caller's
input buffer safely. UTF-8, entry bounds and last-wins duplicate behavior are
checked independently.

A warmed last-wins index has one position per unique key. If its count equals
the original entry count, every key is unique. Iteration can then walk the
borrowed slice without searching the index for each entry. Its exact size
hint also reserves collection output once. This proof uses existing metadata;
it adds no map field, allocation or unsafe operation. Duplicate-containing and
unindexed maps retain their filtering path. Raw arena snapshots are unchanged.

Nine view tests and nine existing map units pass. A counted-key test verifies
zero comparisons after warming a unique index; an allocator probe verifies
zero iterator allocations. Mutation controls cover replacement, unique and
duplicate appends, removal with an earlier value resurfacing, mutable views
and clone/rebuild. Six separate map-decoding controls cover short and long
strings, multiple message offsets, malformed input and buffer lifetime.

## Generator costs

Per-worker field-name caches share `Rc<str>` spellings. Fixed scalar, map and
storage type spellings use borrowed `Cow<str>` values; formatted message paths
remain owned. This avoids repeatedly allocating the same temporary strings.
State remains worker-local, with no global intern table or added atomics.
Generated application code does not depend on `Rc`.

The isolated spelling-only comparison produces byte-identical files on all
six allocation corpora. It makes 13.99–22.06% fewer allocation requests and
requests 0.37–0.87% fewer bytes. Retained bytes are unchanged; one peak-live
case rises 5.74%. These instrumented captures overlapped compilation, so their
clocks cannot establish generator CPU performance or peak RSS. Final integrated
generation intentionally also includes the new lazy helpers described above;
the spelling-only equivalence check does not claim that all new bindings are
byte-identical to the older decoder output.

PENDING: Add final canonical-debug and matched-release generation wall time
and sampled RSS, with all peers' build settings, corpora and losses. These
CLI captures do not measure downstream consumer cold/check/release-build
costs; those remain a separate benchmark axis. Keep the profiles separate.
Do not describe release timings as the canonical debug benchmark or compare
a release candidate with a debug reference. Twenty-five focused codegen units
and strict core-library Clippy pass before final integration validation.

## Fragmented compressed frames

The framer validates the header and configured limit before considering the
claimed length. When at least half of a fragmented compressed frame has
arrived and the buffer needs to grow, it reserves the remaining validated
length. This avoids a final geometric growth for incompressible payloads whose
footer falls just beyond the old capacity. A header or tiny body fragment
does not reserve memory proportional to a large claim. Identity and complete
frame sharing keep their existing behavior; decompression policy is unchanged.

Twelve framer units and three independent integration checks pass, including
oversized claims, multiple following frames, compression negotiation and decode
workspace behavior. PENDING: Give the final shipping allocation/CPU results
and include the zero/noise and identity holdouts, including any losses.

## Validation and reconstruction

PENDING: Fill the final source-bound workspace, strict Clippy, Rust 1.85,
interop, wire differential, generated drift, official lazy/owned conformance,
documentation and checksum results. The focused counts above are not a
replacement for those final checks. Preserve expected strict Prost policy
counterexamples rather than describing them as complete behavior equivalence.

The archive retains frozen source manifests, exact overlays, build records,
raw captures, paired summaries, lockfiles, correctness prechecks, initial
failures and rejected attempts. Shipping timings use binaries without
instrumentation and run separately from allocation captures. PENDING: State
the actual process counts, sampling/host limitations, source-equivalence
checks and reproduction commands from the completed manifests.

These records establish their measured workloads and source revisions. They
do not establish every possible workload, full tonic/prost parity or a world
performance ranking. Build elapsed times alone are not a generator-speed
comparison.
```

## Top-level benchmark guide: insert above the previous map section

```markdown
## Nested decoding and map costs, October 27

New generated lazy getters reuse the parser's nested-wire validation instead
of validating descendants again. Children still materialize only when read.
An independent depth-64 probe records 63 child validations during parsing and
zero during later chain getters; those counts are not a timing measurement.
The flag adds eight requested bytes to each affected lazy allocation in that
probe. Regenerate bindings to use this path.

Short map entries also avoid intermediate backing-wire work. Warm indexed
maps whose keys are all unique iterate directly and report exact size hints,
using existing metadata. The generator reuses spelling strings, and fragmented
compressed frames reserve their remaining validated length after at least
half has arrived and growth is needed.

PENDING: Add a short final-results table with both codec profiles, one large
map row, the generator and compressed holdouts. Name the remaining losses;
link the complete matrix rather than publishing only selected wins.

The [complete record](evidence/decode-and-map-speed-20261027/README.md) separates
shipping CPU, allocator requests and instrumented work counts. It retains the
earlier map/codec regressions and every new control.
```

Keep the existing map, server, nested-message and generator tables with their
original source pins. Change "The latest map-only comparison" to "The earlier
map-only comparison" where the new record is added; do not silently replace
the historical source's numeric results with the new implementation's claims.

## Codegen guide: clarify the storage choice

Use this instead of implying that the owned profile alone avoids repeated
validation. The builder example and imported-layout/encoding caveats can stay.

```markdown
Choose `owned_message_fields(true)` to construct singular children while
parsing. The default lazy profile validates child wire during parsing and
constructs children only when accessed. Newly generated lazy getters reuse
that validation result, so a full nested read avoids repeated descendant
validation while partial reads can leave children unconstructed. Regenerate
application bindings to enable this optimization; older bindings keep their
checked fallback.

Both profiles preserve public parse validation, recursion limits, formats and
message accessors. Owned and lazy storage still differ in allocation, partial
reads, mutation and encoding costs. Use the [latest measurements](../evidence/decode-and-map-speed-20261027/README.md)
to select a profile for the application rather than assuming either always wins.
```

## Status and parity navigation

For `docs/status.md`, prepend a short current-source paragraph, then keep older
counts at their own pins:

```markdown
The [nested decoding and map follow-up](evidence/decode-and-map-speed-20261027/README.md)
at `71422f00` removes repeated descendant validation from new lazy getters,
avoids backing-wire work for short map entries and directly iterates proven
unique maps. It also reduces repeated generator spelling allocations and
adjusts compressed-frame buffer growth. PENDING: State final workspace and
conformance totals from the completed validation, followed by the principal
performance gains and remaining losses.
```

For `docs/parity.md`, update the latest source/link to the new record and
qualify the old benchmark paragraphs as historical. Add this new behavior:

```markdown
Regenerated default lazy bindings reuse prior nested validation when getters
materialize singular children. The proof checks malformed input at public
parse, fresh merge checks, required fields, shared-buffer lifetime, clone and
mutation isolation, and concurrent getters. Repeated/map/group helpers and old
bindings can retain the ordinary checked fallback. This performance change
does not close the remaining field-representation, alloc-only or transport
migration gaps listed below.
```

Replace the current storage-choice bullet that recommends owned messages
specifically to avoid repeated validation: that is now also addressed by
regenerated lazy bindings. Keep the older depth-64 timing explanation tied to
its old source. Default generator output changes in the affected bindings;
do not carry forward the old "all 13 unchanged" result as the new source's
regeneration claim. PENDING: Final generated drift decides which of the
13 bundled outputs changed; the implementation currently changes seven.

Add one link in `docs/evidence/README.md` and, if useful, `docs/README.md`:

```markdown
- [Nested decoding, map reads and generator costs](evidence/decode-and-map-speed-20261027/README.md):
  validated lazy getters, unique-map iteration, bounded compressed input growth
  and complete before/after controls.
```

Use `decode-and-map-speed-20261027/README.md` as the relative link from the
evidence index, not the `evidence/...` prefix shown for the docs root above.
