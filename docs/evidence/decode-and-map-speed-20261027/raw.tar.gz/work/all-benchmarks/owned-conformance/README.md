# Owned-profile official conformance

This driver archives exact implementation `71422f008b4df06b7c68365a806327b0a4bdfa61` and regenerates
its 13 bundled schemas with `shared_pool=true,owned_message_fields=true`.
The isolated registry must stay byte-identical, and before/after manifests
check that only those generated bindings change. No live checkout production
or test inputs are edited.

The pinned v35.1 official runner executes two required runs and one enforced
recommended run with maximum Edition 2023. The publisher requires each run to
pass 5,631 binary/JSON and 909 text cases, with zero skips or failures.

`report.json` retains commands, elapsed times, Cargo-bound executable hashes,
compiler/runner/SDK provenance, imported proto hashes and generation changes.
`owned-generated.patch` reconstructs the profile changes. A dirty-source flag
in the isolated report describes this explicit regeneration.

Keep the driver, publisher, reports, logs, Cargo artifact metadata, source
manifests, reconstruction patch and passes directory as portable evidence.
Full source snapshots, executables and build caches can be omitted.
