#!/usr/bin/env python3
"""Regenerate committed bundled schemas with owned storage and run pinned suites.

Run from an existing checkout with the pinned upstream SDK/compiler provisioned
by scripts/conformance.sh. The source snapshot and build artifacts are local;
manifests, commands, patches and logs are the portable evidence.
"""
import datetime
import difflib
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tarfile
import time

ROOT = Path(__file__).resolve().parents[3]
OUT = Path(__file__).resolve().parent
SOURCE = OUT / 'source'
COMMIT = '71422f008b4df06b7c68365a806327b0a4bdfa61'
PATHS = ['Cargo.toml', 'Cargo.lock', 'build.rs', 'README.md', 'LICENSE-APACHE',
         'LICENSE-MIT', 'clippy.toml', 'rustfmt.toml', 'src', 'vendor', 'proto',
         'pbrs-grpc', 'protobuf-tonic', 'examples', 'scripts/conformance-report.py',
         'scripts/regen-generated.sh']
BUILD = ROOT / 'target/conformance-build'
SDK = ROOT / 'third_party/protobuf'
TARGET = ROOT / 'work/bench-target'
PROTOS = [
    'src/google/protobuf/any.proto',
    'src/google/protobuf/duration.proto',
    'src/google/protobuf/timestamp.proto',
    'src/google/protobuf/struct.proto',
    'src/google/protobuf/wrappers.proto',
    'src/google/protobuf/field_mask.proto',
    'src/google/protobuf/empty.proto',
    'src/google/protobuf/test_messages_proto3.proto',
    'src/google/protobuf/test_messages_proto2.proto',
    'conformance/test_protos/test_messages_edition2023.proto',
    'conformance/test_protos/test_messages_edition_unstable.proto',
    'editions/golden/test_messages_proto2_editions.proto',
    'editions/golden/test_messages_proto3_editions.proto',
]
REPORT = {'source_commit': COMMIT, 'source_paths': PATHS,
          'profile': 'shared_pool=true,owned_message_fields=true',
          'maximum_edition': '2023', 'steps': [], 'complete': False,
          'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
ENV = dict(os.environ)
ENV.update(CARGO_HOME=str(ROOT / 'work/cargo'),
           RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1',
           CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
ENV['PATH'] = ':'.join([str(ROOT / 'work/cargo/bin'), str(BUILD),
                        str(ROOT / 'work/toolchain/protoc/bin'), ENV['PATH']])
for name in list(ENV):
    if name.startswith('PURE_PROTOBUF_'):
        del ENV[name]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save():
    (OUT / 'report.json').write_text(json.dumps(REPORT, indent=2) + '\n')


def step(name, command, cwd=SOURCE, stdout=None):
    log = OUT / (name + '.log')
    before = time.monotonic()
    with log.open('w') as errors:
        if stdout:
            with Path(stdout).open('w') as output:
                result = subprocess.run(command, cwd=cwd, env=ENV,
                                        stdout=output, stderr=errors)
        else:
            result = subprocess.run(command, cwd=cwd, env=ENV,
                                    stdout=errors, stderr=subprocess.STDOUT)
    row = {'name': name, 'command': command, 'cwd': str(cwd),
           'exit_code': result.returncode, 'seconds': time.monotonic()-before,
           'log': log.name, 'stdout': str(stdout) if stdout else log.name}
    REPORT['steps'].append(row)
    save()
    print(json.dumps(row), flush=True)
    if result.returncode:
        print(log.read_text()[-10000:], flush=True)
        raise SystemExit(result.returncode)


def cargo_executable(artifacts, target_name):
    candidates = []
    for line in artifacts.read_text().splitlines():
        row = json.loads(line)
        if (row.get('reason') == 'compiler-artifact'
                and row.get('target', {}).get('name') == target_name
                and 'bin' in row.get('target', {}).get('kind', [])
                and row.get('executable')
                and Path(row['manifest_path']).resolve() == SOURCE / 'Cargo.toml'):
            candidates.append(Path(row['executable']))
    assert len(set(candidates)) == 1, candidates
    executable = candidates[-1]
    saved = OUT / 'artifacts' / target_name
    saved.parent.mkdir(exist_ok=True)
    shutil.copy2(executable, saved)
    REPORT[target_name] = {'cargo_executable': str(executable),
                           'bound_executable': str(saved), 'sha256': sha(saved),
                           'bytes': saved.stat().st_size,
                           'cargo_json': artifacts.name}
    save()
    return saved


if SOURCE.exists():
    raise SystemExit('source already exists; use a fresh output directory')
SOURCE.mkdir()
archive = OUT / 'selected-source.tar'
step('archive', ['git', 'archive', '--format=tar', COMMIT, *PATHS], cwd=ROOT,
     stdout=archive)
with tarfile.open(archive) as stream:
    stream.extractall(SOURCE, filter='data')
archive.unlink()
(SOURCE / 'third_party').mkdir()
(SOURCE / 'third_party/protobuf').symlink_to(SDK, target_is_directory=True)
source_manifest = {str(p.relative_to(SOURCE)): {'sha256': sha(p), 'bytes': p.stat().st_size}
                   for p in sorted(SOURCE.rglob('*'))
                   if p.is_file() and not p.is_symlink()}
(OUT / 'source-before.json').write_text(json.dumps(source_manifest, indent=2)+'\n')
REPORT['source_before_manifest'] = 'source-before.json'
REPORT['external_sdk_symlink'] = {'snapshot_path': 'third_party/protobuf',
                                  'target': str(SDK),
                                  'purpose': 'Pinned SDK source for protoc and conformance FDS build'}
pin = (SOURCE / 'vendor/google/PIN').read_text().strip()
sdk_sha = (SOURCE / 'vendor/google/SHA').read_text().strip()
actual_sdk_sha = subprocess.check_output(['git', '-C', str(SDK), 'rev-parse', 'HEAD'], text=True).strip()
assert actual_sdk_sha == sdk_sha
subprocess.run(['git', '-C', str(SDK), 'diff', '--quiet', 'HEAD', '--'], check=True)
assert not subprocess.check_output(['git', '-C', str(SDK), 'ls-files', '--others', '--exclude-standard', '--', '*.proto'], text=True).strip()
assert (BUILD / '.pbrs-protobuf-pin').read_text().strip() == f'{pin} {sdk_sha}'
assert subprocess.check_output([str(BUILD/'protoc'), '--version'], text=True).strip() == 'libprotoc '+pin[1:]
assert not any(re.search(r'edition[_]*2024', p.read_text(errors='replace'), re.I)
               for p in (SDK/'conformance').rglob('*') if p.is_file())
REPORT['tools'] = {'runner_pin': pin, 'runner_sha': sdk_sha,
                   'runner_sha256': sha(BUILD/'conformance_test_runner'),
                   'protoc_sha256': sha(BUILD/'protoc'),
                   'rustc': subprocess.check_output(['rustc','--version','--verbose'], env=ENV, text=True),
                   'cargo': subprocess.check_output(['cargo','--version'], env=ENV, text=True)}
# Bind all imported .proto files as well as the 13 generation entry points.
REPORT['upstream_proto_manifest'] = {
    str(p.relative_to(SDK)): sha(p) for p in sorted(SDK.rglob('*.proto'))
    if p.is_file() and '.git' not in p.parts}
REPORT['input_protos'] = PROTOS
save()
plugin_artifacts = OUT/'plugin-artifacts.jsonl'
step('build-plugin', ['cargo','build','--locked','--release','--bin','protoc-gen-pbrs',
                      '--message-format=json'], stdout=plugin_artifacts)
plugin = cargo_executable(plugin_artifacts, 'protoc-gen-pbrs')
stage = OUT/'generated'
stage.mkdir()
registry = SOURCE/'src/generated/mod.rs'
registry_hash = sha(registry)
for index, proto in enumerate(PROTOS):
    step(f'generate-{index:02d}', [str(BUILD/'protoc'),
         '--plugin=protoc-gen-pbrs='+str(plugin),
         '--pbrs_out=shared_pool=true,owned_message_fields=true:'+str(stage),
         '-I',str(SDK/'src'),'-I',str(SDK),str(SDK/proto)])
files = [Path(p).stem+'.rs' for p in PROTOS]
registered = []
for attrs, name in re.findall(r'((?:#\[[^\n]*\]\s*)*)pub mod (\w+);',registry.read_text()):
    paths = re.findall(r'#\[path\s*=\s*"([^"]+)"\]',attrs)
    registered.append(paths[0] if paths else name+'.rs')
assert sorted(registered) == sorted(files)
step('format-generated', ['rustfmt','--edition','2021','--config-path',str(SOURCE/'rustfmt.toml'),
                           *[str(stage/name) for name in files]])
changes = []
patch = []
for name in files:
    original = SOURCE/'src/generated'/name
    replacement = stage/name
    before = original.read_text()
    after = replacement.read_text()
    changes.append({'path':'src/generated/'+name, 'before_sha256':sha(original),
                    'owned_sha256':sha(replacement), 'before_bytes':original.stat().st_size,
                    'owned_bytes':replacement.stat().st_size, 'changed':before!=after})
    patch.extend(difflib.unified_diff(before.splitlines(keepends=True),after.splitlines(keepends=True),
                   fromfile='a/src/generated/'+name,tofile='b/src/generated/'+name))
    shutil.copy2(replacement,original)
assert sha(registry) == registry_hash
(OUT/'owned-generated.patch').write_text(''.join(patch))
REPORT['generated_bindings'] = changes
REPORT['registry_preserved'] = {'path':'src/generated/mod.rs','sha256':registry_hash}
source_after = {str(p.relative_to(SOURCE)): {'sha256':sha(p),'bytes':p.stat().st_size}
                for p in sorted(SOURCE.rglob('*')) if p.is_file() and not p.is_symlink()}
(OUT/'source-after.json').write_text(json.dumps(source_after,indent=2)+'\n')
REPORT['source_after_manifest'] = 'source-after.json'
save()
conformance_artifacts = OUT/'conformance-artifacts.jsonl'
step('build-conformance', ['cargo','build','--locked','--release','--bin','conformance',
                           '--message-format=json'], stdout=conformance_artifacts)
conformance = cargo_executable(conformance_artifacts,'conformance')
passes = OUT/'passes'
passes.mkdir()
for name, options in [('required_1',[]),('required_2',[]),('recommended',['--enforce_recommended'])]:
    output = passes/name
    output.mkdir()
    command = [str(BUILD/'conformance_test_runner'),*options,
               '--maximum_edition','2023','--output_dir',str(output),str(conformance)]
    before = time.monotonic()
    with (output/'runner.log').open('w') as log:
        result = subprocess.run(command,cwd=SOURCE,env=ENV,stdout=log,stderr=subprocess.STDOUT)
    row={'name':name,'command':command,'cwd':str(SOURCE),'exit_code':result.returncode,
         'seconds':time.monotonic()-before,'log':str((output/'runner.log').relative_to(OUT))}
    REPORT['steps'].append(row)
    save()
    print(json.dumps(row),flush=True)
    if result.returncode:
        print((output/'runner.log').read_text()[-16000:],flush=True)
        raise SystemExit(result.returncode)
step('validate-report',['python3',str(SOURCE/'scripts/conformance-report.py'),str(passes),
                       pin,sdk_sha,COMMIT,REPORT['started_utc'],'2023','1'])
REPORT['conformance_summary'] = json.loads((passes/'summary.json').read_text())
REPORT['complete']=True
REPORT['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
save()
print(json.dumps({'complete':True,'summary':REPORT['conformance_summary']}),flush=True)
