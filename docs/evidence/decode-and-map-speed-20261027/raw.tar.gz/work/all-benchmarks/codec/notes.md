# Borrowed map decoding

The old decoder ensured a backing buffer for every map occurrence, then
created an entry window before inspecting keys or values. Numeric and inline
string maps needed neither operation. Generated decoders now borrow bounded
entry slices and retain parent-relative offsets. String validation, entry
bounds, unknown-field skipping, duplicate handling and recursion guards remain.
The runtime string helper copies existing inline storage directly; longer
strings keep their old parent-window retention. Bytes use the same shared
threshold as before. Present owned message values still share one parent
backing frame, rather than copying each value separately.

The independent consumer records six new controls and its existing Prost,
merge, ownership, malformed-input and profile-isolation checks. In particular,
an inline-string map with duplicate keys allocates only its backing object and
entry vector. Long strings and large byte-valued map children preserve shared
pointers at multiple parent offsets. Invalid UTF-8 and a length crossing an
entry boundary reject. No timing threshold is part of these checks.

All final focused checks pass. Earlier fixture compile errors and the rejected
root Wire-layout candidate's null-Arc failure remain in the logs; see
results.json. That candidate was reverted. No production unsafe code was added
by this change. Shared source hashes identify collection time, not the final
root integration commit. No shipping-performance improvement is claimed until
the root measures frozen sources and controls.
