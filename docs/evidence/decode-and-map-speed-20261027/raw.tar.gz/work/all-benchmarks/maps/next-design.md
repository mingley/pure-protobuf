# Next map design, unmeasured

The selected and currently measured implementation remains `71422f00`.
This note and `../map-small-prototype` do not change working production or
root tests. No prototype compilation, formatting or timing ran during CPU
quiet. Every footprint and performance statement below is a hypothesis until
checked after quiet ends.

## Small masks in the existing lazy-index slot

Replace the index payload with:

```rust
enum LastWinsIndex<K> {
    Small(u16),
    Large(Vec<(K, usize)>),
}
```

One Small bit marks each original entry that is the final occurrence of its
key. Maps below the existing threshold16 need at most15 bits. The mask is
computed with the same O(n²) duplicate comparisons that small len() already
performs. It needs no heap allocation, clones no keys and preserves wire order.
A ready mask yields the next position with trailing_zeros and gives exact
remaining hints with popcount. Warm iteration becomes O(u), with O(1) hints,
where u is the number of distinct keys.

The enum might fit Vec's existing niche/remaining payload words: expected24B
payload,32B OnceLock and56B MapInner on64-bit. This must be checked on both
Rust1.85 and the current compiler; enum layout is not a public Rust guarantee.
The outer Map remains Option<Box<MapInner>>, so generated all-zero defaults
still mean None. The new enum is only constructed inside an initialized heap
container; it does not reuse or change Wire discriminants.

len() alone is insufficient to warm the unchanged benchmark: its preflight
collects and asks iterator hints but never calls the native map's len().
Therefore MapIter keeps a reference to the existing OnceLock (one pointer,
like the old reference to its payload). An explicit size_hint request can
initialize the small mask through &self. next() only reuses initialized state;
it never builds a complete mask on a cold first-entry read. This avoids the
V1 problem of scanning once for an exact hint and scanning again in next.
Concurrent hint initialization uses OnceLock's existing synchronization.

Cold first-entry comparison complexity remains the current incremental scan,
O(n) for one unique first key, not O(n²) for all key pairs. It still adds a
ready-state probe in next(), so latency neutrality must be measured rather
than asserted. A cold collect can repeat comparisons for the first yielded
entry before size_hint initializes the full mask; the remaining iteration
reuses that mask. Warm unchanged-harness captures, cold first-only probes,
and full mixed-message lifecycle tests must all be retained.

## Mutation rules

- Appending parsed entries invalidates the index as before.
- Replacing an existing key changes its value but not winner positions.
- Appending a new unique key updates a ready Small mask below16. Crossing16
  invalidates it; the next large read builds the sorted index lazily.
- Removing an entry invalidates the cache, including swap_remove and an
  earlier duplicate resurfacing.
- Mutable-view insert/remove/clear/copy obey the same rules.
- Clone starts with an empty cache, as before.
- Unindexed from_slice views keep the existing scan fallback. Raw arena
  snapshots do not change.

Borrowed small-map get must keep its direct borrowed-key scan even if a mask
exists. Routing a cached Small through an owned query key would regress the
existing zero-allocation long-string lookup guarantee.

## Costs and compatibility to check

A slot reference adds one Acquire ready-state load to every next call. The
old large iterator held a resolved payload reference, so large unique loops
may regress even though their algorithm is unchanged. If that occurs, a
future fold specialization could resolve the index once for bulk iteration;
that is not part of this first bounded prototype.

Standard protobuf key/view iterators remain expected Send+Sync, with compile
assertions in the prototype tests. There is an exotic public API caveat:
&OnceLock<Index<K>> needs K:Send+Sync, whereas the old &Index<K> only needed
K:Sync. A handwritten MapKey that is Sync but !Send can lose its iterator
Send/Sync auto traits. No unsafe blanket implementation is proposed. If
preserving that case is required, this slot-reference design cannot be
adopted as-is; retain resolved references or redesign the cache.

Footprint gates must compare payload, OnceLock, MapInner, MapIter and
MapViewIter on both supported compiler profiles before any speed claim.
Then run all small/large map rows plus the full codec, partial and encode
holdouts. Reuse the timed loops and record any faster or slower cold path.

## Large duplicate maps

The current sorted index retains O(log u) membership tests per visited entry.
A per-iterator O(u) scan can prove that every winner lies in a contiguous
suffix, then walk that suffix directly. But eagerly doing this before the
first result can regress arbitrary maps whose first entry already wins; it
must not be inserted unconditionally just to suit the duplicate fixture.

Caching this proof at index construction avoids that read-time scan. One
possible allocation-neutral representation uses a typed metadata footer in
the existing Vec capacity only when duplicates exist: capacity originally
covers n entries and at least one spare initialized duplicate can survive
compaction when u<n. A reserved high bit of its usize position tags metadata;
lookups explicitly exclude the footer. It can hold the first-live suffix
position while the normal entries remain key-sorted. This is more complex
than the Small enum: every index mutation must preserve/update the footer,
and retaining one duplicate K may retain an extra long-key allocation even
though Vec capacity and allocation counts are unchanged. Do not adopt this
footer without dedicated long-key lifetime/allocation tests and generic
position-range proofs. It is an alternative proposal, not implemented here.

Boxing the large index is another alternative: OnceLock<Box<Index>> shrinks
MapInner's inline slot, potentially paying for small metadata while preserving
or reducing the56B container. It adds a separate large-map heap allocation,
so warm wins must not hide the cold allocation regression. No boxed-index
implementation is part of the prototype.

## Preferred Ready/Lazy iterator alternative

The original one-slot-pointer source is preserved in
../map-small-prototype/pointer-slot-original/. The current base prototype now
uses Ready(&Index)/Lazy(&OnceLock<Index>) iterator state. Large constructors
initialize and keep Ready; constructors that observe a cached Small also keep
Ready. Their next() and size_hint() calls do not probe OnceLock. Cold Small
state remains Lazy until an explicit hint seeds the shared mask, then its
next() promotes the reference once.

This deliberately permits one additional iterator stack word: expected
MapIter32→40B and MapViewIter40→at most48B on64-bit, while the required MapInner
heap container remains56B. Payload and stack sizes remain uncompiled
hypotheses until the footprint test runs on1.85/current. The slot-reference
auto-trait caveat remains because the enum can still contain Lazy. The larger
returned iterator can affect ABI/inlining or sparse-message reads even with
zero new allocations. The full94-row lifecycle/iterator/holdout matrix must
reject trading proven large-unique throughput away for small-map gains.
