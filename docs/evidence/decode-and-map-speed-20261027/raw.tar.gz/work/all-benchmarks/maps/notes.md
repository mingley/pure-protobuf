# Unique map iteration

A warmed last-wins index contains exactly one position per distinct key.
If that count equals the wire-entry count, no duplicate key exists. The
iterator therefore walks the original slice directly, preserving wire order,
and avoids every per-entry binary search. The same cardinality proof gives
an exact constant-time size hint so collection reserves its output once.
No new index, allocation, field or unsafe operation is introduced.

Unindexed maps and indexed maps containing duplicates retain their original
filtering paths and conservative hints. Raw arena snapshots are unchanged.
The patch does not claim to fix every map case; comparative timings are owned
by the root measurement campaign.

Two added tests check the actual mechanism and its invalidation: a counted
key proves zero comparisons after warming a unique index, while a thread-local
allocator proves no iterator allocation. Separate mutation checks cover
replacement, appending unique and duplicate keys, removal with earlier-value
resurfacing, mutation through MapMut, and clone/rebuild. Existing order, lifetime,
non-UTF8 key, threshold, raw-arena and allocation checks also pass.
