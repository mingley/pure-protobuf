"""Render final source-scoped evidence prose from the selected raw summaries."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[2];base=root/'work/all-benchmarks/measurement'
def read(p):return json.loads(p.read_text())
performance=read(base/'phase6-results.json');validation=read(root/'work/all-benchmarks/final-validation/results.json')
assert performance['complete'] and validation['complete']
assert validation['source'].startswith('6d1336e0') and validation['exact_frozen_D_wire_source']
alloc=read(base/'phase6-rpc-allocation-comparison/summary.json');cpu=read(base/'phase6-rpc-shipping-comparison/summary.json');default=read(base/'phase6-rpc-default-comparison/summary.json');confirmation=read(base/'phase6-rpc-identity-confirmation/summary.json')
def ratio(r,key='after_native_over_tonic'):
 return f"{r['ratios'][key]['median']:.3f}" if r.get('ratios') else 'invalid slope'
def bounds(r,key):
 return '–'.join(f'{x:.3f}' for x in r['ratios'][key]['range']) if r.get('ratios') else 'invalid slope'
labels={'bidi_4x1m_gzip_noise':'4 × 1 MiB gzip noise, bidi','bidi_4x1m_gzip_zero':'4 × 1 MiB gzip zeros, bidi','upload_4x1m_gzip_noise':'4 × 1 MiB gzip noise, upload','download_4x1m_gzip_noise':'4 × 1 MiB gzip noise, download','unary_1m_gzip_noise':'1 MiB gzip noise, unary','unary_8m_identity_zero':'8 MiB identity zeros, unary'}
rows=['| Work | Endpoint | Requested MB/RPC | Tonic MB/RPC | Paired bytes after/before | Paired CPU after/tonic |','|---|---|---:|---:|---:|---:|']
for a in alloc:
 if a['metric']!='requested_bytes_per_rpc':continue
 c=next(r for r in cpu if r['cell']==a['cell'] and r['endpoint']==a['endpoint'])
 rows.append(f"| {labels[a['cell']]} | {a['endpoint']} | {a['medians']['after']['native']/1e6:.3f} | {a['medians']['after']['tonic']/1e6:.3f} | {ratio(a,'after_over_before_native')} | {ratio(c)} |")
transport='''## Transport buffers

Fragmented compressed frames validate the header and configured limit before
using its length. Once at least half the frame has arrived, the reader can
reserve the validated remainder before copying a large HTTP/2 DATA chunk.
A uniquely owned empty buffer is reclaimed first. Identity frames keep their
previous growth policy, and complete frames retain their sharing behavior.
Headers and tiny body fragments do not reserve a large claimed body.

Compressed output also keeps a reusable buffer tail between messages. The
next message can reclaim that storage once the previous immutable frame has
been consumed. Entirely compressed batches are eligible. Identity attempts
invalidate eligibility before calling the codec, including on failure. A
scope guard releases empty buffers on errors and unwinding while restoring
any complete earlier frames.

The original backing allocation, including its shared prefix, is charged to
the existing encode-retention budget: at most 4 MiB per retained backing and
16 MiB across retained encode buffers. These limits are unchanged. The policy
bounds idle retained buffers, not all active or process memory. Plaintext
serialization scratch and compressed output share that budget; decode scratch
has its existing independent budget.

### Final transport comparisons

These records compare `71422f00` with the exact three wire files in
`6d1336e0`. CPU has five randomized process pairs and allocation traffic has
two pairs, using separate binaries. MB below means 1,000,000 bytes. Allocation
counts, every pair and invalid slopes remain in the resource and timing tables.

'''+ '\n'.join(rows)+'''\n
The default 1 KiB unary and 64-message pipeline CPU holdouts remain separate:

| Work | Endpoint | Median paired native/tonic CPU | Pair range |
|---|---|---:|---:|
'''
for r in default:transport+=f"| {r['cell']} | {r['endpoint']} | {ratio(r)} | {bounds(r,'after_native_over_tonic')} |\n"
pipeline_client=next(r for r in default if r['cell']=='pipeline_64x1k_prost' and r['endpoint']=='client')
pipeline_server=next(r for r in default if r['cell']=='pipeline_64x1k_prost' and r['endpoint']=='server')
transport+=f'''
The pipeline client also has a higher paired before/after CPU median:
{ratio(pipeline_client,'after_over_before_native')} (range {bounds(pipeline_client,'after_over_before_native')});
the server change is {ratio(pipeline_server,'after_over_before_native')}
({bounds(pipeline_server,'after_over_before_native')}). Fresh control slopes vary too.
These increases remain in the ledger; neither a lower after/tonic median nor
control variability establishes absence of a regression. The client loses one
after/tonic repeat. No general transport CPU improvement is claimed.
'''
transport+='''
The longer identity confirmation keeps the same 8 MiB payload, 16 MiB caps,
peers and binaries, increasing counts from 10/20 to 500/1,000. It adds evidence
without replacing the original large-cell rows:

| Endpoint | Before CPU | Final CPU | Paired after/before | Pair range | Paired final/tonic |
|---|---:|---:|---:|---:|---:|
'''
for r in confirmation:transport+=f"| {r['endpoint']} | {r['medians']['before']['native']/1000:.2f} ms/RPC | {r['medians']['after']['native']/1000:.2f} ms/RPC | {ratio(r,'after_over_before_native')} | {bounds(r,'after_over_before_native')} | {ratio(r)} |\n"
transport+='''
These CPU comparisons remain local shared-host measurements. Fresh controls
and pair ranges matter; allocator savings do not establish a general CPU win.
The original 10/20-RPC identity slopes are especially coarse at the 100 Hz
counter resolution. The complete ledger retains them all.

### Rejected framing and output attempts

The initial framer-only change in `71422f00` did not improve end-to-end
allocation bytes. A later reader-only experiment improved unary traffic but
regressed some streaming cases; reclaiming empty storage removed that issue.
An output-buffer prototype failed independent quota and unwind review and was
never timed or selected. Its reviewed replacement supplies the guarded output
reuse above.

A broader framing candidate, C, also anticipated identity lengths. It reduced
8 MiB unary requested bytes by 25.4%, but its longer 500/1,000-RPC check raised
client CPU medians from 7.12 to 11.00 ms and server medians from 5.74 to
9.20 ms. Median paired changes were 1.505 (range 0.764–2.455) and 1.560
(0.421–4.128). Tonic controls moved too; that does not dismiss the loss.
No CPU throttling or new memory-limit events occurred in the retained latter
host window. Identity anticipation was rejected and the final compressed-only
source was built and measured again. C's raw captures remain historical.

Closed uploads currently encode queued messages before sending them. Downloads
can begin the next compression while the connection still owns a small DATA
suffix of the previous backing. Both behaviors can prevent reuse and need
separate scheduling and ownership work. These explanations come from code
inspection; this campaign has no per-role cache-miss instrumentation.

Sixty-nine wire units and strict transport Clippy pass on the reviewed source.
An independent HTTP/2 peer checks nonce-distinct incompressible payloads in
both upload and native-server response directions. It covers mixed sizes,
oversized retention misses, twenty live streams, aggregate budget saturation,
cancellation, deadlines and clean completion. Every decoded message is checked
and all leases return to zero. Error, panic, identity and shared-prefix cases
also have unit controls. CI runs the permanent integration fixture explicitly.

'''
p=root/'docs/evidence/decode-and-map-speed-20261027/README.md';s=p.read_text();a=s.index('## Transport buffers');b=s.index('## Validation and reconstruction');s=s[:a]+transport+s[b:]
s=s.replace('The complete tables and raw records will be packaged beside this page after\nthe final comparisons finish. See the [benchmark guide](../../benchmarks.md).','''Read the complete [timing table](timing.csv), [resource table](resources.csv)
and [remaining-loss gate](all-win-gate.json). Lower ratios favor pbrs.
The [results](results.json), [raw archive](raw.tar.gz), [manifest](manifest.json)
and [checker](check.py) retain the supporting records. See the
[benchmark guide](../../benchmarks.md) for the other workloads.''')
w=validation['workspace_test_counts'];s=s.replace('PENDING: Add final-source checks if a transport follow-up is adopted.',f'''The final `6d1336e0` source passes all nine final checks, including
{w['passed']:,} all-feature workspace tests ({w['failed']} failures, {w['ignored']} existing ignores),
strict transport/adapter/example Clippy, mixed-peer tests, Rust 1.85 native
and Tower builds, official default conformance and generated-file drift.
The Rust runtime/generator and non-transport proof inputs remain byte-identical
to the earlier complete validation. The isolated owned-conformance record
continues to name `71422f00`; it is not silently reassigned to the final source.
The initial final-validation attempt caught draft links to not-yet-packaged
assets; that failure and its disposition are retained. Publication checks
validate the completed links and every evidence checksum separately.''')
g=performance['gate'];s=s.replace('instrumentation and run separately from allocation captures. PENDING: State\nthe actual process counts, sampling/host limitations, source-equivalence\nchecks and reproduction commands from the completed manifests.',f'''instrumentation and run separately from allocation captures. The selected
94 core rows contain 1,880 shipping process captures and 5,640 samples, plus
376 separate allocator captures. Corrected selected generation uses 240 CLI
invocations across debug and release. The selected transport campaign has
684 captures and {performance['total_rpc_successful']:,} successful RPCs, including
45,000 calls in the longer identity confirmation.

The final timing ledger has {g['timing_rows']} rows: 69 wins, 48 losses and seven ties.
The {g['resource_rows']} resource rows contain 43 wins, 55 losses and 138 ties; zero/zero
counts remain ties.
Nine benchmark axes remain missing, including downstream consumer-build costs.
All-benchmark victory is false. Median wins also do not imply every-repeat wins.

RPC captures use one connection, one RPC in flight and two Tokio workers per
endpoint on one shared x86_64 VM. They validate successful counts, lengths and
status, rather than reading every zero payload byte. There is no per-capture
FAIRNESS/socket attestation or independent host qualification. The 8 MiB cell
sets the same explicit 16 MiB message caps on both peers. CPU counters are
100 Hz N/2N differences; RSS, allocator traffic and CLI wall time are separate
metrics. Exact exported sources, ordered patches, overlays and reproduction
drivers are retained; run `python3 check.py` in this directory to verify them.''')
assert 'PENDING:' not in s;p.write_text(s)
print(json.dumps(dict(workspace=w,timing_rows=g['timing_rows'],timing_losses=g['timing_losses_or_ties_or_invalid'],source=validation['source'])))
