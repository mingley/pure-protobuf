"""Bind the independent validated-lazy proof to its collection-time sources."""
import hashlib, json, re, subprocess
from pathlib import Path
root=Path(__file__).resolve().parents[3]
out=Path(__file__).resolve().parent
log=(out/'consumer-final.log').read_text()
clippy=(out/'clippy-final.log').read_text()
assert 'Finished `dev` profile' in clippy and '\nerror' not in clippy
passes=[line for line in log.splitlines() if line.startswith('PASS ')]
assert len(passes)==9, passes
assert 'initial_validations=63 getter_validations=0 parse_allocations=2 parse_bytes=432 first_getter_allocations=1 first_getter_bytes=128 later_allocations=61' in log
paths=['src/lazy.rs','src/gen_support.rs','src/codegen/parse.rs','src/codegen/messages.rs','src/codegen/naming.rs']
paths += [str(p.relative_to(root)) for p in sorted((root/'tests/proof/validated_lazy').rglob('*')) if p.is_file()]
manifest={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in paths}
result=dict(
    scope='Independent instrumented consumer; no timing or blanket performance claim',
    reviewed_git_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
    focused_logs_precede_integration_commit=True,
    source_hash_scope='Reviewed final source after integration formatting, not an exact binding of the earlier focused binary; final root validation reruns the consumer on the committed inputs.',
    reviewed_source_sha256=manifest,
    consumer=dict(command=['cargo','run','--locked','--offline','--manifest-path','tests/proof/validated_lazy/Cargo.toml'],passed=True,log='consumer-final.log',pass_groups=passes),
    clippy=dict(command=['cargo','clippy','--locked','--offline','--manifest-path','tests/proof/validated_lazy/Cargo.toml','--','-D','warnings'],passed=True,log='clippy-final.log'),
    work_invariants=dict(depth=64,initial_child_validations=63,later_chain_getter_validations=0,parse_allocations=2,parse_requested_bytes=432,first_getter_allocations=1,first_getter_requested_bytes=128,later_allocations=61,first_getter_cost_same_for_depths=[4,64],collection_safe_fallback_validations=22,wire_bytes=32,compact_node_bytes=32),
    rejected_phase=dict(
      design='Encode validation provenance in two additional private WireInner variants to reuse the existing enum tag',
      outcome='SIGSEGV at proto3 invalid-UTF8 proof; rejected and reverted',
      logs=['consumer-fixed.log','consumer-diagnostic.log'],
      inferred_cause='Parent source review attributed failure to changed Rust niche/layout assumptions used by all-zero generated defaults. A separate retained Callgrind diagnostic locates a null Arc drop through WireInner/LazyStr in HelloRequest::set_name before RPC/framing; reverting the Wire layout repairs both proofs. The original rejected source was not snapshotted by this agent; later reconstruction must be labelled reconstructed.',
      adjacent_diagnostic='work/all-benchmarks/transport/negotiation-callgrind.log',
      exact_rejected_source_snapshot_retained=False,
      replacement='Private bool on LazyInner; original Wire enum layout restored',
      measured_replacement_cost=dict(extra_requested_bytes_per_lazy_box=8,first_getter_before_bytes=120,first_getter_after_bytes=128,parse_before_bytes=424,parse_after_bytes=432)),
    retained_setup_failures=[dict(log='consumer-first.log',reason='Fixture sum type inference and NodeView borrowing mistakes corrected'),dict(log='clippy.log',reason='Build-script synchronous fs methods needed a scoped allow with a reason')],
    limits=['Instrumented validator counters belong only to this proof consumer; shipping benchmark binaries are separate.', 'Repeated/map/group helpers can still use ordinary checked fallback; this proof records22 such validations.', 'Hidden validated constructor records an internal semantic precondition; it is not a raw-input validator.', 'Generated bindings must be regenerated to opt in; old bindings and handwritten implementations preserve the checked fallback.', 'Collection-time file hashes precede root integration formatting/commit; final validation must bind the final committed source.'])
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(dict(groups=len(passes),source_files=len(manifest),passed=True)))
