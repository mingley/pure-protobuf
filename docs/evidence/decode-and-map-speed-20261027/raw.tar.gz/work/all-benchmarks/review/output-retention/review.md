# Output-retention prototype review

Scope: read-only inspection of the isolated `output-prototype-source` overlay
against production source 71422f00. No production or test files were changed.

## Blockers

1. **Unrestricted identity codecs can introduce an untracked backing.**
   `SegSink::write_contiguous` passes `&mut BytesMut` to the serializer. A
   serializer can preserve the existing header and append valid payload bytes
   while replacing that buffer with a suffix of an 8 MiB allocation. Dropping
   the prefix leaves the suffix uniquely owned but does not make its exposed
   `capacity()` equal the full underlying allocation until reclamation.
   `take_reusing` can then charge roughly 1 MiB and retain an 8 MiB allocation,
   exceeding both the per-buffer policy and aggregate idle-accounting claim.
   The `ENCODE_APPEND_ONLY` capability protects `encode_payload_bufmut`, not the
   `encode_payload` callback currently used for identity framing.

   A minimal fix is compressed-only output retention, with a batch eligibility
   flag that is cleared by any identity frame. Compressed output is produced by
   the transport's own writer. A broader design needs an append-only API that
   cannot replace, split or retain the framed buffer. Merely checking the
   existing capability while calling `encode_payload` is insufficient.

2. **Error/unwind can leave an empty large tail without its idle lease.**
   `prepare_encode` drops the lease. An encode-limit or codec failure can then
   roll back to an empty checkpoint while keeping the mutable tail and a
   `RetainedHead` whose lease is `None`. `take_frame`/`flush` skip empty output,
   so this state is never recharged. Caught panics have the same problem.

   Empty error-state output should be discarded or explicitly recharged. A
   move-out encoding guard, analogous to `EncodeScratch::with_payload`, should
   own the active sink during arbitrary codec/compressor execution; unwinding
   then drops it while the batch holds an empty replacement. Existing complete
   frames should remain available on ordinary `Result::Err` rollback.

## Checks that look sound

- `split_to(length).freeze()` preserves immutable output; later writes target
  the disjoint spare tail, and `BytesMut::reserve` may reclaim only when unique.
- Charging `max(previous_full_capacity, current_capacity)` is conservative for
  allocations created and split exclusively by the transport.
- The shared 16 MiB budget and 4 MiB cap are reused by output and plaintext.
- Normal sink drop order frees `head` before releasing its output lease.
- Segmented output falls back to the old finish path, retaining no mutable tail.

## Needed regression cases

- A custom identity contiguous serializer that substitutes a small suffix of
  an oversized backing; output must remain valid and no idle tail retained.
- Warm retained output followed by encode-cap failure, ordinary codec error,
  codec panic and compressor panic; no uncharged empty large buffer may remain.
- Prior complete output followed by an error still flushes exactly those
  complete frames.
- A previous immutable frame held while encoding the next one keeps its bytes
  and header intact, including shared-segment and cancellation/drop paths.
- Idle accounting samples use full capacities, and mixed plaintext/output
  leases share the existing aggregate budget.

No throughput or allocation improvement is established by this review.

## Variant C follow-up

The separate `guarded-output-source` snapshot resolves both blockers. Its
compressed-only condition gates acquisition; identity attempts invalidate that
eligibility before any user callback, and rollback does not restore it. The
move-out `SinkEncodeGuard` owns the sink before `encoded_len`, limits, codecs,
compression and logging. Failed/aborted encodes discard scratch, roll back the
message and restore only prior nonempty complete output. Empty tails are
therefore dropped rather than left uncharged.

The receive adjustment calls `try_reclaim(frame_len)` before replacing an
empty carry buffer. Standard `BytesMut` ownership prevents reclaim while a
previous immutable frame remains shared; disjoint writable spare tail is also
safe. Only a validated, observed-half-frame claim can trigger fresh allocation.

The reviewed C snapshot passes 69 wire tests and strict all-feature library
Clippy. Controls include a valid identity encoder using an 8 MiB suffix with
both append-capability values, success and failed mixed batches, warmed output
errors/panics, preservation of prior complete frames, and retained immutable
frame bytes. Exact source hashes are in `c-source-sha256.json`.

No further correctness blockers were found in this C snapshot. Actual RPC
performance and allocation outcomes remain separate acceptance gates. This
review does not treat the unsafe B retention path as shippable.
