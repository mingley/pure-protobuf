# Final C adoption checks

Read-only review during benchmark CPU quiet. The three wire files in
`measurement/phase5-source` match the previously reviewed C hashes exactly.
No production, frozen source, or test files were changed by this review.

Before adoption:

- Complete the shipping CPU/default matrix and inspect every endpoint/control,
  including identity holdouts. Unit allocation wins alone are insufficient.
- Preserve the independent end-to-end allocation comparison and full original
  capacity accounting. Do not generalize the 16 MiB cache budget into a total
  memory or RSS bound; active output and application messages are separate.
- Copy the independent `output_workspace.rs` as an auto-discovered native
  integration test under its existing `prost` + `copy-counts` gate. Required
  dependencies already exist in the native crate.
- Add a per-message nonce or changing PRNG seed, and compare nonce plus length
  at the peer. Reusing the same noise for consecutive equal-size messages can
  conceal a stale-frame error.
- Add one large native server-streaming/bidi response lifecycle with successful
  closure and cancellation. The existing fixture covers upload ownership;
  server drain has different asynchronous error/flush paths.
- Keep process-wide counter assertions in one `current_thread` test. This avoids
  independent tests racing while sampling aggregate retention gauges.
- Format the copied fixture and run targeted strict Clippy with both features.
  Run the 69 wire tests and the independent compression negotiation/decode
  lifetime tests on the adopted production files.
- Check Rust 1.85 for native and Tower library profiles, and rerun mixed-peer
  interoperability. Core/codegen inputs remain unchanged by this three-file
  transport adoption; record that equivalence explicitly in final provenance.

The existing fixture covers all decompressed bytes, multiple sizes, oversized
buffers, aggregate cache exhaustion, deadlines, cancellation, successful
recovery and final zero retained leases. It checks bounded retention and
ownership; deterministic low-level pointer tests and the complete allocation
campaign establish actual reuse. The warmed suffix/error/panic cases already
covered by the wire units need not be duplicated as network tests.
