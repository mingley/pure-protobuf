# Reconstruct the comparisons

Start from baseline 0287879dcfe381424cf9aabc919d9fea700dbe39 in a disposable checkout. Either
apply source/implementation.patch once, or apply the ordered stage patches
core-implementation.patch, codegen-timer-fix.patch and selected-d.patch.
Do not apply both routes. The selected-d directory also contains all three
exact measured wire files and the committed permanent noise/budget test.
The ci directory retains both the standard and parity workflows.

Under work/all-benchmarks/measurement, reconstruct_variant.py and
source-overlays/manifest.json retain the Git export paths, exact overlays and
full input hashes for baseline,
71422, rejected phase2, framer A, unmeasured B, rejected identity-reserving C
and adopted compressed-only D snapshots.
Follow each frozen build record, lockfile and harness. A later source manifest
does not silently rebind an earlier campaign. Leave an installed third_party
SDK out of ordinary codec exports: its presence changes build.rs descriptor
inputs. Isolated official conformance explicitly uses the pinned upstream SDK.

The canonical generator uses debug builds; matched release is a separate
profile. Corrected d66 timing blocks for process completion with a watchdog
and stamps elapsed time before sampler teardown. Polling-biased originals,
counterfactuals and negative timer tests are retained but not selected.
Instrumented allocation clocks are not shipping timings. CPU and allocation
binaries are separate. Downstream consumer compilation is a separate axis.

Original low-count identity CPU records survive alongside the separate
higher-count resolution confirmation; confirmation does not replace them.
C identity reservations are rejected after their higher-count CPU loss. D
restores 71422 identity-framer growth while retaining compressed-only changes.
Aborted compressed campaigns, allocator-support setup failures, A/B/C/D
iterations and selected/rejected prototypes remain identifiable by path.
The rejected Wire-tag layout prototype was removed after null-Arc failures;
its exact original source was not snapshotted, so logs support the stated
cause rather than providing a portable isolated source replay. Selected code
retains the original Wire representation and an explicit lazy flag.

The old full 26-gate validation and owned conformance apply to71422. The final
validation report names the adopted compressed-only D source and states its exact checks and
reuse. Source provenance verifies unchanged core source and exact selected wire, timer,
CI and permanent-test hashes. Consult those scopes before combining rows.

Executables, tool installations, caches, duplicate full source snapshots and
representative generated-output copies are omitted. Manifests retain output
names, sizes and hashes; retained inputs/drivers regenerate them. Build elapsed
time alone is not a comparative generator benchmark.
