import hashlib,json,os,re,shutil,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');SOURCE=ROOT/'work/dispatch-candidate';OUTPUT=ROOT/'work/dispatch-sequential-gates';OUTPUT.mkdir(exist_ok=False)
PIN='f8517b53fefaa70866f19ec4896d46254f812b4e'
def git(*args):return subprocess.check_output(['git',*args],cwd=SOURCE,text=True).strip()
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024**2),b''):h.update(b)
 return h.hexdigest()
def clean():assert git('rev-parse','HEAD')==PIN and not git('status','--porcelain','--untracked-files=all')
clean();shutil.copy2(__file__,OUTPUT/'controller.py')
targets=['lib']+[p.stem for p in sorted((SOURCE/'pbrs-grpc/tests').glob('*.rs'))]
report=dict(source=PIN,qualified=False,targets=targets,results=[],limits=['sequential continuation of interrupted aggregate build; no timing or production qualification'])
for name in targets:
 args=['cargo','test','--locked','-p','pbrs-grpc','--all-features',*(['--lib'] if name=='lib' else ['--test',name]),'--message-format=json']
 directory=OUTPUT/name;directory.mkdir();start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:
  result=subprocess.run([str(ROOT/'work/run-rust'),*args],cwd=SOURCE,stdout=out,stderr=err)
 record=dict(command=args,exit_code=result.returncode,elapsed_seconds=time.monotonic()-start)
 artifacts=[]
 for line in (directory/'stdout').read_text().splitlines():
  try:m=json.loads(line)
  except json.JSONDecodeError:continue
  if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(SOURCE/'pbrs-grpc/Cargo.toml') and m.get('target',{}).get('name')==('pbrs_grpc' if name=='lib' else name) and m.get('executable') and m.get('profile',{}).get('test') is True:artifacts.append(m)
 if len(artifacts)==1:
  artifact=artifacts[0];p=Path(artifact['executable']);record['artifact']=artifact
  record['executable_sha256']=sha(p);record['executable_bytes']=p.stat().st_size
  if result.returncode:
   shutil.copy2(p,directory/'failed-test')
  p.unlink();record['inactive_executable_cache_removed']=True
 else:record['artifact_error']='expected one compiler-selected test executable'
 clean();record['source_unchanged']=True
 if name!='lib':
  active=[]
  for proc in Path('/proc').iterdir():
   if proc.name.isdigit():
    try:active.extend(a.decode().split('incremental=',1)[1] for a in (proc/'cmdline').read_bytes().split(b'\0') if a.startswith(b'incremental='))
    except OSError:pass
  record['inactive_incremental_caches_removed']=[]
  for p in (ROOT/'work/target/debug/incremental').glob(name+'-*'):
   if p.is_dir() and str(p) not in active:
    size=sum(f.stat().st_size for f in p.rglob('*') if f.is_file());shutil.rmtree(p);record['inactive_incremental_caches_removed'].append(dict(path=str(p),bytes=size))
 report['results'].append(record);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
 print(name,result.returncode,flush=True)
 if result.returncode:break
report['state']='finished';report['passed']=len(report['results'])==len(targets) and all(r['exit_code']==0 and 'artifact_error' not in r for r in report['results']);(OUTPUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
