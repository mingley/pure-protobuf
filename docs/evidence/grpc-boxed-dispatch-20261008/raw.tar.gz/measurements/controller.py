"""Build a frozen benchmark, retain endpoint captures, and publish to main."""
import argparse
import gzip
import hashlib
import importlib.util
import io
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import subprocess
import tarfile
import time
from types import SimpleNamespace


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run(argv, cwd, output, name):
    start = time.time()
    with (output / (name + '.stdout')).open('w') as stdout, (output / (name + '.stderr')).open('w') as stderr:
        result = subprocess.run(argv, cwd=cwd, stdout=stdout, stderr=stderr, check=False)
    return {'command': list(map(str, argv)), 'exit_code': result.returncode,
            'elapsed_seconds': time.time() - start}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source', required=True)
    p.add_argument('--source-dir', type=Path, required=True)
    p.add_argument('--root', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--evidence-path', type=Path, required=True)
    p.add_argument('--valgrind', type=Path, required=True)
    args = p.parse_args()
    source, root, output = args.source_dir.resolve(), args.root.resolve(), args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, output / 'controller.py')
    state = {'source': args.source, 'state': 'building', 'qualified': False, 'commands': []}
    concurrent = root / 'work/campaign-v5-005/controller-status.json'
    if concurrent.is_file():
        state['concurrent_resource_campaign_at_start'] = json.loads(concurrent.read_text())

    def save():
        (output / 'controller-status.json').write_text(json.dumps(state, indent=2) + '\n')

    def execute(argv, name):
        state['state'] = name
        save()
        result = run(argv, source, output, name)
        state['commands'].append(result)
        save()
        return result['exit_code']

    build = root / 'work/dispatch-benchmark/build'
    state['state'] = 'waiting_for_frozen_build'
    save()
    waiting_until = time.monotonic() + 1800
    while not (build / 'build.json').exists():
        builder_pid = int((root / 'work/readiness/dispatch-build.pid').read_text())
        process = Path(f'/proc/{builder_pid}/stat')
        if not process.exists() or process.read_text().split(') ', 1)[1].startswith('Z ') or time.monotonic() > waiting_until:
            state['state'] = 'build_failed'; save()
            return
        time.sleep(1)
    spec = importlib.util.spec_from_file_location('builder', source / 'scripts/build-rpc-bench.py')
    builder = importlib.util.module_from_spec(spec); spec.loader.exec_module(builder)
    builder.validate_record(build / 'build.json', build / 'rpc-bench')
    state['frozen_build_record'] = json.loads((build / 'build.json').read_text())
    ok = True
    if ok:
        binary = build / 'rpc-bench'
        functional = output / 'functional'
        execute(['python3', str(source / 'scripts/grpc-load-smoke.py'), '--binary', str(binary),
                 '--build-record', str(build / 'build.json'), '--output', str(functional),
                 '--rpc-count', '20', '--duration', '60', '--allocation-counts', '--context-switches',
                 '--load-levels', '1:1,1:16', '--seed', '20261008'], 'functional')
        # N/2N OS counters run without Callgrind. Instrumented process context
        # switches describe Valgrind's scheduling and cannot replace these rows.
        spec = importlib.util.spec_from_file_location('smoke', source / 'scripts/grpc-load-smoke.py')
        smoke = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(smoke)
        pairs = [['native', 'pbrs', 'tonic', 'prost'], ['native', 'prost', 'tonic', 'prost'],
                 ['tonic', 'prost', 'native', 'pbrs'], ['tonic', 'prost', 'native', 'prost'],
                 ['tonic', 'prost', 'tonic', 'prost']]
        cells = [dict(pair=pair, shape=shape, payload_bytes=1024, tls=False, compression='identity',
                      connections=1, in_flight=1, repeat=repeat)
                 for pair, shape, repeat in itertools.product(pairs, smoke.SHAPES, range(3))]
        random.Random(20261008).shuffle(cells)
        for instrumented in (False, True):
            captures = []
            for n in (200, 400):
                label = f'{"callgrind" if instrumented else "native-counters"}-{n}'
                state['state'] = label
                save()
                directory = output / label
                directory.mkdir()
                captures.append(directory)
                build_record = smoke.verified_build(build / 'build.json', binary)
                settings = SimpleNamespace(binary=binary, duration=60, rpc_count=n, allocation_counts=True,
                                           context_switches=not instrumented,
                                           callgrind=args.valgrind if instrumented else None)
                report = dict(schema='pbrs.load-smoke.v2', binary_sha256=sha(binary),
                              harness_script_sha256=sha(source/'scripts/grpc-load-smoke.py'),
                              harness_head=args.source,harness_dirty=False,
                              head=args.source, dirty=False, source_verified=True, build_record=build_record,
                              host=platform.uname()._asdict(), cpu_affinity=sorted(os.sched_getaffinity(0)),
                              seed=20261008, cells=cells, rpc_count=n, duration_per_cell_seconds=60,
                              allocation_counts=True, context_switches=not instrumented,
                              callgrind=str(args.valgrind) if instrumented else None,
                              qualification={'qualified': False, 'limits': [
                                  'shared host; no dedicated timing, headroom or noise qualification',
                                  'resource campaign may run concurrently; no isolated-host attribution',
                                  'one KiB h2c identity at concurrency one; no read-all corpus or saturation',
                                  'process totals include setup; OS switches do not measure task wakes',
                                  'Callgrind captures are separate from native OS scheduling counters']}, runs=[])
                shutil.copy2(source/'scripts/grpc-load-smoke.py',directory/'harness.py')
                (directory / 'manifest.json').write_text(json.dumps(report, indent=2) + '\n')
                for i, cell in enumerate(cells):
                    cell_dir = directory / f'cell-{i:03d}'
                    result = smoke.run_cell(settings, cell, cell_dir)
                    report['runs'].append({'path': f'cell-{i:03d}/run.json', 'passed': result['passed']})
                    for profile in cell_dir.glob('*.callgrind'):
                        with profile.open('rb') as original, gzip.open(str(profile) + '.gz', 'wb') as compressed:
                            shutil.copyfileobj(original, compressed)
                        profile.unlink()
                    print(f'{label}: {i + 1}/{len(cells)} {result["passed"]}', flush=True)
                report['binary_unchanged'] = report['binary_sha256'] == sha(binary)
                try:
                    smoke.verified_build(build / 'build.json', binary)
                    report['source_unchanged'] = True
                except (OSError, ValueError, subprocess.CalledProcessError) as error:
                    report['source_unchanged'] = False
                    report['source_error'] = str(error)
                report['harness_script_unchanged'] = report['harness_script_sha256'] == sha(source/'scripts/grpc-load-smoke.py')
                report['passed'] = report['harness_script_unchanged'] and report['binary_unchanged'] and report['source_unchanged'] and all(r['passed'] for r in report['runs'])
                (directory / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
            execute(['python3', str(source / 'scripts/dominance-ledger.py'), '--small', str(captures[0]),
                     '--large', str(captures[1]), '--output', str(output / ('callgrind-ledger' if instrumented else 'native-ledger')),
                     '--allow-partial', '--allow-failed-captures'], 'ledger-callgrind' if instrumented else 'ledger-native')
    state['state'] = 'finished'
    save()


if __name__ == '__main__':
    main()
