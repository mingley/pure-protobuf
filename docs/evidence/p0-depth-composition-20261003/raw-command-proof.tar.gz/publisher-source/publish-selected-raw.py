#!/usr/bin/env python3
"""WORK ONLY SOURCE: selected P0 raw capsule; requires complete reviewed results and a later publication grant."""
import argparse
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import subprocess
import sys
import tarfile
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
ORIGINAL = ROOT / 'work/p0-depth-composition-preparation-001'
CONTINUATION = ROOT / 'work/p0-depth-continuation-preparation-005'
FINAL_MAP = ROOT / 'work/p0-depth-continuation-preparation-007'
FINAL_MAP_READINESS_SHA = 'f38388f6dbfc79d53ed19f25dc9c7a548515ac8024193ecff6bd8b873ba4f43d'
FINAL_MAP_RUNNER_SHA = 'bd6b15a65d3b9a192a6afd296ce7d784c4c57e2eb3eaafe23bba57039979fbb2'
FINAL_MAP_HELPER = ORIGINAL / 'shared_map_consumer-accepted-007.py'
FINAL_MAP_HELPER_SHA = '0c7858ce04efd7fe4a583af8424d7e2ecf18e772dcfa4992be16651b51373d2c'
FINAL_MAP_GATE_PLAN = FINAL_MAP / 'derived-map-plan.json'
CONTINUATION_SHA = 'c43f73c3991e63541bdfe22429a49e6d02991eadd9714b8785360d374232a76a'
RUNNER_SHA = 'fa467db13260324ae0bde5beb87ad126902441431b8bc659d82774d372dbc58a'
SOURCE = '68e4d57d67c73ff87ea1404bee18c3c70a9dfb93'
ROOT_AUDIT = Path('/workspace/pure-protobuf/work/qualification/root-p0-linked-native-reconciliation.json')
ROOT_AUDIT_SHA = '6042feab22a494dbf409b5395c2581d84c7629d22df91cdf5805d4807220703a'
ROOT_AUDITOR = Path('/workspace/pure-protobuf/work/qualification/reconcile-p0-linked-output-delta.py')
ROOT_AUDITOR_SHA = '848fad6ae5611c1f1a94b81ff38bedd607a9eec8f4508c36e913ce3f799ee47f'
GROUP_AUDIT = Path('/workspace/pure-protobuf/work/qualification/root-p0-group9-native-reconciliation.json')
GROUP_AUDIT_SHA = '6bf816c217e153d80fda93a0feab98eed60d4287c35578bbbcb2d1942e5f1595'
LINKED_RECORD_SHA = 'b497a26618ae6f3b563109f822a2aa50e073fdf86bcb347b7bde1aa7050cf0ab'
LIMIT = 2147483648
MARGIN = 16777216
PAYLOAD_LIMIT = 128 * 1024 * 1024
NATIVE = ['feature-off185-001', 'core185-001', 'combined-default188-002', 'strict-root188-002',
          'linked-upstream188-001', 'strict-consumer188-001', 'plugin-setup188-001',
          'genuine-regen-001', 'group-shared-001', 'map-shared-002']
RAW = {'record.json', 'stdout', 'stderr', 'exit', 'samples.jsonl', 'prelaunch.json',
       'generate.stdout', 'generate.stderr', 'protoc-version.stdout', 'protoc-version.stderr'}
SCOPE = ('Full selected command records/raw output/samples/prelaunch, frozen driver/config/fixture bytes and historical failures. '
         'Two original greens, combined002 and strict002 greens in failed outer runs, ROOT-qualified linked native0/outer126 and four green native records from failed005 plus corrected final map007 qualify the combined 68e4d source only. Focused and broad executions overlap. '
         'Compiler/test ELFs, SDK/schema/generated-source payload closure and selected-artifact payload carriers remain separate local proofs; '
         'their JSON references are included but their binary/payload trees are not included. No performance or complete linker/native closure claim.')
LAST_CACHE_SAMPLE = 0


def require(value, message):
    if not value:
        raise RuntimeError(message)


def guard(pending=0):
    global LAST_CACHE_SAMPLE
    space = os.statvfs('/workspace')
    free = space.f_bavail * space.f_frsize
    require(free >= LIMIT + MARGIN + pending, 'fixed 2GiB free floor/write margin breached')
    now = time.monotonic()
    if now - LAST_CACHE_SAMPLE >= 2:
        cache = ROOT / 'target'
        if cache.exists():
            observed = subprocess.run(['du', '-sb', str(cache)], capture_output=True, text=True, timeout=10)
            require(observed.returncode == 0 and int(observed.stdout.split()[0]) <= LIMIT, 'aggregate owned cache accounting/cap failed')
        LAST_CACHE_SAMPLE = now
    return free


class GuardedOutput:
    def __init__(self, stream):
        self.stream = stream

    def write(self, data):
        guard(len(data))
        count = self.stream.write(data)
        self.stream.flush()
        guard()
        return count

    def flush(self):
        self.stream.flush()


def identity(path):
    st = path.lstat()
    return {key: getattr(st, key) for key in ('st_dev', 'st_ino', 'st_mode', 'st_nlink', 'st_size', 'st_mtime_ns', 'st_ctime_ns', 'st_uid', 'st_gid')}


def digest(path):
    before = identity(path)
    require(stat.S_ISREG(before['st_mode']), 'selected payload is not a regular file')
    value = hashlib.sha256()
    with path.open('rb') as stream:
        require(identity(path) == before, 'selected input changed before hashing')
        for data in iter(lambda: stream.read(1048576), b''):
            guard()
            value.update(data)
    require(identity(path) == before, 'selected input changed during hashing')
    return value.hexdigest()


def source_seal(approved):
    require(digest(HERE / 'readiness.json') == approved, 'literal approved publisher readiness changed')
    value = json.loads((HERE / 'readiness.json').read_text())
    require(value['status'] == 'SOURCE_READY_PUBLISHER_NOT_RUN' and value['source'] == SOURCE, 'publisher scope differs')
    require(all(digest(HERE / name) == pin for name, pin in value['components'].items()), 'publisher components changed')
    require(digest(CONTINUATION / 'readiness.json') == CONTINUATION_SHA
            and digest(CONTINUATION / 'resume-native.py') == RUNNER_SHA
            and digest(FINAL_MAP / 'readiness.json') == FINAL_MAP_READINESS_SHA
            and digest(FINAL_MAP / 'resume-native.py') == FINAL_MAP_RUNNER_SHA
            and digest(FINAL_MAP_HELPER) == FINAL_MAP_HELPER_SHA, 'reviewed continuations changed')
    require(digest(ROOT_AUDIT) == ROOT_AUDIT_SHA and digest(ROOT_AUDITOR) == ROOT_AUDITOR_SHA
            and digest(GROUP_AUDIT) == GROUP_AUDIT_SHA, 'literal independent qualifications changed')


def qualified_linked(resumed, path, step, plan):
    require(digest(path) == LINKED_RECORD_SHA and digest(ROOT_AUDIT) == ROOT_AUDIT_SHA
            and digest(ROOT_AUDITOR) == ROOT_AUDITOR_SHA, 'literal original linked record/root audit/script differs')
    audit = json.loads(ROOT_AUDIT.read_text())
    native = json.loads(path.read_text())
    require(audit['status'] == 'PASS_NATIVE_WITH_EXPECTED_GENERATED_OUTPUT_DELTA' and audit['source'] == SOURCE
            and audit['original_gate_record'] == str(path) and audit['original_gate_record_sha256'] == LINKED_RECORD_SHA
            and audit['original_native_exit'] == native['native_exit'] == 0
            and audit['original_wrapper_exit'] == native['exit'] == 126
            and audit['all230_original_files_fullhash_unchanged'] is True and len(audit['exact117_additions']) == 117
            and audit['mods_reconstructed_byte_exact'] is True
            and audit['original_resources_cleanup_source_tools_helpers_SDK_unchanged'] is True,
            'bounded linked qualification/native-harness split differs')
    require(native['drift'] == audit['original_harness_drift_retained'] == 'standalone source/manifest/lock changed during direct consumer command'
            and native['guard'] is None and native['argv'] == step['argv'] and native['timeout_seconds'] == 900
            and native['plan_sha256'] == digest(resumed.old.PLAN) and native['runner_sha256'] == digest(ORIGINAL / 'gate.py')
            and native['source_before']['commit'] == SOURCE and native['source_before']['status'] == ''
            and all(native[key + '_before'] == native[key + '_after'] for key in ('source', 'tools', 'work_helpers', 'helper_closure'))
            and not any(native.get(key) for key in ('exception', 'cleanup_exception', 'post_cleanup_observation_exception'))
            and not native['processes_after_cleanup']['observed'] and not native['processes_after_cleanup']['inaccessible_pids']
            and native['minimum_free'] >= LIMIT and native['maximum_owned_apparent_bytes'] <= LIMIT,
            'linked actual argv/source/guards/cleanup differs')
    require(audit['native_proof'] == resumed.old.native_details(step, path.parent, plan), 'literal root native semantic/protoc proof differs')
    return native


def completed_results(approved):
    source_seal(approved)
    spec = importlib.util.spec_from_file_location('p0_reviewed_final_map', FINAL_MAP / 'resume-native.py')
    final = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(final)
    # The final verifier owns the reviewed original230-file state transitions.
    final_args = argparse.Namespace(readiness_sha256=FINAL_MAP_READINESS_SHA)
    plan, continuation = final.verify(final_args, map_after=True)
    map_gate_plan = json.loads(FINAL_MAP_GATE_PLAN.read_text())
    expected_plan = json.loads((ORIGINAL / 'composition-plan.json').read_text())
    expected_map = expected_plan['steps'][9]
    expected_map['argv'][2] = str(ORIGINAL / 'shared_map_consumer-accepted-007.py')
    expected_map['argv'][expected_map['argv'].index('--attempt') + 1] = 'map-shared-payload-002'
    expected_plan['steps'] = [expected_map]
    require(plan['source'] == SOURCE and map_gate_plan == expected_plan
            and continuation['steps'] == [expected_map], 'derived map plan has undeclared semantic changes')
    spec = importlib.util.spec_from_file_location('p0_reviewed_retained_five', CONTINUATION / 'resume-native.py')
    resumed = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(resumed)
    resumed.authenticate_history(plan)
    record_path = ORIGINAL / 'native-execution/execution-007/record.json'
    record = json.loads(record_path.read_text())
    require(record['status'] == 'passed' and record['source'] == SOURCE
            and record['readiness_sha256'] == FINAL_MAP_READINESS_SHA
            and [row['name'] for row in record['rows']] == ['map-shared'], 'final map incomplete')
    prefix_path = ORIGINAL / 'native-execution/execution-005/record.json'
    prefix = json.loads(prefix_path.read_text())
    require(prefix['status'] == 'failed_or_incomplete' and prefix['source'] == SOURCE
            and prefix['readiness_sha256'] == CONTINUATION_SHA
            and [row['name'] for row in prefix['rows']] == [step['name'] for step in plan['steps'][5:9]]
            and prefix['error']['message'] == 'qualified original/output payload changed: work/p0-depth-composition-preparation-001/consumers/group-shared/src/lib.rs',
            'fifth failed parent/expected fixture transition history differs')
    for index, dirname in enumerate(NATIVE):
        path = ORIGINAL / 'qualification' / dirname / 'record.json'
        step = map_gate_plan['steps'][0] if index == 9 else plan['steps'][index]
        require(dirname.rsplit('-', 1)[0] == step['name'], 'ten gate order/source labels differ')
        if step['name'] == 'linked-upstream188':
            qualified_linked(resumed, path, step, plan)
        elif step['name'] == 'strict-consumer188':
            resumed.finished_strict(path, step, resumed.old.PLAN)
        else:
            resumed.old.finished_native(path, step, FINAL_MAP_GATE_PLAN if index == 9 else resumed.old.PLAN)
        proof = ({'map-shared': resumed.old.child_proof(next(case for case in plan['cases'] if case['label'] == 'map-shared'),
                    ORIGINAL / 'qualification/map-shared-payload-002/cargo')} if index == 9
                 else resumed.old.native_details(step, path.parent, plan))
        if 5 <= index < 8:
            row = prefix['rows'][index - 5]
            require(row['wrapper_exit'] == row['native_exit'] == 0 and row['gate_record_sha256'] == digest(path)
                    and row['proof'] == proof, 'retained fifth-parent green row differs')
        elif index == 8:
            # The finally verifier failed before filling this green row's hashes/proof.
            # Keep that row unchanged and qualify the immutable actual gate/child raw.
            row = prefix['rows'][3]
            audit = json.loads(GROUP_AUDIT.read_text())
            require(row['wrapper_exit'] == 0 and digest(path) == audit['original_gate_record_sha256']
                    == '2c10de5d794b5b291efcfe931a738594374993673141dc61b1a273c46ca2c96b'
                    and audit['status'] == 'PASS_NATIVE_GROUP9_WITH_EXPECTED_HELPER_FIXTURE_TRANSITION'
                    and audit['source'] == SOURCE and audit['native_exit'] == audit['wrapper_exit'] == 0
                    and audit['failed_coordinator_record_sha256'] == digest(prefix_path)
                    and audit['failed_coordinator_status_retained'] == prefix['status']
                    and audit['actual_parent_launch_row'] == row and audit['proof'] == proof
                    and audit['other229_original_files_fullhash_unchanged'] is True
                    and audit['original_finished_native_read_only'] is True, 'literal independently qualified group9 differs')
        elif index == 9:
            row = record['rows'][0]
            require(row['wrapper_exit'] == row['native_exit'] == 0 and row['gate_record_sha256'] == digest(path)
                    and row['proof'] == proof, 'final map actual native identity/proof differs')
    second = json.loads((ORIGINAL / 'native-execution/execution-002/record.json').read_text())
    require(second['status'] == 'failed_or_incomplete', 'second stopped parent was relabelled')
    combined = next(row for row in second['rows'] if row['name'] == 'combined-default188')
    combined_path = ORIGINAL / 'qualification/combined-default188-002/record.json'
    require(combined['wrapper_exit'] == combined['native_exit'] == 0 and combined['gate_record_sha256'] == digest(combined_path)
            and combined['proof'] == resumed.old.native_details(plan['steps'][2], combined_path.parent, plan), 'retained combined002 green differs')
    prior = json.loads((ORIGINAL / 'native-execution/execution-003/record.json').read_text())
    require(prior['status'] == 'failed_or_incomplete' and [row['name'] for row in prior['rows']] == ['strict-root188', 'linked-upstream188'], 'third failed parent history differs')
    strict_row, linked_row = prior['rows']
    require(strict_row['wrapper_exit'] == strict_row['native_exit'] == 0
            and strict_row['gate_record_sha256'] == digest(ORIGINAL / 'qualification/strict-root188-002/record.json'), 'retained strict002 green differs')
    require(linked_row['wrapper_exit'] == 126 and linked_row['gate_record_sha256'] == LINKED_RECORD_SHA, 'third parent linked126 was relabelled')
    failed_preserver = json.loads((ORIGINAL / 'native-execution/execution-004/record.json').read_text())
    require(failed_preserver['status'] == 'failed_or_incomplete' and failed_preserver['rows'] == []
            and failed_preserver['first_selected_preservation']['wrapper_exit'] == 1, 'failed fourth-parent preservation was relabelled')
    failed_map_parent = json.loads((ORIGINAL / 'native-execution/execution-006/record.json').read_text())
    failed_map_path = ORIGINAL / 'qualification/map-shared-001/record.json'
    failed_map = json.loads(failed_map_path.read_text())
    require(failed_map_parent['status'] == 'failed_or_incomplete'
            and [row['name'] for row in failed_map_parent['rows']] == ['map-shared']
            and failed_map_parent['rows'][0]['wrapper_exit'] == 1
            and failed_map['native_exit'] == failed_map['exit'] == 1
            and failed_map['argv'] == plan['steps'][9]['argv']
            and failed_map['source_before']['commit'] == SOURCE
            and "KeyError: 'accepted_record'" in failed_map_path.with_name('stderr').read_text(),
            'original failed map helper/parent was relabelled')
    for step in plan['metadata_steps']:
        path = ORIGINAL / 'qualification' / (step['name'] + '-001') / 'record.json'
        resumed.old.finished_native(path, step, resumed.old.METADATA_PLAN)
    linked = prefix['first_selected_preservation']
    require(linked['wrapper_exit'] == 0 and digest(Path(linked['gate_record'])) == linked['gate_record_sha256'], 'excluded FULL linked carrier gate missing')
    post_plan = CONTINUATION / 'postprocess-reconciled-plan.json'
    resumed.old.finished_native(Path(linked['gate_record']), json.loads(post_plan.read_text())['steps'][0], post_plan)
    retained_path = ORIGINAL / 'qualification/linked-upstream-selected-payload-002/record.json'
    retained = json.loads(retained_path.read_text())
    require(retained['status'] == 'complete; all copied member hashes rechecked'
            and retained['selected_provider_test_artifacts'] and retained['root_reconciliation']['sha256'] == ROOT_AUDIT_SHA
            and digest(retained_path) == linked['payload_record_sha256'] == '158ff1f30cae65bfb54b41050411ad1670a0f1f75fadb5dadbc08e416dcd6579',
            'excluded FULL linked artifact retention differs')
    return resumed, plan, record


def inputs(plan):
    selected = {}

    def add(member, path, role):
        path = Path(path)
        require(member not in selected and not path.is_symlink()
                and (path.resolve().is_relative_to(ROOT) or path in {ROOT_AUDIT, ROOT_AUDITOR, GROUP_AUDIT}), 'duplicate/path escape/symlink selected member')
        info = identity(path)
        require(stat.S_ISREG(info['st_mode']), 'selected member not regular')
        with path.open('rb') as stream:
            require(stream.read(4) != b'\x7fELF', 'ELF payload outside selected raw scope')
        selected[member] = {'path': path, 'role': role, 'identity': info}

    def raw_tree(label, folder):
        folder = Path(folder)
        require(folder.is_dir() and not folder.is_symlink(), 'missing selected raw context ' + label)
        for path in sorted(folder.rglob('*')):
            rel = path.relative_to(folder)
            if path.is_dir():
                continue
            if path.name in RAW or path.name.endswith(('.stdout', '.stderr')) or 'source-snapshot' in rel.parts:
                add('commands/' + label + '/' + str(rel), path, 'command_or_source_snapshot')

    for dirname in NATIVE + ['combined-default188-001', 'strict-root188-001', 'default188-source-setup-001', 'linked-upstream-selected-preservation-001', 'linked-upstream-selected-preservation-002', 'map-shared-001']:
        raw_tree(dirname, ORIGINAL / 'qualification' / dirname)
    failed_map_parent = json.loads((ORIGINAL / 'native-execution/execution-006/record.json').read_text())
    failed_map_path = ORIGINAL / 'qualification/map-shared-001/record.json'
    failed_map = json.loads(failed_map_path.read_text())
    require(failed_map_parent['status'] == 'failed_or_incomplete'
            and [row['name'] for row in failed_map_parent['rows']] == ['map-shared']
            and failed_map_parent['rows'][0]['wrapper_exit'] == 1
            and failed_map['native_exit'] == failed_map['exit'] == 1
            and failed_map['argv'] == plan['steps'][9]['argv']
            and failed_map['source_before']['commit'] == SOURCE
            and "KeyError: 'accepted_record'" in failed_map_path.with_name('stderr').read_text(),
            'original failed map helper/parent was relabelled')
    for step in plan['metadata_steps']:
        raw_tree(step['name'] + '-001', ORIGINAL / 'qualification' / (step['name'] + '-001'))
    for label in ('genuine-regen', 'group-shared', 'map-shared'):
        payload = label + ('-payload-002' if label == 'map-shared' else '-payload-001')
        raw_tree(payload, ORIGINAL / 'qualification' / payload)
    raw_tree('map-shared-payload-001', ORIGINAL / 'qualification/map-shared-payload-001')
    for label in ('group', 'map'):
        case = next(case for case in plan['cases'] if case['label'] == label)
        raw_tree(label + '-child', case['consumer'])
    for number in ('001', '002', '003', '004', '005', '006', '007'):
        folder = ROOT / ('work/p0-depth-continuation-preparation-' + number)
        for path in sorted(folder.iterdir()):
            if path.is_file():
                add('continuation-' + number + '/' + path.name, path, 'additive_source_history')
    for number in ('001', '002', '003', '004', '005', '006', '007'):
        raw_tree('outer-native-' + number, ORIGINAL / 'native-execution' / ('execution-' + number))
    for name in json.loads((ORIGINAL / 'readiness.json').read_text())['components']:
        add('original-source/' + name, ORIGINAL / name, 'original_frozen_driver')
    add('original-source/shared_map_consumer-accepted-007.py', ORIGINAL / 'shared_map_consumer-accepted-007.py', 'actual_corrected_map_helper')
    for name in ('artifact-source-proof.json', 'proof-assets/selected-assets-manifest.json', 'proof-assets/preservation-record.json'):
        path = ORIGINAL / name
        if path.is_file():
            add('local-payload-references/' + name, path, 'reference_only_no_binary_payload')
    add('local-payload-references/linked-upstream-preservation-record.json',
        ORIGINAL / 'qualification/linked-upstream-selected-payload-002/record.json', 'reference_only_no_binary_payload')
    for name in ('runtime-assets.json', 'corpus-assets.json', 'compile-assets.json'):
        for row in json.loads((CONTINUATION / name).read_text())['rows']:
            role = 'tracked_literal_compile_full_payload' if name == 'compile-assets.json' else 'tracked_runtime_full_payload'
            add('runtime-inputs/' + row['path'], ROOT / row['path'], role)
    for case in plan['cases']:
        for key in ('fixture', 'vectors', 'proto'):
            member = 'oracles/' + case[key]
            if member not in selected:
                add(member, ROOT / case[key], 'frozen_oracle')
    add('oracles/rust_out_shared/tests/arena_recursion.rs', ROOT / 'rust_out_shared/tests/arena_recursion.rs', 'frozen_oracle')
    add('root-qualification/linked-native-reconciliation.json', ROOT_AUDIT, 'literal_independent_qualification_original126_retained')
    add('root-qualification/reconcile-linked-output-delta.py', ROOT_AUDITOR, 'exact_executed_independent_auditor')
    add('root-qualification/group9-native-reconciliation.json', GROUP_AUDIT, 'literal_independent_group9_qualification_failed_parent_retained')
    for path in HERE.iterdir():
        if path.is_file():
            add('publisher-source/' + path.name, path, 'publisher_source')
    require(sum(row['identity']['st_size'] for row in selected.values()) <= PAYLOAD_LIMIT, 'selected logical payload exceeds 128MiB')
    return selected


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--lease', required=True)
    parser.add_argument('--approved-readiness-sha256', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    require(args.execute and args.lease.strip() and sys.dont_write_bytecode, 'Python -B and later literal publication lease required')
    resumed, plan, _ = completed_results(args.approved_readiness_sha256)
    require(plan['owned_cache_roots'] == [str(ROOT / 'target')]
            and resumed.old.gate.apparent_size(ROOT / 'target')[0] <= LIMIT, 'owned cache scope/cap breached')
    selected = inputs(plan)
    rows = []
    for member, row in selected.items():
        rows.append({'member': member, 'original_path': str(row['path']), 'role': row['role'], 'bytes': row['identity']['st_size'],
                     'sha256': digest(row['path']), 'original_mode': stat.S_IMODE(row['identity']['st_mode'])})
    logical = sum(row['bytes'] for row in rows)
    # Entire stored-gzip upper bound is guarded before mkdir; no fit/compression promise.
    upper = logical + 4096 * len(rows) + 1048576
    guard(upper)
    require(args.output.is_absolute() and not args.output.exists() and not args.output.is_symlink(), 'fresh absolute output required')
    args.output.mkdir(parents=False, exist_ok=False)
    archive = args.output / 'raw-command-proof.tar.gz'
    try:
        with archive.open('xb') as output, gzip.GzipFile(fileobj=GuardedOutput(output), mode='wb', compresslevel=6, mtime=0, filename='') as zipped:
            with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as stream:
                for row in rows:
                    path = selected[row['member']]['path']
                    require(identity(path) == selected[row['member']]['identity'], 'selected input changed before archive')
                    guard(row['bytes'] + 8192)
                    member = tarfile.TarInfo(row['member']); member.size = row['bytes']; member.mode = 0o644
                    member.uid = member.gid = member.mtime = 0; member.uname = member.gname = ''
                    with path.open('rb') as payload:
                        stream.addfile(member, payload)
                    require(identity(path) == selected[row['member']]['identity'] and digest(path) == row['sha256'], 'selected input changed during archive')
        source_seal(args.approved_readiness_sha256)
        manifest = {'status': 'PENDING_FULL_SELECTED_RAW_COMMAND_CAPSULE_VERIFICATION', 'source': SOURCE, 'accepted_native_steps': NATIVE,
                    'accepted_coordinator_disposition': {'failed001_first_two': 2, 'failed002_combined_green': 1, 'failed003_strict_green': 1, 'failed003_linked_native_root_qualified': 1, 'failed005_four_native_greens': 4, 'passed007_final_map': 1}, 'archive': {'name': archive.name, 'bytes': archive.stat().st_size, 'sha256': digest(archive)},
                    'rows': rows, 'hash_only_included_members': 0, 'scope': SCOPE, 'lease': args.lease}
        require(archive.stat().st_size <= upper, 'archive exceeded conservative bound')
        for name, data in [('manifest.json', (json.dumps(manifest, indent=2) + '\n').encode()),
                           ('check-payload.py', (HERE / 'check-payload.py').read_bytes()), ('README.md', (HERE / 'README.md').read_bytes())]:
            guard(len(data)); (args.output / name).write_bytes(data)
        spec = importlib.util.spec_from_file_location('p0_portable_selected_raw_auditor', HERE / 'check-payload.py')
        checker = importlib.util.module_from_spec(spec); spec.loader.exec_module(checker)
        checker.audit(args.output, expected_status='PENDING_FULL_SELECTED_RAW_COMMAND_CAPSULE_VERIFICATION')
        source_seal(args.approved_readiness_sha256)
        manifest['status'] = 'PASS_FULL_SELECTED_RAW_COMMAND_CAPSULE'
        data = (json.dumps(manifest, indent=2) + '\n').encode()
        guard(len(data)); (args.output / 'manifest.json').write_bytes(data)
        print(json.dumps({'status': manifest['status'], 'members': len(rows), 'logical_bytes': logical, 'manifest_sha256': digest(args.output / 'manifest.json')}, indent=2))
    except BaseException:
        # Any partial archive/output stays diagnostic; no success manifest is fabricated.
        raise


if __name__ == '__main__':
    main()
