# Combined P0 source qualification

The eventual capsule qualifies ten selected native commands on combined source
`68e4d57d67c73ff87ea1404bee18c3c70a9dfb93`. It requires two retained Rust 1.85
passing rows, the combined-default188 passing row from failed coordinator002,
the strict-root188 passing row from failed003, the independently qualified
linked native result, four actual passing native commands from failed005,
and the separately continued final map command in attempt002. Every failed coordinator keeps
its original failed status. Accepted rows do not relabel their parents.

The linked command retains native exit 0 and original wrapper exit 126. Its
independent ROOT reconciliation and exact executed auditor source are full
capsule members, pinned separately. The fifth coordinator stopped after the
shared-group native command passed because its metadata stub became the tracked
fixture; that raw failure and the actual group9 result remain separate evidence.
The selected artifact preservation failure from coordinator004, missing hello
FDS failure, missing compile-time README failure, and stopped fingerprint
verifier remain in the raw history. The original map001 helper failed before
protoc/Cargo on a missing accepted-record field; its native exit1 and failed
coordinator006 remain unchanged. The retry changes only graph-result serialization
and declared helper/attempt paths, with the same map15 workload.

Included files have complete bytes: selected command records, stdout, stderr,
exits, samples, prelaunch records, frozen drivers and oracles, 124 restored runtime
inputs, seven separately attributed literal compile inputs, and metadata
references to separate artifact carriers. There are no hash-only included
members. Archive modes are normalized to 0644; the manifest records source modes.

Run `python3 check-payload.py` beside the eventual archive and manifest for
streamed full-byte verification, native source/argv/guard checks, generated
consumer 9/15 and shared consumer 9/15 checks, and genuine thirteen-module byte
comparisons. Quiet passing names are inferred by exclusion against the frozen
fixture mask. The 254 upstream executions include the fifteen arena cases.
Focused cases overlap broad suites; counts are not unique-test sums.

Compiler/test ELFs, full SDK/schema/generated-source payloads, and complete
compiler/linker/runtime closure remain separate local proofs. This selected
capsule does not include those payload trees or establish performance. Source
integration and publication on main remain root-owned actions.

This publisher source preparation has not created an archive. Publication
requires the reviewed final continuation's actual pass, an explicit archive
lease, full portable verification, and repeated checks of the approved literal
publisher readiness hash.
