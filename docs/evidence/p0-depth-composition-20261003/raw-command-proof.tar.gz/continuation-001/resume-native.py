"""WORK ONLY: original P0 steps[2:] with separately pinned tracked runtime assets."""
import argparse
import importlib.util
import json
import re
import stat
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / 'p0-depth-composition-preparation-001'
ROOT = HERE.parents[1]
sys.path.insert(0, str(ORIGINAL))
spec = importlib.util.spec_from_file_location('original_composition', ORIGINAL / 'run-composition.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)


def verify(args):
    old.require(re.fullmatch(r'[0-9a-f]{64}', args.readiness_sha256 or '')
                and old.sha(HERE / 'readiness.json') == args.readiness_sha256,
                'literal reviewed continuation readiness SHA required; no mutable seal trust')
    seal = json.loads((HERE / 'readiness.json').read_text())
    old.require(all(old.sha(path) == pin for path, pin in seal['immutable_pins'].items()),
                'continuation/source/history/helper seal drift')
    original = json.loads((ORIGINAL / 'readiness.json').read_text())
    old.require(all(old.sha(ORIGINAL / name) == pin for name, pin in original['components'].items()),
                'original frozen component closure drift')
    old.require(old.gate.source(ROOT)['status'] == '', 'tracked source mutation')
    inventory = json.loads((HERE / 'runtime-assets.json').read_text())
    corpus = json.loads((HERE / 'corpus-assets.json').read_text())
    old.require(inventory['asset_count'] == len(inventory['rows']) == 2
                and corpus['asset_count'] == len(corpus['rows']) == 122,
                'runtime input cardinality drift')
    for row in inventory['rows'] + corpus['rows']:
        path = ROOT / row['path']
        old.require(path.is_file() and not path.is_symlink()
                    and path.resolve().is_relative_to(ROOT.resolve())
                    and old.sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
                    and stat.S_IMODE(path.stat().st_mode) == row['mode'],
                    'tracked runtime bytes/mode drift: ' + row['path'])
    hello_paths = sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'pbrs-grpc/proto').rglob('*')
                         if path.is_file() or path.is_symlink())
    old.require(hello_paths == sorted(row['path'] for row in inventory['rows']),
                'hello runtime asset paths differ or include extras')
    actual = sorted(str(path.relative_to(ROOT)) for prefix in corpus['roots']
                    for path in (ROOT / prefix).rglob('*') if path.is_file() or path.is_symlink())
    old.require(actual == sorted(row['path'] for row in corpus['rows'])
                and corpus['scanner_mask'] == [row['path'] for row in corpus['rows'] if row['path'].endswith('.bin')],
                'tracked corpus path/scanner mask drift or extra assets')
    plan = json.loads(old.PLAN.read_text())
    continuation = json.loads((HERE / 'continuation-plan.json').read_text())
    old.require(continuation['steps'] == plan['steps'][2:] and len(continuation['steps']) == 8,
                'original eight native workloads drift')
    for case in plan['cases']:
        old.graph_contract.immutable_inputs(case)
        old.graph_contract.accepted_case(old.PLAN, case['label'])
    old.require(old.sha(plan['standalone']['authority_lock']) == plan['standalone']['authority_lock_sha256'],
                'standalone24 lock authority changed')
    artifact = json.loads((ORIGINAL / 'artifact-source-proof.json').read_text())
    assets_path = ORIGINAL / 'proof-assets/selected-assets-manifest.json'
    assets = json.loads(assets_path.read_text())
    old.require(artifact['status'] == 'qualified_current_composition_artifacts'
                and artifact['source'] == plan['source'] and artifact['target'] == plan['fresh_target']
                and all(old.sha(path) == pin for path, pin in artifact['runtime_prerequisite_pins'].items())
                and assets['status'] == 'fully_preserved_selected_artifacts'
                and assets['proof_sha256'] == old.sha(ORIGINAL / 'artifact-source-proof.json')
                and assets['target'] == plan['fresh_target'] and assets['hash_only_files'] == 0
                and len(assets['rows']) == 19
                and [row['original_pin'] for row in assets['rows']] == artifact['artifact_pins'],
                'original FULL19 source-qualified artifact carrier changed')
    for row in assets['rows']:
        path = Path(row['retained_path'])
        old.require(path == assets_path.parent / 'target-files' / row['target_relative_path']
                    and not path.is_symlink() and path.resolve().is_relative_to((assets_path.parent / 'target-files').resolve())
                    and old.sha(path) == row['original_pin']['sha256']
                    and path.stat().st_size == row['original_pin']['bytes']
                    and path.stat().st_mode == row['original_pin']['mode'], 'original FULL19 retained payload drift')
    return plan, continuation


def authenticate_history(plan):
    for name in ['feature-off185', 'core185']:
        step = next(step for step in plan['steps'] if step['name'] == name)
        path = ORIGINAL / 'qualification' / (name + '-001/record.json')
        old.finished_native(path, step, old.PLAN)
    core = (ORIGINAL / 'qualification/core185-001/stdout').read_text()
    summaries = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', core)
    old.require(summaries == ['77', '12'], 'historical core185 exact89 coverage differs')
    path = ORIGINAL / 'qualification/combined-default188-001/record.json'
    failed = json.loads(path.read_text())
    stdout = path.with_name('stdout').read_text()
    old.require(failed['native_exit'] == failed['exit'] == 101 and failed['guard'] is None
                and not any(failed.get(k) for k in ['exception', 'drift', 'cleanup_exception', 'post_cleanup_observation_exception'])
                and all(failed[k + '_before'] == failed[k + '_after'] for k in ['source', 'tools', 'work_helpers', 'helper_closure'])
                and not failed['processes_after_cleanup']['observed']
                and not failed['processes_after_cleanup']['inaccessible_pids']
                and 'test result: FAILED. 100 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;' in stdout
                and 'prost_helloworld_stubs_cover_all_shapes' in stdout
                and 'hello fds: Os { code: 2, kind: NotFound' in stdout,
                'historical sparse-fixture101/cleanup attribution differs')


def launch(args, argv, stdout_path, stderr_path, row, record, output):
    verify(args)
    row.update(argv=argv, cwd=str(ROOT))
    old.dump(output / 'record.json', record)
    try:
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
            row['wrapper_pid'] = child.pid
            old.dump(output / 'record.json', record)
            row['wrapper_exit'] = old.wait_wrapper(child, 960, row)
    finally:
        verify(args)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--lease', required=True)
    parser.add_argument('--readiness-sha256', required=True)
    args = parser.parse_args()
    old.require(args.execute and args.lease.strip(), 'literal root ordinary continuation lease required')
    plan, continuation = verify(args)
    authenticate_history(plan)
    output = Path(plan['native_results']) / 'execution-002'
    output.mkdir(parents=True, exist_ok=False)
    record = {'status': 'running', 'lease': args.lease, 'argv': sys.argv, 'started_utc': old.gate.utc(),
              'source': plan['source'], 'original_plan_sha256': old.sha(old.PLAN),
              'continuation_plan_sha256': old.sha(HERE / 'continuation-plan.json'),
              'readiness_sha256': args.readiness_sha256, 'runtime_assets': 124, 'compiler_assets': 668,
              'scope': 'source unchanged; additive tracked runtime assets; historical89 PASS and fixture101 retained; no performance', 'rows': []}
    old.dump(output / 'record.json', record)
    try:
        for step in continuation['steps']:
            name = step['name']; attempt = continuation['attempts'][name]
            row = {'name': name, 'attempt': attempt, 'started_utc': old.gate.utc()}
            record['rows'].append(row)
            argv = [sys.executable, '-B', str(ORIGINAL / 'gate.py'), '--plan', str(old.PLAN),
                    '--step', name, '--attempt', attempt, '--lease', args.lease]
            launch(args, argv, output / (name + '.stdout'), output / (name + '.stderr'), row, record, output)
            path = Path(plan['results']) / (name + '-' + attempt + '/record.json')
            row.update(gate_record=str(path), gate_record_sha256=old.sha(path), finished_utc=old.gate.utc())
            old.require(row['wrapper_exit'] == 0, 'unexpected native wrapper failure; stop without next gate')
            native = old.finished_native(path, step, old.PLAN)
            row['proof'] = old.native_details(step, path.parent, plan)
            if name == 'linked-upstream188':
                post_plan = ORIGINAL / 'postprocess-plan.json'
                post_step = json.loads(post_plan.read_text())['steps'][0]
                post = {'scope': 'Original excluded FULL linked artifact preservation before later Cargo',
                        'name': post_step['name'], 'started_utc': old.gate.utc()}
                row['selected_preservation'] = post
                argv = [sys.executable, '-B', str(ORIGINAL / 'gate.py'), '--plan', str(post_plan),
                        '--step', post_step['name'], '--attempt', '001', '--lease', args.lease]
                launch(args, argv, output / 'selected-preservation.stdout', output / 'selected-preservation.stderr', post, record, output)
                post_path = Path(plan['results']) / (post_step['name'] + '-001/record.json')
                post.update(gate_record=str(post_path), gate_record_sha256=old.sha(post_path), finished_utc=old.gate.utc())
                old.require(post['wrapper_exit'] == 0, 'linked FULL artifact preservation failed before subsequent Cargo')
                old.finished_native(post_path, post_step, post_plan)
                payload = ORIGINAL / 'qualification/linked-upstream-selected-payload-001/record.json'
                retained = json.loads(payload.read_text())
                old.require(retained['status'] == 'complete; all copied member hashes rechecked'
                            and retained['selected_provider_test_artifacts'], 'linked FULL provider/test retention incomplete')
                post['payload_record_sha256'] = old.sha(payload)
            row.update(native_exit=native['native_exit'], minimum_free=native['minimum_free'],
                       maximum_owned_apparent_bytes=native['maximum_owned_apparent_bytes'])
            verify(args)
            old.dump(output / 'record.json', record); print(json.dumps(row), flush=True)
        verify(args)
        record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed_or_incomplete', error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        record['finished_utc'] = old.gate.utc(); old.dump(output / 'record.json', record)


if __name__ == '__main__':
    main()
