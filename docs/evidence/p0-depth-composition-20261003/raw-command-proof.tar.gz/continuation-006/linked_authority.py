"""Read-only authentication of the literal ROOT qualified native/harness split."""
import json
from pathlib import Path

import gate

ROOT = Path('/workspace/scratch/work/p0-depth-main-integration')
NATIVE = ROOT / 'work/p0-depth-composition-preparation-001/qualification/linked-upstream188-001/record.json'
NATIVE_SHA = 'b497a26618ae6f3b563109f822a2aa50e073fdf86bcb347b7bde1aa7050cf0ab'
AUTHORITY = Path('/workspace/pure-protobuf/work/qualification/root-p0-linked-native-reconciliation.json')
AUTHORITY_SHA = '6042feab22a494dbf409b5395c2581d84c7629d22df91cdf5805d4807220703a'
SOURCE = '68e4d57d67c73ff87ea1404bee18c3c70a9dfb93'
DRIFT = 'standalone source/manifest/lock changed during direct consumer command'
STUB_SHA = '7e60417cd4f7dc4cb542b39c5e70cc4b096c7f5d60318a5d2e80fb466a4da85a'
FIXTURE_TRANSITIONS = {
    'work/p0-depth-composition-preparation-001/consumers/group-shared/src/lib.rs': (
        'tests/fixtures/unknown_group_depth_consumer.rs',
        '8e1f1fb572c16041ea12c21ab47669c9bf4081ac6e7147981c87839ccf5e8eaa'),
    'work/p0-depth-composition-preparation-001/consumers/map-shared/src/lib.rs': (
        'tests/fixtures/generated_map_value_depth_consumer.rs',
        '3992a98866a0b2f215f48a3bcb31990e94373e3650c195b75f1eafe5f8b5ef91'),
}


def require(value, message):
    if not value:
        raise RuntimeError(message)


def validate(path, sha256, native_path, *, map_after=False):
    require(Path(path).resolve() == AUTHORITY and sha256 == AUTHORITY_SHA
            and gate.digest(AUTHORITY) == AUTHORITY_SHA
            and Path(native_path).resolve() == NATIVE and gate.digest(NATIVE) == NATIVE_SHA,
            'literal ROOT authority/native artifact hash or path differs')
    proof = json.loads(AUTHORITY.read_text())
    native = json.loads(NATIVE.read_text())
    require(proof['status'] == 'PASS_NATIVE_WITH_EXPECTED_GENERATED_OUTPUT_DELTA'
            and proof['source'] == SOURCE and proof['original_gate_record'] == str(NATIVE)
            and proof['original_gate_record_sha256'] == NATIVE_SHA
            and proof['original_native_exit'] == native['native_exit'] == 0
            and proof['original_wrapper_exit'] == native['exit'] == 126
            and proof['original_harness_drift_retained'] == native['drift'] == DRIFT
            and native['guard'] is None and native['source_before']['commit'] == SOURCE
            and not any(native.get(k) for k in ['exception', 'cleanup_exception', 'post_cleanup_observation_exception'])
            and all(native[k + '_before'] == native[k + '_after'] for k in ['source', 'tools', 'work_helpers', 'helper_closure'])
            and gate.source(ROOT) == native['source_after'], 'qualified ROOT native/source split no longer exact')
    require(proof['all230_original_files_fullhash_unchanged'] and proof['mods_reconstructed_byte_exact']
            and proof['original_resources_cleanup_source_tools_helpers_SDK_unchanged']
            and len(proof['exact117_additions']) == 117 and len(proof['protoc27']) == 27
            and proof['native_proof']['linked_upstream']['total'] == 254
            and len(proof['native_proof']['linked_upstream']['arena15_included']) == 15
            and len(proof['native_proof']['linked_upstream']['generated58']) == 58,
            'literal ROOT qualified native254/15/27/58 coverage differs')
    before = native['consumer_inputs_before']['files']; after = native['consumer_inputs_after']['files']
    require(len(before) == 230 and len(after) == 347 and set(before) <= set(after)
            and set(after) - set(before) == set(proof['exact117_additions']),
            'qualified exact117 output inventory no longer matches original raw')
    for name, pin in {**before, **proof['exact117_additions']}.items():
        path = ROOT / name
        expected = pin
        if name in FIXTURE_TRANSITIONS:
            fixture_name, fixture_sha = FIXTURE_TRANSITIONS[name]
            fixture = ROOT / fixture_name
            require(name in before and pin == after[name] == STUB_SHA
                    and fixture.is_file() and not fixture.is_symlink()
                    and gate.digest(fixture) == fixture_sha,
                    'reviewed stub-to-tracked-fixture origin differs: ' + name)
            if '/group-shared/' in name or map_after:
                expected = fixture_sha
        require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT)
                and pin == after[name] and gate.digest(path) == expected,
                'qualified original/output payload changed: ' + name)
    for row in proof['protoc27']:
        require(gate.digest(row['path']) == row['sha256'], 'qualified actual protoc record changed')
    for name, pin in native['artifacts'].items():
        require(gate.digest(NATIVE.parent / name) == pin['sha256'], 'qualified original raw changed')
    observed = native['processes_after_cleanup']
    require(not observed['observed'] and not observed['inaccessible_pids']
            and native['minimum_free'] >= gate.LIMIT and native['maximum_owned_apparent_bytes'] <= gate.LIMIT,
            'qualified native cleanup or fixed resources differ')
    return proof
