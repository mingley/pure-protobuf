"""Small Python-only coverage/argv/tamper fixtures; no native launch."""
import importlib.util
import json
from pathlib import Path
import re
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]


def load(name, filename):
    spec = importlib.util.spec_from_file_location(name, HERE/filename)
    module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
    return module


runner = load('composition', 'run-composition.py')
artifact = load('composition_artifact', 'audit-composition-artifacts.py')


class Preparation(unittest.TestCase):
    def test_exact_native_argv_and_20_explicit_bounds(self):
        proposal = json.loads((HERE/'proposal.json').read_text())
        plan = json.loads((HERE/'composition-plan.json').read_text())
        self.assertEqual(len(plan['steps']), 10); self.assertEqual(len(plan['metadata_steps']), 10)
        for actual, old in zip(plan['steps'], proposal['steps']):
            expected = old['argv'].copy()
            if '--lease-label' in expected: expected[expected.index('--lease-label')+1] = 'root ordinary P0 composition scope; exact lease is outer gate record'
            self.assertEqual(actual['argv'], expected)
            self.assertEqual(actual['timeout_seconds'], 900)
            self.assertEqual(actual['environment']['CARGO_TARGET_DIR'], plan['fresh_target'])
            if '--target-dir' in actual['argv']:
                self.assertEqual(actual['argv'][actual['argv'].index('--target-dir')+1], plan['fresh_target'])
        for actual, old in zip(plan['metadata_steps'], proposal['excluded_locked_metadata']):
            self.assertEqual(actual['argv'], old['argv']); self.assertEqual(actual['timeout_seconds'], 900)
            self.assertIn('--offline', actual['argv']); self.assertIn('--locked', actual['argv'])

    def test_accepted_locks_are_exact_original_authorities(self):
        plan = json.loads((HERE/'composition-plan.json').read_text())
        for case in plan['cases']:
            self.assertEqual(Path(case['accepted_lock']).read_bytes(), (Path(case['consumer'])/'Cargo.lock').read_bytes())
            self.assertEqual(len(runner.graph_contract.registry(case['accepted_lock'])), 14)
            runner.graph_contract.immutable_inputs(case)
        self.assertEqual(len(runner.graph_contract.registry(plan['standalone']['authority_lock'])), 24)
        self.assertFalse(runner.graph_contract.registry(plan['standalone']['authority_lock']) <= runner.graph_contract.registry(ROOT/'Cargo.lock'))

    def test_genuine_quiet_nine_passes(self):
        raw = Path('/workspace/scratch/work/unknown-group-depth/work/qg18/qualification/consumers/generated-004/stdout')
        fixture = (ROOT/'tests/fixtures/unknown_group_depth_consumer.rs').read_text()
        result = runner.exact_cases(raw.read_text(), fixture, 9)
        self.assertEqual(result['passed'], 9); self.assertIn('inferred', result['name_status_evidence'])

    def test_reject_missing_extra_duplicate_and_filtered_cases(self):
        fixture = (ROOT/'tests/fixtures/generated_map_value_depth_consumer.rs').read_text()
        names = re.findall(r'#\[test\]\s*fn (\w+)\(', fixture)
        valid = 'running 15 tests\n' + '\n'.join('test '+n+' ... ok' for n in names) + '\ntest result: ok. 15 passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;\n'
        self.assertEqual(runner.exact_cases(valid, fixture, 15)['passed'], 15)
        invalid = [valid.replace('test '+names[0]+' ... ok\n',''), valid+'test extra ... ok\n',
                   valid.replace('test '+names[0]+' ... ok','test '+names[1]+' ... ok'),
                   valid.replace('0 filtered out','1 filtered out'), valid.replace('15 passed','14 passed')]
        for value in invalid:
            with self.subTest(value=value), self.assertRaises(RuntimeError): runner.exact_cases(value, fixture, 15)

    def test_stdout_buildscript_attribution_and_fail_closed_unknown_json(self):
        root = ROOT; target = ROOT/'target/p0-composition-gates'
        row = {'reason':'build-script-executed','package_id':'registry+https://github.com/rust-lang/crates.io-index#paste@1.0.15',
               'out_dir':str(target/'debug/build/paste-x/out')}
        raw = '[paste 1.0.15] cargo:rerun-if-changed=build.rs\n'+json.dumps(row)+'\n'
        rows, attributed = artifact.parsed_rows(raw, root, target)
        self.assertEqual(len(attributed),1); self.assertEqual(attributed[0]['build_script_json'],row)
        for bad in [raw.replace('paste 1.0.15]','unknown 1.0.15]'), '{not JSON}\n'+raw,
                    raw+json.dumps(row)+'\n', raw.replace(str(target),'/wrong-target')]:
            with self.assertRaises(RuntimeError): artifact.parsed_rows(bad,root,target)

    def test_frozen_context_has_no_history_or_missing_input(self):
        context = json.loads((HERE/'compiler-inputs.json').read_text())
        self.assertEqual(context['source'],'68e4d57d67c73ff87ea1404bee18c3c70a9dfb93')
        self.assertEqual(len(context['rows']),668)
        self.assertTrue(all((ROOT/r['path']).is_file() and not r['path'].startswith(('docs/','work/','target/')) for r in context['rows']))

    def test_provider_source_features_freshness_profile_tamper(self):
        target = ROOT/'target/p0-composition-gates'; package = 'path+file://'+str(ROOT)+'#pbrs@0.2.0'
        rows = []
        for name in ['pbrs','unknown_group_depth','generated_map_value_depth']:
            is_test = name != 'pbrs'; filename = str(target/'debug/deps'/('libpbrs-x.rlib' if not is_test else name+'-x'))
            rows.append({'reason':'compiler-artifact','package_id':package,'manifest_path':str(ROOT/'Cargo.toml'),
                         'target':{'kind':['test']if is_test else['lib'],'name':name,'src_path':str(ROOT/('tests/'+name+'.rs'if is_test else'src/lib.rs'))},
                         'profile':{'opt_level':'0','debuginfo':0,'debug_assertions':True,'overflow_checks':True,'test':is_test},
                         'features':['codegen','conformance','default','json','reflect','text'],'fresh':False,'filenames':[filename],
                         'executable':filename if is_test else None})
        self.assertEqual(len(artifact.selected(rows,ROOT,target)[1]),2)
        for key,value in [('manifest_path','/wrong/Cargo.toml'),('fresh',True),('features',['codegen']),('profile',{'opt_level':'3'})]:
            bad=json.loads(json.dumps(rows));bad[0][key]=value
            with self.assertRaises(RuntimeError): artifact.selected(bad,ROOT,target)

    def test_verbose_compiler_wrong_path_and_provider_fail_closed(self):
        compiler={'path':'/captured/rustc','sha256':'0'*64};rlib=ROOT/'target/p0-composition-gates/debug/deps/libpbrs-x.rlib'
        text='\n'.join('Running `CARGO_MANIFEST_DIR='+str(ROOT)+' rustc --crate-name '+name+' '+('src/lib.rs'if name=='pbrs'else'tests/'+name+'.rs --test --extern pbrs='+str(rlib))+'`'for name in ['pbrs','unknown_group_depth','generated_map_value_depth'])
        with mock.patch.object(artifact.shutil,'which',return_value=compiler['path']),mock.patch.object(artifact.gate,'executable',return_value=compiler):
            self.assertEqual(len(artifact.invocations(text,ROOT,compiler,rlib,'/captured')),3)
            with self.assertRaises(RuntimeError): artifact.invocations(text.replace('pbrs='+str(rlib),'pbrs=/wrong.rlib'),ROOT,compiler,rlib,'/captured')
        with mock.patch.object(artifact.shutil,'which',return_value='/wrong/rustc'),mock.patch.object(artifact.gate,'executable',return_value={'path':'/wrong/rustc'}):
            with self.assertRaises(RuntimeError): artifact.invocations(text,ROOT,compiler,rlib,'/wrong')


if __name__ == '__main__': unittest.main(verbosity=2)
