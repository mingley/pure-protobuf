#!/usr/bin/env python3
"""Retain actual Cargo/build.rs consumer provenance after a leased command."""
import argparse
import json
import re
from pathlib import Path

import gate
from record_protoc import copy_payload, guard
import linked_authority


def artifact_members(target, artifacts):
    """Map authenticated Cargo package/target metadata to exact payload members."""
    members = set(artifacts)
    mapping = {}
    for artifact, metadata in artifacts.items():
        package, package_root, cargo_target = metadata
        artifact.relative_to(target)
        source = Path(cargo_target["src_path"])
        if (not source.is_file() or source.is_symlink()
                or not source.resolve().is_relative_to(package_root)):
            raise RuntimeError("selected Cargo target source ownership differs")
        kind = cargo_target["kind"]
        if kind == ["custom-build"]:
            if (cargo_target["name"] != "build-script-build"
                    or artifact.name != "build-script-build"
                    or artifact.parent.parent != target / "debug/build"):
                raise RuntimeError("unsupported selected build-script artifact shape")
            prefix = artifact.parent.name
            match = re.fullmatch(re.escape(package) + r"-([0-9a-f]{16})", prefix)
            if not match:
                raise RuntimeError("selected build-script package/hash differs")
            suffix = match.group(1)
            members.update([artifact.parent / ("build_script_build-" + suffix),
                            artifact.parent / ("build_script_build-" + suffix + ".d")])
        elif kind in (["lib"], ["test"]):
            if artifact.parent != target / "debug/deps":
                raise RuntimeError("selected provider/test artifact directory differs")
            if artifact.suffix in {".rlib", ".rmeta"}:
                base = artifact.name.removeprefix("lib").rsplit(".", 1)[0]
                if kind != ["lib"] or cargo_target["name"] != package:
                    raise RuntimeError("selected library package/target differs")
            elif artifact.suffix == "":
                base = artifact.name
            else:
                raise RuntimeError("unsupported selected provider/test artifact suffix")
            match = re.fullmatch(re.escape(cargo_target["name"]) + r"-([0-9a-f]{16})", base)
            if not match:
                raise RuntimeError("selected provider/test target/hash differs")
            prefix = package + "-" + match.group(1)
            members.add(artifact.parent / (base + ".d"))
        else:
            raise RuntimeError("unsupported selected Cargo target kind")
        fingerprint = target / "debug/.fingerprint" / prefix
        if not fingerprint.is_dir() or fingerprint.is_symlink():
            raise RuntimeError("selected provider/test fingerprint absent")
        files = list(fingerprint.iterdir())
        if not files or any(not path.is_file() or path.is_symlink() for path in files):
            raise RuntimeError("selected provider/test fingerprint shape differs")
        members.update(files)
        mapping[str(artifact.relative_to(target))] = {
            "package": package, "target": cargo_target, "fingerprint": str(fingerprint.relative_to(target))}
    if any(not path.is_file() or path.is_symlink() for path in members):
        raise RuntimeError("selected artifact companion payload absent or symlink")
    return members, mapping


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--root-reconciliation", type=Path, required=True)
    parser.add_argument("--root-reconciliation-sha256", required=True)
    args = parser.parse_args()
    previous = json.loads(args.record.read_text())
    authority = linked_authority.validate(args.root_reconciliation, args.root_reconciliation_sha256, args.record)
    if previous.get("guard") or previous.get("drift") != linked_authority.DRIFT or previous.get("cleanup_exception"):
        raise RuntimeError("previous command did not finish cleanly under its fixed guard")
    if previous.get("native_exit") != 0 or previous["exit"] != 126:
        raise RuntimeError("previous command lacks a complete native Cargo exit")
    # Exit101 remains an attempted baseline assertion red only until the raw
    # exact-name/status checker and a human verify its expected failure scope.
    root = Path(previous["cwd"]).resolve()
    source = previous["source_after"]
    if gate.source(root) != source or source != previous["source_before"]:
        raise RuntimeError("previous source pin/input stamp is no longer exact")
    if previous["tools_before"] != previous["tools_after"]:
        raise RuntimeError("previous tools drifted")
    target = Path(previous["environment"]["CARGO_TARGET_DIR"]).resolve()
    if target != root / "target/p0-composition-gates":
        raise RuntimeError("consumer payload target is not exact combined namespace")
    args.output.resolve().relative_to(Path("/workspace/scratch/work/p0-depth-main-integration/work/p0-depth-composition-preparation-001/qualification"))
    guard(16 * 1024 * 1024)
    args.output.mkdir(parents=True, exist_ok=False)
    output = {"schema": "qg19-actual-consumer-payload/1", "previous_record": str(args.record),
              "previous_record_sha256": gate.digest(args.record), "source": source,
              "native_exit": previous["native_exit"], "source_payloads": {},
              "generated_payloads": {}, "executables": {}, "build_script_out_dirs": [],
              "scope": "generated/source/ELF preservation only; no cache retirement or performance claim"}
    output["root_reconciliation"] = {"path": str(args.root_reconciliation), "sha256": args.root_reconciliation_sha256,
                                     "status": authority["status"], "original_wrapper_exit": previous["exit"]}
    out_dirs = set()
    executables = set()
    selected_artifacts = {}
    packages = {"path+file://" + str(root) + "#pbrs@0.2.0": ("pbrs", root),
                "path+file://" + str(root / "rust_out_shared") + "#0.1.0": ("rust_out_shared", root / "rust_out_shared"),
                "path+file://" + str(root / "rust_out_shared") + "#rust_out_shared@0.1.0": ("rust_out_shared", root / "rust_out_shared")}
    with (args.record.parent / "stdout").open() as stream:
        for line in stream:
            try:
                item = json.loads(line)
            except json.JSONDecodeError:
                continue
            if not isinstance(item, dict):
                continue
            if item.get("reason") == "build-script-executed" and "rust_out_shared" in item.get("package_id", ""):
                out_dirs.add(Path(item["out_dir"]).resolve())
            if item.get("reason") == "compiler-artifact":
                package = item.get("package_id", "")
                if package in packages:
                    for name in item.get("filenames", []):
                        artifact = Path(name)
                        if not artifact.is_absolute() or artifact.is_symlink() or artifact.resolve() != artifact:
                            raise RuntimeError("selected Cargo artifact path shape differs")
                        if artifact in selected_artifacts:
                            raise RuntimeError("selected Cargo artifact metadata is not unique")
                        selected_artifacts[artifact] = (*packages[package], item["target"])
                if item.get("executable"):
                    executables.add(Path(item["executable"]).resolve())
    if not out_dirs:
        raise RuntimeError("no actual rust_out_shared build-script-executed provenance")
    try:
        for name in source["inputs"]:
            # Full tracked source/manifests/locks/schema payloads; the actual kernel
            # and linked consumer are preserved, not just their observed digests.
            output["source_payloads"][name] = copy_payload(root / name, args.output / "source" / name)
        sdk = source["sdk_attachment"]
        output["sdk_src_payloads"] = {}
        for name, pinned in sdk["sdk_src_files"].items():
            path = Path(sdk["sdk_src"]) / name
            if gate.digest(path) != pinned["sha256"]:
                raise RuntimeError("SDK source drift before payload capture")
            output["sdk_src_payloads"][name] = copy_payload(path, args.output / "sdk-src" / name)
        output["sdk_proto_input_payloads"] = {}
        for name, pinned in sdk["resolved_proto_import_closure"].items():
            path = Path(pinned["path"])
            if gate.digest(path) != pinned["sha256"]:
                raise RuntimeError("actual SDK proto input drift before capture")
            output["sdk_proto_input_payloads"][name] = copy_payload(path, args.output / "sdk-proto-inputs" / name)
        for out_dir in sorted(out_dirs):
            out_dir.relative_to(target)
            output["build_script_out_dirs"].append(str(out_dir))
            if not (out_dir / "mods.rs").is_file() or not (out_dir / "crate_mapping.txt").is_file():
                raise RuntimeError("actual build.rs final module/mapping outputs absent")
            for item in sorted(out_dir.rglob("*")):
                if item.is_symlink():
                    raise RuntimeError("unqualified build.rs output symlink")
                if item.is_file():
                    rel = item.relative_to(target)
                    output["generated_payloads"][str(rel)] = copy_payload(item, args.output / "build-out" / rel)
        for item in sorted(executables):
            rel = item.relative_to(target)
            output["executables"][str(rel)] = copy_payload(item, args.output / "executables" / rel)
        output["selected_provider_test_artifacts"] = {}
        selected_files, output["selected_artifact_fingerprint_mapping"] = artifact_members(target, selected_artifacts)
        if not any(path.suffix == ".rlib" and path.name.startswith("libpbrs-") for path in selected_files):
            raise RuntimeError("selected actual pbrs provider payload missing")
        for item in sorted(selected_files):
            rel = item.relative_to(target)
            output["selected_provider_test_artifacts"][str(rel)] = copy_payload(item, args.output / "selected-artifacts" / rel)
        if not any("arena_recursion" in name for name in output["executables"]):
            raise RuntimeError("actual linked15-case test executable not retained")
        output["source_after_capture"] = gate.source(root)
        if output["source_after_capture"] != source:
            raise RuntimeError("source drift during consumer capture")
        linked_authority.validate(args.root_reconciliation, args.root_reconciliation_sha256, args.record)
        output["post_guard"] = guard()
        output["status"] = "complete; all copied member hashes rechecked"
    except BaseException as error:
        output["status"] = "failed capture; partial copied payloads retained"
        output["exception"] = {"type": type(error).__name__, "message": str(error)}
        raise
    finally:
        (args.output / "record.json").write_text(json.dumps(output, indent=2) + "\n")
    print(json.dumps({"output": str(args.output), "source_commit": source["commit"],
                      "generated_files": len(output["generated_payloads"]),
                      "executables": len(output["executables"])}))


if __name__ == "__main__":
    main()
