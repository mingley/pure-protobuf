"""WORK ONLY: original P0 steps[5:] after ROOT-qualified linked output reconciliation and FIRST preservation."""
import argparse
import importlib.util
import json
import re
import stat
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
ORIGINAL = HERE.parent / 'p0-depth-composition-preparation-001'
ROOT = HERE.parents[1]
sys.path.insert(0, str(ORIGINAL))
spec = importlib.util.spec_from_file_location('original_composition', ORIGINAL / 'run-composition.py')
old = importlib.util.module_from_spec(spec)
spec.loader.exec_module(old)
sys.path.insert(0, str(HERE))
import linked_authority


def verify(args):
    old.require(re.fullmatch(r'[0-9a-f]{64}', args.readiness_sha256 or '')
                and old.sha(HERE / 'readiness.json') == args.readiness_sha256,
                'literal reviewed continuation readiness SHA required; no mutable seal trust')
    seal = json.loads((HERE / 'readiness.json').read_text())
    old.require(all(old.sha(path) == pin for path, pin in seal['immutable_pins'].items()),
                'continuation/source/history/helper seal drift')
    original = json.loads((ORIGINAL / 'readiness.json').read_text())
    old.require(all(old.sha(ORIGINAL / name) == pin for name, pin in original['components'].items()),
                'original frozen component closure drift')
    old.require(old.gate.source(ROOT)['status'] == '', 'tracked source mutation')
    inventory = json.loads((HERE / 'runtime-assets.json').read_text())
    corpus = json.loads((HERE / 'corpus-assets.json').read_text())
    old.require(inventory['asset_count'] == len(inventory['rows']) == 2
                and corpus['asset_count'] == len(corpus['rows']) == 122,
                'runtime input cardinality drift')
    for row in inventory['rows'] + corpus['rows']:
        path = ROOT / row['path']
        old.require(path.is_file() and not path.is_symlink()
                    and path.resolve().is_relative_to(ROOT.resolve())
                    and old.sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
                    and stat.S_IMODE(path.stat().st_mode) == row['mode'],
                    'tracked runtime bytes/mode drift: ' + row['path'])
    hello_paths = sorted(str(path.relative_to(ROOT)) for path in (ROOT / 'pbrs-grpc/proto').rglob('*')
                         if path.is_file() or path.is_symlink())
    old.require(hello_paths == sorted(row['path'] for row in inventory['rows']),
                'hello runtime asset paths differ or include extras')
    actual = sorted(str(path.relative_to(ROOT)) for prefix in corpus['roots']
                    for path in (ROOT / prefix).rglob('*') if path.is_file() or path.is_symlink())
    old.require(actual == sorted(row['path'] for row in corpus['rows'])
                and corpus['scanner_mask'] == [row['path'] for row in corpus['rows'] if row['path'].endswith('.bin')],
                'tracked corpus path/scanner mask drift or extra assets')
    compiled = json.loads((HERE / 'compile-assets.json').read_text())
    old.require(compiled['asset_count'] == len(compiled['rows']) == 7,
                'additive literal compile-input cardinality drift')
    for row in compiled['rows']:
        path = ROOT / row['path']
        old.require(path.is_file() and not path.is_symlink() and path.resolve().is_relative_to(ROOT.resolve())
                    and old.sha(path) == row['sha256'] and path.stat().st_size == row['bytes']
                    and stat.S_IMODE(path.stat().st_mode) == row['mode'],
                    'additive literal compile-input bytes/mode/path drift: ' + row['path'])
    plan = json.loads(old.PLAN.read_text())
    continuation = json.loads((HERE / 'continuation-plan.json').read_text())
    old.require(continuation['steps'] == plan['steps'][5:] and len(continuation['steps']) == 5,
                'original five native workloads drift')
    for case in plan['cases']:
        old.graph_contract.immutable_inputs(case)
        old.graph_contract.accepted_case(old.PLAN, case['label'])
    old.require(old.sha(plan['standalone']['authority_lock']) == plan['standalone']['authority_lock_sha256'],
                'standalone24 lock authority changed')
    artifact = json.loads((ORIGINAL / 'artifact-source-proof.json').read_text())
    assets_path = ORIGINAL / 'proof-assets/selected-assets-manifest.json'
    assets = json.loads(assets_path.read_text())
    old.require(artifact['status'] == 'qualified_current_composition_artifacts'
                and artifact['source'] == plan['source'] and artifact['target'] == plan['fresh_target']
                and assets['status'] == 'fully_preserved_selected_artifacts'
                and assets['proof_sha256'] == old.sha(ORIGINAL / 'artifact-source-proof.json')
                and assets['target'] == plan['fresh_target'] and assets['hash_only_files'] == 0
                and len(assets['rows']) == 19
                and [row['original_pin'] for row in assets['rows']] == artifact['artifact_pins'],
                'original FULL19 source-qualified artifact carrier changed')
    # Original Cargo outputs are historical prerequisites, preserved in FULL19.
    # Later legitimate Cargo calls may rewrite live dep-fingerprint files.
    by_original = {row['original_pin']['path']: row for row in assets['rows']}
    target_pins = {path: pin for path, pin in artifact['runtime_prerequisite_pins'].items()
                   if Path(path).is_absolute() and Path(path).is_relative_to(Path(plan['fresh_target']))}
    old.require(len(by_original) == len(assets['rows']) == len(target_pins) == 19
                and set(by_original) == set(target_pins),
                'historical TARGET prerequisites require unique complete FULL19 mapping')
    for path, pin in artifact['runtime_prerequisite_pins'].items():
        if path in target_pins:
            row = by_original[path]
            old.require(row['original_pin']['sha256'] == pin and old.sha(row['retained_path']) == pin,
                        'historical TARGET prerequisite retained payload differs')
        else:
            old.require(old.sha(path) == pin, 'live non-TARGET prerequisite drift: ' + path)
    for row in assets['rows']:
        path = Path(row['retained_path'])
        old.require(path == assets_path.parent / 'target-files' / row['target_relative_path']
                    and not path.is_symlink() and path.resolve().is_relative_to((assets_path.parent / 'target-files').resolve())
                    and old.sha(path) == row['original_pin']['sha256']
                    and path.stat().st_size == row['original_pin']['bytes']
                    and path.stat().st_mode == row['original_pin']['mode'], 'original FULL19 retained payload drift')
    linked_authority.validate(linked_authority.AUTHORITY, linked_authority.AUTHORITY_SHA, linked_authority.NATIVE)
    return plan, continuation


def authenticate_history(plan):
    for name in ['feature-off185', 'core185']:
        step = next(step for step in plan['steps'] if step['name'] == name)
        path = ORIGINAL / 'qualification' / (name + '-001/record.json')
        old.finished_native(path, step, old.PLAN)
    core = (ORIGINAL / 'qualification/core185-001/stdout').read_text()
    summaries = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', core)
    old.require(summaries == ['77', '12'], 'historical core185 exact89 coverage differs')
    path = ORIGINAL / 'qualification/combined-default188-001/record.json'
    failed = json.loads(path.read_text())
    stdout = path.with_name('stdout').read_text()
    old.require(failed['native_exit'] == failed['exit'] == 101 and failed['guard'] is None
                and not any(failed.get(k) for k in ['exception', 'drift', 'cleanup_exception', 'post_cleanup_observation_exception'])
                and all(failed[k + '_before'] == failed[k + '_after'] for k in ['source', 'tools', 'work_helpers', 'helper_closure'])
                and not failed['processes_after_cleanup']['observed']
                and not failed['processes_after_cleanup']['inaccessible_pids']
                and 'test result: FAILED. 100 passed; 1 failed; 0 ignored; 0 measured; 0 filtered out;' in stdout
                and 'prost_helloworld_stubs_cover_all_shapes' in stdout
                and 'hello fds: Os { code: 2, kind: NotFound' in stdout,
                'historical sparse-fixture101/cleanup attribution differs')
    combined = next(step for step in plan['steps'] if step['name'] == 'combined-default188')
    passed_path = ORIGINAL / 'qualification/combined-default188-002/record.json'
    old.finished_native(passed_path, combined, old.PLAN)
    old.native_details(combined, passed_path.parent, plan)
    strict = json.loads((ORIGINAL / 'qualification/strict-root188-001/record.json').read_text())
    stderr = (ORIGINAL / 'qualification/strict-root188-001/stderr').read_text()
    old.require(strict['native_exit'] == strict['exit'] == 101 and strict['guard'] is None
                and not any(strict.get(k) for k in ['exception', 'drift', 'cleanup_exception', 'post_cleanup_observation_exception'])
                and all(strict[k + '_before'] == strict[k + '_after'] for k in ['source', 'tools', 'work_helpers', 'helper_closure'])
                and not strict['processes_after_cleanup']['observed']
                and not strict['processes_after_cleanup']['inaccessible_pids']
                and "couldn't read `tests/../protobuf-tonic/README.md`" in stderr,
                'historical literal-include101/cleanup attribution differs')
    strict_step = next(step for step in plan['steps'] if step['name'] == 'strict-root188')
    old.finished_native(ORIGINAL / 'qualification/strict-root188-002/record.json', strict_step, old.PLAN)


def launch(args, argv, stdout_path, stderr_path, row, record, output):
    verify(args)
    row.update(argv=argv, cwd=str(ROOT))
    old.dump(output / 'record.json', record)
    try:
        with stdout_path.open('xb') as stdout, stderr_path.open('xb') as stderr:
            child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
            row['wrapper_pid'] = child.pid
            old.dump(output / 'record.json', record)
            row['wrapper_exit'] = old.wait_wrapper(child, 960, row)
    finally:
        verify(args)


require = old.require
sha = old.sha
gate = old.gate


def finished_strict(path, step, plan_path):
    native = json.loads(path.read_text())
    require(native['native_exit'] == native['exit'] == 0 and native['guard'] is None,
            'unexpected native/infrastructure/resource failure')
    require(not any(native.get(k) for k in ['exception', 'drift', 'cleanup_exception', 'post_cleanup_observation_exception']),
            'source/tool/cleanup failed')
    require(native['argv'] == step['argv'] and native['timeout_seconds'] == 900
            and native['source_before']['commit'] == step['source_pin']
            and native['source_before']['status'] == '' and native['plan_sha256'] == sha(plan_path)
            and native['runner_sha256'] == sha(HERE / 'consumer_gate.py'), 'actual argv/source/helper attribution differs')
    require(all(native[k + '_before'] == native[k + '_after']
                for k in ['source', 'tools', 'work_helpers', 'helper_closure']), 'native attribution drift')
    seal = json.loads((HERE/'readiness.json').read_text())
    require(all(Path(path).parent == HERE and seal['components'].get(Path(path).name) == value
                for path, value in native['helper_closure_before'].items()), 'actual gate imported unreviewed helper/config bytes')
    observed = native['processes_after_cleanup']
    require(observed is not None and not observed['observed'] and not observed['inaccessible_pids'],
            'owned native cleanup incomplete; visible namespace only')
    require(native['minimum_free'] >= gate.LIMIT and native['maximum_owned_apparent_bytes'] <= gate.LIMIT,
            'fixed sampled 2GiB guard violated')
    text = (path.parent/'stdout').read_text() + '\n' + (path.parent/'stderr').read_text()
    require(not any(re.match(r'error(?:\[|:)', line.strip()) for line in text.splitlines()),
            'outer or embedded compiler/resolver infrastructure error')
    return native


def preserve_linked_first(args, record, output, plan):
    post_plan = HERE / 'postprocess-reconciled-plan.json'
    post_step = json.loads(post_plan.read_text())['steps'][0]
    post = {'scope': 'FIRST original excluded FULL linked artifact preservation; literal ROOT6042 native/harness reconciliation',
            'name': post_step['name'], 'started_utc': old.gate.utc()}
    record['first_selected_preservation'] = post
    record['qualified_linked_history'] = {'original_record': str(linked_authority.NATIVE),
                                         'original_sha256': linked_authority.NATIVE_SHA,
                                         'root_reconciliation_sha256': linked_authority.AUTHORITY_SHA,
                                         'native_exit': 0, 'original_wrapper_exit': 126}
    argv = [sys.executable, '-B', str(ORIGINAL / 'gate.py'), '--plan', str(post_plan),
            '--step', post_step['name'], '--attempt', '002', '--lease', args.lease]
    launch(args, argv, output / 'selected-preservation.stdout', output / 'selected-preservation.stderr', post, record, output)
    post_path = Path(plan['results']) / (post_step['name'] + '-002/record.json')
    post.update(gate_record=str(post_path), gate_record_sha256=old.sha(post_path), finished_utc=old.gate.utc())
    old.require(post['wrapper_exit'] == 0, 'FIRST linked FULL artifact preservation failed; no subsequent Cargo')
    old.finished_native(post_path, post_step, post_plan)
    payload = ORIGINAL / 'qualification/linked-upstream-selected-payload-002/record.json'
    retained = json.loads(payload.read_text())
    old.require(retained['status'] == 'complete; all copied member hashes rechecked'
                and retained['selected_provider_test_artifacts']
                and retained['root_reconciliation']['sha256'] == linked_authority.AUTHORITY_SHA,
                'linked FULL provider/test retention incomplete or wrong ROOT authority')
    post['payload_record_sha256'] = old.sha(payload)
    old.dump(output / 'record.json', record); print(json.dumps(post), flush=True)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--lease', required=True)
    parser.add_argument('--readiness-sha256', required=True)
    args = parser.parse_args()
    old.require(args.execute and args.lease.strip(), 'literal root ordinary continuation lease required')
    plan, continuation = verify(args)
    authenticate_history(plan)
    output = Path(plan['native_results']) / 'execution-005'
    output.mkdir(parents=True, exist_ok=False)
    record = {'status': 'running', 'lease': args.lease, 'argv': sys.argv, 'started_utc': old.gate.utc(),
              'source': plan['source'], 'original_plan_sha256': old.sha(old.PLAN),
              'continuation_plan_sha256': old.sha(HERE / 'continuation-plan.json'),
              'readiness_sha256': args.readiness_sha256, 'runtime_assets': 124, 'compiler_assets': 668, 'compile_assets': 7,
              'scope': 'source unchanged; additive tracked inputs; first2+combined002+strict002 PASS, linked native0/outer126 ROOT-qualified, all reds retained; no performance', 'rows': []}
    old.dump(output / 'record.json', record)
    try:
        preserve_linked_first(args, record, output, plan)
        for step in continuation['steps']:
            name = step['name']; attempt = continuation['attempts'][name]
            row = {'name': name, 'attempt': attempt, 'started_utc': old.gate.utc()}
            record['rows'].append(row)
            selected_gate = HERE / 'consumer_gate.py' if name == 'strict-consumer188' else ORIGINAL / 'gate.py'
            argv = [sys.executable, '-B', str(selected_gate), '--plan', str(old.PLAN),
                    '--step', name, '--attempt', attempt, '--lease', args.lease]
            launch(args, argv, output / (name + '.stdout'), output / (name + '.stderr'), row, record, output)
            path = Path(plan['results']) / (name + '-' + attempt + '/record.json')
            row.update(gate_record=str(path), gate_record_sha256=old.sha(path), finished_utc=old.gate.utc())
            old.require(row['wrapper_exit'] == 0, 'unexpected native wrapper failure; stop without next gate')
            native = finished_strict(path, step, old.PLAN) if name == 'strict-consumer188' else old.finished_native(path, step, old.PLAN)
            row['proof'] = old.native_details(step, path.parent, plan)
            row.update(native_exit=native['native_exit'], minimum_free=native['minimum_free'],
                       maximum_owned_apparent_bytes=native['maximum_owned_apparent_bytes'])
            verify(args)
            old.dump(output / 'record.json', record); print(json.dumps(row), flush=True)
        verify(args)
        record['status'] = 'passed'
    except BaseException as error:
        record.update(status='failed_or_incomplete', error={'type': type(error).__name__, 'message': str(error)})
        raise
    finally:
        record['finished_utc'] = old.gate.utc(); old.dump(output / 'record.json', record)


if __name__ == '__main__':
    main()
