"""WORK ONLY: guarded ordinary commands; execute only after coordinator release.

Adapted from reviewed GN15 gate1de171b8; source-only QG19 overlay. No command runs on import.
Elapsed time is bookkeeping, never comparative performance evidence.
"""
import argparse
import datetime
import hashlib
import json
import os
import pathlib
import re
import shutil
import signal
import stat
import subprocess
import time

import sdk_attachment

LIMIT = 2 * 1024**3
ENV_KEYS = (
    "PATH", "RUSTUP_HOME", "CARGO_HOME", "RUSTUP_TOOLCHAIN", "CARGO_TARGET_DIR",
    "CARGO_BUILD_JOBS", "CARGO_INCREMENTAL", "CARGO_PROFILE_DEV_DEBUG",
    "CARGO_PROFILE_TEST_DEBUG", "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS",
    "RUSTDOCFLAGS", "PROTOC", "PBRS_TYPED_EXTENSION_CONSUMER_DIR",
    "CARGO_NET_OFFLINE", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
    "PBRS_QG19_REAL_PROTOC", "PBRS_QG19_PROTOC_RECORDS", "PBRS_QG19_SOURCE_ROOT",
    "PBRS_QG18_CONSUMER_DIR", "PBRS_QG18_CONSUMER_CARGO", "PBRS_QG18_ACCEPTED_CONSUMER_LOCK",
    "PBRS_QG20_CONSUMER_DIR", "PBRS_QG20_CONSUMER_CARGO", "PBRS_QG20_ACCEPTED_CONSUMER_LOCK",
    "P0_UNDER_REVIEWED_GATE",
)


class AccountingUnavailable(RuntimeError):
    """A bounded sample could not establish the fixed disk guard."""


def check_inherited_environment(env):
    problems = {}
    for key, value in env.items():
        if key.startswith("PURE_PROTOBUF_"):
            problems[key] = value
        compiler_override = key in {
            "RUSTFLAGS", "CARGO_ENCODED_RUSTFLAGS", "RUSTDOCFLAGS", "RUSTC",
            "RUSTDOC", "RUSTC_WRAPPER", "RUSTC_WORKSPACE_WRAPPER",
            "CARGO_BUILD_RUSTFLAGS", "CARGO_ENCODED_RUSTDOCFLAGS", "CARGO_BUILD_TARGET",
            "CARGO_BUILD_RUSTC", "CARGO_BUILD_RUSTDOC", "CARGO_BUILD_RUSTC_WRAPPER",
            "CARGO_BUILD_RUSTC_WORKSPACE_WRAPPER", "RUSTC_BOOTSTRAP",
        } or (key.startswith("CARGO_TARGET_") and key.endswith(("_RUSTFLAGS", "_LINKER")))
        if compiler_override and value:
            problems[key] = value
        if key.startswith("CARGO_PROFILE_") and (
            key not in {"CARGO_PROFILE_DEV_DEBUG", "CARGO_PROFILE_TEST_DEBUG"} or value != "0"
        ):
            problems[key] = value
        if key == "CARGO_INCREMENTAL" and value != "0":
            problems[key] = value
    if problems:
        raise RuntimeError("unsupported inherited compiler options: " + json.dumps(problems))


def apparent_size(path):
    """Retry transient du ENOENT; never silently accept a partial size."""
    races = []
    for attempt in range(3):
        if not path.exists():
            return 0, races
        run = subprocess.run(["du", "-sb", str(path)], capture_output=True, text=True)
        if run.returncode == 0:
            return int(run.stdout.split()[0]), races
        lines = run.stderr.splitlines()
        benign = bool(lines) and all(
            line.startswith("du: ") and "No such file or directory" in line for line in lines
        )
        if not benign:
            raise AccountingUnavailable("du sample failed: " + run.stderr)
        races.append({"attempt": attempt + 1, "stderr": run.stderr, "partial_stdout": run.stdout})
    raise AccountingUnavailable("du remained unstable after three ENOENT attempts: " + json.dumps(races))


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    value = hashlib.sha256()
    with pathlib.Path(path).open("rb") as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(data)
    return value.hexdigest()


def git(root, *args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


def compiler_input_names(root):
    frozen = json.loads((pathlib.Path(__file__).parent / "compiler-inputs.json").read_text())
    if pathlib.Path(root).resolve() != pathlib.Path(__file__).resolve().parents[2] or git(root, "rev-parse", "HEAD") != frozen["source"]:
        raise RuntimeError("unexpected combined source root/pin")
    names = []
    for row in frozen["rows"]:
        path = root / row["path"]
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root.resolve()) or digest(path) != row["sha256"] or path.stat().st_size != row["bytes"] or stat.S_IMODE(path.stat().st_mode) != row["mode"]:
            raise RuntimeError("frozen compiler source drift: " + row["path"])
        names.append(row["path"])
    return names


def source(root):
    files = compiler_input_names(root)
    return {
        "commit": git(root, "rev-parse", "HEAD"),
        "status": git(root, "status", "--porcelain"),
        "patch_sha256": hashlib.sha256(subprocess.check_output([
            "git", "diff", "HEAD", "--binary"], cwd=root)).hexdigest(),
        "inputs": {name: digest(root / name) for name in files},
        "sdk_attachment": sdk_attachment.snapshot(root, digest),
    }


def consumer_inputs(path):
    """Observed standalone inputs; newly generated files are post-command pins."""
    if path is None:
        return None
    path = pathlib.Path(path)
    return {"root": str(path), "exists": path.exists(), "files": {
        str(item.relative_to(path)): digest(item) for item in sorted(path.rglob("*"))
        if item.is_file() and (item.suffix == ".rs" or item.name in {"Cargo.toml", "Cargo.lock"})
    }}


def executable(path):
    path = pathlib.Path(path).resolve()
    if not path.is_file():
        return None
    stat = path.stat()
    return {"path": str(path), "sha256": digest(path), "bytes": stat.st_size,
            "device": stat.st_dev, "inode": stat.st_ino, "mtime_ns": stat.st_mtime_ns}


def tools(argv, env):
    result = {}
    first = shutil.which(argv[0], path=env.get("PATH"))
    if first:
        result["launcher"] = executable(first)
    toolchain = env.get("RUSTUP_TOOLCHAIN")
    home = env.get("RUSTUP_HOME")
    if home and toolchain:
        directory = pathlib.Path(home) / "toolchains" / f"{toolchain}-x86_64-unknown-linux-gnu" / "bin"
        for name in ("cargo", "rustc", "rustdoc", "clippy-driver", "cargo-clippy", "rustfmt"):
            item = executable(directory / name)
            if item:
                result[name] = item
    for key in ("PROTOC", "PBRS_QG19_REAL_PROTOC"):
        if env.get(key):
            item = executable(env[key])
            if item:
                result[key] = item
    return result


def cache_sample(roots, fs_root):
    entries = []
    for path in roots:
        path = pathlib.Path(path)
        size, races = apparent_size(path)
        entries.append({"path": str(path), "apparent_bytes": size, "benign_enoent_retries": races})
    return {"utc": utc(), "monotonic": time.monotonic(), "free_bytes": shutil.disk_usage(fs_root).free,
            "owned_apparent_bytes": sum(row["apparent_bytes"] for row in entries), "roots": entries}


def child_observations(group):
    observed = []
    unavailable = []
    for proc in pathlib.Path("/proc").glob("[0-9]*"):
        try:
            fields = (proc / "stat").read_text().rsplit(")", 1)[1].split()
            if int(fields[2]) != group:
                continue
            row = {"pid": int(proc.name), "start_ticks": fields[19], "state": fields[0]}
            row["argv"] = (proc / "cmdline").read_bytes().split(b"\0")
            row["argv"] = [os.fsdecode(arg) for arg in row["argv"] if arg]
            try:
                row["exe"] = str((proc / "exe").resolve(strict=True))
            except (FileNotFoundError, PermissionError):
                row["exe"] = None
            observed.append(row)
        except FileNotFoundError:
            continue
        except PermissionError:
            unavailable.append(int(proc.name))
    return {"process_group": group, "observed": observed, "inaccessible_pids": unavailable,
            "scope": "accessible current PID namespace; samples do not prove global process absence"}


def capture_group(child):
    fields = (pathlib.Path("/proc") / str(child.pid) / "stat").read_text().rsplit(")", 1)[1].split()
    if int(fields[2]) != child.pid:
        raise RuntimeError("child did not create its own process group")
    group = {"pgid": child.pid, "leader_start_ticks": fields[19],
             "known": {str(child.pid): fields[19]}}
    observe_group(group)
    return group


def observe_group(group):
    row = child_observations(group["pgid"])
    anchored = any(group["known"].get(str(item["pid"])) == item["start_ticks"] for item in row["observed"])
    if anchored:
        for item in row["observed"]:
            if int(item["start_ticks"]) < int(group["leader_start_ticks"]):
                raise RuntimeError("process-group member predates owned leader")
            group["known"][str(item["pid"])] = item["start_ticks"]
    row["identity_anchored"] = anchored
    row["known_start_ticks"] = dict(group["known"])
    return row


def stop(child, group, grace=5):
    if child is None:
        return None
    if group is None:
        # Popen is still the unreaped direct-child authority; no group identity
        # was captured, so never signal an unverified PGID.
        if child.poll() is None:
            child.terminate()
            try:
                child.wait(timeout=grace)
            except subprocess.TimeoutExpired:
                child.kill()
        child.wait()
        return {"scope": "direct child only; process-group identity capture failed"}
    observations = []

    def live():
        row = observe_group(group)
        observations.append(row)
        active = [item for item in row["observed"] if item["state"] != "Z"]
        if active and not row["identity_anchored"]:
            raise RuntimeError("refusing to signal unanchored/reused process group")
        return active

    if live():
        try:
            os.killpg(group["pgid"], signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + grace
    while live() and time.monotonic() < deadline:
        time.sleep(0.02)
    if live():
        try:
            os.killpg(group["pgid"], signal.SIGKILL)
        except ProcessLookupError:
            pass
        deadline = time.monotonic() + grace
        while live() and time.monotonic() < deadline:
            time.sleep(0.02)
    child.wait(timeout=grace)
    if live():
        raise RuntimeError("owned process-group survivor after SIGKILL")
    return {"observations": observations,
            "scope": "owned PGID plus recorded PID/start ticks; direct child reaped; non-child zombies observed only"}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--plan", type=pathlib.Path, required=True)
    parser.add_argument("--step", required=True)
    parser.add_argument("--attempt", required=True)
    parser.add_argument("--lease", required=True, help="coordinator ordinary-slot release identifier")
    args = parser.parse_args()
    if not re.fullmatch(r"[A-Za-z0-9_-]+", args.attempt):
        parser.error("attempt must be a simple unique name")
    plan = json.loads(args.plan.read_text())
    step = next(item for item in plan["steps"] if item["name"] == args.step)
    if step.get("blocked"):
        parser.error("step remains blocked by its recorded prerequisite")
    timeout_seconds = step.get("timeout_seconds")
    if not isinstance(timeout_seconds, (int, float)) or not 0 < timeout_seconds <= 900:
        parser.error("each ordinary command requires an explicit timeout within900seconds")
    argv = step["argv"]
    if "--release" in argv or "lto" in " ".join(argv).lower():
        parser.error("this runner forbids release/LTO/performance commands")
    root = pathlib.Path(step["source_root"])
    cwd = pathlib.Path(step.get("cwd", str(root)))
    output = pathlib.Path(plan["results"]) / f"{args.step}-{args.attempt}"
    output.mkdir(parents=True, exist_ok=False)
    inherited = os.environ.copy()
    env = inherited.copy()
    env.update(plan["environment"])
    env.update(step.get("environment", {}))
    if env.get("PROTOC", "").endswith("/record_protoc.py"):
        env["PBRS_QG19_PROTOC_RECORDS"] = str(output / "protoc")
        env["PBRS_QG19_SOURCE_ROOT"] = str(root.resolve())
    record = {"schema": "qg19-ordinary-command-v1", "scope": "correctness only; no performance qualification",
              "name": args.step, "attempt": args.attempt, "argv": argv, "cwd": str(cwd),
              "started_utc": utc(), "runner_sha256": digest(__file__), "plan_sha256": digest(args.plan),
              "lease": args.lease, "expected": step["expected"], "timeout_seconds": timeout_seconds, "guard": None, "native_exit": None,
              "sample_guard": "2GiB global free/combined owned apparent bytes; sampled, not a hard allocation quota",
              "environment": {key: env.get(key) for key in ENV_KEYS}}
    record["inherited_technical_environment"] = {key: value for key, value in inherited.items()
                                                if key in ENV_KEYS or key.startswith("CARGO_PROFILE_")}
    record["environment"].update({key: value for key, value in env.items() if key.startswith("PURE_PROTOBUF_")})
    child = None
    group = None
    samples = []
    result = 126
    consumer = env.get("PBRS_QG18_CONSUMER_DIR") or env.get("PBRS_QG20_CONSUMER_DIR")
    explicit_manifest_consumer = False
    if consumer is None and args.step == "strict-consumer188" and "--manifest-path" in argv:
        if argv.count("--manifest-path") != 1:
            raise RuntimeError("ambiguous direct standalone manifest")
        manifest = pathlib.Path(argv[argv.index("--manifest-path") + 1]).resolve()
        if manifest != root / "rust_out_shared/Cargo.toml":
            raise RuntimeError("unexpected direct standalone manifest")
        consumer = str(manifest.parent)
        explicit_manifest_consumer = True
    if consumer is None and any(x in argv for x in ("metadata", "--manifest-path")) and (cwd / "Cargo.toml").is_file():
        consumer = str(cwd)
    if consumer is None and cwd.name in {"188", "185"} and cwd.parent.name == "consumers":
        consumer = str(cwd)
    try:
        check_inherited_environment(inherited)
        target = pathlib.Path(__file__).resolve().parents[2] / "target/p0-composition-gates"
        if env.get("CARGO_TARGET_DIR") != str(target) or env.get("CARGO_INCREMENTAL") != "0" or env.get("CARGO_PROFILE_DEV_DEBUG") != "0" or env.get("CARGO_PROFILE_TEST_DEBUG") != "0":
            raise RuntimeError("combined exact target/incremental/debug policy differs")
        if "--target-dir" in argv and argv[argv.index("--target-dir") + 1] != str(target):
            raise RuntimeError("explicit target argv differs from owned environment target")
        if env["CARGO_BUILD_JOBS"] != "1" or env.get("CARGO_NET_OFFLINE") != "true":
            raise RuntimeError("fixed jobs=1/offline policy missing")
        record["source_before"] = source(root)
        if record["source_before"]["commit"] != step["source_pin"] or record["source_before"]["status"]:
            raise RuntimeError("source pin/cleanliness precondition failed")
        record["tools_before"] = tools(argv, env)
        record["consumer_inputs_before"] = consumer_inputs(consumer)
        closure = [pathlib.Path(__file__).parent / name for name in ("gate.py", "record_protoc.py", "capture_consumer.py", "check_oracle.py", "sdk_attachment.py", "ordinary.py", "regen_retained.py", "shared_group_consumer.py", "shared_map_consumer.py", "graph_contract.py", "run-composition.py", "audit-composition-artifacts.py", "preserve-selected-artifacts.py", "compiler-inputs.json", "composition-plan.json", "metadata-plan.json", "artifact-setup-plan.json", "postprocess-plan.json")]
        closure.append(pathlib.Path(__file__))
        record["helper_closure_before"] = {str(path): digest(path) for path in closure}
        record["work_helpers_before"] = {str(path): digest(path) for arg in argv
                                         if (path := pathlib.Path(arg)).is_file() and path.suffix == ".py"}
        before = cache_sample(plan["owned_cache_roots"], root)
        samples.append(before)
        (output / "prelaunch.json").write_text(json.dumps(before, indent=2) + "\n")
        if before["free_bytes"] < LIMIT or before["owned_apparent_bytes"] > LIMIT:
            record["guard"] = {"reason": "prelaunch fixed disk guard", **before}
            result = 125
        else:
            payload_bytes = sum(path.stat().st_size for path in closure)
            if before["free_bytes"] < LIMIT + payload_bytes:
                raise AccountingUnavailable("fixed reserve cannot preserve the complete helper closure")
            snapshots = output / "source-snapshot"
            snapshots.mkdir()
            for path in closure:
                captured = snapshots / path.name
                shutil.copy2(path, captured)
                if digest(captured) != record["helper_closure_before"][str(path)]:
                    raise RuntimeError("helper closure changed while freezing execution payload")
            with (output / "stdout").open("xb") as stdout, (output / "stderr").open("xb") as stderr, (output / "samples.jsonl").open("x") as ledger:
                child = subprocess.Popen(argv, cwd=cwd, env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                record["child_pid"] = child.pid
                launched_monotonic = time.monotonic()
                group = capture_group(child)
                record["group_identity"] = group
                while True:
                    sample = cache_sample(plan["owned_cache_roots"], root)
                    sample["processes"] = observe_group(group)
                    samples.append(sample)
                    ledger.write(json.dumps(sample) + "\n")
                    ledger.flush()
                    status = child.poll()
                    if sample["free_bytes"] < LIMIT or sample["owned_apparent_bytes"] > LIMIT:
                        record["guard"] = {"reason": "fixed disk guard stop", **sample}
                        record["guard_cleanup"] = stop(child, group)
                        break
                    if status is None and time.monotonic() - launched_monotonic >= timeout_seconds:
                        record["guard"] = {"reason": "fixed ordinary command timeout", "timeout_seconds": timeout_seconds, "elapsed_seconds": time.monotonic() - launched_monotonic, **sample}
                        record["guard_cleanup"] = stop(child, group)
                        break
                    if status is not None:
                        break
                    time.sleep(1)
                record["native_exit"] = child.wait()
                result = (124 if record["guard"]["reason"] == "fixed ordinary command timeout" else 125) if record["guard"] else record["native_exit"]
        record["source_after"] = source(root)
        record["tools_after"] = tools(argv, env)
        record["consumer_inputs_after"] = consumer_inputs(consumer)
        record["work_helpers_after"] = {name: digest(name) for name in record["work_helpers_before"]}
        record["helper_closure_after"] = {name: digest(name) for name in record["helper_closure_before"]}
        if record["helper_closure_after"] != record["helper_closure_before"]:
            record["drift"] = "imported helper closure changed during command"
            result = 126
        if record["source_after"] != record["source_before"] or record["tools_after"] != record["tools_before"]:
            record["drift"] = "source or executable changed during command"
            result = 126
        if record["work_helpers_after"] != record["work_helpers_before"]:
            record["drift"] = "work helper changed during command"
            result = 126
        if consumer is not None and (cwd == pathlib.Path(consumer) or explicit_manifest_consumer) and record["consumer_inputs_before"] != record["consumer_inputs_after"]:
            record["drift"] = "standalone source/manifest/lock changed during direct consumer command"
            result = 126
    except AccountingUnavailable as error:
        record["guard"] = {"reason": "bounded cache accounting unavailable", "message": str(error)}
        result = 125
    except BaseException as error:
        record["exception"] = {"type": type(error).__name__, "message": str(error)}
        result = 126
    finally:
        try:
            record["finally_cleanup"] = stop(child, group)
        except BaseException as error:
            record["cleanup_exception"] = {"type": type(error).__name__, "message": str(error)}
            result = 126
        if child is not None:
            record["native_exit"] = child.poll()
            try:
                record["processes_after_cleanup"] = observe_group(group) if group is not None else None
            except BaseException as error:
                record["post_cleanup_observation_exception"] = {"type": type(error).__name__, "message": str(error)}
                result = 126
        record.update(exit=result, finished_utc=utc(), minimum_free=min((row["free_bytes"] for row in samples), default=None),
                      maximum_owned_apparent_bytes=max((row["owned_apparent_bytes"] for row in samples), default=None))
        record["artifacts"] = {path.name: {"bytes": path.stat().st_size, "sha256": digest(path)} for path in output.iterdir() if path.is_file()}
        (output / "record.json").write_text(json.dumps(record, indent=2) + "\n")
        (output / "exit").write_text(str(result) + "\n")
    print(json.dumps({"name": args.step, "exit": result, "native_exit": record["native_exit"], "guard": record["guard"], "output": str(output)}))
    raise SystemExit(result)


if __name__ == "__main__":
    main()
