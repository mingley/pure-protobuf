"""WORK ONLY: exact resolver graph audit; no command launches on import."""
import hashlib
import json
from pathlib import Path
import tomllib


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def registry(path):
    values = [(p['name'], p['version'], p['source'], p.get('checksum'))
              for p in tomllib.loads(Path(path).read_text())['package'] if p.get('source')]
    require(len(values) == len(set(values)), 'duplicate provider/accepted registry tuple')
    return set(values)


def immutable_inputs(case):
    root, child = Path(case['root']), Path(case['consumer'])
    pairs = [(root/'Cargo.lock', case['root_lock_sha256']),
             (child/'root-Cargo.lock.before', case['root_lock_sha256']),
             (root/'Cargo.toml', case['root_manifest_sha256']),
             (child/'root-Cargo.toml.before', case['root_manifest_sha256']),
             (child/'Cargo.toml', case['manifest_sha256']),
             (child/'Cargo.lock.seed', case['seed_sha256'])]
    require(all(sha(path) == expected for path, expected in pairs), 'provider/manifest/raw-seed drift')
    require(all(sha(path) == expected for path, expected in case.get('historical_proof_sha256', {}).items()), 'historical accepted proof changed')
    if case.get('mode') == 'existing_accepted_locked_only':
        require(sha(case['accepted_lock']) == case['accepted_input_sha256'], 'copied historical accepted lock changed')
    return {str(path): expected for path, expected in pairs}


def accepted_case(plan_path, label):
    """Require all ten actual locked metadata phases; no normalization fallback."""
    plan_path = Path(plan_path); plan = json.loads(plan_path.read_text())
    case = next(row for row in plan['cases'] if row['label'] == label)
    immutable_inputs(case)
    execution = json.loads((Path(plan['metadata_results'])/'execution-001/record.json').read_text())
    require(execution['status'] == 'passed' and execution['plan_sha256'] == sha(plan_path)
            and len(execution['rows']) == 10, 'all ten actual locked metadata phases must pass')
    require([row['name'] for row in execution['rows']] == [row['name'] for row in plan['metadata_steps']], 'metadata command coverage differs')
    graph_hashes = set()
    for row in execution['rows']:
        if row['case_label'] != label:
            continue
        path = Path(row['gate_record']); require(sha(path) == row['gate_record_sha256'], 'metadata record changed')
        native = json.loads(path.read_text())
        require(native['exit'] == native['native_exit'] == row['wrapper_exit'] == 0 and native['guard'] is None
                and not any(native.get(key) for key in ['exception','drift','cleanup_exception','post_cleanup_observation_exception']), 'metadata guard/native failure')
        require(all(native[key+'_before'] == native[key+'_after'] for key in ['source','tools','work_helpers','helper_closure']), 'metadata source/tools/helpers drift')
        observed = audit_graph(case, path.parent/'stdout', case['accepted_lock'])
        require(observed == row['graph'] and row['active_lock_before_sha256'] == row['active_lock_after_sha256'] == sha(case['accepted_lock']), 'metadata graph/accepted bytes differ')
        graph_hashes.add(observed['graph_sha256'])
    require(len(graph_hashes) == 1, '185/188 actual full graph differs')
    accepted = {'graph': next(row['graph'] for row in execution['rows'] if row['case_label'] == label)}
    return case, accepted


def audit_standalone(case, metadata_path):
    """The existing 24-tuple standalone lock is its own authority."""
    root, child = Path(case['root']), Path(case['consumer'])
    authority = Path(case['authority_lock'])
    require(sha(authority) == case['authority_lock_sha256'], 'standalone authority changed')
    accepted = registry(authority)
    require(len(accepted) == 24, 'standalone exact24 tuple coverage differs')
    metadata = json.loads(Path(metadata_path).read_text())
    packages = metadata['packages']; nodes = {n['id']: n for n in metadata['resolve']['nodes']}
    require(len(nodes) == len(metadata['resolve']['nodes']) and set(nodes) == {p['id'] for p in packages}, 'standalone full node/package coverage differs')
    require({(p['name'], p['version'], p['source']) for p in packages if p['source']}
            == {(n, v, s) for n, v, s, c in accepted}, 'standalone actual registry set differs from authority')
    local = [p for p in packages if p['source'] is None]
    require(len(local) == 2 and {(p['name'], p['version']) for p in local}
            == {('pbrs', '0.2.0'), ('rust_out_shared', '0.1.0')}, 'standalone local identities differ')
    provider = next(p for p in local if p['name'] == 'pbrs')
    driver = next(p for p in local if p['name'] == 'rust_out_shared')
    require(Path(provider['manifest_path']).resolve() == (root/'Cargo.toml').resolve()
            and Path(driver['manifest_path']).resolve() == (child/'Cargo.toml').resolve(), 'standalone manifest origin differs')
    require(metadata['workspace_members'] == [driver['id']] and metadata['resolve']['root'] == driver['id']
            and Path(metadata['workspace_root']).resolve() == child.resolve()
            and Path(metadata['target_directory']).resolve() == Path(case['target']).resolve(), 'standalone workspace/target differs')
    require(sorted(nodes[provider['id']]['features']) == case['expected_pbrs_features'], 'standalone provider default features differ')
    require(all(dep['pkg'] in nodes and all(set(kind) >= {'kind', 'target'} for kind in dep['dep_kinds'])
                for node in nodes.values() for dep in node['deps']), 'standalone dependency kind/edge closure incomplete')
    replacements = sorted([(str(child.resolve()), '$STANDALONE'), (str(root.resolve()), '$PBRS_SOURCE'),
                           (str(Path(case['target']).resolve()), '$OWNED_TARGET')], key=lambda pair: len(pair[0]), reverse=True)
    ids = {provider['id']: 'local:pbrs@0.2.0', driver['id']: 'local:rust_out_shared@0.1.0'}
    def normalize(value):
        if isinstance(value, str):
            if value in ids: return ids[value]
            for before, after in replacements:
                if value == before or value.startswith(before + '/'): return after + value[len(before):]
            return value
        if isinstance(value, list): return [normalize(v) for v in value]
        if isinstance(value, dict): return {k: normalize(v) for k, v in value.items()}
        return value
    graph = {'packages': sorted(normalize(packages), key=lambda p: p['id']), 'resolve': normalize(metadata['resolve']),
             'workspace_members': normalize(metadata['workspace_members']),
             'workspace_default_members': normalize(metadata.get('workspace_default_members', [driver['id']])),
             'workspace_root': normalize(metadata['workspace_root']), 'target_directory': normalize(metadata['target_directory'])}
    graph['resolve']['nodes'].sort(key=lambda n: n['id'])
    for node in graph['resolve']['nodes']:
        node['features'].sort(); node['dependencies'].sort(); node['deps'].sort(key=lambda d: (d['name'], d['pkg']))
        for dep in node['deps']: dep['dep_kinds'].sort(key=lambda k: json.dumps(k, sort_keys=True))
    return {'accepted_registry_count': 24, 'authority_lock_sha256': sha(authority), 'raw_metadata_sha256': sha(metadata_path),
            'graph': graph, 'graph_sha256': hashlib.sha256(json.dumps(graph, sort_keys=True, separators=(',', ':')).encode()).hexdigest(),
            'scope': 'Exact standalone24 authority including its five non-root registry tuples; not a root166 subset claim.'}


def audit_graph(case, metadata_path, lock_path):
    """Validate actual full metadata then normalize declared local identities only.
    Registry IDs, features, dependency aliases and dependency kinds remain exact.
    """
    root, child = Path(case['root']), Path(case['consumer'])
    provider, accepted = registry(root/'Cargo.lock'), registry(lock_path)
    require(len(provider) == 166 and accepted <= provider, 'version/source/checksum outside frozen166 provider')
    metadata = json.loads(Path(metadata_path).read_text())
    packages = metadata['packages']
    locals_ = [p for p in packages if p['source'] is None]
    require(len(locals_) == 2 and {(p['name'],p['version']) for p in locals_}
            == {('pbrs','0.2.0'),(case['name'],'0.0.0')}, 'actual local package set must be pbrs plus declared child')
    pbrs = next(p for p in locals_ if p['name']=='pbrs')
    driver = next(p for p in locals_ if p['name']==case['name'])
    require(Path(pbrs['manifest_path']).resolve() == (root/'Cargo.toml').resolve()
            and Path(driver['manifest_path']).resolve() == (child/'Cargo.toml').resolve(), 'local manifest identity mismatch')
    require(metadata['workspace_members'] == [driver['id']]
            and metadata.get('workspace_default_members',[driver['id']]) == [driver['id']]
            and metadata['resolve']['root'] == driver['id']
            and Path(metadata['workspace_root']).resolve() == child.resolve(), 'standalone workspace/root mismatch')
    nodes = {node['id']:node for node in metadata['resolve']['nodes']}
    require(len(nodes) == len(metadata['resolve']['nodes']) and set(nodes) == {p['id']for p in packages}, 'resolve node/package coverage mismatch')
    require(sorted(nodes[pbrs['id']]['features']) == case['expected_pbrs_features']
            and nodes[driver['id']]['features'] == [], 'actual child default pbrs feature closure changed')
    direct = driver['dependencies']
    require(len(direct)==1 and direct[0]['name']=='pbrs' and direct[0].get('rename') is None
            and direct[0]['uses_default_features'] is True and direct[0]['features']==[]
            and direct[0]['kind'] is None and Path(direct[0]['path']).resolve()==root.resolve(), 'child direct dependency differs from exact manifest')
    require(Path(metadata['target_directory']).resolve() == Path(case['target']).resolve(), 'fixed owned target changed')
    pin_names = {(name,version,source)for name,version,source,checksum in accepted}
    actual_names = {(p['name'],p['version'],p['source'])for p in packages if p['source']}
    require(actual_names == pin_names, 'normalized lock registry set differs from actual full metadata package set')
    local_lock = {(p['name'],p['version'])for p in tomllib.loads(Path(lock_path).read_text())['package']if not p.get('source')}
    require(local_lock == {('pbrs','0.2.0'),(case['name'],'0.0.0')}, 'normalized lock retains unexpected local nodes')
    require(all(dep['pkg'] in nodes and all(set(kind) >= {'kind','target'} for kind in dep['dep_kinds'])
                for node in nodes.values() for dep in node['deps']), 'resolve dependency edges/kinds incomplete')
    # This is graph comparison, not a native compiler/link/runtime closure.
    ids = {pbrs['id']:'local:pbrs@0.2.0',driver['id']:'local:declared-child@0.0.0'}
    replacements = [(str(Path(case['target']).resolve()),'$OWNED_TARGET'),
                    (str(child.resolve()),'$CHILD'),(str(root.resolve()),'$PBRS_SOURCE')]
    replacements.sort(key=lambda pair:len(pair[0]),reverse=True)
    def normalize(value):
        if isinstance(value,str):
            if value in ids:return ids[value]
            for before,after in replacements:
                if value==before or value.startswith(before+'/'):
                    return after+value[len(before):]
            return value
        if isinstance(value,list):return [normalize(item)for item in value]
        if isinstance(value,dict):return {key:normalize(item)for key,item in value.items()}
        return value
    normalized_packages = []
    for package in packages:
        row = normalize(package)
        if package['id']==driver['id']:
            row['name']='$DECLARED_CHILD_NAME'
            for target in row['targets']:
                require(target['name']==case['name'].replace('-','_'), 'undeclared child target name')
                target['name']='$DECLARED_CHILD_TARGET'
        normalized_packages.append(row)
    resolve = normalize(metadata['resolve'])
    resolve['nodes'].sort(key=lambda row:row['id'])
    for node in resolve['nodes']:
        node['features'].sort()
        node['dependencies'].sort()
        node['deps'].sort(key=lambda row:(row['name'],row['pkg']))
        for dep in node['deps']:
            dep['dep_kinds'].sort(key=lambda row:json.dumps(row,sort_keys=True))
    graph = {'packages':sorted(normalized_packages,key=lambda row:row['id']), 'resolve':resolve,
             'workspace_members':normalize(metadata['workspace_members']),
             'workspace_default_members':normalize(metadata.get('workspace_default_members',[driver['id']])),
             'workspace_root':normalize(metadata['workspace_root']),
             'target_directory':normalize(metadata['target_directory'])}
    return {'registry_provider_count':len(provider),'accepted_registry_count':len(accepted),
            'accepted_registry_tuple_checksum_subset':True,'accepted_lock_sha256':sha(lock_path),
            'raw_metadata_sha256':sha(metadata_path),'actual_features':nodes[pbrs['id']]['features'],
            'graph':graph,'graph_sha256':hashlib.sha256(json.dumps(graph,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
            'normalization_scope':'Only declared local package IDs/root paths/child root+lib names and ordering. Registry IDs, features, aliases, edges and dep_kinds preserved; raw full metadata retained.',
            'qualification_scope':'Actual resolver graph only; metadata-only placeholder is never compiled; generated Rust/oracles require later actual locked tests.'}
