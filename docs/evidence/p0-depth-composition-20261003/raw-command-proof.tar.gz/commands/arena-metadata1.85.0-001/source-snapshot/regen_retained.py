#!/usr/bin/env python3
"""Retain genuine pinned 13-file staging/byte comparison; never write src.
Reproduces scripts/regen-generated.sh profile/registry/argv with retained stage.
Requires separately completed source-pinned ordinary plugin-build raw proof.
"""
import argparse
import json
import os
import re
import subprocess
from pathlib import Path
import ordinary

ROOT = ordinary.ROOT
TREE = Path('/workspace/pure-protobuf/third_party/protobuf')
BUILD = Path('/workspace/pure-protobuf/target/conformance-build')
PROTOC = BUILD / 'protoc'
FORMATTER = ordinary.TOOLS / 'stable-x86_64-unknown-linux-gnu/bin/rustfmt'
PROTOS = [
 'src/google/protobuf/any.proto', 'src/google/protobuf/duration.proto',
 'src/google/protobuf/timestamp.proto', 'src/google/protobuf/struct.proto',
 'src/google/protobuf/wrappers.proto', 'src/google/protobuf/field_mask.proto',
 'src/google/protobuf/empty.proto', 'src/google/protobuf/test_messages_proto3.proto',
 'src/google/protobuf/test_messages_proto2.proto',
 'conformance/test_protos/test_messages_edition2023.proto',
 'conformance/test_protos/test_messages_edition_unstable.proto',
 'editions/golden/test_messages_proto2_editions.proto',
 'editions/golden/test_messages_proto3_editions.proto',
]


def main():
 parser = argparse.ArgumentParser(description=__doc__)
 parser.add_argument('--execute', action='store_true')
 parser.add_argument('--lease-label')
 parser.add_argument('--attempt', required=True)
 parser.add_argument('--plugin-build-attempt', required=True)
 parser.add_argument('--cache-cap-bytes', type=int)
 parser.add_argument('--free-reserve-bytes', type=int)
 args = parser.parse_args()
 if not args.execute:
  print(json.dumps({'status': 'NOT_RUN; source-only preparation', 'source_commit': ordinary.SOURCE,
                    'plugin_build_attempt': args.plugin_build_attempt, 'profile': 'shared_pool=true',
                    'protos': PROTOS, 'stage': str(ordinary.PROOF / args.attempt / 'stage')}))
  return
 if not args.lease_label or args.cache_cap_bytes != ordinary.gate.LIMIT or args.free_reserve_bytes != ordinary.gate.LIMIT:
  parser.error('--execute requires root ordinary lease and explicit cache/free bounds')
 if any(Path(value).name != value for value in [args.attempt, args.plugin_build_attempt]):
  parser.error('attempts must be unique simple directory names')
 if ordinary.git(ROOT, 'rev-parse', 'HEAD').decode().strip() != ordinary.SOURCE or ordinary.git(ROOT, 'status', '--short', '--untracked-files=no'):
  parser.error('frozen source or clean tracked state mismatch')
 build = ordinary.PROOF / args.plugin_build_attempt
 command = json.loads((build / 'record.json').read_text())
 result = command
 if result['exit'] or result['guard'] or result.get('drift') or result['source_before'] != result['source_after'] or result['tools_before'] != result['tools_after'] or command['source_before']['commit'] != ordinary.SOURCE:
  parser.error('plugin build was not a successful unchanged-source ordinary gate')
 artifacts = []
 for line in (build / 'stdout').read_text().splitlines():
  item = json.loads(line)
  if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'protoc-gen-pbrs' and 'bin' in item['target'].get('kind', []) and Path(item['manifest_path']).resolve() == (ROOT / 'Cargo.toml').resolve() and item.get('executable'):
   artifacts.append(item['executable'])
 if len(set(artifacts)) != 1:
  parser.error('expected exactly one reported current plugin executable')
 plugin = Path(artifacts[0])
 if not plugin.is_relative_to(ordinary.TARGET):
  parser.error('plugin lies outside the single owned target')
 out = ordinary.PROOF / args.attempt
 out.mkdir(parents=True, exist_ok=False)
 stage = out / 'stage'; stage.mkdir()
 env = ordinary.environment('1.88.0', 'regen-stage', out)
 source_before = ordinary.snapshot(ROOT)
 record = {'kind': 'genuine pinned generated staging; source writes forbidden', 'root_lease_label': args.lease_label,
           'source_before': source_before, 'profile': 'shared_pool=true', 'canonical_script_sha256': ordinary.sha(ROOT / 'scripts/regen-generated.sh'),
           'plugin_build_attempt': args.plugin_build_attempt, 'commands': [], 'inputs': []}
 (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
 def invoke(argv):
  usage = ordinary.cache_usage()
  if usage['owned_apparent_bytes'] > args.cache_cap_bytes or usage['global_available_bytes'] < args.free_reserve_bytes:
   raise RuntimeError('cache/free guard rejected before command')
  index = len(record['commands'])
  row = {'argv': [str(value) for value in argv], 'cwd': str(ROOT), 'started_utc': ordinary.utc(), 'cache_before': usage}
  record['commands'].append(row)
  (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
  run = subprocess.run(row['argv'], cwd=ROOT, env=env, capture_output=True, timeout=120)
  (out / f'{index:02}.stdout').write_bytes(run.stdout); (out / f'{index:02}.stderr').write_bytes(run.stderr)
  row.update({'exit': run.returncode, 'completed_utc': ordinary.utc(), 'cache_after': ordinary.cache_usage()})
  (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
  run.check_returncode()
  return run.stdout
 try:
  pin = (ROOT / 'vendor/google/PIN').read_text().strip(); upstream = (ROOT / 'vendor/google/SHA').read_text().strip()
  assert upstream == '35cd01f9fe9afbeea38cc7b979a3b6bfcde82c03' and pin == 'v35.1'
  assert invoke(['git', '-C', TREE, 'rev-parse', 'HEAD']).decode().strip() == upstream
  invoke(['git', '-C', TREE, 'diff', '--quiet', 'HEAD', '--'])
  assert not invoke(['git', '-C', TREE, 'ls-files', '--others', '--exclude-standard', '--', '*.proto'])
  stamp = (BUILD / '.pbrs-protobuf-pin').read_bytes()
  (out / 'compiler-source-stamp').write_bytes(stamp)
  assert stamp.decode().strip() == pin + ' ' + upstream
  assert invoke([PROTOC, '--version']).decode().strip() == 'libprotoc ' + pin[1:]
  for path in [PROTOC.resolve(), plugin, FORMATTER, ROOT / 'rustfmt.toml']:
   record['inputs'].append({'path': str(path), 'bytes': path.stat().st_size, 'sha256': ordinary.sha(path)})
  # Archive all candidate schema inputs, including imports; no claim that this
  # captures the C++ compiler/runtime closure of the existing protoc executable.
  schemas = []
  for path in sorted(TREE.rglob('*.proto')):
   if path.is_file():
    schemas.append({'path': str(path.relative_to(TREE)), 'bytes': path.stat().st_size, 'sha256': ordinary.sha(path)})
  (out / 'protobuf-schema-inventory.json').write_text(json.dumps({'source_commit': upstream, 'files': schemas}, indent=2) + '\n')
  record['schema_inventory_sha256'] = ordinary.sha(out / 'protobuf-schema-inventory.json')
  canonical = (ROOT / 'scripts/regen-generated.sh').read_text()
  body = canonical.split('PROTOS=(\n', 1)[1].split('\n)', 1)[0]
  assert body.split() == PROTOS, 'canonical proto argv list changed'
  files = [Path(path).stem + '.rs' for path in PROTOS]
  registry = (ROOT / 'src/generated/mod.rs').read_text()
  registered = []
  for attributes, name in re.findall(r'((?:#\[[^\n]*\]\s*)*)pub mod (\w+);', registry):
   explicit = re.findall(r'#\[path\s*=\s*"([^"]+)"\]', attributes)
   registered.append(explicit[0] if explicit else name + '.rs')
  assert sorted(registered) == sorted(files) and len(files) == 13
  for proto in PROTOS:
   invoke([PROTOC, '--plugin=protoc-gen-pbrs=' + str(plugin), '--pbrs_out=shared_pool=true:' + str(stage), '-I', TREE / 'src', '-I', TREE, TREE / proto])
  assert all((stage / name).is_file() for name in files)
  invoke([FORMATTER, '--edition', '2021', '--config-path', ROOT / 'rustfmt.toml', *[stage / name for name in files]])
  comparisons = []
  for name in files:
   before = ROOT / 'src/generated' / name; after = stage / name
   comparisons.append({'path': 'src/generated/' + name, 'candidate_sha256': ordinary.sha(before), 'staged_sha256': ordinary.sha(after), 'byte_equal': before.read_bytes() == after.read_bytes()})
   if not comparisons[-1]['byte_equal']:
    diff = subprocess.run(['diff', '-u', str(before), str(after)], capture_output=True)
    (out / (name + '.diff')).write_bytes(diff.stdout); (out / (name + '.diff.stderr')).write_bytes(diff.stderr)
  record['comparisons'] = comparisons
  record['inputs_after'] = [{'path': row['path'], 'bytes': Path(row['path']).stat().st_size, 'sha256': ordinary.sha(Path(row['path']))} for row in record['inputs']]
  assert record['inputs'] == record['inputs_after'], 'compiler/plugin/formatter/config changed during stage'
  assert (BUILD / '.pbrs-protobuf-pin').read_bytes() == stamp
  assert invoke(['git', '-C', TREE, 'rev-parse', 'HEAD']).decode().strip() == upstream
  invoke(['git', '-C', TREE, 'diff', '--quiet', 'HEAD', '--'])
  assert all((TREE / row['path']).stat().st_size == row['bytes'] and ordinary.sha(TREE / row['path']) == row['sha256'] for row in schemas), 'schema inputs changed during stage'
  record['source_after'] = ordinary.snapshot(ROOT)
  record['source_unchanged'] = source_before == record['source_after']
  record['status'] = 'PASS' if all(row['byte_equal'] for row in comparisons) and record['source_unchanged'] else 'BLOCKED: generated drift or source mutation; retain raw outputs'
  (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
  print(json.dumps({'status': record['status'], 'compared_files': len(comparisons)}))
  raise SystemExit(0 if record['status'] == 'PASS' else 1)
 except Exception as error:
  record['status'] = 'FAILED; no regeneration qualification'
  record['error'] = repr(error)
  (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
  raise


if __name__ == '__main__':
 main()
