#!/usr/bin/env python3
"""Classify retained exact-name15-case results; compiler errors are not reds."""
import argparse
import json
from pathlib import Path
import re

import gate


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--record", type=Path, required=True)
    parser.add_argument("--mode", choices=["baseline", "candidate"], required=True)
    args = parser.parse_args()
    record = json.loads(args.record.read_text())
    for key in ["guard", "drift", "exception", "cleanup_exception"]:
        if record.get(key):
            raise RuntimeError("unqualified attempt: " + key)
    text = (args.record.parent / "stdout").read_text()
    expected = 101 if args.mode == "baseline" else 0
    if record["native_exit"] != expected or record["exit"] != expected:
        raise RuntimeError("unexpected complete native exit")
    for line in text.splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict) and item.get("reason") == "compiler-message" and item["message"].get("level") == "error":
            raise RuntimeError("compiler diagnostic is not a semantic red")
    source = Path(record["cwd"]) / "rust_out_shared/tests/arena_recursion.rs"
    if gate.digest(source) != record["source_before"]["inputs"]["rust_out_shared/tests/arena_recursion.rs"]:
        raise RuntimeError("current oracle is no longer the executed source")
    names = re.findall(r"#\[test\]\s*fn (arena_\w+)\(", source.read_text())
    if len(names) != 15:
        raise RuntimeError("frozen oracle no longer has15cases")
    statuses = re.findall(r"^test (arena_\w+) \.\.\. (ok|FAILED)$", text, re.MULTILINE)
    if len(statuses) != 15 or set(name for name, _ in statuses) != set(names):
        raise RuntimeError("exact15test execution names/statuses missing or duplicated")
    controls = {"arena_sibling_branches_reuse_the_depth_budget",
                "arena_required_checks_and_opaque_unknowns_are_preserved"}
    for name, actual in statuses:
        wanted = "ok" if args.mode == "candidate" or name in controls else "FAILED"
        if actual != wanted:
            raise RuntimeError(f"{name}: expected {wanted}, observed {actual}")
    print(json.dumps({"scope": "actual retained15-case harness execution", "mode": args.mode,
                      "complete_native_exit": expected, "tests": dict(statuses),
                      "semantic_reds": 13 if args.mode == "baseline" else 0,
                      "controls_passed": 2, "performance_or_full_parser_security": "unqualified"}))


if __name__ == "__main__":
    main()
