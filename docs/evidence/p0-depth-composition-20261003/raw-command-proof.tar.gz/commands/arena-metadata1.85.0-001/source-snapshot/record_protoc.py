#!/opt/codex/runtimes/codex-primary-runtime/dependencies/python/bin/python3
"""Work-only recorder for the unchanged rust_out_shared/build.rs invocations.

This runs the genuine pinned protoc, forwards its original output/status, and
retains generated payloads. It never generates or modifies Rust source itself.
It executes only when a separately leased Cargo build invokes PROTOC.
"""
import hashlib
import json
import os
from pathlib import Path
import shutil
import stat
import subprocess
import sys
import time
import uuid

import gate

ROOTS = [Path('/workspace/scratch/work/p0-depth-main-integration')]
CACHES = [root / "target/p0-composition-gates" for root in ROOTS]
LIMIT = 2 * 1024**3
PROTOC_SHA256 = "ba5165ada96fc34d1295b2056ab8ea99756f7896a0ef0449d07f721595702b28"


def guard(next_bytes=0):
    sample = gate.cache_sample(CACHES, ROOTS[0])
    if sample["owned_apparent_bytes"] > LIMIT or sample["free_bytes"] < LIMIT + next_bytes:
        raise RuntimeError("fixed QG19 disk guard: " + json.dumps(sample))
    return sample


def copy_payload(source, dest):
    if source.is_symlink() or not source.is_file():
        raise RuntimeError("unqualified generated payload kind: " + str(source))
    dest.parent.mkdir(parents=True, exist_ok=True)
    value = hashlib.sha256()
    with source.open("rb") as incoming, dest.open("xb") as outgoing:
        while data := incoming.read(1024 * 1024):
            guard(len(data))
            outgoing.write(data)
            value.update(data)
    mode = stat.S_IMODE(source.stat().st_mode)
    dest.chmod(mode)
    if gate.digest(dest) != value.hexdigest():
        raise RuntimeError("generated payload copy mismatch")
    return {"bytes": dest.stat().st_size, "sha256": value.hexdigest(), "mode": mode}


def configured_reference(path):
    info = path.lstat()
    return {"configured_path": str(path), "resolved_path": str(path.resolve()),
            "device": info.st_dev, "inode": info.st_ino, "mtime_ns": info.st_mtime_ns,
            "mode": stat.S_IMODE(info.st_mode),
            "symlink_target": os.readlink(path) if path.is_symlink() else None}


def main():
    root = Path(os.environ["PBRS_QG19_SOURCE_ROOT"]).resolve()
    if root not in ROOTS or Path(os.environ["CARGO_MANIFEST_DIR"]).resolve() != root / "rust_out_shared":
        raise RuntimeError("recorder is only for the qualified rust_out_shared build.rs")
    out_dir = Path(os.environ["OUT_DIR"]).resolve()
    out_dir.relative_to(root / "target/p0-composition-gates")
    configured = Path(os.environ["PBRS_QG19_REAL_PROTOC"])
    expected = Path("/workspace/pure-protobuf/target/conformance-build/protoc")
    real = configured.resolve()
    if configured != expected or real != expected.resolve():
        raise RuntimeError("unexpected configured/resolved genuine protoc path")
    configured_before = configured_reference(configured)
    executable_before = gate.executable(real)
    if executable_before is None or executable_before["sha256"] != PROTOC_SHA256:
        raise RuntimeError("genuine protoc differs from the root-approved ELF hash")
    args = sys.argv[1:]
    output_flags = [arg for arg in args if arg.startswith("--rust_out=")]
    options = [arg for arg in args if arg.startswith("--rust_opt=")]
    if len(output_flags) != 1 or len(options) != 1:
        raise RuntimeError("unexpected actual build.rs generator arguments")
    destination = Path(output_flags[0].split("=", 1)[1]).resolve()
    destination.relative_to(out_dir / "protobuf_generated")
    mapping = out_dir / "crate_mapping.txt"
    if options[0] != f"--rust_opt=experimental-codegen=enabled,kernel=upb,crate_mapping={mapping}":
        raise RuntimeError("changed original generator configuration")
    records = Path(os.environ["PBRS_QG19_PROTOC_RECORDS"]).resolve()
    records.relative_to(ROOTS[0] / "work/p0-depth-composition-preparation-001/qualification")
    guard(16 * 1024 * 1024)
    folder = records / (destination.name + "-" + uuid.uuid4().hex)
    folder.mkdir(parents=True, exist_ok=False)
    parent = Path("/proc") / str(os.getppid())
    fields = (parent / "stat").read_text().rsplit(")", 1)[1].split()
    parent_exe = (parent / "exe").resolve(strict=True)
    parent_exe.relative_to(root / "target/p0-composition-gates")
    if not parent_exe.name.startswith("build-script"):
        raise RuntimeError("caller is not the actual Cargo build-script executable")
    argv = [str(real), *args]
    record = {
        "schema": "qg19-actual-rust-out-invocation/1", "argv": argv,
        "cwd": os.getcwd(), "root": str(root), "out_dir": str(out_dir),
        "native_output_destination": str(destination),
        "build_rs": gate.executable(root / "rust_out_shared/build.rs"),
        "parent_pid": os.getppid(), "parent_start_ticks": fields[19],
        "parent_argv": [os.fsdecode(arg) for arg in (parent / "cmdline").read_bytes().split(b"\0") if arg],
        "parent_executable": gate.executable(parent_exe),
        "configured_protoc_before": configured_before,
        "protoc_before": executable_before,
        "root_approved_protoc_sha256": PROTOC_SHA256,
        "wrapper": gate.executable(Path(__file__)),
        "mapping": {"path": str(mapping), "sha256": gate.digest(mapping)},
        "prelaunch_guard": guard(), "native_exit": None, "exit": 126,
        "generated_payloads": {}, "status": "started",
        "process_visibility": "accessible local PID namespace only",
        "scope": "correctness provenance; no performance measurement",
    }
    (folder / "prelaunch.json").write_text(json.dumps(record, indent=2) + "\n")
    child = None
    result = 126
    try:
        copy_payload(mapping, folder / "crate_mapping.txt")
        with (folder / "stdout").open("xb") as stdout, (folder / "stderr").open("xb") as stderr:
            child = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
            record["child_pid"] = child.pid
            # Retain a live /proc executable observation when the process lasts
            # long enough. A missing observation is recorded, never fabricated.
            try:
                record["child_executable_observed"] = gate.executable(Path("/proc") / str(child.pid) / "exe")
            except (FileNotFoundError, ProcessLookupError):
                record["child_executable_observed"] = None
            while child.poll() is None:
                guard()
                time.sleep(0.25)
            record["native_exit"] = child.wait()
        for name, target in [("stdout", sys.stdout.buffer), ("stderr", sys.stderr.buffer)]:
            with (folder / name).open("rb") as source:
                shutil.copyfileobj(source, target)
            target.flush()
        result = record["native_exit"]
        record["protoc_after"] = gate.executable(real)
        record["configured_protoc_after"] = configured_reference(configured)
        if record["configured_protoc_after"] != record["configured_protoc_before"]:
            raise RuntimeError("configured protoc entry/resolution drift")
        if record["protoc_after"] != record["protoc_before"]:
            raise RuntimeError("genuine protoc artifact drift")
        for item in sorted(destination.rglob("*")):
            if item.is_symlink():
                raise RuntimeError("unqualified generated symlink")
            if item.is_file():
                rel = item.relative_to(destination)
                record["generated_payloads"][str(rel)] = copy_payload(item, folder / "generated" / rel)
        if result == 0 and not any(name.endswith("generated.rs") for name in record["generated_payloads"]):
            raise RuntimeError("successful actual generation missing generated.rs")
        record["status"] = "complete; retained native output and generated payloads"
    except BaseException as error:
        record["exception"] = {"type": type(error).__name__, "message": str(error)}
        result = 126
    finally:
        if child is not None and child.poll() is None:
            # The outer gate owns and finally cleans the entire process group;
            # this recorder also reaps its direct protoc child on local failure.
            child.terminate()
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait(timeout=5)
        if child is not None:
            record["native_exit"] = child.poll()
        record["exit"] = result
        (folder / "record.json").write_text(json.dumps(record, indent=2) + "\n")
    return result


if __name__ == "__main__":
    raise SystemExit(main())
