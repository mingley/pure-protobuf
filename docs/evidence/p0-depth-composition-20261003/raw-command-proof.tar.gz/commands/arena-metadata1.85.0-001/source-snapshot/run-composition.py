"""WORK ONLY: exact reviewed P0 composition; no launches on import."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import signal
import subprocess
import sys
import tomllib

import gate
import graph_contract

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
PLAN = HERE / 'composition-plan.json'
METADATA_PLAN = HERE / 'metadata-plan.json'


def require(value, message):
    if not value:
        raise RuntimeError(message)


def sha(path):
    return gate.digest(path)


def dump(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')


def wait_wrapper(child, timeout, record):
    """Bound the known direct child, never signal its separate native PGID."""
    try:
        return child.wait(timeout=timeout)
    except BaseException as error:
        cleanup = {'wrapper_pid': child.pid, 'initial_error': repr(error),
                   'scope': 'Known direct Popen child only; separately sessioned native descendants are not verified or signaled.',
                   'native_cleanup_complete': False, 'qualification': 'STOP; failed or incomplete; no qualification or later command'}
        record['wrapper_cleanup'] = cleanup
        if child.poll() is None:
            child.send_signal(signal.SIGINT)
            cleanup['sent_sigint_to_direct_wrapper'] = True
        try:
            cleanup['wrapper_exit'] = child.wait(timeout=20)
            cleanup['direct_wrapper_reaped'] = True
            cleanup['disposition'] = 'Direct wrapper reaped after interruption; native cleanup must be independently checked from its gate record.'
        except subprocess.TimeoutExpired as timeout_error:
            cleanup['interrupt_wait_error'] = repr(timeout_error)
            if child.poll() is None:
                child.kill()
                cleanup['killed_only_direct_wrapper'] = True
            try:
                cleanup['wrapper_exit'] = child.wait(timeout=5)
                cleanup['direct_wrapper_reaped'] = True
            except subprocess.TimeoutExpired as kill_error:
                cleanup['kill_wait_error'] = repr(kill_error)
                cleanup['direct_wrapper_reaped'] = False
            cleanup['disposition'] = 'Incomplete native cleanup: direct wrapper exceeded SIGINT grace; no separate native PGID was verified or signaled. Stop and require root process review.'
        raise


def finished_native(path, step, plan_path):
    native = json.loads(path.read_text())
    require(native['native_exit'] == native['exit'] == 0 and native['guard'] is None,
            'unexpected native/infrastructure/resource failure')
    require(not any(native.get(k) for k in ['exception', 'drift', 'cleanup_exception', 'post_cleanup_observation_exception']),
            'source/tool/cleanup failed')
    require(native['argv'] == step['argv'] and native['timeout_seconds'] == 900
            and native['source_before']['commit'] == step['source_pin']
            and native['source_before']['status'] == '' and native['plan_sha256'] == sha(plan_path)
            and native['runner_sha256'] == sha(HERE / 'gate.py'), 'actual argv/source/helper attribution differs')
    require(all(native[k + '_before'] == native[k + '_after']
                for k in ['source', 'tools', 'work_helpers', 'helper_closure']), 'native attribution drift')
    seal = json.loads((HERE/'readiness.json').read_text())
    require(all(Path(path).parent == HERE and seal['components'].get(Path(path).name) == value
                for path, value in native['helper_closure_before'].items()), 'actual gate imported unreviewed helper/config bytes')
    observed = native['processes_after_cleanup']
    require(observed is not None and not observed['observed'] and not observed['inaccessible_pids'],
            'owned native cleanup incomplete; visible namespace only')
    require(native['minimum_free'] >= gate.LIMIT and native['maximum_owned_apparent_bytes'] <= gate.LIMIT,
            'fixed sampled 2GiB guard violated')
    text = (path.parent/'stdout').read_text() + '\n' + (path.parent/'stderr').read_text()
    require(not any(re.match(r'error(?:\[|:)', line.strip()) for line in text.splitlines()),
            'outer or embedded compiler/resolver infrastructure error')
    return native


def exact_cases(stdout, fixture, count):
    names = set(re.findall(r'#\[test\]\s*fn (\w+)\(', fixture))
    require(len(names) == count, 'frozen fixture name count differs')
    summary = re.findall(r'test result: (ok|FAILED)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out;', stdout)
    require(summary == [('ok', str(count), '0', '0', '0', '0')] and 'running ' + str(count) + ' tests' in stdout,
            'complete child coverage/counts differ')
    pretty = re.findall(r'^test (\S+) \.\.\. (ok|FAILED)$', stdout, re.MULTILINE)
    if pretty:
        statuses = {name.rsplit('::', 1)[-1]: status for name, status in pretty}
        require(len(pretty) == count and set(statuses) == names and set(statuses.values()) == {'ok'}, 'child exact named mask differs')
        evidence = 'all statuses explicitly named'
    else:
        require(not re.findall(r'^(\S+) --- FAILED$', stdout, re.MULTILINE), 'quiet child contains a named failure')
        statuses = dict.fromkeys(sorted(names), 'ok')
        evidence = 'quiet greens inferred by exclusion against frozen fixture names; complete run and zero ignored/measured/filtered'
    return {'passed': count, 'failed': 0, 'statuses': statuses, 'name_status_evidence': evidence}


def child_proof(case, raw):
    child = Path(case['consumer'])
    require((child / 'Cargo.toml').read_text() == case['manifest']
            and sha(child / 'Cargo.lock') == sha(case['accepted_lock']) == case['accepted_input_sha256'], 'actual child manifest/accepted lock changed')
    require((child / 'src/lib.rs').read_bytes() == (ROOT / case['fixture']).read_bytes()
            and (child / 'src/vectors.rs').read_bytes() == (ROOT / case['vectors']).read_bytes(), 'generated child fixture/vector bytes differ')
    source = child / ('src/qg18.rs' if case['label'].startswith('group') else 'src/qg20.rs')
    require(source.is_file(), 'genuine generated source missing')
    if case['label'].endswith('shared'):
        text = source.read_text()
        require('pbrs::gencode::conformance_pool()' in text and 'pub const FILE_DESCRIPTOR_SET' not in text, 'actual shared_pool marker differs')
    stdout, stderr = (raw / 'stdout').read_text(), (raw / 'stderr').read_text()
    require(not re.search(r'error\[|could not compile|failed to select a version|--locked was passed', stdout + '\n' + stderr), 'nested child compiler/resolver failure')
    outcomes = exact_cases(stdout, (ROOT / case['fixture']).read_text(), case['expected_cases'])
    return {'case': case['label'], 'provider_root': str(ROOT), 'manifest_sha256': sha(child / 'Cargo.toml'),
            'lock_sha256': sha(child / 'Cargo.lock'), 'generated_sha256': sha(source),
            'stdout_sha256': sha(raw / 'stdout'), 'stderr_sha256': sha(raw / 'stderr'), **outcomes}


def native_details(step, directory, plan):
    name = step['name']; proof = {}
    if name == 'combined-default188':
        for label in ['group', 'map']:
            case = next(c for c in plan['cases'] if c['label'] == label)
            proof[label] = child_proof(case, Path(case['consumer']))
    if name in ['group-shared', 'map-shared']:
        case = next(c for c in plan['cases'] if c['label'] == name)
        proof[name] = child_proof(case, HERE / 'qualification' / (name + '-payload-001') / 'cargo')
    if name == 'genuine-regen':
        record = HERE / 'qualification/genuine-regen-payload-001/record.json'
        result = json.loads(record.read_text())
        require(result['status'] == 'PASS' and result['source_unchanged'] and len(result['comparisons']) == 13
                and all(row['byte_equal'] and row['candidate_sha256'] == row['staged_sha256'] for row in result['comparisons']), 'genuine13 byte comparisons failed')
        require(len(result['commands']) == 20 and all(row['exit'] == 0 for row in result['commands']), 'original regeneration command coverage differs')
        proof['genuine13'] = {'record_sha256': sha(record), 'comparisons': result['comparisons'], 'profile': result['profile']}
    if name == 'linked-upstream188':
        stdout = (directory / 'stdout').read_text()
        summaries = re.findall(r'test result: ok\. (\d+) passed; 0 failed; 0 ignored; 0 measured; 0 filtered out;', stdout)
        require(len(summaries) == 21 and sum(map(int, summaries)) == 254,
                'actual upstream21 summaries/254 INCLUDING arena15 differ')
        fixture = (ROOT / 'rust_out_shared/tests/arena_recursion.rs').read_text()
        expected = set(re.findall(r'#\[test\]\s*fn (arena_\w+)\(', fixture))
        actual = re.findall(r'^test (arena_\w+) \.\.\. (ok|FAILED)$', stdout, re.MULTILINE)
        require(len(expected) == len(actual) == 15 and {n for n, _ in actual} == expected and all(s == 'ok' for _, s in actual), 'actual named arena15 mask differs')
        records = sorted((directory / 'protoc').glob('*/record.json'))
        require(len(records) == 27, 'genuine actual build.rs27 protoc calls differ')
        generated = {}
        for path in records:
            record = json.loads(path.read_text())
            require(record['native_exit'] == record['exit'] == 0 and not record.get('exception')
                    and record['root'] == str(ROOT) and record['protoc_before'] == record['protoc_after']
                    and record['configured_protoc_before'] == record['configured_protoc_after'], 'actual protoc/source/provenance failed')
            module = Path(record['native_output_destination']).name
            for filename, pin in record['generated_payloads'].items():
                key = module + '/' + filename
                require(key not in generated, 'duplicate retained generated output')
                generated[key] = pin
        require(len(generated) == 58, 'actual retained generated58 output coverage differs')
        native = json.loads((directory / 'record.json').read_text())
        require(len(native['source_before']['sdk_attachment']['direct_build_rs_inputs']) == 31
                and len(native['source_before']['sdk_attachment']['vendor_schema_equality']) == 32,
                'SDK31 direct inputs/32 original schema equality differs')
        proof['linked_upstream'] = {'actual_test_summaries': list(map(int, summaries)), 'total': 254,
                                    'arena15_included': dict(actual), 'protoc27_records': [sha(p) for p in records],
                                    'generated58': generated}
    return proof


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--execute', action='store_true')
    parser.add_argument('--mode', choices=['metadata', 'native'], required=True)
    parser.add_argument('--lease', required=True)
    parser.add_argument('--artifact-proof', type=Path)
    parser.add_argument('--artifact-proof-sha256')
    parser.add_argument('--asset-manifest', type=Path)
    parser.add_argument('--asset-manifest-sha256')
    args = parser.parse_args()
    require(args.execute and args.lease.strip(), 'literal root ordinary lease required')
    seal = json.loads((HERE / 'readiness.json').read_text())
    require(all(sha(HERE / name) == value for name, value in seal['components'].items()), 'frozen P0 helper/plan closure changed')
    plan = json.loads(PLAN.read_text()); actual_plan = METADATA_PLAN if args.mode == 'metadata' else PLAN
    steps = plan['metadata_steps'] if args.mode == 'metadata' else plan['steps']
    require(len(steps) == 10 and all(s['timeout_seconds'] == 900 for s in steps), 'exact ten coverage/timeouts differ')
    if args.mode == 'native':
        require(args.artifact_proof is not None and re.fullmatch(r'[0-9a-f]{64}', args.artifact_proof_sha256 or '')
                and sha(args.artifact_proof) == args.artifact_proof_sha256, 'literal actual source-artifact proof SHA required')
        artifact = json.loads(args.artifact_proof.read_text())
        require(artifact['status'] == 'qualified_current_composition_artifacts' and artifact['source'] == plan['source']
                and artifact['target'] == plan['fresh_target'], 'actual composition artifact attribution absent')
        require(all(sha(path) == pin for path, pin in artifact['runtime_prerequisite_pins'].items()), 'actual selected compiler/artifact input drift')
        require(args.asset_manifest is not None and re.fullmatch(r'[0-9a-f]{64}', args.asset_manifest_sha256 or '')
                and sha(args.asset_manifest) == args.asset_manifest_sha256, 'literal reviewed full selected-asset manifest SHA required')
        assets = json.loads(args.asset_manifest.read_text())
        require(assets['status'] == 'fully_preserved_selected_artifacts' and assets['proof_sha256'] == args.artifact_proof_sha256
                and assets['target'] == plan['fresh_target'] and assets['hash_only_files'] == 0
                and [r['original_pin'] for r in assets['rows']] == artifact['artifact_pins'], 'full selected artifact provenance/coverage differs')
        for row in assets['rows']:
            path = Path(row['retained_path'])
            require(path == args.asset_manifest.parent/'target-files'/row['target_relative_path']
                    and not path.is_symlink() and path.resolve().is_relative_to((args.asset_manifest.parent/'target-files').resolve())
                    and sha(path) == row['original_pin']['sha256'] and path.stat().st_size == row['original_pin']['bytes']
                    and path.stat().st_mode == row['original_pin']['mode'], 'full preserved selected artifact bytes/modes differ')
        for case in plan['cases']:
            graph_contract.accepted_case(PLAN, case['label'])
    output = Path(plan['metadata_results'] if args.mode == 'metadata' else plan['native_results']) / 'execution-001'
    output.mkdir(parents=True, exist_ok=False)
    record = {'status': 'running', 'mode': args.mode, 'lease': args.lease,
              'argv': sys.argv, 'started_utc': gate.utc(), 'plan_sha256': sha(PLAN),
              'actual_gate_plan_sha256': sha(actual_plan), 'rows': [],
              'environment': {key: os.environ.get(key) for key in gate.ENV_KEYS},
              'scope': 'current composition correctness only; prior leaf histories and performance remain separate'}
    dump(output / 'record.json', record)
    try:
        for step in steps:
            require(all(sha(HERE/name) == value for name, value in seal['components'].items()), 'frozen helper/config changed between commands')
            for case in plan['cases']:
                graph_contract.immutable_inputs(case)
            standalone = plan['standalone']
            require(sha(standalone['authority_lock']) == standalone['authority_lock_sha256'], 'standalone24 authority changed')
            row = {'name': step['name'], 'started_utc': gate.utc()}
            record['rows'].append(row); dump(output / 'record.json', record)
            argv = [sys.executable, '-B', str(HERE / 'gate.py'), '--plan', str(actual_plan), '--step', step['name'], '--attempt', '001', '--lease', args.lease]
            row.update(argv=argv, cwd=str(ROOT))
            case = next((c for c in plan['cases'] + [standalone] if step['name'] in c['step_names']), None)
            lock = Path(case['authority_lock'] if case and case['label'] == 'standalone' else case['accepted_lock']) if case else None
            if lock:
                row['active_lock_before_sha256'] = sha(Path(case['consumer']) / 'Cargo.lock')
            with (output / (step['name'] + '.stdout')).open('xb') as stdout, (output / (step['name'] + '.stderr')).open('xb') as stderr:
                child = subprocess.Popen(argv, cwd=ROOT, stdout=stdout, stderr=stderr)
                row['wrapper_pid'] = child.pid
                row['wrapper_exit'] = wait_wrapper(child, 960, row)
            native_path = Path(plan['results']) / (step['name'] + '-001/record.json')
            row.update(gate_record=str(native_path), gate_record_sha256=sha(native_path), finished_utc=gate.utc())
            require(row['wrapper_exit'] == 0, 'unexpected native wrapper failure; stop without next gate')
            native = finished_native(native_path, step, actual_plan)
            if args.mode == 'metadata':
                row['case_label'] = case['label']
                row['active_lock_after_sha256'] = sha(Path(case['consumer']) / 'Cargo.lock')
                require(row['active_lock_before_sha256'] == row['active_lock_after_sha256'] == sha(lock), 'locked metadata changed active bytes')
                row['graph'] = (graph_contract.audit_standalone(case, native_path.parent / 'stdout') if case['label'] == 'standalone'
                                else graph_contract.audit_graph(case, native_path.parent / 'stdout', lock))
            else:
                row['proof'] = native_details(step, native_path.parent, plan)
                if step['name'] == 'linked-upstream188':
                    post_plan = HERE / 'postprocess-plan.json'
                    post_step = json.loads(post_plan.read_text())['steps'][0]
                    post = {'scope': 'Excluded bounded provenance preservation, no compiler/test retake',
                            'name': post_step['name'], 'started_utc': gate.utc()}
                    row['selected_preservation'] = post
                    post_argv = [sys.executable, '-B', str(HERE/'gate.py'), '--plan', str(post_plan),
                                 '--step', post_step['name'], '--attempt', '001', '--lease', args.lease]
                    post['argv'] = post_argv; dump(output/'record.json', record)
                    with (output/'selected-preservation.stdout').open('xb') as stdout, (output/'selected-preservation.stderr').open('xb') as stderr:
                        child = subprocess.Popen(post_argv, cwd=ROOT, stdout=stdout, stderr=stderr)
                        post['wrapper_pid'] = child.pid; post['wrapper_exit'] = wait_wrapper(child, 960, post)
                    post_path = Path(plan['results'])/(post_step['name']+'-001/record.json')
                    post.update(gate_record=str(post_path), gate_record_sha256=sha(post_path), finished_utc=gate.utc())
                    require(post['wrapper_exit'] == 0, 'linked payload preservation failed before subsequent Cargo')
                    finished_native(post_path, post_step, post_plan)
                    payload = HERE/'qualification/linked-upstream-selected-payload-001/record.json'
                    retained = json.loads(payload.read_text())
                    require(retained['status'] == 'complete; all copied member hashes rechecked'
                            and retained['selected_provider_test_artifacts'], 'full linked provider/test preservation incomplete')
                    post['payload_record_sha256'] = sha(payload)
            row.update(native_exit=native['native_exit'], minimum_free=native['minimum_free'], maximum_owned_apparent_bytes=native['maximum_owned_apparent_bytes'])
            require(all(sha(HERE/name) == value for name, value in seal['components'].items()), 'frozen helper/config changed during command')
            dump(output / 'record.json', record); print(json.dumps(row), flush=True)
        if args.mode == 'metadata':
            for label in [c['label'] for c in plan['cases']] + ['standalone']:
                require(len({row['graph']['graph_sha256'] for row in record['rows'] if row['case_label'] == label}) == 1,
                        'actual185/188 full resolve graph mismatch: ' + label)
        require(all(sha(HERE/name) == value for name, value in seal['components'].items()), 'frozen final helper/config changed')
        record['status'] = 'passed'
    except BaseException as error:
        record['status'] = 'failed_or_incomplete'
        record['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        record['finished_utc'] = gate.utc(); dump(output / 'record.json', record)


if __name__ == '__main__':
    main()
