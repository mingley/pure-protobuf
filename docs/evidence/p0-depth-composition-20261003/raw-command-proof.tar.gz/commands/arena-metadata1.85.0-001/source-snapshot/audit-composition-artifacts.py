"""WORK ONLY: audit a separately leased default188 no-run setup; launch nothing."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shlex
import shutil
import stat

import gate

HERE = Path(__file__).resolve().parent


def require(value, message):
    if not value:
        raise RuntimeError(message)


def parsed_rows(text, root, target):
    rows, other = [], []
    for number, line in enumerate(text.splitlines(), 1):
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            other.append((number, line)); continue
        require(isinstance(value, dict) and isinstance(value.get('reason'), str), 'malformed Cargo JSON record')
        require(not (value['reason'] == 'compiler-message' and value['message'].get('level') == 'error'), 'actual compiler diagnostic error')
        rows.append(value)
    allowed = {}
    for row in rows:
        if row['reason'] != 'build-script-executed': continue
        package = row['package_id']; match = re.search(r'#([^#@]+)@([^@]+)$', package)
        require(match is not None and Path(row['out_dir']).resolve().is_relative_to(target.resolve()), 'build-script origin/output malformed')
        key = (match[1], match[2]); allowed.setdefault(key, []).append(row)
    attributed = []
    for number, line in other:
        match = re.fullmatch(r'\[([^\s\]]+) ([^\s\]]+)\] (cargo(?:::|:).+)', line)
        require(match is not None and len(allowed.get((match[1], match[2]), [])) == 1,
                'unknown/non-attributable Cargo -vv stdout line')
        attributed.append({'line_number': number, 'content': line,
                           'content_utf8_sha256': hashlib.sha256(line.encode()).hexdigest(),
                           'build_script_json': allowed[(match[1], match[2])][0]})
    return rows, attributed


def selected(rows, root, target):
    package = 'path+file://' + str(root) + '#pbrs@0.2.0'
    artifacts = [r for r in rows if r['reason'] == 'compiler-artifact' and r['package_id'] == package]
    require(all(isinstance(r.get('profile'), dict) and {'opt_level','debuginfo','debug_assertions','overflow_checks','test'} <= set(r['profile']) for r in artifacts), 'selected compiler profile malformed')
    libraries = [r for r in artifacts if r['target']['kind'] == ['lib'] and not r['profile']['test']]
    tests = [r for r in artifacts if r['target']['kind'] == ['test']]
    names = {'unknown_group_depth', 'generated_map_value_depth'}
    require(len(libraries) == 1 and len(tests) == 2 and {r['target']['name'] for r in tests} == names,
            'unique current provider plus two selected test artifacts missing/duplicated')
    library = libraries[0]
    for row in [library] + tests:
        is_test = row in tests; name = row['target']['name']
        source = root / ('tests/' + name + '.rs' if is_test else 'src/lib.rs')
        require(row['manifest_path'] == str(root/'Cargo.toml') and row['target']['src_path'] == str(source)
                and row['fresh'] is False and set(row['features']) == {'codegen', 'conformance', 'default', 'json', 'reflect', 'text'},
                'provider/source/fresh/default feature attribution differs')
        require(row['profile'] == {'opt_level': '0', 'debuginfo': 0, 'debug_assertions': True,
                                   'overflow_checks': True, 'test': is_test}, 'ordinary compiler profile differs')
        require(row['filenames'] and all(Path(p).resolve().is_relative_to(target.resolve()) for p in row['filenames']), 'selected artifact escapes exact owned target')
        if is_test: require(row['executable'] in row['filenames'], 'actual selected test executable absent')
    rlibs = [Path(p) for p in library['filenames'] if p.endswith('.rlib')]
    require(len(rlibs) == 1, 'unique observed provider rlib missing')
    return library, tests, rlibs[0]


def invocations(text, root, compiler, rlib, captured_path):
    expected = {'pbrs', 'unknown_group_depth', 'generated_map_value_depth'}; found = {}
    for line in text.splitlines():
        match = re.fullmatch(r'\s*Running `(.*)`\s*', line)
        if match is None: continue
        tokens = shlex.split(match[1]); at = next((i for i, t in enumerate(tokens) if not re.match(r'^[A-Za-z_][A-Za-z0-9_-]*=', t)), None)
        if at is None or tokens[at] not in [compiler['path'], 'rustc']: continue
        args = tokens[at+1:]
        if '--crate-name' not in args: continue
        name = args[args.index('--crate-name')+1]
        if name not in expected: continue
        require(name not in found, 'duplicate selected rustc source invocation')
        selected_path = shutil.which(tokens[at], path=captured_path)
        require(selected_path is not None and gate.executable(selected_path) == compiler, 'actual captured compiler PATH/identity/hash differs')
        environment = dict(t.split('=', 1) for t in tokens[:at])
        require(environment.get('CARGO_MANIFEST_DIR') == str(root) and ('PATH' not in environment or environment['PATH'] == captured_path), 'actual compile-time source root/PATH differs')
        source = 'src/lib.rs' if name == 'pbrs' else 'tests/' + name + '.rs'
        require(source in args or str(root/source) in args, 'actual selected compiler source absent')
        if name != 'pbrs': require('--test' in args and 'pbrs=' + str(rlib) in args, 'actual test links a different provider')
        found[name] = {'raw': match[1], 'argv': tokens, 'environment': environment, 'selected_compiler': compiler}
    require(set(found) == expected, 'all three actual source compiler invocations missing')
    return found


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', type=Path, required=True); parser.add_argument('--record', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True); args = parser.parse_args()
    require(not args.output.exists(), 'fresh immutable source-proof output required')
    plan = json.loads(args.plan.read_text()); step = plan['steps'][0]; record = json.loads(args.record.read_text())
    root, target = Path(step['source_root']), Path(plan['fresh_target'])
    require(len(plan['steps']) == 1 and record['argv'] == step['argv'] and record['plan_sha256'] == gate.digest(args.plan)
            and record['runner_sha256'] == gate.digest(HERE/'gate.py') and record['source_before']['commit'] == plan['source']
            and record['native_exit'] == record['exit'] == 0 and record['guard'] is None, 'actual separately leased setup did not pass')
    require(not any(record.get(k) for k in ['exception','drift','cleanup_exception','post_cleanup_observation_exception'])
            and all(record[k+'_before'] == record[k+'_after'] for k in ['source','tools','helper_closure','work_helpers'])
            and gate.source(root) == record['source_after'], 'actual source/tools/helpers drift')
    rows, attributed = parsed_rows((args.record.parent/'stdout').read_text(), root, target)
    library, tests, rlib = selected(rows, root, target)
    actual = invocations((args.record.parent/'stderr').read_text(), root, record['tools_before']['rustc'], rlib, record['environment']['PATH'])
    selected_files = {Path(p) for row in [library]+tests for p in row['filenames']}
    selected_files.add(rlib.parent / (rlib.name.removeprefix('lib').removesuffix('.rlib')+'.d'))
    for test in tests: selected_files.add(Path(test['executable']+'.d'))
    for artifact in [rlib]+[Path(t['executable'])for t in tests]:
        fingerprint = target/'debug/.fingerprint'/('pbrs-'+artifact.stem.rsplit('-',1)[1])
        require(fingerprint.is_dir(), 'selected provider/test fingerprint absent')
        selected_files.update(p for p in fingerprint.iterdir()if p.is_file())
    pins = []; elf_counts = {}
    for path in sorted(selected_files):
        before = path.stat(); require(not path.is_symlink() and stat.S_ISREG(before.st_mode) and path.resolve().is_relative_to(target.resolve()), 'selected payload kind/target differs')
        h = hashlib.sha256(); data_count = 0; tail = b''; needle = str(root).encode()
        with path.open('rb') as stream:
            for block in iter(lambda: stream.read(1024*1024), b''):
                sample = gate.cache_sample(plan['owned_cache_roots'], root)
                require(sample['free_bytes'] >= gate.LIMIT and sample['owned_apparent_bytes'] <= gate.LIMIT, 'source artifact audit sampled fixed resource guard')
                h.update(block); joined = tail+block; data_count += joined.count(needle)-tail.count(needle); tail = joined[-(len(needle)-1):]
        require((before.st_dev,before.st_ino,before.st_size,before.st_mtime_ns,before.st_mode)==tuple(getattr(path.stat(),k)for k in ['st_dev','st_ino','st_size','st_mtime_ns','st_mode']), 'selected payload changed during audit')
        pins.append({'path':str(path),'relative_target_path':str(path.relative_to(target)),'sha256':h.hexdigest(),'bytes':before.st_size,'mode':before.st_mode,'device':before.st_dev,'inode':before.st_ino,'mtime_ns':before.st_mtime_ns})
        if path in [Path(t['executable'])for t in tests]:
            with path.open('rb') as stream: magic = stream.read(4)
            require(magic == b'\x7fELF' and before.st_mode & 0o111 and data_count > 0, 'actual selected ELF/compile-time source root absent')
            elf_counts[path.name] = data_count
    prerequisite = {p['path']:p['sha256'] for p in pins}
    for path in [args.plan, args.record, args.record.parent/'stdout', args.record.parent/'stderr', Path(__file__),
                 root/'Cargo.toml', root/'Cargo.lock', root/'tests/unknown_group_depth.rs', root/'tests/generated_map_value_depth.rs',
                 root/'src/lib.rs', Path(record['tools_before']['rustc']['path'])]:
        prerequisite[str(path)] = gate.digest(path)
    require(gate.source(root) == record['source_after'] and gate.tools(step['argv'], record['environment']) == record['tools_after'],
            'source or actual selected tool changed after audit')
    proof={'status':'qualified_current_composition_artifacts','source':plan['source'],'target':str(target),
           'setup_record_sha256':gate.digest(args.record),'setup_plan_sha256':gate.digest(args.plan),'auditor_sha256':gate.digest(__file__),
           'compiler_artifacts':{'library':library,'tests':tests},'actual_rustc':actual,'attributed_non_json_build_script_output':attributed,
           'artifact_pins':pins,'elf_current_root_counts':elf_counts,'runtime_prerequisite_pins':prerequisite,
           'scope':'Fresh current-root default188 provider plus both compile-time-root generated-fixture test ELFs only; no semantic/performance acceptance.',
           'limits':'No complete native linker/sysroot/runtime closure. Full selected bytes/modes/fingerprints must be preserved outside target before subsequent Cargo.'}
    args.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({'status':proof['status'],'output':str(args.output),'sha256':gate.digest(args.output)}))


if __name__ == '__main__': main()
