"""Source-only qualification of the approved full pinned protobuf SDK attachment."""
import os
from pathlib import Path
import re
import stat
import subprocess

SDK = Path("/workspace/pure-protobuf/third_party/protobuf")
PIN = "35cd01f9fe9afbeea38cc7b979a3b6bfcde82c03"


def command(*args):
    return subprocess.check_output(["git", "-C", str(SDK), *args], text=True).strip()


def identity(path):
    info = path.lstat()
    return {"device": info.st_dev, "inode": info.st_ino, "mtime_ns": info.st_mtime_ns,
            "bytes": info.st_size, "mode": stat.S_IMODE(info.st_mode)}


def snapshot(root, digest):
    parent = root / "third_party/protobuf"
    if not parent.is_symlink() or os.readlink(parent) != str(SDK) or parent.resolve() != SDK.resolve():
        raise RuntimeError("protobuf attachment differs from the approved exact SDK symlink")
    if (root / "third_party").is_symlink():
        raise RuntimeError("unexpected third_party containing-directory alias")
    link = parent
    target = SDK / "src"
    if command("rev-parse", "--show-toplevel") != str(SDK) or command("rev-parse", "HEAD") != PIN:
        raise RuntimeError("SDK is not the exact pinned protobuf source repository")
    if command("status", "--porcelain"):
        raise RuntimeError("pinned SDK repository is dirty")
    files = {}
    for path in sorted(target.rglob("*")):
        if path.is_symlink():
            raise RuntimeError("unqualified alias inside SDK src")
        if path.is_file():
            before = identity(path)
            value = digest(path)
            if before != identity(path):
                raise RuntimeError("SDK source changed while hashing")
            files[str(path.relative_to(target))] = {"sha256": value, **before}
    source = (root / "rust_out_shared/build.rs").read_text()
    blocks = re.findall(r"files: &\[(.*?)\]", source, re.DOTALL)
    direct = sorted({name for block in blocks for name in re.findall(r'"([^"]+\.proto)"', block)})
    if not direct:
        raise RuntimeError("could not identify unchanged build.rs direct proto inputs")
    vendor = root / "vendor/google"
    proto_root = SDK
    vendor_equality = {}
    for path in sorted(vendor.rglob("*.proto")):
        name = path.relative_to(vendor)
        logical = str(name).replace("rust-tests/shared/utf8/", "rust/test/shared/utf8/")
        other = SDK / logical
        if not other.is_file():
            other = target / logical
        if not other.is_file() or path.read_bytes() != other.read_bytes():
            raise RuntimeError("existing vendored schema differs from exact SDK counterpart: " + str(name))
        vendor_equality[str(name)] = {"logical_path": logical, "sdk_path": str(other), "sha256": digest(path), "exact_equal": True}

    def resolve(name):
        if Path(name).is_absolute() or ".." in Path(name).parts:
            raise RuntimeError("unqualified proto import path")
        for directory in [proto_root, target]:
            path = directory / name
            if path.is_file():
                return path
        raise RuntimeError("unresolved actual build.rs proto/import: " + name)

    closure = {}
    pending = list(direct)
    while pending:
        name = pending.pop()
        if name in closure:
            continue
        path = resolve(name)
        # These pinned inputs use standard quoted imports. Genuine protoc will
        # perform the language parse; this is a source/import inventory only.
        imports = re.findall(r'^\s*import\s+(?:(?:public|weak)\s+)?"([^"]+)"\s*;',
                             path.read_text(), re.MULTILINE)
        closure[name] = {"path": str(path), "sha256": digest(path), "imports": imports,
                         "origin": "SDK src" if path.is_relative_to(target) else "SDK root fixture"}
        pending.extend(imports)
    return {"sdk_root": str(SDK), "sdk_commit": PIN, "sdk_src": str(target),
            "containing_directory": identity(root / "third_party"), "protobuf_symlink": identity(link),
            "configured_target": os.readlink(link), "resolved_target": str(link.resolve()),
            "sdk_src_files": files, "sdk_src_file_count": len(files),
            "sdk_proto_count": sum(name.endswith(".proto") for name in files),
            "direct_build_rs_inputs": direct, "resolved_proto_import_closure": closure,
            "proto_root_selection": "actual build.rs selects exact SDK root; every existing vendored schema is byte-identical",
            "vendor_schema_equality": vendor_equality,
            "import_inventory_limit": "quoted-import source inventory; actual protoc parse/dispatch remains unqualified"}
