"""WORK ONLY helper utilities. Every actual launch belongs to gate.py's
reviewed owned-PID/start-time process group and fixed 2GiB cache/free guard.
This module launches nothing on import and has no independent compiler CLI.
"""
import json
import os
import subprocess
import tomllib
from pathlib import Path
import gate

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
PROOF = HERE / 'qualification'
SOURCE = '68e4d57d67c73ff87ea1404bee18c3c70a9dfb93'
TOOLS = Path('/workspace/pure-protobuf/work/toolchain/rustup/toolchains')
CARGO_HOME = Path('/workspace/pure-protobuf/work/toolchain/cargo')
TARGET = ROOT / 'target/p0-composition-gates'
sha = gate.digest
utc = gate.utc
snapshot = gate.source


def git(cwd, *args):
 return subprocess.run(['git', *args], cwd=cwd, capture_output=True, check=True).stdout


def registry(lock):
 return sorted((p['name'], p['version'], p['source'], p.get('checksum'))
               for p in tomllib.loads(lock.read_text())['package'] if p.get('source'))


def cache_usage():
 roots = [ROOT / 'target']
 row = gate.cache_sample(roots, ROOT)
 return {'global_available_bytes': row['free_bytes'], 'owned_apparent_bytes': row['owned_apparent_bytes'], 'raw': row}


def environment(toolchain, name, attempt):
 if os.environ.get('P0_UNDER_REVIEWED_GATE') != '1':
  raise RuntimeError('helper must execute as a recorded child of reviewed QG18 gate.py')
 env = os.environ.copy()
 if env.get('CARGO_TARGET_DIR') != str(TARGET) or env.get('CARGO_BUILD_JOBS') != '1' or env.get('CARGO_INCREMENTAL') != '0' or env.get('CARGO_NET_OFFLINE') != 'true':
  raise RuntimeError('fixed owned target/jobs/incremental/offline policy mismatch')
 if env.get('RUSTUP_TOOLCHAIN') != toolchain:
  raise RuntimeError('gate toolchain mismatch')
 for key in list(env):
  if key.startswith('PURE_PROTOBUF_'):
   raise RuntimeError('ambient generator options are unsupported: ' + key)
 env.setdefault('PBRS_QG18_CONSUMER_DIR', str(HERE / 'consumers/group-shared'))
 env.setdefault('PBRS_QG20_CONSUMER_DIR', str(HERE / 'consumers/map-shared'))
 env['PBRS_QG20_CONSUMER_CARGO'] = str(TOOLS / (toolchain + '-x86_64-unknown-linux-gnu') / 'bin/cargo')
 env['PBRS_QG18_CONSUMER_CARGO'] = str(TOOLS / (toolchain + '-x86_64-unknown-linux-gnu') / 'bin/cargo')
 return env


def run_guarded(argv, cwd, env, out, cap, reserve, timeout):
 """Nested command recorder; resource/process ownership comes from outer gate.
 The outer gate cleans descendants on ordinary exit, interruption or errors.
 """
 if cap != gate.LIMIT or reserve != gate.LIMIT or env.get('P0_UNDER_REVIEWED_GATE') != '1':
  raise RuntimeError('nested launch requires reviewed fixed2GiB outer gate')
 out.mkdir(parents=True, exist_ok=False)
 before = snapshot(ROOT); consumer_before = gate.consumer_inputs(cwd)
 tools_before = gate.tools(argv, env); lock_before = registry(cwd / 'Cargo.lock')
 record = {'kind':'nested shared consumer within reviewed outer gate', 'argv':argv,'cwd':str(cwd),'started_utc':utc(),
           'source_before':before,'consumer_inputs_before':consumer_before,'tools_before':tools_before,'registry_before':lock_before}
 (out / 'command.json').write_text(json.dumps(record,indent=2)+'\n')
 with (out / 'stdout').open('xb') as stdout, (out / 'stderr').open('xb') as stderr:
  child = subprocess.run(argv,cwd=cwd,env=env,stdout=stdout,stderr=stderr,timeout=timeout)
 result = {'exit':child.returncode,'stopped_by':None,'source_unchanged':snapshot(ROOT)==before,
           'consumer_inputs_unchanged':gate.consumer_inputs(cwd)==consumer_before,
           'tools_unchanged':gate.tools(argv,env)==tools_before,'registry_unchanged':registry(cwd/'Cargo.lock')==lock_before,'completed_utc':utc()}
 (out / 'result.json').write_text(json.dumps(result,indent=2)+'\n')
 return child.returncode or (0 if all(result[key] for key in ['source_unchanged','consumer_inputs_unchanged','tools_unchanged','registry_unchanged']) else 126)
