"""WORK ONLY: full bounded preservation of the qualified current provider/two-test selected files."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
import sys

HERE = Path(__file__).resolve().parent
import argparse
import gate


def require(value, message):
    if not value:
        raise RuntimeError(message)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--proof', type=Path, required=True); parser.add_argument('--proof-sha256', required=True)
    args = parser.parse_args(); PROOF = args.proof; PROOF_SHA = args.proof_sha256
    require(gate.digest(PROOF) == PROOF_SHA, 'qualified proof changed before preservation')
    proof = json.loads(PROOF.read_text())
    plan_path = HERE / 'artifact-setup-plan.json'
    plan = json.loads(plan_path.read_text())
    root, target = Path(plan['steps'][0]['source_root']), Path(proof['target'])
    native_path = HERE / 'qualification/default188-source-setup-001/record.json'
    native = json.loads(native_path.read_text())
    require(gate.source(root) == native['source_after'], 'candidate source context changed')
    require(proof['status'] == 'qualified_current_composition_artifacts' and proof['source'] == plan['source']
            and proof['setup_record_sha256'] == gate.digest(native_path), 'current composition qualified source setup differs')
    selected_count = len(proof['artifact_pins']); selected_bytes = sum(row['bytes']for row in proof['artifact_pins'])
    out = HERE / 'proof-assets'
    out.mkdir(exist_ok=False)
    payload = out / 'target-files'
    payload.mkdir()
    (out / 'executed-preservation-source.py').write_bytes(Path(__file__).read_bytes())
    source_paths = [Path(__file__), HERE / 'gate.py', PROOF, plan_path, native_path]
    record = {'scope': 'Full selected artifact files only, no whole-cache archive/prune or native execution',
              'status': 'running', 'started_utc': gate.utc(), 'argv': sys.argv, 'cwd': str(Path.cwd()),
              'proof_sha256': PROOF_SHA, 'source_before': {str(path): gate.digest(path) for path in source_paths},
              'python_before': gate.executable(sys.executable),
              'environment': {key: os.environ[key] for key in gate.ENV_KEYS if key in os.environ},
              'resource_samples': [], 'rows': []}

    def guard(next_bytes=0):
        sample = gate.cache_sample(plan['owned_cache_roots'], root)
        record['resource_samples'].append(sample)
        require(sample['free_bytes'] >= gate.LIMIT + next_bytes and sample['owned_apparent_bytes'] <= gate.LIMIT,
                'fixed aggregate 2 GiB cap/free floor during selected-file preservation')

    def identity(value):
        return {'bytes': value.st_size, 'device': value.st_dev, 'inode': value.st_ino,
                'mode': value.st_mode, 'mtime_ns': value.st_mtime_ns}

    try:
        guard()
        for pin in proof['artifact_pins']:
            source = Path(pin['path'])
            relative = source.relative_to(target)
            require(not source.is_symlink() and source.resolve().is_relative_to(target.resolve()),
                    'selected source link escaped exclusive target')
            destination = payload / relative
            destination.parent.mkdir(parents=True, exist_ok=True)
            source_fd = os.open(source, os.O_RDONLY | os.O_NOFOLLOW)
            with os.fdopen(source_fd, 'rb') as stream:
                before = os.fstat(stream.fileno())
                require(stat.S_ISREG(before.st_mode) and identity(before) == {key: pin[key] for key in identity(before)},
                        'selected source metadata differs from qualified proof')
                value = hashlib.sha256()
                with destination.open('xb') as retained:
                    for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                        guard(len(chunk))
                        value.update(chunk)
                        retained.write(chunk)
                    retained.flush()
                    os.fsync(retained.fileno())
                require(identity(os.fstat(stream.fileno())) == identity(before)
                        and identity(source.stat()) == identity(before), 'selected source changed during copy')
            require(value.hexdigest() == pin['sha256'], 'selected source content differs from proof')
            destination.chmod(stat.S_IMODE(before.st_mode))
            os.utime(destination, ns=(before.st_atime_ns, before.st_mtime_ns))
            retained_hash = hashlib.sha256()
            with destination.open('rb') as retained:
                for chunk in iter(lambda: retained.read(1024 * 1024), b''):
                    guard()
                    retained_hash.update(chunk)
            retained_stat = destination.stat()
            require(retained_hash.hexdigest() == pin['sha256']
                    and retained_stat.st_size == pin['bytes'] and retained_stat.st_mode == pin['mode'],
                    'full retained selected content/mode verification failed')
            record['rows'].append({'target_relative_path': relative.as_posix(), 'original_pin': pin,
                                   'retained_path': str(destination), 'retained_sha256': retained_hash.hexdigest(),
                                   'retained_identity': identity(retained_stat)})
        guard()
        require(gate.source(root) == native['source_after'], 'candidate source context changed after preservation')
        record['source_after'] = {str(path): gate.digest(path) for path in source_paths}
        record['python_after'] = gate.executable(sys.executable)
        require(record['source_before'] == record['source_after']
                and record['python_before'] == record['python_after'], 'preservation helper/input/tool drift')
        manifest = {'status': 'fully_preserved_selected_artifacts', 'proof_sha256': PROOF_SHA,
                    'target': str(target), 'selected_count': selected_count, 'selected_bytes': selected_bytes,
                    'rows': record['rows'], 'hash_only_files': 0,
                    'mode_scope': 'Exact full st_mode for each regular retained file; no symlink or omitted selected payload.'}
        manifest_path = out / 'selected-assets-manifest.json'
        manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
        record['manifest_sha256'] = gate.digest(manifest_path)
        record['status'] = 'fully_preserved_selected_artifacts'
    except BaseException as error:
        record['exception'] = repr(error)
        record['status'] = 'failed_or_incomplete'
        raise
    finally:
        record['finished_utc'] = gate.utc()
        record['minimum_free'] = min((row['free_bytes'] for row in record['resource_samples']), default=None)
        record['maximum_owned_apparent_bytes'] = max((row['owned_apparent_bytes'] for row in record['resource_samples']), default=None)
        (out / 'record.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'status': record['status'], 'manifest_sha256': record['manifest_sha256'],
                      'record_sha256': gate.digest(out / 'record.json'), 'minimum_free': record['minimum_free'],
                      'maximum_owned_apparent_bytes': record['maximum_owned_apparent_bytes']}))


if __name__ == '__main__':
    main()
