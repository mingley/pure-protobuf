#!/usr/bin/env python3
"""Compile the exact QG20 bounded fixture with shared_pool=true, using the
reported plugin executable, pinned protoc and one owned offline/locked cache.
No compiler or subprocess launches without --execute and root ordinary lease.
"""
import argparse
import json
import subprocess
import ordinary
import regen_retained
import graph_contract


def main():
 p = argparse.ArgumentParser(description=__doc__)
 p.add_argument('--execute', action='store_true'); p.add_argument('--lease-label')
 p.add_argument('--attempt', required=True); p.add_argument('--plugin-build-attempt', required=True)
 p.add_argument('--cache-cap-bytes', type=int); p.add_argument('--free-reserve-bytes', type=int)
 p.add_argument('--timeout', type=int, default=900)
 args = p.parse_args()
 if not args.execute:
  print(json.dumps({'status': 'NOT_RUN; source-only preparation', 'source_commit': ordinary.SOURCE, 'profile': 'shared_pool=true', 'consumer_cases': 15}))
  return
 if not args.lease_label or args.cache_cap_bytes != ordinary.gate.LIMIT or args.free_reserve_bytes != ordinary.gate.LIMIT:
  p.error('--execute requires root lease and explicit bounds')
 if any(ordinary.Path(value).name != value for value in [args.attempt, args.plugin_build_attempt]):
  p.error('attempts must be unique simple directory names')
 root = ordinary.ROOT
 if ordinary.git(root, 'rev-parse', 'HEAD').decode().strip() != ordinary.SOURCE or ordinary.git(root, 'status', '--short', '--untracked-files=no'):
  p.error('source/clean-state mismatch')
 build = ordinary.PROOF / args.plugin_build_attempt
 command = json.loads((build / 'record.json').read_text()); result = command
 if result['exit'] or result['guard'] or result.get('drift') or result['source_before'] != result['source_after'] or result['tools_before'] != result['tools_after'] or command['source_before']['commit'] != ordinary.SOURCE:
  p.error('successful unchanged-source plugin build required')
 artifacts = []
 for line in (build / 'stdout').read_text().splitlines():
  item = json.loads(line)
  if item.get('reason') == 'compiler-artifact' and item.get('target', {}).get('name') == 'protoc-gen-pbrs' and 'bin' in item['target'].get('kind', []) and ordinary.Path(item['manifest_path']).resolve() == (root / 'Cargo.toml').resolve() and item.get('executable'):
   artifacts.append(item['executable'])
 if len(set(artifacts)) != 1:
  p.error('exactly one current plugin artifact required')
 plugin = ordinary.Path(artifacts[0]); protoc = regen_retained.PROTOC
 if not plugin.is_relative_to(ordinary.TARGET):
  p.error('plugin lies outside owned target')
 stage = ordinary.PROOF / args.attempt
 stage.mkdir(parents=True, exist_ok=False)
 env = ordinary.environment('1.88.0', 'shared-consumer', stage)
 case, accepted = graph_contract.accepted_case(ordinary.HERE / 'composition-plan.json', 'map-shared')
 consumer = ordinary.Path(env['PBRS_QG20_CONSUMER_DIR'])
 if consumer != ordinary.Path(case['consumer']) or env.get('PBRS_QG20_ACCEPTED_CONSUMER_LOCK') != case['accepted_lock']:
  p.error('explicit prepared consumer/immutable accepted lock mismatch')
 (consumer / 'src').mkdir(parents=True, exist_ok=True)
 root_lock = (root / 'Cargo.lock').read_bytes()
 accepted_lock = ordinary.Path(case['accepted_lock']).read_bytes()
 (stage / 'root-seed.Cargo.lock').write_bytes(root_lock)
 (stage / 'seed-before-normalization.Cargo.lock').write_bytes((consumer / 'Cargo.lock.seed').read_bytes())
 (stage / 'accepted.Cargo.lock').write_bytes(accepted_lock)
 (stage / 'accepted-graph.json').write_text(json.dumps(accepted, indent=2) + '\n')
 env['PBRS_QG20_ROOT_LEASE'] = args.lease_label
 proto = root / 'tests/fixtures/generated_map_value_depth.proto'
 argv = [str(protoc), '--plugin=protoc-gen-pbrs=' + str(plugin), '--pbrs_out=shared_pool=true:' + str(consumer / 'src'), '-I', str(proto.parent), str(proto)]
 record = {'kind': 'shared_pool=true bounded fixture', 'source_commit': ordinary.SOURCE, 'root_lease_label': args.lease_label, 'argv': argv,
           'inputs': [{'path': str(path.resolve()), 'sha256': ordinary.sha(path), 'bytes': path.stat().st_size} for path in [plugin, protoc, proto]], 'consumer_cases': 15}
 (stage / 'generate-command.json').write_text(json.dumps(record, indent=2) + '\n')
 usage = ordinary.cache_usage()
 if usage['owned_apparent_bytes'] > args.cache_cap_bytes or usage['global_available_bytes'] < args.free_reserve_bytes:
  raise RuntimeError('cache/free guard rejected before generator')
 stamp = (regen_retained.BUILD / '.pbrs-protobuf-pin').read_text().strip()
 if stamp != 'v35.1 35cd01f9fe9afbeea38cc7b979a3b6bfcde82c03':
  raise RuntimeError('protoc source stamp mismatch')
 version = subprocess.run([str(protoc), '--version'], cwd=root, env=env, capture_output=True, timeout=30)
 (stage / 'protoc-version.stdout').write_bytes(version.stdout); (stage / 'protoc-version.stderr').write_bytes(version.stderr)
 if version.returncode or version.stdout.decode().strip() != 'libprotoc 35.1':
  raise RuntimeError('protoc version mismatch')
 generated = subprocess.run(argv, cwd=root, env=env, capture_output=True, timeout=120)
 (stage / 'generate.stdout').write_bytes(generated.stdout); (stage / 'generate.stderr').write_bytes(generated.stderr)
 (stage / 'generate-result.json').write_text(json.dumps({'exit': generated.returncode}) + '\n'); generated.check_returncode()
 emitted = consumer / 'src/generated_map_value_depth.rs'
 text = emitted.read_text()
 if 'pbrs::gencode::conformance_pool()' not in text or 'pub const FILE_DESCRIPTOR_SET' in text:
  raise RuntimeError('shared_pool=true output did not contain the actual bundled-pool profile')
 (consumer / 'src/qg20.rs').write_bytes(emitted.read_bytes())
 (consumer / 'src/lib.rs').write_bytes((root / 'tests/fixtures/generated_map_value_depth_consumer.rs').read_bytes())
 (consumer / 'src/vectors.rs').write_bytes((root / 'tests/support/generated_map_value_depth.rs').read_bytes())
 manifest = '[package]\nname="qg20-shared-map-consumer"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\npbrs={path=' + json.dumps(str(root)) + '}\n'
 if (consumer / 'Cargo.toml').read_bytes() != manifest.encode() or (consumer / 'Cargo.lock').read_bytes() != accepted_lock:
  raise RuntimeError('prepared manifest/active accepted lock changed; helper never overwrites accepted lock')
 retained = stage / 'actual-consumer-inputs'; (retained / 'src').mkdir(parents=True)
 for name in ['Cargo.toml', 'Cargo.lock', 'src/lib.rs', 'src/vectors.rs', 'src/qg20.rs']:
  (retained / name).write_bytes((consumer / name).read_bytes())
 cargo = ordinary.TOOLS / '1.88.0-x86_64-unknown-linux-gnu/bin/cargo'
 code = ordinary.run_guarded([str(cargo), 'test', '--offline', '--locked', '--quiet', '--lib', '--', '--test-threads=1'], consumer, env, stage / 'cargo', args.cache_cap_bytes, args.free_reserve_bytes, args.timeout)
 result = json.loads((stage / 'cargo/result.json').read_text())
 result['registry_subset_of_frozen_root'] = set(ordinary.registry(consumer / 'Cargo.lock')) <= set(ordinary.registry(root / 'Cargo.lock'))
 result['fifteen_consumer_cases_passed'] = '15 passed; 0 failed' in (stage / 'cargo/stdout').read_text()
 result['actual_shared_pool_profile'] = True
 result['execution_scope'] = 'Actual generated Parse/validate/Serialize15-case consumer; custom fixture reflection lookup and table dispatch are not qualified.'
 result['generation_inputs_unchanged'] = all(ordinary.sha(ordinary.Path(row['path'])) == row['sha256'] for row in record['inputs'])
 (stage / 'root-after.Cargo.lock').write_bytes((root / 'Cargo.lock').read_bytes())
 (stage / 'accepted-after-test.Cargo.lock').write_bytes((consumer / 'Cargo.lock').read_bytes())
 result['accepted_graph_sha256'] = accepted['graph']['graph_sha256']
 result['prefrozen_lock_bytes_equal'] = accepted_lock == (consumer / 'Cargo.lock').read_bytes() == ordinary.Path(case['accepted_lock']).read_bytes()
 result['root_provider_bytes_equal'] = root_lock == (root / 'Cargo.lock').read_bytes()
 result['raw_lock_sha256'] = {name: ordinary.sha(stage / name) for name in ['root-seed.Cargo.lock', 'root-after.Cargo.lock', 'seed-before-normalization.Cargo.lock', 'accepted.Cargo.lock', 'accepted-after-test.Cargo.lock']}
 (stage / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
 raise SystemExit(code or (0 if all(result[key] for key in ['registry_subset_of_frozen_root', 'fifteen_consumer_cases_passed', 'generation_inputs_unchanged', 'prefrozen_lock_bytes_equal', 'root_provider_bytes_equal']) else 1))


if __name__ == '__main__':
 main()
