from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
here=Path('/workspace/map-remove-20261106');root=Path('/workspace/pure-protobuf');env=os.environ.copy();env.update(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_TARGET_DIR=str(here/'target-miri'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0');env['PATH']=str(root/'work/cargo/bin')+':'+env['PATH'];env.pop('RUSTFLAGS',None)
def target_size():return sum(p.stat().st_size for directory in [here/'target',here/'target-miri'] if directory.exists() for p in directory.rglob('*') if p.is_file())
env['MIRIFLAGS']='-Zmiri-disable-isolation -Zmiri-strict-provenance'
filters=['raw_mut_remove_keeps_unrelated_duplicate_winner','raw_removal_releases_only_removed_bytes_and_keeps_survivors_live','removal_panic_guards_prevent_stale_visible_indexes']
for number,filter in enumerate(filters):
 name='candidate-miri-'+str(number);command=['cargo','+nightly-2026-10-29','miri','test','--offline','--locked','--lib','--no-default-features','map::tests::'+filter,'--','--exact','--nocapture'];guard=None
 inputs={str(p.relative_to(here/'tree')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((here/'tree').rglob('*')) if p.is_file() and '.git' not in p.parts}
 with (here/(name+'.log')).open('w') as log:
  proc=subprocess.Popen(command,cwd=here/'tree',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if shutil.disk_usage(here).free<1024**3:guard='disk-floor'
   if target_size()>300*1024**2:guard='target-cap'
   if guard:os.killpg(proc.pid,signal.SIGTERM);break
   time.sleep(.5)
  code=proc.wait()
 report={'name':name,'command':command,'exit_code':code,'guard':guard,'source_sha256':inputs,'miri_flags':env['MIRIFLAGS'],'target_bytes':target_size(),'free_bytes':shutil.disk_usage(here).free}
 (here/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}),flush=True);print((here/(name+'.log')).read_text()[-6000:],flush=True)
 assert code==0 and guard is None
