from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import platform
import random
import shutil
import statistics
import subprocess
import sys
import time

assert sys.argv[1:] == ['--authorized-quiet-slot'], 'Wait for the parent quiet GO'
HERE = Path(__file__).resolve().parent
case_plan = json.loads((HERE / 'canonical-cases.json').read_text())
cases = case_plan['rows']
builds = {variant: json.loads((HERE / f'canonical-{variant}-cpu.json').read_text())
          for variant in ['baseline', 'candidate']}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for variant, build in builds.items():
    assert build['exit_code'] == 0 and build['guard'] is None
    assert build['source_before'] == build['source_after']
    assert sha(HERE / f'canonical-{variant}-cpu-bin') == build['retained_sha256']
assert builds['baseline']['constant_inputs'] == builds['candidate']['constant_inputs']
for artifact in ['binary_artifact', 'library_artifact']:
    for field in ['package_id', 'manifest_path', 'profile', 'features', 'filenames']:
        assert builds['baseline'][artifact][field] == builds['candidate'][artifact][field]
assert builds['baseline']['crate_metadata'] == builds['candidate']['crate_metadata']
for relative, digest in builds['candidate']['source_after'].items():
    assert sha(HERE / 'tree' / relative) == digest
constant = builds['candidate']['constant_inputs']
for relative, key in [('src/main.rs', 'harness_source_sha256'),
                      ('Cargo.toml', 'harness_manifest_sha256'),
                      ('Cargo.lock', 'harness_lock_sha256')]:
    assert sha(HERE / 'harness' / relative) == constant[key]

cpus = sorted(os.sched_getaffinity(0))
cpu = cpus[len(cpus) // 2]
os.sched_setaffinity(0, {cpu})
plan = {'schema': 'pbrs.map-remove-cpu.v1', 'started': datetime.now(timezone.utc).isoformat(),
        'host': platform.node(), 'platform': platform.platform(), 'available_cpus': cpus, 'cpu': cpu,
        'cases': cases, 'pairs': case_plan['cpu_pairs_per_case'], 'seed': 2026110604,
        'binary_sha256': {variant: build['retained_sha256'] for variant, build in builds.items()},
        'scope': case_plan['scope'] + ' Shared host, no independent host qualification or Prost/RPC comparison.'}
assert not (HERE / 'canonical-cpu-plan.json').exists()
(HERE / 'canonical-cpu-plan.json').write_text(json.dumps(plan, indent=2) + '\n')
rng = random.Random(plan['seed'])
order = []
for pair in range(plan['pairs']):
    shuffled = list(range(len(cases)))
    rng.shuffle(shuffled)
    for number in shuffled:
        variants = ['baseline', 'candidate']
        rng.shuffle(variants)
        order.append({'case_no': number, 'pair': pair, 'variants': variants})
(HERE / 'canonical-cpu-order.json').write_text(json.dumps(order, indent=2) + '\n')
observed = {number: [] for number in range(len(cases))}
started = time.monotonic()
with (HERE / 'canonical-cpu-raw.jsonl').open('x') as log:
    for step in order:
        case = cases[step['case_no']]
        paired = {}
        for variant in step['variants']:
            assert shutil.disk_usage(HERE).free > 1024 ** 3
            command = [str(HERE / f'canonical-{variant}-cpu-bin'), case['shape'], case['kind'],
                       str(case['entries']), str(case['key_length']), str(case['cpu_repetitions'])]
            process = subprocess.run(command, capture_output=True, text=True)
            record = {'case_no': step['case_no'], 'pair': step['pair'], 'variant': variant,
                      'command': command, 'exit_code': process.returncode,
                      'stdout': process.stdout, 'stderr': process.stderr}
            log.write(json.dumps(record) + '\n')
            log.flush()
            assert process.returncode == 0, record
            result = json.loads(process.stdout)
            assert result['semantic_checks'] and not result['allocation_instrumentation']
            assert result['cpu_ns'] > 0 and result['wall_ns'] > 0
            assert result['allocation_calls'] is result['requested_bytes'] is None
            assert result['repetitions'] == case['cpu_repetitions']
            paired[variant] = result
        a, b = paired['baseline'], paired['candidate']
        assert a['checksum'] == b['checksum'] and a['operations'] == b['operations']
        observed[step['case_no']].append({'pair': step['pair'], 'checksum': a['checksum'],
            'operations': a['operations'], 'baseline_cpu_ns': a['cpu_ns'],
            'candidate_cpu_ns': b['cpu_ns'], 'ratio': b['cpu_ns'] / a['cpu_ns'],
            'baseline_wall_ns': a['wall_ns'], 'candidate_wall_ns': b['wall_ns']})
summary = []
for number, case in enumerate(cases):
    pairs = observed[number]
    ratios = [pair['ratio'] for pair in pairs]
    row = {'case_no': number, 'case': case, 'pairs': pairs,
           'median_ratio': statistics.median(ratios), 'min_ratio': min(ratios),
           'max_ratio': max(ratios), 'pairs_above_one': sum(value > 1 for value in ratios)}
    summary.append(row)
    print(json.dumps({key: value for key, value in row.items() if key != 'pairs'}), flush=True)
for variant, build in builds.items():
    assert sha(HERE / f'canonical-{variant}-cpu-bin') == build['retained_sha256']
(HERE / 'canonical-cpu-summary.json').write_text(json.dumps({
    'successful_processes': sum(2 * len(row['pairs']) for row in summary),
    'elapsed_seconds': time.monotonic() - started, 'rows': summary}, indent=2) + '\n')
