from pathlib import Path
import hashlib
import json
import random
import subprocess

HERE = Path(__file__).resolve().parent
cases = json.loads((HERE / 'canonical-cases.json').read_text())['rows']
builds = {variant: json.loads((HERE / f'canonical-{variant}-alloc.json').read_text())
          for variant in ['baseline', 'candidate']}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
for variant, build in builds.items():
    assert sha(HERE / f'canonical-{variant}-alloc-bin') == build['retained_sha256']
order = list(range(len(cases)))
rng = random.Random(2026110603)
rng.shuffle(order)
rows = {}
with (HERE / 'canonical-allocation-raw.jsonl').open('x') as log:
    for number in order:
        case = cases[number]
        variants = ['baseline', 'candidate']
        rng.shuffle(variants)
        paired = {}
        for variant in variants:
            repetitions = case['allocation_repetitions']
            command = [str(HERE / f'canonical-{variant}-alloc-bin'), case['shape'], case['kind'],
                       str(case['entries']), str(case['key_length']), str(repetitions)]
            process = subprocess.run(command, capture_output=True, text=True)
            record = {'case_no': number, 'variant': variant, 'command': command,
                      'exit_code': process.returncode, 'stdout': process.stdout,
                      'stderr': process.stderr,
                      'binary_sha256': sha(HERE / f'canonical-{variant}-alloc-bin')}
            log.write(json.dumps(record) + '\n')
            log.flush()
            assert process.returncode == 0, record
            result = json.loads(process.stdout)
            assert result['allocation_instrumentation'] and result['semantic_checks']
            assert result['cpu_ns'] is result['wall_ns'] is None
            assert result['schema'] == 'pbrs.map-remove-screen.v1'
            assert result['repetitions'] == repetitions
            paired[variant] = result
        a, b = paired['baseline'], paired['candidate']
        assert a['checksum'] == b['checksum'] and a['operations'] == b['operations']
        rows[number] = {'case_no': number, 'case': case, 'operations': a['operations'],
                        'checksum': a['checksum'],
                        'baseline_allocations': a['allocation_calls'],
                        'candidate_allocations': b['allocation_calls'],
                        'baseline_requested_bytes': a['requested_bytes'],
                        'candidate_requested_bytes': b['requested_bytes']}
        print(json.dumps(rows[number]), flush=True)
for variant, build in builds.items():
    assert sha(HERE / f'canonical-{variant}-alloc-bin') == build['retained_sha256']
(HERE / 'canonical-allocation-summary.json').write_text(json.dumps({
    'scope': 'Requested allocations in measurement windows, no clock observations. '
             'Cycle includes remove/get/reinsert. Single includes only removal from unindexed maps; '
             'preparation, verification and destruction are excluded. No RSS or retained-memory result.',
    'successful_processes': 2 * len(cases), 'rows': [rows[i] for i in range(len(cases))]}, indent=2) + '\n')
