use pbrs::{Map, MapKey, ProtoString};
use std::hint::black_box;
#[cfg(not(feature = "allocations"))]
use std::time::Instant;

#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    static ENABLED: AtomicBool = AtomicBool::new(false);
    static CALLS: AtomicU64 = AtomicU64::new(0);
    static BYTES: AtomicU64 = AtomicU64::new(0);
    pub struct Counted;
    unsafe impl GlobalAlloc for Counted {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let pointer = unsafe { System.alloc(layout) };
            if !pointer.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            pointer
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let pointer = unsafe { System.alloc_zeroed(layout) };
            if !pointer.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            pointer
        }
        unsafe fn realloc(&self, pointer: *mut u8, old: Layout, length: usize) -> *mut u8 {
            let result = unsafe { System.realloc(pointer, old, length) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(length as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, pointer: *mut u8, layout: Layout) {
            unsafe { System.dealloc(pointer, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOCATOR: count::Counted = count::Counted;

#[cfg(not(feature = "allocations"))]
fn cpu_ns() -> u128 {
    let mut value = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut value) }, 0);
    value.tv_sec as u128 * 1_000_000_000 + value.tv_nsec as u128
}
#[derive(Default)]
struct Metrics { cpu: u128, wall: u128, allocations: u64, requested: u64 }
impl Metrics {
    fn window<R>(&mut self, action: impl FnOnce() -> R) -> R {
        #[cfg(feature = "allocations")]
        count::start();
        #[cfg(not(feature = "allocations"))]
        let (cpu, wall) = (cpu_ns(), Instant::now());
        let result = action();
        #[cfg(feature = "allocations")]
        {
            let (allocations, requested) = count::stop();
            self.allocations += allocations;
            self.requested += requested;
        }
        #[cfg(not(feature = "allocations"))]
        {
            self.cpu += cpu_ns() - cpu;
            self.wall += wall.elapsed().as_nanos();
        }
        result
    }
}
fn value(id: usize) -> i32 { id as i32 * 7 + 3 }
fn cycle<K: MapKey>(keys: &[K], iterations: usize, metrics: &mut Metrics) -> (u64, usize) {
    let mut map = Map::new();
    for (id, key) in keys.iter().enumerate() { map.push_entry(key.clone(), value(id)); }
    assert_eq!(map.len(), keys.len()); // Initial index construction is outside measurement.
    let mut checksum = 0u64;
    metrics.window(|| {
        for iteration in 0..iterations {
            let id = iteration % keys.len();
            let next = (id + 1) % keys.len();
            let removed = black_box(&mut map).remove(black_box(&keys[id])).expect("present unique key");
            let probed = black_box(&map).get(black_box(&keys[next])).copied().expect("unrelated key");
            checksum = checksum.wrapping_add(black_box(removed as u64 + probed as u64));
            assert!(map.insert(keys[id].clone(), removed));
        }
    });
    let expected = (0..iterations).map(|i| value(i % keys.len()) as u64
        + value((i + 1) % keys.len()) as u64).fold(0u64, u64::wrapping_add);
    assert_eq!(checksum, expected);
    for (id, key) in keys.iter().enumerate() { assert_eq!(map.get(key), Some(&value(id))); }
    (checksum, iterations)
}
const BATCH_MAPS: usize = 1024;
fn single<K: MapKey>(keys: &[K], batches: usize, metrics: &mut Metrics) -> (u64, usize) {
    let mut template = Map::new();
    for (id, key) in keys.iter().enumerate() { template.push_entry(key.clone(), value(id)); }
    let target = keys.len() / 2;
    let mut checksum = 0u64;
    let mut seen = vec![false; keys.len()];
    for _ in 0..batches {
        // Map::clone leaves its index uninitialized. Allocation, cloning,
        // verification and destruction are outside every measurement window.
        let mut maps: Vec<_> = (0..BATCH_MAPS).map(|_| template.clone()).collect();
        let mut removed = vec![None; BATCH_MAPS];
        metrics.window(|| {
            for (map, slot) in maps.iter_mut().zip(&mut removed) {
                *slot = black_box(map).remove(black_box(&keys[target]));
            }
        });
        for (map, removed) in maps.iter().zip(removed) {
            assert_eq!(removed, Some(value(target)));
            assert_eq!(map.pairs().len(), keys.len() - 1);
            seen.fill(false);
            let mut sum = removed.expect("removed unique value") as u64;
            for (key, stored) in map.pairs() {
                let id = ((*stored - 3) / 7) as usize;
                assert!(id < keys.len() && id != target && !seen[id]);
                assert!(key == &keys[id]);
                assert_eq!(*stored, value(id));
                seen[id] = true;
                sum += *stored as u64;
            }
            checksum = checksum.wrapping_add(sum);
        }
    }
    let operations = batches * BATCH_MAPS;
    let expected = (0..keys.len()).map(|id| value(id) as u64).sum::<u64>()
        .wrapping_mul(operations as u64);
    assert_eq!(checksum, expected);
    (checksum, operations)
}
fn main() {
    let args: Vec<_> = std::env::args().collect();
    assert_eq!(args.len(), 6, "shape kind entries key_length repetitions");
    let (shape, kind, entries, length, repetitions) = (args[1].as_str(), args[2].as_str(),
        args[3].parse::<usize>().unwrap(), args[4].parse::<usize>().unwrap(),
        args[5].parse::<usize>().unwrap());
    assert!(entries > 1 && length >= 8 && repetitions > 0);
    let mut metrics = Metrics::default();
    let (checksum, operations) = match kind {
        "int" => {
            let keys: Vec<_> = (0..entries as i32).collect();
            match shape { "cycle" => cycle(&keys, repetitions, &mut metrics),
                "single" => single(&keys, repetitions, &mut metrics), _ => panic!("shape") }
        }
        "proto" => {
            let keys: Vec<_> = (0..entries).map(|id| ProtoString::from(
                format!("{}{:08x}", "x".repeat(length - 8), id))).collect();
            match shape { "cycle" => cycle(&keys, repetitions, &mut metrics),
                "single" => single(&keys, repetitions, &mut metrics), _ => panic!("shape") }
        }
        _ => panic!("kind"),
    };
    println!("{}", serde_json::json!({"schema":"pbrs.map-remove-screen.v1","shape":shape,
        "kind":kind,"entries":entries,"key_length":length,"repetitions":repetitions,
        "operations":operations,"checksum":checksum,"semantic_checks":true,
        "allocation_instrumentation":cfg!(feature="allocations"),
        "cpu_ns":if cfg!(feature="allocations") {None} else {Some(metrics.cpu)},
        "wall_ns":if cfg!(feature="allocations") {None} else {Some(metrics.wall)},
        "allocation_calls":if cfg!(feature="allocations") {Some(metrics.allocations)} else {None},
        "requested_bytes":if cfg!(feature="allocations") {Some(metrics.requested)} else {None}}));
}
