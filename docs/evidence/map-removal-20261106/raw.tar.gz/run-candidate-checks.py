from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
here=Path('/workspace/map-remove-20261106');root=Path('/workspace/pure-protobuf');env=os.environ.copy();env.update(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_TARGET_DIR=str(here/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0');env['PATH']=str(root/'work/cargo/bin')+':'+env['PATH'];env.pop('RUSTFLAGS',None)
def target_size():return sum(p.stat().st_size for p in (here/'target').rglob('*') if p.is_file()) if (here/'target').exists() else 0
for name,command in [
 ('candidate-unit',['cargo','test','--offline','--locked','--lib','--no-default-features','--','--nocapture']),
 ('candidate-clippy',['cargo','clippy','--offline','--locked','--lib','--tests','--no-default-features','--','-D','warnings'])
]:
 guard=None
 inputs={str(p.relative_to(here/'tree')):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((here/'tree').rglob('*')) if p.is_file() and '.git' not in p.parts}
 with (here/(name+'.log')).open('w') as log:
  proc=subprocess.Popen(command,cwd=here/'tree',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if shutil.disk_usage(here).free<1024**3:guard='disk-floor'
   if target_size()>300*1024**2:guard='target-cap'
   if guard:os.killpg(proc.pid,signal.SIGTERM);break
   time.sleep(.5)
  code=proc.wait()
 report={'name':name,'command':command,'exit_code':code,'guard':guard,'source_sha256':inputs,'target_bytes':target_size(),'free_bytes':shutil.disk_usage(here).free}
 (here/(name+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='source_sha256'}),flush=True);print((here/(name+'.log')).read_text()[-9000:],flush=True)
 assert code==0 and guard is None
