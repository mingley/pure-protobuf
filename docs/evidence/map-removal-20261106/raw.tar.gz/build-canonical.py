from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time

HERE = Path(__file__).resolve().parent
ROOT = Path('/workspace/pure-protobuf')
TREE = HERE / 'tree'
HARNESS = HERE / 'harness'
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(HERE / 'target'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + env['PATH']
env.pop('RUSTFLAGS', None)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def inventory():
    return {str(path.relative_to(TREE)): sha(path) for path in sorted(TREE.rglob('*'))
            if path.is_file() and '.git' not in path.parts}

def size():
    total = 0
    for directory in [HERE / 'target', HERE / 'target-miri']:
        if directory.exists():
            for path in directory.rglob('*'):
                try:
                    if path.is_file():
                        total += path.stat().st_size
                except FileNotFoundError:
                    pass
    return total

def run(command, log_path):
    assert not log_path.exists()
    assert shutil.disk_usage(HERE).free > 1024 ** 3
    guard = None
    with log_path.open('w') as log:
        process = subprocess.Popen(command, cwd=HERE, env=env, stdout=log,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            if shutil.disk_usage(HERE).free < 1024 ** 3:
                guard = 'disk-floor'
            if size() > 300 * 1024 ** 2:
                guard = 'target-cap'
            if guard:
                os.killpg(process.pid, signal.SIGTERM)
                break
            time.sleep(.5)
        code = process.wait()
    return {'command': command, 'exit_code': code, 'guard': guard,
            'target_bytes': size(), 'free_bytes': shutil.disk_usage(HERE).free}

candidate = (HERE / 'candidate-with-docs-map.rs').read_bytes()
assert sha(HARNESS / 'src/main.rs') == sha(HERE / 'bench.rs')
constant_inputs = {'harness_source_sha256': sha(HARNESS / 'src/main.rs'),
                   'harness_manifest_sha256': sha(HARNESS / 'Cargo.toml'),
                   'harness_lock_sha256': sha(HARNESS / 'Cargo.lock'),
                   'runtime_manifest_sha256': sha(TREE / 'Cargo.toml'),
                   'runtime_lock_sha256': sha(TREE / 'Cargo.lock'),
                   'rustc': subprocess.check_output(['rustc', '-Vv'], env=env, text=True),
                   'cargo': subprocess.check_output(['cargo', '-V'], env=env, text=True)}
try:
    for variant, source in [('baseline', HERE / 'baseline-map.rs'),
                            ('candidate', HERE / 'candidate-with-docs-map.rs')]:
        (TREE / 'src/map.rs').write_bytes(source.read_bytes())
        for mode in ['cpu', 'alloc']:
            stem = f'canonical-{variant}-{mode}'
            before = inventory()
            command = ['cargo', 'build', '--release', '--offline', '--locked',
                       '--manifest-path', str(HARNESS / 'Cargo.toml'), '--message-format=json', '-vv']
            if mode == 'alloc':
                command += ['--features', 'allocations']
            log_path = HERE / (stem + '.jsonl')
            report = run(command, log_path)
            report.update(variant=variant, mode=mode, source_before=before,
                          source_after=inventory(), constant_inputs=constant_inputs,
                          canonical_source_root=str(TREE), canonical_harness_root=str(HARNESS),
                          build_log_sha256=sha(log_path))
            if report['exit_code'] == 0 and report['guard'] is None:
                assert report['source_before'] == report['source_after']
                messages = [json.loads(line) for line in log_path.read_text().splitlines()
                            if line.startswith('{')]
                artifacts = [item for item in messages if item.get('reason') == 'compiler-artifact']
                binary = [item for item in artifacts if item['target']['name'] == 'pbrs-map-removal-screen'
                          and item.get('executable')]
                library = [item for item in artifacts if item['target']['name'] == 'pbrs']
                assert len(binary) == len(library) == 1
                executable = Path(binary[0]['executable'])
                retained = HERE / (stem + '-bin')
                assert not retained.exists()
                source_digest = sha(executable)
                shutil.copy2(executable, retained)
                report.update(executable_sha256=source_digest, retained_sha256=sha(retained),
                              binary_artifact=binary[0], library_artifact=library[0])
                assert report['executable_sha256'] == report['retained_sha256']
                commands = [line for line in log_path.read_text().splitlines()
                            if 'Running ' in line and '--crate-name ' in line
                            and ('--crate-name pbrs ' in line or '--crate-name pbrs_map_removal_screen ' in line)]
                report['rustc_commands'] = commands
                report['crate_metadata'] = {}
                for target in ['pbrs', 'pbrs_map_removal_screen']:
                    matching = [line for line in commands if f'--crate-name {target} ' in line]
                    # The dependency is reused for an allocation-only feature toggle.
                    if matching:
                        assert len(matching) == 1
                        found = re.findall(r'-C\s*metadata=([a-f0-9]+)', matching[0])
                        assert len(found) == 1, matching[0]
                        report['crate_metadata'][target] = found[0]
            (HERE / (stem + '.json')).write_text(json.dumps(report, indent=2) + '\n')
            print(json.dumps({key: value for key, value in report.items()
                              if key in ['variant', 'mode', 'exit_code', 'guard', 'target_bytes',
                                         'free_bytes', 'retained_sha256', 'crate_metadata']}), flush=True)
            assert report['exit_code'] == 0 and report['guard'] is None, log_path
    for mode in ['cpu', 'alloc']:
        a = json.loads((HERE / f'canonical-baseline-{mode}.json').read_text())
        b = json.loads((HERE / f'canonical-candidate-{mode}.json').read_text())
        assert a['constant_inputs'] == b['constant_inputs']
        for artifact in ['binary_artifact', 'library_artifact']:
            for key in ['package_id', 'manifest_path', 'profile', 'features', 'filenames']:
                assert a[artifact][key] == b[artifact][key], (artifact, key)
        for target in a['crate_metadata'].keys() & b['crate_metadata'].keys():
            assert a['crate_metadata'][target] == b['crate_metadata'][target]
        assert {path for path in a['source_before']
                if a['source_before'][path] != b['source_before'][path]} == {'src/map.rs'}
finally:
    if (TREE / 'src/map.rs').read_bytes() != candidate:
        (TREE / 'src/map.rs').write_bytes(candidate)
