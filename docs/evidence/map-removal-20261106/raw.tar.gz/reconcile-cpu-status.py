from pathlib import Path
import json

HERE = Path(__file__).resolve().parent
order = json.loads((HERE / 'canonical-cpu-order.json').read_text())
path = HERE / 'canonical-cpu-raw.jsonl'
captures = [json.loads(line) for line in path.read_text().splitlines()] if path.exists() else []
found = {}
for record in captures:
    key = (record['case_no'], record['pair'], record['variant'])
    assert key not in found
    found[key] = record
rows = []
for step in order:
    for variant in step['variants']:
        key = (step['case_no'], step['pair'], variant)
        row = {'case_no': key[0], 'pair': key[1], 'variant': variant, 'status': 'missing'}
        if key in found:
            record = found[key]
            row['exit_code'] = record['exit_code']
            row['status'] = 'failed'
            if record['exit_code'] == 0:
                try:
                    result = json.loads(record['stdout'])
                    if result['semantic_checks'] and not result['allocation_instrumentation']:
                        if result['cpu_ns'] > 0 and result['wall_ns'] > 0:
                            row['status'] = 'passed'
                except (KeyError, TypeError, ValueError):
                    pass
        rows.append(row)
result = {'scope': 'Missing means no complete capture retained; no successful run is inferred.',
          'planned': len(rows), 'passed': sum(r['status'] == 'passed' for r in rows),
          'failed': sum(r['status'] == 'failed' for r in rows),
          'missing': sum(r['status'] == 'missing' for r in rows), 'rows': rows}
(HERE / 'canonical-cpu-status.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'rows'}))
