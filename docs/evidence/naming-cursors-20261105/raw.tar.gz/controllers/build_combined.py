#!/usr/bin/env python3
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'target/codegen-naming-20261105'
FLOOR = 750 * 1024**2
TARGET_LIMIT = 100 * 1024**2
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
snapshot = lambda folder: {str(p.relative_to(folder)): sha(p) for p in sorted(folder.rglob('*')) if p.is_file()}
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + str(ROOT / 'work/toolchain/protoc/bin') + ':' + env['PATH']
for key in ('RUSTFLAGS', 'RUSTDOCFLAGS', 'CARGO_ENCODED_RUSTFLAGS'):
    env.pop(key, None)
compiler = subprocess.check_output(['rustc', '-Vv'], env=env, text=True)

def run(command, log):
    assert not log.exists(), log
    assert shutil.disk_usage(ROOT).free > FLOOR
    started = time.monotonic()
    reason = None
    peak_target_bytes = 0
    with log.open('w') as output:
        process = subprocess.Popen(command, cwd=ROOT, env=env, stdout=output,
                                   stderr=subprocess.STDOUT, start_new_session=True)
        while process.poll() is None:
            target_bytes = sum(p.stat().st_size for p in TARGET.rglob('*') if p.is_file()) if TARGET.exists() else 0
            peak_target_bytes = max(peak_target_bytes, target_bytes)
            if shutil.disk_usage(ROOT).free < FLOOR:
                reason = 'free disk below 1GiB'
            elif target_bytes > TARGET_LIMIT:
                reason = 'target size exceeded 100MiB'
            if reason:
                os.killpg(process.pid, signal.SIGTERM)
                break
            time.sleep(.25)
        status = process.wait()
    row = {'command': command, 'status': status, 'guard': reason,
           'elapsed_seconds': time.monotonic() - started, 'log': str(log),
           'peak_target_bytes': peak_target_bytes, 'log_sha256': sha(log)}
    print(json.dumps(row), flush=True)
    assert status == 0 and reason is None, row
    return row

for variant in ('combined',):
    manifest = HERE / f'{variant}-harness/Cargo.toml'
    run(['cargo', 'generate-lockfile', '--offline', '--manifest-path', str(manifest)], HERE / f'{variant}-lock.log')
    before = snapshot(HERE / variant)
    command = ['cargo', 'build', '--release', '--locked', '--offline', '--manifest-path', str(manifest), '--message-format=json']
    result = run(command, HERE / f'{variant}-build.jsonl')
    messages = [json.loads(line) for line in Path(result['log']).read_text().splitlines() if line.startswith('{')]
    binaries = [m['executable'] for m in messages if m.get('reason') == 'compiler-artifact' and m.get('executable') and m['target']['name'] == 'pbrs-naming-codegen-diagnostic']
    assert len(binaries) == 1, binaries
    frozen = HERE / f'{variant}-bin'
    assert not frozen.exists()
    shutil.copy2(binaries[0], frozen)
    after = snapshot(HERE / variant)
    assert before == after
    result.update(source_sha256=before, binary_sha256=sha(frozen), rustc=compiler,
                  harness_sha256=sha(manifest.parent / 'src/main.rs'),
                  manifest_sha256=sha(manifest), lock_sha256=sha(manifest.parent / 'Cargo.lock'))
    (HERE / f'{variant}-build.json').write_text(json.dumps(result, indent=2) + '\n')
assert (ROOT / 'work/codegen-naming-20261105/candidate-harness/Cargo.lock').read_bytes() == (HERE / 'combined-harness/Cargo.lock').read_bytes()
