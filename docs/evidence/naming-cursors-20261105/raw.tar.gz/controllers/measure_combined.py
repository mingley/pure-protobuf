#!/usr/bin/env python3
"""Paired default generator wall-time diagnostic for the combined core changes."""
import argparse
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
HELPER = ROOT / 'work/all-benchmarks/measurement/canonical_codegen_blocking.py'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()


def snapshot(folder):
    return {str(p.relative_to(folder)): {'sha256': sha(p), 'bytes': p.stat().st_size,
                                        'mtime_ns': p.stat().st_mtime_ns}
            for p in sorted(folder.rglob('*.rs'))}


def content(snapshot):
    return {k: (v['sha256'], v['bytes']) for k, v in snapshot.items()}


def interval(values):
    return {'median': statistics.median(values), 'range': [min(values), max(values)],
            'pairs': values}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--prepare', action='store_true')
    parser.add_argument('--resume', action='store_true')
    parser.add_argument('--pairs', type=int, default=5)
    parser.add_argument('--cases', nargs='+', default=['small', '100', '1000',
        'collisions_64', 'collisions_256', 'collisions_1024', 'explicit_conflicts'])
    args = parser.parse_args()
    output = args.output.resolve()
    binaries = {v: (HERE / ('baseline-bin' if v == 'baseline' else 'combined-bin')).resolve(strict=True) for v in ['baseline', 'candidate']}
    timebin = (ROOT / 'work/all-benchmarks/measurement/time-package/root/usr/bin/time').resolve(strict=True)
    protoc = (ROOT / 'work/toolchain/protoc/bin/protoc').resolve(strict=True)
    spec = importlib.util.spec_from_file_location('canonical_codegen', HELPER)
    helper = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(helper)
    env = dict(os.environ)
    env.update(PROTOC=str(protoc), PBRS_CODEGEN_TIME=str(timebin), LC_ALL='C')
    for key in list(env):
        if key.startswith(('PURE_PROTOBUF_', 'SB09_PBRS_')):
            del env[key]
    rng = random.Random(511051)
    plan = []
    for repeat in range(args.pairs):
        cases = list(args.cases)
        rng.shuffle(cases)
        for case in cases:
            variants = list(binaries)
            rng.shuffle(variants)
            plan.extend({'repeat': repeat, 'case': case, 'variant': variant} for variant in variants)
    static = {
        'schema': 'pbrs.combined-codegen-diagnostic.v1', 'qualified': False,
        'pairs': args.pairs, 'cases': args.cases, 'plan': plan,
        'binaries': {k: str(p) for k, p in binaries.items()},
        'binary_sha256': {k: sha(p) for k, p in binaries.items()},
        'helper_sha256': sha(HELPER), 'controller_sha256': sha(Path(__file__)),
        'protoc_sha256': sha(protoc), 'time_sha256': sha(timebin),
        'corpus_sha256': {case: {p.name: sha(p) for p in sorted((HERE / 'corpora' / case).glob('*.proto'))}
                          for case in args.cases},
    }
    path = output / 'manifest.json'
    if args.resume:
        manifest = json.loads(path.read_text())
        assert manifest['state'] != 'complete'
        assert all(manifest.get(k) == v for k, v in static.items()), 'resume inputs changed'
    else:
        output.mkdir(parents=True, exist_ok=False)
        manifest = {**static, 'state': 'prepared', 'captures': [],
            'host': platform.uname()._asdict(), 'affinity': sorted(os.sched_getaffinity(0)),
            'cgroup_cpu_max': Path('/sys/fs/cgroup/cpu.max').read_text(),
            'load_before': Path('/proc/loadavg').read_text(),
            'scope': 'CLI elapsed wall time including protoc and file operations; no consumer build or runtime timing. Combined current core snapshot, with default generation options; namespace repairs may change output spelling.',
            'limits': ['Shared host; paused local builds do not establish isolation.',
                'Blocking process-tree timer and RSS sampler have observer overhead.',
                'No Prost comparator or overall ranking claim.',
                'Generated output hashes are observed; output trees and executable bytes are not archived.']}
    def save():
        path.write_text(json.dumps(manifest, indent=2) + '\n')
    save()
    if args.prepare:
        print(json.dumps({'state': manifest['state'], 'planned_processes': len(plan) * 2}))
        return
    manifest['state'] = 'running'
    save()
    try:
        for entry in plan[len(manifest['captures']):]:
            if shutil.disk_usage(ROOT).free < 750 * 1024**2:
                raise RuntimeError('free disk guard reached')
            index = len(manifest['captures'])
            case, variant = entry['case'], entry['variant']
            proto = HERE / 'corpora' / case
            generated = output / 'outputs' / f'{index:03d}'
            generated.mkdir(parents=True, exist_ok=False)
            command = [str(binaries[variant]), str(proto), str(generated), str(protoc)]
            command += [p.name for p in sorted(proto.glob('*.proto'))]
            phases, snapshots = {}, {}
            for operation in ['generation', 'generation_unchanged']:
                measurement = helper.timed_command(command, ROOT, env,
                    output / 'logs' / f'{index:03d}' / operation, output, 120, 100)
                assert measurement['exit_code'] == 0, 'generator failed'
                phases[operation] = measurement
                snapshots[operation] = snapshot(generated)
                assert snapshots[operation], 'no generated output'
            before, after = (snapshots[k] for k in ['generation', 'generation_unchanged'])
            assert content(before) == content(after), 'unchanged output content differs'
            assert all(before[k]['mtime_ns'] == after[k]['mtime_ns'] for k in before), 'unchanged output rewritten'
            tree = hashlib.sha256(json.dumps(content(before), sort_keys=True).encode()).hexdigest()
            capture = {**entry, 'index': index, 'phases': phases, 'generated': before,
                'output_tree_sha256': tree, 'unchanged_generated': after, 'unchanged_mtimes_preserved': len(before), 'rust_files': len(before),
                'rust_bytes': sum(v['bytes'] for v in before.values())}
            (output / 'logs' / f'{index:03d}' / 'capture.json').write_text(json.dumps(capture, indent=2) + '\n')
            representative = output / 'representative-generated' / variant / case
            if not representative.exists():
                shutil.copytree(generated, representative)
            shutil.rmtree(generated)
            manifest['captures'].append(capture)
            save()
            print(f'{len(manifest["captures"])}/{len(plan)} passed', flush=True)
        assert all(sha(p) == manifest['binary_sha256'][v] for v, p in binaries.items())
        rows = []
        for case, operation in itertools.product(args.cases, ['generation', 'generation_unchanged']):
            matching = [r for r in manifest['captures'] if r['case'] == case]
            assert all(len({r['output_tree_sha256'] for r in matching if r['variant'] == v}) == 1 for v in binaries), f'within-variant output mismatch: {case}'
            values = {(r['repeat'], r['variant']): r['phases'][operation]['elapsed_ns'] for r in matching}
            rows.append({'case': case, 'operation': operation,
                'median_ns': {v: statistics.median(values[i, v] for i in range(args.pairs)) for v in binaries},
                'new_over_old': interval([values[i, 'candidate'] / values[i, 'baseline'] for i in range(args.pairs)]),
                'output_identical': len({r['output_tree_sha256'] for r in matching}) == 1, 'rust_bytes': {v: next(r['rust_bytes'] for r in matching if r['variant'] == v) for v in binaries}})
        (output / 'summary.json').write_text(json.dumps(rows, indent=2) + '\n')
        manifest.update(state='complete', successful_processes=len(plan) * 2,
            load_after=Path('/proc/loadavg').read_text())
        save()
        print(json.dumps({'state': 'complete', 'processes': len(plan) * 2}))
    except Exception as error:
        manifest.update(state='failed', error=str(error))
        save()
        raise


if __name__ == '__main__':
    main()
