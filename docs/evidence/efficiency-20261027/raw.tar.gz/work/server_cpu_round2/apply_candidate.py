from pathlib import Path
import re
root=Path('/workspace/pure-protobuf')
rpc=root/'pbrs-grpc/src/server/rpc.rs'
deadline=root/'pbrs-grpc/src/server/deadline.rs'
for p in [rpc,deadline]:
 s=p.read_text()
 s=re.sub(r'(?m)^(\s*)((?:self\.)?accepted_at|call_start)\.elapsed\(\),$',r'\1|| \2.elapsed(),',s)
 s=s.replace('&status, accepted.elapsed());','&status, || accepted.elapsed());')
 p.write_text(s)
s=rpc.read_text()
old='    elapsed: Duration,\n) {\n    if flag.deadline.end() {\n        channelz_end(server, socket, status.is_ok());'
new='    elapsed: impl FnOnce() -> Duration,\n) {\n    if flag.deadline.end() {\n        // Reading the clock is useful only for the first observed end. Sample\n        // before accounting and observer callbacks add their own work.\n        let elapsed = observer.map(|_| elapsed());\n        channelz_end(server, socket, status.is_ok());'
assert s.count(old)==1
s=s.replace(old,new)
old='                status,\n                elapsed,\n            );'
assert s.count(old)==1
s=s.replace(old,'                status,\n                elapsed.unwrap_or_default(),\n            );')
rpc.write_text(s)
