from pathlib import Path
import hashlib,json,re,statistics,subprocess,shutil,time
root=Path('/workspace/pure-protobuf');out=root/'work/server_cpu_round2'
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
candidate_log=(out/'clock-candidate.log').read_text()
assert 'test result: ok.' in candidate_log
match=re.search(r'Running unittests src/lib.rs \(([^)]+)\)',candidate_log)
assert match
candidate=root/match[1]
shutil.copy2(candidate,out/'candidate-probe')
rpc=root/'pbrs-grpc/src/server/rpc.rs';deadline=root/'pbrs-grpc/src/server/deadline.rs'
(out/'rpc.candidate.probe.rs').write_bytes(rpc.read_bytes())
(out/'deadline.candidate.probe.rs').write_bytes(deadline.read_bytes())
probe_name='server::rpc::terminal_elapsed_probe::unobserved_terminal_clock_probe'
probe_args=['--exact',probe_name,'--ignored','--nocapture']
parsed=[]
for repeat in range(3):
 for variant in (['baseline','candidate'] if repeat%2==0 else ['candidate','baseline']):
  cmd=[str(out/(variant+'-probe')),*probe_args]
  result=subprocess.run(cmd,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,check=True)
  log=f'paired-{repeat}-{variant}.log';(out/log).write_text(result.stdout)
  samples=[float(v) for v in re.findall(r'ns_per_call=([0-9.]+)',result.stdout)]
  assert len(samples)==9
  parsed.append(dict(repeat=repeat,variant=variant,command=cmd,log=log,ns_per_call=samples,median_ns=statistics.median(samples)))
checks={}
for label,args in [
 ('deterministic-clock-control',['--exact','server::rpc::layout_tests::terminal_elapsed_is_sampled_once_only_for_an_observed_end','--nocapture']),
 ('server-unit-controls',['server::','--nocapture'])
]:
 command=[str(out/'candidate-probe'),*args]
 result=subprocess.run(command,cwd=root,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
 (out/(label+'.log')).write_text(result.stdout)
 assert result.returncode==0,result.stdout
 checks[label]=dict(command=command,exit_code=result.returncode,log=label+'.log',test_result=re.findall(r'test result:.*',result.stdout))
marker='\n#[cfg(test)]\nmod terminal_elapsed_probe {'
source=rpc.read_text();assert source.count(marker)==1
rpc.write_text(source[:source.index(marker)].rstrip()+'\n')
assert 'terminal-clock-probe' not in rpc.read_text()
files=['pbrs-grpc/src/server/rpc.rs','pbrs-grpc/src/server/deadline.rs']
source_hashes={rel:{'before_sha256':sha(out/(Path(rel).name+'.baseline')),'after_sha256':sha(root/rel)} for rel in files}
(out/'server-clock.patch').write_bytes(subprocess.check_output(['git','diff','--',*files],cwd=root))
all_samples={variant:[sample for row in parsed if row['variant']==variant for sample in row['ns_per_call']] for variant in ['baseline','candidate']}
medians={variant:statistics.median(samples) for variant,samples in all_samples.items()}
summary=dict(
 schema='pbrs.server-terminal-clock.v1',state='source-frozen',baseline_commit='9ad348e62673943acf01e858dcdad0de5d528a4d',
 files=source_hashes,
 change='Defer terminal elapsed-time sampling until the first observed end; unobserved and duplicate ends do not read the clock.',
 structural=dict(production_call_sites=11,unobserved_terminal_elapsed_clock_reads_before=1,after=0,new_allocations=0,new_tasks=0,scheduling_or_framing_changes=False),
 detecting_control=checks['deterministic-clock-control'],validation=checks,
 microprobe=dict(qualified=False,description='100,000 existing CancelFlag records per round; initialize state outside timing; call production end_call without observer, labels or channelz IDs.',
  sample_processes_per_variant=3,rounds_per_process=9,paired_runs=parsed,median_ns_per_call=medians,
  change_percent=(medians['candidate']/medians['baseline']-1)*100,
  initial_build_logs=['clock-baseline.log','clock-candidate.log'],
  binary_sha256={variant:sha(out/(variant+'-probe')) for variant in ['baseline','candidate']},
  baseline_probe_source_sha256=hashlib.sha256((out/'rpc.rs.baseline').read_bytes()+(out/'probe.rs').read_bytes()).hexdigest(),
  candidate_probe_source_sha256=sha(out/'rpc.candidate.probe.rs')),
 build_commands=[['cargo','test','--locked','-p','pbrs-grpc','--release','--lib','terminal_elapsed_probe::unobserved_terminal_clock_probe','--','--ignored','--nocapture']],
 environment=dict(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_TARGET_DIR=str(root/'target')),
 limitations=['Microprobe isolates terminal bookkeeping, not endpoint RPC throughput or CPU. Shared host; no world-leading speed claim.','Pipeline allocation changes remain mixed: native-server repeat 0 requested bytes +9.8%, repeat 1 -2.3%; this change does not claim to resolve that variance.','Builds used the shared checkout while other agents changed disjoint core/codegen files; exact owned-file source and binary hashes are retained.','Temporary ignored timing probe removed from final source. Strict all-feature Clippy and combined workspace checks follow under parent integration.'])
(out/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'state':summary['state'],'files':source_hashes,'microprobe_median_ns_per_call':medians,'microprobe_change_percent':summary['microprobe']['change_percent'],'validation':checks},indent=2))
