
#[cfg(test)]
mod terminal_elapsed_probe {
    use super::*;

    #[test]
    #[ignore = "local cost probe; not an endpoint benchmark"]
    fn unobserved_terminal_clock_probe() {
        let mut flags: Vec<_> = (0..100_000)
            .map(|_| super::super::drain::CancelFlag::new())
            .collect();
        let status = Status::ok();
        let accepted = tokio::time::Instant::now();
        for round in 0..9 {
            for flag in &mut flags {
                Arc::get_mut(flag).unwrap().deadline = super::super::deadline::CallDeadline::new();
            }
            let begin = std::time::Instant::now();
            for flag in &flags {
                end_call(std::hint::black_box(flag), None, None, None, None, &status, accepted.elapsed());
            }
            println!("terminal-clock-probe round={round} ns_per_call={}", begin.elapsed().as_nanos() as f64 / flags.len() as f64);
        }
    }
}
