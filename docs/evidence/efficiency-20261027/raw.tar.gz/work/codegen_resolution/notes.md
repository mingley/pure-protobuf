# Imported type path cache diagnostic

The generator now caches resolved imported type paths within one target.
Local identifiers and explicit extern paths keep their existing priority.
The cache is separate from the local identifier map and resets between both
requests and targets. This removes repeated package/nested-module formatting
for fields that reuse an imported message or enum type.

Production changes are confined to `src/codegen/{config,descriptors,naming}.rs`.
The new unit test checks nested imported paths, local-name priority, extern
mapping priority, plain identifier behavior, and request-state reset. The
existing repeated cross-file generation test also passes.

## Results

All six cases produce identical generated file names, byte counts and SHA-256
hashes. The single-file local-type case has exactly unchanged allocation and
requested-byte counts. Multi-target cases remove 30,191–54,351 allocations per
1,000-message generation: 7.60–13.17% fewer total allocations. Requested bytes
fall 0.61–1.24%; retained output bytes are unchanged.

Timing remains mixed. The table retains every case and every median loss;
negative changes are improvements. CPU uses Linux CLOCK_PROCESS_CPUTIME_ID
and includes all generation threads. Warm timing is the median of seven paired
process comparisons, each using its eight warm generations. Cold timing uses
sample zero from each of those seven paired processes.

| Case | Allocations | Warm CPU | Cold CPU | Warm wall | Cold wall | Peak requested-live bytes |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| single_100_full | +0.00% | -1.42% | -0.14% | -1.41% | -0.15% | +0.00% |
| twenty_1000_full | -7.60% | -7.19% | +10.86% | -3.04% | +2.68% | +5.94% |
| twenty_1000_shared_lean | -7.90% | -7.64% | +0.67% | -5.73% | -2.12% | +7.01% |
| hundred_1000_shared_lean | -12.48% | -12.59% | -6.45% | -7.12% | -2.02% | +9.91% |
| hundred_1000_shared_full | -13.16% | +1.78% | -9.74% | -8.11% | -0.19% | +6.63% |
| hundred_1000_full | -13.17% | -7.94% | -1.45% | -5.36% | +10.06% | -0.08% |

Raw CPU pair ranges are broad (roughly -28% through +21% across warm cases).
The measured peak-live increases are retained too; parallel worker overlap
can affect this metric. These results establish fewer allocations and
unchanged output. They do not establish a consistent cold-process latency
improvement or any world/tonic/prost leadership claim. No generated-source
compilation time was measured.

## Reproduce and audit

The baseline is commit `9ad348e6`. `frozen-core/` is a 6.3 MiB source-only
snapshot of the root package at that commit. Only workspace membership was
narrowed to allow an isolated consumer. `baseline-source.json` records all
source hashes; `candidate-source.json` proves exactly the three owned codegen
files changed. Other agents' runtime changes cannot enter this comparison.
Both variants use the same scratch lock (serde_json 1.0.154, versus repository
1.0.151); this difference is a diagnostic limitation.

Set the usual task Rust environment, with `CARGO_BUILD_JOBS=1`,
`CARGO_INCREMENTAL=0`, `CARGO_PROFILE_DEV_DEBUG=0`, and
`CARGO_TARGET_DIR=/workspace/pure-protobuf/target`. Restore the baseline three
codegen files *inside the frozen snapshot*, build the helper, and save both
variants before installing the candidate source:

```sh
cargo build --locked --release --manifest-path work/codegen_resolution/Cargo.toml
cp target/release/codegen-resolution-probe work/codegen_resolution/baseline-alloc
cargo build --locked --release --no-default-features --manifest-path work/codegen_resolution/Cargo.toml
cp target/release/codegen-resolution-probe work/codegen_resolution/baseline-shipping
```

Copy the candidate versions of those three files into the snapshot, repeat
the builds, and save `candidate-alloc` and `candidate-shipping`. Preserve the
existing measurements directory before rerunning; the runner refuses to
overwrite rows.

```sh
python3 work/codegen_resolution/measure.py --phase allocation --side baseline
python3 work/codegen_resolution/measure.py --phase allocation --side candidate
python3 work/codegen_resolution/measure.py --phase shipping
python3 work/codegen_resolution/analyze.py
```

The allocation phase uses one fresh process per side and case, with nine
generations each. The shipping phase uses separate helpers with allocator
instrumentation disabled, seven fresh processes per side and case, and nine
generations per process. Groups are shuffled with seed 271348; baseline and
candidate order alternate. Every input hash, command, helper hash and stdout
sample is retained under `measurements/`. Generated files are deleted only
after their names, SHA-256 and exact byte counts are recorded, keeping this
complete diagnostic under 30 MiB. Shipping output writes occur outside the
generation timer. Requested-live bytes exclude allocator metadata and
fragmentation and are not RSS.

The timing window was coordinated with the root, MiniTable and server agents;
no compiler was active at its start. This is still shared-host evidence and
is marked `qualified:false` in every report.

Final checks passed:

```sh
cargo test --locked -p pbrs --lib codegen:: --quiet
cargo clippy --locked -p pbrs --lib --all-features -- -D warnings
rustfmt --check --edition 2024 src/codegen/config.rs src/codegen/descriptors.rs src/codegen/naming.rs
git diff --check -- src/codegen/config.rs src/codegen/descriptors.rs src/codegen/naming.rs
```

The focused suite passed 19 tests. Logs are `unit-final.log` and `clippy.log`.
