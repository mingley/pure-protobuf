"""Validate the integrated MiniTable follow-up at one clean source commit."""
import json
import os
from pathlib import Path
import subprocess
import time


root = Path(__file__).resolve().parents[1]
output = root / "work/efficiency-validation"
output.mkdir(exist_ok=False)


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


if git("status", "--porcelain", "--untracked-files=all"):
    raise SystemExit("source must be clean at the start")
report = {"source": git("rev-parse", "HEAD"), "checks": [], "complete": False}
checks = [
    ("format", ["cargo", "fmt", "--all", "--check"]),
    ("core-tests", ["cargo", "test", "--locked", "-p", "pbrs", "--all-features", "--lib", "--test", "upb_kernel", "--test", "dynamic_required_merge", "--test", "depth", "--test", "unknown_group_depth"]),
    ("grpc-tests", ["cargo", "test", "--locked", "-p", "pbrs-grpc", "--all-features", "--lib"]),
    ("core-clippy", ["cargo", "clippy", "--locked", "-p", "pbrs", "--all-features", "--all-targets", "--", "-D", "warnings"]),
    ("grpc-clippy", ["cargo", "clippy", "--locked", "-p", "pbrs-grpc", "--all-features", "--lib", "--", "-D", "warnings"]),
    ("workspace-check", ["cargo", "check", "--locked", "--workspace", "--all-features"]),
    ("msrv-minimal", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs", "--no-default-features", "--lib"]),
    ("msrv-reflect", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs", "--no-default-features", "--features", "reflect", "--lib"]),
    ("msrv-core", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs", "--lib"]),
    ("msrv-grpc", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs-grpc", "--lib"]),
    ("msrv-tower", ["cargo", "+1.85.0", "check", "--locked", "-p", "pbrs-grpc", "--features", "tower", "--lib"]),
    ("conformance", ["./scripts/conformance.sh"]),
]
for name, command in checks:
    env = os.environ.copy()
    if name.startswith("msrv-"):
        env["CARGO_TARGET_DIR"] = str(root / "work/msrv-target")
        env["CARGO_BUILD_JOBS"] = "1"
    if name == "conformance":
        env["CONFORMANCE_OUTPUT_DIR"] = str(output / "conformance")
        env["NPROC"] = "2"
    start = time.monotonic()
    with (output / f"{name}.log").open("w") as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = {"name": name, "command": command, "exit_code": result.returncode, "seconds": time.monotonic() - start, "log": f"{name}.log"}
    report["checks"].append(row)
    (output / "results.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    if result.returncode:
        print((output / f"{name}.log").read_text()[-8000:], flush=True)
        raise SystemExit(result.returncode)
if git("status", "--porcelain", "--untracked-files=all") or git("rev-parse", "HEAD") != report["source"]:
    raise SystemExit("source changed during validation")
report["complete"] = True
report["clean_after"] = True
(output / "results.json").write_text(json.dumps(report, indent=2) + "\n")
