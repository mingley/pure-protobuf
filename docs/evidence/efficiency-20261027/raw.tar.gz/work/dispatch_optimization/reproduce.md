This diagnostic compares the MiniTable decoder at `9ad348e62673943acf01e858dcdad0de5d528a4d` with one field-lookup change. It uses the final parsing fixture retained in `work/group-evidence/original/bench-candidate/src/main.rs`, SHA256 `90196dde096ac718d6276d6c8de151cd4a6a9d1eb9c79ff49542183c3c1061ed`. Both standalone fixture copies are byte-identical.

The benchmark libraries are compact snapshots in `lib-before/` and `lib-after/`. They contain the following files from `git archive` of the baseline commit: `Cargo.toml`, `Cargo.lock`, `build.rs`, `src/`, `vendor/google/conformance_fds.bin`, `README.md`, both licenses, `clippy.toml`, and `rustfmt.toml`. Both manifests reduce `workspace.members` to `["."]`; other source bytes remain pinned. `source.json` records every file hash and verifies that only `src/runtime/decode.rs` differs between the libraries. The candidate source is copied from the owned main-checkout decoder after formatting; no concurrent encoder/codegen edits enter either frozen library.

An initial shared-checkout baseline build failed while the unrelated encoder file was being edited. Its log is preserved as `before-shared-build-failed.log`; that attempt supplied no timing samples. All compared binaries use the compact isolated libraries.

The candidate first checks the vector position at `field_number - 1`, validates its stored number, then falls back to the existing scan. Valid linked protobuf tables have unique field numbers. Sparse and reordered unique-number tables keep their actual slots; malformed duplicate-number table layouts do not define a valid protobuf schema and are outside this fast-path invariant. All accesses remain checked, and no unsafe API or public layout changes. The new controls cover maximum/sparse field numbers, reordered oneofs with wrong-wire unknowns, and sparse singular/repeated groups.

Recorded builds use Rust `1.99.1 (58cf8f9c3 2026-10-13)` and this environment:

```sh
cd /workspace/pure-protobuf
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR=/workspace/pure-protobuf/target
```

Each standalone manifest uses an absolute path dependency on its frozen library and `[profile.release] lto="thin", codegen-units=1`; other release settings retain their defaults. Build and freeze the binaries with:

```sh
cargo build --offline --quiet --release --manifest-path work/dispatch_optimization/before/Cargo.toml
cp target/release/minitable-dispatch-before work/dispatch_optimization/bin/before
cargo build --offline --quiet --release --manifest-path work/dispatch_optimization/after/Cargo.toml
cp target/release/minitable-dispatch-after work/dispatch_optimization/bin/after
```

`compare.py` validates all frozen library/fixture hashes, records executable hashes, then runs six alternating before/after process pairs for each workload:

```sh
python3 work/dispatch_optimization/compare.py
```

It refuses to overwrite retained raw files. Use a fresh copied output directory and update the driver's `OUT` for another run. No argument selects one and 100 complete singular-message fragments; `unknown` selects a varint, four-byte LEN payload, or two nested unknown groups around a varint. Each process emits five samples of 10,000 fresh parses per case. Fixture construction, assertions and destruction are outside the parse timer/allocation snapshot. The allocator counts allocation/reallocation requests and requested bytes, rather than peak memory. Group-body timing is unmeasured.

The direct commands behind the comparison are:

```sh
work/dispatch_optimization/bin/before
work/dispatch_optimization/bin/after
work/dispatch_optimization/bin/before unknown
work/dispatch_optimization/bin/after unknown
```

`non-group-raw.jsonl` and `unknown-raw.jsonl` preserve every sample and process position. `comparison.json` records per-pair medians, all-sample medians/ranges, source hashes, binary hashes and allocation counts. These shared-host timings are diagnostic, with no cross-library ranking claim.

Focused checks run in the shared main checkout, where other owners may change their files independently:

```sh
cargo test --locked -p pbrs --test upb_kernel --lib runtime::decode::tests --quiet
cargo test --locked -p pbrs --test upb_kernel --quiet
cargo clippy --locked -p pbrs --lib --test upb_kernel -- -D warnings
```

Their logs are `unit.log`, `kernel.log`, and `clippy.log`. `candidate.patch` contains only the owned decoder and decode integration-test edits against the baseline commit. No commits, pushes or full worktrees are created for this attempt.

The candidate was rejected and both owned main-checkout files were restored byte-for-byte to9ad348e6. The frozen candidate, patch, behavioral test snapshot and all timing records remain here. `choice.json` records the decision and restored hashes. Across30 samples per variant, one fragment changed111.438→113.044ns (+1.44%) and100 fragments4489.454→4621.743ns (+2.95%). All known-only runs retained four allocation requests/154 requested bytes. No additional variants were attempted.
