from pathlib import Path
import hashlib,json,statistics,subprocess
OUT=Path('/workspace/pure-protobuf/work/dispatch_optimization')
BINS={name:OUT/'bin'/name for name in ('before','after')}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((OUT/'source.json').read_text())
assert sha(OUT/'before/src/main.rs')==sha(OUT/'after/src/main.rs')==source['fixture_sha256']
for name,key in [('before','baseline_files'),('after','candidate_files')]:
 actual={str(p.relative_to(OUT/('lib-'+name))):sha(p) for p in sorted((OUT/('lib-'+name)).rglob('*')) if p.is_file()}
 assert actual==source[key],(name,'source changed since freeze')
provenance={'source':source,'binaries':{name:{'path':str(p),'sha256':sha(p),'mtime_ns':p.stat().st_mtime_ns} for name,p in BINS.items()},'runs':6,'group_body_timing':'unmeasured'}

def execute(name,args,pair,position,output):
 result=subprocess.run([str(BINS[name]),*args],capture_output=True,text=True,check=True)
 rows=[json.loads(line) for line in result.stdout.splitlines()];assert len(rows)==(15 if args else 10)
 records=[{'pair':pair,'position':position,'variant':name,**row} for row in rows]
 with output.open('a') as f:
  for record in records:f.write(json.dumps(record)+'\n')
 return records

def summarize(rows,conditions,pair=None):
 output=[]
 for condition in conditions:
  record=dict(condition)
  for name in BINS:
   selected=[row for row in rows if row['variant']==name and (pair is None or row['pair']==pair) and all(row[k]==v for k,v in condition.items())]
   assert len(selected)==(30 if pair is None else 5)
   record[name]={'median_parse_ns':statistics.median(row['parse_ns'] for row in selected),'min_parse_ns':min(row['parse_ns'] for row in selected),'max_parse_ns':max(row['parse_ns'] for row in selected),'allocations_per_parse':selected[0]['allocations_per_parse'],'requested_bytes_per_parse':selected[0]['requested_bytes_per_parse']}
   assert len({r['allocations_per_parse'] for r in selected})==len({r['requested_bytes_per_parse'] for r in selected})==1
  record['change_percent']=(record['after']['median_parse_ns']/record['before']['median_parse_ns']-1)*100
  output.append(record)
 return output

for mode,args,conditions in [('non-group',[],[{'fragments':1},{'fragments':100}]),('unknown',['unknown'],[{'mode':v} for v in ('varint','len','nested_groups')])]:
 path=OUT/(mode+'-raw.jsonl');assert not path.exists(),'Do not overwrite retained measurements'
 rows=[]
 for pair in range(6):
  order=('before','after') if pair%2==0 else ('after','before')
  for position,name in enumerate(order):rows.extend(execute(name,args,pair,position,path))
 provenance[mode]={'overall':summarize(rows,conditions),'pairs':[{'pair':pair,'first':'before' if pair%2==0 else 'after','cases':summarize(rows,conditions,pair)} for pair in range(6)]}
for name in BINS:assert sha(BINS[name])==provenance['binaries'][name]['sha256']
(OUT/'comparison.json').write_text(json.dumps(provenance,indent=2)+'\n')
for mode in ('non-group','unknown'):print(mode,json.dumps(provenance[mode]['overall']))
