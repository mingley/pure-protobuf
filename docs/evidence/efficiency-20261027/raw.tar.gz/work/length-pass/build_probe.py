from pathlib import Path
import subprocess,tarfile,io,json,hashlib,shutil
root=Path('/workspace/pure-protobuf');out=root/'work/length-pass'
fixture=(root/'work/group-evidence/original/bench-candidate/src/main.rs').read_text().split('fn main(){')[0]
fixture=fixture.replace('use pbrs::{ClearAndParse, Parse};','use pbrs::{ClearAndParse, Parse, Serialize};')
fixture+=r'''
fn main() {
 for depth in [0,8,64] {
  let mut bytes=len_field(1,&[8,11,16,22]);
  for _ in 0..depth { bytes=len_field(6,&bytes); }
  let value=Fixture::parse(&bytes).unwrap();
  let expected=value.serialize().unwrap();
  let hash=expected.iter().fold(14695981039346656037u64,|h,b|(h^u64::from(*b)).wrapping_mul(1099511628211));
  for sample in 0..5 {
   let a=ALLOCS.load(Ordering::Relaxed);let b=BYTES.load(Ordering::Relaxed);let start=Instant::now();
   for _ in 0..10000 { assert_eq!(std::hint::black_box(&value).serialized_len(),expected.len()); }
   let elapsed=start.elapsed().as_nanos();let count=ALLOCS.load(Ordering::Relaxed)-a;let requested=BYTES.load(Ordering::Relaxed)-b;
   println!("{{\"depth\":{depth},\"sample\":{sample},\"ns\":{},\"allocations\":{},\"bytes\":{},\"length\":{},\"output_fnv\":\"{hash:016x}\"}}",elapsed as f64/10000.0,count as f64/10000.0,requested as f64/10000.0,expected.len());
  }
 }
}
'''
paths=['Cargo.toml','Cargo.lock','build.rs','src','vendor/google/conformance_fds.bin','README.md','LICENSE-APACHE','LICENSE-MIT','clippy.toml','rustfmt.toml']
archive=subprocess.check_output(['git','archive','9ad348e6',*paths],cwd=root)
manifest={}
for name in ['before','after']:
 src=out/(name+'-core');src.mkdir(exist_ok=True)
 with tarfile.open(fileobj=io.BytesIO(archive)) as tar:tar.extractall(src,filter='data')
 p=src/'Cargo.toml';s=p.read_text();start=s.index('members = [');end=s.index('\n]',start)+2;s=s[:start]+'members = ["."]'+s[end:];p.write_text(s)
 if name=='after':shutil.copy2(root/'src/runtime/encode.rs',src/'src/runtime/encode.rs')
 crate=out/(name+'-probe');(crate/'src').mkdir(parents=True,exist_ok=True);(crate/'src/main.rs').write_text(fixture)
 (crate/'Cargo.toml').write_text(f'[package]\nname="length-probe"\nversion="0.0.0"\nedition="2024"\n[workspace]\n[dependencies]\npbrs={{path="{src}"}}\n[profile.release]\nlto="thin"\ncodegen-units=1\n')
 shutil.copy2(root/'work/group-evidence/original/bench-candidate/Cargo.lock',crate/'Cargo.lock')
 with (out/(name+'-build.log')).open('w') as log:
  subprocess.run(['cargo','build','--offline','--release','--manifest-path',str(crate/'Cargo.toml')],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 binary=out/(name+'-binary');shutil.copy2(root/'work/bench-target/release/length-probe',binary)
 manifest[name]={'encoder_sha256':hashlib.sha256((src/'src/runtime/encode.rs').read_bytes()).hexdigest(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest()}
 (out/'builds.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print('built',name,flush=True)
