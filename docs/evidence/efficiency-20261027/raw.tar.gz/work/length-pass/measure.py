from pathlib import Path
import subprocess,json,statistics,hashlib
p=Path(__file__).resolve().parent
sha=lambda path:hashlib.sha256(path.read_bytes()).hexdigest()
builds=json.loads((p/'builds.json').read_text())
builds['after']={'encoder_sha256':sha(p/'after-core/src/runtime/encode.rs'),'binary_sha256':sha(p/'after-binary')}
(p/'builds-final.json').write_text(json.dumps(builds,indent=2)+'\n')
rows=[]
for pair in range(3):
 for variant in (['before','after'] if pair%2==0 else ['after','before']):
  result=subprocess.run([str(p/(variant+'-binary'))],text=True,capture_output=True,check=True)
  rows.extend(dict(pair=pair,variant=variant,**json.loads(line)) for line in result.stdout.splitlines())
(p/'raw-final.jsonl').write_text(''.join(json.dumps(r)+'\n' for r in rows))
summary=[]
for d in [0,8,64]:
 r={'depth':d}
 for v in ['before','after']:
  x=[x for x in rows if x['variant']==v and x['depth']==d];r[v]={key:statistics.median(z[key] for z in x) for key in ['ns','allocations','bytes','length']}
 assert len({x['output_fnv'] for x in rows if x['depth']==d})==1
 assert r['after']['allocations']==0 and r['after']['bytes']==0
 summary.append(r)
result={'baseline':'9ad348e6','qualified':False,'scope':'MiniTable serialized_len only; shared host with concurrent builds; timings diagnostic','pairs':3,'cases':summary,'builds':builds,'tools':{t:subprocess.check_output([t,'--version'],text=True).strip() for t in ['rustc','cargo']}}
(p/'summary-final.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(summary,indent=2))
