//! Retained MiniTable trees obey protobuf merge and initialization rules.
#![allow(
    clippy::indexing_slicing,
    clippy::panic,
    reason = "the fixture owns exact table/slot layouts and asserts wire semantics"
)]

use pbrs::__internal::{Private, SealedInternal};
use pbrs::runtime::{
    Arena, FieldKind, FieldType, MessagePtr, MiniField, MiniTable, MiniTablePtr, MsgData,
    UpbGetArena, UpbGetMessagePtr, UpbGetMessagePtrMut,
};
use pbrs::{ClearAndParse, Parse, Serialize};
use std::ptr::NonNull;

fn field(number: u32, ty: FieldType) -> MiniField {
    MiniField {
        number,
        ty,
        repeated: false,
        packed: false,
        proto3_singular: false,
        required: false,
        is_map: false,
        sub: MiniTablePtr::dangling(),
        closed_enum: None,
        oneof_group: 0,
    }
}
fn table(fields: Vec<MiniField>, is_map: bool) -> Box<MiniTable> {
    Box::new(MiniTable {
        fields,
        is_map,
        enforce_utf8: true,
    })
}
// Drop order keeps tables alive until root and arena pointers are destroyed.
struct Fixture {
    root: Box<MsgData>,
    arena: Arena,
    _tables: Vec<Box<MiniTable>>,
}
impl Default for Fixture {
    fn default() -> Self {
        let child = table(
            vec![
                MiniField {
                    required: true,
                    ..field(1, FieldType::Int32)
                },
                MiniField {
                    required: true,
                    ..field(2, FieldType::Int32)
                },
            ],
            false,
        );
        let child_ptr = MiniTablePtr(child.as_ref());
        let entry = table(
            vec![
                field(1, FieldType::Int32),
                MiniField {
                    sub: child_ptr,
                    ..field(2, FieldType::Message)
                },
            ],
            true,
        );
        let entry_ptr = MiniTablePtr(entry.as_ref());
        let mut parent = table(
            vec![
                MiniField {
                    sub: child_ptr,
                    ..field(1, FieldType::Message)
                },
                MiniField {
                    sub: child_ptr,
                    repeated: true,
                    ..field(2, FieldType::Message)
                },
                MiniField {
                    sub: child_ptr,
                    oneof_group: 1,
                    ..field(3, FieldType::Message)
                },
                MiniField {
                    oneof_group: 1,
                    ..field(4, FieldType::Int32)
                },
                MiniField {
                    sub: entry_ptr,
                    repeated: true,
                    is_map: true,
                    ..field(5, FieldType::Message)
                },
            ],
            false,
        );
        let parent_ptr = MiniTablePtr(parent.as_ref());
        parent.fields.push(MiniField {
            sub: parent_ptr,
            ..field(6, FieldType::Message)
        });
        Self {
            root: Box::new(MsgData {
                slots: vec![FieldKind::Empty; parent.fields.len()],
                has: vec![false; parent.fields.len()],
                strs: Vec::new(),
                unknown: pbrs::rt::UnknownFields::default(),
                mt: parent_ptr,
            }),
            arena: Arena::new(),
            _tables: vec![child, entry, parent],
        }
    }
}
impl SealedInternal for Fixture {}
// SAFETY: root has a stable Box address and linked tables owned by self.
unsafe impl UpbGetMessagePtr for Fixture {
    type Msg = Self;
    fn get_ptr(&self, _: Private) -> MessagePtr<Self> {
        unsafe { MessagePtr::wrap(NonNull::from(self.root.as_ref())) }
    }
}
// SAFETY: the mutable self borrow is exclusive and root's Box remains live.
unsafe impl UpbGetMessagePtrMut for Fixture {
    type Msg = Self;
    fn get_ptr_mut(&mut self, _: Private) -> MessagePtr<Self> {
        unsafe { MessagePtr::wrap(NonNull::from(self.root.as_mut())) }
    }
}
// SAFETY: self owns root and the arena holding every parsed descendant.
unsafe impl UpbGetArena for Fixture {
    fn get_arena(&mut self, _: Private) -> &Arena {
        &self.arena
    }
}
fn len_field(number: u32, body: &[u8]) -> Vec<u8> {
    let mut bytes = Vec::new();
    pbrs::rt::encode_len_field(&mut bytes, number, body);
    bytes
}
fn child(data: &MsgData, index: usize) -> &MsgData {
    let FieldKind::Msg(raw) = data.slots[index] else {
        panic!("expected child")
    };
    // SAFETY: this fixture's live arena owns every decoded child.
    unsafe { &*raw }
}
fn integer(data: &MsgData, index: usize) -> i32 {
    let FieldKind::I32(value) = data.slots[index] else {
        panic!("expected integer")
    };
    value
}
fn map_value(data: &MsgData) -> &MsgData {
    let FieldKind::Map(raw) = data.slots[4] else {
        panic!("expected map")
    };
    // SAFETY: this fixture's live arena owns the map and its value.
    let entries = unsafe { (*raw).entries.borrow() };
    assert_eq!(entries.len(), 1);
    let FieldKind::Msg(raw) = entries[0].1 else {
        panic!("expected map message")
    };
    unsafe { &*raw }
}
fn entry(parts: &[&[u8]]) -> Vec<u8> {
    let mut value = vec![8, 7];
    for part in parts {
        value.extend(len_field(2, part));
    }
    len_field(5, &value)
}
#[test]
fn singular_fragments_merge_before_required_initialization() {
    let message = Fixture::parse(
        &[
            len_field(1, &[8, 11]),
            len_field(1, &[16, 22]),
            len_field(1, &[]),
        ]
        .concat(),
    )
    .unwrap();
    assert_eq!(integer(child(&message.root, 0), 0), 11);
    assert_eq!(integer(child(&message.root, 0), 1), 22);
}
#[test]
fn merge_calls_and_empty_enforcing_merge_validate_retained_tree() {
    let mut message = Fixture::default();
    message
        .merge_from_bytes_dont_enforce_required(&len_field(1, &[8, 11]))
        .unwrap();
    assert!(message.merge_from_bytes(&[]).is_err());
    message.merge_from_bytes(&len_field(1, &[16, 22])).unwrap();
    assert_eq!(integer(child(&message.root, 0), 0), 11);
    assert_eq!(integer(child(&message.root, 0), 1), 22);
    message.merge_from_bytes(&[]).unwrap();
}

#[test]
fn clearing_parse_modes_keep_required_checks_independent() {
    let complete = len_field(1, &[8, 11, 16, 22]);
    let mut message = Fixture::parse(&complete).unwrap();
    message
        .clear_and_parse_dont_enforce_required(&len_field(1, &[8, 33]))
        .unwrap();
    assert!(!child(&message.root, 0).has[1]);
    assert!(message.clear_and_parse(&len_field(1, &[16, 44])).is_err());
    assert!(!child(&message.root, 0).has[0]);
    message.clear_and_parse(&complete).unwrap();
    assert_eq!(integer(child(&message.root, 0), 0), 11);
    assert_eq!(integer(child(&message.root, 0), 1), 22);
}
#[test]
fn same_case_oneof_messages_merge_and_replaced_cases_disappear() {
    let message =
        Fixture::parse(&[len_field(3, &[8, 11]), len_field(3, &[16, 22])].concat()).unwrap();
    assert_eq!(integer(child(&message.root, 2), 0), 11);
    assert_eq!(integer(child(&message.root, 2), 1), 22);
    Fixture::parse(&[len_field(3, &[8, 11]), vec![32, 9]].concat()).unwrap();
    assert!(
        Fixture::parse(
            &[
                len_field(3, &[8, 11, 16, 22]),
                vec![32, 9],
                len_field(3, &[16, 33])
            ]
            .concat()
        )
        .is_err()
    );
}
#[test]
fn repeated_elements_remain_independent_and_are_initialized() {
    let bytes = [len_field(2, &[8, 11]), len_field(2, &[16, 22])].concat();
    assert!(
        Fixture::parse(&bytes).is_err(),
        "repeated fragments cannot merge into each other"
    );
    let message = Fixture::parse_dont_enforce_required(&bytes).unwrap();
    let FieldKind::Repeated(raw) = message.root.slots[1] else {
        panic!("expected array")
    };
    assert_eq!(unsafe { (*raw).items.borrow().len() }, 2);
    Fixture::parse(
        &[
            len_field(2, &[8, 11, 16, 22]),
            len_field(2, &[8, 33, 16, 44]),
        ]
        .concat(),
    )
    .unwrap();
}
#[test]
fn map_messages_merge_within_an_entry_and_last_entry_wins() {
    let message = Fixture::parse(&entry(&[&[8, 11], &[16, 22]])).unwrap();
    assert_eq!(integer(map_value(&message.root), 0), 11);
    assert_eq!(integer(map_value(&message.root), 1), 22);
    let message =
        Fixture::parse(&[entry(&[&[8, 99]]), entry(&[&[8, 11, 16, 22]])].concat()).unwrap();
    assert_eq!(integer(map_value(&message.root), 0), 11);
    assert!(Fixture::parse(&[entry(&[&[8, 11, 16, 22]]), entry(&[&[16, 33]])].concat()).is_err());
    assert!(
        Fixture::parse(&entry(&[])).is_err(),
        "omitted map value is an uninitialized default"
    );
    Fixture::parse_dont_enforce_required(&entry(&[])).unwrap();
}
#[test]
fn ancestor_fragments_can_complete_required_descendants() {
    let bytes = [
        len_field(6, &len_field(1, &[8, 11])),
        len_field(6, &len_field(1, &[16, 22])),
    ]
    .concat();
    let message = Fixture::parse(&bytes).unwrap();
    assert_eq!(integer(child(child(&message.root, 5), 0), 0), 11);
    assert_eq!(integer(child(child(&message.root, 5), 0), 1), 22);
}
#[test]
fn wrong_wire_messages_do_not_replace_valid_children() {
    let message = Fixture::parse(&[len_field(1, &[8, 11, 16, 22]), vec![8, 0]].concat()).unwrap();
    assert_eq!(integer(child(&message.root, 0), 0), 11);
    assert_eq!(integer(child(&message.root, 0), 1), 22);
}
#[test]
fn dont_enforce_rejects_bad_wire_and_excessive_depth() {
    for malformed in [vec![10, 1, 8], vec![10, 5], vec![0x1b, 0x24]] {
        assert!(Fixture::parse_dont_enforce_required(&malformed).is_err());
    }
    let mut bytes = Vec::new();
    for _ in 0..pbrs::RECURSION_LIMIT {
        bytes = len_field(6, &bytes);
    }
    Fixture::parse(&bytes).unwrap();
    assert!(Fixture::parse_dont_enforce_required(&len_field(6, &bytes)).is_err());
    Fixture::parse(&[len_field(1, &[8, 11, 16, 22]), len_field(99, &[0x1b, 0x24])].concat())
        .unwrap();
}

use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicU64, Ordering};
use std::time::Instant;
struct Counter;
static ALLOCS: AtomicU64 = AtomicU64::new(0);
static BYTES: AtomicU64 = AtomicU64::new(0);
unsafe impl GlobalAlloc for Counter {
 unsafe fn alloc(&self,l:Layout)->*mut u8 { ALLOCS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(l.size() as u64,Ordering::Relaxed);unsafe{System.alloc(l)} }
 unsafe fn dealloc(&self,p:*mut u8,l:Layout){unsafe{System.dealloc(p,l)}}
 unsafe fn realloc(&self,p:*mut u8,l:Layout,n:usize)->*mut u8 {ALLOCS.fetch_add(1,Ordering::Relaxed);BYTES.fetch_add(n as u64,Ordering::Relaxed);unsafe{System.realloc(p,l,n)}}
}
#[global_allocator] static ALLOCATOR:Counter=Counter;

fn main() {
 for depth in [0,8,64] {
  let mut bytes=len_field(1,&[8,11,16,22]);
  for _ in 0..depth { bytes=len_field(6,&bytes); }
  let value=Fixture::parse(&bytes).unwrap();
  let expected=value.serialize().unwrap();
  let hash=expected.iter().fold(14695981039346656037u64,|h,b|(h^u64::from(*b)).wrapping_mul(1099511628211));
  for sample in 0..5 {
   let a=ALLOCS.load(Ordering::Relaxed);let b=BYTES.load(Ordering::Relaxed);let start=Instant::now();
   for _ in 0..10000 { assert_eq!(std::hint::black_box(&value).serialized_len(),expected.len()); }
   let elapsed=start.elapsed().as_nanos();let count=ALLOCS.load(Ordering::Relaxed)-a;let requested=BYTES.load(Ordering::Relaxed)-b;
   println!("{{\"depth\":{depth},\"sample\":{sample},\"ns\":{},\"allocations\":{},\"bytes\":{},\"length\":{},\"output_fnv\":\"{hash:016x}\"}}",elapsed as f64/10000.0,count as f64/10000.0,requested as f64/10000.0,expected.len());
  }
 }
}
