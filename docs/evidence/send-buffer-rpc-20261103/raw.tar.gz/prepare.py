#!/usr/bin/env python3
"""Export the same committed RPC source twice, reverting only the send chunk loop."""
import hashlib
import io
import json
from pathlib import Path
import subprocess
import tarfile

ROOT = Path('/workspace/pure-protobuf')
OUT = Path(__file__).resolve().parent
COMMIT = '5d280bfb'
BASE = 'a35701582fb9e6964c855386b0d9c991c50345ba'
SEND = 'pbrs-grpc/src/wire/send.rs'
PATHS = ['Cargo.toml', 'Cargo.lock', 'build.rs', 'README.md', 'LICENSE-MIT', 'LICENSE-APACHE',
         'src', 'pbrs-grpc', 'protobuf-tonic', 'rpc-bench', 'vendor/google', 'examples', 'proto']

def sha(data):
    return hashlib.sha256(data).hexdigest()

def snapshot(root):
    return {str(p.relative_to(root)): sha(p.read_bytes()) for p in sorted(root.rglob('*')) if p.is_file()}

commit = subprocess.check_output(['git', 'rev-parse', COMMIT + '^{commit}'], cwd=ROOT, text=True).strip()
archive = subprocess.check_output(['git', 'archive', '--format=tar', commit, '--', *PATHS], cwd=ROOT)
for side in ('before', 'after'):
    dest = OUT / side
    dest.mkdir(exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as tar:
        tar.extractall(dest, filter='data')
old = subprocess.check_output(['git', 'show', BASE + ':' + SEND], cwd=ROOT)
new = (OUT / 'after' / SEND).read_bytes()
assert b'frame.slice(..n)' in old and b'frame.split_to(n)' in new
(OUT / 'before' / SEND).write_bytes(old)
before, after = snapshot(OUT / 'before'), snapshot(OUT / 'after')
assert before.keys() == after.keys()
assert {name for name in before if before[name] != after[name]} == {SEND}
record = {'commit': commit, 'old_send_commit': BASE, 'paths': PATHS,
          'source_file_count': len(before), 'source_file_sha256_before': before,
          'source_file_sha256_after': after, 'only_difference': SEND,
          'scope': 'Git-exported selected build inputs; not a filesystem read trace'}
(OUT / 'source-manifest.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'commit': commit, 'source_files': len(before),
                  'only_difference': SEND, 'before_sha256': sha(old), 'after_sha256': sha(new)}))
