#!/usr/bin/env python3
"""Build uninstrumented RPC binaries with frozen source and a disk guard."""
import os
from pathlib import Path
import shutil
import signal
import subprocess
import sys
import time

ROOT = Path('/workspace/pure-protobuf')
OUT = Path(__file__).resolve().parent
HELPER = ROOT / 'work/all-benchmarks/measurement/build_rpc_probe.py'
FLOOR = 1024 * 1024 * 1024
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT / 'target'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + str(ROOT / 'work/toolchain/protoc/bin') + ':' + env['PATH']
for side in ('before', 'after'):
    if shutil.disk_usage(ROOT).free < FLOOR:
        raise SystemExit('disk floor reached before build')
    source = OUT / side
    output = OUT / 'built' / side
    cmd = [sys.executable, str(HELPER), '--source', str(source), '--manifest', str(source / 'rpc-bench/Cargo.toml'),
           '--binary-name', 'rpc-bench', '--mode', 'shipping', '--output', str(output), '--record-key', 'rpc-shipping']
    print('Building', side, flush=True)
    process = subprocess.Popen(cmd, cwd=ROOT, env=env, start_new_session=True)
    while process.poll() is None:
        if shutil.disk_usage(ROOT).free < FLOOR:
            os.killpg(process.pid, signal.SIGTERM)
            process.wait()
            raise SystemExit('disk floor reached during build')
        time.sleep(2)
    if process.returncode:
        raise SystemExit(f'{side} build failed: {process.returncode}')
