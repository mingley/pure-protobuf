//! Fetch the official conformance FileDescriptorSet for the runner child.
#![allow(
    clippy::panic,
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::disallowed_methods,
    reason = "build.rs is a sync compile-time script; panic fails the build"
)]

use std::path::Path;
use std::process::Command;

fn main() {
    if std::env::var_os("CARGO_FEATURE_CONFORMANCE").is_none() {
        println!("cargo:rerun-if-changed=build.rs");
        return;
    }
    println!("cargo:rerun-if-changed=proto/person.proto");
    println!("cargo:rerun-if-changed=third_party/protobuf");
    println!("cargo:rerun-if-changed=vendor/google/conformance_fds.bin");
    let out = std::env::var("OUT_DIR").unwrap();
    let fds = Path::new(&out).join("conformance_fds.bin");
    let vendored = Path::new("vendor/google/conformance_fds.bin");
    let root = Path::new("third_party/protobuf");
    let src = root.join("src");
    if src.exists() && try_protoc(&fds, root, &src) {
        println!("cargo:warning=wrote conformance descriptor set");
        return;
    }
    // Never write an empty FDS: that produced 2090 unexpected JsonOutput failures.
    if vendored.exists() {
        std::fs::copy(vendored, &fds).unwrap_or_else(|e| {
            panic!("failed to copy vendor/google/conformance_fds.bin: {e}");
        });
        return;
    }
    panic!(
        "missing vendor/google/conformance_fds.bin; \
         refusing to write an empty conformance descriptor set"
    );
}

fn try_protoc(fds: &Path, root: &Path, src: &Path) -> bool {
    let mut inputs: Vec<std::path::PathBuf> = Vec::new();
    for rel in [
        "google/protobuf/test_messages_proto3.proto",
        "google/protobuf/test_messages_proto2.proto",
        "google/protobuf/any.proto",
        "google/protobuf/duration.proto",
        "google/protobuf/timestamp.proto",
        "google/protobuf/struct.proto",
        "google/protobuf/wrappers.proto",
        "google/protobuf/field_mask.proto",
        "google/protobuf/empty.proto",
    ] {
        let p = src.join(rel);
        if p.exists() {
            inputs.push(p);
        }
    }
    for rel in [
        "conformance/test_protos/test_messages_edition2023.proto",
        "conformance/test_protos/test_messages_edition_unstable.proto",
        "editions/golden/test_messages_proto2_editions.proto",
        "editions/golden/test_messages_proto3_editions.proto",
    ] {
        let p = root.join(rel);
        if p.exists() {
            inputs.push(p);
        }
    }
    if inputs.is_empty() {
        return false;
    }
    let mut cmd = Command::new("protoc");
    cmd.arg("--include_imports")
        .arg("--descriptor_set_out")
        .arg(fds)
        .arg("-I")
        .arg(src)
        .arg("-I")
        .arg(root);
    for p in &inputs {
        cmd.arg(p);
    }
    cmd.status().map(|s| s.success()).unwrap_or(false)
}
