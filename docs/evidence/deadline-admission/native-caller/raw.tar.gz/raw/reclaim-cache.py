"""Reclaim one completed owned namespace after preserving all executables."""
import datetime,hashlib,json,os,pathlib,shutil,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2];work=pathlib.Path(__file__).resolve().parent
namespace,label=sys.argv[1:];cache=(root/'target'/namespace).resolve()
assert cache.parent==root/'target' and cache.is_dir(),cache
record_path=work/f'cache-reclaim-{label}.json';assert not record_path.exists()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
active=[]
for item in pathlib.Path('/proc').iterdir():
    if item.name.isdigit():
        try:raw=(item/'cmdline').read_bytes();exe=os.readlink(item/'exe')
        except (FileNotFoundError,PermissionError,ProcessLookupError):continue
        if pathlib.Path(exe).name in ('cargo','rustc','clippy-driver') and str(cache).encode() in raw:active.append({'pid':item.name,'argv':raw.decode(errors='replace')})
assert not active,active
inventory={str(p.relative_to(cache)):{'bytes':p.stat().st_size,'sha256':sha(p)} for p in cache.rglob('*') if p.is_file()}
preserved={}
for p in cache.rglob('*'):
    if p.is_file() and os.access(p,os.X_OK):
        rel=p.relative_to(cache);target=work/'preserved-executables'/label/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target);target.chmod(0o755)
        assert sha(p)==sha(target)
        preserved[str(p)]={'preserved_path':str(target),'sha256':sha(target),'bytes':target.stat().st_size}
record={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'cache':str(cache),'exclusive_compiler_check':active,'all_cache_files':inventory,'preserved_executables':preserved,'operation':'shutil.rmtree completed owned namespace','bytes_before':sum(p['bytes'] for p in inventory.values())}
record_path.write_text(json.dumps(record,indent=2)+'\n');shutil.rmtree(cache)
for p,info in preserved.items():assert sha(pathlib.Path(info['preserved_path']))==info['sha256']
record.update(cache_removed=not cache.exists(),preserved_all_hashes_verified_after=True,free_bytes_after=shutil.disk_usage(root).free)
record_path.write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps({'namespace':namespace,'bytes_removed':record['bytes_before'],'executables_preserved':len(preserved),'global_free_after':record['free_bytes_after']}),flush=True)
