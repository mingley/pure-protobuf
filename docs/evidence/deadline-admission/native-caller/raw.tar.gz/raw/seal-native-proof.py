"""Freeze raw captures, source snapshots and independently replayable audits."""
import hashlib,json,pathlib,subprocess,tarfile,tomllib
ROOT=pathlib.Path(__file__).resolve().parents[2];WORK=pathlib.Path(__file__).resolve().parent
OUT=ROOT/'docs/evidence/deadline-admission/native-caller';OUT.mkdir(parents=True,exist_ok=True)
sha=lambda p:hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
records=[]
for path in sorted(WORK.glob('*.meta.json')):
    row=json.loads(path.read_text())
    records.append({'name':path.stem.removesuffix('.meta'),'source':row.get('before',{}).get('head'),'exit':row.get('exit'),'pins_unchanged':row.get('pins_unchanged'),'seconds':row.get('elapsed_seconds'),'stop_reason':row.get('stop_reason'),'metadata_sha256':sha(path),'argv':row.get('argv')})
required=['031-final-clippy188','032-final-msrv185-build','033-final-msrv185-lib','034-final-msrv185-deadline','035-final-msrv185-retry','036-final-msrv185-preface','037-final-native-interop-build185','039-final-tonic188-build','040-final-tonic188-lib','041-final-tonic188-deadline','042-final-tonic188-retry','043-final-tonic188-preface','045-final-generated-tonic-build','046-final-generated-tonic-clients','047-final-generated-tonic-services']
for name in required:
    row=next(r for r in records if r['name']==name);assert row['exit']==0 and row['pins_unchanged'],row
for kind in ('path','package'):
    for profile in ('default','tower','tonic'):
        row=next(r for r in records if r['name']==f'consumer-final-{kind}-{profile}-run');assert row['exit']==0 and row['pins_unchanged'],row
sources=sorted({row['source'] for row in records if row['source']})
# Archives contain compile/test inputs, not existing evidence archives or tools.
prefixes=('src/','vendor/','proto/','pbrs-grpc/','protobuf-tonic/','examples/greeter/','examples/axum-cohost/','examples/tonic-ports/','tests/interop/tonic/')
root_inputs={'Cargo.toml','Cargo.lock','build.rs','README.md','LICENSE-MIT','LICENSE-APACHE','clippy.toml','rustfmt.toml'}
source_sets={}
for source in sources:
    paths=subprocess.check_output(['git','ls-tree','-r','--name-only',source],cwd=ROOT,text=True).splitlines()
    selected=[p for p in paths if p.startswith(prefixes) or p in root_inputs]
    dest=OUT/f'source-{source[:12]}.tar.gz'
    with dest.open('wb') as out:
        subprocess.run(['git','archive','--format=tar.gz',source,*selected],cwd=ROOT,stdout=out,check=True)
    with tarfile.open(dest,'r:gz') as archive:
        members={m.name:hashlib.sha256(archive.extractfile(m).read()).hexdigest() for m in archive if m.isfile()}
    source_sets[source]={'archive':dest.name,'sha256':sha(dest),'members_sha256':members}
raw=OUT/'raw.tar.gz';raw_members={}
with tarfile.open(raw,'w:gz') as archive:
    for path in sorted(WORK.rglob('*')):
        relative=path.relative_to(WORK)
        if not path.is_file() or any(part.startswith('preserved') or part=='__pycache__' for part in relative.parts):continue
        if path.suffix in ('.rlib','.rmeta','.so') or path.read_bytes()[:4]==b'\x7fELF':continue
        name='raw/'+str(relative);raw_members[name]=sha(path);archive.add(path,arcname=name,recursive=False)
    for path in sorted((ROOT/'target/package-only-stable99/package').glob('*.crate')):
        name='packages/'+path.name;raw_members[name]=sha(path);archive.add(path,arcname=name,recursive=False)
raw_inventory={'archive':raw.name,'sha256':sha(raw),'members_sha256':raw_members}
consumer=json.loads((WORK/'consumers-final.json').read_text());members=json.loads((WORK/'package-final-member-audit.json').read_text())
proof={'final_provider_source':head,'compiler_input_identity':json.loads((WORK/'provider-helper-only-merge.json').read_text()),'records':records,'source_sets':source_sets,'raw':raw_inventory,'consumers':consumer,'packages':members,'limits':['809 broad passes at2826 are historical source-qualified scope; final narrower passes have their own source labels.','Declared ignores and incomplete45s lifecycle attempt are retained; only full900s same-ELF campaign qualifies lifecycle.','Initial invalid helper captures and unavailable Cargo package flag and stale testlock reds remain separate; raw-retention gaps are documented.','Opaque raw path-label tests share one counted body fixture; actual generated client/server shape evidence is separate.','Pre-poll clock/watch checks are cooperative outside the stream lock, not atomic cancellation or FIFO fairness.','No performance, cross-language mTLS, full official profile or long soak claim.','Executables/rlibs are workspace/hash artifacts, excluded from git proof blobs.']}
(OUT/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
(OUT/'members-sha256.json').write_text(json.dumps({'source_sets':source_sets,'raw':raw_inventory},indent=2)+'\n')
print(json.dumps({'out':str(OUT),'source_sets':len(source_sets),'raw_members':len(raw_members),'records':len(records),'bytes':sum(p.stat().st_size for p in OUT.glob('*.gz'))}),flush=True)
