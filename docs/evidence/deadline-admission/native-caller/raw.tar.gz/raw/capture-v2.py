import datetime, hashlib, json, os, pathlib, shutil, subprocess, sys, time
root = pathlib.Path.cwd()
out = root / 'work/native-admission-gates'
name, *argv = sys.argv[1:]
toolchain = os.environ.get('PBRS_GATE_TOOLCHAIN', '1.88.0')
bound = int(os.environ.get('PBRS_GATE_BOUND_SECONDS', '900' if argv[0] == 'cargo' else '45'))
base = out / name

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def snapshot():
    paths = subprocess.check_output(['git', 'ls-files', '-z', 'Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml', 'rustfmt.toml', 'src', 'pbrs-grpc/Cargo.toml', 'pbrs-grpc/build.rs', 'pbrs-grpc/src', 'pbrs-grpc/tests']).split(b'\0')
    files = {os.fsdecode(p): sha(root / os.fsdecode(p)) for p in paths if p}
    tools = {'capture_script': {'path': str(pathlib.Path(__file__).resolve()), 'sha256': sha(__file__)}}
    for tool in ('rustc', 'cargo'):
        path = subprocess.check_output(['rustup', 'which', '--toolchain', toolchain, tool], text=True).strip()
        tools[tool] = {'path': path, 'sha256': sha(path), 'version': subprocess.check_output([path, '-Vv'], text=True)}
    protoc = os.environ['PROTOC']
    tools['protoc'] = {'path': protoc, 'sha256': sha(protoc), 'version': subprocess.check_output([protoc, '--version'], text=True).strip()}
    if argv and pathlib.Path(argv[0]).is_file():
        tools['launched_executable'] = {'path': argv[0], 'sha256': sha(argv[0])}
    return {'head': subprocess.check_output(['git','rev-parse','HEAD'], text=True).strip(), 'status': subprocess.check_output(['git','status','--porcelain'], text=True), 'files': files, 'tools': tools}

if shutil.disk_usage(root).free < 2 * 1024**3:
    raise SystemExit('Global free disk below 2GiB; command not launched')
meta = {'argv': argv, 'cwd': str(root), 'toolchain': toolchain, 'os_bound_seconds': bound, 'utc_start': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'env': {k: os.environ.get(k) for k in ('RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','PBRS_GATE_TOOLCHAIN','PBRS_GATE_BOUND_SECONDS','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','PROTOC','PATH')}, 'before': snapshot()}
base.with_suffix('.meta.json').write_text(json.dumps(meta, indent=2)+'\n')
start = time.monotonic()
with base.with_suffix('.stdout.log').open('wb') as stdout, base.with_suffix('.stderr.log').open('wb') as stderr:
    child = subprocess.Popen(argv, stdout=stdout, stderr=stderr)
    try:
        code = child.wait(timeout=bound)
    except subprocess.TimeoutExpired:
        child.kill(); child.wait(); code = 124
meta.update(exit=code, elapsed_seconds=time.monotonic()-start, utc_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=snapshot())
meta['pins_unchanged'] = meta['before'] == meta['after']
meta['stdout_sha256'] = sha(base.with_suffix('.stdout.log'))
meta['stderr_sha256'] = sha(base.with_suffix('.stderr.log'))
base.with_suffix('.meta.json').write_text(json.dumps(meta, indent=2)+'\n')
base.with_suffix('.exit').write_text(str(code)+'\n')
print(json.dumps({'gate':name,'exit':code,'pins_unchanged':meta['pins_unchanged'],'elapsed_seconds':meta['elapsed_seconds']}), flush=True)
sys.exit(code)
