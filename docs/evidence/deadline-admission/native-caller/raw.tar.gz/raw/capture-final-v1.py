import datetime, hashlib, json, os, pathlib, shutil, signal, subprocess, sys, time
root = pathlib.Path(__file__).resolve().parents[2]
out = pathlib.Path(__file__).resolve().parent
name, *argv = sys.argv[1:]
base = out / name
cwd = pathlib.Path(os.environ.get('PBRS_GATE_CWD', str(root))).resolve()
toolchain = os.environ.get('PBRS_GATE_TOOLCHAIN', '1.88.0')
bound = int(os.environ.get('PBRS_GATE_BOUND_SECONDS', '900' if argv[0] == 'cargo' else '45'))
input_roots = [pathlib.Path(p).resolve() for p in json.loads(os.environ.get('PBRS_GATE_INPUT_ROOTS', '[]'))]
cache_root = root / 'target'

def sha(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def direct_inputs(phase):
    result = {}
    for index, item in enumerate(input_roots):
        paths = [item] if item.is_file() else sorted(p for p in item.rglob('*') if p.is_file() and not any(part in ('target', '.git') for part in p.relative_to(item).parts))
        for path in paths:
            rel = pathlib.Path(path.name) if item.is_file() else path.relative_to(item)
            key = f'{index}/{rel}'
            result[key] = {'path': str(path), 'sha256': sha(path), 'bytes': path.stat().st_size}
            target = out / f'{name}.{phase}.inputs' / str(index) / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, target)
    return result

def snapshot(phase):
    paths = subprocess.check_output(['git', 'ls-files', '-z', 'Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml', 'rustfmt.toml', 'src', 'pbrs-grpc/Cargo.toml', 'pbrs-grpc/build.rs', 'pbrs-grpc/src', 'pbrs-grpc/tests'], cwd=root).split(b'\0')
    files = {os.fsdecode(p): sha(root / os.fsdecode(p)) for p in paths if p}
    tools = {'capture_script': {'path': str(pathlib.Path(__file__).resolve()), 'sha256': sha(__file__)}}
    for tool in (('rustc', 'cargo', 'clippy-driver', 'cargo-clippy') if 'clippy' in argv else ('rustc', 'cargo')):
        path = subprocess.check_output(['rustup', 'which', '--toolchain', toolchain, tool], text=True).strip()
        tools[tool] = {'path': path, 'sha256': sha(path)}
        if tool != 'cargo-clippy':
            tools[tool]['version'] = subprocess.check_output([path, '--version' if tool == 'clippy-driver' else '-Vv'], text=True)
    protoc = os.environ['PROTOC']
    tools['protoc'] = {'path': protoc, 'sha256': sha(protoc), 'version': subprocess.check_output([protoc, '--version'], text=True).strip()}
    if argv and pathlib.Path(argv[0]).is_file():
        tools['launched_executable'] = {'path': argv[0], 'sha256': sha(argv[0])}
    return {'head': subprocess.check_output(['git','rev-parse','HEAD'], cwd=root, text=True).strip(), 'status': subprocess.check_output(['git','status','--porcelain'], cwd=root, text=True), 'files': files, 'tools': tools, 'direct_inputs': direct_inputs(phase)}

def resources():
    cache_bytes = sum(p.stat().st_size for p in cache_root.rglob('*') if p.is_file()) if cache_root.exists() else 0
    return {'cache_apparent_bytes': cache_bytes, 'global_free_bytes': shutil.disk_usage(root).free}

def violation(state):
    if state['cache_apparent_bytes'] > 2 * 1024**3:
        return 'owned Cargo cache exceeds 2GiB'
    if state['global_free_bytes'] < 2 * 1024**3:
        return 'global free disk below 2GiB'
    return None

initial_resources = resources()
problem = violation(initial_resources)
if problem:
    raise SystemExit(problem + '; command not launched')
meta = {'argv': argv, 'cwd': str(cwd), 'provider_root': str(root), 'toolchain': toolchain, 'os_bound_seconds': bound, 'utc_start': datetime.datetime.now(datetime.timezone.utc).isoformat(), 'env': {k: os.environ.get(k) for k in ('RUSTUP_HOME','RUSTUP_TOOLCHAIN','RUSTC','RUSTDOC','PBRS_GATE_TOOLCHAIN','PBRS_GATE_BOUND_SECONDS','PBRS_GATE_CWD','PBRS_GATE_INPUT_ROOTS','CARGO_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG','CARGO_PROFILE_TEST_DEBUG','RUSTFLAGS','CARGO_ENCODED_RUSTFLAGS','CARGO_BUILD_TARGET','PROTOC','PATH')}, 'before': snapshot('before'), 'resources_start': initial_resources}
base.with_suffix('.meta.json').write_text(json.dumps(meta, indent=2)+'\n')
start = time.monotonic()
resource_samples = []
stop_reason = None
with base.with_suffix('.stdout.log').open('wb') as stdout, base.with_suffix('.stderr.log').open('wb') as stderr:
    child = subprocess.Popen(argv, cwd=cwd, stdout=stdout, stderr=stderr, start_new_session=True)
    while True:
        code = child.poll()
        if code is not None:
            break
        current = resources()
        resource_samples.append({'elapsed_seconds': time.monotonic()-start, **current})
        stop_reason = violation(current)
        if time.monotonic()-start > bound:
            stop_reason = 'OS campaign timeout'
        if stop_reason:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
            code = 124 if stop_reason == 'OS campaign timeout' else 125
            break
        time.sleep(1)
meta.update(exit=code, stop_reason=stop_reason, elapsed_seconds=time.monotonic()-start, utc_finish=datetime.datetime.now(datetime.timezone.utc).isoformat(), after=snapshot('after'), resources_finish=resources(), resource_samples=resource_samples)
meta['pins_unchanged'] = meta['before'] == meta['after']
meta['stdout_sha256'] = sha(base.with_suffix('.stdout.log'))
meta['stderr_sha256'] = sha(base.with_suffix('.stderr.log'))
base.with_suffix('.meta.json').write_text(json.dumps(meta, indent=2)+'\n')
base.with_suffix('.exit').write_text(str(code)+'\n')
print(json.dumps({'gate':name,'exit':code,'pins_unchanged':meta['pins_unchanged'],'elapsed_seconds':meta['elapsed_seconds'],'stop_reason':stop_reason}), flush=True)
sys.exit(code)
