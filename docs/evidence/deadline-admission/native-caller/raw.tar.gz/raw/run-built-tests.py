import hashlib,json,os,pathlib,subprocess,sys
root=pathlib.Path(__file__).resolve().parents[2]; work=pathlib.Path(__file__).resolve().parent
build=sys.argv[1]; selector=sys.argv[2]
requests=[item.split('=',1) for item in sys.argv[3:]]
meta=json.loads((work/f'{build}.meta.json').read_text())
assert meta['exit']==0 and meta['pins_unchanged'],build
artifacts={}
for line in (work/f'{build}.stdout.log').read_text().splitlines():
    try:item=json.loads(line)
    except json.JSONDecodeError:continue
    if item.get('reason')=='compiler-artifact' and item.get('executable') and item['profile']['test']:
        target=item['target']['name']; assert target not in artifacts,target
        artifacts[target]=item
pins={}
for label,target in requests:
    item=artifacts[target];p=pathlib.Path(item['executable']); pins[target]={'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'compiler_artifact':item}
(work/f'{build}.executable-pins.json').write_text(json.dumps({'build_source':meta['before']['head'],'runner_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),'selected':pins},indent=2)+'\n')
for label,target in requests:
    env={**os.environ,'RUSTUP_TOOLCHAIN':selector,'PBRS_GATE_TOOLCHAIN':selector,'PBRS_GATE_BOUND_SECONDS':'45'}
    code=subprocess.call(['python3',str(work/'capture-final.py'),label,pins[target]['path'],'--nocapture','--test-threads=1'],cwd=root,env=env)
    if code:raise SystemExit(code)
    assert json.loads((work/f'{label}.meta.json').read_text())['pins_unchanged'],label
