"""Fresh source-guarded path and package consumers; no private-backend patch."""
import hashlib, json, os, pathlib, shutil, subprocess, tarfile, tomllib
ROOT = pathlib.Path(__file__).resolve().parents[2]
WORK = pathlib.Path(__file__).resolve().parent
OUTSIDE = ROOT.parent / 'deadline-admission-native-consumers'
EXPECTED = 'hello ada\nhello grace, alan\nhello edsger #1\nhello edsger #2\nhello edsger #3\nhello barbara\nhello katherine'
FIXTURE = pathlib.Path('/workspace/scratch/work/h2-embedded-consumers/path/src/main.rs')

def digest(path):
    return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()

def inventory(path):
    return {str(p.relative_to(path)): digest(p) for p in sorted(path.rglob('*')) if p.is_file() and 'target' not in p.relative_to(path).parts}

def gate(label, argv, selector, cwd=ROOT, inputs=(), guards=()):
    env = {**os.environ, 'RUSTUP_TOOLCHAIN': selector, 'PBRS_GATE_TOOLCHAIN': selector,
        'PBRS_GATE_CWD': str(cwd), 'PBRS_GATE_INPUT_ROOTS': json.dumps([str(p) for p in inputs]),
        'PBRS_GATE_GUARD_ROOTS': json.dumps([str(p) for p in guards]),
        'CARGO_TARGET_DIR': str(ROOT / 'target' / ('consumers185' if selector == '1.85.0' else 'consumers188')),
        'CARGO_BUILD_JOBS': '1', 'CARGO_INCREMENTAL': '0'}
    code = subprocess.call(['python3', str(WORK/'capture-final.py'), label, *argv], env=env, cwd=ROOT)
    if code:
        raise RuntimeError(f'{label} exit {code}')
    return json.loads((WORK/f'{label}.meta.json').read_text())

def write_consumer(kind, grpc, core=None):
    consumer = OUTSIDE / kind
    consumer.mkdir(parents=True, exist_ok=False)
    manifest = '''[package]
name = "deadline-admission-final-%s"
version = "0.0.0"
edition = "2024"
[workspace]
[features]
tower = ["pbrs-grpc/tower", "dep:tower"]
tonic = ["tower", "pbrs-grpc/tonic", "dep:tonic", "dep:http", "dep:h2"]
[dependencies]
pbrs-grpc = { path = %s }
tokio = { version = "1", features = ["rt-multi-thread", "macros", "net", "time", "sync", "io-util", "fs"] }
tower = { version = "0.5", default-features = false, features = ["util"], optional = true }
tonic = { version = "0.14.6", default-features = false, features = ["codegen", "transport", "router", "_tls-any"], optional = true }
http = { version = "1", optional = true }
h2 = { version = "0.4.18", optional = true }
''' % (kind, json.dumps(str(grpc)))
    if core is not None:
        manifest += '[patch.crates-io]\npbrs = { path = ' + json.dumps(str(core)) + ' }\n'
    assert 'h2 = { path' not in manifest and 'h2_backend' not in manifest
    (consumer/'Cargo.toml').write_text(manifest)
    (consumer/'Cargo.lock').write_bytes((ROOT/'Cargo.lock').read_bytes())
    (consumer/'src').mkdir()
    shutil.copyfile(FIXTURE, consumer/'src/main.rs')
    return consumer

def assert_lock_pins(consumer):
    identity = lambda p: (p['name'], p['version'], p.get('source'), p.get('checksum'))
    source = tomllib.loads((ROOT/'Cargo.lock').read_text())
    output = tomllib.loads((consumer/'Cargo.lock').read_text())
    before = {identity(p) for p in source['package'] if p.get('source')}
    after = {identity(p) for p in output['package'] if p.get('source')}
    assert after <= before, sorted(after-before)
    assert next(p['version'] for p in output['package'] if p['name']=='indexmap') == '2.14.0'
    return {'registry_tuple_count':len(after),'provider_registry_tuple_count':len(before),'registry_pins_subset_provider':True,'indexmap':'2.14.0','consumer_lock_sha256':digest(consumer/'Cargo.lock'),'registry_tuples':sorted(after)}

def run_consumer(kind, consumer, guards=(), profiles=('default','tower','tonic')):
    result = {}
    for profile, selector in [('default','1.85.0'),('tower','1.85.0'),('tonic','1.88.0')]:
        if profile not in profiles:
            continue
        features = [] if profile=='default' else ['--features',profile]
        label=f'consumer-final-{kind}-{profile}-resolve'
        meta=gate(label,['cargo','+'+selector,'metadata','--offline','--format-version','1','--filter-platform','x86_64-unknown-linux-gnu',*features],selector,consumer,[consumer],guards)
        result[profile]=assert_lock_pins(consumer)
        result[profile]['resolve_input_changes_expected']=not meta['pins_unchanged']
        label=f'consumer-final-{kind}-{profile}-run'
        meta=gate(label,['cargo','+'+selector,'run','--offline','--locked',*features],selector,consumer,[consumer],guards)
        assert meta['pins_unchanged'], label
        assert (WORK/f'{label}.stdout.log').read_text().rstrip().endswith(EXPECTED), label
        result[profile].update(four_native_rpc_shapes=True,tower_typed_unary=profile!='default',tonic_channel_trait_and_registry_h2_error_identity=profile=='tonic',direct_inputs_before_after_unchanged=True)
    return result

def package_stage():
    stage=OUTSIDE/'package-stage'
    existing_stage = stage.exists()
    stage.mkdir(parents=True, exist_ok=True)
    tracked=subprocess.check_output(['git','ls-files','-z'],cwd=ROOT).decode().split('\0')
    selected=[p for p in tracked if p and (p.startswith(('src/','vendor/','pbrs-grpc/','protobuf-tonic/','examples/greeter/','examples/axum-cohost/','examples/tonic-ports/')) or p in ('Cargo.toml','Cargo.lock','build.rs','README.md','LICENSE-MIT','LICENSE-APACHE','clippy.toml','rustfmt.toml'))]
    for p in selected:
        target=stage/p
        if existing_stage:
            assert target.is_file() and digest(target)==digest(ROOT/p),p
        else:
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(ROOT/p,target)
    meta=gate('package-final-locked',['cargo','+1.88.0','package','-p','pbrs','-p','pbrs-grpc','--no-verify','--allow-dirty','--offline','--registry','crates-io','--locked'],'1.88.0',stage,[],[stage])
    assert meta['pins_unchanged'], 'package stage inputs changed'
    return ROOT/'target/consumers188/package'

def unpack_and_audit(packages):
    unpack=OUTSIDE/'unpacked'; unpack.mkdir()
    roots={}; audits={}
    for name,version in [('pbrs','0.2.0'),('pbrs-grpc','0.1.0-alpha.2')]:
        path=packages/f'{name}-{version}.crate'
        with tarfile.open(path,'r:gz') as archive:
            members={member.name: hashlib.sha256(archive.extractfile(member).read()).hexdigest() for member in archive if member.isfile()}
            archive.extractall(unpack,filter='data')
        roots[name]=unpack/f'{name}-{version}'
        audits[name]={'crate_sha256':digest(path),'members_sha256':members}
    grpc=roots['pbrs-grpc']; embedded={}
    for original in (ROOT/'pbrs-grpc/src/h2_backend').rglob('*'):
        if original.is_file():
            relative=original.relative_to(ROOT/'pbrs-grpc'); member=grpc/relative
            assert member.is_file(),relative
            assert digest(member)==digest(original),relative
            embedded[str(relative)]=digest(member)
    assert len([p for p in embedded if p.endswith('.rs')])==54
    manifest=tomllib.loads((grpc/'Cargo.toml').read_text())
    assert 'patch' not in manifest and 'path' not in manifest['dependencies']['h2'] and manifest['dependencies']['h2']['optional']
    assert manifest['dependencies']['indexmap']['version']=='2.14.0'
    for record in ('provenance.json','caller-overlay.json','caller-overlay.patch','clippy-1.88-overlay.json','clippy-1.88-overlay.patch','replay-clippy-1.88-overlay.py','wake-guard-1.88-overlay.json','wake-guard-1.88-overlay.patch','replay-wake-guard-1.88-overlay.py','LICENSE-MIT'):
        assert 'src/h2_backend/'+record in embedded,record
    audits['embedded_all_members']=embedded
    (WORK/'package-final-member-audit.json').write_text(json.dumps(audits,indent=2)+'\n')
    return roots

if __name__=='__main__':
    OUTSIDE.mkdir(exist_ok=True)
    before_lock=digest(ROOT/'Cargo.lock')
    source=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
    path=OUTSIDE/'path'
    if path.exists():
        assert (path/'src/main.rs').read_bytes()==FIXTURE.read_bytes()
        assert (path/'Cargo.lock').read_bytes()==(ROOT/'Cargo.lock').read_bytes()
        assert str(ROOT/'pbrs-grpc') in (path/'Cargo.toml').read_text()
    else:
        path=write_consumer('path',ROOT/'pbrs-grpc')
    result={'source':source,'fixture_sha256':digest(FIXTURE),'path':{},'package':{}}
    packages=package_stage(); roots=unpack_and_audit(packages)
    package=write_consumer('package',roots['pbrs-grpc'],roots['pbrs'])
    for kind, consumer, guards in [('path',path,()),('package',package,[roots['pbrs'],roots['pbrs-grpc']])]:
        result[kind].update(run_consumer(kind,consumer,guards,('default','tower')))
    code=subprocess.call(['python3',str(WORK/'reclaim-cache.py'),'consumers185','after-final-msrv-and-four-consumers'],cwd=ROOT)
    if code: raise RuntimeError('cache reclaim failed')
    for kind, consumer, guards in [('path',path,()),('package',package,[roots['pbrs'],roots['pbrs-grpc']])]:
        result[kind].update(run_consumer(kind,consumer,guards,('tonic',)))
    assert digest(ROOT/'Cargo.lock')==before_lock
    result.update(root_lock_before_sha256=before_lock,root_lock_after_sha256=digest(ROOT/'Cargo.lock'),backend_patch_present=False,only_package_patch='unpacked local pbrs core; no backend patch')
    (WORK/'consumers-final.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
