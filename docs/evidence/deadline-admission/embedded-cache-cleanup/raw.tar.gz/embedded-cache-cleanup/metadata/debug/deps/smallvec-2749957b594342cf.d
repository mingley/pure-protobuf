/workspace/scratch/work/h2-embedded/target/debug/deps/smallvec-2749957b594342cf.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.15.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libsmallvec-2749957b594342cf.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.15.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libsmallvec-2749957b594342cf.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.15.2/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/smallvec-1.15.2/src/lib.rs:
