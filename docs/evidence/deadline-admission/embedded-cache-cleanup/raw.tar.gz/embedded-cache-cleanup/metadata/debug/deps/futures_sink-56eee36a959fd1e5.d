/workspace/scratch/work/h2-embedded/target/debug/deps/futures_sink-56eee36a959fd1e5.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libfutures_sink-56eee36a959fd1e5.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libfutures_sink-56eee36a959fd1e5.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs:
