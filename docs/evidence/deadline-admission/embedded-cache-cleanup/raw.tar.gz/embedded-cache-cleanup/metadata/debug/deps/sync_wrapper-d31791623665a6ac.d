/workspace/scratch/work/h2-embedded/target/debug/deps/sync_wrapper-d31791623665a6ac.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sync_wrapper-1.0.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libsync_wrapper-d31791623665a6ac.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sync_wrapper-1.0.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libsync_wrapper-d31791623665a6ac.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sync_wrapper-1.0.2/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/sync_wrapper-1.0.2/src/lib.rs:
