/workspace/scratch/work/h2-embedded/target/debug/deps/want-0581fd3c7a87c065.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libwant-0581fd3c7a87c065.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libwant-0581fd3c7a87c065.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/want-0.3.1/src/lib.rs:
