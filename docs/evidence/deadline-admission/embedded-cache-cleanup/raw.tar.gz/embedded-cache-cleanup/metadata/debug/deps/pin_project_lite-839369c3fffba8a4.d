/workspace/scratch/work/h2-embedded/target/debug/deps/pin_project_lite-839369c3fffba8a4.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project_lite-839369c3fffba8a4.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project_lite-839369c3fffba8a4.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs:
