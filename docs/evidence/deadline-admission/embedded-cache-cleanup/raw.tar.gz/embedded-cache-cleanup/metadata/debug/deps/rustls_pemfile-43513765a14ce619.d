/workspace/scratch/work/h2-embedded/target/debug/deps/librustls_pemfile-43513765a14ce619.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/librustls_pemfile-43513765a14ce619.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/rustls_pemfile-43513765a14ce619.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs:
