/workspace/scratch/work/h2-embedded/target/debug/deps/libhttp_body-c37a50ee8d29ec15.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libhttp_body-c37a50ee8d29ec15.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/http_body-c37a50ee8d29ec15.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs:
