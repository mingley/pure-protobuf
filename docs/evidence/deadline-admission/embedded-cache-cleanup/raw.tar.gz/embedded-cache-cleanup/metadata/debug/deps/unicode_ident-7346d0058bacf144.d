/workspace/scratch/work/h2-embedded/target/debug/deps/unicode_ident-7346d0058bacf144.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/tables.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libunicode_ident-7346d0058bacf144.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/tables.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libunicode_ident-7346d0058bacf144.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/tables.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/unicode-ident-1.0.24/src/tables.rs:
