/workspace/scratch/work/h2-embedded/target/debug/deps/try_lock-71e6b4cd03bfb1d3.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/try-lock-0.2.5/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libtry_lock-71e6b4cd03bfb1d3.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/try-lock-0.2.5/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libtry_lock-71e6b4cd03bfb1d3.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/try-lock-0.2.5/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/try-lock-0.2.5/src/lib.rs:
