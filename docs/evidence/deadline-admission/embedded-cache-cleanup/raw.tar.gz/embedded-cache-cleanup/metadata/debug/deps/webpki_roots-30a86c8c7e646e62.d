/workspace/scratch/work/h2-embedded/target/debug/deps/libwebpki_roots-30a86c8c7e646e62.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libwebpki_roots-30a86c8c7e646e62.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/webpki_roots-30a86c8c7e646e62.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/webpki-roots-1.0.9/src/lib.rs:
