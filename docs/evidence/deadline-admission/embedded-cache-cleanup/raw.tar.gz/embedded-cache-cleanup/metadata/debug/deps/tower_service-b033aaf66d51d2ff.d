/workspace/scratch/work/h2-embedded/target/debug/deps/tower_service-b033aaf66d51d2ff.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libtower_service-b033aaf66d51d2ff.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libtower_service-b033aaf66d51d2ff.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs:
