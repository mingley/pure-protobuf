/workspace/scratch/work/h2-embedded/target/debug/deps/libfutures_sink-81f36296656f691b.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libfutures_sink-81f36296656f691b.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/futures_sink-81f36296656f691b.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/futures-sink-0.3.34/src/lib.rs:
