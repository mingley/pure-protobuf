/workspace/scratch/work/h2-embedded/target/debug/deps/atomic_waker-4d226d98210d8998.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libatomic_waker-4d226d98210d8998.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libatomic_waker-4d226d98210d8998.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/atomic-waker-1.1.2/src/lib.rs:
