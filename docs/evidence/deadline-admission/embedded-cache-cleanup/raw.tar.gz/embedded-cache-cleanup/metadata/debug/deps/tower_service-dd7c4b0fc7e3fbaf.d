/workspace/scratch/work/h2-embedded/target/debug/deps/libtower_service-dd7c4b0fc7e3fbaf.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libtower_service-dd7c4b0fc7e3fbaf.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/tower_service-dd7c4b0fc7e3fbaf.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/tower-service-0.3.3/src/lib.rs:
