/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project_lite-a27e72e4158734e5.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project_lite-a27e72e4158734e5.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/pin_project_lite-a27e72e4158734e5.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-lite-0.2.17/src/lib.rs:
