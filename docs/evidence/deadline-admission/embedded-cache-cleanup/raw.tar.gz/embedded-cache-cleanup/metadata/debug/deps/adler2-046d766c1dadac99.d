/workspace/scratch/work/h2-embedded/target/debug/deps/libadler2-046d766c1dadac99.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/algo.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libadler2-046d766c1dadac99.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/algo.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/adler2-046d766c1dadac99.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/algo.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/adler2-2.0.1/src/algo.rs:
