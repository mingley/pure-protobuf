/workspace/scratch/work/h2-embedded/target/debug/deps/rustls_pemfile-c23b06ec46733f4b.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/librustls_pemfile-c23b06ec46733f4b.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/librustls_pemfile-c23b06ec46733f4b.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/rustls-pemfile-2.2.0/src/pemfile.rs:
