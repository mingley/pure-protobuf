/workspace/scratch/work/h2-embedded/target/debug/deps/libcfg_if-db3e827e061e6728.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.4/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libcfg_if-db3e827e061e6728.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.4/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/cfg_if-db3e827e061e6728.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.4/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/cfg-if-1.0.4/src/lib.rs:
