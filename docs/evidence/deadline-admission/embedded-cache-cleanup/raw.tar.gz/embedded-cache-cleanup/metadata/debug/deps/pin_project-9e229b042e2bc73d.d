/workspace/scratch/work/h2-embedded/target/debug/deps/pin_project-9e229b042e2bc73d.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-1.1.13/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project-9e229b042e2bc73d.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-1.1.13/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libpin_project-9e229b042e2bc73d.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-1.1.13/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/pin-project-1.1.13/src/lib.rs:
