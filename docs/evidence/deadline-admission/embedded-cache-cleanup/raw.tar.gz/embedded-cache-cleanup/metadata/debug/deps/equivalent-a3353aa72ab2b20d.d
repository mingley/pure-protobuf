/workspace/scratch/work/h2-embedded/target/debug/deps/equivalent-a3353aa72ab2b20d.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libequivalent-a3353aa72ab2b20d.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libequivalent-a3353aa72ab2b20d.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/equivalent-1.0.2/src/lib.rs:
