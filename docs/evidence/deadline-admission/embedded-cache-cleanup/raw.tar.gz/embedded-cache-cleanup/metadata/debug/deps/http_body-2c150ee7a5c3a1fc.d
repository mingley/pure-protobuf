/workspace/scratch/work/h2-embedded/target/debug/deps/http_body-2c150ee7a5c3a1fc.d: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libhttp_body-2c150ee7a5c3a1fc.rlib: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/scratch/work/h2-embedded/target/debug/deps/libhttp_body-2c150ee7a5c3a1fc.rmeta: /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs /workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs

/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/lib.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/frame.rs:
/workspace/pure-protobuf/work/toolchain/cargo/registry/src/index.crates.io-1949cf8c6b5b557f/http-body-1.1.0/src/size_hint.rs:
