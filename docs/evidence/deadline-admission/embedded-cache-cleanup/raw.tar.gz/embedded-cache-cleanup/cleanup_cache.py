#!/usr/bin/env python3
"""Snapshot only this leaf's completed cache; deletion is a separate phase."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
CACHE = ROOT / "target"
WORK = Path(__file__).resolve().parent / "cache-cleanup"


def digest(path):
    hasher = hashlib.sha256()
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            hasher.update(block)
    return hasher.hexdigest()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def process_snapshot():
    excluded = set()
    pid = os.getpid()
    while pid > 0 and pid not in excluded:
        excluded.add(pid)
        try:
            status = Path(f"/proc/{pid}/status").read_text()
            pid = int(next(line for line in status.splitlines() if line.startswith("PPid:")).split()[1])
        except (OSError, StopIteration):
            break
    owners, errors = [], {}
    inspected = 0
    zombies = 0
    for path in Path("/proc").iterdir():
        if not path.name.isdecimal():
            continue
        inspected += 1
        reasons = []
        try:
            status = (path / "status").read_text()
            state = next(line for line in status.splitlines() if line.startswith("State:"))
            if "Z (zombie)" in state:
                zombies += 1
                continue
            cwd = (path / "cwd").resolve(strict=True)
            if cwd == ROOT or ROOT in cwd.parents:
                reasons.append("working directory inside owned worktree")
            argv = (path / "cmdline").read_bytes().split(b"\0")
            if any(str(CACHE).encode() in argument for argument in argv):
                reasons.append("command refers to owned target")
            opened = []
            for fd in (path / "fd").iterdir():
                try:
                    target = fd.resolve(strict=True)
                    if target == CACHE or CACHE in target.parents:
                        opened.append(str(target))
                except OSError:
                    continue
            if opened:
                reasons.append("open descriptors in owned target")
            if reasons and int(path.name) not in excluded:
                owners.append({"pid": int(path.name), "comm": (path / "comm").read_text().strip(),
                    "reasons": reasons, "owned_open_descriptors": opened})
        except (OSError, StopIteration) as error:
            errors[type(error).__name__] = errors.get(type(error).__name__, 0) + 1
    return {"at_utc": now(), "inspected_processes": inspected, "excluded_capture_process_and_ancestors": sorted(excluded),
        "zombies_skipped": zombies, "inspection_errors": errors, "active_owned_processes": owners,
        "limits": "Instantaneous procfs cwd/cmdline/open-fd inspection; races and permissions can hide owners. No filesystem-wide lock or future-writer guarantee. Coordinator confirms the exclusive leaf owner is idle."}


def snapshot():
    assert CACHE.resolve() == CACHE and CACHE.is_dir()
    WORK.mkdir(exist_ok=False)
    processes = process_snapshot()
    assert not processes["active_owned_processes"], processes
    (WORK / "process-before.json").write_text(json.dumps(processes, indent=2) + "\n")
    files, directories, unique = {}, {}, {}
    qualified = {}
    for path in sorted(CACHE.rglob("*")):
        assert not path.is_symlink(), path
        stat = path.stat()
        relative = str(path.relative_to(CACHE))
        identity = (stat.st_dev, stat.st_ino)
        if path.is_dir():
            directories[relative] = {"allocated_bytes": stat.st_blocks * 512}
            continue
        if not path.is_file():
            raise RuntimeError(f"unexpected special cache entry {path}")
        with path.open("rb") as stream:
            magic = stream.read(8)
        artifact = path.suffix in [".rlib", ".rmeta", ".so", ".o", ".a", ".exe"] or magic.startswith(b"\x7fELF")
        keep = not artifact
        is_consumer_elf = magic.startswith(b"\x7fELF") and path.parent.name == "deps" and path.name.startswith("h2_embedded_independent_")
        record = {"bytes": stat.st_size, "allocated_bytes": stat.st_blocks * 512, "device": stat.st_dev,
            "inode": stat.st_ino, "links": stat.st_nlink, "sha256": digest(path),
            "preserved_content": keep or is_consumer_elf,
            "class": "qualified consumer ELF" if is_consumer_elf else "fingerprint/dep/generator/other metadata" if keep else "compiler artifact; hash retained"}
        files[relative] = record
        unique.setdefault(identity, stat)
        if keep:
            target = WORK / "metadata" / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
        if is_consumer_elf:
            target = WORK / "consumer-elves" / path.name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(path, target)
            qualified[relative] = {"preserved": str(target), "sha256": record["sha256"], "bytes": record["bytes"]}
    record = {"cache": str(CACHE), "checkout_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT).decode().strip(),
        "cache_produced_from_topology_source": "604f4c2e5b1e33050bf859a97dc69fb7ae791f3a",
        "scope": "current completed own target only; earlier hash-only reclamation records remain separately bounded",
        "captured_utc": now(), "apparent_sum_bytes": sum(p["bytes"] for p in files.values()),
        "unique_inode_apparent_bytes": sum(p.st_size for p in unique.values()),
        "unique_inode_allocated_bytes": sum(p.st_blocks * 512 for p in unique.values()),
        "directory_allocated_bytes": sum(p["allocated_bytes"] for p in directories.values()),
        "measurement_limits": "Allocated bytes are stat st_blocks, deduplicated by device/inode, not an extent/COW or filesystem quota measurement; concurrent disk changes can affect free-space deltas.",
        "global_free_bytes_before": shutil.disk_usage(ROOT).free,
        "protected": [str(ROOT / "work/h2-embedding/miri-sysroot"), "/workspace/pure-protobuf/work/toolchain", str(ROOT / "docs/evidence/deadline-admission/embedded-topology")],
        "qualified_unit_elf_manifest": "work/h2-embedding/qualified-elves.json",
        "qualified_consumer_elves": qualified, "files": files, "directories": directories}
    (WORK / "cache-before.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({key: record[key] for key in ["apparent_sum_bytes", "unique_inode_apparent_bytes", "unique_inode_allocated_bytes", "global_free_bytes_before"]}, indent=2))


def reclaim():
    record = json.loads((WORK / "cache-before.json").read_text())
    processes = process_snapshot()
    assert not processes["active_owned_processes"], processes
    (WORK / "process-before-reclaim.json").write_text(json.dumps(processes, indent=2) + "\n")
    observed = {str(p.relative_to(CACHE)): p for p in CACHE.rglob("*") if p.is_file()}
    assert observed.keys() == record["files"].keys()
    for relative, path in observed.items():
        assert digest(path) == record["files"][relative]["sha256"], relative
        if record["files"][relative]["preserved_content"]:
            preserved = WORK / "metadata" / relative
            if relative in record["qualified_consumer_elves"]:
                preserved = Path(record["qualified_consumer_elves"][relative]["preserved"])
            assert digest(preserved) == record["files"][relative]["sha256"], relative
    for qualified in json.loads((ROOT / "work/h2-embedding/qualified-elves.json").read_text()).values():
        assert digest(Path(qualified["preserved"])) == qualified["sha256"]
    assert CACHE.resolve() == CACHE
    shutil.rmtree(CACHE)
    after = {"at_utc": now(), "removed_only": str(CACHE), "target_absent": not CACHE.exists(),
        "protected_all_exist": all(Path(p).exists() for p in record["protected"]),
        "global_free_bytes_after": shutil.disk_usage(ROOT).free,
        "qualification_or_source_mutated": False, "new_compilation_run": False}
    assert after["protected_all_exist"]
    (WORK / "reclaim-result.json").write_text(json.dumps(after, indent=2) + "\n")
    print(json.dumps(after, indent=2))


if __name__ == "__main__":
    {"snapshot": snapshot, "reclaim": reclaim}[sys.argv[1]]()
