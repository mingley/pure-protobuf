#!/usr/bin/env python3
"""Seal completed-cache preservation and reclamation separately from qualification."""

import hashlib
import json
from pathlib import Path
import shutil
import tarfile

ROOT = Path(__file__).resolve().parents[2]
WORK = Path(__file__).resolve().parent
CAPTURE = WORK / "cache-cleanup"
OUTPUT = ROOT / "docs/evidence/deadline-admission/embedded-cache-cleanup"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


snapshot = json.loads((CAPTURE / "cache-before.json").read_text())
after = json.loads((CAPTURE / "reclaim-result.json").read_text())
assert after["target_absent"] and after["protected_all_exist"] and not after["new_compilation_run"]
assert not (ROOT / "target").exists()
for rel, pin in snapshot["files"].items():
    if pin["preserved_content"]:
        path = CAPTURE / "metadata" / rel
        if rel in snapshot["qualified_consumer_elves"]:
            path = Path(snapshot["qualified_consumer_elves"][rel]["preserved"])
        assert digest(path) == pin["sha256"], rel
for label, qualified in json.loads((WORK / "qualified-elves.json").read_text()).items():
    assert digest(Path(qualified["preserved"])) == qualified["sha256"]
for label in ["process-before.json", "process-before-reclaim-first.json", "process-before-reclaim.json"]:
    assert not json.loads((CAPTURE / label).read_text())["active_owned_processes"]

for source in [WORK / "cleanup_cache.py", Path(__file__), WORK / "cache-cleanup-snapshot.log", WORK / "cache-cleanup-reclaim.log", WORK / "qualified-elves.json"]:
    shutil.copy2(source, CAPTURE / source.name)
OUTPUT.mkdir(parents=True, exist_ok=False)
archive = OUTPUT / "raw.tar.gz"
with tarfile.open(archive, "w:gz", compresslevel=6) as entries:
    entries.add(CAPTURE, arcname="embedded-cache-cleanup")
pins = {}
with tarfile.open(archive, "r:gz") as entries:
    for entry in entries:
        assert not entry.issym() and not entry.islnk()
        if entry.isfile():
            raw = entries.extractfile(entry).read()
            expected = CAPTURE / Path(entry.name).relative_to("embedded-cache-cleanup")
            actual = hashlib.sha256(raw).hexdigest()
            assert actual == digest(expected), entry.name
            pins[entry.name] = {"bytes": entry.size, "sha256": actual}
(OUTPUT / "members-sha256.json").write_text(json.dumps(pins, indent=2) + "\n")

proof = {"schema": 1, "scope": "only completed owned /workspace/scratch/work/h2-embedded/target cache",
    "cache_produced_from_source": snapshot["cache_produced_from_topology_source"],
    "snapshot_checkout_commit": snapshot["checkout_commit"],
    "source_or_qualification_changed_by_cleanup": False, "new_compilation_run": False,
    "artifact_file_count": len(snapshot["files"]),
    "all_current_cache_artifact_hashes_retained": True,
    "full_content_preserved": "all non-artifact files, including every fingerprint, dependency and generator output; current consumer ELFs also copied",
    "qualified_unit_elves_retained": "separate work copies and immutable topology raw archive8d899c703aabc54ef417a9d08c830f811ca1d15946fe40a2423013dcc8a2c9d6",
    "apparent_sum_bytes_before_metadata_refresh": json.loads((CAPTURE / "cache-before-metadata-refresh.json").read_text())["apparent_sum_bytes"],
    "apparent_sum_bytes": snapshot["apparent_sum_bytes"],
    "unique_inode_apparent_bytes": snapshot["unique_inode_apparent_bytes"],
    "unique_inode_allocated_bytes": snapshot["unique_inode_allocated_bytes"],
    "directory_allocated_bytes": snapshot["directory_allocated_bytes"],
    "measurement_limits": snapshot["measurement_limits"],
    "process_inspection": {"active_owned_processes": [], "permissions_and_races": "instantaneous procfs inspections include2permission-limited entries; no filesystem-wide lock/future-writer guarantee",
        "exclusive_owner": "coordinator confirmed leaf idle; capture process and launch ancestors excluded"},
    "metadata_refresh": snapshot["metadata_refresh"],
    "removed_only": after["removed_only"], "target_absent": True, "protected": snapshot["protected"],
    "protected_all_exist": True, "global_free_bytes_before": snapshot["global_free_bytes_before"],
    "global_free_bytes_after": after["global_free_bytes_after"],
    "previous_reclamations": "earlier completed-cache removals retain all-artifact hashes and phase proof; this capture does not retroactively claim their full fingerprint content was retained",
    "archive": {"file": "raw.tar.gz", "bytes": archive.stat().st_size, "sha256": digest(archive), "regular_members": len(pins), "every_member_verified": True}}
(OUTPUT / "proof.json").write_text(json.dumps(proof, indent=2) + "\n")
print(json.dumps(proof, indent=2))
