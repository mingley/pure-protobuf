use std::{env, fs, path::PathBuf, process::Command};
fn main() {
    let out = PathBuf::from(env::var_os("OUT_DIR").unwrap());
    let candidate = out.join("candidate");
    let baseline = out.join("baseline");
    fs::create_dir_all(&candidate).unwrap();
    fs::create_dir_all(&baseline).unwrap();
    pbrs::codegen::Config::new()
        .out_dir(&candidate)
        .compile_protos(&["proof.proto", "strict.proto", "none.proto"], &["."])
        .unwrap();
    let plugin = env::var("PBRS_BASELINE_PLUGIN").unwrap();
    let status = Command::new("protoc")
        .arg(format!("--plugin=protoc-gen-pbrs={plugin}"))
        .arg(format!(
            "--pbrs_out=include_source_info=false:{}",
            baseline.display()
        ))
        .args(["-I", ".", "proof.proto", "strict.proto", "none.proto"])
        .status()
        .unwrap();
    assert!(status.success());
    println!("cargo:rerun-if-changed=proof.proto");
    println!("cargo:rerun-if-changed=strict.proto");
    println!("cargo:rerun-if-changed=none.proto");
    println!("cargo:rerun-if-env-changed=PBRS_BASELINE_PLUGIN");
}
