use pbrs::Serialize;
use std::alloc::{GlobalAlloc, Layout, System};
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
struct Counting;
static ACTIVE: AtomicBool = AtomicBool::new(false);
static BYTES: AtomicUsize = AtomicUsize::new(0);
static CALLS: AtomicUsize = AtomicUsize::new(0);
unsafe impl GlobalAlloc for Counting {
    unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
        let p = unsafe { System.alloc(layout) };
        if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {
            BYTES.fetch_add(layout.size(), Ordering::Relaxed);
            CALLS.fetch_add(1, Ordering::Relaxed);
        }
        p
    }
    unsafe fn dealloc(&self, p: *mut u8, layout: Layout) {
        unsafe { System.dealloc(p, layout) }
    }
    unsafe fn realloc(&self, p: *mut u8, layout: Layout, size: usize) -> *mut u8 {
        let p = unsafe { System.realloc(p, layout, size) };
        if !p.is_null() && ACTIVE.load(Ordering::Relaxed) {
            BYTES.fetch_add(size, Ordering::Relaxed);
            CALLS.fetch_add(1, Ordering::Relaxed);
        }
        p
    }
}
#[global_allocator]
static ALLOCATOR: Counting = Counting;
fn allocated<T>(f: impl FnOnce() -> T) -> (T, usize, usize) {
    BYTES.store(0, Ordering::Relaxed);
    CALLS.store(0, Ordering::Relaxed);
    ACTIVE.store(true, Ordering::Relaxed);
    let value = f();
    ACTIVE.store(false, Ordering::Relaxed);
    (
        value,
        BYTES.load(Ordering::Relaxed),
        CALLS.load(Ordering::Relaxed),
    )
}
#[allow(dead_code, nonstandard_style, unused_imports)]
mod candidate {
    include!(concat!(env!("OUT_DIR"), "/candidate/proof.rs"));
}
#[allow(dead_code, nonstandard_style, unused_imports)]
mod legacy {
    include!(concat!(env!("OUT_DIR"), "/baseline/proof.rs"));
}

#[allow(dead_code, nonstandard_style, unused_imports)]
mod strict_new {
    include!(concat!(env!("OUT_DIR"), "/candidate/strict.rs"));
}
#[allow(dead_code, nonstandard_style, unused_imports)]
mod strict_old {
    include!(concat!(env!("OUT_DIR"), "/baseline/strict.rs"));
}

#[allow(dead_code, nonstandard_style, unused_imports)]
mod none_new {
    include!(concat!(env!("OUT_DIR"), "/candidate/none.rs"));
}
#[allow(dead_code, nonstandard_style, unused_imports)]
mod none_old {
    include!(concat!(env!("OUT_DIR"), "/baseline/none.rs"));
}
fn compare(bytes: &[u8], group: Option<u32>) {
    let mut old = legacy::Runs::default();
    let mut new = candidate::Runs::default();
    let (mut old_pos, mut new_pos) = (0, 0);
    let old_result = old.merge_inner(bytes, &mut None, &mut old_pos, 0, false, group);
    let new_result = new.merge_inner(bytes, &mut None, &mut new_pos, 0, false, group);
    assert_eq!(
        format!("{old_result:?}"),
        format!("{new_result:?}"),
        "result: {bytes:?}"
    );
    assert_eq!(old_pos, new_pos, "cursor: {bytes:?}");
    assert_eq!(old.serialize(), new.serialize(), "partial state: {bytes:?}");
}
fn main() {
    let prefixes: &[&[u8]] = &[
        &[10, 1, b'a'],
        &[16, 1],
        &[26, 2, 8, 1],
        &[122, 1, b'z'],
        &[130, 1, 1, b'x'],
    ];
    let suffixes: &[&[u8]] = &[
        &[],
        &[10, 1, b'b'],
        &[16, 2],
        &[26, 2, 8, 2],
        &[122, 1, b'y'],
        &[130, 1, 1, b'q'],
        &[32, 1],
        &[48, 7],
        &[8, 3],
        &[138, 0, 1, b'c'],
        &[144, 0, 2],
        &[154, 0, 2, 8, 4],
        &[128],
        &[128, 128, 128, 128, 128, 128, 128, 128, 128, 128, 1],
        &[10, 2, b'x'],
        &[16, 128],
        &[26, 2, 8, 128],
        &[122, 2, b'x'],
        &[44],
        &[52],
    ];
    for prefix in prefixes {
        for suffix in suffixes {
            let bytes = [*prefix, *suffix].concat();
            compare(&bytes, None);
            compare(&bytes, Some(5));
        }
    }
    // Interleaved runs, a nested group with a valid ending, a mismatched
    // ending, and a group truncated after a repeated element.
    for bytes in [
        &[10, 1, b'a', 32, 9, 10, 1, b'b'][..],
        &[43, 10, 1, b'a', 10, 1, b'b', 44][..],
        &[43, 10, 1, b'a', 52][..],
        &[43, 10, 1, b'a'][..],
    ] {
        compare(bytes, None);
    }
    for (label, item) in [
        ("string", &[10, 1, b'a'][..]),
        ("bytes15", &[122, 1, b'z'][..]),
        ("bytes16", &[130, 1, 1, b'x'][..]),
    ] {
        for length in [1, 32, 64, 1024] {
            let bytes = item.repeat(length);
            let (old, ob, oc) = allocated(|| {
                let mut m = legacy::Runs::default();
                m.merge_inner(&bytes, &mut None, &mut 0, 0, false, None)
                    .unwrap();
                m
            });
            let (new, nb, nc) = allocated(|| {
                let mut m = candidate::Runs::default();
                m.merge_inner(&bytes, &mut None, &mut 0, 0, false, None)
                    .unwrap();
                m
            });
            assert_eq!(old.serialize(), new.serialize());
            println!("{label} {length}: old {ob} B/{oc} calls, new {nb} B/{nc} calls");
            if length >= 32 {
                assert_eq!(nc, oc, "long-run calls {label}/{length}");
            }
        }
        let mut bytes = item.to_vec();
        bytes.extend_from_slice(&[58, 128, 128, 4]);
        bytes.resize(bytes.len() + 65536, 0);
        let (old, ob, oc) = allocated(|| {
            let mut m = legacy::Runs::default();
            m.merge_inner(&bytes, &mut None, &mut 0, 0, false, None)
                .unwrap();
            m
        });
        let (new, nb, nc) = allocated(|| {
            let mut m = candidate::Runs::default();
            m.merge_inner(&bytes, &mut None, &mut 0, 0, false, None)
                .unwrap();
            m
        });
        assert_eq!(old.serialize(), new.serialize());
        assert!(ob > nb + 20_000);
        println!("{label} unrelated: old {ob} B/{oc} calls, new {nb} B/{nc} calls");
    }
    // Check strict UTF-8 at both first and later repeated values; errors,
    // cursor and partially committed values must match the baseline.
    for bytes in [
        vec![10, 1, 0xff],
        vec![10, 1, b'a', 10, 1, 0xff],
        vec![10, 1, b'a', 10, 1, 0xff, 10, 1, b'b'],
        vec![10, 1, b'a', 10, 128],
        vec![
            10, 1, b'a', 10, 255, 255, 255, 255, 255, 255, 255, 255, 255, 2,
        ],
    ] {
        let (mut old, mut new) = (strict_old::Runs::default(), strict_new::Runs::default());
        let (mut op, mut np) = (0, 0);
        let a = old.merge_inner(&bytes, &mut None, &mut op, 0, false, None);
        let b = new.merge_inner(&bytes, &mut None, &mut np, 0, false, None);
        assert_eq!(format!("{a:?}"), format!("{b:?}"));
        assert_eq!(op, np);
        assert_eq!(old.serialize(), new.serialize());
    }
    // proto2 and Edition UTF8 NONE accept non-UTF-8 payloads.
    for data in [
        &[10, 1, 0xff][..],
        &[10, 1, b'a', 10, 1, 0xff, 10, 1, b'b'][..],
    ] {
        compare(data, None);
        let (mut old, mut new) = (none_old::Runs::default(), none_new::Runs::default());
        let (mut op, mut np) = (0, 0);
        let a = old.merge_inner(data, &mut None, &mut op, 0, false, None);
        let b = new.merge_inner(data, &mut None, &mut np, 0, false, None);
        assert!(a.is_ok() && b.is_ok());
        assert_eq!(op, np);
        assert_eq!(old.serialize(), new.serialize());
    }
    // A malformed second string followed by a long valid run must not cause
    // a reservation for the unreachable tail.
    let mut bytes = vec![10, 1, b'a', 10, 1, 0xff];
    bytes.extend_from_slice(&[10, 1, b'b'].repeat(24_000));
    let ((old, old_pos, old_result), old_bytes, old_calls) = allocated(|| {
        let mut m = strict_old::Runs::default();
        let mut pos = 0;
        let result = m.merge_inner(&bytes, &mut None, &mut pos, 0, false, None);
        (m, pos, result)
    });
    let ((new, new_pos, new_result), new_bytes, new_calls) = allocated(|| {
        let mut m = strict_new::Runs::default();
        let mut pos = 0;
        let result = m.merge_inner(&bytes, &mut None, &mut pos, 0, false, None);
        (m, pos, result)
    });
    assert!(old_result.is_err() && new_result.is_err());
    assert_eq!(format!("{old_result:?}"), format!("{new_result:?}"));
    assert_eq!(old_pos, new_pos);
    assert_eq!(old.serialize(), new.serialize());
    assert!(old_bytes > new_bytes + 20_000);
    println!(
        "invalid second UTF-8: old {old_bytes} B/{old_calls} calls, new {new_bytes} B/{new_calls} calls"
    );

    // Deterministic differential malformed/overflow/tag mixtures.
    let atoms: &[&[u8]] = &[
        &[10, 1, b'a'],
        &[10, 1, 0xff],
        &[10, 0],
        &[10, 2, b'a'],
        &[10, 128],
        &[10, 255, 255, 255, 255, 255, 255, 255, 255, 255, 2],
        &[122, 0],
        &[122, 1, b'b'],
        &[8, 1],
        &[44],
        &[52],
        &[128],
        &[138, 0, 0],
    ];
    let mut rng = 0x6a09e667f3bcc909u64;
    for _ in 0..3000 {
        let mut data = Vec::new();
        for _ in 0..4 {
            rng ^= rng << 13;
            rng ^= rng >> 7;
            rng ^= rng << 17;
            data.extend_from_slice(atoms[(rng as usize) % atoms.len()]);
        }
        let (mut old, mut new) = (strict_old::Runs::default(), strict_new::Runs::default());
        let (mut op, mut np) = (0, 0);
        let a = old.merge_inner(&data, &mut None, &mut op, 0, false, None);
        let b = new.merge_inner(&data, &mut None, &mut np, 0, false, None);
        assert_eq!(format!("{a:?}"), format!("{b:?}"), "{data:?}");
        assert_eq!(op, np, "{data:?}");
        assert_eq!(old.serialize(), new.serialize(), "{data:?}");
    }
    println!(
        "PASS one-byte and multi-byte repeated runs: values, errors, cursor, partial state and groups"
    );
}
