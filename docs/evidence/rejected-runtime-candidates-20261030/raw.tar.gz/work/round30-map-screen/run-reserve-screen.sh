#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
m=work/all-benchmarks/measurement
for profile in lazy owned; do
 b="$m/round30-reserve-before-$profile";a="$m/round30-reserve-after-$profile"
 python3 work/round30-map-screen/measure-reserve.py --before-shipping "$b/codec-shipping" --before-allocations "$b/codec-allocations" --before-record "$b/source.json" --after-shipping "$a/codec-shipping" --after-allocations "$a/codec-allocations" --after-record "$a/source.json" --output "work/round30-map-screen/reserve-$profile-results" --storage "$profile" --pairs 5 --samples 1
done
