"""Compare every repeated-run fixture without starting benchmark clocks."""
import hashlib,itertools,json,subprocess
from pathlib import Path
root=Path.cwd();m=root/'work/all-benchmarks/measurement';out=root/'work/round30-map-screen/reserve-preflight.json';assert not out.exists();rows=[]
cases=('empty','small','strings_32','strings_64','strings_1024','strings_suffix_64k','numbers_64','numbers_1024','children_64','children_1024','bytes15_64','bytes15_1024','bytes16_64','mixed_64','group_64')
for profile,mode,case,op,backend in itertools.product(('lazy','owned'),('shipping','allocations'),cases,('parse_owned','roundtrip'),('pbrs','prost')):
 signatures=[]
 for side in ('before','after'):
  p=m/f'round30-reserve-{side}-{profile}'/('codec-'+mode);j=json.loads((p.parent/'source.json').read_text()); artifacts=[json.loads(x) for x in (p.parent/(p.name+'.jsonl')).read_text().splitlines()]; built=[x for x in artifacts if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='pbrs-round29-repeated-probe' and x.get('executable')]; assert len(built)==1 and not built[0]['fresh'];assert hashlib.sha256(p.read_bytes()).hexdigest()==j['binaries']['codec-'+mode]['sha256'];command=[str(p),case,backend,op,'0','0'];r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,(command,r.stderr);v=json.loads(r.stdout);assert v['semantic_prechecks'] and not v['samples'] and v['case']==case and v['backend']==backend and v['operation']==op and v['message_storage']==profile;signatures.append([v['wire_bytes'],v['wire_fnv1a64'],v['checksum']])
 assert signatures[0]==signatures[1],(case,signatures);rows.append({'profile':profile,'mode':mode,'case':case,'operation':op,'backend':backend,'fixture':signatures[0]})
out.write_text(json.dumps({'complete':True,'captures':len(rows)*2,'timed_iterations':0,'rows':rows},indent=2)+'\n');print(json.dumps({'complete':True,'captures':len(rows)*2,'timed_iterations':0}))
