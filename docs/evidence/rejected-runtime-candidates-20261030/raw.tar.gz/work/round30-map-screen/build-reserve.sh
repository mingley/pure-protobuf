#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME="$PWD/work/cargo" RUSTUP_HOME="$PWD/work/rustup" PATH="$PWD/work/cargo/bin:$PWD/work/toolchain/protoc/bin:$PATH" CARGO_TARGET_DIR="$PWD/work/bench-target" CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
for side in before after; do
 source=work/all-benchmarks/measurement/round30-map-baseline-source
 if [ "$side" = after ]; then source=work/all-benchmarks/measurement/round30-reserve-source; fi
 for profile in lazy owned; do
  for mode in shipping allocations; do
   python3 -c 'import shutil; n=shutil.disk_usage(".").free; print("free_bytes",n,flush=True); assert n>=750*1024*1024'
   extra=(); if [ "$profile" = owned ]; then extra=(--owned); fi
   touch "work/all-benchmarks/measurement/round30-reserve-$side-harness/src/main.rs" "work/all-benchmarks/measurement/round30-reserve-$side-harness/build.rs"
   python3 work/all-benchmarks/measurement/build_probe.py --source "$source" --manifest "work/all-benchmarks/measurement/round30-reserve-$side-harness/Cargo.toml" --binary-name pbrs-round29-repeated-probe --mode "$mode" --output "work/all-benchmarks/measurement/round30-reserve-$side-$profile" --record-key "codec-$mode" "${extra[@]}"
  done
 done
done
