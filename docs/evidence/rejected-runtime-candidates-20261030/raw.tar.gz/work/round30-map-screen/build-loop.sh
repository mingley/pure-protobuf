#!/usr/bin/env bash
set -euo pipefail
cd /workspace/pure-protobuf
export CARGO_HOME="$PWD/work/cargo" RUSTUP_HOME="$PWD/work/rustup" PATH="$PWD/work/cargo/bin:$PWD/work/toolchain/protoc/bin:$PATH" CARGO_TARGET_DIR="$PWD/work/bench-target" CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0
for kind in baseline pure; do
 python3 -c 'import shutil; f=shutil.disk_usage(".").free; print("free_bytes",f,flush=True); assert f>=750*1024*1024'
 touch "work/all-benchmarks/measurement/round30-map-$kind-loop-harness/src/main.rs"
 python3 work/all-benchmarks/measurement/build_probe.py --source "work/all-benchmarks/measurement/round30-map-$kind-source" --manifest "work/all-benchmarks/measurement/round30-map-$kind-loop-harness/Cargo.toml" --binary-name pbrs-map-iteration-proof --mode shipping --output "work/all-benchmarks/measurement/round30-map-$kind-loop" --record-key codec-shipping
 done
