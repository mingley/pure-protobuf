import hashlib,json,shutil,subprocess
from pathlib import Path
root=Path.cwd(); m=root/'work/all-benchmarks/measurement'; old=m/'round29-integrated-source'; old_manifest=json.loads((m/'round29-integrated-source-source.json').read_text())['files']; head=subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip();assert head=='15e738499f0dc937b0e54fd4325271b75ba7e5f4'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=m/'round30-map-baseline-source'; cand=m/'round30-map-pure-source'; assert not base.exists() and not cand.exists();shutil.copytree(old,base)
for p in old_manifest:
 data=subprocess.check_output(['git','show',head+':'+p]); f=base/p; f.write_bytes(data);assert f.read_bytes()==data
shutil.copytree(base,cand);shutil.copyfile(root/'work/round30-map/map.rs',cand/'src/map.rs')
for source in (base,cand):
 files={str(f.relative_to(source)):sha(f) for f in source.rglob('*') if f.is_file()};assert set(files)==set(old_manifest)
 rec={'head':head,'source':str(source),'files':files,'map_candidate':source==cand}; (m/(source.name+'-source.json')).write_text(json.dumps(rec,indent=2)+'\n')
print('source hashes',sha(base/'src/map.rs'),sha(cand/'src/map.rs'))
for label,source in [('baseline',base),('pure',cand)]:
 h=m/('round30-map-'+label+'-loop-harness');shutil.copytree(root/'work/benchmark-followup/map-loop-template',h);shutil.copyfile(m/'map-candidate-harness/Cargo.lock',h/'Cargo.lock');p=h/'Cargo.toml';s=p.read_text();assert s.count('FROZEN_CORE')==1;p.write_text(s.replace('FROZEN_CORE',str(source)));assert (h/'src/main.rs').read_bytes()==(m/'round-loop-before-harness/src/main.rs').read_bytes()
