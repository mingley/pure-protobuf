"""Matched prescan-screen workloads; omitted rows remain unmeasured."""
import sys
from pathlib import Path
sys.path.insert(0,str(Path('work/all-benchmarks/measurement').resolve()))
import codec_compare
codec_compare.CASES={'small':50_000,'strings_32':4_000,'strings_64':2_500,'strings_1024':120,'strings_suffix_64k':100,'bytes15_64':2_500,'bytes15_1024':120,'bytes16_64':2_500,'mixed_64':2_500,'numbers_64':2_500,'children_64':2_500}
codec_compare.OPS=('parse_owned','roundtrip')
codec_compare.FIXTURE_SCOPE='Focused repeated strings and bytes; unrelated suffix, mixed, scalar and child holdouts; parse/drop and parse/serialize/drop.'
codec_compare.main()
