
work/all-benchmarks/measurement/round30-map-baseline-loop/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002d900 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_>:
   2d900:	55                   	push   %rbp
   2d901:	41 57                	push   %r15
   2d903:	41 56                	push   %r14
   2d905:	41 55                	push   %r13
   2d907:	41 54                	push   %r12
   2d909:	53                   	push   %rbx
   2d90a:	48 83 ec 78          	sub    $0x78,%rsp
   2d90e:	48 8b 07             	mov    (%rdi),%rax
   2d911:	48 8b 00             	mov    (%rax),%rax
   2d914:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2d919:	75 10                	jne    2d92b <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x2b>
   2d91b:	48 8b 40 08          	mov    0x8(%rax),%rax
   2d91f:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2d925:	0f 84 4b 03 00 00    	je     2dc76 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2d92b:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2d92f:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2d934:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2d939:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2d93d:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2d941:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2d945:	48 83 f9 04          	cmp    $0x4,%rcx
   2d949:	0f 87 60 0b 00 00    	ja     2e4af <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2d94f:	48 8b 40 08          	mov    0x8(%rax),%rax
   2d953:	48 8d 15 d6 b8 fd ff 	lea    -0x2472a(%rip),%rdx        # 9230 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2d95a:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2d95e:	48 01 d1             	add    %rdx,%rcx
   2d961:	ff e1                	jmp    *%rcx
   2d963:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2d96a:	61 6c 6c 
   2d96d:	48 39 08             	cmp    %rcx,(%rax)
   2d970:	0f 85 39 0b 00 00    	jne    2e4af <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2d976:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   2d97b:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2d97f:	48 85 c0             	test   %rax,%rax
   2d982:	0f 84 2a 03 00 00    	je     2dcb2 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2d988:	48 8b 09             	mov    (%rcx),%rcx
   2d98b:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2d98f:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2d993:	f7 d7                	not    %edi
   2d995:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2d999:	31 d2                	xor    %edx,%edx
   2d99b:	eb 36                	jmp    2d9d3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2d99d:	0f 1f 00             	nopl   (%rax)
   2d9a0:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2d9a4:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2d9a9:	41 21 f8             	and    %edi,%r8d
   2d9ac:	41 c1 e1 03          	shl    $0x3,%r9d
   2d9b0:	48 89 cf             	mov    %rcx,%rdi
   2d9b3:	4c 29 cf             	sub    %r9,%rdi
   2d9b6:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2d9ba:	49 89 d2             	mov    %rdx,%r10
   2d9bd:	4d 01 ca             	add    %r9,%r10
   2d9c0:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2d9c4:	4c 01 d2             	add    %r10,%rdx
   2d9c7:	44 89 c7             	mov    %r8d,%edi
   2d9ca:	48 ff c8             	dec    %rax
   2d9cd:	0f 84 e1 02 00 00    	je     2dcb4 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2d9d3:	66 85 ff             	test   %di,%di
   2d9d6:	75 c8                	jne    2d9a0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2d9d8:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2d9df:	00 
   2d9e0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2d9e4:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2d9e8:	48 83 c6 10          	add    $0x10,%rsi
   2d9ec:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2d9f0:	66 83 f7 ff          	xor    $0xffff,%di
   2d9f4:	74 ea                	je     2d9e0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2d9f6:	eb a8                	jmp    2d9a0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2d9f8:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2d9ff:	66 69 72 
   2da02:	48 33 08             	xor    (%rax),%rcx
   2da05:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2da09:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2da0f:	48 09 c8             	or     %rcx,%rax
   2da12:	0f 85 97 0a 00 00    	jne    2e4af <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2da18:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2da1d:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2da22:	0f 84 77 02 00 00    	je     2dc9f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2da28:	48 8b 00             	mov    (%rax),%rax
   2da2b:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2da2f:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2da33:	66 83 f1 ff          	xor    $0xffff,%cx
   2da37:	75 1d                	jne    2da56 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2da39:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2da3d:	0f 1f 00             	nopl   (%rax)
   2da40:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2da44:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2da48:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2da4c:	48 83 c2 10          	add    $0x10,%rdx
   2da50:	66 83 f1 ff          	xor    $0xffff,%cx
   2da54:	74 ea                	je     2da40 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2da56:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2da5a:	c1 e1 03             	shl    $0x3,%ecx
   2da5d:	48 29 c8             	sub    %rcx,%rax
   2da60:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2da64:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2da68:	e9 34 02 00 00       	jmp    2dca1 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2da6d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2da74:	72 65 61 
   2da77:	48 33 08             	xor    (%rax),%rcx
   2da7a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2da7e:	48 83 f0 64          	xor    $0x64,%rax
   2da82:	48 09 c8             	or     %rcx,%rax
   2da85:	0f 85 24 0a 00 00    	jne    2e4af <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2da8b:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2da92:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2da97:	0f 85 2b 0a 00 00    	jne    2e4c8 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbc8>
   2da9d:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2daa1:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2daa6:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2daaa:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2daae:	0f 10 05 8b 28 04 00 	movups 0x4288b(%rip),%xmm0        # 70340 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4e0>
   2dab5:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2dab9:	f3 0f 6f 05 8f 28 04 	movdqu 0x4288f(%rip),%xmm0        # 70350 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f0>
   2dac0:	00 
   2dac1:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2dac7:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2dacc:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2dad1:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2dad5:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2dada:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2dadf:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2dae4:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dae8:	48 85 c9             	test   %rcx,%rcx
   2daeb:	0f 84 cf 01 00 00    	je     2dcc0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2daf1:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2daf5:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2daf9:	48 89 e3             	mov    %rsp,%rbx
   2dafc:	0f 1f 40 00          	nopl   0x0(%rax)
   2db00:	41 8b 36             	mov    (%r14),%esi
   2db03:	41 8b 56 04          	mov    0x4(%r14),%edx
   2db07:	48 89 df             	mov    %rbx,%rdi
   2db0a:	e8 41 60 00 00       	call   33b50 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2db0f:	49 83 c6 08          	add    $0x8,%r14
   2db13:	4d 39 fe             	cmp    %r15,%r14
   2db16:	75 e8                	jne    2db00 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2db18:	48 8b 3c 24          	mov    (%rsp),%rdi
   2db1c:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2db21:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2db26:	48 85 c9             	test   %rcx,%rcx
   2db29:	0f 84 86 03 00 00    	je     2deb5 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x5b5>
   2db2f:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2db33:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2db38:	41 f7 d1             	not    %r9d
   2db3b:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2db3f:	31 d2                	xor    %edx,%edx
   2db41:	49 89 f8             	mov    %rdi,%r8
   2db44:	eb 3d                	jmp    2db83 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2db46:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2db4d:	00 00 00 
   2db50:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2db54:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2db59:	45 21 ca             	and    %r9d,%r10d
   2db5c:	41 c1 e3 03          	shl    $0x3,%r11d
   2db60:	4d 89 c1             	mov    %r8,%r9
   2db63:	4d 29 d9             	sub    %r11,%r9
   2db66:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2db6a:	48 89 d3             	mov    %rdx,%rbx
   2db6d:	4c 01 db             	add    %r11,%rbx
   2db70:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2db74:	48 01 da             	add    %rbx,%rdx
   2db77:	45 89 d1             	mov    %r10d,%r9d
   2db7a:	48 ff c9             	dec    %rcx
   2db7d:	0f 84 34 03 00 00    	je     2deb7 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x5b7>
   2db83:	66 45 85 c9          	test   %r9w,%r9w
   2db87:	75 c7                	jne    2db50 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2db89:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2db90:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2db94:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2db98:	48 83 c6 10          	add    $0x10,%rsi
   2db9c:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2dba1:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2dba6:	74 e8                	je     2db90 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2dba8:	eb a6                	jmp    2db50 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2dbaa:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2dbb1:	63 6f 6c 
   2dbb4:	48 33 08             	xor    (%rax),%rcx
   2dbb7:	8b 40 08             	mov    0x8(%rax),%eax
   2dbba:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2dbc0:	48 09 c8             	or     %rcx,%rax
   2dbc3:	0f 85 e6 08 00 00    	jne    2e4af <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbaf>
   2dbc9:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2dbce:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2dbd2:	48 85 c9             	test   %rcx,%rcx
   2dbd5:	0f 84 f8 00 00 00    	je     2dcd3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2dbdb:	4c 8b 28             	mov    (%rax),%r13
   2dbde:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2dbe4:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dbe9:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2dbed:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dbf2:	75 25                	jne    2dc19 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2dbf4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2dbfb:	00 00 00 00 00 
   2dc00:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2dc05:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2dc09:	48 83 c5 10          	add    $0x10,%rbp
   2dc0d:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2dc12:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2dc17:	74 e7                	je     2dc00 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2dc19:	48 83 f9 05          	cmp    $0x5,%rcx
   2dc1d:	bb 04 00 00 00       	mov    $0x4,%ebx
   2dc22:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2dc28:	4c 0f 43 f9          	cmovae %rcx,%r15
   2dc2c:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2dc33:	00 
   2dc34:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2dc3b:	ff ff 1f 
   2dc3e:	48 ff c0             	inc    %rax
   2dc41:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2dc46:	48 39 c1             	cmp    %rax,%rcx
   2dc49:	0f 97 c0             	seta   %al
   2dc4c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2dc53:	ff ff 7f 
   2dc56:	48 83 c1 0b          	add    $0xb,%rcx
   2dc5a:	49 39 ce             	cmp    %rcx,%r14
   2dc5d:	0f 97 c1             	seta   %cl
   2dc60:	08 c1                	or     %al,%cl
   2dc62:	0f 84 47 01 00 00    	je     2ddaf <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x4af>
   2dc68:	31 db                	xor    %ebx,%ebx
   2dc6a:	48 89 df             	mov    %rbx,%rdi
   2dc6d:	4c 89 f6             	mov    %r14,%rsi
   2dc70:	ff 15 22 43 04 00    	call   *0x44322(%rip)        # 71f98 <_DYNAMIC+0x230>
   2dc76:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2dc7a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2dc7f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   2dc84:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2dc89:	4c 8b 38             	mov    (%rax),%r15
   2dc8c:	4d 85 ff             	test   %r15,%r15
   2dc8f:	74 4f                	je     2dce0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2dc91:	4d 8b 77 08          	mov    0x8(%r15),%r14
   2dc95:	49 8b 5f 10          	mov    0x10(%r15),%rbx
   2dc99:	49 83 c7 18          	add    $0x18,%r15
   2dc9d:	eb 47                	jmp    2dce6 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x3e6>
   2dc9f:	31 c9                	xor    %ecx,%ecx
   2dca1:	48 89 0c 24          	mov    %rcx,(%rsp)
   2dca5:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2dcaa:	48 89 e0             	mov    %rsp,%rax
   2dcad:	e9 da 09 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dcb2:	31 d2                	xor    %edx,%edx
   2dcb4:	48 89 14 24          	mov    %rdx,(%rsp)
   2dcb8:	48 89 e0             	mov    %rsp,%rax
   2dcbb:	e9 cc 09 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dcc0:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2dcc7:	00 00 
   2dcc9:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2dcce:	e9 b9 09 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dcd3:	b8 04 00 00 00       	mov    $0x4,%eax
   2dcd8:	45 31 ff             	xor    %r15d,%r15d
   2dcdb:	e9 61 04 00 00       	jmp    2e141 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2dce0:	45 31 ff             	xor    %r15d,%r15d
   2dce3:	45 31 f6             	xor    %r14d,%r14d
   2dce6:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2dcea:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dcee:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2dcf2:	48 83 f9 04          	cmp    $0x4,%rcx
   2dcf6:	0f 87 e7 07 00 00    	ja     2e4e3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2dcfc:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dd00:	48 8d 15 3d b5 fd ff 	lea    -0x24ac3(%rip),%rdx        # 9244 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2dd07:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2dd0b:	48 01 d1             	add    %rdx,%rcx
   2dd0e:	ff e1                	jmp    *%rcx
   2dd10:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2dd17:	61 6c 6c 
   2dd1a:	48 39 08             	cmp    %rcx,(%rax)
   2dd1d:	0f 85 c0 07 00 00    	jne    2e4e3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2dd23:	4d 85 f6             	test   %r14,%r14
   2dd26:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2dd2c:	4d 0f 45 e6          	cmovne %r14,%r12
   2dd30:	31 c0                	xor    %eax,%eax
   2dd32:	48 85 db             	test   %rbx,%rbx
   2dd35:	0f 84 4a 09 00 00    	je     2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd3b:	4d 85 f6             	test   %r14,%r14
   2dd3e:	0f 84 41 09 00 00    	je     2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd44:	48 83 fb 10          	cmp    $0x10,%rbx
   2dd48:	0f 92 c0             	setb   %al
   2dd4b:	4d 85 ff             	test   %r15,%r15
   2dd4e:	0f 94 c1             	sete   %cl
   2dd51:	08 c1                	or     %al,%cl
   2dd53:	0f 84 74 04 00 00    	je     2e1cd <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8cd>
   2dd59:	49 8d 0c de          	lea    (%r14,%rbx,8),%rcx
   2dd5d:	31 c0                	xor    %eax,%eax
   2dd5f:	31 d2                	xor    %edx,%edx
   2dd61:	eb 18                	jmp    2dd7b <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x47b>
   2dd63:	49 63 34 f4          	movslq (%r12,%rsi,8),%rsi
   2dd67:	49 63 7c d4 fc       	movslq -0x4(%r12,%rdx,8),%rdi
   2dd6c:	48 01 f0             	add    %rsi,%rax
   2dd6f:	48 01 f8             	add    %rdi,%rax
   2dd72:	48 39 da             	cmp    %rbx,%rdx
   2dd75:	0f 83 0a 09 00 00    	jae    2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2dd7b:	48 89 d6             	mov    %rdx,%rsi
   2dd7e:	48 8d 56 01          	lea    0x1(%rsi),%rdx
   2dd82:	49 8d 3c f4          	lea    (%r12,%rsi,8),%rdi
   2dd86:	48 83 c7 08          	add    $0x8,%rdi
   2dd8a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2dd90:	48 39 cf             	cmp    %rcx,%rdi
   2dd93:	74 ce                	je     2dd63 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x463>
   2dd95:	44 8b 07             	mov    (%rdi),%r8d
   2dd98:	48 83 c7 08          	add    $0x8,%rdi
   2dd9c:	45 3b 04 f4          	cmp    (%r12,%rsi,8),%r8d
   2dda0:	75 ee                	jne    2dd90 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x490>
   2dda2:	48 89 d6             	mov    %rdx,%rsi
   2dda5:	48 39 da             	cmp    %rbx,%rdx
   2dda8:	75 d4                	jne    2dd7e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x47e>
   2ddaa:	e9 d6 08 00 00       	jmp    2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2ddaf:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2ddb4:	c1 e0 03             	shl    $0x3,%eax
   2ddb7:	4c 89 e9             	mov    %r13,%rcx
   2ddba:	48 29 c1             	sub    %rax,%rcx
   2ddbd:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2ddc2:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   2ddc8:	4c 89 f7             	mov    %r14,%rdi
   2ddcb:	ff 15 7f 41 04 00    	call   *0x4417f(%rip)        # 71f50 <malloc@GLIBC_2.2.5>
   2ddd1:	48 85 c0             	test   %rax,%rax
   2ddd4:	0f 84 90 fe ff ff    	je     2dc6a <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2ddda:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2dddf:	48 89 cb             	mov    %rcx,%rbx
   2dde2:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2dde8:	66 0f d6 00          	movq   %xmm0,(%rax)
   2ddec:	4c 89 3c 24          	mov    %r15,(%rsp)
   2ddf0:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2ddf5:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2ddfc:	00 00 
   2ddfe:	48 ff cb             	dec    %rbx
   2de01:	0f 84 3a 03 00 00    	je     2e141 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2de07:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2de0c:	45 21 e7             	and    %r12d,%r15d
   2de0f:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2de15:	49 89 e4             	mov    %rsp,%r12
   2de18:	eb 35                	jmp    2de4f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x54f>
   2de1a:	66 0f 1f 44 00 00    	nopw   0x0(%rax,%rax,1)
   2de20:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2de25:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2de29:	44 21 f9             	and    %r15d,%ecx
   2de2c:	48 ff cb             	dec    %rbx
   2de2f:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2de35:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2de3b:	49 ff c6             	inc    %r14
   2de3e:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2de43:	41 89 cf             	mov    %ecx,%r15d
   2de46:	48 85 db             	test   %rbx,%rbx
   2de49:	0f 84 e4 02 00 00    	je     2e133 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x833>
   2de4f:	66 45 85 ff          	test   %r15w,%r15w
   2de53:	75 24                	jne    2de79 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x579>
   2de55:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2de5c:	00 00 00 00 
   2de60:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2de65:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2de69:	48 83 c5 10          	add    $0x10,%rbp
   2de6d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2de72:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2de77:	74 e7                	je     2de60 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x560>
   2de79:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2de7e:	c1 e1 03             	shl    $0x3,%ecx
   2de81:	4c 89 ea             	mov    %r13,%rdx
   2de84:	48 29 ca             	sub    %rcx,%rdx
   2de87:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2de8c:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2de91:	4c 3b 34 24          	cmp    (%rsp),%r14
   2de95:	75 8e                	jne    2de25 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x525>
   2de97:	b9 04 00 00 00       	mov    $0x4,%ecx
   2de9c:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2dea2:	4c 89 e7             	mov    %r12,%rdi
   2dea5:	4c 89 f6             	mov    %r14,%rsi
   2dea8:	48 89 da             	mov    %rbx,%rdx
   2deab:	e8 d0 ec ff ff       	call   2cb80 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2deb0:	e9 6b ff ff ff       	jmp    2de20 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x520>
   2deb5:	31 d2                	xor    %edx,%edx
   2deb7:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   2debc:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
   2dec1:	48 85 c0             	test   %rax,%rax
   2dec4:	0f 84 c2 07 00 00    	je     2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2deca:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2ded1:	00 
   2ded2:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2ded6:	48 01 c8             	add    %rcx,%rax
   2ded9:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2dedd:	0f 84 a9 07 00 00    	je     2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2dee3:	48 29 cf             	sub    %rcx,%rdi
   2dee6:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2deea:	ff 15 70 40 04 00    	call   *0x44070(%rip)        # 71f60 <free@GLIBC_2.2.5>
   2def0:	e9 97 07 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2def5:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2defc:	66 69 72 
   2deff:	48 33 08             	xor    (%rax),%rcx
   2df02:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2df06:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2df0c:	48 09 c8             	or     %rcx,%rax
   2df0f:	0f 85 ce 05 00 00    	jne    2e4e3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2df15:	4d 85 f6             	test   %r14,%r14
   2df18:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2df1e:	4d 0f 45 e6          	cmovne %r14,%r12
   2df22:	31 ed                	xor    %ebp,%ebp
   2df24:	48 85 db             	test   %rbx,%rbx
   2df27:	0f 84 9e 02 00 00    	je     2e1cb <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2df2d:	4d 85 f6             	test   %r14,%r14
   2df30:	0f 84 95 02 00 00    	je     2e1cb <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2df36:	48 83 fb 10          	cmp    $0x10,%rbx
   2df3a:	0f 92 c0             	setb   %al
   2df3d:	4d 85 ff             	test   %r15,%r15
   2df40:	0f 94 c1             	sete   %cl
   2df43:	08 c1                	or     %al,%cl
   2df45:	0f 84 37 02 00 00    	je     2e182 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x882>
   2df4b:	49 8d 04 de          	lea    (%r14,%rbx,8),%rax
   2df4f:	31 c9                	xor    %ecx,%ecx
   2df51:	49 8d 14 cc          	lea    (%r12,%rcx,8),%rdx
   2df55:	49 8d 34 cc          	lea    (%r12,%rcx,8),%rsi
   2df59:	48 83 c6 08          	add    $0x8,%rsi
   2df5d:	48 ff c1             	inc    %rcx
   2df60:	48 39 c6             	cmp    %rax,%rsi
   2df63:	0f 84 90 02 00 00    	je     2e1f9 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8f9>
   2df69:	8b 3e                	mov    (%rsi),%edi
   2df6b:	48 83 c6 08          	add    $0x8,%rsi
   2df6f:	3b 3a                	cmp    (%rdx),%edi
   2df71:	75 ed                	jne    2df60 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x660>
   2df73:	31 ed                	xor    %ebp,%ebp
   2df75:	48 39 d9             	cmp    %rbx,%rcx
   2df78:	75 d7                	jne    2df51 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x651>
   2df7a:	e9 88 02 00 00       	jmp    2e207 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2df7f:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2df86:	72 65 61 
   2df89:	48 33 08             	xor    (%rax),%rcx
   2df8c:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2df90:	48 83 f0 64          	xor    $0x64,%rax
   2df94:	48 09 c8             	or     %rcx,%rax
   2df97:	0f 85 46 05 00 00    	jne    2e4e3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2df9d:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2dfa4:	00 00 
   2dfa6:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2dfaa:	48 89 04 24          	mov    %rax,(%rsp)
   2dfae:	48 89 e0             	mov    %rsp,%rax
   2dfb1:	48 8b 04 24          	mov    (%rsp),%rax
   2dfb5:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2dfb9:	48 85 c9             	test   %rcx,%rcx
   2dfbc:	0f 84 ab 01 00 00    	je     2e16d <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2dfc2:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2dfc6:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2dfca:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2dfcf:	90                   	nop
   2dfd0:	41 8b 36             	mov    (%r14),%esi
   2dfd3:	41 8b 56 04          	mov    0x4(%r14),%edx
   2dfd7:	48 89 df             	mov    %rbx,%rdi
   2dfda:	e8 d1 70 00 00       	call   350b0 <_RNvMso_NtCsl9Y7oDXyMto_4pbrs3mapINtB5_3MapllE10push_entryCsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2dfdf:	49 83 c6 08          	add    $0x8,%r14
   2dfe3:	4d 39 fe             	cmp    %r15,%r14
   2dfe6:	75 e8                	jne    2dfd0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x6d0>
   2dfe8:	48 8b 7c 24 38       	mov    0x38(%rsp),%rdi
   2dfed:	48 85 ff             	test   %rdi,%rdi
   2dff0:	0f 84 77 01 00 00    	je     2e16d <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2dff6:	48 8b 5f 10          	mov    0x10(%rdi),%rbx
   2dffa:	48 85 db             	test   %rbx,%rbx
   2dffd:	0f 84 6c 01 00 00    	je     2e16f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x86f>
   2e003:	4c 8b 77 08          	mov    0x8(%rdi),%r14
   2e007:	48 83 fb 10          	cmp    $0x10,%rbx
   2e00b:	0f 83 07 02 00 00    	jae    2e218 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x918>
   2e011:	49 8d 4e 08          	lea    0x8(%r14),%rcx
   2e015:	48 8d 14 dd f8 ff ff 	lea    -0x8(,%rbx,8),%rdx
   2e01c:	ff 
   2e01d:	31 c0                	xor    %eax,%eax
   2e01f:	31 f6                	xor    %esi,%esi
   2e021:	eb 1b                	jmp    2e03e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x73e>
   2e023:	4f 63 04 d6          	movslq (%r14,%r10,8),%r8
   2e027:	49 89 c1             	mov    %rax,%r9
   2e02a:	4d 01 c1             	add    %r8,%r9
   2e02d:	49 63 44 f6 fc       	movslq -0x4(%r14,%rsi,8),%rax
   2e032:	4c 01 c8             	add    %r9,%rax
   2e035:	48 39 de             	cmp    %rbx,%rsi
   2e038:	0f 83 33 01 00 00    	jae    2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e03e:	4c 8d 0c f5 00 00 00 	lea    0x0(,%rsi,8),%r9
   2e045:	00 
   2e046:	49 89 d0             	mov    %rdx,%r8
   2e049:	4d 29 c8             	sub    %r9,%r8
   2e04c:	4c 8d 0c f1          	lea    (%rcx,%rsi,8),%r9
   2e050:	49 89 f2             	mov    %rsi,%r10
   2e053:	48 ff c6             	inc    %rsi
   2e056:	48 39 de             	cmp    %rbx,%rsi
   2e059:	74 c8                	je     2e023 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e05b:	47 8b 1c d6          	mov    (%r14,%r10,8),%r11d
   2e05f:	45 31 ff             	xor    %r15d,%r15d
   2e062:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e069:	1f 84 00 00 00 00 00 
   2e070:	47 39 1c 39          	cmp    %r11d,(%r9,%r15,1)
   2e074:	74 0b                	je     2e081 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x781>
   2e076:	49 83 c7 08          	add    $0x8,%r15
   2e07a:	4d 39 f8             	cmp    %r15,%r8
   2e07d:	75 f1                	jne    2e070 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x770>
   2e07f:	eb a2                	jmp    2e023 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e081:	49 83 c1 08          	add    $0x8,%r9
   2e085:	49 83 c0 f8          	add    $0xfffffffffffffff8,%r8
   2e089:	49 89 f2             	mov    %rsi,%r10
   2e08c:	48 ff c6             	inc    %rsi
   2e08f:	48 39 de             	cmp    %rbx,%rsi
   2e092:	75 c7                	jne    2e05b <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x75b>
   2e094:	eb 8d                	jmp    2e023 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e096:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e09d:	63 6f 6c 
   2e0a0:	48 33 08             	xor    (%rax),%rcx
   2e0a3:	8b 40 08             	mov    0x8(%rax),%eax
   2e0a6:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e0ac:	48 09 c8             	or     %rcx,%rax
   2e0af:	0f 85 2e 04 00 00    	jne    2e4e3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbe3>
   2e0b5:	4d 85 f6             	test   %r14,%r14
   2e0b8:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2e0be:	4d 0f 45 e6          	cmovne %r14,%r12
   2e0c2:	49 0f 44 de          	cmove  %r14,%rbx
   2e0c6:	31 c0                	xor    %eax,%eax
   2e0c8:	48 85 db             	test   %rbx,%rbx
   2e0cb:	74 1a                	je     2e0e7 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0cd:	4d 85 ff             	test   %r15,%r15
   2e0d0:	74 15                	je     2e0e7 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0d2:	48 83 fb 10          	cmp    $0x10,%rbx
   2e0d6:	72 0f                	jb     2e0e7 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e0d8:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e0dc:	85 c0                	test   %eax,%eax
   2e0de:	0f 85 18 04 00 00    	jne    2e4fc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xbfc>
   2e0e4:	4c 89 f8             	mov    %r15,%rax
   2e0e7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e0ee:	00 
   2e0ef:	4c 89 64 24 08       	mov    %r12,0x8(%rsp)
   2e0f4:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e0f9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e0fe:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e105:	00 00 
   2e107:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2e10c:	48 89 e6             	mov    %rsp,%rsi
   2e10f:	48 89 df             	mov    %rbx,%rdi
   2e112:	e8 39 74 00 00       	call   35550 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCsl9Y7oDXyMto_4pbrs3map11MapViewIterllEE9from_iterCsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e117:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   2e11d:	0f 84 69 05 00 00    	je     2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e123:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   2e128:	ff 15 32 3e 04 00    	call   *0x43e32(%rip)        # 71f60 <free@GLIBC_2.2.5>
   2e12e:	e9 59 05 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e133:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e137:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e13c:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e141:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e145:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e14a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e14f:	48 89 e0             	mov    %rsp,%rax
   2e152:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e157:	0f 84 2f 05 00 00    	je     2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e15d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e162:	ff 15 f8 3d 04 00    	call   *0x43df8(%rip)        # 71f60 <free@GLIBC_2.2.5>
   2e168:	e9 1f 05 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e16d:	31 ff                	xor    %edi,%edi
   2e16f:	31 c0                	xor    %eax,%eax
   2e171:	48 89 04 24          	mov    %rax,(%rsp)
   2e175:	48 89 e0             	mov    %rsp,%rax
   2e178:	e8 c3 be ff ff       	call   2a040 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl9Y7oDXyMto_4pbrs3map3MapllEECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e17d:	e9 0a 05 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e182:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e186:	85 c0                	test   %eax,%eax
   2e188:	0f 85 81 03 00 00    	jne    2e50f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc0f>
   2e18e:	49 8b 57 10          	mov    0x10(%r15),%rdx
   2e192:	48 39 da             	cmp    %rbx,%rdx
   2e195:	74 65                	je     2e1fc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e197:	48 85 d2             	test   %rdx,%rdx
   2e19a:	74 2f                	je     2e1cb <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8cb>
   2e19c:	49 8b 4f 08          	mov    0x8(%r15),%rcx
   2e1a0:	48 83 fa 01          	cmp    $0x1,%rdx
   2e1a4:	0f 85 a0 02 00 00    	jne    2e44a <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb4a>
   2e1aa:	8b 11                	mov    (%rcx),%edx
   2e1ac:	31 c0                	xor    %eax,%eax
   2e1ae:	eb 0a                	jmp    2e1ba <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8ba>
   2e1b0:	48 ff c0             	inc    %rax
   2e1b3:	31 ed                	xor    %ebp,%ebp
   2e1b5:	48 39 c3             	cmp    %rax,%rbx
   2e1b8:	74 4d                	je     2e207 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e1ba:	41 3b 14 c4          	cmp    (%r12,%rax,8),%edx
   2e1be:	75 f0                	jne    2e1b0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e1c0:	48 3b 41 08          	cmp    0x8(%rcx),%rax
   2e1c4:	75 ea                	jne    2e1b0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8b0>
   2e1c6:	e9 db 02 00 00       	jmp    2e4a6 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xba6>
   2e1cb:	eb 3a                	jmp    2e207 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e1cd:	41 8b 47 18          	mov    0x18(%r15),%eax
   2e1d1:	85 c0                	test   %eax,%eax
   2e1d3:	0f 85 56 03 00 00    	jne    2e52f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc2f>
   2e1d9:	49 8b 4f 10          	mov    0x10(%r15),%rcx
   2e1dd:	48 39 d9             	cmp    %rbx,%rcx
   2e1e0:	0f 85 64 03 00 00    	jne    2e54a <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc4a>
   2e1e6:	48 83 fb 04          	cmp    $0x4,%rbx
   2e1ea:	0f 83 03 01 00 00    	jae    2e2f3 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x9f3>
   2e1f0:	31 c0                	xor    %eax,%eax
   2e1f2:	31 c9                	xor    %ecx,%ecx
   2e1f4:	e9 75 04 00 00       	jmp    2e66e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd6e>
   2e1f9:	49 89 d4             	mov    %rdx,%r12
   2e1fc:	f3 41 0f 7e 04 24    	movq   (%r12),%xmm0
   2e202:	bd 01 00 00 00       	mov    $0x1,%ebp
   2e207:	89 2c 24             	mov    %ebp,(%rsp)
   2e20a:	66 0f d6 44 24 04    	movq   %xmm0,0x4(%rsp)
   2e210:	48 89 e0             	mov    %rsp,%rax
   2e213:	e9 74 04 00 00       	jmp    2e68c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd8c>
   2e218:	49 89 ff             	mov    %rdi,%r15
   2e21b:	8b 47 30             	mov    0x30(%rdi),%eax
   2e21e:	85 c0                	test   %eax,%eax
   2e220:	0f 85 db 03 00 00    	jne    2e601 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd01>
   2e226:	4c 89 ff             	mov    %r15,%rdi
   2e229:	49 8b 4f 28          	mov    0x28(%r15),%rcx
   2e22d:	48 39 d9             	cmp    %rbx,%rcx
   2e230:	0f 85 57 01 00 00    	jne    2e38d <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xa8d>
   2e236:	48 89 d9             	mov    %rbx,%rcx
   2e239:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
   2e23d:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e241:	31 c0                	xor    %eax,%eax
   2e243:	66 0f ef c9          	pxor   %xmm1,%xmm1
   2e247:	f3 41 0f 6f 14 c6    	movdqu (%r14,%rax,8),%xmm2
   2e24d:	f3 41 0f 6f 5c c6 10 	movdqu 0x10(%r14,%rax,8),%xmm3
   2e254:	66 0f 70 e2 e8       	pshufd $0xe8,%xmm2,%xmm4
   2e259:	66 0f 6f e8          	movdqa %xmm0,%xmm5
   2e25d:	66 0f 70 c2 ed       	pshufd $0xed,%xmm2,%xmm0
   2e262:	66 0f 70 d3 e8       	pshufd $0xe8,%xmm3,%xmm2
   2e267:	66 0f 6f f1          	movdqa %xmm1,%xmm6
   2e26b:	66 0f 70 cb ed       	pshufd $0xed,%xmm3,%xmm1
   2e270:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e274:	66 0f 66 dc          	pcmpgtd %xmm4,%xmm3
   2e278:	66 0f 62 e3          	punpckldq %xmm3,%xmm4
   2e27c:	66 0f d4 ec          	paddq  %xmm4,%xmm5
   2e280:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e284:	66 0f 66 da          	pcmpgtd %xmm2,%xmm3
   2e288:	66 0f 62 d3          	punpckldq %xmm3,%xmm2
   2e28c:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   2e290:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e294:	66 0f 66 d0          	pcmpgtd %xmm0,%xmm2
   2e298:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
   2e29c:	66 0f d4 c5          	paddq  %xmm5,%xmm0
   2e2a0:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e2a4:	66 0f 66 d1          	pcmpgtd %xmm1,%xmm2
   2e2a8:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
   2e2ac:	66 0f d4 ce          	paddq  %xmm6,%xmm1
   2e2b0:	48 83 c0 04          	add    $0x4,%rax
   2e2b4:	48 39 c1             	cmp    %rax,%rcx
   2e2b7:	75 8e                	jne    2e247 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x947>
   2e2b9:	66 0f d4 c8          	paddq  %xmm0,%xmm1
   2e2bd:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   2e2c2:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   2e2c6:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2e2cb:	48 39 cb             	cmp    %rcx,%rbx
   2e2ce:	0f 84 9d fe ff ff    	je     2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e2d4:	49 63 14 ce          	movslq (%r14,%rcx,8),%rdx
   2e2d8:	48 89 c6             	mov    %rax,%rsi
   2e2db:	49 63 44 ce 04       	movslq 0x4(%r14,%rcx,8),%rax
   2e2e0:	48 ff c1             	inc    %rcx
   2e2e3:	48 01 d6             	add    %rdx,%rsi
   2e2e6:	48 01 f0             	add    %rsi,%rax
   2e2e9:	48 39 cb             	cmp    %rcx,%rbx
   2e2ec:	75 e6                	jne    2e2d4 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x9d4>
   2e2ee:	e9 7e fe ff ff       	jmp    2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e2f3:	48 89 d9             	mov    %rbx,%rcx
   2e2f6:	48 83 e1 fc          	and    $0xfffffffffffffffc,%rcx
   2e2fa:	66 0f ef c0          	pxor   %xmm0,%xmm0
   2e2fe:	31 c0                	xor    %eax,%eax
   2e300:	66 0f ef c9          	pxor   %xmm1,%xmm1
   2e304:	f3 41 0f 6f 14 c6    	movdqu (%r14,%rax,8),%xmm2
   2e30a:	f3 41 0f 6f 5c c6 10 	movdqu 0x10(%r14,%rax,8),%xmm3
   2e311:	66 0f 70 e2 e8       	pshufd $0xe8,%xmm2,%xmm4
   2e316:	66 0f 6f e8          	movdqa %xmm0,%xmm5
   2e31a:	66 0f 70 c2 ed       	pshufd $0xed,%xmm2,%xmm0
   2e31f:	66 0f 70 d3 e8       	pshufd $0xe8,%xmm3,%xmm2
   2e324:	66 0f 6f f1          	movdqa %xmm1,%xmm6
   2e328:	66 0f 70 cb ed       	pshufd $0xed,%xmm3,%xmm1
   2e32d:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e331:	66 0f 66 dc          	pcmpgtd %xmm4,%xmm3
   2e335:	66 0f 62 e3          	punpckldq %xmm3,%xmm4
   2e339:	66 0f d4 ec          	paddq  %xmm4,%xmm5
   2e33d:	66 0f ef db          	pxor   %xmm3,%xmm3
   2e341:	66 0f 66 da          	pcmpgtd %xmm2,%xmm3
   2e345:	66 0f 62 d3          	punpckldq %xmm3,%xmm2
   2e349:	66 0f d4 f2          	paddq  %xmm2,%xmm6
   2e34d:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e351:	66 0f 66 d0          	pcmpgtd %xmm0,%xmm2
   2e355:	66 0f 62 c2          	punpckldq %xmm2,%xmm0
   2e359:	66 0f d4 c5          	paddq  %xmm5,%xmm0
   2e35d:	66 0f ef d2          	pxor   %xmm2,%xmm2
   2e361:	66 0f 66 d1          	pcmpgtd %xmm1,%xmm2
   2e365:	66 0f 62 ca          	punpckldq %xmm2,%xmm1
   2e369:	66 0f d4 ce          	paddq  %xmm6,%xmm1
   2e36d:	48 83 c0 04          	add    $0x4,%rax
   2e371:	48 39 c1             	cmp    %rax,%rcx
   2e374:	75 8e                	jne    2e304 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xa04>
   2e376:	66 0f d4 c8          	paddq  %xmm0,%xmm1
   2e37a:	66 0f 70 c1 ee       	pshufd $0xee,%xmm1,%xmm0
   2e37f:	66 0f d4 c1          	paddq  %xmm1,%xmm0
   2e383:	66 48 0f 7e c0       	movq   %xmm0,%rax
   2e388:	e9 f3 02 00 00       	jmp    2e680 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd80>
   2e38d:	48 85 c9             	test   %rcx,%rcx
   2e390:	0f 84 d9 fd ff ff    	je     2e16f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x86f>
   2e396:	48 8b 57 20          	mov    0x20(%rdi),%rdx
   2e39a:	31 c0                	xor    %eax,%eax
   2e39c:	31 f6                	xor    %esi,%esi
   2e39e:	48 83 f9 01          	cmp    $0x1,%rcx
   2e3a2:	75 23                	jne    2e3c7 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xac7>
   2e3a4:	44 8b 02             	mov    (%rdx),%r8d
   2e3a7:	eb 0c                	jmp    2e3b5 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xab5>
   2e3a9:	48 ff c6             	inc    %rsi
   2e3ac:	48 39 f3             	cmp    %rsi,%rbx
   2e3af:	0f 84 bc fd ff ff    	je     2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e3b5:	45 3b 04 f6          	cmp    (%r14,%rsi,8),%r8d
   2e3b9:	75 ee                	jne    2e3a9 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e3bb:	48 3b 72 08          	cmp    0x8(%rdx),%rsi
   2e3bf:	75 e8                	jne    2e3a9 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xaa9>
   2e3c1:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
   2e3c5:	eb 64                	jmp    2e42b <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb2b>
   2e3c7:	49 89 f1             	mov    %rsi,%r9
   2e3ca:	eb 09                	jmp    2e3d5 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xad5>
   2e3cc:	49 39 d9             	cmp    %rbx,%r9
   2e3cf:	0f 84 9c fd ff ff    	je     2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e3d5:	4c 89 ce             	mov    %r9,%rsi
   2e3d8:	47 8b 04 ce          	mov    (%r14,%r9,8),%r8d
   2e3dc:	49 89 c9             	mov    %rcx,%r9
   2e3df:	45 31 d2             	xor    %r10d,%r10d
   2e3e2:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e3e9:	1f 84 00 00 00 00 00 
   2e3f0:	4d 89 d3             	mov    %r10,%r11
   2e3f3:	4d 89 cf             	mov    %r9,%r15
   2e3f6:	49 d1 ef             	shr    $1,%r15
   2e3f9:	4d 01 fa             	add    %r15,%r10
   2e3fc:	4d 89 d4             	mov    %r10,%r12
   2e3ff:	49 c1 e4 04          	shl    $0x4,%r12
   2e403:	46 39 04 22          	cmp    %r8d,(%rdx,%r12,1)
   2e407:	4d 0f 4f d3          	cmovg  %r11,%r10
   2e40b:	4d 29 f9             	sub    %r15,%r9
   2e40e:	49 83 f9 01          	cmp    $0x1,%r9
   2e412:	77 dc                	ja     2e3f0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xaf0>
   2e414:	4c 8d 4e 01          	lea    0x1(%rsi),%r9
   2e418:	49 c1 e2 04          	shl    $0x4,%r10
   2e41c:	46 39 04 12          	cmp    %r8d,(%rdx,%r10,1)
   2e420:	75 aa                	jne    2e3cc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xacc>
   2e422:	49 01 d2             	add    %rdx,%r10
   2e425:	49 39 72 08          	cmp    %rsi,0x8(%r10)
   2e429:	75 a1                	jne    2e3cc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xacc>
   2e42b:	49 63 74 f6 04       	movslq 0x4(%r14,%rsi,8),%rsi
   2e430:	4d 63 c0             	movslq %r8d,%r8
   2e433:	4c 01 c0             	add    %r8,%rax
   2e436:	48 01 f0             	add    %rsi,%rax
   2e439:	4c 89 ce             	mov    %r9,%rsi
   2e43c:	49 39 d9             	cmp    %rbx,%r9
   2e43f:	0f 82 59 ff ff ff    	jb     2e39e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xa9e>
   2e445:	e9 27 fd ff ff       	jmp    2e171 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e44a:	31 c0                	xor    %eax,%eax
   2e44c:	eb 0e                	jmp    2e45c <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb5c>
   2e44e:	48 ff c0             	inc    %rax
   2e451:	31 ed                	xor    %ebp,%ebp
   2e453:	48 39 d8             	cmp    %rbx,%rax
   2e456:	0f 84 ab fd ff ff    	je     2e207 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x907>
   2e45c:	41 8b 34 c4          	mov    (%r12,%rax,8),%esi
   2e460:	49 89 d0             	mov    %rdx,%r8
   2e463:	31 ff                	xor    %edi,%edi
   2e465:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e46c:	00 00 00 00 
   2e470:	49 89 f9             	mov    %rdi,%r9
   2e473:	4d 89 c2             	mov    %r8,%r10
   2e476:	49 d1 ea             	shr    $1,%r10
   2e479:	4c 01 d7             	add    %r10,%rdi
   2e47c:	49 89 fb             	mov    %rdi,%r11
   2e47f:	49 c1 e3 04          	shl    $0x4,%r11
   2e483:	42 39 34 19          	cmp    %esi,(%rcx,%r11,1)
   2e487:	49 0f 4f f9          	cmovg  %r9,%rdi
   2e48b:	4d 29 d0             	sub    %r10,%r8
   2e48e:	49 83 f8 01          	cmp    $0x1,%r8
   2e492:	77 dc                	ja     2e470 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb70>
   2e494:	48 c1 e7 04          	shl    $0x4,%rdi
   2e498:	39 34 39             	cmp    %esi,(%rcx,%rdi,1)
   2e49b:	75 b1                	jne    2e44e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb4e>
   2e49d:	48 01 cf             	add    %rcx,%rdi
   2e4a0:	48 39 47 08          	cmp    %rax,0x8(%rdi)
   2e4a4:	75 a8                	jne    2e44e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xb4e>
   2e4a6:	4d 8d 24 c4          	lea    (%r12,%rax,8),%r12
   2e4aa:	e9 4d fd ff ff       	jmp    2e1fc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e4af:	48 8d 3d de ad fd ff 	lea    -0x25222(%rip),%rdi        # 9294 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e4b6:	48 8d 15 4b 20 04 00 	lea    0x4204b(%rip),%rdx        # 70508 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6a8>
   2e4bd:	be 28 00 00 00       	mov    $0x28,%esi
   2e4c2:	ff 15 58 3c 04 00    	call   *0x43c58(%rip)        # 72120 <_DYNAMIC+0x3b8>
   2e4c8:	49 89 fe             	mov    %rdi,%r14
   2e4cb:	ff 15 9f 3e 04 00    	call   *0x43e9f(%rip)        # 72370 <_DYNAMIC+0x608>
   2e4d1:	4c 89 f7             	mov    %r14,%rdi
   2e4d4:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e4d9:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e4de:	e9 c3 f5 ff ff       	jmp    2daa6 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e4e3:	48 8d 3d aa ad fd ff 	lea    -0x25256(%rip),%rdi        # 9294 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e4ea:	48 8d 15 2f 20 04 00 	lea    0x4202f(%rip),%rdx        # 70520 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x6c0>
   2e4f1:	be 28 00 00 00       	mov    $0x28,%esi
   2e4f6:	ff 15 24 3c 04 00    	call   *0x43c24(%rip)        # 72120 <_DYNAMIC+0x3b8>
   2e4fc:	4c 89 ff             	mov    %r15,%rdi
   2e4ff:	4c 89 e6             	mov    %r12,%rsi
   2e502:	48 89 da             	mov    %rbx,%rdx
   2e505:	e8 a2 ab ff ff       	call   290ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsl9Y7oDXyMto_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e50a:	e9 d5 fb ff ff       	jmp    2e0e4 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x7e4>
   2e50f:	4c 89 ff             	mov    %r15,%rdi
   2e512:	4c 89 f6             	mov    %r14,%rsi
   2e515:	48 89 da             	mov    %rbx,%rdx
   2e518:	e8 8f ab ff ff       	call   290ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsl9Y7oDXyMto_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e51d:	49 8b 57 10          	mov    0x10(%r15),%rdx
   2e521:	48 39 da             	cmp    %rbx,%rdx
   2e524:	0f 85 6d fc ff ff    	jne    2e197 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x897>
   2e52a:	e9 cd fc ff ff       	jmp    2e1fc <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e52f:	4c 89 ff             	mov    %r15,%rdi
   2e532:	4c 89 f6             	mov    %r14,%rsi
   2e535:	48 89 da             	mov    %rbx,%rdx
   2e538:	e8 6f ab ff ff       	call   290ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsl9Y7oDXyMto_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e53d:	49 8b 4f 10          	mov    0x10(%r15),%rcx
   2e541:	48 39 d9             	cmp    %rbx,%rcx
   2e544:	0f 84 9c fc ff ff    	je     2e1e6 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x8e6>
   2e54a:	48 85 c9             	test   %rcx,%rcx
   2e54d:	0f 84 a7 00 00 00    	je     2e5fa <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xcfa>
   2e553:	49 8b 57 08          	mov    0x8(%r15),%rdx
   2e557:	31 c0                	xor    %eax,%eax
   2e559:	31 f6                	xor    %esi,%esi
   2e55b:	48 83 f9 01          	cmp    $0x1,%rcx
   2e55f:	75 22                	jne    2e583 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc83>
   2e561:	8b 3a                	mov    (%rdx),%edi
   2e563:	eb 0c                	jmp    2e571 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc71>
   2e565:	48 ff c6             	inc    %rsi
   2e568:	48 39 f3             	cmp    %rsi,%rbx
   2e56b:	0f 84 14 01 00 00    	je     2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e571:	41 3b 3c f4          	cmp    (%r12,%rsi,8),%edi
   2e575:	75 ee                	jne    2e565 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc65>
   2e577:	48 3b 72 08          	cmp    0x8(%rdx),%rsi
   2e57b:	75 e8                	jne    2e565 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc65>
   2e57d:	4c 8d 46 01          	lea    0x1(%rsi),%r8
   2e581:	eb 58                	jmp    2e5db <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xcdb>
   2e583:	49 89 f0             	mov    %rsi,%r8
   2e586:	eb 09                	jmp    2e591 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc91>
   2e588:	49 39 d8             	cmp    %rbx,%r8
   2e58b:	0f 84 f4 00 00 00    	je     2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e591:	4c 89 c6             	mov    %r8,%rsi
   2e594:	43 8b 3c c4          	mov    (%r12,%r8,8),%edi
   2e598:	49 89 c8             	mov    %rcx,%r8
   2e59b:	45 31 c9             	xor    %r9d,%r9d
   2e59e:	66 90                	xchg   %ax,%ax
   2e5a0:	4d 89 ca             	mov    %r9,%r10
   2e5a3:	4d 89 c3             	mov    %r8,%r11
   2e5a6:	49 d1 eb             	shr    $1,%r11
   2e5a9:	4d 01 d9             	add    %r11,%r9
   2e5ac:	4d 89 ce             	mov    %r9,%r14
   2e5af:	49 c1 e6 04          	shl    $0x4,%r14
   2e5b3:	42 39 3c 32          	cmp    %edi,(%rdx,%r14,1)
   2e5b7:	4d 0f 4f ca          	cmovg  %r10,%r9
   2e5bb:	4d 29 d8             	sub    %r11,%r8
   2e5be:	49 83 f8 01          	cmp    $0x1,%r8
   2e5c2:	77 dc                	ja     2e5a0 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xca0>
   2e5c4:	4c 8d 46 01          	lea    0x1(%rsi),%r8
   2e5c8:	49 c1 e1 04          	shl    $0x4,%r9
   2e5cc:	42 39 3c 0a          	cmp    %edi,(%rdx,%r9,1)
   2e5d0:	75 b6                	jne    2e588 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc88>
   2e5d2:	49 01 d1             	add    %rdx,%r9
   2e5d5:	49 39 71 08          	cmp    %rsi,0x8(%r9)
   2e5d9:	75 ad                	jne    2e588 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc88>
   2e5db:	49 63 74 f4 04       	movslq 0x4(%r12,%rsi,8),%rsi
   2e5e0:	48 63 ff             	movslq %edi,%rdi
   2e5e3:	48 01 f8             	add    %rdi,%rax
   2e5e6:	48 01 f0             	add    %rsi,%rax
   2e5e9:	4c 89 c6             	mov    %r8,%rsi
   2e5ec:	49 39 d8             	cmp    %rbx,%r8
   2e5ef:	0f 82 66 ff ff ff    	jb     2e55b <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xc5b>
   2e5f5:	e9 8b 00 00 00       	jmp    2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e5fa:	31 c0                	xor    %eax,%eax
   2e5fc:	e9 84 00 00 00       	jmp    2e685 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd85>
   2e601:	49 8d 7f 18          	lea    0x18(%r15),%rdi
   2e605:	4c 89 f6             	mov    %r14,%rsi
   2e608:	48 89 da             	mov    %rbx,%rdx
   2e60b:	e8 9c aa ff ff       	call   290ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsl9Y7oDXyMto_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e610:	e9 11 fc ff ff       	jmp    2e226 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0x926>
   2e615:	48 89 c3             	mov    %rax,%rbx
   2e618:	eb 25                	jmp    2e63f <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd3f>
   2e61a:	48 89 c3             	mov    %rax,%rbx
   2e61d:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e622:	74 23                	je     2e647 <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd47>
   2e624:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e629:	ff 15 31 39 04 00    	call   *0x43931(%rip)        # 71f60 <free@GLIBC_2.2.5>
   2e62f:	48 89 df             	mov    %rbx,%rdi
   2e632:	e8 89 01 04 00       	call   6e7c0 <_Unwind_Resume@plt>
   2e637:	48 89 c3             	mov    %rax,%rbx
   2e63a:	4c 8b 7c 24 38       	mov    0x38(%rsp),%r15
   2e63f:	4c 89 ff             	mov    %r15,%rdi
   2e642:	e8 f9 b9 ff ff       	call   2a040 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsl9Y7oDXyMto_4pbrs3map3MapllEECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e647:	48 89 df             	mov    %rbx,%rdi
   2e64a:	e8 71 01 04 00       	call   6e7c0 <_Unwind_Resume@plt>
   2e64f:	ff 15 b3 39 04 00    	call   *0x439b3(%rip)        # 72008 <_DYNAMIC+0x2a0>
   2e655:	48 89 c3             	mov    %rax,%rbx
   2e658:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e65c:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e661:	e8 ba ba ff ff       	call   2a120 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECsaXKLQkbzAXt_24pbrs_map_iteration_proof>
   2e666:	48 89 df             	mov    %rbx,%rdi
   2e669:	e8 52 01 04 00       	call   6e7c0 <_Unwind_Resume@plt>
   2e66e:	49 63 14 ce          	movslq (%r14,%rcx,8),%rdx
   2e672:	49 63 74 ce 04       	movslq 0x4(%r14,%rcx,8),%rsi
   2e677:	48 ff c1             	inc    %rcx
   2e67a:	48 01 d0             	add    %rdx,%rax
   2e67d:	48 01 f0             	add    %rsi,%rax
   2e680:	48 39 cb             	cmp    %rcx,%rbx
   2e683:	75 e9                	jne    2e66e <_RNCNvCsaXKLQkbzAXt_24pbrs_map_iteration_proof4mains1_0B3_+0xd6e>
   2e685:	48 89 04 24          	mov    %rax,(%rsp)
   2e689:	48 89 e0             	mov    %rsp,%rax
   2e68c:	48 83 c4 78          	add    $0x78,%rsp
   2e690:	5b                   	pop    %rbx
   2e691:	41 5c                	pop    %r12
   2e693:	41 5d                	pop    %r13
   2e695:	41 5e                	pop    %r14
   2e697:	41 5f                	pop    %r15
   2e699:	5d                   	pop    %rbp
   2e69a:	c3                   	ret
