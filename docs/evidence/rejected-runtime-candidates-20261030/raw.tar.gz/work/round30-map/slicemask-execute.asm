
work/all-benchmarks/measurement/round30-map-slicemask-loop/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002deb0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_>:
   2deb0:	55                   	push   %rbp
   2deb1:	41 57                	push   %r15
   2deb3:	41 56                	push   %r14
   2deb5:	41 55                	push   %r13
   2deb7:	41 54                	push   %r12
   2deb9:	53                   	push   %rbx
   2deba:	48 81 ec 88 00 00 00 	sub    $0x88,%rsp
   2dec1:	48 8b 07             	mov    (%rdi),%rax
   2dec4:	48 8b 00             	mov    (%rax),%rax
   2dec7:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2decc:	75 10                	jne    2dede <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x2e>
   2dece:	48 8b 40 08          	mov    0x8(%rax),%rax
   2ded2:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2ded8:	0f 84 48 03 00 00    	je     2e226 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2dede:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2dee2:	48 89 44 24 40       	mov    %rax,0x40(%rsp)
   2dee7:	48 8d 44 24 40       	lea    0x40(%rsp),%rax
   2deec:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2def0:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2def4:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2def8:	48 83 f9 04          	cmp    $0x4,%rcx
   2defc:	0f 87 a3 09 00 00    	ja     2e8a5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9f5>
   2df02:	48 8b 40 08          	mov    0x8(%rax),%rax
   2df06:	48 8d 15 03 b4 fd ff 	lea    -0x24bfd(%rip),%rdx        # 9310 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2df0d:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2df11:	48 01 d1             	add    %rdx,%rcx
   2df14:	ff e1                	jmp    *%rcx
   2df16:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2df1d:	61 6c 6c 
   2df20:	48 39 08             	cmp    %rcx,(%rax)
   2df23:	0f 85 7c 09 00 00    	jne    2e8a5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9f5>
   2df29:	48 8b 4c 24 40       	mov    0x40(%rsp),%rcx
   2df2e:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2df32:	48 85 c0             	test   %rax,%rax
   2df35:	0f 84 2a 03 00 00    	je     2e265 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3b5>
   2df3b:	48 8b 09             	mov    (%rcx),%rcx
   2df3e:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2df42:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2df46:	f7 d7                	not    %edi
   2df48:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2df4c:	31 d2                	xor    %edx,%edx
   2df4e:	eb 33                	jmp    2df83 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2df50:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2df54:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2df59:	41 21 f8             	and    %edi,%r8d
   2df5c:	41 c1 e1 03          	shl    $0x3,%r9d
   2df60:	48 89 cf             	mov    %rcx,%rdi
   2df63:	4c 29 cf             	sub    %r9,%rdi
   2df66:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2df6a:	49 89 d2             	mov    %rdx,%r10
   2df6d:	4d 01 ca             	add    %r9,%r10
   2df70:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2df74:	4c 01 d2             	add    %r10,%rdx
   2df77:	44 89 c7             	mov    %r8d,%edi
   2df7a:	48 ff c8             	dec    %rax
   2df7d:	0f 84 e4 02 00 00    	je     2e267 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3b7>
   2df83:	66 85 ff             	test   %di,%di
   2df86:	75 c8                	jne    2df50 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2df88:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2df8f:	00 
   2df90:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2df94:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2df98:	48 83 c6 10          	add    $0x10,%rsi
   2df9c:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dfa0:	66 83 f7 ff          	xor    $0xffff,%di
   2dfa4:	74 ea                	je     2df90 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2dfa6:	eb a8                	jmp    2df50 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dfa8:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2dfaf:	66 69 72 
   2dfb2:	48 33 08             	xor    (%rax),%rcx
   2dfb5:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2dfb9:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2dfbf:	48 09 c8             	or     %rcx,%rax
   2dfc2:	0f 85 dd 08 00 00    	jne    2e8a5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9f5>
   2dfc8:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   2dfcd:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2dfd2:	0f 84 77 02 00 00    	je     2e24f <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2dfd8:	48 8b 00             	mov    (%rax),%rax
   2dfdb:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2dfdf:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dfe3:	66 83 f1 ff          	xor    $0xffff,%cx
   2dfe7:	75 1d                	jne    2e006 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2dfe9:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2dfed:	0f 1f 00             	nopl   (%rax)
   2dff0:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2dff4:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2dff8:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dffc:	48 83 c2 10          	add    $0x10,%rdx
   2e000:	66 83 f1 ff          	xor    $0xffff,%cx
   2e004:	74 ea                	je     2dff0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2e006:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2e00a:	c1 e1 03             	shl    $0x3,%ecx
   2e00d:	48 29 c8             	sub    %rcx,%rax
   2e010:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2e014:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2e018:	e9 34 02 00 00       	jmp    2e251 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2e01d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e024:	72 65 61 
   2e027:	48 33 08             	xor    (%rax),%rcx
   2e02a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e02e:	48 83 f0 64          	xor    $0x64,%rax
   2e032:	48 09 c8             	or     %rcx,%rax
   2e035:	0f 85 6a 08 00 00    	jne    2e8a5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9f5>
   2e03b:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2e042:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2e047:	0f 85 71 08 00 00    	jne    2e8be <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa0e>
   2e04d:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2e051:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2e056:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2e05a:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2e05e:	0f 10 05 c3 24 04 00 	movups 0x424c3(%rip),%xmm0        # 70528 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f8>
   2e065:	0f 29 44 24 10       	movaps %xmm0,0x10(%rsp)
   2e06a:	f3 0f 6f 05 c6 24 04 	movdqu 0x424c6(%rip),%xmm0        # 70538 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x508>
   2e071:	00 
   2e072:	66 0f 7f 44 24 20    	movdqa %xmm0,0x20(%rsp)
   2e078:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2e07d:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   2e082:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e086:	48 89 44 24 48       	mov    %rax,0x48(%rsp)
   2e08b:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2e090:	48 8b 44 24 48       	mov    0x48(%rsp),%rax
   2e095:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e099:	48 85 c9             	test   %rcx,%rcx
   2e09c:	0f 84 d4 01 00 00    	je     2e276 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3c6>
   2e0a2:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e0a6:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2e0aa:	48 8d 5c 24 10       	lea    0x10(%rsp),%rbx
   2e0af:	90                   	nop
   2e0b0:	41 8b 36             	mov    (%r14),%esi
   2e0b3:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e0b7:	48 89 df             	mov    %rbx,%rdi
   2e0ba:	e8 01 5e 00 00       	call   33ec0 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e0bf:	49 83 c6 08          	add    $0x8,%r14
   2e0c3:	4d 39 fe             	cmp    %r15,%r14
   2e0c6:	75 e8                	jne    2e0b0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2e0c8:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2e0cd:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e0d2:	48 8b 4c 24 28       	mov    0x28(%rsp),%rcx
   2e0d7:	48 85 c9             	test   %rcx,%rcx
   2e0da:	0f 84 96 03 00 00    	je     2e476 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x5c6>
   2e0e0:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2e0e4:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e0e9:	41 f7 d1             	not    %r9d
   2e0ec:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2e0f0:	31 d2                	xor    %edx,%edx
   2e0f2:	49 89 f8             	mov    %rdi,%r8
   2e0f5:	eb 3c                	jmp    2e133 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2e0f7:	66 0f 1f 84 00 00 00 	nopw   0x0(%rax,%rax,1)
   2e0fe:	00 00 
   2e100:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2e104:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2e109:	45 21 ca             	and    %r9d,%r10d
   2e10c:	41 c1 e3 03          	shl    $0x3,%r11d
   2e110:	4d 89 c1             	mov    %r8,%r9
   2e113:	4d 29 d9             	sub    %r11,%r9
   2e116:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2e11a:	48 89 d3             	mov    %rdx,%rbx
   2e11d:	4c 01 db             	add    %r11,%rbx
   2e120:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2e124:	48 01 da             	add    %rbx,%rdx
   2e127:	45 89 d1             	mov    %r10d,%r9d
   2e12a:	48 ff c9             	dec    %rcx
   2e12d:	0f 84 45 03 00 00    	je     2e478 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x5c8>
   2e133:	66 45 85 c9          	test   %r9w,%r9w
   2e137:	75 c7                	jne    2e100 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e139:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e140:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2e144:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2e148:	48 83 c6 10          	add    $0x10,%rsi
   2e14c:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e151:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2e156:	74 e8                	je     2e140 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2e158:	eb a6                	jmp    2e100 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e15a:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e161:	63 6f 6c 
   2e164:	48 33 08             	xor    (%rax),%rcx
   2e167:	8b 40 08             	mov    0x8(%rax),%eax
   2e16a:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e170:	48 09 c8             	or     %rcx,%rax
   2e173:	0f 85 2c 07 00 00    	jne    2e8a5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9f5>
   2e179:	48 8b 44 24 40       	mov    0x40(%rsp),%rax
   2e17e:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2e182:	48 85 c9             	test   %rcx,%rcx
   2e185:	0f 84 fe 00 00 00    	je     2e289 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3d9>
   2e18b:	4c 8b 28             	mov    (%rax),%r13
   2e18e:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2e194:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e199:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2e19d:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e1a2:	75 25                	jne    2e1c9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2e1a4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e1ab:	00 00 00 00 00 
   2e1b0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e1b5:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e1b9:	48 83 c5 10          	add    $0x10,%rbp
   2e1bd:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e1c2:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e1c7:	74 e7                	je     2e1b0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2e1c9:	48 83 f9 05          	cmp    $0x5,%rcx
   2e1cd:	bb 04 00 00 00       	mov    $0x4,%ebx
   2e1d2:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e1d8:	4c 0f 43 f9          	cmovae %rcx,%r15
   2e1dc:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2e1e3:	00 
   2e1e4:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2e1eb:	ff ff 1f 
   2e1ee:	48 ff c0             	inc    %rax
   2e1f1:	48 89 4c 24 60       	mov    %rcx,0x60(%rsp)
   2e1f6:	48 39 c1             	cmp    %rax,%rcx
   2e1f9:	0f 97 c0             	seta   %al
   2e1fc:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2e203:	ff ff 7f 
   2e206:	48 83 c1 0b          	add    $0xb,%rcx
   2e20a:	49 39 ce             	cmp    %rcx,%r14
   2e20d:	0f 97 c1             	seta   %cl
   2e210:	08 c1                	or     %al,%cl
   2e212:	0f 84 50 01 00 00    	je     2e368 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4b8>
   2e218:	31 db                	xor    %ebx,%ebx
   2e21a:	48 89 df             	mov    %rbx,%rdi
   2e21d:	4c 89 f6             	mov    %r14,%rsi
   2e220:	ff 15 d2 3f 04 00    	call   *0x43fd2(%rip)        # 721f8 <_DYNAMIC+0x230>
   2e226:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2e22a:	48 89 44 24 68       	mov    %rax,0x68(%rsp)
   2e22f:	48 8d 44 24 68       	lea    0x68(%rsp),%rax
   2e234:	48 8b 44 24 68       	mov    0x68(%rsp),%rax
   2e239:	4c 8b 30             	mov    (%rax),%r14
   2e23c:	4d 85 f6             	test   %r14,%r14
   2e23f:	74 55                	je     2e296 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3e6>
   2e241:	49 8b 76 08          	mov    0x8(%r14),%rsi
   2e245:	49 8b 5e 10          	mov    0x10(%r14),%rbx
   2e249:	49 83 c6 18          	add    $0x18,%r14
   2e24d:	eb 4c                	jmp    2e29b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x3eb>
   2e24f:	31 c9                	xor    %ecx,%ecx
   2e251:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e256:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e25b:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e260:	e9 07 07 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e265:	31 d2                	xor    %edx,%edx
   2e267:	48 89 54 24 10       	mov    %rdx,0x10(%rsp)
   2e26c:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e271:	e9 f6 06 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e276:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   2e27d:	00 00 
   2e27f:	48 8d 44 24 48       	lea    0x48(%rsp),%rax
   2e284:	e9 e3 06 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e289:	b8 04 00 00 00       	mov    $0x4,%eax
   2e28e:	45 31 ff             	xor    %r15d,%r15d
   2e291:	e9 8f 04 00 00       	jmp    2e725 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x875>
   2e296:	45 31 f6             	xor    %r14d,%r14d
   2e299:	31 f6                	xor    %esi,%esi
   2e29b:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2e29f:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e2a3:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2e2a7:	48 83 f9 04          	cmp    $0x4,%rcx
   2e2ab:	0f 87 28 06 00 00    	ja     2e8d9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa29>
   2e2b1:	48 8b 40 08          	mov    0x8(%rax),%rax
   2e2b5:	48 8d 15 68 b0 fd ff 	lea    -0x24f98(%rip),%rdx        # 9324 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2e2bc:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2e2c0:	48 01 d1             	add    %rdx,%rcx
   2e2c3:	ff e1                	jmp    *%rcx
   2e2c5:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2e2cc:	61 6c 6c 
   2e2cf:	48 39 08             	cmp    %rcx,(%rax)
   2e2d2:	0f 85 01 06 00 00    	jne    2e8d9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa29>
   2e2d8:	48 85 f6             	test   %rsi,%rsi
   2e2db:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e2e1:	4c 0f 45 fe          	cmovne %rsi,%r15
   2e2e5:	45 31 ed             	xor    %r13d,%r13d
   2e2e8:	48 85 db             	test   %rbx,%rbx
   2e2eb:	74 6c                	je     2e359 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4a9>
   2e2ed:	48 85 f6             	test   %rsi,%rsi
   2e2f0:	74 67                	je     2e359 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4a9>
   2e2f2:	48 83 fb 10          	cmp    $0x10,%rbx
   2e2f6:	0f 92 c0             	setb   %al
   2e2f9:	4d 85 f6             	test   %r14,%r14
   2e2fc:	0f 94 c1             	sete   %cl
   2e2ff:	08 c1                	or     %al,%cl
   2e301:	0f 84 8f 04 00 00    	je     2e796 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8e6>
   2e307:	48 8d 04 de          	lea    (%rsi,%rbx,8),%rax
   2e30b:	45 31 ed             	xor    %r13d,%r13d
   2e30e:	31 c9                	xor    %ecx,%ecx
   2e310:	eb 14                	jmp    2e326 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x476>
   2e312:	49 63 14 d7          	movslq (%r15,%rdx,8),%rdx
   2e316:	49 63 74 cf fc       	movslq -0x4(%r15,%rcx,8),%rsi
   2e31b:	49 01 d5             	add    %rdx,%r13
   2e31e:	49 01 f5             	add    %rsi,%r13
   2e321:	48 39 d9             	cmp    %rbx,%rcx
   2e324:	73 33                	jae    2e359 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4a9>
   2e326:	48 89 ca             	mov    %rcx,%rdx
   2e329:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
   2e32d:	49 8d 34 d7          	lea    (%r15,%rdx,8),%rsi
   2e331:	48 83 c6 08          	add    $0x8,%rsi
   2e335:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e33c:	00 00 00 00 
   2e340:	48 39 c6             	cmp    %rax,%rsi
   2e343:	74 cd                	je     2e312 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x462>
   2e345:	8b 3e                	mov    (%rsi),%edi
   2e347:	48 83 c6 08          	add    $0x8,%rsi
   2e34b:	41 3b 3c d7          	cmp    (%r15,%rdx,8),%edi
   2e34f:	75 ef                	jne    2e340 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x490>
   2e351:	48 89 ca             	mov    %rcx,%rdx
   2e354:	48 39 d9             	cmp    %rbx,%rcx
   2e357:	75 d0                	jne    2e329 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x479>
   2e359:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   2e35e:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e363:	e9 04 06 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e368:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2e36d:	c1 e0 03             	shl    $0x3,%eax
   2e370:	4c 89 e9             	mov    %r13,%rcx
   2e373:	48 29 c1             	sub    %rax,%rcx
   2e376:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2e37b:	66 0f 7f 44 24 70    	movdqa %xmm0,0x70(%rsp)
   2e381:	4c 89 f7             	mov    %r14,%rdi
   2e384:	ff 15 26 3e 04 00    	call   *0x43e26(%rip)        # 721b0 <malloc@GLIBC_2.2.5>
   2e38a:	48 85 c0             	test   %rax,%rax
   2e38d:	0f 84 87 fe ff ff    	je     2e21a <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2e393:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2e398:	48 89 cb             	mov    %rcx,%rbx
   2e39b:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2e3a1:	66 0f d6 00          	movq   %xmm0,(%rax)
   2e3a5:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   2e3aa:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e3af:	48 c7 44 24 20 01 00 	movq   $0x1,0x20(%rsp)
   2e3b6:	00 00 
   2e3b8:	48 ff cb             	dec    %rbx
   2e3bb:	0f 84 64 03 00 00    	je     2e725 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x875>
   2e3c1:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2e3c6:	45 21 e7             	and    %r12d,%r15d
   2e3c9:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e3cf:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
   2e3d4:	eb 39                	jmp    2e40f <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x55f>
   2e3d6:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2e3dd:	00 00 00 
   2e3e0:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e3e5:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2e3e9:	44 21 f9             	and    %r15d,%ecx
   2e3ec:	48 ff cb             	dec    %rbx
   2e3ef:	66 0f 6f 44 24 70    	movdqa 0x70(%rsp),%xmm0
   2e3f5:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2e3fb:	49 ff c6             	inc    %r14
   2e3fe:	4c 89 74 24 20       	mov    %r14,0x20(%rsp)
   2e403:	41 89 cf             	mov    %ecx,%r15d
   2e406:	48 85 db             	test   %rbx,%rbx
   2e409:	0f 84 07 03 00 00    	je     2e716 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x866>
   2e40f:	66 45 85 ff          	test   %r15w,%r15w
   2e413:	75 24                	jne    2e439 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x589>
   2e415:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e41c:	00 00 00 00 
   2e420:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e425:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e429:	48 83 c5 10          	add    $0x10,%rbp
   2e42d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2e432:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2e437:	74 e7                	je     2e420 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x570>
   2e439:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2e43e:	c1 e1 03             	shl    $0x3,%ecx
   2e441:	4c 89 ea             	mov    %r13,%rdx
   2e444:	48 29 ca             	sub    %rcx,%rdx
   2e447:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2e44c:	0f 29 44 24 70       	movaps %xmm0,0x70(%rsp)
   2e451:	4c 3b 74 24 10       	cmp    0x10(%rsp),%r14
   2e456:	75 8d                	jne    2e3e5 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x535>
   2e458:	b9 04 00 00 00       	mov    $0x4,%ecx
   2e45d:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2e463:	4c 89 e7             	mov    %r12,%rdi
   2e466:	4c 89 f6             	mov    %r14,%rsi
   2e469:	48 89 da             	mov    %rbx,%rdx
   2e46c:	e8 ff e9 ff ff       	call   2ce70 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e471:	e9 6a ff ff ff       	jmp    2e3e0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x530>
   2e476:	31 d2                	xor    %edx,%edx
   2e478:	48 89 54 24 48       	mov    %rdx,0x48(%rsp)
   2e47d:	48 8d 4c 24 48       	lea    0x48(%rsp),%rcx
   2e482:	48 85 c0             	test   %rax,%rax
   2e485:	0f 84 e1 04 00 00    	je     2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e48b:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e492:	00 
   2e493:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e497:	48 01 c8             	add    %rcx,%rax
   2e49a:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e49e:	0f 84 c8 04 00 00    	je     2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e4a4:	48 29 cf             	sub    %rcx,%rdi
   2e4a7:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e4ab:	ff 15 0f 3d 04 00    	call   *0x43d0f(%rip)        # 721c0 <free@GLIBC_2.2.5>
   2e4b1:	e9 b6 04 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e4b6:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2e4bd:	66 69 72 
   2e4c0:	48 33 08             	xor    (%rax),%rcx
   2e4c3:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e4c7:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e4cd:	48 09 c8             	or     %rcx,%rax
   2e4d0:	0f 85 03 04 00 00    	jne    2e8d9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa29>
   2e4d6:	48 85 f6             	test   %rsi,%rsi
   2e4d9:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2e4df:	4c 0f 45 e6          	cmovne %rsi,%r12
   2e4e3:	31 ed                	xor    %ebp,%ebp
   2e4e5:	48 85 db             	test   %rbx,%rbx
   2e4e8:	0f 84 6d 04 00 00    	je     2e95b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaab>
   2e4ee:	48 85 f6             	test   %rsi,%rsi
   2e4f1:	0f 84 64 04 00 00    	je     2e95b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaab>
   2e4f7:	48 83 fb 10          	cmp    $0x10,%rbx
   2e4fb:	0f 92 c0             	setb   %al
   2e4fe:	4d 85 f6             	test   %r14,%r14
   2e501:	0f 94 c1             	sete   %cl
   2e504:	08 c1                	or     %al,%cl
   2e506:	0f 84 65 02 00 00    	je     2e771 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8c1>
   2e50c:	48 8d 0c de          	lea    (%rsi,%rbx,8),%rcx
   2e510:	31 d2                	xor    %edx,%edx
   2e512:	49 8d 04 d4          	lea    (%r12,%rdx,8),%rax
   2e516:	49 8d 34 d4          	lea    (%r12,%rdx,8),%rsi
   2e51a:	48 83 c6 08          	add    $0x8,%rsi
   2e51e:	48 ff c2             	inc    %rdx
   2e521:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e528:	0f 1f 84 00 00 00 00 
   2e52f:	00 
   2e530:	48 39 ce             	cmp    %rcx,%rsi
   2e533:	0f 84 e7 02 00 00    	je     2e820 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x970>
   2e539:	8b 3e                	mov    (%rsi),%edi
   2e53b:	48 83 c6 08          	add    $0x8,%rsi
   2e53f:	3b 38                	cmp    (%rax),%edi
   2e541:	75 ed                	jne    2e530 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x680>
   2e543:	31 ed                	xor    %ebp,%ebp
   2e545:	48 39 da             	cmp    %rbx,%rdx
   2e548:	75 c8                	jne    2e512 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x662>
   2e54a:	e9 0c 04 00 00       	jmp    2e95b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaab>
   2e54f:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e556:	72 65 61 
   2e559:	48 33 08             	xor    (%rax),%rcx
   2e55c:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e560:	48 83 f0 64          	xor    $0x64,%rax
   2e564:	48 09 c8             	or     %rcx,%rax
   2e567:	0f 85 6c 03 00 00    	jne    2e8d9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa29>
   2e56d:	48 c7 44 24 48 00 00 	movq   $0x0,0x48(%rsp)
   2e574:	00 00 
   2e576:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e57a:	48 89 44 24 10       	mov    %rax,0x10(%rsp)
   2e57f:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e584:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e589:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e58d:	48 85 c9             	test   %rcx,%rcx
   2e590:	0f 84 bf 01 00 00    	je     2e755 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8a5>
   2e596:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e59a:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2e59e:	48 8d 5c 24 48       	lea    0x48(%rsp),%rbx
   2e5a3:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e5aa:	84 00 00 00 00 00 
   2e5b0:	41 8b 36             	mov    (%r14),%esi
   2e5b3:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e5b7:	48 89 df             	mov    %rbx,%rdi
   2e5ba:	e8 61 6e 00 00       	call   35420 <_RNvMso_NtCslnHRGhLzuz6_4pbrs3mapINtB5_3MapllE10push_entryCs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e5bf:	49 83 c6 08          	add    $0x8,%r14
   2e5c3:	4d 39 fe             	cmp    %r15,%r14
   2e5c6:	75 e8                	jne    2e5b0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x700>
   2e5c8:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   2e5cd:	48 85 db             	test   %rbx,%rbx
   2e5d0:	0f 84 7f 01 00 00    	je     2e755 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8a5>
   2e5d6:	4c 8b 73 10          	mov    0x10(%rbx),%r14
   2e5da:	4d 85 f6             	test   %r14,%r14
   2e5dd:	0f 84 74 01 00 00    	je     2e757 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8a7>
   2e5e3:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
   2e5e7:	49 83 fe 10          	cmp    $0x10,%r14
   2e5eb:	0f 83 38 02 00 00    	jae    2e829 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x979>
   2e5f1:	49 8d 47 08          	lea    0x8(%r15),%rax
   2e5f5:	4a 8d 0c f5 f8 ff ff 	lea    -0x8(,%r14,8),%rcx
   2e5fc:	ff 
   2e5fd:	45 31 ed             	xor    %r13d,%r13d
   2e600:	31 d2                	xor    %edx,%edx
   2e602:	eb 1b                	jmp    2e61f <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x76f>
   2e604:	4b 63 34 c7          	movslq (%r15,%r8,8),%rsi
   2e608:	4c 89 ef             	mov    %r13,%rdi
   2e60b:	48 01 f7             	add    %rsi,%rdi
   2e60e:	4d 63 6c d7 fc       	movslq -0x4(%r15,%rdx,8),%r13
   2e613:	49 01 fd             	add    %rdi,%r13
   2e616:	4c 39 f2             	cmp    %r14,%rdx
   2e619:	0f 83 3b 01 00 00    	jae    2e75a <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8aa>
   2e61f:	48 8d 3c d5 00 00 00 	lea    0x0(,%rdx,8),%rdi
   2e626:	00 
   2e627:	48 89 ce             	mov    %rcx,%rsi
   2e62a:	48 29 fe             	sub    %rdi,%rsi
   2e62d:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
   2e631:	49 89 d0             	mov    %rdx,%r8
   2e634:	48 ff c2             	inc    %rdx
   2e637:	4c 39 f2             	cmp    %r14,%rdx
   2e63a:	74 c8                	je     2e604 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x754>
   2e63c:	47 8b 0c c7          	mov    (%r15,%r8,8),%r9d
   2e640:	45 31 d2             	xor    %r10d,%r10d
   2e643:	66 66 66 66 2e 0f 1f 	data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e64a:	84 00 00 00 00 00 
   2e650:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e654:	74 0b                	je     2e661 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x7b1>
   2e656:	49 83 c2 08          	add    $0x8,%r10
   2e65a:	4c 39 d6             	cmp    %r10,%rsi
   2e65d:	75 f1                	jne    2e650 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x7a0>
   2e65f:	eb a3                	jmp    2e604 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x754>
   2e661:	48 83 c7 08          	add    $0x8,%rdi
   2e665:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   2e669:	49 89 d0             	mov    %rdx,%r8
   2e66c:	48 ff c2             	inc    %rdx
   2e66f:	4c 39 f2             	cmp    %r14,%rdx
   2e672:	75 c8                	jne    2e63c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x78c>
   2e674:	eb 8e                	jmp    2e604 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x754>
   2e676:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e67d:	63 6f 6c 
   2e680:	48 33 08             	xor    (%rax),%rcx
   2e683:	8b 40 08             	mov    0x8(%rax),%eax
   2e686:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e68c:	48 09 c8             	or     %rcx,%rax
   2e68f:	0f 85 44 02 00 00    	jne    2e8d9 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa29>
   2e695:	48 85 f6             	test   %rsi,%rsi
   2e698:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e69e:	4c 0f 45 fe          	cmovne %rsi,%r15
   2e6a2:	48 0f 44 de          	cmove  %rsi,%rbx
   2e6a6:	31 c0                	xor    %eax,%eax
   2e6a8:	48 85 db             	test   %rbx,%rbx
   2e6ab:	74 1a                	je     2e6c7 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x817>
   2e6ad:	4d 85 f6             	test   %r14,%r14
   2e6b0:	74 15                	je     2e6c7 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x817>
   2e6b2:	48 83 fb 10          	cmp    $0x10,%rbx
   2e6b6:	72 0f                	jb     2e6c7 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x817>
   2e6b8:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e6bc:	85 c0                	test   %eax,%eax
   2e6be:	0f 85 2e 02 00 00    	jne    2e8f2 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa42>
   2e6c4:	4c 89 f0             	mov    %r14,%rax
   2e6c7:	48 c7 44 24 10 00 00 	movq   $0x0,0x10(%rsp)
   2e6ce:	00 00 
   2e6d0:	4c 89 7c 24 18       	mov    %r15,0x18(%rsp)
   2e6d5:	48 89 5c 24 20       	mov    %rbx,0x20(%rsp)
   2e6da:	48 89 44 24 28       	mov    %rax,0x28(%rsp)
   2e6df:	48 c7 44 24 30 00 00 	movq   $0x0,0x30(%rsp)
   2e6e6:	00 00 
   2e6e8:	48 8d 5c 24 48       	lea    0x48(%rsp),%rbx
   2e6ed:	48 8d 74 24 10       	lea    0x10(%rsp),%rsi
   2e6f2:	48 89 df             	mov    %rbx,%rdi
   2e6f5:	e8 c6 71 00 00       	call   358c0 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCslnHRGhLzuz6_4pbrs3map11MapViewIterllEE9from_iterCs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e6fa:	48 83 7c 24 48 00    	cmpq   $0x0,0x48(%rsp)
   2e700:	0f 84 66 02 00 00    	je     2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e706:	48 8b 7c 24 50       	mov    0x50(%rsp),%rdi
   2e70b:	ff 15 af 3a 04 00    	call   *0x43aaf(%rip)        # 721c0 <free@GLIBC_2.2.5>
   2e711:	e9 56 02 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e716:	4c 8b 7c 24 10       	mov    0x10(%rsp),%r15
   2e71b:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e720:	48 8b 4c 24 60       	mov    0x60(%rsp),%rcx
   2e725:	4c 89 7c 24 10       	mov    %r15,0x10(%rsp)
   2e72a:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e72f:	48 89 4c 24 20       	mov    %rcx,0x20(%rsp)
   2e734:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e739:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e73f:	0f 84 27 02 00 00    	je     2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e745:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e74a:	ff 15 70 3a 04 00    	call   *0x43a70(%rip)        # 721c0 <free@GLIBC_2.2.5>
   2e750:	e9 17 02 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e755:	31 db                	xor    %ebx,%ebx
   2e757:	45 31 ed             	xor    %r13d,%r13d
   2e75a:	4c 89 6c 24 10       	mov    %r13,0x10(%rsp)
   2e75f:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e764:	48 89 df             	mov    %rbx,%rdi
   2e767:	e8 c4 bb ff ff       	call   2a330 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCslnHRGhLzuz6_4pbrs3map3MapllEECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e76c:	e9 fb 01 00 00       	jmp    2e96c <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xabc>
   2e771:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e775:	85 c0                	test   %eax,%eax
   2e777:	0f 85 88 01 00 00    	jne    2e905 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e77d:	4d 8b 46 10          	mov    0x10(%r14),%r8
   2e781:	49 39 d8             	cmp    %rbx,%r8
   2e784:	0f 85 99 01 00 00    	jne    2e923 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xa73>
   2e78a:	48 83 c6 04          	add    $0x4,%rsi
   2e78e:	4c 89 e0             	mov    %r12,%rax
   2e791:	e9 ba 01 00 00       	jmp    2e950 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaa0>
   2e796:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e79a:	85 c0                	test   %eax,%eax
   2e79c:	0f 85 dc 01 00 00    	jne    2e97e <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xace>
   2e7a2:	45 31 ed             	xor    %r13d,%r13d
   2e7a5:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
   2e7aa:	48 8b 2d ef 3d 04 00 	mov    0x43def(%rip),%rbp        # 725a0 <_DYNAMIC+0x5d8>
   2e7b1:	31 c0                	xor    %eax,%eax
   2e7b3:	eb 17                	jmp    2e7cc <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x91c>
   2e7b5:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e7bc:	00 00 00 00 
   2e7c0:	48 63 09             	movslq (%rcx),%rcx
   2e7c3:	48 63 12             	movslq (%rdx),%rdx
   2e7c6:	49 01 cd             	add    %rcx,%r13
   2e7c9:	49 01 d5             	add    %rdx,%r13
   2e7cc:	4d 8b 46 10          	mov    0x10(%r14),%r8
   2e7d0:	49 39 d8             	cmp    %rbx,%r8
   2e7d3:	75 1a                	jne    2e7ef <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x93f>
   2e7d5:	48 39 d8             	cmp    %rbx,%rax
   2e7d8:	0f 83 7b fb ff ff    	jae    2e359 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4a9>
   2e7de:	49 8d 0c c7          	lea    (%r15,%rax,8),%rcx
   2e7e2:	49 8d 14 c7          	lea    (%r15,%rax,8),%rdx
   2e7e6:	48 83 c2 04          	add    $0x4,%rdx
   2e7ea:	48 ff c0             	inc    %rax
   2e7ed:	eb d1                	jmp    2e7c0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x910>
   2e7ef:	49 8b 4e 08          	mov    0x8(%r14),%rcx
   2e7f3:	4d 8b 4e 18          	mov    0x18(%r14),%r9
   2e7f7:	48 89 04 24          	mov    %rax,(%rsp)
   2e7fb:	4c 89 e7             	mov    %r12,%rdi
   2e7fe:	4c 89 fe             	mov    %r15,%rsi
   2e801:	48 89 da             	mov    %rbx,%rdx
   2e804:	ff d5                	call   *%rbp
   2e806:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2e80b:	48 85 c9             	test   %rcx,%rcx
   2e80e:	0f 84 45 fb ff ff    	je     2e359 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x4a9>
   2e814:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e819:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   2e81e:	eb a0                	jmp    2e7c0 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x910>
   2e820:	48 8d 70 04          	lea    0x4(%rax),%rsi
   2e824:	e9 27 01 00 00       	jmp    2e950 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaa0>
   2e829:	8b 43 38             	mov    0x38(%rbx),%eax
   2e82c:	85 c0                	test   %eax,%eax
   2e82e:	0f 85 5a 01 00 00    	jne    2e98e <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xade>
   2e834:	45 31 ed             	xor    %r13d,%r13d
   2e837:	4c 8d 64 24 10       	lea    0x10(%rsp),%r12
   2e83c:	48 8b 2d 5d 3d 04 00 	mov    0x43d5d(%rip),%rbp        # 725a0 <_DYNAMIC+0x5d8>
   2e843:	31 c0                	xor    %eax,%eax
   2e845:	eb 24                	jmp    2e86b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9bb>
   2e847:	4c 39 f0             	cmp    %r14,%rax
   2e84a:	0f 83 0a ff ff ff    	jae    2e75a <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8aa>
   2e850:	49 8d 0c c7          	lea    (%r15,%rax,8),%rcx
   2e854:	49 8d 14 c7          	lea    (%r15,%rax,8),%rdx
   2e858:	48 83 c2 04          	add    $0x4,%rdx
   2e85c:	48 ff c0             	inc    %rax
   2e85f:	48 63 09             	movslq (%rcx),%rcx
   2e862:	48 63 12             	movslq (%rdx),%rdx
   2e865:	49 01 cd             	add    %rcx,%r13
   2e868:	49 01 d5             	add    %rdx,%r13
   2e86b:	4c 8b 43 28          	mov    0x28(%rbx),%r8
   2e86f:	4d 39 f0             	cmp    %r14,%r8
   2e872:	74 d3                	je     2e847 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x997>
   2e874:	48 8b 4b 20          	mov    0x20(%rbx),%rcx
   2e878:	4c 8b 4b 30          	mov    0x30(%rbx),%r9
   2e87c:	48 89 04 24          	mov    %rax,(%rsp)
   2e880:	4c 89 e7             	mov    %r12,%rdi
   2e883:	4c 89 fe             	mov    %r15,%rsi
   2e886:	4c 89 f2             	mov    %r14,%rdx
   2e889:	ff d5                	call   *%rbp
   2e88b:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2e890:	48 85 c9             	test   %rcx,%rcx
   2e893:	0f 84 c1 fe ff ff    	je     2e75a <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8aa>
   2e899:	48 8b 44 24 10       	mov    0x10(%rsp),%rax
   2e89e:	48 8b 54 24 20       	mov    0x20(%rsp),%rdx
   2e8a3:	eb ba                	jmp    2e85f <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x9af>
   2e8a5:	48 8d 3d c8 aa fd ff 	lea    -0x25538(%rip),%rdi        # 9374 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e8ac:	48 8d 15 b5 1e 04 00 	lea    0x41eb5(%rip),%rdx        # 70768 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x738>
   2e8b3:	be 28 00 00 00       	mov    $0x28,%esi
   2e8b8:	ff 15 c2 3a 04 00    	call   *0x43ac2(%rip)        # 72380 <_DYNAMIC+0x3b8>
   2e8be:	49 89 fe             	mov    %rdi,%r14
   2e8c1:	ff 15 11 3d 04 00    	call   *0x43d11(%rip)        # 725d8 <_DYNAMIC+0x610>
   2e8c7:	4c 89 f7             	mov    %r14,%rdi
   2e8ca:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e8cf:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e8d4:	e9 7d f7 ff ff       	jmp    2e056 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e8d9:	48 8d 3d 94 aa fd ff 	lea    -0x2556c(%rip),%rdi        # 9374 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e8e0:	48 8d 15 99 1e 04 00 	lea    0x41e99(%rip),%rdx        # 70780 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   2e8e7:	be 28 00 00 00       	mov    $0x28,%esi
   2e8ec:	ff 15 8e 3a 04 00    	call   *0x43a8e(%rip)        # 72380 <_DYNAMIC+0x3b8>
   2e8f2:	4c 89 f7             	mov    %r14,%rdi
   2e8f5:	4c 89 fe             	mov    %r15,%rsi
   2e8f8:	48 89 da             	mov    %rbx,%rdx
   2e8fb:	e8 9c aa ff ff       	call   2939c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCslnHRGhLzuz6_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e900:	e9 bf fd ff ff       	jmp    2e6c4 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x814>
   2e905:	4c 89 f7             	mov    %r14,%rdi
   2e908:	49 89 f7             	mov    %rsi,%r15
   2e90b:	48 89 da             	mov    %rbx,%rdx
   2e90e:	e8 89 aa ff ff       	call   2939c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCslnHRGhLzuz6_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e913:	4c 89 fe             	mov    %r15,%rsi
   2e916:	4d 8b 46 10          	mov    0x10(%r14),%r8
   2e91a:	49 39 d8             	cmp    %rbx,%r8
   2e91d:	0f 84 67 fe ff ff    	je     2e78a <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8da>
   2e923:	49 8b 4e 08          	mov    0x8(%r14),%rcx
   2e927:	4d 8b 4e 18          	mov    0x18(%r14),%r9
   2e92b:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e932:	00 
   2e933:	48 8d 7c 24 10       	lea    0x10(%rsp),%rdi
   2e938:	48 89 da             	mov    %rbx,%rdx
   2e93b:	ff 15 5f 3c 04 00    	call   *0x43c5f(%rip)        # 725a0 <_DYNAMIC+0x5d8>
   2e941:	48 8b 44 24 18       	mov    0x18(%rsp),%rax
   2e946:	48 85 c0             	test   %rax,%rax
   2e949:	74 10                	je     2e95b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaab>
   2e94b:	48 8b 74 24 20       	mov    0x20(%rsp),%rsi
   2e950:	8b 38                	mov    (%rax),%edi
   2e952:	8b 06                	mov    (%rsi),%eax
   2e954:	bd 01 00 00 00       	mov    $0x1,%ebp
   2e959:	eb 00                	jmp    2e95b <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xaab>
   2e95b:	89 6c 24 10          	mov    %ebp,0x10(%rsp)
   2e95f:	89 7c 24 14          	mov    %edi,0x14(%rsp)
   2e963:	89 44 24 18          	mov    %eax,0x18(%rsp)
   2e967:	48 8d 44 24 10       	lea    0x10(%rsp),%rax
   2e96c:	48 81 c4 88 00 00 00 	add    $0x88,%rsp
   2e973:	5b                   	pop    %rbx
   2e974:	41 5c                	pop    %r12
   2e976:	41 5d                	pop    %r13
   2e978:	41 5e                	pop    %r14
   2e97a:	41 5f                	pop    %r15
   2e97c:	5d                   	pop    %rbp
   2e97d:	c3                   	ret
   2e97e:	4c 89 f7             	mov    %r14,%rdi
   2e981:	48 89 da             	mov    %rbx,%rdx
   2e984:	e8 13 aa ff ff       	call   2939c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCslnHRGhLzuz6_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e989:	e9 14 fe ff ff       	jmp    2e7a2 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x8f2>
   2e98e:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
   2e992:	4c 89 fe             	mov    %r15,%rsi
   2e995:	4c 89 f2             	mov    %r14,%rdx
   2e998:	e8 ff a9 ff ff       	call   2939c <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCslnHRGhLzuz6_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e99d:	e9 92 fe ff ff       	jmp    2e834 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0x984>
   2e9a2:	49 89 c6             	mov    %rax,%r14
   2e9a5:	eb 2b                	jmp    2e9d2 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xb22>
   2e9a7:	49 89 c6             	mov    %rax,%r14
   2e9aa:	eb 26                	jmp    2e9d2 <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xb22>
   2e9ac:	49 89 c6             	mov    %rax,%r14
   2e9af:	48 83 7c 24 10 00    	cmpq   $0x0,0x10(%rsp)
   2e9b5:	74 23                	je     2e9da <_RNCNvCs9lHJE5KtR0A_24pbrs_map_iteration_proof4mains1_0B3_+0xb2a>
   2e9b7:	48 8b 7c 24 18       	mov    0x18(%rsp),%rdi
   2e9bc:	ff 15 fe 37 04 00    	call   *0x437fe(%rip)        # 721c0 <free@GLIBC_2.2.5>
   2e9c2:	4c 89 f7             	mov    %r14,%rdi
   2e9c5:	e8 c6 ff 03 00       	call   6e990 <_Unwind_Resume@plt>
   2e9ca:	49 89 c6             	mov    %rax,%r14
   2e9cd:	48 8b 5c 24 48       	mov    0x48(%rsp),%rbx
   2e9d2:	48 89 df             	mov    %rbx,%rdi
   2e9d5:	e8 56 b9 ff ff       	call   2a330 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCslnHRGhLzuz6_4pbrs3map3MapllEECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e9da:	4c 89 f7             	mov    %r14,%rdi
   2e9dd:	e8 ae ff 03 00       	call   6e990 <_Unwind_Resume@plt>
   2e9e2:	ff 15 80 38 04 00    	call   *0x43880(%rip)        # 72268 <_DYNAMIC+0x2a0>
   2e9e8:	49 89 c6             	mov    %rax,%r14
   2e9eb:	48 8b 7c 24 10       	mov    0x10(%rsp),%rdi
   2e9f0:	48 8b 74 24 18       	mov    0x18(%rsp),%rsi
   2e9f5:	e8 16 ba ff ff       	call   2a410 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECs9lHJE5KtR0A_24pbrs_map_iteration_proof>
   2e9fa:	4c 89 f7             	mov    %r14,%rdi
   2e9fd:	e8 8e ff 03 00       	call   6e990 <_Unwind_Resume@plt>
