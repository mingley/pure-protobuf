
work/all-benchmarks/measurement/round30-map-pure-loop/codec-shipping:     file format elf64-x86-64


Disassembly of section .text:

000000000002dec0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_>:
   2dec0:	55                   	push   %rbp
   2dec1:	41 57                	push   %r15
   2dec3:	41 56                	push   %r14
   2dec5:	41 55                	push   %r13
   2dec7:	41 54                	push   %r12
   2dec9:	53                   	push   %rbx
   2deca:	48 83 ec 78          	sub    $0x78,%rsp
   2dece:	48 8b 07             	mov    (%rdi),%rax
   2ded1:	48 8b 00             	mov    (%rax),%rax
   2ded4:	48 83 78 10 04       	cmpq   $0x4,0x10(%rax)
   2ded9:	75 10                	jne    2deeb <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x2b>
   2dedb:	48 8b 40 08          	mov    0x8(%rax),%rax
   2dedf:	81 38 70 62 72 73    	cmpl   $0x73726270,(%rax)
   2dee5:	0f 84 4b 03 00 00    	je     2e236 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x376>
   2deeb:	48 8b 47 20          	mov    0x20(%rdi),%rax
   2deef:	48 89 44 24 30       	mov    %rax,0x30(%rsp)
   2def4:	48 8d 44 24 30       	lea    0x30(%rsp),%rax
   2def9:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2defd:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2df01:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2df05:	48 83 f9 04          	cmp    $0x4,%rcx
   2df09:	0f 87 4c 09 00 00    	ja     2e85b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x99b>
   2df0f:	48 8b 40 08          	mov    0x8(%rax),%rax
   2df13:	48 8d 15 e6 b3 fd ff 	lea    -0x24c1a(%rip),%rdx        # 9300 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x39>
   2df1a:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2df1e:	48 01 d1             	add    %rdx,%rcx
   2df21:	ff e1                	jmp    *%rcx
   2df23:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2df2a:	61 6c 6c 
   2df2d:	48 39 08             	cmp    %rcx,(%rax)
   2df30:	0f 85 25 09 00 00    	jne    2e85b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x99b>
   2df36:	48 8b 4c 24 30       	mov    0x30(%rsp),%rcx
   2df3b:	48 8b 41 18          	mov    0x18(%rcx),%rax
   2df3f:	48 85 c0             	test   %rax,%rax
   2df42:	0f 84 2a 03 00 00    	je     2e272 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3b2>
   2df48:	48 8b 09             	mov    (%rcx),%rcx
   2df4b:	66 0f 6f 01          	movdqa (%rcx),%xmm0
   2df4f:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2df53:	f7 d7                	not    %edi
   2df55:	48 8d 71 10          	lea    0x10(%rcx),%rsi
   2df59:	31 d2                	xor    %edx,%edx
   2df5b:	eb 36                	jmp    2df93 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xd3>
   2df5d:	0f 1f 00             	nopl   (%rax)
   2df60:	44 8d 47 ff          	lea    -0x1(%rdi),%r8d
   2df64:	f3 44 0f bc cf       	tzcnt  %edi,%r9d
   2df69:	41 21 f8             	and    %edi,%r8d
   2df6c:	41 c1 e1 03          	shl    $0x3,%r9d
   2df70:	48 89 cf             	mov    %rcx,%rdi
   2df73:	4c 29 cf             	sub    %r9,%rdi
   2df76:	4c 63 4f f8          	movslq -0x8(%rdi),%r9
   2df7a:	49 89 d2             	mov    %rdx,%r10
   2df7d:	4d 01 ca             	add    %r9,%r10
   2df80:	48 63 57 fc          	movslq -0x4(%rdi),%rdx
   2df84:	4c 01 d2             	add    %r10,%rdx
   2df87:	44 89 c7             	mov    %r8d,%edi
   2df8a:	48 ff c8             	dec    %rax
   2df8d:	0f 84 e1 02 00 00    	je     2e274 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3b4>
   2df93:	66 85 ff             	test   %di,%di
   2df96:	75 c8                	jne    2df60 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2df98:	0f 1f 84 00 00 00 00 	nopl   0x0(%rax,%rax,1)
   2df9f:	00 
   2dfa0:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2dfa4:	48 83 c1 80          	add    $0xffffffffffffff80,%rcx
   2dfa8:	48 83 c6 10          	add    $0x10,%rsi
   2dfac:	66 0f d7 f8          	pmovmskb %xmm0,%edi
   2dfb0:	66 83 f7 ff          	xor    $0xffff,%di
   2dfb4:	74 ea                	je     2dfa0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xe0>
   2dfb6:	eb a8                	jmp    2df60 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa0>
   2dfb8:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2dfbf:	66 69 72 
   2dfc2:	48 33 08             	xor    (%rax),%rcx
   2dfc5:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2dfc9:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2dfcf:	48 09 c8             	or     %rcx,%rax
   2dfd2:	0f 85 83 08 00 00    	jne    2e85b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x99b>
   2dfd8:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2dfdd:	48 83 78 18 00       	cmpq   $0x0,0x18(%rax)
   2dfe2:	0f 84 77 02 00 00    	je     2e25f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x39f>
   2dfe8:	48 8b 00             	mov    (%rax),%rax
   2dfeb:	66 0f 6f 00          	movdqa (%rax),%xmm0
   2dfef:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2dff3:	66 83 f1 ff          	xor    $0xffff,%cx
   2dff7:	75 1d                	jne    2e016 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x156>
   2dff9:	48 8d 50 10          	lea    0x10(%rax),%rdx
   2dffd:	0f 1f 00             	nopl   (%rax)
   2e000:	66 0f 6f 02          	movdqa (%rdx),%xmm0
   2e004:	48 83 c0 80          	add    $0xffffffffffffff80,%rax
   2e008:	66 0f d7 c8          	pmovmskb %xmm0,%ecx
   2e00c:	48 83 c2 10          	add    $0x10,%rdx
   2e010:	66 83 f1 ff          	xor    $0xffff,%cx
   2e014:	74 ea                	je     2e000 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x140>
   2e016:	f3 0f bc c9          	tzcnt  %ecx,%ecx
   2e01a:	c1 e1 03             	shl    $0x3,%ecx
   2e01d:	48 29 c8             	sub    %rcx,%rax
   2e020:	48 8d 48 f8          	lea    -0x8(%rax),%rcx
   2e024:	48 83 c0 fc          	add    $0xfffffffffffffffc,%rax
   2e028:	e9 34 02 00 00       	jmp    2e261 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3a1>
   2e02d:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e034:	72 65 61 
   2e037:	48 33 08             	xor    (%rax),%rcx
   2e03a:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e03e:	48 83 f0 64          	xor    $0x64,%rax
   2e042:	48 09 c8             	or     %rcx,%rax
   2e045:	0f 85 10 08 00 00    	jne    2e85b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x99b>
   2e04b:	48 c7 c3 d8 ff ff ff 	mov    $0xffffffffffffffd8,%rbx
   2e052:	64 80 7b 10 01       	cmpb   $0x1,%fs:0x10(%rbx)
   2e057:	0f 85 17 08 00 00    	jne    2e874 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9b4>
   2e05d:	64 48 8b 03          	mov    %fs:(%rbx),%rax
   2e061:	64 48 8b 53 08       	mov    %fs:0x8(%rbx),%rdx
   2e066:	48 8d 48 01          	lea    0x1(%rax),%rcx
   2e06a:	64 48 89 0b          	mov    %rcx,%fs:(%rbx)
   2e06e:	0f 10 05 c3 23 04 00 	movups 0x423c3(%rip),%xmm0        # 70438 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x4f8>
   2e075:	0f 29 04 24          	movaps %xmm0,(%rsp)
   2e079:	f3 0f 6f 05 c7 23 04 	movdqu 0x423c7(%rip),%xmm0        # 70448 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x508>
   2e080:	00 
   2e081:	66 0f 7f 44 24 10    	movdqa %xmm0,0x10(%rsp)
   2e087:	48 89 44 24 20       	mov    %rax,0x20(%rsp)
   2e08c:	48 89 54 24 28       	mov    %rdx,0x28(%rsp)
   2e091:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e095:	48 89 44 24 38       	mov    %rax,0x38(%rsp)
   2e09a:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2e09f:	48 8b 44 24 38       	mov    0x38(%rsp),%rax
   2e0a4:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e0a8:	48 85 c9             	test   %rcx,%rcx
   2e0ab:	0f 84 cf 01 00 00    	je     2e280 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3c0>
   2e0b1:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e0b5:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2e0b9:	48 89 e3             	mov    %rsp,%rbx
   2e0bc:	0f 1f 40 00          	nopl   0x0(%rax)
   2e0c0:	41 8b 36             	mov    (%r14),%esi
   2e0c3:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e0c7:	48 89 df             	mov    %rbx,%rdi
   2e0ca:	e8 51 5d 00 00       	call   33e20 <_RNvMs1_NtCs3BTM885nGDo_9hashbrown3mapINtB5_7HashMapllNtNtNtCs8ZKwes1zzDd_3std4hash6random11RandomStateE6insertCs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e0cf:	49 83 c6 08          	add    $0x8,%r14
   2e0d3:	4d 39 fe             	cmp    %r15,%r14
   2e0d6:	75 e8                	jne    2e0c0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x200>
   2e0d8:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e0dc:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e0e1:	48 8b 4c 24 18       	mov    0x18(%rsp),%rcx
   2e0e6:	48 85 c9             	test   %rcx,%rcx
   2e0e9:	0f 84 76 03 00 00    	je     2e465 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x5a5>
   2e0ef:	66 0f 6f 07          	movdqa (%rdi),%xmm0
   2e0f3:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e0f8:	41 f7 d1             	not    %r9d
   2e0fb:	48 8d 77 10          	lea    0x10(%rdi),%rsi
   2e0ff:	31 d2                	xor    %edx,%edx
   2e101:	49 89 f8             	mov    %rdi,%r8
   2e104:	eb 3d                	jmp    2e143 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x283>
   2e106:	66 2e 0f 1f 84 00 00 	cs nopw 0x0(%rax,%rax,1)
   2e10d:	00 00 00 
   2e110:	45 8d 51 ff          	lea    -0x1(%r9),%r10d
   2e114:	f3 45 0f bc d9       	tzcnt  %r9d,%r11d
   2e119:	45 21 ca             	and    %r9d,%r10d
   2e11c:	41 c1 e3 03          	shl    $0x3,%r11d
   2e120:	4d 89 c1             	mov    %r8,%r9
   2e123:	4d 29 d9             	sub    %r11,%r9
   2e126:	4d 63 59 f8          	movslq -0x8(%r9),%r11
   2e12a:	48 89 d3             	mov    %rdx,%rbx
   2e12d:	4c 01 db             	add    %r11,%rbx
   2e130:	49 63 51 fc          	movslq -0x4(%r9),%rdx
   2e134:	48 01 da             	add    %rbx,%rdx
   2e137:	45 89 d1             	mov    %r10d,%r9d
   2e13a:	48 ff c9             	dec    %rcx
   2e13d:	0f 84 24 03 00 00    	je     2e467 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x5a7>
   2e143:	66 45 85 c9          	test   %r9w,%r9w
   2e147:	75 c7                	jne    2e110 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e149:	0f 1f 80 00 00 00 00 	nopl   0x0(%rax)
   2e150:	66 0f 6f 06          	movdqa (%rsi),%xmm0
   2e154:	49 83 c0 80          	add    $0xffffffffffffff80,%r8
   2e158:	48 83 c6 10          	add    $0x10,%rsi
   2e15c:	66 44 0f d7 c8       	pmovmskb %xmm0,%r9d
   2e161:	66 41 83 f1 ff       	xor    $0xffff,%r9w
   2e166:	74 e8                	je     2e150 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x290>
   2e168:	eb a6                	jmp    2e110 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x250>
   2e16a:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e171:	63 6f 6c 
   2e174:	48 33 08             	xor    (%rax),%rcx
   2e177:	8b 40 08             	mov    0x8(%rax),%eax
   2e17a:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e180:	48 09 c8             	or     %rcx,%rax
   2e183:	0f 85 d2 06 00 00    	jne    2e85b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x99b>
   2e189:	48 8b 44 24 30       	mov    0x30(%rsp),%rax
   2e18e:	48 8b 48 18          	mov    0x18(%rax),%rcx
   2e192:	48 85 c9             	test   %rcx,%rcx
   2e195:	0f 84 f8 00 00 00    	je     2e293 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3d3>
   2e19b:	4c 8b 28             	mov    (%rax),%r13
   2e19e:	66 41 0f 6f 45 00    	movdqa 0x0(%r13),%xmm0
   2e1a4:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e1a9:	49 8d 6d 10          	lea    0x10(%r13),%rbp
   2e1ad:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e1b2:	75 25                	jne    2e1d9 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x319>
   2e1b4:	66 66 66 2e 0f 1f 84 	data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e1bb:	00 00 00 00 00 
   2e1c0:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e1c5:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e1c9:	48 83 c5 10          	add    $0x10,%rbp
   2e1cd:	66 44 0f d7 e0       	pmovmskb %xmm0,%r12d
   2e1d2:	66 41 83 f4 ff       	xor    $0xffff,%r12w
   2e1d7:	74 e7                	je     2e1c0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x300>
   2e1d9:	48 83 f9 05          	cmp    $0x5,%rcx
   2e1dd:	bb 04 00 00 00       	mov    $0x4,%ebx
   2e1e2:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e1e8:	4c 0f 43 f9          	cmovae %rcx,%r15
   2e1ec:	4e 8d 34 fd 00 00 00 	lea    0x0(,%r15,8),%r14
   2e1f3:	00 
   2e1f4:	48 b8 fe ff ff ff ff 	movabs $0x1ffffffffffffffe,%rax
   2e1fb:	ff ff 1f 
   2e1fe:	48 ff c0             	inc    %rax
   2e201:	48 89 4c 24 50       	mov    %rcx,0x50(%rsp)
   2e206:	48 39 c1             	cmp    %rax,%rcx
   2e209:	0f 97 c0             	seta   %al
   2e20c:	48 b9 f1 ff ff ff ff 	movabs $0x7ffffffffffffff1,%rcx
   2e213:	ff ff 7f 
   2e216:	48 83 c1 0b          	add    $0xb,%rcx
   2e21a:	49 39 ce             	cmp    %rcx,%r14
   2e21d:	0f 97 c1             	seta   %cl
   2e220:	08 c1                	or     %al,%cl
   2e222:	0f 84 3d 01 00 00    	je     2e365 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x4a5>
   2e228:	31 db                	xor    %ebx,%ebx
   2e22a:	48 89 df             	mov    %rbx,%rdi
   2e22d:	4c 89 f6             	mov    %r14,%rsi
   2e230:	ff 15 d2 3e 04 00    	call   *0x43ed2(%rip)        # 72108 <_DYNAMIC+0x230>
   2e236:	48 8b 47 08          	mov    0x8(%rdi),%rax
   2e23a:	48 89 44 24 58       	mov    %rax,0x58(%rsp)
   2e23f:	48 8d 44 24 58       	lea    0x58(%rsp),%rax
   2e244:	48 8b 44 24 58       	mov    0x58(%rsp),%rax
   2e249:	4c 8b 30             	mov    (%rax),%r14
   2e24c:	4d 85 f6             	test   %r14,%r14
   2e24f:	74 4f                	je     2e2a0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3e0>
   2e251:	49 8b 76 08          	mov    0x8(%r14),%rsi
   2e255:	49 8b 5e 10          	mov    0x10(%r14),%rbx
   2e259:	49 83 c6 18          	add    $0x18,%r14
   2e25d:	eb 46                	jmp    2e2a5 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x3e5>
   2e25f:	31 c9                	xor    %ecx,%ecx
   2e261:	48 89 0c 24          	mov    %rcx,(%rsp)
   2e265:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e26a:	48 89 e0             	mov    %rsp,%rax
   2e26d:	e9 a3 06 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e272:	31 d2                	xor    %edx,%edx
   2e274:	48 89 14 24          	mov    %rdx,(%rsp)
   2e278:	48 89 e0             	mov    %rsp,%rax
   2e27b:	e9 95 06 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e280:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2e287:	00 00 
   2e289:	48 8d 44 24 38       	lea    0x38(%rsp),%rax
   2e28e:	e9 82 06 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e293:	b8 04 00 00 00       	mov    $0x4,%eax
   2e298:	45 31 ff             	xor    %r15d,%r15d
   2e29b:	e9 61 04 00 00       	jmp    2e701 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2e2a0:	45 31 f6             	xor    %r14d,%r14d
   2e2a3:	31 f6                	xor    %esi,%esi
   2e2a5:	48 8b 47 10          	mov    0x10(%rdi),%rax
   2e2a9:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e2ad:	48 83 c1 f8          	add    $0xfffffffffffffff8,%rcx
   2e2b1:	48 83 f9 04          	cmp    $0x4,%rcx
   2e2b5:	0f 87 d4 05 00 00    	ja     2e88f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9cf>
   2e2bb:	48 8b 40 08          	mov    0x8(%rax),%rax
   2e2bf:	48 8d 15 4e b0 fd ff 	lea    -0x24fb2(%rip),%rdx        # 9314 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x4d>
   2e2c6:	48 63 0c 8a          	movslq (%rdx,%rcx,4),%rcx
   2e2ca:	48 01 d1             	add    %rdx,%rcx
   2e2cd:	ff e1                	jmp    *%rcx
   2e2cf:	48 b9 69 74 65 72 5f 	movabs $0x6c6c615f72657469,%rcx
   2e2d6:	61 6c 6c 
   2e2d9:	48 39 08             	cmp    %rcx,(%rax)
   2e2dc:	0f 85 ad 05 00 00    	jne    2e88f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9cf>
   2e2e2:	48 85 f6             	test   %rsi,%rsi
   2e2e5:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e2eb:	4c 0f 45 fe          	cmovne %rsi,%r15
   2e2ef:	45 31 ed             	xor    %r13d,%r13d
   2e2f2:	48 85 db             	test   %rbx,%rbx
   2e2f5:	74 62                	je     2e359 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x499>
   2e2f7:	48 85 f6             	test   %rsi,%rsi
   2e2fa:	74 5d                	je     2e359 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x499>
   2e2fc:	48 83 fb 10          	cmp    $0x10,%rbx
   2e300:	0f 92 c0             	setb   %al
   2e303:	4d 85 f6             	test   %r14,%r14
   2e306:	0f 94 c1             	sete   %cl
   2e309:	08 c1                	or     %al,%cl
   2e30b:	0f 84 56 04 00 00    	je     2e767 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8a7>
   2e311:	48 8d 04 de          	lea    (%rsi,%rbx,8),%rax
   2e315:	45 31 ed             	xor    %r13d,%r13d
   2e318:	31 c9                	xor    %ecx,%ecx
   2e31a:	eb 14                	jmp    2e330 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x470>
   2e31c:	49 63 14 d7          	movslq (%r15,%rdx,8),%rdx
   2e320:	49 63 74 cf fc       	movslq -0x4(%r15,%rcx,8),%rsi
   2e325:	49 01 d5             	add    %rdx,%r13
   2e328:	49 01 f5             	add    %rsi,%r13
   2e32b:	48 39 d9             	cmp    %rbx,%rcx
   2e32e:	73 29                	jae    2e359 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x499>
   2e330:	48 89 ca             	mov    %rcx,%rdx
   2e333:	48 8d 4a 01          	lea    0x1(%rdx),%rcx
   2e337:	49 8d 34 d7          	lea    (%r15,%rdx,8),%rsi
   2e33b:	48 83 c6 08          	add    $0x8,%rsi
   2e33f:	90                   	nop
   2e340:	48 39 c6             	cmp    %rax,%rsi
   2e343:	74 d7                	je     2e31c <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x45c>
   2e345:	8b 3e                	mov    (%rsi),%edi
   2e347:	48 83 c6 08          	add    $0x8,%rsi
   2e34b:	41 3b 3c d7          	cmp    (%r15,%rdx,8),%edi
   2e34f:	75 ef                	jne    2e340 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x480>
   2e351:	48 89 ca             	mov    %rcx,%rdx
   2e354:	48 39 d9             	cmp    %rbx,%rcx
   2e357:	75 da                	jne    2e333 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x473>
   2e359:	4c 89 2c 24          	mov    %r13,(%rsp)
   2e35d:	48 89 e0             	mov    %rsp,%rax
   2e360:	e9 b0 05 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e365:	f3 41 0f bc c4       	tzcnt  %r12d,%eax
   2e36a:	c1 e0 03             	shl    $0x3,%eax
   2e36d:	4c 89 e9             	mov    %r13,%rcx
   2e370:	48 29 c1             	sub    %rax,%rcx
   2e373:	f3 0f 7e 41 f8       	movq   -0x8(%rcx),%xmm0
   2e378:	66 0f 7f 44 24 60    	movdqa %xmm0,0x60(%rsp)
   2e37e:	4c 89 f7             	mov    %r14,%rdi
   2e381:	ff 15 39 3d 04 00    	call   *0x43d39(%rip)        # 720c0 <malloc@GLIBC_2.2.5>
   2e387:	48 85 c0             	test   %rax,%rax
   2e38a:	0f 84 9a fe ff ff    	je     2e22a <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x36a>
   2e390:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e395:	48 89 cb             	mov    %rcx,%rbx
   2e398:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e39e:	66 0f d6 00          	movq   %xmm0,(%rax)
   2e3a2:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e3a6:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e3ab:	48 c7 44 24 10 01 00 	movq   $0x1,0x10(%rsp)
   2e3b2:	00 00 
   2e3b4:	48 ff cb             	dec    %rbx
   2e3b7:	0f 84 44 03 00 00    	je     2e701 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x841>
   2e3bd:	45 8d 7c 24 ff       	lea    -0x1(%r12),%r15d
   2e3c2:	45 21 e7             	and    %r12d,%r15d
   2e3c5:	41 be 01 00 00 00    	mov    $0x1,%r14d
   2e3cb:	49 89 e4             	mov    %rsp,%r12
   2e3ce:	eb 2f                	jmp    2e3ff <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x53f>
   2e3d0:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e3d5:	41 8d 4f ff          	lea    -0x1(%r15),%ecx
   2e3d9:	44 21 f9             	and    %r15d,%ecx
   2e3dc:	48 ff cb             	dec    %rbx
   2e3df:	66 0f 6f 44 24 60    	movdqa 0x60(%rsp),%xmm0
   2e3e5:	66 42 0f d6 04 f0    	movq   %xmm0,(%rax,%r14,8)
   2e3eb:	49 ff c6             	inc    %r14
   2e3ee:	4c 89 74 24 10       	mov    %r14,0x10(%rsp)
   2e3f3:	41 89 cf             	mov    %ecx,%r15d
   2e3f6:	48 85 db             	test   %rbx,%rbx
   2e3f9:	0f 84 f4 02 00 00    	je     2e6f3 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x833>
   2e3ff:	66 45 85 ff          	test   %r15w,%r15w
   2e403:	75 24                	jne    2e429 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x569>
   2e405:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e40c:	00 00 00 00 
   2e410:	66 0f 6f 45 00       	movdqa 0x0(%rbp),%xmm0
   2e415:	49 83 c5 80          	add    $0xffffffffffffff80,%r13
   2e419:	48 83 c5 10          	add    $0x10,%rbp
   2e41d:	66 44 0f d7 f8       	pmovmskb %xmm0,%r15d
   2e422:	66 41 83 f7 ff       	xor    $0xffff,%r15w
   2e427:	74 e7                	je     2e410 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x550>
   2e429:	f3 41 0f bc cf       	tzcnt  %r15d,%ecx
   2e42e:	c1 e1 03             	shl    $0x3,%ecx
   2e431:	4c 89 ea             	mov    %r13,%rdx
   2e434:	48 29 ca             	sub    %rcx,%rdx
   2e437:	f2 0f 10 42 f8       	movsd  -0x8(%rdx),%xmm0
   2e43c:	0f 29 44 24 60       	movaps %xmm0,0x60(%rsp)
   2e441:	4c 3b 34 24          	cmp    (%rsp),%r14
   2e445:	75 8e                	jne    2e3d5 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x515>
   2e447:	b9 04 00 00 00       	mov    $0x4,%ecx
   2e44c:	41 b8 08 00 00 00    	mov    $0x8,%r8d
   2e452:	4c 89 e7             	mov    %r12,%rdi
   2e455:	4c 89 f6             	mov    %r14,%rsi
   2e458:	48 89 da             	mov    %rbx,%rdx
   2e45b:	e8 20 ea ff ff       	call   2ce80 <_RINvNvMs2_NtCsgFX3jaOk65H_5alloc7raw_vecINtB8_11RawVecInnerpE7reserve21do_reserve_and_handleNtNtBa_5alloc6GlobalECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e460:	e9 6b ff ff ff       	jmp    2e3d0 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x510>
   2e465:	31 d2                	xor    %edx,%edx
   2e467:	48 89 54 24 38       	mov    %rdx,0x38(%rsp)
   2e46c:	48 8d 4c 24 38       	lea    0x38(%rsp),%rcx
   2e471:	48 85 c0             	test   %rax,%rax
   2e474:	0f 84 9b 04 00 00    	je     2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e47a:	48 8d 0c c5 00 00 00 	lea    0x0(,%rax,8),%rcx
   2e481:	00 
   2e482:	48 83 e1 f0          	and    $0xfffffffffffffff0,%rcx
   2e486:	48 01 c8             	add    %rcx,%rax
   2e489:	48 83 f8 df          	cmp    $0xffffffffffffffdf,%rax
   2e48d:	0f 84 82 04 00 00    	je     2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e493:	48 29 cf             	sub    %rcx,%rdi
   2e496:	48 83 c7 f0          	add    $0xfffffffffffffff0,%rdi
   2e49a:	ff 15 30 3c 04 00    	call   *0x43c30(%rip)        # 720d0 <free@GLIBC_2.2.5>
   2e4a0:	e9 70 04 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e4a5:	48 b9 69 74 65 72 5f 	movabs $0x7269665f72657469,%rcx
   2e4ac:	66 69 72 
   2e4af:	48 33 08             	xor    (%rax),%rcx
   2e4b2:	0f b7 40 08          	movzwl 0x8(%rax),%eax
   2e4b6:	48 35 73 74 00 00    	xor    $0x7473,%rax
   2e4bc:	48 09 c8             	or     %rcx,%rax
   2e4bf:	0f 85 ca 03 00 00    	jne    2e88f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9cf>
   2e4c5:	48 85 f6             	test   %rsi,%rsi
   2e4c8:	41 bc 04 00 00 00    	mov    $0x4,%r12d
   2e4ce:	4c 0f 45 e6          	cmovne %rsi,%r12
   2e4d2:	45 31 ff             	xor    %r15d,%r15d
   2e4d5:	48 85 db             	test   %rbx,%rbx
   2e4d8:	0f 84 28 04 00 00    	je     2e906 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa46>
   2e4de:	48 85 f6             	test   %rsi,%rsi
   2e4e1:	0f 84 1f 04 00 00    	je     2e906 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa46>
   2e4e7:	48 83 fb 10          	cmp    $0x10,%rbx
   2e4eb:	0f 92 c0             	setb   %al
   2e4ee:	4d 85 f6             	test   %r14,%r14
   2e4f1:	0f 94 c1             	sete   %cl
   2e4f4:	08 c1                	or     %al,%cl
   2e4f6:	0f 84 49 02 00 00    	je     2e745 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x885>
   2e4fc:	48 8d 0c de          	lea    (%rsi,%rbx,8),%rcx
   2e500:	31 d2                	xor    %edx,%edx
   2e502:	49 8d 04 d4          	lea    (%r12,%rdx,8),%rax
   2e506:	49 8d 34 d4          	lea    (%r12,%rdx,8),%rsi
   2e50a:	48 83 c6 08          	add    $0x8,%rsi
   2e50e:	48 ff c2             	inc    %rdx
   2e511:	66 66 66 66 66 66 2e 	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e518:	0f 1f 84 00 00 00 00 
   2e51f:	00 
   2e520:	48 39 ce             	cmp    %rcx,%rsi
   2e523:	0f 84 ba 02 00 00    	je     2e7e3 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x923>
   2e529:	8b 3e                	mov    (%rsi),%edi
   2e52b:	48 83 c6 08          	add    $0x8,%rsi
   2e52f:	3b 38                	cmp    (%rax),%edi
   2e531:	75 ed                	jne    2e520 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x660>
   2e533:	45 31 ff             	xor    %r15d,%r15d
   2e536:	48 39 da             	cmp    %rbx,%rdx
   2e539:	75 c7                	jne    2e502 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x642>
   2e53b:	e9 c6 03 00 00       	jmp    2e906 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa46>
   2e540:	48 b9 63 6f 6c 64 5f 	movabs $0x6165725f646c6f63,%rcx
   2e547:	72 65 61 
   2e54a:	48 33 08             	xor    (%rax),%rcx
   2e54d:	0f b6 40 08          	movzbl 0x8(%rax),%eax
   2e551:	48 83 f0 64          	xor    $0x64,%rax
   2e555:	48 09 c8             	or     %rcx,%rax
   2e558:	0f 85 31 03 00 00    	jne    2e88f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9cf>
   2e55e:	48 c7 44 24 38 00 00 	movq   $0x0,0x38(%rsp)
   2e565:	00 00 
   2e567:	48 8b 47 18          	mov    0x18(%rdi),%rax
   2e56b:	48 89 04 24          	mov    %rax,(%rsp)
   2e56f:	48 89 e0             	mov    %rsp,%rax
   2e572:	48 8b 04 24          	mov    (%rsp),%rax
   2e576:	48 8b 48 10          	mov    0x10(%rax),%rcx
   2e57a:	48 85 c9             	test   %rcx,%rcx
   2e57d:	0f 84 aa 01 00 00    	je     2e72d <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2e583:	4c 8b 70 08          	mov    0x8(%rax),%r14
   2e587:	4d 8d 3c ce          	lea    (%r14,%rcx,8),%r15
   2e58b:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2e590:	41 8b 36             	mov    (%r14),%esi
   2e593:	41 8b 56 04          	mov    0x4(%r14),%edx
   2e597:	48 89 df             	mov    %rbx,%rdi
   2e59a:	e8 e1 6d 00 00       	call   35380 <_RNvMso_NtCsa9EZGJKk8MG_4pbrs3mapINtB5_3MapllE10push_entryCs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e59f:	49 83 c6 08          	add    $0x8,%r14
   2e5a3:	4d 39 fe             	cmp    %r15,%r14
   2e5a6:	75 e8                	jne    2e590 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x6d0>
   2e5a8:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   2e5ad:	48 85 db             	test   %rbx,%rbx
   2e5b0:	0f 84 77 01 00 00    	je     2e72d <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x86d>
   2e5b6:	4c 8b 73 10          	mov    0x10(%rbx),%r14
   2e5ba:	4d 85 f6             	test   %r14,%r14
   2e5bd:	0f 84 6c 01 00 00    	je     2e72f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x86f>
   2e5c3:	4c 8b 7b 08          	mov    0x8(%rbx),%r15
   2e5c7:	49 83 fe 10          	cmp    $0x10,%r14
   2e5cb:	0f 83 1b 02 00 00    	jae    2e7ec <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x92c>
   2e5d1:	49 8d 47 08          	lea    0x8(%r15),%rax
   2e5d5:	4a 8d 0c f5 f8 ff ff 	lea    -0x8(,%r14,8),%rcx
   2e5dc:	ff 
   2e5dd:	31 ed                	xor    %ebp,%ebp
   2e5df:	31 d2                	xor    %edx,%edx
   2e5e1:	eb 1b                	jmp    2e5fe <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x73e>
   2e5e3:	4b 63 34 c7          	movslq (%r15,%r8,8),%rsi
   2e5e7:	48 89 ef             	mov    %rbp,%rdi
   2e5ea:	48 01 f7             	add    %rsi,%rdi
   2e5ed:	49 63 6c d7 fc       	movslq -0x4(%r15,%rdx,8),%rbp
   2e5f2:	48 01 fd             	add    %rdi,%rbp
   2e5f5:	4c 39 f2             	cmp    %r14,%rdx
   2e5f8:	0f 83 33 01 00 00    	jae    2e731 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e5fe:	48 8d 3c d5 00 00 00 	lea    0x0(,%rdx,8),%rdi
   2e605:	00 
   2e606:	48 89 ce             	mov    %rcx,%rsi
   2e609:	48 29 fe             	sub    %rdi,%rsi
   2e60c:	48 8d 3c d0          	lea    (%rax,%rdx,8),%rdi
   2e610:	49 89 d0             	mov    %rdx,%r8
   2e613:	48 ff c2             	inc    %rdx
   2e616:	4c 39 f2             	cmp    %r14,%rdx
   2e619:	74 c8                	je     2e5e3 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e61b:	47 8b 0c c7          	mov    (%r15,%r8,8),%r9d
   2e61f:	45 31 d2             	xor    %r10d,%r10d
   2e622:	66 66 66 66 66 2e 0f 	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   2e629:	1f 84 00 00 00 00 00 
   2e630:	46 39 0c 17          	cmp    %r9d,(%rdi,%r10,1)
   2e634:	74 0b                	je     2e641 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x781>
   2e636:	49 83 c2 08          	add    $0x8,%r10
   2e63a:	4c 39 d6             	cmp    %r10,%rsi
   2e63d:	75 f1                	jne    2e630 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x770>
   2e63f:	eb a2                	jmp    2e5e3 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e641:	48 83 c7 08          	add    $0x8,%rdi
   2e645:	48 83 c6 f8          	add    $0xfffffffffffffff8,%rsi
   2e649:	49 89 d0             	mov    %rdx,%r8
   2e64c:	48 ff c2             	inc    %rdx
   2e64f:	4c 39 f2             	cmp    %r14,%rdx
   2e652:	75 c7                	jne    2e61b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x75b>
   2e654:	eb 8d                	jmp    2e5e3 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x723>
   2e656:	48 b9 69 74 65 72 5f 	movabs $0x6c6f635f72657469,%rcx
   2e65d:	63 6f 6c 
   2e660:	48 33 08             	xor    (%rax),%rcx
   2e663:	8b 40 08             	mov    0x8(%rax),%eax
   2e666:	48 35 6c 65 63 74    	xor    $0x7463656c,%rax
   2e66c:	48 09 c8             	or     %rcx,%rax
   2e66f:	0f 85 1a 02 00 00    	jne    2e88f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9cf>
   2e675:	48 85 f6             	test   %rsi,%rsi
   2e678:	41 bf 04 00 00 00    	mov    $0x4,%r15d
   2e67e:	4c 0f 45 fe          	cmovne %rsi,%r15
   2e682:	48 0f 44 de          	cmove  %rsi,%rbx
   2e686:	31 c0                	xor    %eax,%eax
   2e688:	48 85 db             	test   %rbx,%rbx
   2e68b:	74 1a                	je     2e6a7 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e68d:	4d 85 f6             	test   %r14,%r14
   2e690:	74 15                	je     2e6a7 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e692:	48 83 fb 10          	cmp    $0x10,%rbx
   2e696:	72 0f                	jb     2e6a7 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x7e7>
   2e698:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e69c:	85 c0                	test   %eax,%eax
   2e69e:	0f 85 04 02 00 00    	jne    2e8a8 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9e8>
   2e6a4:	4c 89 f0             	mov    %r14,%rax
   2e6a7:	48 c7 04 24 00 00 00 	movq   $0x0,(%rsp)
   2e6ae:	00 
   2e6af:	4c 89 7c 24 08       	mov    %r15,0x8(%rsp)
   2e6b4:	48 89 5c 24 10       	mov    %rbx,0x10(%rsp)
   2e6b9:	48 89 44 24 18       	mov    %rax,0x18(%rsp)
   2e6be:	48 c7 44 24 20 00 00 	movq   $0x0,0x20(%rsp)
   2e6c5:	00 00 
   2e6c7:	48 8d 5c 24 38       	lea    0x38(%rsp),%rbx
   2e6cc:	48 89 e6             	mov    %rsp,%rsi
   2e6cf:	48 89 df             	mov    %rbx,%rdi
   2e6d2:	e8 49 71 00 00       	call   35820 <_RNvXNtNtCsgFX3jaOk65H_5alloc3vec21spec_from_iter_nestedINtB4_3VecTllEEINtB2_18SpecFromIterNestedB11_INtNtCsa9EZGJKk8MG_4pbrs3map11MapViewIterllEE9from_iterCs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e6d7:	48 83 7c 24 38 00    	cmpq   $0x0,0x38(%rsp)
   2e6dd:	0f 84 32 02 00 00    	je     2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e6e3:	48 8b 7c 24 40       	mov    0x40(%rsp),%rdi
   2e6e8:	ff 15 e2 39 04 00    	call   *0x439e2(%rip)        # 720d0 <free@GLIBC_2.2.5>
   2e6ee:	e9 22 02 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e6f3:	4c 8b 3c 24          	mov    (%rsp),%r15
   2e6f7:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e6fc:	48 8b 4c 24 50       	mov    0x50(%rsp),%rcx
   2e701:	4c 89 3c 24          	mov    %r15,(%rsp)
   2e705:	48 89 44 24 08       	mov    %rax,0x8(%rsp)
   2e70a:	48 89 4c 24 10       	mov    %rcx,0x10(%rsp)
   2e70f:	48 89 e0             	mov    %rsp,%rax
   2e712:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e717:	0f 84 f8 01 00 00    	je     2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e71d:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e722:	ff 15 a8 39 04 00    	call   *0x439a8(%rip)        # 720d0 <free@GLIBC_2.2.5>
   2e728:	e9 e8 01 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e72d:	31 db                	xor    %ebx,%ebx
   2e72f:	31 ed                	xor    %ebp,%ebp
   2e731:	48 89 2c 24          	mov    %rbp,(%rsp)
   2e735:	48 89 e0             	mov    %rsp,%rax
   2e738:	48 89 df             	mov    %rbx,%rdi
   2e73b:	e8 e0 ba ff ff       	call   2a220 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsa9EZGJKk8MG_4pbrs3map3MapllEECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e740:	e9 d0 01 00 00       	jmp    2e915 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa55>
   2e745:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e749:	85 c0                	test   %eax,%eax
   2e74b:	0f 85 6a 01 00 00    	jne    2e8bb <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x9fb>
   2e751:	49 39 5e 10          	cmp    %rbx,0x10(%r14)
   2e755:	0f 85 7b 01 00 00    	jne    2e8d6 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa16>
   2e75b:	48 83 c6 04          	add    $0x4,%rsi
   2e75f:	4c 89 e0             	mov    %r12,%rax
   2e762:	e9 93 01 00 00       	jmp    2e8fa <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa3a>
   2e767:	41 8b 46 20          	mov    0x20(%r14),%eax
   2e76b:	85 c0                	test   %eax,%eax
   2e76d:	0f 85 b1 01 00 00    	jne    2e924 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa64>
   2e773:	45 31 c0             	xor    %r8d,%r8d
   2e776:	49 89 e4             	mov    %rsp,%r12
   2e779:	48 8b 2d 30 3d 04 00 	mov    0x43d30(%rip),%rbp        # 724b0 <_DYNAMIC+0x5d8>
   2e780:	45 31 ed             	xor    %r13d,%r13d
   2e783:	eb 17                	jmp    2e79c <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8dc>
   2e785:	66 66 2e 0f 1f 84 00 	data16 cs nopw 0x0(%rax,%rax,1)
   2e78c:	00 00 00 00 
   2e790:	48 63 00             	movslq (%rax),%rax
   2e793:	48 63 09             	movslq (%rcx),%rcx
   2e796:	49 01 c5             	add    %rax,%r13
   2e799:	49 01 cd             	add    %rcx,%r13
   2e79c:	49 39 5e 10          	cmp    %rbx,0x10(%r14)
   2e7a0:	75 1a                	jne    2e7bc <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8fc>
   2e7a2:	49 39 d8             	cmp    %rbx,%r8
   2e7a5:	0f 83 ae fb ff ff    	jae    2e359 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x499>
   2e7ab:	4b 8d 04 c7          	lea    (%r15,%r8,8),%rax
   2e7af:	4b 8d 0c c7          	lea    (%r15,%r8,8),%rcx
   2e7b3:	48 83 c1 04          	add    $0x4,%rcx
   2e7b7:	49 ff c0             	inc    %r8
   2e7ba:	eb d4                	jmp    2e790 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8d0>
   2e7bc:	4c 89 e7             	mov    %r12,%rdi
   2e7bf:	4c 89 fe             	mov    %r15,%rsi
   2e7c2:	48 89 da             	mov    %rbx,%rdx
   2e7c5:	4c 89 f1             	mov    %r14,%rcx
   2e7c8:	ff d5                	call   *%rbp
   2e7ca:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e7cf:	48 85 c0             	test   %rax,%rax
   2e7d2:	0f 84 81 fb ff ff    	je     2e359 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x499>
   2e7d8:	4c 8b 04 24          	mov    (%rsp),%r8
   2e7dc:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   2e7e1:	eb ad                	jmp    2e790 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8d0>
   2e7e3:	48 8d 70 04          	lea    0x4(%rax),%rsi
   2e7e7:	e9 0e 01 00 00       	jmp    2e8fa <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa3a>
   2e7ec:	8b 43 38             	mov    0x38(%rbx),%eax
   2e7ef:	85 c0                	test   %eax,%eax
   2e7f1:	0f 85 3d 01 00 00    	jne    2e934 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa74>
   2e7f7:	45 31 c0             	xor    %r8d,%r8d
   2e7fa:	49 89 e5             	mov    %rsp,%r13
   2e7fd:	4c 8b 25 ac 3c 04 00 	mov    0x43cac(%rip),%r12        # 724b0 <_DYNAMIC+0x5d8>
   2e804:	31 ed                	xor    %ebp,%ebp
   2e806:	eb 24                	jmp    2e82c <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x96c>
   2e808:	4d 39 f0             	cmp    %r14,%r8
   2e80b:	0f 83 20 ff ff ff    	jae    2e731 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e811:	4b 8d 04 c7          	lea    (%r15,%r8,8),%rax
   2e815:	4b 8d 0c c7          	lea    (%r15,%r8,8),%rcx
   2e819:	48 83 c1 04          	add    $0x4,%rcx
   2e81d:	49 ff c0             	inc    %r8
   2e820:	48 63 00             	movslq (%rax),%rax
   2e823:	48 63 09             	movslq (%rcx),%rcx
   2e826:	48 01 c5             	add    %rax,%rbp
   2e829:	48 01 cd             	add    %rcx,%rbp
   2e82c:	4c 39 73 28          	cmp    %r14,0x28(%rbx)
   2e830:	74 d6                	je     2e808 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x948>
   2e832:	4c 89 ef             	mov    %r13,%rdi
   2e835:	4c 89 fe             	mov    %r15,%rsi
   2e838:	4c 89 f2             	mov    %r14,%rdx
   2e83b:	48 8d 4b 18          	lea    0x18(%rbx),%rcx
   2e83f:	41 ff d4             	call   *%r12
   2e842:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e847:	48 85 c0             	test   %rax,%rax
   2e84a:	0f 84 e1 fe ff ff    	je     2e731 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x871>
   2e850:	4c 8b 04 24          	mov    (%rsp),%r8
   2e854:	48 8b 4c 24 10       	mov    0x10(%rsp),%rcx
   2e859:	eb c5                	jmp    2e820 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x960>
   2e85b:	48 8d 3d 02 ab fd ff 	lea    -0x254fe(%rip),%rdi        # 9364 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e862:	48 8d 15 0f 1e 04 00 	lea    0x41e0f(%rip),%rdx        # 70678 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x738>
   2e869:	be 28 00 00 00       	mov    $0x28,%esi
   2e86e:	ff 15 1c 3a 04 00    	call   *0x43a1c(%rip)        # 72290 <_DYNAMIC+0x3b8>
   2e874:	49 89 fe             	mov    %rdi,%r14
   2e877:	ff 15 6b 3c 04 00    	call   *0x43c6b(%rip)        # 724e8 <_DYNAMIC+0x610>
   2e87d:	4c 89 f7             	mov    %r14,%rdi
   2e880:	64 48 89 53 08       	mov    %rdx,%fs:0x8(%rbx)
   2e885:	64 c6 43 10 01       	movb   $0x1,%fs:0x10(%rbx)
   2e88a:	e9 d7 f7 ff ff       	jmp    2e066 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x1a6>
   2e88f:	48 8d 3d ce aa fd ff 	lea    -0x25532(%rip),%rdi        # 9364 <_RNvNtCs1K02ZgDXpJi_12panic_unwind3imp6CANARY.llvm.7142448216089381218+0x9d>
   2e896:	48 8d 15 f3 1d 04 00 	lea    0x41df3(%rip),%rdx        # 70690 <anon.821506ce466ee6646de7777fa3b94a42.2.llvm.17558855145083318336+0x750>
   2e89d:	be 28 00 00 00       	mov    $0x28,%esi
   2e8a2:	ff 15 e8 39 04 00    	call   *0x439e8(%rip)        # 72290 <_DYNAMIC+0x3b8>
   2e8a8:	4c 89 f7             	mov    %r14,%rdi
   2e8ab:	4c 89 fe             	mov    %r15,%rsi
   2e8ae:	48 89 da             	mov    %rbx,%rdx
   2e8b1:	e8 f6 aa ff ff       	call   293ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsa9EZGJKk8MG_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e8b6:	e9 e9 fd ff ff       	jmp    2e6a4 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x7e4>
   2e8bb:	4c 89 f7             	mov    %r14,%rdi
   2e8be:	49 89 f7             	mov    %rsi,%r15
   2e8c1:	48 89 da             	mov    %rbx,%rdx
   2e8c4:	e8 e3 aa ff ff       	call   293ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsa9EZGJKk8MG_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e8c9:	4c 89 fe             	mov    %r15,%rsi
   2e8cc:	49 39 5e 10          	cmp    %rbx,0x10(%r14)
   2e8d0:	0f 84 85 fe ff ff    	je     2e75b <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x89b>
   2e8d6:	45 31 ff             	xor    %r15d,%r15d
   2e8d9:	48 89 e7             	mov    %rsp,%rdi
   2e8dc:	48 89 da             	mov    %rbx,%rdx
   2e8df:	4c 89 f1             	mov    %r14,%rcx
   2e8e2:	45 31 c0             	xor    %r8d,%r8d
   2e8e5:	ff 15 c5 3b 04 00    	call   *0x43bc5(%rip)        # 724b0 <_DYNAMIC+0x5d8>
   2e8eb:	48 8b 44 24 08       	mov    0x8(%rsp),%rax
   2e8f0:	48 85 c0             	test   %rax,%rax
   2e8f3:	74 11                	je     2e906 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa46>
   2e8f5:	48 8b 74 24 10       	mov    0x10(%rsp),%rsi
   2e8fa:	8b 38                	mov    (%rax),%edi
   2e8fc:	8b 06                	mov    (%rsi),%eax
   2e8fe:	41 bf 01 00 00 00    	mov    $0x1,%r15d
   2e904:	eb 00                	jmp    2e906 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xa46>
   2e906:	44 89 3c 24          	mov    %r15d,(%rsp)
   2e90a:	89 7c 24 04          	mov    %edi,0x4(%rsp)
   2e90e:	89 44 24 08          	mov    %eax,0x8(%rsp)
   2e912:	48 89 e0             	mov    %rsp,%rax
   2e915:	48 83 c4 78          	add    $0x78,%rsp
   2e919:	5b                   	pop    %rbx
   2e91a:	41 5c                	pop    %r12
   2e91c:	41 5d                	pop    %r13
   2e91e:	41 5e                	pop    %r14
   2e920:	41 5f                	pop    %r15
   2e922:	5d                   	pop    %rbp
   2e923:	c3                   	ret
   2e924:	4c 89 f7             	mov    %r14,%rdi
   2e927:	48 89 da             	mov    %rbx,%rdx
   2e92a:	e8 7d aa ff ff       	call   293ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsa9EZGJKk8MG_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e92f:	e9 3f fe ff ff       	jmp    2e773 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x8b3>
   2e934:	48 8d 7b 18          	lea    0x18(%rbx),%rdi
   2e938:	4c 89 fe             	mov    %r15,%rsi
   2e93b:	4c 89 f2             	mov    %r14,%rdx
   2e93e:	e8 69 aa ff ff       	call   293ac <_RINvMNtNtCs8ZKwes1zzDd_3std4sync9once_lockINtB3_8OnceLockINtNtCsa9EZGJKk8MG_4pbrs3map13LastWinsIndexlEE10initializeNCINvB2_11get_or_initNCINvBW_9hot_indexllE0E0zECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e943:	e9 af fe ff ff       	jmp    2e7f7 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0x937>
   2e948:	49 89 c6             	mov    %rax,%r14
   2e94b:	eb 2a                	jmp    2e977 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xab7>
   2e94d:	49 89 c6             	mov    %rax,%r14
   2e950:	eb 25                	jmp    2e977 <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xab7>
   2e952:	49 89 c6             	mov    %rax,%r14
   2e955:	48 83 3c 24 00       	cmpq   $0x0,(%rsp)
   2e95a:	74 23                	je     2e97f <_RNCNvCs4mZnWWL4Zvj_24pbrs_map_iteration_proof4mains1_0B3_+0xabf>
   2e95c:	48 8b 7c 24 08       	mov    0x8(%rsp),%rdi
   2e961:	ff 15 69 37 04 00    	call   *0x43769(%rip)        # 720d0 <free@GLIBC_2.2.5>
   2e967:	4c 89 f7             	mov    %r14,%rdi
   2e96a:	e8 31 ff 03 00       	call   6e8a0 <_Unwind_Resume@plt>
   2e96f:	49 89 c6             	mov    %rax,%r14
   2e972:	48 8b 5c 24 38       	mov    0x38(%rsp),%rbx
   2e977:	48 89 df             	mov    %rbx,%rdi
   2e97a:	e8 a1 b8 ff ff       	call   2a220 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtCsa9EZGJKk8MG_4pbrs3map3MapllEECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e97f:	4c 89 f7             	mov    %r14,%rdi
   2e982:	e8 19 ff 03 00       	call   6e8a0 <_Unwind_Resume@plt>
   2e987:	ff 15 eb 37 04 00    	call   *0x437eb(%rip)        # 72178 <_DYNAMIC+0x2a0>
   2e98d:	49 89 c6             	mov    %rax,%r14
   2e990:	48 8b 3c 24          	mov    (%rsp),%rdi
   2e994:	48 8b 74 24 08       	mov    0x8(%rsp),%rsi
   2e999:	e8 82 ba ff ff       	call   2a420 <_RINvNtCskADBYZwJmSU_4core3ptr9drop_glueINtNtNtNtCs8ZKwes1zzDd_3std11collections4hash3map7HashMapllEECs4mZnWWL4Zvj_24pbrs_map_iteration_proof>
   2e99e:	4c 89 f7             	mov    %r14,%rdi
   2e9a1:	e8 fa fe 03 00       	call   6e8a0 <_Unwind_Resume@plt>
