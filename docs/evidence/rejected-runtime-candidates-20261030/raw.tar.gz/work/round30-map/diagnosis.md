# Pure helper map assembly screening

The work-only pure-helper candidate `eae81c8a1b121036abd52b04bf9897512389074bb855c2ebb12bd71d21e33668` passes immutable entries/index and cursor by value, so the iterator itself does not escape. The final slice/mask candidate `651957d463853aad50946497d98beb4fa7e97b3a4af4384327b2c0ddae171305` instead passes the sorted positions slice and mask as values. They inherit the earlier packed winner-position design and its in-place heap sort, so cold duplicate construction and index size still need lifecycle evaluation. Neither candidate modified production.

Fresh main `15e73849` binaries, all built with the same ordinary-loop harness:

- Baseline SHA `b05b70d9c8703a33e20a92c6686152a2c4d1d171902ff8357d01f085f22a27df`. The unique-loop cardinality check is hoisted at `0x2e1d9–0x2e1e0`; the loop at `0x2e304–0x2e374` is vectorized.
- Pure helper SHA `3e85ac1d6e7c8753c2be4152c7f62c10f1503c00d0b4380aedf53e586cd6305b`. Unique iteration reloads cardinality per element at `0x2e79c` and remains scalar.
- Slice/mask SHA `456454cb32b3fb221c53854298a9f894faba98955b5143580aad092c3bec8e55`. Unique iteration reloads cardinality per element at `0x2e7cc–0x2e7d3` and remains scalar.

The first two pass 144 paired zero-iteration semantic preflights; the final candidate passes 72 additional controls. Those checks do not measure performance. The scalar-loop codegen is a strong regression concern, but no timing claim is made. Per the assembly-first gate, the slice/mask candidate was rejected without further variants or timings. Relevant assembly dumps are in this directory; source-frozen binaries and semantic preflights are under `work/all-benchmarks/measurement/round30-map-*` and `work/round30-map-screen/`.

Independent review found an edge difference: for the unpacked oversized duplicate-index fallback, a panic from a custom `MapKey::cmp` leaves the prior cursor advanced in old code, while the by-value helper retains the pre-call cursor if the caller catches unwind. No panic-state iterator contract is documented. Native 32-bit testing was not done; prior packing-boundary checks modeled 16-bit halves on a 64-bit machine.
