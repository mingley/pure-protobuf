import contextlib,hashlib,importlib.util,io,json,tarfile
from pathlib import Path
root=Path.cwd(); original=root/'docs/evidence/grpc-load-terminal-accounting'
spec=importlib.util.spec_from_file_location('evidence_check',original/'check.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
index=json.loads((original/'index.json').read_text())
with tarfile.open(original/'records.tar.gz') as tar:
 data={m.name:tar.extractfile(m).read() for m in tar.getmembers()}
report=json.loads(data['matrix/report.json']);run_path='matrix/'+report['runs'][0]['path']
changes={
 'missing_terminal_count': (run_path,lambda value:value['metrics'].pop('completed_rpcs')),
 'invented_cpu_delta':(run_path,lambda value:value.update(client_lifetime_cpu_seconds=value['client_lifetime_cpu_seconds']+1)),
 'missing_cell':('matrix/report.json',lambda value:value['runs'].pop()),
 'false_qualification':('matrix/report.json',lambda value:value['qualification'].update(qualified=True)),
 'unrecovered_permit':('resource/report.json',lambda value:value['events'][-1].update(server_byte_tokens=1)),
}
results=[]
for name,(member,mutate) in changes.items():
 directory=root/'work/rpc-qualification/corrupt'/name;directory.mkdir(parents=True,exist_ok=True)
 altered=dict(data);value=json.loads(altered[member]);mutate(value);altered[member]=(json.dumps(value)+'\n').encode()
 with tarfile.open(directory/'records.tar.gz','w:gz',compresslevel=1) as tar:
  for member,raw in altered.items():
   info=tarfile.TarInfo(member);info.size=len(raw);tar.addfile(info,io.BytesIO(raw))
 copy=dict(index);copy['files']={path:hashlib.sha256(raw).hexdigest() for path,raw in altered.items()};copy['archive_sha256']=hashlib.sha256((directory/'records.tar.gz').read_bytes()).hexdigest()
 (directory/'index.json').write_text(json.dumps(copy))
 module.ROOT=directory
 try:
  with contextlib.redirect_stdout(io.StringIO()):module.main()
 except (AssertionError,KeyError,ValueError) as error:
  results.append({'mutation':name,'rejected':True,'error_type':type(error).__name__})
 else:raise AssertionError(f'{name} was accepted')
print(json.dumps(results,indent=2))
(root/'work/rpc-qualification/corrupt-tests.json').write_text(json.dumps(results,indent=2)+'\n')
