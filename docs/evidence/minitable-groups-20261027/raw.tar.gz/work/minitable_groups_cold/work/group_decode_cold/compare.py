from pathlib import Path
import hashlib
import itertools
import json
import statistics
import subprocess

REPO = Path('/workspace/pure-protobuf')
OUT = REPO / 'work/minitable_groups_cold/work/group_decode_cold'
TREES = {
    'baseline': REPO,
    'current': REPO / 'work/minitable_groups',
    'experiment': REPO / 'work/minitable_groups_cold',
}
BINARIES = {
    name: REPO / 'work/bench-target/release' / binary
    for name, binary in [
        ('baseline', 'kernel-groups-baseline'),
        ('current', 'kernel-groups-candidate'),
        ('experiment', 'kernel-groups-cold'),
    ]
}
FIXTURES = {
    'baseline': REPO / 'work/minitable_groups/work/group_decode/bench-baseline/src/main.rs',
    'current': REPO / 'work/minitable_groups/work/group_decode/bench-candidate/src/main.rs',
    'experiment': OUT / 'bench/src/main.rs',
}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
old = json.loads((REPO / 'work/minitable_groups/work/group_decode/alternating-summary.json').read_text())
assert sha(BINARIES['baseline']) == old['binaries']['baseline']['sha256']
assert sha(BINARIES['current']) == old['binaries']['candidate']['sha256']
assert {sha(path) for path in FIXTURES.values()} == {'90196dde096ac718d6276d6c8de151cd4a6a9d1eb9c79ff49542183c3c1061ed'}
assert BINARIES['experiment'].stat().st_mtime_ns >= (TREES['experiment'] / 'src/runtime/decode.rs').stat().st_mtime_ns
provenance = {
    'base_commit': 'a24c0e3561c44c3ae03f57641e806ac7331b4df4',
    'fixture_sha256': sha(FIXTURES['experiment']),
    'source_hashes': {
        name: {
            file: sha(tree / file)
            for file in ['src/runtime/decode.rs', 'src/runtime/encode.rs', 'tests/upb_kernel/decode.rs']
        }
        for name, tree in TREES.items() if name != 'baseline'
    },
    'baseline_source_hashes': old['source']['source_hashes']['baseline'],
    'binaries': {
        name: {'path': str(path), 'sha256': sha(path), 'mtime_ns': path.stat().st_mtime_ns}
        for name, path in BINARIES.items()
    },
    'group_body_timing': 'unmeasured: fixture has no equivalent known-group benchmark mode',
}

def run(name, arguments, run_metadata, destination):
    process = subprocess.run([str(BINARIES[name]), *arguments], capture_output=True, text=True, check=True)
    rows = [json.loads(line) for line in process.stdout.splitlines()]
    assert len(rows) == (15 if arguments else 10)
    with destination.open('a') as file:
        for row in rows:
            record = {**run_metadata, 'variant': name, **row}
            file.write(json.dumps(record) + '\n')
    return [{**run_metadata, 'variant': name, **row} for row in rows]

known_raw = OUT / 'non-group-raw.jsonl'
unknown_raw = OUT / 'unknown-raw.jsonl'
assert not known_raw.exists() and not unknown_raw.exists(), 'Use a new output directory instead of overwriting retained samples.'
known = []
orders = list(itertools.permutations(('baseline', 'current', 'experiment')))
for trial, order in enumerate(orders):
    for position, name in enumerate(order):
        known.extend(run(name, [], {'trial': trial, 'order': list(order), 'position': position}, known_raw))
unknown = []
for trial in range(6):
    order = ('current', 'experiment') if trial % 2 == 0 else ('experiment', 'current')
    for position, name in enumerate(order):
        unknown.extend(run(name, ['unknown'], {'trial': trial, 'order': list(order), 'position': position}, unknown_raw))

def cases(rows, conditions, variants, trial=None):
    output = []
    for condition in conditions:
        record = dict(condition)
        for name in variants:
            selected = [r for r in rows if r['variant'] == name and (trial is None or r['trial'] == trial) and all(r[key] == value for key, value in condition.items())]
            assert len(selected) == (30 if trial is None else 5)
            allocations = {r['allocations_per_parse'] for r in selected}
            requested = {r['requested_bytes_per_parse'] for r in selected}
            assert len(allocations) == len(requested) == 1
            record[name] = {
                'median_parse_ns': statistics.median(r['parse_ns'] for r in selected),
                'min_parse_ns': min(r['parse_ns'] for r in selected),
                'max_parse_ns': max(r['parse_ns'] for r in selected),
                'allocations_per_parse': allocations.pop(),
                'requested_bytes_per_parse': requested.pop(),
            }
        record['experiment_vs_current_percent'] = (record['experiment']['median_parse_ns'] / record['current']['median_parse_ns'] - 1) * 100
        if 'baseline' in variants:
            record['current_vs_baseline_percent'] = (record['current']['median_parse_ns'] / record['baseline']['median_parse_ns'] - 1) * 100
            record['experiment_vs_baseline_percent'] = (record['experiment']['median_parse_ns'] / record['baseline']['median_parse_ns'] - 1) * 100
        output.append(record)
    return output

known_conditions = [{'fragments': 1}, {'fragments': 100}]
unknown_conditions = [{'mode': mode} for mode in ('varint', 'len', 'nested_groups')]
provenance['non_group'] = cases(known, known_conditions, ('baseline', 'current', 'experiment'))
provenance['unknown'] = cases(unknown, unknown_conditions, ('current', 'experiment'))
provenance['non_group_trials'] = [{'trial': trial, 'order': list(order), 'cases': cases(known, known_conditions, ('baseline', 'current', 'experiment'), trial)} for trial, order in enumerate(orders)]
provenance['unknown_trials'] = [{'trial': trial, 'first': 'current' if trial % 2 == 0 else 'experiment', 'cases': cases(unknown, unknown_conditions, ('current', 'experiment'), trial)} for trial in range(6)]
for name, binary in BINARIES.items():
    assert sha(binary) == provenance['binaries'][name]['sha256']
(OUT / 'comparison.json').write_text(json.dumps(provenance, indent=2) + '\n')
print('non_group', json.dumps(provenance['non_group']))
print('unknown', json.dumps(provenance['unknown']))
