Keep the original correctness patch. It adds known-group decoding/serialization and unknown-field preservation, with 46 kernel tests, eight runtime unit controls, strict Clippy, and protoc oracle records. The base is `a24c0e3561c44c3ae03f57641e806ac7331b4df4`. Group-body timing was not measured.

The selected patch is `original-correct/groups.patch`, SHA256 `a790143884917c104ba31b51c756803d520829273f770766763d35c6c36ff34e`. It is also retained at `/workspace/pure-protobuf/work/minitable_groups/work/group_decode/groups.patch`. Only `src/runtime/decode.rs`, `src/runtime/encode.rs`, and `tests/upb_kernel/decode.rs` change. The final decoder hash is `7aa4a0e638628a94cd5629a24bce9b6b1c2e5d4e808926eb619802ac9b50c02b`.

All attempts remain in this directory:

| Attempt | Patch and metadata | Samples |
| --- | --- | --- |
| Original correct | `original-correct/groups.patch`, `original-correct/source.json` | `original-correct/*-non-group.jsonl`, `original-correct/*-unknown.jsonl`, `original-correct/alternating-raw.jsonl` |
| Cold/noinline helpers plus combined check | `groups-cold.patch`, `experiment-only.patch`, `source.json` | `non-group-raw.jsonl`, `unknown-raw.jsonl` |
| Cold/noinline helpers alone | `helpers-only/groups.patch`, `helpers-only/source.json` | `helpers-only/non-group-raw.jsonl`, `helpers-only/unknown-raw.jsonl` |
| Combined Message/Group check alone | `combined-only/groups.patch`, `combined-only/source.json` | `combined-only/non-group-raw.jsonl`, `combined-only/unknown-raw.jsonl` |

`comparison.json` and each split's `comparison.json` retain every trial/order, binary hashes, allocation counts, medians and ranges. `choice.json` records the decision. No timing samples were removed. The original six reversed process pairs showed a persistent 100-fragment loss: +3.4% to +11.0%, with +5.32% across the 30-sample medians. The combined experiment then added +4.42% versus the correct candidate; the helpers-only and combined-check-only experiments added +1.84% and +0.91% in their respective interleaved comparisons. The selected candidate's allocation count stays at four requests/154 requested bytes for both non-group cases.

Unknown-mode costs are explicit. With one complete known child plus one unknown varint, the selected candidate makes six allocation requests/306 requested bytes; with a four-byte unknown LEN field, seven/310; with two nested unknown groups around a varint, ten/610. The baseline discarded those unknowns and made four/154 in every case. The extra storage is allocated only when unknown data is present. Null linked-table sentinels retain inert payload semantics; linked tables round-trip unknown fields. Map-entry unknown semantics were not expanded.

The fixture is `bench/src/main.rs`, byte-identical to `original-correct/bench-baseline/src/main.rs`, `original-correct/bench-candidate/src/main.rs`, `helpers-only/bench/src/main.rs`, and `combined-only/bench/src/main.rs`. Its SHA256 is `90196dde096ac718d6276d6c8de151cd4a6a9d1eb9c79ff49542183c3c1061ed`. With no CLI argument it parses one and 100 complete singular-message fragments, five samples of 10,000 fresh parses each. With `unknown` it measures varint, LEN and nested-group unknown fields, also five samples of 10,000 parses each. Fixture construction, assertions and destruction sit outside the parse timer/allocation snapshots. The System allocator wrapper counts allocation/reallocation requests and requested sizes, not peak memory.

Recorded builds used Rust `1.99.1 (58cf8f9c3 2026-10-13)` and Cargo `1.99.1 (5f94df478 2026-08-27)`, with:

```sh
export CARGO_HOME=/workspace/pure-protobuf/work/cargo
export RUSTUP_HOME=/workspace/pure-protobuf/work/rustup
export PATH=/workspace/pure-protobuf/work/cargo/bin:/workspace/pure-protobuf/work/toolchain/protoc/bin:$PATH
export CARGO_BUILD_JOBS=1
export CARGO_INCREMENTAL=0
export CARGO_PROFILE_DEV_DEBUG=0
export CARGO_TARGET_DIR=/workspace/pure-protobuf/work/bench-target
```

Every standalone manifest uses the same fixture and an absolute `pbrs` path dependency. Its profile is `[profile.release] lto="thin", codegen-units=1`, with other release settings at defaults, including optimization level 3. The exact original builds/runs were:

```sh
cd /workspace/pure-protobuf/work/minitable_groups
cargo run --offline --quiet --release --manifest-path work/group_decode/bench-baseline/Cargo.toml
cargo run --offline --quiet --release --manifest-path work/group_decode/bench-candidate/Cargo.toml
cargo run --offline --quiet --release --manifest-path work/group_decode/bench-baseline/Cargo.toml -- unknown
cargo run --offline --quiet --release --manifest-path work/group_decode/bench-candidate/Cargo.toml -- unknown
cd /workspace/pure-protobuf/work/minitable_groups_cold
cargo build --offline --quiet --release --manifest-path work/group_decode_cold/bench/Cargo.toml
cargo build --offline --quiet --release --manifest-path work/group_decode_cold/helpers-only/bench/Cargo.toml
cargo build --offline --quiet --release --manifest-path work/group_decode_cold/combined-only/bench/Cargo.toml
python3 work/group_decode_cold/compare.py
python3 work/group_decode_cold/compare-splits.py
```

The comparison drivers executed frozen binaries directly, without intervening builds. The first driver ran all six process permutations of baseline/current/both-changes, followed by six alternating current/experiment unknown-mode pairs. The split driver used the same six permutations separately for each split, plus alternating unknown pairs. Their guards intentionally refuse to overwrite retained raw output. Use new output paths for another run. The drivers reference original source paths; the two split source worktrees were removed after their source snapshots, patches, locks, logs and binary hashes were retained here. Reconstruct them before reusing those exact source-path guards, or adapt a copied driver to newly verified sources/binaries and a new output directory.

The historical baseline binary used the main checkout, whose decoder and encoder were verified byte-identical to the base commit before building. The selected candidate used the isolated `work/minitable_groups` worktree at the base plus its patch. The other attempts used separate isolated worktrees based on the same commit. A future baseline build must use the recorded base rather than the now-updated main checkout.

To rebuild with limited disk, create one fresh detached worktree at the base, then reuse only that worktree sequentially. Before each variant, restore the three owned files to the base and apply that variant's full patch. Build from a copied standalone fixture manifest whose `pbrs` dependency points to this replay worktree. Keep a distinct package/binary name for each variant, use its retained Cargo.lock, and record source/binary hashes before switching variants. The complete patches apply directly to the base; `experiment-only.patch` instead applies on top of the selected correctness patch. For example:

```sh
cd /workspace/pure-protobuf
git worktree add --detach work/minitable_groups_replay a24c0e3561c44c3ae03f57641e806ac7331b4df4
git -C work/minitable_groups_replay apply /workspace/pure-protobuf/work/minitable_groups_cold/work/group_decode_cold/original-correct/groups.patch
```

For the next attempt, restore only these task-owned files inside that fresh replay worktree, then apply its full patch:

```sh
git -C work/minitable_groups_replay restore --source=a24c0e3561c44c3ae03f57641e806ac7331b4df4 -- src/runtime/decode.rs src/runtime/encode.rs tests/upb_kernel/decode.rs
git -C work/minitable_groups_replay apply /workspace/pure-protobuf/work/minitable_groups_cold/work/group_decode_cold/helpers-only/groups.patch
```

Perform the same steps for the combined-check-only or both-changes patch. The isolated replay recipe was documented, not executed during this task. Offline rebuilding requires the retained dependency cache; preserve lock versions. Shared-host timings are diagnostic and do not establish a cross-library ranking.

The selected correctness checks were run from its isolated worktree using the environment above:

```sh
cargo test --locked -p pbrs --test upb_kernel --lib runtime:: --quiet
cargo test --locked -p pbrs --test upb_kernel --quiet
cargo clippy --locked -p pbrs --lib --test upb_kernel -- -D warnings
```

The both-changes variant passed the same checks. Neither split qualified on speed, so each has a successful release build and retained measurement records; further correctness/Clippy runs were not performed for those rejected variants. The selected implementation retains the original correct patch and its measured non-group timing loss.
