from pathlib import Path
import hashlib
import itertools
import json
import statistics
import subprocess

REPO = Path('/workspace/pure-protobuf')
CAPSULE = REPO / 'work/minitable_groups_cold/work/group_decode_cold'
BIN_DIR = REPO / 'work/bench-target/release'
BINS = {'baseline': BIN_DIR / 'kernel-groups-baseline', 'current': BIN_DIR / 'kernel-groups-candidate', 'helpers': BIN_DIR / 'kernel-groups-helpers', 'combined': BIN_DIR / 'kernel-groups-combined'}
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
frozen = json.loads((REPO / 'work/minitable_groups/work/group_decode/alternating-summary.json').read_text())
assert sha(BINS['baseline']) == frozen['binaries']['baseline']['sha256']
assert sha(BINS['current']) == frozen['binaries']['candidate']['sha256']

def run(name, arguments, metadata, output):
    result = subprocess.run([str(BINS[name]), *arguments], capture_output=True, text=True, check=True)
    rows = [json.loads(line) for line in result.stdout.splitlines()]
    assert len(rows) == (15 if arguments else 10)
    records = [{**metadata, 'variant': name, **row} for row in rows]
    with output.open('a') as file:
        for record in records:
            file.write(json.dumps(record) + '\n')
    return records

def summarize(rows, conditions, names, variant, trial=None):
    results = []
    for condition in conditions:
        record = dict(condition)
        for name in names:
            selected = [row for row in rows if row['variant'] == name and (trial is None or row['trial'] == trial) and all(row[key] == value for key, value in condition.items())]
            assert len(selected) == (30 if trial is None else 5)
            assert len({row['allocations_per_parse'] for row in selected}) == 1
            assert len({row['requested_bytes_per_parse'] for row in selected}) == 1
            record[name] = {'median_parse_ns': statistics.median(row['parse_ns'] for row in selected), 'min_parse_ns': min(row['parse_ns'] for row in selected), 'max_parse_ns': max(row['parse_ns'] for row in selected), 'allocations_per_parse': selected[0]['allocations_per_parse'], 'requested_bytes_per_parse': selected[0]['requested_bytes_per_parse']}
        record['variant_vs_current_percent'] = (record[variant]['median_parse_ns'] / record['current']['median_parse_ns'] - 1) * 100
        if 'baseline' in names:
            record['variant_vs_baseline_percent'] = (record[variant]['median_parse_ns'] / record['baseline']['median_parse_ns'] - 1) * 100
            record['current_vs_baseline_percent'] = (record['current']['median_parse_ns'] / record['baseline']['median_parse_ns'] - 1) * 100
        results.append(record)
    return results

for variant in ('helpers', 'combined'):
    out = CAPSULE / (variant + '-only')
    metadata = json.loads((out / 'source.json').read_text())
    source = Path(metadata['source_tree'])
    assert sha(source / 'src/runtime/decode.rs') == metadata['source_hashes']['src/runtime/decode.rs']
    assert sha(out / 'bench/src/main.rs') == metadata['fixture_sha256'] == '90196dde096ac718d6276d6c8de151cd4a6a9d1eb9c79ff49542183c3c1061ed'
    assert BINS[variant].stat().st_mtime_ns >= (source / 'src/runtime/decode.rs').stat().st_mtime_ns
    binaries = {name: {'path': str(BINS[name]), 'sha256': sha(BINS[name]), 'mtime_ns': BINS[name].stat().st_mtime_ns} for name in ('baseline', 'current', variant)}
    assert not (out / 'non-group-raw.jsonl').exists() and not (out / 'unknown-raw.jsonl').exists(), 'Never overwrite retained samples.'
    orders = list(itertools.permutations(('baseline', 'current', variant)))
    known = []
    for trial, order in enumerate(orders):
        for position, name in enumerate(order):
            known.extend(run(name, [], {'trial': trial, 'position': position, 'order': list(order)}, out / 'non-group-raw.jsonl'))
    unknown = []
    for trial in range(6):
        order = ('current', variant) if trial % 2 == 0 else (variant, 'current')
        for position, name in enumerate(order):
            unknown.extend(run(name, ['unknown'], {'trial': trial, 'position': position, 'order': list(order)}, out / 'unknown-raw.jsonl'))
    known_conditions = [{'fragments': 1}, {'fragments': 100}]
    unknown_conditions = [{'mode': mode} for mode in ('varint', 'len', 'nested_groups')]
    summary = {'source': metadata, 'binaries': binaries, 'group_body_timing': 'unmeasured', 'non_group': summarize(known, known_conditions, ('baseline', 'current', variant), variant), 'unknown': summarize(unknown, unknown_conditions, ('current', variant), variant), 'non_group_trials': [{'trial': trial, 'order': list(order), 'cases': summarize(known, known_conditions, ('baseline', 'current', variant), variant, trial)} for trial, order in enumerate(orders)], 'unknown_trials': [{'trial': trial, 'first': 'current' if trial % 2 == 0 else variant, 'cases': summarize(unknown, unknown_conditions, ('current', variant), variant, trial)} for trial in range(6)]}
    for name in binaries:
        assert sha(BINS[name]) == binaries[name]['sha256']
    (out / 'comparison.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(variant, 'non_group', json.dumps(summary['non_group']), flush=True)
    print(variant, 'unknown', json.dumps(summary['unknown']), flush=True)
