#![allow(
    clippy::unimplemented,
    clippy::unwrap_used,
    clippy::expect_used,
    reason = "null MiniTable/MessagePtr is a rust_out kernel invariant, not a user Result"
)]

use crate::error::ParseError;
use crate::internal::{Private, SealedInternal};
use crate::message::{Clear, ClearAndParse, MergeFrom, Serialize};
use crate::proxied::{AsView, View};
use crate::wire::{
    UnknownField, WIRE_EGROUP, WIRE_I32, WIRE_I64, WIRE_LEN, WIRE_SGROUP, WIRE_VARINT,
    capture_unknown_with_depth, decode_tag, decode_varint, decode_zigzag32, decode_zigzag64,
    read_fixed32, read_fixed64, read_len_bytes, skip_field_with_number_and_depth,
};
use std::collections::HashSet;
use std::marker::PhantomData;

use super::{
    Arena, AssociatedMiniTable, FieldKind, FieldType, MessagePtr, MiniField, MiniTablePtr, MsgData,
    RawMap, StringView, UpbGetArena, UpbGetMessagePtr, UpbGetMessagePtrMut,
};

fn descend(depth: u32) -> Result<u32, ParseError> {
    if depth >= crate::RECURSION_LIMIT {
        return Err(ParseError::new("recursion limit exceeded"));
    }
    Ok(depth + 1)
}

fn field_wire_type(ty: FieldType) -> u32 {
    match ty {
        FieldType::Double | FieldType::Fixed64 | FieldType::SFixed64 => WIRE_I64,
        FieldType::Float | FieldType::Fixed32 | FieldType::SFixed32 => WIRE_I32,
        FieldType::String | FieldType::Bytes | FieldType::Message => WIRE_LEN,
        FieldType::Group => WIRE_SGROUP,
        _ => WIRE_VARINT,
    }
}

fn parse_into(
    data: *mut MsgData,
    buf: &[u8],
    arena: &Arena,
    enforce_required: bool,
    depth: u32,
) -> Result<(), ParseError> {
    let mut context = DecodeContext {
        arena,
        maps: Vec::new(),
    };
    let result = decode_into(data, buf, &mut context, depth);
    // Normalize partial successful entries even when a later wire field fails.
    // A subsequent merge must see the same logical map as this parse produced.
    context.finish_maps();
    result?;
    if enforce_required {
        // SAFETY: the caller owns this arena-backed tree for the entire parse;
        // decoding has finished before the immutable validation walk starts.
        check_initialized(unsafe { &*data }, depth)?;
    }
    Ok(())
}

struct DecodeContext<'a> {
    arena: &'a Arena,
    maps: Vec<RawMap>,
}

impl DecodeContext<'_> {
    fn finish_maps(&mut self) {
        self.maps.sort_unstable();
        self.maps.dedup();
        for &map in &self.maps {
            // SAFETY: every recorded map belongs to the arena, which remains
            // live through this parse. No decoding or entry mutation overlaps.
            let mut entries = unsafe { (*map).entries.borrow_mut() };
            if entries.len() < 2 {
                continue;
            }
            // Borrow keys until the scan finishes, then compact in place. This
            // avoids key clones and per-entry linear searches. Default hashing
            // protects the expected linear pass from attacker-chosen keys.
            let mut seen = HashSet::with_capacity(entries.len());
            let mut keep = vec![false; entries.len()];
            for ((key, _), retain) in entries.iter().rev().zip(keep.iter_mut().rev()) {
                *retain = seen.insert(key.as_slice());
            }
            drop(seen);
            let mut keep = keep.into_iter();
            entries.retain(|(_, value)| {
                let retain = keep.next().unwrap_or(false);
                if !retain {
                    // Only the independent string-owner list is borrowed here;
                    // releasing a value does not borrow or mutate entries.
                    super::kernel_map_release_value(map, *value);
                }
                retain
            });
        }
    }
}

fn decode_into(
    data: *mut MsgData,
    buf: &[u8],
    context: &mut DecodeContext<'_>,
    depth: u32,
) -> Result<(), ParseError> {
    let mt = unsafe { (*data).mt };
    if mt.0.is_null() {
        return Ok(());
    }
    if depth > crate::RECURSION_LIMIT {
        return Err(ParseError::new("recursion limit exceeded"));
    }
    let table = unsafe { &*mt.0 };
    let mut pos = 0usize;
    while pos < buf.len() {
        let (num, wire) = decode_tag(buf, &mut pos)?;
        let Some((idx, f)) = table.field_by_number(num) else {
            capture_unknown_into(data, buf, &mut pos, num, wire, depth)?;
            continue;
        };
        decode_field(data, idx, f, buf, &mut pos, wire, context, depth)?;
    }
    Ok(())
}

#[cold]
#[inline(never)]
fn decode_group_into(
    data: *mut MsgData,
    buf: &[u8],
    pos: &mut usize,
    number: u32,
    context: &mut DecodeContext<'_>,
    depth: u32,
) -> Result<(), ParseError> {
    if depth > crate::RECURSION_LIMIT {
        return Err(ParseError::new("recursion limit exceeded"));
    }
    // SAFETY: the caller owns this arena-backed child and its linked table
    // throughout decoding. A null table still requires valid group framing.
    let table = unsafe { (*data).mt.0.as_ref() };
    loop {
        let (num, wire) = decode_tag(buf, pos)?;
        if wire == WIRE_EGROUP {
            return if num == number {
                Ok(())
            } else {
                Err(ParseError::new("mismatched end-group"))
            };
        }
        if let Some((index, field)) = table.and_then(|table| table.field_by_number(num)) {
            decode_field(data, index, field, buf, pos, wire, context, depth)?;
        } else if table.is_some() {
            capture_unknown_into(data, buf, pos, num, wire, depth)?;
        } else {
            // A null MiniTable is an inert child, as for LEN messages. Discard
            // its payload while still validating the group's wire framing.
            skip_field_with_number_and_depth(buf, pos, num, wire, depth)?;
        }
    }
}

#[cold]
#[inline(never)]
fn capture_unknown_into(
    data: *mut MsgData,
    buf: &[u8],
    pos: &mut usize,
    number: u32,
    wire: u32,
    depth: u32,
) -> Result<(), ParseError> {
    let field = capture_unknown_with_depth(buf, pos, number, wire, depth)?;
    // SAFETY: parsing has exclusive access to this live message. Store the
    // owned field only after its complete wire frame has been validated.
    unsafe { (*data).unknown.fields.push(field) };
    Ok(())
}

/// Initialization belongs to the final retained tree: a later fragment can
/// complete a singular child, replace a oneof case, or replace a map entry.
/// The walk uses existing arena storage and allocates no temporary tree.
fn check_initialized(data: &MsgData, depth: u32) -> Result<(), ParseError> {
    // SAFETY: linked MiniTables outlive their arena messages and are immutable.
    let Some(table) = (unsafe { data.mt.0.as_ref() }) else {
        return Ok(());
    };
    if depth > crate::RECURSION_LIMIT {
        return Err(ParseError::new("recursion limit exceeded"));
    }
    for (index, field) in table.fields.iter().enumerate() {
        let present = data.has.get(index).copied().unwrap_or(false);
        if field.required && !present {
            return Err(ParseError::new("required"));
        }
        if !present || !matches!(field.ty, FieldType::Message | FieldType::Group) {
            continue;
        }
        match data.slots.get(index).copied().unwrap_or(FieldKind::Empty) {
            FieldKind::Msg(raw) => {
                // SAFETY: live child pointers are stable Boxes in the owning arena.
                if let Some(child) = unsafe { raw.as_ref() } {
                    check_initialized(child, descend(depth)?)?;
                }
            }
            FieldKind::Repeated(raw) => {
                // SAFETY: the live arena owns this array and every message item.
                if let Some(array) = unsafe { raw.as_ref() } {
                    for value in array.items.borrow().iter() {
                        if let FieldKind::Msg(raw) = *value {
                            if let Some(child) = unsafe { raw.as_ref() } {
                                check_initialized(child, descend(depth)?)?;
                            }
                        }
                    }
                }
            }
            FieldKind::Map(raw) => {
                // SAFETY: this field's linked entry table and raw map remain
                // live throughout the read-only validation walk.
                if let Some(map) = unsafe { raw.as_ref() } {
                    let value_field = unsafe { field.sub.0.as_ref() }
                        .and_then(|entry| entry.fields.iter().find(|field| field.number == 2));
                    let Some(value_field) = value_field
                        .filter(|f| matches!(f.ty, FieldType::Message | FieldType::Group))
                    else {
                        continue;
                    };
                    let default_missing_required = unsafe { value_field.sub.0.as_ref() }
                        .is_some_and(|table| table.fields.iter().any(|field| field.required));
                    for (_, value) in map.entries.borrow().iter() {
                        match *value {
                            FieldKind::Msg(raw) => {
                                if let Some(child) = unsafe { raw.as_ref() } {
                                    check_initialized(child, descend(descend(depth)?)?)?;
                                }
                            }
                            FieldKind::Empty if default_missing_required => {
                                // An omitted message value is the empty default.
                                // No message was present on the wire, so checking
                                // its direct required fields consumes no depth.
                                return Err(ParseError::new("required"));
                            }
                            _ => {}
                        }
                    }
                }
            }
            _ => {}
        }
    }
    Ok(())
}

#[expect(
    clippy::too_many_arguments,
    reason = "private MiniTable field decoder carries its wire frame, arena and enclosing recursion depth"
)]
fn decode_field(
    data: *mut MsgData,
    idx: usize,
    f: MiniField,
    buf: &[u8],
    pos: &mut usize,
    wire: u32,
    context: &mut DecodeContext<'_>,
    depth: u32,
) -> Result<(), ParseError> {
    let ptr = MessagePtr::<()> {
        raw: data,
        _phantom: PhantomData,
    };
    let expected_wire = field_wire_type(f.ty);
    let packable = expected_wire != WIRE_LEN && expected_wire != WIRE_SGROUP;
    // An incompatible known-field tag is unknown wire data. Preserve it before
    // creating a collection or changing a oneof's active case/presence.
    if wire != expected_wire && !(f.repeated && packable && wire == WIRE_LEN) {
        capture_unknown_into(data, buf, pos, f.number, wire, depth)?;
        return Ok(());
    }
    if f.is_map {
        if wire != WIRE_LEN {
            skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
            return Ok(());
        }
        let payload = read_len_bytes(buf, pos)?;
        let entry_depth = descend(depth)?;
        if let Some((k, v)) = decode_map_entry(f.sub, payload, context, entry_depth)? {
            let map = unsafe { ptr.get_or_create_mutable_map_at_index(idx as u32, context.arena) }
                .ok_or_else(|| ParseError::new("map alloc"))?;
            // Map entries replace earlier values for this key; message values
            // merge only inside one entry, never across separate entries. Batch
            // duplicate removal at the root keeps insertion constant time.
            unsafe { (*map).entries.borrow_mut().push((k, v)) };
            if context.maps.last().copied() != Some(map) {
                context.maps.push(map);
            }
        } else {
            // A rejected closed enum invalidates the entire map entry, even
            // if another value in that entry is valid. Preserve its wire data
            // without replacing an earlier valid entry for the same key.
            ptr.data_mut()
                .unknown
                .fields
                .push(UnknownField::LengthDelimited {
                    number: f.number,
                    value: payload.to_vec(),
                });
        }
        return Ok(());
    }
    if f.repeated && !f.is_map {
        let arr = unsafe { ptr.get_or_create_mutable_array_at_index(idx as u32, context.arena) }
            .ok_or_else(|| ParseError::new("array alloc"))?;
        // Protobuf readers accept both forms regardless of the packed option.
        if packable && wire == WIRE_LEN {
            let payload = read_len_bytes(buf, pos)?;
            let mut p = 0usize;
            while p < payload.len() {
                let v = if f.ty == FieldType::Enum {
                    let Some(v) = decode_enum(f, payload, &mut p, ptr)? else {
                        continue;
                    };
                    v
                } else {
                    decode_packed_item(f.ty, payload, &mut p)?
                };
                unsafe {
                    (*arr).items.borrow_mut().push(v);
                }
            }
            return Ok(());
        }
        let v = if f.ty == FieldType::Enum {
            if wire != WIRE_VARINT {
                skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
                return Ok(());
            }
            let Some(v) = decode_enum(f, buf, pos, ptr)? else {
                return Ok(());
            };
            v
        } else {
            decode_one(f, buf, pos, wire, context, depth)?
        };
        unsafe {
            (*arr).items.borrow_mut().push(v);
        }
        ptr.set_slot(idx as u32, FieldKind::Repeated(arr), true);
        return Ok(());
    }
    if f.ty == FieldType::Message && !f.repeated {
        let payload = read_len_bytes(buf, pos)?;
        let child_depth = descend(depth)?;
        let child = match ptr.slot(idx as u32) {
            FieldKind::Msg(child) if !child.is_null() => child,
            _ => context.arena.alloc_msg(f.sub),
        };
        decode_into(child, payload, context, child_depth)?;
        ptr.set_slot(idx as u32, FieldKind::Msg(child), true);
        return Ok(());
    }
    if f.ty == FieldType::Group && !f.repeated {
        let child_depth = descend(depth)?;
        let child = match ptr.slot(idx as u32) {
            FieldKind::Msg(child) if !child.is_null() => child,
            _ => context.arena.alloc_msg(f.sub),
        };
        decode_group_into(child, buf, pos, f.number, context, child_depth)?;
        ptr.set_slot(idx as u32, FieldKind::Msg(child), true);
        return Ok(());
    }
    if matches!(f.ty, FieldType::String | FieldType::Bytes) {
        let payload = read_len_bytes(buf, pos)?;
        if f.ty == FieldType::String {
            let enforce = unsafe {
                (*data)
                    .mt
                    .0
                    .as_ref()
                    .map(|t| t.enforce_utf8)
                    .unwrap_or(false)
            };
            if enforce && std::str::from_utf8(payload).is_err() {
                return Err(ParseError::new("utf8"));
            }
        }
        unsafe {
            ptr.set_base_field_string_at_index(idx as u32, StringView::from(payload));
        }
        return Ok(());
    }
    let v = if f.ty == FieldType::Enum {
        if wire != WIRE_VARINT {
            skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
            return Ok(());
        }
        let Some(v) = decode_enum(f, buf, pos, ptr)? else {
            return Ok(());
        };
        v
    } else {
        decode_one(f, buf, pos, wire, context, depth)?
    };
    ptr.set_slot(idx as u32, v, true);
    Ok(())
}

fn decode_enum(
    field: MiniField,
    buf: &[u8],
    pos: &mut usize,
    message: MessagePtr<()>,
) -> Result<Option<FieldKind>, ParseError> {
    let number = decode_varint(buf, pos)?;
    if field.accepts_enum(number as i32) {
        Ok(Some(FieldKind::I32(number as i32)))
    } else {
        // Preserve the original varint, not a truncated/reinterpreted enum.
        message
            .data_mut()
            .unknown
            .fields
            .push(UnknownField::Varint {
                number: field.number,
                value: number,
            });
        Ok(None)
    }
}

fn decode_map_entry(
    sub: MiniTablePtr,
    buf: &[u8],
    context: &mut DecodeContext<'_>,
    depth: u32,
) -> Result<Option<(Vec<u8>, FieldKind)>, ParseError> {
    if depth > crate::RECURSION_LIMIT {
        return Err(ParseError::new("recursion limit exceeded"));
    }
    let table = unsafe { sub.0.as_ref() };
    let mut key = Vec::new();
    // Enum-valued maps require zero as the enum's first value. An omitted
    // value therefore still has a valid typed enum value, not an empty slot.
    let mut val = if table.is_some_and(|t| {
        t.fields
            .iter()
            .any(|f| f.number == 2 && f.ty == FieldType::Enum)
    }) {
        FieldKind::I32(0)
    } else {
        FieldKind::Empty
    };
    let mut rejected_enum = false;
    let mut pos = 0usize;
    while pos < buf.len() {
        let (num, wire) = decode_tag(buf, &mut pos)?;
        let field = table.and_then(|t| t.fields.iter().copied().find(|f| f.number == num));
        if let Some(field) = field {
            if wire != field_wire_type(field.ty) {
                rejected_enum |= num == 2 && field.ty == FieldType::Enum;
                skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                continue;
            }
        }
        match num {
            1 => match field.map(|f| f.ty) {
                Some(FieldType::String) | Some(FieldType::Bytes) | None => {
                    if wire == WIRE_LEN {
                        key = read_len_bytes(buf, &mut pos)?.to_vec();
                    } else {
                        skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                    }
                }
                Some(FieldType::Bool) => {
                    if wire == WIRE_VARINT {
                        key = vec![if decode_varint(buf, &mut pos)? != 0 {
                            1
                        } else {
                            0
                        }];
                    } else {
                        skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                    }
                }
                Some(FieldType::Fixed32 | FieldType::SFixed32) => {
                    key = read_fixed32(buf, &mut pos)?.to_le_bytes().to_vec();
                }
                Some(FieldType::Fixed64 | FieldType::SFixed64) => {
                    key = read_fixed64(buf, &mut pos)?.to_le_bytes().to_vec();
                }
                Some(FieldType::SInt32) => {
                    let v = decode_zigzag32(decode_varint(buf, &mut pos)?);
                    key = v.to_le_bytes().to_vec();
                }
                Some(FieldType::SInt64) => {
                    let v = decode_zigzag64(decode_varint(buf, &mut pos)?);
                    key = v.to_le_bytes().to_vec();
                }
                Some(FieldType::Int64 | FieldType::UInt64) => {
                    key = decode_varint(buf, &mut pos)?.to_le_bytes().to_vec();
                }
                Some(_) => {
                    if wire == WIRE_VARINT {
                        key = (decode_varint(buf, &mut pos)? as i32)
                            .to_le_bytes()
                            .to_vec();
                    } else {
                        skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                    }
                }
            },
            2 => {
                if let Some(f) = field {
                    if f.ty == FieldType::Message {
                        let payload = read_len_bytes(buf, &mut pos)?;
                        let child_depth = descend(depth)?;
                        let child = match val {
                            FieldKind::Msg(child) if !child.is_null() => child,
                            _ => context.arena.alloc_msg(f.sub),
                        };
                        decode_into(child, payload, context, child_depth)?;
                        val = FieldKind::Msg(child);
                        continue;
                    }
                    if f.ty == FieldType::Enum && wire != WIRE_VARINT {
                        skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                        rejected_enum = true;
                        continue;
                    }
                    val = decode_one(f, buf, &mut pos, wire, context, depth)?;
                    if let FieldKind::I32(number) = val {
                        rejected_enum |= !f.accepts_enum(number);
                    }
                } else if wire == WIRE_VARINT {
                    val = FieldKind::I32(decode_varint(buf, &mut pos)? as i32);
                } else {
                    skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?;
                }
            }
            _ => skip_field_with_number_and_depth(buf, &mut pos, num, wire, depth)?,
        }
    }
    if key.is_empty() {
        let key_type = table.and_then(|t| t.fields.iter().find(|f| f.number == 1).map(|f| f.ty));
        // An omitted key equals an explicitly encoded default key. Use the same
        // canonical bytes as the map accessors and the key decoder below.
        key = match key_type {
            Some(FieldType::Bool) => vec![0],
            Some(
                FieldType::Int64
                | FieldType::UInt64
                | FieldType::SInt64
                | FieldType::Fixed64
                | FieldType::SFixed64,
            ) => 0u64.to_le_bytes().to_vec(),
            Some(
                FieldType::Int32
                | FieldType::UInt32
                | FieldType::SInt32
                | FieldType::Fixed32
                | FieldType::SFixed32,
            ) => 0u32.to_le_bytes().to_vec(),
            _ => Vec::new(),
        };
    }
    Ok((!rejected_enum).then_some((key, val)))
}

fn decode_packed_item(ty: FieldType, buf: &[u8], pos: &mut usize) -> Result<FieldKind, ParseError> {
    match ty {
        FieldType::Int32 | FieldType::Enum => Ok(FieldKind::I32(decode_varint(buf, pos)? as i32)),
        FieldType::Int64 => Ok(FieldKind::I64(decode_varint(buf, pos)? as i64)),
        FieldType::UInt32 => Ok(FieldKind::U32(decode_varint(buf, pos)? as u32)),
        FieldType::UInt64 => Ok(FieldKind::U64(decode_varint(buf, pos)?)),
        FieldType::SInt32 => Ok(FieldKind::I32(decode_zigzag32(decode_varint(buf, pos)?))),
        FieldType::SInt64 => Ok(FieldKind::I64(decode_zigzag64(decode_varint(buf, pos)?))),
        FieldType::Bool => Ok(FieldKind::Bool(decode_varint(buf, pos)? != 0)),
        FieldType::Fixed32 | FieldType::SFixed32 => Ok(FieldKind::U32(read_fixed32(buf, pos)?)),
        FieldType::Fixed64 | FieldType::SFixed64 => Ok(FieldKind::U64(read_fixed64(buf, pos)?)),
        FieldType::Float => Ok(FieldKind::F32(f32::from_bits(read_fixed32(buf, pos)?))),
        FieldType::Double => Ok(FieldKind::F64(f64::from_bits(read_fixed64(buf, pos)?))),
        _ => Err(ParseError::new("bad packed type")),
    }
}

fn decode_one(
    f: MiniField,
    buf: &[u8],
    pos: &mut usize,
    wire: u32,
    context: &mut DecodeContext<'_>,
    depth: u32,
) -> Result<FieldKind, ParseError> {
    match f.ty {
        FieldType::Int32 | FieldType::Enum => {
            if wire != WIRE_VARINT {
                skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
                return Ok(FieldKind::Empty);
            }
            Ok(FieldKind::I32(decode_varint(buf, pos)? as i32))
        }
        FieldType::Int64 => Ok(FieldKind::I64(decode_varint(buf, pos)? as i64)),
        FieldType::UInt32 => Ok(FieldKind::U32(decode_varint(buf, pos)? as u32)),
        FieldType::UInt64 => Ok(FieldKind::U64(decode_varint(buf, pos)?)),
        FieldType::SInt32 => Ok(FieldKind::I32(decode_zigzag32(decode_varint(buf, pos)?))),
        FieldType::SInt64 => Ok(FieldKind::I64(decode_zigzag64(decode_varint(buf, pos)?))),
        FieldType::Bool => Ok(FieldKind::Bool(decode_varint(buf, pos)? != 0)),
        FieldType::Fixed32 | FieldType::SFixed32 => Ok(FieldKind::U32(read_fixed32(buf, pos)?)),
        FieldType::Fixed64 | FieldType::SFixed64 => Ok(FieldKind::U64(read_fixed64(buf, pos)?)),
        FieldType::Float => Ok(FieldKind::F32(f32::from_bits(read_fixed32(buf, pos)?))),
        FieldType::Double => Ok(FieldKind::F64(f64::from_bits(read_fixed64(buf, pos)?))),
        FieldType::String | FieldType::Bytes => {
            let p = read_len_bytes(buf, pos)?;
            Ok(FieldKind::Bytes(context.arena.alloc_bytes(p.to_vec())))
        }
        FieldType::Message => {
            if wire != WIRE_LEN {
                skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
                return Ok(FieldKind::Empty);
            }
            let payload = read_len_bytes(buf, pos)?;
            let child_depth = descend(depth)?;
            let child = context.arena.alloc_msg(f.sub);
            decode_into(child, payload, context, child_depth)?;
            Ok(FieldKind::Msg(child))
        }
        FieldType::Group => {
            if wire != WIRE_SGROUP {
                skip_field_with_number_and_depth(buf, pos, f.number, wire, depth)?;
                return Ok(FieldKind::Empty);
            }
            let child_depth = descend(depth)?;
            let child = context.arena.alloc_msg(f.sub);
            decode_group_into(child, buf, pos, f.number, context, child_depth)?;
            Ok(FieldKind::Msg(child))
        }
    }
}

impl<T> ClearAndParse for T
where
    Self: SealedInternal + UpbGetMessagePtrMut + UpbGetArena,
{
    fn clear_and_parse(&mut self, data: &[u8]) -> Result<(), ParseError> {
        Clear::clear(self);
        parse_into(
            self.get_ptr_mut(Private).raw,
            data,
            self.get_arena(Private),
            true,
            0,
        )
    }
    fn clear_and_parse_dont_enforce_required(&mut self, data: &[u8]) -> Result<(), ParseError> {
        Clear::clear(self);
        parse_into(
            self.get_ptr_mut(Private).raw,
            data,
            self.get_arena(Private),
            false,
            0,
        )
    }
    fn merge_from_bytes(&mut self, data: &[u8]) -> Result<(), ParseError> {
        parse_into(
            self.get_ptr_mut(Private).raw,
            data,
            self.get_arena(Private),
            true,
            0,
        )
    }
    fn merge_from_bytes_dont_enforce_required(&mut self, data: &[u8]) -> Result<(), ParseError> {
        parse_into(
            self.get_ptr_mut(Private).raw,
            data,
            self.get_arena(Private),
            false,
            0,
        )
    }
}

impl<T> MergeFrom for T
where
    Self: SealedInternal + AsView + UpbGetArena + UpbGetMessagePtr,
    Self::Proxied: AssociatedMiniTable,
    for<'a> View<'a, Self::Proxied>: UpbGetMessagePtr,
{
    fn merge_from(&mut self, src: impl AsView<Proxied = Self::Proxied>) {
        if let Ok(bytes) = Serialize::serialize(&src.as_view()) {
            let _ = parse_into(
                self.get_ptr(Private).raw,
                &bytes,
                self.get_arena(Private),
                false,
                0,
            );
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::runtime::encode::encode_slot;
    use crate::runtime::{Arena, FieldType, MiniField, MiniTablePtr};
    use crate::wire::WIRE_LEN;

    fn string_field(repeated: bool) -> MiniField {
        MiniField {
            number: 1,
            ty: FieldType::String,
            repeated,
            packed: false,
            proto3_singular: false,
            required: false,
            is_map: false,
            sub: MiniTablePtr::dangling(),
            closed_enum: None,
            oneof_group: 0,
        }
    }

    #[test]
    fn recursion_descent_checks_the_limit_before_incrementing() {
        assert_eq!(descend(crate::RECURSION_LIMIT - 1).unwrap(), 100);
        assert!(descend(crate::RECURSION_LIMIT).is_err());
        assert!(descend(crate::RECURSION_LIMIT + 1).is_err());
        assert!(descend(u32::MAX).is_err());
    }

    #[test]
    fn message_value_at_the_limit_is_rejected_before_null_table_access() {
        let arena = Arena::new();
        let mut context = DecodeContext {
            arena: &arena,
            maps: Vec::new(),
        };
        let field = MiniField {
            ty: FieldType::Message,
            ..string_field(false)
        };
        assert!(field.sub.0.is_null());
        let mut pos = 0;
        // A present empty LEN message would otherwise allocate and enter the
        // null-MiniTable no-op parser. At entry depth 100, value depth 101 must
        // fail before either action, even though the payload is empty.
        assert!(
            decode_one(
                field,
                &[0],
                &mut pos,
                WIRE_LEN,
                &mut context,
                crate::RECURSION_LIMIT
            )
            .is_err()
        );
        assert_eq!(pos, 1);
    }

    #[test]
    fn parsed_string_storage_is_owned_by_the_arena() {
        let arena = Arena::new();
        let mut context = DecodeContext {
            arena: &arena,
            maps: Vec::new(),
        };
        let mut pos = 0;
        let field = string_field(false);
        let kind =
            decode_one(field, &[1, b'a'], &mut pos, WIRE_LEN, &mut context, 0).expect("decode");
        let mut encoded = Vec::new();
        encode_slot(&field, kind, &mut encoded);
        assert_eq!(encoded, [0x0a, 1, b'a']);
    }

    #[test]
    fn closed_enum_map_unknown_entries_do_not_replace_valid_keys() {
        use crate::runtime::{build_enum_mini_table, build_mini_table, link_mini_table};
        // Real linked mini descriptors: enum {0,1}, map<int32,closed enum>,
        // and a message containing that map at field 1. No generated output
        // is patched to provide metadata that the actual generator omits.
        let enumeration = unsafe { build_enum_mini_table("!$") };
        let entry = unsafe { build_mini_table("%(4") };
        let parent = unsafe { build_mini_table("$G") };
        unsafe {
            link_mini_table(entry, &[], &[enumeration]);
            link_mini_table(parent, &[entry], &[]);
        }
        {
            let arena = Arena::new();
            let data = arena.alloc_msg(parent);
            let known = [0x0a, 4, 8, 5, 16, 1];
            let rejected_same_key = [0x0a, 4, 8, 5, 16, 42];
            let rejected_then_valid = [0x0a, 6, 8, 7, 16, 42, 16, 1];
            let rejected_wrong_wire = [0x0a, 4, 8, 9, 18, 0];
            let missing_value = [0x0a, 2, 8, 8];
            let input = [
                known.as_slice(),
                &rejected_same_key,
                &rejected_then_valid,
                &rejected_wrong_wire,
                &missing_value,
            ]
            .concat();
            parse_into(data, &input, &arena, true, 0).unwrap();
            let FieldKind::Map(raw) = (unsafe { (&(*data).slots)[0] }) else {
                panic!("missing map");
            };
            {
                // SAFETY: this live arena contains validated I32 wire values;
                // primitive views let this test inspect the stored numbers.
                let view = unsafe { crate::MapView::<i32, i32>::from_raw_ptr(raw) };
                assert_eq!(view.len(), 2);
                assert_eq!(view.get(5), Some(1));
                assert_eq!(view.get(7), None);
                assert_eq!(view.get(8), Some(0));
                assert_eq!(view.iter().collect::<Vec<_>>(), [(5, 1), (8, 0)]);
            }
            let mut unknown = Vec::new();
            unsafe { (*data).unknown.encode(&mut unknown) };
            assert_eq!(
                unknown,
                [
                    &rejected_same_key[..],
                    &rejected_then_valid[..],
                    &rejected_wrong_wire[..]
                ]
                .concat()
            );
            let mut encoded = Vec::new();
            // Serialize this single-field message exactly as encode_msg does.
            unsafe { encode_slot(&(&(*parent.0).fields)[0], (&(*data).slots)[0], &mut encoded) };
            encoded.extend_from_slice(&unknown);
            let decoded = arena.alloc_msg(parent);
            parse_into(decoded, &encoded, &arena, true, 0).unwrap();
            let mut roundtrip_unknown = Vec::new();
            unsafe { (*decoded).unknown.encode(&mut roundtrip_unknown) };
            assert_eq!(roundtrip_unknown, unknown);
            let FieldKind::Map(roundtrip) = (unsafe { (&(*decoded).slots)[0] }) else {
                panic!("missing roundtrip map");
            };
            let view = unsafe { crate::MapView::<i32, i32>::from_raw_ptr(roundtrip) };
            assert_eq!(view.iter().collect::<Vec<_>>(), [(5, 1), (8, 0)]);
        }
        // SAFETY: arenas and all views have dropped. Each builder allocated a
        // fresh Box; none was installed in a global/generated OnceLock.
        unsafe {
            drop(Box::from_raw(parent.0.cast_mut()));
            drop(Box::from_raw(entry.0.cast_mut()));
            drop(Box::from_raw(enumeration.cast_mut()));
        }
    }
}
