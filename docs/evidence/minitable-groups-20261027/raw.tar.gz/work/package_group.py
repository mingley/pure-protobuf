"""Collect the MiniTable follow-up and its source-bound checks."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

root = Path(__file__).resolve().parents[1]
output = root / "docs/evidence/minitable-groups-20261027"
output.mkdir(parents=True, exist_ok=True)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(["git", *args], cwd=root, text=True).strip()


source = {"commit": git("rev-parse", "HEAD"), "files": {}}
for name in ["src/runtime/decode.rs", "src/runtime/encode.rs", "tests/upb_kernel/decode.rs"]:
    data = subprocess.check_output(["git", "show", f"HEAD:{name}"], cwd=root)
    source["files"][name] = sha(data)

files = {"source/manifest.json": (json.dumps(source, indent=2) + "\n").encode()}
extensions = {".rs", ".py", ".md", ".txt", ".json", ".jsonl", ".log", ".toml", ".lock", ".patch", ".proto", ".stderr", ".stdout"}
for start in [root / "work/minitable_groups/work/group_decode", root / "work/minitable_groups_cold/work/group_decode_cold", root / "work/integration-group"]:
    if not start.exists():
        continue
    for path in start.rglob("*"):
        if not path.is_file() or path.suffix not in extensions or "target" in path.relative_to(start).parts:
            continue
        data = path.read_bytes()
        if not data.startswith(b"\x7fELF"):
            files[str(path.relative_to(root))] = data
for name in ["run_group_checks.py", "package_group.py", "integration-group-driver.log", "docs-final-after-group.log"]:
    path = root / "work" / name
    if path.is_file():
        files[str(path.relative_to(root))] = path.read_bytes()

group = root / "work/minitable_groups/work/group_decode"
result = {"schema": "pbrs.minitable-groups.v1", "qualified": False, "source": source}
for key, name in [("diagnostic", "results.json"), ("alternating", "alternating-summary.json"), ("experiment", "experiment-summary.json")]:
    path = group / name
    if path.exists():
        result[key] = json.loads(path.read_text())
experiment_dir = root / "work/minitable_groups_cold/work/group_decode_cold"
for key, name in [("cold_combined", "comparison.json"), ("split_variants", "split-summary.json"), ("choice", "choice.json")]:
    path = experiment_dir / name
    if path.exists():
        result[key] = json.loads(path.read_text())
for label in ["helpers-only", "combined-only"]:
    path = experiment_dir / label / "comparison.json"
    if path.exists():
        result[label.replace("-", "_")] = json.loads(path.read_text())
check = root / "work/integration-group/results.json"
if check.exists():
    result["validation"] = json.loads(check.read_text())
(output / "results.json").write_text(json.dumps(result, indent=2) + "\n")

with tarfile.open(output / "raw.tar.gz", "w:gz") as archive:
    for name, data in sorted(files.items()):
        item = tarfile.TarInfo(name)
        item.size = len(data)
        archive.addfile(item, io.BytesIO(data))
manifest = {"schema": "pbrs.evidence-manifest.v1", "archive_sha256": sha((output / "raw.tar.gz").read_bytes()), "results_sha256": sha((output / "results.json").read_bytes()), "files": {name: {"bytes": len(data), "sha256": sha(data)} for name, data in sorted(files.items())}}
(output / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
shutil.copyfile(root / "docs/evidence/grpc-parity-and-costs-20261027/check.py", output / "check.py")
print(f"{len(files)} files; {sum(map(len, files.values()))} logical bytes")
