"""Reconstruct TC-30b2b correctness dispositions from frozen raw records."""
import hashlib
import argparse
import json
import pathlib
import re
import subprocess
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--raw-dir", type=pathlib.Path, default=pathlib.Path(__file__).resolve().parent)
parser.add_argument("--complete", action="store_true")
parser.add_argument("--combined", action="store_true", help="Require the distinct integrated-backend proof")
args = parser.parse_args()
root = pathlib.Path(subprocess.check_output(["git", "rev-parse", "--show-toplevel"], text=True).strip())
raw = args.raw_dir.resolve()
previous_source = "3ac287ab2a58c26f427db96852851bb3c3d3420b"
source = "051f5ed8e5a0064b4d06527713db9dc61997abbf"
baseline = "20ad8ebd95058ae77885830b980f121bdad8b194"
empty_patch = hashlib.sha256(b"").hexdigest()


def record(name):
    value = json.loads((raw / (name + ".json")).read_text())
    assert value["exit"] == int((raw / (name + ".exit")).read_text()), name
    assert value["source_before"] == value["source_after"], name
    assert not value["tracked_changes_before"] and not value["tracked_changes_after"], name
    assert value["patch_sha256"] == empty_patch, name
    return value


final_counts = {}
for name in ["private-framing-final", "native-optout-final", "native-regressions-corrected", "generated-services-retry"]:
    value = record(name)
    assert value["source_before"] == previous_source and value["exit"] == 0, name
    assert value["native_exit"] == 0 and value["disk_guard"] is None, name
    assert value["argv"][:3] == ["rustup", "run", "1.88.0"], name
    assert value["environment"]["CARGO_BUILD_JOBS"] == "1", name
    results = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", (raw / (name + ".log")).read_text())
    assert results and all(x[0] == "ok" and int(x[2]) == 0 for x in results), name
    final_counts[name] = sum(int(x[1]) for x in results)
assert final_counts == {"private-framing-final": 19, "native-optout-final": 18, "native-regressions-corrected": 105, "generated-services-retry": 38}, final_counts
assert sum(final_counts.values()) == 180

for name in ["baseline-identity-red", "baseline-all-optout-red"]:
    value = record(name)
    assert value["source_before"] == baseline and value["exit"] == 101, name
    log = (raw / (name + ".log")).read_text()
    assert 'left: "9"' in log and 'right: "0"' in log, name
    expected_failed = 1 if name == "baseline-identity-red" else 3
    assert re.search(r"test result: FAILED\. 0 passed; " + str(expected_failed) + " failed;", log), name
for name in ["baseline-header-characterization", "baseline-default-characterization"]:
    value = record(name)
    assert value["source_before"] == baseline and value["exit"] == 0, name
    assert "test result: ok. 1 passed; 0 failed;" in (raw / (name + ".log")).read_text(), name

guard = record("generated-services-final")
assert guard["source_before"] == previous_source and guard["exit"] == 125
assert guard["native_exit"] == -15
assert guard["disk_guard"]["free"] < 2 * 1024**3
assert guard["disk_guard"]["owned_cache_bytes"] <= 2 * 1024**3
assert "test result:" not in (raw / "generated-services-final.log").read_text()
wrong_target = record("native-regressions-final")
assert wrong_target["source_before"] == previous_source and wrong_target["exit"] == 101
assert "no test target named" in (raw / "native-regressions-final.log").read_text()
assert "test result:" not in (raw / "native-regressions-final.log").read_text()

for filename, pin in [("previous-source.json", previous_source), ("final-source.json", source)]:
    pins = json.loads((raw / filename).read_text())
    assert pins["source"] == pin
    for path, sha256 in pins["sha256"].items():
        content = subprocess.check_output(["git", "show", pin + ":" + path], cwd=root)
        assert hashlib.sha256(content).hexdigest() == sha256, path
    assert all(pins["unchanged_manifests_locks"].values())
    assert pins["unchanged_default_incoming_and_drain"]["equal"]

previous_clippy = record("native-clippy-final")
assert previous_clippy["source_before"] == previous_source and previous_clippy["exit"] == 0

standalone_clippy = record("generated-clippy-final")
assert standalone_clippy["source_before"] == source and standalone_clippy["exit"] == 101
standalone_clippy_log = (raw / "generated-clippy-final.log").read_text()
assert "src/main.rs:837" in standalone_clippy_log and "src/main.rs:871" in standalone_clippy_log
assert standalone_clippy_log.count("error: variables can be used directly") == 2

strict = ["private-framing-replay", "native-affected-replay", "generated-services-replay", "native-clippy-replay", "rustdoc-final", "msrv-feature-off-final", "default-tree-final", "root-format-final", "owned-fixture-format-final", "whitespace-final"]
missing = [name for name in strict if not (raw / (name + ".json")).exists()]
if args.complete:
    assert not missing, missing
for name in strict:
    if name in missing:
        continue
    value = record(name)
    assert value["source_before"] == source and value["exit"] == 0 and value["disk_guard"] is None, name
    argv = value["argv"]
    if name in ["native-clippy-replay", "generated-clippy-final"]:
        assert argv[:5] == ["rustup", "run", "1.88.0", "cargo", "clippy"], name
        assert argv[-3:] == ["--", "-D", "warnings"] and "--all-targets" in argv, name
    elif name == "rustdoc-final":
        assert argv[:5] == ["rustup", "run", "1.88.0", "cargo", "doc"], name
        assert value["environment"]["RUSTDOCFLAGS"] == "-D warnings", name
    elif name == "msrv-feature-off-final":
        assert argv[:5] == ["rustup", "run", "1.85.0", "cargo", "check"], name
        assert "--no-default-features" in argv and "--lib" in argv, name
    elif name == "default-tree-final":
        assert "--no-default-features" in argv and "normal" in argv, name
        assert not re.search(r"^tonic(?:-| )", (raw / (name + ".log")).read_text(), re.MULTILINE), name
replay_counts = {}
for name in ["private-framing-replay", "native-affected-replay", "generated-services-replay"]:
    if name not in missing:
        results = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", (raw / (name + ".log")).read_text())
        assert results and all(x[0] == "ok" and int(x[2]) == 0 for x in results), name
        replay_counts[name] = sum(int(x[1]) for x in results)
if args.complete:
    assert replay_counts == {"private-framing-replay": 19, "native-affected-replay": 38, "generated-services-replay": 38}, replay_counts
combined_result = "pending"
if args.combined:
    pins = json.loads((raw / "combined-source.json").read_text())
    combined_source = pins["source"]
    assert pins["previous_optout_source"] == source
    assert pins["parents"] == [source, pins["integrated_main"]]
    assert all(pins["optout_paths_byte_identical_to_051f"].values())
    assert all(pins["manifests_locks_equal_to_integrated_main"].values())
    assert all(pins["backend_rust_equal_to_qualified_source"].values())
    assert set(subprocess.check_output(["git", "diff", "--name-only", pins["integrated_main"], combined_source], cwd=root, text=True).splitlines()) == set(pins["only_optout_paths_differ_from_main"])
    for path, digest in pins["sha256"].items():
        assert hashlib.sha256(subprocess.check_output(["git", "show", combined_source + ":" + path], cwd=root)).hexdigest() == digest, path
    for path, digest in pins["backend_sha256"].items():
        assert hashlib.sha256(subprocess.check_output(["git", "show", combined_source + ":" + path], cwd=root)).hexdigest() == digest, path
        assert hashlib.sha256(subprocess.check_output(["git", "show", pins["integrated_main"] + ":" + path], cwd=root)).hexdigest() == digest, path
        if path.endswith(".rs"):
            assert hashlib.sha256(subprocess.check_output(["git", "show", pins["qualified_backend_source"] + ":" + path], cwd=root)).hexdigest() == digest, path
    names = ["combined-private-replay", "combined-native-replay", "combined-generated-replay", "combined-native-clippy", "combined-generated-clippy", "combined-rustdoc", "combined-msrv-feature-off", "combined-default-tree", "combined-root-format", "combined-fixture-format", "combined-whitespace"]
    counts = {}
    for name in names:
        value = record(name)
        assert value["source_before"] == combined_source and value["exit"] == value["native_exit"] == 0 and value["disk_guard"] is None, name
        assert value["environment"]["CARGO_BUILD_JOBS"] == "1", name
        argv = value["argv"]
        if "replay" in name or "clippy" in name or "rustdoc" in name:
            assert argv[:3] == ["rustup", "run", "1.88.0"], name
        if "clippy" in name:
            assert argv[3:5] == ["cargo", "clippy"] and "--all-targets" in argv and argv[-3:] == ["--", "-D", "warnings"], name
        if name == "combined-rustdoc":
            assert value["environment"]["RUSTDOCFLAGS"] == "-D warnings", name
        if name == "combined-msrv-feature-off":
            assert argv[:5] == ["rustup", "run", "1.85.0", "cargo", "check"] and "--no-default-features" in argv and "--lib" in argv, name
        if name == "combined-default-tree":
            assert "--no-default-features" in argv and "normal" in argv, name
            assert not re.search(r"^tonic(?:-| )", (raw / (name + ".log")).read_text(), re.MULTILINE), name
        if "replay" in name:
            results = re.findall(r"test result: (\w+)\. (\d+) passed; (\d+) failed; (\d+) ignored; (\d+) measured; (\d+) filtered out", (raw / (name + ".log")).read_text())
            assert results and all(x[0] == "ok" and int(x[2]) == 0 for x in results), name
            counts[name] = sum(int(x[1]) for x in results)
    assert counts == {"combined-private-replay": 19, "combined-native-replay": 38, "combined-generated-replay": 38}, counts
    combined_result = {"source": combined_source, "passing_executions": counts, "total": sum(counts.values()), "strict_gates": names[3:]}
result = {"source": source, "previous_source": previous_source, "previous_passing_executions": final_counts, "previous_total": 180, "final_passing_replay_executions": replay_counts, "final_total": sum(replay_counts.values()), "32_bit_execution": "not_run", "baseline_and_guard_failures_preserved": True, "missing_gates": missing, "standalone_strict_clippy_at_051f": "failed: two preexisting uninlined-format-args, preserved", "combined_source_replay": combined_result, "shipping_correctness_proof_complete": args.combined, "performance_qualified": False}
print(json.dumps(result, indent=2))
