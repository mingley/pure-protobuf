"""Pin completed test ELF/generated output before reclaiming this owned cache."""
import datetime
import hashlib
import json
import pathlib
import re
import subprocess
import sys

root = pathlib.Path(__file__).resolve().parents[2]
cache = root / "target"
active = []
for proc in pathlib.Path("/proc").glob("[0-9]*"):
    try:
        exe = (proc / "exe").resolve(strict=True)
        argv = (proc / "cmdline").read_bytes().replace(b"\0", b" ").decode(errors="replace")
        uses_cache = str(exe).startswith(str(cache) + "/")
        if exe.name in {"cargo", "rustc", "rustdoc", "clippy-driver"}:
            env = (proc / "environ").read_bytes().split(b"\0")
            uses_cache |= any(x.startswith(b"CARGO_TARGET_DIR=") and str(cache).encode() in x for x in env)
            uses_cache |= str(cache) in argv
        if uses_cache:
            stat = (proc / "stat").read_text()
            active.append({"pid": int(proc.name), "start_ticks": stat.rsplit(")", 1)[1].split()[19], "exe": str(exe), "argv": argv})
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass
assert not active, active
artifacts = []
for path in sorted(cache.rglob("*")):
    if not path.is_file():
        continue
    generated = path.suffix == ".rs" and "out" in path.parts
    elf = False
    if path.parent.name in {"deps", "examples"} and path.suffix == "":
        with path.open("rb") as handle:
            elf = handle.read(4) == b"\x7fELF"
    if generated or elf:
        artifacts.append({"path": str(path.relative_to(root)), "kind": "generated_rust" if generated else "elf", "bytes": path.stat().st_size, "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
value = {"source": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(), "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "active_cache_consumers": active, "du_bytes": int(subprocess.check_output(["du", "-sb", str(cache)], text=True).split()[0]), "elf_count": sum(x["kind"] == "elf" for x in artifacts), "generated_count": sum(x["kind"] == "generated_rust" for x in artifacts), "artifacts": artifacts, "scope": "post-command artifact fingerprints; not an allocation, performance, or process-lifetime qualification"}
(root / "work/tc30b3a" / sys.argv[1]).write_text(json.dumps(value, indent=2) + "\n")
print(json.dumps({k: v for k, v in value.items() if k != "artifacts"}, indent=2))
