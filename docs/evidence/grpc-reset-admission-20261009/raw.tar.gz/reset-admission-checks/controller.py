"""Check the candidate without replacing failed baseline outcomes."""
import hashlib,json,os,subprocess,time
from pathlib import Path
ROOT=Path('/workspace/pure-protobuf');OUT=ROOT/'work/reset-admission-checks';OUT.mkdir(exist_ok=False)
paths=['pbrs-grpc/src/server/connection.rs','pbrs-grpc/src/server/connection/reset_admission_tests.rs','.github/workflows/ci.yml']
def hashes():return {p:hashlib.sha256((ROOT/p).read_bytes()).hexdigest() for p in paths}
snapshot=hashes();report=dict(base_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),dirty=True,state='running',qualified=False,source_files=snapshot,steps=[])
(OUT/'controller.py').write_bytes(Path(__file__).read_bytes())
os.environ['PROTOC']=str(ROOT/'work/toolchain/protoc/bin/protoc');os.environ['PATH']=str(ROOT/'work/toolchain/protoc/bin')+os.pathsep+os.environ['PATH']
for name,selector in [('unit',['--lib']),('resource_bounds',['--test','resource_bounds']),('serving',['--test','serving']),('early_upload_response',['--test','early_upload_response'])]:
 assert hashes()==snapshot
 directory=OUT/name;directory.mkdir();args=[str(ROOT/'work/run-rust'),'cargo','test','--locked','-p','pbrs-grpc','--all-features',*selector,'--message-format=json','--','--test-threads=1'];start=time.monotonic()
 with (directory/'stdout').open('w') as out,(directory/'stderr').open('w') as err:p=subprocess.run(args,cwd=ROOT,stdout=out,stderr=err)
 artifacts=[]
 for line in (directory/'stdout').read_text().splitlines():
  try:m=json.loads(line)
  except json.JSONDecodeError:continue
  if m.get('reason')=='compiler-artifact' and m.get('manifest_path')==str(ROOT/'pbrs-grpc/Cargo.toml') and m.get('target',{}).get('name')==('pbrs_grpc' if name=='unit' else name) and m.get('profile',{}).get('test') and m.get('executable'):artifacts.append(m)
 row=dict(name=name,command=args,exit_code=p.returncode,elapsed_seconds=time.monotonic()-start,source_unchanged=hashes()==snapshot)
 if len(artifacts)==1:
  binary=Path(artifacts[0]['executable']);h=hashlib.sha256()
  with binary.open('rb') as stream:
   for block in iter(lambda:stream.read(1024*1024),b''):h.update(block)
  row.update(artifact=artifacts[0],executable_sha256=h.hexdigest())
 else:row['artifact_error']='expected one compiler-selected executable'
 report['steps'].append(row);(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n');print(name,p.returncode,flush=True)
report.update(state='finished',passed=all(row['exit_code']==0 and row['source_unchanged'] and 'artifact_error' not in row for row in report['steps']));(OUT/'results.json').write_text(json.dumps(report,indent=2)+'\n')
