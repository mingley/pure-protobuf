#!/usr/bin/env python3
from datetime import datetime,timezone
import hashlib,json,os
from pathlib import Path
import subprocess,time

ROOT=Path('/workspace/pure-protobuf')
HERE=Path(__file__).resolve().parent
TARGET=ROOT/'target/safe-defaults-20261105'
source=HERE/'layouts-cached.rs'
env=os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'))
env['PATH']=str(ROOT/'work/cargo/bin')+':'+env['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
record={'source_sha256':sha(source),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'runtime_build':'runtime-build-release.json','runtime_build_sha256':sha(HERE/'runtime-build-release.json'),'builds':[]}
assert not (HERE/'layout-cache-builds.json').exists()
for opt in [0,3]:
    for variant in ['zeroed','derived']:
        base=HERE/f'{variant}-o{opt}-cache'
        command=['rustc','--edition=2024','--crate-name','default_layouts',str(source),'--extern',f'pbrs={TARGET}/release/libpbrs.rlib','-L',f'dependency={TARGET}/release/deps','-C',f'opt-level={opt}','-C','codegen-units=1','-C','debuginfo=0','-C','strip=symbols','--emit',f'asm={base}.s,link={base}']
        if variant=='derived':command.extend(['--cfg','safe_defaults'])
        begin=time.monotonic()
        result=subprocess.run(command,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        base.with_suffix('.stdout').write_bytes(result.stdout)
        base.with_suffix('.stderr').write_bytes(result.stderr)
        row={'variant':variant,'opt_level':opt,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-begin}
        if result.returncode==0:
            row['binary_sha256']=sha(base)
            row['assembly_sha256']=sha(Path(str(base)+'.s'))
            row['precheck']=subprocess.check_output([str(base),'check'],text=True).strip()
            row['layout']=subprocess.check_output([str(base),'layout'],text=True).strip()
        record['builds'].append(row)
        print(json.dumps(row))
        if result.returncode:break
    if result.returncode:break
record['finished_utc']=datetime.now(timezone.utc).isoformat()
(HERE/'layout-cache-builds.json').write_text(json.dumps(record,indent=2)+'\n')
assert all(row['exit_code']==0 for row in record['builds']) and len(record['builds'])==4
assert len(set(row['layout'] for row in record['builds']))==1
