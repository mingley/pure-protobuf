#!/usr/bin/env python3
from datetime import datetime,timezone
import hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path

HERE=Path(__file__).resolve().parent
CASES=['small','hot','optional','collections','cold','cold_outer','owned','small_cache','hot_cache','optional_cache','owned_cache']
OUT=HERE/'layout-screen'
assert not OUT.exists()
OUT.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
available=sorted(os.sched_getaffinity(0))
cpu=available[0]
os.sched_setaffinity(0,{cpu})
report={'scope':'Synthetic actual-storage-layout construction/drop and immediate cache-read, internal elapsed wall time; excludes process startup and is not generated parse or RPC timing','started_utc':datetime.now(timezone.utc).isoformat(),'cpu':cpu,'prior_affinity':available,'host_load_before':Path('/proc/loadavg').read_text().strip(),'runner_sha256':sha(Path(__file__)),'source_sha256':sha(HERE/'layouts-cached.rs'),'builds_sha256':sha(HERE/'layout-cache-builds.json'),'binaries_sha256':{f'{variant}-o{opt}-cache':sha(HERE/f'{variant}-o{opt}-cache') for variant in ['zeroed','derived'] for opt in [0,3]},'captures':[]}
rng=random.Random(53021)
begin=time.monotonic()
for repeat in range(5):
    rows=[(opt,case) for opt in [0,3] for case in CASES]
    rng.shuffle(rows)
    for opt,case in rows:
        count=300_000 if opt==0 else 2_000_000
        variants=['zeroed','derived']
        rng.shuffle(variants)
        values={}
        for variant in variants:
            command=[str(HERE/f'{variant}-o{opt}-cache'),case,str(count)]
            result=subprocess.run(command,cwd=HERE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            name=f'r{repeat}-o{opt}-{case}-{variant}'
            (OUT/(name+'.stdout')).write_text(result.stdout)
            (OUT/(name+'.stderr')).write_text(result.stderr)
            assert result.returncode==0,(name,result.stderr)
            value=json.loads(result.stdout)
            assert value['case']==case and value['iterations']==count and value['safe_defaults']==(variant=='derived')
            values[variant]=value['wall_ns']/count
            report['captures'].append({'id':name,'repeat':repeat,'opt_level':opt,'case':case,'variant':variant,'command':command,'exit_code':result.returncode,'ns_per_op':values[variant],'stdout_sha256':sha(OUT/(name+'.stdout')),'stderr_sha256':sha(OUT/(name+'.stderr'))})
        # Preserve grouping rather than reconstructing by file-name ordering.
        assert set(values)==set(variants)
report['rows']=[]
for opt in [0,3]:
    for case in CASES:
        ratios=[]
        zeroed=[]
        derived=[]
        for repeat in range(5):
            pair={row['variant']:row['ns_per_op'] for row in report['captures'] if row['opt_level']==opt and row['case']==case and row['repeat']==repeat}
            ratios.append(pair['derived']/pair['zeroed'])
            zeroed.append(pair['zeroed'])
            derived.append(pair['derived'])
        report['rows'].append({'opt_level':opt,'case':case,'paired_new_old':ratios,'median_new_old':statistics.median(ratios),'range_new_old':[min(ratios),max(ratios)],'median_ns_zeroed':statistics.median(zeroed),'median_ns_derived':statistics.median(derived)})
report['elapsed_seconds']=time.monotonic()-begin
report['host_load_after']=Path('/proc/loadavg').read_text().strip()
report['finished_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({key:value for key,value in report.items() if key!='captures'},indent=2))
