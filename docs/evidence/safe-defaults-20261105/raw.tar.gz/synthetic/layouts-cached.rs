//! Synthetic representations with the same storage families emitted by pbrs.
#![allow(dead_code)]
use pbrs::{Map, ProtoString, Repeated};
use pbrs::rt::{CachedSize, CachedSize32, LazyBytes, LazyMsg, LazyStr, OptBool, PackedBool, PackedF64, PackedI32, UnknownFields};
use std::hint::black_box;
use std::time::Instant;

macro_rules! message {
    ($name:ident { $($field:ident: $ty:ty),* $(,)? }) => {
        #[cfg_attr(safe_defaults, derive(Default))]
        struct $name { $($field: $ty),* }
        #[cfg(not(safe_defaults))]
        impl Default for $name {
            #[inline(always)]
            fn default() -> Self {
                // Baseline expression from generated pbrs0ae8a43d bindings;
                // each field family here is valid in its observed zero state.
                unsafe { pbrs::rt::zeroed_message() }
            }
        }
    };
}

message!(Child { value: i64, unknown: UnknownFields, cache: CachedSize });
message!(Small { seconds: i64, nanos: i32, unknown: UnknownFields, cache: CachedSize });
message!(Hot {
    route: LazyStr,
    method: LazyStr,
    payload: LazyBytes,
    id: i64,
    count: i32,
    enabled: bool,
    tags: Repeated<LazyStr>,
    nested: LazyMsg<Child>,
    unknown: UnknownFields,
    cache: CachedSize,
});
message!(Optional {
    flag: OptBool,
    i32: Option<i32>,
    i64: Option<i64>,
    u32: Option<u32>,
    u64: Option<u64>,
    f32: Option<f32>,
    f64: Option<f64>,
    string: Option<Box<LazyStr>>,
    bytes: Option<Box<LazyBytes>>,
    nested: Option<Box<Child>>,
    unknown: UnknownFields,
    cache: CachedSize,
});
message!(Collections {
    labels: Map<ProtoString, i64>,
    payloads: Map<i32, LazyBytes>,
    integers: PackedI32,
    floats: PackedF64,
    bools: PackedBool,
    text: Repeated<LazyStr>,
    bytes: Repeated<LazyBytes>,
    children: Repeated<Child>,
    unknown: UnknownFields,
    cache: CachedSize,
});
message!(Cold {
    a: LazyStr, b: LazyStr, c: LazyStr, d: LazyBytes,
    e: LazyBytes, f: LazyBytes, g: LazyStr, h: LazyBytes,
    labels: Map<ProtoString, i64>, payloads: Map<i32, LazyBytes>,
    opt: Option<u64>, nested: LazyMsg<Child>,
});
message!(ColdOuter { id: u64, cold: Option<Box<Cold>>, unknown: UnknownFields, cache: CachedSize });
message!(Owned {
    id: u64,
    route: LazyStr,
    child: Option<Box<Child>>,
    children: Repeated<Child>,
    unknown: UnknownFields,
    cache: CachedSize32,
});

// Keep constructor bodies inspectable independently of the caller.
macro_rules! ctor {
    ($fn:ident, $ty:ty) => {
        #[inline(never)]
        fn $fn() -> $ty { <$ty>::default() }
    }
}
ctor!(make_small, Small);
ctor!(make_hot, Hot);
ctor!(make_optional, Optional);
ctor!(make_collections, Collections);
ctor!(make_cold, Cold);
ctor!(make_cold_outer, ColdOuter);
ctor!(make_owned, Owned);

fn check() {
    let value = Hot::default();
    assert!(value.route.as_bytes().is_empty());
    assert!(value.method.as_bytes().is_empty());
    assert!(value.payload.as_bytes().is_empty());
    assert_eq!((value.id, value.count, value.enabled), (0, 0, false));
    assert!(value.tags.is_empty() && value.nested.is_none());
    assert!(value.unknown.fields.is_empty());
    assert_eq!(value.cache.get(), Some(0));
    let value = Optional::default();
    assert!(value.flag.is_none());
    assert!(value.i32.is_none() && value.i64.is_none());
    assert!(value.u32.is_none() && value.u64.is_none());
    assert!(value.f32.is_none() && value.f64.is_none());
    assert!(value.string.is_none() && value.bytes.is_none() && value.nested.is_none());
    assert!(value.unknown.fields.is_empty());
    assert_eq!(value.cache.get(), Some(0));
    let value = Collections::default();
    assert!(value.labels.is_empty() && value.payloads.is_empty());
    assert!(value.integers.is_empty() && value.floats.is_empty() && value.bools.is_empty());
    assert!(value.text.is_empty() && value.bytes.is_empty() && value.children.is_empty());
    assert!(value.unknown.fields.is_empty());
    assert_eq!(value.cache.get(), Some(0));
    let value = Cold::default();
    assert!(value.a.is_empty() && value.b.is_empty() && value.c.is_empty() && value.d.is_empty());
    assert!(value.e.is_empty() && value.f.is_empty() && value.g.is_empty() && value.h.is_empty());
    assert!(value.labels.is_empty() && value.payloads.is_empty());
    assert!(value.opt.is_none() && value.nested.is_none());
    let value = ColdOuter::default();
    assert_eq!(value.id, 0);
    assert!(value.cold.is_none() && value.unknown.fields.is_empty());
    assert_eq!(value.cache.get(), Some(0));
    let value = Owned::default();
    assert_eq!(value.id, 0);
    assert!(value.route.is_empty() && value.child.is_none() && value.children.is_empty());
    assert_eq!(value.cache.get(), Some(0));
    println!("CHECK default field semantics and drop passed");
}

macro_rules! timed {
    ($make:ident, $count:expr) => {{
        let begin = Instant::now();
        for _ in 0..$count {
            let value = $make();
            black_box(&value);
            drop(value);
        }
        begin.elapsed().as_nanos()
    }};
}

macro_rules! timed_cache {
    ($make:ident, $count:expr) => {{
        let begin = Instant::now();
        for _ in 0..$count {
            let value = $make();
            black_box(&value);
            black_box(value.cache.get());
            drop(value);
        }
        begin.elapsed().as_nanos()
    }};
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    if args.get(1).map(String::as_str) == Some("check") { check(); return; }
    if args.get(1).map(String::as_str) == Some("layout") {
        println!("small={},hot={},optional={},collections={},cold={},cold_outer={},owned={}", std::mem::size_of::<Small>(), std::mem::size_of::<Hot>(), std::mem::size_of::<Optional>(), std::mem::size_of::<Collections>(), std::mem::size_of::<Cold>(), std::mem::size_of::<ColdOuter>(), std::mem::size_of::<Owned>());
        return;
    }
    let count: u64 = args.get(2).expect("ITERATIONS").parse().unwrap();
    let wall = match args.get(1).expect("CASE").as_str() {
        "small_cache" => timed_cache!(make_small, count),
        "hot_cache" => timed_cache!(make_hot, count),
        "optional_cache" => timed_cache!(make_optional, count),
        "owned_cache" => timed_cache!(make_owned, count),
        "small" => timed!(make_small, count),
        "hot" => timed!(make_hot, count),
        "optional" => timed!(make_optional, count),
        "collections" => timed!(make_collections, count),
        "cold" => timed!(make_cold, count),
        "cold_outer" => timed!(make_cold_outer, count),
        "owned" => timed!(make_owned, count),
        _ => panic!("unknown CASE"),
    };
    println!("{{\"case\":\"{}\",\"iterations\":{},\"wall_ns\":{},\"safe_defaults\":{}}}", args[1],count,wall,cfg!(safe_defaults));
}
