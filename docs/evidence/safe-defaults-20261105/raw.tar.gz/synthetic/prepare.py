#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
BASE = '0ae8a43d3d08617c249c84a3f0d30f614494d70e'
SELECTED = ['Cargo.toml', 'Cargo.lock', 'build.rs', 'clippy.toml', 'rustfmt.toml', 'src', 'vendor/google/conformance_fds.bin']
paths = subprocess.check_output(['git', 'ls-tree', '-r', '--name-only', BASE, '--', *SELECTED], cwd=ROOT, text=True).splitlines()
source = {name: subprocess.check_output(['git', 'show', f'{BASE}:{name}'], cwd=ROOT) for name in paths}
sha = lambda b: hashlib.sha256(b).hexdigest()
report = {'baseline_commit': BASE, 'scope': 'Isolated Git core snapshot, runtime-only dependency for a synthetic generated-layout Default prototype', 'original_sha256': {name: sha(value) for name, value in source.items()}}
manifest = source['Cargo.toml'].decode()
source['Cargo.toml'] = ('[workspace]\nresolver = "2"\n\n' + manifest[manifest.index('[package]'):]).encode()
report['manifest_adaptation'] = 'Root-only workspace, all package/dependency/feature/lint configuration unchanged'
report['adapted_sha256'] = {name: sha(value) for name, value in source.items()}
folder = HERE / 'runtime'
assert not folder.exists()
for name, value in source.items():
    destination = folder / name
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(value)
(HERE / 'source-plan.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'exported_files': len(source), 'baseline': BASE}))
