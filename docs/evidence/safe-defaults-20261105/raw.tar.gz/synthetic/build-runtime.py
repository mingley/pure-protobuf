#!/usr/bin/env python3
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
TARGET = ROOT / 'target/safe-defaults-20261105'
ATTEMPT = sys.argv[1] if len(sys.argv)>1 else 'initial'
assert ATTEMPT.isalnum()
PREFIX = 'runtime-build' if ATTEMPT == 'initial' else f'runtime-build-{ATTEMPT}'
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'work/cargo'), RUSTUP_HOME=str(ROOT/'work/rustup'), CARGO_TARGET_DIR=str(TARGET), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='0')
env['PATH'] = str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
plan = json.loads((HERE/'source-plan.json').read_text())
before = {name: sha(HERE/'runtime'/name) for name in plan['adapted_sha256']}
assert before == plan['adapted_sha256']
assert shutil.disk_usage(ROOT).free > 1024**3
command = ['cargo', 'build', '--locked', '--offline', '--manifest-path', str(HERE/'runtime/Cargo.toml'), '--lib', '--no-default-features', '--message-format=json']
if ATTEMPT == 'release':
    command.append('--release')
assert not (HERE/(PREFIX+'.json')).exists()
start = time.monotonic()
with (HERE/(PREFIX+'.jsonl')).open('w') as out, (HERE/(PREFIX+'.stderr')).open('w') as err:
    result = subprocess.run(command, cwd=ROOT, env=env, stdout=out, stderr=err)
after = {name: sha(HERE/'runtime'/name) for name in plan['adapted_sha256']}
report = {'command': command, 'exit_code': result.returncode, 'elapsed_seconds': time.monotonic()-start, 'finished_utc': datetime.now(timezone.utc).isoformat(), 'rustc': subprocess.check_output(['rustc', '-Vv'], cwd=ROOT, env=env, text=True), 'source_unchanged': before == after, 'inputs_sha256': before}
artifacts = [json.loads(line) for line in (HERE/(PREFIX+'.jsonl')).read_text().splitlines() if line.startswith('{')]
for artifact in artifacts:
    if artifact.get('reason') == 'compiler-artifact' and artifact.get('target',{}).get('name') == 'pbrs':
        report['runtime_artifacts'] = {name: sha(Path(name)) for name in artifact['filenames']}
(HERE/(PREFIX+'.json')).write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='inputs_sha256'}, indent=2))
raise SystemExit(result.returncode or (0 if before == after else 2))
