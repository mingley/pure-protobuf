#!/usr/bin/env python3
"""Freeze generated ordinary/safe consumers with matched dependency caches."""
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,time
from pathlib import Path

ROOT=Path('/workspace/pure-protobuf')
HERE=Path(__file__).resolve().parent
PROOF=ROOT/'tests/proof/safe_defaults'
OUT=HERE/'generated-builds'
assert not OUT.exists()
OUT.mkdir()
env=os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def inventory():
    paths=subprocess.check_output(['git','ls-files','--cached','--others','--exclude-standard','-z','--','src','Cargo.toml','Cargo.lock','build.rs','clippy.toml','rustfmt.toml','vendor/google/conformance_fds.bin','tests/proof/safe_defaults'],cwd=ROOT).decode().split('\0')
    return {p:sha(ROOT/p) for p in sorted(set(paths)) if p and (ROOT/p).is_file()}
before=inventory()
record={'scope':'Actual generated binary-only lazy consumer. Ordinary versus safe-message defaults; first Cargo builds have shared dependency-cache limits, not a controlled clean-build benchmark.','started_utc':datetime.now(timezone.utc).isoformat(),'rustc':subprocess.check_output(['rustc','-Vv'],env=env,text=True),'inputs_sha256':before,'builds':[]}
for profile in ['dev','release']:
    for variant in ['ordinary','safe']:
        name=f'{variant}-{profile}'
        command=['cargo','build','--locked','--offline','--manifest-path',str(PROOF/'Cargo.toml'),'--message-format=json']
        if variant=='ordinary':command+=['--features','ordinary-control']
        if profile=='release':command+=['--release']
        begin=time.monotonic()
        result=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True)
        (OUT/(name+'.stdout')).write_text(result.stdout)
        (OUT/(name+'.stderr')).write_text(result.stderr)
        row={'name':name,'command':command,'exit_code':result.returncode,'elapsed_seconds':time.monotonic()-begin}
        assert result.returncode==0,(row,result.stderr)
        records=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
        executable=next(x['executable'] for x in records if x.get('reason')=='compiler-artifact' and x.get('target',{}).get('name')=='pbrs-safe-defaults-proof' and x.get('executable'))
        binary=OUT/name
        shutil.copy2(executable,binary)
        row['binary_sha256']=sha(binary)
        row['binary_bytes']=binary.stat().st_size
        row['precheck']=subprocess.check_output([str(binary)],cwd=ROOT,text=True)
        assert row['precheck'].count('PASS ')==4
        script=next(x for x in records if x.get('reason')=='build-script-executed' and 'pbrs-safe-defaults-proof' in x.get('package_id',''))
        generated=Path(script['out_dir'])
        row['generated']={name:{'bytes':(generated/name).stat().st_size,'sha256':sha(generated/name)} for name in ['legacy.rs','record.rs','mod.rs']}
        record['builds'].append(row)
        print(json.dumps(row))
after=inventory()
record['source_inputs_unchanged']=before==after
record['changed_source_files']=sorted(p for p in set(before)|set(after) if before.get(p)!=after.get(p))
record['finished_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'report.json').write_text(json.dumps(record,indent=2)+'\n')
assert before==after
