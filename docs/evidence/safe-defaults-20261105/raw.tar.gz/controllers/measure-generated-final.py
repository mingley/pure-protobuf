#!/usr/bin/env python3
from datetime import datetime,timezone
import hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path

HERE=Path(__file__).resolve().parent
BIN=HERE/'generated-builds-final'
OUT=HERE/'generated-screen-final'
assert not OUT.exists()
OUT.mkdir()
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cases={'dev':{'default':150_000,'empty_encode':40_000,'parse':10_000,'read_all':5_000},'release':{'default':2_000_000,'empty_encode':1_000_000,'parse':75_000,'read_all':50_000}}
before=sorted(os.sched_getaffinity(0))
os.sched_setaffinity(0,{before[0]})
rng=random.Random(53119)
report={'scope':'Actual generated lazy-message consumer, internal elapsed wall per operation; excludes input preparation and startup; not an RPC/Prost comparison','started_utc':datetime.now(timezone.utc).isoformat(),'prior_affinity':before,'cpu':before[0],'host_load_before':Path('/proc/loadavg').read_text().strip(),'build_report_sha256':sha(BIN/'report.json'),'runner_sha256':sha(Path(__file__)),'captures':[]}
start=time.monotonic()
for repeat in range(5):
    rows=[(profile,case,count) for profile,items in cases.items() for case,count in items.items()]
    rng.shuffle(rows)
    for profile,case,count in rows:
        variants=['ordinary','safe']
        rng.shuffle(variants)
        for variant in variants:
            command=[str(BIN/f'{variant}-{profile}'),case,str(count)]
            result=subprocess.run(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
            name=f'r{repeat}-{profile}-{case}-{variant}'
            (OUT/(name+'.stdout')).write_text(result.stdout)
            (OUT/(name+'.stderr')).write_text(result.stderr)
            assert result.returncode==0,(name,result.stderr)
            value=json.loads(result.stdout)
            assert value['case']==case and value['iterations']==count and value['ordinary']==(variant=='ordinary')
            report['captures'].append({'id':name,'repeat':repeat,'profile':profile,'case':case,'variant':variant,'command':command,'exit_code':result.returncode,'value':value,'stdout_sha256':sha(OUT/(name+'.stdout')),'stderr_sha256':sha(OUT/(name+'.stderr'))})
identities={(r['value']['input_wire_hex'],r['value']['expected_checksum'],r['value']['record_size'],r['value']['presence_size']) for r in report['captures']}
assert len(identities)==1,identities
report['rows']=[]
for profile,items in cases.items():
    for case in items:
        ratios=[]
        old=[]
        new=[]
        for repeat in range(5):
            pair={r['variant']:r['value']['wall_ns']/r['value']['iterations'] for r in report['captures'] if r['profile']==profile and r['case']==case and r['repeat']==repeat}
            ratios.append(pair['safe']/pair['ordinary'])
            old.append(pair['ordinary'])
            new.append(pair['safe'])
        report['rows'].append({'profile':profile,'case':case,'safe_ordinary_ratios':ratios,'median_safe_ordinary':statistics.median(ratios),'range_safe_ordinary':[min(ratios),max(ratios)],'median_ns_ordinary':statistics.median(old),'median_ns_safe':statistics.median(new)})
report['elapsed_seconds']=time.monotonic()-start
report['host_load_after']=Path('/proc/loadavg').read_text().strip()
report['finished_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='captures'},indent=2))
