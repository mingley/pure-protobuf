#!/usr/bin/env python3
from datetime import datetime,timezone
import hashlib,json,os,random,statistics,subprocess,time
from pathlib import Path

ROOT=Path('/workspace/pure-protobuf')
HERE=Path(__file__).resolve().parent
PROOF=ROOT/'tests/proof/safe_defaults'
OUT=HERE/'consumer-build-screen'
assert not OUT.exists()
OUT.mkdir()
env=os.environ.copy()
env.update(CARGO_HOME=str(ROOT/'work/cargo'),RUSTUP_HOME=str(ROOT/'work/rustup'),CARGO_TARGET_DIR=str(ROOT/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0')
env['PATH']=str(ROOT/'work/cargo/bin')+':'+str(ROOT/'work/toolchain/protoc/bin')+':'+env['PATH']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
source_before={str(p.relative_to(ROOT)):sha(p) for p in PROOF.rglob('*') if p.is_file()}
report={'scope':'Dependency-warm clean consumer Cargo builds; removes only this proof package artifacts, includes its code generation, compiler and linking. Shared host/order noise limits generalization.','started_utc':datetime.now(timezone.utc).isoformat(),'runner_sha256':sha(Path(__file__)),'proof_inputs_sha256':source_before,'captures':[]}
rng=random.Random(53120)
for profile in ['dev','release']:
    for repeat in range(3):
        variants=['ordinary','safe']
        rng.shuffle(variants)
        for variant in variants:
            name=f'{profile}-r{repeat}-{variant}'
            clean=['cargo','clean','--locked','--offline','--manifest-path',str(PROOF/'Cargo.toml'),'-p','pbrs-safe-defaults-proof','--profile',profile]
            cleaned=subprocess.run(clean,cwd=ROOT,env=env,text=True,capture_output=True)
            (OUT/(name+'.clean.stdout')).write_text(cleaned.stdout)
            (OUT/(name+'.clean.stderr')).write_text(cleaned.stderr)
            assert cleaned.returncode==0,cleaned.stderr
            command=['cargo','build','--locked','--offline','--manifest-path',str(PROOF/'Cargo.toml'),'--message-format=json']
            if variant=='ordinary':command+=['--features','ordinary-control']
            if profile=='release':command+=['--release']
            begin=time.monotonic()
            result=subprocess.run(command,cwd=ROOT,env=env,text=True,capture_output=True)
            elapsed=time.monotonic()-begin
            (OUT/(name+'.stdout')).write_text(result.stdout)
            (OUT/(name+'.stderr')).write_text(result.stderr)
            assert result.returncode==0,(command,result.stderr)
            artifacts=[json.loads(line) for line in result.stdout.splitlines() if line.startswith('{')]
            rebuilt=[a.get('target',{}).get('name') for a in artifacts if a.get('reason')=='compiler-artifact' and not a.get('fresh')]
            assert set(rebuilt)<={'pbrs-safe-defaults-proof','build-script-build'},rebuilt
            report['captures'].append({'profile':profile,'repeat':repeat,'variant':variant,'clean_command':clean,'clean_exit_code':cleaned.returncode,'command':command,'exit_code':result.returncode,'elapsed_seconds':elapsed,'rebuilt_targets':rebuilt})
report['rows']=[]
for profile in ['dev','release']:
    ratios=[]
    for repeat in range(3):
        pair={r['variant']:r['elapsed_seconds'] for r in report['captures'] if r['profile']==profile and r['repeat']==repeat}
        ratios.append(pair['safe']/pair['ordinary'])
    report['rows'].append({'profile':profile,'ratios_safe_ordinary':ratios,'median_safe_ordinary':statistics.median(ratios),'range_safe_ordinary':[min(ratios),max(ratios)]})
source_after={str(p.relative_to(ROOT)):sha(p) for p in PROOF.rglob('*') if p.is_file()}
report['proof_inputs_unchanged']=source_before==source_after
report['finished_utc']=datetime.now(timezone.utc).isoformat()
(OUT/'report.json').write_text(json.dumps(report,indent=2)+'\n')
assert source_before==source_after
print(json.dumps(report,indent=2))
