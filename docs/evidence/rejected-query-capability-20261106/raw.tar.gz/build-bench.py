from pathlib import Path
import hashlib,json,os,shutil,signal,subprocess,time
here=Path('/workspace/map-query-20261106');root=Path('/workspace/pure-protobuf')
env=os.environ.copy();env.update(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_TARGET_DIR=str(here/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0');env['PATH']=str(root/'work/cargo/bin')+':'+env['PATH'];env.pop('RUSTFLAGS',None)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def size():return sum(p.stat().st_size for p in (here/'target').rglob('*') if p.is_file()) if (here/'target').exists() else 0
def run(command,path,cwd):
 assert not path.exists(),path
 assert shutil.disk_usage(here).free>1024**3
 guard=None;start=time.monotonic()
 with path.open('w') as log:
  proc=subprocess.Popen(command,cwd=cwd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while proc.poll() is None:
   if shutil.disk_usage(here).free<1024**3:guard='disk-floor'
   if size()>500*1024**2:guard='target-cap'
   if guard:os.killpg(proc.pid,signal.SIGTERM);break
   time.sleep(.5)
  code=proc.wait()
 receipt={'command':command,'exit_code':code,'guard':guard,'elapsed_seconds':time.monotonic()-start,'target_bytes':size(),'free_bytes':shutil.disk_usage(here).free}
 print(json.dumps(receipt),flush=True)
 assert code==0 and guard is None,path
 return receipt
for variant in ['baseline','candidate']:
 run(['cargo','generate-lockfile','--offline'],here/(variant+'-harness-lock.log'),here/(variant+'-harness'))
assert (here/'baseline-harness/Cargo.lock').read_bytes()==(here/'candidate-harness/Cargo.lock').read_bytes()
for variant in ['baseline','candidate']:
 for mode in ['cpu','alloc']:
  stem=variant+'-'+mode;manifest=here/(variant+'-harness')/'Cargo.toml'
  cmd=['cargo','build','--release','--offline','--locked','--manifest-path',str(manifest),'--message-format=json']
  if mode=='alloc':cmd+=['--features','allocations']
  path=here/(stem+'-build.jsonl');report=run(cmd,path,here)
  artifacts=[json.loads(line) for line in path.read_text().splitlines() if line.startswith('{')]
  found=[m['executable'] for m in artifacts if m.get('reason')=='compiler-artifact' and m.get('executable') and m['target']['name']=='pbrs-borrowed-query-capability'];assert len(found)==1,found
  executable=Path(found[0]);retained=here/(stem+'-bin');assert not retained.exists();shutil.copy2(executable,retained)
  tree=here/variant
  source={str(p.relative_to(tree)):sha(p) for p in sorted(tree.rglob('*')) if p.is_file() and '.git' not in p.parts}
  report.update(variant=variant,mode=mode,source=source,harness_sha256=sha(manifest.parent/'src/main.rs'),lock_sha256=sha(manifest.parent/'Cargo.lock'),executable_sha256=sha(executable),retained_sha256=sha(retained),rustc=subprocess.check_output(['rustc','-Vv'],cwd=here,env=env,text=True).strip())
  (here/(stem+'-build.json')).write_text(json.dumps(report,indent=2)+'\n')
