00000000000265a0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>>:
   265a0:	push   %rbp
   265a1:	push   %r15
   265a3:	push   %r14
   265a5:	push   %r13
   265a7:	push   %r12
   265a9:	push   %rbx
   265aa:	sub    $0x28,%rsp
   265ae:	mov    %rdx,%r14
   265b1:	mov    %rsi,0x8(%rsp)
   265b6:	cmpb   $0x0,(%rdi)
   265b9:	je     2667e <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xde>
   265bf:	mov    0x8(%rdi),%r12
   265c3:	mov    0x8(%r12),%r13
   265c8:	movabs $0x7fffffffffffffff,%rax
   265d2:	cmp    %rax,%r13
   265d5:	jae    268e7 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x347>
   265db:	mov    0x28(%rdi),%rdx
   265df:	lea    0x1(%r13),%rax
   265e3:	mov    %rax,0x8(%r12)
   265e8:	mov    0x20(%r12),%rcx
   265ed:	xor    %eax,%eax
   265ef:	test   %rcx,%rcx
   265f2:	je     26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   265f8:	mov    %rdx,(%rsp)
   265fc:	mov    0x18(%r12),%r15
   26601:	shl    $0x3,%rcx
   26605:	lea    (%rcx,%rcx,4),%rbp
   26609:	mov    0x477c0(%rip),%rbx        # 6ddd0 <bcmp@GLIBC_2.2.5>
   26610:	jmp    2662a <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x8a>
   26612:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   26620:	add    $0xffffffffffffffd8,%rbp
   26624:	je     2673b <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x19b>
   2662a:	cmp    %r14,-0x18(%r15,%rbp,1)
   2662f:	jne    26620 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x80>
   26631:	mov    -0x20(%r15,%rbp,1),%rdi
   26636:	mov    0x8(%rsp),%rsi
   2663b:	mov    %r14,%rdx
   2663e:	call   *%rbx
   26640:	test   %eax,%eax
   26642:	jne    26620 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x80>
   26644:	movzbl -0x10(%r15,%rbp,1),%eax
   2664a:	mov    -0xc(%r15,%rbp,1),%edx
   2664f:	mov    (%rsp),%rcx
   26653:	test   %rcx,%rcx
   26656:	je     26860 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2c0>
   2665c:	cmp    $0x1,%eax
   2665f:	mov    $0x0,%eax
   26664:	jne    26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   2666a:	mov    %edx,%edi
   2666c:	call   *%rcx
   2666e:	and    $0x1,%eax
   26671:	mov    0x8(%r12),%r13
   26676:	dec    %r13
   26679:	jmp    26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   2667e:	mov    0x10(%rdi),%rcx
   26682:	xor    %eax,%eax
   26684:	test   %rcx,%rcx
   26687:	je     26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   2668d:	mov    %rcx,0x10(%rsp)
   26692:	mov    0x18(%rdi),%rbx
   26696:	mov    0x20(%rdi),%rbp
   2669a:	cmp    $0x10,%rbx
   2669e:	setb   %dl
   266a1:	test   %rbp,%rbp
   266a4:	sete   %cl
   266a7:	or     %dl,%cl
   266a9:	je     26742 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1a2>
   266af:	test   %rbx,%rbx
   266b2:	je     26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   266b8:	shl    $0x3,%rbx
   266bc:	lea    (%rbx,%rbx,4),%rbx
   266c0:	mov    0x10(%rsp),%r13
   266c5:	lea    -0x26(%r13),%r15
   266c9:	mov    0x47700(%rip),%r12        # 6ddd0 <bcmp@GLIBC_2.2.5>
   266d0:	jmp    266fd <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x15d>
   266d2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   266e0:	mov    0x8(%rsp),%rsi
   266e5:	mov    %r14,%rdx
   266e8:	call   *%r12
   266eb:	test   %eax,%eax
   266ed:	je     268b0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x310>
   266f3:	add    $0xffffffffffffffd8,%rbx
   266f7:	je     26859 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2b9>
   266fd:	cmpb   $0x1,-0x28(%r13,%rbx,1)
   26703:	jne    26720 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x180>
   26705:	mov    -0x18(%r13,%rbx,1),%rdi
   2670a:	mov    -0x10(%r13,%rbx,1),%rsi
   2670f:	cmp    %r14,%rsi
   26712:	jne    266f3 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x153>
   26714:	jmp    266e0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x140>
   26716:	cs nopw 0x0(%rax,%rax,1)
   26720:	movzbl -0x27(%r13,%rbx,1),%esi
   26726:	cmp    $0x18,%rsi
   2672a:	jae    268bc <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x31c>
   26730:	lea    (%r15,%rbx,1),%rdi
   26734:	cmp    %r14,%rsi
   26737:	jne    266f3 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x153>
   26739:	jmp    266e0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x140>
   2673b:	xor    %eax,%eax
   2673d:	jmp    26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   26742:	mov    0x18(%rbp),%eax
   26745:	test   %eax,%eax
   26747:	jne    268f4 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x354>
   2674d:	mov    0x10(%rbp),%rcx
   26751:	xor    %eax,%eax
   26753:	test   %rcx,%rcx
   26756:	je     26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   2675c:	mov    %rbx,0x18(%rsp)
   26761:	mov    0x8(%rbp),%rax
   26765:	mov    %rax,(%rsp)
   26769:	cmp    $0x1,%rcx
   2676d:	mov    %rcx,0x20(%rsp)
   26772:	jne    267a0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x200>
   26774:	xor    %ebp,%ebp
   26776:	lea    0x0(,%rbp,4),%rax
   2677e:	add    %rbp,%rax
   26781:	mov    (%rsp),%rcx
   26785:	lea    (%rcx,%rax,8),%rbx
   26789:	cmpb   $0x1,(%rcx,%rax,8)
   2678d:	jne    26822 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x282>
   26793:	mov    0x10(%rbx),%rdi
   26797:	mov    0x18(%rbx),%rsi
   2679b:	jmp    26834 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x294>
   267a0:	xor    %r12d,%r12d
   267a3:	mov    %rcx,%rbx
   267a6:	jmp    267e8 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x248>
   267a8:	nopl   0x0(%rax,%rax,1)
   267b0:	mov    0x10(%rax),%rdi
   267b4:	mov    0x18(%rax),%rdx
   267b8:	mov    %rdx,%r13
   267bb:	sub    %r14,%r13
   267be:	cmovae %r14,%rdx
   267c2:	mov    0x8(%rsp),%rsi
   267c7:	call   *0x47893(%rip)        # 6e060 <memcmp@GLIBC_2.2.5>
   267cd:	cltq
   267cf:	test   %eax,%eax
   267d1:	cmovne %rax,%r13
   267d5:	test   %r13,%r13
   267d8:	cmovg  %r12,%rbp
   267dc:	sub    %r15,%rbx
   267df:	mov    %rbp,%r12
   267e2:	cmp    $0x1,%rbx
   267e6:	jbe    26776 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1d6>
   267e8:	mov    %rbx,%r15
   267eb:	shr    $1,%r15
   267ee:	lea    (%r15,%r12,1),%rbp
   267f2:	lea    0x0(,%rbp,4),%rcx
   267fa:	add    %rbp,%rcx
   267fd:	mov    (%rsp),%rdx
   26801:	lea    (%rdx,%rcx,8),%rax
   26805:	cmpb   $0x1,(%rdx,%rcx,8)
   26809:	je     267b0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x210>
   2680b:	movzbl 0x1(%rax),%edx
   2680f:	cmp    $0x18,%rdx
   26813:	jae    268d0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x330>
   26819:	add    $0x2,%rax
   2681d:	mov    %rax,%rdi
   26820:	jmp    267b8 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x218>
   26822:	movzbl 0x1(%rbx),%esi
   26826:	cmp    $0x18,%rsi
   2682a:	jae    268bc <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x31c>
   26830:	lea    0x2(%rbx),%rdi
   26834:	mov    %rsi,%r15
   26837:	sub    %r14,%r15
   2683a:	cmovb  %rsi,%r14
   2683e:	mov    0x8(%rsp),%rsi
   26843:	mov    %r14,%rdx
   26846:	call   *0x47814(%rip)        # 6e060 <memcmp@GLIBC_2.2.5>
   2684c:	cltq
   2684e:	test   %eax,%eax
   26850:	cmovne %rax,%r15
   26854:	test   %r15,%r15
   26857:	je     2687e <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2de>
   26859:	xor    %eax,%eax
   2685b:	jmp    26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   26860:	or     $0x2,%eax
   26863:	cmp    $0x3,%eax
   26866:	mov    $0x0,%eax
   2686b:	jne    26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   2686d:	mov    $0x1,%eax
   26872:	jmp    26874 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d4>
   26874:	mov    %r13,0x8(%r12)
   26879:	jmp    26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   2687e:	mov    0x20(%rsp),%rsi
   26883:	cmp    %rsi,%rbp
   26886:	jae    26922 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x382>
   2688c:	mov    0x20(%rbx),%rcx
   26890:	cmp    0x18(%rsp),%rcx
   26895:	mov    $0x0,%eax
   2689a:	jae    26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   2689c:	lea    (%rcx,%rcx,4),%rax
   268a0:	mov    0x10(%rsp),%rcx
   268a5:	mov    0x20(%rcx,%rax,8),%edx
   268a9:	mov    $0x1,%eax
   268ae:	jmp    26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   268b0:	mov    -0x8(%r13,%rbx,1),%edx
   268b5:	mov    $0x1,%eax
   268ba:	jmp    26913 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x373>
   268bc:	lea    0x458b5(%rip),%rcx        # 6c178 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458>
   268c3:	mov    $0x17,%edx
   268c8:	xor    %edi,%edi
   268ca:	call   *0x47400(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   268d0:	lea    0x458a1(%rip),%rcx        # 6c178 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458>
   268d7:	mov    %rdx,%rsi
   268da:	mov    $0x17,%edx
   268df:	xor    %edi,%edi
   268e1:	call   *0x473e9(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   268e7:	lea    0x45a02(%rip),%rdi        # 6c2f0 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458+0x178>
   268ee:	call   *0x4751c(%rip)        # 6de10 <_DYNAMIC+0x390>
   268f4:	mov    %rbp,%rdi
   268f7:	mov    0x10(%rsp),%rsi
   268fc:	mov    %rbx,%rdx
   268ff:	call   25306 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::string::ProtoString>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::string::ProtoString>>>::get_or_init<pbrs::map::hot_index<pbrs::string::ProtoString, i32>::{closure#0}>::{closure#0}, !>>
   26904:	mov    0x10(%rbp),%rcx
   26908:	xor    %eax,%eax
   2690a:	test   %rcx,%rcx
   2690d:	jne    2675c <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1bc>
   26913:	add    $0x28,%rsp
   26917:	pop    %rbx
   26918:	pop    %r12
   2691a:	pop    %r13
   2691c:	pop    %r14
   2691e:	pop    %r15
   26920:	pop    %rbp
   26921:	ret
   26922:	lea    0x45867(%rip),%rdx        # 6c190 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458+0x18>
   26929:	mov    %rbp,%rdi
   2692c:	call   *0x47356(%rip)        # 6dc88 <_DYNAMIC+0x208>
   26932:	decq   0x8(%r12)
   26937:	mov    %rax,%rdi
   2693a:	call   6a730 <_Unwind_Resume@plt>
   2693f:	int3

