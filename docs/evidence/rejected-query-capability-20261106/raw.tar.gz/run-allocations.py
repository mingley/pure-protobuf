from pathlib import Path
import json,subprocess,random,shutil
here=Path('/workspace/map-query-20261106');rows=[];cases=[]
for kind in ['proto','lazy']:
 for n in [16,64,256]:
  for dist in ['distinct','duplicate']:
   for hit in ['hit','miss']:cases.append((kind,n,dist,96,'prefix',hit))
 for n in [8,16,256]:
  for dist in ['distinct','duplicate']:
   for hit in ['hit','miss']:cases.append((kind,n,dist,8,'distinct',hit))
for n in [8,16,64,256]:
 for dist in ['distinct','duplicate']:
  for hit in ['hit','miss']:cases.append(('int',n,dist,8,'distinct',hit))
for n in [16,64,256]:
 for dist in ['distinct','duplicate']:
  for hit in ['hit','miss']:cases.append(('hash',n,dist,96,'prefix',hit))
assert len(cases)==76
rng=random.Random(2026110601);rng.shuffle(cases)
with (here/'allocation-observations.jsonl').open('x') as output:
 for case in cases:
  found={};order=['baseline','candidate'];rng.shuffle(order)
  for variant in order:
   assert shutil.disk_usage(here).free>1024**3
   cmd=[str(here/(variant+'-alloc-bin')),*map(str,case),'4096'];p=subprocess.run(cmd,capture_output=True,text=True)
   record={'variant':variant,'case':case,'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};output.write(json.dumps(record)+'\n');output.flush();assert p.returncode==0,record
   data=json.loads(p.stdout);assert data['cpu_ns'] is None and data['wall_ns'] is None and data['allocation_instrumentation'];found[variant]=data
  a,b=found['baseline'],found['candidate'];assert a['checksum']==b['checksum'] and a['query_fingerprint']==b['query_fingerprint'];rows.append({'case':case,'baseline_calls':a['allocation_calls'],'candidate_calls':b['allocation_calls'],'baseline_requested':a['requested_bytes'],'candidate_requested':b['requested_bytes'],'checksum':a['checksum'],'query_fingerprint':a['query_fingerprint']})
(here/'allocation-summary.json').write_text(json.dumps({'scope':'Warm lookup allocation counters only; no CPU or wall clock observations. Construction and index creation excluded. HashMap is a storage reference, not Prost decode.','processes':2*len(cases),'rows':rows},indent=2)+'\n')
print(json.dumps({'passed':True,'cases':len(cases),'processes':2*len(cases),'changed_allocation_rows':sum(r['baseline_calls']!=r['candidate_calls'] for r in rows)}))
