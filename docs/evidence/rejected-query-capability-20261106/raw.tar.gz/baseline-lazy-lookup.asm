0000000000026180 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>>:
   26180:	push   %rbp
   26181:	push   %r15
   26183:	push   %r14
   26185:	push   %r13
   26187:	push   %r12
   26189:	push   %rbx
   2618a:	sub    $0x78,%rsp
   2618e:	mov    %rdx,%r14
   26191:	mov    %rsi,0x68(%rsp)
   26196:	mov    %rdx,0x70(%rsp)
   2619b:	cmpl   $0x1,(%rdi)
   2619e:	jne    261b4 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x34>
   261a0:	test   %r14,%r14
   261a3:	jns    26232 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0xb2>
   261a9:	xor    %edi,%edi
   261ab:	mov    %r14,%rsi
   261ae:	call   *0x47e4c(%rip)        # 6e000 <_DYNAMIC+0x230>
   261b4:	mov    0x10(%rdi),%r15
   261b8:	xor    %ebx,%ebx
   261ba:	test   %r15,%r15
   261bd:	je     26324 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1a4>
   261c3:	mov    0x18(%rdi),%r12
   261c7:	mov    0x20(%rdi),%r13
   261cb:	cmp    $0x10,%r12
   261cf:	setb   %al
   261d2:	test   %r13,%r13
   261d5:	sete   %cl
   261d8:	or     %al,%cl
   261da:	je     26329 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1a9>
   261e0:	test   %r12,%r12
   261e3:	je     26324 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1a4>
   261e9:	lea    (%r12,%r12,2),%rax
   261ed:	shl    $0x4,%rax
   261f1:	lea    (%rax,%r15,1),%r14
   261f5:	add    $0xffffffffffffffd0,%r14
   261f9:	shl    $0x4,%r12
   261fd:	lea    (%r12,%r12,2),%rbx
   26201:	neg    %rbx
   26204:	lea    0x68(%rsp),%r15
   26209:	mov    0x481b8(%rip),%r12        # 6e3c8 <_DYNAMIC+0x5f8>
   26210:	mov    %r15,%rdi
   26213:	mov    %r14,%rsi
   26216:	call   *%r12
   26219:	test   %al,%al
   2621b:	jne    263b3 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x233>
   26221:	add    $0xffffffffffffffd0,%r14
   26225:	add    $0x30,%rbx
   26229:	jne    26210 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x90>
   2622b:	xor    %ebx,%ebx
   2622d:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26232:	mov    0x8(%rdi),%rbp
   26236:	je     26384 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x204>
   2623c:	mov    %rdi,%r12
   2623f:	mov    %rsi,%rbx
   26242:	mov    %r14,%rdi
   26245:	call   *0x47d6d(%rip)        # 6dfb8 <malloc@GLIBC_2.2.5>
   2624b:	test   %rax,%rax
   2624e:	je     265b0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x430>
   26254:	mov    %rax,%r15
   26257:	mov    %rax,%rdi
   2625a:	mov    %rbx,%rsi
   2625d:	mov    %r14,%rdx
   26260:	call   *0x47d72(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   26266:	mov    %r12,%rdi
   26269:	mov    0x8(%rbp),%r13
   2626d:	movabs $0x7fffffffffffffff,%rax
   26277:	cmp    %rax,%r13
   2627a:	jae    263a1 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x221>
   26280:	mov    0x28(%rdi),%rcx
   26284:	lea    0x1(%r13),%rax
   26288:	mov    %rax,0x8(%rbp)
   2628c:	mov    0x20(%rbp),%rax
   26290:	xor    %ebx,%ebx
   26292:	test   %rax,%rax
   26295:	mov    %rbp,0x8(%rsp)
   2629a:	je     263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   262a0:	mov    %rcx,0x38(%rsp)
   262a5:	mov    0x18(%rbp),%rbx
   262a9:	shl    $0x3,%rax
   262ad:	lea    (%rax,%rax,4),%rbp
   262b1:	mov    0x47e80(%rip),%r12        # 6e138 <bcmp@GLIBC_2.2.5>
   262b8:	jmp    262ca <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x14a>
   262ba:	nopw   0x0(%rax,%rax,1)
   262c0:	add    $0xffffffffffffffd8,%rbp
   262c4:	je     26380 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x200>
   262ca:	cmp    %r14,-0x18(%rbx,%rbp,1)
   262cf:	jne    262c0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x140>
   262d1:	mov    -0x20(%rbx,%rbp,1),%rdi
   262d6:	mov    %r15,%rsi
   262d9:	mov    %r14,%rdx
   262dc:	call   *%r12
   262df:	test   %eax,%eax
   262e1:	jne    262c0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x140>
   262e3:	movzbl -0x10(%rbx,%rbp,1),%eax
   262e8:	mov    -0xc(%rbx,%rbp,1),%ebp
   262ec:	mov    0x38(%rsp),%rcx
   262f1:	test   %rcx,%rcx
   262f4:	je     263c1 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x241>
   262fa:	cmp    $0x1,%eax
   262fd:	mov    $0x0,%ebx
   26302:	jne    263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   26308:	mov    %ebp,%edi
   2630a:	call   *%rcx
   2630c:	mov    %eax,%ebx
   2630e:	mov    %edx,%ebp
   26310:	and    $0x1,%ebx
   26313:	mov    0x8(%rsp),%rax
   26318:	mov    0x8(%rax),%r13
   2631c:	dec    %r13
   2631f:	jmp    263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   26324:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26329:	mov    0x18(%r13),%eax
   2632d:	test   %eax,%eax
   2632f:	jne    263f5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x275>
   26335:	cmp    $0x18,%r14
   26339:	jae    26413 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x293>
   2633f:	xorps  %xmm0,%xmm0
   26342:	movaps %xmm0,0x40(%rsp)
   26347:	movq   $0x0,0x4f(%rsp)
   26350:	lea    0x40(%rsp),%rdi
   26355:	mov    %r14,%rdx
   26358:	call   *0x47c7a(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   2635e:	xor    %eax,%eax
   26360:	test   %r14,%r14
   26363:	je     2646a <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x2ea>
   26369:	mov    %r14d,%edx
   2636c:	mov    0x46(%rsp),%r14
   26371:	mov    0x4e(%rsp),%rbx
   26376:	movzbl 0x56(%rsp),%ecx
   2637b:	jmp    2643f <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x2bf>
   26380:	xor    %ebx,%ebx
   26382:	jmp    263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   26384:	mov    $0x1,%r15d
   2638a:	mov    0x8(%rbp),%r13
   2638e:	movabs $0x7fffffffffffffff,%rax
   26398:	cmp    %rax,%r13
   2639b:	jb     26280 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x100>
   263a1:	lea    0x46280(%rip),%rdi        # 6c628 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834+0x160>
   263a8:	call   *0x47dca(%rip)        # 6e178 <_DYNAMIC+0x3a8>
   263ae:	jmp    265ce <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x44e>
   263b3:	mov    0x28(%r14),%ebp
   263b7:	mov    $0x1,%ebx
   263bc:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   263c1:	or     $0x2,%eax
   263c4:	cmp    $0x3,%eax
   263c7:	mov    $0x0,%ebx
   263cc:	jne    263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   263ce:	mov    $0x1,%ebx
   263d3:	jmp    263d5 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x255>
   263d5:	mov    0x8(%rsp),%rax
   263da:	mov    %r13,0x8(%rax)
   263de:	test   %r14,%r14
   263e1:	je     2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   263e7:	mov    %r15,%rdi
   263ea:	call   *0x47bd8(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   263f0:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   263f5:	mov    %r13,%rdi
   263f8:	mov    %rsi,%rbx
   263fb:	mov    %r15,%rsi
   263fe:	mov    %r12,%rdx
   26401:	call   25319 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::lazy::LazyStr>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::lazy::LazyStr>>>::get_or_init<pbrs::map::hot_index<pbrs::lazy::LazyStr, i32>::{closure#0}>::{closure#0}, !>>
   26406:	mov    %rbx,%rsi
   26409:	cmp    $0x18,%r14
   2640d:	jb     2633f <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1bf>
   26413:	mov    %rsi,%rbp
   26416:	mov    %r14,%rdi
   26419:	call   *0x47b99(%rip)        # 6dfb8 <malloc@GLIBC_2.2.5>
   2641f:	test   %rax,%rax
   26422:	je     265b0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x430>
   26428:	mov    %rax,%rbx
   2642b:	mov    %rax,%rdi
   2642e:	mov    %rbp,%rsi
   26431:	mov    %r14,%rdx
   26434:	call   *0x47b9e(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   2643a:	mov    $0x1,%al
   2643c:	mov    %r14,%rcx
   2643f:	mov    %al,0x18(%rsp)
   26443:	mov    %dl,0x19(%rsp)
   26447:	mov    0x40(%rsp),%eax
   2644b:	mov    %eax,0x1a(%rsp)
   2644f:	movzwl 0x44(%rsp),%eax
   26454:	mov    %ax,0x1e(%rsp)
   26459:	mov    %r14,0x20(%rsp)
   2645e:	mov    %rbx,0x28(%rsp)
   26463:	mov    %rcx,0x30(%rsp)
   26468:	mov    $0x2,%al
   2646a:	mov    %al,0x10(%rsp)
   2646e:	mov    0x10(%r13),%r14
   26472:	xor    %ebx,%ebx
   26474:	test   %r14,%r14
   26477:	je     26519 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x399>
   2647d:	mov    %r12,0x38(%rsp)
   26482:	mov    %r15,0x8(%rsp)
   26487:	mov    0x8(%r13),%r13
   2648b:	cmp    $0x1,%r14
   2648f:	mov    %r14,0x60(%rsp)
   26494:	jne    2649a <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x31a>
   26496:	xor    %ebp,%ebp
   26498:	jmp    264e6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x366>
   2649a:	xor    %r12d,%r12d
   2649d:	mov    0x47f04(%rip),%r15        # 6e3a8 <_DYNAMIC+0x5d8>
   264a4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   264b0:	mov    %r14,%rbx
   264b3:	shr    $1,%rbx
   264b6:	lea    (%rbx,%r12,1),%rbp
   264ba:	lea    0x0(,%rbp,2),%rdi
   264c2:	add    %rbp,%rdi
   264c5:	shl    $0x4,%rdi
   264c9:	add    %r13,%rdi
   264cc:	lea    0x10(%rsp),%rsi
   264d1:	call   *%r15
   264d4:	cmp    $0x1,%al
   264d6:	cmove  %r12,%rbp
   264da:	sub    %rbx,%r14
   264dd:	mov    %rbp,%r12
   264e0:	cmp    $0x1,%r14
   264e4:	ja     264b0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x330>
   264e6:	lea    0x0(,%rbp,2),%rax
   264ee:	add    %rbp,%rax
   264f1:	shl    $0x4,%rax
   264f5:	add    %rax,%r13
   264f8:	lea    0x10(%rsp),%rsi
   264fd:	mov    %r13,%rdi
   26500:	call   *0x47ea2(%rip)        # 6e3a8 <_DYNAMIC+0x5d8>
   26506:	test   %al,%al
   26508:	mov    $0x0,%ebx
   2650d:	mov    0x8(%rsp),%rcx
   26512:	mov    0x38(%rsp),%rdx
   26517:	je     26561 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3e1>
   26519:	movzbl 0x10(%rsp),%eax
   2651e:	test   %eax,%eax
   26520:	je     2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26522:	cmp    $0x1,%eax
   26525:	jne    26545 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3c5>
   26527:	mov    0x18(%rsp),%rax
   2652c:	test   %rax,%rax
   2652f:	je     26587 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x407>
   26531:	mov    0x30(%rsp),%rdi
   26536:	mov    0x20(%rsp),%rsi
   2653b:	mov    0x28(%rsp),%rdx
   26540:	call   *0x20(%rax)
   26543:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26545:	cmpb   $0x0,0x18(%rsp)
   2654a:	je     2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   2654c:	cmpq   $0x0,0x20(%rsp)
   26552:	je     2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26554:	mov    0x28(%rsp),%rdi
   26559:	call   *0x47a69(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   2655f:	jmp    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26561:	mov    0x60(%rsp),%rsi
   26566:	cmp    %rsi,%rbp
   26569:	jae    265be <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x43e>
   2656b:	mov    0x28(%r13),%rax
   2656f:	cmp    %rdx,%rax
   26572:	jae    26519 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x399>
   26574:	lea    (%rax,%rax,2),%rax
   26578:	shl    $0x4,%rax
   2657c:	mov    0x28(%rcx,%rax,1),%ebp
   26580:	mov    $0x1,%ebx
   26585:	jmp    26519 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x399>
   26587:	mov    0x20(%rsp),%rax
   2658c:	lock decq (%rax)
   26590:	jne    2659d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x41d>
   26592:	lea    0x20(%rsp),%rdi
   26597:	call   *0x47dfb(%rip)        # 6e398 <_DYNAMIC+0x5c8>
   2659d:	mov    %ebx,%eax
   2659f:	mov    %ebp,%edx
   265a1:	add    $0x78,%rsp
   265a5:	pop    %rbx
   265a6:	pop    %r12
   265a8:	pop    %r13
   265aa:	pop    %r14
   265ac:	pop    %r15
   265ae:	pop    %rbp
   265af:	ret
   265b0:	mov    $0x1,%edi
   265b5:	mov    %r14,%rsi
   265b8:	call   *0x47a42(%rip)        # 6e000 <_DYNAMIC+0x230>
   265be:	lea    0x46303(%rip),%rdx        # 6c8c8 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834+0x400>
   265c5:	mov    %rbp,%rdi
   265c8:	call   *0x47a42(%rip)        # 6e010 <_DYNAMIC+0x240>
   265ce:	ud2
   265d0:	mov    %rax,%rbx
   265d3:	mov    0x8(%rsp),%rax
   265d8:	decq   0x8(%rax)
   265dc:	jmp    265f8 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x478>
   265de:	jmp    265e0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x460>
   265e0:	mov    %rax,%rbx
   265e3:	lea    0x10(%rsp),%rdi
   265e8:	call   27590 <core::ptr::drop_glue::<pbrs::lazy::LazyStr>>
   265ed:	jmp    265fd <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x47d>
   265ef:	call   *0x47a7b(%rip)        # 6e070 <_DYNAMIC+0x2a0>
   265f5:	mov    %rax,%rbx
   265f8:	test   %r14,%r14
   265fb:	jne    26605 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x485>
   265fd:	mov    %rbx,%rdi
   26600:	call   6aa80 <_Unwind_Resume@plt>
   26605:	mov    %r15,%rdi
   26608:	call   *0x479ba(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   2660e:	mov    %rbx,%rdi
   26611:	call   6aa80 <_Unwind_Resume@plt>
   26616:	int3
   26617:	int3
   26618:	int3
   26619:	int3
   2661a:	int3
   2661b:	int3
   2661c:	int3
   2661d:	int3
   2661e:	int3
   2661f:	int3

