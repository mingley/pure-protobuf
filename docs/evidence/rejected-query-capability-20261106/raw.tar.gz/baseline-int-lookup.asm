0000000000026c90 <<pbrs::map::MapView<i32, i32>>::get::<i32>>:
   26c90:	push   %rbp
   26c91:	push   %r15
   26c93:	push   %r14
   26c95:	push   %r12
   26c97:	push   %rbx
   26c98:	mov    %esi,%ebp
   26c9a:	mov    %rdi,%r12
   26c9d:	cmpl   $0x1,(%rdi)
   26ca0:	jne    26d60 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0xd0>
   26ca6:	mov    0x8(%r12),%r15
   26cab:	mov    $0x4,%edi
   26cb0:	call   *0x47302(%rip)        # 6dfb8 <malloc@GLIBC_2.2.5>
   26cb6:	test   %rax,%rax
   26cb9:	je     26e7e <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ee>
   26cbf:	mov    %rax,%r14
   26cc2:	mov    %ebp,(%rax)
   26cc4:	mov    0x8(%r15),%rax
   26cc8:	movabs $0x7fffffffffffffff,%rcx
   26cd2:	cmp    %rcx,%rax
   26cd5:	jae    26e4e <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1be>
   26cdb:	mov    0x28(%r12),%rcx
   26ce0:	lea    0x1(%rax),%rdx
   26ce4:	mov    %rdx,0x8(%r15)
   26ce8:	mov    0x20(%r15),%rsi
   26cec:	xor    %ebx,%ebx
   26cee:	test   %rsi,%rsi
   26cf1:	je     26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26cf7:	mov    0x18(%r15),%rdx
   26cfb:	shl    $0x3,%rsi
   26cff:	lea    (%rsi,%rsi,4),%rsi
   26d03:	jmp    26d1a <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x8a>
   26d05:	data16 cs nopw 0x0(%rax,%rax,1)
   26d10:	add    $0xffffffffffffffd8,%rsi
   26d14:	je     26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26d1a:	cmpq   $0x4,-0x18(%rdx,%rsi,1)
   26d20:	jne    26d10 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x80>
   26d22:	mov    -0x20(%rdx,%rsi,1),%rdi
   26d27:	mov    (%rdi),%edi
   26d29:	cmp    (%r14),%edi
   26d2c:	jne    26d10 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x80>
   26d2e:	movzbl -0x10(%rdx,%rsi,1),%edi
   26d33:	mov    -0xc(%rdx,%rsi,1),%ebp
   26d37:	test   %rcx,%rcx
   26d3a:	je     26e21 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x191>
   26d40:	cmp    $0x1,%edi
   26d43:	jne    26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26d49:	mov    %ebp,%edi
   26d4b:	call   *%rcx
   26d4d:	mov    %eax,%ebx
   26d4f:	mov    %edx,%ebp
   26d51:	and    $0x1,%ebx
   26d54:	mov    0x8(%r15),%rax
   26d58:	dec    %rax
   26d5b:	jmp    26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26d60:	mov    0x10(%r12),%r14
   26d65:	xor    %ebx,%ebx
   26d67:	test   %r14,%r14
   26d6a:	je     26dc5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26d6c:	mov    0x18(%r12),%r15
   26d71:	mov    0x20(%r12),%r12
   26d76:	cmp    $0x10,%r15
   26d7a:	setb   %al
   26d7d:	test   %r12,%r12
   26d80:	sete   %cl
   26d83:	or     %al,%cl
   26d85:	je     26d9f <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x10f>
   26d87:	test   %r15,%r15
   26d8a:	je     26dc5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26d8c:	shl    $0x3,%r15
   26d90:	cmp    -0x8(%r14,%r15,1),%ebp
   26d95:	je     26e15 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x185>
   26d97:	add    $0xfffffffffffffff8,%r15
   26d9b:	jne    26d90 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x100>
   26d9d:	jmp    26dc5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26d9f:	mov    0x18(%r12),%eax
   26da4:	test   %eax,%eax
   26da6:	jne    26e5d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1cd>
   26dac:	mov    0x10(%r12),%rcx
   26db1:	test   %rcx,%rcx
   26db4:	je     26dc5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26db6:	mov    0x8(%r12),%rax
   26dbb:	cmp    $0x1,%rcx
   26dbf:	jne    26dc7 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x137>
   26dc1:	cmp    %ebp,(%rax)
   26dc3:	je     26e00 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x170>
   26dc5:	jmp    26e3d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26dc7:	xor    %edx,%edx
   26dc9:	nopl   0x0(%rax)
   26dd0:	mov    %rdx,%rsi
   26dd3:	mov    %rcx,%rdi
   26dd6:	shr    $1,%rdi
   26dd9:	add    %rdi,%rdx
   26ddc:	mov    %rdx,%r8
   26ddf:	shl    $0x4,%r8
   26de3:	cmp    %ebp,(%rax,%r8,1)
   26de7:	cmovg  %rsi,%rdx
   26deb:	sub    %rdi,%rcx
   26dee:	cmp    $0x1,%rcx
   26df2:	ja     26dd0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x140>
   26df4:	shl    $0x4,%rdx
   26df8:	cmp    %ebp,(%rax,%rdx,1)
   26dfb:	jne    26e4a <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ba>
   26dfd:	add    %rdx,%rax
   26e00:	mov    0x8(%rax),%rax
   26e04:	cmp    %r15,%rax
   26e07:	jae    26e3d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26e09:	mov    0x4(%r14,%rax,8),%ebp
   26e0e:	mov    $0x1,%ebx
   26e13:	jmp    26e3d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26e15:	mov    -0x4(%r14,%r15,1),%ebp
   26e1a:	mov    $0x1,%ebx
   26e1f:	jmp    26e3d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26e21:	or     $0x2,%edi
   26e24:	cmp    $0x3,%edi
   26e27:	jne    26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26e29:	mov    $0x1,%ebx
   26e2e:	jmp    26e30 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26e30:	mov    %rax,0x8(%r15)
   26e34:	mov    %r14,%rdi
   26e37:	call   *0x4718b(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   26e3d:	mov    %ebx,%eax
   26e3f:	mov    %ebp,%edx
   26e41:	pop    %rbx
   26e42:	pop    %r12
   26e44:	pop    %r14
   26e46:	pop    %r15
   26e48:	pop    %rbp
   26e49:	ret
   26e4a:	xor    %ebx,%ebx
   26e4c:	jmp    26e3d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26e4e:	lea    0x457d3(%rip),%rdi        # 6c628 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834+0x160>
   26e55:	call   *0x4731d(%rip)        # 6e178 <_DYNAMIC+0x3a8>
   26e5b:	ud2
   26e5d:	mov    %r12,%rdi
   26e60:	mov    %r14,%rsi
   26e63:	mov    %r15,%rdx
   26e66:	call   253b3 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<i32>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<i32>>>::get_or_init<pbrs::map::hot_index<i32, i32>::{closure#0}>::{closure#0}, !>>
   26e6b:	mov    0x10(%r12),%rcx
   26e70:	test   %rcx,%rcx
   26e73:	jne    26db6 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x126>
   26e79:	jmp    26dc5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26e7e:	mov    $0x1,%edi
   26e83:	mov    $0x4,%esi
   26e88:	call   *0x47172(%rip)        # 6e000 <_DYNAMIC+0x230>
   26e8e:	mov    %rax,%rbx
   26e91:	decq   0x8(%r15)
   26e95:	mov    %r14,%rdi
   26e98:	call   *0x4712a(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   26e9e:	mov    %rbx,%rdi
   26ea1:	call   6aa80 <_Unwind_Resume@plt>
   26ea6:	mov    %rax,%rbx
   26ea9:	mov    %r14,%rdi
   26eac:	call   *0x47116(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   26eb2:	mov    %rbx,%rdi
   26eb5:	call   6aa80 <_Unwind_Resume@plt>
   26eba:	int3
   26ebb:	int3
   26ebc:	int3
   26ebd:	int3
   26ebe:	int3
   26ebf:	int3

