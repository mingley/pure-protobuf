from pathlib import Path
import json,os,shutil,signal,subprocess,time
here=Path('/workspace/map-query-20261106'); root=Path('/workspace/pure-protobuf')
env=os.environ.copy();env.update(CARGO_HOME=str(root/'work/cargo'),RUSTUP_HOME=str(root/'work/rustup'),CARGO_TARGET_DIR=str(here/'target'),CARGO_BUILD_JOBS='1',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='0',CARGO_PROFILE_TEST_DEBUG='0')
env['PATH']=str(root/'work/cargo/bin')+':'+str(root/'work/toolchain/protoc/bin')+':'+env['PATH'];env.pop('RUSTFLAGS',None)
command=['cargo','test','--offline','--locked','--lib','--no-default-features','--features','reflect','map::tests::','--','--nocapture']
def size():
 return sum(p.stat().st_size for p in (here/'target').rglob('*') if p.is_file()) if (here/'target').exists() else 0
assert shutil.disk_usage(here).free>1024**3
start=time.monotonic();guard=None
with (here/'candidate-unit.log').open('w') as log:
 proc=subprocess.Popen(command,cwd=here/'candidate',env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  if shutil.disk_usage(here).free<1024**3:guard='disk-floor'
  if size()>500*1024**2:guard='target-cap'
  if guard:os.killpg(proc.pid,signal.SIGTERM);break
  time.sleep(.5)
 code=proc.wait()
report={'command':command,'exit_code':code,'guard':guard,'elapsed_seconds':time.monotonic()-start,'target_bytes':size(),'free_bytes':shutil.disk_usage(here).free}
(here/'candidate-unit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report));print((here/'candidate-unit.log').read_text()[-10000:]);assert code==0 and guard is None
