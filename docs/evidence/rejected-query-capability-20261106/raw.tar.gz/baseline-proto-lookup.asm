0000000000026620 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>>:
   26620:	push   %rbp
   26621:	push   %r15
   26623:	push   %r14
   26625:	push   %r13
   26627:	push   %r12
   26629:	push   %rbx
   2662a:	sub    $0x68,%rsp
   2662e:	mov    %rdx,%rbx
   26631:	mov    %rsi,%r13
   26634:	cmpl   $0x1,(%rdi)
   26637:	jne    2664d <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d>
   26639:	test   %rbx,%rbx
   2663c:	jns    2670b <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xeb>
   26642:	xor    %edi,%edi
   26644:	mov    %rbx,%rsi
   26647:	call   *0x479b3(%rip)        # 6e000 <_DYNAMIC+0x230>
   2664d:	mov    0x10(%rdi),%rax
   26651:	xor    %r14d,%r14d
   26654:	test   %rax,%rax
   26657:	je     26806 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1e6>
   2665d:	mov    %rax,0x30(%rsp)
   26662:	mov    0x18(%rdi),%r15
   26666:	mov    0x20(%rdi),%rbp
   2666a:	cmp    $0x10,%r15
   2666e:	setb   %al
   26671:	test   %rbp,%rbp
   26674:	sete   %cl
   26677:	or     %al,%cl
   26679:	je     2680b <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1eb>
   2667f:	test   %r15,%r15
   26682:	je     26806 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x1e6>
   26688:	shl    $0x3,%r15
   2668c:	lea    (%r15,%r15,4),%r14
   26690:	mov    0x30(%rsp),%rbp
   26695:	lea    -0x26(%rbp),%r15
   26699:	mov    0x47a98(%rip),%r12        # 6e138 <bcmp@GLIBC_2.2.5>
   266a0:	jmp    266cb <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xab>
   266a2:	data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   266b0:	mov    %r13,%rsi
   266b3:	mov    %rbx,%rdx
   266b6:	call   *%r12
   266b9:	test   %eax,%eax
   266bb:	je     26a3f <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x41f>
   266c1:	add    $0xffffffffffffffd8,%r14
   266c5:	je     2690a <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2ea>
   266cb:	cmpb   $0x1,-0x28(%rbp,%r14,1)
   266d1:	jne    266f0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xd0>
   266d3:	mov    -0x18(%rbp,%r14,1),%rdi
   266d8:	mov    -0x10(%rbp,%r14,1),%rsi
   266dd:	cmp    %rbx,%rsi
   266e0:	jne    266c1 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xa1>
   266e2:	jmp    266b0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x90>
   266e4:	data16 data16 cs nopw 0x0(%rax,%rax,1)
   266f0:	movzbl -0x27(%rbp,%r14,1),%esi
   266f6:	cmp    $0x18,%rsi
   266fa:	jae    26b05 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4e5>
   26700:	lea    (%r15,%r14,1),%rdi
   26704:	cmp    %rbx,%rsi
   26707:	jne    266c1 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0xa1>
   26709:	jmp    266b0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x90>
   2670b:	mov    %rbx,%r12
   2670e:	mov    0x8(%rdi),%rbp
   26712:	je     268db <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2bb>
   26718:	mov    %rdi,%rbx
   2671b:	mov    %r12,%r14
   2671e:	mov    %r12,%rdi
   26721:	call   *0x47891(%rip)        # 6dfb8 <malloc@GLIBC_2.2.5>
   26727:	test   %rax,%rax
   2672a:	je     26c18 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5f8>
   26730:	mov    %rax,%r15
   26733:	mov    %rax,%rdi
   26736:	mov    %r13,%rsi
   26739:	mov    %r14,%rdx
   2673c:	call   *0x47896(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   26742:	mov    %rbx,%rdi
   26745:	mov    0x8(%rbp),%r13
   26749:	movabs $0x7fffffffffffffff,%rax
   26753:	cmp    %rax,%r13
   26756:	jae    268f8 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2d8>
   2675c:	mov    0x28(%rdi),%rcx
   26760:	lea    0x1(%r13),%rax
   26764:	mov    %rax,0x8(%rbp)
   26768:	mov    0x20(%rbp),%rax
   2676c:	xor    %r14d,%r14d
   2676f:	test   %rax,%rax
   26772:	mov    %rbp,(%rsp)
   26776:	je     26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   2677c:	mov    %rcx,0x38(%rsp)
   26781:	mov    0x18(%rbp),%rbx
   26785:	shl    $0x3,%rax
   26789:	lea    (%rax,%rax,4),%rbp
   2678d:	mov    0x479a4(%rip),%r14        # 6e138 <bcmp@GLIBC_2.2.5>
   26794:	jmp    267aa <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x18a>
   26796:	cs nopw 0x0(%rax,%rax,1)
   267a0:	add    $0xffffffffffffffd8,%rbp
   267a4:	je     268d3 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2b3>
   267aa:	cmp    %r12,-0x18(%rbx,%rbp,1)
   267af:	jne    267a0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x180>
   267b1:	mov    -0x20(%rbx,%rbp,1),%rdi
   267b6:	mov    %r15,%rsi
   267b9:	mov    %r12,%rdx
   267bc:	call   *%r14
   267bf:	test   %eax,%eax
   267c1:	jne    267a0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x180>
   267c3:	movzbl -0x10(%rbx,%rbp,1),%eax
   267c8:	mov    -0xc(%rbx,%rbp,1),%ebp
   267cc:	mov    0x38(%rsp),%rcx
   267d1:	test   %rcx,%rcx
   267d4:	je     26ad6 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4b6>
   267da:	cmp    $0x1,%eax
   267dd:	mov    $0x0,%r14d
   267e3:	jne    26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   267e9:	mov    %ebp,%edi
   267eb:	call   *%rcx
   267ed:	mov    %eax,%r14d
   267f0:	mov    %edx,%ebp
   267f2:	and    $0x1,%r14d
   267f6:	mov    (%rsp),%rax
   267fa:	mov    0x8(%rax),%r13
   267fe:	dec    %r13
   26801:	jmp    26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   26806:	jmp    26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   2680b:	mov    0x18(%rbp),%eax
   2680e:	test   %eax,%eax
   26810:	jne    26b3a <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x51a>
   26816:	cmp    $0x18,%rbx
   2681a:	jae    26b54 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x534>
   26820:	xorps  %xmm0,%xmm0
   26823:	movaps %xmm0,0x50(%rsp)
   26828:	movq   $0x0,0x5f(%rsp)
   26831:	lea    0x50(%rsp),%rdi
   26836:	mov    %r13,%rsi
   26839:	mov    %rbx,%rdx
   2683c:	call   *0x47796(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   26842:	mov    %bl,0x9(%rsp)
   26846:	movaps 0x50(%rsp),%xmm0
   2684b:	movups %xmm0,0xa(%rsp)
   26850:	mov    0x5f(%rsp),%rax
   26855:	mov    %rax,0x19(%rsp)
   2685a:	mov    0x10(%rbp),%r13
   2685e:	xor    %r14d,%r14d
   26861:	test   %r13,%r13
   26864:	je     26b97 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x577>
   2686a:	mov    0x8(%rbp),%r12
   2686e:	cmp    $0x1,%r13
   26872:	mov    %rbx,0x28(%rsp)
   26877:	mov    %r15,0x40(%rsp)
   2687c:	mov    %r13,0x48(%rsp)
   26881:	jne    26912 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x2f2>
   26887:	xor    %ebp,%ebp
   26889:	lea    0x0(,%rbp,4),%rax
   26891:	add    %rbp,%rax
   26894:	lea    (%r12,%rax,8),%r14
   26898:	cmpb   $0x1,(%r12,%rax,8)
   2689d:	jne    269aa <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x38a>
   268a3:	mov    0x10(%r14),%rdi
   268a7:	mov    0x18(%r14),%rsi
   268ab:	mov    0x28(%rsp),%r15
   268b0:	cmp    $0x18,%r15
   268b4:	jae    269cc <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x3ac>
   268ba:	movzbl 0x9(%rsp),%edx
   268bf:	cmp    $0x18,%rdx
   268c3:	jae    26bc9 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5a9>
   268c9:	lea    0xa(%rsp),%rax
   268ce:	jmp    269d6 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x3b6>
   268d3:	xor    %r14d,%r14d
   268d6:	jmp    26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   268db:	mov    $0x1,%r15d
   268e1:	mov    0x8(%rbp),%r13
   268e5:	movabs $0x7fffffffffffffff,%rax
   268ef:	cmp    %rax,%r13
   268f2:	jb     2675c <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x13c>
   268f8:	lea    0x45d29(%rip),%rdi        # 6c628 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834+0x160>
   268ff:	call   *0x47873(%rip)        # 6e178 <_DYNAMIC+0x3a8>
   26905:	jmp    26c44 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x624>
   2690a:	xor    %r14d,%r14d
   2690d:	jmp    26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   26912:	cmp    $0x18,%rbx
   26916:	jae    26a4f <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x42f>
   2691c:	movzbl 0x9(%rsp),%eax
   26921:	mov    %rax,(%rsp)
   26925:	cmp    $0x17,%al
   26927:	ja     26be5 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5c5>
   2692d:	xor    %ebp,%ebp
   2692f:	jmp    2697d <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x35d>
   26931:	data16 data16 data16 data16 data16 cs nopw 0x0(%rax,%rax,1)
   26940:	mov    0x18(%rdi),%rdx
   26944:	mov    0x10(%rdi),%rdi
   26948:	mov    %rdx,%r14
   2694b:	mov    (%rsp),%rax
   2694f:	sub    %rax,%r14
   26952:	cmovae %rax,%rdx
   26956:	lea    0xa(%rsp),%rsi
   2695b:	call   *0x47a4f(%rip)        # 6e3b0 <memcmp@GLIBC_2.2.5>
   26961:	cltq
   26963:	test   %eax,%eax
   26965:	cmovne %rax,%r14
   26969:	test   %r14,%r14
   2696c:	cmovle %rbx,%rbp
   26970:	sub    %r15,%r13
   26973:	cmp    $0x1,%r13
   26977:	jbe    26889 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x269>
   2697d:	mov    %r13,%r15
   26980:	shr    $1,%r15
   26983:	lea    (%r15,%rbp,1),%rbx
   26987:	lea    (%rbx,%rbx,4),%rax
   2698b:	lea    (%r12,%rax,8),%rdi
   2698f:	cmpb   $0x0,(%r12,%rax,8)
   26994:	jne    26940 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x320>
   26996:	movzbl 0x1(%rdi),%edx
   2699a:	cmp    $0x17,%rdx
   2699e:	ja     26b19 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4f9>
   269a4:	add    $0x2,%rdi
   269a8:	jmp    26948 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x328>
   269aa:	movzbl 0x1(%r14),%esi
   269af:	cmp    $0x17,%rsi
   269b3:	mov    0x28(%rsp),%r15
   269b8:	ja     26bc4 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5a4>
   269be:	lea    0x2(%r14),%rdi
   269c2:	cmp    $0x18,%r15
   269c6:	jb     268ba <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x29a>
   269cc:	mov    0x18(%rsp),%rax
   269d1:	mov    0x20(%rsp),%rdx
   269d6:	mov    %rsi,%rbx
   269d9:	sub    %rdx,%rbx
   269dc:	cmovb  %rsi,%rdx
   269e0:	mov    %rax,%rsi
   269e3:	call   *0x479c7(%rip)        # 6e3b0 <memcmp@GLIBC_2.2.5>
   269e9:	cltq
   269eb:	test   %eax,%eax
   269ed:	cmovne %rax,%rbx
   269f1:	test   %rbx,%rbx
   269f4:	je     26a01 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x3e1>
   269f6:	mov    %r15,%rbx
   269f9:	xor    %r14d,%r14d
   269fc:	jmp    26b97 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x577>
   26a01:	mov    0x48(%rsp),%rsi
   26a06:	cmp    %rsi,%rbp
   26a09:	mov    %r15,%rbx
   26a0c:	jae    26c34 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x614>
   26a12:	mov    0x20(%r14),%rax
   26a16:	cmp    0x40(%rsp),%rax
   26a1b:	mov    $0x0,%r14d
   26a21:	jae    26b97 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x577>
   26a27:	lea    (%rax,%rax,4),%rax
   26a2b:	mov    0x30(%rsp),%rcx
   26a30:	mov    0x20(%rcx,%rax,8),%ebp
   26a34:	mov    $0x1,%r14d
   26a3a:	jmp    26b97 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x577>
   26a3f:	mov    -0x8(%rbp,%r14,1),%ebp
   26a44:	mov    $0x1,%r14d
   26a4a:	jmp    26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   26a4f:	mov    0x18(%rsp),%rax
   26a54:	mov    %rax,(%rsp)
   26a58:	mov    0x20(%rsp),%rax
   26a5d:	mov    %rax,0x38(%rsp)
   26a62:	xor    %ebp,%ebp
   26a64:	jmp    26aad <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x48d>
   26a66:	cs nopw 0x0(%rax,%rax,1)
   26a70:	mov    0x18(%rdi),%rdx
   26a74:	mov    0x10(%rdi),%rdi
   26a78:	mov    %rdx,%rbx
   26a7b:	mov    0x38(%rsp),%rax
   26a80:	sub    %rax,%rbx
   26a83:	cmovae %rax,%rdx
   26a87:	mov    (%rsp),%rsi
   26a8b:	call   *0x4791f(%rip)        # 6e3b0 <memcmp@GLIBC_2.2.5>
   26a91:	cltq
   26a93:	test   %eax,%eax
   26a95:	cmovne %rax,%rbx
   26a99:	test   %rbx,%rbx
   26a9c:	cmovle %r14,%rbp
   26aa0:	sub    %r15,%r13
   26aa3:	cmp    $0x1,%r13
   26aa7:	jbe    26889 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x269>
   26aad:	mov    %r13,%r15
   26ab0:	shr    $1,%r15
   26ab3:	lea    (%r15,%rbp,1),%r14
   26ab7:	lea    (%r14,%r14,4),%rax
   26abb:	lea    (%r12,%rax,8),%rdi
   26abf:	cmpb   $0x0,(%r12,%rax,8)
   26ac4:	jne    26a70 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x450>
   26ac6:	movzbl 0x1(%rdi),%edx
   26aca:	cmp    $0x17,%rdx
   26ace:	ja     26b19 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4f9>
   26ad0:	add    $0x2,%rdi
   26ad4:	jmp    26a78 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x458>
   26ad6:	or     $0x2,%eax
   26ad9:	cmp    $0x3,%eax
   26adc:	mov    $0x0,%r14d
   26ae2:	jne    26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   26ae4:	mov    $0x1,%r14d
   26aea:	jmp    26aec <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4cc>
   26aec:	mov    (%rsp),%rax
   26af0:	mov    %r13,0x8(%rax)
   26af4:	test   %r12,%r12
   26af7:	je     26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   26afd:	mov    %r15,%rdi
   26b00:	jmp    26baa <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x58a>
   26b05:	lea    0x459bc(%rip),%rcx        # 6c4c8 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834>
   26b0c:	mov    $0x17,%edx
   26b11:	xor    %edi,%edi
   26b13:	call   *0x47527(%rip)        # 6e040 <_DYNAMIC+0x270>
   26b19:	mov    %rdx,%rsi
   26b1c:	lea    0x459a5(%rip),%rcx        # 6c4c8 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834>
   26b23:	mov    $0x17,%edx
   26b28:	xor    %edi,%edi
   26b2a:	mov    0x28(%rsp),%rbx
   26b2f:	call   *0x4750b(%rip)        # 6e040 <_DYNAMIC+0x270>
   26b35:	jmp    26c44 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x624>
   26b3a:	mov    %rbp,%rdi
   26b3d:	mov    0x30(%rsp),%rsi
   26b42:	mov    %r15,%rdx
   26b45:	call   25366 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::string::ProtoString>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::string::ProtoString>>>::get_or_init<pbrs::map::hot_index<pbrs::string::ProtoString, i32>::{closure#0}>::{closure#0}, !>>
   26b4a:	cmp    $0x18,%rbx
   26b4e:	jb     26820 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x200>
   26b54:	mov    %rbx,%rdi
   26b57:	call   *0x4745b(%rip)        # 6dfb8 <malloc@GLIBC_2.2.5>
   26b5d:	test   %rax,%rax
   26b60:	je     26c26 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x606>
   26b66:	mov    %rax,%r14
   26b69:	mov    %rax,%rdi
   26b6c:	mov    %r13,%rsi
   26b6f:	mov    %rbx,%rdx
   26b72:	call   *0x47460(%rip)        # 6dfd8 <memcpy@GLIBC_2.14>
   26b78:	mov    %rbx,0x10(%rsp)
   26b7d:	mov    %r14,0x18(%rsp)
   26b82:	mov    %rbx,0x20(%rsp)
   26b87:	mov    0x10(%rbp),%r13
   26b8b:	xor    %r14d,%r14d
   26b8e:	test   %r13,%r13
   26b91:	jne    2686a <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x24a>
   26b97:	cmp    $0x18,%rbx
   26b9b:	jb     26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   26b9d:	cmpq   $0x0,0x10(%rsp)
   26ba3:	je     26bb0 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x590>
   26ba5:	mov    0x18(%rsp),%rdi
   26baa:	call   *0x47418(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   26bb0:	mov    %r14d,%eax
   26bb3:	mov    %ebp,%edx
   26bb5:	add    $0x68,%rsp
   26bb9:	pop    %rbx
   26bba:	pop    %r12
   26bbc:	pop    %r13
   26bbe:	pop    %r14
   26bc0:	pop    %r15
   26bc2:	pop    %rbp
   26bc3:	ret
   26bc4:	mov    %r15,%rbx
   26bc7:	jmp    26bcf <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5af>
   26bc9:	mov    %r15,%rbx
   26bcc:	mov    %rdx,%rsi
   26bcf:	lea    0x458f2(%rip),%rcx        # 6c4c8 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834>
   26bd6:	mov    $0x17,%edx
   26bdb:	xor    %edi,%edi
   26bdd:	call   *0x4745d(%rip)        # 6e040 <_DYNAMIC+0x270>
   26be3:	jmp    26c44 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x624>
   26be5:	shr    $1,%r13
   26be8:	lea    0x0(,%r13,4),%rax
   26bf0:	add    %r13,%rax
   26bf3:	cmpb   $0x0,(%r12,%rax,8)
   26bf8:	jne    26c0f <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x5ef>
   26bfa:	lea    (%r12,%rax,8),%rax
   26bfe:	movzbl 0x1(%rax),%eax
   26c02:	mov    %rax,%rsi
   26c05:	cmp    $0x17,%rax
   26c09:	ja     26b1c <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4fc>
   26c0f:	mov    (%rsp),%rsi
   26c13:	jmp    26b1c <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x4fc>
   26c18:	mov    $0x1,%edi
   26c1d:	mov    %r14,%rsi
   26c20:	call   *0x473da(%rip)        # 6e000 <_DYNAMIC+0x230>
   26c26:	mov    $0x1,%edi
   26c2b:	mov    %rbx,%rsi
   26c2e:	call   *0x473cc(%rip)        # 6e000 <_DYNAMIC+0x230>
   26c34:	lea    0x45c8d(%rip),%rdx        # 6c8c8 <anon.f40ea0edcf9e7113e58a3a623eb35a60.56.llvm.2565506177212410834+0x400>
   26c3b:	mov    %rbp,%rdi
   26c3e:	call   *0x473cc(%rip)        # 6e010 <_DYNAMIC+0x240>
   26c44:	ud2
   26c46:	mov    %rax,%r14
   26c49:	mov    (%rsp),%rax
   26c4d:	decq   0x8(%rax)
   26c51:	jmp    26c58 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x638>
   26c53:	jmp    26c5f <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x63f>
   26c55:	mov    %rax,%r14
   26c58:	test   %r12,%r12
   26c5b:	jne    26c75 <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x655>
   26c5d:	jmp    26c7e <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x65e>
   26c5f:	mov    %rax,%r14
   26c62:	cmp    $0x18,%rbx
   26c66:	jb     26c7e <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x65e>
   26c68:	cmpq   $0x0,0x10(%rsp)
   26c6e:	je     26c7e <<pbrs::map::MapView<pbrs::string::ProtoString, i32>>::get::<&str>+0x65e>
   26c70:	mov    0x18(%rsp),%r15
   26c75:	mov    %r15,%rdi
   26c78:	call   *0x4734a(%rip)        # 6dfc8 <free@GLIBC_2.2.5>
   26c7e:	mov    %r14,%rdi
   26c81:	call   6aa80 <_Unwind_Resume@plt>
   26c86:	int3
   26c87:	int3
   26c88:	int3
   26c89:	int3
   26c8a:	int3
   26c8b:	int3
   26c8c:	int3
   26c8d:	int3
   26c8e:	int3
   26c8f:	int3

