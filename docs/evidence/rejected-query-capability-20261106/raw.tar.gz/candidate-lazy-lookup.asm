0000000000026120 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>>:
   26120:	push   %rbp
   26121:	push   %r15
   26123:	push   %r14
   26125:	push   %r13
   26127:	push   %r12
   26129:	push   %rbx
   2612a:	sub    $0x38,%rsp
   2612e:	mov    %rdx,%r14
   26131:	mov    %rsi,%r15
   26134:	mov    %rsi,0x28(%rsp)
   26139:	mov    %rdx,0x30(%rsp)
   2613e:	cmpb   $0x0,(%rdi)
   26141:	je     26206 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0xe6>
   26147:	mov    0x8(%rdi),%rbx
   2614b:	mov    0x8(%rbx),%rcx
   2614f:	movabs $0x7fffffffffffffff,%rax
   26159:	cmp    %rax,%rcx
   2615c:	jae    26511 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3f1>
   26162:	mov    0x28(%rdi),%rdx
   26166:	lea    0x1(%rcx),%rax
   2616a:	mov    %rax,0x8(%rbx)
   2616e:	mov    0x20(%rbx),%rax
   26172:	xor    %r13d,%r13d
   26175:	test   %rax,%rax
   26178:	je     26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   2617e:	mov    %rdx,0x8(%rsp)
   26183:	mov    %rcx,(%rsp)
   26187:	mov    0x18(%rbx),%rbp
   2618b:	shl    $0x3,%rax
   2618f:	lea    (%rax,%rax,4),%r13
   26193:	mov    0x47c36(%rip),%r12        # 6ddd0 <bcmp@GLIBC_2.2.5>
   2619a:	jmp    261aa <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x8a>
   2619c:	nopl   0x0(%rax)
   261a0:	add    $0xffffffffffffffd8,%r13
   261a4:	je     26280 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x160>
   261aa:	cmp    %r14,-0x18(%rbp,%r13,1)
   261af:	jne    261a0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x80>
   261b1:	mov    -0x20(%rbp,%r13,1),%rdi
   261b6:	mov    %r15,%rsi
   261b9:	mov    %r14,%rdx
   261bc:	call   *%r12
   261bf:	test   %eax,%eax
   261c1:	jne    261a0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x80>
   261c3:	movzbl -0x10(%rbp,%r13,1),%eax
   261c9:	mov    -0xc(%rbp,%r13,1),%edx
   261ce:	mov    0x8(%rsp),%rsi
   261d3:	test   %rsi,%rsi
   261d6:	je     2640b <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x2eb>
   261dc:	cmp    $0x1,%eax
   261df:	mov    $0x0,%r13d
   261e5:	mov    (%rsp),%rcx
   261e9:	jne    26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   261ef:	mov    %edx,%edi
   261f1:	call   *%rsi
   261f3:	mov    %eax,%r13d
   261f6:	and    $0x1,%r13d
   261fa:	mov    0x8(%rbx),%rcx
   261fe:	dec    %rcx
   26201:	jmp    26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   26206:	mov    0x10(%rdi),%rbx
   2620a:	xor    %r13d,%r13d
   2620d:	test   %rbx,%rbx
   26210:	je     264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   26216:	mov    0x18(%rdi),%r12
   2621a:	mov    0x20(%rdi),%rbp
   2621e:	cmp    $0x10,%r12
   26222:	setb   %al
   26225:	test   %rbp,%rbp
   26228:	sete   %cl
   2622b:	or     %al,%cl
   2622d:	je     2628c <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x16c>
   2622f:	test   %r12,%r12
   26232:	je     264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   26238:	lea    (%r12,%r12,2),%rax
   2623c:	shl    $0x4,%rax
   26240:	lea    (%rax,%rbx,1),%r14
   26244:	add    $0xffffffffffffffd0,%r14
   26248:	shl    $0x4,%r12
   2624c:	lea    (%r12,%r12,2),%rbx
   26250:	neg    %rbx
   26253:	lea    0x28(%rsp),%r15
   26258:	mov    0x47e19(%rip),%r12        # 6e078 <_DYNAMIC+0x5f8>
   2625f:	nop
   26260:	mov    %r15,%rdi
   26263:	mov    %r14,%rsi
   26266:	call   *%r12
   26269:	test   %al,%al
   2626b:	jne    263fc <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x2dc>
   26271:	add    $0xffffffffffffffd0,%r14
   26275:	add    $0x30,%rbx
   26279:	jne    26260 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x140>
   2627b:	jmp    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   26280:	xor    %r13d,%r13d
   26283:	mov    (%rsp),%rcx
   26287:	jmp    26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   2628c:	mov    0x18(%rbp),%eax
   2628f:	test   %eax,%eax
   26291:	jne    26531 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x411>
   26297:	mov    0x10(%rbp),%rax
   2629b:	xor    %r13d,%r13d
   2629e:	test   %rax,%rax
   262a1:	je     264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   262a7:	mov    %r12,0x18(%rsp)
   262ac:	mov    %rbx,0x10(%rsp)
   262b1:	mov    %r15,(%rsp)
   262b5:	mov    0x8(%rbp),%rsi
   262b9:	cmp    $0x1,%rax
   262bd:	mov    %rax,0x20(%rsp)
   262c2:	jne    26310 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1f0>
   262c4:	xor    %ebp,%ebp
   262c6:	lea    0x0(,%rbp,2),%rax
   262ce:	add    %rbp,%rax
   262d1:	shl    $0x4,%rax
   262d5:	lea    (%rsi,%rax,1),%rbx
   262d9:	movzbl (%rsi,%rax,1),%esi
   262dd:	test   %esi,%esi
   262df:	je     2642e <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x30e>
   262e5:	cmp    $0x1,%esi
   262e8:	jne    2643c <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x31c>
   262ee:	cmpq   $0x0,0x8(%rbx)
   262f3:	mov    $0x0,%r13d
   262f9:	mov    (%rsp),%rcx
   262fd:	je     2646a <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x34a>
   26303:	mov    0x10(%rbx),%rdi
   26307:	mov    0x18(%rbx),%rsi
   2630b:	jmp    26493 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x373>
   26310:	xor    %r13d,%r13d
   26313:	mov    %rax,%rbx
   26316:	mov    %rsi,0x8(%rsp)
   2631b:	jmp    2635d <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x23d>
   2631d:	nopl   (%rax)
   26320:	mov    $0x1,%edi
   26325:	mov    %rdx,%r15
   26328:	sub    %r14,%r15
   2632b:	cmovae %r14,%rdx
   2632f:	mov    (%rsp),%rsi
   26333:	call   *0x47d27(%rip)        # 6e060 <memcmp@GLIBC_2.2.5>
   26339:	cltq
   2633b:	test   %eax,%eax
   2633d:	cmovne %rax,%r15
   26341:	test   %r15,%r15
   26344:	cmovg  %r13,%rbp
   26348:	sub    %r12,%rbx
   2634b:	mov    %rbp,%r13
   2634e:	cmp    $0x1,%rbx
   26352:	mov    0x8(%rsp),%rsi
   26357:	jbe    262c6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x1a6>
   2635d:	mov    %rbx,%r12
   26360:	shr    $1,%r12
   26363:	lea    (%r12,%r13,1),%rbp
   26367:	lea    0x0(,%rbp,2),%rcx
   2636f:	add    %rbp,%rcx
   26372:	shl    $0x4,%rcx
   26376:	movzbl (%rsi,%rcx,1),%edx
   2637a:	test   %edx,%edx
   2637c:	je     26320 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x200>
   2637e:	add    %rsi,%rcx
   26381:	cmp    $0x2,%edx
   26384:	jne    263a0 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x280>
   26386:	cmpb   $0x1,0x8(%rcx)
   2638a:	jne    263b4 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x294>
   2638c:	mov    0x18(%rcx),%rdi
   26390:	mov    0x20(%rcx),%rdx
   26394:	jmp    26325 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x205>
   26396:	cs nopw 0x0(%rax,%rax,1)
   263a0:	cmpq   $0x0,0x8(%rcx)
   263a5:	je     263ce <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x2ae>
   263a7:	mov    0x10(%rcx),%rdi
   263ab:	mov    0x18(%rcx),%rdx
   263af:	jmp    26325 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x205>
   263b4:	movzbl 0x9(%rcx),%edx
   263b8:	cmp    $0x18,%rdx
   263bc:	jae    264fa <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3da>
   263c2:	add    $0xa,%rcx
   263c6:	mov    %rcx,%rdi
   263c9:	jmp    26325 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x205>
   263ce:	mov    0x18(%rcx),%rax
   263d2:	mov    0x20(%rcx),%edi
   263d5:	mov    0x24(%rcx),%edx
   263d8:	cmp    %edi,%edx
   263da:	jb     2651e <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3fe>
   263e0:	cmp    %rdx,%rax
   263e3:	jb     2651e <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3fe>
   263e9:	mov    0x10(%rcx),%rax
   263ed:	sub    %rdi,%rdx
   263f0:	add    %rax,%rdi
   263f3:	add    $0x10,%rdi
   263f7:	jmp    26325 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x205>
   263fc:	mov    0x28(%r14),%edx
   26400:	mov    $0x1,%r13d
   26406:	jmp    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   2640b:	or     $0x2,%eax
   2640e:	cmp    $0x3,%eax
   26411:	mov    $0x0,%r13d
   26417:	mov    (%rsp),%rcx
   2641b:	jne    26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   2641d:	mov    $0x1,%r13d
   26423:	jmp    26425 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x305>
   26425:	mov    %rcx,0x8(%rbx)
   26429:	jmp    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   2642e:	mov    $0x1,%edi
   26433:	xor    %r13d,%r13d
   26436:	mov    (%rsp),%rcx
   2643a:	jmp    26493 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x373>
   2643c:	cmpb   $0x1,0x8(%rbx)
   26440:	mov    $0x0,%r13d
   26446:	mov    (%rsp),%rcx
   2644a:	jne    26456 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x336>
   2644c:	mov    0x18(%rbx),%rdi
   26450:	mov    0x20(%rbx),%rsi
   26454:	jmp    26493 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x373>
   26456:	movzbl 0x9(%rbx),%esi
   2645a:	cmp    $0x18,%rsi
   2645e:	jae    26554 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x434>
   26464:	lea    0xa(%rbx),%rdi
   26468:	jmp    26493 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x373>
   2646a:	mov    0x18(%rbx),%rdx
   2646e:	mov    0x20(%rbx),%edi
   26471:	mov    0x24(%rbx),%esi
   26474:	cmp    %edi,%esi
   26476:	jb     26568 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x448>
   2647c:	cmp    %rsi,%rdx
   2647f:	jb     26568 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x448>
   26485:	mov    0x10(%rbx),%rax
   26489:	sub    %rdi,%rsi
   2648c:	add    %rax,%rdi
   2648f:	add    $0x10,%rdi
   26493:	mov    %rsi,%r12
   26496:	sub    %r14,%r12
   26499:	cmovb  %rsi,%r14
   2649d:	mov    %rcx,%rsi
   264a0:	mov    %r14,%rdx
   264a3:	call   *0x47bb7(%rip)        # 6e060 <memcmp@GLIBC_2.2.5>
   264a9:	cltq
   264ab:	test   %eax,%eax
   264ad:	cmovne %rax,%r12
   264b1:	test   %r12,%r12
   264b4:	je     264c8 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x3a8>
   264b6:	mov    %r13d,%eax
   264b9:	add    $0x38,%rsp
   264bd:	pop    %rbx
   264be:	pop    %r12
   264c0:	pop    %r13
   264c2:	pop    %r14
   264c4:	pop    %r15
   264c6:	pop    %rbp
   264c7:	ret
   264c8:	mov    0x20(%rsp),%rsi
   264cd:	cmp    %rsi,%rbp
   264d0:	jae    26575 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x455>
   264d6:	mov    0x28(%rbx),%rax
   264da:	cmp    0x18(%rsp),%rax
   264df:	jae    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   264e1:	lea    (%rax,%rax,2),%rax
   264e5:	shl    $0x4,%rax
   264e9:	mov    0x10(%rsp),%rcx
   264ee:	mov    0x28(%rcx,%rax,1),%edx
   264f2:	mov    $0x1,%r13d
   264f8:	jmp    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   264fa:	lea    0x45c77(%rip),%rcx        # 6c178 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458>
   26501:	mov    %rdx,%rsi
   26504:	mov    $0x17,%edx
   26509:	xor    %edi,%edi
   2650b:	call   *0x477bf(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   26511:	lea    0x45dd8(%rip),%rdi        # 6c2f0 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458+0x178>
   26518:	call   *0x478f2(%rip)        # 6de10 <_DYNAMIC+0x390>
   2651e:	lea    0x45c3b(%rip),%rcx        # 6c160 <anon.ff34666e2116c0781ca0099251eb16d6.23.llvm.5360597913044695458>
   26525:	mov    %rdx,%rsi
   26528:	mov    %rax,%rdx
   2652b:	call   *0x4779f(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   26531:	mov    %rbp,%rdi
   26534:	mov    %rbx,%rsi
   26537:	mov    %r12,%rdx
   2653a:	call   252b9 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::lazy::LazyStr>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<pbrs::lazy::LazyStr>>>::get_or_init<pbrs::map::hot_index<pbrs::lazy::LazyStr, i32>::{closure#0}>::{closure#0}, !>>
   2653f:	mov    0x10(%rbp),%rax
   26543:	xor    %r13d,%r13d
   26546:	test   %rax,%rax
   26549:	jne    262a7 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x187>
   2654f:	jmp    264b6 <<pbrs::map::MapView<pbrs::lazy::LazyStr, i32>>::get::<&str>+0x396>
   26554:	lea    0x45c1d(%rip),%rcx        # 6c178 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458>
   2655b:	mov    $0x17,%edx
   26560:	xor    %edi,%edi
   26562:	call   *0x47768(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   26568:	lea    0x45bf1(%rip),%rcx        # 6c160 <anon.ff34666e2116c0781ca0099251eb16d6.23.llvm.5360597913044695458>
   2656f:	call   *0x4775b(%rip)        # 6dcd0 <_DYNAMIC+0x250>
   26575:	lea    0x45c14(%rip),%rdx        # 6c190 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458+0x18>
   2657c:	mov    %rbp,%rdi
   2657f:	call   *0x47703(%rip)        # 6dc88 <_DYNAMIC+0x208>
   26585:	decq   0x8(%rbx)
   26589:	mov    %rax,%rdi
   2658c:	call   6a730 <_Unwind_Resume@plt>
   26591:	int3
   26592:	int3
   26593:	int3
   26594:	int3
   26595:	int3
   26596:	int3
   26597:	int3
   26598:	int3
   26599:	int3
   2659a:	int3
   2659b:	int3
   2659c:	int3
   2659d:	int3
   2659e:	int3
   2659f:	int3

