0000000000026940 <<pbrs::map::MapView<i32, i32>>::get::<i32>>:
   26940:	push   %rbp
   26941:	push   %r15
   26943:	push   %r14
   26945:	push   %r12
   26947:	push   %rbx
   26948:	mov    %esi,%ebp
   2694a:	mov    %rdi,%r12
   2694d:	cmpl   $0x1,(%rdi)
   26950:	jne    26a10 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0xd0>
   26956:	mov    0x8(%r12),%r15
   2695b:	mov    $0x4,%edi
   26960:	call   *0x47362(%rip)        # 6dcc8 <malloc@GLIBC_2.2.5>
   26966:	test   %rax,%rax
   26969:	je     26b2e <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ee>
   2696f:	mov    %rax,%r14
   26972:	mov    %ebp,(%rax)
   26974:	mov    0x8(%r15),%rax
   26978:	movabs $0x7fffffffffffffff,%rcx
   26982:	cmp    %rcx,%rax
   26985:	jae    26afe <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1be>
   2698b:	mov    0x28(%r12),%rcx
   26990:	lea    0x1(%rax),%rdx
   26994:	mov    %rdx,0x8(%r15)
   26998:	mov    0x20(%r15),%rsi
   2699c:	xor    %ebx,%ebx
   2699e:	test   %rsi,%rsi
   269a1:	je     26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   269a7:	mov    0x18(%r15),%rdx
   269ab:	shl    $0x3,%rsi
   269af:	lea    (%rsi,%rsi,4),%rsi
   269b3:	jmp    269ca <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x8a>
   269b5:	data16 cs nopw 0x0(%rax,%rax,1)
   269c0:	add    $0xffffffffffffffd8,%rsi
   269c4:	je     26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   269ca:	cmpq   $0x4,-0x18(%rdx,%rsi,1)
   269d0:	jne    269c0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x80>
   269d2:	mov    -0x20(%rdx,%rsi,1),%rdi
   269d7:	mov    (%rdi),%edi
   269d9:	cmp    (%r14),%edi
   269dc:	jne    269c0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x80>
   269de:	movzbl -0x10(%rdx,%rsi,1),%edi
   269e3:	mov    -0xc(%rdx,%rsi,1),%ebp
   269e7:	test   %rcx,%rcx
   269ea:	je     26ad1 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x191>
   269f0:	cmp    $0x1,%edi
   269f3:	jne    26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   269f9:	mov    %ebp,%edi
   269fb:	call   *%rcx
   269fd:	mov    %eax,%ebx
   269ff:	mov    %edx,%ebp
   26a01:	and    $0x1,%ebx
   26a04:	mov    0x8(%r15),%rax
   26a08:	dec    %rax
   26a0b:	jmp    26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26a10:	mov    0x10(%r12),%r14
   26a15:	xor    %ebx,%ebx
   26a17:	test   %r14,%r14
   26a1a:	je     26a75 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26a1c:	mov    0x18(%r12),%r15
   26a21:	mov    0x20(%r12),%r12
   26a26:	cmp    $0x10,%r15
   26a2a:	setb   %al
   26a2d:	test   %r12,%r12
   26a30:	sete   %cl
   26a33:	or     %al,%cl
   26a35:	je     26a4f <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x10f>
   26a37:	test   %r15,%r15
   26a3a:	je     26a75 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26a3c:	shl    $0x3,%r15
   26a40:	cmp    -0x8(%r14,%r15,1),%ebp
   26a45:	je     26ac5 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x185>
   26a47:	add    $0xfffffffffffffff8,%r15
   26a4b:	jne    26a40 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x100>
   26a4d:	jmp    26a75 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26a4f:	mov    0x18(%r12),%eax
   26a54:	test   %eax,%eax
   26a56:	jne    26b0d <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1cd>
   26a5c:	mov    0x10(%r12),%rcx
   26a61:	test   %rcx,%rcx
   26a64:	je     26a75 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26a66:	mov    0x8(%r12),%rax
   26a6b:	cmp    $0x1,%rcx
   26a6f:	jne    26a77 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x137>
   26a71:	cmp    %ebp,(%rax)
   26a73:	je     26ab0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x170>
   26a75:	jmp    26aed <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26a77:	xor    %edx,%edx
   26a79:	nopl   0x0(%rax)
   26a80:	mov    %rdx,%rsi
   26a83:	mov    %rcx,%rdi
   26a86:	shr    $1,%rdi
   26a89:	add    %rdi,%rdx
   26a8c:	mov    %rdx,%r8
   26a8f:	shl    $0x4,%r8
   26a93:	cmp    %ebp,(%rax,%r8,1)
   26a97:	cmovg  %rsi,%rdx
   26a9b:	sub    %rdi,%rcx
   26a9e:	cmp    $0x1,%rcx
   26aa2:	ja     26a80 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x140>
   26aa4:	shl    $0x4,%rdx
   26aa8:	cmp    %ebp,(%rax,%rdx,1)
   26aab:	jne    26afa <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ba>
   26aad:	add    %rdx,%rax
   26ab0:	mov    0x8(%rax),%rax
   26ab4:	cmp    %r15,%rax
   26ab7:	jae    26aed <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26ab9:	mov    0x4(%r14,%rax,8),%ebp
   26abe:	mov    $0x1,%ebx
   26ac3:	jmp    26aed <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26ac5:	mov    -0x4(%r14,%r15,1),%ebp
   26aca:	mov    $0x1,%ebx
   26acf:	jmp    26aed <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26ad1:	or     $0x2,%edi
   26ad4:	cmp    $0x3,%edi
   26ad7:	jne    26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26ad9:	mov    $0x1,%ebx
   26ade:	jmp    26ae0 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1a0>
   26ae0:	mov    %rax,0x8(%r15)
   26ae4:	mov    %r14,%rdi
   26ae7:	call   *0x471c3(%rip)        # 6dcb0 <free@GLIBC_2.2.5>
   26aed:	mov    %ebx,%eax
   26aef:	mov    %ebp,%edx
   26af1:	pop    %rbx
   26af2:	pop    %r12
   26af4:	pop    %r14
   26af6:	pop    %r15
   26af8:	pop    %rbp
   26af9:	ret
   26afa:	xor    %ebx,%ebx
   26afc:	jmp    26aed <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x1ad>
   26afe:	lea    0x457eb(%rip),%rdi        # 6c2f0 <anon.ff34666e2116c0781ca0099251eb16d6.56.llvm.5360597913044695458+0x178>
   26b05:	call   *0x47305(%rip)        # 6de10 <_DYNAMIC+0x390>
   26b0b:	ud2
   26b0d:	mov    %r12,%rdi
   26b10:	mov    %r14,%rsi
   26b13:	mov    %r15,%rdx
   26b16:	call   25353 <<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<i32>>>::initialize::<<std::sync::once_lock::OnceLock<pbrs::map::LastWinsIndex<i32>>>::get_or_init<pbrs::map::hot_index<i32, i32>::{closure#0}>::{closure#0}, !>>
   26b1b:	mov    0x10(%r12),%rcx
   26b20:	test   %rcx,%rcx
   26b23:	jne    26a66 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x126>
   26b29:	jmp    26a75 <<pbrs::map::MapView<i32, i32>>::get::<i32>+0x135>
   26b2e:	mov    $0x1,%edi
   26b33:	mov    $0x4,%esi
   26b38:	call   *0x4713a(%rip)        # 6dc78 <_DYNAMIC+0x1f8>
   26b3e:	mov    %rax,%rbx
   26b41:	decq   0x8(%r15)
   26b45:	mov    %r14,%rdi
   26b48:	call   *0x47162(%rip)        # 6dcb0 <free@GLIBC_2.2.5>
   26b4e:	mov    %rbx,%rdi
   26b51:	call   6a730 <_Unwind_Resume@plt>
   26b56:	mov    %rax,%rbx
   26b59:	mov    %r14,%rdi
   26b5c:	call   *0x4714e(%rip)        # 6dcb0 <free@GLIBC_2.2.5>
   26b62:	mov    %rbx,%rdi
   26b65:	call   6a730 <_Unwind_Resume@plt>
   26b6a:	int3
   26b6b:	int3
   26b6c:	int3
   26b6d:	int3
   26b6e:	int3
   26b6f:	int3

