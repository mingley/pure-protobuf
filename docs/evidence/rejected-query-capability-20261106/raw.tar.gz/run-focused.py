from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,platform,random,shutil,statistics,subprocess,sys,time
assert sys.argv[1:]==['--authorized-quiet-slot'], 'Wait for parent CPU quiet-slot authorization'
here=Path('/workspace/map-query-20261106');root=Path('/workspace/pure-protobuf')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
builds={v:json.loads((here/(v+'-cpu-build.json')).read_text()) for v in ['baseline','candidate']}
assert builds['baseline']['harness_sha256']==builds['candidate']['harness_sha256']
assert builds['baseline']['lock_sha256']==builds['candidate']['lock_sha256']
assert builds['baseline']['rustc']==builds['candidate']['rustc']
a,b=builds['baseline']['source'],builds['candidate']['source'];assert a.keys()==b.keys()
assert {p for p in a if a[p]!=b[p]}=={'src/map.rs','src/lazy.rs'}
for variant in builds:
 assert sha(here/(variant+'-cpu-bin'))==builds[variant]['retained_sha256']
 for relative,digest in builds[variant]['source'].items():assert sha(here/variant/relative)==digest,relative
cases=[('proto',8,'duplicate',8,'distinct','hit'),('lazy',8,'duplicate',8,'distinct','hit'),('int',256,'distinct',8,'distinct','hit'),('proto',256,'distinct',96,'prefix','hit'),('lazy',256,'distinct',96,'prefix','hit'),('proto',16,'duplicate',8,'distinct','hit')]
plan={'schema':'pbrs.borrowed-query-capability.focused.v1','started':datetime.now(timezone.utc).isoformat(),'host':platform.node(),'platform':platform.platform(),'seed':2026110602,'pairs_per_case':9,'iterations':3000000,'cases':cases,'scope':'Warm lookup CPU only; construction and lazy index creation excluded. Shared host, no Prost decoder or RPC comparison.','binary_sha256':{v:sha(here/(v+'-cpu-bin')) for v in builds}}
cpus=sorted(os.sched_getaffinity(0));plan['available_cpus']=cpus;plan['cpu']=cpus[len(cpus)//2];os.sched_setaffinity(0,{plan['cpu']})
assert not (here/'focused-plan.json').exists();(here/'focused-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
rng=random.Random(plan['seed']);execution=[]
for pair in range(plan['pairs_per_case']):
 order=list(range(len(cases)));rng.shuffle(order)
 for case_no in order:
  variants=['baseline','candidate'];rng.shuffle(variants);execution.append({'pair':pair,'case_no':case_no,'variants':variants})
(here/'focused-order.json').write_text(json.dumps(execution,indent=2)+'\n')
rows={i:[] for i in range(len(cases))};start=time.monotonic()
with (here/'focused-raw.jsonl').open('x') as log:
 for step in execution:
  paired={};case=cases[step['case_no']]
  for variant in step['variants']:
   assert shutil.disk_usage(here).free>1024**3
   cmd=[str(here/(variant+'-cpu-bin')),*map(str,case),str(plan['iterations'])];p=subprocess.run(cmd,cwd=root,capture_output=True,text=True)
   record={'case_no':step['case_no'],'case':case,'pair':step['pair'],'variant':variant,'command':cmd,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr};log.write(json.dumps(record)+'\n');log.flush();assert p.returncode==0,record
   result=json.loads(p.stdout);assert result['semantic_preflight'] and not result['allocation_instrumentation'] and result['cpu_ns']>0 and result['wall_ns']>0;assert result['allocation_calls'] is result['requested_bytes'] is None;paired[variant]=result
  a,b=paired['baseline'],paired['candidate'];assert a['query_fingerprint']==b['query_fingerprint'] and a['checksum']==b['checksum'];rows[step['case_no']].append({'pair':step['pair'],'baseline_cpu_ns':a['cpu_ns'],'candidate_cpu_ns':b['cpu_ns'],'ratio':b['cpu_ns']/a['cpu_ns'],'checksum':a['checksum'],'query_fingerprint':a['query_fingerprint']})
summary=[]
for number,case in enumerate(cases):
 values=[p['ratio'] for p in rows[number]];row={'case_no':number,'case':case,'pairs':rows[number],'median_ratio':statistics.median(values),'min_ratio':min(values),'max_ratio':max(values),'pairs_above_one':sum(x>1 for x in values)};summary.append(row);print(json.dumps({k:v for k,v in row.items() if k!='pairs'}),flush=True)
for variant in builds:assert sha(here/(variant+'-cpu-bin'))==builds[variant]['retained_sha256']
(here/'focused-summary.json').write_text(json.dumps({'elapsed_seconds':time.monotonic()-start,'successful_processes':sum(len(r['pairs'])*2 for r in summary),'rows':summary},indent=2)+'\n')
