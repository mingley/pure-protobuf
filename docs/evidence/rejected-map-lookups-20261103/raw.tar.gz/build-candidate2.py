#!/usr/bin/env python3
"""Build separate release executables with a shared disk-space guard."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import signal
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
FLOOR = 1024 ** 3
assert shutil.disk_usage(ROOT).free >= FLOOR
env = os.environ.copy()
env.update(CARGO_HOME=str(ROOT / 'work/cargo'), RUSTUP_HOME=str(ROOT / 'work/rustup'),
           CARGO_TARGET_DIR=str(ROOT / 'target/map-borrowed-20261102'),
           CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0')
env['PATH'] = str(ROOT / 'work/cargo/bin') + ':' + str(ROOT / 'work/toolchain/protoc/bin') + ':' + env['PATH']
env.pop('RUSTFLAGS', None)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def run(command, log_path):
    assert not log_path.exists(), log_path
    start = time.monotonic()
    with log_path.open('w') as log:
        proc = subprocess.Popen(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT,
                                start_new_session=True)
        guard = False
        while proc.poll() is None:
            if shutil.disk_usage(ROOT).free < FLOOR:
                guard = True
                os.killpg(proc.pid, signal.SIGTERM)
                break
            time.sleep(0.5)
        code = proc.wait()
    print(json.dumps({'command': command, 'exit_code': code, 'disk_guard': guard,
                      'elapsed': time.monotonic() - start, 'free': shutil.disk_usage(ROOT).free}), flush=True)
    assert code == 0 and not guard, log_path

for variant in ['candidate2']:
    manifest = HERE / (variant + '-harness/Cargo.toml')
    run(['cargo', 'generate-lockfile', '--offline', '--manifest-path', str(manifest)],
        HERE / (variant + '-lock.log'))
assert (HERE / 'baseline-harness/Cargo.lock').read_bytes() == (HERE / 'candidate2-harness/Cargo.lock').read_bytes()
for variant in ['candidate2']:
    for mode in ['shipping', 'alloc']:
        manifest = HERE / (variant + '-harness/Cargo.toml')
        stem = variant if mode == 'shipping' else variant + '-alloc'
        log = HERE / (stem + '-build.jsonl')
        command = ['cargo', 'build', '--release', '--offline', '--locked',
                   '--manifest-path', str(manifest), '--message-format=json']
        if mode == 'alloc':
            command += ['--features', 'allocations']
        run(command, log)
        messages = [json.loads(line) for line in log.read_text().splitlines() if line.startswith('{')]
        matches = [m['executable'] for m in messages if m.get('reason') == 'compiler-artifact'
                   and m.get('executable') and m['target']['name'] == 'pbrs-borrowed-map-lookup-screen']
        assert len(matches) == 1, matches
        executable = Path(matches[0])
        retained = HERE / (stem + '-bin')
        assert not retained.exists()
        shutil.copy2(executable, retained)
        source = HERE / variant
        inputs = {str(p.relative_to(source)): sha(p) for p in sorted(source.rglob('*')) if p.is_file()}
        report = {'variant': variant, 'mode': mode, 'command': command, 'executable': str(executable),
                  'executable_sha256': sha(executable), 'retained_sha256': sha(retained),
                  'build_log_sha256': sha(log), 'cargo_lock_sha256': sha(manifest.parent / 'Cargo.lock'),
                  'input_sha256': inputs, 'harness_sha256': sha(manifest.parent / 'src/main.rs'),
                  'manifest_sha256': sha(manifest),
                  'rustc': subprocess.check_output(['rustc', '-Vv'], cwd=ROOT, env=env, text=True).strip(),
                  'cargo': subprocess.check_output(['cargo', '-V'], cwd=ROOT, env=env, text=True).strip()}
        assert report['executable_sha256'] == report['retained_sha256']
        (HERE / (stem + '-build.json')).write_text(json.dumps(report, indent=2) + '\n')
