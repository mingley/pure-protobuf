#!/usr/bin/env python3
"""Randomized paired warm-map lookup screen; run only during agreed quiet."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
FLOOR = 1024 ** 3
assert shutil.disk_usage(ROOT).free > FLOOR
before = json.loads((HERE / 'baseline-build.json').read_text())
after = json.loads((HERE / 'candidate3-build.json').read_text())
assert before['harness_sha256'] == after['harness_sha256']
assert before['cargo_lock_sha256'] == after['cargo_lock_sha256']
assert before['rustc'] == after['rustc'] and before['cargo'] == after['cargo']
left, right = before['input_sha256'], after['input_sha256']
assert left.keys() == right.keys()
assert {name for name in left if left[name] != right[name]} == {'src/map.rs', 'src/lazy.rs'}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
binaries = {name: HERE / (name + '-bin') for name in ('baseline', 'candidate3')}
assert sha(binaries['baseline']) == before['retained_sha256']
assert sha(binaries['candidate3']) == after['retained_sha256']
allocation_builds = {name: json.loads((HERE / (name + '-alloc-build.json')).read_text())
                     for name in ('baseline', 'candidate3')}
allocation_bins = {name: HERE / (name + '-alloc-bin') for name in ('baseline', 'candidate3')}
for name, build in allocation_builds.items():
    assert build['mode'] == 'alloc'
    assert sha(allocation_bins[name]) == build['retained_sha256']
    assert build['input_sha256'] == (before if name == 'baseline' else after)['input_sha256']
    assert build['harness_sha256'] == before['harness_sha256']
cpus = sorted(os.sched_getaffinity(0))
cpu = cpus[len(cpus) // 2]
os.sched_setaffinity(0, {cpu})
rng = random.Random(20261107)
cases = []
for kind in ('proto', 'lazy'):
    for n in (16, 64, 256):
        for dist in ('distinct', 'duplicate'):
            for hit in ('hit', 'miss'):
                cases.append((kind, n, dist, 96, 'prefix', hit))
    for n in (8, 16, 256):
        for dist in ('distinct', 'duplicate'):
            for hit in ('hit', 'miss'):
                cases.append((kind, n, dist, 8, 'distinct', hit))
for n in (8, 16, 64, 256):
    for dist in ('distinct', 'duplicate'):
        for hit in ('hit', 'miss'):
            cases.append(('int', n, dist, 8, 'distinct', hit))
for n in (16, 64, 256):
    for dist in ('distinct', 'duplicate'):
        for hit in ('hit', 'miss'):
            cases.append(('hash', n, dist, 96, 'prefix', hit))
assert len(cases) == len(set(cases)) == 76
rng.shuffle(cases)
raw = HERE / 'variant3-full-raw.jsonl'
summary = HERE / 'variant3-full-summary.json'
assert not raw.exists() and not summary.exists()
started = datetime.now(timezone.utc).isoformat()
t0 = time.monotonic()
rows = []
with raw.open('w') as output:
    for case_no, case in enumerate(cases):
        pairs = []
        for iteration in range(5):
            pair = {}
            order = ['baseline', 'candidate3']
            rng.shuffle(order)
            for variant in order:
                assert shutil.disk_usage(ROOT).free > FLOOR
                args = [str(binaries[variant]), *(str(part) for part in case), '100000']
                proc = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
                record = {'case': case, 'pair': iteration, 'variant': variant, 'command': args,
                          'exit_code': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}
                output.write(json.dumps(record) + '\n')
                output.flush()
                assert proc.returncode == 0, record
                result = json.loads(proc.stdout)
                assert result['schema'] == 'pbrs.borrowed-map-lookup-screen.v1'
                assert result['semantic_preflight'] is True and result['cpu_ns'] > 0 and result['wall_ns'] > 0
                assert result['allocation_instrumentation'] is False
                assert result['allocation_calls'] is result['requested_bytes'] is None
                pair[variant] = result
            a, b = pair['baseline'], pair['candidate3']
            assert a['query_fingerprint'] == b['query_fingerprint'] and a['checksum'] == b['checksum']
            assert a['iterations'] == b['iterations'] == 100000
            pairs.append({'baseline_cpu_ns': a['cpu_ns'], 'candidate3_cpu_ns': b['cpu_ns'],
                          'baseline_wall_ns': a['wall_ns'], 'candidate3_wall_ns': b['wall_ns'],
                          'ratio_cpu': b['cpu_ns'] / a['cpu_ns'], 'checksum': a['checksum'],
                          'query_fingerprint': a['query_fingerprint']})
        ratios = [pair['ratio_cpu'] for pair in pairs]
        rows.append({'kind': case[0], 'size': case[1], 'distribution': case[2], 'key_length': case[3],
                     'pattern': case[4], 'result': case[5], 'pairs': pairs,
                     'median_cpu_ratio': statistics.median(ratios),
                     'min_cpu_ratio': min(ratios), 'max_cpu_ratio': max(ratios)})
        print(json.dumps({'done': case_no + 1, 'of': len(cases), 'case': case,
                          'ratio': statistics.median(ratios)}), flush=True)
    # Collect requested bytes separately: allocator instrumentation affects CPU.
    for row in rows:
        case = (row['kind'], row['size'], row['distribution'], row['key_length'], row['pattern'], row['result'])
        observations = {}
        order = ['baseline', 'candidate3']
        rng.shuffle(order)
        for variant in order:
            assert shutil.disk_usage(ROOT).free > FLOOR
            args = [str(allocation_bins[variant]), *(str(part) for part in case), '4096']
            proc = subprocess.run(args, cwd=ROOT, text=True, capture_output=True)
            record = {'case': case, 'variant': variant, 'command': args, 'mode': 'allocations',
                      'exit_code': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}
            output.write(json.dumps(record) + '\n')
            output.flush()
            assert proc.returncode == 0, record
            result = json.loads(proc.stdout)
            assert result['allocation_instrumentation'] is True and result['iterations'] == 4096
            assert isinstance(result['allocation_calls'], int) and isinstance(result['requested_bytes'], int)
            assert result['query_fingerprint'] == row['pairs'][0]['query_fingerprint']
            observations[variant] = {'calls': result['allocation_calls'], 'requested_bytes': result['requested_bytes'],
                                     'iterations': result['iterations'], 'checksum': result['checksum']}
        assert observations['baseline']['checksum'] == observations['candidate3']['checksum']
        row['allocations'] = observations
assert sha(binaries['baseline']) == before['retained_sha256']
assert sha(binaries['candidate3']) == after['retained_sha256']
for name, build in allocation_builds.items():
    assert sha(allocation_bins[name]) == build['retained_sha256']
value = {'schema': 'pbrs.borrowed-map-lookup-variant3-full-summary.v1', 'started_utc': started,
         'finished_utc': datetime.now(timezone.utc).isoformat(), 'elapsed_seconds': time.monotonic() - t0,
         'scope': 'Five randomized fresh-process pairs per warmed lookup case, CPU measured inside loop; '
                  'setup and index construction excluded; HashMap is Prost default storage, not Prost decoding. '
                  'Allocation counts use separately instrumented binaries and are not timed.',
         'cpu': cpu, 'allowed_cpus_before_pinning': cpus, 'host': platform.platform(),
         'iterations': 100000, 'pairs_per_case': 5, 'baseline_binary_sha256': before['retained_sha256'],
         'candidate3_binary_sha256': after['retained_sha256'], 'build_reports': ['baseline-build.json', 'candidate3-build.json'],
         'allocation_binary_sha256': {name: build['retained_sha256'] for name, build in allocation_builds.items()},
         'harness_sha256': before['harness_sha256'], 'lock_sha256': before['cargo_lock_sha256'],
         'raw_sha256': sha(raw), 'seed': 20261107, 'rows': rows}
summary.write_text(json.dumps(value, indent=2) + '\n')
