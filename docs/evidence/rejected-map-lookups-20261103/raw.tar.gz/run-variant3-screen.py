#!/usr/bin/env python3
"""Longer paired confirmation; invoke only in an agreed CPU quiet window."""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import random
import shutil
import statistics
import subprocess
import time

ROOT = Path('/workspace/pure-protobuf')
HERE = Path(__file__).resolve().parent
FLOOR = 1024 ** 3
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
builds = {v: json.loads((HERE / (v + '-build.json')).read_text()) for v in ('baseline', 'candidate3')}
bins = {v: HERE / (v + '-bin') for v in builds}
assert builds['baseline']['harness_sha256'] == builds['candidate3']['harness_sha256']
assert builds['baseline']['rustc'] == builds['candidate3']['rustc']
for v, build in builds.items(): assert sha(bins[v]) == build['retained_sha256']
cpus = sorted(os.sched_getaffinity(0))
cpu = cpus[len(cpus) // 2]
os.sched_setaffinity(0, {cpu})
rng = random.Random(67293)
cases = []
for kind in ('proto', 'lazy'):
    for dist in ('distinct', 'duplicate'):
        for result in ('hit', 'miss'):
            cases.append((kind, 8, dist, 8, 'distinct', result))
    cases.append((kind, 256, 'distinct', 96, 'prefix', 'hit'))
cases.extend([('int', 8, 'duplicate', 8, 'distinct', 'hit'),
              ('int', 256, 'distinct', 8, 'distinct', 'hit'),
              ('hash', 8, 'duplicate', 96, 'prefix', 'hit')])
assert len(cases) == len(set(cases)) == 13
rng.shuffle(cases)
raw, summary = HERE / 'variant3-screen-raw.jsonl', HERE / 'variant3-screen-summary.json'
assert not raw.exists() and not summary.exists()
rows = []
started = datetime.now(timezone.utc).isoformat()
start = time.monotonic()
with raw.open('w') as output:
    for case_no, case in enumerate(cases):
        pairs = []
        for i in range(5):
            results = {}
            order = ['baseline', 'candidate3']
            rng.shuffle(order)
            for variant in order:
                assert shutil.disk_usage(ROOT).free > FLOOR
                args = [str(bins[variant]), *(str(part) for part in case), '300000']
                proc = subprocess.run(args, cwd=ROOT, capture_output=True, text=True)
                record = {'case': case, 'pair': i, 'variant': variant, 'command': args,
                          'exit_code': proc.returncode, 'stdout': proc.stdout, 'stderr': proc.stderr}
                output.write(json.dumps(record) + '\n')
                output.flush()
                assert proc.returncode == 0, record
                result = json.loads(proc.stdout)
                assert result['semantic_preflight'] is True and result['allocation_instrumentation'] is False
                assert result['iterations'] == 300000 and result['cpu_ns'] > 0 and result['wall_ns'] > 0
                results[variant] = result
            a, b = results['baseline'], results['candidate3']
            assert a['query_fingerprint'] == b['query_fingerprint'] and a['checksum'] == b['checksum']
            pairs.append({'baseline_cpu_ns': a['cpu_ns'], 'candidate_cpu_ns': b['cpu_ns'],
                          'baseline_wall_ns': a['wall_ns'], 'candidate_wall_ns': b['wall_ns'],
                          'cpu_ratio': b['cpu_ns'] / a['cpu_ns'],
                          'query_fingerprint': a['query_fingerprint'], 'checksum': a['checksum']})
        ratios = [p['cpu_ratio'] for p in pairs]
        rows.append({'case': case, 'pairs': pairs, 'median_cpu_ratio': statistics.median(ratios),
                     'min_cpu_ratio': min(ratios), 'max_cpu_ratio': max(ratios)})
        print(json.dumps({'done': case_no + 1, 'of': len(cases), 'case': case,
                          'ratio': statistics.median(ratios)}), flush=True)
for v, build in builds.items(): assert sha(bins[v]) == build['retained_sha256']
summary.write_text(json.dumps({
    'schema': 'pbrs.borrowed-map-lookup-variant3-screen.v1',
    'scope': 'Five randomized fresh-process pairs per warmed lookup case on a shared host. '
             'CPU clock is measured inside the loop; setup and index construction excluded. '
             'HashMap is the usual Prost field storage, not Prost decoding.',
    'started_utc': started, 'finished_utc': datetime.now(timezone.utc).isoformat(),
    'elapsed_seconds': time.monotonic()-start, 'cpu': cpu, 'iterations': 300000,
    'pairs_per_case': 5, 'seed': 67293, 'rows': rows, 'raw_sha256': sha(raw),
    'binary_sha256': {v: builds[v]['retained_sha256'] for v in builds}
}, indent=2) + '\n')
