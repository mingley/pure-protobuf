#!/usr/bin/env python3
"""Freeze the committed core for isolated borrowed-map lookup experiments."""
import hashlib
import io
import json
from pathlib import Path
import shutil
import subprocess
import tarfile

ROOT = Path('/workspace/pure-protobuf')
OUT = ROOT / 'work/map-borrowed-20261102'
commit = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip()
assert commit == '41612b32e6e3466406ff63138a1e2d65c0d5d22e'
tracked = ['Cargo.toml', 'build.rs', 'src', 'vendor/google/conformance_fds.bin',
           'clippy.toml', 'rustfmt.toml', 'README.md', 'LICENSE-APACHE', 'LICENSE-MIT']
archive = subprocess.check_output(['git', 'archive', commit, *tracked], cwd=ROOT)
baseline = OUT / 'baseline'
candidate = OUT / 'candidate'
assert not baseline.exists() and not candidate.exists()
baseline.mkdir()
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:') as tar:
    assert all(m.isfile() or m.isdir() for m in tar.getmembers())
    tar.extractall(baseline, filter='data')
manifest = (baseline / 'Cargo.toml').read_text()
manifest = '[workspace]\nresolver = "2"\n\n' + manifest[manifest.index('[package]'):]
(baseline / 'Cargo.toml').write_text(manifest)
shutil.copytree(baseline, candidate)
files = {str(p.relative_to(baseline)): hashlib.sha256(p.read_bytes()).hexdigest()
         for p in sorted(baseline.rglob('*')) if p.is_file()}
(OUT / 'snapshot.json').write_text(json.dumps({'commit': commit, 'files': files,
  'scope': 'selected committed core sources, with an isolated workspace header'}, indent=2)+'\n')
print(json.dumps({'commit': commit, 'files': len(files), 'bytes': sum(p.stat().st_size for p in baseline.rglob('*') if p.is_file())}))
