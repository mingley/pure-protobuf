#!/usr/bin/env python3
from pathlib import Path
import hashlib
import shutil

base = Path(__file__).resolve().parent
source = (base / 'bench.rs').read_bytes()
for version in ['baseline', 'candidate']:
    harness = base / (version + '-harness')
    assert not harness.exists()
    (harness / 'src').mkdir(parents=True)
    (harness / 'src/main.rs').write_bytes(source)
    (harness / 'Cargo.toml').write_text(f'''[package]
name = "pbrs-borrowed-map-lookup-screen"
version = "0.0.0"
edition = "2024"
publish = false
[workspace]
[dependencies]
pbrs = {{ path = "{base/version}", default-features = false }}
libc = "=0.2.189"
serde_json = "=1.0.154"
[profile.release]
lto = "thin"
codegen-units = 1
''')
print('harness source sha256', hashlib.sha256(source).hexdigest())
