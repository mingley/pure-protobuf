use pbrs::{Map, ProtoString};
use pbrs::rt::LazyStr;
use std::collections::HashMap;
use std::hint::black_box;
use std::time::Instant;

#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};

    static ENABLED: AtomicBool = AtomicBool::new(false);
    static CALLS: AtomicU64 = AtomicU64::new(0);
    static BYTES: AtomicU64 = AtomicU64::new(0);

    pub struct Counted;
    unsafe impl GlobalAlloc for Counted {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc_zeroed(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new: usize) -> *mut u8 {
            let result = unsafe { System.realloc(ptr, old, new) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(new as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}

#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC: count::Counted = count::Counted;

fn cpu_ns() -> u128 {
    let mut t = libc::timespec { tv_sec: 0, tv_nsec: 0 };
    assert_eq!(unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut t) }, 0);
    (t.tv_sec as u128) * 1_000_000_000 + t.tv_nsec as u128
}

fn key(id: usize, len: usize, pattern: &str) -> String {
    assert!(len >= 8);
    let id = format!("{id:08x}");
    let filler = "x".repeat(len - 8);
    match pattern {
        "prefix" => format!("{filler}{id}"),
        "distinct" => format!("{id}{filler}"),
        _ => panic!("unknown pattern"),
    }
}

fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(), 8, "kind size distribution length pattern hit iterations");
    let (kind, n, dist, len, pattern, hit, iterations) = (
        args[1].as_str(), args[2].parse::<usize>().unwrap(), args[3].as_str(),
        args[4].parse::<usize>().unwrap(), args[5].as_str(), args[6].as_str(),
        args[7].parse::<u64>().unwrap(),
    );
    assert!(matches!(kind, "proto" | "lazy" | "int" | "hash"));
    assert!(matches!(dist, "distinct" | "duplicate"));
    assert!(matches!(hit, "hit" | "miss"));
    assert!(iterations > 0 && n > 0);
    let cardinality = if dist == "duplicate" { (n + 3) / 4 } else { n };
    let mut proto = Map::<ProtoString, i32>::new();
    let mut lazy = Map::<LazyStr, i32>::new();
    let mut ints = Map::<i32, i32>::new();
    let mut hash = HashMap::<String, i32>::new();
    let mut expected_ints = HashMap::<i32, i32>::new();
    for i in 0..n {
        let id = (i * 17) % cardinality;
        let k = key(id, len, pattern);
        let v = (i as i32) * 7 + 3;
        proto.push_entry(ProtoString::from(k.as_str()), v);
        lazy.push_entry(LazyStr::from(k.as_str()), v);
        ints.push_entry(id as i32, v);
        hash.insert(k, v);
        expected_ints.insert(id as i32, v);
    }
    assert_eq!(proto.len(), cardinality);
    assert_eq!(lazy.len(), cardinality);
    assert_eq!(ints.len(), cardinality);
    let start = if hit == "hit" { 0 } else { 1_000_000 };
    let queries: Vec<String> = (0..16)
        .map(|i| key(start + (i * 13 % cardinality), len, pattern))
        .collect();
    let numeric: Vec<i32> = (0..16).map(|i| (start + (i * 13 % cardinality)) as i32).collect();
    for (s, number) in queries.iter().zip(&numeric) {
        assert_eq!(proto.as_view().get(s.as_str()), hash.get(s.as_str()).copied());
        assert_eq!(lazy.as_view().get(s.as_str()), hash.get(s.as_str()).copied());
        assert_eq!(ints.as_view().get(*number), expected_ints.get(number).copied());
    }
    let mut fingerprint: u64 = 14695981039346656037;
    for s in &queries {
        for b in s.as_bytes() { fingerprint = (fingerprint ^ u64::from(*b)).wrapping_mul(1099511628211); }
    }
    let expected = (0..iterations).map(|i| {
        let j = (i as usize) & 15;
        if kind == "int" { expected_ints.get(&numeric[j]).copied() }
        else { hash.get(queries[j].as_str()).copied() }
            .map_or(0, |value| value as u64 + 1)
    }).fold(0u64, u64::wrapping_add);
    let proto_view = proto.as_view();
    let lazy_view = lazy.as_view();
    let int_view = ints.as_view();
    #[cfg(feature = "allocations")]
    count::start();
    let cpu_start = cpu_ns();
    let wall_start = Instant::now();
    let mut sum = 0u64;
    for i in 0..iterations {
        let j = (i as usize) & 15;
        let found = match kind {
            "proto" => black_box(&proto_view).get(black_box(queries[j].as_str())),
            "lazy" => black_box(&lazy_view).get(black_box(queries[j].as_str())),
            "int" => black_box(&int_view).get(black_box(numeric[j])),
            "hash" => black_box(&hash).get(black_box(queries[j].as_str())).copied(),
            _ => unreachable!(),
        };
        sum = sum.wrapping_add(black_box(found).map_or(0, |value| value as u64 + 1));
    }
    let wall = wall_start.elapsed().as_nanos();
    let cpu = cpu_ns() - cpu_start;
    #[cfg(feature = "allocations")]
    let (calls, requested) = { let (calls, bytes) = count::stop(); (Some(calls), Some(bytes)) };
    #[cfg(not(feature = "allocations"))]
    let (calls, requested) = (None::<u64>, None::<u64>);
    assert_eq!(sum, expected);
    println!("{}", serde_json::json!({"schema":"pbrs.borrowed-map-lookup-screen.v1",
        "kind":kind,"size":n,"distribution":dist,"unique":cardinality,
        "key_length":len,"pattern":pattern,"result":hit,"iterations":iterations,
        "query_fingerprint":format!("{fingerprint:016x}"),"checksum":sum,
        "cpu_ns":cpu,"wall_ns":wall,"semantic_preflight":true,
        "allocation_instrumentation":cfg!(feature = "allocations"),
        "allocation_calls":calls,"requested_bytes":requested}));
}
