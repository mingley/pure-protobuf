#!/usr/bin/env python3
"""Run only the coordinator-approved SV09 early screen with frozen binaries."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent.parent
CELLS = "rpc.prost.server_stream"
STAGES = [
    ("screen-before", "devloop-before", "cf3eee22c6b06324e299f81b76915651471d8025",
     "73fa59c733f0637b22ce8d58f035aa45cb13f0b7efc4c8e9bb4cdddcef54e0b9"),
    ("screen-closed-yield", "devloop-closed-channel-yield", "0f7fb8fd23b3b671c3c719e6b1bfd180156f0ab6",
     "890ebef7a2cca2733f93ae83eeec20185340f43e0efb3bebb739c47ef6c2662e"),
]

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def snapshot():
    comms = subprocess.check_output(["ps", "-eo", "comm="], text=True).splitlines()
    return {"utc": now(), "loadavg": Path("/proc/loadavg").read_text().strip(),
            "heavy_processes": {name: comms.count(name) for name in
                ["cargo", "rustc", "clang", "cc1plus", "valgrind.bin", "devloop-before", "devloop-closed-c"]}}

metadata = {"schema": "sv09-early-screen/1", "cells": CELLS.split(","),
            "iters": 200, "repeats": 3, "paired_child_iters": [200, 400],
            "lease_granted": os.environ["SV09_LEASE_GRANTED"], "stages": [],
            "contention": "Coordinator granted the quiet lease; snapshots retained; no wall/CPU qualification claimed."}
meta_path = ROOT / "work/profiles/screen-meta.json"

def save():
    meta_path.write_text(json.dumps(metadata, indent=2) + "\n")

for label, name, source, expected_hash in STAGES:
    binary = ROOT / "work/bin" / name
    assert hashlib.sha256(binary.read_bytes()).hexdigest() == expected_hash
    report = ROOT / "work/profiles" / (label + ".json")
    raw = ROOT / "work/profiles" / (label + ".raw.jsonl")
    log = ROOT / "work/logs" / (label + ".log")
    assert not report.exists() and not raw.exists() and not log.exists(), "refuse to overwrite a capture"
    env = dict(os.environ, PBRS_DEVLOOP_COMMIT=source,
               PBRS_REPLAY_VALGRIND="/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind",
               PBRS_REPLAY_RAW=str(raw), PATH=str(ROOT / "work/bin") + ":" + os.environ["PATH"])
    command = [str(binary), "run", "--cells", CELLS, "--iters", "200", "--repeats", "3", "--out", str(report)]
    stage = {"label": label, "source": source, "binary_sha256": expected_hash,
             "command": command, "started": snapshot()}
    metadata["stages"].append(stage)
    save()
    print(f"{now()} START {label}", flush=True)
    with log.open("wb") as output:
        result = subprocess.run(command, env=env, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    stage["finished"] = snapshot()
    stage["returncode"] = result.returncode
    save()
    assert result.returncode == 0, f"{label} collector failed"
    records = [json.loads(line) for line in raw.read_text().splitlines()]
    assert len(records) == 6, f"expected 6 callgrind children, got {len(records)}"
    assert all(record["returncode"] == 0 for record in records)
    copied = []
    for record in records:
        command = record["command"]
        cell = command[command.index("run-cell") + 1]
        iters = command[command.index("--iters") + 1]
        pattern = next(arg.split("=", 1)[1] for arg in command if arg.startswith("--callgrind-out-file="))
        pid = re.search(r"==(\d+)==", record["stderr"]).group(1)
        original = Path(pattern.replace("%p", pid))
        # Keep the final repeat's complete profile for each cell and N/2N.
        dest = ROOT / "work/profiles" / f"{label}.{cell}.{iters}.callgrind.out"
        shutil.copy2(original, dest)
        copied.append(str(dest.relative_to(ROOT)))
    stage["callgrind_children"] = len(records)
    stage["all_tool_children_zero"] = True
    stage["last_repeat_profiles"] = sorted(set(copied))
    save()
    print(f"{now()} END {label}: {len(records)} children", flush=True)

comparison = ROOT / "work/logs/screen-compare.log"
with comparison.open("wb") as output:
    result = subprocess.run([str(ROOT / "work/bin/devloop-closed-channel-yield"), "compare", "--rpc",
                             "--baseline", str(ROOT / "work/profiles/screen-before.json"),
                             "--current", str(ROOT / "work/profiles/screen-closed-yield.json")],
                            cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
metadata["original_comparator_returncode"] = result.returncode
metadata["finished"] = snapshot()
save()
print(f"{now()} COMPLETE original comparator status {result.returncode}", flush=True)
