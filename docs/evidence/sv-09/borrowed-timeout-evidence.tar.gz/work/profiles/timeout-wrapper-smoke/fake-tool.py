#!/usr/bin/env python3
import os,sys,signal
sys.stdout.buffer.write(b"raw\x00\xffstdout\n");sys.stdout.buffer.flush()
sys.stderr.buffer.write(b"raw\x00\xfestderr\n");sys.stderr.buffer.flush()
if sys.argv[1]=="signal": os.kill(os.getpid(),signal.SIGTERM)
if sys.argv[1].startswith("--tool=callgrind"):
 path=next(a.split("=",1)[1] for a in sys.argv if a.startswith("--callgrind-out-file="));open(path.replace("%p",str(os.getpid())),"wb").write(b"fake full graph bytes\n");sys.exit(0)
sys.exit(7)
