# Read-only SV09 next hypothesis: borrow one pinned request phase through timeout

No runtime edit, compiler invocation or measurement is part of this proposal.
The allocation-before-construction probe is rejected independently; it is not
combined with any new hypothesis. The boxed dispatch and boxed response writer
remain the shipping baseline.

## Actual attribution and source finding

The baseline actual native prost DynService constructor still allocates/copies
11,536 B, while removing only the 3,096 B writer box did not shrink that frame.
This directs the next search toward the request/handler phase, rather than
response draining. In baseline server_streaming poll assembly the code copies
a 2,328 B span (0x918) around the timeout branch setup at 0x531a52,
0x531b20 and 0x531c4d. Calls to the run_unary_request inner async body appear
near 0x531bf8 and 0x531c6a. These are concrete copy arguments, not a measured
Rust type layout or proof that a particular field alone dominates the frame.

In server/rpc.rs, both run_unary_request and run_streaming_request currently
construct an owned async request/handler body and pass it by value into
wrap_timeout. The private wire/send.rs helper has two branches: Some consumes
that same large future into Tokio Timeout<F>; None awaits F directly. Its
async state stores the captured input plus an owned branch-specific await
state. This is a concrete place where storage for an owned F can be repeated
inside the outer service frame, even when the production call has no deadline.
run_handler then pins its application future and preserves biased handler-vs-
reset ordering; no evidence yet supports boxing run_handler itself.

## Bounded source-only diagnostic proposal

Change only the two server/rpc.rs request-phase call sites, leaving wrap_timeout,
run_handler, DynService, hold_cancel, producer yielding and all client files
unchanged. Name the existing async body, pin it once in a local scope, and pass
Pin<&mut F> into the existing wrap_timeout instead of moving F into it:

```rust
let outcome = {
    let request_phase = async {
        // Exact existing request decoding, metadata and handler code.
        // run_handler remains byte-for-byte unchanged.
    };
    tokio::pin!(request_phase);
    wrap_timeout(timeout, request_phase.as_mut()).await
};
notify_deadline(&outcome, &cancel_tx);
```

The extra block is required: it drops the pinned request future immediately
after timeout completion and before notify_deadline, observation and construction
of Prepared, preserving original cancellation/receiver/resource lifetimes and
releasing borrows of respond/recv. Merely pinning inside wrap_timeout could
retain duplicated captured/local F storage; pinning at the owning request phase
keeps wrap_timeout's captured and awaited types pointer-sized. No heap box or
new allocation is introduced, so no composition with the rejected inline writer
is needed. Both deadline branches continue polling the same !Unpin future with
the same biased reset handler and absolute deadline behavior.

First qualify only the structural prerequisite with actual native prost service
size/constructor assembly before/after under frozen release inputs. If the
11,536 B constructor copy does not shrink materially, stop and retain evidence.
Only if it shrinks without allocation/byte inflation should a separate approved
runtime candidate run the original N200/400 x3 >=2% screen and all controls,
including compressed and sparse adoption types. This is an unmeasured hypothesis,
not a claim that the baseline frame size or instructions will halve.

Required semantic gates include the existing cancellation/drop-order fixtures,
all four call shapes with deadlines, handler-vs-reset Ready tie ordering, pending
abandonment and panic, transport lifecycle/hostile peers, producer ordering,
wire-backed bidi echo and response byte budgets. The boxed writer stays unchanged.

An alternative request-phase Box::pin would add an allocation and might only
move the large memcpy to another box; it is less attractive without concrete
size/byte proof. No speculative safe Box initialization elision is relied on.
