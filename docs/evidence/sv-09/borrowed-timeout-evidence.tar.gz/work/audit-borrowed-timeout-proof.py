#!/usr/bin/env python3
"""Read retained SV09 child evidence without rerunning a benchmark or compiler."""

import argparse
import hashlib
import json
from pathlib import Path
import re
import statistics


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_file(directory, description):
    path = directory / description["path"]
    assert path.stat().st_size == description["bytes"], path
    assert digest(path) == description["sha256"], path
    return path


def child_data(stderr, expected_iters):
    rows = [json.loads(line[len("__CHILD__ "):]) for line in stderr.splitlines()
            if line.startswith("__CHILD__ ")]
    assert len(rows) == 1, "expected exactly one child record"
    row = rows[0]
    assert row["cell"] == "rpc.prost.server_stream"
    assert row["iters"] == expected_iters, "child/argv iteration mismatch"
    return row


def callgrind_total(stderr, profile):
    emitted = re.findall(r"^==\d+== I\s+refs:\s+([\d,]+)$", stderr, re.M)
    summaries = re.findall(r"^summary: (\d+)$", profile, re.M)
    totals = re.findall(r"^totals: (\d+)$", profile, re.M)
    assert len(emitted) == len(summaries) == len(totals) == 1
    assert re.findall(r"^events: (.*)$", profile, re.M) == ["Ir"]
    value = int(emitted[0].replace(",", ""))
    assert value == int(summaries[0]) == int(totals[0])
    return value


def strace_totals(stderr):
    total = None
    futex = 0
    for line in stderr.splitlines():
        fields = line.split()
        if fields and (fields[-1] == "total" or fields[-1].startswith("futex")):
            assert len(fields) in (5, 6), "malformed strace summary"
            calls = int(fields[3])
            if fields[-1] == "total":
                assert total is None, "duplicate strace total"
                total = calls
            else:
                futex += calls
    assert total is not None and 0 <= futex <= total
    return total, futex


def stage(root, metadata):
    label = metadata["label"]
    directory = root / "work/profiles" / (label + ".raw")
    records = [json.loads(line) for line in (directory / "invocations.jsonl").read_text().splitlines()]
    assert len(records) == 9
    assert metadata["returncode"] == 0
    report = root / "work/profiles" / (label + ".json")
    assert digest(report) == metadata["report_sha256"]
    for stream in ("stdout", "stderr"):
        assert digest(root / "work/profiles" / (label + "." + stream + ".raw")) == metadata[stream + "_sha256"]
    report = json.loads(report.read_text())
    assert report["devloop_commit"] == metadata["source"]
    assert len(report["cells"]) == 1
    cell = report["cells"][0]
    assert cell["id"] == "rpc.prost.server_stream"
    assert cell["iters"] == 200 and cell["repeats"] == 3
    assert cell["instruction_method"] == "differential_callgrind_2n_minus_n"
    samples = []
    for offset in range(0, 9, 3):
        pair = []
        for index, expected_tool, expected_iters in ((0, "valgrind", 200),
                                                   (1, "valgrind", 400),
                                                   (2, "strace", 200)):
            record = records[offset + index]
            assert record["tool"] == expected_tool and record["returncode"] == 0
            assert record["lc_all"] == "C"
            retained = directory / record["invocation"]
            assert json.loads((retained / "record.json").read_text()) == record
            argv = record["command"]
            binary = metadata["command"][0]
            if expected_tool == "valgrind":
                prefix = ["/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind",
                          "--tool=callgrind", "--cache-sim=no",
                          "--callgrind-out-file=/tmp/devloop-callgrind.%p"]
                suffix = ["--prepare-iters", "400"]
            else:
                prefix, suffix = ["/usr/bin/strace", "-c", "-f"], []
            assert argv == [*prefix, binary, "run-cell", cell["id"],
                            "--iters", str(expected_iters), *suffix]
            assert record["wrapper_argv"][1:] == argv[1:]
            checked_file(retained, record["stdout"])
            stderr = checked_file(retained, record["stderr"]).read_text()
            child = child_data(stderr, expected_iters)
            if expected_tool == "valgrind":
                assert record["profile_capture_complete"]
                assert len(record["callgrind_profiles"]) == 1
                graph = checked_file(retained, record["callgrind_profiles"][0]).read_text()
                pair.append((callgrind_total(stderr, graph), child))
            else:
                syscalls, locks = strace_totals(stderr)
        assert pair[1][0] >= pair[0][0]
        samples.append({"instructions": (pair[1][0] - pair[0][0]) / 200,
                        "allocs": pair[0][1]["allocs"] / 200,
                        "alloc_bytes": pair[0][1]["alloc_bytes"] / 200,
                        "syscalls": syscalls / 200, "locks": locks / 200})
    medians = {key: statistics.median(sample[key] for sample in samples)
               for key in samples[0]}
    for key, value in medians.items():
        assert cell[key]["status"] == "measured"
        assert cell[key]["data"]["value"] == value, (label, key)
    return {"label": label, "samples": samples, "medians": medians}


def verify(root):
    metadata = json.loads((root / "work/profiles/screen-timeout-meta.json").read_text())
    assert metadata["original_comparator_returncode"] == 0
    assert digest(root / "work/profiles/screen-timeout-compare.log") == metadata["comparator_sha256"]
    assert len(metadata["stages"]) == 2
    stages = [stage(root, item) for item in metadata["stages"]]
    before, after = (item["medians"] for item in stages)
    changes = {key: (after[key] / before[key] - 1) * 100 for key in before}
    gain = -changes["instructions"]
    allocation_gain = -changes["allocs"]
    assert gain < 2 and allocation_gain < 2, "target rejection no longer reproduced"
    assert all(value <= 2 for value in changes.values())
    assert before["alloc_bytes"] - after["alloc_bytes"] == 2304
    old = json.loads((root / "work/profiles/screen-timeout-independent.json").read_text())
    assert old["changes_percent"] == changes
    assert old["target_passes"] is False
    correction = json.loads((root / "work/profiles/screen-timeout-clock-correction.json").read_text())
    assert correction["original_lease_annotation"] == metadata["lease_granted"]
    assert correction["baseline_start_utc"] == metadata["stages"][0]["started"]["utc"]
    assert correction["candidate_finish_utc"] == metadata["stages"][1]["finished"]["utc"]
    assert correction["run_finished_utc"] == metadata["finished"]["utc"]
    gates = json.loads((root / "work/profiles/timeout-gate-summary.json").read_text())
    counts = []
    for suite in gates["suites"]:
        log = root / "work/profiles" / ("timeout-allfeature-" + suite["suite"] + ".log")
        assert digest(log) == suite["log_sha256"]
        result = re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", log.read_text())
        assert result == [(str(suite["passed"]), "0", "0")]
        counts.append(suite["passed"])
    units = root / "work/profiles/timeout-allfeature-units.log"
    assert digest(units) == gates["unit_log_sha256"]
    assert re.findall(r"test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;", units.read_text()) == [("12", "0", "0")]
    assert sum(counts) == gates["transport"] == 98 and gates["units"] == 12
    return {"schema": "sv09-borrowed-timeout-proof-audit/1", "stages": stages,
            "changes_percent": changes, "original_target_minimum_percent": 2,
            "target_passes": False, "original_rpc_regression_limit_percent": 2,
            "all_screen_metrics_within_limit": True,
            "retained_tool_children": 18, "retained_complete_callgraphs": 12,
            "selected_allfeature_tests": 110, "selected_failed": 0, "selected_ignored": 0,
            "clock_correction_verified": True, "full20": "not_run after rejected primary"}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("root", nargs="?", type=Path,
                        default=Path(__file__).resolve().parent.parent)
    args = parser.parse_args()
    print(json.dumps(verify(args.root), indent=2))
