#!/usr/bin/env python3
"""Original N200/400 x3 primary collector with immutable inputs and all raw tools."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import tarfile

ROOT = Path(__file__).resolve().parent.parent
STAGES = [
    ("screen-timeout-before", "devloop-before", "cf3eee22c6b06324e299f81b76915651471d8025",
     "73fa59c733f0637b22ce8d58f035aa45cb13f0b7efc4c8e9bb4cdddcef54e0b9"),
    ("screen-timeout-candidate", "devloop-borrowed-timeout", "6ffafa94b6c66144d4afd7b7156859f249c90141",
     "8c5e022e57583c1cbeac425690abec7a9de654db367625f7535e093340863fab"),
]
PINNED_FILES = {
    "bench/devloop/Cargo.toml": "136513da6ad6a7738c0c6f9ba87918f0897022fca0e6f3c36cf6d5b49d3bb66e",
    "bench/devloop/Cargo.lock": "971414022803d3c1a19e32ef4909d1ef897b2e800e6c3574554c31be978e504b",
    "bench/devloop/build.rs": "363342c939503a1f82d665277192991febfbfd39a4ffb39fa2c0e133bb5e324f",
    "bench/devloop/src/main.rs": "163e699803214eb098d5236cba8ee8f8ad6cf927245a0c953303dc226240c9c8",
    "pbrs-grpc/src/server/rpc.rs": "06fab275b9d331c8d38e91d921b45583acec7eee09a4ea19088b91fe246f4b0f",
}
CELL = "rpc.prost.server_stream"


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def snapshot():
    processes = subprocess.check_output(["ps", "-eo", "pid=,comm=,stat=,args="], text=True)
    interested = ("cargo", "rustc", "clang", "cc1plus", "valgrind", "devloop", "strace")
    return {"utc": now(), "loadavg": Path("/proc/loadavg").read_text().strip(),
            "process_snapshot": [line for line in processes.splitlines()
                                 if any(name in line for name in interested)]}


def capture_records(raw, binary):
    records = [json.loads(line) for line in (raw / "invocations.jsonl").read_text().splitlines()]
    assert len(records) == 9, f"expected 6 CG + 3 strace children, got {len(records)}"
    cg = [record for record in records if record["tool"] == "valgrind"]
    trace = [record for record in records if record["tool"] == "strace"]
    assert len(cg) == 6 and len(trace) == 3
    assert all(record["returncode"] == 0 for record in records)
    assert all(record["profile_capture_complete"] and len(record["callgrind_profiles"]) == 1
               for record in cg)
    assert [int(record["command"][record["command"].index("--iters") + 1])
            for record in cg] == [200, 400, 200, 400, 200, 400]
    for record in records:
        if record["tool"] == "valgrind":
            prefix = ["/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind",
                      "--tool=callgrind", "--cache-sim=no",
                      "--callgrind-out-file=/tmp/devloop-callgrind.%p"]
            suffix = ["--prepare-iters", "400"]
        else:
            prefix = ["/usr/bin/strace", "-c", "-f"]
            suffix = []
        iters = record["command"][record["command"].index("--iters") + 1]
        assert record["command"] == [*prefix, str(binary), "run-cell", CELL,
                                      "--iters", iters, *suffix]
        assert record["lc_all"] == "C"
        retained = raw / record["invocation"]
        for description in [record["stdout"], record["stderr"],
                            *record.get("callgrind_profiles", [])]:
            assert sha(retained / description["path"]) == description["sha256"]
        stderr = (retained / "stderr.raw").read_text()
        assert "__CHILD__ " in stderr
        if record["tool"] == "strace":
            assert "total" in stderr, "strace summary missing"
    return records


def main():
    metadata = {"schema": "sv09-borrowed-timeout-screen/1", "cell": CELL,
                "iters": 200, "repeats": 3, "paired_child_iters": [200, 400],
                "lease_granted": os.environ["SV09_LEASE_GRANTED"], "stages": [],
                "qualification": "Original >=2% target and all unchanged controls required; no wall claim.",
                "scope": "Frozen legacy loopback, one streaming warmup, sequential measured calls, default Tokio worker count; both client+server+helper process IR.",
                "wrapper": {"path": "work/timeout-tools/capture-tool.py",
                            "sha256": sha(ROOT / "work/timeout-tools/capture-tool.py")},
                "runner_sha256": sha(Path(__file__)), "pinned_files": PINNED_FILES}
    metadata["tool_sha256"] = {str(path): sha(path) for path in (
        Path("/usr/bin/strace"),
        Path("/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind"),
        Path("/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind.bin"))}
    for filename, expected in PINNED_FILES.items():
        assert sha(ROOT / filename) == expected, filename
    meta_path = ROOT / "work/profiles/screen-timeout-meta.json"
    assert not meta_path.exists(), "refuse to overwrite an existing measurement"

    def save():
        meta_path.write_text(json.dumps(metadata, indent=2) + "\n")

    save()
    for label, binary_name, source, expected_hash in STAGES:
        binary = ROOT / "work/bin" / binary_name
        assert sha(binary) == expected_hash
        report = ROOT / "work/profiles" / (label + ".json")
        raw = ROOT / "work/profiles" / (label + ".raw")
        stdout = ROOT / "work/profiles" / (label + ".stdout.raw")
        stderr = ROOT / "work/profiles" / (label + ".stderr.raw")
        assert not any(path.exists() for path in (report, raw, stdout, stderr))
        raw.mkdir()
        env = dict(os.environ, PBRS_DEVLOOP_COMMIT=source, PBRS_CAPTURE_DIR=str(raw),
                   PBRS_CAPTURE_VALGRIND="/workspace/pure-protobuf/work/toolchain/deb/usr/bin/valgrind",
                   PBRS_CAPTURE_STRACE="/usr/bin/strace",
                   PATH=str(ROOT / "work/timeout-tools") + ":" + os.environ["PATH"])
        command = [str(binary), "run", "--cells", CELL, "--iters", "200", "--repeats", "3", "--out", str(report)]
        stage = {"label": label, "source": source, "binary_sha256": expected_hash,
                 "command": command, "started": snapshot()}
        metadata["stages"].append(stage)
        save()
        print(f"{now()} START {label}", flush=True)
        with stdout.open("wb") as out, stderr.open("wb") as err:
            result = subprocess.run(command, env=env, cwd=ROOT, stdout=out, stderr=err)
        stage.update(finished=snapshot(), returncode=result.returncode)
        save()
        assert result.returncode == 0, f"{label} collector failed"
        records = capture_records(raw, binary)
        collected = json.loads(report.read_text())
        assert collected["devloop_commit"] == source
        assert collected["host"]["perf"] is False
        assert collected["host"]["valgrind"] and collected["host"]["strace"]
        assert len(collected["cells"]) == 1
        cell = collected["cells"][0]
        assert cell["id"] == CELL and cell["iters"] == 200 and cell["repeats"] == 3
        assert cell["instruction_method"] == "differential_callgrind_2n_minus_n"
        assert all(cell[metric]["status"] == "measured"
                   for metric in ("instructions", "allocs", "alloc_bytes", "syscalls", "locks"))
        stage.update(callgrind_children=6, strace_children=3,
                     full_profiles=6, all_raw_hashes_verified=True,
                     child_argv=[record["command"] for record in records])
        archive = raw.with_suffix(".raw.tar.gz")
        with tarfile.open(archive, "w:gz") as output:
            output.add(raw, arcname=raw.name)
        stage["raw_archive"] = {"path": str(archive.relative_to(ROOT)),
                                "sha256": sha(archive), "bytes": archive.stat().st_size}
        stage["report_sha256"] = sha(report)
        stage["stdout_sha256"] = sha(stdout)
        stage["stderr_sha256"] = sha(stderr)
        save()
        print(f"{now()} END {label}: 6 CG full profiles + 3 strace children retained", flush=True)

    comparison = ROOT / "work/profiles/screen-timeout-compare.log"
    command = [str(ROOT / "work/bin/devloop-borrowed-timeout"), "compare", "--rpc",
               "--baseline", str(ROOT / "work/profiles/screen-timeout-before.json"),
               "--current", str(ROOT / "work/profiles/screen-timeout-candidate.json")]
    with comparison.open("wb") as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    metadata.update(original_comparator_argv=command, original_comparator_returncode=result.returncode,
                    comparator_sha256=sha(comparison), finished=snapshot())
    save()
    print(f"{now()} COMPLETE original comparator status {result.returncode}", flush=True)


if __name__ == "__main__":
    main()
