#!/usr/bin/env python3
"""Affected all-feature gates, one completed test executable retained by hash then reclaimed."""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent.parent
TESTS = ["rpc", "gaps", "sv09_streaming", "regress_timeout", "grpc_web",
         "bidi_completion", "hostile", "message_size", "byte_budget_public",
         "compression", "lifecycle"]
metadata = {"source": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
            "features": "all-features", "jobs": 1, "tests": []}
destination = ROOT / "work/profiles/timeout-allfeature-gates.json"
assert not destination.exists()


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def save():
    destination.write_text(json.dumps(metadata, indent=2) + "\n")


save()
for suite in TESTS:
    command = ["cargo", "test", "--locked", "-p", "pbrs-grpc", "--all-features", "--test", suite]
    log = ROOT / "work/profiles" / ("timeout-allfeature-" + suite + ".log")
    assert not log.exists()
    stage = {"suite": suite, "command": command, "started_utc": now()}
    metadata["tests"].append(stage)
    save()
    print(f"{now()} START {suite}", flush=True)
    with log.open("wb") as output:
        result = subprocess.run(command, cwd=ROOT, stdout=output, stderr=subprocess.STDOUT)
    stage.update(returncode=result.returncode, ended_utc=now(),
                 log_sha256=hashlib.sha256(log.read_bytes()).hexdigest())
    save()
    text = log.read_text()
    print(text[-1800:], flush=True)
    assert result.returncode == 0, suite
    # Only this completed, dedicated test binary is reclaimed. No library,
    # release artifact, active command or sibling target is touched.
    match = re.search(r"Running tests/[^\n]+\((target/sv09-devloop/debug/deps/[^)]+)\)", text)
    assert match, suite
    executable = ROOT / match.group(1)
    assert executable.is_file() and executable.name.startswith(suite + "-")
    stage["completed_binary"] = {"path": match.group(1), "bytes": executable.stat().st_size,
                                 "sha256": hashlib.sha256(executable.read_bytes()).hexdigest(),
                                 "reclaimed_after_success": True}
    executable.unlink()
    save()
    print(f"{now()} END {suite}", flush=True)
