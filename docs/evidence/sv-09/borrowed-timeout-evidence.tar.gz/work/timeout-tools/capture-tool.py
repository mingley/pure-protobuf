#!/usr/bin/env python3
"""Forward unchanged Valgrind/strace argv and streams; preserve every child.

This diagnostic wrapper is outside the benchmark/runtime. Put the valgrind and
strace symlinks first on PATH and set PBRS_CAPTURE_DIR plus the absolute real
PBRS_CAPTURE_VALGRIND/PBRS_CAPTURE_STRACE paths. No child argument is rewritten.
"""

import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import signal
import subprocess
import sys
import time


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def describe(path):
    data = path.read_bytes()
    return {"path": path.name, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest()}


def main():
    tool = Path(sys.argv[0]).name
    assert tool in ("valgrind", "strace"), tool
    real = Path(os.environ["PBRS_CAPTURE_" + tool.upper()])
    assert real.is_absolute() and real.resolve() != Path(sys.argv[0]).resolve()
    directory = Path(os.environ["PBRS_CAPTURE_DIR"])
    directory.mkdir(parents=True, exist_ok=True)
    invocation = f"{tool}-{time.time_ns()}-{os.getpid()}"
    retained = directory / invocation
    retained.mkdir()
    command = [str(real), *sys.argv[1:]]
    record = {"schema": "sv09-transparent-tool/1", "invocation": invocation,
              "tool": tool, "wrapper_argv": sys.argv, "command": command,
              "cwd": os.getcwd(), "lc_all": os.environ.get("LC_ALL"),
              "started_utc": now(), "wrapper_pid": os.getpid()}
    try:
        child = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = child.communicate()
        record.update(child_pid=child.pid, returncode=child.returncode, ended_utc=now())
        (retained / "stdout.raw").write_bytes(stdout)
        (retained / "stderr.raw").write_bytes(stderr)
        record["stdout"] = describe(retained / "stdout.raw")
        record["stderr"] = describe(retained / "stderr.raw")
        profiles = []
        if "--tool=callgrind" in command:
            pattern = next(arg.split("=", 1)[1] for arg in command
                           if arg.startswith("--callgrind-out-file="))
            # The real Valgrind launcher execs in place. Retain the actual tool
            # PID from its own diagnostic too, rather than guessing collector PID.
            pids = {child.pid, *map(int, re.findall(rb"==(\d+)==", stderr))}
            originals = set()
            for pid in pids:
                resolved = Path(pattern.replace("%p", str(pid)))
                originals.update(resolved.parent.glob(resolved.name))
                originals.update(resolved.parent.glob(resolved.name + ".*"))
            for index, original in enumerate(sorted(originals)):
                destination = retained / f"callgrind-{index}.out"
                shutil.copy2(original, destination)
                profiles.append({"original_path": str(original), **describe(destination)})
            record["callgrind_profiles"] = profiles
            record["profile_capture_complete"] = bool(profiles)
        (retained / "record.json").write_text(json.dumps(record, indent=2) + "\n")
        with (directory / "invocations.jsonl").open("a") as output:
            output.write(json.dumps(record) + "\n")
        sys.stdout.buffer.write(stdout)
        sys.stdout.buffer.flush()
        sys.stderr.buffer.write(stderr)
        sys.stderr.buffer.flush()
        if child.returncode < 0:
            if -child.returncode not in (signal.SIGKILL, signal.SIGSTOP):
                signal.signal(-child.returncode, signal.SIG_DFL)
            os.kill(os.getpid(), -child.returncode)
        return child.returncode
    except BaseException as error:
        (retained / "capture-error.json").write_text(json.dumps({
            **record, "capture_error": repr(error), "ended_utc": now()}, indent=2) + "\n")
        raise


if __name__ == "__main__":
    sys.exit(main())
