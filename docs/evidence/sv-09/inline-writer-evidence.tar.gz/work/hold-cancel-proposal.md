# SV09 source-only follow-up proposal: remove the response-writer box

This is a proposed experiment, not a runtime edit or qualification claim.
Baseline is the clean shipping runtime at cf3eee22; the failed closed-channel
yield gate is not part of this candidate.

The native prost baseline disassembly proves three separate allocation sizes:

| Site | Allocation/copy size | Proof |
| --- | ---: | --- |
| Client server_streaming call future | 10,816 bytes | Constructor at 0x305ca0; malloc/memcpy 0x2a40 |
| Dynamic service dispatch call future | 11,536 bytes | Constructor at 0x814800; malloc/memcpy 0x2d10 |
| Server server_streaming response writer box | 3,096 bytes | Rpc poll at 0x53263f; malloc/memcpy 0xc18, followed by writer pointer into HoldCancel state |

The writer box is secondary to the two whole-call constructors. It is a bounded
safe candidate because `hold_cancel` owns the box only to project a pinned
writer while retaining the cancellation guard. Removing it saves one allocation
operation and its separate heap storage, subject to the enclosing future's size.
One of 57 allocations is only 1.75%, so the stream allocation-count win alone
does not qualify the unchanged 2% targeted threshold. The instruction change
and complete before/after allocation-byte totals must be measured. Inline writer
storage may enlarge dynamic service futures and erase the byte benefit.

## Exact source design

Keep a small owned state with **cancel declared before write**. The initial
unpolled future captures this whole state, preserving the existing guard-before-
writer drop order before its first poll. After its first poll, pin the writer in
the async frame and move the guard into the owned poll_fn closure. That closure
borrows the pinned writer, so it is destroyed before the writer's storage. On
Ready, take and drop the guard before returning, as the current manual poll does.

```rust
pub(crate) fn hold_cancel<F: Future<Output = ()>>(
    cancel: CancelOnDrop,
    write: F,
) -> impl Future<Output = ()> {
    let held = HoldCancel {
        cancel: Some(cancel),
        write,
    };
    async move {
        // Consuming the whole state avoids disjoint field captures changing
        // the guard-before-writer drop order of an unpolled async block.
        let (cancel, write) = held.into_parts();
        tokio::pin!(write);
        let mut cancel = cancel;
        poll_fn(move |cx| match write.as_mut().poll(cx) {
            Poll::Ready(()) => {
                cancel.take();
                Poll::Ready(())
            }
            Poll::Pending => Poll::Pending,
        })
        .await;
    }
}

struct HoldCancel<F> {
    cancel: Option<CancelOnDrop>,
    write: F,
}

impl<F> HoldCancel<F> {
    fn into_parts(self) -> (Option<CancelOnDrop>, F) {
        (self.cancel, self.write)
    }
}
```

`tokio::pin!` uses the compiler's async-frame pinning. This introduces no unsafe
code, pin-projection dependency, new scheduler task, wire change or default
change. The closure's owned guard avoids relying on an unused local's lifetime.
The current private `HoldCancel<F>: Future` implementation would be removed.
The helper's callers and cancellation-watch protocol remain unchanged.

Before transport checks, dedicated semantic tests must record guard/send and
writer Drop ordering for unpolled drop, Pending drop, Ready completion and
writer-poll panic. A suspended writer must observe cancellation still false
until it completes or the holding future is dropped. These are behavioral
tests of the cancellation lifetime, including the original boxed helper.
Ready completion must be tested through `.await`, as every production caller
uses this helper: both the old and proposed writer are then dropped immediately
after completion, with guard notification first. A caller that manually polls
the private helper to Ready and keeps it alive can retain the old boxed writer
longer; the proposed async helper drops its completed writer during that poll.
Burst ordering/error/trailer/refill, direct wire echo, producer cancellation,
5,000 seeded lifecycle cases, hostile peer and byte-budget gates still apply.

## Experiment gate

First inspect the rebuilt native prost constructor sizes and collect the same
source-pinned original N200/400 x3 primary stream screen. Reject if neither
instructions nor allocation count improves at least 2%, if allocation bytes
regress, or if cancellation/drop ordering differs. A qualifying screen still
requires the original full comparator controls and named correctness checks.
All experiment flags must match the frozen baseline. No builds during the
CL08 quiet lease.

## Larger future-shape lead

The 11,536-byte server and 10,816-byte client constructor copies remain the
dominant proven sites. Before a broader restructuring, collect actual concrete
async type layouts (diagnostic-only rustc print-type-sizes with separate artifact
pinning) to identify which awaited state sets each maximum. Client grab_in
captures all acquire/LB/dial states inline; its ownership is assigned elsewhere.
Boxing only a rare connection/feature branch could reduce the warm future size
without new warm allocations, but it requires the pool/call owner's review and
matching warm/cold/retry/cancel/LB tests. Sparse messages amplify the dynamic
service future to 30,480 bytes in CL08's diagnostic. That alone does not identify
which state controls the 11,536-byte plain echo future.
