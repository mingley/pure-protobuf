# SV09 allocation-before-construction diagnostic

This is not a shipping candidate or an RPC score report. All pbrs-grpc runtime
files remain restored to the shipping boxed writer and dispatch implementation.
The added wrappers are retained only through constructor function pointers.

Cargo.toml, Cargo.lock and build.rs are byte-for-byte copies of the frozen
bench/devloop inputs. The copied main.rs differs only by a new private module
and dispatch-probe CLI arm. Its original CountingAlloc implementation, actual
ProstNativeEchod service and all benchmark shapes are unchanged. The diagnostic
modules forbid unsafe code and introduce no dependencies. Symlinks point to
unchanged original source/proto/corpus files at their equivalent relative depth.

The std-only slot tests pair the original and proposed generic factory shapes
using an explicitly !Unpin future: constructor eager/unpolled drop, Pending
abandonment, Ready retention, poll panic, and constructor panic. These shape
tests do not substitute for production transport/cancellation qualification.

From the same source checkout, using the pinned env.sh and unchanged flags:

```sh
source /workspace/pure-protobuf/work/toolchain/env.sh
rustc --edition 2024 --test -D warnings work/dispatch-probe/src/slot.rs -o work/bin/dispatch-slot-tests
work/bin/dispatch-slot-tests --test-threads=1
CARGO_BUILD_JOBS=1 CARGO_INCREMENTAL=0 CARGO_PROFILE_DEV_DEBUG=0 CARGO_PROFILE_TEST_DEBUG=0 \
  CARGO_TARGET_DIR=$PWD/target/sv09-devloop cargo build --release --locked --manifest-path work/dispatch-probe/Cargo.toml
target/sv09-devloop/release/devloop dispatch-probe
```

Inspect actual native constructor symbols and all out-of-line helpers before
concluding whether the whole service-future memcpy disappeared. The original
DynService constructor must still reproduce the baseline 11,536-byte copy. If
that copy remains in the proposal, reject without runtime composition.
