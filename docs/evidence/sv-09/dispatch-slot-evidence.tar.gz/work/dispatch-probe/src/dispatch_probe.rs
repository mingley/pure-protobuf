//! Assembly diagnostic only. Neither constructor is installed into DynService.
#![forbid(unsafe_code)]

#[path = "slot.rs"]
mod slot;

use super::{ProstNativeEchod, Rpc, Service};
use std::future::Future;
use std::hint::black_box;
use std::mem::size_of;
use std::pin::Pin;

type Erased<'a> = Pin<Box<dyn Future<Output = ()> + Send + 'a>>;
type Constructor = for<'a> fn(&'a ProstNativeEchod, Rpc) -> Erased<'a>;

#[inline(never)]
fn original_native_dispatch(service: &ProstNativeEchod, rpc: Rpc) -> Erased<'_> {
    Box::pin(service.call(rpc))
}

#[inline(never)]
fn proposed_native_dispatch(service: &ProstNativeEchod, rpc: Rpc) -> Erased<'_> {
    slot::boxed_dispatch(|| service.call(rpc))
}

fn layout<F>(_: impl FnOnce(Rpc) -> F) -> (usize, usize) {
    (size_of::<F>(), size_of::<Option<F>>())
}

pub(super) fn report() {
    let original: Constructor = original_native_dispatch;
    let proposed: Constructor = proposed_native_dispatch;
    black_box(original);
    black_box(proposed);
    let service = ProstNativeEchod;
    let (future, slot) = layout(|rpc| service.call(rpc));
    println!(
        "native_prost service_future_bytes={future} option_slot_bytes={slot} rpc_bytes={} wrapper_pointer_bytes={}",
        size_of::<Rpc>(),
        size_of::<Pin<Box<Option<()>>>>(),
    );
    println!("original_ctor={original:p} proposed_ctor={proposed:p}");
}
