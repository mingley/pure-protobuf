//! Diagnostic only: safe allocation before service-future construction.
#![forbid(unsafe_code)]

use std::future::Future;
use std::pin::Pin;
use std::task::{Context, Poll};

struct PinnedDispatch<F> {
    future: Pin<Box<Option<F>>>,
}

impl<F: Future<Output = ()>> Future for PinnedDispatch<F> {
    type Output = ();

    fn poll(mut self: Pin<&mut Self>, cx: &mut Context<'_>) -> Poll<()> {
        match self.future.as_mut().as_pin_mut() {
            Some(future) => future.poll(cx),
            None => Poll::Ready(()),
        }
    }
}

pub fn boxed_dispatch<'a, F: Future<Output = ()> + Send + 'a>(
    make: impl FnOnce() -> F,
) -> Pin<Box<dyn Future<Output = ()> + Send + 'a>> {
    let mut slot: Box<Option<F>> = Box::new(None);
    *slot = Some(make());
    Box::pin(PinnedDispatch {
        future: Box::into_pin(slot),
    })
}

#[cfg(test)]
mod tests {
    use super::boxed_dispatch;
    use std::future::Future;
    use std::marker::PhantomPinned;
    use std::panic::{AssertUnwindSafe, catch_unwind};
    use std::pin::Pin;
    use std::sync::Arc;
    use std::sync::atomic::{AtomicBool, AtomicU64, AtomicUsize, Ordering};
    use std::task::{Context, Poll, Wake, Waker};

    // Each event occupies one nibble: constructor 1, Pending 2, Ready 3,
    // panic 4, cancellation 5, cancelled writer drop 6, constructor panic 7.
    #[derive(Clone, Default)]
    struct State {
        cancelled: Arc<AtomicBool>,
        events: Arc<AtomicU64>,
        drops: Arc<AtomicUsize>,
    }

    impl State {
        fn push(&self, event: u64) {
            let mut old = self.events.load(Ordering::SeqCst);
            loop {
                match self.events.compare_exchange(
                    old,
                    (old << 4) | event,
                    Ordering::SeqCst,
                    Ordering::SeqCst,
                ) {
                    Ok(_) => break,
                    Err(current) => old = current,
                }
            }
        }

        fn events(&self) -> u64 {
            self.events.load(Ordering::SeqCst)
        }
    }

    struct Cancel(State);

    impl Cancel {
        fn cancel(&self) {
            if !self.0.cancelled.swap(true, Ordering::SeqCst) {
                self.0.push(5);
            }
        }
    }

    impl Drop for Cancel {
        fn drop(&mut self) {
            self.cancel();
        }
    }

    struct Writer(State);

    impl Drop for Writer {
        fn drop(&mut self) {
            assert!(self.0.cancelled.load(Ordering::SeqCst));
            self.0.push(6);
            assert_eq!(self.0.drops.fetch_add(1, Ordering::SeqCst), 0);
        }
    }

    #[derive(Clone, Copy)]
    enum Mode {
        Pending,
        Ready,
        Panic,
    }

    struct Probe {
        cancel: Cancel,
        _writer: Writer,
        mode: Mode,
        _pinned: PhantomPinned,
    }

    impl Probe {
        fn new(state: &State, mode: Mode) -> Self {
            Self {
                cancel: Cancel(state.clone()),
                _writer: Writer(state.clone()),
                mode,
                _pinned: PhantomPinned,
            }
        }
    }

    impl Future for Probe {
        type Output = ();

        fn poll(self: Pin<&mut Self>, _: &mut Context<'_>) -> Poll<()> {
            let this = self.as_ref().get_ref();
            assert!(!this.cancel.0.cancelled.load(Ordering::SeqCst));
            match this.mode {
                Mode::Pending => {
                    this.cancel.0.push(2);
                    Poll::Pending
                }
                Mode::Ready => {
                    this.cancel.0.push(3);
                    this.cancel.cancel();
                    Poll::Ready(())
                }
                Mode::Panic => {
                    this.cancel.0.push(4);
                    panic!("probe poll panic");
                }
            }
        }
    }

    #[derive(Clone, Copy)]
    enum Shape {
        Original,
        BeforeConstruction,
    }

    fn construct(
        shape: Shape,
        make: impl FnOnce() -> Probe,
    ) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        match shape {
            Shape::Original => Box::pin(make()),
            Shape::BeforeConstruction => boxed_dispatch(make),
        }
    }

    fn make(shape: Shape, state: &State, mode: Mode) -> Pin<Box<dyn Future<Output = ()> + Send>> {
        let captured = state.clone();
        construct(shape, move || {
            captured.push(1);
            Probe::new(&captured, mode)
        })
    }

    struct Noop;
    impl Wake for Noop {
        fn wake(self: Arc<Self>) {}
    }

    fn poll(future: &mut Pin<Box<dyn Future<Output = ()> + Send>>) -> Poll<()> {
        let waker = Waker::from(Arc::new(Noop));
        let mut cx = Context::from_waker(&waker);
        future.as_mut().poll(&mut cx)
    }

    #[test]
    fn constructor_is_eager_and_unpolled_drop_preserves_order() {
        for shape in [Shape::Original, Shape::BeforeConstruction] {
            let state = State::default();
            let future = make(shape, &state, Mode::Pending);
            assert_eq!(state.events(), 0x1);
            assert!(!state.cancelled.load(Ordering::SeqCst));
            drop(future);
            assert_eq!(state.events(), 0x156);
            assert_eq!(state.drops.load(Ordering::SeqCst), 1);
        }
    }

    #[test]
    fn pending_drop_preserves_the_guard_until_abandonment() {
        for shape in [Shape::Original, Shape::BeforeConstruction] {
            let state = State::default();
            let mut future = make(shape, &state, Mode::Pending);
            assert!(poll(&mut future).is_pending());
            assert_eq!(state.events(), 0x12);
            assert!(!state.cancelled.load(Ordering::SeqCst));
            drop(future);
            assert_eq!(state.events(), 0x1256);
            assert_eq!(state.drops.load(Ordering::SeqCst), 1);
        }
    }

    #[test]
    fn ready_retains_completed_future_until_its_wrapper_drops() {
        for shape in [Shape::Original, Shape::BeforeConstruction] {
            let state = State::default();
            let mut future = make(shape, &state, Mode::Ready);
            assert!(poll(&mut future).is_ready());
            assert_eq!(state.events(), 0x135);
            assert_eq!(state.drops.load(Ordering::SeqCst), 0);
            drop(future);
            assert_eq!(state.events(), 0x1356);
            assert_eq!(state.drops.load(Ordering::SeqCst), 1);
        }
    }

    #[test]
    fn poll_panic_then_drop_preserves_cancellation_order() {
        for shape in [Shape::Original, Shape::BeforeConstruction] {
            let state = State::default();
            let mut future = make(shape, &state, Mode::Panic);
            assert!(catch_unwind(AssertUnwindSafe(|| poll(&mut future))).is_err());
            drop(future);
            assert_eq!(state.events(), 0x1456);
            assert_eq!(state.drops.load(Ordering::SeqCst), 1);
        }
    }

    #[test]
    fn constructor_panic_drops_captured_owned_state_once() {
        for shape in [Shape::Original, Shape::BeforeConstruction] {
            let state = State::default();
            let captured = Probe::new(&state, Mode::Pending);
            assert!(
                catch_unwind(AssertUnwindSafe(|| {
                    construct(shape, move || {
                        let owned = captured;
                        owned.cancel.0.push(1);
                        owned.cancel.0.push(7);
                        panic!("probe constructor panic");
                    })
                }))
                .is_err()
            );
            assert_eq!(state.events(), 0x1756);
            assert_eq!(state.drops.load(Ordering::SeqCst), 1);
        }
    }
}
