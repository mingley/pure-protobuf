# Reconstruct the campaign

Start from baseline `77f361eb8f22d957a737b62bd3524d79b05a57e5` in a disposable checkout. Apply
`source/implementation.patch` for final production and proof source. The
performance variant-file reconstruction record supplies exact overlays and
source chains for the measured map variants and RPC transport candidate.
Follow each frozen source/build manifest and retained helper/lockfile. Do not
include an installed `third_party` SDK in codec snapshot exports: its presence
changes build-script descriptor inputs. The isolated official conformance
driver explicitly records and uses the pinned upstream SDK instead.

The V1 campaign is superseded; its slower collection cases remain in the
archive. The final V2 precheck accepts valid conservative size hints in both
builds; timed loops are unchanged. CPU and allocation builds are separate.
The RPC resume chunks follow one immutable randomized plan and aggregate only
after all 120 captures complete. No cache, compiler installation, executable,
or duplicate full source checkout is included.
