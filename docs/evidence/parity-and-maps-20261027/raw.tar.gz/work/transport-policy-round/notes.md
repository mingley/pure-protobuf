# Native socket and idle keepalive policies

`tcp_nodelay(bool)` defaults true in ServerConfig and ChannelConfig. Server,
Router and generated native server builders forward it. The connected TCP
socket is tuned before optional TLS; the server tunes accepted TCP sockets
before optional TLS. Unix and caller-owned byte streams retain existing
behavior. Actual kernel socket options are asserted in tcp unit tests;
public generated APIs exchange messages over plaintext and TLS with both
settings in the integration test.

`ChannelConfig::keep_alive_while_idle(bool)` defaults true for compatibility.
False suppresses HTTP/2 keepalive PINGs when no RPC lease remains, including
leases transferred into response Streaming. It does not enable an interval.
Data-driven BDP probes remain separate. Existing probes retain their ACK
request deadline even if the RPC finishes after transmission. Configured
intervals below 1 ms are raised to 1 ms instead of panicking in the ticker.

The fixed-window task waits on existing Busy notifications; the adaptive
driver registers a waker before checking Busy. That specialized waker is
boxed and initialized only for explicit active-only adaptive keepalive.
Default Busy start/drop never performs an AtomicWaker operation; default
clients continue without a Busy allocation when no lifetime limits apply.
Driver drop clears its registered waker. The separate keepalive task also
exits when all dead-watch receivers disappear, so an idle/no-PING task does
not retain its connection activity forever.

A discovered BDP bug renewed a pending PING deadline every shorter interval.
The fix latches its first deadline until ACK, and wakes only at that deadline.
The raw-wire regression test advances in 20 ms steps past the 80 ms deadline,
forcing intermediate polls that would have renewed the old deadline.

Raw HTTP/2 tests use paused clocks and no auto-PONG peer. They verify idle
suppression, default idle PING, live response-stream ownership, repeated
idle-to-active transitions, timeout closure and cleanup for both fixed and
adaptive windows. Initial logs retain fixture compilation mistakes and transient failures from
concurrent code edits; final passing runs are named explicitly in results.json.
No CPU or latency improvement is claimed for these functional features.
