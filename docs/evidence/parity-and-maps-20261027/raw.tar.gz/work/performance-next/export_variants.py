"""Export exact small overlays and a checked reconstruction of frozen sources."""
import hashlib,json,shutil
from pathlib import Path

BASE=Path(__file__).resolve().parent
out=BASE/'source-overlays'
out.mkdir(exist_ok=False)
baseline=json.loads((BASE/'baseline-source-source.json').read_text())
variants={}
for name,source in [('v1','map-candidate-source'),('v2','map-v2-source'),('rpc','rpc-candidate-source')]:
    record=json.loads((BASE/(source+'-source.json')).read_text())
    files=record['files'];changed={p:h for p,h in files.items() if baseline['files'].get(p)!=h}
    removed=sorted(set(baseline['files'])-set(files))
    for path,expected in changed.items():
        original=BASE/source/path
        if hashlib.sha256(original.read_bytes()).hexdigest()!=expected:raise ValueError(path)
        target=out/name/path;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(original,target)
    variants[name]=dict(source=source,files=files,changed=changed,removed=removed)
(out/'manifest.json').write_text(json.dumps(dict(baseline=baseline,variants=variants),indent=2)+'\n')
shutil.copy2(__file__,out/'export_variants.py')
print(json.dumps({k:dict(changed=len(v['changed']),removed=len(v['removed'])) for k,v in variants.items()}))
