"""Verify one-file attribution, helper identity, features and binary records."""
import hashlib,json,re,subprocess
from pathlib import Path
BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=json.loads((BASE/'baseline-source-source.json').read_text())
after=json.loads((BASE/'map-candidate-source-source.json').read_text())
changed=[name for name,value in base['files'].items() if after['files'].get(name)!=value]
assert changed==['src/map.rs'];assert set(base['files'])==set(after['files'])
report=dict(baseline_commit=base['commit'],changed_files=changed,source_files=len(base['files']),binaries={},helper_checks={},qualified=False)
for group in ['baseline-lazy','baseline-owned','candidate-lazy','candidate-owned','map-baseline','map-candidate']:
 for mode in ['shipping','allocations']:
  root=BASE/group;record=json.loads((root/f'codec-{mode}-build.json').read_text());binary=root/f'codec-{mode}'
  assert record['exit_code']==0 and record['source_unchanged'] and record['harness_unchanged'];assert sha(binary)==record['binary_sha256']
  expected=({'allocations'} if mode=='allocations' else set())|({'owned-messages'} if group.endswith('owned') else set())
  assert set(record['features'])==expected
  sections=subprocess.check_output(['readelf','-W','-S',str(binary)],text=True)
  line=next(line for line in sections.splitlines() if re.search(r'\]\s+\.text\s',line));cols=line.split();i=cols.index('.text');size=int(cols[i+4],16)
  report['binaries'][group+'/'+mode]=dict(sha256=sha(binary),bytes=binary.stat().st_size,literal_elf_text_bytes=size,features=record['features'])
for rel in ['src/main.rs','build.rs','Cargo.lock','Cargo.toml']:
 a=BASE/'baseline-source/tests/proof/codec_benchmark'/rel;b=BASE/'map-candidate-source/tests/proof/codec_benchmark'/rel
 assert a.read_bytes()==b.read_bytes();report['helper_checks']['codec/'+rel]=sha(a)
for rel in ['src/main.rs','Cargo.lock']:
 a=BASE/'map-before'/rel;b=BASE/'map-after'/rel
 assert a.read_bytes()==b.read_bytes();report['helper_checks']['map/'+rel]=sha(a)
a=(BASE/'map-before/Cargo.toml').read_text().replace(str(BASE/'baseline-source'),'FROZEN_CORE');b=(BASE/'map-after/Cargo.toml').read_text().replace(str(BASE/'map-candidate-source'),'FROZEN_CORE');assert a==b
report['helper_checks']['map/Cargo.toml_normalized_equal']=True
report['complete']=True
(BASE/'artifact-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(complete=True,binaries=len(report['binaries']),changed_files=changed)))
