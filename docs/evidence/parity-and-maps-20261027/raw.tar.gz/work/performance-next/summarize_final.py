"""Collect every measured variant without promoting a world-ranking claim."""
import json
from pathlib import Path
BASE=Path(__file__).resolve().parent
names=['lazy-comparison','owned-comparison','map-small-comparison','map-large-comparison',
       'v2-lazy-comparison','v2-owned-comparison','v2-map-small-comparison','v2-map-large-comparison']
matrices={}
for name in names:
    manifest=json.loads((BASE/name/'manifest.json').read_text())
    assert manifest['state']=='complete' and manifest['passed']
    summary=json.loads((BASE/name/'summary.json').read_text())
    matrices[name]=dict(rows=len(summary),shipping_processes=manifest['shipping_processes'],
                        allocation_processes=manifest['allocation_processes'],cpu_samples=manifest['cpu_samples'],
                        summary=name+'/summary.json',manifest=name+'/manifest.json',
                        all_rows=[dict(case=x['case'],operation=x['operation'],cpu_ns_medians=x['cpu_ns_medians'],
                                       ratios=x['ratios'],allocations=x['allocations']) for x in summary])
rpc=json.loads((BASE/'rpc-comparison/manifest.json').read_text())
assert rpc['state']=='complete' and rpc['passed']
final={k:v for k,v in matrices.items() if k.startswith('v2-')}
def totals(items):return {key:sum(v[key] for v in items.values()) for key in ['rows','shipping_processes','allocation_processes','cpu_samples']}
report=dict(schema='pbrs.parity-and-map-performance.v1',complete=True,qualified=False,world_ranking_proven=False,
    full_tonic_prost_parity_proven=False,source_commit='12cfd09f318b2bcc4d49ca1e2df0e54b56a190ab',
    baseline_commit='77f361eb8f22d957a737b62bd3524d79b05a57e5',
    selected_variant='v2',selection_scope='Retain streamed typed map iterator and borrowed small-map lookup; disclose parse/read regressions alongside direct-map gains.',
    selected_map_sha256='c60f9db6c3c67775dd539bffd634779bfd7ca19a0499ba684f8a000e9374a6d1',
    superseded_variant='v1',superseded_reason='V1 exact typed size_hint duplicated key scanning and regressed distinct collect rows; retained raw captures prevent cherry-picking.',
    totals_all_variants=totals(matrices),totals_selected=totals(final),matrices=matrices,
    rpc=dict(summary='rpc-comparison/summary.json',manifest='rpc-comparison/manifest.json',captures=rpc['captures'],successful_rpcs=rpc['successful_rpcs'],
             rows=json.loads((BASE/'rpc-comparison/summary.json').read_text()),source_equivalence='rpc-final-source-equivalence.json'),
    reconstruction=dict(script='reconstruct_variant.py',overlays='source-overlays/manifest.json',audit='artifact-audit-v2.json'),
    limits=['One shared x86_64 VM; diagnostic paired samples, not dedicated-host qualification.',
            'All wins and losses retained for lazy and optional owned storage; owned mixed parse/read and sparse read regressions remain.',
            'Map microprobe excludes construction, parsing and first-use index build; its Prost-labelled control is std HashMap, not Prost decoding.',
            'Fast map timings can be shorter than1ms; CPU instruction or cross-host ranking is not established.',
            'RPC uses identical Prost codec and matched successful handler work; default transport regression comparison only.',
            'RPC frozen transport differs from final only by verified rustfmt normalization; final map is unused in successful same-Prost cells.',
            'Counter-based RPC N/2N slopes include startup/scheduling variation; no per-capture FAIRNESS/socket attestation.',
            'Separate allocation counters report successful requested allocation/reallocation bytes, not RSS or retained memory.'])
(BASE/'results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(dict(complete=True,totals=report['totals_all_variants'],rpc=report['rpc']['captures'])))
