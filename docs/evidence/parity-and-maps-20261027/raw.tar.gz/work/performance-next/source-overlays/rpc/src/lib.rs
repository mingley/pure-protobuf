//! Protocol Buffers runtime and code generator with the Google protobuf v4 API.
//!
//! Generate messages with `protoc-gen-pbrs` or `pbrs::codegen`.
//! Google's `protoc --rust_out` output uses the separate compatibility runtime.
//!
//! ```ignore
//! pbrs = { git = "https://github.com/mingley/pure-protobuf" }
//! ```

#![deny(unsafe_op_in_unsafe_fn)]
#![expect(
    missing_docs,
    reason = "the v4 application API is described in the crate docs and README; per-item rustdoc is follow-up"
)]
#![expect(
    unsafe_code,
    reason = "MiniTable ABI, ProtoStr cast, packed memcpy, JSON strtod, generated zeroed Default"
)]
#![allow(
    clippy::indexing_slicing,
    clippy::cast_possible_truncation,
    clippy::cast_possible_wrap,
    clippy::cast_sign_loss,
    clippy::let_underscore_must_use,
    clippy::too_many_lines,
    clippy::mem_forget,
    unreachable_pub,
    reason = "wire parser and generated gencode: checked offsets, specified integer widths, String fmt is infallible"
)]

extern crate self as pbrs;

#[cfg(feature = "conformance")]
mod any;

#[doc(hidden)]
pub use paste as __paste;

#[cfg(feature = "reflect")]
pub use crate::dynamic::{
    Cardinality, DescriptorOption, DescriptorPool, DynamicMessage, DynamicMessageMut,
    DynamicMessageView, EnumDescriptor, FieldDescriptor, FieldType, FileDescriptor, MapKeyValue,
    MessageDescriptor, MethodDescriptor, Presence, RECURSION_LIMIT, ServiceDescriptor, Value,
};
#[cfg(not(feature = "reflect"))]
pub const RECURSION_LIMIT: u32 = 100;
pub use crate::error::{ParseError, SerializeError};
pub use crate::extension::{Extension, ExtensionHost, ExtensionValue};
pub use crate::map::{Map, MapIter, MapKey, MapMut, MapValue, MapView};
pub use crate::message::{
    Clear, ClearAndParse, CopyFrom, Enum, MergeFrom, Message, MessageMut, MessageName, MessageType,
    MessageView, Name, Parse, Serialize, TakeFrom, UnknownEnumValue, message_eq,
};
pub use crate::proxied::{
    AsMut, AsView, IntoMut, IntoProxied, IntoView, Mut, MutProxied, Proxied, View,
};
pub use crate::repeated::{ProtoPut, Repeated, RepeatedIter, RepeatedMut, RepeatedView, Singular};
pub use crate::string::{ProtoBytes, ProtoStr, ProtoString, Utf8Error};
pub use crate::wire::{UnknownFields, WireOut};

pub use Singular as ProxiedInRepeated;

pub mod prelude;

#[doc(hidden)]
pub mod __internal {
    pub use crate::internal::{
        EntityType, Enum, MatcherEq, Private, SealedInternal, assert_compatible_gencode_version,
        entity_tag,
    };
    pub use crate::runtime;
}

#[cfg(feature = "codegen")]
pub mod codegen;
pub mod copy_counts;
#[cfg(feature = "reflect")]
mod dynamic;
mod error;
mod extension;
pub mod gen_support;
#[cfg(feature = "conformance")]
pub mod gencode;
#[cfg(feature = "conformance")]
mod generated;
/// Shared standard `google.protobuf` message and enum types.
///
/// Available with the `conformance` feature (enabled by default). Descriptor
/// schema types such as `DescriptorProto` are not part of this module.
#[cfg(feature = "conformance")]
pub mod wkt {
    pub use crate::generated::{
        any::*, duration::*, empty::*, field_mask::*, pb_struct::*, timestamp::*, wrappers::*,
    };
}
mod internal;
#[cfg(feature = "json")]
pub mod json;
mod lazy;
mod map;
mod message;
mod packed;
mod proxied;
mod repeated;
pub mod rt;
#[doc(hidden)]
pub mod runtime;
mod string;
pub mod table;
pub mod testdata;
#[cfg(feature = "text")]
pub mod text;
mod wire;

/// proto! enables Rust struct-init syntax for protobuf messages.
///
/// ```ignore
/// let msg = proto!(Person {
///     id: 1,
///     name: "ada",
///     address: Address { city: "nyc" },
/// });
/// ```
#[macro_export]
macro_rules! proto {
    ($ty:ident { $($body:tt)* }) => {{
        let mut this = <$ty as ::core::default::Default>::default();
        $crate::proto!(@spread_owned this, [] $($body)*);
        this
    }};
    (@spread_owned $this:ident, [$($fs:tt)*] .. $rest:expr_2021 $(,)?) => {
        $crate::MergeFrom::merge_from(&mut $this, $rest);
        $crate::proto!(@owned $this, $($fs)*);
    };
    (@spread_owned $this:ident, [$($fs:tt)*] $t:tt $($rest:tt)*) => {
        $crate::proto!(@spread_owned $this, [$($fs)* $t] $($rest)*);
    };
    (@spread_owned $this:ident, [$($fs:tt)*]) => {
        $crate::proto!(@owned $this, $($fs)*);
    };
    (@spread_mut $this:ident, [$($fs:tt)*] .. $rest:expr_2021 $(,)?) => {
        $crate::MergeFrom::merge_from($this, $rest);
        $crate::proto!(@mut $this, $($fs)*);
    };
    (@spread_mut $this:ident, [$($fs:tt)*] $t:tt $($rest:tt)*) => {
        $crate::proto!(@spread_mut $this, [$($fs)* $t] $($rest)*);
    };
    (@spread_mut $this:ident, [$($fs:tt)*]) => {
        $crate::proto!(@mut $this, $($fs)*);
    };
    (@owned $this:ident, ) => {};
    (@owned $this:ident, .. $rest:expr_2021 $(,)?) => {
        $crate::MergeFrom::merge_from(&mut $this, $rest);
    };
    (@owned $this:ident, $field:ident : __ { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __n = $this.[<$field _mut>]();
                $crate::proto!(@spread_mut __n, [] $($sub)*);
            }
        }
        $crate::proto!(@owned $this, $($($rest)*)?);
    };
    (@owned $this:ident, $field:ident : $subty:ident { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<set_ $field>]($crate::proto!($subty { $($sub)* }));
        }
        $crate::proto!(@owned $this, $($($rest)*)?);
    };
    (@owned $this:ident, $field:ident : [ $($arr:tt)* ] $(, $($rest:tt)*)?) => {
        $crate::proto!(@arr $this, $field, $($arr)*);
        $crate::proto!(@owned $this, $($($rest)*)?);
    };
    (@owned $this:ident, $field:ident : $val:expr_2021 $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<set_ $field>]($val);
        }
        $crate::proto!(@owned $this, $($($rest)*)?);
    };
    (@mut $this:ident, ) => {};
    (@mut $this:ident, .. $rest:expr_2021 $(,)?) => {
        $crate::MergeFrom::merge_from($this, $rest);
    };
    (@mut $this:ident, $field:ident : __ { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __n = $this.[<$field _mut>]();
                $crate::proto!(@spread_mut __n, [] $($sub)*);
            }
        }
        $crate::proto!(@mut $this, $($($rest)*)?);
    };
    (@mut $this:ident, $field:ident : $subty:ident { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<set_ $field>]($crate::proto!($subty { $($sub)* }));
        }
        $crate::proto!(@mut $this, $($($rest)*)?);
    };
    (@mut $this:ident, $field:ident : [ $($arr:tt)* ] $(, $($rest:tt)*)?) => {
        $crate::proto!(@arr_mut $this, $field, $($arr)*);
        $crate::proto!(@mut $this, $($($rest)*)?);
    };
    (@mut $this:ident, $field:ident : $val:expr_2021 $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<set_ $field>]($val);
        }
        $crate::proto!(@mut $this, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, ) => {};
    (@arr $this:ident, $field:ident, __ { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __r = $this.[<$field _mut>]();
                let mut __e = __r.push_default();
                $crate::proto!(@spread_mut __e, [] $($sub)*);
            }
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, $ty:ident { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().push($crate::proto!($ty { $($sub)* }));
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, ($k:expr_2021, __ { $($sub:tt)* }) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __r = $this.[<$field _mut>]();
                let mut __v = __r.default_value();
                $crate::proto!(@owned __v, $($sub)*);
                __r.insert($k, __v);
            }
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, ($k:expr_2021, $ty:ident { $($sub:tt)* }) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().insert($k, $crate::proto!($ty { $($sub)* }));
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, ($k:expr_2021, $v:expr_2021) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().insert($k, $v);
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr $this:ident, $field:ident, $val:expr_2021 $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().proto_put($val);
        }
        $crate::proto!(@arr $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, ) => {};
    (@arr_mut $this:ident, $field:ident, __ { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __r = $this.[<$field _mut>]();
                let mut __e = __r.push_default();
                $crate::proto!(@spread_mut __e, [] $($sub)*);
            }
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, $ty:ident { $($sub:tt)* } $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().push($crate::proto!($ty { $($sub)* }));
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, ($k:expr_2021, __ { $($sub:tt)* }) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            {
                let mut __r = $this.[<$field _mut>]();
                let mut __v = __r.default_value();
                $crate::proto!(@owned __v, $($sub)*);
                __r.insert($k, __v);
            }
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, ($k:expr_2021, $ty:ident { $($sub:tt)* }) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().insert($k, $crate::proto!($ty { $($sub)* }));
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, ($k:expr_2021, $v:expr_2021) $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().insert($k, $v);
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
    (@arr_mut $this:ident, $field:ident, $val:expr_2021 $(, $($rest:tt)*)?) => {
        $crate::__paste::paste! {
            $this.[<$field _mut>]().proto_put($val);
        }
        $crate::proto!(@arr_mut $this, $field, $($($rest)*)?);
    };
}
