"""Interleave frozen before/after codec probes and independent Prost controls.

Every real sample and loss is retained. This is a shared-host development
comparison, never an overall performance ranking.
"""
import argparse
import hashlib
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
import statistics
import subprocess
import sys
import time

CASES={"empty":5_000_000,"scalars":1_000_000,"blob_4kib":30_000,
       "packed_256":50_000,"nested_8":50_000,"nested_64":10_000,
       "rpc_sparse":1_000_000,"rpc_mixed":30_000}
OPS=("parse_owned","read_all")
FIXTURE_SCOPE="Owned results; parse_owned can defer work, read_all visits every populated field and payload byte"
SCHEMA='pbrs.codec-fix-comparison.v1'
CPU_SCOPE='CLOCK_PROCESS_CPUTIME_ID; each owned result dropped inside timing; counters absent'
LIMITS=['shared x86_64 VM; no independent dedicated-host qualification',
        'parse_owned may defer work; read_all recursively accesses every populated field and body byte',
        'five pairs and bootstrap intervals are local diagnostics',
        'iterations fixed per fixture and identical across sources/backends']
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def read_optional(path):
    try:return Path(path).read_text()
    except OSError:return None
def interval(values,seed):
    rng=random.Random(seed)
    draws=sorted(statistics.median(rng.choices(values,k=len(values))) for _ in range(20_000))
    return dict(median=statistics.median(values),range=[min(values),max(values)],
                diagnostic_bootstrap95=[draws[499],draws[19499]],pairs=values)
def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for source in ('before','after'):
        for mode in ('shipping','allocations'):
            parser.add_argument(f'--{source}-{mode}',required=True,type=Path)
        parser.add_argument(f'--{source}-record',required=True,type=Path)
    parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--storage',choices=['lazy','owned'],required=True)
    parser.add_argument('--pairs',type=int,default=5)
    parser.add_argument('--samples',type=int,default=3)
    parser.add_argument('--seed',type=int,default=271127)
    args=parser.parse_args()
    if args.pairs<5 or args.samples<1:parser.error('At least five pairs and one sample are required')
    out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
    binaries={(source,mode):getattr(args,f'{source}_{mode}').resolve(strict=True)
              for source,mode in itertools.product(('before','after'),('shipping','allocations'))}
    hashes={f'{s}-{m}':sha(p) for (s,m),p in binaries.items()}
    records={source:json.loads(getattr(args,f'{source}_record').read_text()) for source in ('before','after')}
    for source in records:
        for mode in ('shipping','allocations'):
            if records[source]['binaries'][f'codec-{mode}']['sha256']!=hashes[f'{source}-{mode}']:
                raise ValueError(f'{source}/{mode} binary does not match its build record')
    affinity=sorted(os.sched_getaffinity(0));core=affinity[0];os.sched_setaffinity(0,{core})
    rng=random.Random(args.seed);plan=[]
    for pair in range(args.pairs):
        cells=list(itertools.product(CASES,OPS));rng.shuffle(cells)
        for case,op in cells:
            versions=list(itertools.product(('before','after'),('pbrs','prost')));rng.shuffle(versions)
            for source,backend in versions:
                plan.append(dict(pair=pair,case=case,operation=op,source=source,backend=backend))
    manifest=dict(schema=SCHEMA,qualified=False,state='running',
                  seed=args.seed,pairs=args.pairs,samples=args.samples,cases=CASES,message_storage=args.storage,
                  cpu=core,affinity_before_pin=affinity,host=platform.uname()._asdict(),
                  cgroup_cpu_max=read_optional('/sys/fs/cgroup/cpu.max'),
                  cgroup_before=read_optional('/sys/fs/cgroup/cpu.stat'),
                  binary_sha256=hashes,build_records=records,plan=plan,
                  fixture_scope=FIXTURE_SCOPE,
                  cpu_scope=CPU_SCOPE,
                  allocation_scope='Separate successful Rust allocation/reallocation requests; not RSS or retained memory',
                  limits=LIMITS)
    manifest_path=out/'manifest.json'
    def save():manifest_path.write_text(json.dumps(manifest,indent=2)+'\n')
    save();shutil.copy2(__file__,out/'codec_compare.py')
    entry=Path(sys.argv[0]).resolve()
    if entry!=Path(__file__).resolve():shutil.copy2(entry,out/entry.name)
    for source in records:shutil.copy2(getattr(args,f'{source}_record'),out/f'{source}-build.json')
    rows=[];fixtures={};allocation_rows=[]
    def capture(entry,mode,index,iterations,samples):
        command=[str(binaries[entry['source'],mode]),entry['case'],entry['backend'],entry['operation'],str(iterations),str(samples)]
        proc=subprocess.run(command,capture_output=True,text=True)
        (out/f'{mode}-{index:03d}.stderr').write_text(proc.stderr)
        (out/f'{mode}-{index:03d}.stdout').write_text(proc.stdout)
        row=dict(entry,command=command,returncode=proc.returncode,stdout=proc.stdout)
        if proc.returncode!=0:raise RuntimeError(f'Probe failed; record preserved: {row}')
        value=json.loads(proc.stdout)
        if value.get('message_storage')!=args.storage:raise ValueError('Probe returned different storage profile')
        if any(value.get(key)!=entry[key] for key in ('case','backend','operation')):
            raise ValueError('Probe returned a different operation')
        if len(value['samples'])!=samples or any(s['iterations']!=iterations or s['cpu_ns']<=0 for s in value['samples']):
            raise ValueError('Probe returned invalid sample work')
        if value.get('semantic_prechecks') is not True or value.get('allocation_instrumentation')!=(mode=='allocations'):
            raise ValueError('Semantic precheck or instrumentation mode mismatch')
        signature=(value['wire_bytes'],value['wire_fnv1a64'],value['checksum'])
        if fixtures.setdefault(entry['case'],signature)!=signature:raise ValueError('Fixture fingerprint/checksum changed')
        row['result']=value
        del row['stdout']
        return row
    started=time.monotonic()
    try:
        with (out/'raw.jsonl').open('w') as raw:
            for index,entry in enumerate(plan):
                row=capture(entry,'shipping',index,CASES[entry['case']],args.samples)
                rows.append(row);raw.write(json.dumps(row)+'\n');raw.flush()
                if (index+1)%16==0:print(f'{index+1}/{len(plan)} shipping processes passed',flush=True)
        allocation_plan=[dict(case=case,operation=op,source=source,backend=backend)
                         for case,op,source,backend in itertools.product(CASES,OPS,('before','after'),('pbrs','prost'))]
        rng.shuffle(allocation_plan)
        with (out/'allocations.jsonl').open('w') as raw:
            for index,entry in enumerate(allocation_plan):
                row=capture(entry,'allocations',index,1000,1)
                allocation_rows.append(row);raw.write(json.dumps(row)+'\n');raw.flush()
        summaries=[]
        for case,op in itertools.product(CASES,OPS):
            values={}
            for row in rows:
                if row['case']==case and row['operation']==op:
                    values[row['pair'],row['source'],row['backend']]=statistics.mean(s['cpu_ns']/s['iterations'] for s in row['result']['samples'])
            cpu={source:{backend:[values[p,source,backend] for p in range(args.pairs)] for backend in ('pbrs','prost')} for source in ('before','after')}
            comparison={
                'after_over_before_pbrs':interval([values[p,'after','pbrs']/values[p,'before','pbrs'] for p in range(args.pairs)],args.seed),
                'after_pbrs_over_prost':interval([values[p,'after','pbrs']/values[p,'after','prost'] for p in range(args.pairs)],args.seed),
                'before_pbrs_over_prost':interval([values[p,'before','pbrs']/values[p,'before','prost'] for p in range(args.pairs)],args.seed),
                'after_over_before_prost_control':interval([values[p,'after','prost']/values[p,'before','prost'] for p in range(args.pairs)],args.seed)}
            allocations={}
            for source,backend in itertools.product(('before','after'),('pbrs','prost')):
                item=next(row for row in allocation_rows if (row['case'],row['operation'],row['source'],row['backend'])==(case,op,source,backend))
                sample=item['result']['samples'][0]
                allocations[f'{source}-{backend}']={name:sample[name]/sample['iterations'] for name in ('allocation_calls','requested_bytes')}
            summaries.append(dict(case=case,operation=op,fixture=dict(zip(('wire_bytes','wire_fnv1a64','checksum'),fixtures[case])),
                                  cpu_ns_process_means=cpu,cpu_ns_medians={s:{b:statistics.median(cpu[s][b]) for b in cpu[s]} for s in cpu},
                                  ratios=comparison,allocations=allocations))
        (out/'summary.json').write_text(json.dumps(summaries,indent=2)+'\n')
        for key,path in binaries.items():
            if sha(path)!=hashes['-'.join(key)]:raise ValueError('Frozen binary changed during campaign')
        manifest.update(state='complete',passed=True,shipping_processes=len(rows),allocation_processes=len(allocation_rows),
                        cpu_samples=sum(len(row['result']['samples']) for row in rows),elapsed_seconds=time.monotonic()-started)
    except Exception as error:
        manifest.update(state='failed',passed=False,error=str(error))
        raise
    finally:
        manifest['cgroup_after']=read_optional('/sys/fs/cgroup/cpu.stat');save()
    print(json.dumps({key:manifest[key] for key in ('state','shipping_processes','allocation_processes','cpu_samples','elapsed_seconds')}),flush=True)

if __name__=='__main__':main()
