"""One final iterator implementation; unchanged broad harness, matched map bounds precheck."""
from pathlib import Path
import json,subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
commands=[]
def add(source,manifest,binary,mode,output,owned=False):
 cmd=['python3',str(BASE/'build_probe.py'),'--source',str(BASE/source),'--manifest',str(BASE/manifest),'--binary-name',binary,'--mode',mode,'--output',str(BASE/output),'--record-key','codec-'+mode]
 if owned:cmd+=['--owned']
 commands.append(cmd)
for profile in ('lazy','owned'):
 for mode in ('shipping','allocations'):
  add('map-v2-source','map-v2-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof',mode,'candidate-v2-'+profile,profile=='owned')
for side,source in [('before','baseline-source'),('after','map-v2-source')]:
 for mode in ('shipping','allocations'):
  add(source,f'map-v2-{side}/Cargo.toml','pbrs-map-iteration-proof',mode,'map-v2-'+('baseline' if side=='before' else 'candidate'))
for i,cmd in enumerate(commands):
 print(json.dumps(dict(index=i,command=cmd)),flush=True)
 r=subprocess.run(cmd,cwd=ROOT)
 if r.returncode:raise SystemExit(r.returncode)
print('all_v2_builds_complete',flush=True)
