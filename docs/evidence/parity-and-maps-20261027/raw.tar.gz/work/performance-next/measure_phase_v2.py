"""Run one bounded CPU-quiet phase. Root must grant quiet first."""
from pathlib import Path
import argparse,json,os,subprocess
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('phase',choices=['lazy','owned','map-small','map-large']);a=p.parse_args()
if a.phase in ('lazy','owned'):
 before=BASE/f'baseline-{a.phase}';after=BASE/f'candidate-v2-{a.phase}';driver=BASE/'codec_compare.py';profile=a.phase
else:
 before=BASE/'map-v2-baseline';after=BASE/'map-v2-candidate';driver=BASE/'map_compare.py';profile='lazy'
cmd=['python3',str(driver),'--before-shipping',str(before/'codec-shipping'),'--before-allocations',str(before/'codec-allocations'),'--before-record',str(before/'source.json'),'--after-shipping',str(after/'codec-shipping'),'--after-allocations',str(after/'codec-allocations'),'--after-record',str(after/'source.json'),'--storage',profile,'--output',str(BASE/('v2-'+a.phase+'-comparison'))]
env=dict(os.environ)
if a.phase.startswith('map-'):env['MAP_GROUP']=a.phase.removeprefix('map-')
print(json.dumps(dict(phase=a.phase,command=cmd,MAP_GROUP=env.get('MAP_GROUP'))),flush=True)
r=subprocess.run(cmd,env=env)
raise SystemExit(r.returncode)
