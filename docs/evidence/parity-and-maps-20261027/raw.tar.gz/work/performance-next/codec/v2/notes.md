# Final map follow-up: keep iteration lazy and make hints cheap

The original candidate's exact typed `size_hint` counted duplicate keys before
`collect`, and `next` then performed the same duplicate scan. Measured collect
losses are retained in the original candidate campaign. The original public
iterator implemented `Iterator`, not `ExactSizeIterator`, and its docs did not
promise an exact hint. The final typed path therefore supplies constant-time
conservative bounds: zero through the remaining wire-entry count. These are
valid even when later duplicate keys are filtered. Exhausted typed iterators
still report `(0, Some(0))`; the raw projected snapshot retains exact hints.

This avoids an extra duplicate scan, at the cost of ordinary output-Vec growth
when collecting rather than reserving the exact final count. It changes an
incidental optimization hint, not yielded values or order. Tests now assert
the standard hint bounds against an independent last-wins oracle, including
every exhaustion state, rather than requiring exact intermediate hints.

The small typed constructor and next paths are marked inline. The raw arena
projection loop is outlined with `inline(never)`, without assuming the raw path
is cold. An empty typed map can then compile to an empty iterator rather than
calling a constructor containing an allocation loop. No mask, cached count,
new representation, runtime atomic or unsafe operation was added.

Seven focused tests and the existing map tests cover semantics and allocation
behavior. Compile assertions preserve Send+Sync for scalar, ProtoString and
LazyStr iterators. Generated native-message projections borrow their original
Sync backing; raw-kernel views already contain non-Send raw pointers. Exotic
handwritten types implementing the documented non-application `__internal`
traits could have stricter auto-trait requirements because typed iterators now
borrow K/V storage rather than retaining projected views alone. No unsafe
blanket auto-trait implementation was added.

The V1 test fixture is retained as ../v1-map-views.rs with its original hash.
The benchmark owner rebuilds the same updated correctness precheck for both
baseline and final candidate; timed loops stay unchanged. Final CPU results
must be assessed separately and all original losses remain available.
