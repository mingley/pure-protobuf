# Typed map views without temporary projection storage

The mixed RPC checksum reads every `headers` pair through `MapView::iter`.
Before this change, `MapViewIter::from_view` visited every typed entry and
allocated a second `Vec<Option<(View<K>, View<V>)>>` even though the map
already owns stable borrowed entries. The new typed path streams through the
existing duplicate-aware `MapIter`. It projects keys and values only when
`next` yields them. Its exact `size_hint` counts remaining unique positions
only when queried, rather than adding a count scan to iterator construction.
The raw arena path keeps its existing projected-view snapshot and lifetime
handling. No new production unsafe code or representation change to maps.

A related lookup cost was also removed: `MapView::get` used to convert a
query into an owned key whenever an index *slot* existed, including small
maps that do not actually build an index. It now uses borrowed `eq_key` for
those scans, and converts only when an actual large-map index is used.
Large indexed queries still use the existing owned conversion.

The six integration tests in `tests/map_views.rs` check zero temporary
allocations in typed iteration (including warm indexed maps) and small-map
borrowed-key lookup, threshold transitions and invalidation, duplicates,
wire-order last-wins iteration, exact hints, exhaustion, non-UTF8 legacy keys,
and views surviving iterator drop while borrowing the same backing bytes.
All nine existing map unit tests, including raw arena reclamation and index
mutation tests, pass. Strict Clippy on the integration target passes.

The tests count per-thread allocation calls, not RSS or process speed.
`perf_next` owns the separate frozen before/after CPU and allocation builds.
Do not infer a performance ranking from these deterministic tests.
