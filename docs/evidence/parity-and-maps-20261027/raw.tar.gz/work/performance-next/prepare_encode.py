"""Prepare the same encode holdout against an immutable source snapshot."""
import argparse,json,hashlib,shutil
from pathlib import Path
BASE=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);args=p.parse_args()
out=args.output.resolve();out.mkdir(parents=True,exist_ok=False);source=args.source.resolve()
shutil.copytree(BASE/'encode-holdout',out,dirs_exist_ok=True)
(out/'Cargo.toml').write_text((out/'Cargo.toml').read_text().replace('FROZEN_CORE',str(source)))
shutil.copy2(BASE/'partial-getter.proto',out/'partial-getter.proto')
lock=(BASE/'partial-before/Cargo.lock').read_text();assert lock.count('name = "pbrs-partial-getter-proof"')==1
(out/'Cargo.lock').write_text(lock.replace('name = "pbrs-partial-getter-proof"','name = "pbrs-encode-proof"'))
(out.parent/(out.name+'-prepared.json')).write_text(json.dumps(dict(source=str(source),files={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()}),indent=2)+'\n')
