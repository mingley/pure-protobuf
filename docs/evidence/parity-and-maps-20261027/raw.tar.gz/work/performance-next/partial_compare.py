"""Run partial-getter holdouts with the same paired collection machinery."""
import codec_compare
codec_compare.CASES={"nested_8":100_000,"nested_64":20_000}
codec_compare.OPS=("read_first_child",)
codec_compare.FIXTURE_SCOPE="Parse then access only root.n and first child.n, drop result; full fixture correctness checked outside timing"
codec_compare.main()
