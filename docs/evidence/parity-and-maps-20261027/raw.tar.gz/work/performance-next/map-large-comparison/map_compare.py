"""Typed warm integer map iteration, including first-entry and collect holdouts."""
import codec_compare,os
group=os.environ.get("MAP_GROUP","all")
sizes={"small":(1,4,8,15),"large":(16,64,256),"all":(1,4,8,15,16,64,256)}[group]
codec_compare.CASES={f'map_{n}_{mode}':max(2500,500_000//n) for n in sizes for mode in ('distinct','duplicate')}
codec_compare.OPS=('iter_all','iter_first','iter_collect')
codec_compare.SCHEMA='pbrs.typed-map-iteration-comparison.v1'
codec_compare.FIXTURE_SCOPE='Warm typed i32/i32 maps; raw entries constructed before timing; hashed bytes are entry-list bytes, not protobuf wire; duplicate keys use last value; raw arena path is outside scope'
codec_compare.CPU_SCOPE='CLOCK_PROCESS_CPUTIME_ID; warm map iteration, first entry, or collect/drop output; input construction, parsing, index warming outside timing; counters absent'
codec_compare.LIMITS=[
 'Shared x86_64 VM; no dedicated-host qualification.',
 'prost-labelled control is std::collections::HashMap, Prost default map-field representation, not Prost decode or codec throughput.',
 'First-entry returned order need not agree across representations; full values, last-wins and iterator hints checked before timing.',
 'Some fast post-change and HashMap samples are shorter than1ms; retain all timings and do not use small margins as ranking evidence.',
 'Warm last-wins index; this probe excludes first-use index build. Full codec matrix includes parse-and-read lifecycle.',
 'Separate allocator requests are not RSS or retained memory.',
]
codec_compare.main()
