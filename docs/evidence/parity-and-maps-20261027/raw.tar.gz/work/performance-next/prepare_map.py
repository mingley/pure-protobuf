"""Prepare identical typed-map probes against a frozen core."""
from pathlib import Path
import argparse,hashlib,json,re,shutil
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
p=argparse.ArgumentParser();p.add_argument('--source',type=Path,required=True);p.add_argument('--output',type=Path,required=True);a=p.parse_args()
source=a.source.resolve();out=a.output.resolve();shutil.copytree(BASE/'map-template',out)
(out/'Cargo.toml').write_text((out/'Cargo.toml').read_text().replace('FROZEN_CORE',str(source)))
base_lock=BASE/'map-before/Cargo.lock'
lock=(base_lock if base_lock.exists() and base_lock.resolve()!=(out/'Cargo.lock').resolve() else ROOT/'tests/proof/codec_benchmark/Cargo.lock').read_text()
lock=lock.replace('name = "pbrs-codec-proof"\nversion = "0.0.0"\ndependencies = [\n "libc",\n "pbrs",\n "prost",\n "prost-build",\n "serde_json",\n]', 'name = "pbrs-map-iteration-proof"\nversion = "0.0.0"\ndependencies = [\n "libc",\n "pbrs",\n "serde_json",\n]')
(out/'Cargo.lock').write_text(lock)
files={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()}
(out.parent/(out.name+'-prepared.json')).write_text(json.dumps(dict(source=str(source),files=files),indent=2)+'\n')
