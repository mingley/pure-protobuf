"""Recover a successful RPC Cargo artifact rejected by overly strict feature validation.

No executable is rebuilt or re-labelled as a failed build: original wrapper
failure is retained, while successful Cargo/source/harness evidence is checked.
"""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,shutil,tomllib
BASE=Path(__file__).resolve().parent
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
old=BASE/'rpc-baseline-default-validation-failure';current=BASE/'rpc-baseline'
if not old.exists():current.rename(old)
record=json.loads((old/'rpc-shipping-build.json').read_text())
assert record['exit_code']==0 and record['source_unchanged'] and record['harness_unchanged']
messages=[json.loads(line) for line in (old/'rpc-shipping.jsonl').read_text().splitlines()]
a=[m for m in messages if m.get('reason')=='compiler-artifact' and m.get('target',{}).get('name')=='rpc-bench' and m.get('executable')]
assert len(a)==1 and set(a[0]['features'])=={'default'}
assert tomllib.loads(Path(record['manifest']).read_text())['features']['default']==[]
source=Path(record['source'])
assert all(sha(source/name)==value for name,value in record['source_files'].items())
current.mkdir()
for suffix in ['.jsonl','.stderr']:shutil.copy2(old/('rpc-shipping'+suffix),current/('rpc-shipping'+suffix))
binary=current/'rpc-shipping';shutil.copy2(a[0]['executable'],binary)
record.update(binary_sha256=sha(binary),binary=str(binary),build_executable=a[0]['executable'],features=a[0]['features'],message_storage='lazy',validation_recovery=dict(at=datetime.now(timezone.utc).isoformat(),reason='Initial wrapper feature validator disallowed the legitimate default=[] Cargo feature marker; Cargo itself succeeded. Expected marker and originalsource/harness checks independently verified.',original_failure=str(old.relative_to(BASE))))
(current/'rpc-shipping-build.json').write_text(json.dumps(record,indent=2)+'\n')
(current/'source.json').write_text(json.dumps(dict(schema='pbrs.frozen-probe-binaries.v1',source=str(source),binaries={'rpc-shipping':dict(path=str(binary),sha256=sha(binary),build_record='rpc-shipping-build.json')}),indent=2)+'\n')
print(json.dumps(dict(recovered=True,sha256=sha(binary),features=a[0]['features'])))
