//! Typed map iteration diagnostic; not codec parsing or a ranking.
use std::collections::{BTreeMap, HashMap};
use std::hint::black_box;
#[cfg(feature = "allocations")]
mod count {
    use std::alloc::{GlobalAlloc, Layout, System};
    use std::sync::atomic::{AtomicBool, AtomicU64, Ordering};
    pub static ENABLED: AtomicBool = AtomicBool::new(false);
    pub static CALLS: AtomicU64 = AtomicU64::new(0);
    pub static BYTES: AtomicU64 = AtomicU64::new(0);
    pub struct Alloc;
    unsafe impl GlobalAlloc for Alloc {
        unsafe fn alloc(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn alloc_zeroed(&self, layout: Layout) -> *mut u8 {
            let ptr = unsafe { System.alloc_zeroed(layout) };
            if !ptr.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(layout.size() as u64, Ordering::Relaxed);
            }
            ptr
        }
        unsafe fn realloc(&self, ptr: *mut u8, old: Layout, new: usize) -> *mut u8 {
            let result = unsafe { System.realloc(ptr, old, new) };
            if !result.is_null() && ENABLED.load(Ordering::Relaxed) {
                CALLS.fetch_add(1, Ordering::Relaxed);
                BYTES.fetch_add(new as u64, Ordering::Relaxed);
            }
            result
        }
        unsafe fn dealloc(&self, ptr: *mut u8, layout: Layout) {
            unsafe { System.dealloc(ptr, layout) }
        }
    }
    pub fn start() {
        CALLS.store(0, Ordering::SeqCst);
        BYTES.store(0, Ordering::SeqCst);
        ENABLED.store(true, Ordering::SeqCst);
    }
    pub fn stop() -> (u64, u64) {
        ENABLED.store(false, Ordering::SeqCst);
        (CALLS.load(Ordering::SeqCst), BYTES.load(Ordering::SeqCst))
    }
}
#[cfg(feature = "allocations")]
#[global_allocator]
static ALLOC: count::Alloc = count::Alloc;

fn cpu_ns() -> u128 {
    let mut ts = libc::timespec {
        tv_sec: 0,
        tv_nsec: 0,
    };
    // SAFETY: ts is a valid timespec out pointer and PROCESS_CPUTIME_ID is read-only.
    assert_eq!(
        unsafe { libc::clock_gettime(libc::CLOCK_PROCESS_CPUTIME_ID, &mut ts) },
        0
    );
    ts.tv_sec as u128 * 1_000_000_000 + ts.tv_nsec as u128
}

fn hash(bytes: &[u8]) -> String {
    format!("{:016x}", bytes.iter().fold(0xcbf29ce484222325u64, |h,b| (h ^ u64::from(*b)).wrapping_mul(0x100000001b3)))
}
fn main() {
    let args: Vec<String> = std::env::args().collect();
    assert_eq!(args.len(), 6, "CASE BACKEND OP ITERATIONS SAMPLES");
    let case=&args[1]; let backend=&args[2]; let op=&args[3];
    let iterations: u64=args[4].parse().unwrap(); let samples: usize=args[5].parse().unwrap();
    assert!(iterations>0 && samples>0);
    assert!(backend=="pbrs" || backend=="prost");
    assert!(matches!(op.as_str(), "iter_all"|"iter_first"|"iter_collect"));
    let parts: Vec<_>=case.split('_').collect();
    assert_eq!(parts.len(), 3); assert_eq!(parts[0],"map");
    let n:usize=parts[1].parse().unwrap(); let duplicate=parts[2]=="duplicate";
    assert!(duplicate || parts[2]=="distinct");
    let mut typed=pbrs::Map::<i32,i32>::new();
    let mut reference=HashMap::<i32,i32>::new();
    let mut normalized=BTreeMap::<i32,i32>::new();
    let mut input=Vec::new();
    let unique=if duplicate {(n+3)/4} else {n};
    for i in 0..n {
        let k=if duplicate {i%unique} else {(i*17)%n} as i32;
        let v=(i as i32)*7+3;
        typed.push_entry(k,v); reference.insert(k,v); normalized.insert(k,v);
        input.extend_from_slice(&k.to_le_bytes()); input.extend_from_slice(&v.to_le_bytes());
    }
    // Full value equality, last-wins and truthful iterator bounds outside timing.
    let actual: BTreeMap<_,_>=typed.as_view().iter().collect(); assert_eq!(actual,normalized);
    assert_eq!(reference.iter().map(|(k,v)|(*k,*v)).collect::<BTreeMap<_,_>>(),normalized);
    let mut check=typed.as_view().iter();
    for left in (1..=normalized.len()).rev() {let (lo,hi)=check.size_hint(); assert!(lo<=left && hi.is_none_or(|upper|upper>=left)); assert!(check.next().is_some());}
    assert_eq!(check.size_hint(),(0,Some(0))); assert!(check.next().is_none());
    let checksum: u64=normalized.iter().map(|(k,v)|(*k as u64).wrapping_add(*v as u64)).sum();
    let execute=|| {
        if backend=="pbrs" {
            let view=black_box(&typed).as_view();
            match op.as_str() {
                "iter_all"=>{let s=view.iter().fold(0u64,|s,(k,v)|s.wrapping_add(k as u64).wrapping_add(v as u64)); black_box(s);}
                "iter_first"=>{black_box(view.iter().next());}
                "iter_collect"=>{black_box(view.iter().collect::<Vec<_>>());}
                _=>unreachable!(),
            }
        } else {
            let map=black_box(&reference);
            match op.as_str() {
                "iter_all"=>{let s=map.iter().fold(0u64,|s,(k,v)|s.wrapping_add(*k as u64).wrapping_add(*v as u64)); black_box(s);}
                "iter_first"=>{black_box(map.iter().next());}
                "iter_collect"=>{black_box(map.iter().map(|(k,v)|(*k,*v)).collect::<Vec<_>>());}
                _=>unreachable!(),
            }
        }
    };
    // Warm lazy index for the iteration-only scope. Index construction and all
    // input storage are outside timing for both peers; raw arena maps are not used.
    for _ in 0..100 {execute();}
    let mut results=Vec::new();
    for _ in 0..samples {
        #[cfg(feature="allocations")] count::start();
        let start=cpu_ns(); let wall=std::time::Instant::now();
        for _ in 0..iterations {execute();}
        let wall_ns=wall.elapsed().as_nanos(); let elapsed=cpu_ns()-start;
        #[cfg(feature="allocations")] let (allocation_calls,requested_bytes)=count::stop();
        #[cfg(not(feature="allocations"))] let (allocation_calls,requested_bytes)=(None::<u64>,None::<u64>);
        results.push(serde_json::json!({"iterations":iterations,"cpu_ns":elapsed,"wall_ns":wall_ns,"allocation_calls":allocation_calls,"requested_bytes":requested_bytes}));
    }
    println!("{}",serde_json::json!({"schema":"map-iteration-proof/1","case":case,"backend":backend,"operation":op,
        "input":"Typed integer map; warmed index; construction outside timing; bytes describe raw entries, not protobuf wire",
        "control":"std::collections::HashMap: Prost default map-field representation, not Prost decode",
        "wire_bytes":input.len(),"wire_fnv1a64":hash(&input),"checksum":checksum,
        "raw_entries":n,"unique_entries":normalized.len(),"semantic_prechecks":true,"message_storage":"lazy",
        "allocation_instrumentation":cfg!(feature="allocations"),"samples":results}));
}
