"""Build a single runtime candidate and the typed-map holdout."""
from pathlib import Path
import json, subprocess
BASE=Path(__file__).resolve().parent;ROOT=BASE.parents[1]
commands=[]
def add(source,manifest,binary,mode,output,owned=False):
 cmd=['python3',str(BASE/'build_probe.py'),'--source',str(BASE/source),'--manifest',str(BASE/manifest),'--binary-name',binary,'--mode',mode,'--output',str(BASE/output),'--record-key','codec-'+mode]
 if owned:cmd+=['--owned']
 commands.append(cmd)
add('baseline-source','map-before/Cargo.toml','pbrs-map-iteration-proof','allocations','map-baseline')
for profile in ('lazy','owned'):
 for mode in ('shipping','allocations'):
  add('map-candidate-source','map-candidate-source/tests/proof/codec_benchmark/Cargo.toml','pbrs-codec-proof',mode,'candidate-'+profile,profile=='owned')
for mode in ('shipping','allocations'):
 add('map-candidate-source','map-after/Cargo.toml','pbrs-map-iteration-proof',mode,'map-candidate')
for i,cmd in enumerate(commands):
 print(json.dumps(dict(index=i,command=cmd)),flush=True)
 r=subprocess.run(cmd,cwd=ROOT)
 if r.returncode:raise SystemExit(r.returncode)
print('all_candidate_builds_complete',flush=True)
