"""Build baseline public profiles sequentially from one immutable source."""
from pathlib import Path
import json, subprocess
BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[1]
for profile in ('lazy','owned'):
 for mode in ('shipping','allocations'):
  source=BASE/'baseline-source';out=BASE/f'baseline-{profile}'
  cmd=['python3',str(BASE/'build_probe.py'),'--source',str(source),'--manifest',str(source/'tests/proof/codec_benchmark/Cargo.toml'),'--binary-name','pbrs-codec-proof','--mode',mode,'--output',str(out),'--record-key','codec-'+mode]
  if profile=='owned':cmd+=['--owned']
  print(json.dumps(dict(profile=profile,mode=mode,command=cmd)),flush=True)
  result=subprocess.run(cmd,cwd=ROOT)
  if result.returncode:raise SystemExit(result.returncode)
print('baseline_profiles_complete',flush=True)
