"""Run four explicit encode holdouts with the paired frozen-probe controller."""
import codec_compare
codec_compare.CASES={"nested_8":20_000,"nested_64":20_000}
codec_compare.OPS=("parse_fresh_encode","fresh_encode","cached_encode","mutate_encode")
codec_compare.FIXTURE_SCOPE="Node8/64: parse+firstencode lifecycle; bounded-batch firstencode excludingparse; warmed unchangedcachedencode; warmed firstchildmutation+encode. Outputallocation/drop included; see eachrawresultfor scopes"
codec_compare.main()
