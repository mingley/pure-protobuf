"""Build identical partial-getter probe source against a selected frozen core."""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

BASE=Path(__file__).resolve().parent
ROOT=BASE.parents[2]
def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--source',required=True,type=Path);p.add_argument('--output',required=True,type=Path)
 args=p.parse_args();out=args.output.resolve();out.mkdir(parents=True,exist_ok=False)
 source=args.source.resolve()
 template=BASE/'partial-getter'
 shutil.copytree(template,out,dirs_exist_ok=True)
 cargo=(template/'Cargo.toml').read_text().replace('FROZEN_CORE',str(source))
 (out/'Cargo.toml').write_text(cargo)
 shutil.copy2(BASE/'partial-getter.proto',out/'partial-getter.proto')
 lock=BASE/'partial-before/Cargo.lock'
 if not lock.exists() or lock.resolve()==(out/'Cargo.lock').resolve():lock=ROOT/'tests/proof/codec_benchmark/Cargo.lock'
 shutil.copy2(lock,out/'Cargo.lock')
 files={str(f.relative_to(out)):hashlib.sha256(f.read_bytes()).hexdigest() for f in out.rglob('*') if f.is_file()}
 (out.parent/(out.name+'-prepared.json')).write_text(json.dumps(dict(source=str(source),files=files),indent=2)+'\n')
if __name__=='__main__':main()
