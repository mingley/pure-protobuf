"""Package the complete map/transport campaign and final-source validation."""
import hashlib, io, json, shutil, subprocess, tarfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'docs/evidence/parity-and-maps-20261027'
OUT.mkdir(exist_ok=True)
def read(path):
    return json.loads((ROOT / path).read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=ROOT)
def sha(data):
    return hashlib.sha256(data).hexdigest()

validation = read('work/parity-next/validation/results.json')
owned = read('work/parity-next/owned-conformance/results.json')
selection = read('work/performance-next/results.json')
assert validation['complete'] and validation['inputs_unchanged']
assert owned['complete'] and owned['all_passed']
assert selection['complete'] and selection['selected_variant'] == 'v2'
files = {}
extensions = {'.json', '.jsonl', '.log', '.rs', '.py', '.md', '.toml', '.lock',
              '.patch', '.diff', '.stderr', '.stdout', '.proto', '.txt', '.sh', '.yml', '.yaml'}
skip = {'target', '.git', '__pycache__', 'artifacts', 'generated'}
groups = ['parity-next', 'performance-next', 'codegen-options',
          'transport-policy-round', 'executor-parity']
for group in groups:
    base = ROOT / 'work' / group
    for path in sorted(base.rglob('*')):
        rel = path.relative_to(base)
        if not path.is_file() or path.is_symlink() or any(p in skip for p in rel.parts):
            continue
        # Exact overlays and complete hash manifests reconstruct these source
        # snapshots without retaining duplicate full checkouts.
        if group == 'performance-next' and rel.parts[0].endswith('-source'):
            continue
        if group == 'parity-next' and rel.parts[:2] == ('owned-conformance', 'source'):
            continue
        if path.suffix not in extensions:
            continue
        data = path.read_bytes()
        if not data.startswith(b'\x7fELF'):
            files[str(path.relative_to(ROOT))] = data

baseline = '77f361eb8f22d957a737b62bd3524d79b05a57e5'
commit = validation['source']
files['source/implementation.patch'] = git('diff', baseline, commit, '--', 'src',
    'pbrs-grpc', 'tests', 'Cargo.toml', 'Cargo.lock', 'build.rs')
files['source/provenance.json'] = (json.dumps(dict(
    baseline=baseline, implementation_commit=commit,
    validated_input_sha256=validation['input_sha256'],
    inputs_unchanged=validation['inputs_unchanged'],
    limits=['Collection-time focused checks preceded the implementation commit; their own file hashes identify that stage.',
            'Final validation binds all non-Markdown production and test inputs to the implementation commit.',
            'Frozen RPC transport source differs by verified formatting; successful Prost cells do not exercise the pbrs map runtime.',
            'Build elapsed times are provenance, not a comparative generator-speed benchmark.']), indent=2)+'\n').encode()
files['source/reproduce.md'] = ('''# Reconstruct the campaign

Start from baseline `'''+baseline+'''` in a disposable checkout. Apply
`source/implementation.patch` for final production and proof source. The
performance variant-file reconstruction record supplies exact overlays and
source chains for the measured map variants and RPC transport candidate.
Follow each frozen source/build manifest and retained helper/lockfile. Do not
include an installed `third_party` SDK in codec snapshot exports: its presence
changes build-script descriptor inputs. The isolated official conformance
driver explicitly records and uses the pinned upstream SDK instead.

The V1 campaign is superseded; its slower collection cases remain in the
archive. The final V2 precheck accepts valid conservative size hints in both
builds; timed loops are unchanged. CPU and allocation builds are separate.
The RPC resume chunks follow one immutable randomized plan and aggregate only
after all 120 captures complete. No cache, compiler installation, executable,
or duplicate full source checkout is included.
''').encode()

matrices = {}
for name in ['lazy-comparison', 'owned-comparison', 'map-small-comparison',
             'map-large-comparison', 'v2-lazy-comparison', 'v2-owned-comparison',
             'v2-map-small-comparison', 'v2-map-large-comparison', 'rpc-comparison']:
    matrices[name] = read('work/performance-next/'+name+'/summary.json')
result = dict(schema='pbrs.parity-and-maps.v1', baseline=baseline,
    implementation_commit=commit, qualified=False, full_tonic_prost_parity=False,
    world_performance_ranking_established=False, selected=selection,
    matrices=matrices, validation=validation, owned_conformance=owned,
    transport_controls=read('work/transport-policy-round/results.json'),
    executors=read('work/executor-parity/results.json'),
    codegen_options=read('work/codegen-options/results.json'),
    source_review=read('work/parity-next/review.json'),
    rpc_source_equivalence=read('work/performance-next/rpc-final-source-equivalence.json'))
(OUT/'results.json').write_text(json.dumps(result, indent=2)+'\n')
with tarfile.open(OUT/'raw.tar.gz', 'w:gz', compresslevel=6) as archive:
    for name, data in sorted(files.items()):
        info = tarfile.TarInfo(name)
        info.size=len(data); info.mode=0o644; info.mtime=0
        archive.addfile(info, io.BytesIO(data))
manifest = dict(schema='pbrs.evidence-manifest.v1',
    archive_sha256=sha((OUT/'raw.tar.gz').read_bytes()),
    results_sha256=sha((OUT/'results.json').read_bytes()),
    files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())})
(OUT/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
shutil.copyfile(ROOT/'docs/evidence/efficiency-20261027/check.py', OUT/'check.py')
print(json.dumps(dict(files=len(files),logical_bytes=sum(map(len,files.values())),
    archive_bytes=(OUT/'raw.tar.gz').stat().st_size,
    workspace=validation['workspace_test_counts'])))
