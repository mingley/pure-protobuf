# Owned-profile official conformance

The exact committed source `12cfd09f318b2bcc4d49ca1e2df0e54b56a190ab` was archived, then its 13 bundled generated schemas were regenerated with `shared_pool=true,owned_message_fields=true`. The isolated registry file stayed byte-identical. No checkout production or test files were modified.

The pinned official v35.1 runner passed two required runs and an enforced recommended run with maximum edition 2023. Each run passed 5,631 binary/JSON and 909 text cases, with zero skips, expected failures, or unexpected failures.

`report.json` records commands, timings, Cargo-bound executable hashes, pinned compiler/runner/SDK provenance, all imported proto hashes, and per-generated-file changes. `source-before.json` and `source-after.json` bind the isolated source; `owned-generated.patch` reconstructs its owned-profile changes. The report's dirty-source flag denotes that explicit regeneration, not an unidentified source revision.

For portable evidence, retain this driver, report, logs, Cargo artifact JSON, manifests, generated sources/patch, and passes directory. Omit the rebuildable full source snapshot and ELF artifacts directory. The precise selected Git archive paths and regeneration commands are in the driver and report.
