#!/usr/bin/env python3
"""Publish results only after all official suites and provenance checks pass."""
import hashlib
import json
from pathlib import Path

out = Path(__file__).resolve().parent
report = json.loads((out/'report.json').read_text())
assert report['complete'] is True
assert report['source_commit'] == '12cfd09f318b2bcc4d49ca1e2df0e54b56a190ab'
assert report['maximum_edition'] == '2023'
summary = report['conformance_summary']
assert summary['overall_passed'] is True and summary['overall_status'] == 'passed'
assert not summary['validation_errors']
steps = {row['name']: row for row in report['steps']}
for name in ['required_1','required_2','recommended','validate-report']:
    assert steps[name]['exit_code'] == 0
for name in ['required_run_1','required_run_2','recommended']:
    suite = summary['runs'][name]
    assert suite['status']=='passed'
    assert suite['successes']==5631 and suite['text_successes']==909
    assert all(suite[key]==0 for key in ['skipped','text_skipped','expected_failures',
               'text_expected_failures','unexpected_failures','text_unexpected_failures'])
assert len(report['generated_bindings'])==13
before=json.loads((out/'source-before.json').read_text())
after=json.loads((out/'source-after.json').read_text())
assert before.keys()==after.keys()
changed={name for name in before if before[name]!=after[name]}
assert changed=={row['path'] for row in report['generated_bindings'] if row['changed']}
registry=report['registry_preserved']
assert before[registry['path']]['sha256']==after[registry['path']]['sha256']==registry['sha256']
assert before['src/map.rs']['sha256']=='c60f9db6c3c67775dd539bffd634779bfd7ca19a0499ba684f8a000e9374a6d1'
assert all(row['exit_code']==0 for row in report['steps'])
for name, entry in after.items():
    assert hashlib.sha256((out/'source'/name).read_bytes()).hexdigest()==entry['sha256'], name
result = dict(report)
result['all_passed'] = True
result['source_changes_validated'] = True
result['changed_paths'] = sorted(changed)
result['profile_regeneration_only'] = True
result['counts'] = summary['test_counts']
result['report_sha256'] = hashlib.sha256((out/'report.json').read_bytes()).hexdigest()
result['evidence_sha256'] = {
    str(path.relative_to(out)): hashlib.sha256(path.read_bytes()).hexdigest()
    for path in sorted(out.rglob('*'))
    if path.is_file() and not path.is_symlink()
    and path.relative_to(out).parts[0] not in ['source','artifacts','generated']
    and path.name!='results.json'
}
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'complete':True,'all_passed':True,'counts':result['counts']}))
