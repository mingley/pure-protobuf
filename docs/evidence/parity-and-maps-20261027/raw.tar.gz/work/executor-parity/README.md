# Custom connection-driver executors

The prior runtime abstraction is private and static. It does not let application
code inject an executor. This change adds public scheduling of background
HTTP/2 connection drivers while leaving `ChannelConfig` and `ServerConfig`
`Copy + Eq`.

APIs:

- `Executor::execute(ExecutorFuture)` schedules an owned Send unit future.
- `tokio::runtime::Handle` and `Arc<E: Executor>` implement `Executor`.
- `Endpoint::executor(E)` covers eager/lazy connects, direct reconnections and
  custom connectors.
- `Channel::from_io_with_executor(io, target, config, E)` accepts connected IO.
- `Server::executor(E)` and `Router::executor(E)` schedule accepted connections.
  Generated service builders forward `.executor(E)` to `Server<Self>`.

Server handler futures run inline inside the selected connection driver.
Tokio IO, timers and helper tasks for retry/upload/resolution/keepalive retain
existing runtime requirements. Explicit `serve_connection` stays caller-polled.
Custom server executors override per-core connection placement; accept loops
remain on their configured shards. Static balance helpers reject per-endpoint
executors rather than silently dropping them. This does not establish complete
Tonic API equivalence or support for an arbitrary non-Tokio runtime.

When no executor is configured, the same concrete future goes straight to
`tokio::spawn`; boxing and executor-owner cloning occur only for the custom
path. A scheduled custom future retains the executor until the driver drops,
including when a response stream outlives the last Channel. Field drop order
releases transport state before scheduler resources. Existing stop, admission,
GOAWAY and drain ownership remains with the connection future.

Custom executors must eventually poll or drop tasks. Retaining unpolled tasks
indefinitely retains their connections; the library cannot force an external
scheduler to make progress. A discarding executor closes the connection, and a
panicking execute call unwinds its future and releases server drain ownership.

Validation:

```sh
cargo test --locked -p pbrs-grpc --test custom_executor
cargo test --locked -p pbrs-grpc --lib executor::tests
cargo clippy --locked -p pbrs-grpc --test custom_executor --lib -- -D warnings
```

All nine integration tests pass. They execute all four RPC shapes while checking
actual task-local placement, eager/lazy idle reconnection, custom connected IO,
custom connectors, clone/router propagation, scheduler drop/panic, dedicated
Tokio-runtime Handle placement and executor ownership past Channel drop.
The unit test discards an unpolled queued task and verifies transport drops
before scheduler resources. The initial test invocation was stopped for the
benchmark CPU quiet window before tests began; its log is retained.

No speed improvement is claimed for this capability. Default RPC regression
measurements belong to the independent combined-runtime campaign.
