include!("../gen/mod.rs");
fn main() {
    let mut b = wktsharing::OptB::new();
    b.set_id(31);
    let wire = pbrs::Serialize::serialize(&b).unwrap();
    let decoded = <wktsharing::OptB as pbrs::Parse>::parse(&wire).unwrap();
    assert_eq!(decoded.id(), 31);
    let mut c = wktsharing::OptC::new();
    c.set_id(41);
    assert_eq!(c.id(), 41);
}
