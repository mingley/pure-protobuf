"""Validate the committed proof suite and transport repairs, preserving failures."""
import json
import os
from pathlib import Path
import subprocess
import time

root = Path(__file__).resolve().parents[1]
output = root / 'work/proof-validation'
output.mkdir(exist_ok=False)
def git(*args):
    return subprocess.check_output(['git', *args], cwd=root, text=True).strip()
if git('status', '--porcelain', '--untracked-files=all'):
    raise SystemExit('source must be clean')
report = dict(source=git('rev-parse','HEAD'), checks=[], complete=False)
commands = [
 ('format', ['cargo','fmt','--all','--check'], 0),
 ('workspace', ['cargo','test','--locked','--workspace','--all-features'], 0),
 ('core-clippy', ['cargo','clippy','--locked','-p','pbrs','--all-targets','--all-features','--','-D','warnings'], 0),
 ('transport-clippy', ['cargo','clippy','--locked','--lib','--all-features','-p','pbrs-grpc','-p','protobuf-tonic','-p','pbrs-grpc-example-greeter','--','-D','warnings'], 0),
 ('message-presence', ['cargo','test','--locked','--manifest-path','tests/proof/tonic_parity/Cargo.toml','--','--nocapture'], 0),
 ('mixed-peers', ['cargo','test','--locked','--manifest-path','tests/interop/tonic/Cargo.toml','--tests'], 0),
 ('prost-known', ['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml','--','--check-known-differences'], 0),
 ('prost-strict', ['cargo','run','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml'], 1),
 ('prost-tests', ['cargo','test','--locked','--manifest-path','tests/proof/prost_parity/Cargo.toml'], 0),
 ('codegen-proof', ['python3','tests/proof/codegen_parity/run.py','--output',str(output/'codegen')], 0),
 ('claim-checker', ['python3','-B','-m','unittest','tests.test_performance_claim','-q'], 0),
 ('msrv-native', ['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--lib'], 0),
 ('msrv-tower', ['cargo','+1.85.0','check','--locked','-p','pbrs-grpc','--features','tower','--lib'], 0),
 ('conformance', ['./scripts/conformance.sh'], 0),
]
for name, command, expected in commands:
    env = dict(os.environ)
    if name.startswith('msrv-'):
        env.update(CARGO_TARGET_DIR=str(root/'work/msrv-target'), CARGO_BUILD_JOBS='1')
    if name == 'conformance':
        env.update(CONFORMANCE_OUTPUT_DIR=str(output/'conformance'), NPROC='2')
    start = time.monotonic()
    with (output/(name+'.log')).open('w') as log:
        result = subprocess.run(command, cwd=root, env=env, stdout=log, stderr=subprocess.STDOUT)
    row = dict(name=name, command=command, exit_code=result.returncode, expected_exit=expected,
               seconds=time.monotonic()-start, log=name+'.log')
    report['checks'].append(row)
    (output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(row),flush=True)
    if result.returncode != expected:
        print((output/(name+'.log')).read_text()[-10000:], flush=True)
        raise SystemExit(1)
    if name == 'prost-strict':
        lines=(output/(name+'.log')).read_text().splitlines()
        summary=json.loads(next(line for line in reversed(lines) if line.startswith('{')))
        assert summary['known_differences_match'] is True and summary['parity_equivalent'] is False
if git('status','--porcelain','--untracked-files=all') or git('rev-parse','HEAD') != report['source']:
    raise SystemExit('source changed during validation')
report.update(complete=True, clean_after=True)
(output/'results.json').write_text(json.dumps(report,indent=2)+'\n')
