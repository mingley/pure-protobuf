# Current codec comparison

Source: `73e954c0610906f0f789ba3276241e3b3863a27b`. The root runtime and generator source hashes match before both builds and after measurement. `source-before.json`, `source-after-build.json`, and `source-after-measurement.json` bind the run; the grpc-only working changes during this session are not dependencies of this probe.

The same `proto/codec_cases.proto` generated pbrs and Prost 0.14.4 bindings. Both parse the same borrowed input into an owned message and drop it inside the measured loop. `parse_owned` can leave pbrs nested/packed materialization deferred; `read_all` visits every populated scalar, nested descendant and string/bytes payload byte. Fixture fingerprints are FNV-1a64, not cryptographic; semantic prechecks compare Prost reference objects, reparse pbrs serialization with Prost, and compare byte-exhaustive touch checksums. These eight valid fixtures do not prove compatibility.

CPU uses a counters-free release binary and `CLOCK_PROCESS_CPUTIME_ID`. Allocations use a separate feature build, warmed first, counting successful Rust alloc/alloc_zeroed/realloc requests. Requested bytes are cumulative requests, not retained memory, peak live bytes or RSS. Both binaries use the same locked dependencies and thin LTO. Their lock resolves serde_json1.0.154 versus the repository root lock1.0.151; that serialization helper is outside the measured loop.

Five seeded randomized process pairs per cell, three samples per process: 160 shipping processes / 480 samples, plus 32 allocation-control processes. No errors or failed semantic prechecks. The random plan was written before execution. All raw rows, stderr streams, commands, source and binary hashes are retained. Timings include parse/read/drop and exclude fixture creation, prechecks and JSON output. Some minimum measured CPU batches were only1.70ms; the very small cases remain diagnostics. The parent held other build/test work for this 20.6second window. Cgroup CPU quota was4cores, the driver pinned CPU0 from5 permitted CPUs; no additional cgroup throttling occurred. Host contention, CPU frequency and independent machine replication are not controlled.

| Case | Work | pbrs CPU ns/op | Prost CPU ns/op | Median paired CPU ratio pbrs/Prost | pbrs allocs/bytes | Prost allocs/bytes |
|---|---|---:|---:|---:|---:|---:|
| empty | parse_owned | 2.95 | 4.13 | 0.718 | 0/0 | 0/0 |
| empty | read_all | 3.27 | 4.45 | 0.745 | 0/0 | 0/0 |
| scalars | parse_owned | 25.10 | 36.26 | 0.716 | 0/0 | 0/0 |
| scalars | read_all | 25.44 | 35.73 | 0.705 | 0/0 | 0/0 |
| blob_4kib | parse_owned | 130.81 | 148.07 | 0.859 | 1/4120 | 2/8192 |
| blob_4kib | read_all | 691.38 | 715.86 | 0.957 | 1/4120 | 2/8192 |
| packed_256 | parse_owned | 72.74 | 715.83 | 0.102 | 2/512 | 7/4064 |
| packed_256 | read_all | 251.91 | 725.65 | 0.342 | 7/4480 | 7/4064 |
| nested_8 | parse_owned | 137.51 | 146.21 | 0.939 | 2/128 | 7/112 |
| nested_8 | read_all | 671.45 | 149.31 | 4.473 | 8/608 | 7/112 |
| nested_64 | parse_owned | 791.45 | 1644.31 | 0.481 | 2/384 | 63/1008 |
| nested_64 | read_all | 28914.35 | 1722.49 | 16.921 | 64/5344 | 63/1008 |
| rpc_sparse | parse_owned | 8.91 | 40.54 | 0.219 | 0/0 | 0/0 |
| rpc_sparse | read_all | 14.02 | 41.26 | 0.346 | 0/0 | 0/0 |
| rpc_mixed | parse_owned | 612.17 | 825.86 | 0.750 | 8/1696 | 23/976 |
| rpc_mixed | read_all | 861.90 | 884.73 | 0.972 | 11/1920 | 23/976 |

Ratios above one are losses. The ratio is the median of matched process-pair CPU ratios; dividing the separately reported median CPU values can differ. Every pair and the diagnostic percentile bootstrap interval appear in `campaign/summary.json`. Five pairs on one shared x86_64 host cannot establish a ranking.

The strongest current counterexample is full traversal of a64level singular child chain: pbrs29us/op versus Prost1.72us/op, with all five paired CPU ratios between14.7 and18.6. At8levels the corresponding ratio is4.47. Parse-only results go the other way, so a parse-only speed claim would hide deferred work.

Inspection suggests repeated descendant validation: generated parse.rs stores a LazyMsg after validating its whole subtree; lazy.rs materializes a child through merge_inner, which again validates the remaining descendants. Repeating this along a chain appears quadratic. This is source attribution, not a profiling result or a shipped fix. Any future repair must preserve recursion, malformed-input, required-field and merge checks.

No runtime change was made by this workstream. Reproduce with the standalone README in `tests/proof/codec_benchmark/`.
