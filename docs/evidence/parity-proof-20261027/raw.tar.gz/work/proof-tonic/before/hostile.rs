//! What the server does when the peer is not a well-behaved gRPC client.
//!
//! These tests speak raw HTTP/2 so they can send bytes no real client would:
//! oversize length prefixes, gzip bombs, reserved flag values, truncated
//! frames, wrong content types, an HTTP/2 rapid-reset flood, a protocol-error
//! RST flood, a HEADERS block split across CONTINUATION frames, and a
//! small-DATA flood. Every
//! case must produce a `Status` (or drop that connection) and leave the
//! server serving. Rapid reset, protocol-error RST, CONTINUATION, and
//! small-DATA floods
//! are h2c-only here; TLS has no raw `h2` peer.

#![allow(
    clippy::disallowed_methods,
    clippy::let_underscore_must_use,
    clippy::unwrap_used,
    clippy::expect_used,
    clippy::indexing_slicing,
    clippy::panic,
    clippy::cast_possible_truncation,
    clippy::cast_possible_wrap,
    clippy::cast_sign_loss,
    clippy::too_many_lines,
    clippy::unimplemented,
    unreachable_pub,
    reason = "integration tests"
)]

mod common;

use bytes::{BufMut, Bytes, BytesMut};
use common::{serve, spawn_greeter_server};
use flate2::Compression;
use flate2::write::{GzEncoder, ZlibEncoder};
use http::{HeaderValue, Method, Request as HttpRequest, StatusCode};
use pbrs_grpc::hello::{Greeter, HelloReply, HelloRequest};
use pbrs_grpc::{Code, Codec, Request, Response, ServerConfig, Status, Streaming};
use std::io::Write;
use std::net::SocketAddr;
use std::task::{Context, Poll};
use std::time::Duration;
use tokio::io::{AsyncReadExt, AsyncWriteExt};
use tokio::net::TcpStream;

const SAY_HELLO: &str = "/helloworld.Greeter/SayHello";
const STREAM_HELLO: &str = "/helloworld.Greeter/StreamHello";

/// A raw HTTP/2 connection that sends whatever bytes it is told to.
struct RawPeer {
    send: h2::client::SendRequest<Bytes>,
    authority: String,
}

impl RawPeer {
    async fn connect(addr: SocketAddr) -> Self {
        let tcp = tokio::net::TcpStream::connect(addr).await.expect("connect");
        let (send, conn) = h2::client::handshake(tcp).await.expect("handshake");
        drop(tokio::spawn(async move {
            conn.await.ok();
        }));
        Self {
            send,
            authority: addr.to_string(),
        }
    }

    fn request(&self, path: &str, content_type: &str) -> HttpRequest<()> {
        let uri = format!("http://{}{path}", self.authority);
        HttpRequest::builder()
            .method(Method::POST)
            .uri(uri)
            .header(http::header::CONTENT_TYPE, content_type)
            .header(http::header::TE, "trailers")
            .body(())
            .expect("request")
    }

    fn grpc_request_builder(&self, path: &str) -> http::request::Builder {
        let uri = format!("http://{}{path}", self.authority);
        HttpRequest::builder()
            .method(Method::POST)
            .uri(uri)
            .header(http::header::CONTENT_TYPE, "application/grpc")
            .header(http::header::TE, "trailers")
    }

    /// Send `body` as the whole request and read back the gRPC status.
    async fn call(&mut self, path: &str, body: Bytes) -> Answer {
        self.call_with(self.request(path, "application/grpc"), body)
            .await
    }

    async fn call_with(&mut self, request: HttpRequest<()>, body: Bytes) -> Answer {
        let mut send = self.send.clone().ready().await.expect("ready");
        let (response, mut stream) = send.send_request(request, false).expect("send_request");
        stream.send_data(body, true).expect("send_data");
        let response = response.await.expect("response");
        let http_status = response.status();
        let header_code = grpc_status(response.headers()).map(Code::from_i32);
        let mut body = response.into_body();
        let mut payload_frames = 0usize;
        while let Some(chunk) = body.data().await {
            let chunk = chunk.expect("data");
            if !chunk.is_empty() {
                payload_frames += 1;
            }
            body.flow_control().release_capacity(chunk.len()).ok();
        }
        let trailer_code = body
            .trailers()
            .await
            .ok()
            .flatten()
            .and_then(|t| grpc_status(&t))
            .map(Code::from_i32);
        Answer {
            http_status,
            code: trailer_code.or(header_code),
            header_code,
            trailer_code,
            payload_frames,
        }
    }
}

struct Answer {
    http_status: StatusCode,
    code: Option<Code>,
    header_code: Option<Code>,
    trailer_code: Option<Code>,
    payload_frames: usize,
}

impl Answer {
    fn expect_code(&self, want: Code) {
        assert_eq!(
            self.http_status,
            StatusCode::OK,
            "gRPC protocol errors answer 200"
        );
        assert_eq!(self.code, Some(want));
    }

    fn expect_trailers_only(&self, want: Code) {
        assert_eq!(
            self.http_status,
            StatusCode::OK,
            "gRPC trailers-only errors answer 200"
        );
        assert_eq!(
            self.header_code,
            Some(want),
            "trailers-only puts grpc-status in initial headers"
        );
        assert_eq!(
            self.trailer_code, None,
            "trailers-only must not send separate trailers"
        );
        assert_eq!(
            self.payload_frames, 0,
            "trailers-only must not send DATA frames"
        );
    }

    fn expect_http(&self, want: StatusCode) {
        assert_eq!(self.http_status, want);
        assert_eq!(self.code, None, "HTTP {want} is not a gRPC status");
        assert_eq!(self.header_code, None);
        assert_eq!(self.trailer_code, None);
        assert_eq!(self.payload_frames, 0);
    }
}

fn grpc_status(headers: &http::HeaderMap) -> Option<i32> {
    headers.get("grpc-status")?.to_str().ok()?.parse().ok()
}

/// A length-prefixed frame with an arbitrary declared length, so tests can lie.
fn frame_with_declared_len(flag: u8, declared: u32, payload: &[u8]) -> Bytes {
    let mut buf = BytesMut::with_capacity(5 + payload.len());
    buf.put_u8(flag);
    buf.put_u32(declared);
    buf.extend_from_slice(payload);
    buf.freeze()
}

fn frame(payload: &[u8]) -> Bytes {
    frame_with_declared_len(0, payload.len() as u32, payload)
}

fn gzip(payload: &[u8]) -> Vec<u8> {
    gzip_with(payload, Compression::fast())
}

fn gzip_with(payload: &[u8], level: Compression) -> Vec<u8> {
    let mut enc = GzEncoder::new(Vec::new(), level);
    enc.write_all(payload).expect("write");
    enc.finish().expect("finish")
}

fn deflate(payload: &[u8]) -> Vec<u8> {
    // gRPC `deflate` is the zlib wrapper (RFC 1950), not a raw stream.
    let mut enc = ZlibEncoder::new(Vec::new(), Compression::fast());
    enc.write_all(payload).expect("write");
    enc.finish().expect("finish")
}

#[cfg(feature = "zstd")]
fn zstd(payload: &[u8]) -> Vec<u8> {
    pbrs_grpc::CompressionAlgorithm::Zstd
        .encode(payload)
        .expect("zstd")
}

/// A valid `HelloRequest { name: "ada" }`.
fn hello_request() -> Vec<u8> {
    vec![0x0a, 0x03, b'a', b'd', b'a']
}

#[tokio::test]
async fn a_giant_declared_length_is_refused_from_the_header() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    // Claims 4 GiB but sends five bytes. The cap must be applied to the claim.
    let body = frame_with_declared_len(0, u32::MAX, &hello_request());
    peer.call(SAY_HELLO, body)
        .await
        .expect_code(Code::ResourceExhausted);
}

#[tokio::test]
async fn immediate_unimplemented_is_trailers_only() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    peer.call("/helloworld.Greeter/Nope", frame(&hello_request()))
        .await
        .expect_trailers_only(Code::Unimplemented);
}

#[tokio::test]
async fn expired_timeout_before_dispatch_is_trailers_only() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let req = peer
        .grpc_request_builder(SAY_HELLO)
        .header("grpc-timeout", "0S")
        .body(())
        .expect("request");
    peer.call_with(req, frame(&hello_request()))
        .await
        .expect_trailers_only(Code::DeadlineExceeded);
}

#[tokio::test]
async fn process_rpc_cap_rejection_is_trailers_only() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().max_concurrent_rpcs(1)).await;
    let holder = RawPeer::connect(addr).await;
    let mut send = holder.send.clone().ready().await.expect("ready");
    let (response, _body) = send
        .send_request(holder.request(STREAM_HELLO, "application/grpc"), false)
        .expect("send held stream");
    response.await.expect("held stream response headers");

    let mut peer = RawPeer::connect(addr).await;
    peer.call(SAY_HELLO, frame(&hello_request()))
        .await
        .expect_trailers_only(Code::ResourceExhausted);
}

#[tokio::test]
async fn oversize_message_is_resource_exhausted_not_a_hang() {
    let (addr, _guard) =
        spawn_greeter_server(ServerConfig::new().max_decoding_message_size(16)).await;
    let mut peer = RawPeer::connect(addr).await;
    let payload = vec![0u8; 1024];
    peer.call(SAY_HELLO, frame(&payload))
        .await
        .expect_code(Code::ResourceExhausted);
}

#[tokio::test]
async fn a_gzip_bomb_cannot_outgrow_the_cap() {
    // 64 MiB of zeros compresses to well under 256 KiB, so the frame itself
    // passes the length check and only bounded inflation stops it.
    const CAP: usize = 256 * 1024;
    let (addr, _guard) =
        spawn_greeter_server(ServerConfig::new().max_decoding_message_size(CAP)).await;
    let bomb = gzip_with(&vec![0u8; 64 * 1024 * 1024], Compression::best());
    assert!(
        bomb.len() < CAP,
        "the bomb must pass the frame-length check: {} bytes vs {CAP}",
        bomb.len()
    );
    let mut peer = RawPeer::connect(addr).await;
    let body = frame_with_declared_len(1, bomb.len() as u32, &bomb);
    // Name the coding so this reaches bounded inflation, rather than the
    // protocol check for a compressed flag without grpc-encoding.
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("gzip"));
    peer.call_with(request, body)
        .await
        .expect_code(Code::ResourceExhausted);
}

#[cfg(feature = "zstd")]
#[tokio::test]
async fn a_zstd_bomb_cannot_outgrow_the_cap() {
    const CAP: usize = 256 * 1024;
    let (addr, _guard) =
        spawn_greeter_server(ServerConfig::new().max_decoding_message_size(CAP)).await;
    let bomb = zstd(&vec![0u8; 64 * 1024 * 1024]);
    assert!(
        bomb.len() < CAP,
        "the bomb must pass the frame-length check: {} bytes vs {CAP}",
        bomb.len()
    );
    let mut peer = RawPeer::connect(addr).await;
    let body = frame_with_declared_len(1, bomb.len() as u32, &bomb);
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("zstd"));
    peer.call_with(request, body)
        .await
        .expect_code(Code::ResourceExhausted);
}

#[tokio::test]
async fn a_legitimate_compressed_frame_still_round_trips() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let compressed = gzip(&hello_request());
    let mut peer = RawPeer::connect(addr).await;
    let body = frame_with_declared_len(1, compressed.len() as u32, &compressed);
    for encoding in ["gzip", "GZIP", "Gzip"] {
        let mut request = peer.request(SAY_HELLO, "application/grpc");
        request.headers_mut().insert(
            "grpc-encoding",
            HeaderValue::from_str(encoding).expect("encoding"),
        );
        let answer = peer.call_with(request, body.clone()).await;
        answer.expect_code(Code::Ok);
        assert_eq!(answer.payload_frames, 1, "{encoding}");
    }

    let mut identity = peer.request(SAY_HELLO, "application/grpc");
    identity
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("IDENTITY"));
    peer.call_with(identity, frame(&hello_request()))
        .await
        .expect_code(Code::Ok);
}

#[tokio::test]
async fn an_identity_encoding_header_is_the_same_as_omitting_it() {
    struct WantsNone;

    impl Greeter for WantsNone {
        async fn say_hello(
            &self,
            request: Request<HelloRequest>,
        ) -> Result<Response<HelloReply>, Status> {
            if let Some(enc) = request.encoding() {
                return Err(Status::internal(format!("identity advertised {enc}")));
            }
            Ok(Response::new(common::reply(common::name_of_request(
                request.get_ref(),
            ))))
        }
    }

    let (addr, _guard) = serve(WantsNone, ServerConfig::new()).await.expect("serve");
    let mut peer = RawPeer::connect(addr).await;
    peer.call(SAY_HELLO, frame(&hello_request()))
        .await
        .expect_code(Code::Ok);
    for token in ["identity", "IDENTITY", "Identity", "identity;q=0"] {
        let mut request = peer.request(SAY_HELLO, "application/grpc");
        request.headers_mut().insert(
            "grpc-encoding",
            HeaderValue::from_str(token).expect("encoding"),
        );
        peer.call_with(request, frame(&hello_request()))
            .await
            .expect_code(Code::Ok);
    }
}

#[tokio::test]
async fn a_reserved_compressed_flag_is_a_protocol_error() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let payload = hello_request();
    let body = frame_with_declared_len(7, payload.len() as u32, &payload);
    peer.call(SAY_HELLO, body).await.expect_code(Code::Internal);
}

#[tokio::test]
async fn a_truncated_frame_is_not_an_empty_message() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    // Declares 64 bytes, sends 3. The stream then half-closes.
    let body = frame_with_declared_len(0, 64, &[1, 2, 3]);
    peer.call(SAY_HELLO, body).await.expect_code(Code::Internal);
}

#[tokio::test]
async fn two_messages_on_a_unary_path_are_refused() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let mut body = BytesMut::new();
    body.extend_from_slice(&frame(&hello_request()));
    body.extend_from_slice(&frame(&hello_request()));
    peer.call(SAY_HELLO, body.freeze())
        .await
        .expect_code(Code::Internal);
}

#[tokio::test]
async fn a_non_grpc_content_type_is_http_415() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    for content_type in [
        "application/json",
        "application/grpc+json",
        "application/grpc+thrift",
        "application/grpc-web+json",
        "application/grpc-web-text+json",
        #[cfg(not(feature = "grpc-web"))]
        "application/grpc-web",
        #[cfg(not(feature = "grpc-web"))]
        "application/grpc-web+proto",
        #[cfg(not(feature = "grpc-web"))]
        "application/grpc-web-text",
        #[cfg(not(feature = "grpc-web"))]
        "application/grpc-web-text+proto",
    ] {
        let request = peer.request(SAY_HELLO, content_type);
        peer.call_with(request, frame(&hello_request()))
            .await
            .expect_http(StatusCode::UNSUPPORTED_MEDIA_TYPE);
    }
}

#[tokio::test]
async fn a_non_grpc_content_type_on_an_unknown_method_is_still_415() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let request = peer.request("/nope.Nothing/Anything", "application/json");
    peer.call_with(request, Bytes::new())
        .await
        .expect_http(StatusCode::UNSUPPORTED_MEDIA_TYPE);
}

#[tokio::test]
async fn a_non_post_is_http_405() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let peer = RawPeer::connect(addr).await;
    for method in [Method::GET, Method::PUT, Method::HEAD] {
        let label = method.as_str().to_owned();
        let mut request = peer.request(SAY_HELLO, "application/grpc");
        *request.method_mut() = method;
        let mut send = peer.send.clone().ready().await.expect("ready");
        let (response, _stream) = send.send_request(request, true).expect("send_request");
        let response = response.await.expect("response");
        assert_eq!(
            response.status(),
            StatusCode::METHOD_NOT_ALLOWED,
            "{label} must be 405"
        );
        assert_eq!(
            response
                .headers()
                .get(http::header::ALLOW)
                .and_then(|v| v.to_str().ok()),
            Some("POST")
        );
        assert!(grpc_status(response.headers()).is_none(), "{label}");
    }
}

#[tokio::test]
async fn grpc_proto_content_type_subtypes_are_accepted() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    for content_type in [
        "application/grpc",
        "application/grpc+proto",
        "Application/Grpc",
        "APPLICATION/GRPC+PROTO",
    ] {
        let request = peer.request(SAY_HELLO, content_type);
        let answer = peer.call_with(request, frame(&hello_request())).await;
        answer.expect_code(Code::Ok);
        assert_eq!(answer.payload_frames, 1, "{content_type} must get a reply");
    }
}

#[tokio::test]
async fn an_unsupported_encoding_is_unimplemented_and_advertises_what_works() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("snappy"));

    let mut send = peer.send.clone().ready().await.expect("ready");
    let (response, mut stream) = send.send_request(request, false).expect("send_request");
    stream
        .send_data(frame(&hello_request()), true)
        .expect("send_data");
    let response = response.await.expect("response");
    assert_eq!(
        grpc_status(response.headers()).map(Code::from_i32),
        Some(Code::Unimplemented)
    );
    assert_eq!(
        response
            .headers()
            .get("grpc-accept-encoding")
            .and_then(|v| v.to_str().ok()),
        if cfg!(feature = "zstd") {
            Some("identity,gzip,deflate,zstd")
        } else {
            Some("identity,gzip,deflate")
        },
        "the spec requires telling the client what to retry with"
    );
}

#[tokio::test]
async fn gzip_is_unimplemented_when_the_server_opts_out_of_inbound_gzip() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().accept_compressed(false)).await;
    let peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("gzip"));

    let mut send = peer.send.clone().ready().await.expect("ready");
    let (response, mut stream) = send.send_request(request, false).expect("send_request");
    stream
        .send_data(frame(&hello_request()), true)
        .expect("send_data");
    let response = response.await.expect("response");
    assert_eq!(
        grpc_status(response.headers()).map(Code::from_i32),
        Some(Code::Unimplemented)
    );
    assert_eq!(
        response
            .headers()
            .get("grpc-accept-encoding")
            .and_then(|v| v.to_str().ok()),
        Some("identity"),
        "opt-out must advertise identity only"
    );
}

#[tokio::test]
async fn a_compressed_flag_is_refused_when_inbound_gzip_is_off() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().accept_compressed(false)).await;
    let compressed = gzip(&hello_request());
    let mut peer = RawPeer::connect(addr).await;
    let body = frame_with_declared_len(1, compressed.len() as u32, &compressed);
    // An advertised gzip coding tests the server's inbound compression policy.
    // Omitting it would instead be an invalid compressed-flag protocol error.
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("gzip"));
    peer.call_with(request, body)
        .await
        .expect_code(Code::Unimplemented);
}

#[tokio::test]
async fn deflate_request_decodes_and_gets_a_reply() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("deflate"));
    let body = deflate(&hello_request());
    let answer = peer
        .call_with(
            request,
            frame_with_declared_len(1, body.len() as u32, &body),
        )
        .await;
    answer.expect_code(Code::Ok);
    assert_eq!(answer.payload_frames, 1, "deflate RPC must get a reply");
}

#[tokio::test]
async fn deflate_coding_is_refused_when_inbound_compression_is_off() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().accept_compressed(false)).await;
    let mut peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("deflate"));
    peer.call_with(request, frame(&hello_request()))
        .await
        .expect_code(Code::Unimplemented);
}

#[tokio::test]
async fn gzip_bytes_under_deflate_coding_are_an_error() {
    // The decoder must follow the RPC's coding, not sniff the bytes: gzip
    // bytes under a deflate coding fail instead of decoding.
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request
        .headers_mut()
        .insert("grpc-encoding", HeaderValue::from_static("deflate"));
    let body = gzip(&hello_request());
    peer.call_with(
        request,
        frame_with_declared_len(1, body.len() as u32, &body),
    )
    .await
    .expect_code(Code::Internal);
}

#[tokio::test]
async fn deflate_configured_server_falls_back_to_gzip_only_peer() {
    let (addr, _guard) = spawn_greeter_server(
        ServerConfig::new()
            .send_compressed(true)
            .compression_codec(Codec::Deflate),
    )
    .await;
    let peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    request.headers_mut().insert(
        "grpc-accept-encoding",
        HeaderValue::from_static("identity,gzip"),
    );
    let mut send = peer.send.clone().ready().await.expect("ready");
    let (response, mut stream) = send.send_request(request, false).expect("send_request");
    stream
        .send_data(frame(&hello_request()), true)
        .expect("send_data");
    let response = response.await.expect("response");
    assert_eq!(
        response
            .headers()
            .get("grpc-encoding")
            .and_then(|v| v.to_str().ok()),
        Some("gzip"),
        "must compress with the coding the peer accepts"
    );
}

#[tokio::test]
async fn an_unknown_method_is_unimplemented() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    peer.call("/helloworld.Greeter/NoSuchMethod", frame(&hello_request()))
        .await
        .expect_code(Code::Unimplemented);
}

#[tokio::test]
async fn an_unknown_service_is_unimplemented() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    peer.call("/nope.Nothing/Anything", frame(&hello_request()))
        .await
        .expect_code(Code::Unimplemented);
}

#[tokio::test]
async fn a_malformed_path_is_unimplemented_not_a_panic() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    for path in ["/", "/nomethod", "//", "/a/b/c"] {
        peer.call(path, frame(&hello_request()))
            .await
            .expect_code(Code::Unimplemented);
    }
}

#[tokio::test]
async fn an_empty_body_decodes_to_a_default_message() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    let answer = peer.call(SAY_HELLO, Bytes::new()).await;
    answer.expect_code(Code::Ok);
    assert_eq!(answer.payload_frames, 1);
}

#[tokio::test]
async fn garbage_protobuf_bytes_are_an_error_not_a_panic() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;
    // Field 1, wire type 5 (fixed32) where a string is expected, truncated.
    peer.call(SAY_HELLO, frame(&[0x0d, 0xff]))
        .await
        .expect_code(Code::Internal);
}

#[tokio::test]
async fn a_hostile_stream_does_not_take_the_server_down() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawPeer::connect(addr).await;

    // Twenty different kinds of bad request on the same connection.
    for _ in 0..5 {
        peer.call(SAY_HELLO, frame_with_declared_len(0, u32::MAX, &[]))
            .await;
        peer.call(SAY_HELLO, frame_with_declared_len(9, 1, &[0]))
            .await;
        peer.call("/unknown.Service/Method", Bytes::new()).await;
        peer.call(STREAM_HELLO, frame_with_declared_len(0, 99, &[1]))
            .await;
    }

    // The server still answers a well-formed request on a fresh connection.
    let client = common::greeter_client(addr).await;
    let reply = client
        .say_hello(pbrs_grpc::Request::new(common::req("ada")))
        .await
        .expect("server still healthy");
    assert_eq!(common::name_of(reply.get_ref()), "ada");
}

#[tokio::test]
async fn metadata_beyond_the_header_list_cap_is_refused() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().max_header_list_size(1024)).await;
    let peer = RawPeer::connect(addr).await;
    let mut request = peer.request(SAY_HELLO, "application/grpc");
    let big = "v".repeat(4096);
    request
        .headers_mut()
        .insert("x-flood", HeaderValue::from_str(&big).expect("value"));

    let mut send = peer.send.clone().ready().await.expect("ready");
    // h2 either refuses locally or the server resets; either way the RPC does
    // not complete and the server is unharmed.
    let outcome = match send.send_request(request, false) {
        Err(_) => None,
        Ok((response, mut stream)) => {
            stream.send_data(frame(&hello_request()), true).ok();
            Some(response.await)
        }
    };
    assert!(
        outcome.is_none_or(|r| r.is_err()),
        "oversize header list must not be served"
    );

    let client = common::greeter_client(addr).await;
    let reply = tokio::time::timeout(
        Duration::from_secs(5),
        client.say_hello(pbrs_grpc::Request::new(common::req("ada"))),
    )
    .await
    .expect("no hang")
    .expect("server still healthy");
    assert_eq!(common::name_of(reply.get_ref()), "ada");
}

#[tokio::test]
async fn h2c_ignores_a_peer_https_scheme() {
    struct MustBeHttp;

    impl Greeter for MustBeHttp {
        async fn say_hello(
            &self,
            request: Request<HelloRequest>,
        ) -> Result<Response<HelloReply>, Status> {
            if request.scheme() != Some("http") {
                return Err(Status::internal(format!("scheme {:?}", request.scheme())));
            }
            Ok(Response::new(common::reply(common::name_of_request(
                request.get_ref(),
            ))))
        }

        async fn client_hello(
            &self,
            _request: Request<Streaming<HelloRequest>>,
        ) -> Result<Response<HelloReply>, Status> {
            Err(Status::unimplemented("must-be-http"))
        }

        async fn server_hello(
            &self,
            _request: Request<HelloRequest>,
        ) -> Result<Response<Streaming<HelloReply>>, Status> {
            Err(Status::unimplemented("must-be-http"))
        }

        async fn stream_hello(
            &self,
            _request: Request<Streaming<HelloRequest>>,
        ) -> Result<Response<Streaming<HelloReply>>, Status> {
            Err(Status::unimplemented("must-be-http"))
        }
    }

    let (addr, _guard) = serve(MustBeHttp, ServerConfig::new()).await.expect("spawn");
    let mut peer = RawPeer::connect(addr).await;
    let uri = format!("https://{}{SAY_HELLO}", peer.authority);
    let request = HttpRequest::builder()
        .method(Method::POST)
        .uri(uri)
        .header(http::header::CONTENT_TYPE, "application/grpc")
        .header(http::header::TE, "trailers")
        .body(())
        .expect("request");
    peer.call_with(request, frame(&hello_request()))
        .await
        .expect_code(Code::Ok);
}

/// A raw peer that `RST_STREAM`s faster than accept exceeds
/// [`ServerConfig::max_pending_accept_reset_streams`]. That connection is
/// dropped (`ENHANCE_YOUR_CALM`); a well-behaved client on a fresh connection
/// still serves. Distinct from wrap still-serves. h2c-only (`RawPeer`).
///
/// `current_thread` so the burst queues HEADERS then RSTs without the server
/// `poll_accept` interleaving. A multi-thread runtime lets the accept loop
/// drain streams before the RSTs land, and the queue never fills.
#[tokio::test(flavor = "current_thread")]
async fn rst_flood_beyond_pending_reset_cap_drops_that_connection() {
    let (addr, _guard) =
        spawn_greeter_server(ServerConfig::new().max_pending_accept_reset_streams(1)).await;
    let peer = RawPeer::connect(addr).await;
    let mut send = peer.send.clone().ready().await.expect("settings");
    let mut opened = Vec::new();
    for _ in 0..32 {
        let request = peer.request(SAY_HELLO, "application/grpc");
        let (response, stream) = send.send_request(request, false).expect("open stream");
        opened.push((response, stream));
        let waker = std::task::Waker::noop();
        let mut cx = Context::from_waker(waker);
        match send.poll_ready(&mut cx) {
            Poll::Ready(Ok(())) => {}
            Poll::Ready(Err(e)) => panic!("connection died while opening the burst: {e}"),
            Poll::Pending => {
                panic!("burst must not yield; SETTINGS should already allow 32 streams")
            }
        }
    }
    for (_, stream) in &mut opened {
        stream.send_reset(h2::Reason::CANCEL);
    }
    drop(opened);
    drop(send);
    let started = std::time::Instant::now();
    let dropped = loop {
        tokio::task::yield_now().await;
        match tokio::time::timeout(Duration::from_millis(50), peer.send.clone().ready()).await {
            Ok(Err(_)) | Err(_) => break true,
            Ok(Ok(_)) => {
                if started.elapsed() > Duration::from_millis(1500) {
                    break false;
                }
            }
        }
    };
    assert!(
        dropped,
        "RST flood must trip max_pending_accept_reset_streams and drop that connection"
    );

    let client = common::greeter_client(addr).await;
    let reply = tokio::time::timeout(
        Duration::from_secs(5),
        client.say_hello(pbrs_grpc::Request::new(common::req("ada"))),
    )
    .await
    .expect("no hang")
    .expect("accept loop still serves after the flood connection dropped");
    assert_eq!(common::name_of(reply.get_ref()), "ada");
}

const H2_PREFACE: &[u8] = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n";
const FRAME_DATA: u8 = 0x0;
const FRAME_HEADERS: u8 = 0x1;
const FRAME_PRIORITY: u8 = 0x2;
const FRAME_SETTINGS: u8 = 0x4;
const FRAME_GOAWAY: u8 = 0x7;
const FRAME_CONTINUATION: u8 = 0x9;
const FLAG_ACK: u8 = 0x1;
const FLAG_END_STREAM: u8 = 0x1;
const FLAG_END_HEADERS: u8 = 0x4;

/// PRIORITY frame whose stream depends on itself: h2 `library_reset`
/// `PROTOCOL_ERROR`. Distinct from DATA after `END_STREAM`, which h2 0.4
/// treats as a connection `PROTOCOL_ERROR` (not a counted library RST).
fn priority_self_dep(stream_id: u32) -> Vec<u8> {
    let payload = [
        ((stream_id >> 24) & 0x7f) as u8,
        (stream_id >> 16) as u8,
        (stream_id >> 8) as u8,
        stream_id as u8,
        16,
    ];
    h2_frame(FRAME_PRIORITY, 0, stream_id, &payload)
}

/// Length-prefixed HTTP/2 frame. `h2::client` always sends a complete header
/// block; this is how a test splits HEADERS across CONTINUATION.
fn h2_frame(ty: u8, flags: u8, stream_id: u32, payload: &[u8]) -> Vec<u8> {
    let len = payload.len();
    let mut buf = Vec::with_capacity(9 + len);
    buf.push(((len >> 16) & 0xff) as u8);
    buf.push(((len >> 8) & 0xff) as u8);
    buf.push((len & 0xff) as u8);
    buf.push(ty);
    buf.push(flags);
    buf.push(((stream_id >> 24) & 0x7f) as u8);
    buf.push(((stream_id >> 16) & 0xff) as u8);
    buf.push(((stream_id >> 8) & 0xff) as u8);
    buf.push((stream_id & 0xff) as u8);
    buf.extend_from_slice(payload);
    buf
}

fn hpack_int(buf: &mut Vec<u8>, n: usize, prefix_bits: u8, first_high: u8) {
    let max = (1usize << prefix_bits) - 1;
    if n < max {
        buf.push(first_high | n as u8);
        return;
    }
    buf.push(first_high | max as u8);
    let mut n = n - max;
    while n >= 128 {
        buf.push((n % 128) as u8 | 0x80);
        n /= 128;
    }
    buf.push(n as u8);
}

fn hpack_string(buf: &mut Vec<u8>, value: &[u8]) {
    hpack_int(buf, value.len(), 7, 0);
    buf.extend_from_slice(value);
}

/// Literal without indexing, static-table name index (RFC 7541 §6.2.2).
fn hpack_literal_indexed(index: usize, value: &str) -> Vec<u8> {
    let mut buf = Vec::new();
    hpack_int(&mut buf, index, 4, 0);
    hpack_string(&mut buf, value.as_bytes());
    buf
}

fn hpack_literal_new(name: &str, value: &[u8]) -> Vec<u8> {
    let mut buf = vec![0];
    hpack_string(&mut buf, name.as_bytes());
    hpack_string(&mut buf, value);
    buf
}

fn grpc_header_block(authority: &str) -> Vec<u8> {
    let mut block = Vec::new();
    block.push(0x83); // :method POST
    block.extend(hpack_literal_indexed(4, SAY_HELLO)); // :path
    block.push(0x86); // :scheme http
    block.extend(hpack_literal_indexed(1, authority)); // :authority
    block.extend(hpack_literal_indexed(31, "application/grpc")); // content-type
    block.extend(hpack_literal_new("te", b"trailers"));
    block
}

/// Prior-knowledge HTTP/2 on a raw TCP socket, so tests can omit `END_HEADERS`.
struct RawH2 {
    tcp: TcpStream,
}

impl RawH2 {
    async fn connect(addr: SocketAddr) -> Self {
        let mut tcp = TcpStream::connect(addr).await.expect("connect");
        tcp.write_all(H2_PREFACE).await.expect("preface");
        tcp.write_all(&h2_frame(FRAME_SETTINGS, 0, 0, &[]))
            .await
            .expect("client settings");
        let mut this = Self { tcp };
        this.ack_server_settings().await;
        this
    }

    async fn ack_server_settings(&mut self) {
        for _ in 0..8 {
            let (ty, _flags, stream, _payload) =
                match tokio::time::timeout(Duration::from_millis(500), self.read_frame()).await {
                    Ok(Ok(frame)) => frame,
                    Ok(Err(_)) | Err(_) => return,
                };
            if ty == FRAME_SETTINGS && stream == 0 {
                self.tcp
                    .write_all(&h2_frame(FRAME_SETTINGS, FLAG_ACK, 0, &[]))
                    .await
                    .expect("settings ack");
                return;
            }
        }
        panic!("server never sent SETTINGS");
    }

    async fn read_frame(&mut self) -> std::io::Result<(u8, u8, u32, Vec<u8>)> {
        let mut head = [0u8; 9];
        self.tcp.read_exact(&mut head).await?;
        let len = (u32::from(head[0]) << 16) | (u32::from(head[1]) << 8) | u32::from(head[2]);
        let ty = head[3];
        let flags = head[4];
        let stream = u32::from_be_bytes([head[5] & 0x7f, head[6], head[7], head[8]]);
        let mut payload = vec![0u8; len as usize];
        if len > 0 {
            self.tcp.read_exact(&mut payload).await?;
        }
        Ok((ty, flags, stream, payload))
    }

    async fn write_all(&mut self, bytes: &[u8]) {
        self.tcp.write_all(bytes).await.expect("write");
    }
}

async fn assert_accept_loop_still_serves(addr: SocketAddr) {
    let client = common::greeter_client(addr).await;
    let reply = tokio::time::timeout(
        Duration::from_secs(5),
        client.say_hello(pbrs_grpc::Request::new(common::req("ada"))),
    )
    .await
    .expect("no hang")
    .expect("accept loop still serves");
    assert_eq!(common::name_of(reply.get_ref()), "ada");
}

/// A raw peer that sends more CONTINUATION frames than the header-list cap
/// allows (`h2` `too_many_continuations`) drops that connection
/// (`ENHANCE_YOUR_CALM`). A well-behaved client on a fresh connection still
/// serves. Distinct from `metadata_beyond_the_header_list_cap_is_refused`,
/// which sends one complete HEADERS frame through `h2::client`, and from
/// rapid-reset. h2c-only (`RawH2`).
#[tokio::test]
async fn continuation_flood_drops_that_connection() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().max_header_list_size(1024)).await;
    let mut peer = RawH2::connect(addr).await;
    let block = grpc_header_block(&addr.to_string());
    peer.write_all(&h2_frame(FRAME_HEADERS, 0, 1, &block)).await;
    for _ in 0..32 {
        peer.write_all(&h2_frame(FRAME_CONTINUATION, 0, 1, &[]))
            .await;
    }

    let started = std::time::Instant::now();
    let dropped = loop {
        match tokio::time::timeout(Duration::from_millis(200), peer.read_frame()).await {
            Ok(Ok((FRAME_GOAWAY, _, _, _))) => break true,
            Ok(Ok(_)) => {
                if started.elapsed() > Duration::from_millis(800) {
                    break false;
                }
            }
            Ok(Err(_)) | Err(_) => break true,
        }
    };
    assert!(
        dropped,
        "CONTINUATION flood must trip too_many_continuations and drop that connection"
    );
    assert_accept_loop_still_serves(addr).await;
}

/// A raw peer that forces library RSTs (PRIORITY self-dependency) beyond
/// [`ServerConfig::max_local_error_reset_streams`] drops that connection
/// (`ENHANCE_YOUR_CALM` / `too_many_internal_resets`). A well-behaved client
/// on a fresh connection still serves. Distinct from rapid-reset (remote
/// `RST_STREAM`s in the accept queue) and from DATA after `END_STREAM`
/// (`FRAME_DATA` after HEADERS with `FLAG_END_HEADERS | FLAG_END_STREAM`),
/// which h2 0.4 treats as a connection `PROTOCOL_ERROR`, not a counted
/// library RST. h2c-only (`RawH2`).
#[tokio::test]
async fn protocol_error_rst_flood_drops_that_connection() {
    let _ = (FRAME_DATA, FLAG_END_HEADERS | FLAG_END_STREAM);
    let (addr, _guard) =
        spawn_greeter_server(ServerConfig::new().max_local_error_reset_streams(1)).await;
    let mut peer = RawH2::connect(addr).await;
    // Cap 1: the first library RST is sent; the second GOAWAYs.
    peer.write_all(&priority_self_dep(1)).await;
    peer.write_all(&priority_self_dep(3)).await;
    peer.write_all(&priority_self_dep(5)).await;

    let started = std::time::Instant::now();
    let dropped = loop {
        match tokio::time::timeout(Duration::from_millis(200), peer.read_frame()).await {
            Ok(Ok((FRAME_GOAWAY, _, _, _))) => break true,
            Ok(Ok(_)) => {
                if started.elapsed() > Duration::from_millis(800) {
                    break false;
                }
            }
            Ok(Err(_)) | Err(_) => break true,
        }
    };
    assert!(
        dropped,
        "protocol-error RST flood must trip max_local_error_reset_streams and drop that connection"
    );
    assert_accept_loop_still_serves(addr).await;
}

/// A raw peer that sends too many tiny DATA frames
/// ([`ServerConfig::data_frame_budget`]) drops that connection
/// (`ENHANCE_YOUR_CALM` / `too_many_data_frames`). Distinct from the
/// connection window (flow-control bytes) and from DATA after `END_STREAM`
/// (connection `PROTOCOL_ERROR`). A well-behaved client on a fresh
/// connection still serves. h2c-only (`RawH2`).
#[tokio::test]
async fn small_data_flood_drops_that_connection() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new().data_frame_budget(256)).await;
    let mut peer = RawH2::connect(addr).await;
    let block = grpc_header_block(&addr.to_string());
    peer.write_all(&h2_frame(FRAME_HEADERS, FLAG_END_HEADERS, 1, &block))
        .await;
    for _ in 0..8 {
        peer.write_all(&h2_frame(FRAME_DATA, 0, 1, &[0x00])).await;
    }

    let started = std::time::Instant::now();
    let dropped = loop {
        match tokio::time::timeout(Duration::from_millis(200), peer.read_frame()).await {
            Ok(Ok((FRAME_GOAWAY, _, _, _))) => break true,
            Ok(Ok(_)) => {
                if started.elapsed() > Duration::from_millis(800) {
                    break false;
                }
            }
            Ok(Err(_)) | Err(_) => break true,
        }
    };
    assert!(
        dropped,
        "small-DATA flood must trip data_frame_budget and drop that connection"
    );
    assert_accept_loop_still_serves(addr).await;
}
/// that stream. Distinct from handshake timeout (preface already finished) and
/// from the CONTINUATION flood above. The accept loop still serves. h2c-only.
#[tokio::test]
async fn unfinished_headers_do_not_take_the_accept_loop_down() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let mut peer = RawH2::connect(addr).await;
    let block = grpc_header_block(&addr.to_string());
    peer.write_all(&h2_frame(FRAME_HEADERS, 0, 1, &block)).await;
    for _ in 0..8 {
        tokio::task::yield_now().await;
    }
    assert_accept_loop_still_serves(addr).await;
    drop(peer);
}

// ============================================================================
// RT-09 Deterministic Framing, Metadata, and Compression Boundary Regressions
// ============================================================================

/// Deterministic test: random chunk fragmentation over arbitrary byte boundaries
/// yields the exact same message stream.
#[test]
fn regression_chunk_fragmentation_preserves_message_stream() {
    let payload1 = b"first message: deterministic gRPC frame fragmentation";
    let payload2 = b"second message: compressed protobuf payload on the wire";
    let payload3 = b""; // empty message
    let payload4 = b"fourth message: multi-byte boundary straddling payload";

    let gz2 = pbrs_grpc::gzip::encode(payload2).expect("encode gz");

    let f1 = pbrs_grpc::codec::encode(payload1, false).expect("f1");
    let f2 = pbrs_grpc::codec::encode(&gz2, true).expect("f2");
    let f3 = pbrs_grpc::codec::encode(payload3, false).expect("f3");
    let f4 = pbrs_grpc::codec::encode(payload4, false).expect("f4");

    let mut stream = BytesMut::new();
    stream.extend_from_slice(&f1);
    stream.extend_from_slice(&f2);
    stream.extend_from_slice(&f3);
    stream.extend_from_slice(&f4);
    let wire = stream.freeze();

    let decode_all_chunks = |chunk_sizes: &[usize]| -> Vec<pbrs_grpc::codec::Frame> {
        let mut buf = BytesMut::new();
        let mut frames = Vec::new();
        let mut offset = 0;
        let mut chunk_idx = 0;
        while offset < wire.len() {
            let chunk_len = chunk_sizes[chunk_idx % chunk_sizes.len()].min(wire.len() - offset);
            buf.extend_from_slice(&wire[offset..offset + chunk_len]);
            offset += chunk_len;
            chunk_idx += 1;
            while let Ok(Some(frame)) =
                pbrs_grpc::codec::pop_limited(&mut buf, pbrs_grpc::MessageLimits::unlimited())
            {
                frames.push(frame);
            }
        }
        frames
    };

    // Regime 1: 1 byte at a time
    let frames_1byte = decode_all_chunks(&[1]);
    // Regime 2: 2 bytes at a time (misaligns 5-byte header)
    let frames_2byte = decode_all_chunks(&[2]);
    // Regime 3: 3 and 7 bytes alternating
    let frames_variable = decode_all_chunks(&[3, 7, 1, 4, 11]);
    // Regime 4: whole stream coalesced
    let frames_coalesced = decode_all_chunks(&[wire.len()]);

    for regime in [
        &frames_1byte,
        &frames_2byte,
        &frames_variable,
        &frames_coalesced,
    ] {
        assert_eq!(
            regime.len(),
            4,
            "all 4 frames must be decoded regardless of chunking"
        );
        assert_eq!(&regime[0].payload[..], payload1);
        assert!(!regime[0].compressed);

        assert!(regime[1].compressed);
        let inflated = pbrs_grpc::gzip::decode_limited(
            &regime[1].payload,
            pbrs_grpc::MessageLimits::unlimited(),
        )
        .expect("inflate");
        assert_eq!(inflated, payload2);

        assert_eq!(&regime[2].payload[..], payload3);
        assert!(!regime[2].compressed);

        assert_eq!(&regime[3].payload[..], payload4);
        assert!(!regime[3].compressed);
    }
}

/// HTTP/2 regression: fragmented DATA chunks over HTTP/2 reassemble correctly.
#[tokio::test]
async fn regression_http2_single_byte_data_chunks_serve_cleanly() {
    let (addr, _guard) = spawn_greeter_server(ServerConfig::new()).await;
    let peer = RawPeer::connect(addr).await;

    let wire_frame = frame(&hello_request());
    let request = peer.request(SAY_HELLO, "application/grpc");

    let mut send = peer.send.clone().ready().await.expect("ready");
    let (response, mut stream) = send.send_request(request, false).expect("send_request");

    // Send the frame byte-by-byte in individual HTTP/2 DATA frames
    for (i, &b) in wire_frame.iter().enumerate() {
        let is_last = i == wire_frame.len() - 1;
        stream
            .send_data(Bytes::copy_from_slice(&[b]), is_last)
            .expect("send_data byte");
    }

    let response = response.await.expect("response");
    let mut body = response.into_body();
    while let Some(chunk) = body.data().await {
        let chunk = chunk.expect("data");
        body.flow_control().release_capacity(chunk.len()).ok();
    }
    let trailer_status = body
        .trailers()
        .await
        .expect("trailers")
        .and_then(|t| grpc_status(&t));

    assert_eq!(
        trailer_status,
        Some(0),
        "fragmented request must succeed with OK status"
    );
}

/// Compression bomb regression: 10 MiB of zeros compressed to ~1 KiB must fail
/// within strict memory and time budgets.
#[test]
fn regression_compression_bomb_fails_within_byte_and_time_budgets() {
    let uncompressed_size = 10 * 1024 * 1024; // 10 MiB
    let bomb_raw = vec![0u8; uncompressed_size];
    let bomb_gz = pbrs_grpc::gzip::encode(&bomb_raw).expect("encode bomb");
    assert!(
        bomb_gz.len() < 100 * 1024,
        "bomb must compress to < 100 KiB: actual {}",
        bomb_gz.len()
    );

    let limits = pbrs_grpc::MessageLimits::unlimited().with_max_decoding(4096);
    let start = std::time::Instant::now();
    let res = pbrs_grpc::gzip::decode_limited(&bomb_gz, limits);
    let elapsed = start.elapsed();

    let err = res.expect_err("compression bomb must be rejected");
    assert_eq!(err.code(), Code::ResourceExhausted);
    assert!(
        elapsed < Duration::from_millis(20),
        "bomb rejection must be instantaneous, took {elapsed:?}"
    );
}

/// Invalid frame lengths regression: declared lengths exceeding limit, u32::MAX,
/// and invalid flags are rejected safely from the header.
#[test]
fn regression_invalid_frame_lengths_and_flags_safely_rejected() {
    let limits = pbrs_grpc::MessageLimits::unlimited().with_max_decoding(1024);

    // 1. Declared length exceeding limit (1025 > 1024)
    let mut buf = BytesMut::from(&[0x00, 0x00, 0x00, 0x04, 0x01][..]); // declares 1025 bytes
    let err = pbrs_grpc::codec::pop_limited(&mut buf, limits).expect_err("oversize");
    assert_eq!(err.code(), Code::ResourceExhausted);

    // 2. Declared length u32::MAX
    let mut buf = BytesMut::from(&[0x00, 0xff, 0xff, 0xff, 0xff][..]);
    let err = pbrs_grpc::codec::pop_limited(&mut buf, limits).expect_err("max len");
    assert_eq!(err.code(), Code::ResourceExhausted);

    // 3. Oversize length (0xffff_fffe) rejected by limit check before buffering
    let mut buf = BytesMut::from(&[0x00, 0xff, 0xff, 0xff, 0xfe][..]);
    let err = pbrs_grpc::codec::pop_limited(&mut buf, limits).expect_err("oversize length");
    assert_eq!(err.code(), Code::ResourceExhausted);

    // 4. Invalid compressed flag (> 1)
    for bad_flag in [2u8, 3, 7, 255] {
        let mut buf = BytesMut::from(&[bad_flag, 0x00, 0x00, 0x00, 0x00][..]);
        let err = pbrs_grpc::codec::pop_limited(&mut buf, pbrs_grpc::MessageLimits::unlimited())
            .expect_err("bad flag");
        assert_eq!(err.code(), Code::Internal);
    }

    // 5. Truncation: 1..=4 bytes header
    for len in 1..5 {
        let mut buf = BytesMut::from(&vec![0u8; len][..]);
        assert!(
            pbrs_grpc::codec::pop_limited(&mut buf, limits)
                .expect("pop")
                .is_none()
        );
    }

    // 6. Truncation: 5-byte header claiming 10 bytes, but only 9 present
    let mut buf = BytesMut::from(&[0x00, 0x00, 0x00, 0x00, 0x0a, 1, 2, 3, 4, 5, 6, 7, 8, 9][..]);
    assert!(
        pbrs_grpc::codec::pop_limited(&mut buf, limits)
            .expect("pop")
            .is_none()
    );
}

/// Bad metadata encodings regression: reserved keys, mis-suffixed -bin keys,
/// and invalid ASCII characters are safely rejected with InvalidArgument.
#[test]
fn regression_bad_metadata_encodings_safely_rejected() {
    let mut md = pbrs_grpc::Metadata::new();

    // 1. ASCII metadata cannot end in -bin
    let err = md
        .insert("custom-bin", "valid_ascii")
        .expect_err("ascii -bin");
    assert_eq!(err.code(), Code::InvalidArgument);
    let err = md
        .set("custom-bin", "valid_ascii")
        .expect_err("ascii set -bin");
    assert_eq!(err.code(), Code::InvalidArgument);

    // 2. Binary metadata must end in -bin
    let err = md
        .insert_bin("custom_ascii", b"bytes")
        .expect_err("bin non-bin");
    assert_eq!(err.code(), Code::InvalidArgument);
    let err = md
        .set_bin("custom_ascii", b"bytes")
        .expect_err("bin set non-bin");
    assert_eq!(err.code(), Code::InvalidArgument);

    // 3. Reserved protocol headers
    for reserved in [
        ":status",
        ":path",
        ":method",
        ":scheme",
        ":authority",
        "grpc-status",
        "grpc-message",
        "grpc-encoding",
        "grpc-accept-encoding",
        "grpc-status-details-bin",
        "content-type",
        "te",
        "connection",
        "keep-alive",
        "proxy-connection",
        "transfer-encoding",
        "upgrade",
        "host",
    ] {
        assert_eq!(
            md.insert(reserved, "val").unwrap_err().code(),
            Code::InvalidArgument,
            "insert {reserved}"
        );
        assert_eq!(
            md.set(reserved, "val").unwrap_err().code(),
            Code::InvalidArgument,
            "set {reserved}"
        );
        assert_eq!(
            md.insert_bin(reserved, b"val").unwrap_err().code(),
            Code::InvalidArgument,
            "insert_bin {reserved}"
        );
        assert_eq!(
            md.set_bin(reserved, b"val").unwrap_err().code(),
            Code::InvalidArgument,
            "set_bin {reserved}"
        );
    }

    // 4. Invalid key characters (spaces, control chars)
    assert_eq!(
        md.insert("bad key with spaces", "val").unwrap_err().code(),
        Code::InvalidArgument
    );
    assert_eq!(
        md.insert("bad\nkey", "val").unwrap_err().code(),
        Code::InvalidArgument
    );

    // 5. Invalid ASCII values (newlines, control characters)
    assert_eq!(
        md.insert("x-key", "val\r\nnewline").unwrap_err().code(),
        Code::InvalidArgument
    );
    assert_eq!(
        md.insert("x-key", "val\0null").unwrap_err().code(),
        Code::InvalidArgument
    );

    // 6. Corrupt binary details in Status safely handled without panic
    let mut status = Status::not_found("not found");
    status.set_details(vec![0xff, 0xff, 0xff]);
    let rpc_err = status.rpc().expect_err("corrupt details must fail parse");
    assert_eq!(rpc_err.code(), Code::Internal);

    // 7. Malformed timeout strings return None rather than panic or incorrect duration
    for bad in [
        "",
        "-1S",
        "100",
        "10X",
        "99999999999999999999999999S",
        "\0S",
        "abc",
    ] {
        assert_eq!(
            pbrs_grpc::timeout::parse_timeout(bad),
            None,
            "timeout {bad}"
        );
    }
}
