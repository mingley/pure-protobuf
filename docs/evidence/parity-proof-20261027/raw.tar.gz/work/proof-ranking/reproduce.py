#!/usr/bin/env python3
"""Reject three published diagnostics as unsupported claim-grade raw evidence."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
HERE = Path(__file__).resolve().parent
SOURCE = '73e954c0610906f0f789ba3276241e3b3863a27b'
records = [
    'docs/evidence/efficiency-20261027/results.json',
    'docs/evidence/grpc-parity-and-costs-20261027/results.json',
    'docs/evidence/grpc-encode-reuse-20261026/results.json',
]
results = []
for index, name in enumerate(records):
    path = ROOT / name
    argv = [sys.executable, str(ROOT / 'scripts/verify-performance-claim.py'), str(path),
            '--expected-source', SOURCE, '--output', str(HERE / f'rejection-{index}.json')]
    output = subprocess.run(argv, cwd=ROOT, text=True, capture_output=True, check=False)
    (HERE / f'rejection-{index}.stdout').write_text(output.stdout)
    (HERE / f'rejection-{index}.stderr').write_text(output.stderr)
    results.append({'input': name, 'input_sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                    'command': argv, 'exit_code': output.returncode,
                    'report': json.loads(output.stdout)})
(HERE / 'published-record-rejections.json').write_text(json.dumps(results, indent=2) + '\n')
assert all(row['exit_code'] == 1 and row['report']['qualified'] is False
           and row['report']['evidence_checks_passed'] is False for row in results)
print('All three published diagnostic summaries rejected as claim-grade RPC CPU evidence.')
