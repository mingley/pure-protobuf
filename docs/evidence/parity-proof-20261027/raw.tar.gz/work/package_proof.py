"""Retain complete proof-attempt logs without binaries or duplicate checkouts."""
import hashlib
import io
import json
from pathlib import Path
import re
import shutil
import subprocess
import tarfile

root=Path(__file__).resolve().parents[1]
out=root/'docs/evidence/parity-proof-20261027'
out.mkdir(parents=True,exist_ok=True)
sha=lambda data:hashlib.sha256(data).hexdigest()
files={}
skip={'source','target','.git','__pycache__'}
exts={'.json','.jsonl','.log','.rs','.py','.md','.toml','.lock','.patch','.stderr','.stdout','.proto','.txt'}
for group in ['proof-prost','proof-tonic','proof-codegen','proof-codec','proof-ranking','proof-review','proof-rpc','proof-validation']:
 base=root/'work'/group
 for path in sorted(base.rglob('*')):
  relative=path.relative_to(base)
  if not path.is_file() or any(part in skip for part in relative.parts) or path.suffix not in exts:
   continue
  data=path.read_bytes()
  if data.startswith(b'\x7fELF'):
   continue
  files[str(path.relative_to(root))]=data
for name in ['proof-checks.py','proof-validation-driver.log','proof-docs.log','proof-docs-final.log','package_proof.py']:
 path=root/'work'/name
 if path.exists():files[str(path.relative_to(root))]=path.read_bytes()
base='73e954c0610906f0f789ba3276241e3b3863a27b'
fix='c1f7e9b433ddbbbd86a025e85d578c090c2f987f'
proof=subprocess.check_output(['git','rev-parse','e14cccb5'],cwd=root,text=True).strip()
files['source/transport-repair.patch']=subprocess.check_output(['git','diff',base,fix,'--'],cwd=root)
files['source/proof-suites.patch']=subprocess.check_output(['git','diff',fix,proof,'--'],cwd=root)
core=subprocess.check_output(['git','diff',base,proof,'--','src','Cargo.toml','Cargo.lock','build.rs','proto/codec_cases.proto'],cwd=root)
production=subprocess.check_output(['git','diff',fix,proof,'--','src','pbrs-grpc','protobuf-tonic','rpc-bench'],cwd=root)
if core or production:raise ValueError('Unexpected runtime source differences')
files['source/parity-workflow.yml']=(root/'.github/workflows/parity.yml').read_bytes()
files['source/equivalence.json']=(json.dumps(dict(core_unchanged_from_base=True,production_unchanged_from_fix=True,base=base,fix=fix,proof=proof),indent=2)+'\n').encode()
validation=json.loads((root/'work/proof-validation/results.json').read_text())
if not validation.get('complete') or not validation.get('clean_after'):raise ValueError('Validation not complete')
workspace=(root/'work/proof-validation/workspace.log').read_text()
counts=[list(map(int,m)) for m in re.findall(r'test result: ok\. (\d+) passed; (\d+) failed; (\d+) ignored;',workspace)]
result=dict(schema='pbrs.parity-proof-attempt.v1',baseline=base,transport_fix=fix,proof_suite=proof,
            qualified=False,full_functional_parity=False,strict_prost_behavior_parity=False,
            world_performance_ranking_established=False,
            workspace_test_counts=dict(zip(['passed','failed','ignored'],map(sum,zip(*counts)))),
            validation=validation)
for key,name in [('prost','proof-prost/results.json'),('tonic','proof-tonic/summary.json'),('codegen','proof-validation/codegen/results.json'),('codec','proof-codec/campaign/summary.json'),('rpc','proof-rpc/results/summary.json'),('rpc_matched','proof-rpc/matched/summary.json'),('preflight','proof-ranking/summary.json'),('conformance','proof-validation/conformance/summary.json')]:
 path=root/'work'/name
 if path.exists():result[key]=json.loads(path.read_text())
(out/'results.json').write_text(json.dumps(result,indent=2)+'\n')
with tarfile.open(out/'raw.tar.gz','w:gz') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);archive.addfile(info,io.BytesIO(data))
manifest=dict(schema='pbrs.evidence-manifest.v1',archive_sha256=sha((out/'raw.tar.gz').read_bytes()),results_sha256=sha((out/'results.json').read_bytes()),files={name:dict(bytes=len(data),sha256=sha(data)) for name,data in sorted(files.items())})
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
shutil.copyfile(root/'docs/evidence/efficiency-20261027/check.py',out/'check.py')
print(len(files),'files',sum(map(len,files.values())),'logical bytes',result['workspace_test_counts'])
