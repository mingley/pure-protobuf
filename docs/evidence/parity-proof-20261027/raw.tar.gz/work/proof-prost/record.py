#!/usr/bin/env python3
"""Record this finite behavior audit; a successful driver is not a parity claim."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/pure-protobuf')
out = root / 'work/proof-prost'
proof = root / 'tests/proof/prost_parity'
env = dict(os.environ, CARGO_HOME=str(root/'work/cargo'), RUSTUP_HOME=str(root/'work/rustup'),
    CARGO_TARGET_DIR=str(root/'target'), CARGO_BUILD_JOBS='1', CARGO_INCREMENTAL='0',
    CARGO_PROFILE_DEV_DEBUG='0')
env['PATH'] = f"{root}/work/cargo/bin:{root}/work/toolchain/protoc/bin:{env['PATH']}"
manifest = 'tests/proof/prost_parity/Cargo.toml'
commands = [
    ('format', ['cargo','fmt','--manifest-path',manifest,'--','--check'],0),
    ('strict', ['cargo','run','--locked','--offline','--manifest-path',manifest],1),
    ('known', ['cargo','run','--locked','--offline','--manifest-path',manifest,'--','--check-known-differences'],0),
    ('test', ['cargo','test','--locked','--offline','--manifest-path',manifest],0),
    ('clippy', ['cargo','clippy','--locked','--offline','--manifest-path',manifest,'--all-targets','--','-D','warnings'],0),
]
results=[]
for label, command, expected in commands:
    start=time.time()
    run=subprocess.run(command,cwd=root,env=env,capture_output=True)
    (out/f'{label}.stdout').write_bytes(run.stdout)
    (out/f'{label}.stderr').write_bytes(run.stderr)
    results.append(dict(label=label,command=command,expected_exit=expected,exit=run.returncode,
        seconds=time.time()-start,matched_expected_exit=run.returncode==expected))

def capture(command):
    run=subprocess.run(command,cwd=root,env=env,capture_output=True,text=True,check=True)
    return run.stdout.strip()
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
tracked=capture(['git','ls-files','src','build.rs','Cargo.toml','Cargo.lock']).splitlines()
sources={p:sha(root/p) for p in tracked}
proof_sources={str(p.relative_to(root)):sha(p) for p in sorted(proof.rglob('*')) if p.is_file()}
generated={str(p.relative_to(root)):sha(p) for pattern in ['pbrs_*.rs','proof.rs','required.rs','proof.fds']
    for p in sorted((root/'target/debug/build').glob(f'pbrs-prost-parity-proof-*/out/{pattern}'))}
provenance=dict(base_revision=capture(['git','rev-parse','HEAD']),
    core_unchanged_from_base=subprocess.run(['git','diff','--quiet','--','src','build.rs','Cargo.toml','Cargo.lock'],cwd=root).returncode==0,
    rustc=capture(['rustc','--version']),cargo=capture(['cargo','--version']),protoc=capture(['protoc','--version']),
    commands=results,source_sha256=sources,proof_source_sha256=proof_sources,generated_sha256=generated,
    environment={k:env[k] for k in ['CARGO_HOME','RUSTUP_HOME','CARGO_TARGET_DIR','CARGO_BUILD_JOBS','CARGO_INCREMENTAL','CARGO_PROFILE_DEV_DEBUG']})
(out/'provenance.json').write_text(json.dumps(provenance,indent=2)+'\n')
strict_rows=[json.loads(line) for line in (out/'strict.stdout').read_text().splitlines()]
known_rows=[json.loads(line) for line in (out/'known.stdout').read_text().splitlines()]
summary=dict(strict=strict_rows[-1],known=known_rows[-1],
    counterexamples=[row for row in strict_rows if row.get('equivalent') is False],
    commands_match_expected_exits=all(r['matched_expected_exit'] for r in results))
summary['harness_validation_passed']=summary['commands_match_expected_exits'] and summary['strict']['parity_equivalent'] is False and summary['known']['harness_passed'] is True and summary['known']['parity_equivalent'] is False
(out/'results.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
raise SystemExit(0 if summary['harness_validation_passed'] else 1)
