# Read-all nested-message review

Read-only source review, 2026-10-27. No code changed or new benchmark/build
was run for this review. Measurements below are the existing frozen codec
campaign in `work/proof-codec/campaign/`.

The deep-node read-all loss has a concrete quadratic cause: every first
child getter reparses that child, and that parse recursively validates the
entire remaining descendant wire again. The benchmark is doing equivalent
populated-field work for this fixture. This review identifies the repeated
work from source; it does not attribute a measured percentage of CPU to each
instruction or predict a candidate's measured result.

## The fixture and measured work match

- `proto/codec_cases.proto:47` defines `Node { int32 n = 1; Node child = 2; }`.
- `tests/proof/codec_benchmark/src/main.rs:135` builds a chain whose values
  are `64, 63, ..., 1`. There are 64 nodes and 63 child links, not 64 links.
- `main.rs:141` reads every pbrs node's `n()` while following `child()`;
  `main.rs:150` reads every prost node's `n` while following the boxed child.
  Both compute 2080. The only populated fields are those node values/links.
- `main.rs:308` creates one reference wire and gives that same slice to both
  parsers. `main.rs:312` checks prost against the fixture, `main.rs:315`
  checks pbrs serialization decoded by prost against the fixture, and
  `main.rs:320` checks the full read checksum before timing.
- `main.rs:322` constructs a fresh result, reads it, and drops it on every
  iteration for both libraries. Prechecking another object does not warm
  any particular measured object's `OnceLock`.
- Recorded rows have the same 285 wire bytes and FNV-1a fingerprint
  `96dc4a0199ae9e5a`, checksum 2080, successful exits and semantic prechecks.

Campaign medians (diagnostic shared host; not leadership qualification):

| Fixture / operation | pbrs CPU ns | prost CPU ns | pbrs alloc calls / requested bytes | prost alloc calls / requested bytes |
|---|---:|---:|---:|---:|
| depth 8 parse | 137.51 | 146.21 | 2 / 128 | 7 / 112 |
| depth 8 parse + read all | 671.45 | 149.31 | 8 / 608 | 7 / 112 |
| depth 64 parse | 791.45 | 1644.31 | 2 / 384 | 63 / 1008 |
| depth 64 parse + read all | 28914.35 | 1722.49 | 64 / 5344 | 63 / 1008 |

## Source-level call chain

1. `src/message.rs:24` implements `Parse::parse` by merging into a default
   value. `src/gen_support.rs:922` forwards generated owned-message merge
   to generated `merge_bytes`.
2. `src/codegen/naming.rs:497` marks singular, non-delimited LEN messages
   lazy. For a required-free child first occurrence,
   `src/codegen/parse.rs:752` emits a call to the child's `validate_inner`
   on its complete wire span, then stores `LazyMsg::from_wire`.
3. `src/codegen/parse.rs:544` emits recursive child validation, so that one
   initial validation visits every descendant. It validates bounds,
   tags, scalar payloads, UTF-8 and depth as applicable; it does not build
   the owned descendant objects for required-free `Node`.
4. `src/lazy.rs:737` lazily initializes the object on a getter.
   `src/lazy.rs:742` calls `MergeBytes::merge_inner` again on that span,
   at depth 0. `src/gen_support.rs:779` forwards to the same generated
   ordinary merge implementation. That newly materialized child again
   takes step 2 for its own child.
5. `src/lazy.rs:134` implements `Wire::window` by sharing the backing buffer.
   For the borrowed-slice parse here, it clones an `Arc` per validation
   recursion and drops that clone on return. Windows avoid repeated byte
   copies, but not repeated tag decoding, bound checks or atomic reference
   count operations.

The concrete frozen generated code is in:

`work/bench-target/release/build/pbrs-codec-proof-046b46a1d4c6211c/out/pbrs/codec_cases.rs`

Relevant generated anchors are `Node` at 1717, getter at 1755, first-child
merge arm at 1802, and recursive validation arm at 1823. The matching prost
output at `out/prost/cases.rs:51` stores `n` and `Option<Box<Node>>`.
Prost's `encoding.rs:797` performs message merge in one recursive pass.

For a chain of N nodes, root parse validates N-1 descendant nodes; reading
the first child validates N-2 descendants again, then N-3, and so on.
Full materialization therefore performs

`(N-1) + (N-2) + ... + 1 = N*(N-1)/2`

validation-node visits, in addition to N materializations. For N=64 this is
2016 validation visits, rather than one linear parse. The original full
parse has already established validity of those immutable spans. Validation
visits are not allocation requests: the retained child objects allocate
linearly, and the validation windows share one backing allocation.

## Why requested bytes also lose

`src/lazy.rs:676` stores each lazy child in a box containing both
`OnceLock<T>` and `Option<Wire>`. When read, the parsed child and its retained
wire coexist. `Node` itself additionally has unknown-field and size-cache
state (`generated codec_cases.rs:1717`; `src/rt.rs:25` for the cache).
Prost's generated `Node` contains just an integer and a boxed child link.
The observed bytes are exactly consistent with a 304-byte private Arc
allocation plus 63 80-byte lazy child boxes: `304 + 63*80 = 5344`.
Depth 8 similarly gives `48 + 7*80 = 608`. The prost observations are
`63*16 = 1008` and `7*16 = 112`. These are requested bytes on this target,
not a stable Rust layout promise, peak live memory or RSS.

## Small safe experiment to run next

Prototype one-pass eager construction for the owned singular-message path,
using the normal generated merge machinery rather than removing validation.
On the first child occurrence, create a child once and merge the bounded
child span into it at the original depth, recursively doing the same for its
children, then store that parsed child. Existing normal parsing continues
checking every tag, length, UTF-8 sequence, unknown group and depth exactly
once. Keep the duplicate-child merge path and oneof clearing semantics.
This removes the redundant validation/materialization distinction for owned
children; it does not by itself eliminate the oversized lazy wrapper.

The least invasive storage prototype could use the existing
`LazyMsg::from_owned` or unused `from_parsed` constructor to keep generated
getter APIs stable. `from_parsed` can preserve raw-wire reuse but keeps the
backing buffer; `from_owned` drops that cache and may change serialization
layout/cost. Neither should be assumed to beat prost without measurement.
A later dedicated owned-child representation can target the 80-byte-box
cost separately from the traversal change.

An alternative that preserves cheap sparse parsing is a distinct generated
materializer for already validated immutable wire spans. It must propagate
validated state transitively, so materializing one child does not validate
all descendants again. That requires a carefully scoped provenance contract
and fallback behavior for old generated code. `LazyMsg::from_wire` is public
runtime machinery today, and ordinary public merge inputs are untrusted;
blindly treating every wire as validated or globally disabling validation
would be incorrect. An ordinary public parse must still reject malformed
unread descendants immediately, and later merge fragments need full checks.
This is a larger design change than the eager prototype.

Preserve the existing required-field graph/final-tree handling
(`src/codegen/parse.rs:11`, `:275`, `:744`): split singular occurrences may
complete required fields; replaced oneof/map values must not cause premature
initialization errors; distinct repeated elements must not complete each
other. A fast path must not reintroduce per-occurrence required checks.
Retain original root-relative recursion limits when parsing all untrusted
input, even if getter materialization uses validated spans.

Before adopting either design, rerun the exact frozen parse-only/read-all
matrix including sparse RPC and shallow cases, the 654-operation prost
behavior corpus, generated required-merge/oneof/map/group/extension tests,
malformed unread-descendant and recursion controls, and official
conformance. Record both sparse-parse regressions and read-all gains.
Do not substitute the existing MiniTable `serialized_len` zero-allocation
result: this path uses generated typed messages and different code.

The shipping/allocation build output copies of `pbrs/codec_cases.rs` in
`pbrs-codec-proof-046b46a1d4c6211c` and
`pbrs-codec-proof-728a0ed4a242c67c` have the same SHA-256:
`9463c1b19a5e8875a34372b7df85d9dde7a8ba56108acf14753515f1748ba7ab`.
