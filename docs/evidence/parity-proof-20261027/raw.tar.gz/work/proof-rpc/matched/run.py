"""Frozen local native/tonic comparisons; every result retained, no ranking claim."""
import argparse
import hashlib
import importlib.util
import itertools
import json
import os
from pathlib import Path
import platform
import random
import shutil
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source', type=Path, required=True)
    parser.add_argument('--build', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--plan', type=Path, default=Path(__file__).parent / 'plan.json')
    args = parser.parse_args()
    source, build, output = args.source.resolve(), args.build.resolve(), args.output.resolve()
    record = json.loads((build / 'build.json').read_text())
    builder = module('proof_builder', source / 'scripts/build-rpc-bench.py')
    assert record['source'] == builder.source_pin()
    assert record['allocation_counts'] is False and record['exit_code'] == 0
    assert record['binary_sha256'] == digest(build / 'rpc-bench')
    assert record['command'] == ['cargo','build','--locked','--release','--manifest-path','rpc-bench/Cargo.toml','--message-format=json']
    for name, value in record['files'].items():
        assert digest(build / name) == value
    helper = module('proof_helper', ROOT / 'work/encode_smoke.py')
    plan_path = args.plan.resolve()
    plan = json.loads(plan_path.read_text())
    output.mkdir(parents=True, exist_ok=False)
    shutil.copy2(__file__, output / 'run.py')
    shutil.copy2(ROOT / 'work/encode_smoke.py', output / 'helper.py')
    shutil.copy2(plan_path, output / 'plan.json')
    cgroup = Path('/sys/fs/cgroup/cpu.stat')
    report = dict(schema='pbrs.rpc-proof-diagnostic.v1', qualified=False,
                  source=record['source'], build=record, host=platform.uname()._asdict(),
                  affinity=sorted(os.sched_getaffinity(0)), clock_ticks_per_second=os.sysconf('SC_CLK_TCK'),
                  cgroup_before=cgroup.read_text() if cgroup.exists() else None,
                  driver_sha256=digest(Path(__file__)), helper_sha256=digest(ROOT / 'work/encode_smoke.py'),
                  plan_sha256=digest(plan_path), plan=plan, runs=[],
                  state='running', passed=False)
    groups = list(itertools.product(range(plan['repeats']), plan['cells']))
    random.Random(plan['seed']).shuffle(groups)
    report['expected_captures'] = len(groups) * len(plan['pairs']) * 2
    result_path = output / 'report.json'
    def save():
        result_path.write_text(json.dumps(report, indent=2) + '\n')
    save()
    try:
        for repeat, spec in groups:
            paired = list(itertools.product(plan['pairs'].items(), spec['counts']))
            random.Random(plan['seed'] + repeat * 1000 + plan['cells'].index(spec)).shuffle(paired)
            for (pair_name, pair), count in paired:
                cell = {k:v for k,v in spec.items() if k not in ('name','counts','codec_override')}
                cell['pair'] = list(pair)
                if 'codec_override' in spec:
                    cell['pair'][1] = cell['pair'][3] = spec['codec_override']
                capture = output / ('capture-%03d' % len(report['runs']))
                options = SimpleNamespace(binary=build / 'rpc-bench', source_checkout=source,
                                          duration=60, rpc_count=count, allocation_counts=False,
                                          context_switches=False, callgrind=None, strace=None)
                result = helper.run_cell(options, cell, capture)
                report['runs'].append(dict(repeat=repeat, name=spec['name'], pair=pair_name,
                                           count=count, path=str(capture.relative_to(output) / 'run.json'),
                                           passed=result['passed']))
                save()
                if not result['passed']:
                    raise RuntimeError(result.get('error', 'capture failed'))
            print(f"{len(report['runs'])}/{report['expected_captures']} captures passed", flush=True)
        assert record['source'] == builder.source_pin()
        assert record['binary_sha256'] == digest(build / 'rpc-bench')
        report.update(state='complete', passed=True, successful_rpcs=sum(r['count'] for r in report['runs']))
    except Exception as error:
        report.update(state='failed', error=str(error))
        raise
    finally:
        report['cgroup_after'] = cgroup.read_text() if cgroup.exists() else None
        save()
    print(f"complete: {len(report['runs'])} captures, {report['successful_rpcs']} successful RPCs", flush=True)

if __name__ == '__main__':
    main()
