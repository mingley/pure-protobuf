import json,random,statistics,sys
from pathlib import Path
base=Path(sys.argv[1]).resolve() if len(sys.argv)>1 else Path(__file__).resolve().parent/'results'
report=json.loads((base/'report.json').read_text())
assert report['passed'] and report['state']=='complete'
data={}
for run in report['runs']:
 raw=json.loads((base/run['path']).read_text())
 assert raw['passed'] and raw['metrics']['successful_rpcs']==run['count']
 key=(run['name'],run['repeat'],run['pair'])
 data.setdefault(key,{})[run['count']]=raw
rows=[]
for cell in report['plan']['cells']:
 name=cell['name'];n,nn=cell['counts']
 for target,side,metric in [('native_client','client','client_lifetime_cpu_seconds'),('native_server','server','server_cpu_during_client_seconds')]:
  native=[];reference=[];ratios=[];pairs=[]
  for repeat in range(report['plan']['repeats']):
   candidate=data[name,repeat,target];control=data[name,repeat,'control']
   a=(candidate[nn][metric]-candidate[n][metric])/(nn-n)*1e6
   b=(control[nn][metric]-control[n][metric])/(nn-n)*1e6
   native.append(a);reference.append(b)
   ratio=a/b if a>0 and b>0 else None
   ratios.append(ratio)
   pairs.append(dict(repeat=repeat,native_cpu_us_per_rpc=a,tonic_cpu_us_per_rpc=b,ratio=ratio))
  valid=all(r is not None for r in ratios)
  interval=None
  if valid:
   gen=random.Random(271027)
   draws=sorted(statistics.median(gen.choices(ratios,k=len(ratios))) for _ in range(10000))
   interval=[draws[249],draws[9749]]
  rows.append(dict(cell=name,endpoint=side,pairs=pairs,native_cpu_us_per_rpc_median=statistics.median(native),
                   tonic_cpu_us_per_rpc_median=statistics.median(reference),
                   median_paired_ratio=statistics.median(ratios) if valid else None,
                   paired_ratio_range=[min(ratios),max(ratios)] if valid else None,
                   diagnostic_paired_bootstrap_95_interval=interval,
                   all_slopes_positive=valid))
summary=dict(schema='pbrs.rpc-proof-summary.v1',source=report['source'],qualified=False,
             captures=len(report['runs']),successful_rpcs=report['successful_rpcs'],
             limitations=report['plan']['limitations'],results=rows,
             interval_warning='Five local pairs with process startup in the measurement windows; no independent-host confidence or leadership qualification')
(base/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
for row in rows:
 print(row['cell'],row['endpoint'],'native',row['native_cpu_us_per_rpc_median'],'tonic',row['tonic_cpu_us_per_rpc_median'],'ratio',row['median_paired_ratio'],'range',row['paired_ratio_range'])
